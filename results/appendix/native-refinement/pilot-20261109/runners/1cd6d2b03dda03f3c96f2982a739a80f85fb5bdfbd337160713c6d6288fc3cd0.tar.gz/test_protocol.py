import ast
import sys
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import PROTOCOL, digest, fingerprint, reservation_usd, time_limit, verify_task
from install_runtime import replace_once


def task():
    return {"id": "crystalyze/pxrd-100/case/01", "method": "crystalyze", "candidate_cif": "cif",
            "candidate_sha256": digest(b"cif"), "pattern_text": "pattern", "pattern_sha256": digest(b"pattern"),
            "protocol_sha256": fingerprint(PROTOCOL), "timeout_seconds": 3600}


def test_reference_fields_rejected():
    value = task()
    verify_task(value)
    value["reference_cif"] = "truth"
    with pytest.raises(ValueError):
        verify_task(value)


def test_changed_inputs_rejected():
    value = task()
    value["pattern_text"] += "changed"
    with pytest.raises(ValueError):
        verify_task(value)


def test_path_escape_rejected():
    value = task()
    value["id"] = "../../oops"
    with pytest.raises(ValueError):
        verify_task(value)


def test_reservation_covers_full_timeout_and_margin():
    assert reservation_usd(task()) > 3600 * (.000222 + 2 * .0000131 + 8 * .00000222)


def test_timeout():
    import time
    with pytest.raises(TimeoutError):
        with time_limit(.01):
            time.sleep(.1)


def test_patch_fails_closed(tmp_path):
    path = tmp_path / "source.py"
    path.write_text("a = 1\n")
    replace_once(path, "a = 1", "a = 2")
    ast.parse(path.read_text())
    with pytest.raises(ValueError):
        replace_once(path, "a = 1", "a = 3")
