"""Local, post-hoc scoring of returned CIFs; never exposes labels to workers."""
import argparse
import csv
import sys
from collections import Counter, defaultdict
from pathlib import Path

from common import REPO, digest, read_json, write_json

sys.path.insert(0, str(REPO))
from baselines.evaluate import guarded_structure_match, minimum_periodic_distance
from verifiable_pxrd.baselines.matching import element_composition_match, primary_metric_metadata
from pymatgen.core import Structure


def evaluate(cif, reference):
    predicted, truth = Structure.from_file(cif), Structure.from_file(reference)
    valid = predicted.volume >= .1 and minimum_periodic_distance(predicted) >= .5
    if not valid or not element_composition_match(predicted, truth):
        return False, ""
    exact, _, error = guarded_structure_match(predicted, truth)
    return exact, error


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--results", type=Path, required=True)
    args = parser.parse_args()
    rows, groups = [], defaultdict(list)
    for entry in read_json(args.inputs / "local-index.json"):
        method, corpus, case, slot = entry["id"].split("/")
        source = REPO / entry["candidate_path"]
        reference = REPO / entry["reference_path"]
        if digest(reference.read_bytes()) != entry["reference_sha256"]:
            raise ValueError(f"Reference changed: {reference}")
        directory = args.results / "candidates" / entry["id"]
        result = read_json(directory / "result.json") if (directory / "result.json").exists() else {"status": "pending"}
        if result.get("input_sha256", digest(source.read_bytes())) != digest(source.read_bytes()):
            raise ValueError("Original CIF hash mismatch")
        before, before_error = evaluate(source, reference)
        after, error = None, ""
        if result["status"] == "completed":
            try:
                after, error = evaluate(directory / "refined.cif", reference)
            except Exception as exc:
                after, error = False, str(exc)
        paired = result.get("paired_profile", {})
        row = {"id": entry["id"], "method": method, "corpus": corpus, "case": case, "slot": int(slot),
               "status": result["status"], "before_exact": before, "after_exact": after,
               "after_with_failure_fallback": after if after is not None else (before if result["status"] != "pending" else None),
               "original_label": entry["before_structure_match"], "wall_seconds": result.get("wall_seconds"),
               "before_rwp": paired.get("before", {}).get("rwp_percent"),
               "after_rwp": paired.get("after", {}).get("rwp_percent"),
               "error": error or before_error or result.get("error", "")}
        rows.append(row)
        groups[(method, corpus)].append(row)
    summary = []
    for (method, corpus), members in groups.items():
        completed = [r for r in members if r["status"] == "completed"]
        paired = [r for r in completed if r["before_rwp"] is not None and r["after_rwp"] is not None]
        summary.append({"method": method, "corpus": corpus, "candidates": len(members),
            "status": dict(Counter(r["status"] for r in members)),
            "before_exact": sum(r["before_exact"] for r in members),
            "after_with_failure_fallback": sum(bool(r["after_with_failure_fallback"]) for r in members),
            "gained": sum(not r["before_exact"] and r["after_exact"] for r in completed),
            "lost": sum(r["before_exact"] and not r["after_exact"] for r in completed),
            "paired_profile_n": len(paired),
            "original_label_disagreements": sum(r["before_exact"] != r["original_label"] for r in members)})
    with (args.results / "scores.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    write_json(args.results / "summary.json", {"pilot": read_json(args.inputs / "manifest.json")["pilot"],
        "metric": primary_metric_metadata(), "groups": summary,
        "warning": "Pilot rows are implementation checks, not benchmark recovery-rate estimates. Pending results are never complete failures."})
    for row in summary:
        print(row)


if __name__ == "__main__":
    main()
