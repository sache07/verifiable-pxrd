"""Retrieve completed Modal calls without starting any new paid computation."""
import argparse
from pathlib import Path
import modal
from common import read_json
from remote import collect

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("ledger", type=Path)
    args = parser.parse_args()
    for record in read_json(args.ledger)["calls"]:
        destination = Path(record["output"])
        if (destination / "candidates" / record["id"] / "result.json").exists():
            continue
        collect(modal.FunctionCall.from_id(record["call_id"]).get(), destination)
