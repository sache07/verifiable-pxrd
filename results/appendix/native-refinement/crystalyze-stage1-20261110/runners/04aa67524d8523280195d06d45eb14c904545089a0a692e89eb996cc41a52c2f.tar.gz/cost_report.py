"""Estimate resource charges and full-sweep scale from completed pilot records."""
import argparse
from collections import defaultdict
from statistics import mean, median
from pathlib import Path
from common import PROTOCOL, REPO, read_json, reservation_usd, write_json
import csv


def rate(result):
    gpu = result.get("gpu", "")
    return 2 * .0000131 + 8 * .00000222 + (.000164 if "T4" in gpu else .000222 if gpu else 0.)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    groups = defaultdict(list)
    for run in args.runs:
        for path in (run / "candidates").rglob("result.json"):
            result = read_json(path)
            groups[result["id"].split("/")[0]].append(result)
    records = []
    for method, results in groups.items():
        config = PROTOCOL["methods"][method]
        available = 0
        for corpus in ("pxrd-100", "pxrd-ood"):
            path = REPO / "results/baselines" / method / corpus / config["variant"] / "candidates.csv"
            available += sum(bool(r["candidate_path"]) for r in csv.DictReader(path.open()))
        seconds = [r.get("remote_wall_seconds", r["wall_seconds"]) for r in results]
        charges = [s * rate(r) for s, r in zip(seconds, results)]
        records.append({"method": method, "pilot_finished": len(results), "full_available_candidates": available,
            "mean_wall_seconds": mean(seconds), "median_wall_seconds": median(seconds),
            "pilot_resource_estimate_usd": sum(charges),
            "full_extrapolation_at_pilot_mean_usd": available * mean(charges),
            "full_conservative_reservation_usd": available * reservation_usd({"method": method, "timeout_seconds": config["timeout_seconds"]})})
    write_json(args.output, {"rates_url": "https://modal.com/pricing", "rate_date": "2026-11-09",
        "cpu_cores": 2, "memory_gib": 8, "methods": records,
        "caveat": "Resource-time estimates, not invoices. Excludes build/startup/idle time. Pilot is size-stratified, not a representative cost sample; full-sweep extrapolation is tentative. Failed calls remain included."})
    for record in records:
        print(record)


if __name__ == "__main__":
    main()
