"""Recover the exact small runner source from a previously built Modal image.

Starts one CPU-only audit process (60-second limit); never reruns a refinement.
"""
import argparse
import gzip
import io
import json
import tarfile
from pathlib import Path
import modal
from common import digest, fingerprint

REMOTE = """
import json
from pathlib import Path
root = Path('/opt/refinement')
print(json.dumps({p.name: p.read_text() for p in root.iterdir() if p.is_file() and p.suffix in {'.py', '.json'}}))
"""

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("image")
    parser.add_argument("expected_hash")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    app = modal.App("pxrd-refinement-source-audit")
    with app.run():
        sandbox = modal.Sandbox.create("python", "-c", REMOTE, app=app, image=modal.Image.from_id(args.image),
                                       cpu=.125, memory=256, timeout=60, block_network=True)
        content = sandbox.stdout.read()
        sandbox.wait()
        if sandbox.returncode:
            raise RuntimeError(sandbox.stderr.read())
    files = json.loads(content)
    actual = fingerprint({name: digest(value.encode()) for name, value in sorted(files.items()) if name.endswith(".py")})
    if actual != args.expected_hash:
        raise ValueError(f"Image runner hash {actual} != expected {args.expected_hash}")
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w") as archive:
        for name, value in sorted(files.items()):
            payload = value.encode()
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            archive.addfile(info, io.BytesIO(payload))
    args.output.mkdir(parents=True, exist_ok=True)
    path = args.output / f"{actual}.tar.gz"
    path.write_bytes(gzip.compress(buffer.getvalue(), mtime=0))
    print(path)
