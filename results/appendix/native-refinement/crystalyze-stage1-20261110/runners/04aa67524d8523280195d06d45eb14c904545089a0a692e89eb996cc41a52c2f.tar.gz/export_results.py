"""Create a small public result bundle from explicitly selected local run folders."""
import argparse
import gzip
import shutil
from pathlib import Path
from common import digest, read_json, write_json

KEEP = {"input.cif", "refined.cif", "result.json", "paired-profile.json", "paired-profiles.npz"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--runners", type=Path, help="Directory containing hash-named source snapshots")
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError("Choose a new bundle path; existing output will not be overwritten")
    args.output.mkdir(parents=True)
    metadata = args.output / "inputs"
    metadata.mkdir()
    for filename in ("manifest.json", "local-index.json", "missing.json"):
        shutil.copy2(args.inputs / filename, metadata / filename)
    sources = {}
    runner_hashes = set()
    for run in args.runs:
        for result in sorted((run / "candidates").rglob("result.json")):
            identifier = read_json(result)["id"]
            runner_hashes.add(read_json(result).get("code_sha256"))
            target = args.output / "candidates" / identifier
            if target.exists():
                raise ValueError(f"Duplicate result ID: {identifier}")
            target.mkdir(parents=True)
            for path in result.parent.iterdir():
                if path.name in KEEP or (path.name.startswith("stage-") and path.suffix in {".cif", ".npz"}):
                    shutil.copy2(path, target / path.name)
                elif path.name == "stages.json":
                    (target / "stages.json.gz").write_bytes(gzip.compress(path.read_bytes(), mtime=0))
                elif path.name == "worker.log":
                    (target / "worker.log.gz").write_bytes(gzip.compress(path.read_bytes(), mtime=0))
                elif path.name in {"packages.json", "sources.lock.json", "patched-sources.json", "binary-lock.json"}:
                    sha = digest(path.read_bytes())
                    store = args.output / "provenance" / (sha + ".json")
                    store.parent.mkdir(exist_ok=True)
                    if not store.exists():
                        shutil.copy2(path, store)
                    sources.setdefault(identifier, {})[path.name] = str(store.relative_to(args.output))
    if args.runners:
        for sha in runner_hashes - {None}:
            source = args.runners / f"{sha}.tar.gz"
            if not source.exists():
                raise FileNotFoundError(f"Missing actual worker source snapshot: {source}")
            target = args.output / "runners" / source.name
            target.parent.mkdir(exist_ok=True)
            shutil.copy2(source, target)
    files = {str(p.relative_to(args.output)): digest(p.read_bytes()) for p in sorted(args.output.rglob("*")) if p.is_file()}
    write_json(args.output / "manifest.json", {"files": files, "provenance": sources,
        "selection": "Explicit run folders; no filtering by success or fit score", "pilot": read_json(args.inputs / "manifest.json")["pilot"]})


if __name__ == "__main__":
    main()
