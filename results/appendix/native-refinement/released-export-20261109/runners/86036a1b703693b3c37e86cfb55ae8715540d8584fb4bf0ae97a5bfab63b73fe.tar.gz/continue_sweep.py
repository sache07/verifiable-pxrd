"""Resume selected lanes from an immutable runner snapshot; drain prior calls.

The old local coordinator must be stopped first. Detached Modal calls remain
running and are reconnected by ID, never resubmitted. Inactive methods retain
their completed outputs but receive no new calls.
"""
import argparse
from collections import Counter, deque
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
import json
import os
from pathlib import Path
import sys
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--tasks', type=Path, required=True)
    parser.add_argument('--sources', type=Path, required=True)
    parser.add_argument('--methods', required=True)
    args = parser.parse_args()
    root = args.plan.resolve().parent
    plan = json.loads(args.plan.read_text())
    sys.path.insert(0, str(root / 'runner'))
    os.environ['MODAL_PROFILE'] = plan['profile']
    os.environ['NATIVE_REFINEMENT_SOURCES'] = str(args.sources.resolve())
    os.environ['NATIVE_GPU_CONCURRENCY'] = str(plan['gpu_workers'])
    os.environ['NATIVE_CPU_CONCURRENCY'] = str(plan['cpu_workers'])
    from common import code_hash, fingerprint, read_json, verify_task, write_json
    from sweep_budget import Budget
    import modal
    from remote import app, collect, cpu_worker, gpu_worker, SOURCE_HASH_AT_IMPORT
    if SOURCE_HASH_AT_IMPORT != plan['source_hash']:
        raise ValueError('Immutable runner snapshot does not match original plan')
    tasks = read_json(args.tasks)
    if fingerprint(tasks) != plan['tasks_sha256']:
        raise ValueError('Tasks differ from original plan')
    tasks = [t for i, t in enumerate(tasks) if i % plan['shards'] == plan['shard']]
    if [t['id'] for t in tasks] != plan['ids']:
        raise ValueError('Original shard differs')
    enabled = set(args.methods.split(','))
    budget = Budget(plan['ledger'], plan['budget_usd'])
    records = budget.records()
    queues = {'gpu': deque(), 'cpu': deque()}
    reconnect, deferred, statuses = [], Counter(), Counter()
    for task in tasks:
        verify_task(task)
        key = fingerprint({'task': task, 'source': plan['source_hash']})
        prior = records.get(key)
        path = root / 'candidates' / task['id'] / 'result.json'
        if prior and (prior['profile'] != plan['profile'] or prior['output'] != str(root)):
            raise ValueError('Task belongs to another coordinator')
        if path.exists():
            result = read_json(path)
            if not prior or result.get('task_fingerprint') != key:
                raise ValueError('Untracked or mismatched result')
            budget.settle(key, task, result)
            statuses[(task['method'], result['status'])] += 1
        elif prior:
            if not prior.get('call_id'):
                raise ValueError('Ambiguous reservation; inspect before restarting')
            reconnect.append((task, key, prior['call_id']))
        elif task['method'] in enabled:
            queues['gpu' if task['method'] == 'crystalyze' else 'cpu'].append((task, key))
        else:
            deferred[task['method']] += 1
    limits = {'gpu': 2 * plan['gpu_workers'], 'cpu': 2 * plan['cpu_workers']}
    active, pending, abort = Counter(), {}, False

    def progress(state):
        write_json(root / 'continued-progress.json', dict(state=state, updated_unix=time.time(),
            methods=sorted(enabled), deferred=dict(deferred),
            collected={f'{m}/{s}': n for (m, s), n in statuses.items()},
            submitted_pending=dict(active), unsubmitted={k: len(v) for k, v in queues.items()}))

    print(f"Resuming {plan['profile']}: {len(reconnect)} calls; enabled {enabled}; deferred {dict(deferred)}", flush=True)
    with modal.enable_output(), app.run(name=plan['campaign'] + '-gpu-continuation', detach=True):
        if code_hash() != plan['source_hash']:
            raise ValueError('Snapshot changed during build')
        with ThreadPoolExecutor(max_workers=sum(limits.values()) + len(reconnect)) as pool:
            def track(task, key, call):
                kind = 'gpu' if task['method'] == 'crystalyze' else 'cpu'
                active[kind] += 1
                pending[pool.submit(call.get)] = (task, key, kind, call.object_id)
            for task, key, call_id in reconnect:
                track(task, key, modal.FunctionCall.from_id(call_id))
            while pending or any(queues.values()):
                if not abort:
                    for kind, queue in queues.items():
                        while queue and active[kind] < limits[kind]:
                            task, key = queue[0]
                            if not budget.reserve(key, task, profile=plan['profile'], output=str(root),
                                    campaign=plan['campaign'], source_hash=plan['source_hash']):
                                break
                            queue.popleft()
                            try:
                                call = (gpu_worker if kind == 'gpu' else cpu_worker).spawn(
                                    task, plan['campaign'], plan['source_hash'])
                                budget.update(key, call_id=call.object_id, state='submitted')
                                track(task, key, call)
                            except Exception as error:
                                budget.update(key, state='submission_unknown', error=repr(error))
                                abort = True
                                break
                progress('draining_after_error' if abort else 'running')
                if not pending:
                    break
                done, _ = wait(pending, timeout=30, return_when=FIRST_COMPLETED)
                for future in done:
                    task, key, kind, call_id = pending.pop(future)
                    active[kind] -= 1
                    try:
                        payload = future.result()
                        collect(payload, root)
                        budget.settle(key, task, payload['result'])
                        statuses[(task['method'], payload['result']['status'])] += 1
                    except Exception as error:
                        budget.update(key, state='collection_error', error=repr(error))
                        print(f'Collection error {call_id}: {error}', flush=True)
                        abort = True
    progress('needs_recovery' if abort else 'budget_paused' if any(queues.values()) else 'complete')


if __name__ == '__main__':
    main()
