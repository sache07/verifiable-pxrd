#!/usr/bin/env python3
"""Save the selected, fully converged GSAS-II model as final.gpx."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve())
    )
    hist = project.histogram(0)
    x = hist.getdata("X")
    hist.data["Limits"] = [
        [float(x[0]), float(x[-1])],
        [float(x[0]), float(x[-1])],
    ]
    # Explicitly retain only the accepted nuisance model. The active flags for
    # scales, cells, shift, background and accepted phase broadening remain as
    # a transparent record of the final refinement.
    sample = hist.data["Sample Parameters"]
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key] = [0.0, False]
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["LeBail"] = False
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
        phase.data["General"]["doPawley"] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.set_Frozen()
    project.save()

    # Reopen once before handoff and report the exact saved state.
    reopened = G2.G2Project(gpxfile=str(args.output.resolve()))
    rhist = reopened.histogram(0)
    masses = {}
    for phase in reopened.phases():
        hap = phase.data["Histograms"][rhist.name]
        masses[phase.name] = float(phase.data["General"]["Mass"] * hap["Scale"][0])
    total = sum(masses.values())
    print(
        json.dumps(
            {
                "project": str(args.output.resolve()),
                "histogram": rhist.name,
                "limits": rhist.data["Limits"],
                "cached_wR_percent": float(rhist.get_wR()),
                "fractions": {key: value / total for key, value in masses.items()},
                "frozen": [str(value) for value in reopened.get_Frozen()],
            }
        )
    )


if __name__ == "__main__":
    main()
