#!/usr/bin/env python3
"""Refine a selected atom group while holding profile-shape terms fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def lattice_matrix(cell: dict) -> np.ndarray:
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    alpha, beta, gamma = np.deg2rad(
        [cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]]
    )
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * np.cos(gamma), b * np.sin(gamma), 0.0])
    vcx = c * np.cos(beta)
    vcy = c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)
    vcz = np.sqrt(max(0.0, c * c - vcx * vcx - vcy * vcy))
    return np.array([va, vb, [vcx, vcy, vcz]])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("--elements", nargs="*", default=[])
    parser.add_argument("--labels", nargs="*", default=[])
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument(
        "--max-component-A",
        type=float,
        default=None,
        help="optional GSAS shift-variable bound; normally omit and use the result only as a line-search direction",
    )
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve())
    )
    hist = project.histogram(0)
    # Coordinate changes are judged under the same frozen peak profile.
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "Zero"):
        if key in inst:
            inst[key][2] = False
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    phase = project.phase(args.phase)
    initial_cell = phase.get_cell()
    matrix = lattice_matrix(initial_cell)
    selected = []
    initial_coordinates = {}
    for index, atom in enumerate(phase.atoms()):
        if atom.element in args.elements or atom.label in args.labels:
            atom.refinement_flags = "X"
            selected.append(atom.label)
            initial_coordinates[atom.label] = np.array(atom.coordinates, dtype=float)
            if args.max_component_A is not None:
                for axis, variable in enumerate(("dAx", "dAy", "dAz")):
                    delta = args.max_component_A / np.linalg.norm(matrix[axis])
                    project.set_Controls(
                        "parmMin", float(-delta), variable=f"{phase.id}::{variable}:{index}"
                    )
                    project.set_Controls(
                        "parmMax", float(delta), variable=f"{phase.id}::{variable}:{index}"
                    )
    if not selected:
        raise ValueError("No atoms selected")

    project.set_Controls("cycles", args.cycles)
    project.set_Frozen()
    project.save()
    project.refine(makeBack=False)
    project.save()

    movements = []
    for atom in phase.atoms():
        if atom.label not in initial_coordinates:
            continue
        delta = np.asarray(atom.coordinates) - initial_coordinates[atom.label]
        delta -= np.round(delta)
        cart = delta @ matrix
        movements.append(
            {
                "label": atom.label,
                "delta_fractional": delta.tolist(),
                "displacement_A": float(np.linalg.norm(cart)),
                "cartesian_components_A": cart.tolist(),
            }
        )
    result = {
        "wR_percent": hist.get_wR(),
        "selected_phase": phase.name,
        "selected_atoms": selected,
        "cell": phase.get_cell(),
        "coordinate_movements": movements,
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(atom.coordinates),
                "uiso_A2": float(atom.uiso),
            }
            for atom in phase.atoms()
        ],
        "instrument": {
            key: float(inst[key][1])
            for key in ("U", "W", "X", "SH/L", "Polariz.")
            if key in inst
        },
        "frozen": project.get_Frozen(),
    }
    args.output.with_suffix(".summary.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
