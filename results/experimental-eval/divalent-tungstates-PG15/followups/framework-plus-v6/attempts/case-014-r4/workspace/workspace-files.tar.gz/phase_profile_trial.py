#!/usr/bin/env python3
"""Refine one phase broadening term while the common profile is fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("--mode", choices=("size", "strain"), required=True)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--passes", type=int, default=3)
    parser.add_argument(
        "--preserve-existing",
        action="store_true",
        help="retain previously accepted size/strain values and refinement flags",
    )
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve())
    )
    hist = project.histogram(0)
    hid = hist.id
    inst = hist.data["Instrument Parameters"][0]
    for key in inst:
        if isinstance(inst[key], list) and len(inst[key]) >= 3:
            inst[key][2] = False
    sample = hist.data["Sample Parameters"]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = False
    sample["Shift"][1] = True
    hist.data["Background"][0][1] = True

    selected = None
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        if not args.preserve_existing:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 10.0
            hap["Size"][2] = [False, False, False]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][1][1] = 0.0
            hap["Mustrain"][2] = [False, False, False]
        if phase.name == args.phase:
            selected = phase
    if selected is None:
        parser.error(f"phase {args.phase!r} not found")
    hap = selected.data["Histograms"][hist.name]
    if args.mode == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.04, variable=f"{selected.id}:{hid}:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{selected.id}:{hid}:Size;i")
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{selected.id}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{selected.id}:{hid}:Mustrain;i")

    project.set_Controls("cycles", args.cycles)
    history = []
    for index in range(args.passes):
        project.set_Frozen()
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = {
            "pass": index + 1,
            "wR_percent": float(project.histogram(0).get_wR()),
            "size_um": float(hap["Size"][1][0]),
            "strain_ppm": float(hap["Mustrain"][1][0]),
            "frozen": [str(value) for value in project.get_Frozen()],
        }
        history.append(row)
        print(json.dumps(row), flush=True)
    args.output.with_suffix(".summary.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
