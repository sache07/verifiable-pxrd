#!/usr/bin/env python3
"""Create the submission CIFs, fit.csv and result.json from a fresh replay."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path

import numpy as np


PHASE_FILES = {
    "SrWO4": "phase_SrWO4.cif",
    "WO3": "phase_WO3.cif",
    "Sr3WO6": "phase_Sr3WO6.cif",
    "Sr3W2O9": "phase_Sr3W2O9.cif",
}

IDENTIFICATIONS = {
    "SrWO4": "scheelite SrWO4, I41/a (No. 88)",
    "WO3": "monoclinic WO3, P21/c (No. 14)",
    "Sr3WO6": "tentative Sr3WO6 model, P21/c (No. 14), derived from the isovalent Sr3UO6 prototype",
    "Sr3W2O9": "monoclinic Sr3W2O9, C2/c (No. 15)",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("replay", type=Path)
    parser.add_argument("--project", type=Path, default=Path("final.gpx"))
    parser.add_argument("--workspace", type=Path, default=Path("."))
    args = parser.parse_args()

    replay_dir = args.replay.resolve()
    workspace = args.workspace.resolve()
    report = json.loads((replay_dir / "replay.json").read_text())
    if report.get("status") != "replayed":
        raise RuntimeError(f"replay failed: {report}")
    phase_names = {row["name"] for row in report["phases"]}
    if phase_names != set(PHASE_FILES):
        raise RuntimeError(f"unexpected replay phase inventory: {sorted(phase_names)}")

    rows = []
    for phase in report["phases"]:
        destination = workspace / PHASE_FILES[phase["name"]]
        shutil.copy2(replay_dir / phase["cif"], destination)
        rows.append(
            {
                "name": phase["name"],
                "identification": IDENTIFICATIONS[phase["name"]],
                "cif_path": destination.name,
                "weight_fraction": float(phase["weight_fraction"]),
            }
        )

    with np.load(replay_dir / "prediction.npz", allow_pickle=False) as arrays:
        x = arrays["x"].copy()
        observed = arrays["observed"].copy()
        calculated = arrays["predicted"].copy()
    difference = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    weighted_sse = float(np.sum(weights * difference**2))
    rwp = float(
        100.0
        * np.sqrt(weighted_sse / np.sum(weights * observed**2))
    )
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    np.savetxt(
        workspace / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.10f",
    )

    project = args.project.resolve()
    result = {
        "schema_version": 1,
        "method": "GSAS-II multiphase Rietveld refinement with fresh atomic forward replay",
        "project_path": project.name,
        "project_sha256": sha256(project),
        "refinement_histogram": report["histogram"],
        "phases": rows,
        "weight_fraction_basis": "Normalized over the modeled crystalline phases only; no amorphous fraction was determined.",
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "weighted_sum_of_squared_residuals": weighted_sse,
            "n_points": int(len(x)),
            "weighting": "1/max(observed_counts, 1); pointwise standard uncertainties were not supplied",
            "evaluation_grid": report["evaluation_grid"],
        },
        "replay_validation": {
            "status": report["status"],
            "parameters_optimized_during_replay": report["parameters_optimized"],
            "profile_review_flags": report["profile_review_flags"],
        },
    }
    (workspace / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(result["fit_statistics"]))


if __name__ == "__main__":
    main()
