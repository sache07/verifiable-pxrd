#!/usr/bin/env python3
"""Rebuild a bounded common profile while retaining accepted phase terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=10)
    parser.add_argument("--passes", type=int, default=5)
    parser.add_argument("--start", nargs=3, type=float, default=[10.0, 20.0, 2.0], metavar=("U", "W", "X"))
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve())
    )
    hist = project.histogram(0)
    hid = hist.id
    inst = hist.data["Instrument Parameters"][0]
    for key in inst:
        if isinstance(inst[key], list) and len(inst[key]) >= 3:
            inst[key][2] = False
    for key, value, low, high in (
        ("U", args.start[0], 0.0, 40.0),
        ("W", args.start[1], 2.0, 40.0),
        ("X", args.start[2], 0.1, 6.0),
    ):
        inst[key][1] = value
        inst[key][2] = True
        project.set_Controls("parmMin", low, variable=f":{hid}:{key}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{key}")
    hist.data["Background"][0][1] = True
    sample = hist.data["Sample Parameters"]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = False
    sample["Shift"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        for atom in phase.atoms():
            atom.refinement_flags = " "

    project.set_Controls("cycles", args.cycles)
    history = []
    for index in range(args.passes):
        project.set_Frozen()
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = {
            "pass": index + 1,
            "wR_percent": float(project.histogram(0).get_wR()),
            "instrument": {key: float(inst[key][1]) for key in ("U", "W", "X", "SH/L", "Polariz.")},
            "profiles": {
                phase.name: {
                    "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                    "strain_ppm": float(phase.data["Histograms"][hist.name]["Mustrain"][1][0]),
                }
                for phase in project.phases()
            },
            "frozen": [str(value) for value in project.get_Frozen()],
        }
        history.append(row)
        print(json.dumps(row), flush=True)
    args.output.with_suffix(".summary.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
