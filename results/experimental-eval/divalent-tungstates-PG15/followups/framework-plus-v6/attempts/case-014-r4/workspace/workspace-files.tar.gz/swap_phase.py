#!/usr/bin/env python3
"""Replace one phase record in a converged GSAS-II project and reconverge.

The old phase is removed from both the phase tree and histogram reflection
lists.  Its crystalline weight fraction and accepted isotropic size/strain
state are used only as starting values for the replacement record.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    rows = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(mass_scale)
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": phase.get_cell(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    total = sum(masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = float(mass / total)
    inst = hist.data["Instrument Parameters"][0]
    return {
        "label": label,
        "wR_percent": float(hist.get_wR()),
        "phases": rows,
        "instrument": {
            key: float(inst[key][1])
            for key in ("U", "V", "W", "X", "SH/L", "Polariz.")
            if key in inst
        },
        "shift_um": float(hist.data["Sample Parameters"]["Shift"][0]),
        "frozen": [str(v) for v in project.get_Frozen()],
    }


def run(project: G2.G2Project, label: str, history: list[dict]) -> None:
    project.set_Frozen()
    project.save()
    project.refine(makeBack=False)
    project.save()
    row = snapshot(project, label)
    history.append(row)
    print(
        json.dumps(
            {
                "label": label,
                "wR_percent": row["wR_percent"],
                "fractions": {
                    phase["name"]: phase["weight_fraction"]
                    for phase in row["phases"]
                },
                "frozen": row["frozen"],
            }
        ),
        flush=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("old_name")
    parser.add_argument("new_name")
    parser.add_argument("cif", type=Path)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--passes", type=int, default=4)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.base.resolve()), newgpx=str(output))
    hist = project.histogram(0)
    old = project.phase(args.old_name)
    if old is None:
        raise KeyError(f"phase {args.old_name!r} not found")
    old_hap = old.data["Histograms"][hist.name]
    old_mass_scale = float(old.data["General"]["Mass"] * old_hap["Scale"][0])
    old_size = float(old_hap["Size"][1][0])
    old_size_refine = bool(old_hap["Size"][2][0])
    old_strain = float(old_hap["Mustrain"][1][0])
    old_strain_refine = bool(old_hap["Mustrain"][2][0])

    # Remove the phase from each location represented in the GPX tree.
    del project.data["Phases"][args.old_name]
    hist.data["Reflection Lists"].pop(args.old_name, None)
    for branch in project.names:
        if branch and branch[0] == "Phases" and args.old_name in branch:
            branch.remove(args.old_name)
    project.update_ids()

    phase = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.new_name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [old_mass_scale / float(phase.data["General"]["Mass"]), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = old_size
    hap["Size"][2] = [old_size_refine, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = old_strain
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [old_strain_refine, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]
    for atom in phase.atoms():
        atom.refinement_flags = " "

    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-4
    hid = hist.id
    for p in project.phases():
        p.set_HAP_refinements({"Scale": True})
        p.set_refinements({"Cell": False})
        project.set_Controls("parmMin", 1e-12, variable=f"{p.id}:{hid}:Scale")
    hist.data["Background"][0][1] = True
    hist.data["Sample Parameters"]["Shift"][1] = True
    # The already established shared profile remains fixed for a fair record
    # comparison; all optional nuisance terms remain neutral.
    inst = hist.data["Instrument Parameters"][0]
    for key, value in inst.items():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False

    history = [snapshot(project, "replacement_added")]
    run(project, "background_scales_shift", history)
    for p in project.phases():
        p.set_refinements({"Cell": True})
    for i in range(args.passes):
        run(project, f"cell_reconverge_{i + 1}", history)

    output.with_suffix(".summary.json").write_text(
        json.dumps(history, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
