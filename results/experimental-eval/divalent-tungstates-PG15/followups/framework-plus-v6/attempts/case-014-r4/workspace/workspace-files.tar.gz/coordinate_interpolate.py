#!/usr/bin/env python3
"""Test a fixed, physically limited coordinate shift toward a refined target."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def lattice_matrix(cell: dict) -> np.ndarray:
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    alpha, beta, gamma = np.deg2rad(
        [cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]]
    )
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * np.cos(gamma), b * np.sin(gamma), 0.0])
    vcx = c * np.cos(beta)
    vcy = c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)
    vcz = np.sqrt(max(0.0, c * c - vcx * vcx - vcy * vcy))
    return np.array([va, vb, [vcx, vcy, vcz]])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("--elements", nargs="*", default=[])
    parser.add_argument("--labels", nargs="*", default=[])
    parser.add_argument("--distance-A", type=float, required=True)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--passes", type=int, default=3)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve())
    )
    target = G2.G2Project(gpxfile=str(args.target.resolve()))
    hist = project.histogram(0)
    source_phase = project.phase(args.phase)
    target_phase = target.phase(args.phase)
    matrix = lattice_matrix(source_phase.get_cell())
    target_atoms = {atom.label: atom for atom in target_phase.atoms()}
    movements = []

    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.set_refinements({"Cell": True})
        phase.data["Histograms"][hist.name]["Scale"][1] = True

    for atom in source_phase.atoms():
        if atom.element not in args.elements and atom.label not in args.labels:
            continue
        other = target_atoms[atom.label]
        start = np.asarray(atom.coordinates, dtype=float)
        delta = np.asarray(other.coordinates, dtype=float) - start
        delta -= np.round(delta)
        full_distance = float(np.linalg.norm(delta @ matrix))
        factor = min(1.0, args.distance_A / full_distance) if full_distance else 0.0
        applied = delta * factor
        atom.coordinates = list(start + applied)
        movements.append(
            {
                "label": atom.label,
                "target_distance_A": full_distance,
                "applied_distance_A": float(np.linalg.norm(applied @ matrix)),
                "delta_fractional": applied.tolist(),
            }
        )
    if not movements:
        raise ValueError("No atoms selected")

    inst = hist.data["Instrument Parameters"][0]
    for key in inst:
        if isinstance(inst[key], list) and len(inst[key]) >= 3:
            inst[key][2] = False
    sample = hist.data["Sample Parameters"]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = False
    sample["Shift"][1] = True
    hist.data["Background"][0][1] = True

    project.set_Controls("cycles", args.cycles)
    history = []
    for index in range(args.passes):
        project.set_Frozen()
        project.save()
        project.refine(makeBack=False)
        project.save()
        history.append(float(project.histogram(0).get_wR()))
        print(json.dumps({"pass": index + 1, "wR_percent": history[-1]}), flush=True)

    result = {
        "phase": args.phase,
        "movements": movements,
        "cached_wR_history_percent": history,
        "cell": source_phase.get_cell(),
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(atom.coordinates),
                "uiso_A2": float(atom.uiso),
            }
            for atom in source_phase.atoms()
        ],
        "frozen": [str(value) for value in project.get_Frozen()],
    }
    args.output.with_suffix(".summary.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
