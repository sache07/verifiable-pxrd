#!/usr/bin/env python3
"""Challenge one intensity/profile nuisance term on a converged GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def summary(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": phase.get_cell(),
                "preferred_orientation": hap["Pref.Ori."],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    total = sum(masses)
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = float(mass / total)
    return {
        "label": label,
        "wR_percent": float(hist.get_wR()),
        "instrument": {
            key: float(inst[key][1])
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
            if key in inst
        },
        "sample": {
            key: float(sample[key][0])
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": phases,
        "frozen": [str(v) for v in project.get_Frozen()],
    }


def run_refinement(project: G2.G2Project, label: str, history: list[dict]) -> None:
    project.set_Frozen()
    project.save()
    project.refine(makeBack=False)
    project.save()
    row = summary(project, label)
    history.append(row)
    print(
        json.dumps(
            {
                "label": label,
                "wR_percent": row["wR_percent"],
                "instrument": row["instrument"],
                "sample": row["sample"],
                "fractions": {
                    p["name"]: p["weight_fraction"] for p in row["phases"]
                },
                "texture": {
                    p["name"]: {
                        "ratio": p["preferred_orientation"][1],
                        "axis": p["preferred_orientation"][3],
                        "refine": p["preferred_orientation"][2],
                    }
                    for p in row["phases"]
                },
                "frozen": row["frozen"],
            }
        ),
        flush=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--mode", choices=("none", "polarization", "asymmetry", "roughness", "texture"), required=True
    )
    parser.add_argument("--phase")
    parser.add_argument("--axis", nargs=3, type=int, metavar=("H", "K", "L"))
    parser.add_argument("--cycles", type=int, default=6)
    parser.add_argument(
        "--quick",
        action="store_true",
        help="stop after the nuisance-only screen with the common profile fixed",
    )
    parser.add_argument(
        "--physical-profile",
        action="store_true",
        help="constrain U/W/X to the laboratory generation ranges",
    )
    parser.add_argument(
        "--preserve-phase-profile",
        action="store_true",
        help="retain previously accepted phase size/strain terms",
    )
    args = parser.parse_args()
    if args.mode == "texture" and (not args.phase or args.axis is None):
        parser.error("texture mode requires --phase and --axis H K L")

    G2.SetPrintLevel("warn")
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.base.resolve()), newgpx=str(output))
    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-4
    project.set_Frozen()

    hist = project.histogram(0)
    hid = hist.id
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    # Clear every optional nuisance term before adding the challenged term.
    for key in inst:
        if isinstance(inst[key], list) and len(inst[key]) >= 3:
            inst[key][2] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = False
    sample["Transparency"][0] = 0.0
    sample["SurfRoughA"][0] = 0.0
    sample["SurfRoughB"][0] = 0.0
    hist.data["Background"][0][1] = True
    sample["Shift"][1] = True

    selected = None
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        if not args.preserve_phase_profile:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 10.0
            hap["Size"][2] = [False, False, False]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][1][1] = 0.0
            hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        if phase.name == args.phase:
            selected = phase
        project.set_Controls("parmMin", 1e-12, variable=f"{phase.id}:{hid}:Scale")

    project.set_Controls("parmMin", -800.0, variable=f":{hid}:Shift")
    project.set_Controls("parmMax", 800.0, variable=f":{hid}:Shift")

    if args.mode == "polarization":
        inst["Polariz."][1] = 0.7
        inst["Polariz."][2] = True
        project.set_Controls("parmMin", 0.5, variable=f":{hid}:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=f":{hid}:Polariz.")
    elif args.mode == "asymmetry":
        inst["SH/L"][2] = True
        project.set_Controls("parmMin", 0.005, variable=f":{hid}:SH/L")
        project.set_Controls("parmMax", 0.1, variable=f":{hid}:SH/L")
    elif args.mode == "roughness":
        sample["SurfRoughA"] = [0.2, True]
        sample["SurfRoughB"] = [0.1, True]
        project.set_Controls("parmMin", 0.05, variable=f":{hid}:SurfRoughA")
        project.set_Controls("parmMax", 0.6, variable=f":{hid}:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=f":{hid}:SurfRoughB")
        project.set_Controls("parmMax", 0.5, variable=f":{hid}:SurfRoughB")
    elif args.mode == "texture":
        if selected is None:
            parser.error(f"phase {args.phase!r} not found")
        hap = selected.data["Histograms"][hist.name]
        hap["Pref.Ori."][1] = 0.9
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(args.axis)
        project.set_Controls("parmMin", 0.7, variable=f"{selected.id}:{hid}:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{selected.id}:{hid}:MD")

    history = [summary(project, "initialized")]
    run_refinement(project, "nuisance_with_fixed_common_profile", history)

    if args.quick:
        output.with_suffix(".summary.json").write_text(
            json.dumps(history, indent=2, default=str) + "\n"
        )
        return

    # Rebuild the shared profile after the new intensity/profile choice.
    limits = {
        "U": (0.0, 40.0 if args.physical_profile else 60.0),
        "W": (2.0 if args.physical_profile else 0.0, 40.0 if args.physical_profile else 60.0),
        "X": (0.1 if args.physical_profile else 0.01, 6.0 if args.physical_profile else 10.0),
    }
    for key, (low, high) in limits.items():
        inst[key][2] = True
        inst[key][1] = float(np.clip(inst[key][1], low + 1e-6, high - 1e-6))
        project.set_Controls("parmMin", low, variable=f":{hid}:{key}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{key}")
    run_refinement(project, "common_profile_rebuild", history)
    run_refinement(project, "reconverged", history)

    output.with_suffix(".summary.json").write_text(
        json.dumps(history, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
