#!/usr/bin/env python3
"""Run the scorer's read-only atomic replay and report original-grid Rwp."""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path

import numpy as np


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--observed", type=Path, default=Path("inputs/pattern.csv"))
    args = parser.parse_args()

    project = args.project.resolve()
    observed = args.observed.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    worker = (
        Path(__file__).resolve().parent
        / "learned/divalent-tungstates/scorer/runtime/replay_worker.py"
    )
    spec = importlib.util.spec_from_file_location("frozen_replay_worker", worker)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    os.chdir(output)
    report = module.replay({"project": str(project), "observed": str(observed)})
    arrays = np.load("prediction.npz")
    y = arrays["observed"]
    calc = arrays["predicted"]
    weights = 1.0 / np.maximum(y, 1.0)
    rwp = float(
        100.0
        * np.sqrt(np.sum(weights * (y - calc) ** 2) / np.sum(weights * y**2))
    )
    report["original_grid_rwp_percent"] = rwp
    Path("replay.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "rwp_percent": rwp,
                      "fractions": {p["name"]: p["weight_fraction"] for p in report["phases"]},
                      "review": report["profile_review_flags"]}))


if __name__ == "__main__":
    main()
