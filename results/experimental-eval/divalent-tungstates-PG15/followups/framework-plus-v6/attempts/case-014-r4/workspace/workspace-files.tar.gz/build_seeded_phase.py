#!/usr/bin/env python3
"""Add a phase at a physically screened seed cell and rebuild a neutral baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("name")
    parser.add_argument("cif", type=Path)
    parser.add_argument("--cell", nargs=6, type=float, required=True)
    parser.add_argument("--fraction", type=float, default=0.05)
    parser.add_argument("--cycles", type=int, default=10)
    parser.add_argument("--passes", type=int, default=4)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve())
    )
    hist = project.histogram(0)
    phase = project.add_phase(
        str(args.cif.resolve()), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    general_cell = phase.data["General"]["Cell"]
    general_cell[1:7] = list(args.cell)
    general_cell[7] = float(G2lat.calc_V(G2lat.cell2A(args.cell)))

    existing_mass_scale = sum(
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
        if p.name != phase.name
    )
    phase.data["Histograms"][hist.name]["Scale"] = [
        args.fraction * existing_mass_scale / ((1.0 - args.fraction) * phase.data["General"]["Mass"]),
        True,
    ]

    inst = hist.data["Instrument Parameters"][0]
    for key in inst:
        if isinstance(inst[key], list) and len(inst[key]) >= 3:
            inst[key][2] = False
    for key, value in (("U", 0.0), ("W", 40.0), ("X", 6.0), ("SH/L", 0.03), ("Polariz.", 1.0)):
        inst[key][1] = value
    sample = hist.data["Sample Parameters"]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = False
    sample["Shift"][1] = True
    hist.data["Background"][0][1] = True

    for item in project.phases():
        item.set_refinements({"Cell": True})
        for atom in item.atoms():
            atom.refinement_flags = " "
        hap = item.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        project.set_Controls("parmMin", 1e-12, variable=f"{item.id}:{hist.id}:Scale")

    project.set_Controls("cycles", args.cycles)
    history = []
    for index in range(args.passes):
        project.set_Frozen()
        project.save()
        project.refine(makeBack=False)
        project.save()
        masses = np.array(
            [
                p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
                for p in project.phases()
            ]
        )
        row = {
            "pass": index + 1,
            "wR_percent": float(project.histogram(0).get_wR()),
            "phases": [
                {
                    "name": p.name,
                    "weight_fraction": float(mass / masses.sum()),
                    "cell": p.get_cell(),
                }
                for p, mass in zip(project.phases(), masses)
            ],
            "frozen": [str(value) for value in project.get_Frozen()],
        }
        history.append(row)
        print(json.dumps(row), flush=True)
    args.output.with_suffix(".summary.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
