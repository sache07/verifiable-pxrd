#!/usr/bin/env python3
"""Replay all active GSAS-II refinements for a small number of full passes."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(
            (
                phase.name,
                float(phase.data["General"]["Mass"] * hap["Scale"][0]),
            )
        )
    total = sum(value for _, value in masses)
    return {
        "label": label,
        "wR_percent": float(hist.get_wR()),
        "fractions": {name: value / total for name, value in masses},
        "frozen": [str(v) for v in project.get_Frozen()],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--passes", type=int, default=2)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve())
    )
    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-4
    history = [state(project, "loaded")]
    for i in range(args.passes):
        project.set_Frozen()
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = state(project, f"pass_{i + 1}")
        history.append(row)
        print(json.dumps(row), flush=True)
    args.output.with_suffix(".summary.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
