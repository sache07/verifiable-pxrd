#!/usr/bin/env python3
"""Compare conservative phase-broadening models under one common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def summarize(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    phases = []
    total = sum(
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    )
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "weight_fraction": float(
                    phase.data["General"]["Mass"] * hap["Scale"][0] / total
                ),
                "cell": phase.get_cell(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    return {
        "label": label,
        "wR_percent": hist.get_wR(),
        "instrument": {
            key: float(inst[key][1])
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
            if key in inst
        },
        "shift_um": float(hist.data["Sample Parameters"]["Shift"][0]),
        "phases": phases,
        "frozen": project.get_Frozen(),
    }


def refine(project: G2.G2Project, label: str, history: list[dict]) -> None:
    project.set_Frozen()
    project.save()
    project.refine(makeBack=False)
    project.save()
    row = summarize(project, label)
    history.append(row)
    print(
        json.dumps(
            {
                "label": label,
                "wR_percent": row["wR_percent"],
                "instrument": row["instrument"],
                "profiles": {
                    p["name"]: {
                        "size_um": p["size"][1][0],
                        "mustrain_ppm": p["mustrain"][1][0],
                    }
                    for p in row["phases"]
                },
                "frozen": row["frozen"],
            }
        ),
        flush=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--mode", choices=("common", "size", "strain", "both"), required=True
    )
    parser.add_argument("--phases", nargs="*", default=[])
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve())
    )
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 10.0, "W": 20.0, "X": 2.0}.items():
        inst[key][1] = value
        inst[key][2] = False
    for key in ("V", "Y", "Z", "SH/L", "Polariz.", "Zero"):
        if key in inst:
            inst[key][2] = False
    selected = set(args.phases) if args.phases else {p.name for p in project.phases()}
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        if phase.name in selected and args.mode in ("size", "both"):
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 0.30, "refine": True}}
            )
        if phase.name in selected and args.mode in ("strain", "both"):
            hap["Mustrain"][1][0] = 1000.0
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )

    project.set_Controls("cycles", args.cycles)
    hid = hist.id
    for key, lo, hi in (
        (f":{hid}:U", 0.0, 50.0),
        (f":{hid}:W", 0.0, 50.0),
        (f":{hid}:X", 0.01, 8.0),
    ):
        project.set_Controls("parmMin", lo, variable=key)
        project.set_Controls("parmMax", hi, variable=key)
    for phase in project.phases():
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:{hid}:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{phase.id}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{phase.id}:{hid}:Mustrain;i")

    history = [summarize(project, "initialized")]
    if args.mode != "common":
        refine(project, "phase_broadening_with_fixed_common", history)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, "common_profile", history)
    refine(project, "reconverged", history)
    args.output.with_suffix(".summary.json").write_text(
        json.dumps(history, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
