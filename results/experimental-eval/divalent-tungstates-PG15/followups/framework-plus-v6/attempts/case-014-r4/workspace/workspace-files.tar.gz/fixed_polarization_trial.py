#!/usr/bin/env python3
"""Set a fixed polarization value and reconverge all already-active terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    values = {
        phase.name: float(
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][hist.name]["Scale"][0]
        )
        for phase in project.phases()
    }
    total = sum(values.values())
    return {key: value / total for key, value in values.items()}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("polarization", type=float)
    parser.add_argument("--cycles", type=int, default=10)
    parser.add_argument("--passes", type=int, default=3)
    args = parser.parse_args()
    if not 0.5 <= args.polarization <= 1.0:
        parser.error("polarization must be in [0.5, 1.0]")

    G2.SetPrintLevel("warn")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve())
    )
    inst = project.histogram(0).data["Instrument Parameters"][0]
    inst["Polariz."][1] = args.polarization
    inst["Polariz."][2] = False
    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-4
    history = []
    for i in range(args.passes):
        project.set_Frozen()
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = {
            "pass": i + 1,
            "polarization": args.polarization,
            "wR_percent": float(project.histogram(0).get_wR()),
            "fractions": fractions(project),
            "frozen": [str(value) for value in project.get_Frozen()],
        }
        history.append(row)
        print(json.dumps(row), flush=True)
    args.output.with_suffix(".summary.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
