#!/usr/bin/env python3
"""Build and stage a conservative GSAS-II trial refinement.

This is an analysis helper. Final exports are made separately after the phase
inventory and nuisance model have been challenged.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter

from GSASII import GSASIIscriptable as G2


def background_coefficients(pattern: Path, order: int = 8) -> list[float]:
    data = np.loadtxt(pattern, delimiter=",", skiprows=1)
    x, y = data.T
    baseline = percentile_filter(y, percentile=18, size=401, mode="nearest")
    baseline = gaussian_filter1d(baseline, 100)
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, baseline, order - 1).tolist()


def instrument_text() -> str:
    return (
        "#GSAS-II Cu Kalpha laboratory instrument; starting profile only\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sp = hist.data["Sample Parameters"]
    result = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": {
            key: float(inst[key][1])
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
            if key in inst
        },
        "sample": {
            "Shift_um": float(sp["Shift"][0]),
            "SurfRoughA": float(sp["SurfRoughA"][0]),
            "SurfRoughB": float(sp["SurfRoughB"][0]),
        },
        "background": {
            "type": hist.data["Background"][0][0],
            "coefficients": [float(v) for v in hist.data["Background"][0][3:]],
        },
        "phases": [],
        "frozen": project.get_Frozen(),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "mass": float(phase.data["General"]["Mass"]),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    masses = np.array([p["scale"] * p["mass"] for p in result["phases"]])
    if masses.sum() > 0:
        for row, fraction in zip(result["phases"], masses / masses.sum()):
            row["weight_fraction"] = float(fraction)
    return result


def run_refinement(project: G2.G2Project, label: str, summaries: list[dict]) -> None:
    project.set_Frozen()
    project.save()
    project.refine(makeBack=False)
    project.save()
    row = snapshot(project, label)
    summaries.append(row)
    print(
        json.dumps(
            {
                "label": label,
                "wR_percent": row["wR_percent"],
                "fractions": {
                    phase["name"]: phase.get("weight_fraction")
                    for phase in row["phases"]
                },
                "frozen": row["frozen"],
            }
        ),
        flush=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+", help="NAME=CIF")
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    instfile = output.with_suffix(".instprm")
    instfile.write_text(instrument_text())

    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(args.pattern.resolve()), str(instfile), fmthint="comma"
    )
    phase_specs = []
    for item in args.phases:
        name, cif = item.split("=", 1)
        phase_specs.append((name, Path(cif).resolve()))
    phases = [
        project.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
        for name, cif in phase_specs
    ]

    hist.set_refinements(
        {
            "Limits": [float(hist.getdata("X")[0]), float(hist.getdata("X")[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": background_coefficients(args.pattern, 8),
                "refine": False,
            },
        }
    )
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 10.0, "V": 0.0, "W": 15.0, "X": 1.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.03, "Polariz.": 0.7, "Zero": 0.0}.items():
        if key in inst:
            inst[key][1] = value
            inst[key][2] = False
    sp = hist.data["Sample Parameters"]
    sp["Type"] = "Bragg-Brentano"
    sp["Gonio. radius"] = 200.0
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sp[key][0] = 0.0
        sp[key][1] = False
    sp["Scale"][0] = 1.0
    sp["Scale"][1] = False

    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / float(phase.data["General"]["Mass"]), False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0e6
        hap["Size"][1][1] = 1.0e6
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]
        phase.set_refinements({"Cell": False})
        phase.set_HAP_refinements({"Scale": False})

    project.set_Controls("cycles", args.cycles)
    hid = hist.id
    for key, lo, hi in (
        (f":{hid}:U", 0.0, 60.0),
        (f":{hid}:W", 0.0, 60.0),
        (f":{hid}:X", 0.01, 10.0),
        (f":{hid}:SH/L", 0.002, 0.2),
        (f":{hid}:Shift", -1000.0, 1000.0),
    ):
        project.set_Controls("parmMin", lo, variable=key)
        project.set_Controls("parmMax", hi, variable=key)
    for phase in phases:
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hid}:Scale")

    summaries: list[dict] = [snapshot(project, "initial")]

    # Establish intensity/background before positional and profile parameters.
    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    run_refinement(project, "background_scales", summaries)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(project, "add_shift", summaries)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_refinement(project, "add_cells", summaries)
    run_refinement(project, "reconverge_cells", summaries)

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    run_refinement(project, "add_W_X", summaries)

    hist.set_refinements({"Instrument Parameters": ["U"]})
    run_refinement(project, "add_U", summaries)
    run_refinement(project, "reconverge_common", summaries)

    summary_path = output.with_suffix(".summary.json")
    summary_path.write_text(json.dumps(summaries, indent=2, default=str) + "\n")
    # Keep the latest project under the requested name even if GSAS rewrites it.
    if Path(project.filename) != output:
        shutil.copy2(project.filename, output)


if __name__ == "__main__":
    main()
