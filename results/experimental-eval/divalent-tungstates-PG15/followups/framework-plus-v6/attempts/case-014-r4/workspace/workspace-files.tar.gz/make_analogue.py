#!/usr/bin/env python3
"""Create a symmetry-preserving one-site chemical analogue CIF."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import numpy as np
from pymatgen.core import Structure


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("parent", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("substitution", help="OLD=NEW")
    args = parser.parse_args()
    old, new = args.substitution.split("=", 1)
    structure = Structure.from_file(args.parent, primitive=False)
    parent_formula = structure.composition.reduced_formula
    parent_sg = structure.get_space_group_info(symprec=1e-3)
    structure.replace_species({old: new})
    target_sg = structure.get_space_group_info(symprec=1e-3)
    if parent_sg[1] != target_sg[1]:
        raise RuntimeError("site substitution changed detected symmetry")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    # Retain the parent's explicit setting and symmetry operators. Pymatgen's
    # standardized CIF writer may relabel a P21/n metric as P21/c without the
    # corresponding basis change, which GSAS-II correctly rejects.
    text = args.parent.read_text()
    element_token = rf"(?<![A-Za-z]){re.escape(old)}(?=(?:\d|\b))"
    args.output.write_text(re.sub(element_token, new, text))

    distances = structure.distance_matrix
    np.fill_diagonal(distances, np.inf)
    nearest = []
    for i, site in enumerate(structure):
        j = int(np.argmin(distances[i]))
        nearest.append(
            {
                "site": i,
                "species": site.species_string,
                "nearest_species": structure[j].species_string,
                "distance_A": float(distances[i, j]),
            }
        )
    record = {
        "model_basis": "analogue_derived",
        "parent_cif": str(args.parent.resolve()),
        "parent_formula": parent_formula,
        "parent_space_group": {"symbol": parent_sg[0], "number": parent_sg[1]},
        "target_formula": structure.composition.reduced_formula,
        "target_space_group": {"symbol": target_sg[0], "number": target_sg[1]},
        "transformation": f"isovalent site substitution {old} -> {new}; parent metric and fractional coordinates retained for initial scale test",
        "cell": [*structure.lattice.abc, *structure.lattice.angles],
        "minimum_interatomic_distance_A": float(np.min(distances)),
        "nearest_neighbors": nearest,
    }
    args.output.with_suffix(".provenance.json").write_text(
        json.dumps(record, indent=2) + "\n"
    )
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
