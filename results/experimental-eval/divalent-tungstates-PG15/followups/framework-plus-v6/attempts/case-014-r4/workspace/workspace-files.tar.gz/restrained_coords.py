#!/usr/bin/env python3
"""Refine selected coordinates with a chemically motivated bond restraint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def lattice_matrix(cell: dict) -> np.ndarray:
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    alpha, beta, gamma = np.deg2rad(
        [cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]]
    )
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * np.cos(gamma), b * np.sin(gamma), 0.0])
    vcx = c * np.cos(beta)
    vcy = c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)
    vcz = np.sqrt(max(0.0, c * c - vcx * vcx - vcy * vcy))
    return np.array([va, vb, [vcx, vcy, vcz]])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("--elements", nargs="+", required=True)
    parser.add_argument("--central", default="W")
    parser.add_argument("--ligand", default="O")
    parser.add_argument("--bond-A", type=float, required=True)
    parser.add_argument("--search-factor", type=float, default=1.12)
    parser.add_argument("--esd-A", type=float, default=0.04)
    parser.add_argument("--weight", type=float, default=100.0)
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--passes", type=int, default=4)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve())
    )
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    matrix = lattice_matrix(phase.get_cell())
    initial = {atom.label: np.asarray(atom.coordinates, dtype=float) for atom in phase.atoms()}

    for item in project.phases():
        item.set_refinements({"Cell": True})
        item.data["Histograms"][hist.name]["Scale"][1] = True
        for atom in item.atoms():
            atom.refinement_flags = "X" if item.name == phase.name and atom.element in args.elements else " "
    inst = hist.data["Instrument Parameters"][0]
    for key in inst:
        if isinstance(inst[key], list) and len(inst[key]) >= 3:
            inst[key][2] = False
    hist.data["Background"][0][1] = True
    sample = hist.data["Sample Parameters"]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = False
    sample["Shift"][1] = True

    project.data["Restraints"]["data"][phase.name] = {
        "Bond": {"wtFactor": float(args.weight), "Range": args.search_factor, "Bonds": [], "Use": True}
    }
    centers = [atom for atom in phase.atoms() if atom.element == args.central]
    ligands = [atom for atom in phase.atoms() if atom.element == args.ligand]
    count = phase.addDistRestraint(
        centers, ligands, args.bond_A, factor=args.search_factor, ESD=args.esd_A
    )
    if count == 0:
        raise ValueError("No bonds found for restraint")

    project.set_Controls("cycles", args.cycles)
    history = []
    for index in range(args.passes):
        project.set_Frozen()
        project.save()
        project.refine(makeBack=False)
        project.save()
        row = {
            "pass": index + 1,
            "wR_percent": float(project.histogram(0).get_wR()),
            "frozen": [str(value) for value in project.get_Frozen()],
        }
        history.append(row)
        print(json.dumps(row), flush=True)

    movements = []
    for atom in phase.atoms():
        if atom.label not in initial:
            continue
        delta = np.asarray(atom.coordinates) - initial[atom.label]
        delta -= np.round(delta)
        movements.append(
            {
                "label": atom.label,
                "element": atom.element,
                "displacement_A": float(np.linalg.norm(delta @ matrix)),
                "coordinates": list(atom.coordinates),
            }
        )
    result = {
        "phase": phase.name,
        "bond_restraints": count,
        "bond_target_A": args.bond_A,
        "esd_A": args.esd_A,
        "weight": args.weight,
        "history": history,
        "movements": movements,
        "cell": phase.get_cell(),
    }
    args.output.with_suffix(".summary.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
