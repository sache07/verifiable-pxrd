#!/usr/bin/env python3
"""Add one watch-list phase to an existing GSAS-II baseline and reconverge."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "mass": float(phase.data["General"]["Mass"]),
                "cell": phase.get_cell(),
            }
        )
    weights = np.array([r["scale"] * r["mass"] for r in rows])
    if weights.sum() > 0:
        for row, value in zip(rows, weights / weights.sum()):
            row["weight_fraction"] = float(value)
    inst = hist.data["Instrument Parameters"][0]
    return {
        "label": label,
        "wR_percent": hist.get_wR(),
        "phases": rows,
        "instrument": {
            key: float(inst[key][1])
            for key in ("U", "W", "X", "SH/L", "Polariz.")
            if key in inst
        },
        "shift_um": float(hist.data["Sample Parameters"]["Shift"][0]),
        "frozen": project.get_Frozen(),
    }


def refine(project: G2.G2Project, label: str, history: list[dict]) -> None:
    project.set_Frozen()
    project.save()
    project.refine(makeBack=False)
    project.save()
    result = state(project, label)
    history.append(result)
    print(
        json.dumps(
            {
                "label": label,
                "wR_percent": result["wR_percent"],
                "fractions": {
                    p["name"]: p.get("weight_fraction") for p in result["phases"]
                },
                "frozen": result["frozen"],
            }
        ),
        flush=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("name")
    parser.add_argument("cif", type=Path)
    parser.add_argument("--cycles", type=int, default=5)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.base.resolve()), newgpx=str(output))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    existing = [p for p in project.phases() if p.name != phase.name]
    existing_mass_scale = sum(
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in existing
    )
    hap["Scale"] = [
        0.10 * existing_mass_scale / (0.90 * phase.data["General"]["Mass"]),
        True,
    ]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]
    phase.set_refinements({"Cell": False})

    project.set_Controls("cycles", args.cycles)
    hid = hist.id
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hid}:Scale")
    history = [state(project, "added")]

    # Re-establish background and every scale before judging the new record.
    hist.set_refinements({"Background": True, "Sample Parameters": ["Shift"]})
    for p in project.phases():
        p.set_HAP_refinements({"Scale": True})
    refine(project, "scale_test", history)

    # A plausible record is then allowed to adjust its metric together with the
    # already accepted phases and the one shared angular correction.
    for p in project.phases():
        p.set_refinements({"Cell": True})
    refine(project, "cell_test", history)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, "common_profile_rebuild", history)
    refine(project, "reconverged", history)

    output.with_suffix(".summary.json").write_text(
        json.dumps(history, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
