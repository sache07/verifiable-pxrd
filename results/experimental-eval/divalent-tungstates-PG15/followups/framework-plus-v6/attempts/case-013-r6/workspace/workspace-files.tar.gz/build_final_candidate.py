#!/usr/bin/env python3
"""Build the clean GSAS-II project used for final Pb-W-O refinement."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


G2.SetPrintLevel("warn")
OUT = Path(".tmp/final_candidate.gpx")
project = G2.G2Project(newgpx=str(OUT))
hist = project.add_powder_histogram("inputs/pattern.csv", "initial.instprm")
hist.SampleParameters["Scale"] = [1.0, False]
hist.SampleParameters["Type"] = "Bragg-Brentano"
hist.SampleParameters["Gonio. radius"] = 200.0
hist.SampleParameters["Shift"] = [0.0, False]
hist.SampleParameters["Transparency"] = [0.0, False]
hist.SampleParameters["SurfRoughA"] = [0.0, False]
hist.SampleParameters["SurfRoughB"] = [0.0, False]

background = [629.1, -559.1, 370.2, -204.4, 101.2, -45.7]
hist.set_refinements(
    {
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 6,
            "coeffs": background,
            "refine": True,
        }
    }
)
inst = hist.data["Instrument Parameters"][0]
for key, value in {
    "Zero": 0.2875,
    "U": 8.02,
    "V": 0.0,
    "W": 17.36,
    "X": 3.77,
    "SH/L": 0.0227,
    "Polariz.": 0.714,
}.items():
    inst[key][1] = value

specs = [
    {
        "name": "stolzite_PbWO4",
        "id": "9009811",
        "cell": [5.46643, 5.46643, 12.06394, 90.0, 90.0, 90.0],
        "scale": 6.08,
        "size": 0.114,
        "strain": 0.0,
        "md": (1.0, [0, 0, 1]),
    },
    {
        "name": "monoclinic_WO3",
        "id": "2311041",
        "cell": [7.30795, 7.55022, 10.56119, 90.0, 133.17806, 90.0],
        "scale": 1.16,
        "size": 0.089,
        "strain": 0.0,
        "md": (1.0, [0, 0, 1]),
    },
    {
        "name": "massicot_PbO",
        "id": "2310433",
        "cell": [5.89789, 5.49263, 4.76178, 90.0, 90.0, 90.0],
        "scale": 3.14,
        "size": 0.04,
        "strain": 7100.0,
        "md": (0.78, [1, 0, 0]),
    },
    {
        "name": "incommensurate_alpha_PbO_approximant",
        "id": "1533609",
        "cell": [5.03900, 5.63464, 44.98590, 90.0, 90.0, 90.0],
        "scale": 0.203,
        "size": 0.04,
        "strain": 5800.0,
        "md": (1.0, [0, 0, 1]),
    },
    {
        "name": "minium_Pb3O4",
        "id": "9012124",
        "cell": [8.78993, 8.78993, 6.57490, 90.0, 90.0, 90.0],
        "scale": 0.233,
        "size": 0.04,
        "strain": 0.0,
        "md": (1.0, [0, 0, 1]),
    },
]

phases = []
for index, spec in enumerate(specs):
    phase = project.add_phase(
        str(Path(".tmp/models") / f"{spec['id']}.cif"),
        phasename=spec["name"],
        histograms=[hist],
        fmthint="CIF",
    )
    cell = spec["cell"]
    phase.data["General"]["Cell"][1:7] = cell
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [spec["scale"], True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = spec["size"]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = spec["strain"]
    hap["Mustrain"][1][1] = spec["strain"]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = spec["md"][0]
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = spec["md"][1]
    hap["Extinction"] = [0.0, False]
    project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")
    phases.append(phase)


def run(label, cycles=18):
    project.set_Controls("cycles", cycles)
    project.refine(printFile=f".tmp/final_{label}.lst")
    if project.get_Frozen():
        project.refine(printFile=f".tmp/final_{label}_bounded.lst")
    project.save()
    print(label, hist.get_wR(), project.get_Frozen(), flush=True)


# Re-establish background, all scales and one angular correction.
hist.set_refinements({"Instrument Parameters": ["Zero"]})
run("01_scale_background_zero")

# Revisit each cell without coupling weak-cell metrics to one another.
for phase in phases:
    phase.set_refinements({"Cell": True})
    run("02_cell_" + phase.name, 12)
    phase.clear_refinements({"Cell": True})

# Common bounded instrument profile, then asymmetry and polarization.
hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
for variable, low, high in (
    (":0:U", 0.0, 40.0),
    (":0:W", 2.0, 40.0),
    (":0:X", 0.1, 6.0),
):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)
run("03_profile")
hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})

hist.set_refinements({"Instrument Parameters": ["SH/L"]})
project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
project.set_Controls("parmMax", 0.10, variable=":0:SH/L")
run("04_asymmetry")
hist.clear_refinements({"Instrument Parameters": ["SH/L"]})

hist.set_refinements({"Instrument Parameters": ["Polariz."]})
project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
run("05_polarization")
hist.clear_refinements({"Instrument Parameters": ["Polariz."]})

# Supported phase profile terms only.
for index in (0, 1):
    phases[index].set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True}}
    )
    project.set_Controls("parmMin", 0.04, variable=f"{index}:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{index}:0:Size;i")
run("06_principal_sizes")
for index in (0, 1):
    phases[index].clear_HAP_refinements({"Size": True})

for index in (2, 3):
    phases[index].set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}
    )
    project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{index}:0:Mustrain;i")
phases[2].set_HAP_refinements({"Pref.Ori.": True})
project.set_Controls("parmMin", 0.7, variable="2:0:MD")
project.set_Controls("parmMax", 1.4, variable="2:0:MD")
run("07_supported_phase_profiles", 24)

project.save()
print("final", hist.get_wR(), flush=True)
for phase in phases:
    hap = phase.data["Histograms"][hist.name]
    print(
        phase.name,
        phase.get_cell(),
        hap["Scale"][0],
        hap["Size"][1][0],
        hap["Mustrain"][1][0],
        hap["Pref.Ori."][:4],
        flush=True,
    )
