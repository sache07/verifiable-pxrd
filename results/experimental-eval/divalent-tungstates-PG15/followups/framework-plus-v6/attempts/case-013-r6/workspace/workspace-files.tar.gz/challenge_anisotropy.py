#!/usr/bin/env python3
"""Challenge phase microstrain anisotropy from the clean final candidate."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
SOURCE = Path(".tmp/final_candidate.gpx")
OUTDIR = Path(".tmp/anisotropy_trials")
OUTDIR.mkdir(parents=True, exist_ok=True)
AXES = ((0, 0, 1), (1, 0, 0), (0, 1, 0))


def trial(phase_index: int, axis: tuple[int, int, int]) -> dict:
    axis_text = "".join(str(value) for value in axis)
    target = OUTDIR / f"phase_{phase_index}_axis_{axis_text}.gpx"
    shutil.copy2(SOURCE, target)
    project = G2.G2Project(gpxfile=str(target))
    hist = project.histograms()[0]
    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][hist.name]
    initial = max(float(hap["Mustrain"][1][0]), 300.0)
    # The GSAS-II uniaxial formula is singular at exactly zero strain.
    hap["Mustrain"][1][0] = initial
    hap["Mustrain"][1][1] = initial
    phase.set_HAP_refinements(
        {
            "Mustrain": {
                "type": "uniaxial",
                "direction": list(axis),
                "refine": True,
            }
        }
    )
    project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{phase_index}:0:Mustrain;i")
    project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;a")
    project.set_Controls("parmMax", 32000.0, variable=f"{phase_index}:0:Mustrain;a")
    project.set_Controls("cycles", 24)
    project.refine(printFile=str(OUTDIR / f"phase_{phase_index}_axis_{axis_text}.lst"))
    frozen_first = [str(item) for item in project.get_Frozen()]
    if frozen_first:
        project.refine(
            printFile=str(OUTDIR / f"phase_{phase_index}_axis_{axis_text}_bounded.lst")
        )
    project.save()
    hap = phase.data["Histograms"][hist.name]
    return {
        "phase_index": phase_index,
        "phase": phase.name,
        "axis": list(axis),
        "Rwp_percent": float(hist.get_wR()),
        "equatorial_ppm": float(hap["Mustrain"][1][0]),
        "axial_ppm": float(hap["Mustrain"][1][1]),
        "frozen_first": frozen_first,
        "frozen_final": [str(item) for item in project.get_Frozen()],
        "project": str(target),
    }


rows = []
for phase_index in (2, 3):
    for axis in AXES:
        row = trial(phase_index, axis)
        rows.append(row)
        print(json.dumps(row), flush=True)

(OUTDIR / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")
