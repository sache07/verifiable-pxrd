#!/usr/bin/env python3
"""Build and run a restrained GSAS-II phase-inventory screen.

Run this script with the GSAS-II Python interpreter. Candidate CIFs are the
normalized, symmetry-preserving copies in .tmp/models.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def parse_phase(value: str) -> tuple[str, str]:
    try:
        name, cod_id = value.split("=", 1)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("phase must be NAME=COD_ID") from exc
    return name, cod_id


def set_common_flags(project, histogram, phases, *, cells=True):
    histogram.set_refinements(
        {
            "Background": True,
            "Instrument Parameters": ["Zero"],
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": cells})


def replay(project, label: str, cycles: int = 10):
    project.set_Controls("cycles", cycles)
    project.refine(printFile=f"{project.filename}.{label}.lst")
    # A parameter put on a limit is frozen after the fit. Refit the remaining
    # variables so the saved curve is evaluated at the clamped value.
    if project.get_Frozen():
        project.refine(printFile=f"{project.filename}.{label}.bounded.lst")
    project.set_Controls("cycles", 0)
    project.refine(printFile=f"{project.filename}.{label}.replay.lst")
    hist = project.histograms()[0]
    print(label, "Rwp", hist.get_wR(), "frozen", project.get_Frozen(), flush=True)
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+", type=parse_phase)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(args.output))
    hist = project.add_powder_histogram("inputs/pattern.csv", "initial.instprm")
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [700.0, -540.0, 290.0, -150.0, 60.0, -40.0],
                "refine": True,
            }
        }
    )
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"][1] = 0.30

    phases = []
    for index, (name, cod_id) in enumerate(args.phases):
        path = Path(".tmp/models") / f"{cod_id}.cif"
        phase = project.add_phase(
            str(path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1000.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")
        phases.append(phase)

    set_common_flags(project, hist, phases, cells=False)
    replay(project, "01_scales_background_zero", 12)

    # Cell refinement only follows a positive scale challenge.
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        if hap["Scale"][0] > 1e-8:
            phase.set_refinements({"Cell": True})
    replay(project, "02_cells", 12)

    # Hold the now-positioned cells while profile terms are compared. This is
    # especially important for weak monoclinic phases, whose metric can become
    # ill-conditioned when width and cell derivatives are released together.
    for phase in phases:
        phase.clear_refinements({"Cell": True})

    # Establish a bounded, common profile from neutral phase broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for variable, lower, upper in (
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    replay(project, "03_common_profile", 14)

    # With the common profile fixed, compare isotropic phase sizes.
    project.set_Frozen()
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for index, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        if hap["Scale"][0] <= 1e-8:
            continue
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.15, "refine": True}}
        )
        project.set_Controls("parmMin", 0.04, variable=f"{index}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{index}:0:Size;i")
    replay(project, "04_sizes", 16)

    # One alternating profile/size pass reduces scale-width coupling.
    project.set_Frozen()
    for phase in phases:
        phase.clear_HAP_refinements({"Size": True})
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    replay(project, "05_profile_revisit", 12)

    project.set_Frozen()
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for phase in phases:
        if phase.data["Histograms"][hist.name]["Scale"][0] > 1e-8:
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    replay(project, "06_sizes_revisit", 12)

    masses = []
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        masses.append(max(0.0, hap["Scale"][0]) * phase.data["General"]["Mass"])
    total = sum(masses)
    summary = {
        "Rwp_percent": hist.get_wR(),
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "SH/L", "Polariz.")
        },
        "background": hist.data["Background"][0],
        "frozen": project.get_Frozen(),
        "phases": [],
    }
    for phase, mass in zip(phases, masses):
        hap = phase.data["Histograms"][hist.name]
        summary["phases"].append(
            {
                "name": phase.name,
                "scale": hap["Scale"][0],
                "weight_fraction": mass / total if total else None,
                "size_um": hap["Size"][1][0],
                "cell": phase.get_cell(),
            }
        )
    args.output.with_suffix(".summary.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
