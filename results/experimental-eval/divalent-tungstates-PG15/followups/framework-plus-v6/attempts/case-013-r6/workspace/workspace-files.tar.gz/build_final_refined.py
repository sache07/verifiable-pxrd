#!/usr/bin/env python3
"""Rebuild the accepted five-phase model with supported profile terms only."""

from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
SOURCE = Path(".tmp/final_candidate.gpx")
OUT = Path(".tmp/final_refined.gpx")
shutil.copy2(SOURCE, OUT)
project = G2.G2Project(gpxfile=str(OUT))
hist = project.histograms()[0]
phases = project.phases()

# Start each rejected or unused phase term from a neutral setting. The two
# dominant-phase sizes, massicot [100] strain and long-period-PbO isotropic
# strain are the only phase-width terms retained for refinement.
for phase in phases:
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][1][1] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]

# Restore the supported interior crystallite sizes for the principal phases.
for index, size in ((0, 0.11427), (1, 0.07853)):
    hap = phases[index].data["Histograms"][hist.name]
    hap["Size"][1][0] = size
    phases[index].set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True}}
    )
    project.set_Controls("parmMin", 0.04, variable=f"{index}:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{index}:0:Size;i")

# Massicot: the [100] uniaxial model was the only axis-specific width trial
# with a material and reproducible improvement. Texture is reset to unity
# because it became bound when this width model was admitted.
massicot = phases[2]
mhap = massicot.data["Histograms"][hist.name]
mhap["Mustrain"][1][0] = 5895.0
mhap["Mustrain"][1][1] = 23854.0
massicot.set_HAP_refinements(
    {
        "Mustrain": {
            "type": "uniaxial",
            "direction": [1, 0, 0],
            "refine": True,
        }
    }
)
project.set_Controls("parmMin", 0.0, variable="2:0:Mustrain;i")
project.set_Controls("parmMax", 8000.0, variable="2:0:Mustrain;i")
project.set_Controls("parmMin", 0.0, variable="2:0:Mustrain;a")
project.set_Controls("parmMax", 32000.0, variable="2:0:Mustrain;a")

# Long-period alpha-PbO: retain only its supported isotropic strain.
long_pbo = phases[3]
lhap = long_pbo.data["Histograms"][hist.name]
lhap["Mustrain"][1][0] = 5359.0
lhap["Mustrain"][1][1] = 5359.0
long_pbo.set_HAP_refinements(
    {"Mustrain": {"type": "isotropic", "refine": True}}
)
project.set_Controls("parmMin", 0.0, variable="3:0:Mustrain;i")
project.set_Controls("parmMax", 8000.0, variable="3:0:Mustrain;i")

# Clear any frozen-variable record inherited from trial projects.
project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []


def run(label: str, cycles: int = 18) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(printFile=f".tmp/refined_{label}.lst")
    if project.get_Frozen():
        project.refine(printFile=f".tmp/refined_{label}_bounded.lst")
    project.save()
    print(label, hist.get_wR(), [str(item) for item in project.get_Frozen()], flush=True)


# Re-establish background, every scale and the one angular correction.
run("01_rebaseline", 24)

# Revisit cells one at a time under the accepted nuisance model.
for phase in phases:
    phase.set_refinements({"Cell": True})
    run("02_cell_" + phase.name, 12)
    phase.clear_refinements({"Cell": True})

# Rebuild the common nonnegative profile, then asymmetry and polarization.
hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
for variable, low, high in (
    (":0:U", 0.0, 40.0),
    (":0:W", 2.0, 40.0),
    (":0:X", 0.1, 6.0),
):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)
run("03_common_profile", 24)
hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})

hist.set_refinements({"Instrument Parameters": ["SH/L"]})
project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
project.set_Controls("parmMax", 0.10, variable=":0:SH/L")
run("04_asymmetry", 18)
hist.clear_refinements({"Instrument Parameters": ["SH/L"]})

hist.set_refinements({"Instrument Parameters": ["Polariz."]})
project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
run("05_polarization", 18)
hist.clear_refinements({"Instrument Parameters": ["Polariz."]})

# Final joint convergence of background, scales, zero, retained sizes/strains.
run("06_joint", 30)
project.save()

print("final", hist.get_wR(), flush=True)
for phase in phases:
    hap = phase.data["Histograms"][hist.name]
    print(
        phase.name,
        phase.get_cell(),
        hap["Scale"][0],
        hap["Size"][:4],
        hap["Mustrain"][:4],
        hap["Pref.Ori."][:4],
        flush=True,
    )
