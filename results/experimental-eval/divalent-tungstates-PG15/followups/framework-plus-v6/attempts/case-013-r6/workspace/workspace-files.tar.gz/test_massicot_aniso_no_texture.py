#!/usr/bin/env python3
"""Test the supported massicot [100] strain with texture fixed to unity."""

from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
source = Path(".tmp/final_candidate.gpx")
target = Path(".tmp/massicot_aniso_no_texture.gpx")
shutil.copy2(source, target)
project = G2.G2Project(gpxfile=str(target))
hist = project.histograms()[0]
phase = project.phases()[2]
hap = phase.data["Histograms"][hist.name]
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = False
hap["Mustrain"][1][0] = 5895.0
hap["Mustrain"][1][1] = 23854.0
phase.set_HAP_refinements(
    {"Mustrain": {"type": "uniaxial", "direction": [1, 0, 0], "refine": True}}
)
project.set_Controls("parmMin", 0.0, variable="2:0:Mustrain;i")
project.set_Controls("parmMax", 8000.0, variable="2:0:Mustrain;i")
project.set_Controls("parmMin", 0.0, variable="2:0:Mustrain;a")
project.set_Controls("parmMax", 32000.0, variable="2:0:Mustrain;a")
project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
project.set_Controls("cycles", 30)
project.refine(printFile=".tmp/massicot_aniso_no_texture.lst")
if project.get_Frozen():
    project.refine(printFile=".tmp/massicot_aniso_no_texture_bounded.lst")
project.save()
print("Rwp", hist.get_wR())
print("frozen", [str(item) for item in project.get_Frozen()])
print("strain", hap["Mustrain"][:4])
print("texture", hap["Pref.Ori."][:4])
