#!/usr/bin/env python3
"""Rank extra phase models by fixed-baseline weighted profile improvement."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


BASE = Path(".tmp/screen_m5_both.gpx")
SIZES = (0.04, 0.07, 0.12, 0.20, 0.40)


def freeze(project, histogram) -> None:
    project.set_Frozen()
    histogram.clear_refinements(
        {
            "Background": True,
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
        }
    )
    for key, value in histogram.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
            }
        )


def calculate(project, name: str) -> np.ndarray:
    project.set_Controls("cycles", 0)
    project.refine(printFile=f".tmp/{name}.lst")
    return np.array(project.histograms()[0].data["data"][1][3], copy=True)


def main() -> None:
    G2.SetPrintLevel("error")
    base = G2.G2Project(str(BASE))
    hist = base.histograms()[0]
    freeze(base, hist)
    yc0 = calculate(base, "challenge_baseline")
    x, y, w = [np.asarray(a) for a in hist.data["data"][1][:3]]
    residual = y - yc0
    denominator = float(np.sum(w * y * y))
    rwp0 = 100.0 * np.sqrt(np.sum(w * residual * residual) / denominator)

    current_mass = sum(
        max(0.0, p.data["Histograms"][hist.name]["Scale"][0])
        * p.data["General"]["Mass"]
        for p in base.phases()
    )
    present = {"9009811", "1528915", "2310433", "9012700", "9012124"}
    rows = []
    for cif in sorted(Path(".tmp/models").glob("*.cif")):
        cod_id = cif.stem
        if cod_id in present:
            continue
        best = None
        project = G2.G2Project(str(BASE))
        h = project.histograms()[0]
        freeze(project, h)
        phase = project.add_phase(
            str(cif), phasename=f"candidate_{cod_id}", histograms=[h], fmthint="CIF"
        )
        hap = phase.data["Histograms"][h.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        for size in SIZES:
            hap["Size"][1][0] = size
            yc1 = calculate(project, f"challenge_{cod_id}_{size:.2f}")
            component = yc1 - yc0
            norm = float(np.sum(w * component * component))
            scale = 0.0 if norm <= 0 else max(0.0, float(np.sum(w * component * residual)) / norm)
            trial_residual = residual - scale * component
            rwp = 100.0 * np.sqrt(np.sum(w * trial_residual * trial_residual) / denominator)
            candidate_mass = scale * phase.data["General"]["Mass"]
            row = {
                "cod_id": cod_id,
                "formula": phase.data["General"]["Name"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "size_um": size,
                "optimal_scale": scale,
                "approx_weight_fraction": candidate_mass / (current_mass + candidate_mass),
                "Rwp_percent": rwp,
                "delta_Rwp_percent": rwp0 - rwp,
            }
            if best is None or row["Rwp_percent"] < best["Rwp_percent"]:
                best = row
        rows.append(best)
        print(json.dumps(best), flush=True)

    rows.sort(key=lambda row: row["Rwp_percent"])
    result = {"baseline_Rwp_percent": rwp0, "candidates": rows}
    Path(".tmp/candidate_challenges.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
