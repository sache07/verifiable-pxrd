#!/usr/bin/env python3
"""Export the final profile and machine-readable result from one verified replay."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(".")
PROJECT = ROOT / "final.gpx"
REPLAY_DIR = ROOT / ".tmp" / "replay_backup"
REPLAY = json.loads((REPLAY_DIR / "replay.json").read_text())


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


if REPLAY["status"] != "replayed":
    raise RuntimeError(f"Final replay failed: {REPLAY}")
if sha256(PROJECT) != REPLAY["project_sha256"]:
    raise RuntimeError("final.gpx is not the project used for the verified replay")

with np.load(REPLAY_DIR / "prediction.npz", allow_pickle=False) as replay_arrays:
    x = replay_arrays["x"].copy()
    observed = replay_arrays["observed"].copy()
    calculated = replay_arrays["predicted"].copy()
    background = replay_arrays["background"].copy()

public = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
if not np.array_equal(x, public[:, 0]) or not np.array_equal(observed, public[:, 1]):
    raise RuntimeError("Replay does not use the complete original observed grid")
if np.any(~np.isfinite(calculated)) or np.any(calculated < 0):
    raise RuntimeError("Invalid calculated profile")

difference = observed - calculated
weights = 1.0 / np.maximum(observed, 1.0)
weighted_chi_square = float(np.sum(weights * difference**2))
weighted_denominator = float(np.sum(weights * observed**2))
rwp = float(100.0 * np.sqrt(weighted_chi_square / weighted_denominator))
rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))

np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x, observed, calculated, difference, background)),
    delimiter=",",
    header="two_theta,observed,calculated,difference,background",
    comments="",
    fmt="%.12g",
)

project = G2.G2Project(gpxfile=str(PROJECT))
hist = project.histogram(REPLAY["histogram"])
rvals = project.data["Covariance"]["data"]["Rvals"]
if abs(float(rvals["Rwp"]) - rwp) > 1e-10:
    raise RuntimeError("Native and replayed Rwp disagree")

cif_paths = [
    "phase_1_stolzite_PbWO4.cif",
    "phase_2_monoclinic_WO3.cif",
    "phase_3_massicot_PbO.cif",
    "phase_4_alpha_PbO_approximant.cif",
    "phase_5_minium_Pb3O4.cif",
]
formulas = ["PbWO4", "WO3", "PbO", "PbO", "Pb3O4"]
source_ids = ["9009811", "2311041", "2310433", "1533609", "9012124"]
confidence = ["high", "high", "moderate", "moderate_to_low", "low"]

phases = []
project_phases = project.phases()
if len(project_phases) != len(REPLAY["phases"]):
    raise RuntimeError("Phase count changed between project and replay")

for index, (phase_report, phase, cif_path, formula, source_id, level) in enumerate(
    zip(REPLAY["phases"], project_phases, cif_paths, formulas, source_ids, confidence)
):
    if phase.name != phase_report["name"]:
        raise RuntimeError("Project/replay phase ordering changed")
    if sha256(ROOT / cif_path) != sha256(REPLAY_DIR / phase_report["cif"]):
        raise RuntimeError(f"{cif_path} is not the CIF exported from final.gpx")
    cell = phase.get_cell()
    phases.append(
        {
            "name": phase.name,
            "formula": formula,
            "cif_path": cif_path,
            "weight_fraction": float(phase_report["weight_fraction"]),
            "weight_percent": float(100.0 * phase_report["weight_fraction"]),
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cell_angstrom_degrees": {
                "a": float(cell["length_a"]),
                "b": float(cell["length_b"]),
                "c": float(cell["length_c"]),
                "alpha": float(cell["angle_alpha"]),
                "beta": float(cell["angle_beta"]),
                "gamma": float(cell["angle_gamma"]),
                "volume_A3": float(cell["volume"]),
            },
            "source": {
                "database": "Crystallography Open Database",
                "cod_id": source_id,
                "model_basis": "published_structure_with_refined_cell",
            },
            "identification_confidence": level,
        }
    )

fraction_sum = sum(row["weight_fraction"] for row in phases)
if abs(fraction_sum - 1.0) > 1e-12:
    raise RuntimeError("Crystalline weight fractions are not normalized")

result = {
    "schema_version": 1,
    "refinement_histogram": REPLAY["histogram"],
    "phases": phases,
    "weight_fraction_basis": "normalized over the five modeled crystalline phases; no amorphous fraction determined",
    "fit_statistics": {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "weighted_chi_square": weighted_chi_square,
        "goodness_of_fit": float(rvals["GOF"]),
        "number_of_observations": int(rvals["Nobs"]),
        "number_of_refined_variables_in_last_cycle": int(rvals["Nvars"]),
        "weighting": "1/max(observed_counts,1)",
        "difference_definition": "observed-calculated",
    },
    "calibration": {
        "zero_shift_deg": float(
            hist.data["Instrument Parameters"][0]["Zero"][1]
        ),
        "wavelength_Kalpha1_angstrom": 1.540598,
        "wavelength_Kalpha2_angstrom": 1.544426,
        "Kalpha2_to_Kalpha1_ratio": 0.5,
    },
    "files": {"profile": "fit.csv", "project": "final.gpx"},
    "verification": {
        "project_sha256": sha256(PROJECT),
        "read_only_forward_replay": True,
        "parameters_optimized_during_replay": 0,
        "profile_review_flags": REPLAY["profile_review_flags"],
    },
}

(ROOT / "result.json").write_text(
    json.dumps(result, indent=2, sort_keys=False, allow_nan=False) + "\n"
)

print(json.dumps(result["fit_statistics"], indent=2))
print("fraction_sum", fraction_sum)
