#!/usr/bin/env python3
"""Print concise quantitative diagnostics from a GSAS-II powder project."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--top", type=int, default=20)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.project.resolve()))
    hist = project.histogram(0)
    x, yobs, weight, ycalc, ybkg, ydiff = hist.data["data"][1]
    lo, hi = hist.data["Limits"][1]
    used = (x >= lo) & (x <= hi)

    print("project", args.project)
    print("histogram", hist.name)
    print("limits", lo, hi, "points", int(used.sum()), "of", len(x))
    print("residuals", hist.residuals)
    print("instrument", {k: hist.InstrumentParameters[k] for k in
          ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
          if k in hist.InstrumentParameters})
    print("sample", {k: hist.SampleParameters[k] for k in
          ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
          if k in hist.SampleParameters})

    amounts = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = phase.data["General"]["Mass"]
        amount = max(0.0, hap["Scale"][0] * mass)
        amounts.append(amount)
    total = sum(amounts)
    for phase, amount in zip(project.phases(), amounts):
        hap = phase.data["Histograms"][hist.name]
        print("phase", phase.name)
        print("  composition", phase.data["General"].get("Name"), phase.data["General"].get("AtomTypes"))
        print("  mass", phase.data["General"]["Mass"], "scale", hap["Scale"],
              "weight_fraction", amount / total if total else float("nan"))
        print("  cell", phase.get_cell())
        print("  size", hap["Size"][:3], "strain", hap["Mustrain"][:3],
              "PO", hap["Pref.Ori."][:4])

    # Rank coherent positive residual maxima by prominence, with one candidate
    # per approximately one instrumental peak width.
    idx, props = find_peaks(ydiff[used], distance=8, prominence=25.0)
    global_idx = np.flatnonzero(used)[idx]
    order = np.argsort(props["prominences"])[::-1][: args.top]
    print("positive residual peaks: two_theta yobs ycalc ydiff prominence")
    for j in order:
        i = global_idx[j]
        print(f"  {x[i]:.5f} {yobs[i]:.3f} {ycalc[i]:.3f} {ydiff[i]:.3f} {props['prominences'][j]:.3f}")


if __name__ == "__main__":
    main()
