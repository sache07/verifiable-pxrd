#!/usr/bin/env python3
"""Create a symmetry-preserving trial model by scaling and/or substitution."""

from __future__ import annotations

import argparse
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--scale", type=float, default=1.0,
                        help="isotropic multiplier for lattice lengths")
    parser.add_argument("--substitute", nargs=2, action="append", default=[],
                        metavar=("FROM", "TO"))
    args = parser.parse_args()

    structure = Structure.from_file(args.input)
    for old, new in args.substitute:
        structure.replace_species({old: new})
    structure.scale_lattice(structure.volume * args.scale**3)
    structure.remove_oxidation_states()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    writer = CifWriter(structure, symprec=1e-3, significant_figures=10)
    args.output.write_text(str(writer) + "\n")


if __name__ == "__main__":
    main()
