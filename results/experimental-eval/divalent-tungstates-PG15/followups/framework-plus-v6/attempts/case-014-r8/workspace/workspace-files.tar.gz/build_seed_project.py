#!/usr/bin/env python3
"""Build a stable five-phase GSAS-II seed for alternate-record challenges."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


NAMES = ["SrWO4", "WO3", "Sr2WO5", "Sr3WO6", "SrCO3-highT"]
SCALES = [17.59, 2.14, 2.49, 2.44, 4.11]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("cifs", nargs=5, type=Path)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    root = Path(__file__).resolve().parent
    project = G2.G2Project(newgpx=str(args.output.resolve()))
    hist = project.add_powder_histogram(
        str((root / ".tmp/pattern.xye").resolve()),
        str((root / ".tmp/instrument.instprm").resolve()),
        fmthint="xye",
    )
    x = hist.data["data"][1][0]
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]
    hist.data["Background"][0] = [
        "chebyschev-1", True, 10,
        629.5, -539.3, 402.5, -225.4, 117.4,
        -66.75, 40.94, -31.41, 16.12, -2.75,
    ]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-619.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.20, False]
    hist.SampleParameters["SurfRoughB"] = [0.229, False]
    for key, value in {
        "Zero": 0.0, "U": 10.0, "V": 0.0, "W": 51.3553976924,
        "X": 5.4871998807, "Y": 0.0, "SH/L": 0.03, "Polariz.": 0.70,
    }.items():
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False

    for name, scale, cif in zip(NAMES, SCALES, args.cifs):
        phase = project.add_phase(
            str(cif.resolve()), phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][1][1] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
        hap["LeBail"] = False
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "

    project.set_Controls("cycles", 12)
    project.save(str(args.output.resolve()))


if __name__ == "__main__":
    main()
