#!/usr/bin/env python3
"""Run GSAS-II autoindexing on a selected residual-peak list."""

from __future__ import annotations

import argparse
import math

from GSASII import GSASIIindex as G2index


DEFAULT_PEAKS = [
    15.01886, 16.61623, 20.68028, 22.10378, 26.99368,
    29.75375, 30.89473, 32.60076, 35.29564, 39.04456,
    42.17410, 44.65164, 48.60703, 53.44259, 56.99592,
    61.26643, 67.02564, 69.59012, 75.64273, 78.59840,
    83.90123, 88.89979, 94.12655,
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--peaks", nargs="*", type=float, default=DEFAULT_PEAKS)
    parser.add_argument("--bravais", nargs="*", type=int, default=[12, 16, 17],
                        help="GSAS-II Bravais indices")
    parser.add_argument("--volume", type=float, default=300.0)
    parser.add_argument("--timeout", type=float, default=25.0)
    parser.add_argument("--nc-no", type=int, default=6)
    args = parser.parse_args()

    wavelength = 1.540598
    peaks = []
    for pos in sorted(args.peaks):
        d = wavelength / (2.0 * math.sin(math.radians(pos / 2.0)))
        peaks.append([pos, 1.0, True, False, 0, 0, 0, d, 0.0])

    # [zero-refine, zero, max Nc/No, initial volume, ...] follows the
    # GSAS-II Unit Cells List representation.
    controls = [0, 0.0, args.nc_no, args.volume, 0, "P1",
                1.0, 1.0, 1.0, 90.0, 90.0, 90.0, 1.0, "P 1"]
    names = [
        "Cubic-F", "Cubic-I", "Cubic-P", "Trigonal-R", "Hexagonal-P",
        "Tetragonal-I", "Tetragonal-P", "Orthorhombic-F", "Orthorhombic-I",
        "Orthorhombic-A", "Orthorhombic-B", "Orthorhombic-C",
        "Orthorhombic-P", "Monoclinic-I", "Monoclinic-A", "Monoclinic-C",
        "Monoclinic-P", "Triclinic",
    ]
    for index in args.bravais:
        selected = [False] * 18
        selected[index] = True
        print(f"\n=== {index}: {names[index]} ===", flush=True)
        ok, dmin, cells = G2index.DoIndexPeaks(
            [row.copy() for row in peaks], controls.copy(), selected, None,
            timeout=args.timeout, M20_min=2.0, return_Nc=True,
        )
        print("OK", ok, "dmin", dmin, "cell_count", len(cells))
        for cell in G2index.sortM20(cells)[:20]:
            print(cell)


if __name__ == "__main__":
    main()
