#!/usr/bin/env python3
"""Test one March-Dollase axis against a fixed common profile."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("axis", nargs=3, type=int)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    hist = project.histogram(0)
    for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."):
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in hist.SampleParameters:
            hist.SampleParameters[key][1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    target = project.phase(args.phase)
    if target is None:
        raise ValueError(f"No phase named {args.phase!r}")
    po = target.data["Histograms"][hist.name]["Pref.Ori."]
    po[1] = 1.0
    po[2] = True
    po[3] = list(args.axis)

    project.set_Controls("cycles", 12)
    for cycle in range(2):
        project.refine()
        print("cycle", cycle, "Rwp", hist.residuals.get("wR"),
              "phase", target.name, "axis", po[3], "ratio", po[1])
    project.save(str(args.output.resolve()))


if __name__ == "__main__":
    main()
