#!/usr/bin/env python3
"""Prepare the supplied count data and a conservative Cu Kalpha GSAS-II profile."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / "inputs"
WORK = ROOT / ".tmp"


def main() -> None:
    WORK.mkdir(exist_ok=True)
    with (INPUTS / "metadata.json").open() as handle:
        metadata = json.load(handle)

    rows: list[tuple[float, float]] = []
    with (INPUTS / "pattern.csv").open(newline="") as handle:
        for row in csv.DictReader(handle):
            rows.append((float(row["two_theta_deg"]), float(row["intensity"])))
    data = np.asarray(rows, dtype=float)
    sigma = np.sqrt(np.maximum(data[:, 1], 1.0))
    np.savetxt(
        WORK / "pattern.xye",
        np.column_stack((data, sigma)),
        fmt=("%.8f", "%.8f", "%.8f"),
    )

    inst = metadata["instrument"]
    text = (
        "# GSAS-II experimental Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        f"Lam1:{inst['wavelength_Kalpha1_angstrom']};"
        f"Lam2:{inst['wavelength_Kalpha2_angstrom']};"
        f"I(L2)/I(L1):{inst['reported_Kalpha2_to_Kalpha1_ratio']}\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    (WORK / "instrument.instprm").write_text(text)


if __name__ == "__main__":
    main()
