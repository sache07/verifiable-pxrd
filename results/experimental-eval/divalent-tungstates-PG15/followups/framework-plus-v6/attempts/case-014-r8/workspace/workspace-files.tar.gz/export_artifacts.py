#!/usr/bin/env python3
"""Export all submission artifacts from one saved GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PHASE_INFO = {
    "SrWO4": {
        "formula": "SrWO4",
        "cif": "phase_1_SrWO4.cif",
        "model_basis": "published",
        "provenance": "COD 1546036 (ambient scheelite SrWO4)",
    },
    "WO3": {
        "formula": "WO3",
        "cif": "phase_2_WO3.cif",
        "model_basis": "published",
        "provenance": "COD 2311041 (ambient neutron-diffraction monoclinic WO3)",
    },
    "Sr2WO5": {
        "formula": "Sr2WO5",
        "cif": "phase_3_Sr2WO5.cif",
        "model_basis": "analogue_derived",
        "provenance": (
            "COD 1529756 Ba2ReO5 parent; Ba->Sr and Re->W isovalent "
            "substitution, initial cell scaled by 0.945"
        ),
    },
    "Sr3WO6": {
        "formula": "Sr3WO6",
        "cif": "phase_4_Sr3WO6.cif",
        "model_basis": "analogue_derived",
        "provenance": (
            "COD 1563081 Ca3WO6 parent; Ca->Sr substitution, initial cell "
            "scaled by 1.06"
        ),
    },
    "SrCO3-highT": {
        "formula": "SrCO3",
        "cif": "phase_5_SrCO3_highT.cif",
        "model_basis": "published",
        "provenance": (
            "COD 1539128 high-temperature rhombohedral SrCO3; initial cell "
            "scaled by 1.02"
        ),
    },
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("."))
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = args.output_dir.resolve()
    project = G2.G2Project(gpxfile=str(args.project.resolve()))
    hist = project.histogram(0)
    phases = project.phases()
    if {p.name for p in phases} != set(PHASE_INFO):
        raise ValueError("Final project phase inventory differs from export manifest")

    # Export directly from the saved phase data. Clearing covariance only in
    # memory prevents stale prior-stage values from being substituted by the
    # CIF writer; final.gpx itself is not modified.
    project.data["Covariance"]["data"] = {}
    amounts = []
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        if phase.data["General"].get("doPawley") or hap.get("LeBail"):
            raise ValueError(f"{phase.name} is not an atomic Rietveld model")
        amount = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        if amount <= 0:
            raise ValueError(f"{phase.name} has a nonpositive crystalline amount")
        amounts.append(amount)
        phase.export_CIF(str(output / PHASE_INFO[phase.name]["cif"]))

    total = float(sum(amounts))
    phase_rows = []
    for phase, amount in zip(phases, amounts):
        info = PHASE_INFO[phase.name]
        phase_rows.append({
            "name": phase.name,
            "formula": info["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cif_path": info["cif"],
            "weight_fraction": amount / total,
            "model_basis": info["model_basis"],
            "provenance": info["provenance"],
        })

    x, observed, weights, calculated, background, difference = hist.data["data"][1]
    profile = np.column_stack((x, observed, calculated, observed - calculated))
    np.savetxt(
        output / "fit.csv",
        profile,
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.12g",
    )

    # Reload fit diagnostics from disk because covariance was deliberately
    # cleared above only for structure export.
    check = G2.G2Project(gpxfile=str(args.project.resolve()))
    residuals = check.histogram(0).residuals
    covariance = check.data["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    vary = [str(item) for item in covariance.get("varyList", [])]
    scale_indices = [vary.index(f"{index}:0:Scale") for index in range(len(phases))]
    scale_covariance = np.asarray(covariance["covMatrix"])[
        np.ix_(scale_indices, scale_indices)
    ]
    masses = np.array([phase.data["General"]["Mass"] for phase in phases], dtype=float)
    scales = np.array([
        phase.data["Histograms"][hist.name]["Scale"][0] for phase in phases
    ], dtype=float)
    phase_amounts = masses * scales
    amount_total = phase_amounts.sum()
    fraction_jacobian = np.empty((len(phases), len(phases)))
    for i in range(len(phases)):
        for j in range(len(phases)):
            fraction_jacobian[i, j] = masses[j] * (
                (amount_total if i == j else 0.0) - phase_amounts[i]
            ) / amount_total**2
    fraction_covariance = fraction_jacobian @ scale_covariance @ fraction_jacobian.T
    for row, esd in zip(phase_rows, np.sqrt(np.diag(fraction_covariance))):
        row["formal_weight_fraction_esd"] = float(esd)
    nobs = int(rvals.get("Nobs", len(x)))
    nvars = int(rvals.get("Nvars", len(vary)))
    chisq = float(rvals.get("chisq", np.nan))
    reduced = chisq / max(1, nobs - nvars)
    result = {
        "schema_version": 1,
        "refinement_histogram": hist.name,
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "goodness_of_fit": float(rvals.get("GOF", np.sqrt(reduced))),
            "reduced_chi_squared": float(reduced),
            "chi_squared": chisq,
            "observations": nobs,
            "refined_parameters": nvars,
        },
        "fraction_basis": "Normalized over the five modeled crystalline phases; amorphous content not quantified.",
    }
    (output / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
