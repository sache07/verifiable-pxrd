#!/usr/bin/env python3
"""Test one isotropic size or microstrain term in a fixed GSAS-II baseline."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("mode", choices=["size", "strain"])
    parser.add_argument("--start", type=float)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    hist = project.histogram(0)
    for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."):
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in hist.SampleParameters:
            hist.SampleParameters[key][1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})

    target = project.phase(args.phase)
    if target is None:
        raise ValueError(f"No phase named {args.phase!r}")
    hap = target.data["Histograms"][hist.name]
    if args.mode == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = args.start if args.start is not None else 0.3
        hap["Size"][2] = [True, False, False]
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = args.start if args.start is not None else 1000.0
        hap["Mustrain"][2] = [True, False, False]

    project.set_Controls("cycles", 12)
    for cycle in range(3):
        project.refine()
        print("cycle", cycle, "Rwp", hist.residuals.get("wR"),
              "phase", target.name, "size", hap["Size"][:3],
              "strain", hap["Mustrain"][:3])
    project.save(str(args.output.resolve()))


if __name__ == "__main__":
    main()
