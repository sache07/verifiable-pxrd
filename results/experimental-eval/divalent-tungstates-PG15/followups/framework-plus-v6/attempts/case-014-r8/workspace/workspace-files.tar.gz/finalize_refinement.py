#!/usr/bin/env python3
"""Freeze and replay the selected physically constrained GSAS-II model."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


PHASE_SIZES_UM = {
    "SrWO4": 0.47,
    "WO3": 0.10,
    "Sr2WO5": 0.12,
    "Sr3WO6": 0.14,
    "SrCO3-highT": 0.05,
}

BACKGROUND_COEFFICIENTS = [
    629.5055426645068,
    -539.3241009157936,
    402.5115039582087,
    -225.36569078357135,
    117.39588553590741,
    -66.75139667340964,
    40.94158019123503,
    -31.40786794302272,
    16.11853071963496,
    -2.750565982508895,
]


def clear_refinements(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in hist.SampleParameters:
            hist.SampleParameters[key][1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.data["General"]["doPawley"] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["LeBail"] = False
        hap["Scale"][1] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        if "Extinction" in hap:
            hap["Extinction"][1] = False


def report(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(label, "Rwp", hist.residuals.get("wR"), "Rp", hist.residuals.get("R"))
    print("  shift", hist.SampleParameters["Shift"][0],
          "roughness", hist.SampleParameters["SurfRoughA"][0],
          hist.SampleParameters["SurfRoughB"][0])
    print("  profile", {key: hist.InstrumentParameters[key][1]
                         for key in ("U", "W", "X", "SH/L", "Polariz.")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(" ", phase.name, "scale", hap["Scale"][0],
              "size", hap["Size"][1][0], "PO", hap["Pref.Ori."][1:4])


def run_refinement(project: G2.G2Project, label: str) -> None:
    project.refine()
    report(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve())
    )
    hist = project.histogram(0)
    x = hist.data["data"][1][0]
    clear_refinements(project)

    # Use the complete measured range. The wavelength doublet and the one
    # Bragg-Brentano specimen-displacement term are fixed by metadata/model
    # selection; no separate zero correction is active.
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]
    hist.InstrumentParameters["Zero"][1] = 0.0
    hist.InstrumentParameters["U"][1] = 10.0
    hist.InstrumentParameters["V"][1] = 0.0
    hist.InstrumentParameters["W"][1] = 51.3553976924
    hist.InstrumentParameters["X"][1] = 5.4871998807
    hist.InstrumentParameters["Y"][1] = 0.0
    hist.InstrumentParameters["SH/L"][1] = 0.03
    hist.InstrumentParameters["Polariz."][1] = 0.70
    hist.data["Background"][0] = [
        "chebyschev-1", True, len(BACKGROUND_COEFFICIENTS),
        *BACKGROUND_COEFFICIENTS,
    ]
    hist.SampleParameters["Shift"] = [-619.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.20, False]
    hist.SampleParameters["SurfRoughB"] = [0.229, False]

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        size = PHASE_SIZES_UM[phase.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][1][1] = size
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Scale"][1] = True

    # The sole retained texture term was supported by multiple Sr2WO5
    # families in the axis challenge. Re-estimate it while all other texture
    # terms remain neutral.
    sr2_hap = project.phase("Sr2WO5").data["Histograms"][hist.name]
    sr2_hap["Pref.Ori."][1] = 0.75
    sr2_hap["Pref.Ori."][2] = True

    # Keep the accepted low-dimensional empirical background active in each
    # stage, so every geometry or lattice update is rebalanced against all
    # phase scales.
    hist.data["Background"][0][1] = True
    project.set_Controls("cycles", 12)

    hist.SampleParameters["SurfRoughB"][1] = True
    run_refinement(project, "roughness/background/scales")
    hist.SampleParameters["SurfRoughB"][1] = False

    hist.SampleParameters["Shift"][1] = True
    run_refinement(project, "specimen displacement")
    hist.SampleParameters["Shift"][1] = False

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    run_refinement(project, "cells")
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False

    run_refinement(project, "final common background/scales/texture")

    ratio = float(sr2_hap["Pref.Ori."][1])
    if not 0.70 <= ratio <= 1.40:
        # Reject a texture surrogate outside the physically screened range and
        # reconverge with neutral preferred orientation.
        print("rejecting Sr2WO5 texture ratio", ratio)
        sr2_hap["Pref.Ori."][1] = 1.0
        sr2_hap["Pref.Ori."][2] = False
        run_refinement(project, "texture-pruned replay")
    else:
        sr2_hap["Pref.Ori."][2] = False

    project.save(str(args.output.resolve()))
    report(project, "saved")


if __name__ == "__main__":
    main()
