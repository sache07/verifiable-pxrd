#!/usr/bin/env python3
"""Build a staged exploratory GSAS-II refinement from specified CIFs."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def set_neutral_hap(phase: G2.G2Phase, histogram: G2.G2PwdrData) -> None:
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"] = [1.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][1][1] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]


def report(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"\n--- {label}: residuals={hist.residuals}")
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")})
    print("sample", {k: v for k, v in hist.SampleParameters.items()
                     if k in ("Shift", "DisplaceX", "DisplaceY", "SurfRoughA", "SurfRoughB")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"][:3], "strain", hap["Mustrain"][:3],
              "PO", hap["Pref.Ori."][:4])


def refine(project: G2.G2Project, label: str) -> None:
    project.refine()
    report(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("cifs", nargs="+", type=Path)
    parser.add_argument("--names", nargs="*")
    parser.add_argument("--full", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    root = Path(__file__).resolve().parent
    work = root / ".tmp"
    project = G2.G2Project(newgpx=str(args.output.resolve()))
    hist = project.add_powder_histogram(
        str(work / "pattern.xye"),
        str(work / "instrument.instprm"),
        fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({
        "Limits": [10.02, 99.98],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 6,
            "coeffs": [600.0, -250.0, 150.0, -75.0, 25.0, -10.0],
            "refine": False,
        },
    })

    names = args.names or [p.stem for p in args.cifs]
    phases = []
    for name, cif in zip(names, args.cifs):
        phase = project.add_phase(
            str(cif.resolve()), phasename=name, histograms=[hist], fmthint="CIF"
        )
        set_neutral_hap(phase, hist)
        phases.append(phase)

    project.set_Controls("cycles", 8)
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    refine(project, "background and scales")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "shift")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells")

    # Hold U at a nonnegative neutral value during inventory trials; missing
    # phases otherwise drive the Caglioti term negative as a width surrogate.
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(project, "common profile")

    if args.full:
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        refine(project, "asymmetry")
        for phase in phases:
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
        refine(project, "phase sizes")

    project.save(str(args.output.resolve()))


if __name__ == "__main__":
    main()
