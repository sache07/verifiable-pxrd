#!/usr/bin/env python3
"""Refine coordinates for one phase against a fixed common profile."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("--element", action="append", default=[])
    parser.add_argument("--cycles", type=int, default=12)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    hist = project.histogram(0)
    for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."):
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in hist.SampleParameters:
            hist.SampleParameters[key][1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "

    target = project.phase(args.phase)
    if target is None:
        raise ValueError(f"No phase named {args.phase!r}")
    selected = []
    for atom in target.atoms():
        if not args.element or atom.element in args.element:
            atom.refinement_flags = "X"
            selected.append(atom.label)
    if not selected:
        raise ValueError("No atoms selected")

    print("selected", target.name, selected)
    print("before", [(a.label, a.coordinates) for a in target.atoms()])
    project.set_Controls("cycles", args.cycles)
    for cycle in range(2):
        project.refine()
        print("cycle", cycle, "Rwp", hist.residuals.get("wR"))
    print("after", [(a.label, a.coordinates) for a in target.atoms()])
    project.save(str(args.output.resolve()))


if __name__ == "__main__":
    main()
