#!/usr/bin/env python3
"""Build fit.csv and result.json from the verified, no-refinement replay."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PHASES = [
    {
        "name": "PbWO4 (stolzite)",
        "formula": "PbWO4",
        "space_group": "I 41/a (No. 88)",
        "cif_path": "phase_1_PbWO4_stolzite.cif",
        "model_provenance": "COD 9009811; coordinates and cell locally refined",
    },
    {
        "name": "Pb2WO5",
        "formula": "Pb2WO5",
        "space_group": "C 2/m (No. 12)",
        "cif_path": "phase_2_Pb2WO5_analogue.cif",
        "model_provenance": "MoPb2O5 COD 7220560 prototype with Mo6+ replaced by W6+; constrained local refinement",
        "structure_reliability": "prototype-level; exact oxygen geometry is not uniquely determined by this powder pattern",
    },
    {
        "name": "PbO (massicot)",
        "formula": "PbO",
        "space_group": "P b c m (No. 57)",
        "cif_path": "phase_3_PbO_massicot.cif",
        "model_provenance": "COD 2310433; coordinates and cell locally refined",
    },
    {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/c (No. 14)",
        "cif_path": "phase_4_WO3_monoclinic.cif",
        "model_provenance": "COD 2311041; coordinates and cell locally refined",
    },
    {
        "name": "alpha-PbO2",
        "formula": "PbO2",
        "space_group": "P b c n (No. 60)",
        "cif_path": "phase_5_alpha_PbO2.cif",
        "model_provenance": "COD 1531016; constrained coordinates with a bounded source-derived cell",
        "structure_reliability": "phase-level; detailed coordinates are weakly determined",
    },
    {
        "name": "Pb3WO6",
        "formula": "Pb3WO6",
        "space_group": "P n m a (No. 62)",
        "cif_path": "phase_6_Pb3WO6_analogue.cif",
        "model_provenance": "U(PbO2)3 COD 2310493 prototype with U6+ replaced by W6+; constrained coordinate and cell refinement",
        "structure_reliability": "prototype-level; oxygen geometry is only weakly determined",
    },
    {
        "name": "Pb3O4 (orthorhombic)",
        "formula": "Pb3O4",
        "space_group": "P b a m (No. 55)",
        "cif_path": "phase_7_Pb3O4_orthorhombic.cif",
        "model_provenance": "COD 9003043; source cell and coordinates retained",
        "fraction_reliability": "least certain component because it is weak and substantially overlapped",
    },
    {
        "name": "PbO (long-period alpha-PbO approximant)",
        "formula": "PbO",
        "space_group": "P b c m (No. 57)",
        "cif_path": "phase_8_PbO_long_period.cif",
        "model_provenance": "COD 1533609 commensurate approximant to incommensurate alpha-PbO; bounded cell and coordinate refinement",
        "structure_reliability": "approximant-level; modulation details cannot be determined from this conventional 3D powder model",
    },
]


def main() -> None:
    replay = json.loads(Path(".tmp/final_replay/replay.json").read_text())
    state = json.loads(Path(".tmp/final_state.json").read_text())
    if replay.get("status") != "replayed":
        raise RuntimeError(f"Final project did not replay: {replay}")
    if replay["project_sha256"] != state["project_sha256"]:
        raise RuntimeError("Replay project hash does not match exported final state")
    replay_fractions = [float(row["weight_fraction"]) for row in replay["phases"]]
    state_fractions = [float(row["weight_fraction"]) for row in state["phases"]]
    if not np.allclose(replay_fractions, state_fractions, rtol=0, atol=1e-14):
        raise RuntimeError("Replayed and exported phase fractions differ")

    profile = np.load(".tmp/final_replay/prediction.npz")
    x = np.asarray(profile["x"], dtype=float)
    observed = np.asarray(profile["observed"], dtype=float)
    calculated = np.asarray(profile["predicted"], dtype=float)
    difference = observed - calculated
    np.savetxt(
        "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference_observed_minus_calculated",
        comments="",
        # Seventeen significant digits round-trip the exact replay grid and
        # profile floats, including the nonuniform decimal spellings supplied
        # in the original CSV.
        fmt=["%.17g", "%.17g", "%.17g", "%.17g"],
    )

    # Use the exact saved GSAS weights. Here they equal 1/Iobs, as expected for
    # the supplied count data, and the replay calculation reproduces the saved
    # profile to sub-millicount precision.
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile="final.gpx")
    histogram = project.histogram(replay["histogram"])
    weights = np.asarray(histogram.data["data"][1][2], dtype=float)
    rwp = 100.0 * np.sqrt(
        np.sum(weights * difference**2) / np.sum(weights * observed**2)
    )
    rp = 100.0 * np.sum(np.abs(difference)) / np.sum(observed)
    chi_squared = float(np.sum(weights * difference**2))
    covariance_rvals = project.data["Covariance"]["data"]["Rvals"]
    n_parameters = int(covariance_rvals["Nvars"])
    goodness_of_fit = float(np.sqrt(chi_squared / (len(x) - n_parameters)))

    phase_rows = []
    for description, fraction in zip(PHASES, replay_fractions):
        row = dict(description)
        row["weight_fraction"] = fraction
        phase_rows.append(row)

    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent": float(rwp),
            "rp_percent": float(rp),
            "chi_squared": chi_squared,
            "goodness_of_fit": goodness_of_fit,
            "n_observations": int(len(x)),
            "n_refined_parameters": n_parameters,
            "weighting": "Poisson counting weights, w = 1/max(I_observed, 1)",
            "evaluation_range_two_theta_deg": [float(x[0]), float(x[-1])],
        },
        "refinement_histogram": replay["histogram"],
        "project_path": "final.gpx",
        "fit_path": "fit.csv",
        "fraction_basis": "normalized over the eight modeled crystalline phases; amorphous content is not determined",
        "verification": {
            "status": "native GSAS-II forward replay without optimization",
            "project_sha256": replay["project_sha256"],
            "entire_original_grid": True,
            "profile_review_flags": replay["profile_review_flags"],
        },
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
