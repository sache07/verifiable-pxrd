#!/usr/bin/env python3
"""Freeze the accepted GSAS-II model and export its exact saved phases."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/structure_trials/eight_freezecells_replay/trial.gpx")
FINAL = Path("final.gpx")
CIF_NAMES = [
    "phase_1_PbWO4_stolzite.cif",
    "phase_2_Pb2WO5_analogue.cif",
    "phase_3_PbO_massicot.cif",
    "phase_4_WO3_monoclinic.cif",
    "phase_5_alpha_PbO2.cif",
    "phase_6_Pb3WO6_analogue.cif",
    "phase_7_Pb3O4_orthorhombic.cif",
    "phase_8_PbO_long_period.cif",
]


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    histogram = project.histogram(0)

    # Atomic parameters have already been projected back into the allowed
    # coordinate neighborhoods. Ensure no accidental atomic refinement flag is
    # left active in the archival project.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.data["General"]["doPawley"] = False
        phase.data["Histograms"][histogram.name]["LeBail"] = False

    project.save()

    phases = project.phases()
    masses = [
        float(phase.data["General"]["Mass"])
        * float(phase.data["Histograms"][histogram.name]["Scale"][0])
        for phase in phases
    ]
    total_mass = sum(masses)
    if total_mass <= 0:
        raise RuntimeError("Final project has no positive crystalline mass scale")

    residuals = dict(histogram.residuals)
    covariance_rvals = dict(project.data["Covariance"]["data"].get("Rvals", {}))
    state = {
        "source_project": str(SOURCE),
        "final_project": str(FINAL),
        "histogram": histogram.name,
        "project_sha256": hashlib.sha256(FINAL.read_bytes()).hexdigest(),
        "limits": histogram.data["Limits"],
        "residuals": residuals,
        "covariance_rvals": covariance_rvals,
        "phases": [],
    }

    # The CIF writer normally consults the last covariance block. It should
    # instead serialize the full-precision atoms and cells saved in final.gpx;
    # clear covariance only in memory, after final.gpx has been written.
    project.data["Covariance"]["data"] = {}
    for index, (phase, cif_name, mass) in enumerate(zip(phases, CIF_NAMES, masses)):
        phase.export_CIF(cif_name)
        hap = phase.data["Histograms"][histogram.name]
        state["phases"].append(
            {
                "index": index,
                "project_name": phase.name,
                "cif_path": cif_name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "cell_mass": float(phase.data["General"]["Mass"]),
                "weight_fraction": mass / total_mass,
                "size_um": float(hap["Size"][1][0]),
                "mustrain_ppm": float(hap["Mustrain"][1][0]),
                "preferred_orientation": hap["Pref.Ori."][:4],
            }
        )

    Path(".tmp/final_state.json").write_text(
        json.dumps(state, indent=2, default=float) + "\n"
    )
    print(json.dumps(state, indent=2, default=float))


if __name__ == "__main__":
    main()
