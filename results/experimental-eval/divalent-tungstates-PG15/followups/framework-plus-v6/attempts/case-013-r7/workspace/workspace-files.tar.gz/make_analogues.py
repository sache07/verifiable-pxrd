#!/usr/bin/env python3
"""Build the small set of explicitly justified Pb-W-O prototype substitutions."""

from pathlib import Path
import json
import warnings

import numpy as np
from pymatgen.io.cif import CifParser, CifWriter


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
OUT = Path(".tmp/candidates")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make(cod_id: str, replacements: dict[str, str], name: str) -> dict:
    source = cod_path(cod_id)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = CifParser(source, occupancy_tolerance=10).parse_structures(
            primitive=False
        )[0]
    parent_formula = structure.composition.reduced_formula
    structure.replace_species(replacements)
    target = OUT / f"{name}.cif"
    CifWriter(structure, symprec=1e-4, significant_figures=10).write_file(target)

    distances = structure.distance_matrix.copy()
    np.fill_diagonal(distances, np.inf)
    contacts = []
    for i, j in zip(*np.where(np.triu(distances, 1) < 2.5)):
        contacts.append(
            {
                "distance_A": float(distances[i, j]),
                "elements": [
                    str(structure[i].species.elements[0]),
                    str(structure[j].species.elements[0]),
                ],
            }
        )
    contacts.sort(key=lambda row: row["distance_A"])
    return {
        "path": str(target),
        "parent_cod_id": cod_id,
        "parent_formula": parent_formula,
        "target_formula": structure.composition.reduced_formula,
        "space_group": structure.get_space_group_info(),
        "cell": list(structure.lattice.parameters),
        "minimum_contacts": contacts[:20],
        "transformation": replacements,
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    records = [
        make("7220560", {"Mo": "W"}, "Pb2WO5_from_MoPb2O5_7220560"),
        make("8103050", {"Cr": "W"}, "Pb2WO5_from_CrPb2O5_8103050"),
        make("2310493", {"U": "W"}, "Pb3WO6_from_UPb3O6_2310493"),
    ]
    (OUT / "provenance.json").write_text(json.dumps(records, indent=2) + "\n")
    print(json.dumps(records, indent=2))


if __name__ == "__main__":
    main()
