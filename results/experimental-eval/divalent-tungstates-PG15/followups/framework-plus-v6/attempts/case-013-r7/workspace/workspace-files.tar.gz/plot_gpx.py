#!/usr/bin/env python3
"""Plot a GSAS-II powder fit in stacked 2theta panels for diagnosis."""

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("gpx")
parser.add_argument("output")
args = parser.parse_args()

project = G2.G2Project(gpxfile=args.gpx)
hist = project.histogram(0)
x, observed, weights, calculated, background, difference = [
    np.asarray(v, float) for v in hist.data["data"][1][:6]
]

fig, axes = plt.subplots(3, 1, figsize=(14, 10), constrained_layout=True)
for ax, (lo, hi) in zip(axes, ((10, 40), (40, 70), (70, 100))):
    mask = (x >= lo) & (x <= hi)
    offset = -0.18 * max(observed[mask].max(), 1)
    ax.plot(x[mask], observed[mask], color="black", lw=0.65, label="observed")
    ax.plot(x[mask], calculated[mask], color="tab:red", lw=0.75, label="calculated")
    ax.plot(x[mask], difference[mask] + offset, color="tab:blue", lw=0.55, label="difference (offset)")
    ax.plot(x[mask], background[mask], color="tab:green", lw=0.7, label="background")
    ax.axhline(offset, color="0.6", lw=0.4)
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
axes[0].legend(ncol=4, fontsize=8)
axes[-1].set_xlabel(r"$2\theta$ (degrees)")
fig.suptitle(f"{Path(args.gpx).name}; Rwp={hist.residuals['wR']:.3f}%")
fig.savefig(args.output, dpi=160)
