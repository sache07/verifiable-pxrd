#!/usr/bin/env python3
"""Create a comparable, conservative GSAS-II screen for candidate COD phases.

Run this with the GSAS-II Python interpreter. Candidate arguments are COD IDs.
The script is deliberately limited to background, phase scales, one zero
correction, cells and a common instrumental profile; phase-specific broadening
and atomic parameters are left neutral for inventory screening.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from scipy.signal import savgol_filter

from GSASII import GSASIIscriptable as G2


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    direct = Path(cod_id)
    if direct.is_file():
        return direct.resolve()
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_measurement(root: Path) -> tuple[Path, Path, np.ndarray, np.ndarray]:
    raw = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
    x, y = raw.T
    data = root / "pattern.xye"
    np.savetxt(data, np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.10g")
    instrument = root / "instrument.instprm"
    instrument.write_text(
        "# GSAS-II Cu K-alpha Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return data, instrument, x, y


def initial_background(x: np.ndarray, y: np.ndarray, ncoef: int = 10) -> list[float]:
    step = float(np.median(np.diff(x)))
    window = max(101, int(round(2.5 / step)) | 1)
    baseline = percentile_filter(y, percentile=12, size=window, mode="nearest")
    baseline = savgol_filter(baseline, min(len(y) // 2 * 2 - 1, 301), 2)
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, baseline, ncoef - 1).tolist()


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    return {
        "step": label,
        "residuals": hist.residuals,
        "instrument": {
            key: float(inst[key][1])
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
            if key in inst
        },
        "sample": {
            key: (float(value[0]) if isinstance(value, list) else value)
            for key, value in hist.SampleParameters.items()
            if key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Scale")
        },
        "phases": phases,
    }


def refine(project: G2.G2Project, label: str, history: list[dict]) -> None:
    project.refine(makeBack=False)
    history.append(snapshot(project, label))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("cod_ids", nargs="+")
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    root = Path(".tmp") / "screens" / args.name
    root.mkdir(parents=True, exist_ok=True)
    data, instrument, x, y = prepare_measurement(root)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(root / "screen.gpx"))
    hist = project.add_powder_histogram(
        str(data), str(instrument), fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": initial_background(x, y),
                "refine": False,
            },
        }
    )

    phases = []
    for index, cod_id in enumerate(args.cod_ids):
        path = cod_path(cod_id)
        if not path.is_file():
            raise FileNotFoundError(path)
        phase = project.add_phase(
            str(path), phasename=f"p{index}_{Path(cod_id).stem}", histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / max(float(phase.data["General"]["Mass"]), 1.0), False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][1][1] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        phases.append(phase)

    project.set_Controls("cycles", args.cycles)
    history: list[dict] = [snapshot(project, "initial")]

    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    refine(project, "background_scales", history)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "zero", history)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells", history)
    refine(project, "reconverge", history)

    # Common low-dimensional profile. V and Y/Z remain fixed at neutral values.
    hist.set_refinements({"Instrument Parameters": ["W"]})
    refine(project, "W", history)
    hist.set_refinements({"Instrument Parameters": ["U"]})
    refine(project, "U_W", history)
    hist.set_refinements({"Instrument Parameters": ["X"]})
    refine(project, "U_W_X", history)
    refine(project, "final_reconverge", history)

    project.save()
    summary = snapshot(project, "saved")
    masses = []
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
    total = sum(masses)
    summary["weight_fractions"] = [m / total for m in masses]
    summary["history"] = history
    (root / "summary.json").write_text(json.dumps(summary, indent=2, default=float) + "\n")
    print(json.dumps({
        "name": args.name,
        "cod_ids": args.cod_ids,
        "wR": hist.get_wR(),
        "fractions": summary["weight_fractions"],
        "zero": summary["instrument"].get("Zero"),
        "U": summary["instrument"].get("U"),
        "W": summary["instrument"].get("W"),
        "X": summary["instrument"].get("X"),
        "cells": [p["cell"] for p in summary["phases"]],
    }, indent=2))


if __name__ == "__main__":
    main()
