#!/usr/bin/env python3
"""Challenge a converged GSAS-II inventory by adding one candidate phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cif_path(value: str) -> Path:
    path = Path(value)
    if path.is_file():
        return path.resolve()
    return COD_ROOT / value[0] / value[1:3] / value[3:5] / f"{value}.cif"


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    rows, masses = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        masses.append(mass)
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": phase.get_cell(),
                "size_um": float(hap["Size"][1][0]),
                "size_refine": bool(hap["Size"][2][0]),
                "weight_fraction": None,
            }
        )
    total = sum(masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = mass / total
    return {
        "label": label,
        "Rwp_percent": float(hist.residuals["wR"]),
        "phases": rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("candidate")
    parser.add_argument(
        "--start", default=".tmp/structure_trials/shl06_refine/trial.gpx"
    )
    parser.add_argument("--initial-fraction", type=float, default=0.03)
    parser.add_argument("--size", type=float, default=0.12)
    parser.add_argument("--refine-size", action="store_true")
    parser.add_argument("--refine-cell", action="store_true")
    parser.add_argument("--cycles", type=int, default=7)
    parser.add_argument("--rounds", type=int, default=2)
    args = parser.parse_args()

    out = Path(".tmp/add_phase_trials") / args.name
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.start, newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)
    old_phases = project.phases()
    old_mass = sum(
        float(p.data["Histograms"][hist.name]["Scale"][0])
        * float(p.data["General"]["Mass"])
        for p in old_phases
    )

    source = cif_path(args.candidate)
    if not source.is_file():
        raise FileNotFoundError(source)
    phase = project.add_phase(
        str(source),
        phasename=f"watch_{Path(args.candidate).stem}",
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    target_mass = old_mass * args.initial_fraction / (1.0 - args.initial_fraction)
    hap["Scale"] = [target_mass / float(phase.data["General"]["Mass"]), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = args.size
    hap["Size"][1][1] = args.size
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    phase.set_refinements({"Cell": False})
    phase.set_HAP_refinements({"Scale": True})

    project.set_Controls("cycles", args.cycles)
    history = [state(project, "added")]
    project.refine(makeBack=False)
    history.append(state(project, "scale_only"))
    if args.refine_cell and history[-1]["phases"][-1]["scale"] > 0:
        phase.set_refinements({"Cell": True})
    if args.refine_size and history[-1]["phases"][-1]["scale"] > 0:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": args.size, "refine": True}}
        )
    for index in range(args.rounds - 1):
        project.refine(makeBack=False)
        history.append(state(project, f"round_{index + 2}"))
    project.save()
    result = state(project, "saved")
    result["history_Rwp_percent"] = [row["Rwp_percent"] for row in history]
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
