#!/usr/bin/env python3
"""Replay a bounded-cell inventory while disabling selected weak phases."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    rows = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        active = bool(hap.get("Use", True)) and float(hap["Scale"][0]) > 0
        mass = (
            float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
            if active
            else 0.0
        )
        masses.append(mass)
        rows.append(
            {
                "name": phase.name,
                "active": active,
                "scale": float(hap["Scale"][0]),
                "cell": phase.get_cell(),
                "size_um": float(hap["Size"][1][0]),
                "mustrain_ppm": float(hap["Mustrain"][1][0]),
            }
        )
    total = sum(masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = mass / total if total else 0.0
    return {
        "label": label,
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "phases": rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("--start", required=True)
    parser.add_argument("--disable", action="append", type=int, default=[])
    parser.add_argument(
        "--fixed-cell",
        action="append",
        default=[],
        help="phase-index:a,b,c,alpha,beta,gamma",
    )
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--rounds", type=int, default=3)
    args = parser.parse_args()

    out = Path(".tmp/inventory_trials") / args.name
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.start, newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)
    phases = project.phases()

    for value in args.fixed_cell:
        index_text, cell_text = value.split(":", 1)
        index = int(index_text)
        cell = [float(v) for v in cell_text.split(",")]
        if len(cell) != 6:
            raise ValueError("--fixed-cell needs a,b,c,alpha,beta,gamma")
        old = phases[index].data["General"]["Cell"]
        old[:7] = [False, *cell]
        # GSAS recomputes volume when project IDs/controls are prepared, but
        # retaining the explicit orthogonal volume keeps the saved tree clear.
        import math

        a, b, c, alpha, beta, gamma = cell
        ca, cb, cg = [math.cos(math.radians(v)) for v in (alpha, beta, gamma)]
        old[7] = a * b * c * math.sqrt(
            1 + 2 * ca * cb * cg - ca * ca - cb * cb - cg * cg
        )
        phases[index].set_refinements({"Cell": False})

    for index in args.disable:
        hap = phases[index].data["Histograms"][hist.name]
        phases[index].clear_HAP_refinements({"Scale": True})
        hap["Scale"] = [0.0, False]
        hap["Use"] = False

    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = " "

    project.set_Controls("cycles", args.cycles)
    history = [snapshot(project, "configured")]
    for index in range(args.rounds):
        project.refine(makeBack=False)
        history.append(snapshot(project, f"round_{index + 1}"))
    project.save()
    result = snapshot(project, "saved")
    result["history_Rwp_percent"] = [row["Rwp_percent"] for row in history]
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
