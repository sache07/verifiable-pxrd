#!/usr/bin/env python3
"""Test small, symmetry-preserving coordinate updates with explicit RMS limits."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def lattice_matrix(cell: dict) -> np.ndarray:
    a, b, c = (cell[f"length_{v}"] for v in "abc")
    alpha, beta, gamma = np.deg2rad(
        [cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]]
    )
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * np.cos(gamma), b * np.sin(gamma), 0.0])
    cx = c * np.cos(beta)
    cy = c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)
    cz = np.sqrt(max(c * c - cx * cx - cy * cy, 0.0))
    return np.vstack((va, vb, [cx, cy, cz]))


def parse_selector(value: str) -> tuple[int, set[str] | None]:
    phase_text, atom_text = value.split(":", 1)
    atoms = None if atom_text.lower() == "all" else set(atom_text.split(","))
    return int(phase_text), atoms


def state(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    phases, masses = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        masses.append(mass)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "size_um": float(hap["Size"][1][0]),
                "weight_fraction": None,
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": [float(v) for v in atom.coordinates],
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    total = sum(masses)
    for row, mass in zip(phases, masses):
        row["weight_fraction"] = mass / total
    return {"Rwp_percent": float(hist.residuals["wR"]), "phases": phases}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("--start", required=True)
    parser.add_argument("--coords", required=True, help="phase-index:all/elements")
    parser.add_argument("--limit", action="append", default=[])
    parser.add_argument("--default-limit", type=float, default=0.04)
    parser.add_argument("--cycles", type=int, default=7)
    parser.add_argument("--replay-rounds", type=int, default=2)
    args = parser.parse_args()

    limits = {key: float(value) for key, value in (item.split(":", 1) for item in args.limit)}
    phase_index, selected = parse_selector(args.coords)
    out = Path(".tmp/restrained_coords") / args.name
    out.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.start, newgpx=str(out / "trial.gpx"))
    phases = project.phases()
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = " "

    phase = phases[phase_index]
    chosen = [
        atom
        for atom in phase.atoms()
        if selected is None or atom.element in selected or atom.label in selected
    ]
    initial = {atom.label: np.asarray(atom.coordinates, float) for atom in chosen}
    initial_cell = phase.get_cell()
    matrix = lattice_matrix(initial_cell)
    for atom in chosen:
        atom.refinement_flags = "X"

    project.set_Controls("cycles", args.cycles)
    start = state(project)
    project.refine(makeBack=False)
    free = state(project)

    displacements = {}
    for element in sorted({atom.element for atom in chosen}):
        atoms = [atom for atom in chosen if atom.element == element]
        deltas = np.array([np.asarray(atom.coordinates) - initial[atom.label] for atom in atoms])
        deltas -= np.rint(deltas)
        distances = np.linalg.norm(deltas @ matrix, axis=1)
        rms = float(np.sqrt(np.mean(distances**2)))
        limit = limits.get(element, args.default_limit)
        factor = min(1.0, limit / max(rms, 1e-15))
        for atom, delta in zip(atoms, deltas):
            atom.coordinates = initial[atom.label] + factor * delta
            atom.refinement_flags = " "
        displacements[element] = {
            "free_rms_A": rms,
            "limit_A": limit,
            "projection_factor": factor,
            "projected_rms_A": rms * factor,
        }

    replay = []
    for _ in range(args.replay_rounds):
        project.refine(makeBack=False)
        replay.append(state(project))
    project.save()
    result = state(project)
    result.update(
        start_Rwp_percent=start["Rwp_percent"],
        free_Rwp_percent=free["Rwp_percent"],
        replay_Rwp_percent=[row["Rwp_percent"] for row in replay],
        displacement_limits=displacements,
    )
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "name": args.name,
                "start_Rwp_percent": result["start_Rwp_percent"],
                "free_Rwp_percent": result["free_Rwp_percent"],
                "replay_Rwp_percent": result["replay_Rwp_percent"],
                "fractions": [p["weight_fraction"] for p in result["phases"]],
                "displacements": displacements,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
