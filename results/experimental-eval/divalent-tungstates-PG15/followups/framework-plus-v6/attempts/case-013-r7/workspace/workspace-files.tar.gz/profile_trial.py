#!/usr/bin/env python3
"""Run controlled profile/geometry trials from a common four-phase project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def indices(value: str) -> set[int]:
    return {int(v) for v in value.split(",") if v.strip()} if value else set()


def indexed_values(value: str) -> dict[int, float]:
    if not value:
        return {}
    return {int(item.split(":", 1)[0]): float(item.split(":", 1)[1]) for item in value.split(",")}


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    instrument = hist.InstrumentParameters
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        masses.append(mass)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "size_type": hap["Size"][0],
                "size_values": [float(v) for v in hap["Size"][1]],
                "size_flags": [bool(v) for v in hap["Size"][2]],
                "mustrain_type": hap["Mustrain"][0],
                "mustrain_values": [float(v) for v in hap["Mustrain"][1]],
                "mustrain_flags": [bool(v) for v in hap["Mustrain"][2]],
                "preferred_orientation": hap["Pref.Ori."][:4],
            }
        )
    total = sum(masses)
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / total
    return {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {
            key: {
                "value": float(instrument[key][1]),
                "refine": bool(instrument[key][2]),
            }
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
            if key in instrument
        },
        "sample": {
            key: value
            for key, value in hist.SampleParameters.items()
            if key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Scale", "Type")
        },
        "phases": phases,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument(
        "--start", default=".tmp/screens/pb2wo5_plus_pbo/screen.gpx"
    )
    parser.add_argument("--U", type=float, default=5.0)
    parser.add_argument("--W", type=float, default=15.0)
    parser.add_argument("--X", type=float, default=2.0)
    parser.add_argument("--shl", type=float, default=0.03)
    parser.add_argument("--refine-inst", default="W,X")
    parser.add_argument("--sizes", default="")
    parser.add_argument("--fixed-sizes", default="")
    parser.add_argument("--strains", default="")
    parser.add_argument("--size-start", type=float, default=0.3)
    parser.add_argument("--strain-start", type=float, default=1200.0)
    parser.add_argument("--texture-index", type=int, default=-1)
    parser.add_argument("--texture-axis", default="0,0,1")
    parser.add_argument("--geometry", choices=("zero", "shift"), default="zero")
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--rounds", type=int, default=3)
    args = parser.parse_args()

    out = Path(".tmp/profile_trials") / args.name
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.start, newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)
    phases = project.phases()
    inst = hist.InstrumentParameters

    # Clear all old profile/geometry flags and set a physical neutral baseline.
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                key
                for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
                if key in inst
            ],
            "Sample Parameters": [
                key
                for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
                if key in hist.SampleParameters
            ],
        }
    )
    for key, value in {
        "U": args.U,
        "V": 0.0,
        "W": args.W,
        "X": args.X,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": args.shl,
    }.items():
        if key in inst:
            inst[key][1] = value
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    size_indices = indices(args.sizes)
    fixed_sizes = indexed_values(args.fixed_sizes)
    strain_indices = indices(args.strains)
    texture_axis = [int(v) for v in args.texture_axis.split(",")]
    if len(texture_axis) != 3:
        raise ValueError("--texture-axis must contain h,k,l")
    for i, phase in enumerate(phases):
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = fixed_sizes.get(
            i, args.size_start if i in size_indices else 10.0
        )
        hap["Size"][1][1] = hap["Size"][1][0]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = args.strain_start if i in strain_indices else 0.0
        hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        if i == args.texture_index:
            hap["Pref.Ori."][3] = texture_axis
        hap["Extinction"] = [0.0, False]

    hist.set_refinements({"Background": True})
    if args.geometry == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    else:
        inst["Zero"][1] = 0.0
        hist.set_refinements({"Sample Parameters": ["Shift"]})

    project.set_Controls("cycles", args.cycles)
    history = [state(project, "reset")]
    project.refine(makeBack=False)
    history.append(state(project, "baseline_reconverged"))

    refine_inst = [v for v in args.refine_inst.split(",") if v]
    if refine_inst:
        hist.set_refinements({"Instrument Parameters": refine_inst})
    for i in size_indices:
        phases[i].set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": args.size_start, "refine": True}}
        )
    for i in strain_indices:
        phases[i].set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    if args.texture_index >= 0:
        phases[args.texture_index].set_HAP_refinements({"Pref.Ori.": True})
    for round_index in range(args.rounds):
        project.refine(makeBack=False)
        history.append(state(project, f"active_round_{round_index + 1}"))

    project.save()
    summary = state(project, "saved")
    summary["history"] = history
    (out / "summary.json").write_text(json.dumps(summary, indent=2, default=float) + "\n")
    print(json.dumps(summary, indent=2, default=float))


if __name__ == "__main__":
    main()
