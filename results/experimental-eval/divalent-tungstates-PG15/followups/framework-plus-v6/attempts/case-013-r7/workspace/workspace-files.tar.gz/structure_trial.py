#!/usr/bin/env python3
"""Run reversible atomic-parameter trials from an accepted GSAS-II baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def selectors(values: list[str]) -> dict[int, set[str] | None]:
    result: dict[int, set[str] | None] = {}
    for value in values:
        phase_text, atom_text = value.split(":", 1)
        result[int(phase_text)] = (
            None if atom_text.lower() == "all" else set(atom_text.split(","))
        )
    return result


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    rows = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        masses.append(mass)
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": phase.get_cell(),
                "size_um": float(hap["Size"][1][0]),
                "mustrain_ppm": [float(v) for v in hap["Mustrain"][1][:2]],
                "preferred_orientation": hap["Pref.Ori."][:4],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": [float(v) for v in atom.coordinates],
                        "uiso_A2": float(atom.uiso),
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    total = sum(masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = mass / total
    inst = hist.InstrumentParameters
    return {
        "label": label,
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "GOF": float(hist.residuals.get("GOF", float("nan"))),
        "instrument": {
            key: {"value": float(inst[key][1]), "refine": bool(inst[key][2])}
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
            if key in inst
        },
        "phases": rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument(
        "--start", default=".tmp/profile_trials/phys_x6/trial.gpx"
    )
    parser.add_argument(
        "--coords",
        action="append",
        default=[],
        help="phase-index:all or phase-index:comma-separated-elements",
    )
    parser.add_argument("--uiso-phase", action="append", type=int, default=[])
    parser.add_argument("--uiso-start", type=float, default=0.008)
    parser.add_argument(
        "--fixed-uiso",
        action="append",
        default=[],
        help="phase-index:value-A2",
    )
    parser.add_argument("--strain-phase", action="append", type=int, default=[])
    parser.add_argument("--strain-start", type=float, default=1200.0)
    parser.add_argument(
        "--fixed-strain",
        action="append",
        default=[],
        help="phase-index:value-ppm",
    )
    parser.add_argument(
        "--texture",
        action="append",
        default=[],
        help="phase-index:h,k,l",
    )
    parser.add_argument(
        "--fixed-texture",
        action="append",
        default=[],
        help="phase-index:ratio:h,k,l",
    )
    parser.add_argument("--refine-instrument", default="")
    parser.add_argument(
        "--set-instrument",
        action="append",
        default=[],
        help="instrument-parameter:value (fixed unless also requested for refinement)",
    )
    parser.add_argument("--geometry", choices=("keep", "zero", "shift"), default="keep")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--roughness-start", default="0.3,0.1")
    parser.add_argument("--cell-phase", action="append", type=int, default=[])
    parser.add_argument("--size-phase", action="append", type=int, default=[])
    parser.add_argument("--fixed-cell-phase", action="append", type=int, default=[])
    parser.add_argument(
        "--fixed-size", action="append", default=[], help="phase-index:value-um"
    )
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--rounds", type=int, default=3)
    args = parser.parse_args()

    out = Path(".tmp/structure_trials") / args.name
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.start, newgpx=str(out / "trial.gpx"))
    phases = project.phases()
    hist = project.histogram(0)

    # Every trial starts with no atomic flags, then releases only the requested set.
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = " "

    for phase_index, elements in selectors(args.coords).items():
        for atom in phases[phase_index].atoms():
            if elements is None or atom.element in elements or atom.label in elements:
                atom.refinement_flags = "X"

    # The generator uses one isotropic U value per phase. Equivalence constraints
    # retain that physical parameterization while allowing the common value to vary.
    for phase_index in args.uiso_phase:
        atoms = phases[phase_index].atoms()
        for atom in atoms:
            atom.uiso = args.uiso_start
            atom.refinement_flags = atom.refinement_flags.strip() + "U"
        variables = tuple(f"{phase_index}::AUiso:{i}" for i in range(len(atoms)))
        if len(variables) > 1:
            project.add_EquivConstr(variables)

    for value in args.fixed_uiso:
        phase_text, uiso_text = value.split(":", 1)
        phase_index = int(phase_text)
        uiso = float(uiso_text)
        for atom in phases[phase_index].atoms():
            atom.uiso = uiso
            atom.refinement_flags = atom.refinement_flags.replace("U", "")

    for phase_index in args.strain_phase:
        hap = phases[phase_index].data["Histograms"][hist.name]
        phases[phase_index].clear_HAP_refinements({"Mustrain": True})
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = args.strain_start
        hap["Mustrain"][1][1] = args.strain_start
        phases[phase_index].set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )

    for phase_index in args.cell_phase:
        phases[phase_index].set_refinements({"Cell": True})

    for phase_index in args.fixed_cell_phase:
        phases[phase_index].set_refinements({"Cell": False})

    for phase_index in args.size_phase:
        hap = phases[phase_index].data["Histograms"][hist.name]
        phases[phase_index].set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": float(hap["Size"][1][0]),
                    "refine": True,
                }
            }
        )

    for value in args.fixed_size:
        phase_text, size_text = value.split(":", 1)
        phase_index = int(phase_text)
        size = float(size_text)
        hap = phases[phase_index].data["Histograms"][hist.name]
        phases[phase_index].clear_HAP_refinements({"Size": True})
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][1][1] = size
        hap["Size"][2] = [False for _ in hap["Size"][2]]

    for value in args.fixed_strain:
        phase_text, strain_text = value.split(":", 1)
        phase_index = int(phase_text)
        strain = float(strain_text)
        hap = phases[phase_index].data["Histograms"][hist.name]
        phases[phase_index].clear_HAP_refinements({"Mustrain": True})
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][1][1] = strain
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]

    for value in args.texture:
        phase_text, axis_text = value.split(":", 1)
        phase_index = int(phase_text)
        axis = [int(v) for v in axis_text.split(",")]
        if len(axis) != 3 or not any(axis):
            raise ValueError("--texture needs phase-index:h,k,l")
        hap = phases[phase_index].data["Histograms"][hist.name]
        phases[phase_index].clear_HAP_refinements({"Pref.Ori.": True})
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = axis
        phases[phase_index].set_HAP_refinements({"Pref.Ori.": True})

    for value in args.fixed_texture:
        phase_text, ratio_text, axis_text = value.split(":", 2)
        phase_index = int(phase_text)
        axis = [int(v) for v in axis_text.split(",")]
        if len(axis) != 3 or not any(axis):
            raise ValueError("--fixed-texture needs phase-index:ratio:h,k,l")
        hap = phases[phase_index].data["Histograms"][hist.name]
        phases[phase_index].clear_HAP_refinements({"Pref.Ori.": True})
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = float(ratio_text)
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = axis

    instrument_parameters = [v for v in args.refine_instrument.split(",") if v]
    for value in args.set_instrument:
        key, parameter_text = value.split(":", 1)
        if key not in hist.InstrumentParameters:
            raise ValueError(f"Unknown instrument parameter {key}")
        hist.InstrumentParameters[key][1] = float(parameter_text)
        hist.InstrumentParameters[key][2] = False
    if instrument_parameters:
        hist.set_refinements({"Instrument Parameters": instrument_parameters})

    if args.geometry != "keep":
        hist.clear_refinements(
            {
                "Instrument Parameters": ["Zero"],
                "Sample Parameters": ["Shift", "Transparency"],
            }
        )
        if args.geometry == "zero":
            hist.InstrumentParameters["Zero"][1] = 0.0
            hist.set_refinements({"Instrument Parameters": ["Zero"]})
        else:
            hist.InstrumentParameters["Zero"][1] = 0.0
            hist.SampleParameters["Shift"] = [0.0, True]

    if args.roughness:
        rough_a, rough_b = [float(v) for v in args.roughness_start.split(",")]
        hist.SampleParameters["SurfRoughA"] = [rough_a, True]
        hist.SampleParameters["SurfRoughB"] = [rough_b, True]

    project.set_Controls("cycles", args.cycles)
    history = [snapshot(project, "start")]
    for index in range(args.rounds):
        project.refine(makeBack=False)
        history.append(snapshot(project, f"round_{index + 1}"))
    project.save()

    result = snapshot(project, "saved")
    result["history_Rwp_percent"] = [row["Rwp_percent"] for row in history]
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "name": args.name,
                "Rwp_percent": result["Rwp_percent"],
                "history_Rwp_percent": result["history_Rwp_percent"],
                "fractions": [p["weight_fraction"] for p in result["phases"]],
                "coordinates": args.coords,
                "uiso_phases": args.uiso_phase,
                "strain_phases": args.strain_phase,
                "textures": args.texture,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
