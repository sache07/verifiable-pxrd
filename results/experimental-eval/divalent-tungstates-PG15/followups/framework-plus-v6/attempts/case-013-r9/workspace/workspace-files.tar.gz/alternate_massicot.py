#!/usr/bin/env python3
"""Challenge the modulated/supercell massicot PbO record COD 1533609."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "profile_anchor.gpx"
ALT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/53/36/1533609.cif")
OUT = WORK / "alternate_massicot.gpx"


def report(project, label):
    hist = project.histogram(0)
    raw, rows = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if not hap or not hap.get("Use", True):
            rows.append({"name": phase.name, "used": False})
            raw.append(0.0)
            continue
        amount = max(0.0, hap["Scale"][0] * phase.data["General"]["Mass"])
        raw.append(amount)
        rows.append({"name": phase.name, "used": True, "scale": hap["Scale"][0], "cell": phase.get_cell()})
    total = sum(raw)
    for row, amount in zip(rows, raw):
        if row["used"]:
            row["weight_fraction"] = amount / total
    print("ALT_MASSICOT", json.dumps({"label": label, "Rwp": hist.get_wR(), "phases": rows}, sort_keys=True))


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(OUT.resolve()))
    hist = project.histogram(0)
    old = project.phase("PbO_massicot")
    old_hap = old.data["Histograms"][hist.name]
    target_mass_amount = old_hap["Scale"][0] * old.data["General"]["Mass"]
    old_hap["Scale"] = [0.0, False]
    old_hap["Use"] = False
    old.set_refinements({"Cell": False})

    alt = project.add_phase(str(ALT), phasename="PbO_massicot_supercell", histograms=[hist], fmthint="CIF")
    hap = alt.data["Histograms"][hist.name]
    hap["Scale"] = [target_mass_amount / alt.data["General"]["Mass"], True]
    common_size = project.phase("PbWO4_scheelite").data["Histograms"][hist.name]["Size"][1][0]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0:2] = [common_size, common_size]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 15)
    project.refine()
    report(project, "scale")

    alt.set_refinements({"Cell": True})
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 18)
    project.refine()
    report(project, "scale_cell")
    project.save(OUT)


if __name__ == "__main__":
    main()
