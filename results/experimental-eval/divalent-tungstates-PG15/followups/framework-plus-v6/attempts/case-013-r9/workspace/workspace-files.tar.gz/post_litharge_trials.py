#!/usr/bin/env python3
"""Re-challenge corrected litharge and common profile terms."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "drop_pb2wo5_strain.gpx"
LITHARGE = "PbO_litharge_1"


def bounds(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def run(tag, setup):
    out = WORK / f"post_litharge_{tag}.gpx"
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(out.resolve()))
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
    setup(project)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 20)
    project.refine()
    hist = project.histogram(0)
    phase = project.phase(LITHARGE)
    hap = phase.data["Histograms"][hist.name]
    raw = []
    for ph in project.phases():
        phap = ph.data["Histograms"].get(hist.name)
        raw.append(0.0 if not phap or not phap.get("Use", True) else max(0.0, phap["Scale"][0] * ph.data["General"]["Mass"]))
    print("POST_LITHARGE", json.dumps({
        "tag": tag,
        "Rwp": hist.get_wR(),
        "fraction": raw[phase.id] / sum(raw),
        "Pb_z": phase.atom("Pb1").coordinates[2],
        "size": hap["Size"][1][0],
        "strain": hap["Mustrain"][1][0],
        "MD": hap["Pref.Ori."][1],
        "axis": hap["Pref.Ori."][3],
        "U": hist.InstrumentParameters["U"],
        "W": hist.InstrumentParameters["W"],
        "SHL": hist.InstrumentParameters["SH/L"],
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }, sort_keys=True), flush=True)
    project.save(out)


def main():
    G2.SetPrintLevel("warn")
    run("Pb_z", lambda p: p.phase(LITHARGE).set_refinements({"Atoms": {"Pb1": "X"}}))

    for axis in ([0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]):
        def texture(p, axis=axis):
            phase = p.phase(LITHARGE)
            hap = phase.data["Histograms"][p.histogram(0).name]
            hap["Pref.Ori."][0:4] = ["MD", 1.05, True, list(axis)]
            bounds(p, f"{phase.id}:0:MD", 0.70, 1.40)
        run("texture_" + "".join(map(str, axis)), texture)

    def size(p):
        phase = p.phase(LITHARGE)
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        bounds(p, f"{phase.id}:0:Size;i", 0.04, 1.50)
    run("size", size)

    def strain(p):
        phase = p.phase(LITHARGE)
        hap = phase.data["Histograms"][p.histogram(0).name]
        hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        bounds(p, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
    run("strain", strain)

    def inst_u(p):
        h = p.histogram(0)
        h.InstrumentParameters["U"][1:] = [10.0, True]
        bounds(p, ":0:U", 0.0, 40.0)
    run("instrument_U", inst_u)

    def shl(p):
        h = p.histogram(0)
        h.InstrumentParameters["SH/L"][2] = True
        bounds(p, ":0:SH/L", 0.005, 0.10)
    run("SHL", shl)


if __name__ == "__main__":
    main()
