#!/usr/bin/env python3
"""Apply source-conditioned coordinate shifts capped at 0.05 Angstrom."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "structure_physical_base.gpx"
OUT = WORK / "structure_clamped.gpx"


COORDS = {
    "PbWO4_scheelite": {
        "O": [0.24085538814332348, 0.11138268139065621, 0.0471484611990388],
    },
    "Pb2WO5_trial": {
        "Pb0": [0.00998364899437829, 0.5, 0.24948522272488113],
        "Pb1": [0.13361364899437828, 0.0, 0.11162267815034939],
        "W2": [0.16745175780607957, 0.0, 0.6631334546829776],
    },
    "WO3_2311041": {
        "W1": [0.03449400622840044, 0.03674917683319744, 0.7507315900582094],
        "W2": [0.5404940062284004, 0.01636968078217282, 0.7452684099417906],
    },
}


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(OUT.resolve()))
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
    for phase_name, rows in COORDS.items():
        phase = project.phase(phase_name)
        for label, xyz in rows.items():
            phase.atom(label).coordinates = xyz
    # Scheelite alone gave a stable interior common Uiso.
    for atom in project.phase("PbWO4_scheelite").atoms():
        atom.uiso = 0.01060394148488689
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 24)
    project.refine()
    hist = project.histogram(0)
    raw, rows = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        used = bool(hap and hap.get("Use", True) and hap["Scale"][0] != 0)
        value = max(0.0, hap["Scale"][0] * phase.data["General"]["Mass"]) if used else 0.0
        raw.append(value)
        rows.append({"name": phase.name, "used": used, "atoms": {a.label: list(a.coordinates) for a in phase.atoms()}})
    for row, val in zip(rows, raw):
        if row["used"]:
            row["fraction"] = val / sum(raw)
    print("CLAMPED_STRUCTURE", json.dumps({
        "Rwp": hist.get_wR(),
        "rows": rows,
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }, sort_keys=True))
    project.save(OUT)
    for name in ["PbWO4_scheelite", "PbO_massicot", "PbO_litharge", "Pb2WO5_trial", "WO3_2311041"]:
        project.phase(name).export_CIF(str(WORK / f"clamped_{name}.cif"))


if __name__ == "__main__":
    main()
