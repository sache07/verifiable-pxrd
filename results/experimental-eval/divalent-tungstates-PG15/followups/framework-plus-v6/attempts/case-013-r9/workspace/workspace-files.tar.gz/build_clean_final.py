#!/usr/bin/env python3
"""Create and replay the clean final GSAS-II project with accepted phases only."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "work" / "final_U_trial.gpx"
OUTPUT = ROOT / "final.gpx"
REMOVE = ["PbO_litharge", "WO3_monoclinic"]
RENAME = {
    "Pb2WO5_trial": "Pb2WO5_C2m",
    "WO3_2311041": "WO3_monoclinic",
    "PbO_litharge_1": "PbO_litharge",
    "Pb3WO6_analogue": "Pb3WO6_Pnma",
    "Pb3O4_tetrag_finalwatch": "Pb3O4_minium",
}


def phase_names_node(project):
    return next(node for node in project.names if node and node[0] == "Phases")


def fractions(project):
    hist = project.histogram(0)
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap and hap.get("Use", True) and hap["Scale"][0] > 0:
            raw[phase.name] = hap["Scale"][0] * phase.data["General"]["Mass"]
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE.resolve()), newgpx=str(OUTPUT.resolve()))
    hist = project.histogram(0)
    names = phase_names_node(project)

    for name in REMOVE:
        project.data["Phases"].pop(name, None)
        if name in names:
            names.remove(name)
        hist.data["Reflection Lists"].pop(name, None)

    for old, new in RENAME.items():
        phase_data = project.data["Phases"].pop(old)
        phase_data["General"]["Name"] = new
        project.data["Phases"][new] = phase_data
        names[names.index(old)] = new
        if old in hist.data["Reflection Lists"]:
            hist.data["Reflection Lists"][new] = hist.data["Reflection Lists"].pop(old)

    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    project.update_ids()
    project.index_ids()

    accepted = [
        "PbWO4_scheelite", "PbO_massicot", "Pb2WO5_C2m", "WO3_monoclinic",
        "PbO_litharge", "Pb3WO6_Pnma", "Pb3O4_minium",
    ]
    actual = [phase.name for phase in project.phases()]
    if set(actual) != set(accepted) or len(actual) != len(accepted):
        raise RuntimeError(f"unexpected clean phase inventory: {actual}")

    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
        if phase.name in ("PbO_massicot", "WO3_monoclinic"):
            # Their source records encode zero/default displacement parameters.
            # A small fixed positive value is physical and remained preferable to
            # the bound, highly correlated independent Uiso trials.
            for atom in phase.atoms():
                atom.uiso = 0.005
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")

    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMax", 40.0, variable=":0:U")
    project.set_Controls("parmMin", 2.0, variable=":0:W")
    project.set_Controls("parmMax", 40.0, variable=":0:W")
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.set_Controls("parmMin", 0.04, variable=f"{project.phase('PbWO4_scheelite').id}:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{project.phase('PbWO4_scheelite').id}:0:Size;i")
    for name in ("PbO_massicot", "Pb2WO5_C2m"):
        phase = project.phase(name)
        project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")

    history = []
    for replay in range(8):
        controls["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 45)
        project.refine()
        cov = project.data["Covariance"]["data"]
        rvals = cov.get("Rvals", {})
        history.append({
            "pass": replay + 1,
            "Rwp": hist.get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
        })
        if rvals.get("converged") and rvals.get("Max shft/sig", 1e9) < 0.05:
            break

    # Remove stale per-phase residual labels inherited from deleted trial phases.
    # ``hist.residuals`` is a filtered copy in this GSAS-II build; edit the
    # histogram's stored residual dictionary so the cleanup survives saving.
    residuals = hist.data["data"][0]
    active_ids = {str(phase.id) for phase in project.phases()}
    for key in list(residuals):
        prefix = str(key).split(":", 1)[0]
        if prefix.isdigit() and prefix not in active_ids:
            residuals.pop(key, None)
    project.save(OUTPUT)
    print("CLEAN_FINAL", json.dumps({
        "Rwp": hist.get_wR(),
        "Rp": hist.residuals.get("Rp"),
        "GOF": project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "phases": [phase.name for phase in project.phases()],
        "fractions": fractions(project),
        "instrument": {key: hist.InstrumentParameters[key] for key in ("U", "W", "X", "SH/L", "Polariz.")},
        "shift": hist.SampleParameters["Shift"],
        "history": history,
        "frozen": {
            str(key): [str(value) for value in values]
            for key, values in controls.get("parmFrozen", {}).items()
        },
    }, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
