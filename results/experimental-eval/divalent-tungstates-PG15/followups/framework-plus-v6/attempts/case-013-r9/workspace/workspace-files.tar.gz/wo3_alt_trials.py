#!/usr/bin/env python3
"""Texture and heavy-coordinate challenges for selected WO3 COD 2311041."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "wo3_alternate_2311041.gpx"
PHASE = "WO3_2311041"


def common_result(project, tag):
    hist = project.histogram(0)
    phase = project.phase(PHASE)
    hap = phase.data["Histograms"][hist.name]
    raw = []
    for ph in project.phases():
        phap = ph.data["Histograms"].get(hist.name)
        raw.append(0.0 if not phap or not phap.get("Use", True) else max(0.0, phap["Scale"][0] * ph.data["General"]["Mass"]))
    return {
        "tag": tag,
        "Rwp": hist.get_wR(),
        "MD": hap["Pref.Ori."][1],
        "axis": hap["Pref.Ori."][3],
        "fraction": raw[phase.id] / sum(raw),
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }


def main():
    G2.SetPrintLevel("warn")
    axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]
    for idx, axis in enumerate(axes):
        out = WORK / f"wo3_alt_texture_{idx}.gpx"
        project = G2.G2Project(str(BASE.resolve()), newgpx=str(out.resolve()))
        hist = project.histogram(0)
        phase = project.phase(PHASE)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0:4] = ["MD", 1.05, True, list(axis)]
        project.set_Controls("parmMin", 0.70, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 1.40, variable=f"{phase.id}:0:MD")
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 15)
        project.refine()
        print("WO3_ALT_TRIAL", json.dumps(common_result(project, f"texture_{axis}"), sort_keys=True), flush=True)
        project.save(out)

    out = WORK / "wo3_alt_heavy.gpx"
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(out.resolve()))
    for ph in project.phases():
        ph.set_refinements({"Atoms": {"all": " "}})
    phase = project.phase(PHASE)
    before = {label: list(phase.atom(label).coordinates) for label in ("W1", "W2")}
    phase.set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 18)
    project.refine()
    result = common_result(project, "heavy_coordinates")
    result["before"] = before
    result["after"] = {label: list(phase.atom(label).coordinates) for label in ("W1", "W2")}
    print("WO3_ALT_TRIAL", json.dumps(result, sort_keys=True), flush=True)
    project.save(out)
    phase.export_CIF(str(WORK / "wo3_alt_heavy.cif"))


if __name__ == "__main__":
    main()
