#!/usr/bin/env python3
"""Bound coordinate shifts to the laboratory reference-mismatch scale.

Unconstrained oxygen and some heavy-atom fits were chemically implausible.
These trials start from the selected source/analogue coordinates and permit at
most about 0.05 Angstrom along each fractional lattice direction.
"""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
SOURCE = WORK / "structure_clean.gpx"
BASE = WORK / "structure_physical_base.gpx"


PB2_PARENT = {
    "Pb0": [0.0135, 0.5, 0.25628],
    "Pb1": [0.13713, 0.0, 0.11447],
    "W2": [0.16897, 0.0, 0.65939],
    "O3": [0.1472, 0.2425, 0.7818],
    "O4": [0.0, 0.255, 0.0],
    "O5": [0.0859, 0.0, 0.3999],
    "O6": [0.2009, 0.5, 0.3069],
}


def clear_flags(project):
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})


def reset_pb2(project):
    phase = project.phase("Pb2WO5_trial")
    for label, xyz in PB2_PARENT.items():
        phase.atom(label).coordinates = xyz


def bounds_for_atoms(project, phase, labels, max_A=0.05):
    cell = phase.get_cell()
    limits = [max_A / cell["length_a"], max_A / cell["length_b"], max_A / cell["length_c"]]
    atoms = phase.atoms()
    for atom_idx, atom in enumerate(atoms):
        if atom.label not in labels:
            continue
        atom.refinement_flags = "X"
        for suffix, lim in zip(("x", "y", "z"), limits):
            variable = f"{phase.id}::dA{suffix}:{atom_idx}"
            project.set_Controls("parmMin", -lim, variable=variable)
            project.set_Controls("parmMax", lim, variable=variable)


def summary(project, tag, phase_name):
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "tag": tag,
        "phase": phase_name,
        "Rwp": hist.get_wR(),
        "atoms": {a.label: list(a.coordinates) for a in phase.atoms()},
        "coordinate_variables": {n: float(v) for n, v in zip(cov.get("varyList", []), cov.get("variables", [])) if n.startswith(f"{phase.id}::dA")},
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }
    print("RESTRAINED_COORD", json.dumps(result, sort_keys=True), flush=True)


def refine(project, cycles=20):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.refine()


def make_base():
    project = G2.G2Project(str(SOURCE.resolve()), newgpx=str(BASE.resolve()))
    clear_flags(project)
    reset_pb2(project)
    refine(project, 20)
    summary(project, "physical_base", "Pb2WO5_trial")
    project.save(BASE)


def trial(tag, phase_name, labels, reset=None):
    out = WORK / f"restrained_{tag}.gpx"
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(out.resolve()))
    clear_flags(project)
    if reset:
        reset(project)
    phase = project.phase(phase_name)
    bounds_for_atoms(project, phase, labels)
    refine(project, 22)
    summary(project, tag, phase_name)
    project.save(out)
    phase.export_CIF(str(WORK / f"restrained_{tag}.cif"))


def main():
    G2.SetPrintLevel("warn")
    make_base()
    trial("scheelite_O", "PbWO4_scheelite", ["O"])
    trial("pb2wo5_all", "Pb2WO5_trial", list(PB2_PARENT), reset=reset_pb2)
    trial("wo3_heavy", "WO3_2311041", ["W1", "W2"])
    trial("wo3_all", "WO3_2311041", ["W1", "W2", "O1", "O2", "O3", "O4", "O5", "O6"])


if __name__ == "__main__":
    main()
