#!/usr/bin/env python3
"""Apply source-conditioned Pb3WO6 heavy-atom shifts capped at 0.05 A."""

from pathlib import Path
import json
import math

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "work" / "cand_pb3wo6_cell.gpx"
TRIAL = ROOT / "work" / "pb3wo6_heavy_trial.gpx"
OUTPUT = ROOT / "work" / "pb3wo6_heavy_clamped.gpx"
LABELS = ["Pb0", "Pb1", "Pb2", "Pb3", "Pb4", "W5"]


def main():
    G2.SetPrintLevel("warn")
    trial = G2.G2Project(str(TRIAL.resolve()))
    trial_phase = trial.phase("Pb3WO6_analogue")
    cov = trial.data["Covariance"]["data"]
    proposed = {
        name: float(value)
        for name, value in zip(cov.get("varyList", []), cov.get("variables", []))
        if name.startswith(f"{trial_phase.id}::dA")
    }

    project = G2.G2Project(str(BASE.resolve()), newgpx=str(OUTPUT.resolve()))
    for item in project.phases():
        item.set_refinements({"Atoms": {"all": " "}})
    phase = project.phase("Pb3WO6_analogue")
    cell = phase.get_cell()
    lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
    applied = {}
    for index, atom in enumerate(phase.atoms()):
        if atom.label not in LABELS:
            continue
        delta = [proposed.get(f"{phase.id}::dA{suffix}:{index}", 0.0) for suffix in ("x", "y", "z")]
        cart = [value * length for value, length in zip(delta, lengths)]
        norm = math.sqrt(sum(value * value for value in cart))
        factor = min(1.0, 0.05 / norm) if norm else 1.0
        bounded = [value * factor for value in delta]
        atom.coordinates = [(value + shift) % 1.0 for value, shift in zip(atom.coordinates, bounded)]
        applied[atom.label] = {
            "proposed_fractional": delta,
            "proposed_norm_A": norm,
            "applied_fractional": bounded,
            "applied_norm_A": norm * factor,
            "coordinates": list(atom.coordinates),
        }

    history = []
    for replay in range(6):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 40)
        project.refine()
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        history.append({
            "pass": replay + 1,
            "Rwp": project.histogram(0).get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
        })
        if rvals.get("converged") and rvals.get("Max shft/sig", 1e9) < 0.08:
            break
    print("PB3WO6_CLAMPED", json.dumps({
        "Rwp": project.histogram(0).get_wR(),
        "applied": applied,
        "history": history,
        "frozen": {
            str(key): [str(value) for value in values]
            for key, values in project.data["Controls"]["data"].get("parmFrozen", {}).items()
        },
    }, sort_keys=True), flush=True)
    project.save(OUTPUT)
    phase.export_CIF(str(ROOT / "work" / "pb3wo6_heavy_clamped.cif"))


if __name__ == "__main__":
    main()
