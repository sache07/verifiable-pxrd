#!/usr/bin/env python3
"""Drop one accepted nuisance term at a time after the litharge correction."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "litharge_corrected.gpx"


def drop(project, tag):
    hist = project.histogram(0)
    if tag == "scheelite_size":
        hap = project.phase("PbWO4_scheelite").data["Histograms"][hist.name]
        hap["Size"][1][0] = 0.11186460943829919
        hap["Size"][2] = [False, False, False]
    elif tag == "massicot_texture":
        hap = project.phase("PbO_massicot").data["Histograms"][hist.name]
        hap["Pref.Ori."][1:4] = [1.0, False, [1, 0, 0]]
    elif tag == "pb2wo5_strain":
        hap = project.phase("Pb2WO5_trial").data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
    elif tag == "pb2wo5_texture":
        hap = project.phase("Pb2WO5_trial").data["Histograms"][hist.name]
        hap["Pref.Ori."][1:4] = [1.0, False, [0, 1, 0]]
    elif tag == "polarization":
        hist.InstrumentParameters["Polariz."][1:] = [0.70, False]


def main():
    G2.SetPrintLevel("warn")
    for tag in ["scheelite_size", "massicot_texture", "pb2wo5_strain", "pb2wo5_texture", "polarization"]:
        out = WORK / f"drop_{tag}.gpx"
        project = G2.G2Project(str(BASE.resolve()), newgpx=str(out.resolve()))
        drop(project, tag)
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 20)
        project.refine()
        hist = project.histogram(0)
        ph = project.phase("Pb2WO5_trial").data["Histograms"][hist.name]
        print("DROP_TERM", json.dumps({
            "tag": tag,
            "Rwp": hist.get_wR(),
            "W": hist.InstrumentParameters["W"][1],
            "polarization": hist.InstrumentParameters["Polariz."][1],
            "scheelite_size": project.phase("PbWO4_scheelite").data["Histograms"][hist.name]["Size"][1][0],
            "massicot_MD": project.phase("PbO_massicot").data["Histograms"][hist.name]["Pref.Ori."][1],
            "pb2wo5_strain": ph["Mustrain"][1][0],
            "pb2wo5_MD": ph["Pref.Ori."][1],
            "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
        }, sort_keys=True), flush=True)
        project.save(out)


if __name__ == "__main__":
    main()
