#!/usr/bin/env python3
"""Combine accepted physical coordinate corrections with selected WO3 source."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "wo3_alternate_2311041.gpx"
OUT = WORK / "structure_clean.gpx"


COORDS = {
    "PbO_massicot": {
        "Pb1": [0.22393381253629258, 0.009320947262594569, 0.25],
    },
    "Pb2WO5_trial": {
        "Pb0": [0.009985766408378977, 0.5, 0.2705172528826828],
        "Pb1": [0.12496524938818676, 0.0, 0.1175548459025313],
        "W2": [0.16544677426944437, 0.0, 0.6555493090302235],
    },
}


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(OUT.resolve()))
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
    for phase_name, atoms in COORDS.items():
        phase = project.phase(phase_name)
        for label, coords in atoms.items():
            phase.atom(label).coordinates = coords
            phase.atom(label).refinement_flags = "X"
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 24)
    project.refine()

    hist = project.histogram(0)
    raw, rows = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        used = bool(hap and hap.get("Use", True) and hap["Scale"][0] != 0)
        amount = max(0.0, hap["Scale"][0] * phase.data["General"]["Mass"]) if used else 0.0
        raw.append(amount)
        rows.append({
            "name": phase.name,
            "used": used,
            "cell": phase.get_cell(),
            "atoms": {a.label: list(a.coordinates) for a in phase.atoms()},
        })
    for row, value in zip(rows, raw):
        if row["used"]:
            row["fraction"] = value / sum(raw)
    print("STRUCTURE_CLEAN", json.dumps({
        "Rwp": hist.get_wR(),
        "rows": rows,
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }, sort_keys=True))
    project.save(OUT)
    for phase_name in ["PbO_massicot", "Pb2WO5_trial", "WO3_2311041"]:
        project.phase(phase_name).export_CIF(str(WORK / f"structure_clean_{phase_name}.cif"))


if __name__ == "__main__":
    main()
