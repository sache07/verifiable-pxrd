#!/usr/bin/env python3
"""Build and screen additional isovalent Pb2WO5 analogue starting models."""

from pathlib import Path
import json
import sys
import warnings

import numpy as np
from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PARENTS = [
    ("8103050", COD / "8/10/30/8103050.cif", {"Cr": "W"}),
    ("9015570", COD / "9/01/55/9015570.cif", {"Te": "W"}),
    ("2002145", COD / "2/00/21/2002145.cif", {"Te": "W"}),
]

sys.path.insert(0, str(ROOT / "learned" / "divalent-tungstates" / "runtime"))
from models import write_synthetic_model  # noqa: E402


def main():
    for cod_id, source, substitution in PARENTS:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = Structure.from_file(source, primitive=False)
        parent_formula = structure.composition.reduced_formula
        structure.remove_oxidation_states()
        structure.replace_species(substitution)
        if structure.composition.reduced_formula != "Pb2WO5":
            raise RuntimeError(f"{cod_id}: unexpected transformed formula {structure.composition}")
        distances = structure.distance_matrix.copy()
        np.fill_diagonal(distances, np.inf)
        minimum = float(np.min(distances))
        if minimum < 0.8:
            raise RuntimeError(f"{cod_id}: hard interatomic contact {minimum}")
        output = ROOT / "work" / f"Pb2WO5_analogue_{cod_id}.cif"
        write_synthetic_model(structure, output, symprec=0.001)
        provenance = {
            "model_basis": "analogue_derived",
            "parent_cod_id": cod_id,
            "parent_formula": parent_formula,
            "target_formula": "Pb2WO5",
            "transformation": ", ".join(f"{a} -> {b}" for a, b in substitution.items()),
            "space_group": structure.get_space_group_info(),
            "cell": [*structure.lattice.abc, *structure.lattice.angles],
            "density_g_cm3": float(structure.density),
            "minimum_separation_A": minimum,
        }
        output.with_suffix(".provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
        print(json.dumps({"cif": str(output), **provenance}, sort_keys=True))


if __name__ == "__main__":
    main()
