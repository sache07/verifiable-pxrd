#!/usr/bin/env python3
"""Rewrite COD 9012700 in a GSAS-consistent P4/nmm setting."""

from pathlib import Path
import sys
import warnings

from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parent
SOURCE = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/01/27/9012700.cif")
OUTPUT = ROOT / "work" / "PbO_litharge_9012700_standardized.cif"

sys.path.insert(0, str(ROOT / "learned" / "divalent-tungstates" / "runtime"))
from models import write_synthetic_model  # noqa: E402


def main():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = Structure.from_file(SOURCE, primitive=False)
    if structure.composition.reduced_formula != "PbO":
        raise RuntimeError(f"unexpected source composition {structure.composition}")
    write_synthetic_model(structure, OUTPUT, symprec=0.001)
    print(OUTPUT)


if __name__ == "__main__":
    main()
