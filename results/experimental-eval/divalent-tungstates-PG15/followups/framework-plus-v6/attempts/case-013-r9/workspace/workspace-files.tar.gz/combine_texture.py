#!/usr/bin/env python3
"""Combine only interior, replay-stable March-Dollase texture candidates."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "common_polarization.gpx"
OUT = WORK / "combined_texture.gpx"


STAGES = [
    ("PbO_massicot", [1, 0, 0], 0.883),
    ("WO3_monoclinic", [0, 1, 0], 0.923),
    ("Pb2WO5_trial", [0, 1, 0], 0.917),
]


def report(project, label):
    hist = project.histogram(0)
    raw, rows = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw.append(max(0.0, hap["Scale"][0] * phase.data["General"]["Mass"]))
        rows.append({
            "name": phase.name,
            "MD": hap["Pref.Ori."][1],
            "axis": hap["Pref.Ori."][3],
            "texture_refine": hap["Pref.Ori."][2],
            "size": hap["Size"][1][0],
            "strain": hap["Mustrain"][1][0],
        })
    for row, val in zip(rows, raw):
        row["fraction"] = val / sum(raw)
    print("COMBINED_TEXTURE", json.dumps({
        "label": label,
        "Rwp": hist.get_wR(),
        "rows": rows,
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }, sort_keys=True))


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(OUT.resolve()))
    hist = project.histogram(0)
    # Explicitly neutralize every texture before accumulating accepted terms.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]

    for idx, (name, axis, start) in enumerate(STAGES):
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0:4] = ["MD", start, True, list(axis)]
        project.set_Controls("parmMin", 0.70, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 1.40, variable=f"{phase.id}:0:MD")
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 18)
        project.refine()
        report(project, f"{idx+1}_{name}")
        project.save(WORK / f"combined_texture_{idx+1}.gpx")
    project.save(OUT)


if __name__ == "__main__":
    main()
