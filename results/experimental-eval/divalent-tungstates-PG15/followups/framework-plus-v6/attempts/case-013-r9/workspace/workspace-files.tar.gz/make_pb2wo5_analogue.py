#!/usr/bin/env python3
"""Create an isovalent Pb2WO5 model from published Pb2MoO5 (COD 7220560)."""

from pathlib import Path
import json
import sys
import warnings

import numpy as np
from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parent
PARENT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/7/22/05/7220560.cif")
OUTPUT = ROOT / "work" / "Pb2WO5_analogue_7220560.cif"

sys.path.insert(0, str(ROOT / "learned" / "divalent-tungstates" / "runtime"))
from models import write_synthetic_model  # noqa: E402


def main():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = Structure.from_file(PARENT, primitive=False)
    structure.replace_species({"Mo": "W"})
    distances = structure.distance_matrix.copy()
    np.fill_diagonal(distances, np.inf)
    if structure.composition.reduced_formula != "Pb2WO5":
        raise RuntimeError(f"unexpected composition {structure.composition}")
    if float(np.min(distances)) < 0.8:
        raise RuntimeError("hard interatomic contact")
    write_synthetic_model(structure, OUTPUT, symprec=0.001)
    provenance = {
        "model_basis": "analogue_derived",
        "parent_cod_id": "7220560",
        "parent_formula": "Pb2MoO5",
        "target_formula": "Pb2WO5",
        "transformation": "Isovalent same-group substitution Mo6+ -> W6+; parent cell and symmetry-constrained fractional coordinates retained as the starting model.",
        "space_group": structure.get_space_group_info(),
        "cell": [*structure.lattice.abc, *structure.lattice.angles],
        "density_g_cm3": float(structure.density),
        "minimum_separation_A": float(np.min(distances)),
    }
    OUTPUT.with_suffix(".provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    print(json.dumps({"cif": str(OUTPUT), **provenance}, indent=2))


if __name__ == "__main__":
    main()
