#!/usr/bin/env python3
"""Export CIFs, profile, machine-readable result and concise final report."""

from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"
PHASE_INFO = {
    "PbWO4_scheelite": {
        "formula": "PbWO4", "cif": "phase_PbWO4_scheelite.cif",
        "model_basis": "COD 9009811 (published scheelite)",
    },
    "PbO_massicot": {
        "formula": "PbO", "cif": "phase_PbO_massicot.cif",
        "model_basis": "COD 2310433 (published massicot)",
    },
    "Pb2WO5_C2m": {
        "formula": "Pb2WO5", "cif": "phase_Pb2WO5_C2m.cif",
        "model_basis": "analogue-derived from Pb2MoO5, COD 7220560, by Mo6+ -> W6+ substitution",
    },
    "WO3_monoclinic": {
        "formula": "WO3", "cif": "phase_WO3_monoclinic.cif",
        "model_basis": "COD 2311041 (published monoclinic WO3)",
    },
    "PbO_litharge": {
        "formula": "PbO", "cif": "phase_PbO_litharge.cif",
        "model_basis": "COD 9012700 chemistry, represented in the correct P4/nmm origin choice",
    },
    "Pb3WO6_Pnma": {
        "formula": "Pb3WO6", "cif": "phase_Pb3WO6_Pnma.cif",
        "model_basis": "analogue-derived from Pb3UO6, COD 2310493, by isovalent U6+ -> W6+ substitution",
    },
    "Pb3O4_minium": {
        "formula": "Pb3O4", "cif": "phase_Pb3O4_minium.cif",
        "model_basis": "COD 9012124 (published ambient tetragonal minium)",
    },
}


def main():
    project = G2.G2Project(str(PROJECT.resolve()))
    hist = project.histogram(0)
    phases = project.phases()
    if {phase.name for phase in phases} != set(PHASE_INFO):
        raise RuntimeError("final project inventory differs from export map")

    raw = {
        phase.name: phase.data["Histograms"][hist.name]["Scale"][0] * phase.data["General"]["Mass"]
        for phase in phases
    }
    total = sum(raw.values())
    fractions = {name: value / total for name, value in raw.items()}

    phase_rows = []
    for phase in phases:
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif"]))
        phase_rows.append({
            "name": phase.name,
            "formula": info["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": info["cif"],
            "weight_fraction": fractions[phase.name],
            "model_basis": info["model_basis"],
        })

    x, observed, weights, calculated, background = [
        np.asarray(value, dtype=float) for value in hist.data["data"][1][:5]
    ]
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.10g",
    )
    use = (x >= hist.Limits("lower")) & (x <= hist.Limits("upper"))
    direct_weights = 1.0 / np.maximum(observed, 1.0)
    direct_rwp = 100.0 * np.sqrt(
        np.sum(direct_weights[use] * difference[use] ** 2)
        / np.sum(direct_weights[use] * observed[use] ** 2)
    )
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    fit_stats = {
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(hist.residuals["R"]),
        "R_background_percent": float(hist.residuals["Rb"]),
        "GOF": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_variables": int(rvals["Nvars"]),
        "direct_profile_Rwp_percent": float(direct_rwp),
    }
    result = {
        "phases": phase_rows,
        "fit_statistics": fit_stats,
        "refinement_histogram": hist.name,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "fractions_normalization": "Modeled crystalline phases only; sums to 1.0.",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    scheelite_hap = project.phase("PbWO4_scheelite").data["Histograms"][hist.name]
    massicot_hap = project.phase("PbO_massicot").data["Histograms"][hist.name]
    pb2_hap = project.phase("Pb2WO5_C2m").data["Histograms"][hist.name]
    table = ["| Phase | wt% | Structural basis |", "|---|---:|---|"]
    for row in phase_rows:
        table.append(f"| {row['formula']} ({row['space_group']}) | {100*row['weight_fraction']:.2f} | {row['model_basis']} |")
    report = f"""# Powder XRD phase analysis

The refined crystalline inventory contains seven phases. Fractions are normalized over the modeled crystalline phases; no amorphous/internal-standard correction is possible from this scan alone.

{chr(10).join(table)}

## Evidence and model selection

Scheelite PbWO4 is the dominant phase and accounts for the strong families throughout the scan. Residual precursor/decomposition peaks require both PbO polymorphs and monoclinic WO3. The selected WO3 record (COD 2311041) has physical W–O geometry and outperformed the alternate monoclinic/high-pressure records.

No exact Pb2WO5 entry was available. The C2/m Pb2MoO5 parent (COD 7220560) was adapted by the isovalent Mo6+→W6+ substitution; its coherent families near 25.9, 29.2, 31.0 and 34.9° survive scale/cell replay, while C2/c, Cc and the alternative C2/m parents fit substantially worse as replacements.

The large residual at 30.22° and additional families near 26.59, 27.45, 29.0–29.4, 51.46, 54.43 and 57.1° require a second lead-rich tungstate. A Pnma Pb3WO6 model was constructed from published Pb3UO6 (COD 2310493) by U6+→W6+ substitution. Its adapted cell and 0.05 Å-capped heavy-atom shifts remain physical (approximately W–O 1.91–2.22 Å and shortest Pb–O about 2.17 Å). Removing this phase raises Rwp from {fit_stats['Rwp_percent']:.3f}% to about 11.00%.

Ambient tetragonal Pb3O4 is weak but replay-stable at about {100*fractions['Pb3O4_minium']:.2f} wt%, with support from partly independent families around 26.7, 31.0, 45–46.5, 50.2 and 75.6°. Its cell could not be refined reliably without exceeding the reference-mismatch range, so the published cell was retained. Pb2O3 was rejected because its two strongest lines required a runaway monoclinic distortion; cubic PbO2 gave a numerical gain but is a 160 kbar fluorite record and has no defensible 500 °C ambient analogue.

The accepted nuisance model uses a smooth eight-coefficient background, one specimen displacement ({sample['Shift'][0]:.1f} µm), polarization {inst['Polariz.'][1]:.3f}, U/W/X = {inst['U'][1]:.3f}/{inst['W'][1]:.3f}/{inst['X'][1]:.3f}, and fixed SH/L = {inst['SH/L'][1]:.5f}. Scheelite has an independently supported size of {scheelite_hap['Size'][1][0]:.3f} µm. Supported March–Dollase terms are {massicot_hap['Pref.Ori.'][1]:.3f} along [100] for massicot and {pb2_hap['Pref.Ori.'][1]:.3f} along [010] for Pb2WO5. Roughness, extra SH/L freedom, and bound PbO/Pb3WO6 size/strain or texture terms were rejected.

## Fit and uncertainty

The final full-range fit has Rwp = {fit_stats['Rwp_percent']:.3f}%, Rp = {fit_stats['Rp_percent']:.3f}% and GOF = {fit_stats['GOF']:.3f} over {fit_stats['n_observations']} points. The model remains above the Poisson-limit diagnostic (about 3.5% Rwp), so minor residual profile/intensity mismatch remains.

PbWO4, both PbO polymorphs, WO3 and Pb2WO5 are well supported as phases, but oxygen coordinates and fixed displacement parameters are only weakly constrained by Cu X-ray powder data. Pb2WO5 and Pb3WO6 are analogue-derived rather than uniquely solved ab initio; their topology and fractions are defensible, but detailed light-atom coordinates are source-conditioned. Pb3O4 is near the practical detection limit, and its reported fraction should be treated as approximate. Alternative weak-phase partitions can improve Rwp only by using chemically/structurally inadmissible cells, so they were not reported as determined phases.
"""
    (ROOT / "report.md").write_text(report)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
