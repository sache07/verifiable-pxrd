#!/usr/bin/env python3
"""Map the X/size degeneracy with X fixed and all relative phase widths free."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "profile_common_only.gpx"


def bounds(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def run(x_value):
    out = WORK / f"grid_X_{x_value:g}.gpx"
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(out.resolve()))
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}

    # Keep one physical angular correction and a fixed representative X. The
    # latter removes the exact Lorentzian common-X/absolute-size degeneracy.
    hist.InstrumentParameters["Zero"][1:] = [0.0, False]
    hist.SampleParameters["Shift"] = [-480.0, True]
    bounds(project, ":0:Shift", -800.0, 800.0)
    hist.InstrumentParameters["X"][1:] = [x_value, False]
    hist.InstrumentParameters["U"][1:] = [0.0, False]
    hist.InstrumentParameters["W"][2] = True
    bounds(project, ":0:W", 2.0, 40.0)

    for pidx, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.35
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        bounds(project, f"{pidx}:0:Size;i", 0.04, 1.5)

    project.set_Controls("cycles", 15)
    project.refine()
    project.save(out)

    raw = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw.append(max(0.0, hap["Scale"][0] * phase.data["General"]["Mass"]))
        phases.append({"name": phase.name, "size_um": hap["Size"][1][0]})
    total = sum(raw)
    for row, value in zip(phases, raw):
        row["weight_fraction"] = value / total
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "X": x_value,
        "Rwp": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "W": hist.InstrumentParameters["W"][1],
        "Shift": hist.SampleParameters["Shift"][0],
        "phases": phases,
        "varyList": cov.get("varyList", []),
        "frozen": {
            str(key): [str(v) for v in values]
            for key, values in project.data["Controls"]["data"].get("parmFrozen", {}).items()
        },
        "output": str(out),
    }
    print("GRID_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    run(float(sys.argv[1]))
