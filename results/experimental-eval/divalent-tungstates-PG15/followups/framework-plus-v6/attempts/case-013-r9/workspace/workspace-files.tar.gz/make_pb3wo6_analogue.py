#!/usr/bin/env python3
"""Create a Pb3WO6 model from isovalent published Pb3UO6."""

from pathlib import Path
import json
import sys
import warnings

import numpy as np
from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parent
PARENT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/04/2310493.cif")
OUTPUT = ROOT / "work" / "Pb3WO6_analogue_2310493.cif"

sys.path.insert(0, str(ROOT / "learned" / "divalent-tungstates" / "runtime"))
from models import write_synthetic_model  # noqa: E402


def main():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = Structure.from_file(PARENT, primitive=False)
    structure.remove_oxidation_states()
    structure.replace_species({"U": "W"})
    distances = structure.distance_matrix.copy()
    np.fill_diagonal(distances, np.inf)
    if structure.composition.reduced_formula != "Pb3WO6":
        raise RuntimeError(f"unexpected composition {structure.composition}")
    minimum = float(np.min(distances))
    if minimum < 0.8:
        raise RuntimeError(f"hard interatomic contact {minimum}")
    write_synthetic_model(structure, OUTPUT, symprec=0.001)
    provenance = {
        "model_basis": "analogue_derived",
        "parent_cod_id": "2310493",
        "parent_formula": "Pb3UO6",
        "target_formula": "Pb3WO6",
        "transformation": "Isovalent U6+ -> W6+ substitution; parent symmetry and fractional coordinates retained as a starting model.",
        "space_group": structure.get_space_group_info(),
        "cell": [*structure.lattice.abc, *structure.lattice.angles],
        "density_g_cm3": float(structure.density),
        "minimum_separation_A": minimum,
    }
    OUTPUT.with_suffix(".provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    print(json.dumps({"cif": str(OUTPUT), **provenance}, indent=2))


if __name__ == "__main__":
    main()
