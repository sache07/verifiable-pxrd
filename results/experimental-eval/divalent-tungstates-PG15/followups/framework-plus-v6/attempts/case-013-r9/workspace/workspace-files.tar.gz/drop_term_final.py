#!/usr/bin/env python3
"""Drop one retained final-model term and reconverge for support testing."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "work" / "final_U_trial.gpx"
PB3WO6_SOURCE = ROOT / "work" / "cand_pb3wo6_cell.gpx"


def fractions(project):
    hist = project.histogram(0)
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap and hap.get("Use", True) and hap["Scale"][0] > 0:
            raw[phase.name] = hap["Scale"][0] * phase.data["General"]["Mass"]
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("term", choices=[
        "scheelite_size", "massicot_texture", "pb2wo5_texture", "pb3o4_phase",
        "pb3wo6_phase", "polarization", "U", "pb3wo6_coords",
    ])
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    if args.term == "scheelite_size":
        hap = project.phase("PbWO4_scheelite").data["Histograms"][hist.name]
        common = project.phase("PbO_massicot").data["Histograms"][hist.name]["Size"][1][0]
        hap["Size"][1][0:2] = [common, common]
        hap["Size"][2] = [False, False, False]
    elif args.term == "massicot_texture":
        hap = project.phase("PbO_massicot").data["Histograms"][hist.name]
        hap["Pref.Ori."][1:3] = [1.0, False]
    elif args.term == "pb2wo5_texture":
        hap = project.phase("Pb2WO5_trial").data["Histograms"][hist.name]
        hap["Pref.Ori."][1:3] = [1.0, False]
    elif args.term in ("pb3o4_phase", "pb3wo6_phase"):
        name = "Pb3O4_tetrag_finalwatch" if args.term == "pb3o4_phase" else "Pb3WO6_analogue"
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [0.0, False]
        hap["Use"] = False
        phase.set_refinements({"Cell": False})
    elif args.term == "polarization":
        hist.InstrumentParameters["Polariz."][1:] = [0.7, False]
    elif args.term == "U":
        hist.InstrumentParameters["U"][1:] = [0.0, False]
    else:
        source = G2.G2Project(str(PB3WO6_SOURCE.resolve()))
        source_phase = source.phase("Pb3WO6_analogue")
        source_coords = {atom.label: list(atom.coordinates) for atom in source_phase.atoms()}
        phase = project.phase("Pb3WO6_analogue")
        for atom in phase.atoms():
            atom.coordinates = source_coords[atom.label]

    history = []
    for replay in range(6):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 45)
        project.refine()
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        history.append({"pass": replay + 1, "Rwp": hist.get_wR(), "max_shift_over_esd": rvals.get("Max shft/sig")})
        if rvals.get("converged") and rvals.get("Max shft/sig", 1e9) < 0.06:
            break
    print("DROP_TERM", json.dumps({
        "term": args.term,
        "Rwp": hist.get_wR(),
        "fractions": fractions(project),
        "history": history,
        "frozen": {
            str(key): [str(value) for value in values]
            for key, values in project.data["Controls"]["data"].get("parmFrozen", {}).items()
        },
    }, sort_keys=True), flush=True)
    project.save(args.output)


if __name__ == "__main__":
    main()
