#!/usr/bin/env python3
"""Replay a GSAS-II project to stable least-squares convergence."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


def phase_fractions(project):
    hist = project.histogram(0)
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap and hap.get("Use", True) and hap["Scale"][0] > 0:
            raw[phase.name] = hap["Scale"][0] * phase.data["General"]["Mass"]
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--passes", type=int, default=6)
    parser.add_argument("--cycles", type=int, default=40)
    parser.add_argument("--threshold", type=float, default=0.08)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    for iteration in range(args.passes):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", args.cycles)
        project.refine()
        cov = project.data["Covariance"]["data"]
        rvals = cov.get("Rvals", {})
        maximum = float(rvals.get("Max shft/sig", float("inf")))
        print("REPLAY", json.dumps({
            "pass": iteration + 1,
            "Rwp": project.histogram(0).get_wR(),
            "max_shift_over_esd": maximum,
            "converged": bool(rvals.get("converged", False)),
            "fractions": phase_fractions(project),
        }, sort_keys=True), flush=True)
        if rvals.get("converged") and maximum < args.threshold:
            break
    project.save(args.output)


if __name__ == "__main__":
    main()
