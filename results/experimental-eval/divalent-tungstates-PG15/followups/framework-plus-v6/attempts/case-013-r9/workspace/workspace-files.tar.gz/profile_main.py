#!/usr/bin/env python3
"""Fit the dominant scheelite width using separated size and strain terms."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "profile_common_only.gpx"


def bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def report(project, label):
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    rows = []
    raw = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        rows.append({
            "name": phase.name,
            "size": hap["Size"][1][0],
            "strain": hap["Mustrain"][1][0],
        })
        raw.append(max(0.0, hap["Scale"][0] * phase.data["General"]["Mass"]))
    for row, val in zip(rows, raw):
        row["fraction"] = val / sum(raw)
    print("MAIN_STAGE", json.dumps({
        "label": label,
        "Rwp": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "W": hist.InstrumentParameters["W"][1],
        "X": hist.InstrumentParameters["X"][1],
        "Shift": hist.SampleParameters["Shift"][0],
        "phases": rows,
        "varyList": cov.get("varyList", []),
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }, sort_keys=True))
    project.save(WORK / f"main_{label}.gpx")


def refine(project, label, cycles=15):
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.refine()
    report(project, label)


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str((WORK / "main_profile.gpx").resolve()))
    hist = project.histogram(0)

    hist.InstrumentParameters["Zero"][1:] = [0.0, False]
    hist.SampleParameters["Shift"] = [-480.0, True]
    bound(project, ":0:Shift", -800.0, 800.0)
    hist.InstrumentParameters["U"][1:] = [0.0, False]
    hist.InstrumentParameters["W"][1:] = [10.0, True]
    hist.InstrumentParameters["X"][1:] = [3.0, False]
    bound(project, ":0:W", 2.0, 40.0)

    for pidx, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:3] = [10.0, 10.0, 1.0]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:3] = [0.0, 0.0, 1.0]
        bound(project, f"{pidx}:0:Size;i", 0.04, 1.5)
        bound(project, f"{pidx}:0:Mustrain;i", 0.0, 8000.0)

    main_phase = project.phase("PbWO4_scheelite")
    main_phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.8, "refine": True}})
    refine(project, "size")

    hap = main_phase.data["Histograms"][hist.name]
    hap["Mustrain"][1][0] = 1800.0
    main_phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, "size_strain", 20)
    project.save(WORK / "main_profile.gpx")


if __name__ == "__main__":
    main()
