#!/usr/bin/env python3
"""Test one phase-specific size or strain term on the corrected inventory."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "work" / "base_replayed.gpx"


def fractions(project):
    hist = project.histogram(0)
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap and hap.get("Use", True) and hap["Scale"][0] > 0:
            raw[phase.name] = hap["Scale"][0] * phase.data["General"]["Mass"]
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["size", "strain"])
    parser.add_argument("phase")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    if args.mode == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = max(0.04, min(1.5, hap["Size"][1][0]))
        hap["Size"][2] = [True, False, False]
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:0:Size;i")
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0:2] = [1000.0, 1000.0]
        hap["Mustrain"][2] = [True, False, False]
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;i")

    history = []
    for replay in range(5):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 35)
        project.refine()
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        history.append({
            "pass": replay + 1,
            "Rwp": hist.get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
        })
        if rvals.get("converged") and rvals.get("Max shft/sig", 1e9) < 0.08:
            break

    result = {
        "mode": args.mode,
        "phase": args.phase,
        "phase_id": phase.id,
        "Rwp": hist.get_wR(),
        "size_um": hap["Size"][1][0],
        "strain_ppm": hap["Mustrain"][1][0],
        "W": hist.InstrumentParameters["W"][1],
        "fractions": fractions(project),
        "history": history,
        "frozen": {
            str(key): [str(value) for value in values]
            for key, values in project.data["Controls"]["data"].get("parmFrozen", {}).items()
        },
    }
    print("PROFILE_TRIAL", json.dumps(result, sort_keys=True), flush=True)
    project.save(args.output)


if __name__ == "__main__":
    main()
