#!/usr/bin/env python3
"""Re-challenge weak Pb oxide watch-list phases under the corrected profile."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "drop_pb2wo5_strain.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


CANDIDATES = [
    ("Pb3O4_watch", COD / "9/01/21/9012124.cif"),
    ("Pb2O3_watch", COD / "2/31/10/2311012.cif"),
]


def report(project, phase, label):
    hist = project.histogram(0)
    raw = []
    for ph in project.phases():
        hap = ph.data["Histograms"].get(hist.name)
        raw.append(0.0 if not hap or not hap.get("Use", True) else max(0.0, hap["Scale"][0] * ph.data["General"]["Mass"]))
    hap = phase.data["Histograms"][hist.name]
    print("WATCHLIST_STAGE", json.dumps({
        "label": label,
        "phase": phase.name,
        "Rwp": hist.get_wR(),
        "scale": hap["Scale"][0],
        "weight_fraction": raw[phase.id] / sum(raw),
        "cell": phase.get_cell(),
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }, sort_keys=True), flush=True)


def main():
    G2.SetPrintLevel("warn")
    for name, cif in CANDIDATES:
        out = WORK / f"rechallenge_{name}.gpx"
        project = G2.G2Project(str(BASE.resolve()), newgpx=str(out.resolve()))
        hist = project.histogram(0)
        existing = 0.0
        for ph in project.phases():
            hap = ph.data["Histograms"].get(hist.name)
            if hap and hap.get("Use", True):
                existing += max(0.0, hap["Scale"][0] * ph.data["General"]["Mass"])
        phase = project.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [0.02 * existing / phase.data["General"]["Mass"], True]
        common_size = project.phase("PbO_massicot").data["Histograms"][hist.name]["Size"][1][0]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0:2] = [common_size, common_size]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0:2] = [0.0, 0.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 20)
        project.refine()
        report(project, phase, "scale")
        phase.set_refinements({"Cell": True})
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 22)
        project.refine()
        report(project, phase, "scale_cell")
        project.save(out)


if __name__ == "__main__":
    main()
