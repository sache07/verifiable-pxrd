#!/usr/bin/env python3
"""Release one candidate cell after its scale-only inventory challenge."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


def fractions(project):
    hist = project.histogram(0)
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap and hap.get("Use", True) and hap["Scale"][0] > 0:
            raw[phase.name] = hap["Scale"][0] * phase.data["General"]["Mass"]
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("phase")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    phase = project.phase(args.phase)
    phase.set_refinements({"Cell": True})
    history = []
    for replay in range(8):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 40)
        project.refine()
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        history.append({
            "pass": replay + 1,
            "Rwp": project.histogram(0).get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
        })
        if rvals.get("converged") and rvals.get("Max shft/sig", 1e9) < 0.08:
            break
    print("CANDIDATE_CELL", json.dumps({
        "phase": args.phase,
        "Rwp": project.histogram(0).get_wR(),
        "cell": phase.get_cell(),
        "fractions": fractions(project),
        "history": history,
        "frozen": {
            str(key): [str(value) for value in values]
            for key, values in project.data["Controls"]["data"].get("parmFrozen", {}).items()
        },
    }, sort_keys=True), flush=True)
    project.save(args.output)


if __name__ == "__main__":
    main()
