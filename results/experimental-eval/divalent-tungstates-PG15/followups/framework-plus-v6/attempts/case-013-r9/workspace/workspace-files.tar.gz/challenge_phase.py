#!/usr/bin/env python3
"""Add one candidate to a converged GPX and re-converge the common model."""

from pathlib import Path
import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


def neutralize(phase, hist):
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.15, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][1][1] = 10.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]


def report(project, label):
    hist = project.histogram(0)
    raw = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw.append(max(0.0, float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])))
    total = sum(raw)
    phases = []
    for phase, value in zip(project.phases(), raw):
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "weight_fraction": value / total if total else None,
                "cell": phase.get_cell(),
            }
        )
    result = {
        "label": label,
        "wR": hist.get_wR(),
        "residuals": hist.residuals,
        "phases": phases,
        "instrument": {k: hist.InstrumentParameters[k] for k in ("Zero", "U", "W", "X", "SH/L")},
    }
    print("CHALLENGE", json.dumps(result, sort_keys=True))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("name")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.base.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]
    phase = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize(phase, hist)
    project.set_Controls("cycles", 10)
    project.refine()
    report(project, "scale_only")

    phase = project.phase(args.name)
    phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 12)
    project.refine()
    report(project, "scale_and_cell")
    project.save(args.output)


if __name__ == "__main__":
    main()
