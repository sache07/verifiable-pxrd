#!/usr/bin/env python3
"""Challenge symmetry-distinct March-Dollase axes one phase at a time."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "common_polarization.gpx"


PHASE_AXES = [
    (0, "PbWO4_scheelite", [[0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]]),
    (1, "PbO_massicot", [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]),
    (2, "PbO_litharge", [[0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]]),
    (3, "WO3_monoclinic", [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]),
    (4, "Pb2WO5_trial", [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]),
]


def main():
    G2.SetPrintLevel("warn")
    trial = 0
    for pidx, name, axes in PHASE_AXES:
        for axis in axes:
            output = WORK / f"texture_trial_{trial:02d}.gpx"
            project = G2.G2Project(str(BASE.resolve()), newgpx=str(output.resolve()))
            hist = project.histogram(0)
            project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
            phase = project.phase(name)
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.05
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
            project.set_Controls("parmMin", 0.70, variable=f"{pidx}:0:MD")
            project.set_Controls("parmMax", 1.40, variable=f"{pidx}:0:MD")
            project.set_Controls("cycles", 12)
            project.refine()
            raw = []
            for ph in project.phases():
                phap = ph.data["Histograms"][hist.name]
                raw.append(max(0.0, phap["Scale"][0] * ph.data["General"]["Mass"]))
            result = {
                "trial": trial,
                "phase_index": pidx,
                "name": name,
                "axis": axis,
                "Rwp": hist.get_wR(),
                "MD": hap["Pref.Ori."][1],
                "weight_fraction": raw[pidx] / sum(raw),
                "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
            }
            print("TEXTURE_STAGE", json.dumps(result, sort_keys=True), flush=True)
            project.save(output)
            trial += 1


if __name__ == "__main__":
    main()
