#!/usr/bin/env python3
"""Refine one common isotropic displacement parameter per phase independently."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "structure_clean.gpx"
PHASES = ["PbWO4_scheelite", "PbO_massicot", "PbO_litharge", "Pb2WO5_trial", "WO3_2311041"]


def main():
    G2.SetPrintLevel("warn")
    for idx, name in enumerate(PHASES):
        out = WORK / f"uiso_trial_{idx}.gpx"
        project = G2.G2Project(str(BASE.resolve()), newgpx=str(out.resolve()))
        # Fix all coordinates for an isolated Uiso challenge.
        for phase in project.phases():
            phase.set_refinements({"Atoms": {"all": " "}})
        phase = project.phase(name)
        atoms = phase.atoms()
        for atom in atoms:
            atom.uiso = 0.008
            atom.refinement_flags = "U"
        if len(atoms) > 1:
            project.add_EquivConstr(tuple(f"{phase.id}::AUiso:{i}" for i in range(len(atoms))))
        project.set_Controls("parmMin", 0.003, variable=f"{phase.id}::AUiso:*")
        project.set_Controls("parmMax", 0.020, variable=f"{phase.id}::AUiso:*")
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 18)
        project.refine()
        cov = project.data.get("Covariance", {}).get("data", {})
        print("UISO_STAGE", json.dumps({
            "name": name,
            "phase_id": phase.id,
            "Rwp": project.histogram(0).get_wR(),
            "uiso": [a.uiso for a in atoms],
            "variables": [v for v in cov.get("varyList", []) if "AUiso" in v],
            "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
        }, sort_keys=True), flush=True)
        project.save(out)


if __name__ == "__main__":
    main()
