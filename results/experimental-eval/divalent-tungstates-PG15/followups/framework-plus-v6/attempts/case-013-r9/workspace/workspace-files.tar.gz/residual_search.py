#!/usr/bin/env python3
"""Rank COD candidates against the signed residual of a current PXRD fit."""

from pathlib import Path
import argparse
import gzip
import json
import os
import warnings

import numpy as np
from scipy.optimize import differential_evolution
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator


INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")
CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
LAMBDA1 = 1.540598
LAMBDA2 = 1.544426


def cif_path(cod_id):
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def add_gaussian(profile, grid, position, height, fwhm):
    sigma = fwhm / 2.354820045
    lo = np.searchsorted(grid, position - 4.5 * sigma)
    hi = np.searchsorted(grid, position + 4.5 * sigma)
    if hi <= lo:
        return
    q = (grid[lo:hi] - position) / sigma
    profile[lo:hi] += height * np.exp(-0.5 * q * q)


def profile_from_sticks(grid, two_theta, intensities, lattice_scale, zero, fwhm):
    theta = np.radians(two_theta / 2.0)
    sin_new = np.sin(theta) / lattice_scale
    valid = np.abs(sin_new) < 1.0
    pos1 = np.degrees(2.0 * np.arcsin(sin_new[valid])) + zero
    sin2 = sin_new[valid] * (LAMBDA2 / LAMBDA1)
    valid2 = np.abs(sin2) < 1.0
    pos2 = np.degrees(2.0 * np.arcsin(sin2[valid2])) + zero
    inten = intensities[valid]
    profile = np.zeros_like(grid)
    for p, h in zip(pos1, inten):
        add_gaussian(profile, grid, p, h, fwhm)
    for p, h in zip(pos2, inten[valid2]):
        add_gaussian(profile, grid, p, 0.5 * h, fwhm)
    return profile


def fit_candidate(grid, obs, calc, sticks_x, sticks_y, seed):
    weights = 1.0 / np.maximum(obs, 1.0)
    residual = obs - calc

    def evaluate(params, details=False):
        scale, zero, fwhm = params
        p = profile_from_sticks(grid, sticks_x, sticks_y, scale, zero, fwhm)
        den = float(np.sum(weights * p * p))
        num = float(np.sum(weights * p * residual))
        amplitude = max(num / den, 0.0) if den > 0 else 0.0
        gain = amplitude * max(num, 0.0)
        if details:
            return gain, amplitude, p
        return -gain

    result = differential_evolution(
        evaluate,
        bounds=[(0.965, 1.035), (-0.05, 0.55), (0.08, 0.70)],
        seed=seed,
        popsize=6,
        maxiter=18,
        polish=True,
        workers=1,
        updating="immediate",
        tol=2e-3,
    )
    gain, amplitude, profile = evaluate(result.x, details=True)
    contribution = amplitude * profile
    peak_order = np.argsort(contribution)[::-1]
    examples = []
    for idx in peak_order:
        if contribution[idx] <= 0:
            break
        if any(abs(grid[idx] - row["two_theta_deg"]) < 0.12 for row in examples):
            continue
        examples.append(
            {
                "two_theta_deg": float(grid[idx]),
                "predicted_added_counts": float(contribution[idx]),
                "current_residual_counts": float(residual[idx]),
            }
        )
        if len(examples) == 8:
            break
    return {
        "chi2_gain": gain,
        "amplitude": amplitude,
        "lattice_scale": float(result.x[0]),
        "zero_deg": float(result.x[1]),
        "fwhm_deg": float(result.x[2]),
        "examples": examples,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("fit_csv", type=Path)
    parser.add_argument("--include-carbon", action="store_true")
    parser.add_argument("--limit", type=int, default=30)
    args = parser.parse_args()

    fit = np.loadtxt(args.fit_csv, delimiter=",", skiprows=1)
    grid, obs, calc = fit[:, 0], fit[:, 1], fit[:, 2]
    weights = 1.0 / np.maximum(obs, 1.0)
    chi2 = float(np.sum(weights * (obs - calc) ** 2))
    obs_denom = float(np.sum(weights * obs**2))

    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    allowed = {"O", "Pb", "W"}
    if args.include_carbon:
        allowed |= {"C", "H"}
    rows = []
    for chemical_system, records in index.items():
        elements = set(chemical_system.split("-"))
        if not (elements <= allowed and "O" in elements and elements & {"Pb", "W"}):
            continue
        for formula, cod_id, indexed_sg, r_factor in records:
            path = cif_path(cod_id)
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    structure = Structure.from_file(path, primitive=False)
                pattern = XRDCalculator(wavelength=LAMBDA1).get_pattern(
                    structure, two_theta_range=(float(grid[0]) - 1.0, float(grid[-1]) + 1.0)
                )
                sticks_x = np.asarray(pattern.x, dtype=float)
                sticks_y = np.asarray(pattern.y, dtype=float) / 100.0
                if len(sticks_x) == 0:
                    continue
                fit_result = fit_candidate(grid, obs, calc, sticks_x, sticks_y, int(cod_id[-6:]))
                new_rwp = 100.0 * np.sqrt(max(chi2 - fit_result["chi2_gain"], 0.0) / obs_denom)
                rows.append(
                    {
                        "cod_id": cod_id,
                        "formula": formula,
                        "chemical_system": chemical_system,
                        "indexed_space_group": indexed_sg,
                        "parsed_space_group": structure.get_space_group_info()[1],
                        "cell": [float(v) for v in (*structure.lattice.abc, *structure.lattice.angles)],
                        "r_factor": r_factor,
                        "estimated_rwp_percent": new_rwp,
                        **fit_result,
                    }
                )
            except Exception as exc:
                rows.append({"cod_id": cod_id, "formula": formula, "error": str(exc)})

    valid = [row for row in rows if "chi2_gain" in row]
    valid.sort(key=lambda row: row["chi2_gain"], reverse=True)
    print(json.dumps({"starting_rwp_percent": 100.0 * np.sqrt(chi2 / obs_denom), "results": valid[: args.limit]}, indent=2))


if __name__ == "__main__":
    main()
