#!/usr/bin/env python3
"""Combine replay-stable broadening terms and challenge common intensity terms."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "profile_anchor.gpx"


def bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def report(project, label):
    hist = project.histogram(0)
    rows, raw = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        rows.append({
            "name": phase.name,
            "size": hap["Size"][1][0],
            "strain": hap["Mustrain"][1][0],
            "scale": hap["Scale"][0],
        })
        raw.append(max(0.0, hap["Scale"][0] * phase.data["General"]["Mass"]))
    for row, val in zip(rows, raw):
        row["fraction"] = val / sum(raw)
    cov = project.data.get("Covariance", {}).get("data", {})
    output = {
        "label": label,
        "Rwp": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "instrument": {k: hist.InstrumentParameters[k] for k in ("U", "W", "X", "SH/L", "Polariz.")},
        "sample": {k: hist.SampleParameters[k] for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "phases": rows,
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }
    print("ACCEPTED_STAGE", json.dumps(output, sort_keys=True))
    project.save(WORK / f"accepted_{label}.gpx")


def refine(project, label, cycles=15):
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.refine()
    report(project, label)


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str((WORK / "accepted_profile.gpx").resolve()))
    hist = project.histogram(0)

    scheelite = project.phase("PbWO4_scheelite")
    sh = scheelite.data["Histograms"][hist.name]
    sh["Size"][1][0] = 0.146
    scheelite.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine(project, "scheelite_size")

    intermediate = project.phase("Pb2WO5_trial")
    ih = intermediate.data["Histograms"][hist.name]
    ih["Mustrain"][1][0] = 3700.0
    intermediate.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, "plus_pb2wo5_strain", 18)

    # A complementary size challenge: retain only if it stays interior and
    # survives jointly with strain.
    intermediate.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine(project, "plus_pb2wo5_size", 18)

    hist.InstrumentParameters["SH/L"][2] = True
    bound(project, ":0:SH/L", 0.005, 0.10)
    refine(project, "plus_asymmetry", 18)

    hist.InstrumentParameters["Polariz."][2] = True
    bound(project, ":0:Polariz.", 0.50, 1.0)
    refine(project, "plus_polarization", 18)
    project.save(WORK / "accepted_profile.gpx")


if __name__ == "__main__":
    main()
