#!/usr/bin/env python3
"""Represent the provisional X width with physical phase sizes, then test each.

For GSAS-II CW profiles, isotropic Lorentzian size broadening and X are
algebraically collinear: gamma contains (X + 1.8*lambda/(pi*size))/cos(theta).
The starting fit is therefore re-parameterized exactly with X at the laboratory
upper bound and a common physical size before any relative phase size is tested.
"""

from pathlib import Path
import json
import math

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "trial_pb2wo5.gpx"
ANCHOR = WORK / "profile_anchor.gpx"


def bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def collect(project, label):
    hist = project.histogram(0)
    raw, rows = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw.append(max(0.0, hap["Scale"][0] * phase.data["General"]["Mass"]))
        rows.append({
            "name": phase.name,
            "size_um": hap["Size"][1][0],
            "size_refine": hap["Size"][2][0],
            "strain_ppm": hap["Mustrain"][1][0],
        })
    total = sum(raw)
    for row, amount in zip(rows, raw):
        row["weight_fraction"] = amount / total
    cov = project.data.get("Covariance", {}).get("data", {})
    out = {
        "label": label,
        "Rwp": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "instrument": {key: hist.InstrumentParameters[key] for key in ("U", "W", "X", "SH/L")},
        "shift_um": hist.SampleParameters["Shift"][0],
        "phases": rows,
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }
    print("TRANSFORM_STAGE", json.dumps(out, sort_keys=True))
    return out


def run_refinement(project, cycles=12):
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.refine()


def prepare_anchor():
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(ANCHOR.resolve()))
    hist = project.histogram(0)

    # Replace the provisional constant offset by one physical specimen-height
    # correction, retaining the best approximate position correction as start.
    hist.InstrumentParameters["Zero"][1:] = [0.0, False]
    hist.SampleParameters["Shift"] = [-475.0, True]
    bound(project, ":0:Shift", -800.0, 800.0)

    # Exact profile re-parameterization (to the precision of lambda1).
    old_x = float(hist.InstrumentParameters["X"][1])
    old_size = float(project.phases()[0].data["Histograms"][hist.name]["Size"][1][0])
    new_x = 6.0
    wavelength = float(hist.InstrumentParameters["Lam1"][1])
    coefficient = 1.8 * wavelength / math.pi
    common_size = coefficient / (old_x + coefficient / old_size - new_x)
    if not 0.04 <= common_size <= 1.5:
        raise RuntimeError(f"transformed size outside laboratory range: {common_size}")
    hist.InstrumentParameters["X"][1:] = [new_x, False]
    hist.InstrumentParameters["U"][1:] = [0.0, False]
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["SH/L"][2] = False
    bound(project, ":0:W", 2.0, 40.0)
    bound(project, ":0:X", 0.1, 6.0)
    bound(project, ":0:SH/L", 0.005, 0.10)

    for pidx, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = common_size
        hap["Size"][1][1] = common_size
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        bound(project, f"{pidx}:0:Size;i", 0.04, 1.5)
        bound(project, f"{pidx}:0:Mustrain;i", 0.0, 8000.0)

    print("TRANSFORM_COMMON_SIZE", common_size)
    run_refinement(project, 15)
    collect(project, "anchor")
    project.save(ANCHOR)


def trial_sizes():
    for pidx, phase_name in enumerate([
        "PbWO4_scheelite", "PbO_massicot", "PbO_litharge", "WO3_monoclinic", "Pb2WO5_trial"
    ]):
        output = WORK / f"size_trial_{pidx}.gpx"
        project = G2.G2Project(str(ANCHOR.resolve()), newgpx=str(output.resolve()))
        phase = project.phase(phase_name)
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        run_refinement(project, 12)
        collect(project, f"size_{phase_name}")
        project.save(output)


def main():
    G2.SetPrintLevel("warn")
    prepare_anchor()
    trial_sizes()


if __name__ == "__main__":
    main()
