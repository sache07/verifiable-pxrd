#!/usr/bin/env python3
"""Test one physically allowed profile or texture term for Pb3WO6."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "work" / "cand_pb3wo6_cell.gpx"


def fractions(project):
    hist = project.histogram(0)
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap and hap.get("Use", True) and hap["Scale"][0] > 0:
            raw[phase.name] = hap["Scale"][0] * phase.data["General"]["Mass"]
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["size", "strain", "texture"])
    parser.add_argument("output", type=Path)
    parser.add_argument("--axis", nargs=3, type=int)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    phase = project.phase("Pb3WO6_analogue")
    hap = phase.data["Histograms"][hist.name]
    if args.mode == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:0:Size;i")
    elif args.mode == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0:2] = [1000.0, 1000.0]
        hap["Mustrain"][2] = [True, False, False]
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;i")
    else:
        if args.axis is None:
            parser.error("texture requires --axis h k l")
        hap["Pref.Ori."][0:4] = ["MD", 0.9, True, list(args.axis)]
        project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")

    history = []
    for replay in range(6):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 40)
        project.refine()
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        history.append({
            "pass": replay + 1,
            "Rwp": hist.get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
        })
        if rvals.get("converged") and rvals.get("Max shft/sig", 1e9) < 0.08:
            break
    print("PB3WO6_NUISANCE", json.dumps({
        "mode": args.mode,
        "axis": args.axis,
        "Rwp": hist.get_wR(),
        "fraction": fractions(project).get(phase.name),
        "size_um": hap["Size"][1][0],
        "strain_ppm": hap["Mustrain"][1][0],
        "texture": hap["Pref.Ori."][:4],
        "history": history,
        "frozen": {
            str(key): [str(value) for value in values]
            for key, values in project.data["Controls"]["data"].get("parmFrozen", {}).items()
        },
    }, sort_keys=True), flush=True)
    project.save(args.output)


if __name__ == "__main__":
    main()
