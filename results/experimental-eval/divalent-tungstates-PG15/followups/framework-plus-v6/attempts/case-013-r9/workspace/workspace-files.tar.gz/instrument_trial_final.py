#!/usr/bin/env python3
"""Challenge one common instrumental profile term on the final inventory."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "work" / "inventory_final_converged.gpx"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["U", "SHL"])
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    if args.mode == "U":
        hist.InstrumentParameters["U"][1:] = [4.0, True]
        project.set_Controls("parmMin", 0.0, variable=":0:U")
        project.set_Controls("parmMax", 40.0, variable=":0:U")
    else:
        hist.InstrumentParameters["SH/L"][2] = True
        project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
        project.set_Controls("parmMax", 0.1, variable=":0:SH/L")
    history = []
    for replay in range(6):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 45)
        project.refine()
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        history.append({"pass": replay + 1, "Rwp": hist.get_wR(), "max_shift_over_esd": rvals.get("Max shft/sig")})
        if rvals.get("converged") and rvals.get("Max shft/sig", 1e9) < 0.06:
            break
    print("INSTRUMENT_TRIAL", json.dumps({
        "mode": args.mode,
        "Rwp": hist.get_wR(),
        "U": hist.InstrumentParameters["U"],
        "W": hist.InstrumentParameters["W"],
        "X": hist.InstrumentParameters["X"],
        "SHL": hist.InstrumentParameters["SH/L"],
        "history": history,
        "frozen": {
            str(key): [str(value) for value in values]
            for key, values in project.data["Controls"]["data"].get("parmFrozen", {}).items()
        },
    }, sort_keys=True), flush=True)
    project.save(args.output)


if __name__ == "__main__":
    main()
