#!/usr/bin/env python3
"""Independent coordinate challenges from the clean five-phase profile."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "profile_clean.gpx"


TRIALS = [
    ("scheelite_O", "PbWO4_scheelite", ["O"]),
    ("massicot_Pb", "PbO_massicot", ["Pb1"]),
    ("massicot_all", "PbO_massicot", ["Pb1", "O1"]),
    ("litharge_Pb", "PbO_litharge", ["Pb"]),
    ("wo3_W", "WO3_monoclinic", ["W1", "W2"]),
    ("wo3_all", "WO3_monoclinic", ["W1", "W2", "O1", "O2", "O3", "O4", "O5", "O6"]),
    ("pb2wo5_heavy", "Pb2WO5_trial", ["Pb0", "Pb1", "W2"]),
    ("pb2wo5_all", "Pb2WO5_trial", ["Pb0", "Pb1", "W2", "O3", "O4", "O5", "O6"]),
]


def atom_rows(phase):
    cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
    rows = []
    for idx, atom in enumerate(phase.data["Atoms"]):
        rows.append({
            "index": idx,
            "label": atom[ct-1],
            "type": atom[ct],
            "xyz": [float(v) for v in atom[cx:cx+3]],
            "occupancy": float(atom[cx+3]),
            "flag": atom[cx-1],
            "uiso": float(atom[cia+1]) if atom[cia] == "I" else None,
        })
    return rows


def main():
    G2.SetPrintLevel("warn")
    for tidx, (tag, phase_name, labels) in enumerate(TRIALS):
        output = WORK / f"coordinate_{tag}.gpx"
        cif = WORK / f"coordinate_{tag}.cif"
        project = G2.G2Project(str(BASE.resolve()), newgpx=str(output.resolve()))
        # Ensure no stale coordinate flags are inherited.
        for ph in project.phases():
            ph.set_refinements({"Atoms": {"all": " "}})
        phase = project.phase(phase_name)
        before = atom_rows(phase)
        phase.set_refinements({"Atoms": {label: "X" for label in labels}})
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 18)
        project.refine()
        after = atom_rows(phase)
        cov = project.data.get("Covariance", {}).get("data", {})
        print("COORDINATE_STAGE", json.dumps({
            "trial": tidx,
            "tag": tag,
            "phase": phase_name,
            "labels": labels,
            "Rwp": project.histogram(0).get_wR(),
            "before": before,
            "after": after,
            "coordinate_variables": [v for v in cov.get("varyList", []) if v.startswith(f"{phase.id}::dA")],
            "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
        }, sort_keys=True), flush=True)
        project.save(output)
        phase.export_CIF(str(cif))


if __name__ == "__main__":
    main()
