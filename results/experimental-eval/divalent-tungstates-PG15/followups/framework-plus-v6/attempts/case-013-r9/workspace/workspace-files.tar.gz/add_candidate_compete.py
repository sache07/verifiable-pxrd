#!/usr/bin/env python3
"""Add a candidate to an arbitrary converged inventory and test scale then cell."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


def fractions(project):
    hist = project.histogram(0)
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap and hap.get("Use", True) and hap["Scale"][0] > 0:
            raw[phase.name] = hap["Scale"][0] * phase.data["General"]["Mass"]
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def replay(project, passes):
    hist = project.histogram(0)
    history = []
    for index in range(passes):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 40)
        project.refine()
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        history.append({
            "pass": index + 1,
            "Rwp": hist.get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
        })
        if rvals.get("converged") and rvals.get("Max shft/sig", 1e9) < 0.08:
            break
    return history


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("name")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    existing = sum(
        max(0.0, phase.data["Histograms"][hist.name]["Scale"][0] * phase.data["General"]["Mass"])
        for phase in project.phases()
        if hist.name in phase.data["Histograms"]
        and phase.data["Histograms"][hist.name].get("Use", True)
    )
    phase = project.add_phase(str(args.cif.resolve()), phasename=args.name, histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.015 * existing / phase.data["General"]["Mass"], True]
    common_size = project.phase("PbO_massicot").data["Histograms"][hist.name]["Size"][1][0]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0:2] = [common_size, common_size]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    phase.set_refinements({"Cell": False})
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")

    scale_history = replay(project, 5)
    scale_result = {
        "Rwp": hist.get_wR(),
        "fraction": fractions(project).get(args.name, 0.0),
        "cell": phase.get_cell(),
        "history": scale_history,
    }
    print("COMPETE_SCALE", json.dumps(scale_result, sort_keys=True), flush=True)

    phase.set_refinements({"Cell": True})
    cell_history = replay(project, 7)
    print("COMPETE_CELL", json.dumps({
        "Rwp": hist.get_wR(),
        "fraction": fractions(project).get(args.name, 0.0),
        "fractions": fractions(project),
        "cell": phase.get_cell(),
        "history": cell_history,
        "frozen": {
            str(key): [str(value) for value in values]
            for key, values in project.data["Controls"]["data"].get("parmFrozen", {}).items()
        },
    }, sort_keys=True), flush=True)
    project.save(args.output)


if __name__ == "__main__":
    main()
