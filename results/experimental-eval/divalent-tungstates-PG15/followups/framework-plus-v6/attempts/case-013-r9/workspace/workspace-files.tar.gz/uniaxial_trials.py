#!/usr/bin/env python3
"""Test symmetry-distinct uniaxial microstrain directions independently."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
ANCHOR = WORK / "profile_anchor.gpx"


TRIALS = [
    (1, "PbO_massicot", [1, 0, 0]),
    (1, "PbO_massicot", [0, 1, 0]),
    (1, "PbO_massicot", [0, 0, 1]),
    (2, "PbO_litharge", [1, 0, 0]),
    (2, "PbO_litharge", [0, 0, 1]),
    (4, "Pb2WO5_trial", [1, 0, 0]),
    (4, "Pb2WO5_trial", [0, 1, 0]),
    (4, "Pb2WO5_trial", [0, 0, 1]),
]


def bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main():
    G2.SetPrintLevel("warn")
    for idx, (pidx, name, axis) in enumerate(TRIALS):
        output = WORK / f"uniaxial_trial_{idx}.gpx"
        project = G2.G2Project(str(ANCHOR.resolve()), newgpx=str(output.resolve()))
        hist = project.histogram(0)
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0:3] = [2000.0, 6000.0, 1.0]
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = list(axis)
        bound(project, f"{pidx}:0:Mustrain;i", 0.0, 8000.0)
        bound(project, f"{pidx}:0:Mustrain;a", 0.0, 32000.0)
        project.set_Controls("cycles", 18)
        project.refine()
        raw = []
        for ph in project.phases():
            phap = ph.data["Histograms"][hist.name]
            raw.append(max(0.0, phap["Scale"][0] * ph.data["General"]["Mass"]))
        strain_i, strain_a = hap["Mustrain"][1][0:2]
        result = {
            "name": name,
            "axis": axis,
            "Rwp": hist.get_wR(),
            "W": hist.InstrumentParameters["W"][1],
            "strain_i": strain_i,
            "strain_a": strain_a,
            "axial_ratio": strain_a / strain_i if strain_i else None,
            "weight_fraction": raw[pidx] / sum(raw),
            "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
        }
        print("UNIAXIAL_STAGE", json.dumps(result, sort_keys=True))
        project.save(output)


if __name__ == "__main__":
    main()
