#!/usr/bin/env python3
"""Challenge one isotropic microstrain term at a time from the clean anchor."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
ANCHOR = WORK / "profile_anchor.gpx"


def bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def summarize(project, label):
    hist = project.histogram(0)
    rows, raw = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        rows.append({
            "name": phase.name,
            "size_um": hap["Size"][1][0],
            "strain_ppm": hap["Mustrain"][1][0],
            "strain_refine": hap["Mustrain"][2][0],
        })
        raw.append(max(0.0, hap["Scale"][0] * phase.data["General"]["Mass"]))
    for row, value in zip(rows, raw):
        row["weight_fraction"] = value / sum(raw)
    cov = project.data.get("Covariance", {}).get("data", {})
    out = {
        "label": label,
        "Rwp": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "W": hist.InstrumentParameters["W"][1],
        "phases": rows,
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }
    print("STRAIN_STAGE", json.dumps(out, sort_keys=True))


def main():
    G2.SetPrintLevel("warn")
    for pidx, name in enumerate([
        "PbWO4_scheelite", "PbO_massicot", "PbO_litharge", "WO3_monoclinic", "Pb2WO5_trial"
    ]):
        output = WORK / f"strain_trial_{pidx}.gpx"
        project = G2.G2Project(str(ANCHOR.resolve()), newgpx=str(output.resolve()))
        hist = project.histogram(0)
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        bound(project, f"{pidx}:0:Mustrain;i", 0.0, 8000.0)
        project.set_Controls("cycles", 15)
        project.refine()
        summarize(project, name)
        project.save(output)


if __name__ == "__main__":
    main()
