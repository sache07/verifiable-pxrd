#!/usr/bin/env python3
"""Rebuild the five-phase refinement with a bounded physical peak profile.

This script deliberately introduces phase broadening one phase at a time.  It
also replaces the provisional constant zero correction with the Bragg-Brentano
specimen displacement term used by the pattern generator.
"""

from __future__ import annotations

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "trial_pb2wo5.gpx"
OUT = WORK / "physical_profile.gpx"


def clear_frozen(project):
    controls = project.data["Controls"]["data"]
    controls.setdefault("parmFrozen", {})
    controls["parmFrozen"] = {"FrozenList": []}


def set_bound(project, variable, lo, hi):
    project.set_Controls("parmMin", lo, variable=variable)
    project.set_Controls("parmMax", hi, variable=variable)


def snapshot(project, label):
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    raw = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw.append(max(0.0, float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])))
    total = sum(raw)
    result = {
        "label": label,
        "Rwp": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "instrument": {
            key: hist.InstrumentParameters[key]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "sample": {
            key: hist.SampleParameters[key]
            for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": [],
        "frozen": [str(v) for v in project.get_Controls("parmFrozen")],
    }
    for phase, amount in zip(project.phases(), raw):
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "weight_fraction": amount / total,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "cell": phase.get_cell(),
            }
        )
    print("PROFILE_STAGE", json.dumps(result, default=str, sort_keys=True))
    project.save(WORK / f"profile_{label}.gpx")
    return result


def refine(project, label, cycles=12):
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.refine()
    return snapshot(project, label)


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(OUT.resolve()))
    hist = project.histogram(0)

    # Keep the intensity normalization entirely in the phase scales.
    hist.SampleParameters["Scale"] = [1.0, False]

    # One physical angular correction: Bragg-Brentano specimen displacement.
    hist.InstrumentParameters["Zero"][1:] = [0.0, False]
    hist.SampleParameters["Shift"] = [-475.0, True]
    set_bound(project, ":0:Shift", -800.0, 800.0)

    # Reset the common profile to the laboratory ranges. V, Y and Z are
    # intentionally neutral. Axial divergence is challenged only later.
    for key, value, refine_flag in (
        ("U", 10.0, True),
        ("V", 0.0, False),
        ("W", 10.0, True),
        ("X", 3.0, True),
        ("Y", 0.0, False),
        ("Z", 0.0, False),
        ("SH/L", 0.025, False),
        ("Polariz.", 0.70, False),
    ):
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = refine_flag
    set_bound(project, ":0:U", 0.0, 40.0)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:X", 0.1, 6.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    set_bound(project, ":0:Polariz.", 0.50, 1.0)

    # Neutralize all phase-specific broadening and texture before comparing
    # phase size terms.
    for pidx, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:3] = [10.0, 10.0, 1.0]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:3] = [0.0, 0.0, 1.0]
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
        set_bound(project, f"{pidx}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{pidx}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{pidx}:0:MD", 0.20, 5.0)

    refine(project, "common_only", 15)

    # Introduce size in descending approximate abundance so the common
    # profile is not asked to mimic the dominant phase's sample broadening.
    order = ["PbWO4_scheelite", "Pb2WO5_trial", "WO3_monoclinic", "PbO_massicot", "PbO_litharge"]
    for i, name in enumerate(order, start=1):
        phase = project.phase(name)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.40, "refine": True}}
        )
        refine(project, f"size_{i}_{name}", 15)

    project.save(OUT)


if __name__ == "__main__":
    main()
