#!/usr/bin/env python3
"""Compare polarization, asymmetry and surface roughness on the clean profile."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "accepted_plus_pb2wo5_strain.gpx"
POL = WORK / "common_polarization.gpx"


def bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def summarize(project, label):
    hist = project.histogram(0)
    raw = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw.append(max(0.0, hap["Scale"][0] * phase.data["General"]["Mass"]))
    result = {
        "label": label,
        "Rwp": hist.get_wR(),
        "polarization": hist.InstrumentParameters["Polariz."],
        "SHL": hist.InstrumentParameters["SH/L"],
        "roughness_A": hist.SampleParameters["SurfRoughA"],
        "roughness_B": hist.SampleParameters["SurfRoughB"],
        "fractions": {p.name: v / sum(raw) for p, v in zip(project.phases(), raw)},
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }
    print("COMMON_STAGE", json.dumps(result, sort_keys=True))


def refine(project, label, output, cycles=18):
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.refine()
    summarize(project, label)
    project.save(output)


def main():
    G2.SetPrintLevel("warn")

    project = G2.G2Project(str(BASE.resolve()), newgpx=str(POL.resolve()))
    hist = project.histogram(0)
    hist.InstrumentParameters["SH/L"][2] = False
    hist.InstrumentParameters["Polariz."][2] = True
    bound(project, ":0:Polariz.", 0.50, 1.0)
    refine(project, "polarization", POL)

    asym = G2.G2Project(str(POL.resolve()), newgpx=str((WORK / "common_asymmetry.gpx").resolve()))
    ah = asym.histogram(0)
    ah.InstrumentParameters["SH/L"][2] = True
    bound(asym, ":0:SH/L", 0.005, 0.10)
    refine(asym, "polarization_asymmetry", WORK / "common_asymmetry.gpx")

    rough = G2.G2Project(str(POL.resolve()), newgpx=str((WORK / "common_roughness.gpx").resolve()))
    rh = rough.histogram(0)
    rh.SampleParameters["SurfRoughA"] = [0.20, True]
    rh.SampleParameters["SurfRoughB"] = [0.10, True]
    bound(rough, ":0:SurfRoughA", 0.05, 0.60)
    bound(rough, ":0:SurfRoughB", 0.02, 0.50)
    refine(rough, "polarization_roughness", WORK / "common_roughness.gpx", 22)


if __name__ == "__main__":
    main()
