#!/usr/bin/env python3
"""Replace origin-misparsed litharge with a stoichiometric origin-2 model."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "structure_clamped.gpx"
CIF = WORK / "PbO_litharge_P4nmm_origin2.cif"
OUT = WORK / "litharge_corrected.gpx"


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(OUT.resolve()))
    hist = project.histogram(0)
    old = project.phase("PbO_litharge")
    old_hap = old.data["Histograms"][hist.name]
    amount = old_hap["Scale"][0] * old.data["General"]["Mass"]
    old_hap["Scale"] = [0.0, False]
    old_hap["Use"] = False
    old.set_refinements({"Cell": False})

    phase = project.add_phase(str(CIF.resolve()), phasename="PbO_litharge", histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [amount / phase.data["General"]["Mass"], True]
    common_size = project.phase("PbO_massicot").data["Histograms"][hist.name]["Size"][1][0]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0:2] = [common_size, common_size]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    phase.set_refinements({"Cell": True})
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 25)
    project.refine()

    raw, rows = [], []
    for ph in project.phases():
        phap = ph.data["Histograms"].get(hist.name)
        used = bool(phap and phap.get("Use", True) and phap["Scale"][0] != 0)
        val = max(0.0, phap["Scale"][0] * ph.data["General"]["Mass"]) if used else 0.0
        raw.append(val)
        rows.append({"name": ph.name, "used": used, "mass": ph.data["General"]["Mass"], "scale": phap["Scale"][0] if phap else None})
    for row, val in zip(rows, raw):
        if row["used"]:
            row["fraction"] = val / sum(raw)
    print("LITHARGE_CORRECTED", json.dumps({
        "Rwp": hist.get_wR(),
        "cell": phase.get_cell(),
        "atoms": {a.label: {"xyz": list(a.coordinates), "mult": a.mult} for a in phase.atoms()},
        "rows": rows,
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }, sort_keys=True))
    project.save(OUT)
    phase.export_CIF(str(WORK / "litharge_corrected.cif"))


if __name__ == "__main__":
    main()
