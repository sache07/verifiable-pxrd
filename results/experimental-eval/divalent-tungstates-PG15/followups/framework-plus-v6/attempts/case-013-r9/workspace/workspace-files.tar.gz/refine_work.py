#!/usr/bin/env python3
"""Build and stage a GSAS-II refinement for the Pb-W-O powder pattern."""

from pathlib import Path
import json
import math

import numpy as np

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "inputs" / "pattern.csv"
WORK = ROOT / "work"
WORK.mkdir(exist_ok=True)

COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = [
    ("PbWO4_scheelite", "9009811"),
    ("PbO_massicot", "2310433"),
    ("PbO_litharge", "9012700"),
    ("WO3_monoclinic", "1528915"),
]


def prepare_files():
    arr = np.loadtxt(INPUT, delimiter=",", skiprows=1)
    x, y = arr.T
    sig = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(WORK / "pattern.xye", np.column_stack([x, y, sig]), fmt="%.8f %.8f %.8f")

    inst = """#GSAS-II Cu Kalpha Bragg-Brentano starting profile
Type:PXC;Bank:1
Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5
Zero:0.20;Polariz.:0.70;Azimuth:0.0
U:0.0;V:0.0;W:10.0;X:3.0;Y:0.0;Z:0.0;SH/L:0.025
"""
    (WORK / "instrument.instprm").write_text(inst)
    return x, y


def background_points(x, y):
    # Robust low-percentile anchors in narrow bins. These initialize only a
    # smooth polynomial; all anchors are removed from the refinement model.
    edges = np.linspace(float(x[0]), float(x[-1]), 25)
    pts = []
    for lo, hi in zip(edges[:-1], edges[1:]):
        mask = (x >= lo) & (x < hi)
        if np.any(mask):
            pts.append(((lo + hi) / 2.0, float(np.percentile(y[mask], 4.0))))
    return pts


def phase_fraction_data(project):
    hist = project.histogram(0)
    rows = []
    raw = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        value = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        raw.append(max(value, 0.0))
    total = sum(raw)
    for phase, value in zip(project.phases(), raw):
        hap = phase.data["Histograms"][hist.name]
        rows.append(
            {
                "phase": phase.name,
                "mass": float(phase.data["General"]["Mass"]),
                "scale": float(hap["Scale"][0]),
                "weight_fraction": value / total if total else float("nan"),
                "cell": phase.get_cell(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    return rows


def summary(project, label):
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    out = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {
            key: inst[key] for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.") if key in inst
        },
        "sample": {key: sample[key] for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB") if key in sample},
        "background": hist.Background,
        "phases": phase_fraction_data(project),
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }
    print("SUMMARY", json.dumps(out, default=str, sort_keys=True))
    return out


def set_neutral_phase_profiles(project):
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][1][1] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]
        if "HStrain" in hap:
            hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
            hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]


def refine(project, label, cycles=8):
    project.set_Controls("cycles", cycles)
    project.refine()
    summary(project, label)
    project.save(WORK / f"{label}.gpx")


def main():
    G2.SetPrintLevel("warn")
    x, y = prepare_files()
    project = G2.G2Project(newgpx=str(WORK / "baseline.gpx"))
    for name, cod_id in PHASES:
        project.add_phase(str(cod_path(cod_id)), phasename=name, fmthint="CIF")
    hist = project.add_powder_histogram(
        str(WORK / "pattern.xye"),
        str(WORK / "instrument.instprm"),
        phases="all",
        fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    set_neutral_phase_profiles(project)

    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [700.0] + [0.0] * 7,
                "FixedPoints": background_points(x, y),
                "fit fixed points": True,
                "refine": True,
            },
        }
    )
    # Fixed-point anchors are only an initialization device.
    hist.Background[1].pop("FixedPoints", None)
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    summary(project, "initial")
    refine(project, "stage1_bg_scale_zero", 10)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, "stage2_cells", 10)

    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(project, "stage3_profile", 12)

    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine(project, "stage4_asymmetry", 10)

    project.save(WORK / "inventory4_baseline.gpx")
    print("GSAS-II revision", GSASIIpath.GetVersionNumber())


if __name__ == "__main__":
    main()
