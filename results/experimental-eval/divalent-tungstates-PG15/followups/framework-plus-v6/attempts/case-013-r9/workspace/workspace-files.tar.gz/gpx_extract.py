#!/usr/bin/env python3
"""Extract a full-grid profile and compact diagnostics from a GSAS-II project."""

from pathlib import Path
import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--csv", type=Path)
    args = parser.parse_args()

    project = G2.G2Project(str(args.project.resolve()))
    hist = project.histogram(0)
    x, obs, weights, calc, background, difference = [
        np.asarray(v, dtype=float) for v in hist.data["data"][1][:6]
    ]
    use = (x >= hist.Limits("lower")) & (x <= hist.Limits("upper"))
    direct_weights = 1.0 / np.maximum(obs, 1.0)
    rwp = 100.0 * np.sqrt(
        np.sum(direct_weights[use] * (obs[use] - calc[use]) ** 2)
        / np.sum(direct_weights[use] * obs[use] ** 2)
    )

    score = np.abs(obs - calc) / np.sqrt(np.maximum(obs, 1.0))
    order = np.argsort(score)[::-1]
    selected = []
    for idx in order:
        if any(abs(x[idx] - row["two_theta_deg"]) < 0.18 for row in selected):
            continue
        selected.append(
            {
                "two_theta_deg": float(x[idx]),
                "observed": float(obs[idx]),
                "calculated": float(calc[idx]),
                "difference": float(obs[idx] - calc[idx]),
                "sigma_residual": float(score[idx]),
            }
        )
        if len(selected) == 30:
            break

    report = {
        "histogram": hist.name,
        "limits": [hist.Limits("lower"), hist.Limits("upper")],
        "bins": len(x),
        "rwp_direct_percent": rwp,
        "rwp_gsas_percent": hist.get_wR(),
        "background_min_max": [float(np.min(background)), float(np.max(background))],
        "calculated_min_max": [float(np.min(calc)), float(np.max(calc))],
        "largest_standardized_residuals": selected,
    }
    print(json.dumps(report, indent=2))
    if args.csv:
        data = np.column_stack([x, obs, calc, obs - calc, background, weights])
        np.savetxt(
            args.csv,
            data,
            delimiter=",",
            header="two_theta_deg,observed,calculated,difference,background,gsas_weight",
            comments="",
            fmt="%.10g",
        )


if __name__ == "__main__":
    main()
