#!/usr/bin/env python3
"""Fit the two weak lead-oxide watch-list candidates in direct competition."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "drop_pb2wo5_strain.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = [
    ("Pb3O4_watch", COD / "9/01/21/9012124.cif"),
    ("Pb2O3_watch", COD / "2/31/10/2311012.cif"),
]


def active_weight_fractions(project):
    hist = project.histogram(0)
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap and hap.get("Use", True):
            raw[phase.name] = max(0.0, hap["Scale"][0] * phase.data["General"]["Mass"])
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()} if total else raw


def report(project, label):
    hist = project.histogram(0)
    payload = {
        "label": label,
        "Rwp": hist.get_wR(),
        "fractions": active_weight_fractions(project),
        "candidates": {},
        "frozen": {
            str(k): [str(v) for v in vals]
            for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()
        },
    }
    for name, _ in CANDIDATES:
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        payload["candidates"][name] = {
            "scale": hap["Scale"],
            "cell": phase.get_cell(),
        }
    print("COMPETITION_STAGE", json.dumps(payload, sort_keys=True), flush=True)


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def main():
    G2.SetPrintLevel("warn")
    output = WORK / "watchlist_competition.gpx"
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(output.resolve()))
    hist = project.histogram(0)
    existing = sum(
        max(0.0, phase.data["Histograms"][hist.name]["Scale"][0] * phase.data["General"]["Mass"])
        for phase in project.phases()
        if hist.name in phase.data["Histograms"]
        and phase.data["Histograms"][hist.name].get("Use", True)
    )
    common_size = project.phase("PbO_massicot").data["Histograms"][hist.name]["Size"][1][0]

    for name, cif in CANDIDATES:
        phase = project.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [0.015 * existing / phase.data["General"]["Mass"], True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0:2] = [common_size, common_size]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0:2] = [0.0, 0.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")

    clear_frozen(project)
    project.set_Controls("cycles", 25)
    project.refine()
    report(project, "joint_scale")

    for name, _ in CANDIDATES:
        project.phase(name).set_refinements({"Cell": True})
    clear_frozen(project)
    project.set_Controls("cycles", 30)
    project.refine()
    report(project, "joint_scale_cell")
    project.save(output)


if __name__ == "__main__":
    main()
