#!/usr/bin/env python3
"""Test roughness with polarization fixed at its independently refined value."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "common_polarization.gpx"
OUT = WORK / "roughness_fixed_pol.gpx"


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(OUT.resolve()))
    hist = project.histogram(0)
    hist.InstrumentParameters["Polariz."][2] = False
    hist.SampleParameters["SurfRoughA"] = [0.20, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 22)
    project.refine()
    raw = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw.append(max(0.0, hap["Scale"][0] * phase.data["General"]["Mass"]))
    print("ROUGHNESS_FIXED_POL", json.dumps({
        "Rwp": hist.get_wR(),
        "polarization": hist.InstrumentParameters["Polariz."],
        "A": hist.SampleParameters["SurfRoughA"],
        "B": hist.SampleParameters["SurfRoughB"],
        "fractions": {p.name: v/sum(raw) for p,v in zip(project.phases(),raw)},
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }, sort_keys=True))
    project.save(OUT)


if __name__ == "__main__":
    main()
