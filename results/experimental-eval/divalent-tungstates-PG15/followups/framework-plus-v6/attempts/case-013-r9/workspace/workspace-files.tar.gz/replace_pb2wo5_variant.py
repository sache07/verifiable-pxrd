#!/usr/bin/env python3
"""Compare one Pb2WO5 analogue prototype as a full replacement phase."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "work" / "base_replayed.gpx"


def fractions(project):
    hist = project.histogram(0)
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap and hap.get("Use", True) and hap["Scale"][0] > 0:
            raw[phase.name] = hap["Scale"][0] * phase.data["General"]["Mass"]
    total = sum(raw.values())
    return {name: value / total for name, value in raw.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("cif", type=Path)
    parser.add_argument("name")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    old = project.phase("Pb2WO5_trial")
    old_hap = old.data["Histograms"][hist.name]
    amount = old_hap["Scale"][0] * old.data["General"]["Mass"]
    old_hap["Scale"] = [0.0, False]
    old_hap["Use"] = False
    old.set_refinements({"Cell": False})

    phase = project.add_phase(str(args.cif.resolve()), phasename=args.name, histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [amount / phase.data["General"]["Mass"], True]
    common_size = project.phase("PbO_massicot").data["Histograms"][hist.name]["Size"][1][0]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0:2] = [common_size, common_size]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0:4] = ["MD", old_hap["Pref.Ori."][1], True, [0, 1, 0]]
    phase.set_refinements({"Cell": True})
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")

    history = []
    for replay in range(7):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 40)
        project.refine()
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        history.append({
            "pass": replay + 1,
            "Rwp": hist.get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
        })
        if rvals.get("converged") and rvals.get("Max shft/sig", 1e9) < 0.08:
            break

    result = {
        "candidate": args.name,
        "Rwp": hist.get_wR(),
        "cell": phase.get_cell(),
        "scale": hap["Scale"],
        "texture": hap["Pref.Ori."][:4],
        "fractions": fractions(project),
        "history": history,
        "frozen": {
            str(key): [str(value) for value in values]
            for key, values in project.data["Controls"]["data"].get("parmFrozen", {}).items()
        },
    }
    print("PB2WO5_REPLACEMENT", json.dumps(result, sort_keys=True), flush=True)
    project.save(args.output)


if __name__ == "__main__":
    main()
