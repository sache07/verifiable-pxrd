#!/usr/bin/env python3
"""Continue the joint watch-list refinement and report convergence diagnostics."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "work" / "watchlist_competition.gpx"
OUTPUT = ROOT / "work" / "watchlist_converged.gpx"


def fractions(project):
    hist = project.histogram(0)
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap and hap.get("Use", True):
            raw[phase.name] = max(0.0, hap["Scale"][0] * phase.data["General"]["Mass"])
    total = sum(raw.values())
    return {key: value / total for key, value in raw.items()}


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE.resolve()), newgpx=str(OUTPUT.resolve()))
    for iteration in range(4):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 35)
        project.refine()
        cov = project.data["Covariance"]["data"]
        vary = cov.get("varyList", [])
        shifts = cov.get("Lastshft", [])
        sigmas = cov.get("sig", [])
        ratios = [abs(shift / sigma) for shift, sigma in zip(shifts, sigmas) if sigma]
        print("CONVERGENCE", json.dumps({
            "iteration": iteration + 1,
            "Rwp": project.histogram(0).get_wR(),
            "fractions": fractions(project),
            "rvals": cov.get("Rvals", {}),
            "max_last_shift_over_esd": max(ratios, default=0.0),
            "max_variable": vary[ratios.index(max(ratios))] if ratios and len(vary) == len(ratios) else None,
        }, default=str, sort_keys=True), flush=True)
        if cov.get("Rvals", {}).get("converged") and max(ratios, default=0.0) < 0.1:
            break
    project.save(OUTPUT)


if __name__ == "__main__":
    main()
