#!/usr/bin/env python3
"""Prune the unsupported Pb2WO5 size term and reconverge accepted terms."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "combined_texture.gpx"
OUT = WORK / "profile_clean.gpx"


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(OUT.resolve()))
    hist = project.histogram(0)
    intermediate = project.phase("Pb2WO5_trial")
    hap = intermediate.data["Histograms"][hist.name]
    hap["Size"][1][0] = 0.11186460943829919
    hap["Size"][2] = [False, False, False]
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 22)
    project.refine()
    raw = []
    rows = []
    for phase in project.phases():
        phap = phase.data["Histograms"][hist.name]
        raw.append(max(0.0, phap["Scale"][0] * phase.data["General"]["Mass"]))
        rows.append({
            "name": phase.name,
            "size": phap["Size"][1][0],
            "strain": phap["Mustrain"][1][0],
            "MD": phap["Pref.Ori."][1],
            "axis": phap["Pref.Ori."][3],
        })
    for row, val in zip(rows, raw):
        row["fraction"] = val / sum(raw)
    print("PRUNED_PROFILE", json.dumps({
        "Rwp": hist.get_wR(),
        "rows": rows,
        "polarization": hist.InstrumentParameters["Polariz."],
        "W": hist.InstrumentParameters["W"],
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }, sort_keys=True))
    project.save(OUT)


if __name__ == "__main__":
    main()
