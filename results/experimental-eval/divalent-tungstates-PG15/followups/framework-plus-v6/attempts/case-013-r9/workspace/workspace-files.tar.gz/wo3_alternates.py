#!/usr/bin/env python3
"""Replace the provisional monoclinic WO3 record with physical exact alternates."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
BASE = WORK / "profile_clean.gpx"


ALTERNATES = [
    ("2311041", Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif")),
    ("1563541", Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/56/35/1563541.cif")),
]


def main():
    G2.SetPrintLevel("warn")
    for cod, cif in ALTERNATES:
        out = WORK / f"wo3_alternate_{cod}.gpx"
        project = G2.G2Project(str(BASE.resolve()), newgpx=str(out.resolve()))
        hist = project.histogram(0)
        old = project.phase("WO3_monoclinic")
        old_hap = old.data["Histograms"][hist.name]
        amount = old_hap["Scale"][0] * old.data["General"]["Mass"]
        old_hap["Scale"] = [0.0, False]
        old_hap["Use"] = False
        old.set_refinements({"Cell": False})
        alt = project.add_phase(str(cif), phasename=f"WO3_{cod}", histograms=[hist], fmthint="CIF")
        hap = alt.data["Histograms"][hist.name]
        hap["Scale"] = [amount / alt.data["General"]["Mass"], True]
        common_size = project.phase("PbO_massicot").data["Histograms"][hist.name]["Size"][1][0]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0:2] = [common_size, common_size]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0:2] = [0.0, 0.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
        alt.set_refinements({"Cell": True})
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 22)
        project.refine()
        raw = []
        for phase in project.phases():
            phap = phase.data["Histograms"].get(hist.name)
            raw.append(0.0 if not phap or not phap.get("Use", True) else max(0.0, phap["Scale"][0] * phase.data["General"]["Mass"]))
        print("WO3_ALTERNATE", json.dumps({
            "cod": cod,
            "Rwp": hist.get_wR(),
            "cell": alt.get_cell(),
            "scale": hap["Scale"][0],
            "weight_fraction": raw[-1] / sum(raw),
            "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
        }, sort_keys=True), flush=True)
        project.save(out)
        alt.export_CIF(str(WORK / f"wo3_alternate_{cod}.cif"))


if __name__ == "__main__":
    main()
