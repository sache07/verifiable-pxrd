#!/usr/bin/env python3
"""Source-conditioned heavy-atom coordinate trial for Pb3WO6."""

from pathlib import Path
import json
import math

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "work" / "cand_pb3wo6_cell.gpx"
OUTPUT = ROOT / "work" / "pb3wo6_heavy_trial.gpx"
LABELS = ["Pb0", "Pb1", "Pb2", "Pb3", "Pb4", "W5"]


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(BASE.resolve()), newgpx=str(OUTPUT.resolve()))
    for item in project.phases():
        item.set_refinements({"Atoms": {"all": " "}})
    phase = project.phase("Pb3WO6_analogue")
    before = {atom.label: list(atom.coordinates) for atom in phase.atoms()}
    cell = phase.get_cell()
    limits = [0.05 / cell["length_a"], 0.05 / cell["length_b"], 0.05 / cell["length_c"]]
    for index, atom in enumerate(phase.atoms()):
        if atom.label not in LABELS:
            continue
        atom.refinement_flags = "X"
        for suffix, limit in zip(("x", "y", "z"), limits):
            variable = f"{phase.id}::dA{suffix}:{index}"
            project.set_Controls("parmMin", -limit, variable=variable)
            project.set_Controls("parmMax", limit, variable=variable)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 35)
    project.refine()
    after = {atom.label: list(atom.coordinates) for atom in phase.atoms()}
    shifts = {}
    for label in LABELS:
        delta = [after[label][i] - before[label][i] for i in range(3)]
        delta = [value - round(value) for value in delta]
        cart = [delta[0] * cell["length_a"], delta[1] * cell["length_b"], delta[2] * cell["length_c"]]
        shifts[label] = {"fractional": delta, "cartesian_component_A": cart, "norm_A": math.sqrt(sum(v * v for v in cart))}
    cov = project.data["Covariance"]["data"]
    print("PB3WO6_COORD", json.dumps({
        "Rwp": project.histogram(0).get_wR(),
        "before": before,
        "after": after,
        "shifts": shifts,
        "coordinate_variables": {
            name: float(value)
            for name, value in zip(cov.get("varyList", []), cov.get("variables", []))
            if name.startswith(f"{phase.id}::dA")
        },
        "frozen": {
            str(key): [str(value) for value in values]
            for key, values in project.data["Controls"]["data"].get("parmFrozen", {}).items()
        },
        "rvals": cov.get("Rvals", {}),
    }, default=str, sort_keys=True), flush=True)
    project.save(OUTPUT)


if __name__ == "__main__":
    main()
