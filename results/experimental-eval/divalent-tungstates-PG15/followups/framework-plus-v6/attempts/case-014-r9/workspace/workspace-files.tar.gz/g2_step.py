#!/usr/bin/env python3
"""Apply a controlled refinement step to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def parse_indices(value: str) -> list[int]:
    if not value:
        return []
    return [int(v) for v in value.split(",")]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--size", default="", help="comma-separated phase indices")
    parser.add_argument("--strain", default="", help="comma-separated phase indices")
    parser.add_argument("--size-start", type=float, default=0.3)
    parser.add_argument("--strain-start", type=float, default=1000.0)
    parser.add_argument("--profile", nargs="*", default=None)
    parser.add_argument("--keep-existing", action="store_true", help="retain HAP flags on phases not selected here")
    parser.add_argument("--cycles", type=int, default=16)
    parser.add_argument("--repeats", type=int, default=1)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(args.input), filename=str(args.output))
    hist = project.histogram(0)
    phases = project.phases()
    size_indices = parse_indices(args.size)
    strain_indices = parse_indices(args.strain)
    project.set_Frozen()

    if args.profile is not None:
        all_profile = ["U", "V", "W", "X", "Y", "Z", "SH/L"]
        hist.clear_refinements({"Instrument Parameters": all_profile})
        if args.profile:
            hist.set_refinements({"Instrument Parameters": args.profile})
        if "SH/L" in args.profile:
            project.set_Controls("parmMin", 0.002, variable=f":{hist.id}:SH/L")
            project.set_Controls("parmMax", 0.2, variable=f":{hist.id}:SH/L")
        if "Polariz." in args.profile:
            project.set_Controls("parmMin", 0.3, variable=f":{hist.id}:Polariz.")
            project.set_Controls("parmMax", 1.1, variable=f":{hist.id}:Polariz.")

    for i, phase in enumerate(phases):
        if not args.keep_existing:
            phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        else:
            if i in size_indices:
                phase.clear_HAP_refinements({"Size": True})
            if i in strain_indices:
                phase.clear_HAP_refinements({"Mustrain": True})
        if i in size_indices:
            phase.setSampleProfile(hist, "size", "isotropic", args.size_start)
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": args.size_start, "refine": True}})
            project.set_Controls("parmMin", 0.02, variable=f"{phase.id}:{hist.id}:Size;i")
            project.set_Controls("parmMax", 10.0, variable=f"{phase.id}:{hist.id}:Size;i")
        if i in strain_indices:
            phase.setSampleProfile(hist, "microstrain", "isotropic", args.strain_start)
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
            project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")
            project.set_Controls("parmMax", 20000.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")

    project.set_Controls("cycles", args.cycles)
    project.save()
    for repeat in range(args.repeats):
        project.refine()
        project.save()
        print("completed refinement pass", repeat + 1)
        if repeat + 1 < args.repeats:
            project = G2sc.G2Project(str(args.output))

    # Reopen before diagnostics to ensure that the saved project replays.
    project = G2sc.G2Project(str(args.output))
    hist = project.histogram(0)
    x, obs, weight, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    w = 1.0 / np.maximum(obs, 1.0)
    rwp = 100.0 * np.sqrt(np.sum(w * (obs - calc) ** 2) / np.sum(w * obs**2))
    masses = np.array(
        [phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0] for phase in project.phases()],
        float,
    )
    fractions = masses / masses.sum()
    diag = {
        "rwp_recomputed_percent": float(rwp),
        "g2_wR_percent": hist.get_wR(),
        "instrument": hist.data["Instrument Parameters"],
        "sample": hist.data["Sample Parameters"],
        "frozen": project.get_Frozen(),
        "vary_list": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
        "phases": [],
    }
    for phase, fraction in zip(project.phases(), fractions):
        hap = phase.data["Histograms"][hist.name]
        diag["phases"].append(
            {
                "name": phase.name,
                "cell": phase.data["General"]["Cell"][1:],
                "scale": hap["Scale"],
                "weight_fraction": float(fraction),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    stem = args.output.with_suffix("")
    np.savetxt(
        stem.with_name(stem.name + "_fit.csv"),
        np.column_stack((x, obs, calc, obs - calc, bkg)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )
    stem.with_name(stem.name + "_diagnostics.json").write_text(json.dumps(diag, indent=2, default=str) + "\n")
    print(json.dumps({"rwp": rwp, "fractions": fractions.tolist(), "frozen": diag["frozen"], "vary": diag["vary_list"]}, indent=2))


if __name__ == "__main__":
    main()
