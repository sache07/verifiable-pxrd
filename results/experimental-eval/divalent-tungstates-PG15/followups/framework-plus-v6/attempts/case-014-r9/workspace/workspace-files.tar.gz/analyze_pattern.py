#!/usr/bin/env python3
"""Small read-only diagnostics for the supplied powder pattern."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.signal import find_peaks, peak_widths


data = np.genfromtxt(Path("inputs/pattern.csv"), delimiter=",", names=True)
x = data["two_theta_deg"]
y = data["intensity"]
step = float(np.median(np.diff(x)))

# A wide running lower quantile follows the fluorescence/background envelope
# while leaving Bragg peaks in the residual.
baseline0 = percentile_filter(y, percentile=18, size=301, mode="nearest")
baseline = gaussian_filter1d(baseline0, 45)
smooth = gaussian_filter1d(y, 1.2)
residual = smooth - baseline

peaks, props = find_peaks(residual, prominence=80.0, distance=4)
width_samples = peak_widths(residual, peaks, rel_height=0.5)[0]
rows = sorted(
    zip(peaks, props["prominences"], width_samples),
    key=lambda row: row[1],
    reverse=True,
)

print(
    f"points={len(x)} range={x[0]:.6f}..{x[-1]:.6f} step={step:.7f} "
    f"intensity={y.min():.1f}..{y.max():.1f}"
)
print("rank  two_theta    intensity  net_height  prominence  fwhm_deg")
for rank, (idx, prominence, width) in enumerate(rows[:120], start=1):
    print(
        f"{rank:4d}  {x[idx]:10.5f}  {y[idx]:9.1f}  {residual[idx]:10.1f}  "
        f"{prominence:10.1f}  {width * step:8.4f}"
    )

fig, axes = plt.subplots(2, 1, figsize=(15, 8), sharex=True)
axes[0].plot(x, y, color="black", lw=0.55)
axes[0].plot(x, baseline, color="tab:orange", lw=0.8)
axes[0].set_ylabel("counts")
axes[1].plot(x, residual, color="tab:blue", lw=0.55)
axes[1].scatter(x[peaks], residual[peaks], s=7, color="tab:red")
axes[1].set_ylabel("counts above envelope")
axes[1].set_xlabel(r"$2\theta$ (degrees)")
fig.tight_layout()
fig.savefig("pattern_diagnostic.png", dpi=150)
