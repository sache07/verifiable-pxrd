#!/usr/bin/env python3
"""Build and stage a compact GSAS-II Rietveld model for inventory testing.

Run with the GSAS-II Python interpreter.  This is intentionally conservative:
atomic parameters, texture, roughness and phase-specific broadening remain off.
"""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


def instrument_text() -> str:
    return (
        "#GSAS-II instrument parameter file: Cu Kalpha Bragg-Brentano\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    x, y, w, calc, bkg, diff = [np.asarray(v) for v in hist.data["data"][1][:6]]
    use = (x >= hist.Limits("lower")) & (x <= hist.Limits("upper"))
    weights = 1.0 / np.maximum(y, 1.0)
    rwp = 100.0 * np.sqrt(np.sum(weights[use] * (y[use] - calc[use]) ** 2) / np.sum(weights[use] * y[use] ** 2))
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": copy.deepcopy(phase.data["General"]["Cell"][1:]),
                "mass": phase.data["General"]["Mass"],
                "scale": copy.deepcopy(hap["Scale"]),
                "size": copy.deepcopy(hap["Size"]),
                "mustrain": copy.deepcopy(hap["Mustrain"]),
                "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
            }
        )
    return {
        "stage": label,
        "rwp_recomputed_percent": float(rwp),
        "g2_wR_percent": hist.get_wR(),
        "background": copy.deepcopy(hist.data["Background"]),
        "instrument": copy.deepcopy(hist.data["Instrument Parameters"]),
        "sample": copy.deepcopy(hist.data["Sample Parameters"]),
        "phases": phases,
        "vary_list": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
        "variables": np.asarray(project.data.get("Covariance", {}).get("data", {}).get("variables", [])).tolist(),
        "sig": np.asarray(project.data.get("Covariance", {}).get("data", {}).get("sig", [])).tolist(),
        "frozen": project.get_Frozen(),
    }


def refine(project: G2sc.G2Project, label: str, log: list[dict], cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    log.append(snapshot(project, label))
    print(label, "Rwp", log[-1]["rwp_recomputed_percent"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+", help="NAME=CIF")
    parser.add_argument("--angular", choices=("shift", "zero"), default="shift")
    parser.add_argument("--background", type=int, default=8)
    parser.add_argument("--profile", nargs="*", default=("W", "X"))
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    stem = args.output.with_suffix("")
    raw = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
    x = np.asarray(raw["two_theta_deg"], float)
    y = np.asarray(raw["intensity"], float)
    xye = stem.with_suffix(".xye")
    np.savetxt(xye, np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.8f %.8f %.8f")
    inst = stem.with_suffix(".instprm")
    inst.write_text(instrument_text())

    project = G2sc.G2Project(newgpx=str(args.output))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.Limits("lower", float(x[0]))
    hist.Limits("upper", float(x[-1]))
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    phases = []
    for spec in args.phases:
        name, path = spec.split("=", 1)
        phases.append(project.add_phase(str(Path(path).resolve()), phasename=name, histograms=[hist], fmthint="CIF"))

    # Guard the exploratory refinements against nonphysical least-squares
    # excursions. Limits are intentionally wider than the generator's modest
    # reference mismatch and are audited if reached.
    project.save()
    project.index_ids()
    project.set_Controls("parmMin", -1000.0, variable=f":{hist.id}:Shift")
    project.set_Controls("parmMax", 1000.0, variable=f":{hist.id}:Shift")
    for key, low, high in (("U", 0.0, 100.0), ("W", 0.0, 100.0), ("X", 0.0, 20.0)):
        project.set_Controls("parmMin", low, variable=f":{hist.id}:{key}")
        project.set_Controls("parmMax", high, variable=f":{hist.id}:{key}")
    for phase in phases:
        project.set_Controls("parmMin", 1.0e-8, variable=f"{phase.id}:{hist.id}:Scale")
        project.set_Controls("parmMax", 1000.0, variable=f"{phase.id}:{hist.id}:Scale")
        avec = G2lat.cell2A(phase.data["General"]["Cell"][1:7])
        diag_scale = max(abs(float(v)) for v in avec[:3])
        for i, value in enumerate(avec):
            value = float(value)
            delta = max(0.12 * abs(value), 0.015 * diag_scale)
            project.set_Controls("parmMin", value - delta, variable=f"{phase.id}::A{i}")
            project.set_Controls("parmMax", value + delta, variable=f"{phase.id}::A{i}")

    coeffs = [float(np.percentile(y, 20))] + [0.0] * (args.background - 1)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background,
                "coeffs": coeffs,
                "refine": True,
            }
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
        phase.setSampleProfile(hist, "size", "isotropic", 1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0)
        hap = phase.data["Histograms"][hist.name]
        hap["Extinction"] = [0.0, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    project.save()
    log: list[dict] = [snapshot(project, "initial")]
    refine(project, "background_scales", log)

    if args.angular == "shift":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    else:
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, args.angular, log)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells", log)

    if args.profile:
        hist.set_refinements({"Instrument Parameters": list(args.profile)})
        refine(project, "common_profile", log, cycles=12)

    project.save()
    hist = project.histogram(0)
    xx, obs, weight, calc, bkg, diff = [np.asarray(v) for v in hist.data["data"][1][:6]]
    np.savetxt(
        stem.with_name(stem.name + "_fit.csv"),
        np.column_stack((xx, obs, calc, obs - calc, bkg)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )
    stem.with_name(stem.name + "_diagnostics.json").write_text(json.dumps(log, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
