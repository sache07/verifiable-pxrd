#!/usr/bin/env python3
"""Plot observed, calculated and difference profiles from a GSAS-II project."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    project = G2sc.G2Project(str(args.project))
    hist = project.histogram(0)
    x, obs, weight, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    fig, axes = plt.subplots(4, 1, figsize=(16, 12), constrained_layout=True)
    windows = [(10, 100), (10, 35), (35, 65), (65, 100)]
    for ax, (low, high) in zip(axes, windows):
        mask = (x >= low) & (x <= high)
        offset = -0.18 * np.max(obs[mask])
        ax.plot(x[mask], obs[mask], color="black", lw=0.55, label="observed")
        ax.plot(x[mask], calc[mask], color="crimson", lw=0.65, label="calculated")
        ax.plot(x[mask], bkg[mask], color="darkorange", lw=0.5, label="background")
        ax.plot(x[mask], obs[mask] - calc[mask] + offset, color="royalblue", lw=0.5, label="difference (offset)")
        ax.axhline(offset, color="0.7", lw=0.4)
        ax.set_xlim(low, high)
        ax.set_ylabel("counts")
    axes[0].legend(ncol=4, loc="upper right")
    axes[-1].set_xlabel(r"$2\theta$ (degrees)")
    fig.suptitle(f"{args.project.name}; GSAS-II Rwp = {hist.get_wR():.3f}%")
    fig.savefig(args.output, dpi=180)


if __name__ == "__main__":
    main()
