#!/usr/bin/env python3
"""Apply bounded atomic-coordinate and common-Uiso refinement steps."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def parse_specs(values: list[str]) -> dict[int, list[str]]:
    result: dict[int, list[str]] = {}
    for value in values:
        phase, selectors = value.split(":", 1)
        result[int(phase)] = [v.strip() for v in selectors.split(",") if v.strip()]
    return result


def selected(atom, selectors: list[str]) -> bool:
    return "all" in selectors or atom.label in selectors or atom.element in selectors


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--coords", action="append", default=[], metavar="PHASE:LABEL_OR_ELEMENT,...")
    parser.add_argument("--hold-coordinate", action="append", default=[], metavar="PHASE:ATOM:AXIS")
    parser.add_argument("--uiso", default="", help="comma-separated phase indices with one common Uiso per phase")
    parser.add_argument("--uiso-start", type=float, default=0.008)
    parser.add_argument("--coord-limit", type=float, default=0.02, help="absolute fractional-coordinate shift bound")
    parser.add_argument("--freeze-roughness", action="store_true")
    parser.add_argument("--cycles", type=int, default=16)
    parser.add_argument("--repeats", type=int, default=1)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(args.input), filename=str(args.output))
    phases = project.phases()
    coords = parse_specs(args.coords)
    uiso = {int(v) for v in args.uiso.split(",") if v.strip()}
    project.set_Frozen()
    if args.freeze_roughness:
        hist = project.histogram(0)
        hist.SampleParameters["SurfRoughA"][1] = False
        hist.SampleParameters["SurfRoughB"][1] = False

    # Atomic flags are rebuilt explicitly so that every branch has a clear model.
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = " "

    for pidx, selectors in coords.items():
        phase = phases[pidx]
        for aidx, atom in enumerate(phase.atoms()):
            if not selected(atom, selectors):
                continue
            atom.refinement_flags = "X"
            for axis_index, axis in enumerate("xyz"):
                variable = f"{phase.id}::dA{axis}:{aidx}"
                # GSAS-II names coordinate shifts dA*, but its out-of-bounds
                # check compares against the absolute A* coordinate.
                center = atom.coordinates[axis_index]
                project.set_Controls("parmMin", center - args.coord_limit, variable=variable)
                project.set_Controls("parmMax", center + args.coord_limit, variable=variable)

    for specification in args.hold_coordinate:
        pidx_text, atom_label, axis = specification.split(":")
        phase = phases[int(pidx_text)]
        if axis not in "xyz":
            raise ValueError(f"unknown coordinate axis {axis}")
        aidx = next(i for i, atom in enumerate(phase.atoms()) if atom.label == atom_label)
        project.add_HoldConstr([f"{phase.id}::dA{axis}:{aidx}"])

    for pidx in sorted(uiso):
        phase = phases[pidx]
        variables = []
        for aidx, atom in enumerate(phase.atoms()):
            atom.uiso = args.uiso_start
            atom.refinement_flags = atom.refinement_flags.strip() + "U"
            variables.append(f"{phase.id}::AUiso:{aidx}")
        if len(variables) > 1:
            project.add_EquivConstr(variables)
        project.set_Controls("parmMin", 0.001, variable=f"{phase.id}::AUiso:*")
        project.set_Controls("parmMax", 0.04, variable=f"{phase.id}::AUiso:*")

    project.set_Controls("cycles", args.cycles)
    project.save()
    for repeat in range(args.repeats):
        project.refine()
        project.save()
        print("completed refinement pass", repeat + 1)
        if repeat + 1 < args.repeats:
            project = G2sc.G2Project(str(args.output))

    project = G2sc.G2Project(str(args.output))
    hist = project.histogram(0)
    x, obs, weight, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    weights = 1.0 / np.maximum(obs, 1.0)
    rwp = 100.0 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2))
    masses = np.array([
        phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ])
    fractions = masses / masses.sum()
    diagnostics = {
        "rwp_percent": float(rwp),
        "fractions": fractions.tolist(),
        "frozen": project.get_Frozen(),
        "vary_list": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
        "phases": [],
    }
    for phase in project.phases():
        atoms = []
        for atom in phase.atoms():
            try:
                uiso_value = atom.uiso
            except G2sc.G2ScriptException:
                uiso_value = None
            atoms.append({
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(atom.coordinates),
                "uiso": uiso_value,
                "flags": atom.refinement_flags,
            })
        diagnostics["phases"].append({
            "name": phase.name,
            "cell": phase.data["General"]["Cell"][1:],
            "atoms": atoms,
        })
    stem = args.output.with_suffix("")
    stem.with_name(stem.name + "_diagnostics.json").write_text(json.dumps(diagnostics, indent=2) + "\n")
    np.savetxt(
        stem.with_name(stem.name + "_fit.csv"),
        np.column_stack((x, obs, calc, obs - calc, bkg)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )
    print(json.dumps({"rwp": rwp, "fractions": fractions.tolist(), "frozen": diagnostics["frozen"],
                      "vary": diagnostics["vary_list"]}, indent=2))


if __name__ == "__main__":
    main()
