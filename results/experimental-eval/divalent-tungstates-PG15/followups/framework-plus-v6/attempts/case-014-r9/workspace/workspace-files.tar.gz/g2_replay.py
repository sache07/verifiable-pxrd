#!/usr/bin/env python3
"""Save, reopen and replay a GSAS-II project without changing its model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def summarize(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    x, obs, weight, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    weights = 1.0 / np.maximum(obs, 1.0)
    rwp = 100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2))
    masses = np.array([p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
                       for p in project.phases()])
    return {
        "rwp": float(rwp),
        "fractions": (masses / masses.sum()).tolist(),
        "frozen": project.get_Frozen(),
        "phases": [{
            "name": p.name,
            "cell": p.data["General"]["Cell"][1:],
            "scale": p.data["Histograms"][hist.name]["Scale"],
            "size": p.data["Histograms"][hist.name]["Size"],
            "mustrain": p.data["Histograms"][hist.name]["Mustrain"],
            "preferred_orientation": p.data["Histograms"][hist.name]["Pref.Ori."],
        } for p in project.phases()],
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "vary": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=16)
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()
    project = G2sc.G2Project(str(args.input), filename=str(args.output))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    project.save()
    log = [summarize(project)]
    for _ in range(args.repeats):
        project.refine()
        project.save()
        project = G2sc.G2Project(str(args.output))
        log.append(summarize(project))
    args.output.with_name(args.output.stem + "_diagnostics.json").write_text(json.dumps(log, indent=2, default=str) + "\n")
    print(json.dumps(log[-1], indent=2, default=str))


if __name__ == "__main__":
    main()
