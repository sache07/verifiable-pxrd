#!/usr/bin/env python3
"""Copy a GSAS-II project while fixing selected profile/sample parameters."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def parse_assignments(values: list[str]) -> dict[str, float]:
    assignments: dict[str, float] = {}
    for item in values:
        key, separator, value = item.partition("=")
        if not separator or not key:
            raise ValueError(f"expected NAME=VALUE, got {item!r}")
        assignments[key] = float(value)
    return assignments


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--instrument", action="append", default=[], metavar="NAME=VALUE")
    parser.add_argument("--sample", action="append", default=[], metavar="NAME=VALUE")
    parser.add_argument("--neutral-strain", default="", help="comma-separated phase indices")
    parser.add_argument("--neutral-size", default="", help="comma-separated phase indices")
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(args.input), filename=str(args.output))
    project.set_Frozen()
    histogram = project.histogram(0)

    instrument = histogram.data["Instrument Parameters"][0]
    for key, value in parse_assignments(args.instrument).items():
        if key not in instrument:
            raise KeyError(f"unknown instrument parameter {key!r}")
        instrument[key][1] = value
        instrument[key][2] = False

    sample = histogram.data["Sample Parameters"]
    for key, value in parse_assignments(args.sample).items():
        if key not in sample:
            raise KeyError(f"unknown sample parameter {key!r}")
        sample[key][0] = value
        sample[key][1] = False

    for text_index in filter(None, args.neutral_strain.split(",")):
        phase = project.phases()[int(text_index)]
        phase.clear_HAP_refinements({"Mustrain": True})
        phase.setSampleProfile(histogram, "microstrain", "isotropic", 0.0)
    for text_index in filter(None, args.neutral_size.split(",")):
        phase = project.phases()[int(text_index)]
        phase.clear_HAP_refinements({"Size": True})
        phase.setSampleProfile(histogram, "size", "isotropic", 1.0)

    project.save()


if __name__ == "__main__":
    main()
