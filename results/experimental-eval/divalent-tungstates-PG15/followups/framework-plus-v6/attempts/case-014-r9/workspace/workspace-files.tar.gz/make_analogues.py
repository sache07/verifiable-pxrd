#!/usr/bin/env python3
"""Create explicitly documented cross-chemistry prototype substitutions."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = Path("candidates")

SPECS = {
    "sr3wo6_from_2310471": ("2310471", {"U": "W"}),
    "sr3wo6_from_2001752": ("2001752", {"U": "W"}),
    "sr3wo6_from_1534803": ("1534803", {"Ba": "Sr"}),
    "sr3wo6_from_1563081": ("1563081", {"Ca": "Sr"}),
    "sr3wo6_from_2310470": ("2310470", {"Ca": "Sr", "U": "W"}),
    "sr3wo6_from_1562666": ("1562666", {"Ca": "Sr", "Os": "W"}),
    "sr3wo6_from_1563543": ("1563543", {"Sc": "Sr"}),
    "sr2wo5_from_1529756": ("1529756", {"Ba": "Sr", "Re": "W"}),
    "srw2o7_from_1542062": ("1542062", {"Cr": "W"}),
    "srw2o7_from_1537702": ("1537702", {"Ba": "Sr", "V": "W"}),
}


def source_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def screen(structure: Structure) -> dict:
    distances = np.asarray(structure.distance_matrix, float)
    np.fill_diagonal(distances, np.inf)
    all_min = float(np.min(distances))
    oxygen = [i for i, site in enumerate(structure) if site.species_string == "O"]
    oo_min = float(np.min(distances[np.ix_(oxygen, oxygen)])) if len(oxygen) > 1 else None
    coordination = {}
    for element in ("Sr", "W"):
        values = []
        for i, site in enumerate(structure):
            if site.species_string != element:
                continue
            od = [float(distances[i, j]) for j in oxygen]
            values.append(sorted(od)[:12])
        coordination[element] = values
    return {"minimum_contact_A": all_min, "minimum_O_O_A": oo_min, "nearest_O_A": coordination}


def main() -> None:
    OUT.mkdir(exist_ok=True)
    records = []
    for name, (cod_id, substitutions) in SPECS.items():
        parent = source_path(cod_id)
        structure = Structure.from_file(parent)
        parent_formula = structure.composition.reduced_formula
        structure.replace_species(substitutions)
        analyzer = SpacegroupAnalyzer(structure, symprec=0.02)
        # Put monoclinic parents into the conventional international setting;
        # this leaves the framework unchanged and avoids ambiguous P21/n vs
        # P21/c operation labels during GSAS-II import.
        structure = analyzer.get_conventional_standard_structure(international_monoclinic=True)
        analyzer = SpacegroupAnalyzer(structure, symprec=0.02)
        path = OUT / f"{name}.cif"
        CifWriter(structure, symprec=0.01, refine_struct=False).write_file(path)
        records.append(
            {
                "name": name,
                "path": str(path),
                "parent_cod_id": cod_id,
                "parent_path": str(parent),
                "parent_formula": parent_formula,
                "target_formula": structure.composition.reduced_formula,
                "substitutions": substitutions,
                "space_group": {
                    "symbol": analyzer.get_space_group_symbol(),
                    "number": analyzer.get_space_group_number(),
                },
                "cell": list(structure.lattice.abc) + list(structure.lattice.angles),
                "volume_A3": structure.volume,
                "density_g_cm3": float(structure.density),
                "physical_screen": screen(structure),
            }
        )
    (OUT / "analogue_provenance.json").write_text(json.dumps(records, indent=2) + "\n")
    for record in records:
        print(record["name"], record["target_formula"], record["space_group"], record["cell"], record["physical_screen"]["minimum_contact_A"], record["physical_screen"]["minimum_O_O_A"])


if __name__ == "__main__":
    main()
