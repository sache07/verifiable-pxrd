#!/usr/bin/env python3
"""Create the exact final GSAS-II project and all project-derived exports."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials" / "physical_nostrain_replay.gpx"
FINAL = ROOT / "final.gpx"

PHASE_METADATA = [
    {
        "name": "SrWO4 (scheelite)",
        "formula": "SrWO4",
        "cif_path": "phase_srwo4.cif",
        "identification_confidence": "high",
    },
    {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif_path": "phase_wo3.cif",
        "identification_confidence": "high",
    },
    {
        "name": "Sr3WO6-like phase",
        "formula": "Sr3WO6",
        "cif_path": "phase_sr3wo6.cif",
        "identification_confidence": "moderate",
    },
    {
        "name": "Sr3W2O9-like phase",
        "formula": "Sr3W2O9",
        "cif_path": "phase_sr3w2o9.cif",
        "identification_confidence": "moderate",
    },
]


def profile(project: G2sc.G2Project) -> tuple[np.ndarray, ...]:
    data = project.histogram(0).data["data"][1]
    return tuple(np.asarray(value, float) for value in data[:6])


def fractions(project: G2sc.G2Project) -> np.ndarray:
    histogram = project.histogram(0)
    masses = np.asarray(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][histogram.name]["Scale"][0]
            for phase in project.phases()
        ],
        float,
    )
    if np.any(masses <= 0):
        raise ValueError(f"non-positive phase mass-scale products: {masses}")
    return masses / masses.sum()


def main() -> None:
    if len(PHASE_METADATA) != 4:
        raise AssertionError("phase metadata is out of sync")

    # Save through GSAS-II so final.gpx is a complete project, not a detached
    # filesystem copy. Clear any historical bound-hit bookkeeping.
    project = G2sc.G2Project(str(SOURCE), filename=str(FINAL))
    project.set_Frozen()
    project.save()

    # All submitted products are generated from this reopened final project.
    project = G2sc.G2Project(str(FINAL))
    histogram = project.histogram(0)
    phases = project.phases()
    if len(phases) != len(PHASE_METADATA):
        raise ValueError(f"expected four phases, found {len(phases)}")
    if project.get_Frozen():
        raise ValueError(f"final project contains frozen variables: {project.get_Frozen()}")
    if any(phase.data["Histograms"][histogram.name].get("LeBail", False) for phase in phases):
        raise ValueError("final project contains a Le Bail phase")

    x, observed, weight, calculated, background, stored_difference = profile(project)
    input_pattern = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    if not np.allclose(x, input_pattern["two_theta_deg"], rtol=0.0, atol=5e-8):
        raise ValueError("final project grid does not match inputs/pattern.csv")
    if not np.array_equal(observed, input_pattern["intensity"]):
        raise ValueError("final project observations do not match inputs/pattern.csv")

    difference = observed - calculated
    if not np.allclose(stored_difference, difference, rtol=0.0, atol=1e-8):
        raise ValueError("GSAS-II stored difference profile is inconsistent")
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    phase_fractions = fractions(project)
    phase_rows = []
    for phase, metadata, fraction in zip(phases, PHASE_METADATA, phase_fractions):
        output = ROOT / metadata["cif_path"]
        phase.export_CIF(str(output))
        cell = phase.data["General"]["Cell"][1:]
        phase_rows.append(
            {
                **metadata,
                "project_phase_name": phase.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "weight_fraction": float(fraction),
                "unit_cell": {
                    "a_angstrom": float(cell[0]),
                    "b_angstrom": float(cell[1]),
                    "c_angstrom": float(cell[2]),
                    "alpha_deg": float(cell[3]),
                    "beta_deg": float(cell[4]),
                    "gamma_deg": float(cell[5]),
                    "volume_angstrom3": float(cell[6]),
                },
            }
        )

    active = weight > 0
    n_points = int(active.sum())
    n_variables = len(project.data.get("Covariance", {}).get("data", {}).get("varyList", []))
    dof = n_points - n_variables
    chi_square = float(np.sum(weight[active] * difference[active] ** 2))
    denominator = float(np.sum(weight[active] * observed[active] ** 2))
    rwp = 100.0 * np.sqrt(chi_square / denominator)
    rp = 100.0 * np.sum(np.abs(difference[active])) / np.sum(np.abs(observed[active]))
    reduced_chi_square = chi_square / dof
    rexp = 100.0 * np.sqrt(dof / denominator)
    fit_statistics = {
        "rwp_percent": float(rwp),
        "rp_percent": float(rp),
        "rexp_percent": float(rexp),
        "weighted_chi_square": chi_square,
        "reduced_chi_square": float(reduced_chi_square),
        "goodness_of_fit": float(np.sqrt(reduced_chi_square)),
        "n_points": n_points,
        "n_refined_variables": n_variables,
        "two_theta_range_deg": [float(x[active][0]), float(x[active][-1])],
    }
    result = {
        "phases": phase_rows,
        "fit_statistics": fit_statistics,
        "project_path": "final.gpx",
        "fit_path": "fit.csv",
        "fraction_basis": "normalized over the modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    # A second reopen verifies that the exports were taken from persistent data.
    replay = G2sc.G2Project(str(FINAL))
    replay_profile = profile(replay)
    if any(not np.array_equal(before, after) for before, after in zip((x, observed, weight, calculated), replay_profile[:4])):
        raise ValueError("final.gpx changed on reopen")
    if not np.allclose(phase_fractions, fractions(replay), rtol=0.0, atol=1e-12):
        raise ValueError("phase fractions changed on reopen")

    print(json.dumps({"fractions": phase_fractions.tolist(), "fit_statistics": fit_statistics}, indent=2))


if __name__ == "__main__":
    main()
