#!/usr/bin/env python3
"""Tabulate residual support at the refined SrO reflection positions."""

from __future__ import annotations

import argparse

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def arrays(project: G2sc.G2Project) -> tuple[np.ndarray, ...]:
    return tuple(np.asarray(v, float) for v in project.histogram(0).data["data"][1][:6])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline")
    parser.add_argument("with_sro")
    args = parser.parse_args()

    baseline = G2sc.G2Project(args.baseline)
    augmented = G2sc.G2Project(args.with_sro)
    x, obs, _, calc0, _, _ = arrays(baseline)
    x1, obs1, _, calc1, _, _ = arrays(augmented)
    if not np.array_equal(x, x1) or not np.array_equal(obs, obs1):
        raise ValueError("profiles use different observed grids")

    histogram = augmented.histogram(0)
    reflections = histogram.data["Reflection Lists"]
    sro = reflections["SrO"]["RefList"]
    others = []
    for phase_name, data in reflections.items():
        if phase_name == "SrO":
            continue
        for row in data["RefList"]:
            others.append((float(row[5]), phase_name, tuple(int(v) for v in row[:3])))

    print("hkl,pos_deg,baseline_center_residual,five_phase_center_residual,local_delta_chisq,nearest_other_deg,nearest_phase")
    for row in sro:
        hkl = tuple(int(v) for v in row[:3])
        position = float(row[5])
        center = int(np.argmin(np.abs(x - position)))
        window = np.abs(x - position) <= 0.22
        weights = 1.0 / np.maximum(obs[window], 1.0)
        delta = np.sum(weights * ((obs[window] - calc0[window]) ** 2 - (obs[window] - calc1[window]) ** 2))
        nearest = min(others, key=lambda item: abs(item[0] - position))
        print(
            f"{hkl},{position:.5f},{obs[center]-calc0[center]:.2f},"
            f"{obs[center]-calc1[center]:.2f},{delta:.3f},{nearest[0]-position:+.4f},"
            f"{nearest[1]} {nearest[2]}"
        )


if __name__ == "__main__":
    main()
