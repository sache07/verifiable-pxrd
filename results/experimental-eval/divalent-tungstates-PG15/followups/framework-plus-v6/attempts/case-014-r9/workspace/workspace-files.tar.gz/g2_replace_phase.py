#!/usr/bin/env python3
"""Replace one phase model while preserving the converged common nuisance model."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


def summarize(project: G2sc.G2Project) -> dict:
    histogram = project.histogram(0)
    x, observed, weight, calculated = [np.asarray(v, float) for v in histogram.data["data"][1][:4]]
    poisson_weight = 1.0 / np.maximum(observed, 1.0)
    rwp = 100.0 * np.sqrt(
        np.sum(poisson_weight * (observed - calculated) ** 2)
        / np.sum(poisson_weight * observed**2)
    )
    mass_scales = np.asarray(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][histogram.name]["Scale"][0]
            for phase in project.phases()
        ]
    )
    return {
        "rwp_percent": float(rwp),
        "fractions": (mass_scales / mass_scales.sum()).tolist(),
        "frozen": project.get_Frozen(),
        "phases": [
            {
                "name": phase.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cell": phase.data["General"]["Cell"][1:],
                "scale": phase.data["Histograms"][histogram.name]["Scale"],
                "size": phase.data["Histograms"][histogram.name]["Size"],
                "mustrain": phase.data["Histograms"][histogram.name]["Mustrain"],
            }
            for phase in project.phases()
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("old_name")
    parser.add_argument("replacement", help="NAME=CIF")
    parser.add_argument("--cycles", type=int, default=20)
    parser.add_argument("--repeats", type=int, default=5)
    args = parser.parse_args()

    new_name, cif = args.replacement.split("=", 1)
    project = G2sc.G2Project(str(args.input), filename=str(args.output))
    project.set_Frozen()
    histogram = project.histogram(0)
    old_phase = project.phase(args.old_name)
    initial_names = [phase.name for phase in project.phases()]
    old_index = initial_names.index(args.old_name)
    old_hap = copy.deepcopy(old_phase.data["Histograms"][histogram.name])
    old_mass_scale = old_phase.data["General"]["Mass"] * old_hap["Scale"][0]

    replacement = project.add_phase(
        str(Path(cif).resolve()), phasename=new_name, histograms=[histogram], fmthint="CIF"
    )
    # Preserve only symmetry-independent HAP terms. HStrain and related arrays
    # have different lengths when a replacement changes Laue class.
    new_hap = replacement.data["Histograms"][histogram.name]
    for key in (
        "Scale",
        "Size",
        "Mustrain",
        "Pref.Ori.",
        "Extinction",
        "Babinet",
        "Fix FXU",
        "Use",
        "LeBail",
        "newLeBail",
    ):
        if key in old_hap and key in new_hap:
            new_hap[key] = copy.deepcopy(old_hap[key])
    new_hap["Scale"][0] = (
        old_mass_scale / replacement.data["General"]["Mass"]
    )
    replacement.set_refinements({"Cell": True})

    # Remove the rejected record and put the replacement in the same logical
    # position so phase-indexed controls remain interpretable.
    phase_tree = project.data["Phases"]
    phase_tree.pop(args.old_name)
    ordered_names = [name for name in initial_names if name != args.old_name]
    ordered_names.insert(old_index, new_name)
    reordered = {"data": phase_tree.get("data")}
    for name in ordered_names:
        reordered[name] = phase_tree[name]
    project.data["Phases"] = reordered
    project.names[-1] = ["Phases", *ordered_names]
    histogram.data["Reflection Lists"].pop(args.old_name, None)
    project.index_ids()

    for phase in project.phases():
        project.set_Controls("parmMin", 1.0e-8, variable=f"{phase.id}:{histogram.id}:Scale")
        project.set_Controls("parmMax", 1000.0, variable=f"{phase.id}:{histogram.id}:Scale")
        avec = G2lat.cell2A(phase.data["General"]["Cell"][1:7])
        for index, value in enumerate(avec):
            delta = max(0.08 * abs(float(value)), 0.002)
            project.set_Controls("parmMin", float(value) - delta, variable=f"{phase.id}::A{index}")
            project.set_Controls("parmMax", float(value) + delta, variable=f"{phase.id}::A{index}")

    project.set_Controls("cycles", args.cycles)
    project.save()
    log = [summarize(project)]
    for _ in range(args.repeats):
        project.refine()
        project.save()
        project = G2sc.G2Project(str(args.output))
        log.append(summarize(project))
    args.output.with_name(args.output.stem + "_diagnostics.json").write_text(
        json.dumps(log, indent=2, default=str) + "\n"
    )
    print(json.dumps(log[-1], indent=2, default=str))


if __name__ == "__main__":
    main()
