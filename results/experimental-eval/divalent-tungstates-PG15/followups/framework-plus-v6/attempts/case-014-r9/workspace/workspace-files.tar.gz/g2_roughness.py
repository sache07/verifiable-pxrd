#!/usr/bin/env python3
"""Test a bounded two-parameter Suortti surface-roughness correction."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--a", type=float, default=0.3)
    parser.add_argument("--b", type=float, default=0.1)
    parser.add_argument("--fix-a", action="store_true", help="fix A and refine only B")
    parser.add_argument("--cycles", type=int, default=16)
    parser.add_argument("--repeats", type=int, default=1)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.input), filename=str(args.output))
    hist = project.histogram(0)
    project.set_Frozen()
    hist.SampleParameters["SurfRoughA"] = [args.a, not args.fix_a]
    hist.SampleParameters["SurfRoughB"] = [args.b, True]
    project.set_Controls("parmMin", 0.01, variable=f":{hist.id}:SurfRoughA")
    project.set_Controls("parmMax", 1.0, variable=f":{hist.id}:SurfRoughA")
    project.set_Controls("parmMin", 0.001, variable=f":{hist.id}:SurfRoughB")
    project.set_Controls("parmMax", 1.0, variable=f":{hist.id}:SurfRoughB")
    project.set_Controls("cycles", args.cycles)
    project.save()
    for repeat in range(args.repeats):
        project.refine()
        project.save()
        if repeat + 1 < args.repeats:
            project = G2sc.G2Project(str(args.output))

    project = G2sc.G2Project(str(args.output))
    hist = project.histogram(0)
    x, obs, weight, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    weights = 1.0 / np.maximum(obs, 1.0)
    rwp = 100.0 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2))
    masses = np.array([p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
                       for p in project.phases()])
    result = {
        "rwp": float(rwp),
        "fractions": (masses / masses.sum()).tolist(),
        "sample": hist.SampleParameters,
        "frozen": project.get_Frozen(),
        "vary": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
    }
    args.output.with_name(args.output.stem + "_diagnostics.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
