#!/usr/bin/env python3
"""Rank visible COD candidates against a current positive difference profile."""

from __future__ import annotations

import gzip
import argparse
import json
import math
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure


INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")
ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
ALLOWED = {"Sr", "W", "O", "C"}


def path_for(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def shifted_profile(x: np.ndarray, px: np.ndarray, py: np.ndarray, cell_scale: float, shift_um: float) -> np.ndarray:
    out = np.zeros_like(x)
    for wavelength, ratio in ((1.540598, 1.0), (1.544426, 0.5)):
        # Pymatgen positions were computed at Cu Kalpha1. Convert back to d,
        # apply isotropic cell scaling, then calculate each wavelength.
        d0 = 1.540598 / (2.0 * np.sin(np.radians(px / 2.0)))
        valid = wavelength < 2.0 * d0 * cell_scale
        pos = np.degrees(2.0 * np.arcsin(wavelength / (2.0 * d0[valid] * cell_scale)))
        pos -= (0.09 / (math.pi * 200.0)) * (4.0 * shift_um * np.cos(np.radians(pos / 2.0)))
        inten = py[valid] * ratio
        for center, height in zip(pos, inten):
            if center < x[0] - 1 or center > x[-1] + 1:
                continue
            fwhm = 0.20 + 0.0017 * center
            sigma = fwhm / 2.35482
            lo = np.searchsorted(x, center - 4.0 * sigma)
            hi = np.searchsorted(x, center + 4.0 * sigma)
            out[lo:hi] += height * np.exp(-0.5 * ((x[lo:hi] - center) / sigma) ** 2)
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("fit_csv", nargs="?", default="trials/srwo4_fit.csv")
    parser.add_argument("--shift-um", type=float, default=-625.0)
    parser.add_argument("--limit", type=int, default=30)
    args = parser.parse_args()
    fit = np.genfromtxt(args.fit_csv, delimiter=",", names=True)
    x = fit["two_theta_deg"]
    obs = fit["observed"]
    residual = fit["difference"]
    weights = 1.0 / np.maximum(obs, 1.0)
    with gzip.open(INDEX, "rt") as handle:
        database = json.load(handle)

    rows = []
    for system, records in database.items():
        elems = set(system.split("-"))
        if not elems <= ALLOWED or not ({"Sr", "W"} & elems):
            continue
        for formula, cod_id, index_sg, quality in records:
            cod_id = str(cod_id)
            path = path_for(cod_id)
            try:
                structure = Structure.from_file(path)
                pattern = XRDCalculator(wavelength=1.540598, symprec=0.01).get_pattern(
                    structure, two_theta_range=(9.5, 100.5)
                )
            except Exception as exc:
                rows.append({"id": cod_id, "formula": formula, "error": str(exc)})
                continue
            best = None
            for cell_scale in np.linspace(0.975, 1.025, 101):
                profile = shifted_profile(x, np.asarray(pattern.x), np.asarray(pattern.y), cell_scale, args.shift_um)
                denom = float(np.sum(weights * profile * profile))
                if denom <= 0:
                    continue
                scale = max(0.0, float(np.sum(weights * profile * residual) / denom))
                improvement = float(
                    np.sum(weights * residual * residual)
                    - np.sum(weights * (residual - scale * profile) ** 2)
                )
                candidate = (improvement, cell_scale, scale)
                if best is None or candidate > best:
                    best = candidate
            if best is not None:
                rows.append(
                    {
                        "id": cod_id,
                        "formula": formula,
                        "system": system,
                        "index_sg": index_sg,
                        "quality": quality,
                        "improvement": best[0],
                        "cell_scale": best[1],
                        "profile_scale": best[2],
                        "path": str(path),
                    }
                )

    rows.sort(key=lambda row: row.get("improvement", -np.inf), reverse=True)
    print(json.dumps(rows[: args.limit], indent=2))


if __name__ == "__main__":
    main()
