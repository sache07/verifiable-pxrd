#!/usr/bin/env python3
"""Test one bounded March-Dollase texture axis from an existing project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--axis", nargs=3, type=int, required=True)
    parser.add_argument("--cycles", type=int, default=16)
    parser.add_argument("--repeats", type=int, default=1)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(args.input), filename=str(args.output))
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Frozen()
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    phase = phases[args.phase]
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][3] = list(args.axis)
    phase.set_HAP_refinements({"Pref.Ori.": True}, histograms=[hist])
    project.set_Controls("parmMin", 0.5, variable=f"{phase.id}:{hist.id}:MD")
    project.set_Controls("parmMax", 2.0, variable=f"{phase.id}:{hist.id}:MD")
    project.set_Controls("cycles", args.cycles)
    project.save()
    for repeat in range(args.repeats):
        project.refine()
        project.save()
        if repeat + 1 < args.repeats:
            project = G2sc.G2Project(str(args.output))

    project = G2sc.G2Project(str(args.output))
    hist = project.histogram(0)
    x, obs, weight, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    weights = 1.0 / np.maximum(obs, 1.0)
    rwp = 100.0 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2))
    masses = np.array([
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ])
    fractions = masses / masses.sum()
    result = {
        "rwp": float(rwp),
        "fractions": fractions.tolist(),
        "frozen": project.get_Frozen(),
        "preferred_orientation": [p.data["Histograms"][hist.name]["Pref.Ori."] for p in project.phases()],
        "vary": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
    }
    args.output.with_name(args.output.stem + "_diagnostics.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
