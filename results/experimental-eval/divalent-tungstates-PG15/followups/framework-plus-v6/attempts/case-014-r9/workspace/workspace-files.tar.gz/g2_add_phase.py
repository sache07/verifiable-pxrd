#!/usr/bin/env python3
"""Re-challenge a saved inventory by adding one bounded candidate phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


def diagnostics(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    x, obs, weight, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    weights = 1.0 / np.maximum(obs, 1.0)
    rwp = 100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2))
    masses = np.array([p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
                       for p in project.phases()])
    return {
        "rwp": float(rwp),
        "fractions": (masses / masses.sum()).tolist(),
        "frozen": project.get_Frozen(),
        "phases": [{
            "name": p.name,
            "cell": p.data["General"]["Cell"][1:],
            "scale": p.data["Histograms"][hist.name]["Scale"],
        } for p in project.phases()],
        "vary": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", help="NAME=CIF")
    parser.add_argument("--scale", type=float, default=0.1)
    parser.add_argument("--cycles", type=int, default=16)
    args = parser.parse_args()

    name, cif = args.phase.split("=", 1)
    project = G2sc.G2Project(str(args.input), filename=str(args.output))
    hist = project.histogram(0)
    project.set_Frozen()
    phase = project.add_phase(str(Path(cif).resolve()), phasename=name, histograms=[hist], fmthint="CIF")
    phase.setSampleProfile(hist, "size", "isotropic", 1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0)
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [args.scale, True]
    hap["Extinction"] = [0.0, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    project.save()
    project.index_ids()
    project.set_Controls("parmMin", 1e-8, variable=f"{phase.id}:{hist.id}:Scale")
    project.set_Controls("parmMax", 1000.0, variable=f"{phase.id}:{hist.id}:Scale")
    avec = G2lat.cell2A(phase.data["General"]["Cell"][1:7])
    for i, value in enumerate(avec):
        delta = max(0.08 * abs(float(value)), 0.002)
        project.set_Controls("parmMin", float(value) - delta, variable=f"{phase.id}::A{i}")
        project.set_Controls("parmMax", float(value) + delta, variable=f"{phase.id}::A{i}")
    project.set_Controls("cycles", args.cycles)
    project.save()
    project.refine()
    project.save()
    first = diagnostics(project)
    phase = project.phase(name)
    phase.set_refinements({"Cell": True})
    project.refine()
    project.save()
    result = {"scale_stage": first, "cell_stage": diagnostics(project)}
    args.output.with_name(args.output.stem + "_diagnostics.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
