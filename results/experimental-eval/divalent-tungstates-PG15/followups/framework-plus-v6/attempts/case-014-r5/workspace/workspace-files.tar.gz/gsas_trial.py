#!/usr/bin/env python3
"""Build and refine trial GSAS-II models for the supplied powder pattern.

Run this script with the GSAS-II Python interpreter. It is intentionally
small and writes only into the requested output directory.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def instrument_text() -> str:
    return """#GSAS-II instrument parameter file for Cu Ka laboratory data
Type:PXC;Bank:1
Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5
Zero:0.0;Polariz.:0.8;Azimuth:0.0
U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03
"""


def summarize(project: G2.G2Project, hist, phases, label: str) -> None:
    cov = project.data.get("Covariance", {}).get("data", {})
    values = dict(zip(cov.get("varyList", []), cov.get("variables", [])))
    sigmas = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    print(f"\n--- {label} ---")
    print("Rwp", hist.get_wR())
    print("GOF", cov.get("Rvals", {}).get("GOF"))
    print("sample", hist.data["Sample Parameters"])
    print("instrument", hist.data["Instrument Parameters"][0])
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        print(
            "phase",
            phase.name,
            "cell",
            phase.get_cell(),
            "scale",
            hap["Scale"],
            "size",
            hap["Size"],
            "mustrain",
            hap["Mustrain"],
            "PO",
            hap["Pref.Ori."],
        )
    print("vary", json.dumps({k: [v, sigmas.get(k)] for k, v in values.items()}, indent=2))


def refine(project, hist, phases, label, *, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()
    project = G2.G2Project(project.filename)
    hist = project.histogram(0)
    phases = project.phases()
    summarize(project, hist, phases, label)
    return project, hist, phases


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase", action="append", required=True, help="name=path")
    parser.add_argument("--background", type=int, default=8)
    parser.add_argument(
        "--stop",
        choices=["scale", "cell", "inventory", "profile", "size"],
        default="size",
    )
    args = parser.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    inst = args.out / "instrument.instprm"
    inst.write_text(instrument_text())
    project = G2.G2Project(newgpx=str(args.out / "trial.gpx"))
    phases = []
    for item in args.phase:
        name, path = item.split("=", 1)
        phases.append(project.add_phase(str(Path(path).resolve()), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()),
        str(inst.resolve()),
        phases=phases,
        fmthint="comma",
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.01, 99.99],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background,
                "coeffs": [600.0] + [0.0] * (args.background - 1),
                "refine": True,
            },
        }
    )
    for index, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        if index == 0:
            hap["Scale"] = [10000.0 / phase.data["General"]["Mass"], True]
        else:
            # Secondary phases are challenged only after the dominant phase
            # has supplied a stable common displacement and background.
            hap["Scale"] = [0.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1000.0
        hap["Size"][1][1] = 1000.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
    project.save()

    project, hist, phases = refine(project, hist, phases, "background and scales")
    if args.stop == "scale":
        return

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    phases[0].set_refinements({"Cell": True})
    project, hist, phases = refine(project, hist, phases, "shift and cells")
    if args.stop == "cell":
        return

    if len(phases) > 1:
        for phase in phases[1:]:
            hap = phase.data["Histograms"][hist.name]
            hap["Scale"] = [1.0, True]
        project, hist, phases = refine(project, hist, phases, "secondary scales")
        for index in range(1, len(phases)):
            phases[index].set_refinements({"Cell": True})
            project, hist, phases = refine(
                project, hist, phases, f"secondary cell {phases[index].name}", cycles=6
            )
    if args.stop == "inventory":
        return

    # Keep the common Caglioti baseline physical: U is fixed at its
    # nonnegative boundary while W and X establish the width floor/tails.
    hist.data["Instrument Parameters"][0]["U"] = [0.0, 0.0, False]
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    project, hist, phases = refine(project, hist, phases, "common profile")
    if args.stop == "profile":
        return

    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True, "value": 1.0}})
    project, hist, phases = refine(project, hist, phases, "phase sizes")
    project.save()


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
