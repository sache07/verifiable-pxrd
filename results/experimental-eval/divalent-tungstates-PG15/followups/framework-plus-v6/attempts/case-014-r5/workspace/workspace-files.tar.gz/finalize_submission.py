#!/usr/bin/env python3
"""Package the converged GSAS-II refinement into the requested deliverables."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final-candidate-full.gpx"
PROJECT = ROOT / "final.gpx"

PHASE_METADATA = {
    "SrWO4": {
        "formula": "SrWO4",
        "space_group": "I 41/a",
        "cif_path": "phase_SrWO4.cif",
        "model_origin": "COD 1546036; refined scheelite model",
    },
    "WO3": {
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif_path": "phase_WO3.cif",
        "model_origin": "COD 2311041; monoclinic WO3 model",
    },
    "Sr2WO5": {
        "formula": "Sr2WO5",
        "space_group": "P n m a",
        "cif_path": "phase_Sr2WO5.cif",
        "model_origin": "Ba2ReO5 prototype (COD 1529756), isovalent Ba->Sr and Re->W substitution",
    },
}


def finite_float(value):
    value = float(value)
    if not np.isfinite(value):
        raise ValueError(f"non-finite output value: {value}")
    return value


def main() -> None:
    G2.SetPrintLevel("warn")

    # Save through GSAS-II so the final project is self-consistent at its final path,
    # then reopen it before all exports.
    project = G2.G2Project(str(SOURCE))
    project.save(str(PROJECT))
    project = G2.G2Project(str(PROJECT))
    hist = project.histogram(0)
    phases = project.phases()

    x, observed, weights, calculated, background, residual = [
        np.asarray(values, dtype=float) for values in hist.data["data"][1]
    ]
    original = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if original.shape != (len(x), 2):
        raise ValueError("final project does not contain the complete observed grid")
    if not np.allclose(x, original[:, 0], rtol=0, atol=1e-10):
        raise ValueError("project angle grid differs from pattern.csv")
    if not np.allclose(observed, original[:, 1], rtol=0, atol=1e-10):
        raise ValueError("project observations differ from pattern.csv")
    if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
        raise ValueError("invalid calculated profile")
    if not np.allclose(residual, observed - calculated, rtol=0, atol=1e-8):
        raise ValueError("saved GSAS-II residual array is inconsistent")
    limits = hist.data["Limits"][1]
    if not np.allclose(limits, [x[0], x[-1]], rtol=0, atol=1e-10):
        raise ValueError("final fit limits do not span the complete pattern")

    # Export the actual saved phase models from the same reopened project.
    phase_lookup = {phase.name: phase for phase in phases}
    if set(phase_lookup) != set(PHASE_METADATA):
        raise ValueError(f"unexpected final phase inventory: {sorted(phase_lookup)}")
    for name, metadata in PHASE_METADATA.items():
        phase_lookup[name].export_CIF(str(ROOT / metadata["cif_path"]))

    profile = np.column_stack((x, observed, calculated, observed - calculated))
    np.savetxt(
        ROOT / "fit.csv",
        profile,
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.10f", "%.15g", "%.15g", "%.15g"],
    )

    fractions = hist.ComputeMassFracs()
    total = sum(value[0] for value in fractions.values())
    if not np.isclose(total, 1.0, rtol=0, atol=1e-10):
        raise ValueError(f"mass fractions are not normalized: {total}")

    phase_rows = []
    for name in [phase.name for phase in phases]:
        metadata = PHASE_METADATA[name]
        fraction, esd = fractions[name]
        cell = phase_lookup[name].get_cell()
        phase_rows.append(
            {
                "name": name,
                "formula": metadata["formula"],
                "space_group": metadata["space_group"],
                "cif_path": metadata["cif_path"],
                "weight_fraction": finite_float(fraction),
                "weight_fraction_esd": finite_float(esd),
                "model_origin": metadata["model_origin"],
                "refined_cell": {
                    "a_A": finite_float(cell["length_a"]),
                    "b_A": finite_float(cell["length_b"]),
                    "c_A": finite_float(cell["length_c"]),
                    "alpha_deg": finite_float(cell["angle_alpha"]),
                    "beta_deg": finite_float(cell["angle_beta"]),
                    "gamma_deg": finite_float(cell["angle_gamma"]),
                },
            }
        )

    histogram_stats = hist.data["data"][0]
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": finite_float(histogram_stats["wR"]),
            "Rp_percent": finite_float(histogram_stats["R"]),
            "Rwp_expected_percent": finite_float(histogram_stats["wRmin"]),
            "goodness_of_fit": finite_float(rvals["GOF"]),
            "chi_squared": finite_float(rvals["chisq"]),
            "Durbin_Watson": finite_float(histogram_stats["Durbin-Watson"]),
            "n_observations": int(rvals["Nobs"]),
            "n_variables": int(rvals["Nvars"]),
            "converged": bool(rvals["converged"]),
            "maximum_shift_over_esd": finite_float(rvals["Max shft/sig"]),
        },
        "refinement_histogram": hist.name,
        "profile_path": "fit.csv",
        "project_path": "final.gpx",
        "fraction_basis": "normalized over the three modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
