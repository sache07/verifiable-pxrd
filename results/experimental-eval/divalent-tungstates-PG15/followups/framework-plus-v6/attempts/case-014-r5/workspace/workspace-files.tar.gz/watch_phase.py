#!/usr/bin/env python3
"""Challenge one additional crystalline phase against a converged project."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("name")
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()

    project = G2.G2Project(str(args.input))
    project.save(str(args.output))
    project = G2.G2Project(str(args.output))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    project.save()
    project = G2.G2Project(str(args.output))
    hist = project.histogram(0)
    phase = project.phase(args.name)
    phase_index = len(project.phases()) - 1
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.10, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Scale")
    project.save()

    for _ in range(args.repeats):
        project.set_Controls("cycles", 12)
        project.refine()
        project = G2.G2Project(str(args.output))

    hist = project.histogram(0)
    phase = project.phase(args.name)
    hap = phase.data["Histograms"][hist.name]
    covariance = project.data["Covariance"]["data"]
    values = dict(zip(covariance.get("varyList", []), covariance.get("variables", [])))
    sigmas = dict(zip(covariance.get("varyList", []), covariance.get("sig", [])))
    variable = f"{phase_index}:0:Scale"
    print("Rwp", hist.get_wR())
    print("candidate", args.name, "scale", hap["Scale"], "sigma", sigmas.get(variable))
    print("frozen", project.get_Frozen())
    print("fractions", hist.ComputeMassFracs())
    print("cell", phase.data["General"]["Cell"][1:7])
    project.save()


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
