#!/usr/bin/env python3
"""Apply a controlled refinement variant to an existing GSAS-II project."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def reopen(project: G2.G2Project, repeats: int = 1) -> G2.G2Project:
    """Refine, save and reopen repeatedly to test replay convergence."""
    for _ in range(repeats):
        project.set_Controls("cycles", 12)
        project.refine()
        project = G2.G2Project(project.filename)
    return project


def summary(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    print(
        "SUMMARY",
        "Rwp",
        hist.get_wR(),
        "shift",
        hist.data["Sample Parameters"]["Shift"][0],
        "U",
        inst["U"][1],
        "W",
        inst["W"][1],
        "X",
        inst["X"][1],
        "SHL",
        inst["SH/L"][1],
    )
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        print(
            "PHASE",
            index,
            phase.name,
            "scale",
            hap["Scale"][0],
            "size",
            hap["Size"][0],
            hap["Size"][1][:3],
            "mustrain",
            hap["Mustrain"][0],
            hap["Mustrain"][1][:3],
            "PO",
            hap["Pref.Ori."][1:4],
            "cell",
            phase.data["General"]["Cell"][1:7],
        )


def neutral_hap(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1000.0
        hap["Size"][1][1] = 1000.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "action",
        choices=[
            "continue",
            "size",
            "size_add",
            "size_uniaxial",
            "strain",
            "strain_uniaxial",
            "reprofile",
            "uwx",
            "shl",
            "polarization",
            "roughness",
            "roughness_a_fixed",
            "background6",
            "coords",
            "coords_bounded",
            "coords_restrained",
            "cell",
            "full_range",
            "uiso",
            "uiso_uniform",
            "texture",
        ],
    )
    parser.add_argument("--phase", type=int)
    parser.add_argument("--axis", nargs=3, type=int, default=[0, 0, 1])
    parser.add_argument("--repeats", type=int, default=1)
    parser.add_argument("--coord-limit", type=float, default=0.006)
    parser.add_argument("--uiso-min", type=float, default=0.003)
    parser.add_argument("--uiso-max", type=float, default=0.02)
    parser.add_argument("--rough-a", type=float, default=0.10)
    parser.add_argument("--restraint-weight", type=float, default=100.0)
    args = parser.parse_args()

    project = G2.G2Project(str(args.input))
    project.save(str(args.output))
    project = G2.G2Project(str(args.output))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]

    if args.action in {"size", "strain", "reprofile"}:
        neutral_hap(project)
        inst["U"] = [0.0, 0.0, False]
        inst["W"] = [10.0, 10.0, True]
        inst["X"] = [1.0, 1.0, True]
    if args.action == "size":
        if args.phase is None:
            raise ValueError("--phase is required")
        hap = project.phases()[args.phase].data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.2
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.03, variable=f"{args.phase}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{args.phase}:0:Size;i")
    elif args.action == "size_add":
        if args.phase is None:
            raise ValueError("--phase is required")
        hap = project.phases()[args.phase].data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.03, variable=f"{args.phase}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{args.phase}:0:Size;i")
    elif args.action == "size_uniaxial":
        if args.phase is None:
            raise ValueError("--phase is required")
        hap = project.phases()[args.phase].data["Histograms"][hist.name]
        hap["Size"][0] = "uniaxial"
        hap["Size"][1][0] = 1.0
        hap["Size"][1][1] = 1.0
        hap["Size"][2][0] = True
        hap["Size"][2][1] = True
        hap["Size"][3] = list(args.axis)
        for suffix in ("i", "a"):
            project.set_Controls("parmMin", 0.03, variable=f"{args.phase}:0:Size;{suffix}")
            project.set_Controls("parmMax", 10.0, variable=f"{args.phase}:0:Size;{suffix}")
    elif args.action == "strain":
        if args.phase is None:
            raise ValueError("--phase is required")
        hap = project.phases()[args.phase].data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{args.phase}:0:Mustrain;i")
    elif args.action == "strain_uniaxial":
        if args.phase is None:
            raise ValueError("--phase is required")
        hap = project.phases()[args.phase].data["Histograms"][hist.name]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = list(args.axis)
        for suffix in ("i", "a"):
            project.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;{suffix}")
            project.set_Controls("parmMax", 8000.0, variable=f"{args.phase}:0:Mustrain;{suffix}")
    elif args.action == "shl":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
        project.set_Controls("parmMax", 0.10, variable=":0:SH/L")
    elif args.action == "uwx":
        inst["U"] = [5.0, 5.0, True]
        inst["W"][2] = True
        inst["X"][2] = True
        project.set_Controls("parmMin", 0.0, variable=":0:U")
        project.set_Controls("parmMax", 40.0, variable=":0:U")
        project.set_Controls("parmMin", 0.0, variable=":0:W")
        project.set_Controls("parmMax", 80.0, variable=":0:W")
        project.set_Controls("parmMin", 0.0, variable=":0:X")
        project.set_Controls("parmMax", 12.0, variable=":0:X")
    elif args.action == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif args.action == "roughness":
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.10, True]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.10, True]
        project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    elif args.action == "roughness_a_fixed":
        hist.data["Sample Parameters"]["SurfRoughA"] = [args.rough_a, False]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.10, True]
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    elif args.action == "background6":
        hist.set_refinements({"Background": {"no. coeffs": 6, "refine": True}})
    elif args.action == "coords":
        if args.phase is None:
            raise ValueError("--phase is required")
        project.phases()[args.phase].set_refinements({"Atoms": {"all": "X"}})
    elif args.action == "coords_bounded":
        if args.phase is None:
            raise ValueError("--phase is required")
        phase = project.phases()[args.phase]
        phase.set_refinements({"Atoms": {"all": "X"}})
        cx = phase.data["General"]["AtomPtrs"][0]
        for atom_index, atom in enumerate(phase.data["Atoms"]):
            for axis, suffix in enumerate("xyz"):
                var = f"{args.phase}::dA{suffix}:{atom_index}"
                project.set_Controls(
                    "parmMin", atom[cx + axis] - args.coord_limit, variable=var
                )
                project.set_Controls(
                    "parmMax", atom[cx + axis] + args.coord_limit, variable=var
                )
    elif args.action == "coords_restrained":
        if args.phase is None:
            raise ValueError("--phase is required")
        phase = project.phases()[args.phase]
        rest = project.data["Restraints"]["data"]
        rest[phase.name] = {
            "Bond": {"wtFactor": args.restraint_weight, "Range": 1.1, "Bonds": [], "Use": True}
        }
        atoms = phase.atoms()
        oxygens = [atom for atom in atoms if atom.element == "O"]
        tungstens = [atom for atom in atoms if atom.element == "W"]
        strontiums = [atom for atom in atoms if atom.element == "Sr"]
        for atom in oxygens:
            atom.refinement_flags = "XU" if "U" in atom.refinement_flags else "X"
        if args.phase == 0:
            # Chemically regular scheelite tetrahedra and eight-coordinate Sr.
            phase.addDistRestraint(tungstens, oxygens, 1.82, factor=1.06, ESD=0.03)
            phase.addDistRestraint(strontiums, oxygens, 2.57, factor=1.04, ESD=0.05)
        elif args.phase == 2:
            phase.addDistRestraint(tungstens, oxygens, 1.753, factor=1.012, ESD=0.03)
            phase.addDistRestraint(tungstens, oxygens, 1.823, factor=1.025, ESD=0.03)
            phase.addDistRestraint(tungstens, oxygens, 2.010, factor=1.025, ESD=0.04)
            phase.addDistRestraint(strontiums, oxygens, 2.60, factor=1.012, ESD=0.05)
            phase.addDistRestraint(strontiums, oxygens, 2.73, factor=1.015, ESD=0.06)
            phase.addDistRestraint(strontiums, oxygens, 2.82, factor=1.025, ESD=0.07)
            phase.addDistRestraint(strontiums, oxygens, 2.91, factor=1.012, ESD=0.07)
        else:
            phase.addDistRestraint(tungstens, oxygens, 1.90, factor=1.18, ESD=0.04)
        phase.setDistRestraintWeight(args.restraint_weight)
    elif args.action == "cell":
        if args.phase is None:
            raise ValueError("--phase is required")
        project.phases()[args.phase].set_refinements({"Cell": True})
    elif args.action == "full_range":
        x = hist.data["data"][1][0]
        hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    elif args.action == "uiso":
        if args.phase is None:
            raise ValueError("--phase is required")
        project.phases()[args.phase].set_refinements({"Atoms": {"all": "U"}})
    elif args.action == "uiso_uniform":
        if args.phase is None:
            raise ValueError("--phase is required")
        phase = project.phases()[args.phase]
        cia = phase.data["General"]["AtomPtrs"][3]
        for atom in phase.data["Atoms"]:
            atom[cia] = "I"
            atom[cia + 1] = 0.01
        phase.set_refinements({"Atoms": {"all": "U"}})
        variables = [f"{args.phase}::AUiso:{i}" for i in range(len(phase.data["Atoms"]))]
        if len(variables) > 1:
            project.add_EquivConstr(variables)
        for variable in variables:
            project.set_Controls("parmMin", args.uiso_min, variable=variable)
            project.set_Controls("parmMax", args.uiso_max, variable=variable)
    elif args.action == "texture":
        if args.phase is None:
            raise ValueError("--phase is required")
        hap = project.phases()[args.phase].data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(args.axis)
        project.set_Controls("parmMin", 0.7, variable=f"{args.phase}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{args.phase}:0:MD")

    project.save()
    project = reopen(project, repeats=args.repeats)
    project.save()
    summary(project)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
