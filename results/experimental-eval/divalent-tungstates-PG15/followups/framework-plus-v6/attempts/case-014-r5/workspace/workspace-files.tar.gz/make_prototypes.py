#!/usr/bin/env python3
"""Create chemically substituted trial models from COD analogue parents."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = Path(".tmp/prototypes")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make(name: str, cod_id: str, substitutions: dict[str, str], scale: float) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species(substitutions)
    structure.lattice = Lattice(structure.lattice.matrix * scale)
    structure.remove_oxidation_states()
    for index, site in enumerate(structure):
        site.label = f"{site.species_string}{index + 1}"
    OUT.mkdir(parents=True, exist_ok=True)
    CifWriter(structure, symprec=1e-3, significant_figures=10).write_file(OUT / f"{name}.cif")


make("Sr2WO5_from_Ba2ReO5_1529756", "1529756", {"Ba": "Sr", "Re": "W"}, 0.962)
make("Sr3WO6_from_Ca3WO6_1563081", "1563081", {"Ca": "Sr"}, 1.071)
make("Sr3WO6_from_Sr3UO6_2001752", "2001752", {"U": "W"}, 0.996)
make("SrW2O7_from_SrCr2O7_1542062", "1542062", {"Cr": "W"}, 0.916)
