#!/usr/bin/env python3
"""Rank plausible COD phases by fixed-model positive residual reduction."""

from pathlib import Path
import argparse
import gzip
import json

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")


def path_for(cid):
    return COD / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def sticksets(structure):
    ans = []
    for wavelength in [1.540598, 1.544426]:
        pat = XRDCalculator(wavelength=wavelength, symprec=0).get_pattern(
            structure, two_theta_range=(9.5, 100.5), scaled=True
        )
        ans.append((np.asarray(pat.x), np.asarray(pat.y)))
    return ans


def profile(sticks, x, lattice, offset, fwhm):
    out = np.zeros_like(x)
    step = np.median(np.diff(x))
    sigma = fwhm / 2.35482
    half = int(np.ceil(4 * sigma / step))
    for (xp0, yp), ratio in zip(sticks, [1.0, 0.5]):
        xp = np.degrees(2 * np.arcsin(np.sin(np.radians(xp0 / 2)) / lattice)) + offset
        for xx, yy in zip(xp, yp * ratio):
            center = int(np.searchsorted(x, xx))
            lo, hi = max(0, center - half), min(len(x), center + half + 1)
            out[lo:hi] += yy * np.exp(-0.5 * ((x[lo:hi] - xx) / sigma) ** 2)
    return out


parser = argparse.ArgumentParser()
parser.add_argument("profile", nargs="?", default=".tmp/challenge_control/profile.csv")
args = parser.parse_args()

base = np.loadtxt(args.profile, delimiter=",", skiprows=1)
x, y, calculated = base[:, :3].T
w = 1 / np.maximum(y, 1.0)
residual = y - calculated
chi0 = float(np.sum(w * residual**2))

with gzip.open(INDEX, "rt") as f:
    index = json.load(f)

records = []
for key in ["O-Pb-W", "O-Pb", "O-W", "C-O-Pb"]:
    records.extend((key, *row) for row in index.get(key, []))

ranked = []
for key, formula, cid, sg, rvalue in records:
    try:
        st = CifParser(path_for(cid), occupancy_tolerance=10).parse_structures(primitive=False)[0]
        sticks = sticksets(st)
    except Exception as exc:
        ranked.append((-np.inf, formula, cid, sg, None, str(exc)))
        continue
    best = None
    for lattice in np.linspace(0.99, 1.01, 9):
        for offset in np.linspace(0.20, 0.40, 5):
            for fwhm in [0.16, 0.24, 0.36, 0.50]:
                p = profile(sticks, x, lattice, offset, fwhm)
                denom = float(np.sum(w * p**2))
                amp = max(0.0, float(np.sum(w * p * residual)) / denom) if denom else 0.0
                chi = float(np.sum(w * (residual - amp * p) ** 2))
                score = chi0 - chi
                if best is None or score > best[0]:
                    best = (score, amp, lattice, offset, fwhm)
    ranked.append((*best, formula, cid, sg, key, rvalue))

ranked.sort(reverse=True, key=lambda row: row[0])
print(f"baseline chi={chi0:.3f}")
print("delta_chi amplitude lattice offset fwhm formula COD SG system R")
for row in ranked[:60]:
    if not np.isfinite(row[0]):
        continue
    score, amp, lattice, offset, fwhm, formula, cid, sg, key, rvalue = row
    print(
        f"{score:10.2f} {amp:9.4g} {lattice:7.4f} {offset:+7.3f} {fwhm:6.3f} "
        f"{formula:18s} {cid} {sg:3d} {key:8s} {rvalue}"
    )
