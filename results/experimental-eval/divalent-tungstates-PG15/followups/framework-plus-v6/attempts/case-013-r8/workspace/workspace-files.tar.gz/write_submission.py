#!/usr/bin/env python3
"""Create the exact final project, CIF/profile exports, result and report."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE=Path(".tmp/accepted6/accepted6.gpx")
FINAL=Path("final.gpx")
INFO={
    "stolzite":dict(display="stolzite PbWO4",formula="PbWO4",cod="9009811",cif="stolzite_PbWO4.cif"),
    "WO3":dict(display="monoclinic WO3",formula="WO3",cod="1528915",cif="monoclinic_WO3.cif"),
    "massicot":dict(display="massicot PbO",formula="PbO",cod="2310433",cif="massicot_PbO.cif"),
    "Pb3O4":dict(display="minium Pb3O4",formula="Pb3O4",cod="1537983",cif="minium_Pb3O4.cif"),
    "W3O8":dict(display="orthorhombic W3O8",formula="W3O8",cod="2101050",cif="orthorhombic_W3O8.cif"),
    "alpha_PbO_long_period":dict(display="long-period alpha-PbO approximant",formula="PbO",cod="1533609",cif="alpha_PbO_long_period.cif"),
}


def metrics(project):
    h=project.histogram(0);a=h.data["data"][1]
    x,y,c,b=(np.asarray(a[i],float) for i in (0,1,3,4));w=1/np.maximum(y,1)
    cov=project.data["Covariance"]["data"];rv=cov["Rvals"]
    rwp=100*np.sqrt(np.sum(w*(y-c)**2)/np.sum(w*y*y));rp=100*np.sum(abs(y-c))/np.sum(y)
    return h,x,y,c,b,cov,rv,float(rwp),float(rp)


def main():
    if FINAL.exists():FINAL.unlink()
    project=G2.G2Project(gpxfile=str(SOURCE),newgpx=str(FINAL));project.save()
    # Reopen and replay twice so final.gpx itself, not only its source branch,
    # is demonstrated stable on the complete measured range.
    for _ in range(2):
        project=G2.G2Project(gpxfile=str(FINAL));project.refine(makeBack=False);project.save()
    project=G2.G2Project(gpxfile=str(FINAL))
    h,x,y,c,b,cov,rv,rwp,rp=metrics(project)
    frozen=[str(v) for v in project.data["Controls"]["data"].get("parmFrozen",{}).get("FrozenList",[])]
    if frozen:raise RuntimeError("Final project has frozen variables: "+repr(frozen))
    if b.min() < -1e-8:raise RuntimeError("Final background is negative")

    # Exact normalized HAP mass fractions and covariance-only scale e.s.d.s.
    phases=project.phases();masses=[]
    for q in phases:
        hap=q.data["Histograms"][h.name]
        masses.append(float(q.data["General"]["Mass"]*hap["Scale"][0]))
    masses=np.asarray(masses);fractions=masses/masses.sum()
    vary=list(cov.get("varyList",[]));cmat=np.asarray(cov.get("covMatrix",[]),float)
    jac=np.zeros((len(phases),len(vary)))
    total=float(masses.sum())
    for j,q in enumerate(phases):
        var=f"{q.data['pId']}:{h.id}:Scale"
        if var not in vary:continue
        k=vary.index(var);cell_mass=float(q.data["General"]["Mass"])
        for i in range(len(phases)):
            jac[i,k]=((cell_mass*total if i==j else 0.)-masses[i]*cell_mass)/total**2
    fraction_esd=np.sqrt(np.maximum(0,np.diag(jac@cmat@jac.T))) if cmat.size else np.full(len(phases),np.nan)

    rows=[]
    for i,(q,f,s) in enumerate(zip(phases,fractions,fraction_esd)):
        meta=INFO[q.name];out=Path(meta["cif"])
        if out.exists():out.unlink()
        q.export_CIF(str(out.resolve()))
        sg=q.data["General"]["SGData"]
        row={"name":meta["display"],"project_phase":q.name,"formula":meta["formula"],
             "space_group":str(sg["SpGrp"]),"cod_parent_id":meta["cod"],"cif_path":meta["cif"],
             "weight_fraction":float(f),"weight_percent":float(100*f),
             "weight_fraction_esd_statistical":float(s)}
        rows.append(row)

    public=np.loadtxt("inputs/pattern.csv",delimiter=",",skiprows=1)
    if public.shape != (len(x),2) or not np.allclose(public[:,0],x,rtol=0,atol=1e-7) or not np.allclose(public[:,1],y,rtol=0,atol=1e-5):
        raise RuntimeError("Final project histogram does not match inputs/pattern.csv")
    np.savetxt("fit.csv",np.column_stack((public[:,0],public[:,1],c,public[:,1]-c,b)),delimiter=",",
               header="two_theta_deg,observed,calculated,difference,background",comments="",fmt="%.10g")

    inst=h.InstrumentParameters;sample=h.SampleParameters
    fit={"rwp_percent":rwp,"rp_percent":rp,"r_exp_percent":float(rwp/rv["GOF"]),
         "chi_square":float(rv["chisq"]),"goodness_of_fit":float(rv["GOF"]),
         "n_observations":int(rv["Nobs"]),"n_refined_parameters":int(rv["Nvars"]),
         "max_shift_over_esd":float(rv["Max shft/sig"]),"background_min_counts":float(b.min()),
         "background_max_counts":float(b.max())}
    result={"phases":rows,"fraction_basis":"normalized over the six modeled crystalline phases; no amorphous/internal-standard correction",
            "fit_statistics":fit,"profile_file":"fit.csv","gsas_project":"final.gpx","refinement_histogram":h.name,
            "calibration":{"zero_deg":float(inst["Zero"][1]),"specimen_displacement_um":float(sample["Shift"][0])},
            "profile":{"U":float(inst["U"][1]),"V":float(inst["V"][1]),"W":float(inst["W"][1]),
                       "X":float(inst["X"][1]),"Y":float(inst["Y"][1]),"Z":float(inst["Z"][1]),"SH_over_L":float(inst["SH/L"][1])},
            "notes":["Scale covariance e.s.d.s. do not include inventory/profile/structural model uncertainty.",
                     "Litharge and WO2 watch-list trials were below reliable quantitative significance (~0.3 wt% each)."]}
    Path("result.json").write_text(json.dumps(result,indent=2)+"\n")

    pct={r["project_phase"]:r["weight_percent"] for r in rows}
    esd={r["project_phase"]:100*r["weight_fraction_esd_statistical"] for r in rows}
    strain=project.phase("alpha_PbO_long_period").data["Histograms"][h.name]["Mustrain"][1][0]
    md=project.phase("massicot").data["Histograms"][h.name]["Pref.Ori."][1]
    report=f"""# Powder XRD phase analysis

## Result

Six crystalline components were retained. Fractions are normalized over those modeled crystalline components only:

| Phase model | Space group | wt% | covariance e.s.d. (wt%) |
|---|---:|---:|---:|
| Stolzite PbWO4 | I 41/a | {pct['stolzite']:.2f} | {esd['stolzite']:.2f} |
| Monoclinic WO3 | P 21/n | {pct['WO3']:.2f} | {esd['WO3']:.2f} |
| Massicot PbO | Pbcm | {pct['massicot']:.2f} | {esd['massicot']:.2f} |
| Long-period alpha-PbO approximant | Pbcm | {pct['alpha_PbO_long_period']:.2f} | {esd['alpha_PbO_long_period']:.2f} |
| Orthorhombic W3O8 | P 21 21 2 | {pct['W3O8']:.2f} | {esd['W3O8']:.2f} |
| Minium Pb3O4 | P 42/mbc | {pct['Pb3O4']:.2f} | {esd['Pb3O4']:.2f} |

The final full-range replay gives Rwp = {rwp:.3f}%, Rp = {rp:.3f}%, and GOF = {rv['GOF']:.3f}. The background remains positive ({b.min():.1f}–{b.max():.1f} counts), no variable is frozen, and the final maximum shift/e.s.d. is {rv['Max shft/sig']:.4f}.

## Evidence and model choices

Stolzite accounts for the dominant coherent families at 27.70, 29.91, 33.06, 45.03, 47.28, 51.49, 55.54 and 72.27° 2theta. Monoclinic WO3 is required by the resolved 23.39/23.89/24.64° triplet and its higher-angle families. Ordinary massicot contributes at 29.35, 30.62, 38.09 and 53.38°. Pb3O4 is supported particularly by 26.77, 31.05 and 34.43°, while W3O8 has a characteristic family near 25.91° plus complementary higher-angle lines.

Residual screening identified COD 1533609, the published long-period approximation to incommensurate alpha-PbO. Its families near 28.85, 31.99–32.11, 35.93 and 48.72–48.81° remove coherent residuals and retain a positive scale after the complete inventory/profile rebuild. It requires broad effective lines; the accepted isotropic strain is {strain:.0f} ppm. A [100] March–Dollase term for ordinary massicot is strongly supported (ratio {md:.3f}); alternate axes and texture on the other major phases were rejected.

One specimen-displacement correction ({sample['Shift'][0]:.1f} micrometres) was used with zero fixed at 0°. U/W/X and SH/L are nonnegative/interior. Absolute crystallite size is covariant with instrumental X: the saved phase-size values are an effective broadening gauge, not independently determined size measurements. Strain trials for ordinary massicot and Pb3O4 hit limits and were pruned; anisotropic strain for the long-period PbO did not improve on its simpler isotropic term. Polarization and roughness trials were unsupported.

Published atomic coordinates were retained because bounded coordinate refinements ran to their displacement limits or were highly correlated. Unit cells were refined, but the final re-challenge did not justify further cell movement. Thus the atomic coordinates—and especially oxygen positions in weak W3O8/Pb3O4 and the long-period PbO model—are not independently resolved by this powder pattern.

## Remaining uncertainty

The two PbO descriptions may represent ordinary and modulated alpha-PbO domains rather than two sharply separable thermodynamic phases. Their combined fraction is {pct['massicot']+pct['alpha_PbO_long_period']:.2f} wt%; the split between them is more model-dependent than the covariance e.s.d.s. indicate. Fixed-cell watch-list tests gave only ~0.3 wt% each for litharge and WO2 (about 2.3–2.4 sigma; Delta Rwp < 0.005%), so neither can be identified or quantified reliably. Raspite and an alternate W3O8 polymorph refined to zero. Fractions exclude any amorphous material and carry additional systematic uncertainty from overlap, broadening and structural-model choice.

Structural parents were COD 9009811, 1528915, 2310433, 1533609, 1537983 and 2101050. The CIFs, fractions and `fit.csv` were exported from the replayed `final.gpx`.
"""
    Path("report.md").write_text(report)
    print(json.dumps({"Rwp":rwp,"Rp":rp,"GOF":rv["GOF"],"max_shift_esd":rv["Max shft/sig"],
                      "fractions":{r["project_phase"]:r["weight_fraction"] for r in rows}},indent=2))


if __name__=="__main__":
    G2.SetPrintLevel("warn");main()
