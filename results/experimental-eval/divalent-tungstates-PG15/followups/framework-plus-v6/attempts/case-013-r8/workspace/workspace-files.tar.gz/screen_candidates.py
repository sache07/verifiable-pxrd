#!/usr/bin/env python3
"""Screen exact-composition COD candidates against observed peak positions."""

from pathlib import Path

import gzip
import json
import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d, minimum_filter1d
from scipy.optimize import nnls
from scipy.signal import find_peaks


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def sticks(structure, wavelength: float):
    pat = XRDCalculator(wavelength=wavelength, symprec=0.0).get_pattern(
        structure, two_theta_range=(9.5, 100.5), scaled=True
    )
    return np.asarray(pat.x), np.asarray(pat.y)


def broaden(sticksets, xgrid, lattice_factor=1.0, offset=0.0):
    out = np.zeros_like(xgrid)
    step = np.median(np.diff(xgrid))
    for (xp0, yp), ratio in zip(sticksets, [1.0, 0.5]):
        xp = np.degrees(2 * np.arcsin(np.sin(np.radians(xp0 / 2)) / lattice_factor))
        # Approximate the observed Caglioti trend for inventory screening.
        fwhm = 0.17 + 0.0017 * np.maximum(xp - 25.0, 0.0)
        for xx, yy, fw in zip(xp + offset, yp * ratio, fwhm):
            half = max(4, int(np.ceil(4 * fw / step)))
            center = int(np.searchsorted(xgrid, xx))
            lo, hi = max(0, center - half), min(len(xgrid), center + half + 1)
            sigma = fw / 2.35482
            out[lo:hi] += yy * np.exp(-0.5 * ((xgrid[lo:hi] - xx) / sigma) ** 2)
    return out


data = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
x, y = data.T
base = gaussian_filter1d(minimum_filter1d(y, size=301, mode="nearest"), 100)
signal = np.maximum(y - base, 0.0)
peaks, props = find_peaks(signal, prominence=120, distance=3)

with gzip.open(INDEX, "rt") as handle:
    index = json.load(handle)

records = []
for key in ["O-Pb-W", "O-Pb", "O-W"]:
    for formula, cod_id, sg, r_value in index.get(key, []):
        # Reject compositions that need reducing/oxidizing chemistry not indicated
        # by the stated PbO + WO3 firing, but retain all common precursor oxides.
        if key == "O-Pb-W" or formula in {"PbO", "Pb3O4", "WO3"}:
            records.append((formula, cod_id, sg, r_value))

print("Observed prominent peak positions:")
print(" ".join(f"{x[p]:.3f}" for p in peaks[np.argsort(props['prominences'])[::-1]][:45]))

for formula, cod_id, sg, r_value in records:
    path = cif_path(cod_id)
    try:
        structure = CifParser(path, occupancy_tolerance=10).parse_structures(primitive=False)[0]
    except Exception as exc:
        print(f"FAIL {cod_id} {formula}: {exc}")
        continue
    best = None
    # Coarse isotropic lattice and zero search is sufficient for source ranking.
    sticksets = [sticks(structure, wave) for wave in (1.540598, 1.544426)]
    for lattice_factor in np.linspace(0.995, 1.005, 5):
        for offset in np.linspace(-0.25, 0.25, 11):
            calc = broaden(sticksets, x, lattice_factor, offset)
            A = np.column_stack([np.ones_like(x), calc])
            coef, _ = nnls(A / np.sqrt(np.maximum(y[:, None], 1.0)), y / np.sqrt(np.maximum(y, 1.0)))
            model = A @ coef
            rwp = np.sqrt(np.sum((y - model) ** 2 / np.maximum(y, 1.0)) / np.sum(y))
            if best is None or rwp < best[0]:
                best = (rwp, lattice_factor, offset, coef[1])
    xp, yp = sticks(structure, 1.540598)
    ii = np.argsort(yp)[::-1][:12]
    top = " ".join(f"{xp[i]:.2f}({yp[i]:.0f})" for i in ii)
    print(
        f"{formula:12s} COD {cod_id} SG {sg:3d} R={r_value!s:6s} "
        f"screen_Rwp={100*best[0]:6.2f}% lat={best[1]:.4f} off={best[2]:+.3f} top: {top}"
    )
