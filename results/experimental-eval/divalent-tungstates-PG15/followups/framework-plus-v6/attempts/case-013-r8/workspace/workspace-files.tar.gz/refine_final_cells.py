#!/usr/bin/env python3
"""Revisit all six unit cells under the accepted nuisance model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


SOURCE=Path(".tmp/accepted6/accepted6.gpx");OUTDIR=Path(".tmp/cells6");GPX=OUTDIR/"cells6.gpx"
def bound(p,v,lo,hi):p.set_Controls("parmMin",float(lo),variable=v);p.set_Controls("parmMax",float(hi),variable=v)
def rwp(p):
    a=p.histogram(0).data["data"][1];y,c=np.asarray(a[1]),np.asarray(a[3]);w=1/np.maximum(y,1)
    return float(100*np.sqrt(np.sum(w*(y-c)**2)/np.sum(w*y*y)))
def snap(p,stage):
    cov=p.data.get("Covariance",{}).get("data",{});rv=cov.get("Rvals",{})
    out={"stage":stage,"rwp_percent":rwp(p),"max_shift_over_esd":float(rv.get("Max shft/sig",np.nan)),
         "cells":{q.name:[float(v) for v in q.data["General"]["Cell"][1:8]] for q in p.phases()},
         "frozen":[str(v) for v in p.data["Controls"]["data"].get("parmFrozen",{}).get("FrozenList",[])]}
    print(stage,out["rwp_percent"],out["max_shift_over_esd"],out["frozen"],flush=True);return out
def configure(p):
    p.set_Controls("cycles",12);ctrl=p.data["Controls"]["data"];ctrl["parmFrozen"]={"FrozenList":[]};ctrl["parmMinDict"]={};ctrl["parmMaxDict"]={}
    h=p.histogram(0)
    for key,item in h.InstrumentParameters.items():
        if isinstance(item,list) and len(item)>2:item[2]=False
    h.Background[0][1]=True
    for key,item in h.SampleParameters.items():
        if isinstance(item,list) and len(item)>1 and isinstance(item[1],(bool,np.bool_)):item[1]=False
    h.SampleParameters["Shift"][1]=True;bound(p,f":{h.id}:Shift",-800,800)
    for q in p.phases():
        q.clear_refinements({"Cell":True});hap=q.data["Histograms"][h.name];hap["Scale"][1]=True
        bound(p,f"{q.data['pId']}:{h.id}:Scale",0,100);hap["Size"][2]=[False for _ in hap["Size"][2]];hap["Mustrain"][2]=[False for _ in hap["Mustrain"][2]]
        if len(hap["Mustrain"])>5:hap["Mustrain"][5]=[False for _ in hap["Mustrain"][5]]
        if q.name=="massicot":hap["Pref.Ori."][2]=True;bound(p,f"{q.data['pId']}:{h.id}:MD",.7,1.4)
        else:hap["Pref.Ori."][2]=False
        for atom in q.atoms():atom.refinement_flags=""
def cell_bounds(p,q,frac=.005):
    A=G2lat.cell2A(q.data["General"]["Cell"][1:7])
    for i,v in enumerate(A):
        if i<3:lo,hi=sorted(((1-frac)*float(v),(1+frac)*float(v)))
        else:lo,hi=float(v)-.0005,float(v)+.0005
        bound(p,f"{q.data['pId']}::A{i}",lo,hi)
def main():
    OUTDIR.mkdir(parents=True,exist_ok=True);p=G2.G2Project(gpxfile=str(SOURCE),newgpx=str(GPX));configure(p);p.save();log=[snap(p,"configured")]
    for q in p.phases():
        cell_bounds(p,q);q.set_refinements({"Cell":True})
        for _ in range(3):
            p.refine(makeBack=False)
        p.save();log.append(snap(p,"cell_"+q.name));q.clear_refinements({"Cell":True})
        p.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}
    # Replay scales/background/angular correction with all cells fixed.
    for i in range(2):p.refine(makeBack=False);p.save();log.append(snap(p,f"fixed_cell_replay_{i+1}"))
    (OUTDIR/"summary.json").write_text(json.dumps(log,indent=2)+"\n")
if __name__=="__main__":G2.SetPrintLevel("warn");main()
