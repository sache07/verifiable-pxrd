#!/usr/bin/env python3
"""Initial visual and peak-list diagnostics for the supplied powder scan."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import minimum_filter1d, gaussian_filter1d
from scipy.signal import find_peaks


data = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
x, y = data.T

# A broad minimum filter followed by smoothing supplies a conservative baseline
# for peak discovery only; it is not used in the crystallographic refinement.
baseline = gaussian_filter1d(minimum_filter1d(y, size=301, mode="nearest"), 100)
residual = y - baseline
noise = 1.4826 * np.median(np.abs((residual - gaussian_filter1d(residual, 5))))
peaks, props = find_peaks(
    residual,
    prominence=max(6 * noise, 80),
    distance=max(2, int(round(0.045 / np.median(np.diff(x))))),
    width=1,
)
order = np.argsort(props["prominences"])[::-1]

print(f"points={len(x)} range={x[0]:.6f}..{x[-1]:.6f} step={np.median(np.diff(x)):.7f}")
print(f"counts min/median/max={y.min():.1f}/{np.median(y):.1f}/{y.max():.1f}; noise~{noise:.1f}")
print("rank two_theta intensity prominence width_deg")
for rank, idx in enumerate(order[:120], 1):
    p = peaks[idx]
    width = props["widths"][idx] * np.median(np.diff(x))
    print(f"{rank:3d} {x[p]:11.6f} {y[p]:10.1f} {props['prominences'][idx]:11.1f} {width:9.5f}")

fig, axes = plt.subplots(3, 1, figsize=(15, 11), constrained_layout=True)
for ax, (lo, hi) in zip(axes, [(10, 40), (40, 70), (70, 100)]):
    mask = (x >= lo) & (x <= hi)
    ax.plot(x[mask], y[mask], color="black", lw=0.65)
    ax.plot(x[mask], baseline[mask], color="tab:orange", lw=0.8)
    ax.set_xlim(lo, hi)
    ax.set_ylabel("Counts")
    ax.grid(alpha=0.15)
axes[-1].set_xlabel(r"$2\theta$ (degrees, Cu K$\alpha$)")
fig.savefig("pattern_overview.png", dpi=160)
