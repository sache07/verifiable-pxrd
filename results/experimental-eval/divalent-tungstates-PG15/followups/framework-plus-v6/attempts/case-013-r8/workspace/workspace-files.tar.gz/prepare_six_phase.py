#!/usr/bin/env python3
"""Remove rejected litharge and rename the long-period alpha-PbO phase."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/develop7_shift/develop7_shift.gpx")
OUTDIR = Path(".tmp/inventory6_seed")
DEST = OUTDIR / "inventory6_seed.gpx"


def main():
    OUTDIR.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(DEST))

    rejected = "litharge"
    renamed_from = "massicot_alt"
    renamed_to = "alpha_PbO_long_period"

    # Scriptable has no public phase-removal API. These are the three project
    # locations keyed by phase name. There are no project constraints here.
    del project.data["Phases"][rejected]
    phase_name_row = next(row for row in project.names if row[0] == "Phases")
    phase_name_row.remove(rejected)
    for hist in project.histograms():
        hist.data["Reflection Lists"].pop(rejected, None)

    phase_data = project.data["Phases"].pop(renamed_from)
    phase_data["General"]["Name"] = renamed_to
    project.data["Phases"][renamed_to] = phase_data
    phase_name_row[phase_name_row.index(renamed_from)] = renamed_to
    for hist in project.histograms():
        refl = hist.data["Reflection Lists"]
        refl[renamed_to] = refl.pop(renamed_from)

    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    project.update_ids()
    project.save()

    # Reopen now so malformed phase/name/reflection bookkeeping fails before
    # any refinement is started.
    check = G2.G2Project(gpxfile=str(DEST))
    assert [p.name for p in check.phases()] == [
        "stolzite", "WO3", "massicot", "Pb3O4", "W3O8",
        "alpha_PbO_long_period",
    ]
    assert set(check.histogram(0).data["Reflection Lists"]) == {
        p.name for p in check.phases()
    }
    print(DEST)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
