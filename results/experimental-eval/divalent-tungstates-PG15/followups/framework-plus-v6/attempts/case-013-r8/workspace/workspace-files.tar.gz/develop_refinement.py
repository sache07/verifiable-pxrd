#!/usr/bin/env python3
"""Build clean, comparable six-phase GSAS-II refinement branches.

This starts from the accepted inventory project but removes every exploratory
size/strain/texture flag and all frozen variables.  It is intended to establish
one angular correction and a nonnegative common profile before phase-specific
terms are tested.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


START_SIZES = {
    "stolzite": 0.080,
    "WO3": 0.075,
    "massicot": 0.045,
    "litharge": 0.040,
    "Pb3O4": 0.040,
    "W3O8": 0.040,
    "massicot_alt": 0.060,
    "alpha_PbO_long_period": 0.060,
}


def set_bound(project, variable, low, high):
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def clean_project(project, angular):
    project.set_Controls("cycles", 10)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}

    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    for key in inst:
        if isinstance(inst[key], list) and len(inst[key]) > 2:
            inst[key][2] = False
    for key, val in [("U", 10.0), ("V", 0.0), ("W", 15.0),
                     ("X", 1.0), ("Y", 0.0), ("Z", 0.0), ("SH/L", 0.03)]:
        inst[key][1] = val
    inst["Zero"][1] = 0.0 if angular == "shift" else 0.30

    sample = hist.SampleParameters
    for key, value in sample.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (bool, np.bool_)):
            value[1] = False
    sample["Shift"] = [0.0, angular == "shift"]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    sample["Gonio. radius"] = 200.0
    hist.Background[0][1] = True

    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""
            atom.uiso = 0.01
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Extinction"] = [0.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = START_SIZES[phase.name]
        hap["Size"][1][1] = START_SIZES[phase.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        set_bound(project, f"{phase.data['pId']}:{hist.id}:Scale", 0.0, 100.0)

    if angular == "zero":
        inst["Zero"][2] = True
        set_bound(project, f":{hist.id}:Zero", -0.6, 0.6)
    elif angular == "shift":
        set_bound(project, f":{hist.id}:Shift", -800.0, 800.0)
    else:
        raise ValueError(angular)


def stage_summary(project, stage):
    hist = project.histogram(0)
    arr = hist.data["data"][1]
    x, obs, calc, bkg = map(lambda z: np.asarray(z, float), (arr[0], arr[1], arr[3], arr[4]))
    w = 1.0 / np.maximum(obs, 1.0)
    denom = np.sum(w * obs**2)
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(0.0, mass_scale))
        phases.append({
            "name": phase.name,
            "mass_scale": mass_scale,
            "size_um": float(hap["Size"][1][0]),
            "strain_ppm": float(hap["Mustrain"][1][0]),
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:8]],
        })
    total = sum(masses)
    for row, value in zip(phases, masses):
        row["weight_fraction"] = value / total
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    result = {
        "stage": stage,
        "rwp_percent": float(100 * np.sqrt(np.sum(w * (obs - calc)**2) / denom)),
        "rwp_gsas_percent": float(hist.get_wR()),
        "background_min": float(np.min(bkg)),
        "background_max": float(np.max(bkg)),
        "instrument": {k: float(inst[k][1]) for k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]},
        "sample": {k: float(sample[k][0]) for k in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]},
        "phases": phases,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }
    print(stage, f"Rwp={result['rwp_percent']:.5f}",
          f"zero={result['instrument']['Zero']:.5f}", f"shift={result['sample']['Shift']:.2f}",
          " ".join(f"{r['name']}={r['weight_fraction']:.4f}" for r in phases), flush=True)
    return result


def run(project, stage, log, repeats=1):
    for _ in range(repeats):
        project.refine(makeBack=False)
    project.save()
    log.append(stage_summary(project, stage))


def set_cell_bounds(project, phase, frac=0.025):
    avec = G2lat.cell2A(phase.data["General"]["Cell"][1:7])
    for i, val in enumerate(avec):
        if i < 3:
            lo, hi = sorted(((1 - frac) * float(val), (1 + frac) * float(val)))
        else:
            lo, hi = float(val) - 0.002, float(val) + 0.002
        set_bound(project, f"{phase.data['pId']}::A{i}", lo, hi)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default=".tmp/challenge_pb3o4_w3o8/pb3o4_w3o8.gpx")
    ap.add_argument("--angular", choices=["zero", "shift"], required=True)
    ap.add_argument("--tag", required=True)
    args = ap.parse_args()

    out = Path(".tmp") / args.tag
    out.mkdir(parents=True, exist_ok=True)
    gpx = out / f"{args.tag}.gpx"
    project = G2.G2Project(gpxfile=args.source, newgpx=str(gpx))
    clean_project(project, args.angular)
    project.save()
    log = [stage_summary(project, "clean_start")]

    # Reconverge smooth background, all scales and the single angular correction.
    run(project, "background_scales_angular", log, repeats=3)

    # Revisit every cell under the accepted inventory, then replay them jointly.
    for phase in project.phases():
        set_cell_bounds(project, phase)
        phase.set_refinements({"Cell": True})
        run(project, f"cell_{phase.name}", log)
        phase.clear_refinements({"Cell": True})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, "cells_joint", log, repeats=2)
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})

    # Common profile with physical nonnegative bounds; phase sizes remain fixed.
    hist = project.histogram(0)
    for key, low, high in [("W", 2.0, 40.0), ("U", 0.0, 40.0), ("X", 0.1, 6.0)]:
        hist.InstrumentParameters[key][2] = True
        set_bound(project, f":{hist.id}:{key}", low, high)
        run(project, f"profile_{key}", log)
    hist.InstrumentParameters["SH/L"][2] = True
    set_bound(project, f":{hist.id}:SH/L", 0.005, 0.10)
    run(project, "profile_SHL", log, repeats=2)
    run(project, "common_profile_replay", log, repeats=2)

    arr = project.histogram(0).data["data"][1]
    np.savetxt(out / "profile.csv", np.column_stack((arr[0], arr[1], arr[3], arr[5], arr[4])),
               delimiter=",", header="two_theta_deg,observed,calculated,difference,background", comments="")
    (out / "summary.json").write_text(json.dumps(log, indent=2) + "\n")
    project.save()


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
