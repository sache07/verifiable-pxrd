#!/usr/bin/env python3
"""Challenge a candidate phase under the accepted common profile and texture."""

from __future__ import annotations

import argparse,json
from pathlib import Path
import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

COD=Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
def cif(cid):return COD/cid[0]/cid[1:3]/cid[3:5]/f'{cid}.cif'
def bound(p,v,lo,hi):p.set_Controls('parmMin',float(lo),variable=v);p.set_Controls('parmMax',float(hi),variable=v)
def snap(p,stage):
 h=p.histogram(0);a=h.data['data'][1];y=np.asarray(a[1]);c=np.asarray(a[3]);w=1/np.maximum(y,1)
 rows=[];m=[]
 for q in p.phases():
  hap=q.data['Histograms'][h.name];z=float(q.data['General']['Mass']*hap['Scale'][0]);m.append(max(0,z));rows.append({'name':q.name,'scale':float(hap['Scale'][0]),'cell':list(map(float,q.data['General']['Cell'][1:8]))})
 for r,z in zip(rows,m):r['weight_fraction']=z/sum(m)
 return {'stage':stage,'rwp_percent':float(100*np.sqrt(np.sum(w*(y-c)**2)/np.sum(w*y*y))),'phases':rows,'frozen':[str(v) for v in p.data['Controls']['data'].get('parmFrozen',{}).get('FrozenList',[])]}
def run(p,n):
 for _ in range(n):p.refine(makeBack=False)
 p.save()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',default='.tmp/tex_massicot_100/tex_massicot_100.gpx');ap.add_argument('--candidate',required=True);ap.add_argument('--tag',required=True);args=ap.parse_args()
 name,cid=args.candidate.split('=',1);out=Path('.tmp')/args.tag;out.mkdir(parents=True,exist_ok=True);p=G2.G2Project(gpxfile=args.source,newgpx=str(out/f'{args.tag}.gpx'))
 p.set_Controls('cycles',12);ctrl=p.data['Controls']['data'];ctrl['parmFrozen']={'FrozenList':[]};ctrl['parmMinDict']={};ctrl['parmMaxDict']={};p.data['Constraints']['data']['Phase']=[];h=p.histogram(0)
 for key in ['Zero','U','V','W','X','Y','Z','SH/L','Polariz.']:h.InstrumentParameters[key][2]=False
 h.SampleParameters['Shift'][1]=True;bound(p,f':{h.id}:Shift',-800,800);h.Background[0][1]=True
 for q in p.phases():
  q.clear_refinements({'Cell':True});hap=q.data['Histograms'][h.name];hap['Scale'][1]=True;bound(p,f"{q.data['pId']}:{h.id}:Scale",0,100)
  for at in q.atoms():at.refinement_flags='';at.uiso=.01
  if q.name=='massicot':hap['Pref.Ori.'][2]=True;bound(p,f"{q.data['pId']}:{h.id}:MD",.7,1.4)
  else:hap['Pref.Ori.'][1]=1.;hap['Pref.Ori.'][2]=False
 q=p.add_phase(str(cif(cid)),phasename=name,histograms=[h],fmthint='CIF');hap=q.data['Histograms'][h.name];hap['Scale']=[.05,True];hap['Size'][0]='isotropic';hap['Size'][1][0]=.06;hap['Size'][1][1]=.06;hap['Size'][2]=[False]*len(hap['Size'][2]);hap['Mustrain'][0]='isotropic';hap['Mustrain'][1][0]=0.;hap['Mustrain'][1][1]=0.;hap['Mustrain'][2]=[False]*len(hap['Mustrain'][2]);hap['Pref.Ori.'][1]=1.;hap['Pref.Ori.'][2]=False;hap['Extinction']=[0.,False]
 for at in q.atoms():at.refinement_flags='';at.uiso=.01
 bound(p,f"{q.data['pId']}:{h.id}:Scale",0,100);p.save();run(p,3);log=[snap(p,'fixed_cell')]
 q.set_refinements({'Cell':True});A=G2lat.cell2A(q.data['General']['Cell'][1:7])
 for i,v in enumerate(A):
  if abs(v)<1e-9:lo,hi=-.002,.002
  elif i<3:lo,hi=sorted((.97*v,1.03*v))
  else:lo,hi=v-.002,v+.002
  bound(p,f"{q.data['pId']}::A{i}",lo,hi)
 run(p,2);q.clear_refinements({'Cell':True});ctrl['parmFrozen']={'FrozenList':[]};run(p,1);log.append(snap(p,'cell_replay'));print(json.dumps(log[-1],indent=2),flush=True)
 a=h.data['data'][1];np.savetxt(out/'profile.csv',np.column_stack((a[0],a[1],a[3],a[5],a[4])),delimiter=',',header='two_theta_deg,observed,calculated,difference,background',comments='');(out/'summary.json').write_text(json.dumps(log,indent=2)+'\n');p.save()
if __name__=='__main__':G2.SetPrintLevel('warn');main()
