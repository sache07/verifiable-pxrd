#!/usr/bin/env python3
"""Rebuild the common profile after accepted relative phase-width changes."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/final_profile6/final_profile6.gpx")
OUTDIR = Path(".tmp/width6")
GPX = OUTDIR / "width6.gpx"

# Absolute size is covariant with instrumental X. These fixed values define an
# effective-width gauge; only the within-gauge relative changes were tested.
SIZES = {
    "stolzite": 0.08354,
    "WO3": 0.075,
    "massicot": 0.040,
    "Pb3O4": 0.040,
    "W3O8": 0.040,
    "alpha_PbO_long_period": 0.040,
}


def bound(p, v, lo, hi):
    p.set_Controls("parmMin", float(lo), variable=v)
    p.set_Controls("parmMax", float(hi), variable=v)


def configure(p):
    p.set_Controls("cycles", 12)
    ctrl = p.data["Controls"]["data"]
    ctrl["parmFrozen"] = {"FrozenList": []}
    ctrl["parmMinDict"] = {}
    ctrl["parmMaxDict"] = {}
    p.data["Constraints"]["data"]["Phase"] = []
    h = p.histogram(0)
    for key, item in h.InstrumentParameters.items():
        if isinstance(item, list) and len(item) > 2:
            item[2] = False
    for key, lo, hi in [("U",0,40),("W",2,40),("X",.1,6),("SH/L",.005,.1)]:
        h.InstrumentParameters[key][2] = True
        bound(p, f":{h.id}:{key}", lo, hi)
    h.InstrumentParameters["Zero"][1] = 0.0
    h.Background[0][1] = True
    for key, item in h.SampleParameters.items():
        if isinstance(item, list) and len(item)>1 and isinstance(item[1], (bool,np.bool_)):
            item[1] = False
    h.SampleParameters["Shift"][1] = True
    bound(p, f":{h.id}:Shift", -800, 800)
    for q in p.phases():
        q.clear_refinements({"Cell": True})
        for atom in q.atoms():
            atom.refinement_flags = ""
            atom.uiso = .01
        hap = q.data["Histograms"][h.name]
        hap["Scale"][1] = True
        bound(p, f"{q.data['pId']}:{h.id}:Scale", 0, 100)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = hap["Size"][1][1] = SIZES[q.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][0] = "MD"
        if q.name == "massicot":
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [1,0,0]
            bound(p, f"{q.data['pId']}:{h.id}:MD", .7, 1.4)
        else:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False


def snap(p, stage):
    h=p.histogram(0);a=h.data["data"][1]
    y,c,b=(np.asarray(a[i],float) for i in (1,3,4));w=1/np.maximum(y,1)
    rows=[];m=[]
    for q in p.phases():
        hap=q.data["Histograms"][h.name];z=float(q.data["General"]["Mass"]*hap["Scale"][0]);m.append(max(0,z))
        rows.append({"name":q.name,"size_um":float(hap["Size"][1][0]),"mass_scale":z,
                     "md_ratio":float(hap["Pref.Ori."][1])})
    for r,z in zip(rows,m):r["weight_fraction"]=z/sum(m)
    cov=p.data.get("Covariance",{}).get("data",{});rv=cov.get("Rvals",{})
    out={"stage":stage,"rwp_percent":float(100*np.sqrt(np.sum(w*(y-c)**2)/np.sum(w*y*y))),
         "background_min":float(b.min()),"background_max":float(b.max()),
         "instrument":{k:float(h.InstrumentParameters[k][1]) for k in ["U","W","X","SH/L"]},
         "shift_micrometers":float(h.SampleParameters["Shift"][0]),
         "max_shift_over_esd":float(rv.get("Max shft/sig",np.nan)),"phases":rows,
         "vary_list":list(cov.get("varyList",[])),"sigmas":[float(x) for x in cov.get("sig",[])],
         "frozen":[str(v) for v in p.data["Controls"]["data"].get("parmFrozen",{}).get("FrozenList",[])]}
    print(stage,out["rwp_percent"],out["instrument"],out["max_shift_over_esd"],flush=True);return out


def main():
    OUTDIR.mkdir(parents=True,exist_ok=True)
    p=G2.G2Project(gpxfile=str(SOURCE),newgpx=str(GPX));configure(p);p.save();log=[snap(p,"configured")]
    for i in range(4):
        p.refine(makeBack=False);p.save();log.append(snap(p,f"common_profile_{i+1}"))
    p=G2.G2Project(gpxfile=str(GPX));configure(p);p.refine(makeBack=False);p.save();log.append(snap(p,"reopened_replay"))
    a=p.histogram(0).data["data"][1]
    np.savetxt(OUTDIR/"profile.csv",np.column_stack((a[0],a[1],a[3],a[5],a[4])),delimiter=",",
               header="two_theta_deg,observed,calculated,difference,background",comments="")
    (OUTDIR/"summary.json").write_text(json.dumps(log,indent=2)+"\n")


if __name__=="__main__":
    G2.SetPrintLevel("warn");main()
