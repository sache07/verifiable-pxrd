#!/usr/bin/env python3
"""Re-challenge a weak phase under one restrained, replayable profile model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutral_hap(phase, histname, scale, size):
    hap = phase.data["Histograms"][histname]
    hap["Scale"] = [float(scale), True]
    hap["Extinction"] = [0.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = float(size)
    hap["Size"][1][1] = float(size)
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def summarize(project, stage, y):
    hist = project.histogram(0)
    data = hist.data["data"][1]
    calc = np.asarray(data[3], float)
    w = 1 / np.maximum(y, 1.0)
    total = 0.0
    rows = []
    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        ms = float(p.data["General"]["Mass"] * hap["Scale"][0])
        total += max(ms, 0.0)
        rows.append(
            {
                "name": p.name,
                "mass_scale": ms,
                "scale": float(hap["Scale"][0]),
                "size_um": float(hap["Size"][1][0]),
                "strain_ppm": float(hap["Mustrain"][1][0]),
                "cell": [float(v) for v in p.data["General"]["Cell"][1:8]],
            }
        )
    for row in rows:
        row["weight_fraction"] = max(row["mass_scale"], 0.0) / total
    result = {
        "stage": stage,
        "rwp_percent": float(100 * np.sqrt(np.sum(w * (y - calc) ** 2) / np.sum(w * y**2))),
        "phases": rows,
        "instrument": {
            key: float(hist.data["Instrument Parameters"][0][key][1])
            for key in ["Zero", "U", "W", "X", "SH/L"]
        },
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }
    print(
        stage,
        f"Rwp={result['rwp_percent']:.5f}",
        " ".join(f"{r['name']}={r['weight_fraction']:.4f}@{r['size_um']:.4g}um" for r in rows),
        flush=True,
    )
    return result


def run(project, stage, y, log, repeats=1):
    for _ in range(repeats):
        project.refine(makeBack=False)
    project.save()
    log.append(summarize(project, stage, y))


def bounds(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--candidate", help="NAME=COD_ID; omit for the common-profile control")
    args = ap.parse_args()

    out = Path(".tmp") / f"challenge_{args.tag}"
    out.mkdir(parents=True, exist_ok=True)
    gpx = out / f"{args.tag}.gpx"
    project = G2.G2Project(gpxfile=args.source, newgpx=str(gpx))
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key, value in [("U", 10.0), ("W", 15.0), ("X", 1.0), ("SH/L", 0.03)]:
        inst[key][1] = value
        inst[key][2] = False

    starting_sizes = {
        "stolzite": 0.080,
        "WO3": 0.075,
        "massicot": 0.045,
        "litharge": 0.040,
        "Pb3O4": 0.040,
        "W3O8": 0.040,
    }
    for p in project.phases():
        neutral_hap(p, hist.name, p.data["Histograms"][hist.name]["Scale"][0], starting_sizes[p.name])
        p.clear_refinements({"Cell": True})
        bounds(project, f"{p.data['pId']}:{hist.id}:Scale", 0.0, 100.0)

    candidate_name = None
    if args.candidate:
        candidate_name, cod_id = args.candidate.split("=", 1)
        p = project.add_phase(str(cif_path(cod_id)), phasename=candidate_name, histograms=[hist], fmthint="CIF")
        neutral_hap(p, hist.name, 0.05, 0.08)
        p.clear_refinements({"Cell": True})
        bounds(project, f"{p.data['pId']}:{hist.id}:Scale", 0.0, 100.0)

    # Keep one angular correction and the same smooth background/scales/cells.
    inst["Zero"][2] = True
    hist.data["Background"][0][1] = True
    project.save()
    _, y = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1).T
    log = []
    run(project, "candidate_scale_fixed_cell", y, log, repeats=3)

    # Only a positive scale authorizes a modest, bounded source-cell adjustment.
    if candidate_name:
        hist = project.histogram(0)
        p = project.phase(candidate_name)
        p.set_refinements({"Cell": True})
        avec = G2lat.cell2A(p.data["General"]["Cell"][1:7])
        for i, value in enumerate(avec):
            if abs(value) < 1e-12:
                continue
            lo, hi = sorted((0.95 * float(value), 1.05 * float(value)))
            bounds(project, f"{p.data['pId']}::A{i}", lo, hi)
        run(project, "candidate_bounded_cell", y, log, repeats=2)
        p = project.phase(candidate_name)
        p.clear_refinements({"Cell": True})

        hist = project.histogram(0)
        p = project.phase(candidate_name)
        p.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.08, "refine": True}}, [hist])
        bounds(project, f"{p.data['pId']}:{hist.id}:Size;i", 0.04, 10.0)
        run(project, "candidate_size", y, log, repeats=2)

    hist = project.histogram(0)
    arr = hist.data["data"][1]
    np.savetxt(
        out / "profile.csv",
        np.column_stack((arr[0], arr[1], arr[3], arr[5], arr[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )
    (out / "summary.json").write_text(json.dumps(log, indent=2) + "\n")
    project.save()


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
