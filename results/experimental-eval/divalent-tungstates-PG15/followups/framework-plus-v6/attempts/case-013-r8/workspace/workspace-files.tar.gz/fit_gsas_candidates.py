#!/usr/bin/env python3
"""Create comparable baseline GSAS-II fits for candidate phase inventories.

Run with the GSAS-II Python interpreter. The script intentionally keeps all
phase-specific size/strain/texture terms neutral so source records are judged
under one common background, angular correction, and instrumental profile.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, minimum_filter1d

from GSASII import GSASIIscriptable as G2


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_inputs(work: Path) -> tuple[Path, Path, np.ndarray, np.ndarray]:
    work.mkdir(parents=True, exist_ok=True)
    x, y = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1).T
    xye = work / "observed.xye"
    np.savetxt(xye, np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.10g")
    inst = work / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; uncalibrated Cu Kalpha starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.15;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst, x, y


def chebyshev_start(x: np.ndarray, y: np.ndarray, degree: int = 7) -> list[float]:
    # Conservative lower envelope only seeds the refined smooth background.
    baseline = gaussian_filter1d(minimum_filter1d(y, size=301, mode="nearest"), 90)
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, baseline, degree).tolist()


def neutralize_hap(phase, histogram_name: str, initial_scale: float) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Scale"] = [float(initial_scale), False]
    hap["Extinction"] = [0.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1000.0
    hap["Size"][1][1] = 1000.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    if len(hap["Mustrain"]) > 5:
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]


def rwp_from_arrays(hist, y_original: np.ndarray) -> float:
    arr = hist.data["data"][1]
    calc = np.asarray(arr[3], float)
    w = 1 / np.maximum(y_original, 1.0)
    return float(100 * np.sqrt(np.sum(w * (y_original - calc) ** 2) / np.sum(w * y_original**2)))


def summary(project, label: str, y: np.ndarray) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    rows = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(mass_scale, 0.0))
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "mass_scale": mass_scale,
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:8]],
            }
        )
    total = sum(masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = mass / total if total > 0 else None
    result = {
        "stage": label,
        "gsas_wR_percent": hist.get_wR(),
        "poisson_rwp_percent": rwp_from_arrays(hist, y),
        "instrument": {
            key: float(inst[key][1])
            for key in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
            if key in inst
        },
        "sample": {
            key: (float(sample[key][0]) if isinstance(sample.get(key), list) else sample.get(key))
            for key in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
        },
        "phases": rows,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "chisq": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("chisq"),
    }
    print(json.dumps(result, indent=2, default=float), flush=True)
    return result


def run_refine(project, label: str, y: np.ndarray, summaries: list[dict], repeats: int = 1) -> None:
    for _ in range(repeats):
        project.refine(makeBack=False)
    project.save()
    summaries.append(summary(project, label, y))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tag", required=True)
    parser.add_argument(
        "--phase",
        action="append",
        required=True,
        help="Phase specification NAME=COD_ID (repeat for every phase)",
    )
    parser.add_argument("--background-terms", type=int, default=8)
    args = parser.parse_args()

    out = Path(".tmp") / f"fit_{args.tag}"
    xye, instfile, x, y = make_inputs(out)
    gpx = out / f"{args.tag}.gpx"
    if gpx.exists():
        gpx.unlink()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(str(xye), str(instfile), fmthint="xye")
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    phase_specs = []
    for spec in args.phase:
        name, cod_id = spec.split("=", 1)
        phase_specs.append((name, cod_id))
        phase = project.add_phase(
            str(cif_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase, hist.name, initial_scale=1e-4)

    coeffs = chebyshev_start(x, y, degree=args.background_terms - 1)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": coeffs,
                "refine": True,
            }
        }
    )
    project.set_Controls("cycles", 8)
    project.save()

    summaries: list[dict] = [summary(project, "initial", y)]

    # Reversible common baseline: smooth background and all scales first.
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])
    run_refine(project, "background_scales", y, summaries, repeats=2)

    # One common angular correction, followed by symmetry-constrained cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("parmMin", -0.5, variable=":0:Zero")
    project.set_Controls("parmMax", 0.5, variable=":0:Zero")
    run_refine(project, "zero", y, summaries, repeats=2)

    # Cells are released one phase at a time to keep overlapping families from
    # driving an ill-conditioned first step. A joint replay follows.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        run_refine(project, f"cell_{phase.name}", y, summaries, repeats=1)
        phase.clear_refinements({"Cell": True})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run_refine(project, "zero_cells", y, summaries, repeats=1)

    # Establish a nonnegative common instrumental profile. V/Y/Z remain neutral.
    for key, low, high in [("W", 0.0, 40.0), ("X", 0.0, 6.0), ("U", 0.0, 40.0)]:
        hist.set_refinements({"Instrument Parameters": [key]})
        project.set_Controls("parmMin", low, variable=f":0:{key}")
        project.set_Controls("parmMax", high, variable=f":0:{key}")
        run_refine(project, f"profile_{key}", y, summaries, repeats=1)
    run_refine(project, "common_profile", y, summaries, repeats=1)

    # Axial divergence is released only after widths are approximately correct.
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.set_Controls("parmMin", 0.001, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.2, variable=":0:SH/L")
    run_refine(project, "common_profile_asymmetry", y, summaries, repeats=2)

    # Save a complete profile for residual comparison between inventories.
    arr = hist.data["data"][1]
    np.savetxt(
        out / "profile.csv",
        np.column_stack((arr[0], arr[1], arr[3], arr[5], arr[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )
    (out / "summary.json").write_text(json.dumps(summaries, indent=2, default=float) + "\n")
    project.save()


if __name__ == "__main__":
    main()
