#!/usr/bin/env python3
"""Develop phase-specific size/strain terms from a bounded common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def fit_summary(project, stage, y):
    hist = project.histogram(0)
    arr = hist.data["data"][1]
    calc = np.asarray(arr[3], float)
    w = 1 / np.maximum(y, 1.0)
    inst = hist.data["Instrument Parameters"][0]
    rows = []
    total = 0.0
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        total += max(mass_scale, 0.0)
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "mass_scale": mass_scale,
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:8]],
                "size": list(map(float, hap["Size"][1][:2])),
                "mustrain": list(map(float, hap["Mustrain"][1][:2])),
                "size_type": hap["Size"][0],
                "mustrain_type": hap["Mustrain"][0],
            }
        )
    for row in rows:
        row["weight_fraction"] = max(row["mass_scale"], 0.0) / total
    result = {
        "stage": stage,
        "rwp_percent": float(
            100 * np.sqrt(np.sum(w * (y - calc) ** 2) / np.sum(w * y**2))
        ),
        "gsas_wR_percent": hist.get_wR(),
        "instrument": {
            key: float(inst[key][1])
            for key in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
            if key in inst
        },
        "phases": rows,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "frozen": [str(v) for vals in project.data["Controls"]["data"].get("parmFrozen", {}).values() for v in vals],
    }
    print(
        stage,
        f"Rwp={result['rwp_percent']:.4f}",
        "profile=" + ",".join(f"{k}:{result['instrument'][k]:.4g}" for k in ["U", "W", "X", "SH/L"]),
        " | ".join(
            f"{r['name']} wf={r['weight_fraction']:.4f} size={r['size'][0]:.4g} strain={r['mustrain'][0]:.4g}"
            for r in rows
        ),
        flush=True,
    )
    return result


def refine(project, stage, y, log, repeats=1):
    for _ in range(repeats):
        project.refine(makeBack=False)
    project.save()
    log.append(fit_summary(project, stage, y))


def set_bound(project, variable, low, high):
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--tag", required=True)
    parser.add_argument("--include-strain", action="store_true")
    args = parser.parse_args()

    root = Path(".tmp") / f"profiles_{args.tag}"
    root.mkdir(parents=True, exist_ok=True)
    target = root / f"{args.tag}.gpx"
    project = G2.G2Project(gpxfile=args.source, newgpx=str(target))
    project.set_Controls("cycles", 8)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key, value in [("U", 10.0), ("W", 10.0), ("X", 1.0), ("SH/L", 0.03)]:
        inst[key][1] = value
        inst[key][2] = False

    # Preserve the converged inventory/cells/scales but return all phase-width
    # terms to neutral before testing one phase at a time.
    phase_names = [p.name for p in project.phases()]
    for name in phase_names:
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][1][1] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    project.save()

    _, y = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1).T
    log = [fit_summary(project, "reset", y)]

    # Isotropic size is introduced independently for every phase.
    for name in phase_names:
        hist = project.histogram(0)
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][1][0] = 0.30
        hap["Size"][1][1] = 0.30
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.30, "refine": True}}, [hist]
        )
        set_bound(project, f"{phase.data['pId']}:{hist.id}:Size;i", 0.03, 10.0)
        refine(project, f"size_{name}", y, log, repeats=2)

    if args.include_strain:
        # Compare complementary isotropic microstrain from a neutral value.
        for name in phase_names:
            hist = project.histogram(0)
            phase = project.phase(name)
            hap = phase.data["Histograms"][hist.name]
            hap["Mustrain"][1][0] = 800.0
            hap["Mustrain"][1][1] = 800.0
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
            )
            set_bound(project, f"{phase.data['pId']}:{hist.id}:Mustrain;i", 0.0, 10000.0)
            refine(project, f"strain_{name}", y, log, repeats=2)

    # With phase widths represented, re-establish the bounded common profile.
    for key, value, low, high in [
        ("W", 10.0, 0.0, 40.0),
        ("X", 1.0, 0.1, 6.0),
        ("U", 10.0, 0.0, 40.0),
    ]:
        controls = project.data["Controls"]["data"]
        controls["parmFrozen"] = {"FrozenList": []}
        hist = project.histogram(0)
        inst = hist.data["Instrument Parameters"][0]
        inst[key][1] = value
        inst[key][2] = True
        set_bound(project, f":{hist.id}:{key}", low, high)
        refine(project, f"instrument_{key}", y, log, repeats=2)

    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    hist.data["Instrument Parameters"][0]["SH/L"][2] = True
    set_bound(project, f":{hist.id}:SH/L", 0.001, 0.2)
    refine(project, "asymmetry", y, log, repeats=2)

    hist = project.histogram(0)
    arr = hist.data["data"][1]
    np.savetxt(
        root / "profile.csv",
        np.column_stack((arr[0], arr[1], arr[3], arr[5], arr[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )
    (root / "summary.json").write_text(json.dumps(log, indent=2) + "\n")
    project.save()


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
