#!/usr/bin/env python3
"""Test symmetry-constrained coordinate refinement for one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


HEAVY = {"Pb", "W"}


def bound(project, variable, low, high):
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def summary(project, stage):
    hist = project.histogram(0)
    a = hist.data["data"][1]
    obs, calc = np.asarray(a[1]), np.asarray(a[3])
    w = 1 / np.maximum(obs, 1.0)
    phases, masses = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        m = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(m, 0.0))
        phases.append({
            "name": phase.name,
            "coordinates": [{"label": at.label, "element": at.element,
                             "xyz": list(map(float, at.coordinates)),
                             "flags": at.refinement_flags} for at in phase.atoms()],
            "md_ratio": float(hap["Pref.Ori."][1]),
            "md_axis": list(map(int, hap["Pref.Ori."][3])),
        })
    total = sum(masses)
    for p, m in zip(phases, masses):
        p["weight_fraction"] = m / total
    return {
        "stage": stage,
        "rwp_percent": float(100 * np.sqrt(np.sum(w * (obs - calc)**2) / np.sum(w * obs**2))),
        "phases": phases,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }


def run(project, repeats):
    for _ in range(repeats):
        project.refine(makeBack=False)
    project.save()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default=".tmp/tex_massicot_100/tex_massicot_100.gpx")
    ap.add_argument("--phase", required=True)
    ap.add_argument("--mode", choices=["heavy", "light", "all"], required=True)
    ap.add_argument("--bounded", action="store_true", help="limit one coordinate step to the known source-mismatch scale")
    ap.add_argument("--tag", required=True)
    args = ap.parse_args()
    out = Path(".tmp") / args.tag
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.source, newgpx=str(out / f"{args.tag}.gpx"))
    project.set_Controls("cycles", 12)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    project.data["Constraints"]["data"]["Phase"] = []
    hist = project.histogram(0)
    for key in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]:
        hist.InstrumentParameters[key][2] = False
    hist.SampleParameters["Shift"][1] = True
    bound(project, f":{hist.id}:Shift", -800, 800)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        bound(project, f"{phase.data['pId']}:{hist.id}:Scale", 0, 100)
        for atom in phase.atoms():
            atom.uiso = 0.01
            atom.refinement_flags = ""
    # Preserve the accepted massicot [100] texture and no others.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if phase.name == "massicot":
            hap["Pref.Ori."][2] = True
            bound(project, f"{phase.data['pId']}:{hist.id}:MD", 0.7, 1.4)
        else:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
    project.save()
    run(project, 2)
    log = [summary(project, "control")]

    selected = project.phase(args.phase)
    lengths = list(map(float, selected.data["General"]["Cell"][1:4]))
    for atom_index, atom in enumerate(selected.atoms()):
        use = args.mode == "all" or (args.mode == "heavy" and atom.element in HEAVY) or (args.mode == "light" and atom.element not in HEAVY)
        atom.refinement_flags = "X" if use else ""
        if use and args.bounded:
            cart = 0.04 if atom.element in HEAVY else 0.05
            # Component bounds imply a displacement no larger than the stated
            # Cartesian source-mismatch scale for an orthogonal cell. They are
            # slightly conservative for the monoclinic WO3 cell.
            for axis, length, center in zip("xyz", lengths, atom.coordinates):
                delta = cart / (np.sqrt(3.0) * length)
                # GSAS-II applies coordinate limits to the mapped absolute
                # coordinate even though the refinement variable is named dA.
                bound(project, f"{selected.data['pId']}::dA{axis}:{atom_index}", center - delta, center + delta)
    run(project, 1 if args.bounded else 3)
    if args.bounded:
        # Coordinate shifts are transferred into the atom table after a
        # refinement. Hold them and reconverge nuisance terms without allowing
        # repeated bounded steps to accumulate.
        for atom in selected.atoms():
            atom.refinement_flags = ""
        controls["parmFrozen"] = {"FrozenList": []}
        run(project, 2)
    log.append(summary(project, "candidate"))
    print(json.dumps(log[-1], indent=2), flush=True)
    a = project.histogram(0).data["data"][1]
    np.savetxt(out / "profile.csv", np.column_stack((a[0], a[1], a[3], a[5], a[4])), delimiter=",",
               header="two_theta_deg,observed,calculated,difference,background", comments="")
    (out / "summary.json").write_text(json.dumps(log, indent=2) + "\n")
    project.save()


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
