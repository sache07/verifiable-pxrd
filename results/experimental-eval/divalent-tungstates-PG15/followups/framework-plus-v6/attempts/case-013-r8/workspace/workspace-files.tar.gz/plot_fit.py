#!/usr/bin/env python3
"""Plot a GSAS-II exported observed/calculated/background profile by ranges."""

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


parser = argparse.ArgumentParser()
parser.add_argument("profile")
parser.add_argument("--out")
args = parser.parse_args()

d = np.loadtxt(args.profile, delimiter=",", skiprows=1)
x, obs, calc, diff, bg = d.T
fig, axes = plt.subplots(3, 1, figsize=(16, 11), constrained_layout=True)
for ax, (lo, hi) in zip(axes, [(10, 40), (40, 70), (70, 100)]):
    m = (x >= lo) & (x <= hi)
    ax.plot(x[m], obs[m], color="black", lw=0.55, label="observed")
    ax.plot(x[m], calc[m], color="tab:red", lw=0.75, label="calculated")
    ax.plot(x[m], bg[m], color="tab:orange", lw=0.55, label="background")
    ax.plot(x[m], diff[m], color="tab:blue", lw=0.5, label="difference")
    ax.axhline(0, color="0.6", lw=0.4)
    ax.set_xlim(lo, hi)
    ax.set_ylabel("Counts")
    ax.grid(alpha=0.12)
axes[0].legend(ncol=4, fontsize=8)
axes[-1].set_xlabel(r"$2\theta$ (degrees)")
out = args.out or str(Path(args.profile).with_suffix(".png"))
fig.savefig(out, dpi=170)
