#!/usr/bin/env python3
"""Test one phase-specific profile or March-Dollase term on a clean branch."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def bound(project, variable, low, high):
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def snapshot(project, stage):
    hist = project.histogram(0)
    a = hist.data["data"][1]
    obs, calc = np.asarray(a[1]), np.asarray(a[3])
    w = 1 / np.maximum(obs, 1.0)
    rows, masses = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(0.0, mass))
        rows.append({
            "name": phase.name,
            "scale": float(hap["Scale"][0]),
            "size_type": hap["Size"][0],
            "size": [float(x) for x in hap["Size"][1][:2]],
            "strain_type": hap["Mustrain"][0],
            "strain": [float(x) for x in hap["Mustrain"][1][:2]],
            "strain_axis": list(map(int, hap["Mustrain"][3])),
            "md_ratio": float(hap["Pref.Ori."][1]),
            "md_axis": list(map(int, hap["Pref.Ori."][3])),
        })
    total = sum(masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = mass / total
    return {
        "stage": stage,
        "rwp_percent": float(100 * np.sqrt(np.sum(w * (obs - calc)**2) / np.sum(w * obs**2))),
        "phases": rows,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }


def run(project, repeats=1):
    for _ in range(repeats):
        project.refine(makeBack=False)
    project.save()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default=".tmp/develop_shift/develop_shift.gpx")
    ap.add_argument("--phase", required=True)
    ap.add_argument("--effect", choices=["size", "strain_iso", "size_strain", "strain_axis", "texture"], required=True)
    ap.add_argument("--axis", nargs=3, type=int, default=[0, 0, 1])
    ap.add_argument("--tag", required=True)
    args = ap.parse_args()

    out = Path(".tmp") / args.tag
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.source, newgpx=str(out / f"{args.tag}.gpx"))
    project.set_Controls("cycles", 10)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    project.data["Constraints"]["data"]["Phase"] = []
    hist = project.histogram(0)
    for key in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]:
        hist.InstrumentParameters[key][2] = False
    hist.SampleParameters["Shift"][1] = True
    bound(project, f":{hist.id}:Shift", -800, 800)
    hist.Background[0][1] = True

    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.uiso = 0.01
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        bound(project, f"{phase.data['pId']}:{hist.id}:Scale", 0, 100)
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        # Preserve the accepted massicot texture while width terms are tested.
        # A texture challenge itself starts all phases from neutral texture.
        if args.effect == "texture":
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
        elif phase.name == "massicot" and hap["Pref.Ori."][3] == [1, 0, 0]:
            hap["Pref.Ori."][2] = True
            bound(project, f"{phase.data['pId']}:{hist.id}:MD", 0.7, 1.4)
        else:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False

    project.save()
    run(project, repeats=2)
    log = [snapshot(project, "control")]
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    pid, hid = phase.data["pId"], hist.id
    axis = list(args.axis)
    if args.effect == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.20
        hap["Size"][1][1] = 0.20
        hap["Size"][2][0] = True
        bound(project, f"{pid}:{hid}:Size;i", 0.04, 1.5)
    elif args.effect in ("strain_iso", "size_strain"):
        if args.effect == "size_strain":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 0.20
            hap["Size"][1][1] = 0.20
            hap["Size"][2][0] = True
            bound(project, f"{pid}:{hid}:Size;i", 0.04, 1.5)
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 4000.0 if args.effect == "size_strain" else 1000.0
        hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
        hap["Mustrain"][2][0] = True
        bound(project, f"{pid}:{hid}:Mustrain;i", 0.0, 8000.0)
    elif args.effect == "strain_axis":
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1500.0
        hap["Mustrain"][3] = axis
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        bound(project, f"{pid}:{hid}:Mustrain;i", 0.0, 8000.0)
        bound(project, f"{pid}:{hid}:Mustrain;a", 0.0, 8000.0)
    else:
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.05
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        bound(project, f"{pid}:{hid}:MD", 0.7, 1.4)

    run(project, repeats=3)
    log.append(snapshot(project, "candidate"))
    print(json.dumps(log[-1], indent=2), flush=True)
    a = project.histogram(0).data["data"][1]
    np.savetxt(out / "profile.csv", np.column_stack((a[0], a[1], a[3], a[5], a[4])), delimiter=",",
               header="two_theta_deg,observed,calculated,difference,background", comments="")
    (out / "summary.json").write_text(json.dumps(log, indent=2) + "\n")
    project.save()


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
