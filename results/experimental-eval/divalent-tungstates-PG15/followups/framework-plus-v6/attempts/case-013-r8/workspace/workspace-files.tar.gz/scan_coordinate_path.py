#!/usr/bin/env python3
"""Scan a physically bounded path from a source to an unconstrained coordinate fit."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


HEAVY = {"Pb", "W"}


def bound(p, var, lo, hi):
    p.set_Controls("parmMin", float(lo), variable=var)
    p.set_Controls("parmMax", float(hi), variable=var)


def rwp(p):
    a=p.histogram(0).data['data'][1];y=np.asarray(a[1]);c=np.asarray(a[3]);w=1/np.maximum(y,1)
    return float(100*np.sqrt(np.sum(w*(y-c)**2)/np.sum(w*y*y)))


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source',default='.tmp/tex_massicot_100/tex_massicot_100.gpx')
    ap.add_argument('--unconstrained',required=True)
    ap.add_argument('--phase',required=True)
    ap.add_argument('--mode',choices=['heavy','light','all'],required=True)
    ap.add_argument('--radii',default='0,0.01,0.02,0.03,0.04')
    ap.add_argument('--tag',required=True)
    args=ap.parse_args(); radii=[float(x) for x in args.radii.split(',')]
    out=Path('.tmp')/args.tag;out.mkdir(parents=True,exist_ok=True)

    src=G2.G2Project(gpxfile=args.source); unc=G2.G2Project(gpxfile=args.unconstrained)
    ps=src.phase(args.phase); pu=unc.phase(args.phase)
    cell=np.asarray(ps.data['General']['Cell'][1:7],float)
    from GSASII import GSASIIlattice as G2lat
    amat=np.asarray(G2lat.cell2AB(cell)[0],float).T
    selected=[]; weighted=[]
    for i,(a,b) in enumerate(zip(ps.atoms(),pu.atoms())):
        use=args.mode=='all' or (args.mode=='heavy' and a.element in HEAVY) or (args.mode=='light' and a.element not in HEAVY)
        d=np.asarray(b.coordinates)-np.asarray(a.coordinates);d-=np.rint(d)
        if use and np.linalg.norm(d)>0:
            selected.append((i,d));weighted.append((a.mult,float(np.linalg.norm(amat@d))))
    direction_rms=float(np.sqrt(sum(m*d*d for m,d in weighted)/sum(m for m,d in weighted)))
    if direction_rms<=0:raise ValueError('selected path has zero displacement')

    log=[]
    for radius in radii:
        tag=f"r{radius:.3f}".replace('.','p')
        p=G2.G2Project(gpxfile=args.source,newgpx=str(out/f'{tag}.gpx'))
        p.set_Controls('cycles',12);ctrl=p.data['Controls']['data'];ctrl['parmFrozen']={'FrozenList':[]};ctrl['parmMinDict']={};ctrl['parmMaxDict']={}
        p.data['Constraints']['data']['Phase']=[];h=p.histogram(0)
        for key in ['Zero','U','V','W','X','Y','Z','SH/L','Polariz.']:h.InstrumentParameters[key][2]=False
        h.SampleParameters['Shift'][1]=True;bound(p,f':{h.id}:Shift',-800,800);h.Background[0][1]=True
        for q in p.phases():
            q.clear_refinements({'Cell':True});hap=q.data['Histograms'][h.name];hap['Scale'][1]=True;bound(p,f"{q.data['pId']}:{h.id}:Scale",0,100)
            for at in q.atoms():at.refinement_flags='';at.uiso=.01
            if q.name=='massicot':hap['Pref.Ori.'][2]=True;bound(p,f"{q.data['pId']}:{h.id}:MD",.7,1.4)
            else:hap['Pref.Ori.'][1]=1.;hap['Pref.Ori.'][2]=False
        q=p.phase(args.phase); factor=radius/direction_rms
        for i,d in selected:
            a=q.atoms()[i];a.coordinates=(np.asarray(a.coordinates)+factor*d).tolist()
        p.save();p.refine(makeBack=False);p.save()
        masses=[max(0,float(q.data['General']['Mass']*q.data['Histograms'][h.name]['Scale'][0])) for q in p.phases()]
        row={'radius_A':radius,'path_factor':factor,'rwp_percent':rwp(p),
             'fractions':{q.name:m/sum(masses) for q,m in zip(p.phases(),masses)},
             'coordinates':[{'label':a.label,'element':a.element,'xyz':list(map(float,a.coordinates))} for a in p.phase(args.phase).atoms()],
             'frozen':[str(v) for v in ctrl.get('parmFrozen',{}).get('FrozenList',[])]}
        print(args.phase,row['radius_A'],row['rwp_percent'],flush=True);log.append(row)
    (out/'summary.json').write_text(json.dumps({'phase':args.phase,'mode':args.mode,'direction_rms_A':direction_rms,'results':log},indent=2)+'\n')


if __name__=='__main__':G2.SetPrintLevel('warn');main()
