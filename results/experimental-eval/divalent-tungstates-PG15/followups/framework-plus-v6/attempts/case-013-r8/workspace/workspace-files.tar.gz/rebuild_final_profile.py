#!/usr/bin/env python3
"""Rebuild and replay the accepted six-phase common-profile model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/tex6_massicot_100/tex6_massicot_100.gpx")
OUTDIR = Path(".tmp/final_profile6")
GPX = OUTDIR / "final_profile6.gpx"


def bound(project, variable, low, high):
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def snapshot(project, stage):
    hist = project.histogram(0)
    arr = hist.data["data"][1]
    obs, calc, bkg = (np.asarray(arr[i], float) for i in (1, 3, 4))
    w = 1.0 / np.maximum(obs, 1.0)
    rows, mass_scales = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        mass_scales.append(max(0.0, mass_scale))
        rows.append({
            "name": phase.name,
            "mass_scale": mass_scale,
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:8]],
            "md_ratio": float(hap["Pref.Ori."][1]),
            "md_axis": [int(v) for v in hap["Pref.Ori."][3]],
        })
    total = sum(mass_scales)
    for row, value in zip(rows, mass_scales):
        row["weight_fraction"] = value / total
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    inst = hist.InstrumentParameters
    result = {
        "stage": stage,
        "rwp_percent": float(100 * np.sqrt(np.sum(w * (obs-calc)**2) / np.sum(w * obs**2))),
        "rp_percent": float(100 * np.sum(np.abs(obs-calc)) / np.sum(obs)),
        "gsas_rwp_percent": float(hist.get_wR()),
        "chi_square": float(rvals.get("chisq", np.nan)),
        "goodness_of_fit": float(rvals.get("GOF", np.nan)),
        "max_shift_over_esd": float(rvals.get("Max shft/sig", np.nan)),
        "background_min": float(np.min(bkg)),
        "background_max": float(np.max(bkg)),
        "shift_micrometers": float(hist.SampleParameters["Shift"][0]),
        "instrument": {k: float(inst[k][1]) for k in ["U", "V", "W", "X", "Y", "Z", "SH/L"]},
        "phases": rows,
        "vary_list": list(cov.get("varyList", [])),
        "sigmas": [float(v) for v in cov.get("sig", [])],
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }
    print(stage, json.dumps({
        "Rwp": result["rwp_percent"], "GOF": result["goodness_of_fit"],
        "max_shift/esd": result["max_shift_over_esd"],
        "fractions": {r["name"]: r["weight_fraction"] for r in rows},
    }), flush=True)
    return result


def configure(project):
    project.set_Controls("cycles", 12)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    project.data["Constraints"]["data"]["Phase"] = []

    hist = project.histogram(0)
    for key in hist.InstrumentParameters:
        item = hist.InstrumentParameters[key]
        if isinstance(item, list) and len(item) > 2:
            item[2] = False
    for key, low, high in [("U", 0.0, 40.0), ("W", 2.0, 40.0),
                           ("X", 0.1, 6.0), ("SH/L", 0.005, 0.10)]:
        hist.InstrumentParameters[key][2] = True
        bound(project, f":{hist.id}:{key}", low, high)
    hist.InstrumentParameters["Zero"][1] = 0.0
    hist.Background[0][1] = True
    for key, item in hist.SampleParameters.items():
        if isinstance(item, list) and len(item) > 1 and isinstance(item[1], (bool, np.bool_)):
            item[1] = False
    hist.SampleParameters["Shift"][1] = True
    bound(project, f":{hist.id}:Shift", -800.0, 800.0)

    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""
            atom.uiso = 0.01
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        bound(project, f"{phase.data['pId']}:{hist.id}:Scale", 0.0, 100.0)
        hap["Extinction"] = [0.0, False]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][0] = "MD"
        if phase.name == "massicot":
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [1, 0, 0]
            bound(project, f"{phase.data['pId']}:{hist.id}:MD", 0.7, 1.4)
        else:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False


def main():
    OUTDIR.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(GPX))
    configure(project)
    project.save()
    log = [snapshot(project, "configured")]
    for i in range(3):
        project.refine(makeBack=False)
        project.save()
        log.append(snapshot(project, f"common_profile_{i+1}"))

    # A save/reopen/full-range replay is the final stability test.
    project = G2.G2Project(gpxfile=str(GPX))
    configure(project)
    project.refine(makeBack=False)
    project.save()
    log.append(snapshot(project, "reopened_replay"))

    arr = project.histogram(0).data["data"][1]
    np.savetxt(OUTDIR / "profile.csv",
               np.column_stack((arr[0], arr[1], arr[3], arr[5], arr[4])),
               delimiter=",", header="two_theta_deg,observed,calculated,difference,background",
               comments="")
    (OUTDIR / "summary.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
