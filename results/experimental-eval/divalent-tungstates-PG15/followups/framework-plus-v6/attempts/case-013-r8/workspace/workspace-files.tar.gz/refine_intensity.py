#!/usr/bin/env python3
"""Refine cells and phase-wise isotropic ADPs under a fixed common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def bound(project, variable, low, high):
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def summarize(project, stage):
    hist = project.histogram(0)
    a = hist.data["data"][1]
    obs, calc, bkg = np.asarray(a[1]), np.asarray(a[3]), np.asarray(a[4])
    w = 1 / np.maximum(obs, 1.0)
    masses, rows = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(0.0, mass))
        rows.append({
            "name": phase.name,
            "uiso_A2": [float(at.uiso) for at in phase.atoms()],
            "cell": [float(x) for x in phase.data["General"]["Cell"][1:8]],
            "scale": float(hap["Scale"][0]),
        })
    total = sum(masses)
    for r, m in zip(rows, masses):
        r["weight_fraction"] = m / total
    ans = {
        "stage": stage,
        "rwp_percent": float(100 * np.sqrt(np.sum(w * (obs - calc)**2) / np.sum(w * obs**2))),
        "background_range": [float(np.min(bkg)), float(np.max(bkg))],
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "phases": rows,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }
    print(stage, f"Rwp={ans['rwp_percent']:.5f}", f"P={ans['polarization']:.4f}",
          " ".join(f"{r['name']}={r['weight_fraction']:.4f},U={r['uiso_A2'][0]:.5f}" for r in rows), flush=True)
    return ans


def run(project, stage, log, repeats=1):
    for _ in range(repeats):
        project.refine(makeBack=False)
    project.save()
    log.append(summarize(project, stage))


def cell_bounds(project, phase):
    # Diagonal reciprocal terms receive a relative bound. Off-diagonal terms
    # can be near zero, so an absolute guard avoids the pathological tiny bound
    # that froze monoclinic beta in the inventory branch.
    for i, val in enumerate(G2lat.cell2A(phase.data["General"]["Cell"][1:7])):
        val = float(val)
        if i < 3:
            lo, hi = sorted((0.97 * val, 1.03 * val))
        else:
            lo, hi = val - 0.002, val + 0.002
        bound(project, f"{phase.data['pId']}::A{i}", lo, hi)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default=".tmp/develop_shift/develop_shift.gpx")
    ap.add_argument("--tag", default="intensity_model")
    args = ap.parse_args()
    out = Path(".tmp") / args.tag
    out.mkdir(parents=True, exist_ok=True)
    gpx = out / f"{args.tag}.gpx"
    project = G2.G2Project(gpxfile=args.source, newgpx=str(gpx))
    project.set_Controls("cycles", 12)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    project.data["Constraints"]["data"]["Phase"] = []

    hist = project.histogram(0)
    # The common profile has been established; hold it while intensity terms
    # and phase structures are challenged.
    for key in ["U", "V", "W", "X", "Y", "Z", "SH/L", "Zero", "Polariz."]:
        hist.InstrumentParameters[key][2] = False
    hist.SampleParameters["Shift"][1] = True
    bound(project, f":{hist.id}:Shift", -800.0, 800.0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        bound(project, f"{phase.data['pId']}:{hist.id}:Scale", 0.0, 100.0)
        cell_bounds(project, phase)
        for atom in phase.atoms():
            atom.refinement_flags = ""

    project.save()
    log = [summarize(project, "start")]

    # Remove the prior frozen WO3 beta and reconverge every cell under one model.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, "cells_unfrozen", log, repeats=3)
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    controls["parmFrozen"] = {"FrozenList": []}

    # The synthetic source family uses one isotropic U value per phase. Enforce
    # that physical model rather than refining independent atom ADPs.
    project.save()
    project.index_ids()
    for phase in project.phases():
        pid = phase.data["pId"]
        vars_ = [f"{pid}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        for var in vars_:
            bound(project, var, 0.002, 0.030)
        if len(vars_) > 1:
            project.add_EquivConstr(vars_, reloadIdx=False)

    # Release one phase at a time, retaining accepted earlier ADPs, then replay.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "U"
        run(project, f"uiso_{phase.name}", log, repeats=2)
    run(project, "uiso_joint_replay", log, repeats=3)

    # Polarization is a common source/intensity correction and is tested only
    # after phase ADPs have converged.
    hist.InstrumentParameters["Polariz."][2] = True
    bound(project, f":{hist.id}:Polariz.", 0.5, 1.0)
    run(project, "polarization", log, repeats=3)

    a = project.histogram(0).data["data"][1]
    np.savetxt(out / "profile.csv", np.column_stack((a[0], a[1], a[3], a[5], a[4])), delimiter=",",
               header="two_theta_deg,observed,calculated,difference,background", comments="")
    (out / "summary.json").write_text(json.dumps(log, indent=2) + "\n")
    project.save()


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
