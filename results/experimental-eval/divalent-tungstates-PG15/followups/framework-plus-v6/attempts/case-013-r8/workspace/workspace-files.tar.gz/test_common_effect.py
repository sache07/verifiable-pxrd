#!/usr/bin/env python3
"""Test a common intensity correction after the accepted phase texture."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def bound(p, var, lo, hi):
    p.set_Controls("parmMin", float(lo), variable=var)
    p.set_Controls("parmMax", float(hi), variable=var)


def snap(p, stage):
    h = p.histogram(0); a = h.data["data"][1]
    y, c = np.asarray(a[1]), np.asarray(a[3]); w = 1 / np.maximum(y, 1)
    masses = [max(0.0, float(q.data["General"]["Mass"] * q.data["Histograms"][h.name]["Scale"][0])) for q in p.phases()]
    return {"stage": stage,
            "rwp_percent": float(100*np.sqrt(np.sum(w*(y-c)**2)/np.sum(w*y*y))),
            "polarization": float(h.InstrumentParameters["Polariz."][1]),
            "sample": {k: float(h.SampleParameters[k][0]) for k in ["Shift","SurfRoughA","SurfRoughB"]},
            "fractions": {q.name: m/sum(masses) for q,m in zip(p.phases(),masses)},
            "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen",{}).get("FrozenList",[])],
            "vary_list": list(p.data.get("Covariance",{}).get("data",{}).get("varyList",[]))}


def run(p, n):
    for _ in range(n): p.refine(makeBack=False)
    p.save()


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--source",default=".tmp/tex_massicot_100/tex_massicot_100.gpx")
    ap.add_argument("--effect",choices=["polarization","roughness"],required=True)
    ap.add_argument("--tag",required=True)
    args=ap.parse_args(); out=Path('.tmp')/args.tag; out.mkdir(parents=True,exist_ok=True)
    p=G2.G2Project(gpxfile=args.source,newgpx=str(out/f'{args.tag}.gpx'))
    p.set_Controls('cycles',12); ctrl=p.data['Controls']['data']; ctrl['parmFrozen']={'FrozenList':[]}; ctrl['parmMinDict']={};ctrl['parmMaxDict']={}
    p.data['Constraints']['data']['Phase']=[]; h=p.histogram(0)
    for key in ['Zero','U','V','W','X','Y','Z','SH/L','Polariz.']:h.InstrumentParameters[key][2]=False
    h.SampleParameters['Shift'][1]=True; bound(p,f':{h.id}:Shift',-800,800)
    h.SampleParameters['SurfRoughA']=[0.,False]; h.SampleParameters['SurfRoughB']=[0.,False]
    h.Background[0][1]=True
    for q in p.phases():
        q.clear_refinements({'Cell':True}); hap=q.data['Histograms'][h.name];hap['Scale'][1]=True;bound(p,f"{q.data['pId']}:{h.id}:Scale",0,100)
        for at in q.atoms():at.refinement_flags='';at.uiso=.01
        if q.name=='massicot': hap['Pref.Ori.'][2]=True;bound(p,f"{q.data['pId']}:{h.id}:MD",.7,1.4)
        else:hap['Pref.Ori.'][1]=1.;hap['Pref.Ori.'][2]=False
    p.save();run(p,2); log=[snap(p,'control')]
    if args.effect=='polarization':
        h.InstrumentParameters['Polariz.'][2]=True;bound(p,f':{h.id}:Polariz.',.5,1.)
    else:
        h.SampleParameters['SurfRoughA']=[.30,True];h.SampleParameters['SurfRoughB']=[.10,True]
        bound(p,f':{h.id}:SurfRoughA',.05,.60);bound(p,f':{h.id}:SurfRoughB',.02,.50)
    run(p,3);log.append(snap(p,'candidate'));print(json.dumps(log[-1],indent=2),flush=True)
    a=h.data['data'][1];np.savetxt(out/'profile.csv',np.column_stack((a[0],a[1],a[3],a[5],a[4])),delimiter=',',header='two_theta_deg,observed,calculated,difference,background',comments='')
    (out/'summary.json').write_text(json.dumps(log,indent=2)+'\n');p.save()


if __name__=='__main__':G2.SetPrintLevel('warn');main()
