#!/usr/bin/env python3
"""Re-challenge one watch-list phase under the accepted nuisance model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD=Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
def cif(cid):return COD/cid[0]/cid[1:3]/cid[3:5]/f"{cid}.cif"
def bound(p,v,lo,hi):p.set_Controls("parmMin",float(lo),variable=v);p.set_Controls("parmMax",float(hi),variable=v)


def snap(p,stage,candidate):
    h=p.histogram(0);a=h.data["data"][1];y,c=np.asarray(a[1]),np.asarray(a[3]);w=1/np.maximum(y,1)
    rows=[];m=[]
    for q in p.phases():
        hap=q.data["Histograms"][h.name];z=float(q.data["General"]["Mass"]*hap["Scale"][0]);m.append(max(0,z))
        rows.append({"name":q.name,"scale":float(hap["Scale"][0]),"mass_scale":z})
    for r,z in zip(rows,m):r["weight_fraction"]=z/sum(m)
    cov=p.data.get("Covariance",{}).get("data",{});sig=dict(zip(cov.get("varyList",[]),map(float,cov.get("sig",[]))))
    q=p.phase(candidate);var=f"{q.data['pId']}:{h.id}:Scale"
    return {"stage":stage,"rwp_percent":float(100*np.sqrt(np.sum(w*(y-c)**2)/np.sum(w*y*y))),"phases":rows,
            "candidate_scale_sigma":sig.get(var),"vary_list":list(cov.get("varyList",[])),
            "frozen":[str(v) for v in p.data["Controls"]["data"].get("parmFrozen",{}).get("FrozenList",[])]}


def main():
    ap=argparse.ArgumentParser();ap.add_argument("--candidate",required=True,help="NAME=CODID");ap.add_argument("--tag",required=True);args=ap.parse_args()
    name,cid=args.candidate.split("=",1);out=Path(".tmp")/args.tag;out.mkdir(parents=True,exist_ok=True)
    p=G2.G2Project(gpxfile=".tmp/accepted6/accepted6.gpx",newgpx=str(out/f"{args.tag}.gpx"))
    p.set_Controls("cycles",12);ctrl=p.data["Controls"]["data"];ctrl["parmFrozen"]={"FrozenList":[]};ctrl["parmMinDict"]={};ctrl["parmMaxDict"]={}
    h=p.histogram(0)
    for key,item in h.InstrumentParameters.items():
        if isinstance(item,list) and len(item)>2:item[2]=False
    h.Background[0][1]=True
    for key,item in h.SampleParameters.items():
        if isinstance(item,list) and len(item)>1 and isinstance(item[1],(bool,np.bool_)):item[1]=False
    h.SampleParameters["Shift"][1]=True;bound(p,f":{h.id}:Shift",-800,800)
    for q in p.phases():
        q.clear_refinements({"Cell":True});hap=q.data["Histograms"][h.name];hap["Scale"][1]=True
        bound(p,f"{q.data['pId']}:{h.id}:Scale",0,100)
        hap["Size"][2]=[False for _ in hap["Size"][2]];hap["Mustrain"][2]=[False for _ in hap["Mustrain"][2]]
        if len(hap["Mustrain"])>5:hap["Mustrain"][5]=[False for _ in hap["Mustrain"][5]]
        if q.name=="massicot":hap["Pref.Ori."][2]=True;bound(p,f"{q.data['pId']}:{h.id}:MD",.7,1.4)
        else:hap["Pref.Ori."][2]=False
        for atom in q.atoms():atom.refinement_flags="";atom.uiso=.01
    q=p.add_phase(str(cif(cid)),phasename=name,histograms=[h],fmthint="CIF");hap=q.data["Histograms"][h.name]
    hap["Scale"]=[.03,True];hap["Size"][0]="isotropic";hap["Size"][1][0]=hap["Size"][1][1]=.04;hap["Size"][2]=[False for _ in hap["Size"][2]]
    hap["Mustrain"][0]="isotropic";hap["Mustrain"][1][0]=hap["Mustrain"][1][1]=0.;hap["Mustrain"][2]=[False for _ in hap["Mustrain"][2]]
    hap["Pref.Ori."][1]=1.;hap["Pref.Ori."][2]=False;hap["Extinction"]=[0.,False]
    for atom in q.atoms():
        atom.refinement_flags=""
        try:
            atom.uiso=.01
        except G2.G2ScriptException:
            # Some source CIFs use anisotropic tensors. Keep those fixed; this
            # watch-list test releases only scale.
            pass
    bound(p,f"{q.data['pId']}:{h.id}:Scale",0,100);p.save();log=[]
    for i in range(4):
        p.refine(makeBack=False);p.save();log.append(snap(p,f"refine_{i+1}",name))
    print(json.dumps(log[-1],indent=2),flush=True);(out/"summary.json").write_text(json.dumps(log,indent=2)+"\n")


if __name__=="__main__":G2.SetPrintLevel("warn");main()
