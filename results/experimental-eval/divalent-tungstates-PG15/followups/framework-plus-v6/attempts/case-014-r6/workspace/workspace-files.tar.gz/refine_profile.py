#!/usr/bin/env python3
"""Replay candidate projects with physical phase-broadening trials."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_candidate import snapshot


def reset_frozen(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mode", choices=("size", "strain", "both"), required=True)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input), newgpx=str(args.output))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1], inst["W"][1], inst["X"][1], inst["SH/L"][1] = 10.0, 25.0, 2.0, 0.03
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    log = []

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]

    reset_frozen(project)
    project.refine()
    log.append(snapshot(project, "reset_common_profile"))

    if args.mode in ("size", "both"):
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][1][0] = 0.10
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 0.10, "refine": True}}, [hist]
            )
            reset_frozen(project)
            project.refine()
            log.append(snapshot(project, f"size_{phase.name}"))

    if args.mode == "strain":
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            hap["Mustrain"][1][0] = 1000.0
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "value": 1000.0, "refine": True}}, [hist]
            )
            reset_frozen(project)
            project.refine()
            log.append(snapshot(project, f"strain_{phase.name}"))

    # Once all phase widths are represented, establish the common profile.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    reset_frozen(project)
    project.refine()
    log.append(snapshot(project, "common_profile_UWX"))

    if args.mode == "both":
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            hap["Mustrain"][1][0] = 500.0
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "value": 500.0, "refine": True}}, [hist]
            )
            reset_frozen(project)
            project.refine()
            log.append(snapshot(project, f"strain_after_size_{phase.name}"))

    project.save()
    args.output.with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
