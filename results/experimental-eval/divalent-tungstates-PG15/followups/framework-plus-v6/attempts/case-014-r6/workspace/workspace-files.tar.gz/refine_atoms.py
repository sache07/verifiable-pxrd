#!/usr/bin/env python3
"""Refine symmetry-constrained coordinates one phase and sublattice at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_candidate import snapshot


def atom_state(project: G2.G2Project) -> dict:
    return {
        phase.name: [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(atom.coordinates),
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ]
        for phase in project.phases()
    }


def refine_labels(project: G2.G2Project, phase, labels: list[str], label: str, log: list) -> None:
    phase.set_refinements({"Atoms": {name: "X" for name in labels}})
    project.refine()
    row = snapshot(project, label)
    row["atoms"] = atom_state(project)
    log.append(row)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--oxygen", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input), newgpx=str(args.output))
    project.set_Controls("cycles", 16)
    project.set_Frozen()
    log = []

    scheelite = project.phase("SrWO4")
    refine_labels(project, scheelite, ["O"], "coordinates_SrWO4_O", log)

    intermediate = project.phase("Sr2WO5")
    heavy = [a.label for a in intermediate.atoms() if a.element != "O"]
    refine_labels(project, intermediate, heavy, "coordinates_Sr2WO5_heavy", log)
    oxy = [a.label for a in intermediate.atoms() if a.element == "O"]
    refine_labels(project, intermediate, oxy, "coordinates_Sr2WO5_O", log)

    tungsten_oxide = project.phase("WO3")
    heavy = [a.label for a in tungsten_oxide.atoms() if a.element == "W"]
    refine_labels(project, tungsten_oxide, heavy, "coordinates_WO3_W", log)
    if args.oxygen:
        oxy = [a.label for a in tungsten_oxide.atoms() if a.element == "O"]
        refine_labels(project, tungsten_oxide, oxy, "coordinates_WO3_O", log)

    project.refine()
    row = snapshot(project, "coordinates_reconverged")
    row["atoms"] = atom_state(project)
    log.append(row)
    project.save()
    args.output.with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
