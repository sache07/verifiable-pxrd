#!/usr/bin/env python3
"""Challenge a settled inventory with one watch-list phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_candidate import cod_path, snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("candidate")
    parser.add_argument("name")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input), newgpx=str(args.output))
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    project.set_Frozen()
    phase = project.add_phase(
        str(cod_path(args.candidate)), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.10, True]
    phase.setSampleProfile(hist, "size", "isotropic", 0.10)
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    project.set_Controls("cycles", 12)
    log = []
    project.refine()
    log.append(snapshot(project, "watch_scale"))
    row = log[-1]["phases"][-1]
    if row.get("weight_fraction", 0.0) > 0.002 and row["scale"] > 0:
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.10, "refine": True}}, [hist]
        )
        project.refine()
        log.append(snapshot(project, "watch_cell_size"))
        project.refine()
        log.append(snapshot(project, "watch_reconverged"))
    project.save()
    args.output.with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
