#!/usr/bin/env python3
"""Prune unsupported terms and replay the accepted model over the full range."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_candidate import snapshot


def configure(project: G2.G2Project) -> None:
    project.set_Controls("cycles", 18)
    project.set_Frozen()
    hist = project.histogram(0)
    x = hist.data["data"][1][0]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    inst = hist.data["Instrument Parameters"][0]
    # The physical profile trials placed these at their allowed edges. Keep the
    # accepted values, but do not retain active bound parameters.
    inst["U"][1] = 0.0
    inst["W"][1] = 40.0
    # X and isotropic size have nearly the same Lorentzian-angle dependence in
    # this uncalibrated scan. Retain the established common X, but fix it so the
    # final replay does not carry a singular X/size decomposition.
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    hist.set_refinements({"Instrument Parameters": ["SH/L", "Polariz."]})
    hist.data["Background"][0][1] = True
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.05, False]
    sample["SurfRoughB"][1] = True
    sample["Shift"][1] = True
    sample["Transparency"] = [0.0, False]

    for phase in project.phases():
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
        phase_restraints = project.data["Restraints"]["data"].get(phase.name, {})
        if "Bond" in phase_restraints:
            phase_restraints["Bond"]["Bonds"] = []
            phase_restraints["Bond"]["Use"] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        phase.set_HAP_refinements({"Scale": True, "Size": {"type": "isotropic", "refine": True}}, [hist])
        phase.set_refinements({"Cell": True})

    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    project.index_ids()
    bounds = {
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
        ":0:Shift": (-800.0, 800.0),
        ":0:SurfRoughB": (0.02, 0.50),
    }
    for phase in project.phases():
        bounds[f"{phase.id}:0:Scale"] = (1e-12, 1e12)
        bounds[f"{phase.id}:0:Size;i"] = (0.04, 1.5)
    for variable, (minimum, maximum) in bounds.items():
        project.set_Controls("parmMin", minimum, variable=variable)
        project.set_Controls("parmMax", maximum, variable=variable)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input), newgpx=str(args.output))
    configure(project)
    log = []
    project.refine()
    log.append({**snapshot(project, "full_range_first"), "frozen": project.get_Frozen()})
    project.refine()
    log.append({**snapshot(project, "full_range_reconverged"), "frozen": project.get_Frozen()})
    project.save()

    # Reopen the serialized project and replay once more to test persistence.
    replay = G2.G2Project(str(args.output))
    configure(replay)
    replay.refine()
    log.append({**snapshot(replay, "reopened_full_range_replay"), "frozen": replay.get_Frozen()})
    replay.save()
    args.output.with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
