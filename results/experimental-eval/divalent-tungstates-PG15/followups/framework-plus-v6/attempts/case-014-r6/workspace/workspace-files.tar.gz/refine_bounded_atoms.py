#!/usr/bin/env python3
"""Refine selected coordinates inside a Cartesian component trust region."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_atoms import atom_state
from refine_candidate import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("--elements", nargs="+")
    parser.add_argument("--component-limit-A", type=float, default=0.03)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input), newgpx=str(args.output))
    project.set_Controls("cycles", 16)
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["U", "W"]})
    phase = project.phase(args.phase)
    lengths = phase.data["General"]["Cell"][1:4]
    atoms = list(phase.atoms())
    selected = [
        (index, atom)
        for index, atom in enumerate(atoms)
        if not args.elements or atom.element in args.elements
    ]
    phase.set_refinements({"Atoms": {atom.label: "X" for _, atom in selected}})
    project.index_ids()
    for atom_index, atom in selected:
        for axis, (coordinate, length) in enumerate(zip(atom.coordinates, lengths)):
            delta = args.component_limit_A / length
            variable = f"{phase.id}::dA{'xyz'[axis]}:{atom_index}"
            project.set_Controls("parmMin", coordinate - delta, variable=variable)
            project.set_Controls("parmMax", coordinate + delta, variable=variable)

    log = []
    project.refine()
    row = snapshot(project, "bounded_coordinates_first")
    row["atoms"] = atom_state(project)
    row["frozen"] = project.get_Frozen()
    log.append(row)
    project.refine()
    row = snapshot(project, "bounded_coordinates_replay")
    row["atoms"] = atom_state(project)
    row["frozen"] = project.get_Frozen()
    log.append(row)
    project.save()
    args.output.with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
