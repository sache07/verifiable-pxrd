#!/usr/bin/env python3
"""Export every phase in one or more GSAS-II projects to CIF."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("projects", nargs="+", type=Path)
    parser.add_argument("--outdir", type=Path, default=Path(".tmp/screen"))
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    for source in args.projects:
        project = G2.G2Project(str(source))
        for phase in project.phases():
            destination = args.outdir / f"{source.stem}-{phase.name}.cif"
            phase.export_CIF(str(destination))


if __name__ == "__main__":
    main()
