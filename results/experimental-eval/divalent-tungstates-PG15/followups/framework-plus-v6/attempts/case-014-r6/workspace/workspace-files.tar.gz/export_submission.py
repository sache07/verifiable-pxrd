#!/usr/bin/env python3
"""Export CIFs, profile and machine-readable results from the final GPX."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PROJECT = Path("final.gpx")
CIF_NAMES = {"SrWO4": "SrWO4.cif", "WO3": "WO3.cif", "Sr2WO5": "Sr2WO5.cif"}
DISPLAY_NAMES = {
    "SrWO4": "strontium tungstate (scheelite)",
    "WO3": "monoclinic tungsten trioxide",
    "Sr2WO5": "strontium oxytungstate",
}


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(PROJECT))
    hist = project.histogram(0)
    x, observed, weights, calculated, background, difference = [
        np.asarray(array, dtype=float) for array in hist.data["data"][1]
    ]
    if not np.allclose(difference, observed - calculated, atol=1e-8, rtol=0):
        raise RuntimeError("GSAS-II difference array is inconsistent")
    if np.any(calculated < 0) or np.any(background < 0):
        raise RuntimeError("negative calculated intensity or background")

    with Path("fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta", "observed", "calculated", "difference", "background"])
        for row in zip(x, observed, calculated, difference, background):
            writer.writerow([f"{value:.10f}" for value in row])

    masses, scales = [], []
    for phase in project.phases():
        phase.export_CIF(CIF_NAMES[phase.name])
        masses.append(float(phase.data["General"]["Mass"]))
        scales.append(float(phase.data["Histograms"][hist.name]["Scale"][0]))
    weighted = np.asarray(masses) * np.asarray(scales)
    fractions = weighted / weighted.sum()
    formal = hist.ComputeMassFracs()

    denominator = float(np.sum(weights * observed**2))
    residual_sum = float(np.sum(weights * (observed - calculated) ** 2))
    rp = 100.0 * float(np.sum(np.abs(observed - calculated)) / np.sum(np.abs(observed)))
    rwp = 100.0 * np.sqrt(residual_sum / denominator)
    covariance = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "phases": [],
        "fit_statistics": {
            "Rwp_percent": float(rwp),
            "Rp_percent": float(rp),
            "goodness_of_fit": float(covariance["GOF"]),
            "chi_square": residual_sum,
            "data_points": int(len(x)),
            "refined_parameters": int(covariance["Nvars"]),
        },
        "refinement_histogram": hist.name,
        "fraction_basis": "normalized over the modeled crystalline phases",
    }
    for phase, fraction in zip(project.phases(), fractions):
        result["phases"].append(
            {
                "name": DISPLAY_NAMES[phase.name],
                "formula": phase.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": CIF_NAMES[phase.name],
                "weight_fraction": float(fraction),
                "formal_weight_fraction_esd": float(formal[phase.name][1]),
            }
        )
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
