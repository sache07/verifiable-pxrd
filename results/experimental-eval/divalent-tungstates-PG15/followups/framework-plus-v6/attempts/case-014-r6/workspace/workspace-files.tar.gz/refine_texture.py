#!/usr/bin/env python3
"""Challenge symmetry-distinct March-Dollase axes for one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_candidate import snapshot


def parse_axis(text: str) -> list[int]:
    axis = [int(value) for value in text.split(",")]
    if len(axis) != 3 or axis == [0, 0, 0]:
        raise argparse.ArgumentTypeError("axis must be h,k,l")
    return axis


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("phase")
    parser.add_argument("axes", nargs="+", type=parse_axis)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    args.outdir.mkdir(parents=True, exist_ok=True)
    rows = []
    for axis in args.axes:
        tag = "".join(str(value).replace("-", "m") for value in axis)
        destination = args.outdir / f"texture-{args.phase}-{tag}.gpx"
        project = G2.G2Project(str(args.input), newgpx=str(destination))
        project.set_Controls("cycles", 16)
        project.set_Frozen()
        hist = project.histogram(0)
        hist.clear_refinements({"Instrument Parameters": ["U", "W"]})
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")
        project.refine()
        project.refine()
        row = snapshot(project, f"texture_{args.phase}_{axis}")
        row["project"] = str(destination)
        rows.append(row)
    summary = args.outdir / f"texture-{args.phase}.json"
    summary.write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
