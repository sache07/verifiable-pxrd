#!/usr/bin/env python3
"""Apply generator-range physical bounds to an established size model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_candidate import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input), newgpx=str(args.output))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1], inst["W"][1], inst["X"][1] = 5.0, 30.0, 2.0
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})

    controls = project.data["Controls"]["data"]
    mins = {
        ":0:U": 0.0,
        ":0:W": 2.0,
        ":0:X": 0.1,
        ":0:Shift": -800.0,
    }
    maxs = {
        ":0:U": 40.0,
        ":0:W": 40.0,
        ":0:X": 6.0,
        ":0:Shift": 800.0,
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Size"][0] = "isotropic"
        if not 0.04 <= hap["Size"][1][0] <= 1.5:
            hap["Size"][1][0] = 0.10
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
        mins[f"{phase.id}:0:Size;i"] = 0.04
        maxs[f"{phase.id}:0:Size;i"] = 1.5
        mins[f"{phase.id}:0:Scale"] = 1e-12
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    project.index_ids()
    for variable, value in mins.items():
        project.set_Controls("parmMin", value, variable=variable)
    for variable, value in maxs.items():
        project.set_Controls("parmMax", value, variable=variable)
    log = []
    project.refine()
    log.append(snapshot(project, "bounded_profile_first"))
    # Continue with any parameters that did not encounter a bound.
    project.refine()
    log.append(snapshot(project, "bounded_profile_reconverged"))
    project.save()
    args.output.with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
