#!/usr/bin/env python3
"""Compare physically bounded common instrument/specimen nuisance terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_candidate import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--shl", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    args = parser.parse_args()
    if not (args.polarization or args.shl or args.roughness):
        raise ValueError("select at least one nuisance term")

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input), newgpx=str(args.output))
    project.set_Controls("cycles", 16)
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["U", "W"]})
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    if args.polarization:
        inst["Polariz."][1] = 0.8
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    if args.shl:
        inst["SH/L"][1] = 0.03
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
        project.set_Controls("parmMax", 0.10, variable=":0:SH/L")
    if args.roughness:
        sample["SurfRoughA"] = [0.20, True]
        sample["SurfRoughB"] = [0.10, True]
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")

    log = []
    project.refine()
    log.append(snapshot(project, "nuisance_first"))
    project.refine()
    log.append(snapshot(project, "nuisance_replay"))
    project.save()
    args.output.with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
