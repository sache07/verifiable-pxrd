#!/usr/bin/env python3
"""Build and stage a GSAS-II candidate refinement for this pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    supplied = Path(cod_id)
    if supplied.is_file():
        return supplied.resolve()
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "instrument": {
            key: inst[key][1] for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "sample": {
            key: sample[key][0] if isinstance(sample.get(key), list) else sample.get(key)
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": [],
    }
    masses = []
    scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"])
        scale = float(hap["Scale"][0])
        masses.append(mass)
        scales.append(scale)
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.data["General"]["Cell"][1:8],
                "mass": mass,
                "scale": scale,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    weighted = np.asarray(masses) * np.asarray(scales)
    if np.all(np.isfinite(weighted)) and weighted.sum() != 0:
        for row, fraction in zip(result["phases"], weighted / weighted.sum()):
            row["weight_fraction"] = float(fraction)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ids", nargs="+", required=True)
    parser.add_argument("--names", nargs="+")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--shift", type=float, default=-650.0)
    parser.add_argument("--profile", action="store_true")
    args = parser.parse_args()

    names = args.names or args.ids
    if len(names) != len(args.ids):
        raise ValueError("--names and --ids must have the same length")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(args.out))
    hist = project.add_powder_histogram("observed.xye", "instrument.instprm", fmthint="xye")
    hist.set_refinements({"Limits": [10.01, 99.99]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [args.shift, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [600.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            }
        }
    )
    phases = []
    for cod_id, name in zip(args.ids, names):
        phase = project.add_phase(
            str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        phase.setSampleProfile(hist, "size", "isotropic", 10.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0)
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        phases.append(phase)

    project.set_Controls("cycles", 12)
    log = []
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.refine()
    log.append(snapshot(project, "background_scales"))

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine()
    log.append(snapshot(project, "shift"))

    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine()
    log.append(snapshot(project, "cells"))

    # Re-establish the common background, scales, angular correction and cells.
    project.refine()
    log.append(snapshot(project, "baseline_reconverged"))

    if args.profile:
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        project.refine()
        log.append(snapshot(project, "profile_UWX"))
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.refine()
        log.append(snapshot(project, "profile_SHL"))

    project.save()
    args.out.with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
