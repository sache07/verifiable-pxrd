#!/usr/bin/env python3
"""Report short interatomic contacts for one or more CIFs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from pymatgen.core import Structure


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cifs", nargs="+", type=Path)
    args = parser.parse_args()
    report = {}
    for source in args.cifs:
        structure = Structure.from_file(source)
        pair_minima = {}
        nearest = []
        matrix = structure.distance_matrix
        for i, site_i in enumerate(structure):
            candidates = []
            for j, site_j in enumerate(structure):
                if i == j:
                    continue
                distance = float(matrix[i, j])
                key = "-".join(sorted((site_i.specie.symbol, site_j.specie.symbol)))
                pair_minima[key] = min(pair_minima.get(key, 1e9), distance)
                candidates.append((distance, site_j.specie.symbol))
            nearest.append(
                {
                    "site": f"{site_i.specie.symbol}{i + 1}",
                    "nearest": [
                        {"element": element, "distance_A": round(distance, 5)}
                        for distance, element in sorted(candidates)[:6]
                    ],
                }
            )
        report[str(source)] = {
            "formula": structure.composition.reduced_formula,
            "volume_A3": structure.volume,
            "pair_minima_A": {key: round(value, 5) for key, value in sorted(pair_minima.items())},
            "nearest": nearest,
        }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
