#!/usr/bin/env python3
"""Select a common isotropic Uiso for all sites in one phase by replay."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_candidate import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("--values", nargs="+", type=float, default=[0.003, 0.005, 0.008, 0.012, 0.016, 0.020])
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    candidates = []
    for i, value in enumerate(args.values):
        candidate = args.output.with_name(f"{args.output.stem}-trial-{i}{args.output.suffix}")
        project = G2.G2Project(str(args.input), newgpx=str(candidate))
        project.set_Controls("cycles", 14)
        project.set_Frozen()
        hist = project.histogram(0)
        hist.clear_refinements({"Instrument Parameters": ["U", "W"]})
        for atom in project.phase(args.phase).atoms():
            atom.uiso = value
        project.refine()
        project.refine()
        row = snapshot(project, f"{args.phase}_Uiso_{value:.5f}")
        row["phase_Uiso_A2"] = value
        rows.append(row)
        candidates.append(candidate)
    best_index = min(range(len(rows)), key=lambda index: rows[index]["Rwp_percent"])
    shutil.copyfile(candidates[best_index], args.output)
    record = {"phase": args.phase, "best_index": best_index, "trials": rows}
    args.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
