#!/usr/bin/env python3
"""Refine coordinates with soft restraints to the parent bond geometry."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIImath as G2mth

from refine_atoms import atom_state
from refine_candidate import snapshot


def bond_distance_data(phase):
    general = phase.data["General"]
    atoms = phase.data["Atoms"]
    cx, ct, cs, cia = general["AtomPtrs"]
    lookup = G2mth.FillAtomLookUp(atoms, cia + 8)
    amat, _ = G2lat.cell2AB(general["Cell"][1:7])
    result = []
    for bond in phase._getBondRest("bond_distance_data")["Bonds"]:
        indices, operations, target, esd = bond
        xyz = np.array(G2mth.GetAtomItemsById(atoms, lookup, indices, cx, 3))
        xyz = G2mth.getSyXYZ(xyz, operations, general["SGData"])
        calculated = float(G2mth.getRestDist(xyz, amat))
        result.append((bond, calculated))
    return result


def add_parent_bonds(phase, esd: float, weight: float) -> int:
    restraints = phase.proj.data["Restraints"]["data"]
    restraints.setdefault(phase.name, {})
    restraints[phase.name].setdefault(
        "Bond", {"wtFactor": 1.0, "Range": 1.1, "Bonds": [], "Use": True}
    )
    phase.clearDistRestraint()
    atoms = list(phase.atoms())
    oxygens = [atom for atom in atoms if atom.element == "O"]
    count = 0
    if phase.name == "SrWO4":
        count += phase.addDistRestraint([phase.atom("W")], oxygens, 1.88, factor=1.18, ESD=esd)
        count += phase.addDistRestraint([phase.atom("Sr")], oxygens, 2.65, factor=1.18, ESD=esd)
    elif phase.name == "WO3":
        tungstens = [atom for atom in atoms if atom.element == "W"]
        count += phase.addDistRestraint(tungstens, oxygens, 1.90, factor=1.30, ESD=esd)
    elif phase.name == "Sr2WO5":
        tungstens = [atom for atom in atoms if atom.element == "W"]
        strontiums = [atom for atom in atoms if atom.element == "Sr"]
        count += phase.addDistRestraint(tungstens, oxygens, 1.88, factor=1.18, ESD=esd)
        count += phase.addDistRestraint(strontiums, oxygens, 2.75, factor=1.20, ESD=esd)
    else:
        raise ValueError(f"no bond inventory defined for {phase.name}")
    # Preserve each distinct parent distance instead of forcing a regular polyhedron.
    for bond, calculated in bond_distance_data(phase):
        bond[2] = calculated
        bond[3] = esd
    phase.setDistRestraintWeight(weight)
    return count


def restraint_summary(phase) -> dict:
    values = []
    for bond, calculated in bond_distance_data(phase):
        values.append({"target_A": bond[2], "calculated_A": calculated, "delta_A": calculated - bond[2], "esd_A": bond[3]})
    return {
        "count": len(values),
        "rms_delta_A": float(np.sqrt(np.mean([value["delta_A"] ** 2 for value in values]))) if values else 0.0,
        "max_abs_delta_A": max((abs(value["delta_A"]) for value in values), default=0.0),
        "bonds": values,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("--elements", nargs="+")
    parser.add_argument("--esd", type=float, default=0.04)
    parser.add_argument("--weight", type=float, default=10.0)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input), newgpx=str(args.output))
    project.set_Controls("cycles", 20)
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["U", "W"]})
    phase = project.phase(args.phase)
    selected = [atom for atom in phase.atoms() if not args.elements or atom.element in args.elements]
    phase.set_refinements({"Atoms": {atom.label: "X" for atom in selected}})
    count = add_parent_bonds(phase, args.esd, args.weight)

    log = []
    project.refine()
    row = snapshot(project, "restrained_coordinates_first")
    row.update(atoms=atom_state(project), restraints=restraint_summary(phase), restraint_count_added=count)
    log.append(row)
    project.refine()
    row = snapshot(project, "restrained_coordinates_replay")
    row.update(atoms=atom_state(project), restraints=restraint_summary(phase), restraint_count_added=count)
    log.append(row)
    project.save()
    args.output.with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
