#!/usr/bin/env python3
"""Recalculate one no-background phase contribution at a time from a GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def disable_refinement(project) -> None:
    histogram = project.histogram(0)
    histogram.clear_refinements(
        {
            "Background": True,
            "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
            "Instrument Parameters": ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"],
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
            }
        )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    probe = G2.G2Project(gpxfile=str(args.project.resolve()))
    names = [phase.name for phase in probe.phases()]
    del probe
    columns = []
    x = None
    for target_name in names:
        work = args.output.parent / f".{args.output.stem}_{target_name}.gpx"
        project = G2.G2Project(gpxfile=str(args.project.resolve()), newgpx=str(work.resolve()))
        histogram = project.histogram(0)
        disable_refinement(project)
        background = histogram.data["Background"]
        background[0][1] = False
        background[0][3:] = [0.0 for _ in background[0][3:]]
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            if phase.name != target_name:
                hap["Scale"][0] = 0.0
        project.set_Controls("cycles", 0)
        project.refine(makeBack=False)
        arrays = np.asarray(histogram.data["data"][1], float)
        if x is None:
            x = arrays[0].copy()
        columns.append(arrays[3].copy())
        work.unlink(missing_ok=True)
        work.with_suffix(".lst").unlink(missing_ok=True)
    matrix = np.column_stack([x, *columns])
    np.savetxt(
        args.output,
        matrix,
        delimiter=",",
        header="two_theta_deg," + ",".join(names),
        comments="",
        fmt="%.10g",
    )
    args.output.with_suffix(".json").write_text(
        json.dumps({"phases": names}, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
