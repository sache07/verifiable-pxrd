#!/usr/bin/env python3
"""Rough peak and COD-candidate screen for the supplied PXRD pattern."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.signal import find_peaks


ROOT = Path(__file__).resolve().parent
INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")
CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    # A deliberately conservative lower-envelope baseline for inventory work.
    baseline = percentile_filter(y, percentile=18, size=501, mode="nearest")
    baseline = gaussian_filter1d(baseline, 80)
    residual = y - baseline
    noise = np.median(np.abs(np.diff(y))) / 0.954
    peaks, props = find_peaks(
        residual,
        prominence=max(6 * noise, 100),
        height=max(8 * noise, 120),
        distance=4,
    )
    order = peaks[np.argsort(residual[peaks])[::-1]]

    print(f"points={len(x)} range={x[0]:.6f}..{x[-1]:.6f} step={np.median(np.diff(x)):.7f}")
    print(f"counts min/median/max={y.min():.1f}/{np.median(y):.1f}/{y.max():.1f}; rough noise={noise:.1f}")
    print(f"rough peak count={len(peaks)}")
    print("strong observed maxima: 2theta, net height, prominence")
    prominence_by_index = dict(zip(peaks, props["prominences"]))
    for i in order[:80]:
        print(f"  {x[i]:10.5f} {residual[i]:11.1f} {prominence_by_index[i]:11.1f}")

    with gzip.open(INDEX, "rt") as handle:
        index = json.load(handle)
    records = []
    for key in ("O-Pb-W", "O-Pb", "O-W", "C-O-Pb"):
        for formula, cod_id, sg, r_value in index.get(key, []):
            records.append((key, formula, cod_id, sg, r_value))

    calc = XRDCalculator(wavelength=1.540598, symprec=0)
    print("\nCOD candidate structures and strongest calculated lines:")
    for key, formula, cod_id, sg, r_value in records:
        path = cif_path(cod_id)
        try:
            parser = CifParser(path, occupancy_tolerance=2.0)
            structure = parser.parse_structures(primitive=False)[0]
            patt = calc.get_pattern(structure, two_theta_range=(9.8, 100.2), scaled=True)
            strongest = np.argsort(patt.y)[::-1][:10]
            lines = ", ".join(f"{patt.x[j]:.3f}({patt.y[j]:.0f})" for j in strongest)
            lattice = structure.lattice
            print(
                f"{cod_id} {formula:18s} SGidx={sg:3d} parsed={structure.composition.reduced_formula:12s} "
                f"n={len(structure):3d} cell={lattice.a:.4f},{lattice.b:.4f},{lattice.c:.4f},"
                f"{lattice.alpha:.2f},{lattice.beta:.2f},{lattice.gamma:.2f} lines: {lines}"
            )
        except Exception as exc:
            print(f"{cod_id} {formula}: ERROR {type(exc).__name__}: {exc}")

    fig, axes = plt.subplots(2, 1, figsize=(15, 8), sharex=True, gridspec_kw={"height_ratios": [2, 1]})
    axes[0].plot(x, y, color="black", linewidth=0.55)
    axes[0].plot(x, baseline, color="tab:orange", linewidth=1.0)
    axes[0].set_ylabel("counts")
    axes[0].set_title("Observed pattern and conservative baseline")
    axes[1].plot(x, residual, color="black", linewidth=0.55)
    axes[1].plot(x[peaks], residual[peaks], ".", color="tab:red", markersize=3)
    axes[1].set_xlabel(r"$2\theta$ (deg)")
    axes[1].set_ylabel("counts above baseline")
    axes[1].set_xlim(x[0], x[-1])
    fig.tight_layout()
    fig.savefig(ROOT / "pattern_overview.png", dpi=180)


if __name__ == "__main__":
    main()
