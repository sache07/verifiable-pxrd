#!/usr/bin/env python3
"""Apply the physical Pb3WO6 site shift and conservative supported texture."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


def clear_frozen(project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--ratio", type=float, default=1.35)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    if not 0.7 < args.ratio < 1.4:
        raise SystemExit("The conservative fixed ratio must be strictly interior")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    project.set_Controls("cycles", 12)
    clear_frozen(project)
    instrument = histogram.data["Instrument Parameters"][0]
    instrument["SH/L"][2] = False
    histogram.set_refinements(
        {
            "Background": True,
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Polariz.", "W"],
        }
    )
    for phase in phases:
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        if phase.name == "wo3_1528915":
            hap["Size"][2][0] = True
        if phase.name in {"pbwo4_9009811", "pb2wo5_from_mo_7220560"}:
            hap["Mustrain"][2][0] = True
        if phase.name in {"wo3_1528915", "massicot_2310433", "pb2wo5_from_mo_7220560"}:
            hap["Pref.Ori."][2] = True
        if phase.name == "pb3wo6_from_u_2310493":
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = args.ratio
            hap["Pref.Ori."][2] = False
            hap["Pref.Ori."][3] = [0, 1, 0]
        if phase.name == "pbwo4_9009811":
            for atom in phase.atoms():
                atom.refinement_flags = "U"
    history = [snapshot(project, "pb3_conservative_loaded")]
    for index in range(3):
        clear_frozen(project)
        project.refine(makeBack=False)
        state = snapshot(project, f"pb3_conservative_{index + 1}")
        history.append(state)
        print(f"{state['label']}: Rwp={state['rwp_percent']:.4f}%")
    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
