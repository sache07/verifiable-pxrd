#!/usr/bin/env python3
"""Retest one common SH/L term after inventory and texture stabilization."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


def clear_frozen(project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def refine(project, history, label, repeats=1) -> None:
    for index in range(repeats):
        clear_frozen(project)
        project.refine(makeBack=False)
        state = snapshot(project, label if repeats == 1 else f"{label}_{index + 1}")
        history.append(state)
        print(f"{state['label']}: Rwp={state['rwp_percent']:.4f}%")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    project.set_Controls("cycles", 12)
    clear_frozen(project)
    project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.1, variable=":0:SH/L")

    histogram.clear_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Polariz.", "W"],
        }
    )
    instrument["SH/L"][2] = True
    histogram.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
    history = [snapshot(project, "shl_loaded")]
    refine(project, history, "shl_isolated", repeats=2)

    histogram.set_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Polariz.", "W"],
        }
    )
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][histogram.name]
        if phase.name == "wo3_1528915":
            hap["Size"][2][0] = True
        if phase.name in {"pbwo4_9009811", "pb2wo5_from_mo_7220560"}:
            hap["Mustrain"][2][0] = True
        if phase.name in {"wo3_1528915", "massicot_2310433", "pb2wo5_from_mo_7220560"}:
            hap["Pref.Ori."][2] = True
        if phase.name == "pbwo4_9009811":
            for atom in phase.atoms():
                atom.refinement_flags = "U"
    refine(project, history, "shl_reconverged", repeats=2)
    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
