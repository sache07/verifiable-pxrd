#!/usr/bin/env python3
"""Write fit.csv, result.json and report.md from the verified GPX replay."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / ".tmp" / "replay_final"
N_PARAMETERS = 46
FORMULAS = {
    "pbwo4_9009811": "PbWO4",
    "wo3_1528915": "WO3",
    "litharge_9012700": "PbO",
    "massicot_2310433": "PbO",
    "pb2wo5_from_mo_7220560": "Pb2WO5",
    "pb3wo6_from_u_2310493": "Pb3WO6",
    "pb3o4_1537983": "Pb3O4",
}
DISPLAY = {
    "pbwo4_9009811": "scheelite PbWO4",
    "wo3_1528915": "monoclinic WO3",
    "litharge_9012700": "litharge PbO",
    "massicot_2310433": "massicot PbO",
    "pb2wo5_from_mo_7220560": "Pb2WO5 (Pb2MoO5-type)",
    "pb3wo6_from_u_2310493": "Pb3WO6 (Pb3UO6-type)",
    "pb3o4_1537983": "tetragonal Pb3O4",
}


def main() -> None:
    replay = json.loads((REPLAY / "replay.json").read_text())
    model = json.loads((ROOT / "final_model.json").read_text())
    if replay.get("status") != "replayed":
        raise RuntimeError(f"Final replay failed: {replay}")
    if replay.get("profile_review_flags"):
        raise RuntimeError(f"Final replay has profile flags: {replay['profile_review_flags']}")
    model_by_name = {row["name"]: row for row in model["phases"]}
    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as archive:
        x = archive["x"].copy()
        observed = archive["observed"].copy()
        calculated = archive["predicted"].copy()
        background = archive["background"].copy()
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference, background]),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt="%.15g",
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100 * np.sqrt(chi_square / denominator))
    rp = float(100 * np.sum(np.abs(difference)) / np.sum(observed))
    dof = int(len(x) - N_PARAMETERS)
    reduced = chi_square / dof
    fit_statistics = {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "chi_square": chi_square,
        "degrees_of_freedom": dof,
        "reduced_chi_square": reduced,
        "goodness_of_fit": float(np.sqrt(reduced)),
        "n_points": int(len(x)),
        "n_refined_parameters": N_PARAMETERS,
        "weighting": "1/max(observed_counts,1)",
        "source": "no-refinement replay of final.gpx over the complete observed grid",
    }
    phases = []
    for row in replay["phases"]:
        saved = model_by_name[row["name"]]
        if abs(saved["weight_fraction"] - row["weight_fraction"]) > 1e-12:
            raise RuntimeError(f"Fraction mismatch for {row['name']}")
        phases.append(
            {
                "name": DISPLAY[row["name"]],
                "formula": FORMULAS[row["name"]],
                "cif_path": saved["cif_path"],
                "weight_fraction": row["weight_fraction"],
            }
        )
    result = {
        "schema_version": 1,
        "refinement_histogram": replay["histogram"],
        "fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phases,
        "fit_statistics": fit_statistics,
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )

    table = "\n".join(
        f"| {row['name']} | {100 * row['weight_fraction']:.2f} | `{row['cif_path']}` |"
        for row in phases
    )
    report = f"""# Powder XRD phase analysis

The final seven-phase atomic model gives **Rwp = {rwp:.3f}%** (Rp = {rp:.3f}%, goodness of fit = {np.sqrt(reduced):.3f}) in a no-refinement replay of `final.gpx` over all {len(x)} measured points. The replay regenerated structure factors and reflection lists, left the project unchanged, produced a nonnegative background, and raised no profile-review flags.

| Crystalline phase | Weight fraction (%) | Submitted structure |
|---|---:|---|
{table}

Fractions are normalized over the modeled crystalline material; this experiment does not determine an amorphous fraction.

## Evidence

Scheelite PbWO4 accounts for the dominant families at about 27.70, 33.06, 45.03, 51.49 and 55.54° 2theta. Monoclinic WO3 is required by the 23.35/23.84/24.65° cluster and its higher-angle families. Litharge and massicot PbO are independently supported by their distinct 32.05/48.80° and 29.33/30.55/38.05° families. Weak tetragonal Pb3O4 is supported by coherent lines near 26.85, 31.03 and 32.79°.

The off-stoichiometric phases are supported by families not explained by those four records. Pb2WO5 matches lines near 25.90, 29.24, 31.05 and 43.39°; an isovalent W-for-Mo model based on COD 7220560 was substantially better than the Pb2CrO5-type alternate. Pb3WO6 matches the 26.59/28.74/29.40/30.19° group and associated mid-angle lines. A composition-, cell- and space-group-filtered analogue search found Pb3UO6 (COD 2310493, Pnma) as the only close same-symmetry parent, so U6+ was replaced by W6+ and the model was cell-refined.

Alternative scheelite, Pb-deficient scheelite, triclinic/other WO3, massicot and Pb3O4 records were challenged under the same nuisance model. They either fitted worse or produced unstable/nonphysical metrics. The final profile uses one specimen-displacement correction, a smooth eight-term Chebyshev background, a common nonnegative width profile, selected phase size/strain terms, and only texture axes supported by multiple families.

## Remaining uncertainty

The Pb2WO5 and especially Pb3WO6 structures are analogue-derived rather than direct database identifications. Pb3WO6 preferred orientation was strongly supported along [010], but its unconstrained ratio reached the allowed range edge; the submitted project therefore uses a fixed interior ratio of 1.35. Its exact coordinates and 9.48 wt% fraction should not be treated as high precision. The 1.23 wt% Pb3O4 fraction is also near the practical detection limit.

Published WO3 and Pb3O4 coordinates trigger a geometry-review warning for short O--O contacts (about 1.58 and 1.80 Å, respectively), though there are no hard contacts, invalid occupancies or density failures. Oxygen-coordinate refinements were not identifiable without exceeding the stated reference-mismatch scale, so the published coordinates were retained. Massicot broadening is resolution-limited (fixed 0.045 micrometre size), adding correlation to its fraction. Residual intensity/profile mismatch remains in heavily overlapped 25--60° regions; major-phase fractions are more reliable than the weak/analogue-derived fractions.
"""
    (ROOT / "report.md").write_text(report)


if __name__ == "__main__":
    main()
