#!/usr/bin/env python3
"""Transfer the accepted profile model to the selected monoclinic-WO3 inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


def run(project, history, label, repeats=1):
    for index in range(repeats):
        project.refine(makeBack=False)
        state = snapshot(project, label if repeats == 1 else f"{label}_{index + 1}")
        history.append(state)
        print(f"{state['label']}: Rwp={state['rwp_percent']:.4f}%")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1], inst["W"][1], inst["X"][1], inst["SH/L"][1], inst["Polariz."][1] = 0.0, 34.0, 6.0, 0.03, 0.78
    hist.clear_refinements({"Instrument Parameters": ["U", "X", "SH/L"]})
    hist.set_refinements({"Instrument Parameters": ["W", "Polariz."]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Background": True})
    project.set_Controls("parmMin", 2.0, variable=":0:W")
    project.set_Controls("parmMax", 40.0, variable=":0:W")
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.set_Controls("parmMin", -1000.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1000.0, variable=":0:Shift")

    for phase in phases:
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][0] = "isotropic"
        hap["Mustrain"][0] = "isotropic"
        if phase.name == "wo3_1528915":
            hap["Size"][1][0], hap["Size"][2][0] = 0.11, True
        elif phase.name == "massicot_2310433":
            hap["Size"][1][0], hap["Size"][2][0] = 0.04, False
        else:
            hap["Size"][1][0], hap["Size"][2][0] = 1.5, False
        if phase.name == "pbwo4_9009811":
            hap["Mustrain"][1][0], hap["Mustrain"][2][0] = 1300.0, True
        elif phase.name == "pb2wo5_from_mo_7220560":
            hap["Mustrain"][1][0], hap["Mustrain"][2][0] = 1650.0, True
        else:
            hap["Mustrain"][1][0], hap["Mustrain"][2][0] = 0.0, False
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;i")

    history = [snapshot(project, "transferred_profile")]
    run(project, history, "monoclinic_inventory_reconverged", repeats=4)
    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
