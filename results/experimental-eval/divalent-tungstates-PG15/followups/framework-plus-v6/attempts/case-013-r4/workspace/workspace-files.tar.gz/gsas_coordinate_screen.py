#!/usr/bin/env python3
"""Screen bounded coordinates for selected elements in one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


def lattice_matrix(cell):
    """Return row-vector crystallographic lattice vectors."""
    a, b, c = (cell[key] for key in ("length_a", "length_b", "length_c"))
    alpha, beta, gamma = np.deg2rad(
        [cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]]
    )
    cg, sg = np.cos(gamma), np.sin(gamma)
    ca, cb = np.cos(alpha), np.cos(beta)
    cx = c * cb
    cy = c * (ca - cb * cg) / sg
    cz = np.sqrt(max(c * c - cx * cx - cy * cy, 0.0))
    return np.asarray([[a, 0.0, 0.0], [b * cg, b * sg, 0.0], [cx, cy, cz]])


def clear_frozen(project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--elements", required=True, help="comma-separated element symbols")
    parser.add_argument("--max-frac", type=float, default=0.008)
    parser.add_argument("--indices", help="optional comma-separated atom indices")
    parser.add_argument("--unbounded", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    selected = {item.strip() for item in args.elements.split(",") if item.strip()}
    indices = None if args.indices is None else {
        int(item) for item in args.indices.split(",") if item.strip()
    }
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    target = next(phase for phase in phases if phase.name == args.phase)
    project.set_Controls("cycles", 12)
    clear_frozen(project)

    histogram.clear_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Polariz.", "W", "SH/L"],
        }
    )
    histogram.set_refinements({"Background": True})
    starts = {}
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = False
        for atom_index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = ""
            if (
                phase.name == args.phase
                and atom.element in selected
                and (indices is None or atom_index in indices)
            ):
                atom.refinement_flags = "X"
                starts[atom_index] = list(atom.coordinates)
                if not args.unbounded:
                    # GSAS-II names these dA variables, but parameter limits are
                    # applied to the resulting absolute fractional coordinate.
                    for component_index, component in enumerate("xyz"):
                        variable = f"{phase.id}::dA{component}:{atom_index}"
                        center = starts[atom_index][component_index]
                        project.set_Controls("parmMin", center - args.max_frac, variable=variable)
                        project.set_Controls("parmMax", center + args.max_frac, variable=variable)

    history = [snapshot(project, "bounded_coordinates_loaded")]
    project.refine(makeBack=False)
    history.append(snapshot(project, "bounded_coordinates"))
    project.save()

    cell = target.get_cell()
    lattice = lattice_matrix(cell)
    shifts = []
    for atom_index, start in starts.items():
        atom = target.atoms()[atom_index]
        delta = np.asarray(atom.coordinates, float) - np.asarray(start, float)
        delta -= np.rint(delta)
        shifts.append(
            {
                "atom_index": atom_index,
                "label": atom.label,
                "element": atom.element,
                "start": start,
                "end": list(atom.coordinates),
                "delta_frac": delta.tolist(),
                "distance_A": float(np.linalg.norm(delta @ lattice)),
            }
        )
    report = {
        "phase": args.phase,
        "elements": sorted(selected),
        "max_frac": None if args.unbounded else args.max_frac,
        "rwp_before_percent": history[0]["rwp_percent"],
        "rwp_after_percent": history[1]["rwp_percent"],
        "frozen": [
            str(item)
            for item in project.data["Controls"]["data"]
            .get("parmFrozen", {})
            .get("FrozenList", [])
        ],
        "coordinate_shifts": shifts,
        "history": history,
    }
    args.output.with_suffix(".summary.json").write_text(
        json.dumps(report, indent=2, allow_nan=False) + "\n"
    )
    if not args.quiet:
        print(json.dumps({key: report[key] for key in report if key != "history"}, indent=2))


if __name__ == "__main__":
    main()
