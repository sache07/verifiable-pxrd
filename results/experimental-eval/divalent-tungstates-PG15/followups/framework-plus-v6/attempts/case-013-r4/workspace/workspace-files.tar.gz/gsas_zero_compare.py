#!/usr/bin/env python3
"""Replace specimen displacement by a single zero correction and reconverge."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


def clear_frozen(project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    project.set_Controls("cycles", 12)
    clear_frozen(project)

    sample["Shift"] = [0.0, False]
    instrument["Zero"][1] = 0.0
    instrument["Zero"][2] = True
    instrument["Polariz."][2] = False
    instrument["W"][2] = False
    project.set_Controls("parmMin", -0.5, variable=":0:Zero")
    project.set_Controls("parmMax", 0.5, variable=":0:Zero")
    histogram.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
    history = [snapshot(project, "zero_only_loaded")]
    for index in range(2):
        clear_frozen(project)
        project.refine(makeBack=False)
        state = snapshot(project, f"zero_only_{index + 1}")
        history.append(state)
        print(f"{state['label']}: Rwp={state['rwp_percent']:.4f}%")

    instrument["Polariz."][2] = True
    instrument["W"][2] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][histogram.name]
        if phase.name == "wo3_1528915":
            hap["Size"][2][0] = True
        if phase.name in {"pbwo4_9009811", "pb2wo5_from_mo_7220560"}:
            hap["Mustrain"][2][0] = True
        if phase.name in {"wo3_1528915", "massicot_2310433", "pb2wo5_from_mo_7220560"}:
            hap["Pref.Ori."][2] = True
        if phase.name == "pbwo4_9009811":
            for atom in phase.atoms():
                atom.refinement_flags = "U"
    for index in range(2):
        clear_frozen(project)
        project.refine(makeBack=False)
        state = snapshot(project, f"zero_reconverged_{index + 1}")
        history.append(state)
        print(f"{state['label']}: Rwp={state['rwp_percent']:.4f}%")
    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
