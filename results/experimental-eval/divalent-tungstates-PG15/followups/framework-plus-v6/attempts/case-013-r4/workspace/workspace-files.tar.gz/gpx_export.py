#!/usr/bin/env python3
"""Export saved GSAS-II histogram arrays and compact model diagnostics."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return plain(value.tolist())
    if isinstance(value, np.generic):
        return value.item()
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path)
    parser.add_argument("prefix", type=Path)
    args = parser.parse_args()
    project = G2.G2Project(gpxfile=str(args.project.resolve()))
    hist = project.histogram(0)
    arrays = np.asarray(hist.data["data"][1], dtype=float)
    # GSAS arrays: x, observed, weight, calculated, background, residual.
    out = np.column_stack([arrays[0], arrays[1], arrays[3], arrays[4], arrays[5]])
    np.savetxt(
        args.prefix.with_suffix(".csv"),
        out,
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference",
        comments="",
        fmt="%.10g",
    )
    masses = []
    phase_rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        amount = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        masses.append(amount)
        phase_rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell_mass": float(phase.data["General"]["Mass"]),
                "cell": phase.get_cell(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for row, amount in zip(phase_rows, masses):
        row["weight_fraction"] = amount / total
    report = {
        "project": str(args.project),
        "histogram": hist.name,
        "rwp_percent": hist.get_wR(),
        "residuals": hist.data["data"][0],
        "instrument": hist.data["Instrument Parameters"],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "phases": phase_rows,
        "controls": project.data["Controls"]["data"],
    }
    args.prefix.with_suffix(".json").write_text(json.dumps(plain(report), indent=2) + "\n")


if __name__ == "__main__":
    main()
