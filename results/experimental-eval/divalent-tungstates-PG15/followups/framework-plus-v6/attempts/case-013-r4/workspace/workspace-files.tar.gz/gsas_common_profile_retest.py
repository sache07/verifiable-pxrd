#!/usr/bin/env python3
"""Retest common U/W/X after neutralizing unsupported phase-size terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


REFINED_SIZE = {"wo3_1528915", "pb3wo6_from_u_2310493"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    phases = project.phases()
    project.set_Controls("cycles", 16)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}

    histogram.clear_refinements(
        {"Sample Parameters": ["Shift"], "Instrument Parameters": ["Polariz.", "SH/L"]}
    )
    histogram.set_refinements({"Background": True})
    instrument["U"][1] = 5.0
    instrument["W"][1] = 30.0
    instrument["X"][1] = 4.0
    histogram.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for name, low, high in (("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0)):
        project.set_Controls("parmMin", low, variable=f":0:{name}")
        project.set_Controls("parmMax", high, variable=f":0:{name}")

    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = False
        if phase.name not in REFINED_SIZE:
            # Massicot is demonstrably resolution-limited at the lower source
            # range. Keep a conservative small fixed value, but neutralize all
            # other unsupported size terms.
            hap["Size"][1][0] = 0.045 if phase.name == "massicot_2310433" else 10.0
        for atom in phase.atoms():
            atom.refinement_flags = ""
    history = [snapshot(project, "neutral_sizes_common_profile_loaded")]
    project.refine(makeBack=False)
    history.append(snapshot(project, "neutral_sizes_common_profile"))
    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )
    state = history[-1]
    frozen = project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])
    print(f"Rwp={state['rwp_percent']:.4f}% frozen={[str(item) for item in frozen]}")
    print({key: state["instrument"][key] for key in ("U", "W", "X")})


if __name__ == "__main__":
    main()
