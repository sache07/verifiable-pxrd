#!/usr/bin/env python3
"""Print compact physical/refinement state from a GSAS-II project."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.project)
    histogram = project.histogram(0)
    result = {
        "rwp_percent": histogram.get_wR(),
        "frozen": [
            str(item)
            for item in project.data.get("Controls", {})
            .get("data", {})
            .get("parmFrozen", {})
            .get("FrozenList", [])
        ],
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        result["phases"].append(
            {
                "id": phase.id,
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "size": hap["Size"][:4],
                "mustrain": hap["Mustrain"][:4],
                "preferred_orientation": hap["Pref.Ori."][:4],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": list(atom.coordinates),
                        "uiso": atom.uiso,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
