#!/usr/bin/env python3
"""Continue a saved GSAS-II inventory trial with phase-width comparisons."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


def refine(project, history, label):
    project.refine(makeBack=False)
    state = snapshot(project, label)
    history.append(state)
    print(f"{label}: Rwp={state['rwp_percent']:.4f}%")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--sizes", action="store_true")
    parser.add_argument("--mustrain", action="store_true")
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("parmMin", 0.0, variable=":0:X")
    project.set_Controls("parmMax", 6.0, variable=":0:X")
    hist.data["Instrument Parameters"][0]["X"][1] = min(
        4.0, float(hist.data["Instrument Parameters"][0]["X"][1])
    )
    history = [snapshot(project, "loaded")]

    if args.sizes:
        for phase in phases:
            project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
            )
            refine(project, history, f"size_{phase.name}")
    if args.mustrain:
        for phase in phases:
            project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
            refine(project, history, f"mustrain_{phase.name}")

    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    refine(project, history, "reconverged")
    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
