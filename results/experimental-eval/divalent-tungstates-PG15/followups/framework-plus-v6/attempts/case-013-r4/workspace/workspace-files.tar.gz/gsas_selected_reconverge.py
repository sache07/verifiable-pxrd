#!/usr/bin/env python3
"""Reconverge the selected physical profile, texture and structure model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


TEXTURED = {"wo3_1528915", "massicot_2310433", "pb2wo5_from_mo_7220560"}


def clear_frozen(project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--reset-pb3-parent", action="store_true")
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    phases = project.phases()
    if args.reset_pb3_parent:
        pb3 = next(phase for phase in phases if phase.name == "pb3wo6_from_u_2310493")
        # Undo the statistically unsupported (<1 sigma) Pb2-orbit trial.
        pb3.atoms()[2].coordinates = (0.032, 0.25, 0.026)
    project.set_Controls("cycles", 14)
    clear_frozen(project)
    instrument["SH/L"][2] = False
    instrument["Zero"][2] = False
    instrument["U"][1] = 0.0
    instrument["U"][2] = False
    instrument["X"][1] = 6.0
    instrument["X"][2] = False
    # GSAS-II's scripting API returns after a scalar Background request, so
    # these must be separate calls or the later flags are silently skipped.
    histogram.set_refinements({"Background": True})
    histogram.set_refinements({"Sample Parameters": ["Shift"]})
    histogram.set_refinements({"Instrument Parameters": ["Polariz.", "W"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = phase.name in TEXTURED
        for atom in phase.atoms():
            atom.refinement_flags = ""
        if phase.name == "pbwo4_9009811":
            hap["Mustrain"][2][0] = True
            for atom in phase.atoms():
                atom.refinement_flags = "U"
        elif phase.name == "wo3_1528915":
            hap["Size"][2][0] = True
        elif phase.name == "massicot_2310433":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2][0] = False
        elif phase.name == "pb2wo5_from_mo_7220560":
            hap["Mustrain"][2][0] = True
        elif phase.name == "pb3wo6_from_u_2310493":
            hap["Size"][0] = "isotropic"
            hap["Size"][2][0] = True
            hap["Pref.Ori."][2] = False
            project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
            project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:0:Size;i")
    history = [snapshot(project, "selected_model_loaded")]
    for index in range(4):
        clear_frozen(project)
        project.refine(makeBack=False)
        state = snapshot(project, f"selected_model_{index + 1}")
        history.append(state)
        print(f"{state['label']}: Rwp={state['rwp_percent']:.4f}%")
    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
