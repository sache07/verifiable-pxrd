#!/usr/bin/env python3
"""Refine one constrained isotropic displacement parameter per phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


def run(project, history, label, repeats=1):
    for index in range(repeats):
        project.refine(makeBack=False)
        state = snapshot(project, label if repeats == 1 else f"{label}_{index + 1}")
        history.append(state)
        print(f"{state['label']}: Rwp={state['rwp_percent']:.4f}%")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Controls("cycles", 10)
    project.set_Frozen()
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})

    # This project has no scientific constraints yet; define one AUiso master
    # per phase so the parameterization matches the generator exactly.
    project.get_Constraints("Phase")[:] = []
    project.index_ids()
    first_constraint = True
    for phase in phases:
        variables = []
        for atom_index, atom in enumerate(phase.atoms()):
            if atom.adp_flag != "I":
                raise ValueError(f"Expected isotropic ADP in {phase.name}")
            atom.refinement_flags = "U"
            variables.append(f"{phase.id}::AUiso:{atom_index}")
            project.set_Controls("parmMin", 0.001, variable=variables[-1])
            project.set_Controls("parmMax", 0.03, variable=variables[-1])
        if len(variables) > 1:
            project.add_EquivConstr(
                variables,
                reloadIdx=first_constraint,
                override=False,
            )
            first_constraint = False

    history = [snapshot(project, "uiso_constraints_added")]
    run(project, history, "phase_common_uiso", repeats=3)

    # Re-open geometry only after the intensity-versus-angle term is settled.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.set_Frozen()
    run(project, history, "uiso_geometry_reconverged", repeats=2)
    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
