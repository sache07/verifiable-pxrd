#!/usr/bin/env python3
"""Refine one controlled parameter block from a saved GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--block", required=True, choices=("geometry", "width", "phase_widths", "textures"))
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    histogram = project.histogram(0)
    instrument = histogram.data["Instrument Parameters"][0]
    phases = project.phases()
    project.set_Controls("cycles", 16)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}

    # Start every block from a frozen, physically selected state.
    histogram.clear_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["U", "W", "X", "Polariz.", "SH/L", "Zero"],
        }
    )
    instrument["U"][1] = 0.0
    instrument["X"][1] = 6.0
    histogram.set_refinements({"Background": True})
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""

    if args.block == "geometry":
        histogram.set_refinements({"Sample Parameters": ["Shift"]})
        for phase in phases:
            phase.set_refinements({"Cell": True})
    elif args.block == "width":
        histogram.set_refinements({"Instrument Parameters": ["W"]})
    elif args.block == "phase_widths":
        for phase in phases:
            hap = phase.data["Histograms"][histogram.name]
            if phase.name == "pbwo4_9009811":
                hap["Mustrain"][2][0] = True
            elif phase.name == "wo3_1528915":
                hap["Size"][2][0] = True
            elif phase.name == "pb2wo5_from_mo_7220560":
                hap["Mustrain"][2][0] = True
            elif phase.name == "pb3wo6_from_u_2310493":
                hap["Size"][2][0] = True
    else:
        for phase in phases:
            if phase.name in {"wo3_1528915", "massicot_2310433", "pb2wo5_from_mo_7220560"}:
                phase.data["Histograms"][histogram.name]["Pref.Ori."][2] = True

    history = [snapshot(project, f"{args.block}_loaded")]
    for index in range(2):
        project.refine(makeBack=False)
        state = snapshot(project, f"{args.block}_{index + 1}")
        history.append(state)
        print(f"{state['label']}: Rwp={state['rwp_percent']:.4f}%")
    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
