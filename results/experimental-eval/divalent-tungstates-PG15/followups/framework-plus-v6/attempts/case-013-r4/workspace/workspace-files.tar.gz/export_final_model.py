#!/usr/bin/env python3
"""Freeze a GSAS-II project and export its saved atomic phases exactly."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("final", type=Path)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    if args.final.exists() and not args.overwrite:
        raise SystemExit(f"Refusing to overwrite {args.final}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.final.resolve()))

    # Reopen the frozen file and export saved atoms/cells, not potentially stale
    # values held in a covariance record.
    project = G2.G2Project(gpxfile=str(args.final.resolve()))
    histogram = project.histogram(0)
    project.data["Covariance"]["data"] = {}
    amounts = []
    rows = []
    for index, phase in enumerate(project.phases(), start=1):
        filename = f"phase_{index}_{slug(phase.name)}.cif"
        phase.export_CIF(str((args.final.parent / filename).resolve()))
        hap = phase.data["Histograms"][histogram.name]
        amount = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        amounts.append(amount)
        rows.append(
            {
                "name": phase.name,
                "cif_path": filename,
                "scale": float(hap["Scale"][0]),
                "cell_mass": float(phase.data["General"]["Mass"]),
                "cell": phase.get_cell(),
            }
        )
    total = sum(amounts)
    for row, amount in zip(rows, amounts):
        row["weight_fraction"] = amount / total
    summary = {
        "project": args.final.name,
        "histogram": histogram.name,
        "saved_rwp_percent": histogram.get_wR(),
        "phases": rows,
    }
    (args.final.parent / "final_model.json").write_text(
        json.dumps(summary, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
