#!/usr/bin/env python3
"""Combine the replay-stable interior March-Dollase terms and reconverge."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


TEXTURES = {
    "wo3_1528915": ([0, 1, 0], 0.933),
    "massicot_2310433": ([1, 0, 0], 0.789),
    "pb2wo5_from_mo_7220560": ([1, 0, 0], 1.161),
}


def clear_frozen(project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def refine(project, history, label, repeats=1) -> None:
    for index in range(repeats):
        clear_frozen(project)
        project.refine(makeBack=False)
        state = snapshot(project, label if repeats == 1 else f"{label}_{index + 1}")
        history.append(state)
        print(f"{state['label']}: Rwp={state['rwp_percent']:.4f}%")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    project.set_Controls("cycles", 12)
    clear_frozen(project)

    histogram.clear_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Polariz.", "W"],
        }
    )
    histogram.set_refinements({"Background": True})
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.clear_HAP_refinements({"Pref.Ori.": True})
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        if phase.name in TEXTURES:
            axis, ratio = TEXTURES[phase.name]
            hap["Pref.Ori."][1] = ratio
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
            project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")

    history = [snapshot(project, "interior_textures_loaded")]
    refine(project, history, "interior_textures", repeats=2)

    histogram.set_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Polariz.", "W"],
        }
    )
    for phase in phases:
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][histogram.name]
        if phase.name == "wo3_1528915":
            hap["Size"][2][0] = True
        if phase.name in {"pbwo4_9009811", "pb2wo5_from_mo_7220560"}:
            hap["Mustrain"][2][0] = True
    refine(project, history, "texture_profile_reconverged", repeats=2)
    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
