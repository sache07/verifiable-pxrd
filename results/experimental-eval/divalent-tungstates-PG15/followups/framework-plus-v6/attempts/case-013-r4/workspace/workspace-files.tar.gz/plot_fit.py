#!/usr/bin/env python3
"""Plot observed, calculated and difference curves from an exported fit CSV."""

from __future__ import annotations

import argparse

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv")
    parser.add_argument("png")
    args = parser.parse_args()
    table = pd.read_csv(args.csv)
    x = table["two_theta_deg"].to_numpy(float)
    yo = table["observed"].to_numpy(float)
    yc = table["calculated"].to_numpy(float)
    yd = table["difference"].to_numpy(float)
    fig, axes = plt.subplots(5, 1, figsize=(16, 14))
    axes[0].plot(x, yo, color="black", lw=0.5, label="observed")
    axes[0].plot(x, yc, color="tab:red", lw=0.65, label="calculated")
    axes[0].plot(x, yd - 0.08 * np.max(yo), color="tab:blue", lw=0.45, label="difference, offset")
    axes[0].set_xlim(x[0], x[-1])
    axes[0].legend(loc="upper right", ncol=3)
    axes[0].set_ylabel("counts")
    for axis, (lo, hi) in zip(axes[1:], [(20, 35), (35, 50), (50, 65), (65, 82)]):
        mask = (x >= lo) & (x <= hi)
        axis.plot(x[mask], yo[mask], color="black", lw=0.7)
        axis.plot(x[mask], yc[mask], color="tab:red", lw=0.8)
        axis.plot(x[mask], yd[mask], color="tab:blue", lw=0.55)
        axis.axhline(0, color="0.7", lw=0.5)
        axis.set_xlim(lo, hi)
        axis.set_ylabel("counts")
    axes[-1].set_xlabel(r"$2\theta$ (deg)")
    fig.tight_layout()
    fig.savefig(args.png, dpi=180)


if __name__ == "__main__":
    main()
