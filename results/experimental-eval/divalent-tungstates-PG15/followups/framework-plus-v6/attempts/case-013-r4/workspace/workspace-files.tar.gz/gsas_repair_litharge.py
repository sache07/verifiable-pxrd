#!/usr/bin/env python3
"""Repair the P4/nmm origin-setting import of litharge to stoichiometric PbO."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIspc as G2spc
from GSASII.GSASIIscriptable import SetupGeneral


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    phase = project.phase("litharge_9012700")
    atoms = phase.data["Atoms"]
    cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
    # In GSAS-II's selected origin, Pb on 2c is (1/4,1/4,z). The CIF
    # importer had placed it at (3/4,1/4,z), a multiplicity-four orbit.
    atoms[0][cx:cx + 3] = [0.25, 0.25, atoms[0][cx + 2]]
    G2spc.UpdateSytSym(phase.data)
    SetupGeneral(phase.data, None)
    if atoms[0][cs + 1] != 2 or atoms[1][cs + 1] != 2:
        raise RuntimeError(f"Unexpected repaired multiplicities: {atoms[0][cs + 1]}, {atoms[1][cs + 1]}")
    expected = 2 * (207.2 + 15.999)
    if abs(float(phase.data["General"]["Mass"]) - expected) > 0.1:
        raise RuntimeError(f"Unexpected repaired cell mass: {phase.data['General']['Mass']}")
    project.save()
    print("litharge multiplicities", atoms[0][cs + 1], atoms[1][cs + 1])
    print("litharge cell mass", phase.data["General"]["Mass"])


if __name__ == "__main__":
    main()
