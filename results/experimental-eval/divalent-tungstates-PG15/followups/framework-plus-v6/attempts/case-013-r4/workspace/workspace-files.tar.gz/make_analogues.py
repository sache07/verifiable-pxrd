#!/usr/bin/env python3
"""Construct chemically justified Pb2WO5 analogue models from COD parents."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
from pymatgen.io.cif import CifParser

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "learned" / "divalent-tungstates" / "runtime"))
from models import write_synthetic_model


CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def source_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    out = ROOT / "candidates" / "analogues"
    out.mkdir(parents=True, exist_ok=True)
    cases = [
        ("pb2wo5_from_mo_7220560", "7220560", {"Mo": "W"}),
        ("pb2wo5_from_cr_8103050", "8103050", {"Cr": "W"}),
        ("pb3wo6_from_u_2310493", "2310493", {"U": "W"}),
    ]
    provenance = []
    for name, cod_id, substitutions in cases:
        parser = CifParser(source_path(cod_id), occupancy_tolerance=1.0, site_tolerance=1e-5, frac_tolerance=0)
        structures = parser.parse_structures(primitive=False, on_error="raise")
        if len(structures) != 1:
            raise ValueError(f"Expected one structure in COD {cod_id}")
        structure = structures[0]
        structure.remove_oxidation_states()
        before = structure.composition.reduced_formula
        structure.replace_species(substitutions)
        distance = structure.distance_matrix.copy()
        np.fill_diagonal(distance, np.inf)
        nearest = float(np.min(distance))
        if nearest < 0.8 or not 0.5 < float(structure.density) < 30:
            raise ValueError(f"Physical screen failed for {name}")
        target = out / f"{name}.cif"
        write_synthetic_model(structure, target)
        provenance.append(
            {
                "id": name,
                "parent_cod_id": cod_id,
                "parent_formula": before,
                "target_formula": structure.composition.reduced_formula,
                "substitution": substitutions,
                "cell_retained_from_parent": True,
                "minimum_separation_A": nearest,
                "density_g_cm3": float(structure.density),
                "output": str(target.relative_to(ROOT)),
            }
        )
    (out / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")


if __name__ == "__main__":
    main()
