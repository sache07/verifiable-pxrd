#!/usr/bin/env python3
"""Prune unsupported width terms, fit polarization, and reconverge geometry."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


def run(project, history, label, repeats=1):
    for index in range(repeats):
        project.refine(makeBack=False)
        state = snapshot(project, label if repeats == 1 else f"{label}_{index + 1}")
        history.append(state)
        print(f"{state['label']}: Rwp={state['rwp_percent']:.4f}%")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}

    inst = hist.data["Instrument Parameters"][0]
    hist.clear_refinements({"Instrument Parameters": ["U", "X", "SH/L"]})
    inst["U"][1] = 0.0
    inst["X"][1] = 6.0
    inst["SH/L"][1] = 0.03
    hist.set_refinements({"Instrument Parameters": ["W", "Polariz."]})
    project.set_Controls("parmMin", 2.0, variable=":0:W")
    project.set_Controls("parmMax", 40.0, variable=":0:W")
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.set_Controls("parmMin", -1000.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1000.0, variable=":0:Shift")
    hist.set_refinements({"Background": True})
    hist.clear_refinements({"Sample Parameters": ["Shift"]})

    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][hist.name]
        # Explicit retained profile inventory from the controlled comparisons.
        keep_size = phase.name == "wo3_2106293"
        keep_strain = phase.name in {
            "pbwo4_9009811",
            "massicot_2310433",
            "pb2wo5_from_mo_7220560",
        }
        hap["Size"][2][0] = keep_size
        if not keep_size:
            hap["Size"][1][0] = {
                "massicot_2310433": 0.04,
            }.get(phase.name, 1.5)
        hap["Mustrain"][2][0] = keep_strain
        if not keep_strain:
            hap["Mustrain"][1][0] = 0.0

    history = [snapshot(project, "pruned_loaded")]
    run(project, history, "polarization_profile_fixed_geometry", repeats=2)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    run(project, history, "geometry_reconverged", repeats=3)

    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
