#!/usr/bin/env python3
"""Refine one additional March-Dollase term with other texture terms fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


def clear_frozen(project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--axis", required=True, nargs=3, type=int)
    parser.add_argument("--start", type=float, default=1.0)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    target = next(phase for phase in phases if phase.name == args.phase)
    project.set_Controls("cycles", 12)
    clear_frozen(project)
    histogram.clear_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Polariz.", "W", "SH/L"],
        }
    )
    histogram.set_refinements({"Background": True})
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
    hap = target.data["Histograms"][histogram.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = args.start
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(args.axis)
    project.set_Controls("parmMin", 0.7, variable=f"{target.id}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{target.id}:0:MD")
    history = [snapshot(project, "texture_loaded")]
    for index in range(2):
        clear_frozen(project)
        project.refine(makeBack=False)
        state = snapshot(project, f"texture_{index + 1}")
        history.append(state)
        print(f"{state['label']}: Rwp={state['rwp_percent']:.4f}% MD={hap['Pref.Ori.'][1]:.6f}")
    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
