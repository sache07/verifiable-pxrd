#!/usr/bin/env python3
"""Screen one isotropic phase-size or microstrain term under a fixed profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


def clear_frozen(project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--mode", required=True, choices=("size", "strain"))
    parser.add_argument("--start", required=True, type=float)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    target = next(phase for phase in phases if phase.name == args.phase)
    project.set_Controls("cycles", 12)
    clear_frozen(project)
    histogram.clear_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Polariz.", "W", "SH/L"],
        }
    )
    histogram.set_refinements({"Background": True})
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
    hap = target.data["Histograms"][histogram.name]
    if args.mode == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = args.start
        hap["Size"][2][0] = True
        variable = f"{target.id}:0:Size;i"
        project.set_Controls("parmMin", 0.04, variable=variable)
        project.set_Controls("parmMax", 1.5, variable=variable)
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = args.start
        hap["Mustrain"][2][0] = True
        variable = f"{target.id}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 8000.0, variable=variable)
    history = [snapshot(project, "width_loaded")]
    for index in range(2):
        clear_frozen(project)
        project.refine(makeBack=False)
        state = snapshot(project, f"width_{index + 1}")
        history.append(state)
        value = hap["Size"][1][0] if args.mode == "size" else hap["Mustrain"][1][0]
        print(f"{state['label']}: Rwp={state['rwp_percent']:.4f}% value={value:.6g}")
    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
