#!/usr/bin/env python3
"""Screen one March-Dollase axis at a time under a fixed common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])
PHASES = {
    "pbwo4_9009811",
    "wo3_1528915",
    "massicot_2310433",
    "pb2wo5_from_mo_7220560",
    "pb3wo6_from_u_2310493",
}


def prepare(project, target_name, axis):
    histogram = project.histogram(0)
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    histogram.clear_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Polariz.", "W"],
        }
    )
    histogram.set_refinements({"Background": True})
    target = None
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.clear_HAP_refinements({"Pref.Ori.": True})
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        if phase.name == target_name:
            target = phase
    if target is None:
        raise KeyError(target_name)
    hap = target.data["Histograms"][histogram.name]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    project.set_Controls("parmMin", 0.7, variable=f"{target.id}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{target.id}:0:MD")
    return histogram, target, hap


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    rows = []
    probe = G2.G2Project(gpxfile=str(args.input.resolve()))
    names = [phase.name for phase in probe.phases() if phase.name in PHASES]
    del probe
    for name in names:
        for axis in AXES:
            if name == "pbwo4_9009811" and axis == (0, 1, 0):
                continue
            axis_tag = "".join(str(value) for value in axis)
            gpx = args.output_dir / f"{name}__{axis_tag}.gpx"
            if gpx.exists():
                raise SystemExit(f"Refusing to overwrite {gpx}")
            project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(gpx.resolve()))
            histogram, target, hap = prepare(project, name, axis)
            try:
                project.refine(makeBack=False)
                row = {
                    "phase": name,
                    "axis": list(axis),
                    "md_ratio": float(hap["Pref.Ori."][1]),
                    "rwp_percent": float(histogram.get_wR()),
                    "frozen": [
                        str(item)
                        for item in project.data["Controls"]["data"]
                        .get("parmFrozen", {})
                        .get("FrozenList", [])
                    ],
                    "project": str(gpx),
                }
                project.save()
            except Exception as exc:
                row = {"phase": name, "axis": list(axis), "error": repr(exc)}
            rows.append(row)
            print(json.dumps(row), flush=True)
    (args.output_dir / "screen.json").write_text(
        json.dumps(rows, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
