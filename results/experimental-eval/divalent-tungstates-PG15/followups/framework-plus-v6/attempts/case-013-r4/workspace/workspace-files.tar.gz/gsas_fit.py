#!/usr/bin/env python3
"""Create and refine comparable GSAS-II projects for phase-inventory trials.

Run this script with the GSAS-II Python interpreter. Candidate CIFs are the
standardized, physically screened models in candidates/pool/models.
"""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
MODEL_ROOTS = [
    ROOT / "candidates" / "pool" / "models",
    ROOT / "candidates" / "analogue_pool" / "models",
    ROOT / "candidates" / "analogue_extra_pool" / "models",
]


def write_observation_files(work: Path) -> tuple[Path, Path, np.ndarray, np.ndarray]:
    x, y = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1).T
    xye = work / "observed.xye"
    np.savetxt(xye, np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]), fmt="%.10g")
    inst = work / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha laboratory instrument; initial profile for refinement\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst, x, y


def background_start(x: np.ndarray, y: np.ndarray, degree: int = 7) -> list[float]:
    # Fit low quantiles in narrow angular bins, avoiding Bragg maxima.
    edges = np.linspace(x[0], x[-1], 151)
    xb, yb = [], []
    for lo, hi in zip(edges[:-1], edges[1:]):
        mask = (x >= lo) & (x < hi)
        if np.any(mask):
            xb.append(float(np.median(x[mask])))
            yb.append(float(np.quantile(y[mask], 0.12)))
    t = 2 * (np.asarray(xb) - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, np.asarray(yb), degree).tolist()


def set_neutral_hap(phase, histogram_name: str, initial_scale: float = 1.0) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Scale"] = [float(initial_scale), False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][1][1] = 10.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": phase.get_cell(),
                "size": copy.deepcopy(hap["Size"][:4]),
                "mustrain": copy.deepcopy(hap["Mustrain"][:4]),
                "preferred_orientation": copy.deepcopy(hap["Pref.Ori."][:4]),
            }
        )
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "residuals": dict(hist.data["data"][0]),
        "instrument": {k: v for k, v in inst.items() if k in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."}},
        "sample": {k: sample.get(k) for k in ["Type", "Gonio. radius", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]},
        "phases": phases,
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "variables": np.asarray(cov.get("variables", [])).tolist(),
        "sig": np.asarray(cov.get("sig", [])).tolist(),
    }


def run_refinement(project, history: list[dict], label: str) -> None:
    project.refine(makeBack=False)
    state = snapshot(project, label)
    history.append(state)
    scales = ", ".join(f"{p['name']}={p['scale']:.5g}" for p in state["phases"])
    print(f"{label}: Rwp={state['rwp_percent']:.4f}% {scales}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tag", required=True)
    parser.add_argument("--ids", required=True, help="comma-separated model IDs")
    parser.add_argument("--sizes", action="store_true", help="refine one isotropic size term per phase after the common profile")
    parser.add_argument("--mustrain", action="store_true", help="compare one isotropic microstrain term per phase after size")
    parser.add_argument("--asymmetry", action="store_true", help="test SH/L after the common U/W/X profile")
    args = parser.parse_args()

    ids = [item.strip() for item in args.ids.split(",") if item.strip()]
    work = ROOT / "trials" / args.tag
    work.mkdir(parents=True, exist_ok=True)
    gpx = work / f"{args.tag}.gpx"
    if gpx.exists():
        raise SystemExit(f"Refusing to overwrite existing project: {gpx}")

    G2.SetPrintLevel("warn")
    xye, instfile, x, y = write_observation_files(work)
    project = G2.G2Project(newgpx=str(gpx))
    phases = []
    for model_id in ids:
        path = next((folder / f"{model_id}.cif" for folder in MODEL_ROOTS if (folder / f"{model_id}.cif").is_file()), None)
        if path is None:
            raise FileNotFoundError(f"No standardized candidate CIF for {model_id}")
        phases.append(project.add_phase(str(path), phasename=model_id, fmthint="CIF"))
    hist = project.add_powder_histogram(str(xye), str(instfile), phases=phases)
    imported_x = np.asarray(hist.data["data"][1][0], float)
    imported_y = np.asarray(hist.data["data"][1][1], float)
    if imported_x.shape != x.shape or not np.allclose(imported_x, x, atol=1e-7, rtol=0):
        raise RuntimeError("GSAS-II import changed the observed grid")
    if not np.allclose(imported_y, y, atol=1e-5, rtol=0):
        raise RuntimeError("GSAS-II import changed observed intensities")

    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Shift"] = [-350.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    coeffs = background_start(x, y)
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(coeffs),
                "coeffs": coeffs,
                "refine": False,
            },
        }
    )
    for phase in phases:
        set_neutral_hap(phase, hist.name)

    project.set_Controls("cycles", 8)
    # Numerical/physical bounds for parameters released in this screen.
    project.set_Controls("parmMin", -1000.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1000.0, variable=":0:Shift")
    for name, lo, hi in [("U", 0.0, 60.0), ("W", 0.1, 60.0), ("X", 0.0, 6.0), ("SH/L", 0.001, 0.2)]:
        project.set_Controls("parmMin", lo, variable=f":0:{name}")
        project.set_Controls("parmMax", hi, variable=f":0:{name}")
    for phase in phases:
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMax", 1000.0, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMin", 0.02, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 100.0, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{phase.id}:0:Mustrain;i")

    history = [snapshot(project, "initial")]
    # Re-establish background and phase amplitudes before any cell/profile freedom.
    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    run_refinement(project, history, "background_scales")

    # One common angular correction, then cells under the same background/scales.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(project, history, "shift")
    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_refinement(project, history, "cells")

    # Nonnegative common U/W/X profile, followed by axial-divergence asymmetry.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    run_refinement(project, history, "common_uwx")
    if args.asymmetry:
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        run_refinement(project, history, "common_asymmetry")

    if args.sizes:
        # A common Lorentzian term can otherwise run to its bound before phase
        # widths are available. Re-open it from a physical interior value.
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        hist.data["Instrument Parameters"][0]["X"][1] = min(
            4.0, float(hist.data["Instrument Parameters"][0]["X"][1])
        )
        for phase in phases:
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True}})
            run_refinement(project, history, f"size_{phase.name}")
    if args.mustrain:
        for phase in phases:
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
            run_refinement(project, history, f"mustrain_{phase.name}")

    # Final common reconvergence after any phase-width additions.
    run_refinement(project, history, "reconverged")
    project.save()
    (work / "summary.json").write_text(json.dumps({"ids": ids, "history": history}, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
