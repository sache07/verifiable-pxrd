#!/usr/bin/env python3
"""Compare isotropic strain phase-by-phase on a bounded size baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


SIZE_START = {
    "pbwo4_9009811": 1.5,
    "wo3_2106293": 0.136,
    "litharge_9012700": 1.5,
    "massicot_2310433": 0.04,
    "pb2wo5_from_mo_7220560": 0.157,
    "pb3wo6_from_u_2310493": 0.04,
    "pb3o4_1537983": 1.5,
}


def run(project, history, label, repeats=1):
    for index in range(repeats):
        project.refine(makeBack=False)
        state = snapshot(project, label if repeats == 1 else f"{label}_{index + 1}")
        history.append(state)
        print(f"{state['label']}: Rwp={state['rwp_percent']:.4f}%")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}

    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Background": True})
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1], inst["W"][1], inst["X"][1], inst["SH/L"][1] = 5.0, 5.0, 0.5, 0.03

    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = SIZE_START[phase.name]
        # Retain the two replay-stable interior size terms from the preceding run.
        hap["Size"][2][0] = phase.name in {"wo3_2106293", "pb2wo5_from_mo_7220560"}
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;i")

    history = [snapshot(project, "size_baseline_loaded")]
    run(project, history, "size_baseline_fixed_profile", repeats=2)

    for phase in phases:
        before = float(project.histogram(0).get_wR())
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 800.0
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        run(project, history, f"strain_{phase.name}")
        after = float(project.histogram(0).get_wR())
        value = float(hap["Mustrain"][1][0])
        if after > before - 0.01 or not (30.0 < value < 7999.0):
            phase.clear_HAP_refinements({"Mustrain": True})
            hap["Mustrain"][1][0] = 0.0
            project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
            run(project, history, f"reject_strain_{phase.name}")

    for name, lo, hi in [("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0)]:
        project.set_Controls("parmMin", lo, variable=f":0:{name}")
        project.set_Controls("parmMax", hi, variable=f":0:{name}")
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    run(project, history, "common_profile_with_size_strain", repeats=3)

    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
