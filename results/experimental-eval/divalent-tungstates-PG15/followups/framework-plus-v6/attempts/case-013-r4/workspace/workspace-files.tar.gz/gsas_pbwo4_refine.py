#!/usr/bin/env python3
"""Refine the supported PbWO4 Uiso and symmetry-allowed coordinates."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


TARGET = "pbwo4_9009811"


def clear_frozen(project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def refine(project, history, label, repeats=1) -> None:
    for index in range(repeats):
        clear_frozen(project)
        project.refine(makeBack=False)
        state = snapshot(project, label if repeats == 1 else f"{label}_{index + 1}")
        history.append(state)
        print(f"{state['label']}: Rwp={state['rwp_percent']:.4f}%")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--uiso-only", action="store_true")
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    target = next(phase for phase in phases if phase.name == TARGET)
    project.set_Controls("cycles", 12)
    clear_frozen(project)

    project.get_Constraints("Phase")[:] = []
    project.index_ids()
    variables = []
    for phase in phases:
        for atom_index, atom in enumerate(phase.atoms()):
            atom.uiso = 0.005
            atom.refinement_flags = ""
            if phase.name == TARGET:
                atom.refinement_flags = "U"
                variables.append(f"{phase.id}::AUiso:{atom_index}")
    project.add_EquivConstr(variables, reloadIdx=True, override=False)

    # First settle the one supported displacement parameter with intensity
    # nuisance terms, while positions, geometry and widths remain fixed.
    histogram.clear_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Polariz.", "W"],
        }
    )
    histogram.set_refinements({"Background": True})
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    history = [snapshot(project, "clean_pbwo4_uiso_loaded")]
    refine(project, history, "pbwo4_uiso", repeats=2)

    if args.uiso_only:
        project.save()
        args.output.with_suffix(".summary.json").write_text(
            json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
        )
        return

    # GSAS-II automatically applies the site-symmetry constraints to dAx/dAy/dAz.
    for atom in target.atoms():
        atom.refinement_flags = "XU"
    refine(project, history, "pbwo4_coordinates", repeats=2)

    # Re-open the already accepted common geometry/profile and reconverge it.
    histogram.set_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Polariz.", "W"],
        }
    )
    for phase in phases:
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][histogram.name]
        if phase.name == "wo3_1528915":
            hap["Size"][2][0] = True
        if phase.name in {"pbwo4_9009811", "pb2wo5_from_mo_7220560"}:
            hap["Mustrain"][2][0] = True
    refine(project, history, "pbwo4_structure_reconverged", repeats=2)
    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
