#!/usr/bin/env python3
"""Keep only phase-common Uiso terms supported by the clean baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_fit import snapshot


SUPPORTED = {"pbwo4_9009811", "pb2wo5_from_mo_7220560"}


def clear_frozen(project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def refine(project, history, label, repeats=1) -> None:
    for index in range(repeats):
        clear_frozen(project)
        project.refine(makeBack=False)
        state = snapshot(project, label if repeats == 1 else f"{label}_{index + 1}")
        history.append(state)
        print(f"{state['label']}: Rwp={state['rwp_percent']:.4f}%")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite {args.output}")
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    project.set_Controls("cycles", 12)
    clear_frozen(project)

    # Reset the rejected all-phase trial, then restore only the two phase terms
    # that gave interior values. Equality constraints reproduce the generator's
    # one-isotropic-U value per phase.
    project.get_Constraints("Phase")[:] = []
    project.index_ids()
    first = True
    for phase in phases:
        variables = []
        for atom_index, atom in enumerate(phase.atoms()):
            atom.uiso = 0.005
            atom.refinement_flags = ""
            if phase.name in SUPPORTED:
                atom.refinement_flags = "U"
                variables.append(f"{phase.id}::AUiso:{atom_index}")
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=first, override=False)
            first = False

    # Isolate the displacement signal from peak positions and widths first.
    histogram.clear_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Polariz.", "W"],
        }
    )
    histogram.set_refinements({"Background": True})
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]

    history = [snapshot(project, "supported_uiso_loaded")]
    refine(project, history, "supported_uiso_scales", repeats=2)

    # Rebuild the accepted common profile and geometry after changing the
    # intensity model.
    histogram.set_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Polariz.", "W"],
        }
    )
    for phase in phases:
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][histogram.name]
        if phase.name == "wo3_1528915":
            hap["Size"][2][0] = True
        if phase.name in {"pbwo4_9009811", "pb2wo5_from_mo_7220560"}:
            hap["Mustrain"][2][0] = True
    refine(project, history, "supported_uiso_reconverged", repeats=2)
    project.save()
    args.output.with_suffix(".summary.json").write_text(
        json.dumps({"history": history}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
