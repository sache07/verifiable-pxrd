#!/usr/bin/env python3
"""Refine bounded equatorial/axial microstrain for one phase."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--direction", nargs=3, type=int, default=[0, 0, 1])
    parser.add_argument("--equatorial", type=float, default=6000.0)
    parser.add_argument("--axial", type=float, default=3000.0)
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.source)
    project.save(args.output)
    project.set_Frozen()
    histogram = project.histograms()[0]
    phases = project.phases()
    phase = phases[args.phase]
    for candidate in phases:
        hap = candidate.data["Histograms"][histogram.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False
    hap = phase.data["Histograms"][histogram.name]
    hap["Mustrain"][1][0] = args.equatorial
    hap["Mustrain"][1][1] = args.axial
    phase.set_HAP_refinements(
        {
            "Mustrain": {
                "type": "uniaxial",
                "direction": args.direction,
                "refine": True,
            }
        }
    )
    for suffix in ("i", "a"):
        project.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;{suffix}")
        project.set_Controls("parmMax", 8000.0, variable=f"{args.phase}:0:Mustrain;{suffix}")
    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save(args.output)
    masses = [
        float(p.data["General"]["Mass"] * p.data["Histograms"][histogram.name]["Scale"][0])
        for p in phases
    ]
    total = sum(max(0.0, value) for value in masses)
    print(
        json.dumps(
            {
                "rwp_percent": float(histogram.get_wR()),
                "fractions": [max(0.0, value) / total for value in masses],
                "microstrain": hap["Mustrain"],
                "frozen": project.get_Frozen(),
                "vary_list": [
                    str(v) for v in project.data["Covariance"]["data"].get("varyList", [])
                ],
            },
            indent=2,
            allow_nan=False,
        )
    )


if __name__ == "__main__":
    main()
