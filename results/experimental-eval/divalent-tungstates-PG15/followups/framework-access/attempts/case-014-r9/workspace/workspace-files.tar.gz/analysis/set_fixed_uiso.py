#!/usr/bin/env python3
"""Set one fixed isotropic displacement parameter per selected phase."""

from __future__ import annotations

import argparse

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--set", action="append", required=True, metavar="PHASE:UISO")
    args = parser.parse_args()

    project = G2.G2Project(args.source)
    for item in args.set:
        phase_number, value = item.split(":", 1)
        phase = project.phases()[int(phase_number)]
        for atom in phase.atoms():
            atom.uiso = float(value)
            atom.refinement_flags = ""
    project.save(args.output)


if __name__ == "__main__":
    main()
