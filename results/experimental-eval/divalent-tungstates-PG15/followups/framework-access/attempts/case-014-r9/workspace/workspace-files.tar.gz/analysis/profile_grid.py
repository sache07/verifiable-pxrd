#!/usr/bin/env python3
"""Grid fixed size and uniaxial-strain values for one phase."""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def floats(value: str) -> list[float]:
    return [float(v) for v in value.split(",")]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("outdir")
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--sizes", type=floats, required=True)
    parser.add_argument("--equatorial", type=floats, required=True)
    parser.add_argument("--axial", type=floats, required=True)
    parser.add_argument("--cycles", type=int, default=2)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    rows = []
    for size, equatorial, axial in itertools.product(args.sizes, args.equatorial, args.axial):
        tag = f"s{size:g}_e{equatorial:g}_a{axial:g}".replace(".", "p")
        output = outdir / f"{tag}.gpx"
        project = G2.G2Project(args.source)
        project.save(str(output))
        project.set_Frozen()
        histogram = project.histograms()[0]
        phases = project.phases()
        for candidate in phases:
            hap = candidate.data["Histograms"][histogram.name]
            hap["Size"][2] = [False for _ in hap["Size"][2]]
            hap["Size"][5] = [False for _ in hap["Size"][5]]
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap = phases[args.phase].data["Histograms"][histogram.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = equatorial
        hap["Mustrain"][1][1] = axial
        hap["Mustrain"][3] = [0, 0, 1]
        project.set_Controls("cycles", args.cycles)
        project.refine()
        project.save(str(output))
        masses = [
            float(p.data["General"]["Mass"] * p.data["Histograms"][histogram.name]["Scale"][0])
            for p in phases
        ]
        total = sum(max(0.0, value) for value in masses)
        row = {
            "size": size,
            "equatorial": equatorial,
            "axial": axial,
            "rwp_percent": float(histogram.get_wR()),
            "fractions": [max(0.0, value) / total for value in masses],
            "project": str(output),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    rows.sort(key=lambda row: row["rwp_percent"])
    (outdir / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")
    print("BEST", json.dumps(rows[0]))


if __name__ == "__main__":
    main()
