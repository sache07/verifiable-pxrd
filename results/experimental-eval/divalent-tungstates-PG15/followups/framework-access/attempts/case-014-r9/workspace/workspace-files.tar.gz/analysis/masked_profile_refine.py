#!/usr/bin/env python3
"""Fit profile terms on selected, phase-diagnostic angular windows."""

from __future__ import annotations

import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


PRINCIPAL_WINDOWS = [
    (17.95, 18.72),
    (27.55, 28.42),
    (29.96, 30.53),
    (33.05, 33.78),
    (37.82, 38.62),
    (45.08, 45.86),
    (47.40, 48.08),
    (51.62, 52.31),
    (55.70, 56.39),
    (57.03, 57.69),
    (72.02, 73.36),
    (76.04, 76.84),
    (77.13, 77.96),
    (78.85, 79.58),
    (81.49, 82.26),
    (84.72, 85.53),
    (86.42, 87.37),
    (94.62, 95.51),
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--phase", type=int, default=0)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--instrument-only", action="store_true")
    parser.add_argument("--effective-principal-profile", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.source)
    project.save(args.output)
    project.set_Frozen()
    histogram = project.histograms()[0]
    phases = project.phases()

    x = np.asarray(histogram.data["data"][1][0], dtype=float)
    weights = np.asarray(histogram.data["data"][1][2], dtype=float)
    use = np.zeros(x.shape, dtype=bool)
    for low, high in PRINCIPAL_WINDOWS:
        use |= (x >= low) & (x <= high)
    histogram.data["data"][1][2][:] = np.where(use, weights, 0.0)

    histogram.clear_refinements({"Background": True})
    histogram.clear_refinements(
        {"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L", "Zero", "Polariz."]}
    )
    histogram.SampleParameters["Shift"][1] = False
    histogram.SampleParameters["SurfRoughA"][1] = False
    histogram.SampleParameters["SurfRoughB"][1] = False
    for i, phase in enumerate(phases):
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = i == args.phase
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False

    principal = phases[args.phase]
    if args.effective_principal_profile:
        principal.setSampleProfile(histogram, "size", "isotropic", 1.5)
        principal.setSampleProfile(histogram, "microstrain", "isotropic", 0.0)

    histogram.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for name, low, high in [
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.1),
    ]:
        project.set_Controls("parmMin", low, variable=f":0:{name}")
        project.set_Controls("parmMax", high, variable=f":0:{name}")

    if not args.instrument_only:
        principal.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
        project.set_Controls("parmMin", 0.04, variable=f"{args.phase}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{args.phase}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{args.phase}:0:Mustrain;i")

    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save(args.output)
    hap = principal.data["Histograms"][histogram.name]
    result = {
        "masked_rwp_percent": float(histogram.get_wR()),
        "used_points": int(use.sum()),
        "instrument": histogram.InstrumentParameters,
        "size": hap["Size"],
        "microstrain": hap["Mustrain"],
        "frozen": project.get_Frozen(),
        "vary_list": [str(v) for v in project.data["Covariance"]["data"].get("varyList", [])],
    }
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
