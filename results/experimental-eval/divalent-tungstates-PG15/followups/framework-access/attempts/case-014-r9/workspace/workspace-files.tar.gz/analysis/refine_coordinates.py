#!/usr/bin/env python3
"""Run a small, explicit atomic-coordinate refinement experiment."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def phase_state(phase: G2.G2Phase, histogram: G2.G2PwdrData) -> dict:
    hap = phase.data["Histograms"][histogram.name]
    return {
        "name": phase.name,
        "cell": phase.get_cell(),
        "scale": float(hap["Scale"][0]),
        "size": hap["Size"],
        "microstrain": hap["Mustrain"],
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "xyz": [float(v) for v in atom.coordinates],
                "uiso": float(atom.uiso),
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument(
        "--refine",
        action="append",
        default=[],
        metavar="PHASE:ATOM:FLAGS",
        help="phase index, atom label (or all), and GSAS-II atom flags",
    )
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--clear-all", action="store_true")
    parser.add_argument(
        "--max-delta",
        type=float,
        help="bound each refined fractional-coordinate change in this pass",
    )
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.source)
    project.save(args.output)
    phases = project.phases()
    histogram = project.histograms()[0]
    if args.clear_all:
        for phase in phases:
            phase.set_refinements({"Atoms": {"all": ""}})
    bounded_atoms: list[tuple[int, int, tuple[float, float, float]]] = []
    for spec in args.refine:
        phase_index, atom, flags = spec.split(":", 2)
        phase_number = int(phase_index)
        phases[phase_number].set_refinements({"Atoms": {atom: flags}})
        if args.max_delta is not None and "X" in flags:
            if atom == "all":
                bounded_atoms.extend(
                    (phase_number, i, tuple(float(v) for v in candidate.coordinates))
                    for i, candidate in enumerate(phases[phase_number].atoms())
                )
            else:
                atom_number = next(
                    i
                    for i, candidate in enumerate(phases[phase_number].atoms())
                    if candidate.label == atom
                )
                bounded_atoms.append(
                    (
                        phase_number,
                        atom_number,
                        tuple(
                            float(v)
                            for v in list(phases[phase_number].atoms())[atom_number].coordinates
                        ),
                    )
                )
    if args.max_delta is not None:
        project.set_Frozen()
        for phase_number, atom_number, coordinates in bounded_atoms:
            for axis, value in zip("xyz", coordinates):
                variable = f"{phase_number}::dA{axis}:{atom_number}"
                project.set_Controls("parmMin", value - args.max_delta, variable=variable)
                project.set_Controls("parmMax", value + args.max_delta, variable=variable)
    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save(args.output)

    masses = [
        float(p.data["General"]["Mass"] * p.data["Histograms"][histogram.name]["Scale"][0])
        for p in phases
    ]
    total = sum(max(0.0, v) for v in masses)
    result = {
        "rwp_percent": float(histogram.get_wR()),
        "fractions": [max(0.0, v) / total for v in masses],
        "phases": [phase_state(p, histogram) for p in phases],
        "vary_list": [str(v) for v in project.data["Covariance"]["data"].get("varyList", [])],
        "frozen": project.get_Frozen(),
    }
    summary = Path(args.output).with_suffix(".json")
    summary.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
