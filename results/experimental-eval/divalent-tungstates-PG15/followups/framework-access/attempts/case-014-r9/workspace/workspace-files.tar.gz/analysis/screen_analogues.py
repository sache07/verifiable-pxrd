#!/usr/bin/env python3
"""Screen one-cation tungstate COD structures as Sr-substituted analogues."""

from __future__ import annotations

import gzip
import argparse
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import differential_evolution


WORKSPACE = Path.cwd()
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
COD_INDEX = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/venv/"
    "lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz"
)
LAMBDA1 = 1.540598


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def transformed_positions(d: np.ndarray, lattice_scale: float, zero: float) -> np.ndarray:
    arg = LAMBDA1 / (2 * d * lattice_scale)
    if np.any(arg >= 1):
        return np.full_like(d, np.nan)
    pos = np.rad2deg(2 * np.arcsin(arg))
    # Approximate the common Bragg-Brentano specimen shift seen in the principal phase.
    return pos + zero + 0.40 * np.cos(np.deg2rad(pos / 2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--fit",
        default=".tmp/comparisons/two_phase_profile/fit.csv",
        help="CSV with x, observed, calculated, background, residual columns",
    )
    parser.add_argument("--out", default=".tmp/analogue_screen.json")
    args = parser.parse_args()
    fit = np.loadtxt(
        WORKSPACE / args.fit, delimiter=",", skiprows=1
    )
    x, observed, _calculated, _background, residual = fit.T
    white = gaussian_filter1d(residual, 2) / np.sqrt(np.maximum(observed, 1))
    # Capping prevents the strongest residual line from dominating the whole search.
    capped = np.clip(white, -5, 12)

    with gzip.open(COD_INDEX, "rt") as stream:
        index = json.load(stream)
    records = []
    for chemical_system, rows in index.items():
        elements = chemical_system.split("-")
        if len(elements) != 3 or "O" not in elements or "W" not in elements:
            continue
        parent = next(e for e in elements if e not in {"O", "W"})
        for formula, cod_id, space_group, r_factor in rows:
            records.append((parent, formula, cod_id, space_group, r_factor))

    calculator = XRDCalculator(wavelength=LAMBDA1)
    results = []
    for parent, formula, cod_id, space_group, r_factor in records:
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                parser = CifParser(
                    cod_path(cod_id), occupancy_tolerance=1.0, site_tolerance=1e-5, frac_tolerance=0
                )
                structures = parser.parse_structures(primitive=False, on_error="raise")
            if len(structures) != 1:
                continue
            structure = structures[0]
            structure.remove_oxidation_states()
            if len(structure) > 300:
                continue
            replacements = {
                element: "Sr"
                for element in structure.composition.elements
                if element.symbol not in {"O", "W"}
            }
            structure.replace_species(replacements)
            amounts = structure.composition.reduced_composition.get_el_amt_dict()
            sr, tungsten, oxygen = (amounts.get(k, 0.0) for k in ("Sr", "W", "O"))
            if not sr or not tungsten or not oxygen:
                continue
            charge_error = abs(oxygen - sr - 3 * tungsten) / oxygen
            if charge_error > 0.16:
                continue

            pattern = calculator.get_pattern(structure, two_theta_range=(8, 105), scaled=True)
            tt, intensity = np.asarray(pattern.x), np.asarray(pattern.y)
            keep = intensity > 0.35
            tt, intensity = tt[keep], intensity[keep]
            if len(tt) < 3:
                continue
            d = LAMBDA1 / (2 * np.sin(np.deg2rad(tt / 2)))
            peak_weight = np.sqrt(intensity)

            def objective(params: np.ndarray) -> float:
                pos = transformed_positions(d, float(params[0]), float(params[1]))
                if not np.all(np.isfinite(pos)):
                    return 1e6
                values = np.interp(pos, x, capped, left=-5, right=-5)
                return -float(np.sum(peak_weight * values) / np.sum(peak_weight))

            opt = differential_evolution(
                objective,
                [(0.78, 1.30), (-0.5, 0.5)],
                seed=735019,
                popsize=6,
                maxiter=14,
                polish=True,
                tol=1e-5,
            )
            results.append(
                {
                    "cod_id": cod_id,
                    "parent_element": parent,
                    "parent_formula": formula,
                    "analogue_formula": structure.composition.reduced_formula,
                    "sites": len(structure),
                    "space_group": structure.get_space_group_info(symprec=0.001),
                    "charge_error": charge_error,
                    "lattice_scale": float(opt.x[0]),
                    "zero_deg": float(opt.x[1]),
                    "peak_score": float(-opt.fun),
                    "r_factor": r_factor,
                }
            )
        except Exception as exc:
            results.append({"cod_id": cod_id, "error": str(exc)})

    valid = sorted((r for r in results if "peak_score" in r), key=lambda r: r["peak_score"], reverse=True)
    output = {"screened": len(records), "valid": len(valid), "ranked": valid, "errors": [r for r in results if "error" in r]}
    out = WORKSPACE / args.out
    out.write_text(json.dumps(output, indent=2, allow_nan=False) + "\n")
    for rank, row in enumerate(valid[:60], 1):
        print(
            f"{rank:2d} {row['cod_id']} {row['parent_formula']:<18} -> {row['analogue_formula']:<14} "
            f"SG={row['space_group'][0]:<8} sites={row['sites']:3d} score={row['peak_score']:.4f} "
            f"scale={row['lattice_scale']:.5f} zero={row['zero_deg']:+.4f}"
        )


if __name__ == "__main__":
    main()
