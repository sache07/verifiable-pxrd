#!/usr/bin/env python3
"""Restore full Poisson weights and refine only background and phase scales."""

from __future__ import annotations

import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--cycles", type=int, default=4)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.source)
    project.save(args.output)
    project.set_Frozen()
    histogram = project.histograms()[0]
    phases = project.phases()
    arrays = histogram.data["data"][1]
    arrays[2][:] = 1.0 / np.maximum(np.asarray(arrays[1], dtype=float), 1.0)

    histogram.set_refinements({"Background": True})
    histogram.clear_refinements(
        {"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L", "Zero", "Polariz."]}
    )
    for name in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        histogram.SampleParameters[name][1] = False
    for phase in phases:
        phase.data["General"]["Cell"][0] = False
        phase.set_refinements({"Atoms": {"all": ""}})
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False

    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save(args.output)
    masses = [
        float(p.data["General"]["Mass"] * p.data["Histograms"][histogram.name]["Scale"][0])
        for p in phases
    ]
    total = sum(max(0.0, value) for value in masses)
    result = {
        "rwp_percent": float(histogram.get_wR()),
        "fractions": [max(0.0, value) / total for value in masses],
        "instrument": histogram.InstrumentParameters,
        "sample": histogram.SampleParameters,
        "profiles": [
            {
                "phase": p.name,
                "size": p.data["Histograms"][histogram.name]["Size"],
                "microstrain": p.data["Histograms"][histogram.name]["Mustrain"],
                "texture": p.data["Histograms"][histogram.name]["Pref.Ori."],
            }
            for p in phases
        ],
    }
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
