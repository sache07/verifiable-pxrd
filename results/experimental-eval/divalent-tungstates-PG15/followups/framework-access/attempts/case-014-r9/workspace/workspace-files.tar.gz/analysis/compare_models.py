#!/usr/bin/env python3
"""Build a staged GSAS-II refinement for a supplied set of candidate phases."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def background_start(x: np.ndarray, y: np.ndarray, ncoeff: int) -> list[float]:
    """Estimate a smooth low envelope and express it as Chebyshev coefficients."""
    edges = np.linspace(x[0], x[-1], 181)
    xc, yc = [], []
    for lo, hi in zip(edges[:-1], edges[1:]):
        mask = (x >= lo) & (x < hi)
        if np.any(mask):
            xc.append((lo + hi) / 2)
            yc.append(np.percentile(y[mask], 10))
    t = 2 * (np.asarray(xc) - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, np.asarray(yc), ncoeff - 1).tolist()


def phase_summary(project: G2.G2Project, histogram: G2.G2PwdrData) -> list[dict]:
    rows = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(0.0, mass_scale))
        rows.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "mass_scale": mass_scale,
                "size": hap["Size"],
                "microstrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = mass / total if total else 0.0
    return rows


def snapshot(project: G2.G2Project, histogram: G2.G2PwdrData, stage: str) -> dict:
    return {
        "stage": stage,
        "rwp_percent": histogram.get_wR(),
        "residuals": histogram.residuals,
        "sample": histogram.SampleParameters,
        "instrument": histogram.InstrumentParameters,
        "phases": phase_summary(project, histogram),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True)
    parser.add_argument(
        "--phase",
        action="append",
        required=True,
        help="COD id and phase name as ID:NAME; first phase is treated as principal",
    )
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--profile", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    workspace = Path.cwd()
    out = workspace / ".tmp" / "comparisons" / args.name
    out.mkdir(parents=True, exist_ok=True)

    observed = np.loadtxt(workspace / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    x, y = observed.T
    np.savetxt(
        out / "pattern.xye",
        np.column_stack((x, y, np.sqrt(np.maximum(y, 1)))),
        fmt="%.8f %.8f %.8f",
    )
    (out / "instrument.instprm").write_text(
        "# trial GSAS-II instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )

    project = G2.G2Project(newgpx=str(out / "model.gpx"))
    phases = []
    for item in args.phase:
        cod_id, phase_name = item.split(":", 1)
        cif = workspace / ".tmp" / "candidates" / f"{cod_id}.cif"
        phases.append(project.add_phase(str(cif), phasename=phase_name, fmthint="CIF"))
    histogram = project.add_powder_histogram(
        str(out / "pattern.xye"),
        str(out / "instrument.instprm"),
        phases=phases,
        fmthint="xye",
    )
    histogram.SampleParameters["Scale"] = [1.0, False]
    histogram.SampleParameters["Type"] = "Bragg-Brentano"
    histogram.SampleParameters["Gonio. radius"] = 200.0
    histogram.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": background_start(x, y, 12),
                "refine": True,
            },
        }
    )
    for phase in phases:
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"] = [0.5, True]
        phase.setSampleProfile(histogram, "size", "isotropic", 0.5)
        phase.setSampleProfile(histogram, "microstrain", "isotropic", 1000.0)

    project.set_Controls("cycles", args.cycles)
    stages = []

    project.refine()
    stages.append(snapshot(project, histogram, "scale_background"))

    histogram.set_refinements({"Sample Parameters": ["Shift"]})
    phases[0].set_refinements({"Cell": True})
    project.refine()
    stages.append(snapshot(project, histogram, "principal_cell_shift"))

    for phase in phases[1:]:
        phase.set_refinements({"Cell": True})
    project.refine()
    stages.append(snapshot(project, histogram, "all_cells"))

    histogram.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    project.refine()
    stages.append(snapshot(project, histogram, "instrument"))

    if args.profile:
        for phase in phases:
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                }
            )
        project.refine()
        stages.append(snapshot(project, histogram, "profiles"))

    project.save(str(out / "model.gpx"))
    np.savetxt(
        out / "fit.csv",
        np.column_stack(
            (
                histogram.getdata("X"),
                histogram.getdata("Yobs"),
                histogram.getdata("Ycalc"),
                histogram.getdata("Background"),
                histogram.getdata("Residual"),
            )
        ),
        delimiter=",",
        header="two_theta,observed,calculated,background,difference",
        comments="",
    )
    result = {"name": args.name, "phase_specs": args.phase, "stages": stages}
    (out / "summary.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
