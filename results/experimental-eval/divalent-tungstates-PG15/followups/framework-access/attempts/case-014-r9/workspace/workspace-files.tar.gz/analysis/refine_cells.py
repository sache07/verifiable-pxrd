#!/usr/bin/env python3
"""Refine phase cells and common specimen displacement with profiles fixed."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.source)
    project.save(args.output)
    project.set_Frozen()
    histogram = project.histograms()[0]
    histogram.SampleParameters["Shift"][1] = True
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.set_refinements({"Atoms": {"all": ""}})
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False
    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save(args.output)
    print(
        json.dumps(
            {
                "rwp_percent": float(histogram.get_wR()),
                "shift": histogram.SampleParameters["Shift"],
                "cells": [phase.get_cell() for phase in project.phases()],
                "vary_list": [
                    str(v) for v in project.data["Covariance"]["data"].get("varyList", [])
                ],
            },
            indent=2,
            allow_nan=False,
        )
    )


if __name__ == "__main__":
    main()
