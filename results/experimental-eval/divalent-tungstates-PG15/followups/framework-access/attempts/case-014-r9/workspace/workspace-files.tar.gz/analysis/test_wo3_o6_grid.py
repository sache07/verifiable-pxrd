#!/usr/bin/env python3
"""Test the smallest repair of the anomalously close WO3 O6 site."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    G2.SetPrintLevel("warn")
    root = Path.cwd()
    source = root / ".tmp/comparisons/final_candidate.gpx"
    rows = []
    for y in [0.760, 0.765, 0.770, 0.775, 0.780, 0.790, 0.800]:
        output = root / ".tmp/comparisons" / f"wo3_o6_y{int(round(1000*y)):03d}.gpx"
        project = G2.G2Project(str(source))
        project.save(str(output))
        project.set_Frozen()
        histogram = project.histograms()[0]
        phase = project.phase("WO3")
        atom = next(atom for atom in phase.data["Atoms"] if atom[0] == "O6")
        atom[4] = y
        for candidate in project.phases():
            candidate.data["Histograms"][histogram.name]["Scale"][1] = True
        histogram.set_refinements({"Background": True})
        project.set_Controls("cycles", 5)
        project.refine()
        project.save(str(output))
        project.data["Covariance"]["data"] = {}
        cif = output.with_suffix(".cif")
        phase.export_CIF(str(cif))
        masses = [
            float(p.data["General"]["Mass"] * p.data["Histograms"][histogram.name]["Scale"][0])
            for p in project.phases()
        ]
        total = sum(masses)
        rows.append(
            {
                "o6_y": y,
                "rwp_percent": float(histogram.get_wR()),
                "wo3_weight_fraction": masses[1] / total,
                "project": str(output),
                "wo3_cif": str(cif),
            }
        )
    print(json.dumps(rows, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
