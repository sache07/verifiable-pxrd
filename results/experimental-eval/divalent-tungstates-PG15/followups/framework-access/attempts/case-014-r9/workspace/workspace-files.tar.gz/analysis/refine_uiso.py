#!/usr/bin/env python3
"""Refine one constrained isotropic displacement parameter per phase."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--phase", action="append", type=int, default=[])
    parser.add_argument("--fix-roughness", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.source)
    project.save(args.output)
    histogram = project.histograms()[0]
    phases = project.phases()
    selected = args.phase or list(range(len(phases)))
    project.set_Frozen()

    if args.fix_roughness:
        histogram.SampleParameters["SurfRoughA"][1] = False
        histogram.SampleParameters["SurfRoughB"][1] = False

    for phase_index in selected:
        phase = phases[phase_index]
        phase.set_refinements({"Atoms": {"all": "U"}})
        variables = [f"{phase_index}::AUiso:{i}" for i, _atom in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables)
        for variable in variables:
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)

    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save(args.output)

    masses = [
        float(p.data["General"]["Mass"] * p.data["Histograms"][histogram.name]["Scale"][0])
        for p in phases
    ]
    total = sum(max(0.0, value) for value in masses)
    result = {
        "rwp_percent": float(histogram.get_wR()),
        "fractions": [max(0.0, value) / total for value in masses],
        "uiso": [[float(a.uiso) for a in p.atoms()] for p in phases],
        "roughness": {
            "A": histogram.SampleParameters["SurfRoughA"],
            "B": histogram.SampleParameters["SurfRoughB"],
        },
        "vary_list": [str(v) for v in project.data["Covariance"]["data"].get("varyList", [])],
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
