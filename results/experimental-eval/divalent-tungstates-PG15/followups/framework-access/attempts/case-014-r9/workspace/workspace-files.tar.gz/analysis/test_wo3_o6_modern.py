#!/usr/bin/env python3
"""Test replacement of the suspect WO3 O6 coordinate from COD 2311041."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    G2.SetPrintLevel("warn")
    root = Path.cwd()
    output = root / ".tmp/comparisons/wo3_o6_modern.gpx"
    project = G2.G2Project(str(root / ".tmp/comparisons/final_candidate.gpx"))
    project.save(str(output))
    project.set_Frozen()
    histogram = project.histograms()[0]
    phase = project.phase("WO3")
    atom = next(atom for atom in phase.data["Atoms"] if atom[0] == "O6")
    atom[3:6] = [0.286, 0.513, 0.007]
    for candidate in project.phases():
        candidate.data["Histograms"][histogram.name]["Scale"][1] = True
    histogram.set_refinements({"Background": True})
    project.set_Controls("cycles", 5)
    project.refine()
    project.save(str(output))
    project.data["Covariance"]["data"] = {}
    phase.export_CIF(str(output.with_suffix(".cif")))
    masses = [
        candidate.data["General"]["Mass"]
        * candidate.data["Histograms"][histogram.name]["Scale"][0]
        for candidate in project.phases()
    ]
    print(histogram.get_wR(), masses[1] / sum(masses))


if __name__ == "__main__":
    main()
