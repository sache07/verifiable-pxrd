#!/usr/bin/env python3
"""Export the final, internally consistent GSAS-II submission artifacts."""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE_PROJECT = Path(".tmp/comparisons/final_candidate.gpx")
FINAL_PROJECT = Path("final.gpx")
PHASE_FILES = {
    "SrWO4": "phase_SrWO4.cif",
    "WO3": "phase_WO3.cif",
    "Sr3WO6_Pa3": "phase_Sr3WO6_Pa3.cif",
}
PHASE_METADATA = {
    "SrWO4": {
        "formula": "SrWO4",
        "identification": "scheelite strontium tungstate",
        "space_group": "I 41/a",
    },
    "WO3": {
        "formula": "WO3",
        "identification": "monoclinic tungsten(VI) oxide",
        "space_group": "P 21/c",
    },
    "Sr3WO6_Pa3": {
        "formula": "Sr3WO6",
        "identification": "cubic Pa-3 Sr3WO6-type analogue-derived model",
        "space_group": "P a -3",
    },
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    root = Path.cwd()
    source = root / SOURCE_PROJECT
    destination = root / FINAL_PROJECT
    if not source.is_file():
        raise FileNotFoundError(source)

    # Preserve the exact, already-refined binary project. All other artifacts
    # below are read from this copied file, not from a separate model.
    shutil.copy2(source, destination)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(destination))

    observed = np.loadtxt(root / "inputs/pattern.csv", delimiter=",", skiprows=1, ndmin=2)
    candidates = []
    for histogram in project.histograms():
        x = np.asarray(histogram.getdata("X"), dtype=float)
        y = np.asarray(histogram.getdata("Yobs"), dtype=float)
        if (
            x.shape == observed[:, 0].shape
            and np.allclose(x, observed[:, 0], rtol=0, atol=1e-7)
            and np.allclose(y, observed[:, 1], rtol=0, atol=1e-5)
        ):
            candidates.append(histogram)
    if len(candidates) != 1:
        raise RuntimeError(f"Expected one histogram matching pattern.csv, found {len(candidates)}")
    histogram = candidates[0]

    phases = []
    mass_scales = []
    for phase in project.phases():
        hap = phase.data.get("Histograms", {}).get(histogram.name)
        if not hap or not hap.get("Use", True) or float(hap["Scale"][0]) <= 0:
            continue
        if phase.name not in PHASE_FILES:
            raise RuntimeError(f"No output filename declared for phase {phase.name!r}")
        phases.append(phase)
        mass_scales.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
    if len(phases) != len(PHASE_FILES):
        raise RuntimeError("Final project phase inventory differs from the declared output inventory")
    total_mass_scale = float(sum(mass_scales))
    fractions = [value / total_mass_scale for value in mass_scales]

    x = np.asarray(histogram.getdata("X"), dtype=float)
    yobs = np.asarray(histogram.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    background = np.asarray(histogram.getdata("Background"), dtype=float)
    difference = yobs - ycalc
    if not (np.all(np.isfinite(ycalc)) and np.all(np.isfinite(background))):
        raise RuntimeError("Final calculated profile contains nonfinite values")
    if np.any(ycalc < 0):
        raise RuntimeError("Final calculated profile contains negative counts")

    np.savetxt(
        root / "fit.csv",
        np.column_stack((x, yobs, ycalc, difference, background)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.10f", "%.10f", "%.10f", "%.10f"],
    )

    # Ignore covariance substitutions during export so the CIFs contain the
    # full-precision saved phase values. This is an in-memory change only and
    # is deliberately not written back to final.gpx.
    project.data.setdefault("Covariance", {}).setdefault("data", {})
    project.data["Covariance"]["data"] = {}
    phase_rows = []
    for phase, fraction in zip(phases, fractions):
        filename = PHASE_FILES[phase.name]
        output = root / filename
        output.unlink(missing_ok=True)
        phase.export_CIF(str(output))
        if not output.is_file() or output.stat().st_size == 0:
            raise RuntimeError(f"CIF export failed for {phase.name}")
        phase_rows.append(
            {
                "name": phase.name,
                **PHASE_METADATA[phase.name],
                "cif_path": filename,
                "weight_fraction": fraction,
            }
        )

    weights = 1.0 / np.maximum(yobs, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    covariance = G2.G2Project(str(destination)).data.get("Covariance", {}).get("data", {})
    n_parameters = len(covariance.get("varyList", []))
    degrees_of_freedom = int(len(x) - n_parameters)
    denominator = float(np.sum(weights * yobs**2))
    rwp = 100.0 * np.sqrt(chi_square / denominator)
    rp = 100.0 * float(np.sum(np.abs(difference)) / np.sum(yobs))
    rexp = 100.0 * np.sqrt(degrees_of_freedom / denominator)
    reduced_chi_square = chi_square / degrees_of_freedom
    result = {
        "schema_version": 1,
        "project_file": FINAL_PROJECT.name,
        "refinement_histogram": histogram.name,
        "fractions_basis": "normalized over the modeled crystalline phases",
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent": float(rwp),
            "rp_percent": float(rp),
            "rexp_percent": float(rexp),
            "goodness_of_fit": float(np.sqrt(reduced_chi_square)),
            "chi_square": float(chi_square),
            "reduced_chi_square": float(reduced_chi_square),
            "n_points": int(len(x)),
            "n_refined_parameters_last_cycle": int(n_parameters),
            "weighting": "1/max(observed_counts,1)",
        },
        "project_sha256": sha256(destination),
    }
    (root / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
