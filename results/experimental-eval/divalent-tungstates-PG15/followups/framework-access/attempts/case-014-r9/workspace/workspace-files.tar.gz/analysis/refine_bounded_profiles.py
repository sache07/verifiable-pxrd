#!/usr/bin/env python3
"""Refine physically bounded phase and instrumental profile parameters."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--instrument", action="store_true")
    parser.add_argument("--shift", action="store_true")
    parser.add_argument("--zero", action="store_true")
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument(
        "--roughness",
        nargs=2,
        type=float,
        metavar=("A", "B"),
        help="initialize and refine Suortti surface-roughness A and B",
    )
    parser.add_argument("--fix-roughness", action="store_true")
    parser.add_argument("--roughness-b", type=float, help="fix A and refine only roughness B")
    parser.add_argument("--phase", action="append", type=int, default=[])
    parser.add_argument("--no-profiles", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.source)
    project.save(args.output)
    histogram = project.histograms()[0]
    phases = project.phases()
    selected = [] if args.no_profiles else (args.phase or list(range(len(phases))))

    # Remove stale frozen-at-a-bound bookkeeping before applying these bounds.
    project.set_Frozen()
    for i in selected:
        phases[i].set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
        project.set_Controls("parmMin", 0.04, variable=f"{i}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{i}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{i}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{i}:0:Mustrain;i")
        project.set_Controls("parmMin", 0.0, variable=f"{i}:0:Scale")

    if args.instrument:
        histogram.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        for name, lo, hi in [
            ("U", 0.0, 40.0),
            ("W", 2.0, 40.0),
            ("X", 0.1, 6.0),
            ("SH/L", 0.005, 0.1),
        ]:
            project.set_Controls("parmMin", lo, variable=f":0:{name}")
            project.set_Controls("parmMax", hi, variable=f":0:{name}")
    if args.shift:
        histogram.set_refinements({"Sample Parameters": ["Shift"]})
        project.set_Controls("parmMin", -800.0, variable=":0:Shift")
        project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    if args.zero:
        histogram.set_refinements({"Instrument Parameters": ["Zero"]})
        project.set_Controls("parmMin", -0.25, variable=":0:Zero")
        project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    if args.polarization:
        histogram.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    if args.roughness:
        histogram.SampleParameters["SurfRoughA"] = [args.roughness[0], True]
        histogram.SampleParameters["SurfRoughB"] = [args.roughness[1], True]
        project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.6, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")
    if args.fix_roughness:
        histogram.SampleParameters["SurfRoughA"][1] = False
        histogram.SampleParameters["SurfRoughB"][1] = False
    if args.roughness_b is not None:
        histogram.SampleParameters["SurfRoughA"][1] = False
        histogram.SampleParameters["SurfRoughB"] = [args.roughness_b, True]
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")

    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save(args.output)

    masses = [
        float(p.data["General"]["Mass"] * p.data["Histograms"][histogram.name]["Scale"][0])
        for p in phases
    ]
    total = sum(max(0.0, value) for value in masses)
    result = {
        "rwp_percent": float(histogram.get_wR()),
        "fractions": [max(0.0, value) / total for value in masses],
        "instrument": histogram.InstrumentParameters,
        "sample": histogram.SampleParameters,
        "phases": [
            {
                "name": p.name,
                "size": p.data["Histograms"][histogram.name]["Size"],
                "microstrain": p.data["Histograms"][histogram.name]["Mustrain"],
            }
            for p in phases
        ],
        "frozen": project.get_Frozen(),
        "vary_list": [str(v) for v in project.data["Covariance"]["data"].get("varyList", [])],
    }
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
