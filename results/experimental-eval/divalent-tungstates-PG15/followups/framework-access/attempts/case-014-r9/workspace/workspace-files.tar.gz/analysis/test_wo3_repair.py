#!/usr/bin/env python3
"""Compare a physically valid modern WO3 model at the fitted monoclinic cell."""

from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    G2.SetPrintLevel("warn")
    root = Path.cwd()
    source = root / ".tmp/comparisons/final_candidate.gpx"
    output = root / ".tmp/comparisons/wo3_modern.gpx"
    project = G2.G2Project(str(source))
    project.save(str(output))
    project.set_Frozen()
    histogram = project.histograms()[0]
    old = project.phase("WO3")
    old_hap = old.data["Histograms"][histogram.name]

    new = project.add_phase(
        str(root / ".tmp/candidates/2311041.cif"),
        phasename="WO3_modern",
        histograms=[histogram],
        fmthint="CIF",
    )
    new.data["General"]["Cell"] = copy.deepcopy(old.data["General"]["Cell"])
    new.data["Histograms"][histogram.name] = copy.deepcopy(old_hap)
    new.data["Histograms"][histogram.name]["Use"] = True
    new.data["Histograms"][histogram.name]["Scale"] = [float(old_hap["Scale"][0]), True]
    old_hap["Use"] = False
    old_hap["Scale"] = [0.0, False]

    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = bool(hap.get("Use", True) and hap["Scale"][0] > 0)
        phase.data["General"]["Cell"][0] = False
    histogram.set_refinements({"Background": True})
    project.set_Controls("cycles", 6)
    project.refine()
    project.save(str(output))

    used = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        if hap.get("Use", True) and hap["Scale"][0] > 0:
            used.append(phase)
            masses.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
    total = sum(masses)
    result = {
        "rwp_percent": float(histogram.get_wR()),
        "phases": [
            {
                "name": phase.name,
                "scale": float(phase.data["Histograms"][histogram.name]["Scale"][0]),
                "weight_fraction": mass / total,
            }
            for phase, mass in zip(used, masses)
        ],
    }
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
