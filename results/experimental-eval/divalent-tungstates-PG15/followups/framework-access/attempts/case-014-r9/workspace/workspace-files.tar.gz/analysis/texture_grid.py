#!/usr/bin/env python3
"""Grid fixed March-Dollase settings while refining only scales/background."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("outdir")
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--cycles", type=int, default=2)
    parser.add_argument("--axis", nargs=3, type=int)
    parser.add_argument("--ratio", type=float)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    if args.axis is not None or args.ratio is not None:
        if args.axis is None or args.ratio is None:
            parser.error("--axis and --ratio must be supplied together")
        settings = [(args.axis, args.ratio)]
    else:
        settings = [
            (axis, ratio)
            for axis in ([0, 0, 1], [1, 1, 0], [1, 1, 1])
            for ratio in (0.70, 0.80, 0.90, 1.00, 1.10, 1.20, 1.40)
        ]
    rows = []
    for axis, ratio in settings:
        tag = "".join(str(v) for v in axis) + "_" + f"{ratio:.2f}".replace(".", "p")
        output = outdir / f"texture_{tag}.gpx"
        project = G2.G2Project(args.source)
        project.save(str(output))
        project.set_Frozen()
        histogram = project.histograms()[0]
        phases = project.phases()
        for phase in phases:
            hap = phase.data["Histograms"][histogram.name]
            hap["Size"][2] = [False for _ in hap["Size"][2]]
            hap["Size"][5] = [False for _ in hap["Size"][5]]
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
            hap["Pref.Ori."][2] = False
        po = phases[args.phase].data["Histograms"][histogram.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = ratio
        po[2] = False
        po[3] = axis
        project.set_Controls("cycles", args.cycles)
        project.refine()
        project.save(str(output))
        masses = [
            float(p.data["General"]["Mass"] * p.data["Histograms"][histogram.name]["Scale"][0])
            for p in phases
        ]
        total = sum(max(0.0, value) for value in masses)
        row = {
            "axis": axis,
            "ratio": ratio,
            "rwp_percent": float(histogram.get_wR()),
            "fractions": [max(0.0, value) / total for value in masses],
            "project": str(output),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    rows.sort(key=lambda row: row["rwp_percent"])
    (outdir / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")
    print("BEST", json.dumps(rows[0]))


if __name__ == "__main__":
    main()
