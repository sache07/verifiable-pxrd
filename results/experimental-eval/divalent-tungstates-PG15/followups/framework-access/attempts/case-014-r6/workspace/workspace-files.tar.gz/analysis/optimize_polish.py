#!/usr/bin/env python3
"""Short accepted-branch polish after phase inventory and texture selection."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from optimize_branches import Optimizer, configure_limits


def main(source: Path, destination: Path):
    opt = Optimizer(source, destination)
    phase_count = len(G2.G2Project(gpxfile=str(destination)).phases())

    for round_index in range(2):
        for phase_index in range(phase_count):
            def size_cfg(project, phase_index=phase_index):
                configure_limits(project)
                project.phases()[phase_index].set_HAP_refinements({
                    "Size": {"type": "isotropic", "refine": True}})
            opt.trial(f"r{round_index}_p{phase_index}_size", size_cfg, cycles=5)

            def strain_cfg(project, phase_index=phase_index):
                configure_limits(project)
                hist = project.histogram(0)
                phase = project.phases()[phase_index]
                strain = phase.data["Histograms"][hist.name]["Mustrain"]
                kind = strain[0]
                settings = {"type": kind, "refine": True}
                if kind == "uniaxial":
                    settings["direction"] = list(strain[3])
                phase.set_HAP_refinements({"Mustrain": settings})
            opt.trial(f"r{round_index}_p{phase_index}_strain", strain_cfg, cycles=5)

        for key in ("W", "X", "SH/L"):
            def inst_cfg(project, key=key):
                configure_limits(project)
                project.histogram(0).data["Instrument Parameters"][0][key][2] = True
            opt.trial(f"r{round_index}_inst_{key}", inst_cfg, cycles=5)

    for phase_index in range(phase_count):
        def cell_cfg(project, phase_index=phase_index):
            configure_limits(project)
            project.phases()[phase_index].set_refinements({"Cell": True})
        opt.trial(f"p{phase_index}_cell", cell_cfg, cycles=6)

    def rough_cfg(project):
        configure_limits(project)
        hist = project.histogram(0)
        hist.SampleParameters["SurfRoughA"] = [0.10, False]
        hist.SampleParameters["SurfRoughB"][1] = True
    opt.trial("roughness_B", rough_cfg, cycles=5)

    for key in ("Shift", "Zero"):
        def angular_cfg(project, key=key):
            configure_limits(project)
            if key == "Shift":
                project.histogram(0).SampleParameters["Shift"][1] = True
            else:
                project.histogram(0).data["Instrument Parameters"][0]["Zero"][2] = True
        opt.trial(f"angular_{key}", angular_cfg, cycles=5)

    opt.save_log()
    print("BEST", opt.best, destination, flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: optimize_polish.py INPUT.gpx OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    main(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
