#!/usr/bin/env python3
"""Optimize texture with fixed in-range values so boundary fits are replayable."""

from __future__ import annotations

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from optimize_branches import Optimizer, configure_limits


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def fixed_md(project, phase_index, axis, ratio):
    configure_limits(project)
    hist = project.histogram(0)
    po = project.phases()[phase_index].data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = float(ratio)
    po[2] = False
    po[3] = list(axis)


def main(source: Path, destination: Path):
    opt = Optimizer(source, destination)

    # The minor Sr3W2O9 phase reached a bound in an unconstrained trial. Search
    # the complete allowed axis set using fixed ratios, which gives a fully
    # replayable objective value at every grid point.
    for axis in AXES:
        for ratio in (0.70, 0.85, 1.00, 1.15, 1.30, 1.40):
            def cfg(project, axis=axis, ratio=ratio):
                fixed_md(project, 2, axis, ratio)
            opt.trial(f"p2_fixed_{''.join(map(str, axis))}_{ratio:.2f}", cfg, cycles=1)

    # Densify around the best fixed minor-phase branch.
    probe = G2.G2Project(gpxfile=str(destination))
    hist = probe.histogram(0)
    po = probe.phases()[2].data["Histograms"][hist.name]["Pref.Ori."]
    best_axis, best_ratio = list(po[3]), float(po[1])
    low = max(0.70, best_ratio - 0.12)
    high = min(1.40, best_ratio + 0.12)
    for step in range(9):
        ratio = low + (high - low) * step / 8.0
        def cfg_local(project, axis=best_axis, ratio=ratio):
            fixed_md(project, 2, axis, ratio)
        opt.trial(f"p2_local_{ratio:.4f}", cfg_local, cycles=1)

    # The two interior texture terms were not boundary-limited. A short fixed
    # grid around their prior optima updates scales after the minor-phase search.
    for phase_index, ratios in (
        (0, (0.98, 1.00, 1.02, 1.04, 1.06, 1.08)),
        (1, (1.05, 1.10, 1.15, 1.20, 1.25, 1.30)),
    ):
        probe = G2.G2Project(gpxfile=str(destination))
        hist = probe.histogram(0)
        axis = list(probe.phases()[phase_index].data["Histograms"][hist.name]["Pref.Ori."][3])
        for ratio in ratios:
            def cfg_main(project, phase_index=phase_index, axis=axis, ratio=ratio):
                fixed_md(project, phase_index, axis, ratio)
            opt.trial(f"p{phase_index}_local_{ratio:.3f}", cfg_main, cycles=1)

    opt.save_log()
    print("BEST", opt.best, opt.destination, flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: optimize_texture_fixed.py INPUT.gpx OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    main(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
