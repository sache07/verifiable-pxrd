#!/usr/bin/env python3
"""Bounded, accepted-branch optimization for the confirmed GSAS-II model."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def mass_fractions(project, hist):
    raw = {
        phase.name: float(phase.data["General"]["Mass"]
                          * phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in project.phases()
    }
    total = sum(raw.values())
    return {key: value / total for key, value in raw.items()}


def set_limit(project, variable, lower, upper):
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def reset_flags(project):
    hist = project.histogram(0)
    hist.set_refinements({"Background": True})
    for key, value in hist.data["Instrument Parameters"][0].items():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        phase.set_HAP_refinements({"Scale": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""
    project.set_Frozen()


def freeze_for_replay(project):
    """Clear every refinement flag before a physical profile recalculation."""
    hist = project.histogram(0)
    hist.set_refinements({"Background": False})
    for key, value in hist.data["Instrument Parameters"][0].items():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""
    project.set_Frozen()


class Optimizer:
    def __init__(self, source: Path, destination: Path):
        self.destination = destination
        self.scratch = destination.with_name(destination.stem + "_trial.gpx")
        shutil.copy2(source, destination)
        project = G2.G2Project(gpxfile=str(destination))
        self.best = float(project.histogram(0).get_wR())
        self.log = [{"label": "source", "Rwp": self.best,
                     "fractions": mass_fractions(project, project.histogram(0))}]
        print("source", self.best, flush=True)

    def trial(self, label, configure, cycles=5):
        project = G2.G2Project(gpxfile=str(self.destination), newgpx=str(self.scratch))
        reset_flags(project)
        configure(project)
        project.set_Frozen()
        project.set_Controls("cycles", cycles)
        try:
            project.refine()
            # A GSAS-II boundary stop can leave Ycalc from the out-of-range
            # trial while saving the parameter at its clipped limit. Force a
            # zero-variable replay so acceptance always uses the saved model.
            freeze_for_replay(project)
            project.set_Controls("cycles", 0)
            project.refine()
            value = float(project.histogram(0).get_wR())
        except Exception as exc:
            value = 1.0e9
            print(label, "ERROR", repr(exc), flush=True)
        accepted = value < self.best - 1.0e-6
        row = {"label": label, "Rwp": value, "accepted": accepted}
        if value < 1.0e8:
            row["fractions"] = mass_fractions(project, project.histogram(0))
        self.log.append(row)
        print(label, value, "ACCEPT" if accepted else "reject", flush=True)
        if accepted:
            shutil.copy2(self.scratch, self.destination)
            self.best = value
        return accepted

    def save_log(self):
        self.destination.with_suffix(".trials.json").write_text(
            json.dumps(self.log, indent=2) + "\n")


def configure_limits(project):
    hist = project.histogram(0)
    hid = hist.id
    for variable, bounds in {
        f":{hid}:U": (0.0, 40.0),
        f":{hid}:W": (2.0, 40.0),
        f":{hid}:X": (0.1, 6.0),
        f":{hid}:SH/L": (0.005, 0.10),
        f":{hid}:Polariz.": (0.5, 1.0),
        f":{hid}:Zero": (-0.25, 0.25),
        f":{hid}:Shift": (-800.0, 800.0),
        f":{hid}:SurfRoughA": (0.0, 0.60),
        f":{hid}:SurfRoughB": (0.0, 0.50),
    }.items():
        set_limit(project, variable, *bounds)
    for phase in project.phases():
        set_limit(project, f"{phase.id}:{hid}:Size;i", 0.04, 1.5)
        set_limit(project, f"{phase.id}:{hid}:Mustrain;i", 0.0, 8000.0)
        set_limit(project, f"{phase.id}:{hid}:Mustrain;a", 0.0, 32000.0)
        set_limit(project, f"{phase.id}:{hid}:MD", 0.70, 1.40)


def core(source: Path, destination: Path):
    opt = Optimizer(source, destination)
    phase_count = len(G2.G2Project(gpxfile=str(destination)).phases())

    # Alternate phase and common broadening terms. Rejected boundary jumps do
    # not contaminate the next trial.
    for iteration in range(3):
        for phase_index in range(phase_count):
            def size_cfg(p, phase_index=phase_index):
                configure_limits(p)
                p.phases()[phase_index].set_HAP_refinements({
                    "Size": {"type": "isotropic", "refine": True}})
            opt.trial(f"r{iteration}_p{phase_index}_size", size_cfg, cycles=5)

            def strain_cfg(p, phase_index=phase_index):
                configure_limits(p)
                p.phases()[phase_index].set_HAP_refinements({
                    "Mustrain": {"type": "isotropic", "refine": True}})
            opt.trial(f"r{iteration}_p{phase_index}_strain", strain_cfg, cycles=5)

        for key in ("W", "U", "X", "SH/L"):
            def inst_cfg(p, key=key):
                configure_limits(p)
                p.histogram(0).data["Instrument Parameters"][0][key][2] = True
            opt.trial(f"r{iteration}_inst_{key}", inst_cfg, cycles=5)

    # One common, fixed Uiso value per phase. Grid selection is robust and
    # preserves the exact registration convention without fragile constraints.
    u_grid = [0.003, 0.005, 0.008, 0.012, 0.016, 0.020]
    for phase_index in range(phase_count):
        for value in u_grid:
            def u_cfg(p, phase_index=phase_index, value=value):
                phase = p.phases()[phase_index]
                cia = phase.data["General"]["AtomPtrs"][3]
                for atom in phase.atoms():
                    atom.data[cia] = "I"
                    atom.data[cia + 1] = value
                    atom.data[cia + 2:cia + 8] = [0.0] * 6
            opt.trial(f"p{phase_index}_Uiso_{value:.3f}", u_cfg, cycles=4)

    # Refine polarization separately.
    def pol_cfg(p):
        configure_limits(p)
        p.histogram(0).data["Instrument Parameters"][0]["Polariz."][2] = True
    opt.trial("polarization", pol_cfg, cycles=6)

    # Surface roughness is nearly singular in A/B. Hold A on a small grid and
    # refine B, retaining the best physical branch (B=0 is the no-effect case).
    for aval in (0.10, 0.30, 0.50):
        def rough_cfg(p, aval=aval):
            configure_limits(p)
            h = p.histogram(0)
            h.SampleParameters["SurfRoughA"] = [aval, False]
            h.SampleParameters["SurfRoughB"] = [0.08, True]
        opt.trial(f"rough_A_{aval:.2f}", rough_cfg, cycles=6)

    # Alternate the two angular corrections without allowing their >99%
    # correlation into one normal matrix.
    for key in ("Shift", "Zero"):
        def angular_cfg(p, key=key):
            configure_limits(p)
            if key == "Shift":
                p.histogram(0).SampleParameters["Shift"][1] = True
            else:
                p.histogram(0).data["Instrument Parameters"][0]["Zero"][2] = True
        opt.trial(f"angular_{key}", angular_cfg, cycles=5)

    opt.save_log()
    print("BEST", opt.best, opt.destination, flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: optimize_branches.py INPUT.gpx OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    core(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
