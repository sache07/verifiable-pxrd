#!/usr/bin/env python3
"""Continue the confirmed normalized three-phase model with stable refinements."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]


def fractions(project, hist):
    values = {
        phase.name: float(phase.data["General"]["Mass"]
                          * phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in project.phases()
    }
    total = sum(values.values())
    return {key: value / total for key, value in values.items()}


def run_refinement(project, label, cycles=6):
    project.set_Controls("cycles", cycles)
    project.refine()
    hist = project.histogram(0)
    print(label, "Rwp", hist.get_wR(), "fractions", fractions(project, hist), flush=True)


def set_limit(project, variable, lower, upper):
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def main(source: Path, destination: Path):
    project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
    hist = project.histogram(0)
    phases = project.phases()
    hid = hist.id
    project.set_Frozen()

    # Profile starts inside the known laboratory envelope. HAP broadening is
    # alternated by phase to avoid the size/instrument singularity.
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 10.0, "W": 20.0, "X": 1.0, "SH/L": 0.03}.items():
        inst[key][1] = value
        inst[key][2] = False
    starts = [(0.08, 500.0), (0.06, 500.0), (0.40, 6000.0)]
    for phase, (size, strain) in zip(phases, starts):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][2] = [False, False, False]
        set_limit(project, f"{phase.id}:{hid}:Size;i", 0.04, 1.5)
        set_limit(project, f"{phase.id}:{hid}:Mustrain;i", 0.0, 8000.0)
    set_limit(project, f":{hid}:U", 0.0, 40.0)
    set_limit(project, f":{hid}:W", 2.0, 40.0)
    set_limit(project, f":{hid}:X", 0.1, 6.0)
    set_limit(project, f":{hid}:SH/L", 0.005, 0.10)
    set_limit(project, f":{hid}:Polariz.", 0.5, 1.0)
    set_limit(project, f":{hid}:SurfRoughA", 0.0, 0.60)
    set_limit(project, f":{hid}:SurfRoughB", 0.0, 0.50)

    # Preserve cell, background and scale refinement from the indexed fit.
    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
    run_refinement(project, "profile_start", cycles=0)

    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
        project.set_Frozen()
        run_refinement(project, f"profile_{phase.name}", cycles=6)
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})

    for key in ("U", "W", "X", "SH/L"):
        inst[key][2] = True
    project.set_Frozen()
    run_refinement(project, "instrument", cycles=6)
    for key in ("U", "W", "X", "SH/L"):
        inst[key][2] = False

    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
        project.set_Frozen()
        run_refinement(project, f"profile2_{phase.name}", cycles=5)
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})

    # Match the registered-model convention and refine one common isotropic
    # displacement parameter per phase using exact equivalence constraints.
    project.data["Constraints"]["data"]["Phase"] = []
    for phase in phases:
        variables = []
        cia = phase.data["General"]["AtomPtrs"][3]
        for index, atom in enumerate(phase.atoms()):
            atom.data[cia] = "I"
            atom.data[cia + 1] = 0.005
            atom.data[cia + 2:cia + 8] = [0.0] * 6
            atom.refinement_flags = "U"
            variables.append(f"{phase.id}::AUiso:{index}")
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=True, override=True)
        for variable in variables:
            set_limit(project, variable, 0.003, 0.020)
    project.set_Frozen()
    run_refinement(project, "common_Uiso", cycles=7)
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = ""

    # Refine only heavy-atom coordinates first. Their perturbations matter for
    # X-ray intensities and are much better determined than oxygen shifts.
    for phase in phases[1:]:
        for atom in phase.atoms():
            if atom.element == "W":
                atom.refinement_flags = "X"
        project.set_Frozen()
        run_refinement(project, f"W_coordinates_{phase.name}", cycles=7)
        for atom in phase.atoms():
            atom.refinement_flags = ""

    # Whole-specimen low-angle deficit and polarization are intensity effects
    # that otherwise bias scales and phase fractions.
    hist.SampleParameters["SurfRoughA"] = [0.30, True]
    hist.SampleParameters["SurfRoughB"] = [0.08, True]
    inst["Polariz."][2] = True
    project.set_Frozen()
    run_refinement(project, "roughness_polarization", cycles=8)
    hist.SampleParameters["SurfRoughA"][1] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    inst["Polariz."][2] = False

    project.save()
    summary = {
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions(project, hist),
        "cells": {p.name: p.get_cell() for p in phases},
        "instrument": {k: v[1] for k, v in inst.items()
                       if isinstance(v, list) and len(v) >= 2},
        "sample": hist.SampleParameters,
        "profiles": {
            p.name: {
                "Size": p.data["Histograms"][hist.name]["Size"],
                "Mustrain": p.data["Histograms"][hist.name]["Mustrain"],
                "Pref.Ori.": p.data["Histograms"][hist.name]["Pref.Ori."],
            } for p in phases
        },
        "atoms": {
            p.name: [{"label": a.label, "element": a.element,
                      "coordinates": a.coordinates, "ADP": a.ADP}
                     for a in p.atoms()] for p in phases
        },
        "frozen": project.get_Frozen(),
    }
    destination.with_suffix(".json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps(summary, indent=2, default=str), flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_advanced.py INPUT.gpx OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    main(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
