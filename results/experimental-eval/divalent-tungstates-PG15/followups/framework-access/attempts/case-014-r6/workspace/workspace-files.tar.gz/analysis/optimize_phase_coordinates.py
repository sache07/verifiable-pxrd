#!/usr/bin/env python3
"""Bounded coordinate refinement for one selected analogue-derived phase."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from optimize_branches import Optimizer, configure_limits
from optimize_structure import coordinate_limits


def main(source: Path, destination: Path, phase_index: int):
    opt = Optimizer(source, destination)
    probe = G2.G2Project(gpxfile=str(destination))
    phase = probe.phases()[phase_index]
    sites = [(i, atom.label, atom.element) for i, atom in enumerate(phase.atoms())]

    for element_class in ("heavy", "oxygen"):
        for atom_index, label, element in sites:
            selected = element == "O" if element_class == "oxygen" else element != "O"
            if not selected:
                continue

            def cfg(project, atom_index=atom_index):
                configure_limits(project)
                selected_phase = project.phases()[phase_index]
                coordinate_limits(project, selected_phase, atom_index, component_cap_A=0.04)
                selected_phase.atoms()[atom_index].refinement_flags = "X"
            opt.trial(f"{element_class}_{label}_coordinates", cfg, cycles=7)

    def cell_cfg(project):
        configure_limits(project)
        project.phases()[phase_index].set_refinements({"Cell": True})
    opt.trial("cell_final", cell_cfg, cycles=6)
    opt.save_log()
    print("BEST", opt.best, destination, flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit("usage: optimize_phase_coordinates.py INPUT.gpx OUTPUT.gpx PHASE_INDEX")
    G2.SetPrintLevel("warn")
    main(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve(), int(sys.argv[3]))
