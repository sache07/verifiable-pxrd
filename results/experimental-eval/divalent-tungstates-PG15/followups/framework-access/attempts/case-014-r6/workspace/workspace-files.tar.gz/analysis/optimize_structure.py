#!/usr/bin/env python3
"""Accepted, tightly bounded cell and coordinate refinement branches."""

from __future__ import annotations

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from optimize_branches import Optimizer, configure_limits, set_limit


def coordinate_limits(project, phase, atom_index, component_cap_A=0.06):
    """Bound each fractional component to component_cap_A in direct space."""
    cell = phase.get_cell()
    lengths = (cell["length_a"], cell["length_b"], cell["length_c"])
    coordinates = phase.atoms()[atom_index].coordinates
    for component, length, coordinate in zip("xyz", lengths, coordinates):
        delta = component_cap_A / float(length)
        set_limit(
            project,
            f"{phase.id}::dA{component}:{atom_index}",
            float(coordinate) - delta,
            float(coordinate) + delta,
        )


def main(source: Path, destination: Path):
    opt = Optimizer(source, destination)

    # Re-equilibrate each cell after the profile and texture terms were fixed.
    for phase_index in range(3):
        def cell_cfg(project, phase_index=phase_index):
            configure_limits(project)
            project.phases()[phase_index].set_refinements({"Cell": True})
        opt.trial(f"p{phase_index}_cell", cell_cfg, cycles=6)

    # One site at a time keeps the normal matrices well conditioned. All
    # coordinate shifts remain symmetry constrained by GSAS-II.
    for element_class in ("heavy", "oxygen"):
        probe = G2.G2Project(gpxfile=str(destination))
        site_list = []
        for phase_index, phase in enumerate(probe.phases()):
            for atom_index, atom in enumerate(phase.atoms()):
                selected = atom.element == "O" if element_class == "oxygen" else atom.element != "O"
                if selected:
                    site_list.append((phase_index, atom_index, atom.label))

        for phase_index, atom_index, label in site_list:
            def atom_cfg(project, phase_index=phase_index, atom_index=atom_index):
                configure_limits(project)
                phase = project.phases()[phase_index]
                coordinate_limits(project, phase, atom_index)
                phase.atoms()[atom_index].refinement_flags = "X"
            opt.trial(
                f"p{phase_index}_{element_class}_{label}_coordinates",
                atom_cfg,
                cycles=7,
            )

    # A final cell pass absorbs the small peak-position change caused by the
    # accepted coordinate/intensity branches without opening angular terms.
    for phase_index in range(3):
        def cell_cfg2(project, phase_index=phase_index):
            configure_limits(project)
            project.phases()[phase_index].set_refinements({"Cell": True})
        opt.trial(f"p{phase_index}_cell_final", cell_cfg2, cycles=5)

    opt.save_log()
    print("BEST", opt.best, opt.destination, flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: optimize_structure.py INPUT.gpx OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    main(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
