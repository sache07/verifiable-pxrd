#!/usr/bin/env python3
"""Fast whole-profile screen of COD phases and Sr-substituted tungstate analogues."""

from __future__ import annotations

import gzip
import json
from pathlib import Path
import sys
import warnings

import numpy as np
from scipy.ndimage import gaussian_filter1d
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure


INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
METALS = {"Ba", "Be", "Ca", "Cd", "Co", "Cu", "Eu", "Fe", "Hg", "Mg", "Mn", "Ni", "Pb", "Zn"}
LAMBDA1 = 1.540598
LAMBDA2 = 1.544426


def cod_path(record_id):
    return COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def candidates(index):
    rows = []
    for chemical_system, records in index.items():
        elements = set(chemical_system.split("-"))
        exact = elements <= {"C", "O", "Sr", "W"} and bool(elements & {"Sr", "W"})
        analogue = len(elements) == 3 and {"O", "W"} <= elements and bool(elements & METALS)
        if not (exact or analogue):
            continue
        for formula, record_id, space_group, rfactor in records:
            rows.append((chemical_system, formula, record_id, space_group, analogue and not exact))
    return rows


def profile_from_pattern(pattern, x, lattice_scale, fwhm):
    step = float(np.median(np.diff(x)))
    sticks = np.zeros_like(x)
    for angle, intensity in zip(pattern.x, pattern.y):
        theta = np.radians(float(angle) / 2.0)
        d_scaled = LAMBDA1 / (2.0 * np.sin(theta)) * lattice_scale
        for wavelength, ratio in ((LAMBDA1, 1.0), (LAMBDA2, 0.5)):
            arg = wavelength / (2.0 * d_scaled)
            if not 0 < arg < 1:
                continue
            position = np.degrees(2.0 * np.arcsin(arg))
            q = (position - x[0]) / step
            i = int(np.floor(q))
            if 0 <= i < len(x) - 1:
                frac = q - i
                sticks[i] += ratio * float(intensity) * (1.0 - frac)
                sticks[i + 1] += ratio * float(intensity) * frac
    return gaussian_filter1d(sticks, fwhm / 2.35482 / step, mode="constant")


def main(npz_path: Path, output: Path):
    data = np.load(npz_path)
    x, y, yc, w = (np.asarray(data[k], float) for k in ("x", "y", "yc", "w"))
    residual = y - yc
    base_sse = float(np.sum(w * residual ** 2))
    denominator = float(np.sum(w * y ** 2))
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    calculator = XRDCalculator(wavelength=LAMBDA1, symprec=0)
    results = []
    seen = set()
    warnings.filterwarnings("ignore")

    for chemical_system, formula, record_id, space_group, analogue in candidates(index):
        try:
            structure = Structure.from_file(cod_path(record_id), primitive=False)
            if len(structure) > 180:
                continue
            if analogue:
                substitutions = {}
                for species in structure.composition:
                    if species.symbol not in {"O", "W"}:
                        substitutions[species] = "Sr"
                structure.replace_species(substitutions)
            structure.remove_oxidation_states()
            key = (structure.composition.reduced_formula, space_group, len(structure))
            # Keep distinct records when their cells differ, but suppress exact duplicates.
            metric = tuple(round(v, 3) for v in (*structure.lattice.abc, *structure.lattice.angles))
            if (key, metric) in seen:
                continue
            seen.add((key, metric))
            pattern = calculator.get_pattern(structure, two_theta_range=(float(x[0]) - 1, float(x[-1]) + 1), scaled=True)
        except Exception:
            continue

        scales = np.arange(0.86 if analogue else 0.96,
                           1.161 if analogue else 1.041, 0.004)
        best = None
        for lattice_scale in scales:
            for fwhm in (0.12, 0.24, 0.45, 0.75):
                trial = profile_from_pattern(pattern, x, lattice_scale, fwhm)
                pp = float(np.sum(w * trial ** 2))
                if pp <= 0:
                    continue
                amplitude = max(0.0, float(np.sum(w * trial * residual)) / pp)
                improvement = 2.0 * amplitude * float(np.sum(w * trial * residual)) - amplitude ** 2 * pp
                if best is None or improvement > best[0]:
                    best = (improvement, lattice_scale, fwhm, amplitude)
        if best and best[0] > 0:
            improvement, lattice_scale, fwhm, amplitude = best
            rwp = 100.0 * np.sqrt(max(base_sse - improvement, 0.0) / denominator)
            results.append({
                "record_id": record_id,
                "source_formula": formula,
                "model_formula": structure.composition.reduced_formula,
                "chemical_system": chemical_system,
                "space_group_number": space_group,
                "analogue_to_Sr": analogue,
                "lattice_scale": lattice_scale,
                "fwhm_deg": fwhm,
                "amplitude": amplitude,
                "weighted_sse_improvement": improvement,
                "linear_screen_Rwp_percent": rwp,
            })

    results.sort(key=lambda row: row["weighted_sse_improvement"], reverse=True)
    output.write_text(json.dumps(results, indent=2) + "\n")
    print("base_Rwp", 100.0 * np.sqrt(base_sse / denominator), "screened", len(results))
    print(json.dumps(results[:40], indent=2))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: screen_residual.py FIT.npz OUTPUT.json")
    main(Path(sys.argv[1]), Path(sys.argv[2]))
