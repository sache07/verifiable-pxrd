#!/usr/bin/env python3
"""Build and refine a two-phase GSAS-II model for candidate screening.

Run this with the GSAS-II Python interpreter. The first phase is scheelite
SrWO4 (COD 1546036); the second phase is selected by COD identifier.
"""

from __future__ import annotations

import csv
import json
import math
import os
import sys
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

# Peak-indexed starts for the confirmed three-phase model. These only prevent
# a weak trial phase from wandering before its scale is released; all cells
# remain refined in the project.
START_CELLS = {
    "1546036": [5.4190, 5.4190, 11.9640, 90.0, 90.0, 90.0],
    "1528915": [7.3031, 7.5414, 10.5385, 90.0, 133.1105, 90.0],
    "2311977": [9.6533, 5.5291, 13.4246, 90.0, 103.6353, 90.0],
}


def cod_path(record_id: str) -> Path:
    normalized = ROOT / "analysis" / "normalized" / f"{record_id}.cif"
    if normalized.exists():
        return normalized
    return COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def write_inputs(run_dir: Path) -> tuple[Path, Path, np.ndarray, np.ndarray]:
    source = ROOT / "inputs" / "pattern.csv"
    with source.open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    x = np.array([float(row["two_theta_deg"]) for row in rows])
    y = np.array([float(row["intensity"]) for row in rows])
    data = run_dir / "pattern.xye"
    with data.open("w") as stream:
        stream.write("# two_theta intensity sigma_poisson\n")
        for xx, yy in zip(x, y):
            stream.write(f"{xx:.8f} {yy:.8f} {math.sqrt(max(yy, 1.0)):.8f}\n")
    inst = run_dir / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu K-alpha laboratory Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return data, inst, x, y


def initial_background(x: np.ndarray, y: np.ndarray, ncoeff: int = 16) -> list[float]:
    # A broad lower-envelope estimate gives the nonlinear refinement a stable
    # positive start while leaving diffraction peaks to the phase models.
    baseline = percentile_filter(y, percentile=18, size=401, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    coeff = np.polynomial.chebyshev.chebfit(t, baseline, ncoeff - 1)
    return [float(v) for v in coeff]


def mass_fractions(project: G2.G2Project, hist_name: str) -> dict[str, float]:
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist_name]
        raw[phase.name] = float(phase.data["General"]["Mass"] * hap["Scale"][0])
    total = sum(raw.values())
    return {key: value / total for key, value in raw.items()}


def refine(project: G2.G2Project, label: str, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    hist = project.histogram(0)
    print(f"{label}: Rwp={hist.get_wR():.6g}", flush=True)


def set_physical_limits(project: G2.G2Project, hist, phases) -> None:
    """Keep nuisance parameters inside the stated laboratory envelope."""
    hid = hist.id
    limits = {
        f":{hid}:Zero": (-0.25, 0.25),
        f":{hid}:Shift": (-800.0, 800.0),
        f":{hid}:U": (0.0, 40.0),
        f":{hid}:W": (2.0, 40.0),
        f":{hid}:X": (0.1, 6.0),
        f":{hid}:SH/L": (0.005, 0.10),
        f":{hid}:Polariz.": (0.5, 1.0),
    }
    for phase in phases:
        pid = phase.id
        limits[f"{pid}:{hid}:Scale"] = (1.0e-8, 100.0)
        limits[f"{pid}:{hid}:Size;i"] = (0.04, 1.5)
        limits[f"{pid}:{hid}:Mustrain;i"] = (0.0, 8000.0)
        cell = phase.data["General"]["Cell"][1:7]
        for index, value in enumerate(G2lat.cell2A(cell)):
            delta = max(abs(float(value)) * 0.05, 0.0005)
            limits[f"{pid}::A{index}"] = (float(value) - delta, float(value) + delta)
    for variable, (lower, upper) in limits.items():
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)


def main(candidate_ids: list[str]) -> None:
    quick = os.environ.get("PXRD_QUICK", "0") == "1"
    run_key = "_".join(candidate_ids)
    run_dir = ROOT / "candidate_runs" / run_key
    run_dir.mkdir(parents=True, exist_ok=True)
    data_file, inst_file, x, y = write_inputs(run_dir)
    project = G2.G2Project(newgpx=str(run_dir / "refined.gpx"))
    hist = project.add_powder_histogram(
        str(data_file), str(inst_file), fmthint="xye"
    )
    srwo4 = project.add_phase(
        str(cod_path("1546036")), phasename="SrWO4_scheelite",
        histograms=[hist], fmthint="CIF"
    )
    candidates = [
        project.add_phase(
            str(cod_path(candidate_id)), phasename=f"candidate_{candidate_id}",
            histograms=[hist], fmthint="CIF"
        )
        for candidate_id in candidate_ids
    ]
    phases = [srwo4, *candidates]
    for record_id, phase in zip(["1546036", *candidate_ids], phases):
        if record_id in START_CELLS:
            cell = START_CELLS[record_id]
            volume = float(G2lat.calc_V(G2lat.cell2A(cell)))
            phase.data["General"]["Cell"][1:] = [*cell, volume]
    set_physical_limits(project, hist, phases)

    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [-400.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    coeff = initial_background(x, y)
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1", "no. coeffs": len(coeff),
            "coeffs": coeff, "refine": False,
        },
    })
    inst = hist.data["Instrument Parameters"][0]
    # Keep the exact reported wavelengths and K-alpha ratio fixed.
    for key, value in {"U": 10.0, "V": 0.0, "W": 10.0, "X": 1.0,
                       "Y": 0.0, "Z": 0.0, "SH/L": 0.03,
                       "Zero": 0.0, "Polariz.": 0.75}.items():
        inst[key][1] = value
        inst[key][2] = False

    # HAP scale times unit-cell mass is proportional to phase mass in GSAS-II.
    if len(phases) == 2:
        starting_fractions = [0.90, 0.10]
    elif len(phases) == 3:
        starting_fractions = [0.74, 0.12, 0.14]
    else:
        residual = 0.18 / (len(phases) - 1)
        starting_fractions = [0.82, *([residual] * (len(phases) - 1))]
    for phase, fraction in zip(phases, starting_fractions):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [2.0e4 * fraction / phase.data["General"]["Mass"], False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.10
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    # Calculate once, then add parameter groups progressively to avoid local
    # minima from the large unknown displacement/profile/background offsets.
    refine(project, "initial", cycles=0)
    hist.set_refinements({"Background": True})
    for phase in phases[:2]:
        phase.set_HAP_refinements({"Scale": True})
    refine(project, "scale_background", cycles=8)

    # Position terms are highly correlated. Refine the shared specimen shift
    # with one cell at a time, then alternate a common zero correction with
    # all cells. This is much more stable than releasing Zero and Shift at once.
    hist.SampleParameters["Shift"][1] = True
    for phase in phases:
        phase.set_refinements({"Cell": True})
        refine(project, f"position_{phase.name}", cycles=6)
        phase.set_refinements({"Cell": False})
        project.set_Frozen()
    hist.SampleParameters["Shift"][1] = False
    inst["Zero"][2] = True
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "position_zero_cells", cycles=8)
    inst["Zero"][2] = False
    for phase in phases[2:]:
        # The trial phase cell has now been brought onto any matching peaks;
        # only now release its scale so an offset reference is not rejected.
        phase.set_HAP_refinements({"Scale": True})
        project.set_Frozen()
        refine(project, f"scale_{phase.name}", cycles=6)

    if not quick:
        # Establish phase broadening before allowing the common instrumental
        # profile to move. Then alternate the common and phase-specific terms.
        for phase in phases:
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            })
        refine(project, "phase_profile", cycles=8)
        for phase in phases:
            phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        for key in ("U", "W", "X", "SH/L"):
            inst[key][2] = True
        project.set_Frozen()
        refine(project, "instrument_profile", cycles=8)
        for key in ("U", "W", "X", "SH/L"):
            inst[key][2] = False
        for phase in phases:
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            })
        project.set_Frozen()
        refine(project, "phase_profile_final", cycles=8)

    project.save()
    fractions = mass_fractions(project, hist.name)
    summary = {
        "candidate_ids": candidate_ids,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions,
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "instrument": {key: value[1] for key, value in inst.items()
                       if isinstance(value, list) and len(value) >= 2},
        "sample": hist.SampleParameters,
        "background": hist.data["Background"],
        "phase_hap": {
            phase.name: {
                "Scale": phase.data["Histograms"][hist.name]["Scale"],
                "Size": phase.data["Histograms"][hist.name]["Size"],
                "Mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
    }
    (run_dir / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps({"candidate_ids": candidate_ids,
                      "Rwp_percent": summary["Rwp_percent"],
                      "fractions": fractions,
                      "cells": summary["cells"]}, indent=2))


if __name__ == "__main__":
    if len(sys.argv) < 2 or any(len(v) != 7 or not v.isdigit() for v in sys.argv[1:]):
        raise SystemExit("usage: refine_candidate.py COD_ID [COD_ID ...]")
    G2.SetPrintLevel("warn")
    main(sys.argv[1:])
