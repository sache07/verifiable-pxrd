#!/usr/bin/env python3
"""Build neutral Sr-substituted structural analogues for residual-phase tests."""

from pathlib import Path
import sys

from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
sys.path.insert(0, str(ROOT / "learned/divalent-tungstates/runtime"))
from models import write_synthetic_model  # noqa: E402


def cod_path(record_id: str) -> Path:
    return COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def derive(record_id: str, old: str, new: str, linear_scale: float, name: str):
    structure = Structure.from_file(cod_path(record_id), primitive=False)
    structure.replace_species({old: new})
    if linear_scale != 1.0:
        structure.scale_lattice(structure.volume * linear_scale ** 3)
    destination = ROOT / "analysis/derived" / f"{name}.cif"
    write_synthetic_model(structure, destination)
    print(destination, structure.composition.reduced_formula,
          structure.get_space_group_info(), structure.lattice)


if __name__ == "__main__":
    derive("1533878", "Ba", "Sr", 1.00, "Sr3W2O9_R3c_from_Ba3W2O9")
    derive("1563081", "Ca", "Sr", 1.06, "Sr3WO6_P21c_from_Ca3WO6")
    derive("1534803", "Ba", "Sr", 0.95, "Sr3WO6_P1_from_Ba3WO6")
    # The profile screen ignores the already-refined specimen displacement;
    # 1.117 places the cubic 320/321 pair on 29.76/30.90 degrees in that frame.
    derive("1527404", "Cu", "Sr", 1.117, "Sr3WO6_Pa3_from_Cu3WO6")
    derive("2002703", "Mn", "Sr", 1.08, "Sr3WO6_R3_from_Mn3WO6")
