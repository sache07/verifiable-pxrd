#!/usr/bin/env python3
"""Freeze the selected GSAS-II model and export the requested deliverables."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

from optimize_branches import freeze_for_replay


PHASES = (
    ("SrWO4 (scheelite, I41/a)", "phase_1_SrWO4_scheelite.cif"),
    ("WO3 (monoclinic, P21/c)", "phase_2_WO3_monoclinic.cif"),
    ("Sr3W2O9 (monoclinic, C2/c)", "phase_3_Sr3W2O9_monoclinic.cif"),
    ("Sr3WO6 (cubic Pa-3, analogue-derived)", "phase_4_Sr3WO6_cubic.cif"),
)


def main(source: Path, root: Path):
    final_project = root / "final.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(final_project))
    freeze_for_replay(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save()

    hist = project.histogram(0)
    phases = project.phases()
    if len(phases) != len(PHASES):
        raise RuntimeError(f"expected {len(PHASES)} phases, found {len(phases)}")

    masses = np.asarray([
        phase.data["General"]["Mass"]
        * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in phases
    ], float)
    fractions = masses / masses.sum()
    rows = []
    for phase, (name, filename), fraction in zip(phases, PHASES, fractions):
        phase.export_CIF(str(root / filename))
        rows.append({
            "name": name,
            "cif_path": filename,
            "weight_fraction": float(fraction),
        })

    x, observed, weights, calculated, background, difference = (
        np.asarray(v, float) for v in hist.data["data"][1]
    )
    # GSAS stores difference as observed-calculated; recompute explicitly for
    # the exported table to make the sign convention unambiguous.
    difference = observed - calculated
    fit = np.column_stack((x, observed, calculated, difference))
    np.savetxt(
        root / "fit.csv",
        fit,
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference_observed_minus_calculated",
        comments="",
        fmt=("%.8f", "%.8f", "%.8f", "%.8f"),
    )

    poisson_weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(poisson_weights * difference ** 2))
    denominator = float(np.sum(poisson_weights * observed ** 2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    gof_n = float(np.sqrt(chi_square / len(observed)))
    result = {
        "phases": rows,
        "refinement_histogram": hist.name,
        "fit_csv": "fit.csv",
        "final_project": "final.gpx",
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "weighted_chi_square": chi_square,
            "goodness_of_fit_sqrt_chi2_over_N": gof_n,
            "number_of_points": int(len(observed)),
        },
        "fraction_basis": "normalized over the four modeled crystalline phases",
    }
    (root / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: finalize.py SELECTED.gpx OUTPUT_DIRECTORY")
    G2.SetPrintLevel("warn")
    main(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
