#!/usr/bin/env python3
"""Replay-safe fixed-grid March-Dollase search for one phase."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from optimize_branches import Optimizer, configure_limits


# For the present cubic phase [100]/[010]/[001] are symmetry-equivalent; the
# [001] branch was checked separately before this reduced grid.
AXES = ([1, 1, 0], [1, 1, 1])
RATIOS = (0.70, 0.80, 0.90, 1.00, 1.10, 1.20, 1.30, 1.40)


def main(source: Path, destination: Path, phase_index: int):
    opt = Optimizer(source, destination)
    for axis in AXES:
        for ratio in RATIOS:
            def cfg(project, axis=axis, ratio=ratio):
                configure_limits(project)
                hist = project.histogram(0)
                po = project.phases()[phase_index].data["Histograms"][hist.name]["Pref.Ori."]
                po[0] = "MD"
                po[1] = ratio
                po[2] = False
                po[3] = list(axis)
            opt.trial(f"MD_{''.join(map(str, axis))}_{ratio:.2f}", cfg, cycles=1)
    opt.save_log()
    print("BEST", opt.best, destination, flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit("usage: optimize_md_grid.py INPUT.gpx OUTPUT.gpx PHASE_INDEX")
    G2.SetPrintLevel("warn")
    main(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve(), int(sys.argv[3]))
