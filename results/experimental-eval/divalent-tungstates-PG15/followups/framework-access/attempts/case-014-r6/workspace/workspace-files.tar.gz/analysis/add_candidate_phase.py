#!/usr/bin/env python3
"""Add and bounded-refine a candidate residual phase in an existing project."""

from __future__ import annotations

from pathlib import Path
import shutil
import sys

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from optimize_branches import (
    Optimizer,
    configure_limits,
    freeze_for_replay,
    mass_fractions,
    reset_flags,
    set_limit,
)


def add_cell_limits(project, phase, fraction=0.20):
    for index, value in enumerate(G2lat.cell2A(phase.data["General"]["Cell"][1:7])):
        delta = max(abs(float(value)) * fraction, 0.001)
        set_limit(project, f"{phase.id}::A{index}", float(value) - delta, float(value) + delta)


def prepare(source: Path, candidate_cif: Path, output: Path, name: str):
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(candidate_cif), phasename=name, histograms=[hist], fmthint="CIF")
    configure_limits(project)
    add_cell_limits(project, phase)
    set_limit(project, f"{phase.id}:{hist.id}:Scale", 0.0, 100.0)

    hap = phase.data["Histograms"][hist.name]
    current_mass_scale = sum(
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()[:-1]
    )
    hap["Scale"] = [0.05 * current_mass_scale / phase.data["General"]["Mass"], True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.10
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False

    reset_flags(project)
    configure_limits(project)
    add_cell_limits(project, phase)
    set_limit(project, f"{phase.id}:{hist.id}:Scale", 0.0, 100.0)
    project.set_Frozen()
    project.set_Controls("cycles", 4)
    project.refine()
    freeze_for_replay(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save()
    print("prepared", hist.get_wR(), mass_fractions(project, hist), flush=True)


def optimize(base: Path, output: Path):
    opt = Optimizer(base, output)
    candidate_index = len(G2.G2Project(gpxfile=str(output)).phases()) - 1

    def cell_cfg(project):
        configure_limits(project)
        phase = project.phases()[candidate_index]
        add_cell_limits(project, phase)
        phase.set_refinements({"Cell": True})
    opt.trial("candidate_cell", cell_cfg, cycles=8)

    for round_index in range(2):
        def size_cfg(project):
            configure_limits(project)
            project.phases()[candidate_index].set_HAP_refinements({
                "Size": {"type": "isotropic", "refine": True}})
        opt.trial(f"candidate_size_{round_index}", size_cfg, cycles=6)

        def strain_cfg(project):
            configure_limits(project)
            project.phases()[candidate_index].set_HAP_refinements({
                "Mustrain": {"type": "isotropic", "refine": True}})
        opt.trial(f"candidate_strain_{round_index}", strain_cfg, cycles=6)

    # A final cell pass after broadening often separates an analogue from a
    # merely overlapping candidate.
    opt.trial("candidate_cell_final", cell_cfg, cycles=6)
    opt.save_log()
    print("BEST", opt.best, output, flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 5:
        raise SystemExit("usage: add_candidate_phase.py INPUT.gpx CANDIDATE.cif OUTPUT.gpx NAME")
    G2.SetPrintLevel("warn")
    source = Path(sys.argv[1]).resolve()
    candidate = Path(sys.argv[2]).resolve()
    output = Path(sys.argv[3]).resolve()
    base = output.with_name(output.stem + "_base.gpx")
    prepare(source, candidate, base, sys.argv[4])
    optimize(base, output)
