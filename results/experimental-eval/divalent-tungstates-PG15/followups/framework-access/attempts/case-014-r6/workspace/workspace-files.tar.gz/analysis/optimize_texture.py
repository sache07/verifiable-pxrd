#!/usr/bin/env python3
"""Accepted-branch tests for preferred orientation and uniaxial strain."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from optimize_branches import Optimizer, configure_limits, set_limit


AXES_PO = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])
AXES_STRAIN = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def main(source: Path, destination: Path):
    opt = Optimizer(source, destination)
    phase_count = len(G2.G2Project(gpxfile=str(destination)).phases())

    for phase_index in range(phase_count):
        for axis in AXES_PO:
            def cfg(project, phase_index=phase_index, axis=axis):
                configure_limits(project)
                hist = project.histogram(0)
                phase = project.phases()[phase_index]
                hap = phase.data["Histograms"][hist.name]
                hap["Pref.Ori."][0] = "MD"
                hap["Pref.Ori."][1] = 1.0
                hap["Pref.Ori."][2] = True
                hap["Pref.Ori."][3] = list(axis)
                set_limit(project, f"{phase.id}:{hist.id}:MD", 0.70, 1.40)
            opt.trial(f"p{phase_index}_MD_{''.join(map(str, axis))}", cfg, cycles=6)

    for phase_index in range(phase_count):
        for axis in AXES_STRAIN:
            def cfg(project, phase_index=phase_index, axis=axis):
                configure_limits(project)
                hist = project.histogram(0)
                phase = project.phases()[phase_index]
                strain = phase.data["Histograms"][hist.name]["Mustrain"]
                equatorial = max(float(strain[1][0]), 100.0)
                strain[0] = "uniaxial"
                strain[1][0] = equatorial
                strain[1][1] = min(1.2 * equatorial, 32000.0)
                strain[2][0] = True
                strain[2][1] = True
                strain[3] = list(axis)
                set_limit(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 8000.0)
                set_limit(project, f"{phase.id}:{hist.id}:Mustrain;a", 0.0, 32000.0)
            opt.trial(f"p{phase_index}_uniax_{''.join(map(str, axis))}", cfg, cycles=6)

    opt.save_log()
    print("BEST", opt.best, opt.destination, flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: optimize_texture.py INPUT.gpx OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    main(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
