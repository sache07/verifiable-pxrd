#!/usr/bin/env python3
"""Accepted individual cell passes for the selected multiphase model."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from optimize_branches import Optimizer, configure_limits


def main(source: Path, destination: Path):
    opt = Optimizer(source, destination)
    phase_count = len(G2.G2Project(gpxfile=str(destination)).phases())
    for round_index in range(2):
        for phase_index in range(phase_count):
            def cfg(project, phase_index=phase_index):
                configure_limits(project)
                project.phases()[phase_index].set_refinements({"Cell": True})
            opt.trial(f"r{round_index}_p{phase_index}_cell", cfg, cycles=7)
    opt.save_log()
    print("BEST", opt.best, destination, flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: optimize_cells.py INPUT.gpx OUTPUT.gpx")
    G2.SetPrintLevel("warn")
    main(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
