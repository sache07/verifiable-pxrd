#!/usr/bin/env python3
"""Rank charge-balanced Pb-W-O analogues by fit to a positive residual profile."""

from __future__ import annotations

from collections import defaultdict
import gzip
import json
from pathlib import Path
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Structure
from scipy.ndimage import gaussian_filter1d


INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
LAMBDA1 = 1.540598
LAMBDA2 = 1.544426


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def plausible_collapsed_formula(formula: str) -> tuple[float, float, float] | None:
    try:
        amounts = Composition(formula).reduced_composition.get_el_amt_dict()
    except Exception:
        return None
    if "W" not in amounts or "O" not in amounts:
        return None
    pb = sum(value for element, value in amounts.items() if element not in {"W", "O"})
    w, oxygen = amounts["W"], amounts["O"]
    # Pb(II), W(VI), O(II-) charge balance. Permit a small tolerance for
    # rounded partial occupancies, but exclude molecular/polyoxo chemistry.
    if pb <= 0 or w <= 0 or abs(oxygen - (pb + 3 * w)) > 0.08:
        return None
    if pb + w + oxygen > 24:
        return None
    return pb, w, oxygen


def transformed_profile(x: np.ndarray, two_theta: np.ndarray, intensity: np.ndarray,
                        lattice_scale: float, offset: float) -> np.ndarray:
    theta = np.radians(two_theta / 2)
    d_scaled = LAMBDA1 / (2 * np.sin(theta)) * lattice_scale
    profiles = []
    for wavelength, ratio in ((LAMBDA1, 1.0), (LAMBDA2, 0.5)):
        valid = wavelength < 2 * d_scaled
        pos = np.degrees(2 * np.arcsin(wavelength / (2 * d_scaled[valid]))) + offset
        val = intensity[valid] * ratio
        stick = np.zeros_like(x)
        indices = np.searchsorted(x, pos)
        good = (indices > 0) & (indices < len(x))
        indices, pos, val = indices[good], pos[good], val[good]
        left = indices - 1
        fraction = (pos - x[left]) / (x[indices] - x[left])
        np.add.at(stick, left, val * (1 - fraction))
        np.add.at(stick, indices, val * fraction)
        profiles.append(stick)
    # FWHM about 0.13 degrees near the diagnostic low-angle peaks.
    step = float(np.median(np.diff(x)))
    return gaussian_filter1d(profiles[0] + profiles[1], 0.055 / step, mode="constant")


def main() -> None:
    data = np.genfromtxt(".tmp/current_fit.csv", delimiter=",", names=True)
    x, y, residual = data["two_theta_deg"], data["yobs"], data["difference"]
    mask = (x >= 20) & (x <= 85)
    x, y, residual = x[mask], y[mask], residual[mask]
    weight = 1 / np.maximum(y, 1)
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)

    records = []
    seen = set()
    for system, entries in index.items():
        elements = set(system.split("-"))
        if not {"W", "O"} <= elements or len(elements) < 3:
            continue
        for formula, cod_id, *_ in entries:
            stoichiometry = plausible_collapsed_formula(formula)
            if stoichiometry is None or cod_id in seen:
                continue
            seen.add(cod_id)
            path = cif_path(cod_id)
            if not path.exists():
                continue
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    structure = Structure.from_file(path, primitive=False)
                if len(structure) > 96:
                    continue
                structure.remove_oxidation_states()
                substitutions = {
                    element: "Pb" for element in structure.composition.elements
                    if element.symbol not in {"O", "W", "Pb"}
                }
                structure.replace_species(substitutions)
                pattern = XRDCalculator(wavelength=LAMBDA1).get_pattern(
                    structure, two_theta_range=(18, 90), scaled=False,
                )
            except Exception:
                continue
            if len(pattern.x) == 0:
                continue

            best = (-np.inf, None, None, None)
            for scale in np.linspace(0.965, 1.04, 16):
                for offset in np.linspace(0.12, 0.36, 9):
                    profile = transformed_profile(
                        x, np.asarray(pattern.x), np.asarray(pattern.y), scale, offset,
                    )
                    denom = float(np.sum(weight * profile * profile))
                    if denom <= 0:
                        continue
                    amplitude = max(0.0, float(np.sum(weight * profile * residual)) / denom)
                    improvement = float(
                        np.sum(weight * residual * residual)
                        - np.sum(weight * (residual - amplitude * profile) ** 2)
                    )
                    if improvement > best[0]:
                        best = (improvement, scale, offset, amplitude)
            records.append({
                "cod_id": cod_id,
                "source_formula": formula,
                "collapsed_formula": f"Pb{stoichiometry[0]:g}W{stoichiometry[1]:g}O{stoichiometry[2]:g}",
                "space_group": structure.get_space_group_info(symprec=1e-3)[0],
                "sites": len(structure),
                "improvement": best[0],
                "lattice_scale": best[1],
                "offset_deg": best[2],
                "amplitude": best[3],
            })

    records.sort(key=lambda row: row["improvement"], reverse=True)
    Path(".tmp/pb_framework_ranking.json").write_text(json.dumps(records, indent=2) + "\n")
    for row in records[:50]:
        print(
            f"{row['improvement']:10.2f} {row['cod_id']} {row['source_formula']:18s} "
            f"->{row['collapsed_formula']:12s} {row['space_group']:10s} "
            f"scale={row['lattice_scale']:.3f} offset={row['offset_deg']:.3f}"
        )


if __name__ == "__main__":
    main()
