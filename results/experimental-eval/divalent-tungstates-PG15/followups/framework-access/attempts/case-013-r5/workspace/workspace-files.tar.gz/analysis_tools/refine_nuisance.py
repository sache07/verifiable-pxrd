#!/usr/bin/env python3
"""Refine selected common nuisance parameters and force a clean replay pass."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--surface", action="store_true")
    parser.add_argument("--position", action="store_true")
    parser.add_argument("--instrument", action="store_true")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()),
        newgpx=str((args.out / "refined.gpx").resolve()),
    )
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Frozen()
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Background": True,
    })
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    hist.set_refinements({"Background": {"refine": True}})
    selected_instrument, selected_sample = [], []
    if args.polarization:
        selected_instrument.append("Polariz.")
        project.set_Controls("parmMin", 0.5, ":0:Polariz.")
        project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    if args.instrument:
        selected_instrument += ["U", "W", "X", "SH/L"]
        hist.data["Instrument Parameters"][0]["X"][1] = min(
            5.9, hist.data["Instrument Parameters"][0]["X"][1]
        )
        for variable, lo, hi in [
            (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0),
            (":0:X", 0.1, 6.0), (":0:SH/L", 0.005, 0.1),
        ]:
            project.set_Controls("parmMin", lo, variable)
            project.set_Controls("parmMax", hi, variable)
    if args.surface:
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.10, True]
        sample["SurfRoughB"] = [0.10, True]
        selected_sample += ["SurfRoughA", "SurfRoughB"]
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughA")
        project.set_Controls("parmMax", 0.6, ":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, ":0:SurfRoughB")
        project.set_Controls("parmMax", 0.5, ":0:SurfRoughB")
    if args.position:
        instrument = hist.data["Instrument Parameters"][0]
        instrument["Zero"][1] = min(0.24, max(-0.24, instrument["Zero"][1]))
        selected_instrument.append("Zero")
        selected_sample.append("Shift")
        project.set_Controls("parmMin", -0.25, ":0:Zero")
        project.set_Controls("parmMax", 0.25, ":0:Zero")
        project.set_Controls("parmMin", -800.0, ":0:Shift")
        project.set_Controls("parmMax", 800.0, ":0:Shift")
    if selected_instrument:
        hist.set_refinements({"Instrument Parameters": selected_instrument})
    if selected_sample:
        hist.set_refinements({"Sample Parameters": selected_sample})
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    project.data["Covariance"]["data"] = {}
    project.refine()
    first = hist.get_wR()
    if selected_instrument:
        hist.clear_refinements({"Instrument Parameters": selected_instrument})
    if selected_sample:
        hist.clear_refinements({"Sample Parameters": selected_sample})
    project.set_Frozen()
    project.data["Covariance"]["data"] = {}
    project.refine()
    project.save()
    result = {
        "Rwp_first_percent": first,
        "Rwp_replay_percent": hist.get_wR(),
        "instrument": {
            key: values[1] for key, values in hist.data["Instrument Parameters"][0].items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."}
        },
        "sample": {
            key: values for key, values in hist.data["Sample Parameters"].items()
            if key in {"Shift", "SurfRoughA", "SurfRoughB"}
        },
    }
    (args.out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
