#!/usr/bin/env python3
"""Restore parent coordinates while retaining the selected inventory/profile fit."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("profile_project", type=Path)
    parser.add_argument("three_phase_parent", type=Path)
    parser.add_argument("six_phase_parent", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.profile_project.resolve()),
        newgpx=str((args.out / "refined.gpx").resolve()),
    )
    source_three = G2.G2Project(gpxfile=str(args.three_phase_parent.resolve()))
    source_six = G2.G2Project(gpxfile=str(args.six_phase_parent.resolve()))
    hist = project.histogram(0)
    phases = project.phases()
    parent_phases = source_three.phases()[:3] + source_six.phases()[3:]
    for phase, parent in zip(phases, parent_phases):
        if len(phase.data["Atoms"]) != len(parent.data["Atoms"]):
            raise ValueError(f"atom count differs for {phase.name}")
        for atom, reference in zip(phase.data["Atoms"], parent.data["Atoms"]):
            if atom[1] != reference[1]:
                raise ValueError(f"atom order differs for {phase.name}")
            atom[3:7] = reference[3:7]
            atom[9:17] = reference[9:17]

    # Enforce the known laboratory-generation ranges before recomputing.
    instrument = hist.data["Instrument Parameters"][0]
    instrument["X"][1] = min(float(instrument["X"][1]), 6.0)
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][1][0] = min(1.5, max(0.04, float(hap["Size"][1][0])))
        strain = float(hap["Mustrain"][1][0])
        if 0 < strain < 300:
            strain = 0.0
        hap["Mustrain"][1][0] = min(8000.0, strain)
        hap["Mustrain"][1][1] = hap["Mustrain"][1][0]

    project.set_Frozen()
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Background": True,
    })
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    hist.set_refinements({"Background": {"refine": True}})
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    project.data["Covariance"]["data"] = {}
    project.refine()
    project.save()
    print(f"physical reset Rwp={hist.get_wR():.6f}")


if __name__ == "__main__":
    main()
