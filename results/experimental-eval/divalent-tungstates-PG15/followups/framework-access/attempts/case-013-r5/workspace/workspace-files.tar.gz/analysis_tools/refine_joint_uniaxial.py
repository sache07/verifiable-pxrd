#!/usr/bin/env python3
"""Jointly refine selected generator-compatible uniaxial strain terms."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument(
        "--term", action="append", nargs=5, type=float, required=True,
        metavar=("PHASE", "H", "K", "L", "AXIAL_PPM"),
    )
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()),
        newgpx=str((args.out / "refined.gpx").resolve()),
    )
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Frozen()
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Background": True,
    })
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    hist.set_refinements({"Background": {"refine": True}})

    selected = []
    for phase_index, h, k, l, axial in args.term:
        phase = phases[int(phase_index)]
        hap = phase.data["Histograms"][hist.name]
        equatorial = float(hap["Mustrain"][1][0])
        hap["Mustrain"][1][1] = float(axial)
        phase.set_HAP_refinements({
            "Mustrain": {
                "type": "uniaxial",
                "refine": "axial",
                "direction": [int(h), int(k), int(l)],
            }
        })
        project.set_Controls("parmMin", 0.25 * equatorial, f"{phase.id}:0:Mustrain;a")
        project.set_Controls("parmMax", 4.0 * equatorial, f"{phase.id}:0:Mustrain;a")
        selected.append(phase)

    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 0.00005
    project.data["Covariance"]["data"] = {}
    project.refine()
    first = hist.get_wR()
    for phase in selected:
        phase.clear_HAP_refinements({"Mustrain": True})
    project.set_Frozen()
    project.data["Covariance"]["data"] = {}
    project.refine()
    replay = hist.get_wR()
    project.save()

    result = {"Rwp_first_percent": first, "Rwp_replay_percent": replay, "terms": []}
    for phase in selected:
        hap = phase.data["Histograms"][hist.name]
        eq, axial = map(float, hap["Mustrain"][1][:2])
        result["terms"].append({
            "phase": phase.name,
            "axis": hap["Mustrain"][3],
            "equatorial_ppm": eq,
            "axial_ppm": axial,
            "axial_ratio": axial / eq,
        })
    (args.out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
