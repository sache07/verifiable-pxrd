#!/usr/bin/env python3
"""Create and refine a GSAS-II project for a selected candidate phase set.

Run with the GSAS-II Python environment. This is an exploratory trial driver;
the final export is produced separately after model selection.
"""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2


def instrument_text() -> str:
    return (
        "# GSAS-II Cu Kalpha laboratory instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.12;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:12.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def summary(project: G2.G2Project, hist, stage: str) -> dict:
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "stage": stage,
        "wR_percent": hist.get_wR(),
        "instrument": {k: v[1] for k, v in inst.items()
                       if k in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."}},
        "sample": {k: (v[0] if isinstance(v, list) else v)
                   for k, v in sample.items()
                   if k in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"}},
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append({
            "name": phase.name,
            "cell": phase.data["General"]["Cell"][1:8],
            "mass": phase.data["General"]["Mass"],
            "scale": hap["Scale"][0],
            "size": copy.deepcopy(hap["Size"]),
            "mustrain": copy.deepcopy(hap["Mustrain"]),
            "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
        })
    cov = project.data.get("Covariance", {}).get("data", {})
    result["GOF"] = cov.get("Rvals", {}).get("GOF")
    result["vary_list"] = [str(x) for x in cov.get("varyList", [])]
    return result


def run_refinement(project, hist, label, history, strict=True):
    try:
        project.refine()
        history.append(summary(project, hist, label))
        print(label, "wR", hist.get_wR())
    except Exception as exc:
        history.append({"stage": label, "error": str(exc), "traceback": traceback.format_exc()})
        print(label, "FAILED", repr(exc))
        if strict:
            raise


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("cifs", nargs="+", type=Path)
    parser.add_argument("--names", nargs="*")
    parser.add_argument("--background", type=int, default=15)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--atoms", action="store_true")
    parser.add_argument("--phase-widths", action="store_true")
    parser.add_argument("--surface", action="store_true")
    parser.add_argument("--fixed-last-cell", action="store_true")
    parser.add_argument("--last-po-axis", nargs=3, type=int)
    parser.add_argument("--last-po-ratio", type=float, default=1.0)
    parser.add_argument("--last-po-fixed", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.out.mkdir(parents=True, exist_ok=True)
    x, y = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1).T
    # GSAS XYE convention: third column is sigma, so Poisson weights are 1/y.
    data = args.out / "pattern.xye"
    np.savetxt(data, np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]), fmt="%.10g")
    inst = args.out / "instrument.instprm"
    inst.write_text(instrument_text())

    gpx = args.out / "trial.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    names = args.names or [p.stem for p in args.cifs]
    if len(names) != len(args.cifs):
        raise ValueError("--names count must equal CIF count")
    phases = [project.add_phase(str(c.resolve()), phasename=n, fmthint="CIF")
              for c, n in zip(args.cifs, names)]
    hist = project.add_powder_histogram(str(data), str(inst), phases=phases, fmthint="xye")
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements({
        "Limits": [float(x[0]), float(x[-1])],
        "Background": {"type": "chebyschev-1", "no. coeffs": args.background,
                       "coeffs": [float(np.percentile(y, 10))] + [0.0] * (args.background - 1),
                       "refine": True},
    })
    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    # Keep nuisance parameters in the physically sampled laboratory range.
    for variable, lo, hi in [
        (":0:Zero", -0.5, 0.5), (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 50.0), (":0:W", 0.0, 50.0),
        (":0:X", 0.01, 10.0), (":0:SH/L", 0.001, 0.2),
    ]:
        project.set_Controls("parmMin", lo, variable)
        project.set_Controls("parmMax", hi, variable)
    history = []

    # Initial scales are kept modest and positive. Refinement establishes the
    # physically relevant mass fractions through Scale * cell mass.
    for i, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / len(phases), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    if args.last_po_axis:
        hap = phases[-1].data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = args.last_po_ratio
        hap["Pref.Ori."][2] = not args.last_po_fixed
        hap["Pref.Ori."][3] = list(args.last_po_axis)
        if not args.last_po_fixed:
            project.set_Controls("parmMin", 0.5, f"{phases[-1].id}:0:MD")
            project.set_Controls("parmMax", 2.0, f"{phases[-1].id}:0:MD")
    run_refinement(project, hist, "background_scales", history)

    # Refine a constant angular zero first, then cells. The subsequent sample
    # displacement captures the characteristic cos(theta) shift.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, hist, "zero", history)
    for phase in (phases[:-1] if args.fixed_last_cell else phases):
        phase.set_refinements({"Cell": True})
    run_refinement(project, hist, "cells", history)
    for phase in phases:
        phase.clear_refinements({"Cell": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(project, hist, "shift", history)
    hist.clear_refinements({"Sample Parameters": ["Shift"]})

    # Laboratory instrumental broadening and phase-specific specimen widths.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_refinement(project, hist, "instrument_profile", history)
    if args.phase_widths:
        for phase in phases:
            project.set_Controls("parmMin", 0.04, f"{phase.id}:0:Size;i")
            project.set_Controls("parmMax", 2.0, f"{phase.id}:0:Size;i")
            project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Mustrain;i")
            project.set_Controls("parmMax", 8000.0, f"{phase.id}:0:Mustrain;i")
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "value": 0.5, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            })
        run_refinement(project, hist, "phase_widths", history)

    # A modest physical surface roughness model can account for a common
    # low-angle deficit. Start it only after scales and widths stabilize.
    if args.surface:
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.15, True]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.10, True]
        run_refinement(project, hist, "surface_roughness", history, strict=False)

    if args.atoms:
        for phase in phases:
            phase.set_refinements({"Atoms": {"all": "X"}})
        run_refinement(project, hist, "atomic_coordinates", history, strict=False)

    project.save()
    final = summary(project, hist, "final")
    (args.out / "summary.json").write_text(json.dumps({"history": history, "final": final}, indent=2, default=str) + "\n")
    arrays = hist.data["data"][1]
    np.savetxt(args.out / "fit.csv", np.column_stack([arrays[0], arrays[1], arrays[3], arrays[5]]),
               delimiter=",", header="two_theta_deg,observed,calculated,difference", comments="", fmt="%.10g")
    print(json.dumps({"gpx": str(gpx), "wR": hist.get_wR(), "phases": final["phases"]}, default=str))


if __name__ == "__main__":
    main()
