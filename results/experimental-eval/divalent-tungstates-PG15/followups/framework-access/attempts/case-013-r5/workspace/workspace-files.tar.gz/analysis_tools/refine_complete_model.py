#!/usr/bin/env python3
"""Sequentially refine the selected six-phase model without changing inventory."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def state(project, hist, stage):
    result = {"stage": stage, "Rwp_percent": hist.get_wR(), "phases": []}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append({
            "name": phase.name,
            "cell": phase.data["General"]["Cell"][1:8],
            "mass": phase.data["General"]["Mass"],
            "scale": hap["Scale"][0],
            "size": copy.deepcopy(hap["Size"]),
            "mustrain": copy.deepcopy(hap["Mustrain"]),
            "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
        })
    result["instrument"] = {
        key: values[1] for key, values in hist.data["Instrument Parameters"][0].items()
        if key in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."}
    }
    result["sample"] = {
        key: (values[0] if isinstance(values, list) else values)
        for key, values in hist.data["Sample Parameters"].items()
        if key in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
    }
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--no-atoms", action="store_true")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    output = args.out / "refined.gpx"

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.base.resolve()), newgpx=str(output.resolve()))
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Frozen()
    project.set_Controls("cycles", 6)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001

    # Start from retained parameter values, but remove every stale refinement flag.
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Background": True,
    })
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})

    for variable, lo, hi in [
        (":0:Zero", -0.5, 0.5), (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 50.0), (":0:W", 2.0, 50.0),
        (":0:X", 0.05, 10.0), (":0:SH/L", 0.001, 0.2),
        (":0:SurfRoughA", 0.0, 0.8), (":0:SurfRoughB", 0.001, 1.0),
    ]:
        project.set_Controls("parmMin", lo, variable)
        project.set_Controls("parmMax", hi, variable)
    for phase in phases:
        project.set_Controls("parmMin", 0.04, f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 2.0, f"{phase.id}:0:Size;i")
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, f"{phase.id}:0:Mustrain;i")

    history = []

    def refine(label):
        project.data["Covariance"]["data"] = {}
        project.refine()
        row = state(project, hist, label)
        history.append(row)
        project.save()
        print(f"{label}: Rwp={row['Rwp_percent']:.6f}", flush=True)

    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    refine("background_and_scales")

    # Cells are optimized one phase at a time to avoid unstable correlated shifts.
    for phase in phases:
        phase.set_refinements({"Cell": True})
        refine(f"cell_{phase.name}")
        phase.clear_refinements({"Cell": True})

    # First specimen-width pass with the current common instrument profile.
    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        refine(f"size_{phase.name}")
        phase.clear_HAP_refinements({"Size": True})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        refine(f"mustrain_{phase.name}")
        phase.clear_HAP_refinements({"Mustrain": True})

    # Re-establish the common instrument contribution, then repeat phase widths.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine("instrument_profile")
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
        refine(f"widths_{phase.name}")
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})

    if not args.no_atoms:
        # Symmetry restrictions are imposed internally by GSAS-II. Refining one
        # phase at a time limits cross-correlation among overlapping patterns.
        for phase in phases:
            phase.set_refinements({"Atoms": {"all": "X"}})
            refine(f"coordinates_{phase.name}")
            phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})

    refine("final_background_scales")
    (args.out / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print(json.dumps(state(project, hist, "final")), flush=True)


if __name__ == "__main__":
    main()
