#!/usr/bin/env python3
"""Jointly refine protocol-bounded zero/height displacement and phase cells."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--zero", required=True, type=float)
    parser.add_argument("--shift", required=True, type=float)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()),
        newgpx=str((args.out / "refined.gpx").resolve()),
    )
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Frozen()
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Background": True,
    })
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
    hist.set_refinements({
        "Background": {"refine": True},
        "Instrument Parameters": ["Zero"],
        "Sample Parameters": ["Shift"],
    })
    hist.data["Instrument Parameters"][0]["Zero"][1] = args.zero
    hist.data["Sample Parameters"]["Shift"][0] = args.shift
    project.set_Controls("parmMin", -0.25, ":0:Zero")
    project.set_Controls("parmMax", 0.25, ":0:Zero")
    project.set_Controls("parmMin", -800.0, ":0:Shift")
    project.set_Controls("parmMax", 800.0, ":0:Shift")
    project.set_Controls("cycles", 18)
    project.data["Controls"]["data"]["min dM/M"] = 0.00003
    project.data["Covariance"]["data"] = {}
    project.refine()
    first = hist.get_wR()

    hist.clear_refinements({
        "Instrument Parameters": ["Zero"],
        "Sample Parameters": ["Shift"],
    })
    for phase in phases:
        phase.clear_refinements({"Cell": True})
    project.set_Frozen()
    project.data["Covariance"]["data"] = {}
    project.refine()
    replay = hist.get_wR()
    project.save()

    result = {
        "Rwp_first_percent": first,
        "Rwp_replay_percent": replay,
        "zero_deg": hist.data["Instrument Parameters"][0]["Zero"][1],
        "shift_um": hist.data["Sample Parameters"]["Shift"][0],
        "cells": [{"phase": p.name, "cell": p.data["General"]["Cell"][1:8]} for p in phases],
    }
    (args.out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
