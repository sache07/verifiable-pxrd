#!/usr/bin/env python3
"""Jointly refine selected isotropic phase widths, then test a frozen replay."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--phase", action="append", type=int, default=[])
    parser.add_argument(
        "--seed", action="append", nargs=3, type=float,
        metavar=("PHASE", "SIZE_UM", "MUSTRAIN_PPM"), default=[],
    )
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()),
        newgpx=str((args.out / "refined.gpx").resolve()),
    )
    hist = project.histogram(0)
    phases = project.phases()
    selected = args.phase or list(range(len(phases)))

    project.set_Frozen()
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Background": True,
    })
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    hist.set_refinements({"Background": {"refine": True}})

    for phase_index, size, strain in args.seed:
        phase = phases[int(phase_index)]
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain

    for phase_index in selected:
        phase = phases[phase_index]
        project.set_Controls("parmMin", 0.04, f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 1.5, f"{phase.id}:0:Size;i")
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, f"{phase.id}:0:Mustrain;i")
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })

    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 0.00005
    project.data["Covariance"]["data"] = {}
    project.refine()
    first = hist.get_wR()

    # Hold the widths and re-optimize only background and phase scales. This
    # catches non-reproducible values caused by bounds/frozen variables.
    for phase in phases:
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    project.set_Frozen()
    project.data["Covariance"]["data"] = {}
    project.refine()
    replay = hist.get_wR()
    project.save()

    result = {
        "Rwp_first_percent": first,
        "Rwp_replay_percent": replay,
        "phases": [],
    }
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append({
            "name": phase.name,
            "size_um": hap["Size"][1][0],
            "mustrain_ppm": hap["Mustrain"][1][0],
            "scale": hap["Scale"][0],
        })
    (args.out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
