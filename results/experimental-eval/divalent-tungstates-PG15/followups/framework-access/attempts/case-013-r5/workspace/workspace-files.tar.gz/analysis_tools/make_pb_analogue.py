#!/usr/bin/env python3
"""Create a Pb-W-O analogue by replacing every non-W/O cation in a COD model."""

from pathlib import Path
import sys
import warnings

from pymatgen.io.cif import CifParser, CifWriter


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    cod_id, destination = sys.argv[1], Path(sys.argv[2])
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = CifParser(
            cod_path(cod_id), occupancy_tolerance=1.0,
            site_tolerance=1e-5, frac_tolerance=0,
        ).parse_structures(primitive=False, on_error="raise")[0]
    structure.remove_oxidation_states()
    substitutions = {
        element: "Pb" for element in structure.composition.elements
        if element.symbol not in {"O", "W", "Pb"}
    }
    structure.replace_species(substitutions)
    for i, site in enumerate(structure):
        site.label = f"{site.species_string}{i}"
    writer = CifWriter(structure, symprec=0.001, significant_figures=10)
    tag = "_atom_site_U_iso_or_equiv"
    for block in writer.cif_file.data.values():
        block.data[tag] = ["0.0050000000"] * len(block.data["_atom_site_label"])
        loop = next(loop for loop in block.loops if "_atom_site_label" in loop)
        if tag not in loop:
            loop.append(tag)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(str(writer) + "\n")
    print(destination, structure.composition.reduced_formula, substitutions)


if __name__ == "__main__":
    main()
