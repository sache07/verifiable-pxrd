#!/usr/bin/env python3
"""Apply fixed common Uiso values and selected MD textures, then update scales/background."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--uiso", nargs="+", type=float, required=True)
    parser.add_argument("--polarization", type=float)
    parser.add_argument("--surface", nargs=2, type=float, metavar=("A", "B"))
    parser.add_argument(
        "--texture", action="append", nargs=5, type=float,
        metavar=("PHASE", "H", "K", "L", "RATIO"), default=[],
    )
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()),
        newgpx=str((args.out / "refined.gpx").resolve()),
    )
    hist = project.histogram(0)
    phases = project.phases()
    if len(args.uiso) != len(phases):
        raise ValueError("one Uiso value is required for each phase")
    project.set_Frozen()
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Background": True,
    })
    for phase, value in zip(phases, args.uiso):
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
        pointer = phase.data["General"]["AtomPtrs"][3]
        for atom in phase.data["Atoms"]:
            atom[pointer] = "I"
            atom[pointer + 1] = value
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
    for phase_index, h, k, l, ratio in args.texture:
        phase = phases[int(phase_index)]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][1] = float(ratio)
        hap["Pref.Ori."][3] = [int(h), int(k), int(l)]
    hist.set_refinements({"Background": {"refine": True}})
    if args.polarization is not None:
        hist.data["Instrument Parameters"][0]["Polariz."][1] = args.polarization
    if args.surface is not None:
        hist.data["Sample Parameters"]["SurfRoughA"] = [args.surface[0], False]
        hist.data["Sample Parameters"]["SurfRoughB"] = [args.surface[1], False]
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    project.data["Covariance"]["data"] = {}
    project.refine()
    project.save()
    result = {
        "Rwp_percent": hist.get_wR(),
        "phases": [
            {
                "name": phase.name,
                "uiso_A2": args.uiso[i],
                "texture": phase.data["Histograms"][hist.name]["Pref.Ori."][:4],
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
            }
            for i, phase in enumerate(phases)
        ],
    }
    (args.out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
