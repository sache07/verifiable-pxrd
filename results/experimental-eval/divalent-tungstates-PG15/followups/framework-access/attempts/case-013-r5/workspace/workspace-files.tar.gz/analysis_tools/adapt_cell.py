#!/usr/bin/env python3
"""Replace a CIF lattice while retaining fractional coordinates and symmetry."""

import argparse
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser, CifWriter


def main():
    p = argparse.ArgumentParser()
    p.add_argument("source", type=Path)
    p.add_argument("destination", type=Path)
    p.add_argument("cell", nargs="*", type=float, metavar="CELL")
    p.add_argument("--isotropic-scale", type=float)
    a = p.parse_args()
    old = CifParser(a.source, occupancy_tolerance=1.0, frac_tolerance=0).parse_structures(primitive=False)[0]
    if a.isotropic_scale is not None:
        lattice = Lattice.from_parameters(
            *(length * a.isotropic_scale for length in old.lattice.abc),
            *old.lattice.angles,
        )
    elif len(a.cell) == 6:
        lattice = Lattice.from_parameters(*a.cell)
    else:
        p.error("supply six cell values or --isotropic-scale")
    new = Structure(lattice, [s.species for s in old], old.frac_coords,
                    site_properties=old.site_properties, labels=[s.label for s in old])
    a.destination.parent.mkdir(parents=True, exist_ok=True)
    a.destination.write_text(str(CifWriter(new, symprec=0.001, significant_figures=10)) + "\n")


if __name__ == "__main__":
    main()
