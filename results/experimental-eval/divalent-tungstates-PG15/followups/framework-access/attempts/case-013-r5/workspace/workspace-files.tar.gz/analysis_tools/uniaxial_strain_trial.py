#!/usr/bin/env python3
"""Test one phase/axis for generator-compatible uniaxial microstrain."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--phase", required=True, type=int)
    parser.add_argument("--axis", required=True, nargs=3, type=int)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()),
        newgpx=str((args.out / "trial.gpx").resolve()),
    )
    hist = project.histogram(0)
    phases = project.phases()
    target = phases[args.phase]

    project.set_Frozen()
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Background": True,
    })
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    hist.set_refinements({"Background": {"refine": True}})

    hap = target.data["Histograms"][hist.name]
    equatorial = float(hap["Mustrain"][1][0])
    if equatorial <= 0:
        raise ValueError("uniaxial trial requires positive equatorial strain")
    hap["Mustrain"][1][1] = equatorial
    target.set_HAP_refinements({
        "Mustrain": {
            "type": "uniaxial",
            "refine": "axial",
            "direction": args.axis,
        }
    })
    project.set_Controls("parmMin", 0.25 * equatorial, f"{target.id}:0:Mustrain;a")
    project.set_Controls("parmMax", 4.0 * equatorial, f"{target.id}:0:Mustrain;a")
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["min dM/M"] = 0.00005
    project.data["Covariance"]["data"] = {}
    project.refine()
    first = hist.get_wR()

    target.clear_HAP_refinements({"Mustrain": True})
    project.set_Frozen()
    project.data["Covariance"]["data"] = {}
    project.refine()
    replay = hist.get_wR()
    project.save()
    axial = float(hap["Mustrain"][1][1])
    result = {
        "phase": target.name,
        "axis": args.axis,
        "Rwp_first_percent": first,
        "Rwp_replay_percent": replay,
        "equatorial_ppm": equatorial,
        "axial_ppm": axial,
        "axial_ratio": axial / equatorial,
    }
    (args.out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
