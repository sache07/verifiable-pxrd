#!/usr/bin/env python3
"""Refine one phase's isotropic size/strain and verify the bounded replay."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--phase", required=True, type=int)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()),
        newgpx=str((args.out / "trial.gpx").resolve()),
    )
    hist = project.histogram(0)
    project.set_Frozen()
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Background": True,
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    hist.set_refinements({"Background": {"refine": True}})
    phase = project.phase(args.phase)
    project.set_Controls("parmMin", 0.04, f"{phase.id}:0:Size;i")
    project.set_Controls("parmMax", 1.5, f"{phase.id}:0:Size;i")
    project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, f"{phase.id}:0:Mustrain;i")
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    project.data["Covariance"]["data"] = {}
    project.refine()
    first = hist.get_wR()
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    project.set_Frozen()
    project.data["Covariance"]["data"] = {}
    project.refine()
    project.save()
    hap = phase.data["Histograms"][hist.name]
    result = {
        "phase": phase.name,
        "Rwp_first_percent": first,
        "Rwp_replay_percent": hist.get_wR(),
        "size_um": hap["Size"][1][0],
        "mustrain_ppm": hap["Mustrain"][1][0],
    }
    (args.out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
