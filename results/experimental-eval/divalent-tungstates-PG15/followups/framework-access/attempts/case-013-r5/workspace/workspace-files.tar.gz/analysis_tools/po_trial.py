#!/usr/bin/env python3
"""Test one March-Dollase axis against a stable GSAS-II refinement."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--phase", type=int, required=True)
    ap.add_argument("--axis", nargs=3, type=int, required=True)
    ap.add_argument("--start", type=float, default=1.0)
    a = ap.parse_args()
    G2.SetPrintLevel("warn")
    a.out.mkdir(parents=True, exist_ok=True)
    proj = G2.G2Project(gpxfile=str(a.base.resolve()), newgpx=str((a.out / "trial.gpx").resolve()))
    hist = proj.histogram(0)
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
    })
    proj.set_Frozen()
    for phase in proj.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    phase = proj.phase(a.phase)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = a.start
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(a.axis)
    proj.set_Controls("parmMin", 0.7, f"{phase.id}:0:MD")
    proj.set_Controls("parmMax", 1.4, f"{phase.id}:0:MD")
    proj.data["Covariance"]["data"] = {}
    proj.set_Controls("cycles", 6)
    proj.refine()
    result = {
        "wR_percent": hist.get_wR(),
        "phase": phase.name,
        "axis": a.axis,
        "ratio": phase.data["Histograms"][hist.name]["Pref.Ori."][1],
        "scales": {p.name: p.data["Histograms"][hist.name]["Scale"][0] for p in proj.phases()},
    }
    proj.save()
    (a.out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
