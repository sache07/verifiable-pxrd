#!/usr/bin/env python3
"""Test a common fixed isotropic displacement parameter for one phase."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--phase", required=True, type=int)
    parser.add_argument("--uiso", required=True, type=float)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()),
        newgpx=str((args.out / "trial.gpx").resolve()),
    )
    hist = project.histogram(0)
    project.set_Frozen()
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Background": True,
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    hist.set_refinements({"Background": {"refine": True}})
    phase = project.phase(args.phase)
    pointer = phase.data["General"]["AtomPtrs"][3]
    for atom in phase.data["Atoms"]:
        atom[pointer] = "I"
        atom[pointer + 1] = args.uiso
    project.set_Controls("cycles", 6)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    project.data["Covariance"]["data"] = {}
    project.refine()
    project.save()
    result = {
        "phase": phase.name,
        "uiso_A2": args.uiso,
        "Rwp_percent": hist.get_wR(),
        "scales": {p.name: p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()},
    }
    (args.out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
