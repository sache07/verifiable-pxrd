#!/usr/bin/env python3
"""Prepare COD structures in the same normalized form used by the generator."""

from pathlib import Path
import sys
import warnings

from pymatgen.io.cif import CifParser, CifWriter


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def normalize(cod_id: str, destination: Path) -> None:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = CifParser(
            cod_path(cod_id), occupancy_tolerance=1.0,
            site_tolerance=1e-5, frac_tolerance=0,
        ).parse_structures(primitive=False, on_error="raise")[0]
    structure.remove_oxidation_states()
    for i, site in enumerate(structure):
        site.label = f"{site.species_string}{i}"
    writer = CifWriter(structure, symprec=0.001, significant_figures=10)
    tag = "_atom_site_U_iso_or_equiv"
    for block in writer.cif_file.data.values():
        block.data[tag] = ["0.0050000000"] * len(block.data["_atom_site_label"])
        loop = next(loop for loop in block.loops if "_atom_site_label" in loop)
        if tag not in loop:
            loop.append(tag)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(str(writer) + "\n")


def main() -> None:
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "analysis_tools/candidates")
    ids = sys.argv[2:] or [
        "9016035", "2310433", "1010618", "1528915", "1563541",
        "2311041", "2106293", "2107312", "1521532", "1521533",
    ]
    for cod_id in ids:
        path = out / f"cod_{cod_id}.cif"
        normalize(cod_id, path)
        print(path)


if __name__ == "__main__":
    main()
