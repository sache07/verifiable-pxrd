#!/usr/bin/env python3
"""Refine small coordinate offsets with an 0.08 A per-axis hard cap."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()),
        newgpx=str((args.out / "refined.gpx").resolve()),
    )
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Frozen()
    project.set_Controls("cycles", 4)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Background": True,
    })
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    hist.set_refinements({"Background": {"refine": True}})
    history = []

    def refine(label):
        project.data["Covariance"]["data"] = {}
        project.refine()
        project.save()
        history.append({"stage": label, "Rwp_percent": hist.get_wR()})
        print(f"{label}: Rwp={hist.get_wR():.6f}", flush=True)

    refine("baseline")
    for phase in phases:
        lengths = phase.data["General"]["Cell"][1:4]
        for atom_index, atom in enumerate(phase.data["Atoms"]):
            for coordinate_index, (axis, length) in enumerate(zip("xyz", lengths), start=3):
                variable = f"{phase.id}::dA{axis}:{atom_index}"
                bound = 0.08 / float(length)
                # Despite the historical dA variable name, GSAS-II applies
                # min/max limits to the absolute fractional coordinate.
                center = float(atom[coordinate_index])
                project.set_Controls("parmMin", center - bound, variable)
                project.set_Controls("parmMax", center + bound, variable)
        phase.set_refinements({"Atoms": {"all": "X"}})
        refine("bounded_coordinates_" + phase.name)
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
        project.set_Frozen()
        # Recompute after hard-limit clamping so the stored profile is replayable.
        refine("replay_" + phase.name)
    (args.out / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
