#!/usr/bin/env python3
"""Screen one additional phase by adding it to a stable GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def snapshot(project, hist, stage):
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append({
            "name": phase.name,
            "cell": phase.data["General"]["Cell"][1:8],
            "mass": phase.data["General"]["Mass"],
            "scale": hap["Scale"][0],
        })
    return {"stage": stage, "wR_percent": hist.get_wR(), "phases": phases}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("base", type=Path)
    p.add_argument("cif", type=Path)
    p.add_argument("--out", required=True, type=Path)
    p.add_argument("--name", default="candidate")
    p.add_argument("--refine-cell", action="store_true")
    p.add_argument("--po-axis", nargs=3, type=int)
    p.add_argument("--po-ratio", type=float, default=1.0)
    a = p.parse_args()
    G2.SetPrintLevel("warn")
    a.out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(a.base.resolve()), newgpx=str((a.out / "trial.gpx").resolve()))
    hist = project.histogram(0)
    # Remove all pre-existing nonlinear flags, retaining the stable parameter
    # values from the base fit. Keep background and all phase scales adjustable.
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Background": True,
    })
    project.set_Frozen()
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.clear_HAP_refinements({"Scale": True})

    extra = project.add_phase(str(a.cif.resolve()), phasename=a.name, histograms=[hist], fmthint="CIF")
    extra.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in extra.atoms()]})
    hap = extra.data["Histograms"][hist.name]
    hap["Scale"] = [0.05, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][1][1] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    if a.po_axis:
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = a.po_ratio
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = list(a.po_axis)
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    project.data["Covariance"]["data"] = {}

    history = []
    project.refine()
    history.append(snapshot(project, hist, "candidate_scale_only"))
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    project.refine()
    history.append(snapshot(project, hist, "all_scales"))
    # Only attempt a cell adjustment when the candidate has a non-negligible
    # positive scale. This avoids singular absent-phase cell refinements.
    extra = project.phase(a.name)
    if a.refine_cell and extra.data["Histograms"][hist.name]["Scale"][0] > 1e-5:
        extra.set_refinements({"Cell": True})
        project.refine()
        history.append(snapshot(project, hist, "candidate_cell"))
    project.save()
    result = {"history": history, "final": snapshot(project, hist, "final")}
    (a.out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result["final"]))


if __name__ == "__main__":
    main()
