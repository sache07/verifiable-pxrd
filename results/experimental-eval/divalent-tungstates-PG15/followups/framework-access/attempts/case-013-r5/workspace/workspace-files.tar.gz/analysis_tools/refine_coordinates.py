#!/usr/bin/env python3
"""Refine symmetry-allowed coordinates phase-by-phase from a stable profile fit."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.base.resolve()),
        newgpx=str((args.out / "refined.gpx").resolve()),
    )
    hist = project.histogram(0)
    phases = project.phases()
    project.set_Frozen()
    project.set_Controls("cycles", 4)
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Background": True,
    })
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    hist.set_refinements({"Background": {"refine": True}})
    history = []

    def refine(label):
        project.data["Covariance"]["data"] = {}
        project.refine()
        history.append({"stage": label, "Rwp_percent": hist.get_wR()})
        project.save()
        print(f"{label}: Rwp={hist.get_wR():.6f}", flush=True)

    refine("background_scales")
    for phase in phases:
        phase.set_refinements({"Atoms": {"all": "X"}})
        refine("coordinates_" + phase.name)
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
    refine("final_background_scales")
    (args.out / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
