#!/usr/bin/env python3
"""Screen March-Dollase axes for one phase without altering the base model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_models import summary
from sixphase_refine import clear_flags, set_bounds


AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def main(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    rows = []
    for axis in AXES:
        label = "".join(str(v) for v in axis)
        target = out / f"axis_{label}.gpx"
        project = G2.G2Project(str(args.base.resolve()), newgpx=str(target))
        clear_flags(project)
        set_bounds(project)
        hist = project.histogram(0)
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        pid = phase.data["pId"]
        hid = hist.data["data"][0]["hId"]
        project.set_Controls("parmMin", args.minimum, variable=f"{pid}:{hid}:MD")
        project.set_Controls("parmMax", args.maximum, variable=f"{pid}:{hid}:MD")
        project.set_Controls("cycles", 16)
        project.refine()
        project.save()
        state = summary(project)
        ratio = project.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."][1]
        row = {"axis": list(axis), "ratio": float(ratio), "Rwp_percent": state["Rwp_percent"], "project": target.name}
        rows.append(row)
        print(args.phase, axis, ratio, state["Rwp_percent"], flush=True)
    (out / "screen.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--minimum", type=float, default=0.5)
    parser.add_argument("--maximum", type=float, default=2.0)
    main(parser.parse_args())
