#!/usr/bin/env python3
"""Screen uniaxial microstrain axes for one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_models import summary
from sixphase_refine import clear_flags, set_bounds


AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0)]


def main(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    rows = []
    for axis in AXES:
        label = "".join(str(v) for v in axis)
        target = out / f"axis_{label}.gpx"
        project = G2.G2Project(str(args.base.resolve()), newgpx=str(target))
        clear_flags(project)
        set_bounds(project)
        hist = project.histogram(0)
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        initial = float(hap["Mustrain"][1][0])
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = initial
        hap["Mustrain"][1][1] = initial
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = list(axis)
        pid = phase.data["pId"]
        hid = hist.data["data"][0]["hId"]
        for variable in [f"{pid}:{hid}:Mustrain;i", f"{pid}:{hid}:Mustrain;a"]:
            project.set_Controls("parmMin", 0.0, variable=variable)
            project.set_Controls("parmMax", args.maximum, variable=variable)
        project.set_Controls("cycles", 24)
        project.refine()
        project.save()
        state = summary(project)
        hap = project.phase(args.phase).data["Histograms"][hist.name]
        row = {
            "axis": list(axis),
            "perpendicular_ppm": float(hap["Mustrain"][1][0]),
            "axial_ppm": float(hap["Mustrain"][1][1]),
            "Rwp_percent": state["Rwp_percent"],
            "project": target.name,
        }
        rows.append(row)
        print(args.phase, row, flush=True)
    (out / "screen.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--maximum", type=float, default=32000.0)
    main(parser.parse_args())
