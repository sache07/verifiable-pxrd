#!/usr/bin/env python3
"""Screen bounded angular-zero/specimen-displacement refinements.

The synthetic laboratory model contains both a constant 2theta zero and the
GSAS-II Bragg-Brentano sample-height term.  They are correlated with lattice
parameters, so this script uses several starts and refines all phase cells in
the same least-squares stage.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_models import summary
from sixphase_refine import clear_flags, set_bounds


def run(base: Path, outdir: Path, zero: float, shift: float) -> dict:
    tag = f"z{zero:+.2f}_s{shift:+.0f}".replace("+", "p").replace("-", "m")
    target = outdir / f"{tag}.gpx"
    project = G2.G2Project(str(base.resolve()), newgpx=str(target.resolve()))
    clear_flags(project)
    set_bounds(project)
    hist = project.histogram(0)
    hid = hist.data["data"][0]["hId"]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    inst["Zero"][1:] = [zero, True]
    sample["Shift"][0:2] = [shift, True]
    project.set_Controls("parmMin", -0.25, variable=f":{hid}:Zero")
    project.set_Controls("parmMax", 0.25, variable=f":{hid}:Zero")
    project.set_Controls("parmMin", -800.0, variable=f":{hid}:Shift")
    project.set_Controls("parmMax", 800.0, variable=f":{hid}:Shift")
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    project.set_Controls("cycles", 40)
    project.refine()
    project.save()
    result = summary(project)
    result.update(
        project=str(target),
        start_zero=zero,
        start_shift_um=shift,
        zero_deg=float(inst["Zero"][1]),
        shift_um=float(sample["Shift"][0]),
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=False)
    rows = []
    for zero in (-0.2, 0.0, 0.2):
        for shift in (-600.0, 0.0, 600.0):
            try:
                row = run(args.base, args.outdir, zero, shift)
                print(row["Rwp_percent"], row["zero_deg"], row["shift_um"], row["project"], flush=True)
                rows.append(row)
            except Exception as exc:
                print("FAILED", zero, shift, repr(exc), flush=True)
    (args.outdir / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
