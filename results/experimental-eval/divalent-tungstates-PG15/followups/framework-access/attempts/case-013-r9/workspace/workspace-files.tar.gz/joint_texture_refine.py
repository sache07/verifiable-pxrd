#!/usr/bin/env python3
"""Consolidate supported texture terms and rebalance common profile/cells."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_models import summary
from sixphase_refine import clear_flags, set_bounds


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/texture4_massicot/axis_010.gpx"
OUT = ROOT / "trials/joint_texture"
TEXTURES = {
    "PbO_massicot": [0, 1, 0],
    "WO3": [1, 1, 0],
    "Pb2WO5": [1, 0, 0],
    "Pb3WO6": [1, 0, 0],
}


def textures(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hid = hist.data["data"][0]["hId"]
    for name, axis in TEXTURES.items():
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.5, variable=f"{pid}:{hid}:MD")
        project.set_Controls("parmMax", 2.0, variable=f"{pid}:{hid}:MD")


def instrument(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hid = hist.data["data"][0]["hId"]
    inst = hist.data["Instrument Parameters"][0]
    # Keep the common profile inside the calibrated laboratory range used for
    # this measurement family; phase broadening remains modeled in the HAPs.
    inst["X"][1] = min(float(inst["X"][1]), 6.0)
    for key in ["U", "W", "X", "SH/L"]:
        inst[key][2] = True
    for key, low, high in [("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0), ("SH/L", 0.005, 0.1)]:
        project.set_Controls("parmMin", low, variable=f":{hid}:{key}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{key}")


def cells(project: G2.G2Project) -> None:
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True


def run_stage(source: Path, number: int, label: str, configure) -> tuple[Path, dict]:
    target = OUT / f"stage{number:02d}_{label}.gpx"
    project = G2.G2Project(str(source), newgpx=str(target))
    clear_flags(project)
    set_bounds(project)
    configure(project)
    project.set_Controls("cycles", 30)
    project.refine()
    project.save()
    state = summary(project)
    state.update(stage=label, project=str(target.relative_to(ROOT)))
    print(number, label, state["Rwp_percent"], flush=True)
    return target, state


def main() -> None:
    if OUT.exists():
        raise SystemExit(f"Refusing to overwrite {OUT}")
    OUT.mkdir(parents=True)
    stages = [("textures_1", textures), ("instrument", instrument), ("textures_2", textures), ("cells_1", cells), ("cells_2", cells)]
    current = SOURCE
    history = []
    for number, (label, configure) in enumerate(stages, 1):
        current, state = run_stage(current, number, label, configure)
        history.append(state)
    shutil.copy2(current, OUT / "model.gpx")
    (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
