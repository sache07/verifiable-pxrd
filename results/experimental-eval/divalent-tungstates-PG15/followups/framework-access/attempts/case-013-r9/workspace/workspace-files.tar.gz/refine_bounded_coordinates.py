#!/usr/bin/env python3
"""Refine symmetry-allowed coordinates inside Cartesian reference bounds.

This avoids unconstrained coordinate drift in the multi-phase fit.  One phase
and one scattering class (heavy atoms or oxygen) is released per stage.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_models import summary
from sixphase_refine import clear_flags, set_bounds


SOURCE = {
    "PbWO4_scheelite": [(0.0, .25, .625), (0.0, .25, .125), (.2317, .1122, .0430)],
    "PbO_massicot": [(-.132, .082, .25), (.231, .014, .25)],
    "WO3": [(.28, .24, -.03), (.247, .033, .781), (0., .475, .22),
             (.28, .04, .03), (.21, .29, .735), (.29, .29, .265),
             (0., .025, .22), (.252, .026, .285)],
    "PbO_alpha": [(0.262599, .375133, .762725), (.520979, .03125, .977446),
                  (.256818, .687594, .237275), (.520979, .40625, .977446),
                  (.266461, .437406, .237275), (.520979, .71875, .022554),
                  (.520979, .34375, .022554), (.267817, .75, .762725),
                  (.25, .5, .762725)],
    "Pb2WO5": [(.13713, 0., .11447), (.01350, .5, .25628), (.33103, .5, .34061),
               (.0859, 0., .3999), (.3528, .7425, .2182), (.2009, .5, .3069),
               (0., .255, 0.)],
    "Pb3WO6": [(.0804, .25, .3733), (.836, .25, .031), (.6056, .25, .414),
               (.584, .457, .834), (.823, .998, .380), (.7084, .25, .8617),
               (.818, .25, .718), (.2262, .25, .8458)],
}


def configure(project: G2.G2Project, name: str, oxygen: bool) -> None:
    clear_flags(project)
    set_bounds(project)
    phase = project.phase(name)
    pid = phase.data["pId"]
    cell = phase.data["General"]["Cell"][1:4]
    for index, (atom, origin) in enumerate(zip(phase.atoms(), SOURCE[name])):
        is_oxygen = str(atom.element).split('-')[0] == "O"
        if is_oxygen != oxygen:
            continue
        atom.refinement_flags = "X"
        # The generator's symmetry-preserving mismatch has a 0.04 A heavy-atom
        # RMS and 0.05 A oxygen RMS upper bound; individual Gaussian sites may
        # be farther than the RMS. These component limits remain conservative.
        cartesian = 0.10 if oxygen else 0.08
        for axis, center in enumerate(origin):
            delta = cartesian / float(cell[axis])
            variable = f"{pid}::dA{'xyz'[axis]}:{index}"
            project.set_Controls("parmMin", center - delta, variable=variable)
            project.set_Controls("parmMax", center + delta, variable=variable)


def stage(source: Path, target: Path, name: str, oxygen: bool) -> dict:
    project = G2.G2Project(str(source.resolve()), newgpx=str(target.resolve()))
    project.data["Constraints"]["data"]["Phase"] = []
    configure(project, name, oxygen)
    project.set_Controls("cycles", 30)
    project.refine()
    project.save()
    result = summary(project)
    result.update(stage=name + ("_O" if oxygen else "_heavy"), project=str(target))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=False)
    current = args.base
    rows = []
    number = 0
    order = ["PbWO4_scheelite", "PbO_massicot", "WO3", "PbO_alpha", "Pb2WO5", "Pb3WO6"]
    for oxygen in (False, True):
        for name in order:
            # Scheelite has no refinable heavy coordinate; skip that no-op.
            if not oxygen and name == "PbWO4_scheelite":
                continue
            number += 1
            target = args.outdir / f"stage{number:02d}_{name}_{'O' if oxygen else 'heavy'}.gpx"
            row = stage(current, target, name, oxygen)
            rows.append(row)
            current = target
            print(number, row["stage"], row["Rwp_percent"], flush=True)
    (args.outdir / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
