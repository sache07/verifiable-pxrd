#!/usr/bin/env python3
"""Run conservative structural-refinement stages on the five-phase model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_models import summary


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/profile5a/model.gpx"
OUT = ROOT / "trials/struct5"


def clear_flags(project: G2.G2Project) -> None:
    """Leave only background and phase scales active."""
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    project.set_Frozen()


def run_stage(source: Path, number: int, label: str, configure) -> tuple[Path, dict]:
    target = OUT / f"stage{number:02d}_{label}.gpx"
    project = G2.G2Project(str(source), newgpx=str(target))
    clear_flags(project)
    configure(project)
    project.set_Controls("cycles", 16)
    project.refine()
    project.save()
    state = summary(project)
    state["stage"] = label
    state["project"] = str(target.relative_to(ROOT))
    print(number, label, state["Rwp_percent"])
    return target, state


def select_atoms(phase_name: str, elements: set[str] | None = None, labels: set[str] | None = None):
    def configure(project: G2.G2Project) -> None:
        phase = project.phase(phase_name)
        for atom in phase.atoms():
            if (elements is None or atom.element in elements) and (labels is None or atom.label in labels):
                atom.refinement_flags = "X"
    return configure


def all_cells(project: G2.G2Project) -> None:
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True


def main() -> None:
    if OUT.exists():
        raise SystemExit(f"Refusing to overwrite {OUT}")
    OUT.mkdir(parents=True)
    history: list[dict] = []
    current = SOURCE
    stages = [
        ("cells", all_cells),
        ("pbwo4_O", select_atoms("PbWO4_scheelite", elements={"O"})),
        ("pb2wo5_heavy", select_atoms("Pb2WO5", elements={"Pb", "W"})),
        ("pb2wo5_all", select_atoms("Pb2WO5")),
        ("wo3_W", select_atoms("WO3", elements={"W"})),
        ("wo3_all", select_atoms("WO3")),
        ("massicot_all", select_atoms("PbO_massicot")),
        ("alpha_Pb", select_atoms("PbO_alpha", elements={"Pb"})),
        ("alpha_all", select_atoms("PbO_alpha")),
    ]
    for number, (label, configure) in enumerate(stages, 1):
        current, state = run_stage(current, number, label, configure)
        history.append(state)
    shutil.copy2(current, OUT / "model.gpx")
    (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
