#!/usr/bin/env python3
"""Profile the zero/sample-height ambiguity with stable cell updates.

Each trial fixes the bounded constant zero, initializes the sample-height term
on the locus matching the existing low-angle peak positions, then updates one
phase cell at a time.  The long-cell PbO phase is therefore never released
with the other lattice metrics in the same least-squares step.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_models import summary
from sixphase_refine import clear_flags, set_bounds


ZEROS = [-0.10, 0.00, 0.10, 0.20, 0.25]


def stage(project: G2.G2Project, phase_name: str | None = None, shift: bool = False) -> None:
    clear_flags(project)
    set_bounds(project)
    hist = project.histogram(0)
    hid = hist.data["data"][0]["hId"]
    if phase_name is not None:
        project.phase(phase_name).data["General"]["Cell"][0] = True
    if shift:
        hist.data["Sample Parameters"]["Shift"][1] = True
        project.set_Controls("parmMin", -800.0, variable=f":{hid}:Shift")
        project.set_Controls("parmMax", 800.0, variable=f":{hid}:Shift")
    project.set_Controls("cycles", 18)
    project.refine()


def run(base: Path, outdir: Path, zero: float) -> dict:
    # At 2theta about 35 degrees, -0.000547*Shift is the GSAS specimen
    # contribution.  This starts each trial near the previous 0.296 degree
    # effective displacement without treating that estimate as a constraint.
    initial_shift = max(-800.0, min(800.0, (zero - 0.296) / 0.000547))
    tag = f"z{zero:+.2f}".replace("+", "p").replace("-", "m")
    target = outdir / f"{tag}.gpx"
    project = G2.G2Project(str(base.resolve()), newgpx=str(target.resolve()))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    inst["Zero"][1:] = [zero, False]
    sample["Shift"][0:2] = [initial_shift, False]
    names = [p.name for p in project.phases()]
    for _ in range(2):
        for name in names:
            stage(project, phase_name=name)
        stage(project, shift=True)
    # Rebalance cells once more after the second height update.
    for name in names:
        stage(project, phase_name=name)
    clear_flags(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save()
    result = summary(project)
    result.update(
        project=str(target),
        fixed_zero_deg=zero,
        initial_shift_um=initial_shift,
        refined_shift_um=float(sample["Shift"][0]),
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=False)
    rows = []
    for zero in ZEROS:
        try:
            row = run(args.base, args.outdir, zero)
            rows.append(row)
            print(row["Rwp_percent"], zero, row["refined_shift_um"], row["project"], flush=True)
        except Exception as exc:
            print("FAILED", zero, repr(exc), flush=True)
    (args.outdir / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
