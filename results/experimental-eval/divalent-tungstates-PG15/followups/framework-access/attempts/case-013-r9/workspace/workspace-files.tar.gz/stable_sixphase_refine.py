#!/usr/bin/env python3
"""Alternate weakly correlated stages from the stable six-phase solution."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_models import summary
from sixphase_refine import clear_flags, set_bounds


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/sixphase_iso/stage04_pb3_strain.gpx"
OUT = ROOT / "trials/sixphase_stable"


def instrument(project: G2.G2Project) -> None:
    inst = project.histogram(0).data["Instrument Parameters"][0]
    for key in ["U", "W", "X", "SH/L"]:
        inst[key][2] = True


def candidate_parameter(key: str):
    def configure(project: G2.G2Project) -> None:
        hist = project.histogram(0)
        hap = project.phase("Pb3WO6").data["Histograms"][hist.name]
        hap[key][0] = "isotropic"
        hap[key][2][0] = True
    return configure


def all_cells(project: G2.G2Project) -> None:
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True


def run_stage(source: Path, number: int, label: str, configure) -> tuple[Path, dict]:
    target = OUT / f"stage{number:02d}_{label}.gpx"
    project = G2.G2Project(str(source), newgpx=str(target))
    clear_flags(project)
    set_bounds(project)
    # Tighter profile limits avoid the size/strain compensation seen in the
    # simultaneous trial while remaining broad for laboratory powders.
    pid = project.phase("Pb3WO6").data["pId"]
    hid = project.histogram(0).data["data"][0]["hId"]
    project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:Size;i")
    project.set_Controls("parmMax", 2.0, variable=f"{pid}:{hid}:Size;i")
    project.set_Controls("parmMax", 10000.0, variable=f"{pid}:{hid}:Mustrain;i")
    configure(project)
    project.set_Controls("cycles", 24)
    project.refine()
    project.save()
    state = summary(project)
    state.update(stage=label, project=str(target.relative_to(ROOT)))
    print(number, label, state["Rwp_percent"], flush=True)
    return target, state


def main() -> None:
    if OUT.exists():
        raise SystemExit(f"Refusing to overwrite {OUT}")
    OUT.mkdir(parents=True)
    stages = [
        ("instrument", instrument),
        ("pb3_size_1", candidate_parameter("Size")),
        ("pb3_strain_1", candidate_parameter("Mustrain")),
        ("pb3_size_2", candidate_parameter("Size")),
        ("pb3_strain_2", candidate_parameter("Mustrain")),
        ("cells_1", all_cells),
        ("cells_2", all_cells),
    ]
    history = []
    current = SOURCE
    for number, (label, configure) in enumerate(stages, 1):
        current, state = run_stage(current, number, label, configure)
        history.append(state)
    shutil.copy2(current, OUT / "model.gpx")
    (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
