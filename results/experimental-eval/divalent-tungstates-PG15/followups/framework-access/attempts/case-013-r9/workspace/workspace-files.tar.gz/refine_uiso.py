#!/usr/bin/env python3
"""Refine one constrained isotropic displacement parameter per phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_models import summary
from sixphase_refine import clear_flags, set_bounds


def main(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.base.resolve()), newgpx=str(args.out.resolve()))
    clear_flags(project)
    set_bounds(project)
    for phase in project.phases():
        pid = phase.data["pId"]
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.uiso = args.initial
            atom.refinement_flags = "U"
            variable = f"{pid}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", args.minimum, variable=variable)
            project.set_Controls("parmMax", args.maximum, variable=variable)
        if len(variables) > 1:
            project.add_EquivConstr(tuple(variables), override=True)
    project.set_Controls("cycles", 30)
    project.refine()
    project.save()
    state = summary(project)
    state["phase_Uiso_A2"] = {phase.name: float(phase.atoms()[0].uiso) for phase in project.phases()}
    print(json.dumps(state, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--initial", type=float, default=0.01)
    parser.add_argument("--minimum", type=float, default=0.002)
    parser.add_argument("--maximum", type=float, default=0.025)
    main(parser.parse_args())
