#!/usr/bin/env python3
"""Freeze the selected GSAS-II model and export its six phase CIFs."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/uiso_physical2.gpx"
FINAL = ROOT / "final.gpx"
CIFS = [
    "phase_1_PbWO4.cif",
    "phase_2_PbO_massicot.cif",
    "phase_3_WO3.cif",
    "phase_4_PbO_long_cell.cif",
    "phase_5_Pb2WO5.cif",
    "phase_6_Pb3WO6.cif",
]


def clear_all_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    for key in ("Hist", "HAP", "Phase", "Global"):
        project.data["Constraints"]["data"][key] = []
    project.set_Frozen()
    project.set_Controls("cycles", 0)


def main() -> None:
    if FINAL.exists():
        raise SystemExit(f"Refusing to overwrite {FINAL}")
    project = G2.G2Project(str(SOURCE), newgpx=str(FINAL))
    clear_all_flags(project)
    project.save()

    # Match the evaluator's native export convention: serialize the saved atom
    # records and do not substitute anything from a covariance cache.
    export = G2.G2Project(gpxfile=str(FINAL))
    export.data["Covariance"]["data"] = {}
    for phase, filename in zip(export.phases(), CIFS):
        phase.export_CIF(str((ROOT / filename).resolve()))
        print(filename)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
