#!/usr/bin/env python3
"""Refine the six-phase model while keeping reference coordinates fixed."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_models import summary


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/with_pb3wo6/trial.gpx"
OUT = ROOT / "trials/sixphase_iso"


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    project.set_Frozen()


def set_bounds(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hid = hist.data["data"][0]["hId"]
    for phase in project.phases():
        pid = phase.data["pId"]
        for variable, low, high in [
            (f"{pid}:{hid}:Scale", 0.0, 100.0),
            (f"{pid}:{hid}:Size;i", 0.02, 5.0),
            (f"{pid}:{hid}:Mustrain;i", 0.0, 12000.0),
        ]:
            project.set_Controls("parmMin", low, variable=variable)
            project.set_Controls("parmMax", high, variable=variable)
    for variable, low, high in [
        (f":{hid}:U", 0.0, 60.0),
        (f":{hid}:W", 0.1, 60.0),
        (f":{hid}:X", 0.0, 10.0),
        (f":{hid}:SH/L", 0.001, 0.2),
    ]:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)


def all_cells(project: G2.G2Project) -> None:
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True


def candidate_size(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hap = project.phase("Pb3WO6").data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = min(float(hap["Size"][1][0]), 0.5)
    hap["Size"][2][0] = True


def candidate_strain(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hap = project.phase("Pb3WO6").data["Histograms"][hist.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][2][0] = True


def candidate_profile(project: G2.G2Project) -> None:
    candidate_size(project)
    candidate_strain(project)


def all_profiles(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][2][0] = True
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2][0] = True


def instrument(project: G2.G2Project) -> None:
    inst = project.histogram(0).data["Instrument Parameters"][0]
    for key in ["U", "W", "X", "SH/L"]:
        inst[key][2] = True


def run_stage(source: Path, number: int, label: str, configure) -> tuple[Path, dict]:
    target = OUT / f"stage{number:02d}_{label}.gpx"
    project = G2.G2Project(str(source), newgpx=str(target))
    clear_flags(project)
    set_bounds(project)
    configure(project)
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    state = summary(project)
    state.update(stage=label, project=str(target.relative_to(ROOT)))
    print(number, label, state["Rwp_percent"], flush=True)
    return target, state


def main() -> None:
    if OUT.exists():
        raise SystemExit(f"Refusing to overwrite {OUT}")
    OUT.mkdir(parents=True)
    stages = [
        ("cells_1", all_cells),
        ("cells_2", all_cells),
        ("pb3_size", candidate_size),
        ("pb3_strain", candidate_strain),
        ("pb3_profile", candidate_profile),
        ("all_profiles_1", all_profiles),
        ("instrument", instrument),
        ("all_profiles_2", all_profiles),
        ("cells_3", all_cells),
    ]
    current = SOURCE
    history = []
    for number, (label, configure) in enumerate(stages, 1):
        current, state = run_stage(current, number, label, configure)
        history.append(state)
    shutil.copy2(current, OUT / "model.gpx")
    (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
