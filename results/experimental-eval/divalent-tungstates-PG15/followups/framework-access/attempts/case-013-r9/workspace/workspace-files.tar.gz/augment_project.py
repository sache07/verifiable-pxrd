#!/usr/bin/env python3
"""Add one candidate phase to a converged GSAS-II project and screen it."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_models import cod_path, summary


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    project = G2.G2Project(str(args.base.resolve()), newgpx=str(out / "trial.gpx"))
    hist = project.histogram(0)
    phase_file = args.phase_file.resolve() if args.phase_file else cod_path(args.cod_id)
    source_id = args.cod_id or str(phase_file)
    new_phase = project.add_phase(
        str(phase_file),
        phasename=args.name or f"candidate_{source_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    hap = new_phase.data["Histograms"][hist.name]
    hap["Scale"] = [args.scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    clear_flags(project)
    project.set_Controls("cycles", 12)
    history = []
    project.refine()
    history.append({"stage": "scale", **summary(project)})
    # Cell refinement is attempted only after a candidate has acquired a
    # meaningful positive scale, which prevents absent phases from running to
    # a nonphysical metric tensor.
    weights = [p.get("weight_fraction", 0.0) for p in history[-1]["phases"]]
    if weights[-1] > args.cell_threshold:
        new_phase = project.phase(new_phase.name)
        new_phase.data["General"]["Cell"][0] = True
        project.refine()
        history.append({"stage": "cell", **summary(project)})
    project.save()
    info = summary(project)
    info.update(base=str(args.base), candidate_source=source_id, history=history)
    (out / "summary.json").write_text(json.dumps(info, indent=2) + "\n")
    if not args.quiet:
        print(json.dumps(info, indent=2))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--cod-id")
    source.add_argument("--phase-file", type=Path)
    parser.add_argument("--name")
    parser.add_argument("--scale", type=float, default=0.05)
    parser.add_argument("--cell-threshold", type=float, default=0.003)
    parser.add_argument("--quiet", action="store_true")
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
