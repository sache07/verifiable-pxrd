#!/usr/bin/env python3
"""Build and refine trial GSAS-II models for the supplied powder pattern.

Run with the GSAS-II Python interpreter. This is intentionally kept in the
workspace so that the final refinement can be reproduced and audited.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inputs(pattern: Path, out: Path) -> tuple[Path, Path]:
    x, y = [], []
    with pattern.open(newline="") as stream:
        for row in csv.DictReader(stream):
            x.append(float(row["two_theta_deg"]))
            y.append(float(row["intensity"]))
    x = np.asarray(x)
    y = np.asarray(y)
    sigma = np.sqrt(np.maximum(y, 1.0))
    data_path = out / "pattern.xye"
    np.savetxt(data_path, np.column_stack([x, y, sigma]), fmt="%.8f %.8f %.8f")
    inst_path = out / "instrument.instprm"
    inst_path.write_text(
        "# Trial laboratory Cu K-alpha instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:20.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return data_path, inst_path


def summary(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "Rwp_percent": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) >= 2},
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in sample.items()
            if k in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type"}
        },
        "phases": [],
    }
    masses, scales = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"])
        scale = float(hap["Scale"][0])
        masses.append(mass)
        scales.append(scale)
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass": mass,
                "scale": scale,
                "size": hap["Size"],
                "microstrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    weights = np.asarray(masses) * np.asarray(scales)
    if np.all(weights >= 0) and weights.sum() > 0:
        weights /= weights.sum()
        for row, weight in zip(result["phases"], weights):
            row["weight_fraction"] = float(weight)
    return result


def set_initial_model(project: G2.G2Project, background_terms: int) -> None:
    hist = project.histogram(0)
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.00943322, 99.99442286],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": background_terms,
                "coeffs": [500.0] + [0.0] * (background_terms - 1),
                "refine": False,
            },
        }
    )
    # Put all phase scales in a sensible numerical range and use a moderate
    # initial sample profile. HAP scale times unit-cell mass is proportional
    # to phase mass in GSAS-II.
    initial_scales = [1.0, 1.0, 1.0] + [0.01] * max(0, len(project.phases()) - 3)
    for phase, initial_scale in zip(project.phases(), initial_scales):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [initial_scale, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][1][1] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]


def run(args: argparse.Namespace) -> dict:
    G2.SetPrintLevel("warn")
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    data_path, inst_path = write_inputs(args.pattern.resolve(), out)
    project = G2.G2Project(newgpx=str(out / "trial.gpx"))
    hist = project.add_powder_histogram(str(data_path), str(inst_path), fmthint="xye")
    phase_specs = [
        (args.main, args.main_name),
        (args.pbo, "PbO_massicot"),
        (args.wo3, "WO3"),
    ]
    phase_specs.extend((cod_id, f"extra_{cod_id}") for cod_id in args.extra)
    for cod_id, name in phase_specs:
        project.add_phase(str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF")
    set_initial_model(project, args.background_terms)
    project.save()

    # Stage 1: establish background and independent phase scales.
    project.set_Controls("cycles", 12)
    stages = [
        {"set": {"Background": True, "PhaseFraction": True}},
        {"set": {"Cell": True, "Instrument Parameters": ["Zero"]}},
        {"set": {"Instrument Parameters": ["U", "W", "X", "SH/L"]}},
    ]
    if args.profiles:
        stages.extend(
            [
                {"set": {"Size": {"type": "isotropic", "refine": True}}},
                {"set": {"Mustrain": {"type": "isotropic", "refine": True}}},
            ]
        )
    history = []
    for index, stage in enumerate(stages, 1):
        project.do_refinements([stage])
        state = summary(project)
        state["stage"] = index
        history.append(state)
    project.save()
    info = summary(project)
    info["cod_ids"] = {"main": args.main, "pbo": args.pbo, "wo3": args.wo3}
    info["extra_cod_ids"] = args.extra
    info["history"] = history
    (out / "summary.json").write_text(json.dumps(info, indent=2) + "\n")
    if not args.quiet:
        print(json.dumps(info, indent=2))
    return info


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--main", default="9009811")
    parser.add_argument("--main-name", default="PbWO4_scheelite")
    parser.add_argument("--pbo", default="2310433")
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--background-terms", type=int, default=12)
    parser.add_argument("--extra", action="append", default=[])
    parser.add_argument("--profiles", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
