#!/usr/bin/env python3
"""Screen a uniaxial microstrain direction with other profile terms fixed."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", type=Path, required=True)
    ap.add_argument("--phase", type=int, required=True)
    ap.add_argument("--axis", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--axial-max", type=float, default=32000.0)
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)
    p = G2.G2Project(gpxfile=str(a.base), filename=str(a.out / "strain.gpx"))
    h = p.histogram(0)
    phases = p.phases()
    for key in ("parmFrozen", "parmMinDict", "parmMaxDict"):
        p.data["Controls"]["data"][key] = {} if key != "parmFrozen" else {}
    h.data["Background"][0][1] = False
    for v in h.data["Instrument Parameters"][0].values():
        if isinstance(v, list) and len(v) > 2:
            v[2] = False
    for name in ("Scale", "Shift", "SurfRoughA", "SurfRoughB", "Transparency"):
        if name in h.SampleParameters and isinstance(h.SampleParameters[name], list):
            h.SampleParameters[name][1] = False
    for ph in phases:
        ph.data["General"]["Cell"][0] = False
        hap = ph.data["Histograms"][h.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        for atom in ph.atoms():
            atom.refinement_flags = " "
    axis = [int(x) for x in a.axis.split(",")]
    hap = phases[a.phase].data["Histograms"][h.name]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = 7000.0
    hap["Mustrain"][1][1] = 7000.0
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = axis
    p.index_ids()
    p.set_Controls("parmMin", 300.0, f"{phases[a.phase].id}:{h.id}:Mustrain;i")
    p.set_Controls("parmMax", 8000.0, f"{phases[a.phase].id}:{h.id}:Mustrain;i")
    p.set_Controls("parmMin", 75.0, f"{phases[a.phase].id}:{h.id}:Mustrain;a")
    p.set_Controls("parmMax", a.axial_max, f"{phases[a.phase].id}:{h.id}:Mustrain;a")
    p.set_Controls("cycles", 7)
    G2.SetPrintLevel("warn")
    p.refine(makeBack=False)
    # Recompute/refine after any out-of-bounds parameter is frozen at its limit.
    p.refine(makeBack=False)
    p.save()
    arr = h.data["data"][1]
    y, calc = np.asarray(arr[1]), np.asarray(arr[3])
    w = 1 / np.maximum(y, 1.0)
    rwp = 100 * np.sqrt(np.sum(w * (y - calc) ** 2) / np.sum(w * y**2))
    masses = np.array([ph.data["General"]["Mass"] * ph.data["Histograms"][h.name]["Scale"][0] for ph in phases])
    result = {
        "phase": a.phase,
        "axis": axis,
        "equatorial": hap["Mustrain"][1][0],
        "axial": hap["Mustrain"][1][1],
        "rwp": rwp,
        "fractions": (masses / masses.sum()).tolist(),
    }
    (a.out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
