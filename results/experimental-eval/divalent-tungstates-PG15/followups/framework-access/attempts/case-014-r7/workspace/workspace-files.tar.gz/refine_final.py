#!/usr/bin/env python3
"""Produce a physically constrained final refinement from the selected model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def stats(project, hist, label):
    a = hist.data["data"][1]
    y, calc = np.asarray(a[1], float), np.asarray(a[3], float)
    w = 1 / np.maximum(y, 1.0)
    chi = float(np.sum(w * (y - calc) ** 2))
    masses = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()]
    )
    return {
        "stage": label,
        "rwp_percent": float(100 * np.sqrt(chi / np.sum(w * y**2))),
        "chi_square": chi,
        "fractions": (masses / masses.sum()).tolist(),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--stop-after-profile", action="store_true")
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)
    work = a.out / "working.gpx"
    p = G2.G2Project(gpxfile=str(a.base), filename=str(work))
    h = p.histogram(0)
    phases = p.phases()
    if len(phases) != 3:
        raise ValueError("Expected three phases")
    G2.SetPrintLevel("warn")

    ctrl = p.data["Controls"]["data"]
    ctrl["parmFrozen"] = {}
    ctrl["parmMinDict"] = {}
    ctrl["parmMaxDict"] = {}
    p.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": [], "_Explain": {}}
    p.index_ids()

    # Keep the physically bounded instrument and Uiso values from the selected checkpoint.
    for v in h.data["Instrument Parameters"][0].values():
        if isinstance(v, list) and len(v) > 2:
            v[2] = False
    h.data["Background"][0][1] = True
    h.SampleParameters["Scale"] = [1.0, False]
    for name in ("Shift", "SurfRoughA", "SurfRoughB"):
        h.SampleParameters[name][1] = True
    h.SampleParameters["Transparency"][1] = False

    for ph in phases:
        ph.data["General"]["Cell"][0] = True
        hap = ph.data["Histograms"][h.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        for atom in ph.atoms():
            atom.refinement_flags = " "

    # Main/product and WO3 sizes are constrained by many resolved peaks.
    for ph in phases[:2]:
        hap = ph.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][2][0] = True
        p.set_Controls("parmMin", 0.04, f"{ph.id}:{h.id}:Size;i")
        p.set_Controls("parmMax", 1.5, f"{ph.id}:{h.id}:Size;i")

    # The Sr3WO6 peaks require the allowed uniaxial strain (c axis) and <110> texture.
    sr3 = phases[2].data["Histograms"][h.name]
    sr3["Size"][0] = "isotropic"
    sr3["Size"][1][0] = 1.5
    sr3["Mustrain"][0] = "uniaxial"
    sr3["Mustrain"][1][0] = 5000.0
    sr3["Mustrain"][1][1] = 20000.0
    sr3["Mustrain"][2][0] = False
    sr3["Mustrain"][2][1] = False
    sr3["Mustrain"][3] = [0, 0, 1]
    sr3["Pref.Ori."][0] = "MD"
    sr3["Pref.Ori."][1] = 0.76
    sr3["Pref.Ori."][2] = True
    sr3["Pref.Ori."][3] = [1, 1, 0]

    def limit(var, lo, hi):
        p.set_Controls("parmMin", lo, var)
        p.set_Controls("parmMax", hi, var)

    limit(f":{h.id}:Shift", -800.0, 800.0)
    limit(f":{h.id}:SurfRoughA", 0.05, 0.60)
    limit(f":{h.id}:SurfRoughB", 0.02, 0.50)
    limit(f"{phases[2].id}:{h.id}:MD", 0.70, 1.40)
    for ph in phases:
        limit(f"{ph.id}:{h.id}:Scale", 0.0, 100.0)

    log = []

    def refine(label, cycles=7, repeats=1):
        p.set_Controls("cycles", cycles)
        for _ in range(repeats):
            p.refine(makeBack=False)
        p.save()
        shutil.copy2(work, a.out / f"{label}.gpx")
        row = stats(p, h, label)
        log.append(row)
        print(json.dumps(row))

    refine("01_profile_texture", cycles=7, repeats=2)

    if a.stop_after_profile:
        p.set_Controls("cycles", 0)
        p.refine(makeBack=False)
        p.save()
        shutil.copy2(work, a.out / "final_model.gpx")
        log.append(stats(p, h, "final_recalculation"))
        (a.out / "stages.json").write_text(json.dumps(log, indent=2) + "\n")
        print(json.dumps(log[-1], indent=2))
        return

    # One bounded coordinate step per phase. Bounds apply to GSAS coordinate shifts,
    # limiting each atom to the generator's 0.04--0.05 A mismatch scale.
    def coordinate_step(phase, labels, max_cart_A, label):
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        ctrl["parmFrozen"] = {}
        for i, atom in enumerate(phase.atoms()):
            if atom.label not in labels:
                continue
            atom.refinement_flags = "X"
            # Component cap chosen so the 3-D displacement cannot exceed max_cart_A.
            for axis, length in zip("xyz", lengths):
                delta = max_cart_A / np.sqrt(3) / length
                limit(f"{phase.id}::dA{axis}:{i}", -delta, delta)
        refine(label, cycles=1, repeats=1)
        for atom in phase.atoms():
            atom.refinement_flags = " "
        # Recalculate with the accepted bounded coordinates and no coordinate variables.
        ctrl["parmFrozen"] = {}
        refine(label + "_recalc", cycles=3, repeats=1)

    coordinate_step(phases[0], {"O"}, 0.05, "02_srwo4_coordinates")
    coordinate_step(phases[2], {"Sr1", "O1", "O2", "O3"}, 0.05, "03_sr3wo6_coordinates")
    coordinate_step(phases[1], {atom.label for atom in phases[1].atoms()}, 0.05, "04_wo3_coordinates")

    refine("05_final_refinement", cycles=7, repeats=2)
    # Force calculated arrays to correspond exactly to the saved parameter set.
    p.set_Controls("cycles", 0)
    p.refine(makeBack=False)
    p.save()
    shutil.copy2(work, a.out / "final_model.gpx")
    log.append(stats(p, h, "final_recalculation"))
    (a.out / "stages.json").write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
