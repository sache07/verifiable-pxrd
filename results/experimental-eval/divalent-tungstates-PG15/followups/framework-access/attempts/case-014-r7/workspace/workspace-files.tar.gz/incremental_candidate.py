#!/usr/bin/env python3
"""Add one candidate phase to the stable scheelite-only fit and test its scale."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cid: str) -> Path:
    return COD_ROOT / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def freeze_phase(p, hist):
    p.data["General"]["Cell"][0] = False
    h = p.data["Histograms"][hist.name]
    h["Scale"][1] = False
    h["Size"][2] = [False] * len(h["Size"][2])
    h["Size"][5] = [False] * len(h["Size"][5])
    h["Mustrain"][2] = [False] * len(h["Mustrain"][2])
    h["Mustrain"][5] = [False] * len(h["Mustrain"][5])


def run(cid: str, out: Path, refine_cell: bool, base: Path) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(base), filename=str(out / "candidate.gpx")
    )
    hist = project.histogram(0)
    # Keep the established peak positions/profile fixed while the new phase is admitted.
    hist.data["Background"][0][1] = True
    for v in hist.data["Instrument Parameters"][0].values():
        if isinstance(v, list) and len(v) > 2:
            v[2] = False
    for name in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if name in hist.SampleParameters and isinstance(hist.SampleParameters[name], list):
            hist.SampleParameters[name][1] = False
    for p in project.phases():
        freeze_phase(p, hist)
        p.data["Histograms"][hist.name]["Scale"][1] = True

    source = Path(cid) if cid.endswith(".cif") or "/" in cid else cod_path(cid)
    cand = project.add_phase(
        str(source), phasename=f"candidate_{source.stem}", histograms=[hist], fmthint="CIF"
    )
    freeze_phase(cand, hist)
    hap = cand.data["Histograms"][hist.name]
    hap["Scale"] = [0.5, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.2
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    project.index_ids()
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("parmMin", 0.0, f"{cand.id}:{hist.id}:Scale")
    project.set_Controls("cycles", 5)
    project.refine(makeBack=False)
    scale_stage1 = float(hap["Scale"][0])
    if refine_cell and scale_stage1 > 1e-5:
        cand.set_refinements({"Cell": True})
        project.set_Controls("cycles", 3)
        project.refine(makeBack=False)
        # One phase-specific width term is enough for screening.
        cand.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.2, "refine": True}}, [hist]
        )
        project.set_Controls("parmMin", 0.02, f"{cand.id}:{hist.id}:Size;i")
        project.set_Controls("parmMax", 5.0, f"{cand.id}:{hist.id}:Size;i")
        project.refine(makeBack=False)
    project.save()

    a = hist.data["data"][1]
    x, y, calc = (np.asarray(a[i], float) for i in (0, 1, 3))
    w = 1 / np.maximum(y, 1.0)
    chi = float(np.sum(w * (y - calc) ** 2))
    den = float(np.sum(w * y**2))
    masses = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()]
    )
    fractions = masses / masses.sum()
    result = {
        "candidate": cid,
        "scale_stage1": scale_stage1,
        "rwp_percent": 100 * np.sqrt(chi / den),
        "chi_square": chi,
        "phases": [
            {
                "name": p.name,
                "fraction": float(f),
                "scale": float(p.data["Histograms"][hist.name]["Scale"][0]),
                "cell": p.get_cell(),
            }
            for p, f in zip(project.phases(), fractions)
        ],
    }
    (out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cid")
    ap.add_argument("out", type=Path)
    ap.add_argument("--cell", action="store_true")
    ap.add_argument("--base", type=Path, default=Path(".tmp/screen2_1546036/screen.gpx"))
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    run(args.cid, args.out, args.cell, args.base)


if __name__ == "__main__":
    main()
