#!/usr/bin/env python3
"""Staged constrained refinement for the three-phase Sr-W-O model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def fraction_rows(project, hist):
    masses = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()]
    )
    fractions = masses / masses.sum()
    return [
        {
            "name": p.name,
            "fraction": float(f),
            "scale": float(p.data["Histograms"][hist.name]["Scale"][0]),
            "cell": p.get_cell(),
            "size": float(p.data["Histograms"][hist.name]["Size"][1][0]),
            "mustrain": float(p.data["Histograms"][hist.name]["Mustrain"][1][0]),
            "md_ratio": float(p.data["Histograms"][hist.name]["Pref.Ori."][1]),
            "md_axis": p.data["Histograms"][hist.name]["Pref.Ori."][3],
        }
        for p, f in zip(project.phases(), fractions)
    ]


def metrics(project, hist, label):
    a = hist.data["data"][1]
    x, y, calc = (np.asarray(a[i], float) for i in (0, 1, 3))
    w = 1.0 / np.maximum(y, 1.0)
    chi = float(np.sum(w * (y - calc) ** 2))
    den = float(np.sum(w * y**2))
    inst = hist.data["Instrument Parameters"][0]
    return {
        "stage": label,
        "rwp_percent": 100 * np.sqrt(chi / den),
        "chi_square": chi,
        "gsas_wR_percent": hist.get_wR(),
        "instrument": {k: float(v[1]) for k, v in inst.items() if isinstance(v, list) and len(v) > 1 and isinstance(v[1], (int, float))},
        "sample": {
            k: float(hist.SampleParameters[k][0])
            for k in ("Shift", "SurfRoughA", "SurfRoughB", "Transparency")
        },
        "phases": fraction_rows(project, hist),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--stop-after-surface", action="store_true")
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    work = args.out / "working.gpx"
    project = G2.G2Project(gpxfile=str(args.base), filename=str(work))
    hist = project.histogram(0)
    phases = project.phases()
    if len(phases) != 3:
        raise ValueError("Expected SrWO4, WO3 and Sr3WO6 in that order")
    G2.SetPrintLevel("warn")

    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    project.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": [], "_Explain": {}}
    project.index_ids()

    # Clear all active flags before selecting each staged parameter block.
    hist.data["Background"][0][1] = True
    hist.SampleParameters["Scale"] = [1.0, False]
    for v in hist.data["Instrument Parameters"][0].values():
        if isinstance(v, list) and len(v) > 2:
            v[2] = False
    for name in ("Shift", "SurfRoughA", "SurfRoughB", "Transparency"):
        hist.SampleParameters[name][1] = False
    for p in phases:
        p.data["General"]["Cell"][0] = False
        hap = p.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        for atom in p.atoms():
            atom.refinement_flags = " "

    project.save()
    log = [metrics(project, hist, "start")]

    def bounds(variable, low, high):
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)

    bounds(f":{hist.id}:Shift", -800.0, 800.0)
    for p in phases:
        bounds(f"{p.id}:{hist.id}:Scale", 0.0, 100.0)

    def stage(label, cycles=7, repeats=1):
        project.set_Controls("cycles", cycles)
        for _ in range(repeats):
            project.refine(makeBack=False)
        project.save()
        shutil.copy2(work, args.out / f"{label}.gpx")
        row = metrics(project, hist, label)
        log.append(row)
        print(json.dumps({"stage": label, "rwp": row["rwp_percent"], "fractions": [p["fraction"] for p in row["phases"]]}))

    # Jointly establish the peak positions and specimen displacement.
    for p in phases:
        p.data["General"]["Cell"][0] = True
    hist.SampleParameters["Shift"][1] = True
    stage("01_cells_shift", cycles=8, repeats=2)

    # Instrument Gaussian/asymmetry terms; phase-specific widths remain fixed here.
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1], inst["W"][1], inst["SH/L"][1] = 10.0, 30.0, 0.03
    for name in ("U", "W", "SH/L"):
        inst[name][2] = True
    bounds(f":{hist.id}:U", 0.0, 40.0)
    bounds(f":{hist.id}:W", 2.0, 40.0)
    bounds(f":{hist.id}:SH/L", 0.005, 0.10)
    stage("02_instrument", cycles=8, repeats=2)
    for name in ("U", "W", "SH/L"):
        inst[name][2] = False

    # Phase-specific Lorentzian size and Gaussian microstrain broadening.
    for p in phases:
        hap = p.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Mustrain"][0] = "isotropic"
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
        if hap["Mustrain"][1][0] <= 0:
            hap["Mustrain"][1][0] = 500.0
        bounds(f"{p.id}:{hist.id}:Size;i", 0.04, 1.5)
        bounds(f"{p.id}:{hist.id}:Mustrain;i", 0.0, 8000.0)
    stage("03_phase_profiles", cycles=8, repeats=2)

    # Isotropic displacement parameters are common within each phase in the generator.
    project.index_ids()
    for p in phases:
        atoms = p.atoms()
        for atom in atoms:
            atom.uiso = 0.008
            atom.refinement_flags = "U"
        if len(atoms) > 1:
            project.add_EquivConstr(
                tuple(f"{p.id}::AUiso:{i}" for i in range(len(atoms))), reloadIdx=False
            )
        for i in range(len(atoms)):
            bounds(f"{p.id}::AUiso:{i}", 0.003, 0.020)
    inst["Polariz."][2] = True
    bounds(f":{hist.id}:Polariz.", 0.5, 1.0)
    stage("04_uiso_polarization", cycles=8, repeats=2)

    # Surface roughness is a whole-specimen low-angle intensity correction.
    hist.SampleParameters["SurfRoughA"] = [0.30, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    bounds(f":{hist.id}:SurfRoughA", 0.05, 0.60)
    bounds(f":{hist.id}:SurfRoughB", 0.02, 0.50)
    stage("05_surface_roughness", cycles=8, repeats=2)

    if args.stop_after_surface:
        (args.out / "stages.json").write_text(json.dumps(log, indent=2) + "\n")
        print(json.dumps(log[-1], indent=2))
        return

    # Refine the best-constrained coordinates first: scheelite O and Sr3WO6 framework.
    for atom in phases[0].atoms():
        if atom.element == "O":
            atom.refinement_flags = "XU"
    for atom in phases[2].atoms():
        if atom.label in {"Sr1", "O1", "O2", "O3"}:
            atom.refinement_flags = "XU"
    for p in (phases[0], phases[2]):
        for i, atom in enumerate(p.atoms()):
            if "X" not in atom.refinement_flags:
                continue
            for axis, value in zip("xyz", atom.coordinates):
                bounds(f"{p.id}::A{axis}:{i}", value - 0.025, value + 0.025)
    stage("06_main_intermediate_coordinates", cycles=6, repeats=2)

    # The weaker WO3 phase still carries enough unique peaks for small coordinate shifts.
    for i, atom in enumerate(phases[1].atoms()):
        atom.refinement_flags = "XU"
        for axis, value in zip("xyz", atom.coordinates):
            bounds(f"{phases[1].id}::A{axis}:{i}", value - 0.015, value + 0.015)
    stage("07_wo3_coordinates", cycles=5, repeats=2)

    (args.out / "stages.json").write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
