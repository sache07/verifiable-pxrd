#!/usr/bin/env python3
"""Small GSAS-II batch refinement used to compare candidate phase inventories."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inputs(work: Path) -> tuple[Path, Path]:
    x, y = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1).T
    xye = work / "observed.xye"
    np.savetxt(xye, np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.10g")
    inst = work / "instrument.instprm"
    inst.write_text(
        "#GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def refine(ids: list[str], outdir: Path) -> dict:
    outdir.mkdir(parents=True, exist_ok=True)
    xye, inst = write_inputs(outdir)
    gpx = outdir / "screen.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]

    phases = []
    for cod_id in ids:
        p = project.add_phase(
            str(cod_path(cod_id)), phasename=f"COD_{cod_id}", histograms=[hist], fmthint="CIF"
        )
        phases.append(p)

    x, y = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1).T
    baseline = percentile_filter(y, size=501, percentile=15, mode="nearest")
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    bcoef = np.polynomial.chebyshev.chebfit(t, baseline, 15)
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(bcoef),
                "coeffs": bcoef.tolist(),
                "refine": True,
            },
        }
    )
    for p in phases:
        hap = p.data["Histograms"][hist.name]
        hap["Scale"] = [10.0 / len(phases), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0

    project.set_Controls("cycles", 8)
    project.index_ids()
    project.set_Controls("parmMin", -800.0, f":{hist.id}:Shift")
    project.set_Controls("parmMax", 800.0, f":{hist.id}:Shift")
    project.set_Controls("parmMin", 0.0, f":{hist.id}:U")
    project.set_Controls("parmMin", 0.1, f":{hist.id}:W")
    project.set_Controls("parmMin", 0.001, f":{hist.id}:SH/L")
    project.set_Controls("parmMax", 0.2, f":{hist.id}:SH/L")
    for p in phases:
        project.set_Controls("parmMin", 0.0, f"{p.id}:{hist.id}:Scale")
        project.set_Controls("parmMin", 0.02, f"{p.id}:{hist.id}:Size;i")
        project.set_Controls("parmMax", 5.0, f"{p.id}:{hist.id}:Size;i")
        project.set_Controls("parmMin", 0.0, f"{p.id}:{hist.id}:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, f"{p.id}:{hist.id}:Mustrain;i")
    # Stabilize the absolute and relative scales before adding peak-position terms.
    project.refine(makeBack=False)
    for p in phases:
        p.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine(makeBack=False)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    project.refine(makeBack=False)
    # Freeze the global Gaussian terms before phase-specific strain is introduced.
    for key in ("U", "W", "SH/L"):
        hist.data["Instrument Parameters"][0][key][2] = False
    for p in phases:
        p.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.3, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save()

    arr = hist.data["data"][1]
    xx, obs, calc = (np.asarray(arr[i], float) for i in (0, 1, 3))
    weights = 1.0 / np.maximum(obs, 1.0)
    loss = float(np.sum(weights * (obs - calc) ** 2))
    denom = float(np.sum(weights * obs**2))
    masses = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in phases]
    )
    fractions = masses / masses.sum()
    result = {
        "ids": ids,
        "gpx": str(gpx),
        "rwp_percent": 100 * np.sqrt(loss / denom),
        "gsas_wR_percent": hist.get_wR(),
        "weighted_chi_square": loss,
        "gof": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "instrument": {k: v[1] for k, v in hist.data["Instrument Parameters"][0].items() if isinstance(v, list) and len(v) > 1},
        "sample": hist.SampleParameters,
        "phases": [
            {
                "id": cod_id,
                "fraction": float(frac),
                "scale": float(p.data["Histograms"][hist.name]["Scale"][0]),
                "cell": p.get_cell(),
                "size": p.data["Histograms"][hist.name]["Size"],
                "mustrain": p.data["Histograms"][hist.name]["Mustrain"],
            }
            for cod_id, p, frac in zip(ids, phases, fractions)
        ],
    }
    (outdir / "result.json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    return result


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ids", required=True, help="comma-separated COD identifiers")
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    result = refine(args.ids.split(","), args.out)
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
