#!/usr/bin/env python3
"""Freeze the selected GSAS-II checkpoint and export its atomic phase models."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--project", type=Path, required=True)
    args = parser.parse_args()

    shutil.copy2(args.source, args.project)
    project = G2.G2Project(gpxfile=str(args.project))
    hist = project.histogram(0)

    # Preserve the accepted numerical model, but leave no variables selected for
    # accidental further refinement. The evaluator regenerates the profile from
    # these saved atomic/profile parameters rather than cached calculated arrays.
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False

    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    # Avoid stale shift values or ESDs affecting CIF output. Cell and coordinates
    # have already been committed into each phase's saved data tree.
    project.data["Covariance"]["data"] = {}
    project.save(str(args.project))

    cif_names = ["phase_SrWO4.cif", "phase_WO3.cif", "phase_Sr3WO6.cif"]
    for phase, filename in zip(project.phases(), cif_names):
        phase.export_CIF(filename)

    masses = np.array([
        phase.data["General"]["Mass"]
        * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ])
    summary = {
        "histogram": hist.name,
        "phases": [
            {
                "project_name": phase.name,
                "cif": filename,
                "weight_fraction": float(mass / masses.sum()),
                "cell": phase.get_cell(),
            }
            for phase, filename, mass in zip(project.phases(), cif_names, masses)
        ],
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
