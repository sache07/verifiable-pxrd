#!/usr/bin/env python3
"""Refine heavy-atom positions with physically modest displacement bounds."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histograms()[0]
    raw = np.asarray([
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ])
    return (raw / raw.sum()).tolist()


def activate(project: G2.G2Project) -> None:
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for pid, phase in enumerate(project.phases()):
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{pid}:0:Scale")


def sync(project: G2.G2Project) -> None:
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.save()
    project.refine()
    project.save()


def snapshot(project: G2.G2Project, label: str) -> dict:
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "step": label,
        "Rwp_percent": project.histograms()[0].get_wR(),
        "fractions": fractions(project),
        "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
        "message": cov.get("Rvals", {}).get("msg"),
        "atoms": [[
            {"label": a.label, "element": a.element, "coordinates": list(a.coordinates), "uiso": a.uiso}
            for a in phase.atoms()
        ] for phase in project.phases()],
    }


def stage(project: G2.G2Project, outdir: Path, history: list[dict], label: str) -> None:
    project.save()
    project.refine()
    project.save()
    project.set_Frozen()
    project.refine()
    history.append(snapshot(project, label))
    project.save(str(outdir / f"{len(history)-1:02d}_{label}.gpx"))
    project.save(str(outdir / "working.gpx"))
    print(label, history[-1]["Rwp_percent"], history[-1]["fractions"], flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--fractional-bound", type=float, default=0.010)
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    args.out.mkdir(parents=True, exist_ok=True)
    working = args.out / "working.gpx"
    shutil.copy2(args.source.resolve(), working)
    project = G2.G2Project(gpxfile=str(working))
    sync(project)
    history = [snapshot(project, "synchronized")]

    for pid, phase in enumerate(project.phases()):
        activate(project)
        for atom_index, atom in enumerate(phase.atoms()):
            if atom.element == "O":
                continue
            atom.refinement_flags = "X"
            for axis in "xyz":
                variable = f"{pid}::dA{axis}:{atom_index}"
                project.set_Controls("parmMin", -args.fractional_bound, variable=variable)
                project.set_Controls("parmMax", args.fractional_bound, variable=variable)
        stage(project, args.out, history, f"restrained_heavy_phase_{pid}")

    # Use the plausible per-phase values inferred from a preliminary common-U
    # refinement, but impose them exactly and inside the generator's range.
    trial_uiso = [0.00635, 0.0121, 0.0200, 0.0030, 0.0200]
    if len(project.phases()) != len(trial_uiso):
        trial_uiso = [0.005] * len(project.phases())
    for phase, value in zip(project.phases(), trial_uiso):
        for atom in phase.atoms():
            atom.uiso = value
    sync(project)
    activate(project)
    stage(project, args.out, history, "fixed_common_uiso")

    sync(project)
    history.append(snapshot(project, "final_synchronized"))
    (args.out / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print("final", history[-1]["Rwp_percent"], history[-1]["fractions"], flush=True)


if __name__ == "__main__":
    main()
