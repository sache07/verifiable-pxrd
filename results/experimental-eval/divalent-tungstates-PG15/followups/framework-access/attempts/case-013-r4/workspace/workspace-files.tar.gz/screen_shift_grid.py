#!/usr/bin/env python3
"""Profile a fixed specimen-displacement grid while refining zero and cells."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from screen_effects import clear_flags


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histograms()[0]
    raw = np.asarray([
        phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ])
    return (raw / raw.sum()).tolist()


def activate(project: G2.G2Project) -> None:
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    hist.data["Instrument Parameters"][0]["Zero"][2] = True
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    for pid, phase in enumerate(project.phases()):
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        phase.data["General"]["Cell"][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{pid}:0:Scale")
        for j, value in enumerate(G2lat.cell2A(phase.data["General"]["Cell"][1:7])):
            low, high = (-0.001, 0.001) if abs(value) < 1e-12 else sorted((0.97 * value, 1.03 * value))
            project.set_Controls("parmMin", low, variable=f"{pid}::A{j}")
            project.set_Controls("parmMax", high, variable=f"{pid}::A{j}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--shift", type=float, action="append", required=True)
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    args.out.mkdir(parents=True, exist_ok=True)
    rows = []
    for shift in args.shift:
        destination = args.out / f"shift_{shift:+07.1f}.gpx"
        shutil.copy2(args.source.resolve(), destination)
        project = G2.G2Project(gpxfile=str(destination))
        hist = project.histograms()[0]
        hist.data["Sample Parameters"]["Shift"] = [float(shift), False]
        activate(project)
        try:
            project.save()
            project.refine()
            project.save()
            project.set_Frozen()
            project.refine()
            row = {
                "shift_um": shift,
                "zero_deg": hist.data["Instrument Parameters"][0]["Zero"][1],
                "Rwp_percent": hist.get_wR(),
                "fractions": fractions(project),
                "project": str(destination),
                "cells": [p.data["General"]["Cell"][1:8] for p in project.phases()],
            }
        except Exception as exc:
            row = {"shift_um": shift, "error": repr(exc), "Rwp_percent": 1e9}
        rows.append(row)
        (args.out / "results_partial.json").write_text(json.dumps(rows, indent=2) + "\n")
        print(shift, row.get("zero_deg"), row.get("Rwp_percent"), flush=True)
    rows.sort(key=lambda row: row.get("Rwp_percent", 1e9))
    (args.out / "results.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
