#!/usr/bin/env python3
"""Refine one March-Dollase ratio for each supported phase/axis pair."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags


AXES = [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histograms()[0]
    raw = np.asarray([
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ])
    return (raw / raw.sum()).tolist()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase", type=int, action="append")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    args.out.mkdir(parents=True, exist_ok=True)
    rows = []
    nphases = len(G2.G2Project(gpxfile=str(args.source.resolve())).phases())
    phase_ids = args.phase if args.phase is not None else list(range(nphases))
    for pid in phase_ids:
        for axis in AXES:
            tag = f"p{pid}_{axis[0]}{axis[1]}{axis[2]}"
            destination = args.out / f"{tag}.gpx"
            shutil.copy2(args.source.resolve(), destination)
            project = G2.G2Project(gpxfile=str(destination))
            clear_flags(project)
            project.set_Frozen()
            project.set_Controls("cycles", 10)
            hist = project.histograms()[0]
            hist.data["Background"][0][1] = True
            for phase_index, phase in enumerate(project.phases()):
                phase.data["Histograms"][hist.name]["Scale"][1] = True
                project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Scale")
                project.set_Controls("parmMax", 100.0, variable=f"{phase_index}:0:Scale")
            hap = project.phases()[pid].data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = axis
            project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
            try:
                project.save()
                project.refine()
                project.save()
                project.set_Frozen()
                project.refine()
                row = {
                    "phase": pid,
                    "phase_name": project.phases()[pid].name,
                    "axis": axis,
                    "ratio": project.phases()[pid].data["Histograms"][hist.name]["Pref.Ori."][1],
                    "Rwp_percent": hist.get_wR(),
                    "fractions": fractions(project),
                    "project": str(destination),
                }
            except Exception as exc:
                row = {"phase": pid, "axis": axis, "error": repr(exc), "Rwp_percent": 1e9}
            rows.append(row)
            (args.out / "results_partial.json").write_text(json.dumps(rows, indent=2) + "\n")
            print(tag, row.get("ratio"), row.get("Rwp_percent"), flush=True)
    rows.sort(key=lambda row: row.get("Rwp_percent", 1e9))
    (args.out / "results.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows[:10], indent=2))


if __name__ == "__main__":
    main()
