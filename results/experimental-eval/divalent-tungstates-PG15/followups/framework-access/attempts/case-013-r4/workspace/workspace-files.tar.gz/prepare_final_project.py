#!/usr/bin/env python3
"""Freeze the selected model and export phase CIFs from the same project."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags


EXPORTS = [
    "phase_PbWO4_scheelite.cif",
    "phase_WO3_monoclinic.cif",
    "phase_PbO_massicot.cif",
    "phase_Pb2WO5_intermediate.cif",
    "phase_Pb3WO6_provisional.cif",
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, default=Path("."))
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    args.out.mkdir(parents=True, exist_ok=True)
    destination = args.out / "final.gpx"
    shutil.copy2(args.source.resolve(), destination)
    project = G2.G2Project(gpxfile=str(destination))
    if len(project.phases()) != len(EXPORTS):
        raise ValueError(f"Expected {len(EXPORTS)} phases, found {len(project.phases())}")
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.save()
    project.refine()
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.save()

    hist = project.histograms()[0]
    masses = np.asarray([
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ])
    fractions = masses / masses.sum()
    rows = []
    for phase, filename, fraction in zip(project.phases(), EXPORTS, fractions):
        phase.export_CIF(str((args.out / filename).resolve()))
        rows.append({"project_phase": phase.name, "cif_path": filename, "weight_fraction": float(fraction)})
    (args.out / ".tmp_final_project_summary.json").write_text(json.dumps({
        "histogram": hist.name,
        "native_Rwp_percent": hist.get_wR(),
        "phases": rows,
    }, indent=2) + "\n")
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
