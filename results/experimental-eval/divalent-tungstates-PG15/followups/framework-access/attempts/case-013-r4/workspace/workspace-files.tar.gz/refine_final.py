#!/usr/bin/env python3
"""Staged GSAS-II Rietveld refinement for the selected Pb-W-O inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
REGISTERED = ROOT / ".tmp/registered"


def write_instrument(path: Path) -> None:
    path.write_text(
        "# GSAS-II Cu Kalpha laboratory instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.20;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def initial_background(ncoeff: int) -> list[float]:
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    baseline = percentile_filter(y, percentile=10, size=501, mode="nearest")
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, baseline, ncoeff - 1).tolist()


def phase_weight_fractions(project: G2.G2Project) -> list[float]:
    hist = project.histograms()[0]
    raw = np.asarray(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()
        ],
        dtype=float,
    )
    return (raw / raw.sum()).tolist()


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "step": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "vary_count": len(cov.get("varyList", [])),
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
            if key in inst
        },
        "sample": {
            key: sample[key][0]
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "weight_fractions": phase_weight_fractions(project),
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.data["General"]["Cell"][1:8],
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": list(atom.coordinates),
                        "occupancy": atom.occupancy,
                        "uiso": atom.uiso,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    return result


def set_limit(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def build_project(
    outdir: Path, main_id: str, wo3_id: str, pbo_id: str, extras: list[str]
) -> G2.G2Project:
    outdir.mkdir(parents=True, exist_ok=True)
    instrument = outdir / "instrument.instprm"
    write_instrument(instrument)
    project = G2.G2Project(newgpx=str(outdir / "working.gpx"))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"), str(instrument), fmthint="comma"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-700.0, False]
    hist.set_refinements(
        {
            "Limits": [10.00943322, 99.99442286],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 15,
                "coeffs": initial_background(15),
                "refine": False,
            },
        }
    )
    ids = [main_id, wo3_id, pbo_id, *extras]
    names = ["Pb7W8O28.8", "WO3", "PbO_massicot", *[f"extra_{v}" for v in extras]]
    if extras:
        initial_fractions = [0.70, 0.10, 0.10] + [0.10 / len(extras)] * len(extras)
    else:
        initial_fractions = [0.79, 0.11, 0.10]
    for cod_id, name, fraction in zip(ids, names, initial_fractions):
        phase = project.add_phase(
            str(REGISTERED / f"{cod_id}.cif"),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 * fraction / phase.data["General"]["Mass"], False]
        phase.setSampleProfile(hist, "size", "isotropic", 0.35)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 800.0)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]

    project.set_Controls("cycles", 12)
    project.save()
    limits = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
    }
    for variable, bounds in limits.items():
        set_limit(project, variable, *bounds)
    for pid in range(len(ids)):
        set_limit(project, f"{pid}:0:Scale", 0.0, 100.0)
        set_limit(project, f"{pid}:0:Size;i", 0.04, 1.5)
        set_limit(project, f"{pid}:0:Mustrain;i", 0.0, 8000.0)
        set_limit(project, f"{pid}:0:MD", 0.7, 1.4)
        set_limit(project, f"{pid}::AUiso:*", 0.003, 0.020)
        phase = project.phases()[pid]
        cell = phase.data["General"]["Cell"][1:7]
        for j, value in enumerate(G2lat.cell2A(cell)):
            if abs(value) < 1e-10:
                low, high = -0.001, 0.001
            else:
                low, high = sorted((0.96 * value, 1.04 * value))
            set_limit(project, f"{pid}::A{j}", low, high)
    return project


def refine_step(project: G2.G2Project, history: list[dict], label: str, recipe: dict | None = None) -> None:
    if recipe is None:
        recipe = {}
    project.set_Frozen()
    project.do_refinements([recipe])
    history.append(snapshot(project, label))
    print(label, history[-1]["Rwp_percent"], history[-1]["weight_fractions"], flush=True)


def set_atom_flags(project: G2.G2Project, mode: str) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            if mode == "heavy":
                atom.refinement_flags = "X" if atom.element != "O" else ""
            elif mode == "all_coordinates":
                atom.refinement_flags = "X"
            elif mode == "coordinates_uiso":
                atom.refinement_flags = "XU"
            else:
                raise ValueError(mode)


def add_common_uiso_constraints(project: G2.G2Project) -> None:
    project.index_ids()
    for pid, phase in enumerate(project.phases()):
        variables = [f"{pid}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)


def export_profile(project: G2.G2Project, path: Path) -> None:
    data = project.histograms()[0].data["data"][1]
    x, observed, _, calculated, background, _ = data
    np.savetxt(
        path,
        np.column_stack([x, observed, calculated, background, observed - calculated]),
        delimiter=",",
        header="two_theta,observed,calculated,background,difference",
        comments="",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=".tmp/final_refinement")
    parser.add_argument("--main", default="9016035")
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--pbo", default="2310433")
    parser.add_argument("--extra", action="append", default=[])
    parser.add_argument("--extra-po-axis", default=None, help="h,k,l for the final extra phase")
    parser.add_argument("--extra-po-ratio", type=float, default=1.0)
    parser.add_argument("--extra-po-refine", action="store_true")
    parser.add_argument("--coordinates", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    outdir = ROOT / args.out
    project = build_project(outdir, args.main, args.wo3, args.pbo, args.extra)
    if args.extra_po_axis is not None:
        if not args.extra:
            raise ValueError("--extra-po-axis requires --extra")
        axis = [int(v) for v in args.extra_po_axis.split(",")]
        if len(axis) != 3 or not any(axis):
            raise ValueError("preferred-orientation axis must be three nonzero-index integers")
        hap = project.phases()[-1].data["Histograms"][project.histograms()[0].name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = args.extra_po_ratio
        hap["Pref.Ori."][2] = args.extra_po_refine
        hap["Pref.Ori."][3] = axis
    history = [snapshot(project, "initial")]

    refine_step(
        project,
        history,
        "scales_background",
        {"set": {"Background": True, "PhaseFraction": True}},
    )
    cell_recipe = {"set": {"Cell": True}}
    if args.extra:
        # Candidate-screen phases begin at low scale. Keep their parent cells
        # fixed until their presence is established; otherwise a near-zero
        # phase can make the cell normal matrix singular.
        cell_recipe["phases"] = ["Pb7W8O28.8", "WO3", "PbO_massicot"]
    refine_step(project, history, "cells", cell_recipe)
    refine_step(
        project,
        history,
        "zero_shift",
        {"set": {"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]}},
    )
    refine_step(
        project,
        history,
        "instrument_profile",
        {"set": {"Instrument Parameters": ["U", "W", "X", "SH/L"]}},
    )
    refine_step(
        project,
        history,
        "isotropic_phase_profiles",
        {
            "set": {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        },
    )
    refine_step(
        project,
        history,
        "polarization",
        {"set": {"Instrument Parameters": ["Polariz."]}},
    )
    if args.coordinates:
        set_atom_flags(project, "heavy")
        refine_step(project, history, "heavy_atom_coordinates")
        set_atom_flags(project, "all_coordinates")
        refine_step(project, history, "all_coordinates")
        add_common_uiso_constraints(project)
        set_atom_flags(project, "coordinates_uiso")
        refine_step(project, history, "common_phase_uiso")

    project.save(str(outdir / "working.gpx"))
    export_profile(project, outdir / "fit.csv")
    (outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
