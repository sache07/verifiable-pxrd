#!/usr/bin/env python3
"""Combine selected preferred-orientation models and reoptimize scales."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histograms()[0]
    raw = np.asarray([p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()])
    return (raw / raw.sum()).tolist()


def parse_po(value: str) -> tuple[int, list[int], float]:
    pid_text, axis_text, ratio_text = value.split(":")
    axis = [int(v) for v in axis_text.split(",")]
    if len(axis) != 3:
        raise ValueError(value)
    return int(pid_text), axis, float(ratio_text)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--po", action="append", default=[])
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    args.out.mkdir(parents=True, exist_ok=True)
    destination = args.out / "working.gpx"
    shutil.copy2(args.source.resolve(), destination)
    project = G2.G2Project(gpxfile=str(destination))
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for pid, phase in enumerate(project.phases()):
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{pid}:0:Scale")
    selected = []
    for value in args.po:
        pid, axis, ratio = parse_po(value)
        hap = project.phases()[pid].data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = ratio
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
        selected.append({"phase": pid, "axis": axis})
    project.save()
    project.refine()
    project.save()
    project.set_Frozen()
    project.refine()
    result = {
        "Rwp_percent": hist.get_wR(),
        "fractions": fractions(project),
        "selected": [
            {**item, "ratio": project.phases()[item["phase"]].data["Histograms"][hist.name]["Pref.Ori."][1]}
            for item in selected
        ],
    }
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.save()
    project.refine()
    project.save()
    result["fresh_Rwp_percent"] = hist.get_wR()
    (args.out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
