#!/usr/bin/env python3
"""Stable staged refinement for PbWO4/WO3/PbO/Pb2WO5."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from screen_effects import clear_flags


PHASE_NAMES = ["PbWO4_scheelite", "WO3_monoclinic", "PbO_massicot", "Pb2WO5_intermediate"]


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histograms()[0]
    raw = np.asarray([
        phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ])
    return (raw / raw.sum()).tolist()


def rename_phases(project: G2.G2Project) -> None:
    old_names = [phase.name for phase in project.phases()]
    if len(old_names) > len(PHASE_NAMES) and old_names[:len(PHASE_NAMES)] == PHASE_NAMES:
        return
    if len(old_names) != len(PHASE_NAMES):
        raise ValueError(f"Expected the selected phase inventory, found {old_names}")
    phase_tree = next(item for item in project.names if item[0] == "Phases")
    for index, (old, new) in enumerate(zip(old_names, PHASE_NAMES), start=1):
        if old == new:
            continue
        data = project.data["Phases"].pop(old)
        data["General"]["Name"] = new
        project.data["Phases"][new] = data
        phase_tree[index] = new
        for hist in project.histograms():
            reflection_lists = hist.data.get("Reflection Lists", {})
            if old in reflection_lists:
                reflection_lists[new] = reflection_lists.pop(old)


def synchronize(project: G2.G2Project) -> None:
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.save()
    project.refine()
    project.save()


def activate_scales_background(project: G2.G2Project) -> None:
    clear_flags(project)
    project.set_Frozen()
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    project.index_ids()
    for pid, phase in enumerate(project.phases()):
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{pid}:0:Scale")
    project.set_Controls("cycles", 12)


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    inst = hist.data["Instrument Parameters"][0]
    return {
        "step": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
        "message": cov.get("Rvals", {}).get("msg"),
        "fractions": fractions(project),
        "instrument": {k: inst[k][1] for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]},
        "sample": {k: v[0] for k, v in hist.data["Sample Parameters"].items() if isinstance(v, list)},
        "phases": [
            {
                "name": phase.name,
                "cell": phase.data["General"]["Cell"][1:8],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
                "po": phase.data["Histograms"][hist.name]["Pref.Ori."],
                "atoms": [
                    {"label": a.label, "element": a.element, "coordinates": list(a.coordinates), "uiso": a.uiso}
                    for a in phase.atoms()
                ],
            }
            for phase in project.phases()
        ],
    }


def run_stage(project: G2.G2Project, history: list[dict], label: str) -> None:
    project.save()
    project.refine()
    project.save()
    project.set_Frozen()
    project.refine()
    history.append(snapshot(project, label))
    print(label, history[-1]["Rwp_percent"], history[-1]["fractions"], flush=True)


def set_cell_limits(project: G2.G2Project, relative: float = 0.03) -> None:
    for pid, phase in enumerate(project.phases()):
        for j, value in enumerate(G2lat.cell2A(phase.data["General"]["Cell"][1:7])):
            low, high = (-0.001, 0.001) if abs(value) < 1e-12 else sorted(((1-relative)*value, (1+relative)*value))
            project.set_Controls("parmMin", low, variable=f"{pid}::A{j}")
            project.set_Controls("parmMax", high, variable=f"{pid}::A{j}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--coordinates", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    args.out.mkdir(parents=True, exist_ok=True)
    destination = args.out / "working.gpx"
    shutil.copy2(args.source.resolve(), destination)
    project = G2.G2Project(gpxfile=str(destination))
    rename_phases(project)
    synchronize(project)
    history = [snapshot(project, "synchronized")]

    activate_scales_background(project)
    run_stage(project, history, "scales_background")

    activate_scales_background(project)
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    set_cell_limits(project)
    run_stage(project, history, "all_cells")

    # Zero offset is identifiable enough when specimen displacement is held
    # fixed. Simultaneous Zero/Shift refinement is nearly singular here.
    activate_scales_background(project)
    hist = project.histograms()[0]
    hist.data["Instrument Parameters"][0]["Zero"][2] = True
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    run_stage(project, history, "zero_offset")

    activate_scales_background(project)
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    set_cell_limits(project, relative=0.015)
    run_stage(project, history, "cells_after_zero")

    hist = project.histograms()[0]
    for pid, phase in enumerate(project.phases()):
        activate_scales_background(project)
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        run_stage(project, history, f"profile_phase_{pid}")

    activate_scales_background(project)
    inst = hist.data["Instrument Parameters"][0]
    for key in ["U", "W", "X"]:
        inst[key][2] = True
    for variable, low, high in [(":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0), (":0:X", 0.1, 6.0)]:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    run_stage(project, history, "instrument_width")

    activate_scales_background(project)
    inst["SH/L"][2] = True
    project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.10, variable=":0:SH/L")
    run_stage(project, history, "axial_divergence")

    if args.coordinates:
        for pid, phase in enumerate(project.phases()):
            activate_scales_background(project)
            for atom in phase.atoms():
                atom.refinement_flags = "X" if atom.element != "O" else ""
            run_stage(project, history, f"heavy_coordinates_phase_{pid}")
            activate_scales_background(project)
            for atom in phase.atoms():
                atom.refinement_flags = "X"
            run_stage(project, history, f"all_coordinates_phase_{pid}")

    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.save()
    project.refine()
    project.save()
    history.append(snapshot(project, "final_synchronized"))
    (args.out / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print("final", history[-1]["Rwp_percent"], history[-1]["fractions"], flush=True)


if __name__ == "__main__":
    main()
