#!/usr/bin/env python3
"""Refine a substituted intermediate model in a clean, synchronized project."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from screen_effects import clear_flags


def phase_fractions(project: G2.G2Project) -> list[float]:
    hist = project.histograms()[0]
    raw = np.asarray([
        phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ])
    return (raw / raw.sum()).tolist()


def sync(project: G2.G2Project) -> None:
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.save()
    project.refine()
    project.save()


def set_scales_background(project: G2.G2Project) -> None:
    clear_flags(project)
    project.set_Frozen()
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    project.index_ids()
    for pid, phase in enumerate(project.phases()):
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{pid}:0:Scale")
    project.set_Controls("cycles", 12)


def snapshot(project: G2.G2Project, label: str) -> dict:
    return {
        "step": label,
        "Rwp_percent": project.histograms()[0].get_wR(),
        "fractions": phase_fractions(project),
        "phase_names": [p.name for p in project.phases()],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("--mode", choices=["replace_pbo", "add"], required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--name", default="Pb2WO5_intermediate")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    args.out.mkdir(parents=True, exist_ok=True)
    destination = args.out / "working.gpx"
    shutil.copy2(args.source.resolve(), destination)
    project = G2.G2Project(gpxfile=str(destination))
    sync(project)
    if args.mode == "replace_pbo":
        name = project.phases()[2].name
        del project.data["Phases"][name]
        for item in project.names:
            if item[0] == "Phases" and name in item:
                item.remove(name)
        target_fraction = 0.20
    else:
        target_fraction = 0.08
    hist = project.histograms()[0]
    phase = project.add_phase(
        str(args.candidate.resolve()), phasename=args.name,
        histograms=[hist], fmthint="CIF",
    )
    existing_raw = sum(
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()[:-1]
    )
    phase.data["Histograms"][hist.name]["Scale"] = [
        existing_raw * target_fraction / (1 - target_fraction) / phase.data["General"]["Mass"],
        False,
    ]
    phase.setSampleProfile(hist, "size", "isotropic", 0.35)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0)
    project.save()
    sync(project)
    history = [snapshot(project, "synchronized")]

    set_scales_background(project)
    project.save()
    project.refine()
    project.save()
    project.refine()
    history.append(snapshot(project, "scales_background"))

    set_scales_background(project)
    phase = project.phase(args.name)
    phase.data["General"]["Cell"][0] = True
    pid = [p.name for p in project.phases()].index(args.name)
    for j, value in enumerate(G2lat.cell2A(phase.data["General"]["Cell"][1:7])):
        low, high = (-0.001, 0.001) if abs(value) < 1e-12 else sorted((0.96 * value, 1.04 * value))
        project.set_Controls("parmMin", low, variable=f"{pid}::A{j}")
        project.set_Controls("parmMax", high, variable=f"{pid}::A{j}")
    project.save()
    project.refine()
    project.save()
    project.refine()
    history.append(snapshot(project, "candidate_cell"))

    set_scales_background(project)
    phase = project.phase(args.name)
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][2][0] = True
    hap["Mustrain"][2][0] = True
    project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
    project.save()
    project.refine()
    project.save()
    project.refine()
    history.append(snapshot(project, "candidate_profile"))
    project.save()
    (args.out / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print(json.dumps(history, indent=2))


if __name__ == "__main__":
    main()
