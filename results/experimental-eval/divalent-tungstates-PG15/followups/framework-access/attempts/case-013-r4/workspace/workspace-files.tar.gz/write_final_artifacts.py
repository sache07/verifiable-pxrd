#!/usr/bin/env python3
"""Write fit.csv and result.json from the evaluator-style replay of final.gpx."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY_DIR = ROOT / ".tmp/final_verify_repaired/final"

PHASE_METADATA = [
    {
        "name": "PbWO4 (scheelite)",
        "formula": "PbWO4",
        "space_group": "I 41/a",
        "cif_path": "phase_PbWO4_scheelite.cif",
        "model_status": "refined published structure",
    },
    {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif_path": "phase_WO3_monoclinic.cif",
        "model_status": "refined published structure",
    },
    {
        "name": "PbO (massicot)",
        "formula": "PbO",
        "space_group": "Pbcm",
        "cif_path": "phase_PbO_massicot.cif",
        "model_status": "refined published structure",
    },
    {
        "name": "Pb2WO5 intermediate",
        "formula": "Pb2WO5",
        "space_group": "C 2/m",
        "cif_path": "phase_Pb2WO5_intermediate.cif",
        "model_status": "analogue-derived framework; oxygen positions uncertain",
    },
    {
        "name": "Pb3WO6 intermediate (provisional)",
        "formula": "Pb3WO6",
        "space_group": "P 21/m",
        "cif_path": "phase_Pb3WO6_provisional.cif",
        "model_status": "provisional analogue-derived scattering model; exact atomic structure not reliable",
    },
]


def main() -> None:
    replay = json.loads((REPLAY_DIR / "replay.json").read_text())
    if replay.get("status") != "replayed":
        raise RuntimeError(replay)
    with np.load(REPLAY_DIR / "prediction.npz") as values:
        x = values["x"]
        observed = values["observed"]
        calculated = values["predicted"]
        background = values["background"]
    public = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    if not np.array_equal(x, public[:, 0]) or not np.array_equal(observed, public[:, 1]):
        raise ValueError("Replay grid or observations differ from the supplied pattern")

    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, background, difference]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference_observed_minus_calculated",
        comments="",
        fmt=["%.17g", "%.17g", "%.17g", "%.17g", "%.17g"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    weighted_ss = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100 * np.sqrt(weighted_ss / denominator))
    rp = float(100 * np.sum(np.abs(difference)) / np.sum(observed))
    rexp0 = float(100 * np.sqrt(len(observed) / denominator))

    if len(replay["phases"]) != len(PHASE_METADATA):
        raise ValueError("Unexpected phase count in final replay")
    raw_fractions = np.asarray([row["weight_fraction"] for row in replay["phases"]], dtype=float)
    fractions = raw_fractions / raw_fractions.sum()
    phases = []
    for metadata, project_phase, fraction in zip(PHASE_METADATA, replay["phases"], fractions):
        if not (ROOT / metadata["cif_path"]).is_file():
            raise FileNotFoundError(metadata["cif_path"])
        phases.append({
            **metadata,
            "project_phase_name": project_phase["name"],
            "weight_fraction": float(fraction),
            "weight_percent": float(100 * fraction),
        })

    result = {
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "weighted_chi_square": weighted_ss,
            "counting_statistical_Rexp_percent_no_parameter_correction": rexp0,
            "Rwp_over_counting_Rexp": rwp / rexp0,
            "mean_absolute_error_counts": float(np.mean(np.abs(difference))),
            "root_mean_square_error_counts": float(np.sqrt(np.mean(difference**2))),
            "n_points": int(len(observed)),
            "weighting": "1/max(observed_counts,1)",
            "difference_convention": "observed-calculated",
        },
        "refinement_histogram": replay["histogram"],
        "project_path": "final.gpx",
        "fit_csv_path": "fit.csv",
        "fraction_basis": "normalized over the five modeled crystalline phases; amorphous material not quantified",
        "profile_source": "fresh atomic forward replay of final.gpx; cached calculated arrays not used",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
