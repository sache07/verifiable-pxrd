#!/usr/bin/env python3
"""Normalize selected COD oxide models using the synthetic-source convention."""

from __future__ import annotations

import argparse
import sys
import warnings
from pathlib import Path


# Keep this explicit: these are all filtered-COD entries in O-Pb-W, O-W and
# O-Pb as listed in the frozen public index, not an outcome-selected subset.
CANDIDATE_IDS = [
    "1527935", "9009811", "5910060", "9007617", "9016035",
    "1001358", "1529777", "1528166", "1538315", "1538317", "2107065",
    "1004057", "1010618", "1521532", "1521533", "1523082", "1528915",
    "1548686", "1563541", "2311041", "2101049", "2101050", "2106293",
    "2107312", "5910153", "9014468",
    "1010382", "9012700", "1531016", "1533609", "2310433", "1537983",
    "9012124", "2311012", "9003043", "9013442", "9005760", "9007543",
    "9017012",
]

COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    from pymatgen.io.cif import CifParser

    runtime = Path(__file__).resolve().parent / "learned/divalent-tungstates/runtime"
    sys.path.insert(0, str(runtime))
    from models import write_synthetic_model

    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=Path(".tmp/all_registered"))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    for cod_id in CANDIDATE_IDS:
        output = args.out / f"{cod_id}.cif"
        if output.is_file():
            continue
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structures = CifParser(
                cod_path(cod_id), occupancy_tolerance=1.0,
                site_tolerance=1e-5, frac_tolerance=0,
            ).parse_structures(primitive=False, on_error="raise")
        if len(structures) != 1:
            raise ValueError(f"{cod_id}: expected one structure, got {len(structures)}")
        write_synthetic_model(structures[0], output)
        print(cod_id, structures[0].composition.reduced_formula, len(structures[0]))


if __name__ == "__main__":
    main()
