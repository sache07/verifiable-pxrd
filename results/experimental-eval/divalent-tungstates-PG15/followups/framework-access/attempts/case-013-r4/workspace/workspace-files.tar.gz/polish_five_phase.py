#!/usr/bin/env python3
"""Final staged polish of the selected five-phase GSAS-II model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from screen_effects import clear_flags


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histograms()[0]
    raw = np.asarray([
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ])
    return (raw / raw.sum()).tolist()


def snapshot(project: G2.G2Project, step: str) -> dict:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "step": step,
        "Rwp_percent": hist.get_wR(),
        "fractions": fractions(project),
        "zero_deg": hist.data["Instrument Parameters"][0]["Zero"][1],
        "shift_um": hist.data["Sample Parameters"]["Shift"][0],
        "instrument": {k: hist.data["Instrument Parameters"][0][k][1] for k in ["U", "W", "X", "SH/L", "Polariz."]},
        "surface_roughness": {k: hist.data["Sample Parameters"][k][0] for k in ["SurfRoughA", "SurfRoughB"]},
        "cells": [p.data["General"]["Cell"][1:8] for p in project.phases()],
        "profiles": [{
            "name": p.name,
            "size": p.data["Histograms"][hist.name]["Size"],
            "mustrain": p.data["Histograms"][hist.name]["Mustrain"],
            "po": p.data["Histograms"][hist.name]["Pref.Ori."],
        } for p in project.phases()],
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
        "message": cov.get("Rvals", {}).get("msg"),
    }


def base(project: G2.G2Project, cycles: int = 12) -> None:
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for pid, phase in enumerate(project.phases()):
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{pid}:0:Scale")


def add_cells_zero(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.data["Instrument Parameters"][0]["Zero"][2] = True
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    for pid, phase in enumerate(project.phases()):
        phase.data["General"]["Cell"][0] = True
        for j, value in enumerate(G2lat.cell2A(phase.data["General"]["Cell"][1:7])):
            low, high = (-0.001, 0.001) if abs(value) < 1e-12 else sorted((0.99 * value, 1.01 * value))
            project.set_Controls("parmMin", low, variable=f"{pid}::A{j}")
            project.set_Controls("parmMax", high, variable=f"{pid}::A{j}")


def run(project: G2.G2Project, out: Path, history: list[dict], step: str, repeats: int = 2) -> None:
    for _ in range(repeats):
        project.save()
        project.refine()
        project.set_Frozen()
    project.save()
    history.append(snapshot(project, step))
    project.save(str(out / f"{len(history)-1:02d}_{step}.gpx"))
    project.save(str(out / "working.gpx"))
    print(step, history[-1]["Rwp_percent"], history[-1]["fractions"], flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    args.out.mkdir(parents=True, exist_ok=True)
    working = args.out / "working.gpx"
    shutil.copy2(args.source.resolve(), working)
    project = G2.G2Project(gpxfile=str(working))
    history = [snapshot(project, "start")]

    base(project)
    add_cells_zero(project)
    run(project, args.out, history, "cells_zero")

    hist = project.histograms()[0]
    for pid, phase in enumerate(project.phases()):
        base(project)
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        run(project, args.out, history, f"profile_phase_{pid}")

    base(project)
    inst = hist.data["Instrument Parameters"][0]
    for key, low, high in [("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0)]:
        inst[key][2] = True
        project.set_Controls("parmMin", low, variable=f":0:{key}")
        project.set_Controls("parmMax", high, variable=f":0:{key}")
    run(project, args.out, history, "instrument_width")

    base(project)
    for pid in [1, 2, 3, 4]:
        project.phases()[pid].data["Histograms"][hist.name]["Pref.Ori."][2] = True
        project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
    run(project, args.out, history, "preferred_orientation")

    base(project)
    add_cells_zero(project)
    run(project, args.out, history, "final_cells_zero")

    base(project)
    inst["Polariz."][2] = True
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"][1] = True
    project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.6, variable=":0:SurfRoughA")
    run(project, args.out, history, "intensity_corrections")

    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.save()
    project.refine()
    project.save()
    history.append(snapshot(project, "synchronized"))
    (args.out / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print("synchronized", history[-1]["Rwp_percent"], history[-1]["fractions"], flush=True)


if __name__ == "__main__":
    main()
