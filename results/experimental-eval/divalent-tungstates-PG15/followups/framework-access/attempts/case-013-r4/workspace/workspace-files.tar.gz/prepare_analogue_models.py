#!/usr/bin/env python3
"""Create chemically substituted Pb-W-O analogue models for phase testing."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from pymatgen.io.cif import CifParser


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
RUNTIME = ROOT / "learned/divalent-tungstates/runtime"
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402


MODELS = {
    "Pb2WO5_from_Pb2MoO5_7220560": ("7220560", {"Mo": "W"}),
    "Pb2WO5_from_Pb2CrO5_8103050": ("8103050", {"Cr": "W"}),
    "Pb2WO5_from_Pb2SO5_9011421": ("9011421", {"S": "W"}),
    "Pb5WO8_from_Pb5MoO8_2007541": ("2007541", {"Mo": "W"}),
    "Pb5WO8_from_Pb5CrO8_3500065": ("3500065", {"Cr": "W"}),
    "Pb3WO6_from_Pb3SO6_8103588": ("8103588", {"S": "W"}),
    "Pb3WO6_from_Pb3SO6_1542011": ("1542011", {"S": "W"}),
    "Pb3WO6_from_Pb3NO6_4338324": ("4338324", {"N": "W"}),
}


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    outdir = ROOT / ".tmp/analogues"
    outdir.mkdir(parents=True, exist_ok=True)
    provenance = []
    for name, (cod_id, substitutions) in MODELS.items():
        structures = CifParser(
            cod_path(cod_id), occupancy_tolerance=1.0,
            site_tolerance=1e-5, frac_tolerance=0,
        ).parse_structures(primitive=False, on_error="raise")
        if len(structures) != 1:
            raise ValueError(f"{cod_id}: expected one structure")
        structure = structures[0]
        structure.remove_oxidation_states()
        structure.replace_species(substitutions)
        output = outdir / f"{name}.cif"
        write_synthetic_model(structure, output)
        provenance.append({
            "model": name,
            "path": str(output.relative_to(ROOT)),
            "parent_cod_id": cod_id,
            "transformation": substitutions,
            "formula": structure.composition.reduced_formula,
            "space_group": structure.get_space_group_info(),
        })
        print(name, structure.composition.reduced_formula, structure.get_space_group_info())
    (outdir / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")


if __name__ == "__main__":
    main()
