#!/usr/bin/env python3
"""Test small, physically bounded heavy-atom coordinate adjustments."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags


def lattice_matrix(cell: list[float]) -> np.ndarray:
    a, b, c, alpha, beta, gamma = cell[:6]
    al, be, ga = np.radians([alpha, beta, gamma])
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * np.cos(ga), b * np.sin(ga), 0.0])
    cx = c * np.cos(be)
    cy = c * (np.cos(al) - np.cos(be) * np.cos(ga)) / np.sin(ga)
    cz = math.sqrt(max(0.0, c * c - cx * cx - cy * cy))
    return np.array([va, vb, [cx, cy, cz]])


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histograms()[0]
    raw = np.asarray([
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ])
    return (raw / raw.sum()).tolist()


def scales_background(project: G2.G2Project, cycles: int) -> None:
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for pid, phase in enumerate(project.phases()):
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{pid}:0:Scale")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--max-displacement", type=float, required=True, help="maximum move per atom in angstrom")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    args.out.mkdir(parents=True, exist_ok=True)
    destination = args.out / "working.gpx"
    shutil.copy2(args.source.resolve(), destination)
    project = G2.G2Project(gpxfile=str(destination))
    phase = project.phases()[args.phase]
    matrix = lattice_matrix(phase.data["General"]["Cell"][1:7])
    before = [np.asarray(atom.coordinates, dtype=float) for atom in phase.atoms()]

    scales_background(project, 1)
    for atom in phase.atoms():
        atom.refinement_flags = "X" if atom.element != "O" else ""
    project.save()
    project.refine()
    raw_after = [np.asarray(atom.coordinates, dtype=float) for atom in phase.atoms()]

    movements = []
    for atom, old, raw in zip(phase.atoms(), before, raw_after):
        delta = (raw - old + 0.5) % 1.0 - 0.5
        raw_norm = float(np.linalg.norm(delta @ matrix))
        factor = min(1.0, args.max_displacement / raw_norm) if raw_norm > 0 else 1.0
        clipped = old + factor * delta
        atom.coordinates = clipped.tolist()
        movements.append({
            "label": atom.label,
            "element": atom.element,
            "raw_displacement_A": raw_norm,
            "applied_displacement_A": float(np.linalg.norm((factor * delta) @ matrix)),
            "coordinates_before": old.tolist(),
            "coordinates_after": clipped.tolist(),
        })

    scales_background(project, 12)
    project.save()
    project.refine()
    project.set_Frozen()
    project.refine()
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.save()
    project.refine()
    project.save()
    result = {
        "phase": args.phase,
        "phase_name": phase.name,
        "max_displacement_A": args.max_displacement,
        "Rwp_percent": project.histograms()[0].get_wR(),
        "fractions": fractions(project),
        "movements": movements,
    }
    (args.out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
