#!/usr/bin/env python3
"""Test every public Pb/W oxide candidate as one additional crystalline phase."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from prepare_candidate_models import CANDIDATE_IDS
from screen_effects import clear_flags


ROOT = Path(__file__).resolve().parent
MODELS = ROOT / ".tmp/all_registered"
EXCLUDE = {"9009811", "1528915", "2310433"}


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histograms()[0]
    raw = np.asarray([
        phase.data["General"]["Mass"]
        * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ])
    return (raw / raw.sum()).tolist()


def set_scale_refinement(project: G2.G2Project, background: bool = True) -> None:
    clear_flags(project)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = background
    project.index_ids()
    for pid, phase in enumerate(project.phases()):
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{pid}:0:Scale")
    project.set_Frozen()
    project.set_Controls("cycles", 8)


def synchronize(project: G2.G2Project) -> None:
    """Regenerate reflection lists/profile arrays before any least squares."""
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.save()
    project.refine()
    project.save()


def refine_baseline(source: Path, outdir: Path) -> dict:
    destination = outdir / "baseline.gpx"
    shutil.copy2(source, destination)
    project = G2.G2Project(gpxfile=str(destination))
    synchronize(project)
    set_scale_refinement(project)
    project.save()
    project.refine()
    return {
        "cod_id": "baseline",
        "Rwp_scales_percent": project.histograms()[0].get_wR(),
        "Rwp_final_percent": project.histograms()[0].get_wR(),
        "fractions": fractions(project),
    }


def refine_candidate(source: Path, outdir: Path, cod_id: str) -> dict:
    destination = outdir / f"{cod_id}.gpx"
    shutil.copy2(source, destination)
    project = G2.G2Project(gpxfile=str(destination))
    synchronize(project)
    hist = project.histograms()[0]
    phase = project.add_phase(
        str(MODELS / f"{cod_id}.cif"),
        phasename=f"candidate_{cod_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    total_raw = sum(
        ph.data["General"]["Mass"] * ph.data["Histograms"][hist.name]["Scale"][0]
        for ph in project.phases()[:-1]
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [total_raw * 0.03 / 0.97 / phase.data["General"]["Mass"], True]
    phase.setSampleProfile(hist, "size", "isotropic", 0.35)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0)
    synchronize(project)
    set_scale_refinement(project)
    project.save()
    project.refine()
    result = {
        "cod_id": cod_id,
        "formula": phase.data["General"].get("Name", phase.name),
        "Rwp_scales_percent": project.histograms()[0].get_wR(),
        "fractions_scales": fractions(project),
    }
    candidate_fraction = result["fractions_scales"][-1]
    if candidate_fraction > 0.001:
        # Only the new phase cell is adjusted; the established phases and all
        # calibration terms remain fixed, preventing the candidate from moving
        # unrelated peaks into residual maxima.
        set_scale_refinement(project)
        phase = project.phases()[-1]
        phase.data["General"]["Cell"][0] = True
        for j, value in enumerate(G2lat.cell2A(phase.data["General"]["Cell"][1:7])):
            if abs(value) < 1e-12:
                low, high = -0.001, 0.001
            else:
                low, high = sorted((0.98 * value, 1.02 * value))
            pid = len(project.phases()) - 1
            project.set_Controls("parmMin", low, variable=f"{pid}::A{j}")
            project.set_Controls("parmMax", high, variable=f"{pid}::A{j}")
        project.save(str(destination))
        project.refine()
        result["Rwp_cell_percent"] = project.histograms()[0].get_wR()
        result["fractions_cell"] = fractions(project)

        # A final profile-width adjustment is accepted only for a phase that
        # survives the scale/cell screen. Generator-supported physical bounds
        # are imposed and recorded for later review.
        if result["fractions_cell"][-1] > 0.002:
            set_scale_refinement(project)
            phase = project.phases()[-1]
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][2][0] = True
            hap["Mustrain"][2][0] = True
            pid = len(project.phases()) - 1
            project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
            project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
            project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
            project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
            project.save(str(destination))
            project.refine()
            result["Rwp_profile_percent"] = project.histograms()[0].get_wR()
            result["fractions_profile"] = fractions(project)
    result["Rwp_final_percent"] = project.histograms()[0].get_wR()
    result["fractions"] = fractions(project)
    result["cell"] = project.phases()[-1].data["General"]["Cell"][1:8]
    result["size"] = project.phases()[-1].data["Histograms"][hist.name]["Size"]
    result["mustrain"] = project.phases()[-1].data["Histograms"][hist.name]["Mustrain"]
    project.save(str(destination))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, default=Path(".tmp/phase_inventory_screen"))
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    args.out.mkdir(parents=True, exist_ok=True)
    rows = [refine_baseline(args.source.resolve(), args.out.resolve())]
    for cod_id in CANDIDATE_IDS:
        if cod_id in EXCLUDE:
            continue
        try:
            row = refine_candidate(args.source.resolve(), args.out.resolve(), cod_id)
        except Exception as exc:
            row = {"cod_id": cod_id, "error": repr(exc), "Rwp_final_percent": 1e9}
        rows.append(row)
        (args.out / "results_partial.json").write_text(json.dumps(rows, indent=2) + "\n")
        print(cod_id, row.get("Rwp_final_percent"), row.get("fractions", [None])[-1], flush=True)
    rows.sort(key=lambda row: row.get("Rwp_final_percent", 1e9))
    (args.out / "results.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows[:12], indent=2))


if __name__ == "__main__":
    main()
