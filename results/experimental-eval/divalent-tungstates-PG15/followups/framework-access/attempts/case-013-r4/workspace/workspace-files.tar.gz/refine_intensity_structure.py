#!/usr/bin/env python3
"""Refine intensity corrections and atomic parameters on a selected inventory."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histograms()[0]
    raw = np.asarray([
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ])
    return (raw / raw.sum()).tolist()


def activate(project: G2.G2Project) -> None:
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 10)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    project.index_ids()
    for pid, phase in enumerate(project.phases()):
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{pid}:0:Scale")


def sync(project: G2.G2Project) -> None:
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.save()
    project.refine()
    project.save()


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "step": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
        "message": cov.get("Rvals", {}).get("msg"),
        "fractions": fractions(project),
        "polarization": hist.data["Instrument Parameters"][0]["Polariz."][1],
        "surface_roughness": {
            "A": hist.data["Sample Parameters"]["SurfRoughA"][0],
            "B": hist.data["Sample Parameters"]["SurfRoughB"][0],
        },
        "atoms": [
            [
                {"label": a.label, "element": a.element, "coordinates": list(a.coordinates), "uiso": a.uiso}
                for a in phase.atoms()
            ]
            for phase in project.phases()
        ],
    }


def stage(project: G2.G2Project, outdir: Path, history: list[dict], label: str) -> None:
    project.save()
    project.refine()
    project.save()
    project.set_Frozen()
    project.refine()
    history.append(snapshot(project, label))
    checkpoint = outdir / f"{len(history)-1:02d}_{label}.gpx"
    project.save(str(checkpoint))
    project.save(str(outdir / "working.gpx"))
    print(label, history[-1]["Rwp_percent"], history[-1]["fractions"], flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--oxygen", action="store_true", help="also refine oxygen coordinates")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    args.out.mkdir(parents=True, exist_ok=True)
    working = args.out / "working.gpx"
    shutil.copy2(args.source.resolve(), working)
    project = G2.G2Project(gpxfile=str(working))
    sync(project)
    history = [snapshot(project, "synchronized")]

    activate(project)
    inst = project.histograms()[0].data["Instrument Parameters"][0]
    inst["Polariz."][2] = True
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    stage(project, args.out, history, "polarization")

    activate(project)
    sample = project.histograms()[0].data["Sample Parameters"]
    sample["SurfRoughA"] = [0.20, True]
    sample["SurfRoughB"] = [0.10, True]
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.6, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")
    stage(project, args.out, history, "surface_roughness")

    for pid, phase in enumerate(project.phases()):
        activate(project)
        for atom in phase.atoms():
            atom.refinement_flags = "X" if atom.element != "O" else ""
        stage(project, args.out, history, f"heavy_coordinates_phase_{pid}")

    if args.oxygen:
        for pid, phase in enumerate(project.phases()):
            activate(project)
            for atom in phase.atoms():
                atom.refinement_flags = "X"
            stage(project, args.out, history, f"all_coordinates_phase_{pid}")

    # The generator uses one Uiso per phase. Equivalence constraints preserve
    # that model while retaining one independently refined value per phase.
    activate(project)
    project.index_ids()
    for pid, phase in enumerate(project.phases()):
        variables = [f"{pid}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
        for i, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            project.set_Controls("parmMin", 0.003, variable=f"{pid}::AUiso:{i}")
            project.set_Controls("parmMax", 0.020, variable=f"{pid}::AUiso:{i}")
    stage(project, args.out, history, "common_phase_uiso")

    sync(project)
    history.append(snapshot(project, "final_synchronized"))
    (args.out / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print("final", history[-1]["Rwp_percent"], history[-1]["fractions"], flush=True)


if __name__ == "__main__":
    main()
