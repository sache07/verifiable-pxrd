#!/usr/bin/env python3
"""Screen discrete specimen-effect models against a refined GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    for hist in project.histograms():
        hist.data["Background"][0][1] = False
        for value in hist.data["Instrument Parameters"][0].values():
            if isinstance(value, list) and len(value) > 2:
                value[2] = False
        for value in hist.data["Sample Parameters"].values():
            if isinstance(value, list) and len(value) > 1:
                value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        for hap in phase.data["Histograms"].values():
            hap["Scale"][1] = False
            hap["Pref.Ori."][2] = False
            hap["Size"][2] = [False] * len(hap["Size"][2])
            hap["Size"][5] = [False] * len(hap["Size"][5])
            hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def prepare(source: Path, destination: Path) -> G2.G2Project:
    project = G2.G2Project(gpxfile=str(source))
    clear_flags(project)
    hist = project.histograms()[0]
    for pid, phase in enumerate(project.phases()):
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
    project.set_Controls("cycles", 4)
    project.save(str(destination))
    return project


def run_po(source: Path, outdir: Path, phase_index: int) -> list[dict]:
    axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]
    ratios = [0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.4]
    results = []
    for axis in axes:
        for ratio in ratios:
            tag = "po_%d_%d_%d_%s" % (*axis, str(ratio).replace(".", "p"))
            project = prepare(source, outdir / f"{tag}.gpx")
            hist = project.histograms()[0]
            hap = project.phases()[phase_index].data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = ratio
            hap["Pref.Ori."][2] = False
            hap["Pref.Ori."][3] = axis
            try:
                project.refine()
                rwp = project.histograms()[0].get_wR()
                fractions = []
                raw = []
                for phase in project.phases():
                    phap = phase.data["Histograms"][hist.name]
                    raw.append(phap["Scale"][0] * phase.data["General"]["Mass"])
                fractions = [v / sum(raw) for v in raw]
                results.append({"axis": axis, "ratio": ratio, "Rwp_percent": rwp, "fractions": fractions})
            except Exception as exc:
                results.append({"axis": axis, "ratio": ratio, "error": repr(exc)})
    return results


def run_mustrain(source: Path, outdir: Path, phase_index: int) -> list[dict]:
    axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0]]
    equatorials = [1000.0, 2000.0, 4000.0, 8000.0]
    ratios = [0.25, 0.5, 1.0, 2.0, 4.0]
    results = []
    for axis in axes:
        for equatorial in equatorials:
            for ratio in ratios:
                axial = equatorial * ratio
                tag = "ms_%d_%d_%d_%g_%g" % (*axis, equatorial, axial)
                project = prepare(source, outdir / f"{tag}.gpx")
                hist = project.histograms()[0]
                phase = project.phases()[phase_index]
                phase.setSampleProfile(hist, "microstrain", "uniaxial", equatorial, axial, axis)
                hap = phase.data["Histograms"][hist.name]
                hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
                try:
                    project.refine()
                    rwp = project.histograms()[0].get_wR()
                    raw = []
                    for ph in project.phases():
                        phap = ph.data["Histograms"][hist.name]
                        raw.append(phap["Scale"][0] * ph.data["General"]["Mass"])
                    results.append(
                        {
                            "axis": axis,
                            "equatorial_ppm": equatorial,
                            "axial_ppm": axial,
                            "Rwp_percent": rwp,
                            "fractions": [v / sum(raw) for v in raw],
                        }
                    )
                except Exception as exc:
                    results.append(
                        {"axis": axis, "equatorial_ppm": equatorial, "axial_ppm": axial, "error": repr(exc)}
                    )
    return results


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--effect", choices=["po", "mustrain"], required=True)
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    args.out.mkdir(parents=True, exist_ok=True)
    source = args.source.resolve()
    results = (
        run_po(source, args.out.resolve(), args.phase)
        if args.effect == "po"
        else run_mustrain(source, args.out.resolve(), args.phase)
    )
    results.sort(key=lambda row: row.get("Rwp_percent", 1e9))
    (args.out / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results[:10], indent=2))


if __name__ == "__main__":
    main()
