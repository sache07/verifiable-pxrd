#!/usr/bin/env python3
"""Replace the diagnostic WO3 oxygen sublattice with a physical P21/c model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags


OXYGEN_COORDINATES = [
    [0.002, 0.738, 0.714],
    [0.225, 0.026, 0.718],
    [0.206, 0.042, 0.211],
    [0.284, 0.543, 0.492],
    [0.286, 0.987, 0.507],
    [0.481, 0.741, 0.270],
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    args.out.mkdir(parents=True, exist_ok=True)
    destination = args.out / "working.gpx"
    shutil.copy2(args.source.resolve(), destination)
    project = G2.G2Project(gpxfile=str(destination))
    phase = project.phases()[1]
    oxygen = [atom for atom in phase.atoms() if atom.element == "O"]
    if len(oxygen) != len(OXYGEN_COORDINATES):
        raise ValueError("Unexpected WO3 oxygen-site count")
    for atom, coordinates in zip(oxygen, OXYGEN_COORDINATES):
        atom.coordinates = coordinates

    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for pid, item in enumerate(project.phases()):
        item.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{pid}:0:Scale")
    project.save()
    project.refine()
    project.set_Frozen()
    project.refine()
    clear_flags(project)
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.save()
    project.refine()
    project.save()
    masses = np.asarray([
        item.data["General"]["Mass"] * item.data["Histograms"][hist.name]["Scale"][0]
        for item in project.phases()
    ])
    result = {"Rwp_percent": hist.get_wR(), "fractions": (masses / masses.sum()).tolist()}
    (args.out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
