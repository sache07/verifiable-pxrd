#!/usr/bin/env python3
"""Summarize a GSAS-II project and its largest profile residual regions."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.project))
    hist = project.histograms()[0]
    x, obs, weight, calc, background, residual = hist.data["data"][1]
    # Integrated positive/negative residuals near local maxima help distinguish
    # omitted reflections from intensity/model problems.
    diff = obs - calc
    sigma = np.sqrt(np.maximum(obs, 1.0))
    prominence = max(5.0 * np.median(sigma), 0.01 * (obs.max() - np.median(obs)))
    peaks, props = find_peaks(np.abs(diff), prominence=prominence, distance=5)
    order = peaks[np.argsort(np.abs(diff[peaks]))[::-1]][:40]
    cov = project.data.get("Covariance", {}).get("data", {})
    raw = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw.append(hap["Scale"][0] * phase.data["General"]["Mass"])
        phases.append(
            {
                "name": phase.name,
                "cell": phase.data["General"]["Cell"][1:8],
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "po": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": list(atom.coordinates),
                        "uiso": atom.uiso,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    fractions = (np.asarray(raw) / np.sum(raw)).tolist()
    for phase, fraction in zip(phases, fractions):
        phase["weight_fraction"] = fraction
    result = {
        "project": str(args.project),
        "Rwp_percent": hist.get_wR(),
        "Rvals": cov.get("Rvals", {}),
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "phases": phases,
        "largest_residuals": [
            {
                "two_theta": float(x[i]),
                "observed": float(obs[i]),
                "calculated": float(calc[i]),
                "difference": float(diff[i]),
            }
            for i in order
        ],
    }
    rendered = json.dumps(result, indent=2, default=lambda v: v.tolist() if hasattr(v, "tolist") else str(v))
    if args.json:
        args.json.write_text(rendered + "\n")
    print(rendered)


if __name__ == "__main__":
    main()
