#!/usr/bin/env python3
"""Run the supplied evaluator replay and report fresh-profile Rwp values."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
WORKER = ROOT / "learned/divalent-tungstates/scorer/runtime/replay_worker.py"
OBSERVED = ROOT / "inputs/pattern.csv"


def safe_tag(path: Path) -> str:
    return "_".join(path.with_suffix("").parts[-3:]).replace(".", "_")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", nargs="+", type=Path)
    parser.add_argument("--out", type=Path, default=Path(".tmp/replay_metrics"))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    rows = []
    for project_arg in args.project:
        project = project_arg.resolve()
        outdir = (args.out / safe_tag(project_arg)).resolve()
        outdir.mkdir(parents=True, exist_ok=True)
        request = outdir / "request.json"
        request.write_text(json.dumps({"project": str(project), "observed": str(OBSERVED)}) + "\n")
        run = subprocess.run(
            [sys.executable, str(WORKER), str(request)],
            cwd=outdir,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        replay = json.loads((outdir / "replay.json").read_text())
        row = {"project": str(project_arg), "status": replay.get("status"), "returncode": run.returncode}
        if replay.get("status") == "replayed":
            with np.load(outdir / "prediction.npz") as z:
                observed = z["observed"]
                predicted = z["predicted"]
            weights = 1.0 / np.maximum(observed, 1.0)
            row["fresh_Rwp_percent"] = float(
                100 * np.sqrt(np.sum(weights * (observed - predicted) ** 2) / np.sum(weights * observed**2))
            )
            row["fractions"] = [p["weight_fraction"] for p in replay["phases"]]
            row["review_flags"] = replay["profile_review_flags"]
        else:
            row["error"] = replay.get("error")
            row["log"] = run.stdout[-2000:]
        rows.append(row)
        print(json.dumps(row), flush=True)
    (args.out / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
