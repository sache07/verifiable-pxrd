#!/usr/bin/env python3
"""Build comparable GSAS-II trial refinements for Pb-W-O phase candidates.

This is an analysis helper. The final project is produced separately after the
phase inventory has been selected.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    registered = ROOT / ".tmp/registered" / f"{cod_id}.cif"
    if registered.is_file():
        return registered
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_instrument(path: Path) -> None:
    path.write_text(
        "# GSAS-II Cu Kalpha laboratory instrument; initial trial profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def initial_background(ncoeff: int = 12) -> list[float]:
    data = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    x, y = data.T
    # A low rolling percentile estimates the broad continuum without using a
    # phase model. Fit in the same [-1,1] coordinate used by chebyschev-1.
    baseline = percentile_filter(y, percentile=12, size=501, mode="nearest")
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, baseline, ncoeff - 1).tolist()


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "step": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "instrument": {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.") if k in inst},
        "sample": {k: sample[k][0] for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.data["General"]["Cell"][1:8],
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    return result


def refine_trial(tag: str, ids: list[str], fractions: list[float], outdir: Path) -> list[dict]:
    G2.SetPrintLevel("error")
    outdir.mkdir(parents=True, exist_ok=True)
    instfile = outdir / "instrument.instprm"
    write_instrument(instfile)
    gpx = outdir / f"{tag}.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"), str(instfile), fmthint="comma"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"][1] = False
    hist.set_refinements(
        {
            "Limits": [10.00943322, 99.99442286],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": initial_background(12),
                "refine": False,
            },
        }
    )
    phases = []
    for i, (cod_id, fraction) in enumerate(zip(ids, fractions)):
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=f"p{i}_{cod_id}",
            histograms=[hist],
            fmthint="CIF",
        )
        hap = phase.data["Histograms"][hist.name]
        # Same mass-scale convention used by the supplied synthetic forward model.
        hap["Scale"] = [10000.0 * fraction / phase.data["General"]["Mass"], False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        phases.append(phase)

    project.set_Controls("cycles", 8)
    project.save()
    # Keep the uncalibrated instrument/specimen parameters inside the physical
    # ranges specified for this laboratory. Otherwise Zero and Shift can trade
    # against cell dimensions and converge to a numerically equivalent but
    # physically meaningless solution.
    limits = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
    }
    for variable, (low, high) in limits.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    history = [snapshot(project, "initial")]

    steps = [
        ("scales_background", {"set": {"Background": True, "PhaseFraction": True}}),
        ("zero_shift", {"set": {"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]}}),
        ("cells", {"set": {"Cell": True}}),
        ("instrument_profile", {"set": {"Instrument Parameters": ["U", "W", "X", "SH/L"]}}),
    ]
    for label, recipe in steps:
        try:
            project.do_refinements([recipe])
            history.append(snapshot(project, label))
        except Exception as exc:
            history.append({"step": label, "error": repr(exc)})
            break
    project.save(str(gpx))
    (outdir / f"{tag}.json").write_text(json.dumps(history, indent=2) + "\n")
    return history


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=".tmp/candidate_fits")
    parser.add_argument(
        "--trial",
        action="append",
        help="tag:id,id,id (repeatable); defaults test the leading candidates",
    )
    args = parser.parse_args()
    trials = args.trial or [
        "wo3_1528915:9016035,1528915,2310433",
        "wo3_2311041:9016035,2311041,2310433",
        "wo3_1010618:9016035,1010618,2310433",
        "wo3_2106293:9016035,2106293,2310433",
        "scheelite_control:9009811,1528915,2310433",
        "pbo_litharge:9016035,1528915,9012700",
    ]
    summary = []
    for spec in trials:
        tag, values = spec.split(":", 1)
        ids = values.split(",")
        history = refine_trial(tag, ids, [0.80, 0.12, 0.08], ROOT / args.out)
        final = history[-1]
        summary.append({"tag": tag, "ids": ids, **final})
        print(tag, final.get("Rwp_percent"), final.get("error", ""), flush=True)
    (ROOT / args.out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
