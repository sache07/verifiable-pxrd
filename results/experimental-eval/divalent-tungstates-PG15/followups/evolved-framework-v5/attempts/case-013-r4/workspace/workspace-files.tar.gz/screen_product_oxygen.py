#!/usr/bin/env python3
"""Evaluate two physically bounded PbWO4 oxygen-coordinate starts."""

from __future__ import annotations

import json
import multiprocessing as mp
import shutil
from pathlib import Path

import numpy as np


SOURCE = Path(".tmp/coord_pb2_heavy_stable.gpx").resolve()
OUTDIR = Path(".tmp/product_oxygen_starts").resolve()
FULL_TARGET = np.array([0.26051558765648064, 0.10268191428170204, 0.0481037030611881])


def worker(fraction):
    from GSASII import GSASIIscriptable as G2

    G2.SetPrintLevel("error")
    out = OUTDIR / f"fraction_{fraction:.1f}.gpx"
    shutil.copy2(SOURCE, out)
    project = G2.G2Project(gpxfile=str(out))
    hist = project.histograms()[0]
    atom = project.phase("PbWO4").atom("O")
    start = np.asarray(atom.coordinates, dtype=float)
    atom.coordinates = start + fraction * (FULL_TARGET - start)
    project.set_Controls("cycles", 30)
    project.refine(makeBack=False)
    project.save()
    return {
        "fraction": fraction,
        "coordinates": list(atom.coordinates),
        "Rwp_percent": float(hist.get_wR()),
        "gpx": str(out),
    }


if __name__ == "__main__":
    if OUTDIR.exists():
        shutil.rmtree(OUTDIR)
    OUTDIR.mkdir(parents=True)
    with mp.get_context("spawn").Pool(processes=2) as pool:
        results = pool.map(worker, [0.2, 0.4])
    print(json.dumps(results, indent=2))
