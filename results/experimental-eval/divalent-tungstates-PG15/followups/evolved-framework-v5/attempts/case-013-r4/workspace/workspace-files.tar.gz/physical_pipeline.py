#!/usr/bin/env python3
"""Conservative staged refinement of the physical four-phase model."""

from __future__ import annotations

import argparse
import copy
import json
import math
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2


def lattice_matrix(cell: dict[str, float]) -> np.ndarray:
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    al, be, ga = np.deg2rad([cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]])
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * np.cos(ga), b * np.sin(ga), 0.0])
    cx = c * np.cos(be)
    cy = c * (np.cos(al) - np.cos(be) * np.cos(ga)) / np.sin(ga)
    cz = math.sqrt(max(c * c - cx * cx - cy * cy, 0.0))
    return np.vstack((va, vb, [cx, cy, cz]))


def atom_positions(project) -> dict[str, dict[str, np.ndarray]]:
    return {
        p.name: {a.label: np.asarray(a.coordinates, dtype=float) for a in p.atoms()}
        for p in project.phases()
    }


def max_displacement(project, before, phase_name: str, labels: list[str]) -> float:
    phase = project.phase(phase_name)
    mat = lattice_matrix(phase.get_cell())
    after = {a.label: np.asarray(a.coordinates, dtype=float) for a in phase.atoms()}
    vals = []
    for label in labels:
        d = after[label] - before[phase_name][label]
        d -= np.round(d)
        vals.append(float(np.linalg.norm(d @ mat)))
    return max(vals, default=0.0)


def fractions(project) -> dict[str, float]:
    hist = project.histograms()[0]
    values = {
        p.name: p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    }
    total = sum(max(0.0, v) for v in values.values())
    return {k: max(0.0, v) / total for k, v in values.items()}


def summary(project, tag: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    # Start the phase-specific microstrain search from no strain. This prevents
    # a common arbitrary strain value from being exchanged against instrument U.
    for phase in project.phases():
        mustrain = phase.data["Histograms"][hist.name]["Mustrain"]
        mustrain[0] = "isotropic"
        mustrain[1][0] = 0.0
        mustrain[1][1] = 0.0
        mustrain[2] = [False for _ in mustrain[2]]
    sample = hist.data["Sample Parameters"]
    return {
        "tag": tag,
        "wR_percent": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "fractions": fractions(project),
        "instrument": {k: inst[k][1] for k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]},
        "sample": {k: sample[k][0] for k in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]},
        "phases": {
            p.name: {
                "cell": p.get_cell(),
                "size": copy.deepcopy(p.data["Histograms"][hist.name]["Size"]),
                "mustrain": copy.deepcopy(p.data["Histograms"][hist.name]["Mustrain"]),
                "preferred_orientation": copy.deepcopy(p.data["Histograms"][hist.name]["Pref.Ori."]),
                "atoms": [
                    {"label": a.label, "element": a.element, "xyz": list(a.coordinates), "uiso": a.uiso}
                    for a in p.atoms()
                ],
            }
            for p in project.phases()
        },
        "varyList": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
    }


def checkpoint(project, working: Path, outdir: Path, tag: str, history: list[dict]) -> None:
    project.save(str(working))
    shutil.copy2(working, outdir / f"{tag}.gpx")
    rec = summary(project, tag)
    history.append(rec)
    (outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print(json.dumps({"tag": tag, "wR": rec["wR_percent"], "GOF": rec["GOF"], "fractions": rec["fractions"]}))


def run(project, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)


def coordinate_trial(project, working: Path, phase_name: str, labels: list[str],
                     cycles: int, max_shift_a: float) -> tuple[object, float, bool]:
    project.save(str(working))
    backup = working.with_name("_coordinate_pretrial.gpx")
    shutil.copy2(working, backup)
    before_w = project.histograms()[0].get_wR()
    before = atom_positions(project)
    phase = project.phase(phase_name)
    phase.set_refinements({"Atoms": {label: "X" for label in labels}})
    run(project, cycles)
    displacement = max_displacement(project, before, phase_name, labels)
    after_w = project.histograms()[0].get_wR()
    accepted = bool(np.isfinite(after_w) and after_w < before_w and displacement <= max_shift_a)
    if not accepted:
        shutil.copy2(backup, working)
        project = G2.G2Project(gpxfile=str(working))
    else:
        project.phase(phase_name).clear_refinements({"Atoms": labels})
    return project, displacement, accepted


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    outdir = args.out.resolve()
    if outdir.exists():
        shutil.rmtree(outdir)
    outdir.mkdir(parents=True)
    working = outdir / "working.gpx"
    shutil.copy2(args.source.resolve(), working)
    project = G2.G2Project(gpxfile=str(working))
    hist = project.histograms()[0]
    history: list[dict] = []

    # Positive, common per-phase starting displacement factors.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.uiso = 0.01
    checkpoint(project, working, outdir, "00_start", history)

    # Split the initial constant offset into a bounded zero and the physically
    # expected Bragg-Brentano specimen-height term.
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"][1] = 0.10
    inst["Zero"][2] = True
    hist.data["Sample Parameters"]["Shift"] = [-350.0, True]
    project.set_Controls("parmMin", -0.25, ":0:Zero")
    project.set_Controls("parmMax", 0.25, ":0:Zero")
    project.set_Controls("parmMin", -800.0, ":0:Shift")
    project.set_Controls("parmMax", 800.0, ":0:Shift")
    run(project, 10)
    checkpoint(project, working, outdir, "01_calibration", history)

    # The analogue-derived intermediate has chemically transferable topology,
    # but its heavy-atom coordinates may need modest adaptation after Mo->W.
    project, disp, accepted = coordinate_trial(
        project, working, "Pb2WO5", ["Pb1", "Pb2", "W1"], cycles=2, max_shift_a=0.20
    )
    checkpoint(project, working, outdir, "02_heavy_Pb2WO5", history)
    history[-1]["coordinate_trial"] = {"max_displacement_A": disp, "accepted": accepted}
    (outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")

    # The dominant phase can support a tightly bounded oxygen adjustment.
    project, disp, accepted = coordinate_trial(
        project, working, "PbWO4", ["O"], cycles=1, max_shift_a=0.10
    )
    checkpoint(project, working, outdir, "03_oxygen_PbWO4", history)
    history[-1]["coordinate_trial"] = {"max_displacement_A": disp, "accepted": accepted}
    (outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")

    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    for key, value, lo, hi in [
        ("U", 12.0, 0.0, 40.0),
        ("W", 18.0, 2.0, 40.0),
        ("X", 2.0, 0.1, 6.0),
        ("SH/L", 0.03, 0.005, 0.10),
    ]:
        inst[key][1] = value
        project.set_Controls("parmMin", lo, f":0:{key}")
        project.set_Controls("parmMax", hi, f":0:{key}")
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run(project, 8)
    checkpoint(project, working, outdir, "04_instrument", history)
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})

    # One phase profile at a time. Sizes and microstrains stay inside the
    # laboratory's physical support and are frozen before moving to the next.
    for phase_name in [p.name for p in project.phases()]:
        phase = project.phase(phase_name)
        project.save(str(working))
        backup = outdir / "_profile_pretrial.gpx"
        shutil.copy2(working, backup)
        before_w = hist.get_wR()
        pid, hid = phase.id, hist.id
        project.set_Controls("parmMin", 0.04, f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 1.5, f"{pid}:{hid}:Size;i")
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.30, "refine": True}}, [hist])
        run(project, 5)
        accepted = bool(np.isfinite(hist.get_wR()) and hist.get_wR() < before_w)
        if accepted:
            phase.clear_HAP_refinements({"Size": None}, [hist])
        else:
            shutil.copy2(backup, working)
            project = G2.G2Project(gpxfile=str(working))
            hist = project.histograms()[0]
        checkpoint(project, working, outdir, f"05_size_{phase_name}", history)
        history[-1]["profile_trial"] = {"kind": "isotropic_size", "accepted": accepted}
        (outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")

    for phase_name in [p.name for p in project.phases()]:
        phase = project.phase(phase_name)
        project.save(str(working))
        backup = outdir / "_profile_pretrial.gpx"
        shutil.copy2(working, backup)
        before_w = hist.get_wR()
        pid, hid = phase.id, hist.id
        project.set_Controls("parmMin", 0.0, f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, f"{pid}:{hid}:Mustrain;i")
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
        run(project, 5)
        accepted = bool(np.isfinite(hist.get_wR()) and hist.get_wR() < before_w)
        if accepted:
            phase.clear_HAP_refinements({"Mustrain": None}, [hist])
        else:
            shutil.copy2(backup, working)
            project = G2.G2Project(gpxfile=str(working))
            hist = project.histograms()[0]
        checkpoint(project, working, outdir, f"06_strain_{phase_name}", history)
        history[-1]["profile_trial"] = {"kind": "isotropic_microstrain", "accepted": accepted}
        (outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")

    # Polarization is a bounded instrument intensity term independent of phase
    # topology and is refined after the phase scales/profiles have stabilized.
    project.save(str(working))
    backup = outdir / "_polarization_pretrial.gpx"
    shutil.copy2(working, backup)
    before_w = hist.get_wR()
    inst = hist.data["Instrument Parameters"][0]
    inst["Polariz."][2] = True
    project.set_Controls("parmMin", 0.5, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    run(project, 6)
    accepted = bool(np.isfinite(hist.get_wR()) and hist.get_wR() < before_w)
    if not accepted:
        shutil.copy2(backup, working)
        project = G2.G2Project(gpxfile=str(working))
        hist = project.histograms()[0]
    checkpoint(project, working, outdir, "07_polarization", history)
    history[-1]["profile_trial"] = {"kind": "polarization", "accepted": accepted}
    (outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    if accepted:
        hist.clear_refinements({"Instrument Parameters": ["Polariz."]})

    # Freeze the highly correlated calibration pair at its bounded optimum and
    # perform a final scale/background/cell stabilization. Frozen-at-bound
    # bookkeeping is cleared only after all profile flags have been disabled.
    hist.data["Instrument Parameters"][0]["Zero"][2] = False
    hist.data["Sample Parameters"]["Shift"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    run(project, 12)
    checkpoint(project, working, outdir, "08_stabilized", history)

    project.save(str(outdir / "physical_final.gpx"))


if __name__ == "__main__":
    main()
