#!/usr/bin/env python3
"""Export the mutually consistent final GSAS-II project and deliverables."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/final_best.gpx")
PROJECT = Path("final.gpx")
EXPORTS = {
    "PbWO4": ("phase_PbWO4_stolzite.cif", "PbWO4 (stolzite, I41/a)"),
    "Pb2WO5": ("phase_Pb2WO5.cif", "Pb2WO5 (C2/m; Pb2MoO5-topology analogue)"),
    "PbO_massicot": ("phase_PbO_massicot.cif", "PbO (massicot, Pbcm)"),
    "WO3_monoclinic": ("phase_WO3_monoclinic.cif", "WO3 (monoclinic, P21/c)"),
    "PbO_litharge": ("phase_PbO_litharge.cif", "PbO (litharge, P4/nmm)"),
}


shutil.copy2(SOURCE, PROJECT)
project = G2.G2Project(gpxfile=str(PROJECT))
project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
project.save(str(PROJECT))
hist = project.histograms()[0]
phases = project.phases()

mass_scales = {
    phase.name: float(phase.data["General"]["Mass"])
    * float(phase.data["Histograms"][hist.name]["Scale"][0])
    for phase in phases
}
total_mass_scale = sum(mass_scales.values())

phase_rows = []
for phase in phases:
    cif, assignment = EXPORTS[phase.name]
    phase.export_CIF(cif)
    phase_rows.append({
        "name": phase.name,
        "assignment": assignment,
        "cif_path": cif,
        "weight_fraction": mass_scales[phase.name] / total_mass_scale,
    })

x, observed, weights, calculated, background, difference = [
    np.asarray(values, dtype=float) for values in hist.data["data"][1]
]
np.savetxt(
    "fit.csv",
    np.column_stack((x, observed, calculated, difference)),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference",
    comments="",
    fmt=["%.8f", "%.10g", "%.10g", "%.10g"],
)

covariance = project.data["Covariance"]["data"]["Rvals"]
histogram_rvals = hist.data["data"][0]
result = {
    "refinement_histogram": hist.name,
    "phases": phase_rows,
    "fit_statistics": {
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(histogram_rvals["R"]),
        "R_expected_percent": float(histogram_rvals["wRmin"]),
        "goodness_of_fit": float(covariance["GOF"]),
        "chi_square": float(covariance["chisq"]),
        "n_observations": int(covariance["Nobs"]),
        "n_variables": int(covariance["Nvars"]),
        "max_shift_over_esd": float(covariance["Max shft/sig"]),
        "converged": bool(covariance["converged"]),
        "weighting": "Poisson counting weights, sigma=sqrt(max(observed,1))",
    },
}
Path("result.json").write_text(json.dumps(result, indent=2) + "\n")

print(json.dumps(result, indent=2))
