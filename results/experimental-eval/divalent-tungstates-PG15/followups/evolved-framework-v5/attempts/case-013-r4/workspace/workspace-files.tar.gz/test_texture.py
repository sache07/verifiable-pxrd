#!/usr/bin/env python3
"""Screen bounded single-phase March-Dollase texture branches."""

from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import shutil
from pathlib import Path


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def worker(job):
    source, outdir, phase_name, axis = job
    from GSASII import GSASIIscriptable as G2
    G2.SetPrintLevel("error")
    tag = phase_name + "_" + "".join(str(i) for i in axis)
    gpx = outdir / f"{tag}.gpx"
    shutil.copy2(source, gpx)
    project = G2.G2Project(gpxfile=str(gpx))
    project.update_ids()
    hist = project.histograms()[0]
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    project.set_Controls("parmMin", 0.7, f"{phase.id}:{hist.id}:MD")
    project.set_Controls("parmMax", 1.4, f"{phase.id}:{hist.id}:MD")
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    ratio = phase.data["Histograms"][hist.name]["Pref.Ori."][1]
    return {
        "phase": phase_name,
        "axis": list(axis),
        "ratio": float(ratio),
        "wR_percent": float(hist.get_wR()),
        "gpx": str(gpx),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    source = args.source.resolve()
    outdir = args.out.resolve()
    if outdir.exists():
        shutil.rmtree(outdir)
    outdir.mkdir(parents=True)
    from GSASII import GSASIIscriptable as G2
    project = G2.G2Project(gpxfile=str(source))
    jobs = [(source, outdir, p.name, axis) for p in project.phases() for axis in AXES]
    with mp.get_context("spawn").Pool(processes=4) as pool:
        results = pool.map(worker, jobs)
    results.sort(key=lambda r: r["wR_percent"])
    (outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    for result in results:
        print(json.dumps(result))


if __name__ == "__main__":
    main()
