#!/usr/bin/env python3
"""Single-cycle heavy-site screens for minor accepted phases."""

from __future__ import annotations

import json
import multiprocessing as mp
import shutil
from pathlib import Path


SOURCE = Path(".tmp/coords_accepted_stable.gpx").resolve()
OUTDIR = Path(".tmp/minor_heavy").resolve()
JOBS = [
    ("PbO_massicot", ["Pb1"]),
    ("WO3_monoclinic", ["W1", "W2"]),
    ("PbO_litharge", ["Pb1"]),
]


def worker(job):
    phase_name, labels = job
    from GSASII import GSASIIscriptable as G2
    from physical_pipeline import atom_positions, max_displacement

    G2.SetPrintLevel("error")
    out = OUTDIR / f"{phase_name}.gpx"
    shutil.copy2(SOURCE, out)
    project = G2.G2Project(gpxfile=str(out))
    hist = project.histograms()[0]
    phase = project.phase(phase_name)
    before = atom_positions(project)
    initial_rwp = float(hist.get_wR())
    phase.set_refinements({"Atoms": {label: "X" for label in labels}})
    project.set_Controls("cycles", 1)
    project.refine(makeBack=False)
    trial_rwp = float(hist.get_wR())
    displacement = max_displacement(project, before, phase_name, labels)
    coordinates = {label: list(phase.atom(label).coordinates) for label in labels}
    phase.clear_refinements({"Atoms": labels})
    project.set_Controls("cycles", 30)
    project.refine(makeBack=False)
    project.save()
    phase.export_CIF(str(OUTDIR / f"{phase_name}.cif"))
    return {
        "phase": phase_name,
        "initial_Rwp_percent": initial_rwp,
        "trial_Rwp_percent": trial_rwp,
        "stabilized_Rwp_percent": float(hist.get_wR()),
        "max_displacement_A": displacement,
        "coordinates": coordinates,
        "gpx": str(out),
    }


if __name__ == "__main__":
    if OUTDIR.exists():
        shutil.rmtree(OUTDIR)
    OUTDIR.mkdir(parents=True)
    with mp.get_context("spawn").Pool(processes=3) as pool:
        results = pool.map(worker, JOBS)
    (OUTDIR / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))
