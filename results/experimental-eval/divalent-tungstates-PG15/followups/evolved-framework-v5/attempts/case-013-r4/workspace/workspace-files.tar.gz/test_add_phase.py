#!/usr/bin/env python3
"""Add one candidate phase to a converged GSAS-II checkpoint in safe stages."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def summarize(project: G2.G2Project, stage: str) -> None:
    hist = project.histograms()[0]
    vals = {
        phase.name: float(phase.data["General"]["Mass"])
        * float(phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in project.phases()
    }
    total = sum(max(value, 0.0) for value in vals.values())
    print(json.dumps({
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "phases": {
            phase.name: {
                "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
                "weight_fraction": max(vals[phase.name], 0.0) / total,
                "cell": phase.get_cell(),
                "size": phase.data["Histograms"][hist.name]["Size"][1][0],
            }
            for phase in project.phases()
        },
    }))


def refine(project: G2.G2Project, cycles: int) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("name")
    parser.add_argument("cif", type=Path)
    parser.add_argument("--scale", type=float, default=0.2)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    source = args.source.resolve()
    output = args.output.resolve()
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histograms()[0]
    phase = project.add_phase(
        str(args.cif.resolve()), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    for atom in phase.atoms():
        if atom.adp_flag == "I":
            atom.uiso = 0.01
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(args.scale), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.30
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    project.update_ids()
    project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Scale")
    project.set_Controls("parmMin", 0.04, f"{phase.id}:{hist.id}:Size;i")
    project.set_Controls("parmMax", 1.5, f"{phase.id}:{hist.id}:Size;i")
    phase.clear_refinements({"Cell": True})
    project.save()

    refine(project, 10)
    project.save()
    summarize(project, "scale_fixed_cell")

    before_cell = hist.get_wR()
    backup = output.with_suffix(".pre_cell.gpx")
    shutil.copy2(output, backup)
    try:
        phase.set_refinements({"Cell": True})
        refine(project, 10)
        if not math.isfinite(hist.get_wR()) or hist.get_wR() >= before_cell:
            raise RuntimeError("cell stage did not improve the fit")
        project.save()
        summarize(project, "cell_accepted")
    except Exception as exc:
        print(json.dumps({"stage": "cell_rejected", "reason": str(exc)}))
        shutil.copy2(backup, output)
        project = G2.G2Project(gpxfile=str(output))
        hist = project.histograms()[0]
        phase = project.phase(args.name)

    before_size = hist.get_wR()
    backup = output.with_suffix(".pre_size.gpx")
    project.save()
    shutil.copy2(output, backup)
    phase.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.30, "refine": True}}, [hist]
    )
    refine(project, 8)
    size = float(phase.data["Histograms"][hist.name]["Size"][1][0])
    if (not math.isfinite(hist.get_wR()) or hist.get_wR() >= before_size
            or not 0.04 <= size <= 1.5):
        shutil.copy2(backup, output)
        project = G2.G2Project(gpxfile=str(output))
        hist = project.histograms()[0]
        phase = project.phase(args.name)
        print(json.dumps({"stage": "size_rejected", "trial_size": size}))
    else:
        phase.clear_HAP_refinements({"Size": None}, [hist])
        project.save()
        summarize(project, "size_accepted")

    refine(project, 16)
    project.save()
    summarize(project, "stabilized")


if __name__ == "__main__":
    main()
