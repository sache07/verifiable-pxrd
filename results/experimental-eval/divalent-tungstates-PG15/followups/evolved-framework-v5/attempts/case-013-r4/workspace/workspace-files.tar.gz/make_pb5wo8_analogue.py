#!/usr/bin/env python3
"""Create the Pb5WO8 test model by isovalent Mo6+ -> W6+ substitution."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/00/75/2007541.cif"
)
TARGET = Path("models/Pb5WO8_from_Pb5MoO8.cif")

structure = Structure.from_file(SOURCE)
structure.replace_species({"Mo": "W"})
CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(TARGET)
