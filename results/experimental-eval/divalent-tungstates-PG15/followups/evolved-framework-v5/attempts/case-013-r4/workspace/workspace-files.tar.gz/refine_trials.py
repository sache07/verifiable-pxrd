#!/usr/bin/env python3
"""Build reproducible GSAS-II trial refinements for the PbO/WO3 specimen.

This script is intentionally limited to whole-pattern checkpoint fitting.  It
does not select the final structural model or write the submission files.
"""

from __future__ import annotations

import argparse
import copy
import json
import math
import shutil
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks

from GSASII import GSASIIscriptable as G2


def instrument_text() -> str:
    return (
        "#GSAS-II Cu K-alpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.15;Polariz.:0.8;Azimuth:0.0\n"
        "U:12.0;V:0.0;W:18.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def write_observed_xye(csv_path: Path, xye_path: Path) -> None:
    arr = np.loadtxt(csv_path, delimiter=",", skiprows=1)
    sigma = np.sqrt(np.maximum(arr[:, 1], 1.0))
    np.savetxt(xye_path, np.column_stack((arr, sigma)), fmt="%.10g")


def set_initial_hap(phase, hist_name: str, scale: float) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [float(scale), False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.30
    hap["Size"][1][1] = 0.30
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][1][1] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]


def mass_fractions(phases, hist_name: str) -> dict[str, float]:
    vals = {
        p.name: float(p.data["General"]["Mass"])
        * float(p.data["Histograms"][hist_name]["Scale"][0])
        for p in phases
    }
    total = sum(max(0.0, v) for v in vals.values())
    return {k: max(0.0, v) / total if total else math.nan for k, v in vals.items()}


def snapshot(project, outdir: Path, tag: str, history: list[dict]) -> None:
    project.save(str(outdir / f"{tag}.gpx"))
    hist = project.histograms()[0]
    phases = project.phases()
    data = hist.data["data"][1]
    resid = np.asarray(data[5], dtype=float)
    smooth = np.convolve(resid, np.ones(9) / 9.0, mode="same")
    peaks, props = find_peaks(smooth, prominence=40.0, distance=8)
    order = np.argsort(props["prominences"])[::-1][:20]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    rec = {
        "tag": tag,
        "wR_percent": hist.get_wR(),
        "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "cells": {p.name: p.get_cell() for p in phases},
        "scales": {
            p.name: float(p.data["Histograms"][hist.name]["Scale"][0])
            for p in phases
        },
        "weight_fractions": mass_fractions(phases, hist.name),
        "instrument": {
            k: float(v[1]) if isinstance(v, list) and len(v) > 1 and isinstance(v[1], (int, float)) else v
            for k, v in inst.items()
        },
        "sample": {
            k: (float(v[0]) if isinstance(v, list) and v and isinstance(v[0], (int, float)) else v)
            for k, v in sample.items()
            if k in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Scale", "Gonio. radius"}
        },
        "hap": {
            p.name: {
                "size": copy.deepcopy(p.data["Histograms"][hist.name]["Size"]),
                "mustrain": copy.deepcopy(p.data["Histograms"][hist.name]["Mustrain"]),
                "preferred_orientation": copy.deepcopy(p.data["Histograms"][hist.name]["Pref.Ori."]),
            }
            for p in phases
        },
        "largest_positive_residuals": [
            {
                "two_theta": float(data[0][peaks[j]]),
                "smoothed_difference": float(smooth[peaks[j]]),
                "prominence": float(props["prominences"][j]),
            }
            for j in order
            if smooth[peaks[j]] > 0
        ],
        "varyList": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
    }
    history.append(rec)
    (outdir / "history.json").write_text(json.dumps(history, indent=2, default=str) + "\n")
    print(json.dumps({"tag": tag, "wR": rec["wR_percent"], "GOF": rec["GOF"], "fractions": rec["weight_fractions"]}))


def run_refinement(project, outdir: Path, tag: str, history: list[dict]) -> None:
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    snapshot(project, outdir, tag, history)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--phase", action="append", nargs=2, metavar=("NAME", "CIF"), required=True)
    parser.add_argument("--profile", action="store_true", help="continue through isotropic size/microstrain refinement")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = args.out.resolve()
    if outdir.exists():
        shutil.rmtree(outdir)
    outdir.mkdir(parents=True)
    xye = outdir / "pattern.xye"
    instfile = outdir / "instrument.instprm"
    write_observed_xye(Path("inputs/pattern.csv").resolve(), xye)
    instfile.write_text(instrument_text())

    project = G2.G2Project(newgpx=str(outdir / "working.gpx"))
    phases = [
        project.add_phase(str(Path(cif).resolve()), phasename=name, fmthint="CIF")
        for name, cif in args.phase
    ]
    hist = project.add_powder_histogram(str(xye), str(instfile), phases="all", fmthint="xye")
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 15,
                "coeffs": [600.0] + [0.0] * 14,
                "refine": False,
            },
        }
    )
    for i, phase in enumerate(phases):
        set_initial_hap(phase, hist.name, [1.0, 0.20, 0.10][min(i, 2)])
    project.update_ids()
    project.save()

    # Keep scale parameters nonnegative and broadening parameters physical.
    for phase in phases:
        pid, hid = phase.id, hist.id
        project.set_Controls("parmMin", 0.0, f"{pid}:{hid}:Scale")
        project.set_Controls("parmMin", 0.02, f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 5.0, f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, f"{pid}:{hid}:Mustrain;i")

    history: list[dict] = []
    snapshot(project, outdir, "00_initial", history)

    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    run_refinement(project, outdir, "01_scale_background", history)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, outdir, "02_cells_zero", history)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_refinement(project, outdir, "03_instrument", history)

    if args.profile:
        for phase in phases:
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "value": 0.30, "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                },
                [hist],
            )
        run_refinement(project, outdir, "04_phase_profiles", history)

    project.save(str(outdir / "trial_final.gpx"))


if __name__ == "__main__":
    main()
