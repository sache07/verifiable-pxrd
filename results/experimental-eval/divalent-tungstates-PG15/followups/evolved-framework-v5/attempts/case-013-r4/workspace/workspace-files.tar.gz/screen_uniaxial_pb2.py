#!/usr/bin/env python3
"""Screen uniaxial microstrain axes for the accepted Pb2WO5 phase."""

from __future__ import annotations

import json
import multiprocessing as mp
import shutil
from pathlib import Path


SOURCE = Path(".tmp/five_profile_stable.gpx").resolve()
OUTDIR = Path(".tmp/uniaxial_pb2").resolve()
AXES = ([1, 0, 0], [0, 1, 0], [0, 0, 1])


def worker(axis):
    from GSASII import GSASIIscriptable as G2

    G2.SetPrintLevel("error")
    tag = "".join(str(value) for value in axis)
    out = OUTDIR / f"axis_{tag}.gpx"
    shutil.copy2(SOURCE, out)
    project = G2.G2Project(gpxfile=str(out))
    hist = project.histograms()[0]
    phase = project.phase("Pb2WO5")
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.update_ids()
    value = float(phase.data["Histograms"][hist.name]["Mustrain"][1][0])
    phase.setSampleProfile(hist, "microstrain", "uniaxial", value, value, axis)
    mustrain = phase.data["Histograms"][hist.name]["Mustrain"]
    mustrain[2] = [True, True, False]
    for name in ("Mustrain;i", "Mustrain;a"):
        project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:{name}")
        project.set_Controls("parmMax", 8000.0, f"{phase.id}:{hist.id}:{name}")
    project.set_Controls("cycles", 14)
    project.refine(makeBack=False)
    project.save()
    return {
        "axis": axis,
        "Rwp_percent": float(hist.get_wR()),
        "equatorial_microstrain_ppm": float(mustrain[1][0]),
        "axial_microstrain_ppm": float(mustrain[1][1]),
        "gpx": str(out),
    }


if __name__ == "__main__":
    if OUTDIR.exists():
        shutil.rmtree(OUTDIR)
    OUTDIR.mkdir(parents=True)
    with mp.get_context("spawn").Pool(processes=3) as pool:
        results = pool.map(worker, AXES)
    results.sort(key=lambda row: row["Rwp_percent"])
    (OUTDIR / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    for row in results:
        print(json.dumps(row))
