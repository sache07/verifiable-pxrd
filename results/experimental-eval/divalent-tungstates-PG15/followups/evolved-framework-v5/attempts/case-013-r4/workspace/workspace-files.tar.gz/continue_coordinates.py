#!/usr/bin/env python3
"""Coordinate-refinement checkpoints for the accepted four-phase inventory."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def record(project, outdir: Path, tag: str, history: list[dict]) -> None:
    project.save(str(outdir / f"{tag}.gpx"))
    hist = project.histograms()[0]
    rec = {
        "tag": tag,
        "wR_percent": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "atoms": {
            p.name: [
                {
                    "label": a.label,
                    "element": a.element,
                    "xyz": list(a.coordinates),
                    "uiso": a.uiso,
                    "flags": a.refinement_flags,
                }
                for a in p.atoms()
            ]
            for p in project.phases()
        },
        "varyList": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
    }
    history.append(copy.deepcopy(rec))
    (outdir / "coordinate_history.json").write_text(json.dumps(history, indent=2) + "\n")
    print(json.dumps({"tag": tag, "wR": rec["wR_percent"], "GOF": rec["GOF"]}))


def refine(project, outdir: Path, tag: str, history: list[dict]) -> None:
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    record(project, outdir, tag, history)


def set_atom_flags(phase, labels: list[str], flag: str = "X") -> None:
    phase.set_refinements({"Atoms": {label: flag for label in labels}})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    outdir = args.out.resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.source.resolve()))
    project.save(str(outdir / "working.gpx"))
    history: list[dict] = []
    record(project, outdir, "00_start", history)

    # The synthetic-lab protocol applies one physical Uiso per phase. Start all
    # sites at a neutral positive value before coordinate work; Uiso stays fixed.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.uiso = 0.01

    phase = project.phase("Pb2WO5")
    set_atom_flags(phase, ["Pb1", "Pb2", "W1"])
    refine(project, outdir, "01_heavy_Pb2WO5", history)

    phase = project.phase("PbO_massicot")
    set_atom_flags(phase, ["Pb1"])
    refine(project, outdir, "02_heavy_PbO", history)

    phase = project.phase("WO3_monoclinic")
    set_atom_flags(phase, ["W1", "W2"])
    refine(project, outdir, "03_heavy_WO3", history)

    phase = project.phase("PbWO4")
    set_atom_flags(phase, ["O"])
    refine(project, outdir, "04_oxygen_PbWO4", history)

    phase = project.phase("Pb2WO5")
    set_atom_flags(phase, ["O1", "O2", "O3", "O4"])
    refine(project, outdir, "05_oxygen_Pb2WO5", history)

    phase = project.phase("PbO_massicot")
    set_atom_flags(phase, ["O1"])
    refine(project, outdir, "06_oxygen_PbO", history)

    phase = project.phase("WO3_monoclinic")
    set_atom_flags(phase, ["O1", "O2", "O3", "O4", "O5", "O6"])
    refine(project, outdir, "07_oxygen_WO3", history)

    project.save(str(outdir / "coordinates_final.gpx"))


if __name__ == "__main__":
    main()
