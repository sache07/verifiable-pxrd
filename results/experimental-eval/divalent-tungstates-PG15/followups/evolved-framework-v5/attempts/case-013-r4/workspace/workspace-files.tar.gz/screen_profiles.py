#!/usr/bin/env python3
"""Screen one bounded isotropic size or microstrain parameter per branch."""

from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import shutil
from pathlib import Path


def worker(job):
    source, outdir, phase_name, kind = job
    from GSASII import GSASIIscriptable as G2

    G2.SetPrintLevel("error")
    out = outdir / f"{kind}_{phase_name}.gpx"
    shutil.copy2(source, out)
    project = G2.G2Project(gpxfile=str(out))
    hist = project.histograms()[0]
    phase = project.phase(phase_name)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.update_ids()
    if kind == "size":
        project.set_Controls("parmMin", 0.04, f"{phase.id}:{hist.id}:Size;i")
        project.set_Controls("parmMax", 1.5, f"{phase.id}:{hist.id}:Size;i")
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
    else:
        project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, f"{phase.id}:{hist.id}:Mustrain;i")
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    project.save()
    hap = phase.data["Histograms"][hist.name]
    return {
        "phase": phase_name,
        "kind": kind,
        "Rwp_percent": float(hist.get_wR()),
        "size_um": float(hap["Size"][1][0]),
        "microstrain_ppm": float(hap["Mustrain"][1][0]),
        "gpx": str(out),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    source = args.source.resolve()
    outdir = args.out.resolve()
    if outdir.exists():
        shutil.rmtree(outdir)
    outdir.mkdir(parents=True)
    from GSASII import GSASIIscriptable as G2

    project = G2.G2Project(gpxfile=str(source))
    jobs = [
        (source, outdir, phase.name, kind)
        for kind in ("size", "strain")
        for phase in project.phases()
    ]
    with mp.get_context("spawn").Pool(processes=4) as pool:
        results = pool.map(worker, jobs)
    results.sort(key=lambda item: item["Rwp_percent"])
    (outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    for result in results:
        print(json.dumps(result))


if __name__ == "__main__":
    main()
