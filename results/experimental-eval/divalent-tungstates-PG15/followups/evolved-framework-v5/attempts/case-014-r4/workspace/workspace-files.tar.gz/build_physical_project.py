"""Build the physically constrained three-phase GSAS-II checkpoint."""

from math import pi, sin

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project = G2.G2Project("sr3_physwo3_screen.gpx", newgpx="sr3_physical_start.gpx")
histogram = project.histograms()[0]

# Choose one member of the strongly correlated zero/displacement family that is
# inside the laboratory bounds and gives ordinary reference-cell mismatches.
histogram.data["Instrument Parameters"][0]["Zero"] = [0.0, 0.05, False]
histogram.data["Sample Parameters"]["Shift"] = [-532.0, False]

instrument = histogram.data["Instrument Parameters"][0]
for name, value in (("U", 10.0), ("V", 0.0), ("W", 30.0), ("X", 2.0), ("SH/L", 0.03)):
    instrument[name][1] = value
    instrument[name][2] = False

cells = (
    (5.4201, 5.4201, 11.9637, 90.0, 90.0, 90.0),
    (7.6995, 7.5503, 10.5310, 90.0, 136.10, 90.0),
    (10.9333, 10.9333, 10.9333, 90.0, 90.0, 90.0),
)
for phase, cell in zip(project.phases(), cells):
    a, b, c, alpha, beta, gamma = cell
    volume = a * b * c * sin(beta * pi / 180.0)
    phase.data["General"]["Cell"] = [True, a, b, c, alpha, beta, gamma, volume]
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"][1] = True
    hap["Size"] = [
        "isotropic",
        [0.5, 0.5, 1.0],
        [False, False, False],
        [0, 0, 1],
        [1.0, 1.0, 1.0, 0.0, 0.0, 0.0],
        [False, False, False, False, False, False],
    ]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][4]]
    hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
    for atom in phase.atoms():
        atom.refinement_flags = " "

project.set_Controls("cycles", 12)
project.refine()
project.save()

print("Rwp", histogram.get_wR())
print("zero", instrument["Zero"], "shift", histogram.data["Sample Parameters"]["Shift"])
for phase in project.phases():
    print(phase.name, phase.get_cell(), phase.data["Histograms"][histogram.name]["Scale"])
