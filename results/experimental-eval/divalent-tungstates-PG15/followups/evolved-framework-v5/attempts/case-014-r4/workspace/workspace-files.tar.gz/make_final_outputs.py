"""Export the selected full-grid GSAS-II checkpoint and submission files."""

import json

import numpy as np
from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project = G2.G2Project("sr3_physical_u.gpx", newgpx="final.gpx")
project.save()

cif_paths = [
    "phase_1_SrWO4.cif",
    "phase_2_WO3_monoclinic.cif",
    "phase_3_Sr3WO6_provisional.cif",
]
for phase, path in zip(project.phases(), cif_paths):
    phase.export_CIF(path)

histogram = project.histograms()[0]
x = np.asarray(histogram.getdata("X"), dtype=float)
observed = np.asarray(histogram.getdata("Yobs"), dtype=float)
calculated = np.asarray(histogram.getdata("Ycalc"), dtype=float)
background = np.asarray(histogram.getdata("Background"), dtype=float)
difference = observed - calculated
np.savetxt(
    "fit.csv",
    np.column_stack((x, observed, calculated, difference, background)),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference,background",
    comments="",
    fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
)

mass_terms = []
for phase in project.phases():
    scale = phase.data["Histograms"][histogram.name]["Scale"][0]
    mass_terms.append(scale * phase.data["General"]["Mass"])
fractions = np.asarray(mass_terms) / np.sum(mass_terms)

summary = {
    "cif_paths": cif_paths,
    "fractions": fractions.tolist(),
    "histogram_residuals": histogram.residuals,
    "refinement": project.data["Covariance"]["data"]["Rvals"],
    "points": len(x),
}
print(json.dumps(summary, indent=2, default=float))
