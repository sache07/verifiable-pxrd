"""Add one candidate phase to a GSAS-II checkpoint and refine for screening."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


def cod_path(cod_id: str) -> Path:
    root = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
    return root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


base, cod_id, phase_name, output = sys.argv[1:5]
candidate_path = Path(cod_id)
if not candidate_path.exists():
    candidate_path = cod_path(cod_id)
G2.SetPrintLevel("warn")
project = G2.G2Project(base, newgpx=output)
hist = project.histogram(0)
phase = project.add_phase(
    str(candidate_path),
    phasename=phase_name,
    histograms=[hist],
    fmthint="CIF",
)
phase.data["Histograms"][hist.name]["Scale"] = [0.3, True]
project.set_Controls("cycles", 6)
try:
    # Establish a stable positive scale before allowing the metric to move.
    project.refine()
    scale_only_rwp = hist.residuals.get("wR")
    scale_only_value = phase.data["Histograms"][hist.name]["Scale"][0]
    if scale_only_value > 0:
        phase.set_refinements({"Cell": True})
        project.set_Controls("cycles", 10)
        project.refine()
    project.save()
    masses = []
    for item in project.phases():
        hap = item.data["Histograms"][hist.name]
        masses.append(hap["Scale"][0] * item.data["General"]["Mass"])
    total = sum(masses)
    fractions = [value / total for value in masses] if total else [None] * len(masses)
    result = {
        "cod_id": cod_id,
        "phase_name": phase.name,
        "Rwp": hist.residuals.get("wR"),
        "scale_only_Rwp": scale_only_rwp,
        "scale_only_value": scale_only_value,
        "GOF": project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "scale": phase.data["Histograms"][hist.name]["Scale"][0],
        "fractions": fractions,
        "cell": phase.get_cell(),
        "output": output,
    }
except Exception as exc:
    result = {"cod_id": cod_id, "phase_name": phase_name, "error": repr(exc)}
print(json.dumps(result, sort_keys=True))
