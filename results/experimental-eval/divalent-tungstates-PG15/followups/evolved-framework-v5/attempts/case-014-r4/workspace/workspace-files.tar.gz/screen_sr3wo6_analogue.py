"""Screen a Sr3WO6 model made by Ca->Sr transfer from COD 1563081."""

import json
import sys

from GSASII import GSASIIscriptable as G2


base, output, factor_text = sys.argv[1:4]
factor = float(factor_text)
source = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/56/30/1563081.cif"

G2.SetPrintLevel("warn")
project = G2.G2Project(base, newgpx=output)
hist = project.histogram(0)
phase = project.add_phase(
    source,
    phasename=f"Sr3WO6_Ca_analogue_s{factor:.3f}",
    histograms=[hist],
    fmthint="CIF",
)
for atom in phase.atoms():
    if atom.element == "Ca":
        atom.type = "Sr"
        atom.label = atom.label.replace("Ca", "Sr")
cell = phase.data["General"]["Cell"]
for index in (1, 2, 3):
    cell[index] *= factor
cell[7] *= factor**3
G2.SetupGeneral(phase.data, None)
phase.data["Histograms"][hist.name]["Scale"] = [0.3, True]
project.set_Controls("cycles", 6)
project.refine()
scale_only_rwp = hist.residuals.get("wR")
scale_only_value = phase.data["Histograms"][hist.name]["Scale"][0]
if scale_only_value > 0:
    phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 12)
    project.refine()
project.save()
phase.export_CIF(output.replace(".gpx", "_initial_or_refined.cif"))
masses = []
for item in project.phases():
    hap = item.data["Histograms"][hist.name]
    masses.append(hap["Scale"][0] * item.data["General"]["Mass"])
total = sum(masses)
print(
    json.dumps(
        {
            "factor": factor,
            "Rwp": hist.residuals.get("wR"),
            "scale_only_Rwp": scale_only_rwp,
            "scale_only_value": scale_only_value,
            "scale": phase.data["Histograms"][hist.name]["Scale"][0],
            "fractions": [value / total for value in masses],
            "cell": phase.get_cell(),
            "mass": phase.data["General"]["Mass"],
            "output": output,
        },
        sort_keys=True,
    )
)
