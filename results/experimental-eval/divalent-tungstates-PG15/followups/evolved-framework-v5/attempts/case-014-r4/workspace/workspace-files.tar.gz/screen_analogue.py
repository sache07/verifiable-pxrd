"""Screen a simple element-substituted COD analogue in GSAS-II."""

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


base, output, cod_id, old_element, new_element, factor_text, phase_name = sys.argv[1:8]
factor = float(factor_text)
root = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
source = root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"

G2.SetPrintLevel("warn")
project = G2.G2Project(base, newgpx=output)
hist = project.histogram(0)
phase = project.add_phase(str(source), phasename=phase_name, histograms=[hist], fmthint="CIF")
for atom in phase.atoms():
    if atom.element == old_element:
        atom.type = new_element
        atom.label = atom.label.replace(old_element, new_element)
cell = phase.data["General"]["Cell"]
for index in (1, 2, 3):
    cell[index] *= factor
cell[7] *= factor**3
G2.SetupGeneral(phase.data, None)
phase.data["Histograms"][hist.name]["Scale"] = [0.3, True]
project.set_Controls("cycles", 6)
project.refine()
scale_only_rwp = hist.residuals.get("wR")
scale_only_value = phase.data["Histograms"][hist.name]["Scale"][0]
if scale_only_value > 0:
    phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 12)
    project.refine()
project.save()
phase.export_CIF(output.replace(".gpx", ".cif"))
masses = [
    item.data["Histograms"][hist.name]["Scale"][0] * item.data["General"]["Mass"]
    for item in project.phases()
]
print(
    json.dumps(
        {
            "cod_id": cod_id,
            "factor": factor,
            "Rwp": hist.residuals.get("wR"),
            "scale_only_Rwp": scale_only_rwp,
            "scale_only_value": scale_only_value,
            "scale": phase.data["Histograms"][hist.name]["Scale"][0],
            "fraction": masses[-1] / sum(masses),
            "cell": phase.get_cell(),
            "mass": phase.data["General"]["Mass"],
            "output": output,
        },
        sort_keys=True,
    )
)
