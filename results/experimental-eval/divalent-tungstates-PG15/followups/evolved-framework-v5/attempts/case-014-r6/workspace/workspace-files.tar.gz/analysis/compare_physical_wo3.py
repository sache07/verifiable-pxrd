"""Rebuild the accepted inventory with physical same-composition WO3 models."""

from __future__ import annotations

import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
TEMPLATE = ROOT / "checkpoints/inventory/01_scales_background.gpx"
INST = ROOT / "analysis/trials/wo3_1528915_rerun/initial.instprm"
OUT = ROOT / "checkpoints/physical_wo3"
PHASE0 = ROOT / "checkpoints/inventory/01_scales_background_phase0.cif"
PHASE2 = ROOT / "checkpoints/inventory/01_scales_background_phase2.cif"


def cod_path(record: str) -> Path:
    return COD / record[0] / record[1:3] / record[3:5] / f"{record}.cif"


def report(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    rows = []
    mass_scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scales.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
            }
        )
    total = sum(max(0.0, value) for value in mass_scales)
    for row, value in zip(rows, mass_scales):
        row["weight_fraction"] = max(0.0, value) / total
    return {
        "stage": label,
        "rwp_percent": float(hist.get_wR()),
        "residuals": {
            str(key): float(value)
            for key, value in hist.residuals.items()
            if isinstance(value, (int, float, np.number))
        },
        "vary_list": [str(value) for value in (project.get_VaryList() or [])],
        "phases": rows,
    }


def save(project: G2.G2Project, branch: Path, label: str, reports: list[dict]) -> None:
    project.save(str(branch / f"{label}.gpx"))
    for index, phase in enumerate(project.phases()):
        phase.export_CIF(str(branch / f"{label}_phase{index}.cif"))
    hist = project.histograms()[0]
    arrays = [np.asarray(value, float) for value in hist.data["data"][1]]
    np.savetxt(
        branch / f"{label}_profile.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[4], arrays[5])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference",
        comments="",
    )
    reports.append(report(project, label))
    (branch / "stages.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps(reports[-1], indent=2))


def refine(project: G2.G2Project, branch: Path, label: str, reports: list[dict], cycles: int = 16) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    save(project, branch, label, reports)


def build(record: str) -> None:
    branch = OUT / record
    branch.mkdir(parents=True, exist_ok=True)
    template = G2.G2Project(gpxfile=str(TEMPLATE))
    source_hist = template.histograms()[0]

    project = G2.G2Project(newgpx=str(branch / "working.gpx"))
    hist = project.add_powder_histogram(str(ROOT / "inputs/pattern.csv"), str(INST))
    hist.data["Background"] = copy.deepcopy(source_hist.data["Background"])
    hist.data["Instrument Parameters"] = copy.deepcopy(source_hist.data["Instrument Parameters"])
    hist.data["Sample Parameters"] = copy.deepcopy(source_hist.data["Sample Parameters"])

    phases = [
        project.add_phase(str(PHASE0), phasename="SrWO4_scheelite_COD1546036", histograms=[hist], fmthint="CIF"),
        project.add_phase(str(cod_path(record)), phasename=f"WO3_COD{record}", histograms=[hist], fmthint="CIF"),
        project.add_phase(str(PHASE2), phasename="Sr3W2O9_COD2311977", histograms=[hist], fmthint="CIF"),
    ]
    clear_all_flags(project)
    for phase, scale in zip(phases, (11.93, 1.24, 0.99)):
        phase.data["Histograms"][hist.name]["Scale"] = [scale, True]
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    hist.Background[0][1] = True
    reports: list[dict] = []
    refine(project, branch, "01_scales_background", reports)

    # Metrics are released only after each physical topology has a stable,
    # positive scale in the complete inventory.
    for phase in phases:
        phase.data["General"]["Cell"][0] = True
    refine(project, branch, "02_cells", reports, cycles=20)


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    for record in ("2106293", "2311041"):
        build(record)


if __name__ == "__main__":
    main()
