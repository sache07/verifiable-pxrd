from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import percentile_filter
from scipy.signal import find_peaks, peak_widths


ROOT = Path(__file__).resolve().parents[1]
data = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
x, y = data.T

# A broad local percentile is used only to rank observed maxima; it is not a
# background model for refinement.
baseline = percentile_filter(y, percentile=18, size=401, mode="nearest")
net = y - baseline
peaks, properties = find_peaks(net, prominence=80, distance=7, width=1)
width = peak_widths(net, peaks, rel_height=0.5)[0] * np.median(np.diff(x))
rows = sorted(
    zip(
        x[peaks],
        y[peaks],
        net[peaks],
        properties["prominences"],
        width,
    ),
    key=lambda row: row[3],
    reverse=True,
)

print("two_theta,intensity,net,prominence,fwhm_deg")
for row in rows[:100]:
    print(",".join(f"{value:.6g}" for value in row))

fig, axes = plt.subplots(2, 1, figsize=(14, 8), sharex=False)
axes[0].plot(x, y, color="black", lw=0.6)
axes[0].plot(x, baseline, color="tab:orange", lw=0.8)
axes[0].set(xlim=(10, 100), ylabel="counts")
axes[1].plot(x, net, color="black", lw=0.6)
axes[1].set(xlim=(10, 60), xlabel=r"$2\theta$ (deg, Cu K$\alpha$)", ylabel="net counts")
for ax in axes:
    ax.grid(alpha=0.15)
fig.tight_layout()
fig.savefig(ROOT / "analysis" / "pattern.png", dpi=180)
