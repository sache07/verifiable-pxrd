"""Test a bounded Suortti surface-roughness correction."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/calibration_accepted/03_polarization_validated.gpx"
OUT = ROOT / "checkpoints/surface_roughness"


def report(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    masses = []
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        rows.append({"name": phase.name, "scale": float(hap["Scale"][0])})
    total = sum(max(0.0, value) for value in masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = max(0.0, mass) / total
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": label,
        "rwp_percent": float(hist.get_wR()),
        "gof": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
        "surface_roughness_A": float(hist.SampleParameters["SurfRoughA"][0]),
        "surface_roughness_B": float(hist.SampleParameters["SurfRoughB"][0]),
        "phases": rows,
        "vary_list": [str(value) for value in (project.get_VaryList() or [])],
    }


def save(project: G2.G2Project, label: str, reports: list[dict]) -> None:
    project.save(str(OUT / f"{label}.gpx"))
    item = report(project, label)
    reports.append(item)
    (OUT / "stages.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps(item, indent=2), flush=True)
    project.save(str(OUT / "working.gpx"))


def refine(project: G2.G2Project, label: str, reports: list[dict], cycles: int = 8) -> None:
    print(f"starting {label}", flush=True)
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    save(project, label, reports)


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    hist.SampleParameters["SurfRoughA"] = [0.3, True]
    hist.SampleParameters["SurfRoughB"] = [0.1, True]
    project.set_Controls("parmMin", 0.05, variable=f":{hist.id}:SurfRoughA")
    project.set_Controls("parmMax", 0.6, variable=f":{hist.id}:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=f":{hist.id}:SurfRoughB")
    project.set_Controls("parmMax", 0.5, variable=f":{hist.id}:SurfRoughB")
    project.save(str(OUT / "working.gpx"))
    reports: list[dict] = []
    refine(project, "01_surface_roughness", reports, cycles=10)
    hist.SampleParameters["SurfRoughA"][1] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    refine(project, "02_surface_validated", reports, cycles=8)


if __name__ == "__main__":
    main()
