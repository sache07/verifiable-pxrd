"""Compare a small physical grid of phase-common isotropic U values."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/texture_screen/p2_111.gpx"
OUT = ROOT / "checkpoints/uiso_grid"
TRIPLETS = (
    (0.010, 0.003, 0.010),
    (0.008, 0.003, 0.020),
    (0.008, 0.005, 0.015),
    (0.012, 0.003, 0.020),
    (0.005, 0.003, 0.020),
    (0.008, 0.003, 0.015),
)


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for index, triplet in enumerate(TRIPLETS):
        print(f"starting {triplet}", flush=True)
        project = G2.G2Project(gpxfile=str(SOURCE))
        clear_all_flags(project)
        hist = project.histograms()[0]
        hist.Background[0][1] = True
        masses = []
        for phase, uiso in zip(project.phases(), triplet):
            phase.data["Histograms"][hist.name]["Scale"][1] = True
            project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
            for atom in phase.atoms():
                atom.uiso = uiso
        working = OUT / f"working_{index}.gpx"
        project.save(str(working))
        project.set_Controls("cycles", 6)
        project.refine(makeBack=False)
        result = OUT / f"candidate_{index}.gpx"
        project.save(str(result))
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            masses.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        total = sum(max(0.0, value) for value in masses)
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        row = {
            "uiso_A2": list(triplet),
            "rwp_percent": float(hist.get_wR()),
            "gof": float(rvals.get("GOF", float("nan"))),
            "converged": bool(rvals.get("converged", False)),
            "weight_fractions": [max(0.0, value) / total for value in masses],
            "gpx": str(result.relative_to(ROOT)),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
        (OUT / "grid.json").write_text(json.dumps(rows, indent=2) + "\n")
    rows.sort(key=lambda row: row["rwp_percent"])
    (OUT / "ranked.json").write_text(json.dumps(rows, indent=2) + "\n")
    print("best", json.dumps(rows[0]), flush=True)


if __name__ == "__main__":
    main()
