"""Sequential low-dimensional physical profile refinements."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/coordinates_final/04_srwo4_oxygen_validated.gpx"
OUT = ROOT / "checkpoints/profile_sequential"


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        phases.append(
            {
                "name": phase.name,
                "size_um": float(hap["Size"][1][0]),
                "microstrain_ppm": float(hap["Mustrain"][1][0]),
                "scale": float(hap["Scale"][0]),
            }
        )
    total = sum(max(0.0, value) for value in masses)
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = max(0.0, mass) / total
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": label,
        "rwp_percent": float(hist.get_wR()),
        "gof": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
        "instrument": {key: float(value[1]) for key, value in hist.InstrumentParameters.items() if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (int, float, np.number))},
        "phases": phases,
        "vary_list": [str(value) for value in (project.get_VaryList() or [])],
    }


def checkpoint(project: G2.G2Project, label: str, reports: list[dict]) -> None:
    project.save(str(OUT / f"{label}.gpx"))
    report = state(project, label)
    reports.append(report)
    (OUT / "stages.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps(report, indent=2), flush=True)
    project.save(str(OUT / "working.gpx"))


def refine(project: G2.G2Project, label: str, reports: list[dict], cycles: int = 6) -> None:
    print(f"starting {label}", flush=True)
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    checkpoint(project, label, reports)


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:3] = [0.5, 0.5, 1.0]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:3] = [0.0, 0.0, 1.0]
    for key, value in (("U", 10.0), ("W", 40.0), ("X", 2.0), ("SH/L", 0.02)):
        hist.InstrumentParameters[key][1] = value
    project.save(str(OUT / "working.gpx"))
    reports: list[dict] = []
    refine(project, "00_reset_profile", reports)

    for index, suffix in enumerate(("srwo4", "wo3", "sr3w2o9")):
        phase = project.phases()[index]
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:{hist.id}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:{hist.id}:Size;i")
        refine(project, f"0{index + 1}_size_{suffix}", reports)
        hap["Size"][2][0] = False

    refine(project, "04_sizes_validated", reports)


if __name__ == "__main__":
    main()
