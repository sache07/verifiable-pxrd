"""Recalculate coordinate checkpoints with coordinates fixed for fair comparison."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/bounded_coordinates"
OUT = ROOT / "checkpoints/coordinate_validation"


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    reports = []
    for label in (
        "00_fixed",
        "01_heavy",
        "02_oxygen_srwo4",
        "03_oxygen_wo3",
        "04_oxygen_sr3w2o9",
    ):
        project = G2.G2Project(gpxfile=str(SOURCE / f"{label}.gpx"))
        clear_all_flags(project)
        hist = project.histograms()[0]
        hist.Background[0][1] = True
        mass_scales = []
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            hap["Scale"][1] = True
            project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
        project.set_Controls("cycles", 16)
        project.refine(makeBack=False)
        out_label = f"{label}_validated"
        project.save(str(OUT / f"{out_label}.gpx"))
        for index, phase in enumerate(project.phases()):
            phase.export_CIF(str(OUT / f"{out_label}_phase{index}.cif"))
            hap = phase.data["Histograms"][hist.name]
            mass_scales.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        total = sum(max(0.0, value) for value in mass_scales)
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        reports.append(
            {
                "source_stage": label,
                "rwp_percent": float(hist.get_wR()),
                "gof": float(rvals.get("GOF", np.nan)),
                "converged": bool(rvals.get("converged", False)),
                "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
                "weight_fractions": [max(0.0, value) / total for value in mass_scales],
            }
        )
        print(json.dumps(reports[-1], indent=2))
    (OUT / "summary.json").write_text(json.dumps(reports, indent=2) + "\n")


if __name__ == "__main__":
    main()
