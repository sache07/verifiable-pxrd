"""Optimize a candidate metric against the positive multiphase residual.

This is a position-search diagnostic, not a final refinement. Structure-factor
weights are taken from the parent CIF and held fixed while the symmetry-allowed
metric and a common Gaussian width are searched. Promising metrics must still
survive atomic GSAS-II refinement and geometry checks.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import differential_evolution, minimize


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
LAM1 = 1.540598
LAM2 = 1.544426
KA2_RATIO = 0.5
ZERO = 0.3
SHIFT_UM = -100.61200034714086
RADIUS_MM = 200.0


def source_path(value: str) -> Path:
    if value.isdigit() and len(value) == 7:
        return COD / value[0] / value[1:3] / value[3:5] / f"{value}.cif"
    return (ROOT / value).resolve()


def corrected_position(d: np.ndarray, wavelength: float) -> np.ndarray:
    valid = d > wavelength / 2
    pos = np.full(d.shape, np.nan)
    ideal = np.degrees(2 * np.arcsin(wavelength / (2 * d[valid])))
    constant = 0.09 / (np.pi * RADIUS_MM)
    pos[valid] = ideal - constant * 4 * SHIFT_UM * np.cos(np.radians(ideal / 2)) + ZERO
    return pos


def lattice_system(structure: Structure) -> str:
    return SpacegroupAnalyzer(structure, symprec=1e-3).get_crystal_system()


def parameterization(structure: Structure, relative: float, angle_span: float):
    a, b, c = structure.lattice.abc
    alpha, beta, gamma = structure.lattice.angles
    system = lattice_system(structure)
    length_bounds = lambda value: (value * (1 - relative), value * (1 + relative))
    if system == "cubic":
        initial = [a]
        bounds = [length_bounds(a)]
        make = lambda p: Lattice.cubic(p[0])
    elif system == "tetragonal":
        initial = [a, c]
        bounds = [length_bounds(a), length_bounds(c)]
        make = lambda p: Lattice.tetragonal(p[0], p[1])
    elif system in ("hexagonal", "trigonal") and abs(gamma - 120) < 2:
        initial = [a, c]
        bounds = [length_bounds(a), length_bounds(c)]
        make = lambda p: Lattice.hexagonal(p[0], p[1])
    elif system == "orthorhombic":
        initial = [a, b, c]
        bounds = [length_bounds(a), length_bounds(b), length_bounds(c)]
        make = lambda p: Lattice.orthorhombic(*p)
    elif system == "monoclinic":
        initial = [a, b, c, beta]
        bounds = [
            length_bounds(a),
            length_bounds(b),
            length_bounds(c),
            (max(75.0, beta - angle_span), min(125.0, beta + angle_span)),
        ]
        make = lambda p: Lattice.monoclinic(p[0], p[1], p[2], p[3])
    else:
        initial = [a, b, c, alpha, beta, gamma]
        bounds = [
            length_bounds(a),
            length_bounds(b),
            length_bounds(c),
            (max(70, alpha - angle_span), min(130, alpha + angle_span)),
            (max(70, beta - angle_span), min(130, beta + angle_span)),
            (max(70, gamma - angle_span), min(130, gamma + angle_span)),
        ]
        make = lambda p: Lattice.from_parameters(*p)
    return system, np.asarray(initial, float), bounds, make


def reflection_sticks(structure: Structure):
    pattern = XRDCalculator(wavelength=LAM1).get_pattern(
        structure, two_theta_range=(9.5, 105), scaled=True
    )
    hkls: list[tuple[int, int, int]] = []
    intensity: list[float] = []
    for value, families in zip(pattern.y, pattern.hkls):
        multiplicities = np.asarray([family["multiplicity"] for family in families], float)
        multiplicities /= multiplicities.sum()
        for fraction, family in zip(multiplicities, families):
            hkls.append(tuple(int(v) for v in family["hkl"]))
            intensity.append(float(value * fraction))
    return np.asarray(hkls, float), np.asarray(intensity, float)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate")
    parser.add_argument("outdir")
    parser.add_argument(
        "--residual-profile",
        default="analysis/trials/wo3_1528915_rerun/profile.csv",
    )
    parser.add_argument("--relative", type=float, default=0.15)
    parser.add_argument("--angle-span", type=float, default=12.0)
    parser.add_argument("--maxiter", type=int, default=100)
    args = parser.parse_args()

    outdir = (ROOT / args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    structure = Structure.from_file(source_path(args.candidate))
    system, initial, bounds, make_lattice = parameterization(
        structure, args.relative, args.angle_span
    )
    hkls, intensities = reflection_sticks(structure)
    data = np.loadtxt(ROOT / args.residual_profile, delimiter=",", skiprows=1)
    x, observed, calculated = data[:, 0], data[:, 1], data[:, 2]
    residual = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    step = float(np.median(np.diff(x)))

    def profile(params: np.ndarray) -> np.ndarray:
        lattice = make_lattice(params[:-1])
        reciprocal_metric = lattice.reciprocal_lattice_crystallographic.metric_tensor
        reciprocal_d2 = np.einsum("ni,ij,nj->n", hkls, reciprocal_metric, hkls)
        d = 1.0 / np.sqrt(np.maximum(reciprocal_d2, 1e-12))
        sticks = np.zeros_like(x)
        for wavelength, ratio in ((LAM1, 1.0), (LAM2, KA2_RATIO)):
            positions = corrected_position(d, wavelength)
            indices = np.rint((positions - x[0]) / step).astype(int)
            valid = np.isfinite(positions) & (indices >= 0) & (indices < len(x))
            np.add.at(sticks, indices[valid], ratio * intensities[valid])
        sigma_deg = params[-1]
        return gaussian_filter1d(sticks, sigma_deg / step, mode="constant")

    baseline_sse = float(np.sum(weights * residual**2))

    def evaluate(params: np.ndarray):
        candidate_profile = profile(params)
        denominator = float(np.sum(weights * candidate_profile**2))
        scale = max(
            0.0,
            float(np.sum(weights * candidate_profile * residual)) / max(denominator, 1e-30),
        )
        sse = float(np.sum(weights * (residual - scale * candidate_profile) ** 2))
        return sse, scale, candidate_profile

    def objective(params: np.ndarray) -> float:
        return evaluate(params)[0] / baseline_sse

    full_bounds = bounds + [(0.04, 0.28)]
    result = differential_evolution(
        objective,
        full_bounds,
        seed=1776,
        maxiter=args.maxiter,
        popsize=18,
        tol=2e-6,
        polish=False,
        updating="immediate",
    )
    local = minimize(objective, result.x, method="Nelder-Mead", options={"maxiter": 1200})
    best = local.x if local.fun < result.fun else result.x
    sse, scale, candidate_profile = evaluate(best)
    lattice = make_lattice(best[:-1])
    fitted_structure = Structure(
        lattice,
        structure.species,
        structure.frac_coords,
        site_properties=structure.site_properties,
    )
    CifWriter(fitted_structure, symprec=1e-3, significant_figures=10).write_file(
        outdir / "metric_candidate.cif"
    )
    np.savetxt(
        outdir / "diagnostic_profile.csv",
        np.column_stack((x, residual, scale * candidate_profile)),
        delimiter=",",
        header="two_theta_deg,residual,candidate_profile",
        comments="",
    )
    report = {
        "candidate": args.candidate,
        "formula": structure.composition.reduced_formula,
        "space_group": structure.get_space_group_info(),
        "lattice_system": system,
        "parent_cell": [*structure.lattice.abc, *structure.lattice.angles],
        "optimized_cell": [*lattice.abc, *lattice.angles],
        "gaussian_sigma_deg": float(best[-1]),
        "linear_profile_scale": scale,
        "weighted_sse_ratio": sse / baseline_sse,
        "weighted_sse_improvement_percent": 100 * (1 - sse / baseline_sse),
        "optimizer_success": bool(result.success or local.success),
        "optimizer_message": str(result.message),
    }
    (outdir / "optimization.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
