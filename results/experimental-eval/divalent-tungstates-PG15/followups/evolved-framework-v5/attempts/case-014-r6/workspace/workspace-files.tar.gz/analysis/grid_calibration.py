"""Directly replay a physical zero/shift grid without unstable coupled LS steps."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/strain_sequential/04_strain_validated.gpx"
OUT = ROOT / "checkpoints/calibration_grid"


def weighted_rwp(hist: G2.G2PwdrData) -> float:
    data = [np.asarray(value, float) for value in hist.data["data"][1]]
    obs, weight, calc = data[1], data[2], data[3]
    return float(100.0 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for shift in np.arange(-206.0, -193.9, 1.0):
        project = G2.G2Project(gpxfile=str(SOURCE))
        clear_all_flags(project)
        hist = project.histograms()[0]
        hist.InstrumentParameters["Zero"][1] = 0.25
        hist.SampleParameters["Shift"][0] = float(shift)
        project.set_Controls("cycles", 0)
        project.save(str(OUT / "working.gpx"))
        project.refine(makeBack=False)
        row = {
            "zero_deg": 0.25,
            "shift_um": float(shift),
            "rwp_percent": weighted_rwp(hist),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    rows.sort(key=lambda row: row["rwp_percent"])
    (OUT / "fine_grid.json").write_text(json.dumps(rows, indent=2) + "\n")
    print("best", json.dumps(rows[0]), flush=True)


if __name__ == "__main__":
    main()
