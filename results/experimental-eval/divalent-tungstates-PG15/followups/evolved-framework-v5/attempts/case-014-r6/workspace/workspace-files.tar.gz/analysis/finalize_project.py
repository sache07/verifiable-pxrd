"""Create the frozen final GPX and CIF exports from the accepted checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/background_order/20_coefficients.gpx"
WORKING = ROOT / "analysis/final_working.gpx"
CIF_NAMES = ("SrWO4.cif", "WO3.cif", "Sr3W2O9.cif")


def main() -> None:
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(SOURCE))
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    project.save(str(WORKING))
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)

    arrays = [np.asarray(value, float) for value in hist.data["data"][1]]
    if not np.all(np.isfinite(np.concatenate(arrays[:6]))):
        raise RuntimeError("Nonfinite final profile")
    if np.min(arrays[3]) < 0 or np.min(arrays[4]) < 0:
        raise RuntimeError("Negative calculated intensity or background")

    masses, phases = [], []
    for phase, filename in zip(project.phases(), CIF_NAMES):
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        phases.append({
            "project_name": phase.name,
            "cif_path": filename,
            "scale": float(hap["Scale"][0]),
            "cell_mass": float(phase.data["General"]["Mass"]),
            "cell": [float(value) for value in phase.data["General"]["Cell"][1:]],
            "size_um": float(hap["Size"][1][0]),
            "microstrain_ppm": float(hap["Mustrain"][1][0]),
            "md_ratio": float(hap["Pref.Ori."][1]),
            "md_axis": list(map(int, hap["Pref.Ori."][3])),
            "uiso_A2": sorted(set(round(float(atom.uiso), 8) for atom in phase.atoms())),
        })
    total = sum(max(0.0, value) for value in masses)
    for row, mass in zip(phases, masses):
        row["weight_fraction"] = max(0.0, mass) / total

    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    snapshot = {
        "histogram": hist.name,
        "rwp_percent_saved": float(hist.get_wR()),
        "gof_saved": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
        "background_min_counts": float(np.min(arrays[4])),
        "background_max_counts": float(np.max(arrays[4])),
        "instrument": {key: float(value[1]) for key, value in hist.InstrumentParameters.items() if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (int, float, np.number))},
        "sample": {key: float(value[0]) for key, value in hist.SampleParameters.items() if isinstance(value, list) and len(value) > 1 and isinstance(value[0], (int, float, np.number))},
        "phases": phases,
        "residuals": {str(key): float(value) for key, value in hist.residuals.items() if isinstance(value, (int, float, np.number))},
    }
    (ROOT / "analysis/final_snapshot.json").write_text(json.dumps(snapshot, indent=2) + "\n")

    # Freeze all refinement flags after the final calculation; replay uses only
    # the saved atomic/profile values and regenerates reflection lists.
    clear_all_flags(project)
    project.save(str(ROOT / "final.gpx"))
    for phase, filename in zip(project.phases(), CIF_NAMES):
        phase.export_CIF(str(ROOT / filename))
    print(json.dumps(snapshot, indent=2), flush=True)


if __name__ == "__main__":
    main()
