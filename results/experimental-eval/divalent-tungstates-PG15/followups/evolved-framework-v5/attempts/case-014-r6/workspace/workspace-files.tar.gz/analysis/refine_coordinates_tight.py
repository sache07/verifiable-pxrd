"""Final conservative coordinate pass with a fixed-profile validation after each step."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/physical_wo3/2106293/02_cells.gpx"
OUT = ROOT / "checkpoints/coordinates_final"


def release(project: G2.G2Project, phase_index: int, elements: set[str], bound: float) -> None:
    phase = project.phases()[phase_index]
    for atom_index, atom in enumerate(phase.atoms()):
        if atom.element not in elements:
            continue
        atom.refinement_flags = "X"
        for axis, coordinate in zip("xyz", atom.coordinates):
            variable = f"{phase.id}::dA{axis}:{atom_index}"
            project.set_Controls("parmMin", float(coordinate) - bound, variable=variable)
            project.set_Controls("parmMax", float(coordinate) + bound, variable=variable)


def fix_atoms(project: G2.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def save(project: G2.G2Project, label: str, reports: list[dict]) -> None:
    project.save(str(OUT / f"{label}.gpx"))
    hist = project.histograms()[0]
    masses = []
    coordinates = []
    for index, phase in enumerate(project.phases()):
        phase.export_CIF(str(OUT / f"{label}_phase{index}.cif"))
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        coordinates.append(
            {
                "name": phase.name,
                "atoms": [
                    {"label": atom.label, "element": atom.element, "coordinates": list(map(float, atom.coordinates))}
                    for atom in phase.atoms()
                ],
            }
        )
    total = sum(max(0.0, value) for value in masses)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    report = {
        "stage": label,
        "rwp_percent": float(hist.get_wR()),
        "gof": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
        "weight_fractions": [max(0.0, value) / total for value in masses],
        "coordinates": coordinates,
    }
    reports.append(report)
    (OUT / "stages.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "coordinates"}, indent=2))
    # project.save changes the active GSAS-II filename. Point subsequent
    # refinements at a disposable working project so this checkpoint cannot be
    # overwritten by the next project.refine call.
    project.save(str(OUT / "working.gpx"))


def refine(project: G2.G2Project, label: str, reports: list[dict], cycles: int = 16) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    save(project, label, reports)


def validate(project: G2.G2Project, label: str, reports: list[dict]) -> None:
    fix_atoms(project)
    refine(project, label, reports, cycles=12)


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    reports: list[dict] = []
    project.save(str(OUT / "working.gpx"))
    refine(project, "00_baseline_validated", reports, cycles=16)

    # About 0.04--0.05 A per fractional component for the 7--12 A cells.
    for phase_index in range(3):
        release(project, phase_index, {"Sr", "W"}, 0.006)
    refine(project, "01_heavy_raw", reports)
    validate(project, "02_heavy_validated", reports)

    # The dominant scheelite oxygen coordinate is observable; minor-phase
    # oxygen positions were shown by the preceding test to be underdetermined.
    release(project, 0, {"O"}, 0.008)
    refine(project, "03_srwo4_oxygen_raw", reports)
    validate(project, "04_srwo4_oxygen_validated", reports)


if __name__ == "__main__":
    main()
