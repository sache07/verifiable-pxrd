from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
inst = ROOT / "analysis" / "initial.instprm"
inst.write_text(
    "# GSAS-II initial Cu K-alpha laboratory profile\n"
    "Type:PXC;Bank:1\n"
    "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
    "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
    "U:10.0;V:0.0;W:10.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.02\n"
)
project = G2.G2Project(newgpx=str(ROOT / "analysis" / "import_test.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"), str(inst)
)
x, y, w = [np.asarray(v) for v in hist.data["data"][1][:3]]
original = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
print(hist.name, len(x), x[0], x[-1])
print("x match", np.allclose(x, original[:, 0], rtol=0, atol=1e-10))
print("y match", np.allclose(y, original[:, 1], rtol=0, atol=1e-10))
print("weights", w[:5], w.min(), w.max())
print("instrument", hist.InstrumentParameters)
print("sample", hist.SampleParameters)
print("limits", hist.data["Limits"])
