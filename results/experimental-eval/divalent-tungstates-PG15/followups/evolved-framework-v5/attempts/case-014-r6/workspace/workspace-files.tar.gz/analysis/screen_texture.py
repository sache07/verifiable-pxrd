"""Screen the finite laboratory March--Dollase axes one phase at a time."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/surface_roughness/02_surface_validated.gpx"
OUT = ROOT / "checkpoints/texture_screen"
AXES = {
    0: ((0, 0, 1), (1, 0, 0), (1, 1, 0), (1, 1, 1)),
    1: ((0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)),
    2: ((0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)),
}


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for phase_index, axes in AXES.items():
        for axis in axes:
            tag = "".join(map(str, axis))
            print(f"starting phase {phase_index} axis {axis}", flush=True)
            project = G2.G2Project(gpxfile=str(SOURCE))
            clear_all_flags(project)
            hist = project.histograms()[0]
            hist.Background[0][1] = True
            for phase in project.phases():
                phase.data["Histograms"][hist.name]["Scale"][1] = True
                project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
            phase = project.phases()[phase_index]
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
            project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:{hist.id}:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:{hist.id}:MD")
            working = OUT / f"working_p{phase_index}_{tag}.gpx"
            project.save(str(working))
            project.set_Controls("cycles", 5)
            project.refine(makeBack=False)
            hap["Pref.Ori."][2] = False
            project.set_Controls("cycles", 4)
            project.refine(makeBack=False)
            result_path = OUT / f"p{phase_index}_{tag}.gpx"
            project.save(str(result_path))
            rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
            row = {
                "phase_index": phase_index,
                "phase_name": phase.name,
                "axis": list(axis),
                "ratio": float(hap["Pref.Ori."][1]),
                "rwp_percent": float(hist.get_wR()),
                "gof": float(rvals.get("GOF", float("nan"))),
                "converged": bool(rvals.get("converged", False)),
                "gpx": str(result_path.relative_to(ROOT)),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
            (OUT / "screen.json").write_text(json.dumps(rows, indent=2) + "\n")
    rows.sort(key=lambda row: row["rwp_percent"])
    (OUT / "ranked.json").write_text(json.dumps(rows, indent=2) + "\n")
    print("best", json.dumps(rows[0]), flush=True)


if __name__ == "__main__":
    main()
