"""Accept the replay-grid calibration and test one bounded polarization term."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/strain_sequential/04_strain_validated.gpx"
OUT = ROOT / "checkpoints/calibration_accepted"


def summary(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    masses, rows = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        rows.append({"name": phase.name, "scale": float(hap["Scale"][0])})
    total = sum(max(0.0, value) for value in masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = max(0.0, mass) / total
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": label,
        "rwp_percent": float(hist.get_wR()),
        "gof": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
        "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "phases": rows,
        "vary_list": [str(value) for value in (project.get_VaryList() or [])],
    }


def save(project: G2.G2Project, label: str, reports: list[dict]) -> None:
    project.save(str(OUT / f"{label}.gpx"))
    report = summary(project, label)
    reports.append(report)
    (OUT / "stages.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps(report, indent=2), flush=True)
    project.save(str(OUT / "working.gpx"))


def refine(project: G2.G2Project, label: str, reports: list[dict], cycles: int = 7) -> None:
    print(f"starting {label}", flush=True)
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    save(project, label, reports)


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.InstrumentParameters["Zero"][1] = 0.25
    hist.SampleParameters["Shift"][0] = -199.0
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    project.save(str(OUT / "working.gpx"))
    reports: list[dict] = []
    refine(project, "01_calibration_linear", reports, cycles=8)

    hist.InstrumentParameters["Polariz."][2] = True
    project.set_Controls("parmMin", 0.5, variable=f":{hist.id}:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=f":{hist.id}:Polariz.")
    refine(project, "02_polarization", reports, cycles=8)
    hist.InstrumentParameters["Polariz."][2] = False
    refine(project, "03_polarization_validated", reports, cycles=7)


if __name__ == "__main__":
    main()
