"""Assemble fit.csv, result.json and report.md from the verified GPX replay."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
REPLAY = ROOT / "analysis/final_replay"


def main() -> None:
    replay = json.loads((REPLAY / "replay.json").read_text())
    snapshot = json.loads((ROOT / "analysis/final_snapshot.json").read_text())
    if replay.get("status") != "replayed" or replay.get("profile_review_flags"):
        raise RuntimeError(f"Final replay was not clean: {replay}")
    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as values:
        replay_x = values["x"].astype(float)
        replay_observed = values["observed"].astype(float)
        calculated = values["predicted"].astype(float)
    source_profile = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    x = source_profile[:, 0]
    observed = source_profile[:, 1]
    if not (
        x.shape == replay_x.shape == observed.shape == replay_observed.shape
        and np.allclose(x, replay_x, rtol=0.0, atol=1e-10)
        and np.array_equal(observed, replay_observed)
    ):
        raise RuntimeError("Replayed profile grid does not match the specimen input")
    difference = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    rwp = float(100.0 * np.sqrt(chi_square / np.sum(weights * observed**2)))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    gof = float(snapshot["gof_saved"])
    rexp = rwp / gof

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        # Preserve the input grid exactly and keep observed-calculated
        # numerically self-consistent after CSV serialization.
        fmt="%.17g",
    )

    phase_metadata = (
        {
            "name": "scheelite strontium tungstate",
            "formula": "SrWO4",
            "space_group": "I 41/a",
            "cif_path": "SrWO4.cif",
            "identification_confidence": "high",
        },
        {
            "name": "triclinic tungsten trioxide",
            "formula": "WO3",
            "space_group": "P -1",
            "cif_path": "WO3.cif",
            "identification_confidence": "moderate",
        },
        {
            "name": "monoclinic strontium ditungstate",
            "formula": "Sr3W2O9",
            "space_group": "C 2/c",
            "cif_path": "Sr3W2O9.cif",
            "identification_confidence": "moderate; metric-adapted topology",
        },
    )
    phases = []
    for metadata, replay_phase in zip(phase_metadata, replay["phases"]):
        phases.append({**metadata, "weight_fraction": float(replay_phase["weight_fraction"])})

    result = {
        "method": "full-pattern Rietveld refinement with atomic GSAS-II models",
        "refinement_histogram": replay["histogram"],
        "fraction_basis": "normalized over the three modeled crystalline phases",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": rexp,
            "GOF": gof,
            "chi_square": chi_square,
            "number_of_points": int(len(x)),
            "profile_source": "fresh atomic forward replay of final.gpx over the full observed grid",
        },
        "calibration": {
            "zero_deg": float(snapshot["instrument"]["Zero"]),
            "specimen_shift_um": float(snapshot["sample"]["Shift"]),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    fractions = [100.0 * phase["weight_fraction"] for phase in phases]
    cells = [phase["cell"] for phase in snapshot["phases"]]
    report = f"""# Powder XRD phase analysis

The 900 °C SrCO3 + WO3 specimen is modeled by three crystalline phases: scheelite SrWO4, residual WO3, and Sr3W2O9. Fractions normalized over these modeled crystalline phases are **{fractions[0]:.2f} wt% SrWO4**, **{fractions[1]:.2f} wt% WO3**, and **{fractions[2]:.2f} wt% Sr3W2O9**. No amorphous fraction was determined.

## Evidence

- Scheelite SrWO4 (COD 1546036, I 41/a) explains the dominant reflection set. Its refined cell is a = {cells[0][0]:.5f} Å and c = {cells[0][2]:.5f} Å.
- A physical triclinic WO3 model (COD 2106293, P -1; a/b/c = {cells[1][0]:.5f}/{cells[1][1]:.5f}/{cells[1][2]:.5f} Å) accounts for the residual precursor family. A slightly better-fitting alternative COD entry was rejected because it generated a 1.57 Å O–O contact; the submitted model has normal distorted WO6 geometry.
- Exact-composition Sr3W2O9 (COD 2311977 topology, C 2/c) gives a stable positive scale and indexes the previously unassigned family, including reflections near 29.77, 30.90, 32.56, 56.97, and 61.22° 2theta. Its metric required residual-guided adaptation to a/b/c = {cells[2][0]:.5f}/{cells[2][1]:.5f}/{cells[2][2]:.5f} Å, beta = {cells[2][4]:.4f}°. After this phase was included, no separate coherent fourth reflection family remained.
- The final full-grid atomic replay has Rwp = {rwp:.3f}%, Rp = {rp:.3f}%, and GOF = {gof:.3f} over {len(x)} points. The replay reported no negative-background, peak-width, displacement-tensor, or other physical-review flags.

## Remaining uncertainty

SrWO4 is secure. WO3 is secure as a composition/precursor assignment, but its exact low-symmetry polymorph and oxygen coordinates are less well constrained by this overlapped powder pattern. Sr3W2O9 is the least certain structure: its coherent peak family and positive abundance are robust, while the adapted metric, minor-phase light-atom coordinates, and [111] texture term are correlated; the texture ratio reached the imposed physical limit (1.4). Its reported fraction should therefore be regarded as approximate (several wt% systematic uncertainty), and the other fractions inherit that covariance. Unconstrained minor-phase oxygen refinements were rejected as unreliable. Fractions describe only the modeled crystalline material.

The submitted CIFs and `fit.csv` were exported from, or freshly replayed from, `final.gpx`; the project retains the original observed scan and all accepted profile, calibration, background, and atomic parameters.
"""
    (ROOT / "report.md").write_text(report)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
