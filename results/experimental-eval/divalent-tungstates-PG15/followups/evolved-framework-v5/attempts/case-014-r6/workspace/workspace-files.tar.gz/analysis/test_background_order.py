"""Test a modest increase in smooth Chebyshev background order."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/profile_reoptimized/08_profile_validated.gpx"
OUT = ROOT / "checkpoints/background_order"


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.set_refinements({"Background": {"no. coeffs": 20, "refine": True}})
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    project.save(str(OUT / "working.gpx"))
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    project.save(str(OUT / "20_coefficients.gpx"))
    arrays = [np.asarray(value, float) for value in hist.data["data"][1]]
    masses = [float(phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]) for phase in project.phases()]
    total = sum(max(0.0, value) for value in masses)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    report = {
        "rwp_percent": float(hist.get_wR()),
        "gof": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
        "background_coefficients": int(hist.Background[0][2]),
        "background_min_counts": float(np.min(arrays[4])),
        "background_max_counts": float(np.max(arrays[4])),
        "weight_fractions": [max(0.0, value) / total for value in masses],
    }
    (OUT / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    main()
