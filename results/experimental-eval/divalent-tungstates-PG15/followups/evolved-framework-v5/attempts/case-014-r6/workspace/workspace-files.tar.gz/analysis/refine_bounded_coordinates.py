"""Bounded, phase-specific coordinate refinement for the physical inventory."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/physical_wo3/2106293/02_cells.gpx"
OUT = ROOT / "checkpoints/bounded_coordinates"


def release(project: G2.G2Project, phase_index: int, elements: set[str], bound: float) -> None:
    phase = project.phases()[phase_index]
    for atom_index, atom in enumerate(phase.atoms()):
        if atom.element not in elements:
            continue
        atom.refinement_flags = "X"
        # GSAS-II names these dA variables, but parmMin/parmMax are compared
        # against the resulting absolute fractional coordinate. Center each
        # limit around the current site rather than around zero.
        for axis, coordinate in zip("xyz", atom.coordinates):
            variable = f"{phase.id}::dA{axis}:{atom_index}"
            project.set_Controls("parmMin", float(coordinate) - bound, variable=variable)
            project.set_Controls("parmMax", float(coordinate) + bound, variable=variable)


def fix_all_atoms(project: G2.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def snapshot(project: G2.G2Project, label: str, reports: list[dict]) -> None:
    project.save(str(OUT / f"{label}.gpx"))
    hist = project.histograms()[0]
    for index, phase in enumerate(project.phases()):
        phase.export_CIF(str(OUT / f"{label}_phase{index}.cif"))
    arrays = [np.asarray(value, float) for value in hist.data["data"][1]]
    np.savetxt(
        OUT / f"{label}_profile.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[4], arrays[5])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference",
        comments="",
    )
    rows = []
    mass_scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scales.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": [float(value) for value in phase.data["General"]["Cell"][1:]],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": [float(value) for value in atom.coordinates],
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    total = sum(max(0.0, value) for value in mass_scales)
    for row, value in zip(rows, mass_scales):
        row["weight_fraction"] = max(0.0, value) / total
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    report = {
        "stage": label,
        "rwp_percent": float(hist.get_wR()),
        "gof": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
        "vary_list": [str(value) for value in (project.get_VaryList() or [])],
        "phases": rows,
    }
    reports.append(report)
    (OUT / "stages.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps(report, indent=2))


def refine(project: G2.G2Project, label: str, reports: list[dict], cycles: int = 16) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    snapshot(project, label, reports)


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    reports: list[dict] = []
    snapshot(project, "00_fixed", reports)

    # The generator's expected reference mismatch is at most a few hundredths
    # of an angstrom. Fractional bounds below correspond to roughly 0.05--0.15 A
    # for these cells and prevent intensity fitting from destroying geometry.
    for phase_index in range(3):
        release(project, phase_index, {"Sr", "W"}, 0.012)
    refine(project, "01_heavy", reports)
    fix_all_atoms(project)

    for stage, phase_index, suffix, bound in (
        (2, 0, "srwo4", 0.010),
        (3, 1, "wo3", 0.010),
        (4, 2, "sr3w2o9", 0.015),
    ):
        release(project, phase_index, {"O"}, bound)
        refine(project, f"0{stage}_oxygen_{suffix}", reports)
        fix_all_atoms(project)

    # Final linear re-equilibration with all coordinates fixed.
    refine(project, "05_linear_rebalance", reports, cycles=10)


if __name__ == "__main__":
    main()
