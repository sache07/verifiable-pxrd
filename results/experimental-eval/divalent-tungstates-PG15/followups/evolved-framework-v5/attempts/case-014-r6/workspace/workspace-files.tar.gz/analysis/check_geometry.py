"""Report compact cation--oxygen and oxygen--oxygen geometry from CIF files."""

from __future__ import annotations

import argparse
from pathlib import Path

from pymatgen.core import Structure


def element(site) -> str:
    return site.specie.symbol


def unique_rows(rows: list[tuple[float, ...]], tolerance: float = 0.003) -> list[tuple[float, ...]]:
    kept: list[tuple[float, ...]] = []
    for row in rows:
        if not any(len(row) == len(other) and max(abs(a - b) for a, b in zip(row, other)) < tolerance for other in kept):
            kept.append(row)
    return kept


def describe(path: Path) -> None:
    structure = Structure.from_file(path)
    print(f"\n{path}")
    print(f"formula={structure.composition.reduced_formula} volume={structure.volume:.3f}")
    for cation, count, cutoff in (("W", 6, 3.0), ("Sr", 10, 3.6)):
        rows: list[tuple[float, ...]] = []
        for site in structure:
            if element(site) != cation:
                continue
            distances = sorted(
                float(neighbor.nn_distance)
                for neighbor in structure.get_neighbors(site, cutoff)
                if element(neighbor) == "O"
            )
            rows.append(tuple(round(value, 4) for value in distances[:count]))
        for index, row in enumerate(unique_rows(rows)):
            print(f"{cation}-O[{index}]={row}")
    oo = []
    for site in structure:
        if element(site) != "O":
            continue
        oo.extend(
            float(neighbor.nn_distance)
            for neighbor in structure.get_neighbors(site, 2.5)
            if element(neighbor) == "O" and neighbor.nn_distance > 1e-5
        )
    print(f"minimum_O-O={min(oo) if oo else None}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cifs", nargs="+")
    args = parser.parse_args()
    for item in args.cifs:
        describe(Path(item))


if __name__ == "__main__":
    main()
