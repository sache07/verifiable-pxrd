"""Add isotropic microstrain one accepted phase at a time."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/profile_sequential/04_sizes_validated.gpx"
OUT = ROOT / "checkpoints/strain_sequential"


def summarize(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    masses, phases = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        phases.append({
            "name": phase.name,
            "size_um": float(hap["Size"][1][0]),
            "microstrain_ppm": float(hap["Mustrain"][1][0]),
            "scale": float(hap["Scale"][0]),
        })
    total = sum(max(0.0, value) for value in masses)
    for row, mass in zip(phases, masses):
        row["weight_fraction"] = max(0.0, mass) / total
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": label,
        "rwp_percent": float(hist.get_wR()),
        "gof": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
        "phases": phases,
        "vary_list": [str(value) for value in (project.get_VaryList() or [])],
    }


def checkpoint(project: G2.G2Project, label: str, reports: list[dict]) -> None:
    project.save(str(OUT / f"{label}.gpx"))
    report = summarize(project, label)
    reports.append(report)
    (OUT / "stages.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps(report, indent=2), flush=True)
    project.save(str(OUT / "working.gpx"))


def refine(project: G2.G2Project, label: str, reports: list[dict], cycles: int = 7) -> None:
    print(f"starting {label}", flush=True)
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    checkpoint(project, label, reports)


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    project.save(str(OUT / "working.gpx"))
    reports: list[dict] = []

    for index, suffix in enumerate(("srwo4", "wo3", "sr3w2o9")):
        phase = project.phases()[index]
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 500.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")
        refine(project, f"0{index + 1}_strain_{suffix}", reports)
        hap["Mustrain"][2][0] = False

    refine(project, "04_strain_validated", reports)


if __name__ == "__main__":
    main()
