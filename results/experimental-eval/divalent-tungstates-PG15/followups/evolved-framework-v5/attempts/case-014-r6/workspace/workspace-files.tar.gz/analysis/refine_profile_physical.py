"""Replace the provisional peak shape with bounded physical profile terms."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/coordinates_final/04_srwo4_oxygen_validated.gpx"
OUT = ROOT / "checkpoints/profile_physical"


def values(project: G2.G2Project) -> dict:
    hist = project.histograms()[0]
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "size_um": float(hap["Size"][1][0]),
                "microstrain_ppm": float(hap["Mustrain"][1][0]),
                "preferred_orientation": {
                    "ratio": float(hap["Pref.Ori."][1]),
                    "axis": list(map(int, hap["Pref.Ori."][3])),
                },
            }
        )
    total = sum(max(0.0, value) for value in masses)
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = max(0.0, mass) / total
    return {
        "instrument": {
            key: float(item[1])
            for key, item in hist.InstrumentParameters.items()
            if isinstance(item, list) and len(item) > 1 and isinstance(item[1], (int, float, np.number))
        },
        "sample": {
            key: float(item[0])
            for key, item in hist.SampleParameters.items()
            if isinstance(item, list) and len(item) > 1 and isinstance(item[0], (int, float, np.number))
        },
        "phases": phases,
    }


def save(project: G2.G2Project, label: str, reports: list[dict]) -> None:
    project.save(str(OUT / f"{label}.gpx"))
    hist = project.histograms()[0]
    for index, phase in enumerate(project.phases()):
        phase.export_CIF(str(OUT / f"{label}_phase{index}.cif"))
    arrays = [np.asarray(value, float) for value in hist.data["data"][1]]
    np.savetxt(
        OUT / f"{label}_profile.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[4], arrays[5])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference",
        comments="",
    )
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    report = {
        "stage": label,
        "rwp_percent": float(hist.get_wR()),
        "gof": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
        "vary_list": [str(value) for value in (project.get_VaryList() or [])],
        **values(project),
    }
    reports.append(report)
    (OUT / "stages.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    project.save(str(OUT / "working.gpx"))


def refine(project: G2.G2Project, label: str, reports: list[dict], cycles: int = 18) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    save(project, label, reports)


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")

        # Start from the interior of the known laboratory ranges. The inactive
        # strain value is exactly zero until that term is explicitly released.
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Size"][1][1] = 0.5
        hap["Size"][1][2] = 1.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][1][2] = 1.0

    # The inventory search used W=80 as a permissive provisional width. Reset
    # to the physical laboratory envelope before adding phase-specific terms.
    for key, value in (("U", 10.0), ("W", 40.0), ("X", 2.0), ("SH/L", 0.02)):
        hist.InstrumentParameters[key][1] = value
    project.save(str(OUT / "working.gpx"))
    reports: list[dict] = []

    # Phase sizes first, with common instrumental terms fixed.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:{hist.id}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:{hist.id}:Size;i")
    refine(project, "01_sizes", reports)

    # Add isotropic strain independently for each phase; zero remains allowed.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 500.0
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")
    refine(project, "02_sizes_strain", reports)

    # Release the common instrument profile only after phase broadening is
    # present, keeping every term inside the stated laboratory ranges.
    for key, low, high in (
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
    ):
        hist.InstrumentParameters[key][2] = True
        project.set_Controls("parmMin", low, variable=f":{hist.id}:{key}")
        project.set_Controls("parmMax", high, variable=f":{hist.id}:{key}")
    refine(project, "03_instrument", reports, cycles=24)

    # Freeze shape terms and recalculate once to ensure the checkpoint arrays
    # exactly represent the accepted bounded values.
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    refine(project, "04_profile_validated", reports, cycles=12)


if __name__ == "__main__":
    main()
