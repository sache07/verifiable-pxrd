"""Refine one isotropic displacement parameter per accepted phase."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/texture_screen/p2_111.gpx"
OUT = ROOT / "checkpoints/phase_uiso"


def summary(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    masses, rows = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        rows.append({
            "name": phase.name,
            "scale": float(hap["Scale"][0]),
            "uiso_A2": [float(atom.uiso) for atom in phase.atoms()],
        })
    total = sum(max(0.0, value) for value in masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = max(0.0, mass) / total
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": label,
        "rwp_percent": float(hist.get_wR()),
        "gof": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
        "phases": rows,
        "vary_list": [str(value) for value in (project.get_VaryList() or [])],
    }


def save(project: G2.G2Project, label: str, reports: list[dict]) -> None:
    project.save(str(OUT / f"{label}.gpx"))
    item = summary(project, label)
    reports.append(item)
    (OUT / "stages.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps(item, indent=2), flush=True)
    project.save(str(OUT / "working.gpx"))


def refine(project: G2.G2Project, label: str, reports: list[dict], cycles: int) -> None:
    print(f"starting {label}", flush=True)
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    save(project, label, reports)


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    # Redirect any indexing save triggered while constraints are built away
    # from the accepted source checkpoint.
    project.save(str(OUT / "working.gpx"))
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
        atoms = phase.atoms()
        for atom_index, atom in enumerate(atoms):
            atom.uiso = 0.008
            atom.refinement_flags = "U"
            variable = f"{phase.id}::AUiso:{atom_index}"
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
        if len(atoms) > 1:
            project.add_EquivConstr(
                tuple(f"{phase.id}::AUiso:{index}" for index in range(len(atoms))),
                reloadIdx=True,
            )
    project.save(str(OUT / "working.gpx"))
    reports: list[dict] = []
    refine(project, "01_phase_uiso", reports, cycles=10)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    refine(project, "02_uiso_validated", reports, cycles=8)


if __name__ == "__main__":
    main()
