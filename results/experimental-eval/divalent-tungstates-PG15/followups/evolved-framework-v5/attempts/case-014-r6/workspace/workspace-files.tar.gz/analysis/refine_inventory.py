"""Refine the accepted three-phase inventory through cell/calibration stages."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/calibrated_tests/sr3w2o9_metric/04_candidate_cell.gpx"
OUT = ROOT / "checkpoints/inventory"


def report(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(0.0, mass_scale))
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
            }
        )
    total = sum(masses)
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / total
    return {
        "stage": label,
        "rwp_percent": float(hist.get_wR()),
        "instrument": {
            key: float(value[1])
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list)
            and len(value) > 1
            and isinstance(value[1], (int, float, np.number))
        },
        "sample": {
            key: float(value[0])
            for key, value in hist.SampleParameters.items()
            if isinstance(value, list)
            and len(value) > 1
            and isinstance(value[0], (int, float, np.number))
        },
        "phases": phases,
        "vary_list": [str(v) for v in (project.get_VaryList() or [])],
    }


def save_outputs(project: G2.G2Project, label: str) -> None:
    project.save(str(OUT / f"{label}.gpx"))
    hist = project.histograms()[0]
    arrays = [np.asarray(v, float) for v in hist.data["data"][1]]
    np.savetxt(
        OUT / f"{label}_profile.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[4], arrays[5])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference",
        comments="",
    )
    for index, phase in enumerate(project.phases()):
        phase.export_CIF(str(OUT / f"{label}_phase{index}.cif"))


def refine(project: G2.G2Project, label: str, reports: list[dict], cycles: int = 10) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    save_outputs(project, label)
    reports.append(report(project, label))
    (OUT / "stages.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps(reports[-1], indent=2))


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(OUT / "working.gpx"))
    clear_all_flags(project)
    hist = project.histograms()[0]
    reports: list[dict] = []

    # Re-establish only the linear terms on a freshly regenerated profile.
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    refine(project, "01_scales_background", reports)

    # Refine metrics with a common zero while specimen displacement remains
    # fixed, then release the physically distinct cosine-dependent shift.
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    hist.InstrumentParameters["Zero"][2] = True
    project.set_Controls("parmMin", -0.3, variable=f":{hist.id}:Zero")
    project.set_Controls("parmMax", 0.3, variable=f":{hist.id}:Zero")
    refine(project, "02_cells_zero", reports, cycles=12)

    hist.SampleParameters["Shift"][1] = True
    project.set_Controls("parmMin", -800.0, variable=f":{hist.id}:Shift")
    project.set_Controls("parmMax", 800.0, variable=f":{hist.id}:Shift")
    refine(project, "03_cells_zero_shift", reports, cycles=12)


if __name__ == "__main__":
    main()
