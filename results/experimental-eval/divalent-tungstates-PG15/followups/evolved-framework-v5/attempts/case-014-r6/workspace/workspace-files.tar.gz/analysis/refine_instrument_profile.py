"""Refine the common instrument profile after phase broadening is established."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/strain_sequential/04_strain_validated.gpx"
OUT = ROOT / "checkpoints/instrument_profile"


def summary(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    masses, phases = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        phases.append({
            "name": phase.name,
            "size_um": float(hap["Size"][1][0]),
            "microstrain_ppm": float(hap["Mustrain"][1][0]),
            "scale": float(hap["Scale"][0]),
        })
    total = sum(max(0.0, value) for value in masses)
    for row, mass in zip(phases, masses):
        row["weight_fraction"] = max(0.0, mass) / total
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": label,
        "rwp_percent": float(hist.get_wR()),
        "gof": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
        "instrument": {key: float(value[1]) for key, value in hist.InstrumentParameters.items() if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (int, float, np.number))},
        "phases": phases,
        "vary_list": [str(value) for value in (project.get_VaryList() or [])],
    }


def save(project: G2.G2Project, label: str, reports: list[dict]) -> None:
    project.save(str(OUT / f"{label}.gpx"))
    report = summary(project, label)
    reports.append(report)
    (OUT / "stages.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps(report, indent=2), flush=True)
    project.save(str(OUT / "working.gpx"))


def refine(project: G2.G2Project, label: str, reports: list[dict], cycles: int) -> None:
    print(f"starting {label}", flush=True)
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    save(project, label, reports)


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    for key, low, high in (
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
    ):
        hist.InstrumentParameters[key][2] = True
        project.set_Controls("parmMin", low, variable=f":{hist.id}:{key}")
        project.set_Controls("parmMax", high, variable=f":{hist.id}:{key}")
    project.save(str(OUT / "working.gpx"))
    reports: list[dict] = []
    refine(project, "01_instrument", reports, cycles=12)
    for key in ("U", "W", "X", "SH/L"):
        hist.InstrumentParameters[key][2] = False
    refine(project, "02_instrument_validated", reports, cycles=7)


if __name__ == "__main__":
    main()
