"""Re-optimize accepted phase-size/strain terms after intensity corrections."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/uiso_grid/candidate_2.gpx"
OUT = ROOT / "checkpoints/profile_reoptimized"


def summary(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    masses, rows = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        rows.append({
            "name": phase.name,
            "scale": float(hap["Scale"][0]),
            "size_um": float(hap["Size"][1][0]),
            "microstrain_ppm": float(hap["Mustrain"][1][0]),
            "uiso_A2": sorted(set(round(float(atom.uiso), 8) for atom in phase.atoms())),
            "md_ratio": float(hap["Pref.Ori."][1]),
            "md_axis": list(map(int, hap["Pref.Ori."][3])),
        })
    total = sum(max(0.0, value) for value in masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = max(0.0, mass) / total
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": label,
        "rwp_percent": float(hist.get_wR()),
        "gof": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
        "phases": rows,
        "vary_list": [str(value) for value in (project.get_VaryList() or [])],
    }


def save(project: G2.G2Project, label: str, reports: list[dict]) -> None:
    project.save(str(OUT / f"{label}.gpx"))
    item = summary(project, label)
    reports.append(item)
    (OUT / "stages.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps(item, indent=2), flush=True)
    project.save(str(OUT / "working.gpx"))


def refine(project: G2.G2Project, label: str, reports: list[dict], cycles: int) -> None:
    print(f"starting {label}", flush=True)
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    save(project, label, reports)


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    project.save(str(OUT / "working.gpx"))
    reports: list[dict] = []

    for index, suffix in enumerate(("srwo4", "wo3", "sr3w2o9")):
        phase = project.phases()[index]
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:{hist.id}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:{hist.id}:Size;i")
        refine(project, f"0{index + 1}_size_{suffix}_raw", reports, cycles=6)
        hap["Size"][2][0] = False
        refine(project, f"0{index + 1}_size_{suffix}_validated", reports, cycles=4)

    phase = project.phases()[2]
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][2][0] = True
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")
    refine(project, "07_sr3w2o9_strain_raw", reports, cycles=6)
    hap["Mustrain"][2][0] = False
    refine(project, "08_profile_validated", reports, cycles=5)


if __name__ == "__main__":
    main()
