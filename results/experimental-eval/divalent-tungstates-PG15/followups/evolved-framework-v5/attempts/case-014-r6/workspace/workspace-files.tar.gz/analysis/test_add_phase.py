"""Insert one candidate into a calibrated multiphase checkpoint.

Candidate scale is established with every positional parameter fixed. This
avoids the singular cell steps that occur when a poor initial scale has already
been driven to zero.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def source_path(value: str) -> Path:
    if value.isdigit() and len(value) == 7:
        return COD / value[0] / value[1:3] / value[3:5] / f"{value}.cif"
    return (ROOT / value).resolve()


def clear_all_flags(project: G2.G2Project) -> None:
    for hist in project.histograms():
        hist.Background[0][1] = False
        for value in hist.InstrumentParameters.values():
            if isinstance(value, list) and len(value) > 2:
                value[2] = False
        for value in hist.SampleParameters.values():
            if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
                value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        for hap in phase.data.get("Histograms", {}).values():
            hap["Scale"][1] = False
            hap["Extinction"][1] = False
            hap["Pref.Ori."][2] = False
            hap["Size"][2] = [False] * len(hap["Size"][2])
            hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
            if len(hap["Mustrain"]) > 5:
                hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def run_refinement(project: G2.G2Project, outdir: Path, label: str, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    project.save(str(outdir / f"{label}.gpx"))


def summary(project: G2.G2Project, outdir: Path, label: str) -> dict:
    hist = project.histograms()[0]
    phases = []
    mass_scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        mass_scales.append(max(0.0, float(mass_scale)))
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell_mass": float(phase.data["General"]["Mass"]),
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
            }
        )
    total = sum(mass_scales)
    for phase, value in zip(phases, mass_scales):
        phase["weight_fraction"] = value / total if total else 0.0
    result = {
        "label": label,
        "rwp_percent": float(hist.get_wR()),
        "residuals": {
            str(key): float(value)
            for key, value in hist.residuals.items()
            if isinstance(value, (int, float, np.number))
        },
        "phases": phases,
    }
    return result


def export_profile(project: G2.G2Project, path: Path) -> None:
    values = [np.asarray(v, float) for v in project.histograms()[0].data["data"][1]]
    np.savetxt(
        path,
        np.column_stack((values[0], values[1], values[3], values[4], values[5])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference",
        comments="",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base_gpx")
    parser.add_argument("candidate")
    parser.add_argument("outdir")
    parser.add_argument("--initial-scale", type=float, default=0.5)
    parser.add_argument("--refine-cell", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    outdir = (ROOT / args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str((ROOT / args.base_gpx).resolve()))
    project.save(str(outdir / "00_base_copy.gpx"))
    clear_all_flags(project)
    hist = project.histograms()[0]
    candidate = project.add_phase(
        str(source_path(args.candidate)),
        phasename=f"candidate_{Path(args.candidate).stem}",
        histograms=[hist],
        fmthint="CIF",
    )
    clear_all_flags(project)
    candidate.data["Histograms"][hist.name]["Scale"] = [args.initial_scale, True]
    project.set_Controls("parmMin", 0.0, variable=f"{candidate.id}:{hist.id}:Scale")
    project.save(str(outdir / "01_inserted.gpx"))
    run_refinement(project, outdir, "02_candidate_scale")
    reports = [summary(project, outdir, "candidate_scale")]

    # Re-equilibrate only linear intensity terms after the candidate is known
    # to have a stable positive scale.
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    run_refinement(project, outdir, "03_all_scales_background")
    reports.append(summary(project, outdir, "all_scales_background"))

    if args.refine_cell and candidate.data["Histograms"][hist.name]["Scale"][0] > 1e-5:
        candidate.data["General"]["Cell"][0] = True
        run_refinement(project, outdir, "04_candidate_cell", cycles=6)
        reports.append(summary(project, outdir, "candidate_cell"))

    export_profile(project, outdir / "profile.csv")
    (outdir / "summary.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps(reports, indent=2))


if __name__ == "__main__":
    main()
