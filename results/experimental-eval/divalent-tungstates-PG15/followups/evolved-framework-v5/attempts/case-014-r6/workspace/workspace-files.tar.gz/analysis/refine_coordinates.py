"""Test staged atomic-coordinate refinement for the accepted inventory.

The metric, calibration and profile are fixed at the best inventory checkpoint.
Only scales/background remain active while heavy-atom coordinates are released
first, followed by oxygen coordinates one phase at a time. Each stage is saved
so an unphysical or unstable step can be rolled back without losing prior work.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from test_add_phase import clear_all_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checkpoints/inventory/01_scales_background.gpx"
OUT = ROOT / "checkpoints/coordinates"


def phase_snapshot(project: G2.G2Project, hist: G2.G2PwdrData) -> list[dict]:
    rows: list[dict] = []
    mass_scales: list[float] = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scales.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": [float(v) for v in atom.coordinates],
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    total = sum(max(0.0, value) for value in mass_scales)
    for row, value in zip(rows, mass_scales):
        row["weight_fraction"] = max(0.0, value) / total
    return rows


def save_stage(project: G2.G2Project, label: str, reports: list[dict]) -> None:
    project.save(str(OUT / f"{label}.gpx"))
    hist = project.histograms()[0]
    for index, phase in enumerate(project.phases()):
        phase.export_CIF(str(OUT / f"{label}_phase{index}.cif"))
    values = [np.asarray(v, float) for v in hist.data["data"][1]]
    np.savetxt(
        OUT / f"{label}_profile.csv",
        np.column_stack((values[0], values[1], values[3], values[4], values[5])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference",
        comments="",
    )
    report = {
        "stage": label,
        "rwp_percent": float(hist.get_wR()),
        "residuals": {
            str(key): float(value)
            for key, value in hist.residuals.items()
            if isinstance(value, (int, float, np.number))
        },
        "vary_list": [str(v) for v in (project.get_VaryList() or [])],
        "phases": phase_snapshot(project, hist),
    }
    reports.append(report)
    (OUT / "stages.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps(report, indent=2))


def refine(project: G2.G2Project, label: str, reports: list[dict], cycles: int = 16) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    save_stage(project, label, reports)


def release_atoms(phase: G2.G2Phase, oxygen: bool) -> None:
    for atom in phase.atoms():
        if (atom.element == "O") == oxygen:
            atom.refinement_flags = "X"


def main() -> None:
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")

    reports: list[dict] = []
    save_stage(project, "00_fixed_coordinates", reports)

    # Heavy-atom positions are released together before oxygen positions.
    for phase in project.phases():
        release_atoms(phase, oxygen=False)
    refine(project, "01_heavy_coordinates", reports)

    # Oxygen sublattices are added incrementally so that each topology can be
    # checked for sensible W--O/Sr--O geometry before accepting the next step.
    for phase_index, suffix in ((0, "srwo4"), (1, "wo3"), (2, "sr3w2o9")):
        release_atoms(project.phases()[phase_index], oxygen=True)
        refine(project, f"0{phase_index + 2}_oxygen_{suffix}", reports)


if __name__ == "__main__":
    main()
