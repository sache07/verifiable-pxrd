"""Build a staged GSAS-II trial from selected frozen-COD records.

This is intentionally conservative: atomic coordinates and phase-specific
broadening remain fixed. It is used to establish the phase inventory before
the final structural refinement.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(record: str) -> Path:
    if not (record.isdigit() and len(record) == 7):
        return Path(record).resolve()
    return COD / record[0] / record[1:3] / record[3:5] / f"{record}.cif"


def write_instrument(path: Path) -> None:
    path.write_text(
        "# GSAS-II initial Cu K-alpha laboratory profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )


def snapshot(project: G2.G2Project, outdir: Path, label: str) -> None:
    project.save(str(outdir / f"{label}.gpx"))


def refine(project: G2.G2Project, outdir: Path, label: str, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    snapshot(project, outdir, label)


def summarize(project: G2.G2Project, outdir: Path, records: list[str]) -> dict:
    hist = project.histograms()[0]
    instrument = {
        key: value[1]
        for key, value in hist.InstrumentParameters.items()
        if isinstance(value, list) and len(value) >= 2
    }
    sample = {
        key: value[0]
        for key, value in hist.SampleParameters.items()
        if isinstance(value, list) and len(value) >= 2
    }
    phases = []
    masses = []
    for record, phase in zip(records, project.phases()):
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(mass_scale)
        phases.append(
            {
                "record": record,
                "name": phase.name,
                "mass": float(phase.data["General"]["Mass"]),
                "scale": float(hap["Scale"][0]),
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
            }
        )
    total = sum(max(0.0, value) for value in masses)
    for phase, value in zip(phases, masses):
        phase["weight_fraction"] = max(0.0, value) / total if total else 0.0
    arrays = [np.asarray(value, dtype=float) for value in hist.data["data"][1]]
    x, obs, weight, calc, background, difference = arrays[:6]
    np.savetxt(
        outdir / "profile.csv",
        np.column_stack((x, obs, calc, background, difference)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference",
        comments="",
    )
    residuals = {}
    for key, value in hist.residuals.items():
        try:
            residuals[key] = float(value)
        except (TypeError, ValueError):
            residuals[key] = str(value)
    summary = {
        "records": records,
        "histogram": hist.name,
        "residuals": residuals,
        "instrument": instrument,
        "sample": sample,
        "phases": phases,
        "vary_list": [str(value) for value in (project.get_VaryList() or [])],
    }
    (outdir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("outdir")
    parser.add_argument("records", nargs="+")
    args = parser.parse_args()
    outdir = (ROOT / args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")

    inst = outdir / "initial.instprm"
    write_instrument(inst)
    project = G2.G2Project(newgpx=str(outdir / "working.gpx"))
    hist = project.add_powder_histogram(str(ROOT / "inputs" / "pattern.csv"), str(inst))
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    phases = []
    for record in args.records:
        phase = project.add_phase(
            str(cod_path(record)),
            phasename=f"phase_{record}",
            histograms=[hist],
            fmthint="CIF",
        )
        phase.data["Histograms"][hist.name]["Scale"] = [2.0, True]
        phases.append(phase)

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 15,
                "coeffs": [700.0] + [0.0] * 14,
                "refine": True,
            }
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    snapshot(project, outdir, "00_initial")
    refine(project, outdir, "01_scale_background")

    # Peak positions: first refine each metric and a common angular zero, then
    # add the physically distinct Bragg-Brentano specimen-height term.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("parmMin", -0.3, variable=f":{hist.id}:Zero")
    project.set_Controls("parmMax", 0.3, variable=f":{hist.id}:Zero")
    refine(project, outdir, "02_cells_zero")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.set_Controls("parmMin", -1000.0, variable=f":{hist.id}:Shift")
    project.set_Controls("parmMax", 1000.0, variable=f":{hist.id}:Shift")
    refine(project, outdir, "03_shift")

    # Common instrumental peak shape only. Phase-specific terms are deferred
    # until all coherent residual families are assigned.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for variable, low, high in (
        ("U", 0.0, 80.0),
        ("W", 0.0, 80.0),
        ("X", 0.01, 12.0),
        ("SH/L", 0.001, 0.2),
    ):
        project.set_Controls("parmMin", low, variable=f":{hist.id}:{variable}")
        project.set_Controls("parmMax", high, variable=f":{hist.id}:{variable}")
    refine(project, outdir, "04_profile", cycles=12)

    summary = summarize(project, outdir, args.records)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
