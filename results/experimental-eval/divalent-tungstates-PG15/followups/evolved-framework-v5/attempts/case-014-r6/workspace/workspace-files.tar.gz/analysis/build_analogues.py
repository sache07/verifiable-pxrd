"""Create explicitly documented analogue-derived candidates for residual tests."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = ROOT / "candidates"


def cod_path(record: str) -> Path:
    return COD / record[0] / record[1:3] / record[3:5] / f"{record}.cif"


def make(
    filename: str,
    parent: str,
    substitutions: dict[str, str],
    linear_scale: float,
    rationale: str,
) -> None:
    structure = Structure.from_file(cod_path(parent))
    structure.replace_species(substitutions)
    structure.scale_lattice(structure.volume * linear_scale**3)
    path = OUT / filename
    CifWriter(structure, symprec=1e-4, significant_figures=10).write_file(path)
    provenance = {
        "model_basis": "analogue_derived",
        "parent_cod_id": parent,
        "parent_path": str(cod_path(parent)),
        "substitutions": substitutions,
        "initial_linear_cell_scale": linear_scale,
        "rationale": rationale,
    }
    path.with_suffix(".provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")


OUT.mkdir(parents=True, exist_ok=True)
for scale in (1.03, 1.05, 1.07):
    make(
        f"Sr3WO6_from_Ca3WO6_scale{int(round(scale * 100)):03d}.cif",
        "1563081",
        {"Ca": "Sr"},
        scale,
        "P21/n A3WO6 topology tested against the unassigned Sr-rich residual family.",
    )

make(
    "Sr3WO6_from_Ba3WO6_scale096.cif",
    "1534803",
    {"Ba": "Sr"},
    0.96,
    "Alternative A3WO6 topology retained as a topology control.",
)
make(
    "Sr2WO5_from_Pb2MoO5_scale092.cif",
    "7220560",
    {"Pb": "Sr", "Mo": "W"},
    0.92,
    "A2BO5 topology tested as the other simple Sr-rich phase balancing residual WO3.",
)
