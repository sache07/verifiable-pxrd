#!/usr/bin/env python3
"""Screen physically plausible residual phases from a common checkpoint."""

from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "checkpoint_03_cells.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = {
    "litharge_9012700": ("PbO_litharge", "9012700"),
    "raspite_9007617": ("PbWO4_raspite", "9007617"),
    "minium_9012124": ("Pb3O4_tetragonal", "9012124"),
    "minium_9003043": ("Pb3O4_orthorhombic", "9003043"),
}


def run_branch(tag, phase_name, cod_id):
    out = ROOT / f"branch_{tag}.gpx"
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(out))
    hist = project.histogram(0)
    # Remove the redundant histogram scale that was active in the coarse model.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    phase = project.add_phase(
        str(cod_cif(cod_id)),
        phasename=phase_name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.getHAPvalues(hist.name)
    hap["Scale"][0] = 0.1
    phase.setSampleProfile(hist.name, "size", "isotropic", 1.0, LGmix=0.5)
    phase.setSampleProfile(hist.name, "microstrain", "isotropic", 500.0, LGmix=0.5)
    phase.set_HAP_refinements({"Scale": True}, [hist])
    phase.set_refinements({"Cell": True})
    project.save()
    # Reiterate because the starting checkpoint had not fully converged.
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save()
    result = {
        "branch": tag,
        "Rwp_percent": hist.get_wR(),
        "new_phase_scale": phase.getHAPvalues(hist.name)["Scale"][0],
        "new_phase_cell": phase.get_cell(),
        "all_scales": {
            p.name: p.getHAPvalues(hist.name)["Scale"][0]
            for p in project.phases()
        },
    }
    print(json.dumps(result, default=str))
    return result


def main():
    results = []
    for tag, (phase_name, cod_id) in CANDIDATES.items():
        results.append(run_branch(tag, phase_name, cod_id))
    print(json.dumps(results, indent=2, default=str))


if __name__ == "__main__":
    main()
