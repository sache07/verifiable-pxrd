#!/usr/bin/env python3
"""Final residual-phase audit from the best physical four-phase checkpoint."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "physical_final_SHL.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = [
    ("Pb3O4_tetragonal_9012124", "Pb3O4_tetragonal", "9012124"),
    ("Pb3O4_orthorhombic_9003043", "Pb3O4_orthorhombic", "9003043"),
    ("Pb2O3_2311012", "Pb2O3", "2311012"),
    ("PbO2_rutile_9007543", "PbO2_rutile", "9007543"),
]


def prepare(project):
    hist = project.histogram(0)
    hist.clear_refinements({
        "Instrument Parameters": [
            "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."
        ],
        "Sample Parameters": [
            "Shift", "Transparency", "SurfRoughA", "SurfRoughB"
        ],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_refinements({
            "Atoms": [atom.label for atom in phase.atoms()]
        })
        phase.clear_HAP_refinements({
            "Size": True, "Mustrain": True, "Pref.Ori.": True
        })
    project.set_Frozen()
    project.set_Controls("cycles", 7)


def run_one(tag, name, cod_id):
    outfile = ROOT / f"final_residual_{tag}.gpx"
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(outfile))
    prepare(project)
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cod_cif(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
    )
    phase.setSampleProfile(hist.name, "size", "isotropic", 1.0, LGmix=0.5)
    phase.setSampleProfile(
        hist.name, "microstrain", "isotropic", 500.0, LGmix=0.5
    )
    phase.getHAPvalues(hist.name)["Scale"][0] = 0.05
    phase.set_HAP_refinements({"Scale": True}, [hist])
    phase_index = len(project.phases()) - 1
    project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Scale")
    project.refine(makeBack=False)
    fixed = {
        "Rwp": hist.get_wR(),
        "scale": phase.getHAPvalues(hist.name)["Scale"][0],
        "cell": phase.get_cell(),
    }
    phase.set_refinements({"Cell": True})
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save()
    result = {
        "tag": tag,
        "fixed_cell": fixed,
        "refined_cell": {
            "Rwp": hist.get_wR(),
            "scale": phase.getHAPvalues(hist.name)["Scale"][0],
            "cell": phase.get_cell(),
        },
        "mass_per_cell": phase.data["General"].get("Mass"),
        "composition": phase.composition,
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(result, default=str))
    return result


def main():
    results = [run_one(*candidate) for candidate in CANDIDATES]
    (ROOT / "final_residual_tests.json").write_text(
        json.dumps(results, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
