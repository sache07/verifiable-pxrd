#!/usr/bin/env python3
"""Export all requested deliverables from final.gpx without re-refinement."""

from pathlib import Path
import csv
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"

PHASE_OUTPUTS = [
    ("PbWO4 (scheelite)", "PbWO4", "phase_1_PbWO4_scheelite.cif", "9009811"),
    ("PbO (massicot)", "PbO", "phase_2_PbO_massicot.cif", "2310433"),
    ("WO3 (monoclinic)", "WO3", "phase_3_WO3_monoclinic.cif", "2311041"),
    ("PbO (litharge)", "PbO", "phase_4_PbO_litharge.cif", "9012700"),
]


def main():
    project = G2sc.G2Project(gpxfile=str(PROJECT))
    hist = project.histogram(0)
    phases = project.phases()
    if len(phases) != len(PHASE_OUTPUTS):
        raise RuntimeError(f"Expected four phases, found {len(phases)}")
    if project.get_Frozen():
        raise RuntimeError(f"Final project contains frozen variables: {project.get_Frozen()}")

    fractions = hist.ComputeMassFracs()
    phase_results = []
    for phase, (display_name, formula, filename, cod_id) in zip(phases, PHASE_OUTPUTS):
        phase.export_CIF(str(ROOT / filename), quickmode=True)
        fraction, sigma = fractions[phase.name]
        cell, cell_sigma = phase.get_cell_and_esd()
        phase_results.append({
            "name": display_name,
            "formula": formula,
            "gsas_phase_name": phase.name,
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "reference_cod_id": cod_id,
            "cif_path": filename,
            "weight_fraction": fraction,
            "weight_fraction_std_uncertainty": sigma,
            "cell": cell,
            "cell_std_uncertainty": cell_sigma,
        })

    arrays = hist.data["data"][1]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "difference_intensity",
        ])
        for two_theta, observed, calculated, difference in zip(
            arrays[0], arrays[1], arrays[3], arrays[5]
        ):
            writer.writerow([
                f"{float(two_theta):.8f}",
                f"{float(observed):.8f}",
                f"{float(calculated):.8f}",
                f"{float(difference):.8f}",
            ])

    residuals = hist.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "project_path": "final.gpx",
        "histogram": hist.name,
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phase_results,
        "fit_statistics": {
            "Rwp_percent": residuals["wR"],
            "Rp_percent": residuals["R"],
            "Rexp_percent": residuals["wRmin"],
            "goodness_of_fit": rvals["GOF"],
            "chi_squared": rvals["chisq"],
            "background_Rp_percent": residuals["Rb"],
            "background_Rwp_percent": residuals["wRb"],
            "n_observations": rvals["Nobs"],
            "n_variables": rvals["Nvars"],
            "converged": bool(rvals["converged"]),
            "max_shift_over_sigma": rvals["Max shft/sig"],
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
