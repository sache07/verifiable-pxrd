#!/usr/bin/env python3
"""Build and stage-refine the chemically ordinary three-phase model."""

from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = [
    ("PbWO4_scheelite", "9009811"),
    ("PbO_massicot", "2310433"),
    ("WO3_monoclinic", "1528915"),
]


def fit_summary(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    out = {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "sample": {k: v[0] for k, v in sample.items() if isinstance(v, list) and len(v) > 1},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    print(json.dumps(out, indent=2, default=str))
    return out


def refine(project, label):
    project.refine(makeBack=False)
    fit_summary(project, label)
    project.save(ROOT / f"checkpoint_{label}.gpx")


def main():
    gpx = ROOT / "initial_three_phase.gpx"
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.set_refinements({
        "Limits": [10.01, 99.99],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 12,
        },
    })
    for name, cod_id in PHASES:
        project.add_phase(
            str(cod_cif(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )

    # Start all phases with positive scales and physically broad peaks.
    start_scales = [1.0, 0.15, 0.15]
    for phase, scale in zip(project.phases(), start_scales):
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"][0] = scale
        phase.setSampleProfile(hist.name, "size", "isotropic", 1.0, LGmix=0.5)
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", 500.0, LGmix=0.5)
        phase.set_HAP_refinements({"Scale": True}, [hist])

    project.save()
    refine(project, "01_background_scales")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "02_zero")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, "03_cells")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "04_shift")

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]})
    refine(project, "05_instrument_profile")

    project.save(ROOT / "three_phase_refined.gpx")


if __name__ == "__main__":
    main()
