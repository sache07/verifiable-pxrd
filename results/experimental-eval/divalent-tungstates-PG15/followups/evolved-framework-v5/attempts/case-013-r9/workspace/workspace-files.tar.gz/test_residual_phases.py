#!/usr/bin/env python3
"""Screen a short chemistry-supported list against the four-phase residual."""

from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "physical_09_polarization.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = {
    "WO2_rutile_5910153": ("WO2_rutile", "5910153"),
    "WO2_monoclinic_1548686": ("WO2_monoclinic", "1548686"),
    "Pb2O3_2311012": ("Pb2O3", "2311012"),
    "PbO2_rutile_9007543": ("PbO2_rutile", "9007543"),
    "Pb3O4_9012124": ("Pb3O4", "9012124"),
    "PbWO4_raspite_9007617": ("PbWO4_raspite", "9007617"),
    "W3O8_2101050": ("W3O8", "2101050"),
}


def clear_non_scale_flags(project):
    hist = project.histogram(0)
    # Keep background and phase scales active, but isolate the candidate cell test.
    hist.clear_refinements({"Instrument Parameters": [
        "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."
    ]})
    hist.clear_refinements({"Sample Parameters": [
        "Shift", "Transparency", "SurfRoughA", "SurfRoughB"
    ]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    project.set_Frozen()


def run_branch(tag, phase_name, cod_id):
    out = ROOT / f"residual_{tag}.gpx"
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(out))
    project.set_Controls("cycles", 5)
    clear_non_scale_flags(project)
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cod_cif(cod_id)), phasename=phase_name,
        histograms=[hist], fmthint="CIF"
    )
    hap = phase.getHAPvalues(hist.name)
    hap["Scale"][0] = 0.05
    phase.setSampleProfile(hist.name, "size", "isotropic", 1.0, LGmix=0.5)
    phase.setSampleProfile(hist.name, "microstrain", "isotropic", 500.0, LGmix=0.5)
    phase.set_HAP_refinements({"Scale": True}, [hist])
    phase_index = len(project.phases()) - 1
    project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Scale")
    project.save()

    # First establish whether the unmodified reference has a stable positive scale.
    project.refine(makeBack=False)
    rwp_fixed_cell = hist.get_wR()
    scale_fixed_cell = phase.getHAPvalues(hist.name)["Scale"][0]

    # Then allow only the new cell to move. Large or invalid changes reject the branch.
    phase.set_refinements({"Cell": True})
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save()
    result = {
        "branch": tag,
        "Rwp_fixed_cell": rwp_fixed_cell,
        "scale_fixed_cell": scale_fixed_cell,
        "Rwp_refined_cell": hist.get_wR(),
        "scale_refined_cell": phase.getHAPvalues(hist.name)["Scale"][0],
        "cell": phase.get_cell(),
        "mass_per_cell": phase.data["General"].get("Mass"),
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "atom_sites": [
            {
                "label": atom.label,
                "element": atom.element,
                "multiplicity": atom.mult,
                "occupancy": atom.occupancy,
            }
            for atom in phase.atoms()
        ],
    }
    print(json.dumps(result, default=str))
    return result


def main():
    results = []
    for tag, (name, cod_id) in CANDIDATES.items():
        try:
            results.append(run_branch(tag, name, cod_id))
        except Exception as exc:
            results.append({"branch": tag, "error": repr(exc)})
            print(json.dumps(results[-1]))
    print(json.dumps(results, indent=2, default=str))


if __name__ == "__main__":
    main()
