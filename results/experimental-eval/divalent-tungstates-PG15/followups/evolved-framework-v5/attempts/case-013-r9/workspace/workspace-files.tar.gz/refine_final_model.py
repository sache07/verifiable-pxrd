#!/usr/bin/env python3
"""Assemble and refine the selected physical four-phase model."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "po_p1_100.gpx"
WORK = ROOT / "final_work.gpx"


def checkpoint(project, tag):
    project.save()
    shutil.copy2(WORK, ROOT / f"final_checkpoint_{tag}.gpx")
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "tag": tag,
        "Rwp": hist.get_wR(),
        "zero_deg": inst["Zero"][1],
        "shift_um": sample["Shift"][0],
        "SH_L": inst["SH/L"][1],
        "polarization": inst["Polariz."][1],
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "scales": {
            phase.name: phase.getHAPvalues(hist.name)["Scale"][0]
            for phase in project.phases()
        },
        "preferred_orientation": {
            phase.name: phase.getHAPvalues(hist.name)["Pref.Ori."][:4]
            for phase in project.phases()
        },
        "massicot_Pb": list(project.phase(1).atom("Pb1").coordinates),
        "vary": project.get_VaryList(),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(result, indent=2, default=str))
    return result


def refine_twice(project, tag):
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    return checkpoint(project, tag)


def main():
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(WORK))
    project.set_Controls("cycles", 8)
    hist = project.histogram(0)
    project.set_Frozen()
    checkpoint(project, "00_massicot_PO")

    # A weak but stable [010] texture term for monoclinic WO3 was the only
    # secondary PO direction with a reproducible family-wide improvement.
    wo3 = project.phase(2)
    wo3_hap = wo3.getHAPvalues(hist.name)
    wo3_hap["Pref.Ori."][0] = "MD"
    wo3_hap["Pref.Ori."][1] = 1.0
    wo3_hap["Pref.Ori."][3] = [0, 1, 0]
    wo3.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    project.set_Controls("parmMin", 0.6, variable="2:0:MD")
    project.set_Controls("parmMax", 1.6, variable="2:0:MD")
    refine_twice(project, "01_WO3_PO")

    # Re-optimize the one stable coordinate result after the texture terms.
    massicot = project.phase(1)
    massicot.set_refinements({"Atoms": {"Pb1": "X"}})
    for variable, lower, upper in (
        ("1::dAx:1", 0.216, 0.246),
        ("1::dAy:1", -0.001, 0.029),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    refine_twice(project, "02_massicot_Pb")

    # These global instrument intensity/axial-divergence terms were supported
    # in the complete four-phase model and remain bounded.
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.10, variable=":0:SH/L")
    refine_twice(project, "03_SHL")

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    refine_twice(project, "04_polarization")

    project.save()


if __name__ == "__main__":
    main()
