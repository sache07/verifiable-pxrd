#!/usr/bin/env python3
"""Test WO2 references after small uniform cell shifts align their primary line."""

from pathlib import Path
import json
import math
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "physical_09_polarization.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def cell_volume(a, b, c, al, be, ga):
    ca, cb, cg = [math.cos(math.radians(v)) for v in (al, be, ga)]
    return a * b * c * math.sqrt(1 + 2 * ca * cb * cg - ca*ca - cb*cb - cg*cg)


def isolate(project):
    h = project.histogram(0)
    h.clear_refinements({"Instrument Parameters": [
        "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."
    ]})
    h.clear_refinements({"Sample Parameters": [
        "Shift", "Transparency", "SurfRoughA", "SurfRoughB"
    ]})
    for p in project.phases():
        p.clear_refinements({"Cell": True})
    project.set_Frozen()


def branch(name, cod_id, factor):
    tag = f"{name}_{factor:.4f}".replace(".", "p")
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(ROOT / f"aligned_{tag}.gpx"))
    project.set_Controls("cycles", 5)
    isolate(project)
    hist = project.histogram(0)
    phase = project.add_phase(str(cod_cif(cod_id)), phasename=name,
                              histograms=[hist], fmthint="CIF")
    cell = phase.data["General"]["Cell"]
    for i in (1, 2, 3):
        cell[i] *= factor
    cell[7] = cell_volume(*cell[1:7])
    hap = phase.getHAPvalues(hist.name)
    hap["Scale"][0] = 0.2
    phase.setSampleProfile(hist.name, "size", "isotropic", 1.0, LGmix=0.5)
    phase.setSampleProfile(hist.name, "microstrain", "isotropic", 500.0, LGmix=0.5)
    phase.set_HAP_refinements({"Scale": True}, [hist])
    idx = len(project.phases()) - 1
    project.set_Controls("parmMin", 0.0, variable=f"{idx}:0:Scale")
    project.save()
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save()
    project = G2sc.G2Project(gpxfile=str(project.filename))
    hist = project.histogram(0)
    phase = project.phase(name)
    return {
        "name": name, "factor": factor, "Rwp": hist.get_wR(),
        "scale": phase.getHAPvalues(hist.name)["Scale"][0],
        "cell": phase.get_cell(), "frozen": project.get_Frozen(),
    }


def main():
    results = []
    for name, cod_id, factors in [
        ("WO2_monoclinic", "1548686", [1.003, 1.005, 1.007, 1.009]),
        ("WO2_rutile", "5910153", [1.007, 1.009, 1.011, 1.013]),
    ]:
        for factor in factors:
            result = branch(name, cod_id, factor)
            results.append(result)
            print(json.dumps(result, default=str))
    print(json.dumps(results, indent=2, default=str))


if __name__ == "__main__":
    main()
