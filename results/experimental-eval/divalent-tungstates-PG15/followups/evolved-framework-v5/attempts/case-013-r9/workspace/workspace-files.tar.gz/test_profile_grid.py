#!/usr/bin/env python3
"""Coarse physical profile screen on the accepted four-phase structure."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "coordtest_massicot_Pb.gpx"

# U, W and X cover profiles both narrower and more Gaussian than the first
# all-pattern least-squares endpoint. V, Y and Z remain zero.
INSTRUMENT = [
    (10.0, 20.0, 1.0),
    (20.0, 20.0, 3.0),
    (20.0, 30.0, 4.0),
    (30.0, 20.0, 4.0),
    (30.0, 30.0, 4.0),
    (40.0, 30.0, 4.0),
    (30.0, 40.0, 4.0),
    (40.0, 40.0, 3.0),
    (40.0, 40.0, 6.0),
]

# Isotropic crystallite size is in micrometres; microstrain is in ppm.
SAMPLE = [
    (10.0, 10.0),
    (2.0, 250.0),
    (1.0, 500.0),
]


def prepare(project):
    hist = project.histogram(0)
    hist.clear_refinements({
        "Instrument Parameters": [
            "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."
        ],
        "Sample Parameters": [
            "Shift", "Transparency", "SurfRoughA", "SurfRoughB"
        ],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_refinements({
            "Atoms": [atom.label for atom in phase.atoms()]
        })
    project.set_Frozen()
    project.set_Controls("cycles", 5)


def run_one(index, u, w, x, size, strain):
    outfile = ROOT / ".tmp" / f"profile_grid_{index:02d}.gpx"
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(outfile))
    prepare(project)
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1], inst["W"][1], inst["X"][1] = u, w, x
    for phase in project.phases():
        phase.setSampleProfile(hist.name, "size", "isotropic", size, LGmix=0.5)
        phase.setSampleProfile(
            hist.name, "microstrain", "isotropic", strain, LGmix=0.5
        )
    project.refine(makeBack=False)
    result = {
        "index": index,
        "U": u,
        "W": w,
        "X": x,
        "size_um": size,
        "microstrain_ppm": strain,
        "Rwp": hist.get_wR(),
    }
    print(json.dumps(result))
    return result


def main():
    results = []
    index = 0
    for size, strain in SAMPLE:
        for u, w, x in INSTRUMENT:
            results.append(run_one(index, u, w, x, size, strain))
            index += 1
    (ROOT / "profile_grid.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
