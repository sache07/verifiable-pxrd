#!/usr/bin/env python3
"""Compare physical zero/shift calibration choices with cells re-refined."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "coordtest_massicot_Pb.gpx"

MODELS = [
    # tag, zero start, refine zero, shift start (micrometres), refine shift
    ("fixed_current", 0.25, False, -88.478, False),
    ("shift_only", 0.0, False, -100.0, True),
    ("zero_only", 0.20, True, 0.0, False),
    ("zero_and_shift", 0.25, True, -88.478, True),
]


def prepare(project):
    hist = project.histogram(0)
    hist.clear_refinements({
        "Instrument Parameters": [
            "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."
        ],
        "Sample Parameters": [
            "Shift", "Transparency", "SurfRoughA", "SurfRoughB"
        ],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_refinements({
            "Atoms": [atom.label for atom in phase.atoms()]
        })
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    project.set_Frozen()
    project.set_Controls("cycles", 7)


def run_one(tag, zero, refine_zero, shift, refine_shift):
    outfile = ROOT / f"calibration_{tag}.gpx"
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(outfile))
    prepare(project)
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    inst["Zero"][1] = zero
    sample["Shift"][0] = shift
    if refine_zero:
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        project.set_Controls("parmMin", -0.5, variable=":0:Zero")
        project.set_Controls("parmMax", 0.5, variable=":0:Zero")
    if refine_shift:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        project.set_Controls("parmMin", -800.0, variable=":0:Shift")
        project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save()
    result = {
        "tag": tag,
        "Rwp": hist.get_wR(),
        "zero_deg": inst["Zero"][1],
        "shift_um": sample["Shift"][0],
        "frozen": project.get_Frozen(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }
    print(json.dumps(result, default=str))
    return result


def main():
    results = [run_one(*model) for model in MODELS]
    (ROOT / "calibration_tests.json").write_text(
        json.dumps(results, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
