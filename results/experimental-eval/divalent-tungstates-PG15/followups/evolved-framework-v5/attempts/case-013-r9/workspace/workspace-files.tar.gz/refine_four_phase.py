#!/usr/bin/env python3
"""Build the accepted four-phase model and refine only bounded physical terms."""

from pathlib import Path
import json
import shutil
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PROJECT = ROOT / "four_phase_physical.gpx"


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = [
    ("PbWO4_scheelite", cod_cif("9009811"), 1.0),
    ("PbO_massicot", cod_cif("2310433"), 0.25),
    ("WO3_monoclinic", cod_cif("1528915"), 0.15),
    ("PbO_litharge", ROOT / "references" / "PbO_litharge_9012700_origin2.cif", 0.08),
]


def checkpoint(project, tag):
    project.save()
    shutil.copy2(project.filename, ROOT / f"physical_{tag}.gpx")
    h = project.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    sample = h.data["Sample Parameters"]
    summary = {
        "tag": tag,
        "Rwp": h.get_wR(),
        "Zero": inst["Zero"][1],
        "Shift_um": sample["Shift"][0],
        "U": inst["U"][1],
        "W": inst["W"][1],
        "X": inst["X"][1],
        "SH_L": inst["SH/L"][1],
        "Polarization": inst["Polariz."][1],
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "scales": {
            p.name: p.getHAPvalues(h.name)["Scale"][0]
            for p in project.phases()
        },
        "vary": project.get_VaryList(),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(summary, indent=2, default=str))
    return summary


def run(project, tag, repeats=1):
    for _ in range(repeats):
        project.refine(makeBack=False)
    return checkpoint(project, tag)


def set_bound(project, variable, lower, upper):
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def main():
    project = G2sc.G2Project(newgpx=str(PROJECT))
    project.set_Controls("cycles", 5)
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.set_refinements({
        "Limits": [10.01, 99.99],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 12,
        },
    })
    # There must be only one arbitrary scale. Fix the redundant histogram scale.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]

    for name, source, scale in PHASES:
        phase = project.add_phase(
            str(source), phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"][0] = scale
        phase.setSampleProfile(hist.name, "size", "isotropic", 1.0, LGmix=0.5)
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", 500.0, LGmix=0.5)
        phase.set_HAP_refinements({"Scale": True}, [hist])

    set_bound(project, ":0:Zero", -0.25, 0.25)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    set_bound(project, ":0:U", 0.0, 40.0)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:X", 0.1, 6.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    set_bound(project, ":0:Polariz.", 0.5, 1.0)

    checkpoint(project, "00_complete")
    run(project, "01_background_scales", repeats=2)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run(project, "02_zero", repeats=2)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, "03_cells", repeats=2)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run(project, "04_shift", repeats=2)

    hist.set_refinements({"Instrument Parameters": ["W"]})
    run(project, "05_W", repeats=2)

    hist.set_refinements({"Instrument Parameters": ["U"]})
    run(project, "06_UW", repeats=2)

    hist.set_refinements({"Instrument Parameters": ["X"]})
    run(project, "07_X", repeats=2)

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    run(project, "08_SHL", repeats=2)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run(project, "09_polarization", repeats=2)

    project.save()


if __name__ == "__main__":
    main()
