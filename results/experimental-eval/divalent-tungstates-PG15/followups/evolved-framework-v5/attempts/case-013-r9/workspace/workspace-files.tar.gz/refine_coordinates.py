#!/usr/bin/env python3
"""Refine accepted structures in heavy-then-light atom groups.

The coordinate windows are deliberately narrow.  Each stage is saved so that
an unphysical or statistically unsupported group can be rolled back without
losing the preceding complete four-phase model.
"""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "physical_09_polarization.gpx"
WORK = ROOT / "coordinates_work.gpx"


STAGES = [
    # tag, phase index, atom labels, fractional-coordinate half-window
    ("01_massicot_Pb", 1, ["Pb1"], 0.020),
    ("02_WO3_W", 2, ["W1", "W2"], 0.015),
    ("03_litharge_Pb", 3, ["Pb1"], 0.030),
    ("04_scheelite_O", 0, ["O"], 0.025),
    ("05_massicot_O", 1, ["O1"], 0.025),
    ("06_WO3_O", 2, ["O1", "O2", "O3", "O4", "O5", "O6"], 0.025),
]


def atom_parameter_names(phase_index, phase, labels):
    """Return coordinate parameter names and starting values for selected atoms."""
    cx, _, _, _ = phase.data["General"]["AtomPtrs"]
    selected = []
    for row in phase.data["Atoms"]:
        if row[0] not in labels:
            continue
        atom_id = row[-1]
        for axis, value in zip("xyz", row[cx:cx + 3]):
            selected.append((f"{phase_index}::A{axis}:{atom_id}", float(value)))
    return selected


def summary(project, tag):
    hist = project.histogram(0)
    out = {
        "tag": tag,
        "Rwp": hist.get_wR(),
        "scales": {
            phase.name: phase.getHAPvalues(hist.name)["Scale"][0]
            for phase in project.phases()
        },
        "atoms": {
            phase.name: {
                atom.label: {
                    "xyz": list(atom.coordinates),
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            }
            for phase in project.phases()
        },
        "vary": project.get_VaryList(),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(out, indent=2, default=str))
    return out


def main():
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(WORK))
    project.set_Controls("cycles", 8)
    hist = project.histogram(0)

    # Isolate structural intensity changes. Background and phase scales remain
    # active, while the already established cells/calibration/profile are fixed.
    hist.clear_refinements({
        "Instrument Parameters": [
            "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."
        ],
        "Sample Parameters": [
            "Shift", "Transparency", "SurfRoughA", "SurfRoughB"
        ],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    project.set_Frozen()
    project.save()
    shutil.copy2(WORK, ROOT / "coord_00_fixed_profile.gpx")
    summary(project, "00_fixed_profile")

    for tag, phase_index, labels, half_window in STAGES:
        phase = project.phase(phase_index)
        phase.set_refinements({"Atoms": {label: "X" for label in labels}})
        for variable, start in atom_parameter_names(phase_index, phase, labels):
            project.set_Controls(
                "parmMin", start - half_window, variable=variable
            )
            project.set_Controls(
                "parmMax", start + half_window, variable=variable
            )
        project.refine(makeBack=False)
        project.refine(makeBack=False)
        project.save()
        shutil.copy2(WORK, ROOT / f"coord_{tag}.gpx")
        summary(project, tag)


if __name__ == "__main__":
    main()
