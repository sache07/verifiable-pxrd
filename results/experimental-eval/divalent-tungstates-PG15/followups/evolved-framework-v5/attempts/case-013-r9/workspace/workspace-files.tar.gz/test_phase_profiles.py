#!/usr/bin/env python3
"""Test one isotropic specimen-broadening term at a time by phase."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
# This checkpoint has U=30, W=30, X=4 and negligible specimen broadening.
BASE = ROOT / ".tmp" / "profile_grid_04.gpx"


def prepare(project):
    hist = project.histogram(0)
    hist.clear_refinements({
        "Instrument Parameters": [
            "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."
        ],
        "Sample Parameters": [
            "Shift", "Transparency", "SurfRoughA", "SurfRoughB"
        ],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_refinements({
            "Atoms": [atom.label for atom in phase.atoms()]
        })
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    project.set_Frozen()
    project.set_Controls("cycles", 7)


def run_one(index, phase_index, term):
    outfile = ROOT / ".tmp" / f"profile_term_{index:02d}.gpx"
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(outfile))
    prepare(project)
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    if term == "size":
        phase.setSampleProfile(hist.name, "size", "isotropic", 1.0, LGmix=0.5)
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True}
        }, [hist])
        variable = f"{phase_index}:0:Size;i"
        project.set_Controls("parmMin", 0.03, variable=variable)
        project.set_Controls("parmMax", 10.0, variable=variable)
    else:
        phase.setSampleProfile(
            hist.name, "microstrain", "isotropic", 500.0, LGmix=0.5
        )
        phase.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True}
        }, [hist])
        variable = f"{phase_index}:0:Mustrain;i"
        project.set_Controls("parmMin", 10.0, variable=variable)
        project.set_Controls("parmMax", 5000.0, variable=variable)
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    hap = phase.getHAPvalues(hist.name)
    result = {
        "index": index,
        "phase_index": phase_index,
        "phase": phase.name,
        "term": term,
        "Rwp": hist.get_wR(),
        "size_um": hap["Size"][1][0],
        "microstrain_ppm": hap["Mustrain"][1][0],
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(result))
    return result


def main():
    results = []
    index = 0
    for phase_index in range(4):
        for term in ("size", "microstrain"):
            results.append(run_one(index, phase_index, term))
            index += 1
    (ROOT / "phase_profile_tests.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
