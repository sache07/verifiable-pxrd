#!/usr/bin/env python3
"""Rebuild the complete model with a physically valid monoclinic WO3 reference."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
WORK = ROOT / "valid_wo3_work.gpx"


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = [
    ("PbWO4_scheelite", cod_cif("9009811"), 5.57),
    ("PbO_massicot", cod_cif("2310433"), 1.54),
    ("WO3_monoclinic", cod_cif("2311041"), 0.80),
    ("PbO_litharge", ROOT / "references" / "PbO_litharge_9012700_origin2.cif", 1.76),
]


def set_bound(project, variable, lower, upper):
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def checkpoint(project, tag):
    project.save()
    shutil.copy2(WORK, ROOT / f"valid_wo3_{tag}.gpx")
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    out = {
        "tag": tag,
        "Rwp": hist.get_wR(),
        "zero": inst["Zero"][1],
        "SH_L": inst["SH/L"][1],
        "scales": {
            phase.name: phase.getHAPvalues(hist.name)["Scale"][0]
            for phase in project.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "PO": {
            phase.name: phase.getHAPvalues(hist.name)["Pref.Ori."][:4]
            for phase in project.phases()
        },
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(out, indent=2, default=str))


def refine_twice(project, tag):
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    checkpoint(project, tag)


def main():
    project = G2sc.G2Project(newgpx=str(WORK))
    project.set_Controls("cycles", 8)
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.set_refinements({
        "Limits": [10.01, 99.99],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 12,
        },
    })
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"][1] = 0.2975
    inst["U"][1] = 40.0
    inst["W"][1] = 40.0
    inst["X"][1] = 6.0
    inst["SH/L"][1] = 0.02933
    inst["Polariz."][1] = 0.840674

    for index, (name, source, scale) in enumerate(PHASES):
        phase = project.add_phase(
            str(source), phasename=name, histograms=[hist], fmthint="CIF"
        )
        phase.getHAPvalues(hist.name)["Scale"][0] = scale
        phase.setSampleProfile(hist.name, "size", "isotropic", 1.0, LGmix=0.5)
        phase.setSampleProfile(
            hist.name, "microstrain", "isotropic", 500.0, LGmix=0.5
        )
        phase.set_HAP_refinements({"Scale": True}, [hist])
        set_bound(project, f"{index}:0:Scale", 0.0, 20.0)

    # Retain the independently supported, interior massicot Pb coordinate.
    project.phase(1).atom("Pb1").coordinates = (0.22441938080533771,
                                                  0.005371267340980873,
                                                  0.25)

    set_bound(project, ":0:Zero", -0.5, 0.5)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    checkpoint(project, "00_complete")
    refine_twice(project, "01_scales_background")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_twice(project, "02_zero")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine_twice(project, "03_cells")

    # The physical reference uses an alternative P21/c cell, but b is the
    # unique axis and the prior weak [010] texture direction transfers exactly.
    for phase_index, axis in ((1, [1, 0, 0]), (2, [0, 1, 0])):
        phase = project.phase(phase_index)
        po = phase.getHAPvalues(hist.name)["Pref.Ori."]
        po[0], po[1], po[3] = "MD", 1.0, axis
        phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
        set_bound(project, f"{phase_index}:0:MD", 0.6, 1.6)
    refine_twice(project, "04_texture")

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine_twice(project, "05_SHL")
    project.save()


if __name__ == "__main__":
    main()
