#!/usr/bin/env python3
"""Independently test narrowly bounded coordinate groups in the four-phase fit."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "physical_09_polarization.gpx"


TESTS = [
    ("massicot_Pb", 1, ["Pb1"], 0.015),
    ("WO3_W1", 2, ["W1"], 0.012),
    ("WO3_W2", 2, ["W2"], 0.012),
    ("litharge_Pb", 3, ["Pb1"], 0.020),
    ("scheelite_O", 0, ["O"], 0.015),
    ("massicot_O", 1, ["O1"], 0.020),
    ("WO3_O1", 2, ["O1"], 0.015),
    ("WO3_O2", 2, ["O2"], 0.015),
    ("WO3_O3", 2, ["O3"], 0.015),
    ("WO3_O4", 2, ["O4"], 0.015),
    ("WO3_O5", 2, ["O5"], 0.015),
    ("WO3_O6", 2, ["O6"], 0.015),
    ("WO3_O_all", 2, ["O1", "O2", "O3", "O4", "O5", "O6"], 0.015),
]


def prepare(project):
    hist = project.histogram(0)
    hist.clear_refinements({
        "Instrument Parameters": [
            "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."
        ],
        "Sample Parameters": [
            "Shift", "Transparency", "SurfRoughA", "SurfRoughB"
        ],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_refinements({
            "Atoms": [atom.label for atom in phase.atoms()]
        })
    project.set_Frozen()
    project.set_Controls("cycles", 7)


def bounded_coordinate_names(phase_index, phase, labels, half_window):
    cx, _, _, _ = phase.data["General"]["AtomPtrs"]
    limits = {}
    for atom_index, row in enumerate(phase.data["Atoms"]):
        if row[0] not in labels:
            continue
        for axis, value in zip("xyz", row[cx:cx + 3]):
            variable = f"{phase_index}::dA{axis}:{atom_index}"
            limits[variable] = [float(value) - half_window,
                                float(value) + half_window]
    return limits


def run_test(tag, phase_index, labels, half_window):
    out = ROOT / f"coordtest_{tag}.gpx"
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(out))
    prepare(project)
    phase = project.phase(phase_index)
    phase.set_refinements({"Atoms": {label: "X" for label in labels}})
    limits = bounded_coordinate_names(phase_index, phase, labels, half_window)
    for variable, (lower, upper) in limits.items():
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save()
    result = {
        "tag": tag,
        "Rwp": project.histogram(0).get_wR(),
        "frozen": project.get_Frozen(),
        "limits": limits,
        "selected_atoms": {
            atom.label: list(atom.coordinates)
            for atom in phase.atoms() if atom.label in labels
        },
        "scales": {
            p.name: p.getHAPvalues(project.histogram(0).name)["Scale"][0]
            for p in project.phases()
        },
    }
    print(json.dumps(result, default=str))
    return result


def main():
    results = []
    for args in TESTS:
        try:
            results.append(run_test(*args))
        except Exception as exc:
            results.append({"tag": args[0], "error": repr(exc)})
            print(json.dumps(results[-1]))
    (ROOT / "coordinate_tests.json").write_text(
        json.dumps(results, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
