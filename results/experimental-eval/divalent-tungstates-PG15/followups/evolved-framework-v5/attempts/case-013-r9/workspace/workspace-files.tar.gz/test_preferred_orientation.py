#!/usr/bin/env python3
"""Screen restrained March-Dollase directions for the accepted phases."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "calibration_zero_only.gpx"

TESTS = [
    (0, [0, 0, 1]), (0, [1, 0, 0]), (0, [1, 1, 2]),
    (1, [1, 0, 0]), (1, [0, 1, 0]), (1, [0, 0, 1]),
    (2, [1, 0, 0]), (2, [0, 1, 0]), (2, [0, 0, 1]),
    (3, [0, 0, 1]),
]


def prepare(project):
    hist = project.histogram(0)
    hist.clear_refinements({
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
    })
    for phase in project.phases():
        phase.clear_refinements({
            "Atoms": [atom.label for atom in phase.atoms()]
        })
        phase.clear_HAP_refinements({
            "Size": True, "Mustrain": True, "Pref.Ori.": True
        })
    project.set_Frozen()
    project.set_Controls("cycles", 7)


def run_one(index, phase_index, axis):
    tag = f"p{phase_index}_{axis[0]}{axis[1]}{axis[2]}"
    outfile = ROOT / ".tmp" / f"po_{tag}.gpx"
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(outfile))
    prepare(project)
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.getHAPvalues(hist.name)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][3] = list(axis)
    phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    variable = f"{phase_index}:0:MD"
    project.set_Controls("parmMin", 0.6, variable=variable)
    project.set_Controls("parmMax", 1.6, variable=variable)
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    result = {
        "index": index,
        "phase_index": phase_index,
        "phase": phase.name,
        "axis": axis,
        "MD": hap["Pref.Ori."][1],
        "Rwp": hist.get_wR(),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(result))
    return result


def main():
    results = [run_one(i, *test) for i, test in enumerate(TESTS)]
    (ROOT / "preferred_orientation_tests.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
