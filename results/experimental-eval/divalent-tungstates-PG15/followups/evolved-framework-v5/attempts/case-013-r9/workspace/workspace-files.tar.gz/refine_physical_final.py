#!/usr/bin/env python3
"""Refine the final model from the last fully physical coordinate checkpoint."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "final_checkpoint_01_WO3_PO.gpx"
WORK = ROOT / "physical_final_work.gpx"


def state(project, tag):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    out = {
        "tag": tag,
        "Rwp": hist.get_wR(),
        "zero_deg": inst["Zero"][1],
        "SH_L": inst["SH/L"][1],
        "polarization": inst["Polariz."][1],
        "massicot_Pb": list(project.phase(1).atom("Pb1").coordinates),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(out, indent=2))


def main():
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(WORK))
    project.set_Controls("cycles", 8)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.clear_refinements({
            "Atoms": [atom.label for atom in phase.atoms()]
        })
    project.set_Frozen()

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.10, variable=":0:SH/L")
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(WORK, ROOT / "physical_final_SHL.gpx")
    state(project, "SHL")

    # Keep a separate polarization trial. It is accepted only if it gives a
    # reproducible improvement from the physical SH/L checkpoint.
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(WORK, ROOT / "physical_final_polarization_trial.gpx")
    state(project, "polarization_trial")


if __name__ == "__main__":
    main()
