#!/usr/bin/env python3
"""Convert the supplied two-column CSV to a GSAS-II xye file.

No pointwise uncertainties were supplied. The third column therefore uses
Poisson counting uncertainties, sqrt(max(counts, 1)), which is the natural
weighting for the unprocessed counts in this scan.
"""

import csv
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
source = ROOT / "inputs" / "pattern.csv"
target = Path(__file__).resolve().parent / "pattern.xye"

with source.open(newline="") as src, target.open("w", newline="\n") as dst:
    rows = csv.DictReader(src)
    dst.write("# two_theta_deg intensity sigma_poisson\n")
    for row in rows:
        x = float(row["two_theta_deg"])
        y = float(row["intensity"])
        dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")

print(target)
