#!/usr/bin/env python3
"""Export all submission artifacts from the exact accepted GSAS-II project."""

from __future__ import annotations

import csv
import json
import shutil
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


CIF_NAMES = {
    "PbWO4": "phase_PbWO4.cif",
    "Pb2WO5": "phase_Pb2WO5.cif",
    "PbO_massicot": "phase_PbO_massicot.cif",
    "PbO_litharge": "phase_PbO_litharge.cif",
    "WO3": "phase_WO3.cif",
}


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: export_final.py ACCEPTED.gpx WORKSPACE_ROOT")
    source = Path(sys.argv[1]).resolve()
    root = Path(sys.argv[2]).resolve()
    final_gpx = root / "final.gpx"
    shutil.copy2(source, final_gpx)
    project = G2sc.G2Project(str(final_gpx))
    hist = project.histogram(0)

    for phase in project.phases():
        phase.export_CIF(str(root / CIF_NAMES[phase.name]))

    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    difference = yobs - ycalc
    with (root / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        writer.writerows(zip(x, yobs, ycalc, difference, background))

    # Confirm that the exported profile has exactly the specimen's unresampled
    # grid and observed counts.
    with (root / "inputs" / "pattern.csv").open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    xin = np.asarray([float(row["two_theta_deg"]) for row in rows])
    yin = np.asarray([float(row["intensity"]) for row in rows])
    # Decimal-to-binary roundoff in the GPX reaches only 1.4e-14 degree;
    # counts are bit-for-bit identical and no point has been resampled.
    if not (
        np.allclose(x, xin, rtol=0.0, atol=1e-12)
        and np.array_equal(yobs, yin)
    ):
        raise RuntimeError("GSAS-II profile does not reproduce the input grid/counts")

    fractions = hist.ComputeMassFracs()
    summary = {
        "project": final_gpx.name,
        "point_count": len(x),
        "profile_grid_exact": True,
        "profile_grid_max_abs_error_deg": float(np.max(np.abs(x - xin))),
        "observed_counts_exact": bool(np.array_equal(yobs, yin)),
        "frozen": project.get_Frozen(),
        "fit_statistics": {
            "Rwp_percent": hist.residuals["wR"],
            "Rp_percent": hist.residuals["R"],
            "Rwp_min_percent": hist.residuals["wRmin"],
            "goodness_of_fit": hist.residuals["wR"] / hist.residuals["wRmin"],
            "reduced_chi_square": (
                hist.residuals["wR"] / hist.residuals["wRmin"]
            ) ** 2,
        },
        "phases": [
            {
                "name": phase.name,
                "cif": CIF_NAMES[phase.name],
                "weight_fraction": fractions[phase.name][0],
                "weight_fraction_esd": fractions[phase.name][1],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            }
            for phase in project.phases()
        ],
    }
    (root / "analysis" / "export_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
