#!/usr/bin/env python3
"""Screen generator-supported uniaxial microstrain axes."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


AXES = ((0, 0, 1), (1, 0, 0), (0, 1, 0))
PHASES = ("Pb2WO5", "PbO_massicot", "PbO_litharge")


def clear_all(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                "Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."
            ],
            "Sample Parameters": ["Scale", "Shift", "SurfRoughA", "SurfRoughB"],
            "Background": True,
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "HStrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            }
        )


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: screen_strain_anisotropy.py INPUT.gpx OUTPUT_DIR")
    source = Path(sys.argv[1]).resolve()
    outdir = Path(sys.argv[2]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    baseline = G2sc.G2Project(str(source)).histogram(0).get_wR()
    results: list[dict] = []

    for name in PHASES:
        for axis in AXES:
            tag = name + "_" + "".join(map(str, axis))
            project = G2sc.G2Project(
                str(source), newgpx=str(outdir / f"{tag}.gpx")
            )
            project.data["Controls"]["data"].update(
                {"max cyc": 10, "min dM/M": 1e-6, "shift factor": 0.5}
            )
            project.set_Frozen()
            clear_all(project)
            hist = project.histogram(0)
            # Preserve the two accepted texture terms and reoptimize scales.
            for phase in project.phases():
                phase.set_HAP_refinements({"Scale": True})
            for pname in ("Pb2WO5", "PbO_massicot"):
                project.phase(pname).set_HAP_refinements({"Pref.Ori.": True})

            phase = project.phase(name)
            profile = phase.data["Histograms"][hist.name]["Mustrain"]
            iso = float(profile[1][0])
            profile[1][0] = iso
            profile[1][1] = iso
            phase.set_HAP_refinements(
                {
                    "Mustrain": {
                        "type": "uniaxial",
                        "direction": axis,
                        "refine": True,
                    }
                }
            )
            for variable in ("Mustrain;i", "Mustrain;a"):
                project.set_Controls(
                    "parmMin", 50.0, variable=f"{phase.id}:0:{variable}"
                )
                project.set_Controls(
                    "parmMax", 20000.0, variable=f"{phase.id}:0:{variable}"
                )
            project.save()
            project.refine(makeBack=False)
            project.save()
            result = {
                "phase": name,
                "axis": list(axis),
                "equatorial_ppm": profile[1][0],
                "axial_ppm": profile[1][1],
                "axial_ratio": profile[1][1] / profile[1][0],
                "rwp_percent": hist.get_wR(),
                "delta_rwp": baseline - hist.get_wR(),
                "frozen": project.get_Frozen(),
                "gpx": str(outdir / f"{tag}.gpx"),
            }
            results.append(result)
            print("STRAIN", json.dumps(result), flush=True)

    results.sort(key=lambda item: item["rwp_percent"])
    (outdir / "results.json").write_text(
        json.dumps({"baseline_rwp": baseline, "tests": results}, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
