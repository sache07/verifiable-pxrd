#!/usr/bin/env python3
"""Bounded physical refinement of the accepted five-phase inventory."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def clear_atom_flags(project: G2sc.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def report(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "gof": hist.residuals.get("wR", 0.0) / hist.residuals.get("wRmin", 1.0),
        "fractions": {
            k: {"value": v[0], "sigma": v[1]}
            for k, v in hist.ComputeMassFracs().items()
        },
        "instrument": {
            k: inst[k][1]
            for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "sample": {
            k: sample[k][0]
            for k in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "phases": {},
        "frozen": project.get_Frozen(),
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": {
                atom.label: list(atom.coordinates) for atom in phase.atoms()
            },
        }
    print("STATE", json.dumps(result, sort_keys=True), flush=True)
    return result


def checkpoint(project: G2sc.G2Project, outdir: Path, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")


def run_refine(
    project: G2sc.G2Project, outdir: Path, label: str, states: list[dict]
) -> None:
    project.refine(makeBack=False)
    checkpoint(project, outdir, label)
    states.append(report(project, label))


def set_limit(
    project: G2sc.G2Project, variable: str, lower: float, upper: float
) -> None:
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_profile.py INPUT.gpx OUTPUT_DIR")
    source = Path(sys.argv[1]).resolve()
    outdir = Path(sys.argv[2]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(source), newgpx=str(outdir / "physical.gpx"))
    controls = project.data["Controls"]["data"]
    controls.update({"max cyc": 12, "min dM/M": 1e-5, "shift factor": 0.5})
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    # Materialize the new project before helpers call GSAS-II routines that
    # reopen the current GPX (notably ComputeMassFracs).
    project.save()
    states: list[dict] = [report(project, "start")]

    set_limit(project, ":0:Zero", -0.5, 0.5)
    set_limit(project, ":0:Shift", -800.0, 800.0)
    set_limit(project, ":0:W", 2.0, 40.0)
    set_limit(project, ":0:SH/L", 0.005, 0.10)
    set_limit(project, ":0:Polariz.", 0.5, 1.0)
    set_limit(project, ":0:SurfRoughA", 0.0, 1.0)
    set_limit(project, ":0:SurfRoughB", 0.001, 1.0)
    for phase in project.phases():
        set_limit(project, f"{phase.id}:0:Size;i", 0.04, 2.0)
        set_limit(project, f"{phase.id}:0:Mustrain;i", 0.0, 10000.0)

    # Retain only supported heavy-coordinate changes. PbWO4 heavy sites are
    # fixed by symmetry and WO3 heavy refinement was separately found to make
    # a 1.54-A W-O contact, so both remain at their published positions.
    clear_atom_flags(project)
    for name in ("Pb2WO5", "PbO_massicot", "PbO_litharge"):
        phase = project.phase(name)
        for atom in phase.atoms():
            if atom.element in {"Pb", "W"}:
                atom.refinement_flags = "X"
    run_refine(project, outdir, "01_selected_heavy", states)
    clear_atom_flags(project)

    # Keep a physical, identifiable decomposition of broadening: U and X are
    # fixed at their ordinary starting values while the common Gaussian W and
    # phase-specific size/strain terms carry the observed phase differences.
    for key in ("U", "V", "W", "X", "Y", "SH/L", "Polariz."):
        inst[key][2] = False
    inst["U"][1] = 10.0
    inst["W"][1] = 10.0
    inst["X"][1] = 1.0
    inst["SH/L"][1] = 0.02
    for phase in project.phases():
        phase.setSampleProfile(hist, "size", "isotropic", 0.30, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}
        )
    run_refine(project, outdir, "02_size", states)

    hist.set_refinements({"Instrument Parameters": ["W"]})
    run_refine(project, outdir, "03_W", states)

    for phase in project.phases():
        phase.setSampleProfile(
            hist, "microstrain", "isotropic", 500.0, LGmix=1.0
        )
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    run_refine(project, outdir, "04_mustrain", states)

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    run_refine(project, outdir, "05_SHL", states)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run_refine(project, outdir, "06_polarization", states)

    # Surface roughness is tested last and can be rejected by selecting the
    # preceding checkpoint if it reaches a boundary or lacks fit support.
    sample["SurfRoughA"] = [0.10, True]
    sample["SurfRoughB"] = [0.10, True]
    run_refine(project, outdir, "07_surface_roughness", states)

    clear_atom_flags(project)
    checkpoint(project, outdir, "final_profile_branch")
    (outdir / "states.json").write_text(json.dumps(states, indent=2) + "\n")


if __name__ == "__main__":
    main()
