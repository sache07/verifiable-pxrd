#!/usr/bin/env python3
"""Refine supported textures/scales on the accepted physical profile state."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def clear_all(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                "Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."
            ],
            "Sample Parameters": ["Scale", "Shift", "SurfRoughA", "SurfRoughB"],
            # GSAS-II returns immediately after a boolean Background clear,
            # so this entry must be last.
            "Background": True,
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "HStrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            }
        )


def set_texture(
    project: G2sc.G2Project, phase_name: str, ratio: float
) -> None:
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", ratio, True, [1, 0, 0]
    project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")


def report(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "rp_percent": hist.residuals["R"],
        "rwp_min_percent": hist.residuals["wRmin"],
        "frozen": project.get_Frozen(),
        "fractions": {
            key: {"value": val[0], "sigma": val[1]}
            for key, val in hist.ComputeMassFracs().items()
        },
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "shift_um": sample["Shift"][0],
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "po": hap["Pref.Ori."],
        }
    print("STATE", json.dumps(result, default=float, sort_keys=True), flush=True)
    return result


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_fixed_textures.py INPUT.gpx OUTPUT_DIR")
    source = Path(sys.argv[1]).resolve()
    outdir = Path(sys.argv[2]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(
        str(source), newgpx=str(outdir / "physical_textures.gpx")
    )
    project.data["Controls"]["data"].update(
        {"max cyc": 12, "min dM/M": 1e-6, "shift factor": 0.5}
    )
    project.set_Frozen()
    clear_all(project)
    hist = project.histogram(0)

    # Preserve boundary values from the accepted profile, but do not claim
    # that they are independently refined.
    project.phase("PbWO4").data["Histograms"][hist.name]["Mustrain"][1][0] = 0.0
    project.phase("WO3").data["Histograms"][hist.name]["Mustrain"][1][0] = 0.0
    project.phase("PbO_litharge").data["Histograms"][hist.name]["Size"][1][0] = 0.04

    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    set_texture(project, "Pb2WO5", 1.14)
    set_texture(project, "PbO_massicot", 0.86)
    project.save()
    states = [report(project, "start")]

    project.refine(makeBack=False)
    project.save()
    shutil.copy2(project.filename, outdir / "01_scales_textures.gpx")
    states.append(report(project, "scales_textures"))

    # Refit the same smooth background representation once after the scale
    # redistribution; retain this only if it remains stable and improves Rwp.
    hist.set_refinements({"Background": {"refine": True}})
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(project.filename, outdir / "02_background.gpx")
    states.append(report(project, "background"))
    (outdir / "states.json").write_text(json.dumps(states, indent=2) + "\n")


if __name__ == "__main__":
    main()
