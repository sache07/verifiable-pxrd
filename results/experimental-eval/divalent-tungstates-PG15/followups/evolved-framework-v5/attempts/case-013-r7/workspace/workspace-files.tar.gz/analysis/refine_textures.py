#!/usr/bin/env python3
"""Add the two supported texture terms to the clean physical checkpoint."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def state(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    result = {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "residuals": dict(hist.residuals),
        "frozen": project.get_Frozen(),
        "fractions": {
            name: {"value": value[0], "sigma": value[1]}
            for name, value in hist.ComputeMassFracs().items()
        },
        "po": {
            phase.name: phase.getHAPvalues(hist.name)["Pref.Ori."][:4]
            for phase in project.phases()
        },
    }
    print("STATE", json.dumps(result, default=float, sort_keys=True), flush=True)
    return result


def checkpoint(project: G2sc.G2Project, outdir: Path, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")


def add_texture(
    project: G2sc.G2Project, phase_name: str, axis: tuple[int, int, int], ratio: float
) -> None:
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = ratio
    po[2] = True
    po[3] = list(axis)
    project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_textures.py INPUT.gpx OUTPUT_DIR")
    source = Path(sys.argv[1]).resolve()
    outdir = Path(sys.argv[2]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(
        str(source), newgpx=str(outdir / "textures.gpx")
    )
    project.data["Controls"]["data"].update(
        {"max cyc": 12, "min dM/M": 1e-5, "shift factor": 0.5}
    )
    project.set_Frozen()
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")

    # Boundary estimates are physically meaningful but not independently
    # determined. Keep their values and remove them from the varying set.
    hist = project.histogram(0)
    for name in ("PbWO4", "WO3"):
        phase = project.phase(name)
        profile = phase.data["Histograms"][hist.name]["Mustrain"]
        profile[1][0] = 0.0
        phase.clear_HAP_refinements({"Mustrain": True})
    phase = project.phase("PbO_litharge")
    profile = phase.data["Histograms"][hist.name]["Size"]
    profile[1][0] = 0.04
    phase.clear_HAP_refinements({"Size": True})

    project.save()
    states = [state(project, "clean_start")]

    add_texture(project, "Pb2WO5", (1, 0, 0), 1.14)
    project.refine(makeBack=False)
    checkpoint(project, outdir, "01_Pb2WO5_100")
    states.append(state(project, "Pb2WO5_100"))

    add_texture(project, "PbO_massicot", (1, 0, 0), 0.86)
    project.refine(makeBack=False)
    checkpoint(project, outdir, "02_massicot_100")
    states.append(state(project, "massicot_100"))

    (outdir / "states.json").write_text(json.dumps(states, indent=2) + "\n")


if __name__ == "__main__":
    main()
