#!/usr/bin/env python3
"""Refine coordinates in ordered heavy-then-light checkpoints."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def state(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    out = {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "fractions": {
            k: {"value": v[0], "sigma": v[1]}
            for k, v in hist.ComputeMassFracs().items()
        },
        "phases": {},
    }
    for phase in project.phases():
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": list(atom.coordinates),
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    print("STATE", json.dumps(out, sort_keys=True), flush=True)
    return out


def snapshot(project: G2sc.G2Project, outdir: Path, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    cifdir = outdir / label
    cifdir.mkdir(exist_ok=True)
    for phase in project.phases():
        phase.export_CIF(str(cifdir / f"{phase.name}.cif"))


def clear_atom_flags(project: G2sc.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def refine_stage(
    project: G2sc.G2Project,
    outdir: Path,
    label: str,
    phase_names: set[str],
    elements: set[str],
) -> dict:
    clear_atom_flags(project)
    for phase in project.phases():
        if phase.name not in phase_names:
            continue
        for atom in phase.atoms():
            if atom.element in elements:
                atom.refinement_flags = "X"
    project.refine(makeBack=False)
    snapshot(project, outdir, label)
    return state(project, label)


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_coordinates.py INPUT.gpx OUTPUT_DIR")
    source = Path(sys.argv[1]).resolve()
    outdir = Path(sys.argv[2]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(source), newgpx=str(outdir / "coordinates.gpx"))
    project.data["Controls"]["data"].update(
        {"max cyc": 10, "min dM/M": 1e-5, "shift factor": 0.5}
    )
    project.set_Controls("parmMin", -1000.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1000.0, variable=":0:Shift")
    project.set_Controls("parmMin", -0.5, variable=":0:Zero")
    project.set_Controls("parmMax", 0.5, variable=":0:Zero")
    states = [state(project, "start")]

    all_names = {phase.name for phase in project.phases()}
    states.append(
        refine_stage(project, outdir, "01_heavy", all_names, {"Pb", "W"})
    )

    # Light coordinates are introduced in supported blocks, with snapshots so
    # that a geometrically unstable minor-phase branch can be rolled back.
    states.append(
        refine_stage(project, outdir, "02_O_PbWO4", {"PbWO4"}, {"O"})
    )
    states.append(
        refine_stage(project, outdir, "03_O_Pb2WO5", {"Pb2WO5"}, {"O"})
    )
    states.append(
        refine_stage(
            project,
            outdir,
            "04_O_PbO",
            {"PbO_massicot", "PbO_litharge"},
            {"O"},
        )
    )
    states.append(refine_stage(project, outdir, "05_O_WO3", {"WO3"}, {"O"}))
    clear_atom_flags(project)
    snapshot(project, outdir, "final_coordinates")
    (outdir / "states.json").write_text(json.dumps(states, indent=2) + "\n")


if __name__ == "__main__":
    main()
