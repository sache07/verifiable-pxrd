#!/usr/bin/env python3
"""Screen bounded single-phase March-Dollase axes from one fixed checkpoint."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


AXES = ((0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1))


def clear_flags(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                "Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."
            ],
            "Sample Parameters": ["Scale", "Shift", "SurfRoughA", "SurfRoughB"],
            # GSAS-II returns immediately after a boolean Background clear,
            # so this entry must be last.
            "Background": True,
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "HStrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            }
        )


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: screen_texture.py INPUT.gpx OUTPUT_DIR")
    source = Path(sys.argv[1]).resolve()
    outdir = Path(sys.argv[2]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    base = G2sc.G2Project(str(source))
    baseline = base.histogram(0).get_wR()
    names = [phase.name for phase in base.phases()]
    results: list[dict] = []

    for name in names:
        for axis in AXES:
            tag = name + "_" + "".join(map(str, axis))
            project = G2sc.G2Project(
                str(source), newgpx=str(outdir / f"{tag}.gpx")
            )
            project.data["Controls"]["data"].update(
                {"max cyc": 8, "min dM/M": 1e-6}
            )
            clear_flags(project)
            hist = project.histogram(0)
            # Reoptimize all scales while testing one texture parameter; this
            # avoids mistaking its mean-intensity effect for orientation.
            for phase in project.phases():
                phase.set_HAP_refinements({"Scale": True})
            phase = project.phase(name)
            po = phase.data["Histograms"][hist.name]["Pref.Ori."]
            po[0] = "MD"
            po[1] = 1.0
            po[2] = True
            po[3] = list(axis)
            project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")
            project.save()
            project.refine(makeBack=False)
            project.save()
            ratio = phase.data["Histograms"][hist.name]["Pref.Ori."][1]
            results.append(
                {
                    "phase": name,
                    "axis": list(axis),
                    "ratio": ratio,
                    "rwp_percent": hist.get_wR(),
                    "delta_rwp": baseline - hist.get_wR(),
                    "frozen": project.get_Frozen(),
                    "gpx": str(outdir / f"{tag}.gpx"),
                }
            )
            print("TEXTURE", json.dumps(results[-1]), flush=True)

    results.sort(key=lambda item: item["rwp_percent"])
    (outdir / "results.json").write_text(
        json.dumps({"baseline_rwp": baseline, "tests": results}, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
