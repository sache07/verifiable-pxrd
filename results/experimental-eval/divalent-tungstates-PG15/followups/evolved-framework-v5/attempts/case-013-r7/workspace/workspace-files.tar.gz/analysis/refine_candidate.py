#!/usr/bin/env python3
"""Build and stage a conservative multiphase GSAS-II refinement.

Usage (with the GSAS-II Python interpreter):
    refine_candidate.py RUN_DIR NAME=CIF [NAME=CIF ...]

The script is intentionally limited to inventory/cell/profile screening. Atom
coordinates, preferred orientation and anisotropic broadening are left for the
subsequent physical-model refinement once the phase inventory is established.
"""

from __future__ import annotations

import json
import math
import os
import shutil
import sys
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent


def report(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    try:
        fractions = {
            k: {"value": v[0], "sigma": v[1]}
            for k, v in hist.ComputeMassFracs().items()
        }
    except Exception as exc:  # unavailable before a covariance matrix exists
        fractions = {"error": repr(exc)}
    state = {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "residuals": dict(hist.residuals),
        "instrument": {
            k: inst[k][1]
            for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "sample": {
            k: sample[k][0]
            for k in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "fractions": fractions,
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        state["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    print("STATE", json.dumps(state, sort_keys=True, default=float), flush=True)
    return state


def refine(project: G2sc.G2Project, run_dir: Path, label: str, states: list[dict]) -> None:
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(project.filename, run_dir / f"{label}.gpx")
    states.append(report(project, label))


def main() -> None:
    if len(sys.argv) < 4:
        raise SystemExit("usage: refine_candidate.py RUN_DIR NAME=CIF NAME=CIF [NAME=CIF ...]")
    run_dir = Path(sys.argv[1]).resolve()
    run_dir.mkdir(parents=True, exist_ok=True)
    phase_specs: list[tuple[str, Path]] = []
    for spec in sys.argv[2:]:
        name, sep, path = spec.partition("=")
        if not sep:
            raise SystemExit(f"phase specification lacks '=': {spec}")
        phase_specs.append((name, Path(path).resolve()))

    project = G2sc.G2Project(newgpx=str(run_dir / "screen.gpx"))
    project.data["Controls"]["data"].update({"max cyc": 12, "min dM/M": 1e-5})
    hist = project.add_powder_histogram(
        str(HERE / "pattern.xye"),
        str(HERE / "instrument.instprm"),
        fmthint="xye",
    )
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    # HAP scales carry the phase quantities; keep the redundant histogram
    # sample scale fixed.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    for name, cif in phase_specs:
        project.add_phase(
            str(cif), phasename=name, histograms=[hist], fmthint="CIF"
        )

    # Start near the clear common positive peak displacement; refinement then
    # separates constant zero from Bragg-Brentano sample-height shift.
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"][1] = 0.25
    # Estimate the smooth raw-count background and fit it with a replayable
    # Chebyshev representation in the project.
    x_obs = np.asarray(hist.getdata("X"), dtype=float)
    y_obs = np.asarray(hist.getdata("Yobs"), dtype=float)
    baseline = percentile_filter(y_obs, percentile=20, size=401, mode="nearest")
    stride = max(1, len(x_obs) // 140)
    fixed_points = list(zip(x_obs[::stride], baseline[::stride]))
    if fixed_points[-1][0] != x_obs[-1]:
        fixed_points.append((x_obs[-1], baseline[-1]))
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 15,
                "FixedPoints": fixed_points,
                "fit fixed points": True,
                "refine": True,
            }
        }
    )
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})

    project.save()
    states: list[dict] = [report(project, "initial")]

    # Scales and smooth background first.
    refine(project, run_dir, "01_scale_background", states)

    # Phase cells plus a common constant angular offset.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, run_dir, "02_cells_zero", states)

    # Add sample displacement only after cells/zero are close.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, run_dir, "03_shift", states)

    # LAB.md varies U, W, X and SH/L. Keep V and Y at zero for this screen.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, run_dir, "04_instrument_profile", states)

    if os.environ.get("SCREEN_ONLY"):
        (run_dir / "states.json").write_text(
            json.dumps(states, indent=2, default=float) + "\n"
        )
        return

    # One isotropic phase broadening term at a time. Size starts at a physical
    # submicron value; microstrain is introduced only after the size fit.
    for phase in project.phases():
        phase.setSampleProfile(hist, "size", "isotropic", 0.3, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}
        )
    refine(project, run_dir, "05_size", states)

    for phase in project.phases():
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    refine(project, run_dir, "06_mustrain", states)

    project.save(run_dir / "screen.gpx")
    (run_dir / "states.json").write_text(json.dumps(states, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
