#!/usr/bin/env python3
"""Create the final physical checkpoint from the accepted anisotropy branch."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_final_checkpoint.py INPUT.gpx OUTPUT.gpx")
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project.data["Controls"]["data"].update(
        {"max cyc": 12, "min dM/M": 1e-6, "shift factor": 0.5}
    )
    project.set_Frozen()
    hist = project.histogram(0)

    # Explicitly hold calibration and all nonselected profile terms at the
    # physical checkpoint values. Vary only background, scales, the two
    # supported textures, and the one supported strain anisotropy.
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                "Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."
            ],
            "Sample Parameters": ["Scale", "Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "HStrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            }
        )
        phase.set_HAP_refinements({"Scale": True})

    for name in ("Pb2WO5", "PbO_massicot"):
        phase = project.phase(name)
        phase.set_HAP_refinements({"Pref.Ori.": True})
        project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")

    phase = project.phase("Pb2WO5")
    phase.set_HAP_refinements(
        {
            "Mustrain": {
                "type": "uniaxial",
                "direction": (1, 0, 0),
                "refine": True,
            }
        }
    )
    for variable in ("Mustrain;i", "Mustrain;a"):
        project.set_Controls(
            "parmMin", 50.0, variable=f"{phase.id}:0:{variable}"
        )
        project.set_Controls(
            "parmMax", 20000.0, variable=f"{phase.id}:0:{variable}"
        )

    project.save()
    project.refine(makeBack=False)
    project.save()
    fractions = hist.ComputeMassFracs()
    profile = phase.getHAPvalues(hist.name)["Mustrain"]
    result = {
        "rwp_percent": hist.get_wR(),
        "rp_percent": hist.residuals["R"],
        "rwp_min_percent": hist.residuals["wRmin"],
        "gof": hist.residuals["wR"] / hist.residuals["wRmin"],
        "reduced_chi_square": (
            hist.residuals["wR"] / hist.residuals["wRmin"]
        ) ** 2,
        "fractions": {
            key: {"value": val[0], "sigma": val[1]}
            for key, val in fractions.items()
        },
        "pb2wo5_strain": {
            "axis": profile[3],
            "equatorial_ppm": profile[1][0],
            "axial_ppm": profile[1][1],
            "axial_ratio": profile[1][1] / profile[1][0],
        },
        "textures": {
            name: project.phase(name).getHAPvalues(hist.name)["Pref.Ori."][:4]
            for name in ("Pb2WO5", "PbO_massicot")
        },
        "frozen": project.get_Frozen(),
        "vary_list": [str(item) for item in project.get_VaryList()],
    }
    output.with_suffix(".summary.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print("FINAL", json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
