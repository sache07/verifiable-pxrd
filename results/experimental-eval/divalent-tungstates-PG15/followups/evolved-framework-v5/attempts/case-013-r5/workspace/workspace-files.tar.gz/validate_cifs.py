#!/usr/bin/env python3
"""Independent pymatgen checks for the exported phase CIF files."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.core import Composition, Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(__file__).resolve().parent
EXPECTED = {
    "phase_1_PbWO4_scheelite.cif": "PbWO4",
    "phase_2_WO3_monoclinic.cif": "WO3",
    "phase_3_Pb2WO5.cif": "Pb2WO5",
    "phase_4_PbO_massicot.cif": "PbO",
    "phase_5_PbO_litharge.cif": "PbO",
}


def normalized_amounts(composition: Composition) -> dict[str, float]:
    reduced = composition.reduced_composition
    return {str(element): float(amount) for element, amount in reduced.items()}


def main() -> None:
    checks = {}
    for filename, formula in EXPECTED.items():
        structure = Structure.from_file(ROOT / filename, primitive=False)
        expected = normalized_amounts(Composition(formula))
        actual = normalized_amounts(structure.composition)
        if expected != actual:
            raise RuntimeError(f"{filename}: expected {expected}, parsed {actual}")
        distances = np.asarray(structure.distance_matrix, dtype=float)
        distances[distances < 1e-8] = np.inf
        shortest = float(np.min(distances))
        if shortest < 1.45:
            raise RuntimeError(f"{filename}: implausibly short contact {shortest:.4f} A")
        symmetry = SpacegroupAnalyzer(structure, symprec=0.02, angle_tolerance=5.0)
        checks[filename] = {
            "reduced_formula": structure.composition.reduced_formula,
            "sites_in_conventional_exported_cell": len(structure),
            "volume_angstrom3": float(structure.volume),
            "shortest_contact_angstrom": shortest,
            "recognized_space_group": symmetry.get_space_group_symbol(),
            "recognized_space_group_number": symmetry.get_space_group_number(),
        }
    print(json.dumps(checks, indent=2))


if __name__ == "__main__":
    main()
