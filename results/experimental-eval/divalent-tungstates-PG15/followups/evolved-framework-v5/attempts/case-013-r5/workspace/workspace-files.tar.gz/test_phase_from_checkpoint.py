#!/usr/bin/env python3
"""Add one candidate phase to a physical checkpoint and test it conservatively."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"


def rwp(project: G2.G2Project) -> float:
    return float(project.histogram(0).get_wR())


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in inst and len(inst[key]) > 2:
            inst[key][2] = False
    for key in ("Shift", "SurfRoughA", "SurfRoughB"):
        hist.data["Sample Parameters"][key][1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def masses(project: G2.G2Project) -> dict[str, list[float]]:
    return {
        key: [float(value[0]), float(value[1])]
        for key, value in project.histogram(0).ComputeMassFracs().items()
    }


def branch(project, tag, step, label, setup, validator, threshold=0.002):
    before = TMP / f"{tag}-a{step:02d}-before.gpx"
    work = TMP / f"{tag}-a{step:02d}.gpx"
    project.save(before)
    project.save(work)
    old = rwp(project)
    clear_flags(project)
    setup(project)
    project.set_Controls("cycles", 12)
    project.refine()
    new = rwp(project)
    physical, detail = validator(project)
    accept = np.isfinite(new) and new < old - threshold and physical
    print(
        f"ADD {step:02d} {label:22s} old={old:.6f} new={new:.6f} "
        f"accepted={accept} detail={detail}"
    )
    if accept:
        project.save(work)
        return project, True, detail
    project = G2.G2Project(str(before), newgpx=str(work))
    project.save(work)
    return project, False, detail


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base_gpx")
    parser.add_argument("name")
    parser.add_argument("cif")
    parser.add_argument("--tag", required=True)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    output = TMP / f"{args.tag}.gpx"
    project = G2.G2Project(args.base_gpx, newgpx=str(output))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(Path(args.cif).resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    source_cell = phase.get_cell()
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.10, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.10
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 800.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    clear_flags(project)
    project.save(output)
    decisions = []

    def setup_scale(p):
        p.histogram(0).data["Background"][0][1] = True
        for q in p.phases():
            q.data["Histograms"][p.histogram(0).name]["Scale"][1] = True

    def valid_scale(p):
        value = masses(p)[args.name][0]
        scale = float(p.phase(args.name).data["Histograms"][p.histogram(0).name]["Scale"][0])
        return value > 0.001 and scale > 0.0, {"fraction": value, "scale": scale}

    project, ok, detail = branch(
        project, args.tag, 1, "scales + background", setup_scale, valid_scale, 0.01
    )
    decisions.append({"step": "scale", "accepted": ok, "detail": detail})
    if not ok:
        project.save(output)
        result = {
            "accepted": False,
            "reason": "candidate scale was not stable and positive",
            "Rwp_percent": rwp(project),
            "decisions": decisions,
        }
        (TMP / f"{args.tag}.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result, indent=2))
        return

    def setup_cell(p):
        setup_scale(p)
        p.phase(args.name).data["General"]["Cell"][0] = True

    def valid_cell(p):
        cell = p.phase(args.name).get_cell()
        length_ratios = [cell[f"length_{v}"] / source_cell[f"length_{v}"] for v in "abc"]
        angle_deltas = [
            abs(cell[f"angle_{v}"] - source_cell[f"angle_{v}"])
            for v in ("alpha", "beta", "gamma")
        ]
        physical = all(0.97 <= v <= 1.03 for v in length_ratios) and all(v <= 2.0 for v in angle_deltas)
        return physical, {"cell": cell, "length_ratios": length_ratios, "angle_deltas": angle_deltas}

    project, ok, detail = branch(project, args.tag, 2, "candidate cell", setup_cell, valid_cell)
    decisions.append({"step": "cell", "accepted": ok, "detail": detail})

    def setup_size(p):
        setup_scale(p)
        q = p.phase(args.name)
        q.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [p.histogram(0)])

    def valid_size(p):
        value = float(p.phase(args.name).data["Histograms"][p.histogram(0).name]["Size"][1][0])
        return 0.04 <= value <= 1.5, value

    project, ok, detail = branch(project, args.tag, 3, "candidate size", setup_size, valid_size)
    decisions.append({"step": "size", "accepted": ok, "detail": detail})

    def setup_strain(p):
        setup_scale(p)
        q = p.phase(args.name)
        q.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [p.histogram(0)])

    def valid_strain(p):
        value = float(p.phase(args.name).data["Histograms"][p.histogram(0).name]["Mustrain"][1][0])
        return 0.0 <= value <= 8000.0, value

    project, ok, detail = branch(project, args.tag, 4, "candidate strain", setup_strain, valid_strain)
    decisions.append({"step": "strain", "accepted": ok, "detail": detail})

    # Check the documented texture axes, retaining only an in-range, meaningful gain.
    texture_base = TMP / f"{args.tag}-texture-base.gpx"
    project.save(texture_base)
    trials = []
    best = None
    for i, axis in enumerate(([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]), 1):
        trial_file = TMP / f"{args.tag}-texture-{i}.gpx"
        p = G2.G2Project(str(texture_base), newgpx=str(trial_file))
        clear_flags(p)
        setup_scale(p)
        thap = p.phase(args.name).data["Histograms"][p.histogram(0).name]
        thap["Pref.Ori."][:4] = ["MD", 1.0, True, list(axis)]
        p.set_Controls("cycles", 12)
        p.refine()
        ratio = float(p.phase(args.name).data["Histograms"][p.histogram(0).name]["Pref.Ori."][1])
        item = {"axis": list(axis), "ratio": ratio, "Rwp_percent": rwp(p), "file": str(trial_file)}
        trials.append(item)
        if 0.70 <= ratio <= 1.40 and (best is None or rwp(p) < best[0]):
            best = (rwp(p), trial_file, item)
    if best is not None and best[0] < rwp(project) - 0.01:
        project = G2.G2Project(str(best[1]), newgpx=str(output))
        project.phase(args.name).data["Histograms"][project.histogram(0).name]["Pref.Ori."][2] = False
        accepted_texture = True
    else:
        project = G2.G2Project(str(texture_base), newgpx=str(output))
        accepted_texture = False
    decisions.append({"step": "texture", "accepted": accepted_texture, "detail": best[2] if best else trials})
    clear_flags(project)
    project.save(output)

    result = {
        "accepted_scale": True,
        "candidate": args.name,
        "source_cif": str(Path(args.cif).resolve()),
        "source_cell": source_cell,
        "Rwp_percent": rwp(project),
        "mass_fractions": masses(project),
        "candidate_cell": project.phase(args.name).get_cell(),
        "candidate_HAP": project.phase(args.name).data["Histograms"][project.histogram(0).name],
        "decisions": decisions,
        "texture_trials": trials,
        "output": str(output),
    }
    (TMP / f"{args.tag}.json").write_text(
        json.dumps(result, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else float(x)) + "\n"
    )
    print(json.dumps(result, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else float(x)))


if __name__ == "__main__":
    main()
