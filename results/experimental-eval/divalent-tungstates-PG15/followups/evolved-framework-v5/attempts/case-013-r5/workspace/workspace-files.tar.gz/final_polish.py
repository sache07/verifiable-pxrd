#!/usr/bin/env python3
"""Full-grid coordinate-descent polish of already accepted model terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"


def rwp(project: G2.G2Project) -> float:
    return float(project.histogram(0).get_wR())


def clear_nonlinear(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in inst and len(inst[key]) > 2:
            inst[key][2] = False
    for key in ("Shift", "SurfRoughA", "SurfRoughB"):
        hist.data["Sample Parameters"][key][1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def ensure_linear(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def branch(project, tag, step, label, setup, validate, threshold=0.0005):
    before = TMP / f"{tag}-f{step:02d}-before.gpx"
    work = TMP / f"{tag}-f{step:02d}.gpx"
    project.save(before)
    project.save(work)
    old = rwp(project)
    clear_nonlinear(project)
    ensure_linear(project)
    project.set_Frozen()
    setup(project)
    project.set_Controls("cycles", 16)
    project.refine()
    new = rwp(project)
    physical, detail = validate(project)
    accepted = np.isfinite(new) and new < old - threshold and physical
    print(
        f"FINAL {step:02d} {label:26s} old={old:.6f} new={new:.6f} "
        f"accepted={accepted} detail={detail}"
    )
    if accepted:
        clear_nonlinear(project)
        project.save(work)
        return project, True, detail
    project = G2.G2Project(str(before), newgpx=str(work))
    clear_nonlinear(project)
    project.save(work)
    return project, False, detail


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("--tag", default="final-polish")
    parser.add_argument("--output", default=str(TMP / "final-polish.gpx"))
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.input_gpx, newgpx=args.output)
    hist = project.histogram(0)
    clear_nonlinear(project)
    ensure_linear(project)

    # Use every supplied point. Recompute linear terms before comparing
    # subsequent branches so the old/new statistics share the same grid.
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    project.set_Controls("cycles", 16)
    project.refine()
    project.save(args.output)
    print(f"FINAL 00 full-grid linear          Rwp={rwp(project):.6f}")
    decisions = []
    step = 1

    for key, bounds in (
        ("W", (2.0, 40.0)),
        ("U", (0.0, 40.0)),
        ("X", (0.1, 6.0)),
        ("SH/L", (0.005, 0.10)),
        ("Polariz.", (0.5, 1.0)),
    ):
        def setup(p, key=key, bounds=bounds):
            p.set_Controls("parmMin", bounds[0], variable=f":0:{key}")
            p.set_Controls("parmMax", bounds[1], variable=f":0:{key}")
            p.histogram(0).data["Instrument Parameters"][0][key][2] = True

        def validate(p, key=key, bounds=bounds):
            value = float(p.histogram(0).data["Instrument Parameters"][0][key][1])
            return bounds[0] <= value <= bounds[1], value

        project, ok, detail = branch(project, args.tag, step, f"instrument {key}", setup, validate)
        decisions.append({"step": f"instrument {key}", "accepted": ok, "detail": detail})
        step += 1

    # Reoptimize only texture terms already accepted; axes are not searched.
    for phase_name in [phase.name for phase in project.phases()]:
        hap = project.phase(phase_name).data["Histograms"][project.histogram(0).name]
        if abs(float(hap["Pref.Ori."][1]) - 1.0) < 1e-8:
            continue

        def setup(p, phase_name=phase_name):
            phase = p.phase(phase_name)
            h = p.histogram(0)
            p.set_Controls("parmMin", 0.70, variable=f"{phase.id}:{h.id}:MD")
            p.set_Controls("parmMax", 1.40, variable=f"{phase.id}:{h.id}:MD")
            phase.data["Histograms"][h.name]["Pref.Ori."][2] = True

        def validate(p, phase_name=phase_name):
            value = float(p.phase(phase_name).data["Histograms"][p.histogram(0).name]["Pref.Ori."][1])
            return 0.70 <= value <= 1.40, value

        project, ok, detail = branch(project, args.tag, step, f"{phase_name} texture", setup, validate)
        decisions.append({"step": f"{phase_name} texture", "accepted": ok, "detail": detail})
        step += 1

    for phase_name in [phase.name for phase in project.phases()]:
        def setup(p, phase_name=phase_name):
            phase = p.phase(phase_name)
            h = p.histogram(0)
            p.set_Controls("parmMin", 0.04, variable=f"{phase.id}:{h.id}:Size;i")
            p.set_Controls("parmMax", 1.50, variable=f"{phase.id}:{h.id}:Size;i")
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [h])

        def validate(p, phase_name=phase_name):
            value = float(p.phase(phase_name).data["Histograms"][p.histogram(0).name]["Size"][1][0])
            return 0.04 <= value <= 1.50, value

        project, ok, detail = branch(project, args.tag, step, f"{phase_name} size", setup, validate)
        decisions.append({"step": f"{phase_name} size", "accepted": ok, "detail": detail})
        step += 1

    for phase_name in [phase.name for phase in project.phases()]:
        profile = project.phase(phase_name).data["Histograms"][project.histogram(0).name]["Mustrain"][0]

        def setup(p, phase_name=phase_name, profile=profile):
            phase = p.phase(phase_name)
            h = p.histogram(0)
            hap = phase.data["Histograms"][h.name]
            if profile == "uniaxial":
                for suffix in ("i", "a"):
                    p.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{h.id}:Mustrain;{suffix}")
                    p.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:{h.id}:Mustrain;{suffix}")
                hap["Mustrain"][2] = [True, True, False]
            else:
                p.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{h.id}:Mustrain;i")
                p.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:{h.id}:Mustrain;i")
                phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [h])

        def validate(p, phase_name=phase_name, profile=profile):
            values = p.phase(phase_name).data["Histograms"][p.histogram(0).name]["Mustrain"][1]
            if profile == "uniaxial":
                eq, axial = float(values[0]), float(values[1])
                ratio = axial / eq if eq > 0 else float("inf")
                return 0 <= eq <= 8000 and 0 <= axial <= 8000 and 0.25 <= ratio <= 4.0, {"equatorial": eq, "axial": axial, "ratio": ratio}
            value = float(values[0])
            return 0 <= value <= 8000, value

        project, ok, detail = branch(project, args.tag, step, f"{phase_name} strain", setup, validate)
        decisions.append({"step": f"{phase_name} strain", "accepted": ok, "detail": detail})
        step += 1

    def setup_shift(p):
        p.set_Controls("parmMin", -800.0, variable=":0:Shift")
        p.set_Controls("parmMax", 800.0, variable=":0:Shift")
        p.histogram(0).data["Sample Parameters"]["Shift"][1] = True

    def validate_shift(p):
        value = float(p.histogram(0).data["Sample Parameters"]["Shift"][0])
        return -800 <= value <= 800, value

    project, ok, detail = branch(project, args.tag, step, "sample displacement", setup_shift, validate_shift)
    decisions.append({"step": "sample displacement", "accepted": ok, "detail": detail})
    step += 1

    cells_before = {phase.name: phase.get_cell() for phase in project.phases()}

    def setup_cells(p):
        for phase in p.phases():
            phase.data["General"]["Cell"][0] = True

    def validate_cells(p):
        ratios = {}
        physical = True
        for phase in p.phases():
            before = cells_before[phase.name]
            after = phase.get_cell()
            values = [after[f"length_{v}"] / before[f"length_{v}"] for v in "abc"]
            ratios[phase.name] = values
            physical &= all(0.99 <= value <= 1.01 for value in values)
        return physical, ratios

    project, ok, detail = branch(project, args.tag, step, "all phase cells", setup_cells, validate_cells)
    decisions.append({"step": "all phase cells", "accepted": ok, "detail": detail})

    clear_nonlinear(project)
    ensure_linear(project)
    project.set_Controls("cycles", 16)
    project.refine()
    clear_nonlinear(project)
    project.save(args.output)
    hist = project.histogram(0)
    summary = {
        "input": args.input_gpx,
        "output": args.output,
        "Rwp_percent": rwp(project),
        "Nobs": int(hist.data["data"][0]["Nobs"]),
        "limits": hist.data["Limits"],
        "decisions": decisions,
        "mass_fractions": {
            key: [float(value[0]), float(value[1])]
            for key, value in hist.ComputeMassFracs().items()
        },
    }
    (TMP / f"{args.tag}.json").write_text(
        json.dumps(summary, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else float(x)) + "\n"
    )
    print(json.dumps(summary, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else float(x)))


if __name__ == "__main__":
    main()
