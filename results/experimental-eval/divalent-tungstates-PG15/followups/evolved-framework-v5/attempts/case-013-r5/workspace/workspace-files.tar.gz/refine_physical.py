#!/usr/bin/env python3
"""Conservative physical profile/specimen/texture refinement for GSAS-II."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Callable

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"


def rwp(project: G2.G2Project) -> float:
    return float(project.histogram(0).get_wR())


def clear_inst_profile_flags(project: G2.G2Project) -> None:
    inst = project.histogram(0).data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in inst and len(inst[key]) > 2:
            inst[key][2] = False


def clear_hap_profile_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False


def run_branch(
    project: G2.G2Project,
    tag: str,
    step: int,
    label: str,
    setup: Callable[[G2.G2Project], None],
    validate: Callable[[G2.G2Project], tuple[bool, object]],
    min_improvement: float = 0.001,
) -> tuple[G2.G2Project, bool, object]:
    before = TMP / f"{tag}-p{step:02d}-before.gpx"
    work = TMP / f"{tag}-p{step:02d}.gpx"
    project.save(before)
    project.save(work)
    old = rwp(project)
    setup(project)
    project.set_Controls("cycles", 12)
    project.refine()
    new = rwp(project)
    physical, details = validate(project)
    accepted = np.isfinite(new) and new < old - min_improvement and physical
    print(
        f"PHYS {step:02d} {label:24s} old={old:.6f} new={new:.6f} "
        f"accepted={accepted} details={details}"
    )
    if accepted:
        project.save(work)
        return project, True, details
    project = G2.G2Project(str(before), newgpx=str(work))
    project.save(work)
    return project, False, details


def instrument_step(
    project: G2.G2Project,
    tag: str,
    step: int,
    key: str,
    bounds: tuple[float, float],
) -> tuple[G2.G2Project, bool, object]:
    def setup(p: G2.G2Project) -> None:
        clear_inst_profile_flags(p)
        p.set_Frozen()
        p.set_Controls("parmMin", bounds[0], variable=f":0:{key}")
        p.set_Controls("parmMax", bounds[1], variable=f":0:{key}")
        p.histogram(0).data["Instrument Parameters"][0][key][2] = True

    def validate(p: G2.G2Project) -> tuple[bool, object]:
        value = float(p.histogram(0).data["Instrument Parameters"][0][key][1])
        return bounds[0] <= value <= bounds[1], value

    return run_branch(project, tag, step, f"instrument {key}", setup, validate)


def phase_profile_step(
    project: G2.G2Project,
    tag: str,
    step: int,
    phase_name: str,
    mode: str,
    bounds: tuple[float, float],
) -> tuple[G2.G2Project, bool, object]:
    def setup(p: G2.G2Project) -> None:
        clear_inst_profile_flags(p)
        clear_hap_profile_flags(p)
        p.set_Frozen()
        phase = p.phase(phase_name)
        hist = p.histogram(0)
        variable = f"{phase.id}:{hist.id}:{mode};i"
        p.set_Controls("parmMin", bounds[0], variable=variable)
        p.set_Controls("parmMax", bounds[1], variable=variable)
        if mode == "Size":
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "refine": True}}, [hist]
            )
        else:
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
            )

    def validate(p: G2.G2Project) -> tuple[bool, object]:
        hap = p.phase(phase_name).data["Histograms"][p.histogram(0).name]
        value = float(hap[mode][1][0])
        return bounds[0] <= value <= bounds[1], value

    return run_branch(
        project, tag, step, f"{phase_name} {mode}", setup, validate
    )


def calibration_shift_steps(
    project: G2.G2Project, tag: str, step: int
) -> tuple[G2.G2Project, list[dict], int]:
    decisions = []
    hist = project.histogram(0)

    def setup_shift(p: G2.G2Project) -> None:
        h = p.histogram(0)
        h.data["Instrument Parameters"][0]["Zero"][1] = 0.20
        h.data["Instrument Parameters"][0]["Zero"][2] = False
        h.data["Sample Parameters"]["Shift"] = [0.0, True]

    def valid_shift(p: G2.G2Project) -> tuple[bool, object]:
        value = float(p.histogram(0).data["Sample Parameters"]["Shift"][0])
        return -800.0 <= value <= 800.0, value

    project, ok, detail = run_branch(
        project, tag, step, "sample displacement", setup_shift, valid_shift
    )
    decisions.append({"step": "sample displacement", "accepted": ok, "value": detail})
    step += 1
    if not ok:
        return project, decisions, step

    def setup_zero(p: G2.G2Project) -> None:
        h = p.histogram(0)
        h.data["Sample Parameters"]["Shift"][1] = False
        h.data["Instrument Parameters"][0]["Zero"][2] = True

    def valid_zero(p: G2.G2Project) -> tuple[bool, object]:
        value = float(p.histogram(0).data["Instrument Parameters"][0]["Zero"][1])
        return -0.5 <= value <= 0.5, value

    project, ok, detail = run_branch(
        project, tag, step, "zero after displacement", setup_zero, valid_zero
    )
    decisions.append({"step": "zero after displacement", "accepted": ok, "value": detail})
    step += 1
    return project, decisions, step


def texture_search(
    project: G2.G2Project,
    tag: str,
    step: int,
    phase_name: str,
) -> tuple[G2.G2Project, bool, dict, int]:
    axes = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])
    base_file = TMP / f"{tag}-texture-{phase_name}-base.gpx"
    project.save(base_file)
    best = None
    trials = []
    for trial, axis in enumerate(axes, 1):
        branch_file = TMP / f"{tag}-texture-{phase_name}-{trial}.gpx"
        p = G2.G2Project(str(base_file), newgpx=str(branch_file))
        clear_inst_profile_flags(p)
        clear_hap_profile_flags(p)
        p.set_Frozen()
        hist = p.histogram(0)
        hap = p.phase(phase_name).data["Histograms"][hist.name]
        p.set_Controls("parmMin", 0.70, variable=f"{p.phase(phase_name).id}:{hist.id}:MD")
        p.set_Controls("parmMax", 1.40, variable=f"{p.phase(phase_name).id}:{hist.id}:MD")
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        p.set_Controls("cycles", 12)
        p.refine()
        ratio = float(p.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."][1])
        trial_info = {"axis": list(axis), "ratio": ratio, "Rwp": rwp(p)}
        trials.append(trial_info)
        if 0.70 <= ratio <= 1.40 and (best is None or rwp(p) < best[0]):
            best = (rwp(p), branch_file, trial_info)
    old = rwp(project)
    accepted = best is not None and best[0] < old - 0.01
    print(
        f"TEXT {step:02d} {phase_name:24s} old={old:.6f} "
        f"best={None if best is None else best[0]:} accepted={accepted} trials={trials}"
    )
    if accepted and best is not None:
        project = G2.G2Project(str(best[1]), newgpx=str(TMP / f"{tag}-p{step:02d}.gpx"))
        # Preserve the accepted ratio while avoiding correlation in later trials.
        project.phase(phase_name).data["Histograms"][project.histogram(0).name]["Pref.Ori."][2] = False
        project.save()
        return project, True, best[2], step + 1
    project = G2.G2Project(str(base_file), newgpx=str(TMP / f"{tag}-p{step:02d}.gpx"))
    project.save()
    return project, False, {"trials": trials}, step + 1


def surface_roughness_step(
    project: G2.G2Project, tag: str, step: int
) -> tuple[G2.G2Project, bool, object]:
    def setup(p: G2.G2Project) -> None:
        p.set_Frozen()
        p.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        p.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
        p.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        p.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
        sample = p.histogram(0).data["Sample Parameters"]
        sample["SurfRoughA"] = [0.20, True]
        sample["SurfRoughB"] = [0.10, True]

    def validate(p: G2.G2Project) -> tuple[bool, object]:
        sample = p.histogram(0).data["Sample Parameters"]
        a = float(sample["SurfRoughA"][0])
        b = float(sample["SurfRoughB"][0])
        return 0.05 <= a <= 0.60 and 0.02 <= b <= 0.50, {"A": a, "B": b}

    return run_branch(
        project, tag, step, "surface roughness", setup, validate, min_improvement=0.005
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("--tag", default="physical")
    parser.add_argument("--output", default=str(TMP / "physical.gpx"))
    parser.add_argument("--skip-calibration", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.input_gpx, newgpx=args.output)
    decisions = []
    step = 1

    # Instrument terms are introduced individually and then held.
    for key, bounds in (
        ("W", (2.0, 40.0)),
        ("U", (0.0, 40.0)),
        ("X", (0.1, 6.0)),
        ("SH/L", (0.005, 0.10)),
        ("Polariz.", (0.5, 1.0)),
    ):
        project, ok, detail = instrument_step(project, args.tag, step, key, bounds)
        decisions.append({"step": f"instrument {key}", "accepted": ok, "value": detail})
        step += 1

    if not args.skip_calibration:
        project, cal_decisions, step = calibration_shift_steps(project, args.tag, step)
        decisions.extend(cal_decisions)

    for phase in [p.name for p in project.phases()]:
        project, ok, detail = phase_profile_step(
            project, args.tag, step, phase, "Size", (0.04, 1.5)
        )
        decisions.append({"step": f"{phase} size", "accepted": ok, "value": detail})
        step += 1
    for phase in [p.name for p in project.phases()]:
        project, ok, detail = phase_profile_step(
            project, args.tag, step, phase, "Mustrain", (0.0, 8000.0)
        )
        decisions.append({"step": f"{phase} strain", "accepted": ok, "value": detail})
        step += 1

    for phase in [p.name for p in project.phases()]:
        project, ok, detail, step = texture_search(
            project, args.tag, step, phase
        )
        decisions.append({"step": f"{phase} texture", "accepted": ok, "value": detail})

    project, ok, detail = surface_roughness_step(project, args.tag, step)
    decisions.append({"step": "surface roughness", "accepted": ok, "value": detail})
    step += 1

    clear_inst_profile_flags(project)
    clear_hap_profile_flags(project)
    hist = project.histogram(0)
    hist.data["Instrument Parameters"][0]["Zero"][2] = False
    for key in ("Shift", "SurfRoughA", "SurfRoughB"):
        hist.data["Sample Parameters"][key][1] = False
    project.save(args.output)

    summary = {
        "input": args.input_gpx,
        "output": args.output,
        "Rwp_percent": rwp(project),
        "decisions": decisions,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "mass_fractions": {
            name: {"value": val[0], "su": val[1]}
            for name, val in hist.ComputeMassFracs().items()
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "hap": phase.data["Histograms"][hist.name],
            }
            for phase in project.phases()
        },
    }
    (TMP / f"{args.tag}-physical.json").write_text(
        json.dumps(
            summary,
            indent=2,
            default=lambda x: x.tolist() if hasattr(x, "tolist") else float(x),
        )
        + "\n"
    )
    print(
        json.dumps(
            summary,
            indent=2,
            default=lambda x: x.tolist() if hasattr(x, "tolist") else float(x),
        )
    )


if __name__ == "__main__":
    main()
