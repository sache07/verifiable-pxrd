#!/usr/bin/env python3
"""Create and conservatively refine GSAS-II screening projects.

Run with the GSAS-II Python interpreter. These projects are checkpoints for
phase-inventory testing; final refinement and exports are handled separately.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"


def write_observed_xye() -> Path:
    raw = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    out = TMP / "observed.xye"
    sigma = np.sqrt(np.maximum(raw["intensity"], 1.0))
    np.savetxt(
        out,
        np.column_stack([raw["two_theta_deg"], raw["intensity"], sigma]),
        fmt="%.8f %.8f %.8f",
        header="two_theta_deg intensity sigma",
    )
    return out


def write_instrument() -> Path:
    out = TMP / "screening.instprm"
    out.write_text(
        "#GSAS-II Cu Kalpha Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return out


def set_starting_values(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"][1] = 0.30
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.05, 99.95],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 15,
                "coeffs": [700.0] + [0.0] * 14,
                "refine": True,
            },
        }
    )
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.08
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 800.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]


def checkpoint(project: G2.G2Project, tag: str, step: int) -> None:
    working_file = project.filename
    project.save(TMP / f"{tag}-s{step:02d}.gpx")
    # Keep subsequent refinements on the working project so this checkpoint
    # remains an immutable replay of the labeled step.
    project.save(working_file)


def safe_refine(project: G2.G2Project, tag: str, step: int, label: str) -> None:
    project.set_Controls("cycles", 8)
    project.refine()
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    print(
        f"STEP {step:02d} {label:22s} "
        f"Rwp={hist.get_wR()!s} GOF={rvals.get('GOF', rvals.get('chisq', None))!s} "
        f"Nvar={len(cov.get('varyList', []))}"
    )
    checkpoint(project, tag, step)


def summarize(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    masses = {}
    try:
        masses = {
            key: {"weight_fraction": val[0], "su": val[1]}
            for key, val in hist.ComputeMassFracs().items()
        }
    except Exception as exc:  # noqa: BLE001
        masses = {"error": str(exc)}
    phases = []
    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        phases.append(
            {
                "name": p.name,
                "composition": p.composition,
                "cell": p.get_cell(),
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    return {
        "Rwp_percent": hist.get_wR(),
        "residuals": hist.data["data"][0],
        "Rvals": cov.get("Rvals", {}),
        "mass_fractions": masses,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "phases": phases,
    }


def run(args: argparse.Namespace) -> None:
    TMP.mkdir(exist_ok=True)
    G2.SetPrintLevel("warn")
    datafile = write_observed_xye()
    instfile = write_instrument()
    out = TMP / f"{args.tag}.gpx"
    project = G2.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(datafile), str(instfile), fmthint="xye"
    )
    for item in args.phase:
        name, path = item.split("=", 1)
        project.add_phase(
            str(Path(path).resolve()),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
    set_starting_values(project)
    checkpoint(project, args.tag, 0)

    # Stable inventory screen: linear terms, calibration, cells, then profile.
    safe_refine(project, args.tag, 1, "background + scales")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    safe_refine(project, args.tag, 2, "+ zero")
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    safe_refine(project, args.tag, 3, "+ phase cells")
    if args.stop_after == 3:
        project.save(out)
        summary = summarize(project)
        (TMP / f"{args.tag}-summary.json").write_text(
            json.dumps(summary, indent=2, default=lambda value: float(value)) + "\n"
        )
        print(json.dumps(summary, indent=2, default=lambda value: float(value)))
        return
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    safe_refine(project, args.tag, 4, "+ W/X")
    hist.set_refinements({"Instrument Parameters": ["U", "V"]})
    safe_refine(project, args.tag, 5, "+ U/V")
    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
    safe_refine(project, args.tag, 6, "+ isotropic size")
    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    safe_refine(project, args.tag, 7, "+ isotropic strain")

    project.save(out)
    summary = summarize(project)
    (TMP / f"{args.tag}-summary.json").write_text(
        json.dumps(summary, indent=2, default=lambda value: float(value)) + "\n"
    )
    print(json.dumps(summary, indent=2, default=lambda value: float(value)))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tag", required=True)
    parser.add_argument(
        "--phase", action="append", required=True, help="phase_name=/path/to/file.cif"
    )
    parser.add_argument("--stop-after", type=int, choices=[3, 7], default=7)
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
