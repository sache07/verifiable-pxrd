#!/usr/bin/env python3
"""Initial peak extraction and COD candidate screening for the specimen pattern."""

from __future__ import annotations

import csv
import gzip
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, minimum_filter1d
from scipy.signal import find_peaks, peak_widths, savgol_filter


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INDEX = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/venv/"
    "lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz"
)
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"
)


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def load_pattern() -> tuple[np.ndarray, np.ndarray]:
    a = np.genfromtxt(PATTERN, delimiter=",", names=True)
    return a["two_theta_deg"], a["intensity"]


def main() -> None:
    x, y = load_pattern()
    step = float(np.median(np.diff(x)))
    # A robust rolling-minimum envelope, then broad smoothing, gives a useful
    # peak-only trace without assuming the eventual Rietveld background.
    floor = minimum_filter1d(y, size=max(5, round(1.2 / step)), mode="nearest")
    background = savgol_filter(floor, max(5, round(2.5 / step)) | 1, 2)
    net = y - background
    smooth = gaussian_filter1d(net, 0.025 / step)
    noise = 1.4826 * np.median(np.abs((net - smooth) - np.median(net - smooth)))
    peaks, props = find_peaks(
        smooth,
        prominence=max(8 * noise, 120),
        distance=max(2, round(0.07 / step)),
        width=max(1, round(0.025 / step)),
    )
    widths = peak_widths(smooth, peaks, rel_height=0.5)[0] * step
    order = np.argsort(props["prominences"])[::-1]
    print(f"points={len(x)} range={x[0]:.6f}..{x[-1]:.6f} step={step:.7f}")
    print(
        f"counts min/median/max={y.min():.1f}/{np.median(y):.1f}/{y.max():.1f}; "
        f"estimated point noise={noise:.2f}; peaks={len(peaks)}"
    )
    print("rank  2theta       d(A)      height    prominence   FWHM(deg)")
    wavelength = 1.540598
    for rank, j in enumerate(order[:120], 1):
        i = peaks[j]
        d = wavelength / (2 * np.sin(np.deg2rad(x[i] / 2)))
        print(
            f"{rank:3d} {x[i]:10.5f} {d:10.5f} {net[i]:10.1f} "
            f"{props['prominences'][j]:12.1f} {widths[j]:11.5f}"
        )

    with gzip.open(INDEX, "rt") as handle:
        index = json.load(handle)
    print("\nFrozen-index candidates:")
    for key in ("O-Pb-W", "O-Pb", "O-W"):
        print(f"[{key}]")
        for formula, cod_id, sg_no, r_value in index.get(key, []):
            print(
                f"  {cod_id}  {formula:16s} SG={sg_no:3d} R={r_value!s:>7s} "
                f"{cif_path(cod_id)}"
            )

    out = ROOT / ".tmp" / "peak_list.csv"
    out.parent.mkdir(exist_ok=True)
    with out.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "d_angstrom", "net_height", "prominence", "fwhm_deg"])
        for j in np.argsort(x[peaks]):
            i = peaks[j]
            d = wavelength / (2 * np.sin(np.deg2rad(x[i] / 2)))
            writer.writerow([x[i], d, net[i], props["prominences"][j], widths[j]])


if __name__ == "__main__":
    main()
