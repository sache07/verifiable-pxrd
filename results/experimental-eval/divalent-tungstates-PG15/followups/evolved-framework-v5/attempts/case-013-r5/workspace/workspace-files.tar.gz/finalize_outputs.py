#!/usr/bin/env python3
"""Export the selected replayable GSAS-II checkpoint into submission files."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE_GPX = ROOT / ".tmp" / "fullgrid-polish2.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_INFO = {
    "PbWO4_scheelite": {
        "name": "PbWO4 (scheelite)",
        "formula": "PbWO4",
        "cif_path": "phase_1_PbWO4_scheelite.cif",
        "model_provenance": "COD 9009811; refined against this specimen",
    },
    "WO3_monoclinic": {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif_path": "phase_2_WO3_monoclinic.cif",
        "model_provenance": "COD 2311041; refined against this specimen",
    },
    "Pb2WO5": {
        "name": "Pb2WO5",
        "formula": "Pb2WO5",
        "cif_path": "phase_3_Pb2WO5.cif",
        "model_provenance": (
            "Pb2MoO5 topology from COD 7220560 with Mo(VI) replaced by W(VI); "
            "bounded coordinates refined against this specimen"
        ),
    },
    "PbO_massicot": {
        "name": "PbO (massicot)",
        "formula": "PbO",
        "cif_path": "phase_4_PbO_massicot.cif",
        "model_provenance": "COD 2310433; refined against this specimen",
    },
    "PbO_litharge": {
        "name": "PbO (litharge)",
        "formula": "PbO",
        "cif_path": "phase_5_PbO_litharge.cif",
        "model_provenance": "COD 9012700 (origin transformed for GSAS-II); refined against this specimen",
    },
}


def native(value):
    """Convert NumPy values and nested containers to JSON-native objects."""
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, dict):
        return {str(key): native(val) for key, val in value.items()}
    if isinstance(value, (list, tuple)):
        return [native(val) for val in value]
    return value


def main() -> None:
    if not SOURCE_GPX.is_file():
        raise FileNotFoundError(SOURCE_GPX)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE_GPX), newgpx=str(FINAL_GPX))
    project.save(str(FINAL_GPX))

    # Reload the exact deliverable before deriving any other output. This makes
    # all exported arrays and statistics a direct replay of final.gpx.
    project = G2.G2Project(str(FINAL_GPX))
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    observed = np.asarray(arrays[1], dtype=float)
    calculated = np.asarray(arrays[3], dtype=float)
    background = np.asarray(arrays[4], dtype=float)
    difference = np.asarray(arrays[5], dtype=float)
    if not (len(x) == len(observed) == len(calculated) == len(background) == len(difference)):
        raise RuntimeError("Profile arrays have inconsistent lengths")
    if not np.allclose(difference, observed - calculated, rtol=0.0, atol=1e-7):
        raise RuntimeError("Stored GSAS-II difference profile is not observed minus calculated")

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_intensity",
                "background_intensity",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    raw_fractions = hist.ComputeMassFracs()
    total_fraction = sum(float(values[0]) for values in raw_fractions.values())
    if total_fraction <= 0:
        raise RuntimeError("Non-positive crystalline phase-fraction total")

    phases = []
    for phase in project.phases():
        if phase.name not in PHASE_INFO:
            raise KeyError(f"No export metadata for phase {phase.name!r}")
        info = PHASE_INFO[phase.name]
        cif_path = ROOT / info["cif_path"]
        phase.export_CIF(str(cif_path))
        fraction, formal_esd = raw_fractions[phase.name]
        fraction = float(fraction) / total_fraction
        formal_esd = float(formal_esd) / total_fraction
        cell = {key: float(value) for key, value in phase.get_cell().items()}
        phases.append(
            {
                "name": info["name"],
                "model_phase_name": phase.name,
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cell": cell,
                "cif_path": info["cif_path"],
                "weight_fraction": fraction,
                "weight_percent": 100.0 * fraction,
                "weight_fraction_formal_esd": formal_esd,
                "model_provenance": info["model_provenance"],
            }
        )

    fraction_sum = sum(phase["weight_fraction"] for phase in phases)
    if abs(fraction_sum - 1.0) > 1e-10:
        raise RuntimeError(f"Normalized phase fractions sum to {fraction_sum}")

    residuals = hist.data["data"][0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    nvars = len(covariance.get("varyList", []))
    fit_statistics = {
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(residuals["R"]),
        "R_expected_percent": float(residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "number_of_observations": int(residuals["Nobs"]),
        "number_of_refined_variables_in_final_cycle": int(nvars),
        "two_theta_range_deg": [float(x[0]), float(x[-1])],
        "full_input_grid_used": len(x) == 8282,
    }

    result = {
        "analysis": "multiphase Rietveld refinement",
        "radiation": {
            "target": "Cu",
            "Kalpha1_wavelength_angstrom": 1.540598,
            "Kalpha2_wavelength_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_intensity_ratio": 0.5,
        },
        "phase_fraction_basis": "normalized over the five modeled crystalline phases",
        "phases": phases,
        "fit_statistics": fit_statistics,
        "project_path": FINAL_GPX.name,
        "profile_path": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(native(result), indent=2) + "\n")

    print(
        json.dumps(
            {
                "Rwp_percent": fit_statistics["Rwp_percent"],
                "Rp_percent": fit_statistics["Rp_percent"],
                "GOF": fit_statistics["goodness_of_fit"],
                "chi_square": fit_statistics["chi_square"],
                "Nobs": fit_statistics["number_of_observations"],
                "Nvars": fit_statistics["number_of_refined_variables_in_final_cycle"],
                "fractions": {phase["model_phase_name"]: phase["weight_fraction"] for phase in phases},
                "space_groups": {phase["model_phase_name"]: phase["space_group"] for phase in phases},
                "cells": {phase["model_phase_name"]: phase["cell"] for phase in phases},
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
