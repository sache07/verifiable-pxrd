#!/usr/bin/env python3
"""Inspect and profile-screen chemically plausible frozen-COD structures."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from scipy.ndimage import gaussian_filter1d, minimum_filter1d
from scipy.optimize import nnls
from scipy.signal import savgol_filter


ROOT = Path(__file__).resolve().parent
INDEX = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/venv/"
    "lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz"
)
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
LAMBDA1 = 1.540598
LAMBDA2 = 1.544426


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def calc_trace(
    peak_positions: np.ndarray,
    peak_intensities: np.ndarray,
    x: np.ndarray,
    shift: float,
    fwhm: float,
) -> np.ndarray:
    """Simple normalized K-alpha doublet trace for screening, not refinement."""
    sticks = np.zeros_like(x)
    step = np.median(np.diff(x))
    for pos, inten in zip(peak_positions, peak_intensities, strict=True):
        p1 = pos + shift
        # Bragg-law transform from K-alpha1 to K-alpha2.
        s2 = np.sin(np.deg2rad(pos / 2)) * LAMBDA2 / LAMBDA1
        p2 = np.rad2deg(2 * np.arcsin(s2)) + shift if s2 < 1 else 999.0
        for p, amp in ((p1, inten), (p2, 0.5 * inten)):
            q = (p - x[0]) / step
            i0 = int(np.floor(q))
            frac = q - i0
            if 0 <= i0 < len(sticks):
                sticks[i0] += amp * (1 - frac)
            if 0 <= i0 + 1 < len(sticks):
                sticks[i0 + 1] += amp * frac
    sigma_pts = fwhm / (2.354820045 * step)
    trace = gaussian_filter1d(sticks, sigma_pts)
    m = np.max(trace)
    return trace / m if m else trace


def main() -> None:
    raw = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    x, y = raw["two_theta_deg"], raw["intensity"]
    step = np.median(np.diff(x))
    floor = minimum_filter1d(y, size=round(1.2 / step), mode="nearest")
    background = savgol_filter(floor, round(2.5 / step) | 1, 2)
    net = np.maximum(y - background, 0)
    # Weight lower-intensity regions enough to expose secondary phases.
    weights = 1.0 / np.sqrt(np.maximum(y, 100))

    with gzip.open(INDEX, "rt") as handle:
        index = json.load(handle)
    records = []
    wanted_formulas = {
        "PbWO4",
        "Pb7W8O28.8",
        "PbO",
        "Pb3O4",
        "PbO2",
        "WO3",
    }
    for key in ("O-Pb-W", "O-Pb", "O-W"):
        for formula, cod_id, sg_no, r_value in index[key]:
            if formula in wanted_formulas:
                records.append((key, formula, cod_id, sg_no, r_value))

    structures: dict[str, Structure] = {}
    print("Candidate structures")
    print("id       formula          reported/detected SG          lattice(A,deg)                 density min_d")
    for key, formula, cod_id, sg_no, r_value in records:
        try:
            s = Structure.from_file(cif_path(cod_id), primitive=False)
            structures[cod_id] = s
            try:
                spga = SpacegroupAnalyzer(s, symprec=0.02, angle_tolerance=3)
                detected = f"{spga.get_space_group_symbol()}({spga.get_space_group_number()})"
            except Exception as exc:  # noqa: BLE001
                detected = f"ERR:{type(exc).__name__}"
            abc = s.lattice.abc
            ang = s.lattice.angles
            distances = s.distance_matrix
            min_d = np.min(distances[np.nonzero(distances)])
            print(
                f"{cod_id}  {formula:15s} {sg_no:3d}/{detected:18s} "
                f"{abc[0]:6.3f},{abc[1]:6.3f},{abc[2]:6.3f};"
                f"{ang[0]:6.2f},{ang[1]:6.2f},{ang[2]:6.2f} "
                f"{s.density:7.3f} {min_d:5.3f}"
            )
        except Exception as exc:  # noqa: BLE001
            print(f"{cod_id}  {formula:15s} LOAD_ERROR {exc}")

    # Optimize each reference's broadening and a constant screening shift.
    calc = XRDCalculator(wavelength=LAMBDA1)
    peak_data: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    for cod_id, structure in structures.items():
        patt = calc.get_pattern(
            structure, two_theta_range=(max(1.0, x[0] - 1), x[-1] + 1)
        )
        peak_data[cod_id] = (np.asarray(patt.x), np.asarray(patt.y))

    print("\nIndividual weighted NNLS screen")
    print("id       formula          shift  fwhm    scale       weighted_resid  cosine")
    best_traces: dict[str, np.ndarray] = {}
    fit_mask = (x >= 15) & (x <= 95)
    wy = net[fit_mask] * weights[fit_mask]
    for key, formula, cod_id, sg_no, r_value in records:
        if cod_id not in structures:
            continue
        best = None
        for shift in np.arange(-0.40, 0.401, 0.02):
            for fwhm in np.arange(0.12, 0.421, 0.04):
                t = calc_trace(*peak_data[cod_id], x, shift, fwhm)
                wt = t[fit_mask] * weights[fit_mask]
                scale = max(0.0, float(np.dot(wt, wy) / max(np.dot(wt, wt), 1e-30)))
                resid = float(np.mean((wy - scale * wt) ** 2))
                cosine = float(np.dot(wt, wy) / np.sqrt(np.dot(wt, wt) * np.dot(wy, wy)))
                score = resid
                if best is None or score < best[0]:
                    best = (score, shift, fwhm, scale, cosine, t)
        assert best is not None
        best_traces[cod_id] = best[-1]
        print(
            f"{cod_id}  {formula:15s} {best[1]:+6.2f} {best[2]:5.2f} "
            f"{best[3]:10.1f} {best[0]:14.5f} {best[4]:7.4f}"
        )

    # Approximate multiphase screen with all best individual traces. It is
    # intentionally permissive; candidates are judged later by GSAS-II.
    ids = list(best_traces)
    a = np.column_stack([best_traces[i][fit_mask] * weights[fit_mask] for i in ids])
    coeff, resid = nnls(a, wy)
    print(f"\nAll-candidate NNLS residual norm={resid:.4f}")
    for cod_id, c in sorted(zip(ids, coeff, strict=True), key=lambda z: z[1], reverse=True):
        if c > 1:
            formula = next(r[1] for r in records if r[2] == cod_id)
            print(f"  {cod_id} {formula:15s} coefficient={c:.2f}")

    print("\nStrong theoretical peaks for candidates with appreciable individual cosine")
    for key, formula, cod_id, sg_no, r_value in records:
        if cod_id not in structures:
            continue
        positions, intensities = peak_data[cod_id]
        strong = [(p, i) for p, i in zip(positions, intensities, strict=True) if i >= 8]
        print(f"{cod_id} {formula}: " + ", ".join(f"{p:.2f}({i:.0f})" for p, i in strong[:24]))


if __name__ == "__main__":
    main()
