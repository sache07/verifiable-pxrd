#!/usr/bin/env python3
"""Refine one bounded isotropic displacement parameter per phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"


def rwp(project: G2.G2Project) -> float:
    return float(project.histogram(0).get_wR())


def clear_atom_flags(project: G2.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def linear_refine(project: G2.G2Project) -> None:
    project.set_Controls("cycles", 12)
    project.refine()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("--tag", default="uiso")
    parser.add_argument("--output", default=str(TMP / "uiso.gpx"))
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.input_gpx, newgpx=args.output)
    decisions = []
    for step, phase_name in enumerate([phase.name for phase in project.phases()], 1):
        before = TMP / f"{args.tag}-d{step:02d}-before.gpx"
        trial = TMP / f"{args.tag}-d{step:02d}-trial.gpx"
        work = TMP / f"{args.tag}-d{step:02d}.gpx"
        project.save(before)
        project.save(trial)
        old = rwp(project)
        clear_atom_flags(project)
        phase = project.phase(phase_name)
        old_values = [float(atom.uiso) for atom in phase.atoms()]
        start = float(np.clip(np.median(old_values), 0.003, 0.020))
        variables = []
        for i, atom in enumerate(phase.atoms()):
            atom.uiso = start
            atom.refinement_flags = "U"
            variables.append(f"{phase.id}::AUiso:{i}")
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
        project.set_Frozen()
        project.set_Controls("parmMin", 0.003, variable=variables[0])
        project.set_Controls("parmMax", 0.020, variable=variables[0])
        linear_refine(project)
        refined = [float(atom.uiso) for atom in project.phase(phase_name).atoms()]
        direct_rwp = rwp(project)
        physical = all(0.003 <= value <= 0.020 for value in refined)
        mode = "refined"
        candidate = project
        candidate_rwp = direct_rwp

        if not physical:
            # Limits on constrained variables are not always applied by GSAS-II;
            # evaluate the indicated physical boundary with ADPs fixed.
            boundary = 0.003 if float(np.median(refined)) < 0.003 else 0.020
            candidate = G2.G2Project(str(before), newgpx=str(work))
            clear_atom_flags(candidate)
            for atom in candidate.phase(phase_name).atoms():
                atom.uiso = boundary
            linear_refine(candidate)
            candidate_rwp = rwp(candidate)
            refined = [boundary] * len(candidate.phase(phase_name).atoms())
            physical = True
            mode = "fixed_boundary"

        accepted = physical and candidate_rwp < old - 0.002
        print(
            f"UISO {step:02d} {phase_name:24s} old={old:.6f} "
            f"direct={direct_rwp:.6f} final={candidate_rwp:.6f} "
            f"values={refined} mode={mode} accepted={accepted}"
        )
        if accepted:
            project = candidate
            project.save(work)
        else:
            project = G2.G2Project(str(before), newgpx=str(work))
            project.save(work)
        clear_atom_flags(project)
        decisions.append(
            {
                "phase": phase_name,
                "accepted": accepted,
                "mode": mode,
                "old_values_A2": old_values,
                "candidate_values_A2": refined,
                "direct_Rwp_percent": direct_rwp,
                "candidate_Rwp_percent": candidate_rwp,
            }
        )
    clear_atom_flags(project)
    project.save(args.output)
    summary = {
        "input": args.input_gpx,
        "output": args.output,
        "Rwp_percent": rwp(project),
        "decisions": decisions,
        "uiso_A2": {
            phase.name: {atom.label: float(atom.uiso) for atom in phase.atoms()}
            for phase in project.phases()
        },
    }
    (TMP / f"{args.tag}-uiso.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
