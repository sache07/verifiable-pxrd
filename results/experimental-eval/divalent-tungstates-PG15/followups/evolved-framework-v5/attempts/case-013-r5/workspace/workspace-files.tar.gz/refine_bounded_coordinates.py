#!/usr/bin/env python3
"""Try capped coordinate moves along unconstrained least-squares directions."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"


def clear_atom_flags(project: G2.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def metric(phase: G2.G2Phase) -> np.ndarray:
    cell = phase.get_cell()
    _, g = G2lat.cell2Gmat(
        [
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ]
    )
    return g


def capped_step(project, tag, step, label, phase_name, elements, cap_a):
    before_file = TMP / f"{tag}-b{step:02d}-before.gpx"
    work_file = TMP / f"{tag}-b{step:02d}.gpx"
    target_file = TMP / f"{tag}-b{step:02d}-raw.gpx"
    project.save(before_file)
    project.save(target_file)
    old = float(project.histogram(0).get_wR())
    phase = project.phase(phase_name)
    start = {atom.label: np.asarray(atom.coordinates, float) for atom in phase.atoms()}
    clear_atom_flags(project)
    for atom in phase.atoms():
        if atom.element in elements:
            atom.refinement_flags = "X"
    project.set_Controls("cycles", 12)
    project.refine()
    raw_rwp = float(project.histogram(0).get_wR())
    raw = {atom.label: np.asarray(atom.coordinates, float) for atom in project.phase(phase_name).atoms()}
    g = metric(project.phase(phase_name))
    deltas = {}
    distances = {}
    for atom in project.phase(phase_name).atoms():
        if atom.element not in elements:
            continue
        delta = raw[atom.label] - start[atom.label]
        delta -= np.round(delta)
        deltas[atom.label] = delta
        distances[atom.label] = float(np.sqrt(delta @ g @ delta))
    raw_max = max(distances.values(), default=0.0)
    fraction = min(1.0, cap_a / raw_max) if raw_max > 0 else 0.0
    # Reload the exact physical start, apply only the capped part of the
    # least-squares direction and refine linear terms with coordinates fixed.
    project = G2.G2Project(str(before_file), newgpx=str(work_file))
    clear_atom_flags(project)
    for atom in project.phase(phase_name).atoms():
        if atom.label in deltas:
            atom.coordinates = (start[atom.label] + fraction * deltas[atom.label]) % 1.0
    project.set_Controls("cycles", 12)
    project.refine()
    new = float(project.histogram(0).get_wR())
    bad = project.phase(phase_name).ShortDistances(useAll=True)
    accepted = np.isfinite(new) and new < old - 0.002 and not bad and fraction > 0
    detail = {
        "raw_Rwp_percent": raw_rwp,
        "raw_max_displacement_A": raw_max,
        "cap_A": cap_a,
        "fraction_of_raw_move": fraction,
        "raw_displacements_A": distances,
        "short_contacts": bad,
    }
    print(
        f"BOUND {step:02d} {label:24s} old={old:.6f} new={new:.6f} "
        f"raw_max={raw_max:.4f}A fraction={fraction:.4f} accepted={accepted} short={bad}"
    )
    if accepted:
        clear_atom_flags(project)
        project.save(work_file)
        return project, True, detail
    project = G2.G2Project(str(before_file), newgpx=str(work_file))
    clear_atom_flags(project)
    project.save(work_file)
    return project, False, detail


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("--tag", default="bounded")
    parser.add_argument("--output", default=str(TMP / "bounded-coordinates.gpx"))
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.input_gpx, newgpx=args.output)
    plan = [
        ("WO3 heavy atoms", "WO3_monoclinic", {"W"}, 0.08),
        ("Pb2WO5 heavy atoms", "Pb2WO5", {"Pb", "W"}, 0.08),
        ("scheelite oxygen", "PbWO4_scheelite", {"O"}, 0.10),
        ("WO3 oxygen", "WO3_monoclinic", {"O"}, 0.10),
        ("Pb2WO5 oxygen", "Pb2WO5", {"O"}, 0.10),
        ("massicot oxygen", "PbO_massicot", {"O"}, 0.10),
    ]
    available = {phase.name for phase in project.phases()}
    decisions = []
    for step, (label, phase, elements, cap) in enumerate(
        (item for item in plan if item[1] in available), 1
    ):
        project, accepted, detail = capped_step(
            project, args.tag, step, label, phase, elements, cap
        )
        decisions.append({"step": label, "accepted": accepted, "detail": detail})
    clear_atom_flags(project)
    project.save(args.output)
    summary = {
        "input": args.input_gpx,
        "output": args.output,
        "Rwp_percent": float(project.histogram(0).get_wR()),
        "decisions": decisions,
        "coordinates": {
            phase.name: {
                atom.label: {"element": atom.element, "xyz": list(atom.coordinates)}
                for atom in phase.atoms()
            }
            for phase in project.phases()
        },
    }
    (TMP / f"{args.tag}-bounded.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
