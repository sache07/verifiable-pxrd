#!/usr/bin/env python3
"""Screen documented uniaxial microstrain axes with physical bounds."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"


def rwp(project: G2.G2Project) -> float:
    return float(project.histogram(0).get_wR())


def clear_profile_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("--tag", default="uniaxial")
    parser.add_argument("--output", default=str(TMP / "uniaxial.gpx"))
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.input_gpx, newgpx=args.output)
    axes = ([0, 0, 1], [1, 0, 0], [0, 1, 0])
    decisions = []
    step = 1
    for phase_name in [phase.name for phase in project.phases()]:
        base_file = TMP / f"{args.tag}-u{step:02d}-{phase_name}-base.gpx"
        project.save(base_file)
        old = rwp(project)
        trials = []
        best = None
        for trial, axis in enumerate(axes, 1):
            trial_file = TMP / f"{args.tag}-u{step:02d}-{phase_name}-{trial}.gpx"
            p = G2.G2Project(str(base_file), newgpx=str(trial_file))
            p.set_Frozen()
            clear_profile_flags(p)
            hist = p.histogram(0)
            phase = p.phase(phase_name)
            hap = phase.data["Histograms"][hist.name]
            initial = max(300.0, float(hap["Mustrain"][1][0]))
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][0] = initial
            hap["Mustrain"][1][1] = initial
            hap["Mustrain"][2] = [True, True, False]
            hap["Mustrain"][3] = list(axis)
            for suffix in ("i", "a"):
                variable = f"{phase.id}:{hist.id}:Mustrain;{suffix}"
                p.set_Controls("parmMin", 0.0, variable=variable)
                p.set_Controls("parmMax", 8000.0, variable=variable)
            p.set_Controls("cycles", 12)
            p.refine()
            values = p.phase(phase_name).data["Histograms"][hist.name]["Mustrain"][1]
            equatorial, axial = float(values[0]), float(values[1])
            ratio = axial / equatorial if equatorial > 0 else float("inf")
            physical = (
                0.0 <= equatorial <= 8000.0
                and 0.0 <= axial <= 8000.0
                and 0.25 <= ratio <= 4.0
            )
            item = {
                "axis": list(axis),
                "equatorial_ppm": equatorial,
                "axial_ppm": axial,
                "axial_ratio": ratio,
                "Rwp_percent": rwp(p),
                "physical": physical,
                "file": str(trial_file),
            }
            trials.append(item)
            if physical and (best is None or rwp(p) < best[0]):
                best = (rwp(p), trial_file, item)
        accepted = best is not None and best[0] < old - 0.01
        print(
            f"UNI {step:02d} {phase_name:24s} old={old:.6f} "
            f"best={None if best is None else best[0]} accepted={accepted} trials={trials}"
        )
        if accepted:
            project = G2.G2Project(str(best[1]), newgpx=args.output)
            clear_profile_flags(project)
            project.save(args.output)
        else:
            project = G2.G2Project(str(base_file), newgpx=args.output)
            project.save(args.output)
        decisions.append(
            {
                "phase": phase_name,
                "accepted": accepted,
                "selected": best[2] if accepted and best else None,
                "trials": trials,
            }
        )
        step += 1
    clear_profile_flags(project)
    project.save(args.output)
    summary = {
        "input": args.input_gpx,
        "output": args.output,
        "Rwp_percent": rwp(project),
        "decisions": decisions,
        "profiles": {
            phase.name: phase.data["Histograms"][project.histogram(0).name]["Mustrain"]
            for phase in project.phases()
        },
    }
    (TMP / f"{args.tag}-uniaxial.json").write_text(
        json.dumps(summary, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else float(x)) + "\n"
    )
    print(json.dumps(summary, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else float(x)))


if __name__ == "__main__":
    main()
