#!/usr/bin/env python3
"""Make a Pb2WO5 topology model from published Pb2MoO5 (COD 7220560)."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
PARENT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/7/22/05/7220560.cif"
)
OUT = ROOT / ".tmp" / "Pb2WO5_from_Pb2MoO5.cif"


def main() -> None:
    structure = Structure.from_file(PARENT, primitive=False)
    structure.replace_species({"Mo": "W"})
    # Mo(VI) and W(VI) are close isovalent congeners; preserve the published
    # topology and starting cell, then let diffraction refine cell/coordinates.
    CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(OUT)
    provenance = {
        "model_basis": "analogue_derived",
        "parent_cod_id": "7220560",
        "parent_formula": "Pb2MoO5",
        "target_formula": "Pb2WO5",
        "transformation": "isovalent Mo(VI) -> W(VI) substitution; parent cell and fractional coordinates retained as starting values",
    }
    OUT.with_suffix(".provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    print(OUT)
    print(structure.composition, structure.get_space_group_info(), structure.density)


if __name__ == "__main__":
    main()
