#!/usr/bin/env python3
"""Refine linear terms and cells at a fixed or free zero-offset checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_noncalibration_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in inst and len(inst[key]) > 2:
            inst[key][2] = False
    for key in ("Shift", "SurfRoughA", "SurfRoughB"):
        hist.data["Sample Parameters"][key][1] = False
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("--zero", type=float, required=True)
    parser.add_argument("--refine-zero", action="store_true")
    parser.add_argument("--shift", type=float, default=0.0)
    parser.add_argument("--refine-shift", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.input_gpx, newgpx=args.output_gpx)
    hist = project.histogram(0)
    before_cells = {phase.name: phase.get_cell() for phase in project.phases()}
    clear_noncalibration_flags(project)
    hist.data["Instrument Parameters"][0]["Zero"][1] = args.zero
    hist.data["Instrument Parameters"][0]["Zero"][2] = args.refine_zero
    hist.data["Sample Parameters"]["Shift"] = [args.shift, args.refine_shift]
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    project.set_Controls("cycles", 16)
    project.refine()
    clear_noncalibration_flags(project)
    hist.data["Instrument Parameters"][0]["Zero"][2] = False
    hist.data["Sample Parameters"]["Shift"][1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
    project.save(args.output_gpx)
    summary = {
        "input": args.input_gpx,
        "output": args.output_gpx,
        "Rwp_percent": float(hist.get_wR()),
        "zero_deg": float(hist.data["Instrument Parameters"][0]["Zero"][1]),
        "zero_refined": args.refine_zero,
        "sample_shift_um": float(hist.data["Sample Parameters"]["Shift"][0]),
        "sample_shift_refined": args.refine_shift,
        "mass_fractions": {
            key: [float(value[0]), float(value[1])]
            for key, value in hist.ComputeMassFracs().items()
        },
        "cells_before": before_cells,
        "cells_after": {phase.name: phase.get_cell() for phase in project.phases()},
    }
    Path(args.output_gpx).with_suffix(".json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
