#!/usr/bin/env python3
"""Search the frozen COD index for oxide tungstate stoichiometry analogues."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

from pymatgen.core import Composition


INDEX = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/venv/"
    "lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz"
)
TARGETS = {
    "A1W1O4": (1.0, 4.0),
    "A2W1O5": (2.0, 5.0),
    "A3W1O6": (3.0, 6.0),
    "A4W1O7": (4.0, 7.0),
    "A5W3O15": (5.0 / 3.0, 5.0),
    "A3W2O9": (1.5, 4.5),
    "A7W8O29": (7.0 / 8.0, 3.6),
}


def close(a: float, b: float, tol: float = 0.025) -> bool:
    return abs(a - b) <= tol * max(1.0, abs(b))


def main() -> None:
    with gzip.open(INDEX, "rt") as handle:
        index = json.load(handle)
    found = {key: [] for key in TARGETS}
    for system, records in index.items():
        elems = system.split("-")
        if len(elems) != 3 or "O" not in elems or "W" not in elems:
            continue
        a_element = next(el for el in elems if el not in {"O", "W"})
        for formula, cod_id, sg_no, rval in records:
            try:
                amounts = Composition(formula).get_el_amt_dict()
            except Exception:  # noqa: BLE001
                continue
            if set(amounts) != {a_element, "O", "W"} or amounts["W"] <= 0:
                continue
            aratio = amounts[a_element] / amounts["W"]
            oratio = amounts["O"] / amounts["W"]
            for target, (atarget, otarget) in TARGETS.items():
                if close(aratio, atarget) and close(oratio, otarget):
                    found[target].append(
                        (a_element, formula, cod_id, sg_no, rval, aratio, oratio)
                    )
    for target, records in found.items():
        print(f"[{target}] n={len(records)}")
        for record in sorted(records):
            print(" ", record)


if __name__ == "__main__":
    main()
