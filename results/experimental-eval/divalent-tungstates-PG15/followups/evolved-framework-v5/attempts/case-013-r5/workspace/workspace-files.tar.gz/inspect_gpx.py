#!/usr/bin/env python3
"""Print residual peak families and nearby GSAS-II reflections from a GPX."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks, peak_widths


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx")
    parser.add_argument("--prominence", type=float, default=100.0)
    parser.add_argument("--match", type=float, default=0.24)
    args = parser.parse_args()

    project = G2.G2Project(args.gpx)
    hist = project.histogram(0)
    data = hist.data["data"][1]
    x, obs, calc, background, diff = (
        np.asarray(data[0]),
        np.asarray(data[1]),
        np.asarray(data[3]),
        np.asarray(data[4]),
        np.asarray(data[5]),
    )
    step = np.median(np.diff(x))
    smooth = gaussian_filter1d(diff, 0.025 / step)
    refls = hist.data["Reflection Lists"]

    print(f"{Path(args.gpx).name}: Rwp={hist.get_wR():.6f}%")
    print("Positive residual peaks")
    peaks, props = find_peaks(
        smooth,
        prominence=args.prominence,
        distance=max(2, round(0.07 / step)),
        width=max(1, round(0.025 / step)),
    )
    widths = peak_widths(smooth, peaks, rel_height=0.5)[0] * step
    order = np.argsort(props["prominences"])[::-1]
    for rank, j in enumerate(order, 1):
        i = peaks[j]
        matches = []
        for phase, refdata in refls.items():
            arr = np.asarray(refdata["RefList"])
            near = arr[np.abs(arr[:, 5] - x[i]) <= args.match]
            for row in near:
                matches.append(
                    (
                        abs(row[5] - x[i]),
                        phase,
                        tuple(int(v) for v in row[:3]),
                        row[5],
                        row[9],
                    )
                )
        matches.sort()
        mtext = "; ".join(
            f"{phase}{hkl}@{pos:.3f}[I={inten:.1f}]"
            for _, phase, hkl, pos, inten in matches[:5]
        )
        print(
            f"{rank:3d} {x[i]:9.4f} diff={smooth[i]:9.1f} "
            f"prom={props['prominences'][j]:9.1f} FWHM={widths[j]:7.4f}  {mtext or 'UNMATCHED'}"
        )

    print("\nNegative residual extrema")
    peaks, props = find_peaks(
        -smooth,
        prominence=args.prominence,
        distance=max(2, round(0.07 / step)),
        width=max(1, round(0.025 / step)),
    )
    order = np.argsort(props["prominences"])[::-1]
    for rank, j in enumerate(order[:40], 1):
        i = peaks[j]
        print(
            f"{rank:3d} {x[i]:9.4f} diff={smooth[i]:9.1f} "
            f"prom={props['prominences'][j]:9.1f}"
        )


if __name__ == "__main__":
    main()
