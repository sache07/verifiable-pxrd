#!/usr/bin/env python3
"""Coordinate/ADP refinement with physical rollback for an accepted inventory."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"


def clear_atom_flags(project: G2.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def coord_snapshot(project: G2.G2Project) -> dict[str, dict[str, np.ndarray]]:
    return {
        phase.name: {
            atom.label: np.asarray(atom.coordinates, dtype=float)
            for atom in phase.atoms()
        }
        for phase in project.phases()
    }


def displacement(
    phase: G2.G2Phase,
    before: dict[str, np.ndarray],
) -> tuple[float, dict[str, float]]:
    cell = phase.get_cell()
    _, metric = G2lat.cell2Gmat(
        [
            cell["length_a"],
            cell["length_b"],
            cell["length_c"],
            cell["angle_alpha"],
            cell["angle_beta"],
            cell["angle_gamma"],
        ]
    )
    values = {}
    for atom in phase.atoms():
        delta = np.asarray(atom.coordinates) - before[atom.label]
        delta -= np.round(delta)
        values[atom.label] = float(np.sqrt(delta @ metric @ delta))
    return max(values.values(), default=0.0), values


def refine_step(
    project: G2.G2Project,
    tag: str,
    step: int,
    label: str,
    phase_name: str,
    elements: set[str],
    max_allowed_a: float,
) -> tuple[G2.G2Project, bool]:
    before_file = TMP / f"{tag}-c{step:02d}-before.gpx"
    after_file = TMP / f"{tag}-c{step:02d}.gpx"
    project.save(before_file)
    # Switch the active refinement filename so GSAS-II cannot overwrite the
    # immutable rollback checkpoint above.
    project.save(after_file)
    old_rwp = float(project.histogram(0).get_wR())
    before = coord_snapshot(project)
    clear_atom_flags(project)
    phase = project.phase(phase_name)
    for atom in phase.atoms():
        if atom.element in elements:
            atom.refinement_flags = "X"
    project.set_Controls("cycles", 12)
    project.refine()
    new_rwp = float(project.histogram(0).get_wR())
    max_disp, displacements = displacement(project.phase(phase_name), before[phase_name])
    bad = project.phase(phase_name).ShortDistances(useAll=True)
    accepted = (
        np.isfinite(new_rwp)
        and new_rwp < old_rwp - 0.002
        and max_disp <= max_allowed_a
        and not bad
    )
    print(
        f"COORD {step:02d} {label:24s} old={old_rwp:.6f} new={new_rwp:.6f} "
        f"max_d={max_disp:.4f}A accepted={accepted} short={bad}"
    )
    print("  displacements", json.dumps(displacements, sort_keys=True))
    if accepted:
        project.save(after_file)
        clear_atom_flags(project)
        return project, True
    # Reload the exact physical checkpoint and continue from it.
    project = G2.G2Project(str(before_file), newgpx=str(after_file))
    clear_atom_flags(project)
    project.save(after_file)
    return project, False


def refine_common_uiso(
    project: G2.G2Project, tag: str, step: int
) -> tuple[G2.G2Project, bool]:
    before_file = TMP / f"{tag}-c{step:02d}-before.gpx"
    after_file = TMP / f"{tag}-c{step:02d}.gpx"
    project.save(before_file)
    project.save(after_file)
    old_rwp = float(project.histogram(0).get_wR())
    clear_atom_flags(project)
    # One isotropic displacement parameter per phase. This avoids unsupported
    # atom-by-atom ADPs in a laboratory multiphase pattern.
    for phase in project.phases():
        variables = []
        for i, atom in enumerate(phase.atoms()):
            atom.uiso = 0.01
            atom.refinement_flags = "U"
            variables.append(f"{phase.id}::AUiso:{i}")
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
    project.set_Controls("cycles", 12)
    project.refine()
    new_rwp = float(project.histogram(0).get_wR())
    uisos = {
        phase.name: [float(atom.uiso) for atom in phase.atoms()]
        for phase in project.phases()
    }
    values = [u[0] for u in uisos.values() if u]
    accepted = (
        np.isfinite(new_rwp)
        and new_rwp < old_rwp - 0.002
        and all(0.003 <= u <= 0.02 for u in values)
    )
    print(
        f"ADP   {step:02d} common Uiso/phase         old={old_rwp:.6f} "
        f"new={new_rwp:.6f} accepted={accepted} uiso={uisos}"
    )
    if accepted:
        project.save(after_file)
        clear_atom_flags(project)
        return project, True
    project = G2.G2Project(str(before_file), newgpx=str(after_file))
    clear_atom_flags(project)
    project.save(after_file)
    return project, False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("--tag", default="coordinates")
    parser.add_argument("--output", default=str(TMP / "coordinates.gpx"))
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(args.input_gpx, newgpx=args.output)
    clear_atom_flags(project)
    # Heavy atoms first, then oxygen sublattices. Limits are real-space
    # displacements from the accepted reference coordinates.
    plan = [
        ("WO3 heavy atoms", "WO3_monoclinic", {"W"}, 0.10),
        ("Pb2WO5 heavy atoms", "Pb2WO5", {"Pb", "W"}, 0.10),
        ("massicot heavy atoms", "PbO_massicot", {"Pb"}, 0.10),
        ("litharge heavy atoms", "PbO_litharge", {"Pb"}, 0.08),
        ("scheelite oxygen", "PbWO4_scheelite", {"O"}, 0.12),
        ("WO3 oxygen", "WO3_monoclinic", {"O"}, 0.15),
        ("Pb2WO5 oxygen", "Pb2WO5", {"O"}, 0.15),
        ("massicot oxygen", "PbO_massicot", {"O"}, 0.15),
    ]
    available = {phase.name for phase in project.phases()}
    plan = [item for item in plan if item[1] in available]
    decisions = []
    for step, (label, phase, elements, limit) in enumerate(plan, 1):
        project, accepted = refine_step(
            project, args.tag, step, label, phase, elements, limit
        )
        decisions.append({"step": label, "accepted": accepted})
    project, accepted = refine_common_uiso(project, args.tag, len(plan) + 1)
    decisions.append({"step": "common Uiso per phase", "accepted": accepted})
    clear_atom_flags(project)
    project.save(args.output)
    summary = {
        "input": args.input_gpx,
        "output": args.output,
        "Rwp_percent": project.histogram(0).get_wR(),
        "decisions": decisions,
        "coordinates": {
            phase.name: {
                atom.label: {
                    "element": atom.element,
                    "xyz": list(atom.coordinates),
                    "uiso": float(atom.uiso),
                }
                for atom in phase.atoms()
            }
            for phase in project.phases()
        },
    }
    (TMP / f"{args.tag}-coordinates.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
