#!/usr/bin/env python3
"""Explore phase-specific broadening from the current trial refinement."""

from pathlib import Path
import numpy as np
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
project = G2sc.G2Project(str(root / "trial.gpx"))
project.filename = str(root / "profile_trial.gpx")
project.set_Controls("cycles", 8)
hist = project.histograms()[0]

for phase in project.phases():
    phase.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=0.5)
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True,
                 "LGmix": {"value": 0.5, "refine": False}},
    })
project.refine()
print("after size", hist.residuals)
for phase in project.phases():
    print(phase.name, "size", phase.data["Histograms"][hist.name]["Size"])

for phase in project.phases():
    phase.setSampleProfile(hist, "microstrain", "isotropic", 500.0, LGmix=0.5)
    phase.set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True,
                     "LGmix": {"value": 0.5, "refine": False}},
    })
project.refine()
print("after strain", hist.residuals)
for phase in project.phases():
    print(phase.name,
          "size", phase.data["Histograms"][hist.name]["Size"],
          "strain", phase.data["Histograms"][hist.name]["Mustrain"])

hist.set_refinements({"Instrument Parameters": ["SH/L"]})
project.refine()
print("after SH/L", hist.residuals)
print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                     if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")})
print("fractions", hist.ComputeMassFracs())
project.save(str(root / "profile_trial.gpx"))
x, yobs, wt, ycalc, ybkg, diff = hist.data["data"][1]
np.savetxt(root / "profile_trial_fit.csv",
           np.column_stack([x, yobs, ycalc, ybkg, diff]), delimiter=",",
           header="two_theta_deg,observed,calculated,background,difference",
           comments="")
