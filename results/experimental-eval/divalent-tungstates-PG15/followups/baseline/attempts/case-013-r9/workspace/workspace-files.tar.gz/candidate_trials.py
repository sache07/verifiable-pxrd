#!/usr/bin/env python3
"""Add one candidate phase at a time to the stable four-phase GSAS-II model."""

from pathlib import Path
import traceback

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


# label, COD id, isotropic multiplier for the starting cell
CANDIDATES = [
    ("Pb3O4_tetragonal", "1537983", 1.0289),
    ("PbO2_cubic", "9005760", 0.9940),
    ("PbO2_orthorhombic", "1531016", 0.9825),
    ("PbO2_tetragonal", "9007543", 0.9707),
    ("Pb2O3_monoclinic", "2311012", 0.9972),
    ("PbWO4_raspite", "9007617", 1.0268),
    ("W3O8_orthorhombic", "2101050", 0.9989),
    ("W18O49_monoclinic", "1528166", 1.0212),
]


for label, cod_id, cellscale in CANDIDATES:
    print("\n=====", label, cod_id, "=====")
    try:
        project = G2sc.G2Project(str(ROOT / "trial.gpx"))
        project.set_Controls("cycles", 8)
        outfile = ROOT / ".tmp" / f"candidate_{cod_id}.gpx"
        project.save(str(outfile))
        hist = project.histograms()[0]
        before = hist.get_wR()
        phase = project.add_phase(
            str(cod_path(cod_id)), phasename=label,
            histograms=[hist], fmthint="CIF")
        cell = phase.data["General"]["Cell"]
        cell[1] *= cellscale
        cell[2] *= cellscale
        cell[3] *= cellscale
        cell[7] *= cellscale ** 3
        phase.HAPvalue("Scale", 0.10)
        phase.set_HAP_refinements({"Scale": True})
        project.refine()
        scale_rwp = hist.get_wR()
        phase.set_refinements({"Cell": True})
        project.refine()
        final_rwp = hist.get_wR()
        print("composition", phase.composition)
        print("spacegroup", phase.data["General"]["SGData"]["SpGrp"])
        print("Rwp", before, scale_rwp, final_rwp)
        print("cell", phase.get_cell())
        print("scale", phase.HAPvalue("Scale"))
        print("fractions", hist.ComputeMassFracs())
        project.save(str(outfile))
    except Exception as exc:
        print("FAILED", repr(exc))
        traceback.print_exc()
