#!/usr/bin/env python3
"""Build exploratory GSAS-II refinements for candidate Pb-W-O phase sets."""

from pathlib import Path
import json
import sys

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = {
    "PbWO4_scheelite": "9009811",
    "WO3_monoclinic": "1528915",
    "PbO_massicot": "2310433",
}


def summarize(project, hist, tag):
    print(f"\n===== {tag} =====")
    print("residuals", hist.residuals)
    print("instrument")
    for key, val in hist.InstrumentParameters.items():
        if key in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"}:
            print(key, val)
    for phase in project.phases():
        print(phase.name, "cell", phase.get_cell(), "scale", phase.HAPvalue("Scale"))
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fraction error", repr(exc))


def main():
    gpx = ROOT / "trial.gpx"
    if gpx.exists():
        gpx.unlink()
    project = G2sc.G2Project(newgpx=str(gpx))
    project.set_Controls("cycles", 8)
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "cu_kalpha.instprm"),
        fmthint="xye",
    )
    hist.set_refinements({
        "Limits": [10.05, 99.9],
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 18},
    })
    hist.clear_refinements({"Sample Parameters": ["Scale"]})
    for name, cod_id in PHASES.items():
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.HAPvalue("Scale", 1.0)
        phase.set_HAP_refinements({"Scale": True})
    project.save()

    # Scale and background first.
    project.refine()
    summarize(project, hist, "background + scales")

    # Refine common zero and independent cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine()
    summarize(project, hist, "zero + cells")

    # Add common Gaussian profile terms.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    project.refine()
    summarize(project, hist, "UVW")

    # Add Lorentzian profile terms.
    hist.set_refinements({"Instrument Parameters": ["X", "Y"]})
    project.refine()
    summarize(project, hist, "UVWXY")

    # Introduce litharge only after the major phase positions/profile are stable.
    litharge = project.add_phase(
        str(ROOT / "litharge_standard.cif"),
        phasename="PbO_litharge",
        histograms=[hist],
        fmthint="CIF",
    )
    litharge.HAPvalue("Scale", 0.10)
    litharge.set_HAP_refinements({"Scale": True})
    project.refine()
    summarize(project, hist, "add litharge scale")
    litharge.set_refinements({"Cell": True})
    project.refine()
    summarize(project, hist, "add litharge cell")
    project.save(str(gpx))

    x, yobs, wt, ycalc, ybkg, diff = hist.data["data"][1]
    np.savetxt(
        ROOT / "trial_fit.csv",
        np.column_stack([x, yobs, ycalc, ybkg, diff]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference",
        comments="",
    )


if __name__ == "__main__":
    main()
