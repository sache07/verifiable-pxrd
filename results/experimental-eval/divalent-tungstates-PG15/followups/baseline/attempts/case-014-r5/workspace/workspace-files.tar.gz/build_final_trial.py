#!/usr/bin/env python3
"""Build a physically constrained three-phase GSAS-II refinement trial."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp" / "final_trial"
TMP.mkdir(parents=True, exist_ok=True)
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_inputs() -> tuple[Path, Path]:
    raw = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    xye = TMP / "pattern.xye"
    np.savetxt(
        xye,
        np.column_stack(
            [raw["two_theta_deg"], raw["intensity"], np.sqrt(np.maximum(raw["intensity"], 1.0))]
        ),
        fmt=("%.8f", "%.8f", "%.8f"),
    )
    inst = TMP / "cu_ka.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for lab CuKa data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:2.0;V:-2.0;W:120.0;X:10.0;Y:10.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def step(project: G2sc.G2Project, label: str) -> None:
    project.refine()
    hist = project.histogram(0)
    print(label, json.dumps(hist.residuals, sort_keys=True), flush=True)


def main() -> None:
    xye, inst = make_inputs()
    out = TMP / "physical.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    project.set_Controls("cycles", 8)
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-550.0, False]
    hist.data["Background"][0] = ["chebyschev-1", True, 15, 700.0] + [0.0] * 14

    phases = [
        project.add_phase(
            str(cod_path("1546036")),
            phasename="SrWO4_scheelite",
            histograms=[hist],
            fmthint="CIF",
        ),
        project.add_phase(
            str(cod_path("1528915")),
            phasename="WO3_monoclinic",
            histograms=[hist],
            fmthint="CIF",
        ),
        project.add_phase(
            str(cod_path("9008198")),
            phasename="SrCO3_orthorhombic",
            histograms=[hist],
            fmthint="CIF",
        ),
    ]
    for phase, scale in zip(phases, (1.0, 0.1, 0.1)):
        phase.data["Histograms"][hist.name]["Scale"] = [scale, True]

    # Strong (200) texture is needed to represent the observed SrCO3 line ratios.
    carbonate_po = phases[2].data["Histograms"][hist.name]["Pref.Ori."]
    carbonate_po[1] = 0.4
    carbonate_po[2] = False
    carbonate_po[3] = [1, 0, 0]

    step(project, "scale_background")

    phases[0].set_refinements({"Cell": True})
    hist.SampleParameters["Shift"][1] = True
    step(project, "main_cell_shift")

    for phase in phases[1:]:
        phase.set_refinements({"Cell": True})
    step(project, "all_cells")

    project.set_Controls("parmMin", 0.0, variable=":0:W")
    project.set_Controls("parmMin", 0.0, variable=":0:X")
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["X"][2] = True
    step(project, "profile_WX")

    # Suortti roughness correction suppresses low-angle intensities in reflection geometry.
    project.set_Controls("parmMin", 0.001, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.999, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 2.0, variable=":0:SurfRoughB")
    hist.SampleParameters["SurfRoughA"] = [0.5, False]
    hist.SampleParameters["SurfRoughB"] = [0.05, True]
    step(project, "roughness_B")
    hist.SampleParameters["SurfRoughA"][1] = True
    step(project, "roughness_AB")
    step(project, "repeat")
    project.save()

    print(
        "RESULT",
        json.dumps(
            {
                "gpx": str(out),
                "residuals": hist.residuals,
                "mass_fractions": hist.ComputeMassFracs(),
                "sample": hist.SampleParameters,
                "instrument": hist.InstrumentParameters,
                "phases": {
                    p.name: {
                        "cell": p.get_cell(),
                        "scale": p.data["Histograms"][hist.name]["Scale"],
                        "po": p.data["Histograms"][hist.name]["Pref.Ori."],
                    }
                    for p in phases
                },
            },
            sort_keys=True,
            default=str,
        ),
    )


if __name__ == "__main__":
    main()
