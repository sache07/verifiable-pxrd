#!/usr/bin/env python3
"""Export the selected GSAS-II project, phase CIFs, fit profile and JSON summary."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_trial" / "polished.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_INFO = {
    "SrWO4_scheelite": {
        "name": "scheelite SrWO4",
        "display_name": "scheelite SrWO4",
        "formula": "SrWO4",
        "cif_path": "phase_1_SrWO4_scheelite.cif",
        "source_database": "COD",
        "source_database_id": "1546036",
        "fraction_reliability": "moderate",
    },
    "WO3_monoclinic": {
        "name": "monoclinic WO3",
        "display_name": "monoclinic WO3",
        "formula": "WO3",
        "cif_path": "phase_2_WO3_monoclinic.cif",
        "source_database": "COD",
        "source_database_id": "1528915",
        "fraction_reliability": "moderate",
    },
    "SrCO3_orthorhombic": {
        "name": "orthorhombic SrCO3",
        "display_name": "orthorhombic SrCO3",
        "formula": "SrCO3",
        "cif_path": "phase_3_SrCO3_orthorhombic.cif",
        "source_database": "COD",
        "source_database_id": "9008198",
        "fraction_reliability": "low; strongly texture-model-dependent",
    },
}


def plain_cell(phase: G2sc.G2Phase) -> dict[str, float]:
    return {key: float(value) for key, value in phase.get_cell().items()}


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL_GPX))
    project.save()
    hist = project.histogram(0)

    mass = hist.ComputeMassFracs()
    fraction_sum = sum(value[0] for value in mass.values())
    if not np.isclose(fraction_sum, 1.0, atol=1.0e-10):
        raise RuntimeError(f"Phase fractions do not sum to one: {fraction_sum}")

    phase_rows = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif_path"]))
        frac, frac_esd = mass[phase.name]
        sgdata = phase.data["General"]["SGData"]
        row = dict(info)
        row.update(
            {
                "project_phase_name": phase.name,
                "space_group": sgdata["SpGrp"].strip(),
                "weight_fraction": float(frac),
                "weight_fraction_percent": float(100.0 * frac),
                "formal_weight_fraction_standard_uncertainty": float(frac_esd),
                "cell": plain_cell(phase),
            }
        )
        phase_rows.append(row)

    arrays = hist.data["data"][1]
    two_theta, observed, weights, calculated, background, difference = arrays[:6]
    if not np.allclose(difference, observed - calculated, atol=1.0e-6, rtol=0.0):
        raise RuntimeError("Stored GSAS-II difference profile is inconsistent")
    fit = np.column_stack((two_theta, observed, calculated, difference))
    np.savetxt(
        ROOT / "fit.csv",
        fit,
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=("%.8f", "%.8f", "%.8f", "%.8f"),
    )

    residuals = hist.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "phases": phase_rows,
        "fraction_basis": "normalized over the modeled crystalline phases; sums to 1",
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "R_expected_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters_in_final_covariance": int(rvals["Nvars"]),
            "converged": bool(rvals.get("converged", False)),
            "maximum_shift_over_standard_uncertainty": float(rvals["Max shft/sig"]),
            "background_R_percent": float(residuals["Rb"]),
            "weighted_background_R_percent": float(residuals["wRb"]),
        },
        "measurement_model": {
            "radiation": "Cu K-alpha doublet",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "weighting": "Poisson approximation: sigma=sqrt(max(observed counts,1)); input uncertainties were not supplied",
        },
        "files": {
            "GSASII_project": "final.gpx",
            "fit_profile": "fit.csv",
            "report": "report.md",
        },
        "important_caveat": (
            "The SrCO3 fraction is not reliable as a unique quantitative value because "
            "its scale and [100] March-Dollase texture term are nearly singular. The "
            "listed value is the selected physically plausible fixed-texture model."
        ),
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    print(
        json.dumps(
            {
                "final_gpx": str(FINAL_GPX),
                "fit_rows": int(len(fit)),
                "fractions": {key: value[0] for key, value in mass.items()},
                "Rwp_percent": residuals["wR"],
                "GOF": rvals["GOF"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
