#!/usr/bin/env python3
"""Refine the SrCO3 March-Dollase term with explicit physical bounds."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
project = G2sc.G2Project(str(ROOT / ".tmp" / "screen" / "three_9008198.gpx"))
project.set_Controls("cycles", 8)
hist = project.histogram(0)
carbonate = project.phase("candidate3_9008198")

for phase in project.phases():
    phase.set_refinements({"Cell": False})
for key in ("U", "V", "W", "X", "Y"):
    hist.InstrumentParameters[key][2] = False
hist.SampleParameters["Shift"][1] = False
carbonate.data["Histograms"][hist.name]["Pref.Ori."][2] = True

project.set_Controls("parmMin", 0.05, variable="2:0:MD")
project.set_Controls("parmMax", 5.0, variable="2:0:MD")
project.refine()

for phase in project.phases():
    phase.set_refinements({"Cell": True})
hist.SampleParameters["Shift"][1] = True
for key in ("W", "X"):
    hist.InstrumentParameters[key][2] = True
project.refine()
project.save()

print(
    "RESULT",
    json.dumps(
        {
            "residuals": hist.residuals,
            "mass_fractions": hist.ComputeMassFracs(),
            "MD": carbonate.data["Histograms"][hist.name]["Pref.Ori."],
            "cells": {p.name: p.get_cell() for p in project.phases()},
            "sample": hist.SampleParameters,
            "instrument": hist.InstrumentParameters,
        },
        default=str,
        sort_keys=True,
    ),
)
