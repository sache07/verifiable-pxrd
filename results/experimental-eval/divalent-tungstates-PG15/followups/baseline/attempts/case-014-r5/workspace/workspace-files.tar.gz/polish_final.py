#!/usr/bin/env python3
"""Converge the correlated SrCO3 texture and scale blocks for final export."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_trial" / "stabilized.gpx"
OUTPUT = ROOT / ".tmp" / "final_trial" / "polished.gpx"


def set_joint(project: G2sc.G2Project, enabled: bool) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = enabled
    for phase in project.phases():
        phase.set_HAP_refinements(
            {
                "Scale": enabled,
                "Mustrain": {"type": "isotropic", "refine": enabled},
            },
            [hist],
        )


def snapshot(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    carbonate = project.phase("SrCO3_orthorhombic")
    print(
        label,
        json.dumps(
            {
                "Rvals": project.data.get("Covariance", {})
                .get("data", {})
                .get("Rvals", {}),
                "residuals": hist.residuals,
                "mass_fractions": hist.ComputeMassFracs(),
                "MD": carbonate.data["Histograms"][hist.name]["Pref.Ori."],
                "mustrain": {
                    phase.name: phase.data["Histograms"][hist.name]["Mustrain"][1][0]
                    for phase in project.phases()
                },
            },
            default=str,
            sort_keys=True,
        ),
        flush=True,
    )


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-9
    hist = project.histogram(0)
    carbonate = project.phase("SrCO3_orthorhombic")
    po = carbonate.data["Histograms"][hist.name]["Pref.Ori."]

    for cycle in range(4):
        set_joint(project, False)
        po[2] = True
        project.refine()
        snapshot(project, f"texture_{cycle + 1}")

        po[2] = False
        set_joint(project, True)
        project.refine()
        snapshot(project, f"joint_{cycle + 1}")

    po[2] = False
    set_joint(project, True)
    project.save()
    snapshot(project, "FINAL")


if __name__ == "__main__":
    main()
