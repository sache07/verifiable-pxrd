#!/usr/bin/env python3
"""Screen conservative phase-specific isotropic broadening models."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_trial" / "md_optimized.gpx"
OUTDIR = ROOT / ".tmp" / "final_trial" / "broadening"
OUTDIR.mkdir(parents=True, exist_ok=True)


def freeze_all(project: G2sc.G2Project) -> None:
    """Clear every refinement flag that can interfere with this screen."""
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        phase.set_HAP_refinements(
            {
                "Scale": False,
                "Pref.Ori.": False,
                "Size": {"type": "isotropic", "refine": False},
                "Mustrain": {"type": "isotropic", "refine": False},
            },
            [hist],
        )


def describe(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(
        label,
        json.dumps(
            {
                "residuals": hist.residuals,
                "mass_fractions": hist.ComputeMassFracs(),
                "HAP": {
                    phase.name: {
                        "Size": phase.data["Histograms"][hist.name]["Size"],
                        "Mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
                    }
                    for phase in project.phases()
                },
                "covariance": project.data.get("Covariance", {}).get("data", {}).get(
                    "Rvals", {}
                ),
            },
            default=str,
            sort_keys=True,
        ),
        flush=True,
    )


def run_case(name: str, size_phases: tuple[int, ...], strain_phases: tuple[int, ...]) -> None:
    out = OUTDIR / f"{name}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(out))
    project.set_Controls("cycles", 12)
    freeze_all(project)
    hist = project.histogram(0)

    # Keep the empirical intensity model fixed while determining widths.
    for index in size_phases:
        project.phase(index).set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
    for index in strain_phases:
        project.phase(index).set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    project.refine()
    describe(project, f"{name}_widths")

    # Re-equilibrate phase scales and background with the selected widths fixed.
    for phase in project.phases():
        phase.set_HAP_refinements(
            {
                "Scale": True,
                "Size": {"type": "isotropic", "refine": False},
                "Mustrain": {"type": "isotropic", "refine": False},
            },
            [hist],
        )
    hist.data["Background"][0][1] = True
    project.refine()
    project.save()
    describe(project, f"{name}_final")


def main() -> None:
    cases = {
        "size_main": ((0,), ()),
        "size_wo3": ((1,), ()),
        "size_carbonate": ((2,), ()),
        "size_all": ((0, 1, 2), ()),
        "strain_all": ((), (0, 1, 2)),
        "size_strain_all": ((0, 1, 2), (0, 1, 2)),
    }
    for name, (sizes, strains) in cases.items():
        run_case(name, sizes, strains)


if __name__ == "__main__":
    main()
