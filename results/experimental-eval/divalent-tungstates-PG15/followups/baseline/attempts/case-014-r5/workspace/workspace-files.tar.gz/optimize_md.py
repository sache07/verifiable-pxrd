#!/usr/bin/env python3
"""Alternate texture and scale refinement to avoid their near-singular covariance."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
src = ROOT / ".tmp" / "final_trial" / "physical.gpx"
dst = ROOT / ".tmp" / "final_trial" / "md_optimized.gpx"
project = G2sc.G2Project(str(src), newgpx=str(dst))
project.set_Controls("cycles", 12)
hist = project.histogram(0)
carbonate = project.phase("SrCO3_orthorhombic")

# Hold the converged geometric/profile model and all scale factors.
hist.data["Background"][0][1] = False
for key in hist.InstrumentParameters:
    if isinstance(hist.InstrumentParameters[key], list) and len(hist.InstrumentParameters[key]) >= 3:
        hist.InstrumentParameters[key][2] = False
for key, value in hist.SampleParameters.items():
    if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
        value[1] = False
for phase in project.phases():
    phase.set_refinements({"Cell": False})
    phase.data["Histograms"][hist.name]["Scale"][1] = False
    phase.data["Histograms"][hist.name]["Pref.Ori."][2] = False

po = carbonate.data["Histograms"][hist.name]["Pref.Ori."]
po[2] = True
project.set_Controls("parmMin", 0.15, variable="2:0:MD")
project.set_Controls("parmMax", 1.0, variable="2:0:MD")
project.refine()
print("MD_ONLY", po[1], hist.residuals, flush=True)

# Hold texture at that value and update phase scales/background.
po[2] = False
hist.data["Background"][0][1] = True
for phase in project.phases():
    phase.data["Histograms"][hist.name]["Scale"][1] = True
project.refine()
print("SCALES", po[1], hist.residuals, flush=True)

# One more coordinate-descent pass.
hist.data["Background"][0][1] = False
for phase in project.phases():
    phase.data["Histograms"][hist.name]["Scale"][1] = False
po[2] = True
project.refine()
print("MD_ONLY_2", po[1], hist.residuals, flush=True)

po[2] = False
hist.data["Background"][0][1] = True
for phase in project.phases():
    phase.data["Histograms"][hist.name]["Scale"][1] = True
project.refine()
project.save()

print(
    "RESULT",
    json.dumps(
        {
            "MD": po,
            "residuals": hist.residuals,
            "mass_fractions": hist.ComputeMassFracs(),
            "cells": {p.name: p.get_cell() for p in project.phases()},
        },
        default=str,
        sort_keys=True,
    ),
)
