#!/usr/bin/env python3
"""Screen a SrWO4 + candidate impurity model with GSAS-II."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
MAIN_ID = "1546036"


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_inputs() -> tuple[Path, Path]:
    raw = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    xye = ROOT / ".tmp" / "pattern.xye"
    np.savetxt(
        xye,
        np.column_stack(
            [raw["two_theta_deg"], raw["intensity"], np.sqrt(np.maximum(raw["intensity"], 1.0))]
        ),
        fmt=("%.8f", "%.8f", "%.8f"),
    )
    inst = ROOT / ".tmp" / "cu_ka.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for lab CuKa data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:2.0;V:-2.0;W:120.0;X:10.0;Y:10.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def refine_step(project: G2sc.G2Project, label: str) -> None:
    project.refine()
    hist = project.histogram(0)
    print(label, json.dumps(hist.residuals, sort_keys=True), flush=True)


def screen(candidate_id: str) -> dict:
    xye, inst = make_inputs()
    outdir = ROOT / ".tmp" / "screen"
    outdir.mkdir(parents=True, exist_ok=True)
    gpx_path = outdir / f"model_{candidate_id}.gpx"
    project = G2sc.G2Project(newgpx=str(gpx_path))
    project.set_Controls("cycles", 4)
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-500.0, False]
    hist.data["Background"][0] = ["chebyschev-1", True, 15, 700.0] + [0.0] * 14

    main = project.add_phase(
        str(cod_path(MAIN_ID)), phasename="SrWO4_scheelite", histograms=[hist], fmthint="CIF"
    )
    impurity = project.add_phase(
        str(cod_path(candidate_id)), phasename=f"candidate_{candidate_id}", histograms=[hist], fmthint="CIF"
    )
    main.data["Histograms"][hist.name]["Scale"] = [1.0, True]
    impurity.data["Histograms"][hist.name]["Scale"] = [0.1, True]

    refine_step(project, "scale_background")

    main.set_refinements({"Cell": True})
    impurity.set_refinements({"Cell": True})
    hist.SampleParameters["Shift"][1] = True
    refine_step(project, "cell_shift")

    for key in ("U", "V", "W", "X", "Y"):
        hist.InstrumentParameters[key][2] = True
    refine_step(project, "profile")

    try:
        mass = hist.ComputeMassFracs()
    except Exception as exc:
        mass = {"error": repr(exc)}
    result = {
        "candidate": candidate_id,
        "gpx": str(gpx_path),
        "residuals": hist.residuals,
        "mass_fractions": mass,
        "instrument": {k: v for k, v in hist.InstrumentParameters.items()},
        "sample": hist.SampleParameters,
        "phases": {
            ph.name: {
                "cell": ph.get_cell(),
                "scale": ph.data["Histograms"][hist.name]["Scale"],
                "composition": ph.composition,
            }
            for ph in project.phases()
        },
    }
    project.save()
    return result


if __name__ == "__main__":
    result = screen(sys.argv[1])
    print("RESULT", json.dumps(result, sort_keys=True, default=str))
