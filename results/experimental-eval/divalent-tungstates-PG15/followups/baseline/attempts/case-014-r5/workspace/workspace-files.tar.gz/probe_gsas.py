#!/usr/bin/env python3
"""Build a minimal GSAS-II project to inspect imported data defaults."""

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def make_inputs() -> tuple[Path, Path]:
    raw = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    xye = ROOT / ".tmp" / "pattern.xye"
    np.savetxt(
        xye,
        np.column_stack(
            [raw["two_theta_deg"], raw["intensity"], np.sqrt(np.maximum(raw["intensity"], 1.0))]
        ),
        fmt=("%.8f", "%.8f", "%.8f"),
    )
    inst = ROOT / ".tmp" / "cu_ka.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for lab CuKa data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:2.0;V:-2.0;W:80.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def main() -> None:
    xye, inst = make_inputs()
    project = G2sc.G2Project(newgpx=str(ROOT / ".tmp" / "probe.gpx"))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    print("hist", hist.name)
    print("instrument", hist.InstrumentParameters)
    print("sample", hist.SampleParameters)
    print("background", hist.Background)
    print("limits", hist.data["Limits"])
    print("data arrays", [a.shape if hasattr(a, "shape") else type(a) for a in hist.data["data"][1]])
    project.save()


if __name__ == "__main__":
    main()
