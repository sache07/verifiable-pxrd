#!/usr/bin/env python3
"""Diagnostic joint refinement of the correlated carbonate scale and texture."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
p = G2sc.G2Project(
    str(ROOT / ".tmp" / "final_trial" / "polished.gpx"),
    newgpx=str(ROOT / ".tmp" / "final_trial" / "joint_texture_test.gpx"),
)
p.set_Controls("cycles", 20)
p.data["Controls"]["data"]["min dM/M"] = 1.0e-7
h = p.histogram(0)
carbonate = p.phase("SrCO3_orthorhombic")
carbonate.data["Histograms"][h.name]["Pref.Ori."][2] = True
p.refine()
p.save()
print(
    "RESULT",
    json.dumps(
        {
            "Rvals": p.data["Covariance"]["data"]["Rvals"],
            "residuals": h.residuals,
            "mass_fractions": h.ComputeMassFracs(),
            "MD": carbonate.data["Histograms"][h.name]["Pref.Ori."],
        },
        default=str,
        sort_keys=True,
    ),
)
