#!/usr/bin/env python3
"""Test whether plausible fourth phases have nonzero support in the final model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_trial" / "stabilized.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = ROOT / ".tmp" / "final_trial" / "extra_phase_tests"
OUT.mkdir(parents=True, exist_ok=True)


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def freeze(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        phase.set_HAP_refinements(
            {
                "Scale": False,
                "Pref.Ori.": False,
                "Size": {"type": "isotropic", "refine": False},
                "Mustrain": {"type": "isotropic", "refine": False},
            },
            [hist],
        )


def test(cod_id: str) -> None:
    project = G2sc.G2Project(
        str(SOURCE), newgpx=str(OUT / f"candidate_{cod_id}.gpx")
    )
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-7
    freeze(project)
    hist = project.histogram(0)
    candidate = project.add_phase(
        str(cod_path(cod_id)),
        phasename=f"candidate_{cod_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    candidate.data["Histograms"][hist.name]["Scale"] = [0.01, True]
    project.set_Controls("parmMin", 0.0, variable="3:0:Scale")
    project.refine()
    print(
        "RESULT",
        json.dumps(
            {
                "candidate": cod_id,
                "scale": candidate.data["Histograms"][hist.name]["Scale"],
                "mass_fractions": hist.ComputeMassFracs(),
                "residuals": hist.residuals,
                "Rvals": project.data.get("Covariance", {})
                .get("data", {})
                .get("Rvals", {}),
            },
            default=str,
            sort_keys=True,
        ),
        flush=True,
    )


def main() -> None:
    # Sr3W2O9, high-pressure SrCO3, fergusonite SrWO4, SrO and SrO2.
    for cod_id in ("2311977", "1539128", "1546037", "7200689", "9008161"):
        test(cod_id)


if __name__ == "__main__":
    main()
