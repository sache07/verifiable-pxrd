#!/usr/bin/env python3
"""Stabilize the selected three-phase model with conservative coordinate refinement."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_trial" / "md_optimized.gpx"
OUTPUT = ROOT / ".tmp" / "final_trial" / "stabilized.gpx"


def freeze_all(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        phase.set_HAP_refinements(
            {
                "Scale": False,
                "Pref.Ori.": False,
                "Size": {"type": "isotropic", "refine": False},
                "Mustrain": {"type": "isotropic", "refine": False},
            },
            [hist],
        )


def state(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    print(
        label,
        json.dumps(
            {
                "residuals": hist.residuals,
                "Rvals": cov.get("Rvals", {}),
                "mass_fractions": hist.ComputeMassFracs(),
                "sample": hist.SampleParameters,
                "cells": {phase.name: phase.get_cell() for phase in project.phases()},
                "HAP": {
                    phase.name: {
                        "scale": phase.data["Histograms"][hist.name]["Scale"],
                        "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
                        "PO": phase.data["Histograms"][hist.name]["Pref.Ori."],
                    }
                    for phase in project.phases()
                },
            },
            default=str,
            sort_keys=True,
        ),
        flush=True,
    )


def refine(project: G2sc.G2Project, label: str) -> None:
    project.refine()
    state(project, label)


def enable_strain(project: G2sc.G2Project, enabled: bool) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": enabled}}, [hist]
        )


def enable_intensities(project: G2sc.G2Project, enabled: bool) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = enabled
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": enabled}, [hist])


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    project.set_Controls("cycles", 16)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    freeze_all(project)
    hist = project.histogram(0)
    carbonate = project.phase("SrCO3_orthorhombic")

    for index in range(3):
        project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Mustrain;i")
        project.set_Controls("parmMax", 15000.0, variable=f"{index}:0:Mustrain;i")

    # Alternate widths and intensities until neither block changes materially.
    for cycle in range(3):
        enable_intensities(project, False)
        enable_strain(project, True)
        refine(project, f"strain_{cycle + 1}")
        enable_strain(project, False)
        enable_intensities(project, True)
        refine(project, f"intensity_{cycle + 1}")

    # Update peak positions after the broadening model has settled.
    enable_intensities(project, False)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.SampleParameters["Shift"][1] = True
    refine(project, "cells_and_displacement")
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
    hist.SampleParameters["Shift"][1] = False

    # Texture and phase scale are highly correlated, so use coordinate descent.
    po = carbonate.data["Histograms"][hist.name]["Pref.Ori."]
    project.set_Controls("parmMin", 0.15, variable="2:0:MD")
    project.set_Controls("parmMax", 1.0, variable="2:0:MD")
    for cycle in range(2):
        enable_strain(project, False)
        enable_intensities(project, False)
        po[2] = True
        refine(project, f"texture_{cycle + 1}")
        po[2] = False
        enable_intensities(project, True)
        refine(project, f"post_texture_intensity_{cycle + 1}")

    # Final joint covariance for the parameters that control phase fractions.
    po[2] = False
    enable_strain(project, True)
    enable_intensities(project, True)
    refine(project, "joint_final")
    project.save()
    state(project, "FINAL")


if __name__ == "__main__":
    main()
