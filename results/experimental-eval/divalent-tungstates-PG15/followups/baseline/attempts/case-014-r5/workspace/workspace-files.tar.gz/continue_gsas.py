#!/usr/bin/env python3
"""Continue a screening GPX with profile refinement and print a compact summary."""

from __future__ import annotations

import json
import sys

from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(sys.argv[1])
project.set_Controls("cycles", 6)
hist = project.histogram(0)
for key in ("U", "V", "W", "X", "Y"):
    hist.InstrumentParameters[key][2] = True
project.refine()
project.save()
try:
    mass = hist.ComputeMassFracs()
except Exception as exc:
    mass = {"error": repr(exc)}
print(
    "RESULT",
    json.dumps(
        {
            "residuals": hist.residuals,
            "mass_fractions": mass,
            "instrument": hist.InstrumentParameters,
            "sample": hist.SampleParameters,
            "phases": {
                ph.name: {
                    "cell": ph.get_cell(),
                    "scale": ph.data["Histograms"][hist.name]["Scale"],
                }
                for ph in project.phases()
            },
        },
        sort_keys=True,
        default=str,
    ),
)
