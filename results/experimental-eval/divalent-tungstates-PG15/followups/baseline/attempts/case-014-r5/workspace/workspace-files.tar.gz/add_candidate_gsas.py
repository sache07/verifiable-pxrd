#!/usr/bin/env python3
"""Add a third candidate phase to the best two-phase screening model."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main(
    cod_id: str,
    texture: tuple[list[int], float, bool] | None = None,
    fix_extra_cell: bool = False,
) -> None:
    base = ROOT / ".tmp" / "screen" / "model_1528915.gpx"
    suffix = ""
    if texture is not None:
        axis, md_value, refine_texture = texture
        axis_text = "".join(str(v).replace("-", "m") for v in axis)
        mode = "ref" if refine_texture else "fix"
        suffix = f"_{axis_text}_{md_value:g}_{mode}".replace(".", "p")
    if fix_extra_cell:
        suffix += "_cellfix"
    out = ROOT / ".tmp" / "screen" / f"three_{cod_id}{suffix}.gpx"
    project = G2sc.G2Project(str(base), newgpx=str(out))
    project.set_Controls("cycles", 5)
    hist = project.histogram(0)

    # Freeze the already-determined profile while the new scale is introduced.
    for key in ("U", "V", "W", "X", "Y"):
        hist.InstrumentParameters[key][2] = False
    hist.SampleParameters["Shift"][1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})

    extra = project.add_phase(
        str(cod_path(cod_id)),
        phasename=f"candidate3_{cod_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    extra.data["Histograms"][hist.name]["Scale"] = [0.1, True]
    if texture is not None:
        axis, md, refine_texture = texture
        pref = extra.data["Histograms"][hist.name]["Pref.Ori."]
        pref[1] = md
        pref[2] = refine_texture
        pref[3] = axis
    project.refine()

    # Then allow peak positions and a limited global profile adjustment.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    if fix_extra_cell:
        extra.set_refinements({"Cell": False})
    hist.SampleParameters["Shift"][1] = True
    for key in ("W", "X"):
        hist.InstrumentParameters[key][2] = True
    project.refine()
    project.save()

    try:
        mass = hist.ComputeMassFracs()
    except Exception as exc:
        mass = {"error": repr(exc)}
    print(
        "RESULT",
        json.dumps(
            {
                "candidate": cod_id,
                "gpx": str(out),
                "residuals": hist.residuals,
                "mass_fractions": mass,
                "sample": hist.SampleParameters,
                "instrument": hist.InstrumentParameters,
                "phases": {
                    phase.name: {
                        "cell": phase.get_cell(),
                        "scale": phase.data["Histograms"][hist.name]["Scale"],
                        "composition": phase.composition,
                    }
                    for phase in project.phases()
                },
            },
            sort_keys=True,
            default=str,
        ),
    )


if __name__ == "__main__":
    texture_arg = None
    if len(sys.argv) >= 6:
        texture_arg = (
            [int(v) for v in sys.argv[2:5]],
            float(sys.argv[5]),
            len(sys.argv) == 6 or sys.argv[6].lower() != "fixed",
        )
    main(sys.argv[1], texture_arg, "fixcell" in [v.lower() for v in sys.argv[2:]])
