import sys

from GSASII import GSASIIscriptable as G2sc


name = sys.argv[1]
tag = name.split("_")[0]
gpx = G2sc.G2Project("polarization.gpx", newgpx=f"remove_{tag}.gpx")
hist = gpx.histogram(0)
gpx.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", []).clear()
hist.clear_refinements({"Instrument Parameters": ["Y"]})
phase = gpx.phase(name)
phase.data["Histograms"][hist.name]["Use"] = False
phase.data["Histograms"][hist.name]["Scale"][1] = False
gpx.set_Controls("cycles", 10)
gpx.do_refinements([{}])
print("REMOVED", name, hist.get_wR(), hist.residuals)
gpx.save()
