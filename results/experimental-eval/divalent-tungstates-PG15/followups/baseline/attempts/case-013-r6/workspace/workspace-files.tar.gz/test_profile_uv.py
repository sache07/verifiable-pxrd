from GSASII import GSASIIscriptable as G2sc
gpx = G2sc.G2Project("polarization.gpx", newgpx="profile_uv.gpx")
hist = gpx.histogram(0)
gpx.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", []).clear()
hist.clear_refinements({"Instrument Parameters": ["Y"]})
for variable, low, high in ((":0:U", 0.0, 100.0), (":0:V", -50.0, 50.0)):
    gpx.set_Controls("parmMin", low, variable=variable)
    gpx.set_Controls("parmMax", high, variable=variable)
gpx.set_Controls("cycles", 10)
for key in ("U", "V"):
    gpx.do_refinements([{"set": {"Instrument Parameters": [key]}}])
    inst = hist.data["Instrument Parameters"][0]
    print("RESULT", key, hist.get_wR(), {k: inst[k][1] for k in "UVWXY"}, hist.ComputeMassFracs())
gpx.save()
