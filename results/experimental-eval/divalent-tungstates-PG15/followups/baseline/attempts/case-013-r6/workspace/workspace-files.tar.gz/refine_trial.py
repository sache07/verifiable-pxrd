from pathlib import Path
from pprint import pprint

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summary(gpx, label):
    hist = gpx.histogram(0)
    print("\nSUMMARY", label)
    print("residuals")
    pprint(hist.residuals)
    print("instrument values")
    pprint({k: v[1:] for k, v in hist.data["Instrument Parameters"][0].items()})
    print("sample values")
    pprint({k: v for k, v in hist.data["Sample Parameters"].items() if isinstance(v, list)})
    for phase in gpx.phases():
        print("phase", phase.name, "cell", phase.get_cell())
        pprint(phase.data["Histograms"][hist.name])
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fractions unavailable", repr(exc))


gpx = G2sc.G2Project(newgpx="trial_refined.gpx")
hist = gpx.add_powder_histogram(
    "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
)
for name, cod_id in (
    ("PbWO4_scheelite", "9009811"),
    ("WO3_monoclinic", "1010618"),
    ("PbO_massicot", "2310433"),
):
    phase = gpx.add_phase(
        str(cod_path(cod_id)),
        phasename=name,
        histograms=[hist],
        fmthint="CIF",
    )
    phase.data["Histograms"][hist.name]["Scale"][0] = 0.01

# A visually estimated zero offset places the starting reflections inside the
# observed profiles, allowing the nonlinear least-squares fit to converge.
hist.data["Instrument Parameters"][0]["Zero"][1] = 0.30
hist.data["Sample Parameters"]["Scale"][1] = False
hist.data["Limits"][1] = [10.05, 99.9]
gpx.set_Controls("cycles", 8)

steps = [
    {"set": {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 15},
              "PhaseFraction": True}},
    {"set": {"Instrument Parameters": ["Zero"]}},
    {"set": {"Cell": True}},
    {"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}},
]

for i, step in enumerate(steps, 1):
    print("\nREFINEMENT STEP", i, step)
    try:
        gpx.do_refinements([step])
    except Exception:
        summary(gpx, f"failed step {i}")
        raise
    summary(gpx, f"step {i}")

gpx.save()
