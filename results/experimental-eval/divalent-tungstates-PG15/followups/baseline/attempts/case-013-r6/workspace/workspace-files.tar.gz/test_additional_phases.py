from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = (
    ("PbWO4_raspite", "9007617"),
    ("Pb3O4_tetragonal", "9012124"),
    ("Pb3O4_orthorhombic", "9013442"),
    ("WO2_monoclinic", "1548686"),
    ("WO2_tetragonal", "5910153"),
    ("W3O8_orthorhombic", "2101050"),
    ("W2O7_cubic", "1529777"),
    ("Pb2O3_monoclinic", "2311012"),
)


for name, cod_id in CANDIDATES:
    gpx = G2sc.G2Project("polarization.gpx", newgpx=f"candidate2_{cod_id}.gpx")
    hist = gpx.histogram(0)
    gpx.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", []).clear()
    hist.clear_refinements({"Instrument Parameters": ["Y"]})
    phase = gpx.add_phase(str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF")
    gpx.update_ids()
    gpx.save()
    gpx.index_ids()
    phase = gpx.phase(name)
    phase.data["Histograms"][hist.name]["Scale"] = [0.01, True]
    phase.data["General"]["Cell"][0] = False
    gpx.save()
    gpx.set_Controls("cycles", 6)
    try:
        gpx.do_refinements([{}])
        print("FIXED", name, cod_id, "wR", hist.get_wR(), "scale", phase.HAPvalue("Scale"), "fracs", hist.ComputeMassFracs())
        gpx.do_refinements([{"set": {"Cell": True}}], phase=name)
        print("CELL", name, cod_id, "wR", hist.get_wR(), "cell", phase.get_cell(), "scale", phase.HAPvalue("Scale"), "fracs", hist.ComputeMassFracs())
        gpx.save()
    except Exception as exc:
        print("FAILED", name, cod_id, repr(exc))
