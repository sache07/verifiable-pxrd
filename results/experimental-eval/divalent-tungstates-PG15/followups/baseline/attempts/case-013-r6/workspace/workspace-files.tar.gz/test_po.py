from GSASII import GSASIIscriptable as G2sc


for direction in ([0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 2]):
    tag = "".join(map(str, direction))
    gpx = G2sc.G2Project("four.gpx", newgpx=f"po_{tag}.gpx")
    hist = gpx.histogram(0)
    phase = gpx.phase("PbWO4_scheelite")
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(direction)
    gpx.set_Controls("cycles", 8)
    gpx.do_refinements([{}])
    print("RESULT", direction, "wR", hist.get_wR(), "PO", po, "fractions", hist.ComputeMassFracs())
    gpx.save()
