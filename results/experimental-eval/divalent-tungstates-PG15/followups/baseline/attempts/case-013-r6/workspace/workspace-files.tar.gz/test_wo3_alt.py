import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


name, cod_id = sys.argv[1:3]
root = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
cif = root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"

gpx = G2sc.G2Project("polarization.gpx", newgpx=f"wo3alt_{cod_id}.gpx")
hist = gpx.histogram(0)
gpx.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", []).clear()
hist.clear_refinements({"Instrument Parameters": ["Y"]})
old = gpx.phase("WO3_gamma_monoclinic")
old.data["Histograms"][hist.name]["Use"] = False
old.data["Histograms"][hist.name]["Scale"][1] = False
phase = gpx.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
gpx.update_ids()
gpx.save()
gpx.index_ids()
phase = gpx.phase(name)
phase.data["Histograms"][hist.name]["Scale"] = [0.9, True]
phase.data["General"]["Cell"][0] = False
gpx.save()
gpx.set_Controls("cycles", 10)
gpx.do_refinements([{}])
print("FIXED", name, cod_id, hist.get_wR(), phase.HAPvalue("Scale"), hist.ComputeMassFracs())
gpx.do_refinements([{"set": {"Cell": True}}], phase=name)
print("CELL", name, cod_id, hist.get_wR(), phase.get_cell(), phase.HAPvalue("Scale"), hist.ComputeMassFracs())
gpx.save()
