from GSASII import GSASIIscriptable as G2sc


for value in (0.0, 0.0025, 0.0050, 0.0075, 0.0100):
    tag = str(value).replace(".", "p")
    gpx = G2sc.G2Project("four.gpx", newgpx=f"uiso_{tag}.gpx")
    hist = gpx.histogram(0)
    phase = gpx.phase("PbWO4_scheelite")
    gpx.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", []).clear()
    hist.clear_refinements({"Instrument Parameters": ["Y"]})
    phase.clear_refinements({"Atoms": {a.label: "" for a in phase.atoms()}})
    for atom in phase.atoms():
        atom.uiso = value
        atom.refinement_flags = ""
    gpx.set_Controls("cycles", 8)
    gpx.do_refinements([{}])
    print("RESULT", value, hist.get_wR(), hist.ComputeMassFracs())
    gpx.save()
