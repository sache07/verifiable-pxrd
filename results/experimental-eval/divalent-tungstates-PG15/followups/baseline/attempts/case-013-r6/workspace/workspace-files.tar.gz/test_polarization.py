from GSASII import GSASIIscriptable as G2sc


gpx = G2sc.G2Project("uiso_0p0.gpx", newgpx="polarization.gpx")
hist = gpx.histogram(0)
gpx.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", []).clear()
hist.clear_refinements({"Instrument Parameters": ["Y"]})
gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
gpx.set_Controls("cycles", 10)
gpx.do_refinements([{"set": {"Instrument Parameters": ["Polariz."]}}])
print("RESULT", hist.get_wR(), hist.data["Instrument Parameters"][0]["Polariz."], hist.ComputeMassFracs())
gpx.save()
