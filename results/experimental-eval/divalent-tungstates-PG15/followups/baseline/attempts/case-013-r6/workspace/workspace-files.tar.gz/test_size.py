from GSASII import GSASIIscriptable as G2sc


gpx = G2sc.G2Project("polarization.gpx", newgpx="size.gpx")
hist = gpx.histogram(0)
gpx.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", []).clear()
hist.clear_refinements({"Instrument Parameters": ["Y"]})
for phase in gpx.phases():
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True, "value": 1.0}})
gpx.set_Controls("cycles", 12)
gpx.do_refinements([{}])
print("RESULT", hist.get_wR(), hist.ComputeMassFracs())
for phase in gpx.phases():
    print(phase.name, phase.data["Histograms"][hist.name]["Size"])
print(gpx.get_VaryList())
gpx.save()
