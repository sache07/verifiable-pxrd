from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = (
    ("PbWO4_scheelite", "9009811"),
    ("WO3_gamma_monoclinic", "1528915"),
    ("PbO_massicot", "2310433"),
    ("PbO_litharge", "9012700"),
)


gpx = G2sc.G2Project(newgpx="four.gpx")
hist = gpx.add_powder_histogram("inputs/pattern.csv", "instrument.instprm", fmthint="comma")
for name, cod_id in PHASES:
    phase = gpx.add_phase(str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF")
    phase.data["Histograms"][hist.name]["Scale"][0] = 0.01

inst = hist.data["Instrument Parameters"][0]
for key, value in {"Zero": 0.27, "U": 5.0, "V": -2.0, "W": 20.0, "X": 5.0, "Y": 2.0}.items():
    inst[key][0] = inst[key][1] = value
hist.data["Sample Parameters"]["Scale"][1] = False
hist.data["Limits"][1] = [10.05, 99.9]
gpx.set_Controls("cycles", 6)
gpx.save()


def run(label, refs, phase="all"):
    print("\n---", label, "---")
    gpx.do_refinements([refs], phase=phase)
    print("wR", hist.get_wR(), "Zero", inst["Zero"][1], "UVWXY", [inst[k][1] for k in "UVWXY"])
    print("fractions", hist.ComputeMassFracs())
    for p in gpx.phases():
        print(p.name, p.get_cell())


run("background and phase scales", {"set": {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 18}, "PhaseFraction": True}})
run("zero", {"set": {"Instrument Parameters": ["Zero"]}})
for phase_name, _ in PHASES:
    run(f"cell {phase_name}", {"set": {"Cell": True}}, phase=phase_name)

# Keep the empirical profile physically valid while allowing the uncalibrated
# instrumental broadening to adapt to this scan.
for variable, low, high in ((":0:W", 0.01, 100.0), (":0:X", 0.0, 30.0), (":0:Y", 0.0, 30.0)):
    gpx.set_Controls("parmMin", low, variable=variable)
    gpx.set_Controls("parmMax", high, variable=variable)
run("profile W", {"set": {"Instrument Parameters": ["W"]}})
run("profile X", {"set": {"Instrument Parameters": ["X"]}})
run("profile Y", {"set": {"Instrument Parameters": ["Y"]}})
run("settle", {})
gpx.save()
