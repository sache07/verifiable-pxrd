from pathlib import Path
from pprint import pprint

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def brief(gpx, label):
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    print("\nSUMMARY", label, "wR", hist.get_wR())
    print("inst", {k: (v[1], v[2]) for k, v in inst.items() if k in ("Zero", "U", "V", "W", "X", "Y")})
    for p in gpx.phases():
        print(p.name, "cell", p.get_cell(), "scale", p.data["Histograms"][hist.name]["Scale"])
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fractions unavailable", repr(exc))


gpx = G2sc.G2Project(newgpx="trial2.gpx")
hist = gpx.add_powder_histogram("inputs/pattern.csv", "instrument.instprm", fmthint="comma")
for name, cod_id in (
    ("PbWO4_scheelite", "9009811"),
    ("WO3_monoclinic", "1010618"),
    ("PbO_massicot", "2310433"),
):
    p = gpx.add_phase(str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF")
    p.data["Histograms"][hist.name]["Scale"][0] = 0.01

inst = hist.data["Instrument Parameters"][0]
inst["Zero"][1] = 0.30
inst["W"][0] = inst["W"][1] = 250.0
hist.data["Sample Parameters"]["Scale"][1] = False
hist.data["Limits"][1] = [10.05, 99.9]
gpx.set_Controls("cycles", 5)

stages = [
    ("background/scales", {"set": {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 15}, "PhaseFraction": True}}, "all"),
    ("zero", {"set": {"Instrument Parameters": ["Zero"]}}, "all"),
    ("W", {"set": {"Instrument Parameters": ["W"]}}, "all"),
    ("PbWO4 cell", {"set": {"Cell": True}}, "PbWO4_scheelite"),
    ("PbO cell", {"set": {"Cell": True}}, "PbO_massicot"),
    ("WO3 cell", {"set": {"Cell": True}}, "WO3_monoclinic"),
    ("profile U V X Y", {"set": {"Instrument Parameters": ["U", "V", "X", "Y"]}}, "all"),
]

for label, refs, phase in stages:
    print("\nREFINE", label)
    gpx.do_refinements([refs], phase=phase)
    brief(gpx, label)

gpx.save()
