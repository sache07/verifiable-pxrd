from pathlib import Path
from pprint import pprint

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


gpx = G2sc.G2Project(newgpx="trial.gpx")
hist = gpx.add_powder_histogram(
    "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
)
for name, cod_id in (
    ("PbWO4_scheelite", "9009811"),
    ("WO3_monoclinic", "1010618"),
    ("PbO_massicot", "2310433"),
):
    gpx.add_phase(
        str(cod_path(cod_id)),
        phasename=name,
        histograms=[hist],
        fmthint="CIF",
    )

print("histogram", hist.name)
print("limits")
pprint(hist.data["Limits"])
print("background")
pprint(hist.data["Background"])
print("instrument")
pprint(hist.data["Instrument Parameters"])
print("sample")
pprint(hist.data["Sample Parameters"])
print("residuals")
pprint(hist.residuals)
for phase in gpx.phases():
    print("phase", phase.name)
    pprint(phase.get_cell())
    pprint(phase.data["Histograms"][hist.name])
gpx.save()
