from GSASII import GSASIIscriptable as G2sc


gpx = G2sc.G2Project("four.gpx", newgpx="uiso.gpx")
hist = gpx.histogram(0)
phase = gpx.phase("PbWO4_scheelite")
gpx.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", []).clear()
hist.clear_refinements({"Instrument Parameters": ["Y"]})
phase.set_refinements({"Atoms": {"all": "U"}})
gpx.add_EquivConstr(("0::AUiso:0", "0::AUiso:1", "0::AUiso:2"))
gpx.set_Controls("parmMin", 0.0, variable="0::AUiso:0")
gpx.set_Controls("parmMax", 0.03, variable="0::AUiso:0")
gpx.set_Controls("cycles", 10)
gpx.do_refinements([{}])
print("RESULT", "wR", hist.get_wR(), "fractions", hist.ComputeMassFracs())
for atom in phase.atoms():
    print(atom.label, atom.uiso, atom.refinement_flags)
print("vary", gpx.get_VaryList())
gpx.save()
