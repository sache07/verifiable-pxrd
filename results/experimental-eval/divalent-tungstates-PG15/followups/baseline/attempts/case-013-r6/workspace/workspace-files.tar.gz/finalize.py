import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIspc as G2spc


PHASE_INFO = {
    "PbWO4_scheelite": {
        "display_name": "PbWO4 (scheelite)",
        "formula": "PbWO4",
        "space_group": "I 41/a",
        "source": "COD 9009811",
        "cif": "phase_PbWO4_scheelite.cif",
    },
    "WO3_gamma_monoclinic": {
        "display_name": "WO3 (gamma, monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "source": "COD 1528915",
        "cif": "phase_WO3_gamma_monoclinic.cif",
    },
    "PbO_massicot": {
        "display_name": "PbO (massicot)",
        "formula": "PbO",
        "space_group": "P b c m",
        "source": "COD 2310433",
        "cif": "phase_PbO_massicot.cif",
    },
    "PbO_litharge": {
        "display_name": "PbO (litharge)",
        "formula": "PbO",
        "space_group": "P 4/n m m",
        "source": "COD 9012700; transformed to conventional origin choice 2",
        "cif": "phase_PbO_litharge.cif",
    },
}


gpx = G2sc.G2Project("polarization.gpx", newgpx="final.gpx")
hist = gpx.histogram(0)
controls = gpx.data["Controls"]["data"]
controls["Author"] = "Codex PXRD phase analysis"
controls.get("parmFrozen", {}).get("FrozenList", []).clear()

# COD 9012700 is supplied in P 4/n m m origin choice 1. The GSAS-II CIF
# importer shifts its coordinates but retains the origin-choice-2 symmetry
# operators, which incorrectly puts Pb on a multiplicity-4 site. Put litharge
# on the conventional origin-choice-2 sites before refining/exporting:
# Pb 2c (1/4,1/4,z) and O 2a (3/4,1/4,0).
litharge = gpx.phase("PbO_litharge")
cx, ct, cs, cia = litharge.data["General"]["AtomPtrs"]
corrected_sites = {"Pb": (0.25, 0.25), "O": (0.75, 0.25)}
for atom in litharge.data["Atoms"]:
    atom[cx], atom[cx + 1] = corrected_sites[atom[ct]]
    site_symmetry, multiplicity = G2spc.SytSym(
        atom[cx : cx + 3], litharge.data["General"]["SGData"]
    )[:2]
    atom[cs] = site_symmetry
    atom[cs + 1] = multiplicity
G2sc.SetupGeneral(litharge.data, None)

hist.clear_refinements({"Instrument Parameters": ["U", "V", "Y", "SH/L"]})
hist.set_refinements({"Instrument Parameters": ["Zero", "Polariz.", "W", "X"]})
hist.data["Limits"][1] = list(hist.data["Limits"][0])
for phase in gpx.phases():
    phase.data["General"]["Cell"][0] = True
    phase.data["Histograms"][hist.name]["Scale"][1] = True
    phase.data["Histograms"][hist.name]["Use"] = True
    phase.data["Histograms"][hist.name]["Pref.Ori."][2] = False
    phase.data["Histograms"][hist.name]["Size"][2] = [False, False, False]
    phase.data["Histograms"][hist.name]["Mustrain"][2] = [False, False, False]
    for atom in phase.atoms():
        atom.refinement_flags = ""

gpx.set_Controls("cycles", 15)
for cycle in range(4):
    gpx.do_refinements([{}])
    rvals = gpx.data["Covariance"]["data"]["Rvals"]
    print(
        "settle",
        cycle + 1,
        "Rwp",
        rvals["Rwp"],
        "GOF",
        rvals["GOF"],
        "max_shift_over_esd",
        rvals["Max shft/sig"],
    )

gpx.save()

fractions = hist.ComputeMassFracs()
for phase in gpx.phases():
    phase.export_CIF(PHASE_INFO[phase.name]["cif"])

x = hist.getdata("X")
yobs = hist.getdata("Yobs")
ycalc = hist.getdata("Ycalc")
background = hist.getdata("Background")
difference = hist.getdata("Residual")
with open("fit.csv", "w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_intensity_counts",
            "calculated_intensity_counts",
            "background_intensity_counts",
            "difference_observed_minus_calculated_counts",
        ]
    )
    writer.writerows(zip(x, yobs, ycalc, background, difference))

rvals = gpx.data["Covariance"]["data"]["Rvals"]
residuals = hist.residuals
phases = []
for phase in gpx.phases():
    value, esd = fractions[phase.name]
    info = PHASE_INFO[phase.name]
    phases.append(
        {
            "name": info["display_name"],
            "formula": info["formula"],
            "space_group": info["space_group"],
            "initial_structure_source": info["source"],
            "cif_path": info["cif"],
            "weight_fraction": value,
            "weight_fraction_formal_esd": esd,
            "unit_cell": phase.get_cell(),
            "phase_Rf_percent": residuals.get(f"{phase.id}:0:Rf"),
            "phase_Rf2_percent": residuals.get(f"{phase.id}:0:Rf^2"),
        }
    )

result = {
    "phases": phases,
    "weight_fraction_basis": "Normalized over the four modeled crystalline phases; amorphous content and unmodeled crystalline material are excluded.",
    "modeled_weight_fraction_sum": sum(p["weight_fraction"] for p in phases),
    "uncertainty_note": "Weight-fraction e.s.d.s are formal covariance estimates only; profile mismatch, microabsorption and any unmodeled material make the true uncertainty larger.",
    "fit_statistics": {
        "Rwp_percent": residuals["wR"],
        "Rp_percent": residuals["R"],
        "Rexp_percent": residuals["wRmin"],
        "goodness_of_fit_sqrt_reduced_chi_square": rvals["GOF"],
        "reduced_chi_square": rvals["GOF"] ** 2,
        "chi_square": rvals["chisq"],
        "n_observations": rvals["Nobs"],
        "n_refined_variables": rvals["Nvars"],
        "converged": bool(rvals["converged"]),
        "two_theta_range_deg": [float(hist.data["Limits"][1][0]), float(hist.data["Limits"][1][1])],
        "weighting": "Poisson proxy w=1/I because pointwise standard uncertainties were not supplied.",
    },
    "unmodeled_features": {
        "status": "A fifth phase could not be assigned reliably.",
        "details": "The largest narrow positive residual is near 25.91 degrees 2theta, with other maxima near 30.15 and 31.05 degrees. Tested Pb-W-O candidates either refined to zero, required implausible cells/chemistry, or did not explain a consistent residual family.",
    },
}
with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps(result, indent=2))
