from GSASII import GSASIIscriptable as G2sc


gpx = G2sc.G2Project("polarization.gpx", newgpx="oxygen2.gpx")
hist = gpx.histogram(0)
phase = gpx.phase("PbWO4_scheelite")
gpx.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", []).clear()
hist.clear_refinements({"Instrument Parameters": ["Y"]})
phase.set_refinements({"Atoms": {"O": "X"}})
starting = dict(zip("xyz", phase.atom("O").coordinates))
for axis in "xyz":
    variable = f"0::dA{axis}:2"
    gpx.set_Controls("parmMin", starting[axis] - 0.03, variable=variable)
    gpx.set_Controls("parmMax", starting[axis] + 0.03, variable=variable)
gpx.set_Controls("cycles", 10)
gpx.do_refinements([{}])
print("RESULT", hist.get_wR(), hist.ComputeMassFracs())
for atom in phase.atoms():
    print(atom.label, atom.coordinates, atom.uiso, atom.refinement_flags)
print(gpx.get_VaryList())
gpx.save()
