#!/usr/bin/env python3
"""Freeze the selected texture correction and settle all remaining variables."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


source = Path(".tmp/textured.gpx").resolve()
output = Path(".tmp/textured_fixed.gpx").resolve()
if output.exists():
    output.unlink()
project = G2sc.G2Project(str(source), newgpx=str(output))
hist = project.histogram(0)
project.set_Controls("cycles", 15)
po = project.phase("Sr3WO6").data["Histograms"][hist.name]["Pref.Ori."]
po[2] = False

passes = []
for number in range(3):
    project.do_refinements([{}])
    passes.append(
        {
            "pass": number + 1,
            "Rwp": hist.get_wR(),
            "mass_fractions": hist.ComputeMassFracs(),
            "max_shift_over_esd": project.data["Covariance"]["data"]["Rvals"]["Max shft/sig"],
        }
    )
    if passes[-1]["max_shift_over_esd"] < 0.1:
        break
project.save(str(output))
summary = {
    "passes": passes,
    "preferred_orientation": po,
    "mass_fractions": hist.ComputeMassFracs(),
    "residuals": hist.residuals,
    "covariance": project.data["Covariance"]["data"]["Rvals"],
}
output.with_suffix(".json").write_text(json.dumps(summary, indent=2, default=float) + "\n")
print(json.dumps(summary, indent=2, default=float))
