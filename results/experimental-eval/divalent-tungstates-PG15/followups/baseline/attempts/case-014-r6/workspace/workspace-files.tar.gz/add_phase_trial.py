#!/usr/bin/env python3
"""Add one phase to a converged GSAS-II project and refine it stably."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("base")
parser.add_argument("output")
parser.add_argument("cif")
parser.add_argument("name")
parser.add_argument("scale", type=float)
args = parser.parse_args()

out = Path(args.output).resolve()
if out.exists():
    out.unlink()
project = G2sc.G2Project(str(Path(args.base).resolve()), newgpx=str(out))
hist = project.histogram(0)

# Freeze the converged two-phase model for the first candidate-scale test.
hist.Background[0][1] = False
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for value in hist.SampleParameters.values():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = False
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])

candidate = project.add_phase(
    str(Path(args.cif).resolve()), phasename=args.name,
    histograms=[hist], fmthint="CIF"
)
candidate.data["Histograms"][hist.name]["Scale"] = [args.scale, True]
project.set_Controls("cycles", 12)

stages = []
for label, action in [
    ("candidate_scale", lambda: None),
    ("all_scales_background", lambda: (
        setattr(hist.Background[0], "unused", False) if False else None
    )),
    ("candidate_cell", lambda: None),
    ("profile", lambda: None),
    ("settle", lambda: None),
]:
    if label == "all_scales_background":
        hist.Background[0][1] = True
        for phase in project.phases():
            phase.data["Histograms"][hist.name]["Scale"][1] = True
    elif label == "candidate_cell":
        candidate.data["General"]["Cell"][0] = True
    elif label == "profile":
        for key in ("Zero", "U", "V", "W", "X"):
            hist.InstrumentParameters[key][2] = True
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
    try:
        project.do_refinements([{}])
        stages.append({
            "stage": label,
            "wR": hist.get_wR(),
            "scale": candidate.data["Histograms"][hist.name]["Scale"][0],
            "cell": candidate.get_cell(),
        })
    except Exception as exc:
        stages.append({"stage": label, "error": repr(exc)})
        break

project.save(str(out))
result = {
    "wR": hist.get_wR(),
    "residuals": hist.residuals,
    "mass_fractions": hist.ComputeMassFracs(),
    "stages": stages,
    "instrument": {
        k: v[1] if isinstance(v, list) and len(v) > 1 else v
        for k, v in hist.InstrumentParameters.items()
    },
    "phases": [
        {
            "name": p.name,
            "cell": p.get_cell(),
            "scale": p.data["Histograms"][hist.name]["Scale"],
        }
        for p in project.phases()
    ],
}
out.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float))
