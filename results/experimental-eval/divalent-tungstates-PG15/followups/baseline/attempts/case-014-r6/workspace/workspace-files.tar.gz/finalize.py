#!/usr/bin/env python3
"""Settle the selected Rietveld model and export all submission artifacts."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "tight_textured2.gpx"
FINAL = ROOT / "final.gpx"


def plain(value):
    """Convert numpy values recursively for strict JSON serialization."""
    if isinstance(value, dict):
        return {str(key): plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(item) for item in value]
    if isinstance(value, (np.integer, np.floating)):
        return value.item()
    return value


if FINAL.exists():
    FINAL.unlink()

project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
hist = project.histogram(0)
project.set_Controls("cycles", 30)
project.data["Controls"]["data"]["min dM/M"] = 1e-7

# One final pass starts from the converged model and updates its covariance
# matrix, formal uncertainties, profile arrays and project history together.
project.do_refinements([{}])
project.save(str(FINAL))

cif_names = {
    "SrWO4": "SrWO4.cif",
    "WO3": "WO3.cif",
    "Sr3WO6": "Sr3WO6.cif",
}
for phase in project.phases():
    phase.export_CIF(str(ROOT / cif_names[phase.name]))

# Export exactly the fitted interval, omitting the handful of edge points that
# were intentionally outside the GSAS-II refinement limits.
x = np.asarray(hist.getdata("x"), dtype=float)
yobs = np.asarray(hist.getdata("yobs"), dtype=float)
ycalc = np.asarray(hist.getdata("ycalc"), dtype=float)
bkg = np.asarray(hist.getdata("background"), dtype=float)
diff = np.asarray(hist.getdata("residual"), dtype=float)
lower, upper = hist.Limits("lower"), hist.Limits("upper")
# GSAS-II snaps each nominal limit to the nearest measured point. Its populated
# profile arrays therefore give the exact 8270-point interval used in the fit.
selected = (ycalc != 0.0) | (bkg != 0.0)
profile = np.column_stack((x[selected], yobs[selected], ycalc[selected], diff[selected], bkg[selected]))
np.savetxt(
    ROOT / "fit.csv",
    profile,
    delimiter=",",
    header="two_theta_deg,observed_intensity,calculated_intensity,difference_observed_minus_calculated,background_intensity",
    comments="",
    fmt=["%.8f", "%.6f", "%.6f", "%.6f", "%.6f"],
)

mass_fractions = hist.ComputeMassFracs()
covariance = project.data["Covariance"]["data"]["Rvals"]
residuals = hist.residuals
phases = []
formulae = {"SrWO4": "SrWO4", "WO3": "WO3", "Sr3WO6": "Sr3WO6"}
for index, phase in enumerate(project.phases()):
    cell, cell_esd = phase.get_cell_and_esd()
    fraction, fraction_esd = mass_fractions[phase.name]
    phase_result = {
            "name": phase.name,
            "formula": formulae[phase.name],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": cif_names[phase.name],
            "weight_fraction": float(fraction),
            "weight_fraction_formal_esd": float(fraction_esd),
            "unit_cell": plain(cell),
            "unit_cell_formal_esd": plain(cell_esd),
            "R_F_percent": float(residuals[f"{index}:0:Rf"]),
            "R_F_squared_percent": float(residuals[f"{index}:0:Rf^2"]),
        }
    preferred = phase.data["Histograms"][hist.name]["Pref.Ori."]
    if preferred[0] == "MD" and (preferred[2] or abs(preferred[1] - 1.0) > 1e-6):
        phase_result["preferred_orientation"] = {
            "model": "March-Dollase",
            "axis_hkl": preferred[3],
            "ratio": float(preferred[1]),
            "refined": bool(preferred[2]),
        }
    phases.append(phase_result)

result = {
    "phases": phases,
    "weight_fraction_basis": "normalized over the three modeled crystalline phases; sum = 1",
    "fit_statistics": {
        "Rwp_percent": float(residuals["wR"]),
        "Rp_percent": float(residuals["R"]),
        "Rexp_percent": float(residuals["wRmin"]),
        "goodness_of_fit": float(covariance["GOF"]),
        "chi_squared": float(covariance["chisq"]),
        "number_of_observations": int(covariance["Nobs"]),
        "number_of_refined_variables": int(covariance["Nvars"]),
        "converged": bool(covariance["converged"]),
        "maximum_shift_over_esd": float(covariance["Max shft/sig"]),
    },
    "refinement": {
        "software": "GSAS-II",
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "radiation": "Cu Kalpha1/Kalpha2",
        "wavelengths_angstrom": [1.540598, 1.544426],
        "Kalpha2_to_Kalpha1_ratio": 0.5,
        "two_theta_range_deg": [float(lower), float(upper)],
        "profile_points": int(selected.sum()),
        "background": "15-term Chebyshev-1",
        "sample_correction": {
            "model": "Suortti surface roughness",
            "A": float(hist.SampleParameters["SurfRoughA"][0]),
            "B": float(hist.SampleParameters["SurfRoughB"][0]),
        },
    },
    "uncertainty_note": (
        "Fraction esds are least-squares formal values only and do not include "
        "systematic uncertainty from the intensity-error model, surface roughness, "
        "microabsorption, the strong Sr3WO6 preferred-orientation correction, or "
        "the analogue-based Sr3WO6 atomic coordinates."
    ),
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

print(json.dumps(result, indent=2))
