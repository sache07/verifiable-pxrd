#!/usr/bin/env python3
"""Build a chemically correct Sr3WO6 starting model from Sr2CaWO6."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/10/46/2104688.cif"
)
OUTPUT = Path(".tmp/sr3wo6_start.cif")
CA3_SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/56/30/1563081.cif"
)
CA3_OUTPUT = Path(".tmp/sr3wo6_ca3_analogue.cif")


structure = Structure.from_file(SOURCE)
structure.replace_species({"Ca": "Sr"})
# Approximate P21/c metric from the resolved (200), (020), (112), and (220)
# lines. Atomic fractional coordinates come from the closest local analogue,
# Sr2CaWO6, and are subsequently tested/refined against the measured profile.
structure = Structure(
    Lattice.from_parameters(6.068, 5.541, 8.360, 90.0, 90.0, 90.0),
    structure.species,
    structure.frac_coords,
    site_properties=structure.site_properties,
)
CifWriter(structure, symprec=1e-3).write_file(OUTPUT)

# Independent A3WO6 analogue: Ca3WO6 has the exact stoichiometry and P21/n
# topology. Swap Ca for Sr and use the indexed Sr-cell metric (in this source's
# axis order) to test whether its distinct octahedral tilts improve intensities.
ca3 = Structure.from_file(CA3_SOURCE)
ca3.replace_species({"Ca": "Sr"})
ca3 = Structure(
    Lattice.from_parameters(5.548, 6.060, 8.363, 90.0, 90.245, 90.0),
    ca3.species,
    ca3.frac_coords,
    site_properties=ca3.site_properties,
)
CifWriter(ca3, symprec=1e-3).write_file(CA3_OUTPUT)
