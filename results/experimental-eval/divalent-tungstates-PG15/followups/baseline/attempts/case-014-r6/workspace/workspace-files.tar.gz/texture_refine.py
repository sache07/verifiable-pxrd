#!/usr/bin/env python3
"""Stable staged refinement of the Sr3WO6 March-Dollase correction."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


base = Path(".tmp/var_rough.gpx").resolve()
out = Path(".tmp/textured.gpx").resolve()
if out.exists():
    out.unlink()
project = G2sc.G2Project(str(base), newgpx=str(out))
hist = project.histogram(0)
project.set_Controls("cycles", 15)

# Freeze the converged untextured model, then introduce the two correlated
# minor-phase parameters by themselves.
hist.Background[0][1] = False
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for key in ("SurfRoughA", "SurfRoughB"):
    hist.SampleParameters[key][1] = False
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    phase.data["Histograms"][hist.name]["Scale"][1] = False

sr3 = project.phase("Sr3WO6")
hap = sr3.data["Histograms"][hist.name]
hap["Scale"][1] = True
hap["Pref.Ori."][1:4] = [0.5, True, [1, 0, 0]]

stages = []
for stage in (
    "sr3_scale_and_texture",
    "all_phase_scales",
    "background_and_roughness",
    "unit_cells",
    "instrument_profile",
    "settle",
):
    if stage == "all_phase_scales":
        for phase in project.phases():
            phase.data["Histograms"][hist.name]["Scale"][1] = True
    elif stage == "background_and_roughness":
        hist.Background[0][1] = True
        for key in ("SurfRoughA", "SurfRoughB"):
            hist.SampleParameters[key][1] = True
    elif stage == "unit_cells":
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
    elif stage == "instrument_profile":
        for key in ("Zero", "U", "V", "W", "X"):
            hist.InstrumentParameters[key][2] = True
    project.do_refinements([{}])
    stages.append(
        {
            "stage": stage,
            "Rwp": hist.get_wR(),
            "Sr3WO6_scale": hap["Scale"][0],
            "MD_ratio": hap["Pref.Ori."][1],
            "mass_fractions": hist.ComputeMassFracs(),
        }
    )

project.save(str(out))
data = {
    "stages": stages,
    "residuals": hist.residuals,
    "mass_fractions": hist.ComputeMassFracs(),
    "preferred_orientation": hap["Pref.Ori."],
    "sample": hist.SampleParameters,
    "covariance": project.data["Covariance"]["data"]["Rvals"],
}
out.with_suffix(".json").write_text(json.dumps(data, indent=2, default=float) + "\n")
print(json.dumps(data, indent=2, default=float))
