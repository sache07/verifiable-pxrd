#!/usr/bin/env python3
"""Run a staged GSAS-II trial refinement for a specified phase set."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output")
    parser.add_argument("cifs", nargs="+")
    parser.add_argument("--names", nargs="*")
    parser.add_argument("--initial-scales", nargs="*", type=float)
    parser.add_argument("--refine-all-cells", action="store_true")
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    out = Path(args.output).resolve()
    if out.exists():
        out.unlink()

    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(Path(".tmp/pattern.xye").resolve()),
        str(Path("instrument.instprm").resolve()),
        fmthint="xye",
    )
    names = args.names or [Path(p).stem for p in args.cifs]
    if len(names) != len(args.cifs):
        raise ValueError("--names must match the number of CIF files")
    phases = [
        project.add_phase(str(Path(cif).resolve()), phasename=name,
                          histograms=[hist], fmthint="CIF")
        for cif, name in zip(args.cifs, names)
    ]

    project.set_Controls("cycles", args.cycles)
    hist.set_refinements({
        "Limits": [10.05, 99.90],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 15,
        },
    })
    # The global sample scale is exactly correlated with all HAP phase scales.
    # Keep it fixed at unity so phase scales (and derived weight fractions) are
    # identifiable.
    hist.SampleParameters["Scale"][0] = 1.0
    hist.SampleParameters["Scale"][1] = False

    # Give each linked phase a positive initial scale, then stage increasingly
    # correlated parameters so the least-squares fit has a stable starting point.
    scale_starts = args.initial_scales or (
        [10.0, 1.0] + [0.03] * max(0, len(phases) - 2)
    )
    if len(scale_starts) != len(phases):
        raise ValueError("--initial-scales must match the number of phases")
    for phase, scale in zip(phases, scale_starts):
        phase.data["Histograms"][hist.name]["Scale"][0] = scale
    cell_phases = phases if args.refine_all_cells else phases[: min(2, len(phases))]
    stages = [
        {"set": {"Scale": True}},
        {"set": {"Instrument Parameters": ["Zero"], "Cell": True},
         "phases": cell_phases},
        {"set": {"Instrument Parameters": ["U", "V", "W"]}},
        {"set": {"Instrument Parameters": ["X"]}},
        {},
    ]
    log = []
    for number, stage in enumerate(stages, 1):
        try:
            project.do_refinements([stage])
            log.append({
                "stage": number,
                "wR": hist.get_wR(),
                "residuals": hist.residuals,
                "cells": {p.name: p.get_cell() for p in phases},
            })
        except Exception as exc:
            log.append({"stage": number, "error": repr(exc)})
            break

    project.save(str(out))
    inst = {
        key: value[1] if isinstance(value, list) and len(value) > 1 else value
        for key, value in hist.InstrumentParameters.items()
    }
    result = {
        "project": str(out),
        "histogram": hist.name,
        "wR": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": inst,
        "background": hist.Background,
        "phases": [],
        "stages": log,
    }
    try:
        mass = hist.ComputeMassFracs()
    except Exception as exc:
        mass = {"error": repr(exc)}
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append({
            "name": phase.name,
            "composition": phase.composition,
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        })
    result["mass_fractions"] = mass
    out.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float))

    # A compact profile for comparing trial models.
    arr = np.column_stack([
        hist.getdata("X"), hist.getdata("Yobs"), hist.getdata("Ycalc"),
        hist.getdata("Background"), hist.getdata("Residual"),
    ])
    np.savetxt(out.with_suffix(".csv"), arr, delimiter=",",
               header="two_theta_deg,y_obs,y_calc,background,y_obs_minus_y_calc",
               comments="")


if __name__ == "__main__":
    main()
