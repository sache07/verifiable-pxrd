#!/usr/bin/env python3
"""Continue a selected project with a stricter least-squares stop criterion."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("base")
parser.add_argument("output")
parser.add_argument("--fix-md", action="store_true")
args = parser.parse_args()

out = Path(args.output).resolve()
if out.exists():
    out.unlink()
project = G2sc.G2Project(str(Path(args.base).resolve()), newgpx=str(out))
hist = project.histogram(0)
project.set_Controls("cycles", 30)
project.data["Controls"]["data"]["min dM/M"] = 1e-7
if args.fix_md:
    project.phase("Sr3WO6").data["Histograms"][hist.name]["Pref.Ori."][2] = False

project.do_refinements([{}])
project.save(str(out))
result = {
    "Rwp": hist.get_wR(),
    "residuals": hist.residuals,
    "mass_fractions": hist.ComputeMassFracs(),
    "preferred_orientation": project.phase("Sr3WO6").data["Histograms"][hist.name]["Pref.Ori."],
    "cells": {phase.name: phase.get_cell_and_esd() for phase in project.phases()},
    "covariance": project.data["Covariance"]["data"]["Rvals"],
}
out.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
print(json.dumps(result, indent=2, default=float))
