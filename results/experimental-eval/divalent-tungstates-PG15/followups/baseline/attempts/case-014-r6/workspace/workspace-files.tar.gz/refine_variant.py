#!/usr/bin/env python3
"""Test selected physically motivated refinements on the three-phase model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("base")
parser.add_argument("output")
parser.add_argument("mode")
args = parser.parse_args()

out = Path(args.output).resolve()
if out.exists():
    out.unlink()
project = G2sc.G2Project(str(Path(args.base).resolve()), newgpx=str(out))
hist = project.histogram(0)
project.set_Controls("cycles", 15)

mode = args.mode
if mode == "rough":
    hist.SampleParameters["SurfRoughA"] = [0.8, True]
    hist.SampleParameters["SurfRoughB"] = [0.1, True]
elif mode.startswith("po_sw_"):
    axes = {
        "po_sw_001": [0, 0, 1],
        "po_sw_100": [1, 0, 0],
        "po_sw_110": [1, 1, 0],
        "po_sw_112": [1, 1, 2],
        "po_sw_204": [2, 0, 4],
    }
    po = project.phase("SrWO4").data["Histograms"][hist.name]["Pref.Ori."]
    po[1], po[2], po[3] = 1.0, True, axes[mode]
elif mode.startswith("po_sr3_"):
    axes = {
        "po_sr3_100": [1, 0, 0],
        "po_sr3_010": [0, 1, 0],
        "po_sr3_001": [0, 0, 1],
        "po_sr3_110": [1, 1, 0],
        "po_sr3_101": [1, 0, 1],
        "po_sr3_011": [0, 1, 1],
        "po_sr3_112": [1, 1, 2],
        "po_sr3_100_lo": [1, 0, 0],
        "po_sr3_001_lo": [0, 0, 1],
        "po_sr3_112_lo": [1, 1, 2],
    }
    po = project.phase("Sr3WO6").data["Histograms"][hist.name]["Pref.Ori."]
    po[1], po[2], po[3] = (0.5 if mode.endswith("_lo") else 1.0), True, axes[mode]
elif mode == "sw_o_xyz":
    project.phase("SrWO4").atom("O").refinement_flags = "X"
elif mode == "sr3_sra_xyz":
    project.phase("Sr3WO6").atom("SrA").refinement_flags = "X"
elif mode == "sr3_o_xyz":
    for label in ("O1", "O2", "O3"):
        project.phase("Sr3WO6").atom(label).refinement_flags = "X"
elif mode == "wo3_w_xyz":
    for label in ("W1", "W2"):
        project.phase("WO3").atom(label).refinement_flags = "X"
elif mode == "all_heavy_xyz":
    project.phase("Sr3WO6").atom("SrA").refinement_flags = "X"
    for label in ("W1", "W2"):
        project.phase("WO3").atom(label).refinement_flags = "X"
elif mode == "freeze_v":
    hist.InstrumentParameters["V"][2] = False
elif mode == "freeze_u":
    hist.InstrumentParameters["U"][2] = False
elif mode == "freeze_v_md":
    hist.InstrumentParameters["V"][2] = False
    project.phase("Sr3WO6").data["Histograms"][hist.name]["Pref.Ori."][2] = False
elif mode == "freeze_u_md":
    hist.InstrumentParameters["U"][2] = False
    project.phase("Sr3WO6").data["Histograms"][hist.name]["Pref.Ori."][2] = False
elif mode == "settle":
    pass
else:
    raise ValueError(f"unknown mode: {mode}")

stages = []
for i in range(2):
    try:
        project.do_refinements([{}])
        stages.append({"iteration": i + 1, "wR": hist.get_wR()})
    except Exception as exc:
        stages.append({"iteration": i + 1, "error": repr(exc)})
        break
project.save(str(out))

result = {
    "mode": mode,
    "wR": hist.get_wR(),
    "residuals": hist.residuals,
    "mass_fractions": hist.ComputeMassFracs(),
    "sample": hist.SampleParameters,
    "stages": stages,
    "phases": [],
}
for phase in project.phases():
    result["phases"].append({
        "name": phase.name,
        "cell": phase.get_cell(),
        "scale": phase.data["Histograms"][hist.name]["Scale"],
        "preferred_orientation": phase.data["Histograms"][hist.name]["Pref.Ori."],
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": atom.coordinates,
                "refinement_flags": atom.refinement_flags,
                "uiso": atom.uiso,
            }
            for atom in phase.atoms()
        ],
    })
out.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float))
