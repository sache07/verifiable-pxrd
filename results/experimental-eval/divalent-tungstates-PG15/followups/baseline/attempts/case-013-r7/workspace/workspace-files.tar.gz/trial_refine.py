#!/usr/bin/env python3
"""Build trial GSAS-II Rietveld models for phase-selection tests."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

CANDIDATES = {
    "scheelite": ("9009811", "PbWO4_scheelite"),
    "raspite": ("9007617", "PbWO4_raspite"),
    "massicot": ("2310433", "PbO_massicot"),
    "litharge": ("9012700", "PbO_litharge"),
    "wo3": ("1528915", "WO3_monoclinic"),
    "wo3_alt": ("1010618", "WO3_monoclinic_alt"),
    "wo3_m14b": ("2311041", "WO3_monoclinic_b"),
    "wo3_tri": ("2106293", "WO3_triclinic"),
    "wo3_pnma": ("2107312", "WO3_orthorhombic"),
    "wo3_m14s": ("1563541", "WO3_monoclinic_small"),
    "wo2_m": ("1548686", "WO2_monoclinic"),
    "wo2_t": ("5910153", "WO2_tetragonal"),
    "pbo2_t": ("9007543", "PbO2_tetragonal"),
    "pb3o4": ("1537983", "Pb3O4_tetragonal"),
    "w3o8": ("2101050", "W3O8_orthorhombic"),
}


def cif_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def set_cycles(project: G2sc.G2Project, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)


def summarize(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "scale": hap["Scale"][0],
            "cell": phase.get_cell(),
        }
    try:
        mass_fracs = hist.ComputeMassFracs()
    except Exception as exc:
        mass_fracs = {"error": repr(exc)}
    return {
        "residuals": hist.residuals,
        "mass_fractions": mass_fracs,
        "instrument": {
            key: value[:2]
            for key, value in hist.InstrumentParameters.items()
            if key in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "SH/L"}
        },
        "background": hist.Background[0],
        "phases": phases,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phases", nargs="+", required=True, choices=CANDIDATES)
    parser.add_argument("--output", required=True)
    parser.add_argument("--background", type=int, default=18)
    args = parser.parse_args()

    out = Path(args.output).resolve()
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    # The histogram scale and all HAP scales are exactly correlated. Keep the
    # histogram scale fixed and refine one scale per crystalline phase.
    hist.SampleParameters["Scale"][0] = 1.0
    hist.SampleParameters["Scale"][1] = False
    hist.set_refinements({
        "Limits": [10.02, 99.98],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": args.background,
        },
    })

    phases = []
    for key in args.phases:
        cod_id, name = CANDIDATES[key]
        phase = project.add_phase(
            str(cif_path(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phases.append(phase)

    set_cycles(project, 8)
    project.save()

    # Establish background and phase scales, then position, cells, and profile.
    project.do_refinements([{}])
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.do_refinements([{}])
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
    project.do_refinements([{}])
    # Very weak rejected candidates can make an unconstrained cell singular.
    # Refine cells only where the scale is appreciably nonzero.
    for phase in phases:
        if phase.data["Histograms"][hist.name]["Scale"][0] > 0.05:
            phase.set_refinements({"Cell": True})
    project.do_refinements([{}])
    project.do_refinements([{}])
    project.save()

    summary = summarize(project)
    Path(str(out) + ".json").write_text(json.dumps(summary, indent=2, default=float) + "\n")
    data = hist.data["data"][1]
    np.savetxt(
        str(out) + ".fit.csv",
        np.column_stack((data[0], data[1], data[3], data[5], data[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )


if __name__ == "__main__":
    G2sc.SetPrintLevel("warn")
    main()
