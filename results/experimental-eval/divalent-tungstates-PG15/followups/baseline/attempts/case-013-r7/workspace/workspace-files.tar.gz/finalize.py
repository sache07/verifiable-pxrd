#!/usr/bin/env python3
"""Create the submitted GSAS-II project and artifacts from the final model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

PHASE_SPECS = [
    {
        "name": "PbWO4_scheelite",
        "formula": "PbWO4",
        "cod_id": "9009811",
        "cif": "PbWO4_scheelite.cif",
    },
    {
        "name": "PbO_massicot",
        "formula": "PbO",
        "cod_id": "2310433",
        "cif": "PbO_massicot.cif",
    },
    {
        "name": "WO3_monoclinic",
        "formula": "WO3",
        "cod_id": "2311041",
        "cif": "WO3_monoclinic.cif",
    },
]


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def refine(project: G2sc.G2Project) -> None:
    """Run one refinement and save its updated covariance/project state."""
    project.do_refinements([{}])
    project.save()


def main() -> None:
    project = G2sc.G2Project(newgpx=str(WORK / "final.gpx"))
    hist = project.add_powder_histogram(
        str(WORK / "inputs" / "pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )

    # Avoid exact correlation between the overall histogram scale and HAP scales.
    hist.SampleParameters["Scale"][0] = 1.0
    hist.SampleParameters["Scale"][1] = False
    hist.set_refinements(
        {
            "Limits": [10.02, 99.98],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 24,
            },
        }
    )

    phases = []
    for spec in PHASE_SPECS:
        phase = project.add_phase(
            str(cod_cif(spec["cod_id"])),
            phasename=spec["name"],
            histograms=[hist],
            fmthint="CIF",
        )
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phases.append(phase)

    project.set_Controls("cycles", 12)
    project.save()

    # Staged refinement: intensities/background, position, Gaussian profile,
    # Lorentzian profile and cells. SH/L remains fixed because allowing it to
    # vary is strongly correlated with zero shift for this uncalibrated scan.
    refine(project)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project)
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    refine(project)
    hist.set_refinements({"Instrument Parameters": ["X", "Y"]})
    refine(project)
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project)

    # Repeat to settle the coupled profile/cell/background parameters.
    for _ in range(6):
        refine(project)
        if project.data["Covariance"]["data"]["Rvals"].get("Max shft/sig", 999.0) < 0.1:
            break

    mass_fractions = hist.ComputeMassFracs()
    residuals = hist.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]

    phase_results = []
    for phase, spec in zip(phases, PHASE_SPECS):
        cif_out = WORK / spec["cif"]
        phase.export_CIF(str(cif_out))
        cell, cell_esd = phase.get_cell_and_esd()
        fraction, fraction_esd = mass_fractions[phase.name]
        pfx = f"{phase.id}:{hist.id}:"
        phase_results.append(
            {
                "name": phase.name,
                "formula": spec["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "source_structure": f"COD {spec['cod_id']}",
                "cif_path": spec["cif"],
                "weight_fraction": fraction,
                "weight_fraction_percent": 100.0 * fraction,
                "formal_weight_fraction_esd": fraction_esd,
                "formal_weight_fraction_esd_percent": 100.0 * fraction_esd,
                "phase_Rf_percent": residuals.get(pfx + "Rf"),
                "phase_Rf2_percent": residuals.get(pfx + "Rf^2"),
                "unit_cell": cell,
                "unit_cell_esd": cell_esd,
            }
        )

    profile = hist.data["data"][1]
    fit_mask = (profile[0] >= hist.Limits("lower")) & (profile[0] <= hist.Limits("upper"))
    np.savetxt(
        WORK / "fit.csv",
        np.column_stack(
            (
                profile[0][fit_mask],
                profile[1][fit_mask],
                profile[3][fit_mask],
                (profile[1] - profile[3])[fit_mask],
                profile[4][fit_mask],
            )
        ),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt="%.15g",
    )

    result = {
        "phases": phase_results,
        "weight_fraction_normalization": "modeled crystalline phases only; sums to 1",
        "fit_statistics": {
            "Rwp_percent": residuals["wR"],
            "Rp_percent": residuals["R"],
            "Rwp_background_subtracted_percent": residuals["wRb"],
            "Rp_background_subtracted_percent": residuals["Rb"],
            "Rexp_percent": residuals["wRmin"],
            "goodness_of_fit": rvals["GOF"],
            "reduced_chi_squared": rvals["GOF"] ** 2,
            "objective_chi_squared": rvals["chisq"],
            "number_observations": rvals["Nobs"],
            "number_variables": rvals["Nvars"],
            "durbin_watson": hist.data["data"][0].get("Durbin-Watson"),
            "converged": bool(rvals.get("converged", False)),
            "maximum_shift_over_esd": rvals.get("Max shft/sig"),
        },
        "refinement": {
            "project_path": "final.gpx",
            "profile_path": "fit.csv",
            "two_theta_range_deg": [hist.Limits("lower"), hist.Limits("upper")],
            "radiation": "Cu K-alpha 1,2",
            "wavelength_Kalpha1_angstrom": hist.InstrumentParameters["Lam1"][1],
            "wavelength_Kalpha2_angstrom": hist.InstrumentParameters["Lam2"][1],
            "Kalpha2_to_Kalpha1_ratio": hist.InstrumentParameters["I(L2)/I(L1)"][1],
        },
    }
    (WORK / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    project.save()

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    G2sc.SetPrintLevel("warn")
    main()
