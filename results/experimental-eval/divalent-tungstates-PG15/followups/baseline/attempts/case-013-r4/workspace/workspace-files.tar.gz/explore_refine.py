#!/usr/bin/env python3
"""Build exploratory GSAS-II Rietveld projects for the supplied PXRD data."""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)

PHASES = {
    "PbWO4_scheelite": "9009811",
    "PbO_massicot": "2310433",
    "WO3_monoclinic": "1528915",
    "PbWO4_raspite": "9007617",
    "Pb3O4_minium": "1537983",
    "PbO_litharge": "9012700",
    "PbO_litharge_modulated": "1533609",
    "PbO_litharge_corrected": "manual",
    "PbO2_rutile": "9007543",
    "PbO2_cubic": "9005760",
    "PbO2_orthorhombic": "1531016",
    "Pb2O_cubic": "1010382",
    "Pb2O3_monoclinic": "2311012",
    "W2O7_cubic": "1529777",
    "WO2_tetragonal": "5910153",
    "WO2_monoclinic": "1548686",
    "W3O10_orthorhombic": "9014468",
    "Pb_metal": "9012959",
}


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def read_pattern() -> tuple[np.ndarray, np.ndarray]:
    x, y = [], []
    with (ROOT / "inputs" / "pattern.csv").open(newline="") as stream:
        rows = csv.DictReader(stream)
        for row in rows:
            x.append(float(row["two_theta_deg"]))
            y.append(float(row["intensity"]))
    return np.asarray(x), np.asarray(y)


def write_inputs(x: np.ndarray, y: np.ndarray) -> tuple[Path, Path]:
    data_path = ROOT / "pattern.xye"
    with data_path.open("w") as stream:
        stream.write("# Original counts from inputs/pattern.csv; sigma=sqrt(counts)\n")
        for xx, yy in zip(x, y):
            stream.write(f"{xx:.8f} {yy:.8f} {math.sqrt(max(yy, 1.0)):.8f}\n")

    inst_path = ROOT / "instrument.instprm"
    with inst_path.open("w") as stream:
        stream.write("#GSAS-II instrument parameter file for supplied Cu Ka data\n")
        stream.write("Type:PXC;Bank:1\n")
        stream.write(
            "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;"
            "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        )
        # Deliberately broad but physical starting profile.
        stream.write("U:10.0;V:-5.0;W:40.0;X:1.0;Y:1.0;Z:0.0;SH/L:0.002\n")
    return data_path, inst_path


def initial_background(x: np.ndarray, y: np.ndarray, ncoeff: int = 18) -> list[float]:
    # A low percentile filter gives a peak-resistant initial baseline. Convert
    # it to the exact Chebyshev basis used by GSAS-II.
    baseline = percentile_filter(y, percentile=18, size=401, mode="nearest")
    xpos = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    return np.polynomial.chebyshev.chebfit(xpos, baseline, ncoeff - 1).tolist()


def summary(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    out = {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("GOF"),
        "phases": {},
    }
    try:
        out["mass_fractions"] = {
            k: [v[0], v[1]] for k, v in hist.ComputeMassFracs().items()
        }
    except Exception as err:
        out["mass_fraction_error"] = repr(err)
    for phase in project.phases():
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": phase.HAPvalue("Scale", targethistlist=[hist]),
            "mass": phase.data["General"].get("Mass"),
        }
    inst = hist.data["Instrument Parameters"][0]
    out["instrument"] = {
        key: val[1] for key, val in inst.items() if isinstance(val, list) and len(val) > 1
    }
    return out


def run_model(phase_names: list[str], output: Path) -> dict:
    x, y = read_pattern()
    data_path, inst_path = write_inputs(x, y)
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(newgpx=str(output))
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 1.0

    hist = project.add_powder_histogram(
        str(data_path), str(inst_path), fmthint="Topas xye"
    )
    # The histogram/sample scale and all HAP phase scales are exactly
    # redundant. Keep the former fixed so phase-scale covariances are valid.
    hist.data["Sample Parameters"]["Scale"][0] = 1.0
    hist.data["Sample Parameters"]["Scale"][1] = False
    hist.set_refinements(
        {
            "Limits": [10.02, 99.98],
            "Background": {
                "type": "chebyschev-1",
                "refine": False,
                "no. coeffs": 18,
                "coeffs": initial_background(x, y),
            },
        }
    )

    phases = []
    for name in phase_names:
        phase = project.add_phase(
            str(cod_path(PHASES[name])),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.HAPvalue("Scale", 0.05 if phases else 1.0, targethistlist=[hist])
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
        phases.append(phase)

    project.save()
    print(json.dumps(summary(project, "initial"), indent=2))

    steps = [
        ("scale", {"set": {"PhaseFraction": True}}),
        (
            "background",
            {
                "set": {
                    "PhaseFraction": True,
                    "Background": {"refine": True},
                }
            },
        ),
        (
            "cells",
            {
                "set": {
                    "PhaseFraction": True,
                    "Background": {"refine": True},
                    "Cell": True,
                }
            },
        ),
        (
            "zero_WXY",
            {
                "set": {
                    "PhaseFraction": True,
                    "Background": {"refine": True},
                    "Cell": True,
                    "Instrument Parameters": ["Zero", "W", "X", "Y"],
                }
            },
        ),
        (
            "full_profile",
            {
                "set": {
                    "PhaseFraction": True,
                    "Background": {"refine": True},
                    "Cell": True,
                    "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"],
                }
            },
        ),
    ]

    records = []
    for label, recipe in steps:
        try:
            project.do_refinements([recipe], makeBack=False)
            rec = summary(project, label)
            records.append(rec)
            print(json.dumps(rec, indent=2))
        except Exception as err:
            records.append({"label": label, "error": repr(err)})
            print(f"STEP {label} FAILED: {err!r}")
            break
    project.save()
    with output.with_suffix(".summary.json").open("w") as stream:
        json.dump(records, stream, indent=2)
    return records[-1] if records else summary(project, "initial")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--phases",
        nargs="+",
        default=["PbWO4_scheelite", "PbO_massicot", "WO3_monoclinic"],
        choices=sorted(PHASES),
    )
    parser.add_argument("--output", default="explore.gpx")
    args = parser.parse_args()
    run_model(args.phases, ROOT / args.output)


if __name__ == "__main__":
    main()
