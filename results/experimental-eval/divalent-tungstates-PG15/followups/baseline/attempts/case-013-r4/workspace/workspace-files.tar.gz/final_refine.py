#!/usr/bin/env python3
"""Final four-phase GSAS-II refinement and deliverable export."""

from __future__ import annotations

import csv
import json
import math
import os
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def load_pattern() -> tuple[np.ndarray, np.ndarray]:
    x, y = [], []
    with (ROOT / "inputs" / "pattern.csv").open(newline="") as stream:
        for row in csv.DictReader(stream):
            x.append(float(row["two_theta_deg"]))
            y.append(float(row["intensity"]))
    return np.asarray(x), np.asarray(y)


def prepare_import_files(x: np.ndarray, y: np.ndarray) -> tuple[Path, Path]:
    datafile = ROOT / "pattern.xye"
    with datafile.open("w") as stream:
        stream.write("# inputs/pattern.csv; Poisson sigma=sqrt(counts)\n")
        for xx, yy in zip(x, y):
            stream.write(f"{xx:.8f} {yy:.8f} {math.sqrt(max(yy, 1.0)):.8f}\n")

    instfile = ROOT / "instrument.instprm"
    with instfile.open("w") as stream:
        stream.write("#GSAS-II parameters for supplied Cu Kalpha measurement\n")
        stream.write("Type:PXC;Bank:1\n")
        stream.write(
            "Lam1:1.540598;Lam2:1.544426;Zero:0.27;Polariz.:0.7;"
            "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        )
        stream.write("U:10.0;V:-5.0;W:40.0;X:1.0;Y:1.0;Z:0.0;SH/L:0.002\n")
    return datafile, instfile


def background_coefficients(x: np.ndarray, y: np.ndarray, n: int = 18) -> list[float]:
    baseline = percentile_filter(y, percentile=18, size=401, mode="nearest")
    xpos = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    return np.polynomial.chebyshev.chebfit(xpos, baseline, n - 1).tolist()


def clear_flags(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    # clear_refinements returns immediately for a boolean Background entry,
    # so clear background in a separate call.
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                "Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"
            ],
            "Sample Parameters": ["Scale"],
        }
    )
    hist.clear_refinements({"Background": True})
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True},
            histograms=[hist],
        )


def refine(project: G2sc.G2Project, label: str) -> dict:
    project.refine(makeBack=False)
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    record = {
        "step": label,
        "Rwp_percent": float(hist.get_wR()),
        "GOF": float(rvals["GOF"]),
        "max_shift_over_esd": float(rvals.get("Max shft/sig", 0.0)),
        "converged": bool(rvals.get("converged", False)),
    }
    print(json.dumps(record))
    return record


def build_project(x: np.ndarray, y: np.ndarray) -> tuple[G2sc.G2Project, list[dict]]:
    gpx_path = ROOT / "final.gpx"
    if gpx_path.exists():
        gpx_path.unlink()
    datafile, instfile = prepare_import_files(x, y)
    project = G2sc.G2Project(newgpx=str(gpx_path))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["shift factor"] = 1.0
    hist = project.add_powder_histogram(
        str(datafile), str(instfile), fmthint="Topas xye"
    )
    hist.set_refinements(
        {
            "Limits": [10.02, 99.98],
            "Background": {
                "type": "chebyschev-1",
                "refine": False,
                "no. coeffs": 18,
                "coeffs": background_coefficients(x, y),
            },
        }
    )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]

    phase_specs = [
        ("PbWO4_scheelite", "9009811", 1.0),
        ("PbO_massicot", "2310433", 0.25),
        ("WO3_monoclinic", "1528915", 0.20),
    ]
    for name, cod_id, scale in phase_specs:
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.HAPvalue("Scale", scale, targethistlist=[hist])

    # COD 9012700 is P4/nmm origin choice 1. GSAS-II uses choice 2;
    # translate (x,y) by (-1/4,+1/4) so that multiplicities and PbO
    # stoichiometry are preserved in the GSAS-II symmetry setting.
    litharge = project.add_phase(
        None,
        phasename="PbO_litharge",
        histograms=[hist],
        spacegroup="P 4/n m m",
        cell=[3.9744, 3.9744, 5.0220, 90.0, 90.0, 90.0],
    )
    litharge.add_atom(-0.25, -0.25, 0.23510, "Pb", "Pb", uiso=0.01520)
    litharge.add_atom(-0.25, 0.25, 0.0, "O", "O", uiso=0.01013)
    litharge.HAPvalue("Scale", 0.15, targethistlist=[hist])

    clear_flags(project)
    project.save()
    history: list[dict] = []

    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
    history.append(refine(project, "phase scales"))

    hist.set_refinements({"Background": {"refine": True}})
    history.append(refine(project, "background and scales"))

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    history.append(refine(project, "unit cells"))

    hist.set_refinements({"Instrument Parameters": ["Zero", "W", "X", "Y"]})
    history.append(refine(project, "zero and basic profile"))

    hist.set_refinements({"Instrument Parameters": ["U", "V", "SH/L"]})
    history.append(refine(project, "full effective profile"))

    # Repeat the unchanged final model to reduce remaining shifts after the
    # staged parameter release. No atom coordinates or ADPs are varied.
    for i in range(6):
        history.append(refine(project, f"final convergence {i + 1}"))
        if history[-1]["max_shift_over_esd"] < 0.2:
            break

    project.save()
    return project, history


def export_deliverables(project: G2sc.G2Project, history: list[dict]) -> None:
    hist = project.histogram(0)
    phase_meta = {
        "PbWO4_scheelite": {
            "display": "PbWO4 (scheelite/stolzite)",
            "formula": "PbWO4",
            "cif": "phase_1_PbWO4_scheelite.cif",
            "source": "COD 9009811",
        },
        "PbO_massicot": {
            "display": "PbO (massicot)",
            "formula": "PbO",
            "cif": "phase_2_PbO_massicot.cif",
            "source": "COD 2310433",
        },
        "WO3_monoclinic": {
            "display": "WO3 (monoclinic)",
            "formula": "WO3",
            "cif": "phase_3_WO3_monoclinic.cif",
            "source": "COD 1528915",
        },
        "PbO_litharge": {
            "display": "PbO (litharge)",
            "formula": "PbO",
            "cif": "phase_4_PbO_litharge.cif",
            "source": "COD 9012700, transformed from P4/nmm origin 1 to origin 2",
        },
    }

    mass_fracs = hist.ComputeMassFracs()
    phases_out = []
    for phase in project.phases():
        meta = phase_meta[phase.name]
        cif_path = ROOT / meta["cif"]
        phase.export_CIF(str(cif_path))
        cell, cell_su = phase.get_cell_and_esd()
        fraction, fraction_su = mass_fracs[phase.name]
        h_id = hist.id
        p_id = phase.id
        residuals = hist.data["data"][0]
        phases_out.append(
            {
                "name": meta["display"],
                "formula": meta["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": meta["cif"],
                "weight_fraction": float(fraction),
                "weight_fraction_su_statistical": float(fraction_su),
                "weight_percent": float(100.0 * fraction),
                "reference_structure": meta["source"],
                "cell": {key: float(value) for key, value in cell.items()},
                "cell_su_statistical": {
                    key: float(value) for key, value in cell_su.items()
                },
                "Rf_percent": float(residuals.get(f"{p_id}:{h_id}:Rf", float("nan"))),
            }
        )

    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    difference = yobs - ycalc
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_observed_minus_calculated",
                "background",
            ]
        )
        writer.writerows(zip(x, yobs, ycalc, difference, background))

    rvals = project.data["Covariance"]["data"]["Rvals"]
    hres = hist.data["data"][0]
    inst = hist.data["Instrument Parameters"][0]
    result = {
        "phases": phases_out,
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": float(hres["wR"]),
            "Rp_percent": float(hres["R"]),
            "Rexp_percent": float(hres["wRmin"]),
            "GOF": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "number_of_observations": int(rvals["Nobs"]),
            "number_of_variables": int(rvals["Nvars"]),
            "Durbin_Watson": float(hres["Durbin-Watson"]),
            "refined_two_theta_range_deg": [10.02, 99.98],
        },
        "radiation_model": {
            "wavelength_Kalpha1_angstrom": float(inst["Lam1"][1]),
            "wavelength_Kalpha2_angstrom": float(inst["Lam2"][1]),
            "Kalpha2_to_Kalpha1_ratio": float(inst["I(L2)/I(L1)"][1]),
            "refined_zero_offset_deg": float(inst["Zero"][1]),
        },
        "files": {
            "profile": "fit.csv",
            "GSASII_project": "final.gpx",
            "report": "report.md",
        },
        "refinement_history": history,
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")

    phase_rows = "\n".join(
        f"| {p['name']} | {p['space_group']} | {p['weight_percent']:.2f} | "
        f"{100*p['weight_fraction_su_statistical']:.2f} | `{p['cif_path']}` |"
        for p in phases_out
    )
    report = f"""# PXRD phase analysis

The crystalline pattern is best described by four phases in the PbO-WO3 system. Fractions below are normalized over those modeled crystalline phases; this experiment does not determine an amorphous fraction.

| Phase | Space group | wt% | statistical s.u. (wt%) | CIF |
|---|---:|---:|---:|---|
{phase_rows}

The final Cu Kalpha1/Kalpha2 Rietveld fit over 10.02-99.98 degrees has Rwp = {hres['wR']:.2f}%, Rp = {hres['R']:.2f}%, and GOF = {rvals['GOF']:.2f}. The refined common zero offset is {inst['Zero'][1]:.3f} degrees 2-theta. Only unit cells, phase scales, background, zero, and an effective common peak profile were refined; atomic coordinates and displacement parameters were held to the reference structures because the laboratory powder data do not support reliable unconstrained coordinate refinement.

## Evidence

Scheelite PbWO4 is fixed by its strong series at approximately 27.70, 29.91, 33.05, 45.02, 47.28, 51.48, 55.54, and 56.82 degrees. Monoclinic WO3 accounts for the characteristic low-angle triplet near 23.38, 23.89, and 24.64 degrees and lines near 33.52, 34.44, and 41.92 degrees. Orthorhombic massicot PbO is supported by lines near 29.35, 30.62, 38.12, 49.49, 53.39, 60.54, and 63.28 degrees. Tetragonal litharge PbO is supported independently by lines/shoulders near 17.97, 28.9, 32.10, 36.00, 45.92, and 48.86 degrees. The litharge coordinates were transformed from the published P4/nmm origin-1 setting into GSAS-II's origin-2 setting before refinement.

## Remaining uncertainty

Several positive residual peaks—notably near 25.92, 30.16, and 31.04 degrees—track expected Cu Kbeta positions from the fitted phases. For example, the WO3 Kalpha reflections near 33.51 and 34.43 degrees map to Kbeta near 30.24 and 31.06 degrees. Kbeta was not included because the supplied measurement model specifies only Cu Kalpha1/Kalpha2; these residuals were therefore not converted into chemically implausible extra phases. Peak overlap, the uncalibrated instrumental profile, and correlation of zero/sample displacement with lattice constants make the quoted covariance s.u. values optimistic. A practical systematic uncertainty is about 2-4 wt% for the dominant phase and 1-2 wt% for each minor phase. Structures or fractions below roughly 1-2 wt% cannot be established reliably from this pattern.
"""
    (ROOT / "report.md").write_text(report)
    project.save()


def main() -> None:
    x, y = load_pattern()
    project, history = build_project(x, y)
    export_deliverables(project, history)


if __name__ == "__main__":
    main()
