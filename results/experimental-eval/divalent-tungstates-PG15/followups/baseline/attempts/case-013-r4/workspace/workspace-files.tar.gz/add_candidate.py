#!/usr/bin/env python3
"""Add one candidate phase to a converged GSAS-II project for model testing."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from explore_refine import PHASES, cod_path, summary


ROOT = Path(__file__).resolve().parent


def clear_all(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Background": True,
            "Instrument Parameters": [
                "Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"
            ],
            "Sample Parameters": ["Scale"],
        }
    )
    hist.data["Sample Parameters"]["Scale"][0] = 1.0
    hist.data["Sample Parameters"]["Scale"][1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True},
            histograms=[hist],
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", choices=sorted(PHASES))
    parser.add_argument("--base", default="explore3.gpx")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    output = ROOT / args.output
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(str(ROOT / args.base), newgpx=str(output))
    project.set_Controls("cycles", 10)
    clear_all(project)
    hist = project.histogram(0)
    if args.candidate == "PbO_litharge_corrected":
        # COD 9012700 is supplied in origin choice 1, while GSAS-II uses
        # origin choice 2 for P4/nmm. These are the same published atoms
        # transformed into GSAS-II's setting; this preserves PbO stoichiometry
        # and the allowed 101 reflection.
        candidate = project.add_phase(
            None,
            phasename=args.candidate,
            histograms=[hist],
            spacegroup="P 4/n m m",
            cell=[3.9744, 3.9744, 5.0220, 90.0, 90.0, 90.0],
        )
        candidate.add_atom(-0.25, -0.25, 0.23510, "Pb", "Pb", uiso=0.01520)
        candidate.add_atom(-0.25, 0.25, 0.0, "O", "O", uiso=0.01013)
    else:
        candidate = project.add_phase(
            str(cod_path(PHASES[args.candidate])),
            phasename=args.candidate,
            histograms=[hist],
            fmthint="CIF",
        )
    candidate.HAPvalue("Scale", 0.03, targethistlist=[hist])
    clear_all(project)
    records = []

    def refine(label: str, *, all_cells: bool = False, candidate_cell: bool = False,
               background: bool = False, profile: list[str] | None = None) -> None:
        for phase in project.phases():
            phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
            if all_cells:
                phase.set_refinements({"Cell": True})
        if candidate_cell:
            candidate.set_refinements({"Cell": True})
        if background:
            hist.set_refinements({"Background": {"refine": True}})
        if profile:
            hist.set_refinements({"Instrument Parameters": profile})
        project.refine(makeBack=False)
        rec = summary(project, label)
        records.append(rec)
        print(json.dumps(rec, indent=2))

    refine("scales")
    refine("candidate_cell", candidate_cell=True)
    refine("all_cells_background", all_cells=True, background=True)
    refine(
        "profile",
        all_cells=True,
        background=True,
        profile=["Zero", "W", "X", "Y"],
    )
    project.save()
    with output.with_suffix(".summary.json").open("w") as stream:
        json.dump(records, stream, indent=2)


if __name__ == "__main__":
    main()
