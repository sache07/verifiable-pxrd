#!/usr/bin/env python3
"""Export all requested deliverables from the selected final GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE = Path(".tmp/conservative_corrected_C.gpx")
FINAL_GPX = Path("final.gpx")

PHASE_INFO = {
    "PbWO4_scheelite": {
        "display_name": "PbWO4 (scheelite)",
        "formula": "PbWO4",
        "cif": "phase_1_PbWO4_scheelite.cif",
        "source_cod_id": "9009811",
        "source_model": "COD 9009811",
        "confidence": "high",
    },
    "WO3_monoclinic_alt": {
        "display_name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif": "phase_2_WO3_monoclinic.cif",
        "source_cod_id": "1528915",
        "source_model": "COD 1528915",
        "confidence": "high",
    },
    "PbO_litharge": {
        "display_name": "PbO (litharge)",
        "formula": "PbO",
        "cif": "phase_3_PbO_litharge.cif",
        "source_cod_id": "9012700",
        "source_model": (
            "COD 9012700, transformed from origin choice 1 to the standard "
            "P4/nmm setting"
        ),
        "confidence": "moderate",
    },
    "PbO_massicot": {
        "display_name": "PbO (massicot)",
        "formula": "PbO",
        "cif": "phase_4_PbO_massicot.cif",
        "source_cod_id": "2310433",
        "source_model": "COD 2310433",
        "confidence": "moderate",
    },
}


def fmt_cell(cell: dict) -> str:
    return (
        f"a={cell['length_a']:.5f}, b={cell['length_b']:.5f}, "
        f"c={cell['length_c']:.5f} A; "
        f"alpha={cell['angle_alpha']:.3f}, "
        f"beta={cell['angle_beta']:.3f}, "
        f"gamma={cell['angle_gamma']:.3f} deg"
    )


def main() -> None:
    G2sc.SetPrintLevel("warn")
    if FINAL_GPX.exists():
        FINAL_GPX.unlink()
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL_GPX))
    project.save()
    hist = project.histogram(0)
    phases = project.phases()

    fractions = hist.ComputeMassFracs()
    phase_records = []
    for phase in phases:
        info = PHASE_INFO[phase.name]
        phase.export_CIF(info["cif"])
        fraction, formal_esd = fractions[phase.name]
        cell = phase.get_cell()
        phase_records.append({
            "name": info["display_name"],
            "formula": info["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": info["cif"],
            "weight_fraction": float(fraction),
            "weight_percent": float(100.0 * fraction),
            "formal_weight_fraction_esd": float(formal_esd),
            "identification_confidence": info["confidence"],
            "source_model": info["source_model"],
            "refined_cell": {key: float(value) for key, value in cell.items()},
        })

    powder = hist.data["data"][1]
    x = np.asarray(powder[0], dtype=float)
    observed = np.asarray(powder[1], dtype=float)
    calculated = np.asarray(powder[3], dtype=float)
    background = np.asarray(powder[4], dtype=float)
    difference = observed - calculated
    with Path("fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg", "observed_intensity", "calculated_intensity",
            "difference_intensity", "background_intensity"
        ])
        writer.writerows(zip(x, observed, calculated, difference, background))

    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    hstats = hist.data["data"][0]
    limits = hist.data["Limits"][1]
    fit_statistics = {
        "Rwp_percent": float(rvals["Rwp"]),
        "Rp_percent": float(hstats["R"]),
        "Rexp_percent": float(hstats["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "durbin_watson": float(hstats["Durbin-Watson"]),
        "number_of_observations": int(rvals["Nobs"]),
        "number_of_varied_parameters": int(rvals["Nvars"]),
        "fit_range_two_theta_deg": [float(limits[0]), float(limits[1])],
        "weighting": "Poisson approximation w=1/I because pointwise uncertainties were not supplied",
        "radiation": "Cu Kalpha1+2",
        "wavelengths_angstrom": [1.540598, 1.544426],
    }

    result = {
        "phases": phase_records,
        "weight_fraction_basis": (
            "Normalized over the four modeled crystalline phases; any "
            "unidentified crystalline or amorphous component is excluded."
        ),
        "weight_fraction_sum": float(sum(p["weight_fraction"] for p in phase_records)),
        "fit_statistics": fit_statistics,
        "final_gsasii_project": str(FINAL_GPX),
        "fit_profile": "fit.csv",
        "unmodeled_component": {
            "present": True,
            "weight_fraction": None,
            "reason": (
                "Structured residual reflections, especially near 25.91 deg "
                "2theta and in the 30-31 deg region, remain. Tested Pb-W-O "
                "and oxide models did not provide a stable full-pattern match, "
                "so neither a structure nor a fraction is reported."
            ),
        },
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")

    table_rows = []
    for rec in phase_records:
        table_rows.append(
            f"| {rec['name']} | {rec['space_group']} | "
            f"{rec['weight_percent']:.1f} | {fmt_cell(rec['refined_cell'])} |"
        )
    report = f"""# PXRD phase analysis

## Result

The modeled crystalline material contains four phases. Fractions are normalized over these phases only.

| Phase | Space group | wt% | Refined cell |
|---|---:|---:|---|
{chr(10).join(table_rows)}

The final whole-pattern fit gives Rwp = {fit_statistics['Rwp_percent']:.2f}%, Rp = {fit_statistics['Rp_percent']:.2f}%, Rexp = {fit_statistics['Rexp_percent']:.2f}%, and goodness-of-fit = {fit_statistics['goodness_of_fit']:.2f} over {limits[0]:.2f}-{limits[1]:.2f} deg 2theta. Atomic coordinates and displacement parameters were retained from the cited COD starting models; unit cells, phase scales, background, zero offset, and a common peak profile were refined in stages. The physical common profile was then held fixed for the final scale covariance cycle because independent phase broadening made the weak PbO fractions strongly size-correlated. The litharge coordinates from COD 9012700 were transformed from its origin-choice-1 description into the standard P4/nmm setting; the exported model was checked to contain two Pb and two O atoms per cell.

## Evidence

Scheelite PbWO4 accounts for the dominant series at about 27.69, 29.91, 33.05, 45.02, 47.28, 51.48, 55.54, and 56.81 deg. Monoclinic WO3 is supported by the diagnostic 23.38/23.88/24.64 deg triplet and its higher-angle lines. Orthorhombic massicot and tetragonal litharge explain separate PbO line families, including features around 30.61/38.11/49.50 deg and 28.91/32.10/45.91/48.85 deg, respectively. This phase assemblage is chemically consistent with reaction of PbO and WO3 at the reported 500 C with incomplete conversion and both PbO polymorphs.

Alternative raspite PbWO4, Pb7W8O28.8, Pb3O4, PbO2, Pb2O3, WO2, and W3O8 models were tested; they either refined to negligible scale or failed to improve the full pattern consistently.

## Remaining uncertainty

The fit has structured residual intensity, most notably a sharp unassigned feature near 25.91 deg and additional intensity near 30-31 deg. Residual indexing suggests another line lattice may be present, but no available structural model matched enough reflections to identify or quantify it reliably. Its structure and fraction are therefore reported as undetermined rather than folded into a speculative phase.

The tabulated covariance errors in `result.json` are formal only. Missing pointwise uncertainties, lack of a calibrated instrumental profile, possible preferred orientation/microabsorption in this Pb/W-rich specimen, overlap, and the unidentified component dominate the true uncertainty. A phase-specific size model shifted litharge from about 5.4 to 8.3 wt% and encountered a broadening bound, so practical fraction uncertainties are several absolute wt% and larger than the formal errors. No amorphous fraction can be measured from this dataset without an internal standard.
"""
    Path("report.md").write_text(report)

    # Save once more after export so the submitted project is unambiguously
    # the project from which every reported value was read.
    project.save()


if __name__ == "__main__":
    main()
