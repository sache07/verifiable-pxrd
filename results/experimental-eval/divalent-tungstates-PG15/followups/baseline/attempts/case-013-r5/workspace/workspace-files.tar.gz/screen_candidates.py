#!/usr/bin/env python3
"""Conservative candidate screening with fixed minor-phase cells and sizes."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_candidates import CANDIDATES, cod_path


def run(keys: list[str], output: Path) -> dict:
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    hist.set_refinements({"Limits": [10.10, 99.85]})
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    phases = []
    for key in keys:
        cod_id, name = CANDIDATES[key]
        ph = project.add_phase(
            str(cod_path(cod_id)), phasename=name,
            histograms=[hist], fmthint="CIF"
        )
        ph.HAPvalue("Scale", 6.0 if not phases else 0.4)
        # A large fixed value makes size broadening negligible. This screen
        # therefore cannot gain fit quality by smearing a wrong phase into
        # the background.
        ph.data["Histograms"][hist.name]["Size"][1][0] = 10.0
        ph.data["Histograms"][hist.name]["Size"][2][0] = False
        phases.append(ph)

    project.set_Controls("cycles", 10)
    project.save()
    project.do_refinements([
        {"set": {"Background": {
            "type": "chebyschev-1", "refine": True, "no. coeffs": 16
        }}},
        {"set": {"PhaseFraction": True}},
        {"set": {"Instrument Parameters": ["Zero"]}},
    ])
    # Refine only the well-established dominant phase lattice during
    # screening. Minor phase cells remain literature values.
    project.do_refinements([{"set": {"Cell": True}}], phase=phases[0])
    project.do_refinements([
        {"set": {"Instrument Parameters": ["U", "V", "W"]}},
        {},
    ])

    out = {
        "keys": keys,
        "wR_percent": hist.get_wR(),
        "mass_fractions": {
            name: [float(v[0]), float(v[1])]
            for name, v in hist.ComputeMassFracs().items()
        } if len(phases) > 1 else {},
        "scales": {ph.name: ph.HAPvalue("Scale") for ph in phases},
        "cells": {ph.name: ph.get_cell() for ph in phases},
        "instrument": {
            key: hist.data["Instrument Parameters"][0][key][1]
            for key in ("Zero", "U", "V", "W")
        },
        "project": str(output),
    }
    project.save()
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("keys", nargs="+", choices=sorted(CANDIDATES))
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    print("RESULT_JSON " + json.dumps(run(args.keys, args.output), sort_keys=True))


if __name__ == "__main__":
    main()
