#!/usr/bin/env python3
"""Run comparable GSAS-II refinements for candidate phase combinations."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)

CANDIDATES = {
    "scheelite": ("9009811", "PbWO4_scheelite"),
    "raspite": ("9007617", "PbWO4_raspite"),
    "wo3_mono": ("1010618", "WO3_monoclinic"),
    "wo3_mono_alt": ("1528915", "WO3_monoclinic_alt"),
    "pbo_litharge": ("9012700", "PbO_litharge"),
    "pbo_massicot": ("2310433", "PbO_massicot"),
    "pb3o4": ("1537983", "Pb3O4_minium"),
    "pb3o4_orth": ("9003043", "Pb3O4_orthorhombic"),
    "pb2o3": ("2311012", "Pb2O3_monoclinic"),
    "pbo2": ("9007543", "PbO2_rutile"),
    "wo2_mono": ("1548686", "WO2_monoclinic"),
    "wo2_tetra": ("5910153", "WO2_tetragonal"),
    "w3o8": ("2101050", "W3O8_orthorhombic"),
    "w18o49": ("1538315", "W18O49_monoclinic"),
    "w17o47": ("2107065", "W17O47_monoclinic"),
}


def cod_path(cod_id: str) -> Path:
    # COD 9012700 uses P4/nmm origin choice 1. Its explicit symmetry loop is
    # interpreted inconsistently by GSAS-II, producing Pb2O after import.
    # Use the same published model transformed to the standard setting.
    if cod_id == "9012700":
        return Path("litharge_P4nmm_corrected.cif")
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def build_and_refine(keys: list[str], output: Path) -> dict:
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(newgpx=str(output))
    histogram = project.add_powder_histogram(
        "inputs/pattern.csv",
        "instrument.instprm",
        fmthint="comma",
    )
    histogram.set_refinements({"Limits": [10.10, 99.85]})
    # The CSV importer enables the histogram scale by default. Keep that
    # fixed so it is not exactly correlated with every HAP phase scale.
    histogram.data["Sample Parameters"]["Scale"] = [1.0, False]

    phases = []
    for key in keys:
        cod_id, name = CANDIDATES[key]
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=name,
            histograms=[histogram],
            fmthint="CIF",
        )
        phases.append(phase)

    # Start minor phases below the dominant phase so that initial normal
    # equations are reasonably conditioned.
    for i, phase in enumerate(phases):
        phase.HAPvalue("Scale", 6.0 if i == 0 else 0.5)

    project.set_Controls("cycles", 8)
    project.save()

    steps = [
        {"set": {"Background": {
            "type": "chebyschev-1", "refine": True, "no. coeffs": 16
        }}},
        {"set": {"PhaseFraction": True}},
        {"set": {"Instrument Parameters": ["Zero"]}},
        {"set": {"Cell": True}},
        {"set": {"Instrument Parameters": ["U", "V", "W"]}},
        {"set": {"Size": {
            "type": "isotropic", "value": 1.0, "refine": True
        }}},
    ]

    error = None
    try:
        project.do_refinements(steps)
        # One final cycle with all enabled settings provides a directly
        # comparable endpoint for every candidate combination.
        project.do_refinements([{}])
    except Exception as exc:  # retain failed projects for diagnosis
        error = f"{type(exc).__name__}: {exc}"
        project.save()

    result = {
        "keys": keys,
        "project": str(output),
        "error": error,
        "wR_percent": histogram.get_wR(),
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "scales": {phase.name: phase.HAPvalue("Scale") for phase in phases},
    }
    try:
        result["mass_fractions"] = {
            key: [float(value[0]), float(value[1])]
            for key, value in histogram.ComputeMassFracs().items()
        }
    except Exception as exc:
        result["mass_fraction_error"] = f"{type(exc).__name__}: {exc}"
    project.save()
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("keys", nargs="+", choices=sorted(CANDIDATES))
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    result = build_and_refine(args.keys, args.output)
    print("RESULT_JSON " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
