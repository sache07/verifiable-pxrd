#!/usr/bin/env python3
"""Refine the selected four-phase model in controlled sequential stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phases = project.phases()
    result = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "cells": {p.name: p.get_cell() for p in phases},
        "scales": {p.name: p.HAPvalue("Scale") for p in phases},
        "sizes_micrometre": {
            p.name: p.data["Histograms"][hist.name]["Size"][1][0]
            for p in phases
        },
    }
    try:
        result["mass_fractions"] = {
            name: [float(v[0]), float(v[1])]
            for name, v in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        result["mass_fraction_error"] = f"{type(exc).__name__}: {exc}"
    print("STAGE_JSON " + json.dumps(result, sort_keys=True))
    return result


def refine(source: Path, output: Path, refine_sizes: bool = True) -> list[dict]:
    if output.exists():
        output.unlink()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(source), newgpx=str(output))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    phases = project.phases()
    history = [snapshot(project, "screen_start")]

    # Keep one Caglioti term fixed to reduce the very high U/V/W covariance.
    # The current V value is retained while U and W continue to refine.
    hist.clear_refinements({"Instrument Parameters": ["V"]})
    project.do_refinements([{}])
    history.append(snapshot(project, "profile_reconditioned"))

    # Refine minor-phase cells one at a time from close literature starts.
    # Clear each flag before moving on so a weak phase cannot destabilize the
    # lattice of another weak phase.
    for phase in phases[1:]:
        phase.set_refinements({"Cell": True})
        project.do_refinements([{}])
        history.append(snapshot(project, f"cell_{phase.name}"))
        phase.clear_refinements({"Cell": True})

    # Re-refine the dominant cell after the minor phase positions are settled.
    phases[0].set_refinements({"Cell": True})
    project.do_refinements([{}])
    phases[0].clear_refinements({"Cell": True})
    history.append(snapshot(project, "dominant_cell_final"))

    # Allow physically bounded isotropic coherent-domain broadening. Values
    # are in micrometres in GSAS-II; 0.02 um is a conservative 20 nm floor.
    if refine_sizes:
        starts = {
            "PbWO4_scheelite": 0.5,
            "WO3_monoclinic_alt": 0.5,
            "PbO_litharge": 0.10,
            "PbO_massicot": 0.10,
        }
        for phase in phases:
            var = f"{phase.id}:0:Size;i"
            project.set_Controls("parmMin", 0.02, variable=var)
            project.set_Controls("parmMax", 10.0, variable=var)
            phase.set_HAP_refinements({
                "Size": {
                    "type": "isotropic",
                    "value": starts.get(phase.name, 0.2),
                    "refine": True,
                }
            })
            project.do_refinements([{}])
            history.append(snapshot(project, f"size_{phase.name}"))

    # Refine Lorentzian profile contributions after phase broadening is set.
    inst = hist.data["Instrument Parameters"][0]
    inst["X"][1] = 0.1
    inst["Y"][1] = 0.1
    project.do_refinements([
        {"set": {"Instrument Parameters": ["X", "Y"]}},
        {},
    ])
    history.append(snapshot(project, "xy_profile"))

    # Hold broadening terms at their refined (or common-profile) values and
    # remove any parameters frozen at limits. This yields a clean final
    # covariance/refinement cycle for scales, background and profile terms.
    for phase in phases:
        phase.clear_HAP_refinements({"Size": True})
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.do_refinements([{}, {}, {}])
    history.append(snapshot(project, "final_converged"))

    project.save()
    return history


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=Path(".tmp/screen_swalm.gpx"))
    parser.add_argument("--output", type=Path, default=Path(".tmp/refined4.gpx"))
    parser.add_argument("--fixed-size", action="store_true")
    args = parser.parse_args()
    refine(args.source, args.output, refine_sizes=not args.fixed_size)


if __name__ == "__main__":
    main()
