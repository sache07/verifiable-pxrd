#!/usr/bin/env python3
"""Freeze the selected model and export an internally consistent submission."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "add_four_sro.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "SrWO4_scheelite": {
        "name": "SrWO4 (scheelite)",
        "formula": "SrWO4",
        "cif_path": "phase_1_srwo4_scheelite.cif",
        "assignment_status": "established",
        "structure_source": "COD 1546036",
    },
    "WO3_P21n": {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif_path": "phase_2_wo3_monoclinic.cif",
        "assignment_status": "established",
        "structure_source": "COD 1528915",
    },
    "Sr3WO6_rigid_WO6": {
        "name": "Sr3WO6 (prototype-derived monoclinic model)",
        "formula": "Sr3WO6",
        "cif_path": "phase_3_sr3wo6_prototype.cif",
        "assignment_status": "tentative",
        "structure_source": "Sr3UO6 P21/n topology (COD 2001752), W substituted and WO6 geometry regularized against Ca3WO6 (COD 1563081)",
    },
    "Sr3W2O9": {
        "name": "Sr3W2O9",
        "formula": "Sr3W2O9",
        "cif_path": "phase_4_sr3w2o9.cif",
        "assignment_status": "tentative",
        "structure_source": "COD 2311977",
    },
    "SrO": {
        "name": "SrO",
        "formula": "SrO",
        "cif_path": "phase_5_sro.cif",
        "assignment_status": "probable trace phase",
        "structure_source": "COD 7200689",
    },
}


def neutralize_unused_terms(project: G2sc.G2Project) -> None:
    """Make the selected nuisance model explicit before final replay."""
    hist = project.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Absorption"):
        hist.SampleParameters[key] = [0.0, False]

    inst = hist.InstrumentParameters
    inst["Polariz."][1:] = [0.7, False]
    inst["U"][1:] = [0.0, False]
    inst["V"][1:] = [0.0, False]
    inst["Y"][1:] = [0.0, False]
    inst["Z"][1:] = [0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True
    inst["Zero"][2] = True
    inst["SH/L"][2] = True

    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 24)
    # The GSAS-II default (1e-3) stopped this model after one cycle while a
    # weak scale/cell direction was still moving. Use a stricter convergence
    # threshold so a replay reaches a stationary solution in one invocation.
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6

    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        # Cell metrics were already refined phase-by-phase in the clean source
        # project. Lock those accepted values for the final common-profile
        # replay; simultaneous weak-phase cell refinement was not replay-stable.
        phase.set_refinements({"Cell": False})
        phase.set_HAP_refinements({"Scale": True})
        hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
        hap["Size"][0] = "isotropic"
        # 10 micrometres is the GSAS-II neutral/maximal crystallite-size value.
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]

        hap["Pref.Ori."][0] = "MD"
        if index == 1:
            hap["Pref.Ori."][1] = float(hap["Pref.Ori."][1])
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [1, 1, 0]
        else:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False

        if index == 0:
            # Retain the accepted, strongly supported extinction correction,
            # but lock it to remove its 88% correlation with scheelite scale.
            hap["Extinction"][1] = False
        else:
            hap["Extinction"] = [0.0, False]


def converge(project: G2sc.G2Project, max_replays: int = 4) -> None:
    """Replay until parameter shifts are comfortably below their esds."""
    for _ in range(max_replays):
        project.refine(makeBack=False)
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        if (
            rvals.get("converged", False)
            and abs(float(rvals.get("Max shft/sig", math.inf))) < 0.25
            and abs(float(rvals.get("DelChi2", math.inf))) < 1.0e-6
        ):
            break


def export_outputs(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    phases = project.phases()
    observed_order = [phase.name for phase in phases]
    if observed_order != list(PHASE_INFO):
        raise RuntimeError(f"Unexpected phase order: {observed_order}")

    masses = [float(p.HAPvalue("Scale")) * float(p.data["General"]["Mass"]) for p in phases]
    total_mass = sum(masses)
    phase_records = []
    for phase, mass in zip(phases, masses):
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif_path"]))
        fraction = mass / total_mass
        cell = phase.get_cell()
        phase_records.append(
            {
                **info,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": info["cif_path"],
                "weight_fraction": fraction,
                "weight_percent": 100.0 * fraction,
                "refined_cell": {
                    "a_angstrom": float(cell["length_a"]),
                    "b_angstrom": float(cell["length_b"]),
                    "c_angstrom": float(cell["length_c"]),
                    "alpha_deg": float(cell["angle_alpha"]),
                    "beta_deg": float(cell["angle_beta"]),
                    "gamma_deg": float(cell["angle_gamma"]),
                    "volume_angstrom3": float(cell["volume"]),
                },
            }
        )

    x, yobs, weight, ycalc, ybkg, ydiff = hist.data["data"][1]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_observed_minus_calculated",
                "background_intensity",
            ]
        )
        for values in zip(x, yobs, ycalc, yobs - ycalc, ybkg):
            # Seventeen significant digits preserve binary64 values on a
            # text round trip, keeping this profile exact with final.gpx.
            writer.writerow([f"{float(value):.17g}" for value in values])

    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    result = {
        "input_pattern": "inputs/pattern.csv",
        "measurement_metadata": "inputs/metadata.json",
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "fraction_normalization": "normalized over the modeled crystalline phases only",
        "phases": phase_records,
        "fit_statistics": {
            "rwp_percent": float(hist.residuals["wR"]),
            "rp_percent": float(hist.residuals["R"]),
            "gof": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "converged": bool(rvals.get("converged", False)),
            "maximum_shift_over_esd": float(rvals.get("Max shft/sig", float("nan"))),
            "weighting": "Poisson counting uncertainty, sigma=sqrt(max(intensity,1))",
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> None:
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(FINAL))
    hist = project.histogram(0)
    x = hist.data["data"][1][0]
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]
    neutralize_unused_terms(project)
    converge(project)
    project.save()

    # Reopen and replay to expose state-dependent changes, then save that exact
    # state. All exports are made from a second read without further refinement.
    replay = G2sc.G2Project(str(FINAL))
    converge(replay)
    replay.save()
    exact = G2sc.G2Project(str(FINAL))
    result = export_outputs(exact)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
