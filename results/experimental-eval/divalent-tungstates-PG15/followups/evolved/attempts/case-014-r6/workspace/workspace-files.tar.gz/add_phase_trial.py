#!/usr/bin/env python3
"""Challenge a candidate phase against an already converged common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from profile_trials import summary
from refine_trials import CANDIDATES, neutralize_hap


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("candidate", choices=sorted(CANDIDATES))
    parser.add_argument("output", type=Path)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--no-cell", action="store_true")
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source))
    project.save(str(args.output))
    hist = project.histogram(0)
    name, cif = CANDIDATES[args.candidate]
    phase = project.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
    neutralize_hap(phase, hist.name)
    phase.HAPvalue("Scale", 0.5)
    phase.set_HAP_refinements({"Scale": True})
    project.update_ids()
    project.set_Controls("parmMin", 1.0e-10, variable=f"{phase.id}:0:Scale")
    project.set_Controls("parmMax", 100.0, variable=f"{phase.id}:0:Scale")
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist.InstrumentParameters["U"][1] = 0.0
    hist.InstrumentParameters["U"][2] = False

    history = []
    project.refine(makeBack=False)
    history.append({"step": "scale_common_profile", **summary(project)})
    masses = [p.HAPvalue("Scale") * p.data["General"]["Mass"] for p in project.phases()]
    candidate_fraction = masses[-1] / sum(masses)
    if candidate_fraction > 1.0e-4 and not args.no_cell:
        phase.set_refinements({"Cell": True})
        project.refine(makeBack=False)
        history.append({"step": "candidate_cell", **summary(project)})
    project.refine(makeBack=False)
    history.append({"step": "replay", **summary(project)})
    project.save()
    replay = G2sc.G2Project(str(args.output))
    replay.refine(makeBack=False)
    replay.save()
    history.append({"step": "reopen_replay", **summary(replay)})
    args.summary.write_text(json.dumps(history, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
