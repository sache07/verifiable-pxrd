#!/usr/bin/env python3
"""Build reproducible GSAS-II trial refinements for candidate phase records.

This is an analysis driver. The final submission is generated separately after
the phase inventory and profile model have been selected.
"""

from __future__ import annotations

import argparse
import copy
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = {
    "srwo4_tet": ("SrWO4_scheelite", cod_path("1546036")),
    "srwo4_mon": ("SrWO4_fergusonite", cod_path("1546037")),
    "sr3w2o9": ("Sr3W2O9", cod_path("2311977")),
    "wo3_p21n": ("WO3_P21n", cod_path("1528915")),
    "wo3_p21c_2010": ("WO3_P21c_2010", cod_path("1563541")),
    "wo3_p21c_1966": ("WO3_P21c_1966", cod_path("2311041")),
    "wo3_p1": ("WO3_P1", cod_path("2106293")),
    "wo3_pnma": ("WO3_Pnma", cod_path("2107312")),
    "wo3_old": ("WO3_old", cod_path("1010618")),
    "wo3_tet130": ("WO3_tetragonal_130", cod_path("1521532")),
    "wo3_tet129": ("WO3_tetragonal_129", cod_path("1521533")),
    "wo3_hex": ("WO3_hexagonal", cod_path("1004057")),
    "w18o49": ("W18O49", cod_path("1528166")),
    "w18o49_old": ("W18O49_old", cod_path("1538315")),
    "w10o29": ("W10O29", cod_path("1538317")),
    "w17o47": ("W17O47", cod_path("2107065")),
    "w3o8_21": ("W3O8_21", cod_path("2101049")),
    "w3o8_55": ("W3O8_55", cod_path("2101050")),
    "w3o10": ("W3O10", cod_path("9014468")),
    "srco3_hex": ("SrCO3_hexagonal", cod_path("1539128")),
    "srco3_ortho": ("SrCO3_strontianite", cod_path("9008198")),
    "sro": ("SrO", cod_path("7200689")),
    "sr3wo6_u": ("Sr3WO6_from_Sr3UO6", ROOT / ".tmp" / "sr3wo6_from_sr3uo6.cif"),
    "sr3wo6_ca": ("Sr3WO6_from_Ca3WO6", ROOT / ".tmp" / "sr3wo6_from_ca3wo6.cif"),
    "sr3wo6_u_p21": ("Sr3WO6_from_Sr3UO6_P21", ROOT / ".tmp" / "sr3wo6_from_sr3uo6_p21.cif"),
    "sr3wo6_rigid": ("Sr3WO6_rigid_WO6", ROOT / ".tmp" / "sr3wo6_rigid_wo6.cif"),
    "w18o49_neutral": ("W18O49_neutral", ROOT / ".tmp" / "w18o49_neutral.cif"),
}


def make_inputs() -> tuple[Path, Path]:
    """Create GSAS-II-readable count data and instrument parameters."""
    xye = ROOT / ".tmp" / "pattern.xye"
    inst = ROOT / ".tmp" / "pattern.instprm"
    xye.parent.mkdir(exist_ok=True)
    with (ROOT / "inputs" / "pattern.csv").open(newline="") as src, xye.open("w") as dst:
        rows = csv.DictReader(src)
        dst.write("# two_theta_deg intensity sigma_Poisson\n")
        for row in rows:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    inst.write_text(
        "#GSAS-II instrument parameter file for reflection Cu Kalpha data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        # Modest, nonnegative starting profile; V/Y/Z are neutral and fixed.
        "U:50.0;V:0.0;W:100.0;X:5.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def neutralize_hap(phase, hist_name: str) -> None:
    """Remove unused phase broadening, roughness/texture-like HAP terms."""
    hap = phase.data["Histograms"][hist_name]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    # Size is in micrometres; 1e6 is effectively infinite for this range.
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0e6
    hap["Size"][1][1] = 1.0e6
    hap["Size"][1][2] = 1.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]


def covariance_summary(project: G2sc.G2Project) -> dict:
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "Rvals": copy.deepcopy(cov.get("Rvals", {})),
        "varyList": cov.get("varyList", []),
        "variables": [float(v) for v in cov.get("variables", [])],
        "sig": [None if v is None else float(v) for v in cov.get("sig", [])],
    }


def project_summary(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    phases = []
    for phase in project.phases():
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(phase.HAPvalue("Scale")),
                "mass": float(phase.data["General"]["Mass"]),
                "hap": phase.data["Histograms"][hist.name],
            }
        )
    scales_mass = np.array([p["scale"] * p["mass"] for p in phases])
    denom = float(scales_mass.sum())
    for phase, value in zip(phases, scales_mass):
        phase["weight_fraction"] = float(value / denom) if denom > 0 else None
        phase.pop("hap")
    return {
        "residuals": copy.deepcopy(hist.residuals),
        "instrument": {
            key: {"value": val[1], "refine": val[2] if len(val) > 2 else None}
            for key, val in inst.items()
            if isinstance(val, list) and len(val) >= 2
        },
        "background": hist.Background[0],
        "phases": phases,
        "covariance": covariance_summary(project),
    }


def refine_once(project: G2sc.G2Project, label: str) -> dict:
    project.refine(makeBack=False)
    out = project_summary(project)
    out["step"] = label
    print(json.dumps(out, default=str))
    return out


def build_trial(keys: list[str], out_path: Path, inspect_only: bool = False) -> dict:
    xye, inst = make_inputs()
    project = G2sc.G2Project(newgpx=str(out_path))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.set_refinements(
        {
            "Limits": [10.01, 99.99],
            "Background": {
                "type": "chebyschev-1",
                "refine": False,
                "no. coeffs": 6,
                "coeffs": [650.0, -250.0, 100.0, -40.0, 15.0, -5.0],
            },
        }
    )
    # Keep the reflection geometry explicit and neutralize roughness.
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    # The global histogram scale is redundant with all HAP scales; keep it fixed.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    phases = []
    for key in keys:
        name, cif = CANDIDATES[key]
        phase = project.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
        neutralize_hap(phase, hist.name)
        phase.HAPvalue("Scale", 10.0 if key == "srwo4_tet" else 1.0)
        phases.append(phase)
    project.set_Controls("cycles", 12)
    project.update_ids()
    project.set_Controls("parmMin", -1.0, variable=":0:Zero")
    project.set_Controls("parmMax", 1.0, variable=":0:Zero")
    for name in ("U", "W", "X"):
        project.set_Controls("parmMin", 0.0, variable=f":0:{name}")
        project.set_Controls("parmMax", 5000.0, variable=f":0:{name}")
    for phase in phases:
        project.set_Controls("parmMin", 1.0e-10, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{phase.id}:0:Scale")
    project.save()
    if inspect_only:
        return project_summary(project)

    history = []
    # Common nuisance sequence after every inventory/source change.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    history.append(refine_once(project, "background_scales"))

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    history.append(refine_once(project, "zero_background_scales"))

    scale_masses = np.array([phase.HAPvalue("Scale") * phase.data["General"]["Mass"] for phase in phases])
    scale_total = float(scale_masses.sum())
    for phase, scale_mass in zip(phases, scale_masses):
        # A record rejected at the scale step should not be allowed to destroy
        # its metric tensor in a subsequent unconstrained cell refinement.
        if scale_total > 0 and scale_mass / scale_total > 1.0e-5:
            phase.set_refinements({"Cell": True})
    history.append(refine_once(project, "cells_zero_background_scales"))

    # Establish the same low-dimensional nonnegative common profile.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    history.append(refine_once(project, "common_profile"))
    history.append(refine_once(project, "common_profile_replay"))
    project.save()
    # Reload and replay to expose any state-dependent solution.
    replay = G2sc.G2Project(str(out_path))
    replay.refine(makeBack=False)
    replay.save()
    history.append({"step": "reopen_replay", **project_summary(replay)})
    return {"project": str(out_path), "keys": keys, "history": history}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("keys", nargs="+", choices=sorted(CANDIDATES))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--summary", type=Path)
    parser.add_argument("--inspect", action="store_true")
    args = parser.parse_args()
    result = build_trial(args.keys, args.output, args.inspect)
    if args.summary:
        args.summary.write_text(json.dumps(result, indent=2, default=str) + "\n")
    else:
        print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
