#!/usr/bin/env python3
"""Run one reversible profile/intensity-model trial from an existing GPX."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def summary(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    masses = [p.HAPvalue("Scale") * p.data["General"]["Mass"] for p in project.phases()]
    total = sum(masses)
    return {
        "wR": float(hist.residuals.get("wR", float("nan"))),
        "R": float(hist.residuals.get("R", float("nan"))),
        "GOF": float(project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF", float("nan"))),
        "instrument": {
            key: [float(value[1]), bool(value[2])]
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list)
            and len(value) > 2
            and isinstance(value[1], (int, float))
        },
        "phases": [
            {
                "name": phase.name,
                "weight_fraction": float(mass / total),
                "scale": float(phase.HAPvalue("Scale")),
                "cell": phase.get_cell(),
                "preferred_orientation": copy.deepcopy(phase.data["Histograms"][hist.name]["Pref.Ori."]),
                "size": copy.deepcopy(phase.data["Histograms"][hist.name]["Size"]),
                "mustrain": copy.deepcopy(phase.data["Histograms"][hist.name]["Mustrain"]),
                "extinction": copy.deepcopy(phase.data["Histograms"][hist.name]["Extinction"]),
            }
            for phase, mass in zip(project.phases(), masses)
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--polarization", type=float)
    parser.add_argument("--refine-polarization", action="store_true")
    parser.add_argument("--refine-shl", action="store_true")
    parser.add_argument("--shl-value", type=float)
    parser.add_argument("--texture-phase", type=int)
    parser.add_argument("--axis", nargs=3, type=int)
    parser.add_argument("--size-phase", type=int)
    parser.add_argument("--strain-phase", type=int)
    parser.add_argument("--extinction-phase", type=int)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source))
    project.save(str(args.output))
    hist = project.histogram(0)

    # U repeatedly attempted to cross its nonnegative bound. Prune it rather
    # than carrying a frozen, unsupported parameter into later comparisons.
    hist.InstrumentParameters["U"][1] = 0.0
    hist.InstrumentParameters["U"][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}

    if args.polarization is not None:
        hist.InstrumentParameters["Polariz."][1] = args.polarization
    hist.InstrumentParameters["Polariz."][2] = args.refine_polarization
    if args.refine_polarization:
        project.set_Controls("parmMin", 0.3, variable=":0:Polariz.")
        project.set_Controls("parmMax", 0.9, variable=":0:Polariz.")

    if args.shl_value is not None:
        hist.InstrumentParameters["SH/L"][1] = args.shl_value
    hist.InstrumentParameters["SH/L"][2] = args.refine_shl
    if args.refine_shl:
        project.set_Controls("parmMin", 0.0001, variable=":0:SH/L")
        project.set_Controls("parmMax", 0.1, variable=":0:SH/L")

    if args.texture_phase is not None:
        if args.axis is None:
            parser.error("--axis is required with --texture-phase")
        phase = project.phase(args.texture_phase)
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(args.axis)
        project.set_Controls("parmMin", 0.2, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 5.0, variable=f"{phase.id}:0:MD")

    if args.size_phase is not None:
        phase = project.phase(args.size_phase)
        size = phase.data["Histograms"][hist.name]["Size"]
        size[0] = "isotropic"
        size[1][0] = 10.0
        size[2] = [False for _ in size[2]]
        size[2][0] = True
        project.set_Controls("parmMin", 0.01, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 1.0e6, variable=f"{phase.id}:0:Size;i")

    if args.strain_phase is not None:
        phase = project.phase(args.strain_phase)
        strain = phase.data["Histograms"][hist.name]["Mustrain"]
        strain[0] = "isotropic"
        strain[1][0] = 100.0
        strain[2] = [False for _ in strain[2]]
        strain[2][0] = True
        strain[5] = [False for _ in strain[5]]
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 5000.0, variable=f"{phase.id}:0:Mustrain;i")

    if args.extinction_phase is not None:
        phase = project.phase(args.extinction_phase)
        ext = phase.data["Histograms"][hist.name]["Extinction"]
        ext[0] = 0.1
        ext[1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Extinction")
        project.set_Controls("parmMax", 100.0, variable=f"{phase.id}:0:Extinction")

    history = []
    for label in ("refine", "replay"):
        project.refine(makeBack=False)
        history.append({"step": label, **summary(project)})
    project.save()
    replay = G2sc.G2Project(str(args.output))
    replay.refine(makeBack=False)
    replay.save()
    history.append({"step": "reopen_replay", **summary(replay)})
    args.summary.write_text(json.dumps(history, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
