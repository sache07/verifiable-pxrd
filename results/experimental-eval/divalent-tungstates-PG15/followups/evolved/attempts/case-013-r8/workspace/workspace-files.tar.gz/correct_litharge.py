#!/usr/bin/env python3
"""Transform the COD litharge coordinates into GSAS-II's P4/nmm origin."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIspc as G2spc


ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--base", default="final.gpx")
parser.add_argument("--output", default="corrected_litharge.gpx")
parser.add_argument("--replays", type=int, default=3)
args = parser.parse_args()
output = ROOT / args.output
project = G2sc.G2Project(str(ROOT / args.base), newgpx=str(output))
phase = project.phase("PbO_litharge")
general = phase.data["General"]
cx, ct, cs, cia = general["AtomPtrs"]

# COD 9012700 is supplied in P4/nmm origin choice 1. GSAS-II uses the
# standard origin represented below. This is the same litharge structure,
# with Pb on 2c and O on 2a, and restores Pb:O = 1:1.
coordinates = {
    "Pb": [0.25, 0.25, 0.23510],
    "O": [0.75, 0.25, 0.0],
}
for atom in phase.data["Atoms"]:
    label = atom[ct - 1]
    atom[cx : cx + 3] = coordinates[label]
    site_symmetry, multiplicity = G2spc.SytSym(atom[cx : cx + 3], general["SGData"])[:2]
    atom[cs] = site_symmetry
    atom[cs + 1] = multiplicity

G2sc.SetupGeneral(phase.data, None)
if general["NoAtoms"] != {"Pb": 2.0, "O": 2.0}:
    raise RuntimeError(f"unexpected corrected litharge contents: {general['NoAtoms']}")

project.set_Frozen()
project.set_Controls("cycles", 12)
project.save()
for _ in range(args.replays):
    project = G2sc.G2Project(str(output))
    project.do_refinements([{}], makeBack=False)
    project.save()

project = G2sc.G2Project(str(output))
hist = project.histogram(0)
print("residuals", hist.residuals)
print("fractions", hist.ComputeMassFracs())
print("litharge contents", project.phase("PbO_litharge").data["General"]["NoAtoms"])
print("litharge cell", project.phase("PbO_litharge").get_cell())
print("frozen", project.get_Frozen())
