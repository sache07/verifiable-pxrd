#!/usr/bin/env python3
"""Replay, export and document the selected GSAS-II refinement exactly."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "variant_corrected_isosize005.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "PbWO4_stolzite": {
        "formula": "PbWO4",
        "common_name": "stolzite (scheelite-type)",
        "source_cod_id": "9009811",
        "cif": "phase_1_PbWO4_stolzite.cif",
        "fraction_reliability": "model-dependent because of correlation with broadened massicot intensity",
    },
    "WO3_triclinic": {
        "formula": "WO3",
        "common_name": "triclinic tungsten(VI) oxide",
        "source_cod_id": "2106293",
        "cif": "phase_2_WO3_triclinic.cif",
        "fraction_reliability": "moderate; monoclinic gamma-WO3 is a near-degenerate structural alternative",
    },
    "PbO_massicot": {
        "formula": "PbO",
        "common_name": "massicot",
        "source_cod_id": "2310433",
        "cif": "phase_3_PbO_massicot.cif",
        "fraction_reliability": "strongly model-dependent because its broad intensity is correlated with domain size and background",
    },
    "PbO_litharge": {
        "formula": "PbO",
        "common_name": "litharge",
        "source_cod_id": "9012700 (origin transformed to GSAS-II standard P4/nmm setting)",
        "cif": "phase_4_PbO_litharge.cif",
        "fraction_reliability": "tentative trace/minor fraction; several reflections overlap other phases",
    },
    "Pb3O4_minium": {
        "formula": "Pb3O4",
        "common_name": "minium (red lead)",
        "source_cod_id": "1537983",
        "cif": "phase_5_Pb3O4_minium.cif",
        "fraction_reliability": "tentative trace fraction; supported by multiple weak families but overlap is substantial",
    },
}


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    project.set_Controls("cycles", 12)
    project.set_Frozen()
    project.save()

    # Required save/reopen/replay of the complete range. No settings are changed
    # between passes, so all exported products arise from the final replay state.
    for _ in range(2):
        project = G2sc.G2Project(str(FINAL))
        project.do_refinements([{}], makeBack=False)
        project.save()
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)

    fractions = hist.ComputeMassFracs()
    total = sum(value for value, _sigma in fractions.values())
    if not np.isclose(total, 1.0, atol=1e-8):
        raise RuntimeError(f"mass fractions do not sum to one: {total}")
    if project.get_Frozen():
        raise RuntimeError(f"final project has frozen bound variables: {project.get_Frozen()}")

    phase_rows = []
    residuals = hist.residuals
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif"]))
        value, sigma = fractions[phase.name]
        sg = phase.data["General"]["SGData"]
        pid = phase.id
        phase_rows.append(
            {
                "name": phase.name,
                "formula": info["formula"],
                "common_name": info["common_name"],
                "space_group": sg["SpGrp"].strip(),
                "source_cod_id": info["source_cod_id"],
                "cif_path": info["cif"],
                "weight_fraction": value / total,
                "weight_fraction_esd": sigma,
                "fraction_reliability": info["fraction_reliability"],
                "refined_cell": phase.get_cell(),
                "bragg_r_factor_percent": residuals.get(f"{pid}:0:Rf"),
                "bragg_r_factor_squared_percent": residuals.get(f"{pid}:0:Rf^2"),
            }
        )

    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_observed_minus_calculated",
            ]
        )
        x_data = np.asarray(hist.getdata("X"), dtype=float)
        observed = np.asarray(hist.getdata("Yobs"), dtype=float)
        calculated = np.asarray(hist.getdata("Ycalc"), dtype=float)
        difference = observed - calculated
        for row in zip(x_data, observed, calculated, difference):
            writer.writerow([f"{float(value):.8f}" for value in row])

    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    inst = hist.InstrumentParameters
    massicot_hap = project.phase("PbO_massicot").data["Histograms"][hist.name]
    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "r_wp_percent": residuals["wR"],
            "r_p_percent": residuals["R"],
            "r_exp_percent": residuals["wRmin"],
            "goodness_of_fit": rvals["GOF"],
            "chi_square": rvals["chisq"],
            "n_observations": rvals["Nobs"],
            "n_refined_variables": rvals["Nvars"],
            "max_shift_over_esd": rvals["Max shft/sig"],
            "weighting": "Poisson working weights, sigma=sqrt(counts); pointwise uncertainties were not supplied",
            "profile_range_two_theta_deg": [
                float(hist.data["Limits"][1][0]),
                float(hist.data["Limits"][1][1]),
            ],
        },
        "refinement_model": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelengths_angstrom": [inst["Lam1"][1], inst["Lam2"][1]],
            "kalpha2_to_kalpha1_ratio": inst["I(L2)/I(L1)"][1],
            "zero_shift_deg_two_theta": inst["Zero"][1],
            "polarization": inst["Polariz."][1],
            "profile_U_V_W_X": [inst[key][1] for key in ("U", "V", "W", "X")],
            "sh_over_l": inst["SH/L"][1],
            "background": "10-term Chebyshev-1 polynomial",
            "texture": "none",
            "massicot_domain_size_model": {
                "type": massicot_hap["Size"][0],
                "domain_size_micrometre": massicot_hap["Size"][1][0],
            },
        },
        "files": {
            "gsasii_project": "final.gpx",
            "profile": "fit.csv",
            "report": "report.md",
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    by_name = {row["name"]: row for row in phase_rows}
    lines = [
        "# PXRD phase analysis",
        "",
        "## Submitted crystalline model",
        "",
        "Weight fractions are normalized over the five modeled crystalline phases.",
        "",
        "| Phase | Space group | Weight fraction | Refined cell (Å, °) |",
        "|---|---:|---:|---|",
    ]
    for row in phase_rows:
        cell = row["refined_cell"]
        cell_text = (
            f"a={cell['length_a']:.5f}, b={cell['length_b']:.5f}, "
            f"c={cell['length_c']:.5f}; alpha={cell['angle_alpha']:.3f}, "
            f"beta={cell['angle_beta']:.3f}, gamma={cell['angle_gamma']:.3f}"
        )
        lines.append(
            f"| {row['common_name']} ({row['formula']}) | {row['space_group']} | "
            f"{100*row['weight_fraction']:.2f}% | {cell_text} |"
        )
    lines += [
        "",
        "## Evidence",
        "",
        "The PbO + WO3 precursor chemistry and 500 °C treatment first suggest PbWO4. "
        "The dominant 27.70, 29.91, 33.05, 45.02, 47.28, 51.48, 55.54 and 56.81° families are indexed by tetragonal stolzite. "
        "The 23.36/23.88/24.65° cluster and related split families require WO3. Broad families near 29.34, 30.61, 38.11, 49.52, 53.38, 60.55 and 63.28° require orthorhombic massicot; "
        "the narrower 32.10, 35.99, 45.92 and 48.84° features retain tetragonal litharge. Weak coherent groups near 26.8, 31, 34.4° and at higher angle support trace Pb3O4.",
        "",
        "All submitted structures use full-occupancy COD coordinates (IDs 9009811, 2106293, 2310433, 9012700 and 1537983); the litharge coordinates were origin-transformed into GSAS-II's standard P4/nmm setting to preserve PbO stoichiometry. Atomic coordinates and displacement factors were held at their reference values while cells were refined. "
        "Raspite PbWO4 and epsilon-WO3 collapsed to zero scale. A room-temperature monoclinic WO3 record is nearly degenerate (Rwp 14.034% versus the submitted triclinic model), so the WO3 symmetry assignment is not definitive.",
        "",
        "## Refinement and uncertainty",
        "",
        f"The replayed full-range fit gives Rwp={residuals['wR']:.3f}%, Rp={residuals['R']:.3f}%, Rexp={residuals['wRmin']:.3f}% and GOF={rvals['GOF']:.3f}. "
        "The baseline uses one zero correction, refined polarization, nonnegative W/X profile terms with U=V=0, fixed reported Kalpha2/Kalpha1=0.5, a smooth 10-term background, no roughness/texture, and one isotropic massicot domain-size term. SH/L, texture, strain, anisotropic size, and unsupported phase size terms were pruned.",
        "",
        "The formal covariance errors in result.json are much smaller than the systematic uncertainty because the measurement supplied no pointwise uncertainties. Most importantly, massicot is nanocrystalline and its integrated intensity is correlated with background and domain size: the corrected common-profile/no-size model gives about 70.7% PbWO4 and 9.8% massicot, whereas the submitted physically broadened model gives "
        f"{100*by_name['PbWO4_stolzite']['weight_fraction']:.1f}% and {100*by_name['PbO_massicot']['weight_fraction']:.1f}%. "
        "Thus those two absolute fractions cannot be determined reliably from this pattern alone; the submitted values are the best-fit broadened-model values, not high-accuracy composition measurements. WO3 is moderately robust near 10–12%; litharge and Pb3O4 are tentative trace/minor quantities because of overlap.",
        "",
        "The exact replayed project is `final.gpx`; its exported structures and calculated profile are the submitted CIFs and `fit.csv`.",
    ]
    (ROOT / "report.md").write_text("\n".join(lines) + "\n")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
