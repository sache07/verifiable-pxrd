#!/usr/bin/env python3
"""Build consistently refined GSAS-II screening projects for candidate inventories."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


PHASES = {
    "pwo_tet_rt": ("PbWO4_stolzite", "9009811"),
    "pwo_tet_alt": ("PbWO4_stolzite", "1527935"),
    "pwo_raspite": ("PbWO4_raspite", "9007617"),
    "wo3_mono": ("WO3_gamma", "2311041"),
    "wo3_mono_alt": ("WO3_gamma", "1528915"),
    "wo3_tri": ("WO3_triclinic", "2106293"),
    "wo3_eps": ("WO3_epsilon", "1563541"),
    "pbo_massicot": ("PbO_massicot", "2310433"),
    "pbo_massicot_super": ("PbO_massicot", "1533609"),
    "pbo_litharge": ("PbO_litharge", "9012700"),
    "pb3o4_tet": ("Pb3O4_minium", "1537983"),
}


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_data() -> tuple[Path, Path]:
    """Create GSAS-II-friendly profile and instrument files from the raw CSV."""
    xye = ROOT / "pattern.xye"
    inst = ROOT / "instrument.instprm"
    rows = []
    with (ROOT / "inputs" / "pattern.csv").open(newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            # No pointwise uncertainties were supplied. Counting statistics are
            # the least-assumptive working weights for the unprocessed counts.
            rows.append((x, y, math.sqrt(max(y, 1.0))))
    np.savetxt(xye, np.asarray(rows), fmt="%.8f %.8f %.8f")
    inst.write_text(
        "#GSAS-II instrument parameter file for lab Cu Ka reflection data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:80.0;V:0.0;W:80.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def set_neutral_hap(phase, hist) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.05, False]
    hap["Extinction"] = [0.0, False]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    # Effectively neutral sample broadening; phase-specific trials are made later.
    size = hap["Size"]
    size[0] = "isotropic"
    size[1][0] = 1000.0
    size[1][1] = 1000.0
    size[1][2] = 1.0
    size[2] = [False for _ in size[2]]
    if len(size) > 5:
        size[5] = [False for _ in size[5]]
    strain = hap["Mustrain"]
    strain[0] = "isotropic"
    strain[1][0] = 0.0
    strain[1][1] = 0.0
    strain[1][2] = 1.0
    strain[2] = [False for _ in strain[2]]
    if len(strain) > 5:
        strain[5] = [False for _ in strain[5]]
    hap["Pref.Ori."][2] = False


def summary(project: G2sc.G2Project, tag: str, keys: list[str]) -> dict:
    hist = project.histogram(0)
    out = {
        "tag": tag,
        "keys": keys,
        "residuals": hist.residuals,
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if key in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "phases": {},
        "frozen": project.get_Frozen(),
    }
    try:
        out["mass_fractions"] = {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "scale": hap["Scale"],
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    return out


def run(tag: str, keys: list[str]) -> dict:
    xye, inst = prepare_data()
    project_path = ROOT / f"screen_{tag}.gpx"
    project = G2sc.G2Project(newgpx=str(project_path))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    # Keep one absolute histogram scale fixed; only phase scales carry the
    # quantitative information. GSAS-II otherwise starts this as refinable.
    hist.SampleParameters["Scale"][0] = 1.0
    hist.SampleParameters["Scale"][1] = False
    hist.set_refinements(
        {
            "Limits": [10.01, 99.99],
            "Background": {
                "type": "chebyschev-1",
                "refine": False,
                "no. coeffs": 8,
                "coeffs": [900.0, -600.0, 300.0, -120.0, 40.0, 0.0, 0.0, 0.0],
            },
        }
    )
    inst_dict = hist.InstrumentParameters
    for name, value in {"U": 80.0, "V": 0.0, "W": 80.0, "X": 0.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002}.items():
        inst_dict[name][1] = value
        inst_dict[name][2] = False

    used_names: dict[str, int] = {}
    for key in keys:
        base_name, cod_id = PHASES[key]
        used_names[base_name] = used_names.get(base_name, 0) + 1
        suffix = "" if used_names[base_name] == 1 else f"_{used_names[base_name]}"
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=f"{base_name}{suffix}",
            histograms=[hist],
            fmthint="CIF",
        )
        set_neutral_hap(phase, hist)

    project.set_Controls("cycles", 10)
    # Global wildcard limits. A hit freezes the parameter, which is reported.
    for variable, lower, upper in [
        ("*:0:Scale", 1e-10, 1e6),
        (":0:U", 0.0, 5000.0),
        (":0:W", 0.0, 5000.0),
        (":0:X", 0.0, 100.0),
        (":0:Zero", -1.0, 1.0),
    ]:
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    stages = [
        {"set": {"Background": {"refine": True}, "Scale": True}},
        {"set": {"Instrument Parameters": ["Zero"]}},
        {"set": {"Cell": True}},
        {"set": {"Instrument Parameters": ["U", "W", "X"]}},
        {},
    ]
    for index, stage in enumerate(stages, 1):
        project.do_refinements([stage], makeBack=False)
        project.save()
        # Reopen at every stage so screening and final work use replayable state.
        project = G2sc.G2Project(str(project_path))
        hist = project.histogram(0)
        print(
            json.dumps(
                {
                    "tag": tag,
                    "stage": index,
                    "residuals": hist.residuals,
                    "zero": hist.InstrumentParameters["Zero"][1],
                    "UWX": [hist.InstrumentParameters[n][1] for n in ("U", "W", "X")],
                    "scales": {
                        p.name: p.data["Histograms"][hist.name]["Scale"][0]
                        for p in project.phases()
                    },
                },
                default=float,
            )
        )

    result = summary(project, tag, keys)
    (ROOT / f"screen_{tag}.json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, indent=2, default=float))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("tag")
    parser.add_argument("phases", nargs="+", choices=sorted(PHASES))
    args = parser.parse_args()
    run(args.tag, args.phases)


if __name__ == "__main__":
    main()
