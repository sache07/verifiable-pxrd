#!/usr/bin/env python3
"""Replay profile, broadening and texture variants from a converged inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PHASE_INDEX = {
    "pwo": 0,
    "wo3": 1,
    "massicot": 2,
    "litharge": 3,
}


def clear_bound_u(project: G2sc.G2Project) -> None:
    project.set_Frozen()
    inst = project.histogram(0).InstrumentParameters
    inst["U"][1] = 0.0
    inst["U"][2] = False
    inst["V"][1] = 0.0
    inst["V"][2] = False
    inst["W"][2] = True
    inst["X"][2] = True


def set_isotropic_profile(project: G2sc.G2Project, phase_index: int, kind: str) -> None:
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    if kind == "size":
        profile = hap["Size"]
        profile[0] = "isotropic"
        profile[1][0] = 0.05
        profile[1][2] = 1.0
        profile[2] = [False for _ in profile[2]]
        profile[2][0] = True
        project.set_Controls("parmMin", 0.001, variable=f"{phase_index}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{phase_index}:0:Size;i")
    elif kind == "strain":
        profile = hap["Mustrain"]
        profile[0] = "isotropic"
        profile[1][0] = 500.0
        profile[1][2] = 1.0
        profile[2] = [False for _ in profile[2]]
        profile[2][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{phase_index}:0:Mustrain;i")
    else:
        raise ValueError(kind)


def set_uniaxial_profile(
    project: G2sc.G2Project,
    phase_index: int,
    kind: str,
    axis: list[int],
) -> None:
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    if kind == "usize":
        profile = hap["Size"]
        profile[0] = "uniaxial"
        profile[1][0] = 0.02
        profile[1][1] = 0.02
        profile[1][2] = 1.0
        profile[2] = [False for _ in profile[2]]
        profile[2][0] = True
        profile[2][1] = True
        profile[3] = axis
        for suffix in ("i", "a"):
            project.set_Controls("parmMin", 0.001, variable=f"{phase_index}:0:Size;{suffix}")
            project.set_Controls("parmMax", 10.0, variable=f"{phase_index}:0:Size;{suffix}")
    elif kind == "ustrain":
        profile = hap["Mustrain"]
        profile[0] = "uniaxial"
        profile[1][0] = 3000.0
        profile[1][1] = 3000.0
        profile[1][2] = 1.0
        profile[2] = [False for _ in profile[2]]
        profile[2][0] = True
        profile[2][1] = True
        profile[3] = axis
        for suffix in ("i", "a"):
            project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;{suffix}")
            project.set_Controls("parmMax", 10000.0, variable=f"{phase_index}:0:Mustrain;{suffix}")
    else:
        raise ValueError(kind)


def apply_variant(project: G2sc.G2Project, variant: str) -> None:
    clear_bound_u(project)
    hist = project.histogram(0)
    inst = hist.InstrumentParameters

    if variant == "clean":
        return
    if variant == "polarization":
        inst["Polariz."][2] = True
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
        return
    if variant == "shl":
        inst["SH/L"][2] = True
        project.set_Controls("parmMin", 0.002, variable=":0:SH/L")
        project.set_Controls("parmMax", 0.1, variable=":0:SH/L")
        return
    if variant == "polarization_shl":
        inst["Polariz."][2] = True
        inst["SH/L"][2] = True
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
        project.set_Controls("parmMin", 0.002, variable=":0:SH/L")
        project.set_Controls("parmMax", 0.1, variable=":0:SH/L")
        return
    if variant == "w_only":
        inst["X"][1] = 0.0
        inst["X"][2] = False
        return
    if variant == "neutral_massicot_size":
        hap = project.phase(PHASE_INDEX["massicot"]).data["Histograms"][hist.name]
        profile = hap["Size"]
        profile[0] = "isotropic"
        profile[1][0] = 10.0
        profile[1][1] = 10.0
        profile[1][2] = 1.0
        profile[2] = [False for _ in profile[2]]
        if len(profile) > 5:
            profile[5] = [False for _ in profile[5]]
        return
    if variant in {"disable_litharge", "disable_pb3o4"}:
        phase_index = 3 if variant == "disable_litharge" else 4
        hap = project.phase(phase_index).data["Histograms"][hist.name]
        hap["Use"] = False
        return
    if variant.startswith("background"):
        count = int(variant.removeprefix("background"))
        bg = hist.data["Background"][0]
        coeffs = list(bg[3:])
        if count < len(coeffs):
            coeffs = coeffs[:count]
        else:
            coeffs.extend([0.0] * (count - len(coeffs)))
        bg[:] = [bg[0], True, count, *coeffs]
        return
    if variant.startswith("size_") or variant.startswith("strain_"):
        kind, phase_key = variant.split("_", 1)
        set_isotropic_profile(project, PHASE_INDEX[phase_key], kind)
        return
    if variant.startswith("usize_") or variant.startswith("ustrain_"):
        kind, phase_key, axis_text = variant.split("_", 2)
        axis = [int(char) for char in axis_text]
        set_uniaxial_profile(project, PHASE_INDEX[phase_key], kind, axis)
        return
    if variant.startswith("texture_"):
        axis = {
            "texture_001": [0, 0, 1],
            "texture_100": [1, 0, 0],
            "texture_110": [1, 1, 0],
            "texture_112": [1, 1, 2],
        }[variant]
        hap = project.phase(0).data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        project.set_Controls("parmMin", 0.2, variable="0:0:MD")
        project.set_Controls("parmMax", 5.0, variable="0:0:MD")
        return
    raise ValueError(f"unknown variant {variant}")


def summarize(project: G2sc.G2Project, variant: str) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    vary = cov.get("varyList", [])
    values = cov.get("variables", [])
    sigmas = cov.get("sig", [])
    out = {
        "variant": variant,
        "residuals": hist.residuals,
        "instrument": {
            key: value
            for key, (_initial, value, _refine) in hist.InstrumentParameters.items()
            if key in {"Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"}
        },
        "frozen": project.get_Frozen(),
        "variables": {
            str(name): {"value": float(value), "sigma": float(sigma)}
            for name, value, sigma in zip(vary, values, sigmas)
        },
        "phases": {},
    }
    try:
        out["mass_fractions"] = {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "scale": hap["Scale"],
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("variant")
    parser.add_argument("--base", default="screen_wo3_tri.gpx")
    parser.add_argument("--tag", default=None)
    args = parser.parse_args()

    tag = args.tag or args.variant
    output = ROOT / f"variant_{tag}.gpx"
    project = G2sc.G2Project(str(ROOT / args.base), newgpx=str(output))
    project.set_Controls("cycles", 10)
    apply_variant(project, args.variant)
    project.save()
    for _ in range(2):
        project = G2sc.G2Project(str(output))
        project.do_refinements([{}], makeBack=False)
        project.save()

    project = G2sc.G2Project(str(output))
    result = summarize(project, args.variant)
    result["tag"] = tag
    (ROOT / f"variant_{tag}.json").write_text(
        json.dumps(result, indent=2, default=float) + "\n"
    )
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
