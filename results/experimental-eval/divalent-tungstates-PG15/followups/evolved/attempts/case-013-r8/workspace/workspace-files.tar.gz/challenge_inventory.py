#!/usr/bin/env python3
"""Add one watch-list phase to the accepted common-profile project and replay."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_screen import PHASES, cod_path, set_neutral_hap


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", choices=sorted(PHASES))
    parser.add_argument("--base", default="variant_lowmin_usize_massicot_100.gpx")
    parser.add_argument("--tag", default=None)
    args = parser.parse_args()

    tag = args.tag or args.candidate
    output = ROOT / f"challenge_{tag}.gpx"
    project = G2sc.G2Project(str(ROOT / args.base), newgpx=str(output))
    hist = project.histogram(0)
    name, cod_id = PHASES[args.candidate]
    phase = project.add_phase(
        str(cod_path(cod_id)),
        phasename=name,
        histograms=[hist],
        fmthint="CIF",
    )
    set_neutral_hap(phase, hist)
    phase.data["Histograms"][hist.name]["Scale"] = [0.02, True]
    phase.data["General"]["Cell"][0] = False
    project.set_Frozen()
    project.set_Controls("cycles", 10)
    new_index = len(project.phases()) - 1
    project.set_Controls("parmMin", 1e-10, variable=f"{new_index}:0:Scale")
    project.set_Controls("parmMax", 1e6, variable=f"{new_index}:0:Scale")
    project.save()

    # Scale under the established profile, then release the candidate cell and
    # rebuild all already-accepted common/profile parameters.
    project.do_refinements([{}], makeBack=False)
    project.save()
    project = G2sc.G2Project(str(output))
    first_scale = project.phase(new_index).data["Histograms"][project.histogram(0).name]["Scale"][0]
    collapsed = first_scale <= 1e-8 or f"{new_index}:0:Scale" in project.get_Frozen()
    if not collapsed:
        project.phase(new_index).data["General"]["Cell"][0] = True
        project.do_refinements([{}], makeBack=False)
        project.save()
        project = G2sc.G2Project(str(output))
        project.do_refinements([{}], makeBack=False)
        project.save()
    project = G2sc.G2Project(str(output))
    hist = project.histogram(0)

    result = {
        "candidate": args.candidate,
        "collapsed_after_scale_test": collapsed,
        "residuals": hist.residuals,
        "frozen": project.get_Frozen(),
        "mass_fractions": {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        },
        "candidate_scale": project.phase(new_index).data["Histograms"][hist.name]["Scale"],
        "candidate_cell": project.phase(new_index).get_cell(),
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "Polariz.", "U", "V", "W", "X", "SH/L"}
        },
    }
    (ROOT / f"challenge_{tag}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
