#!/usr/bin/env python3
"""Replay the selected GSAS-II model and export all requested deliverables."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/massicot_strain/massicot_strain.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_INFO = {
    "PbWO4_scheelite": {
        "formula": "PbWO4",
        "cif": "phase_1_PbWO4_scheelite.cif",
        "space_group": "I41/a",
        "model_status": "identified_database_structure",
        "source": "COD 9009811",
    },
    "Pb2WO5_C2m_prototype": {
        "formula": "Pb2WO5",
        "cif": "phase_2_Pb2WO5_C2m_prototype.cif",
        "space_group": "C2/m",
        "model_status": "prototype_substitution_Mo6+_to_W6+",
        "source": "Pb2MoO5 prototype, COD 7220560",
    },
    "WO3_monoclinic": {
        "formula": "WO3",
        "cif": "phase_3_WO3_monoclinic.cif",
        "space_group": "P21/n",
        "model_status": "identified_database_structure",
        "source": "COD 1528915",
    },
    "PbO_massicot": {
        "formula": "PbO",
        "cif": "phase_4_PbO_massicot.cif",
        "space_group": "Pbcm",
        "model_status": "identified_database_structure",
        "source": "COD 2310433",
    },
    "PbO_alpha_long_period": {
        "formula": "PbO",
        "cif": "phase_5_PbO_alpha_long_period.cif",
        "space_group": "Pbma (No. 57 setting; long-period approximant)",
        "model_status": "identified_commensurate_approximant",
        "source": "COD 1533609",
    },
    "Pb2O3_monoclinic_tentative": {
        "formula": "Pb2O3",
        "cif": "phase_6_Pb2O3_tentative.cif",
        "space_group": "P21/c",
        "model_status": "tentative_geometry_corrected_database_model",
        "source": "COD 2311012; O1 y corrected from 0.964 to 0.164",
    },
    "Pb3WO6_Pnma_prototype": {
        "formula": "Pb3WO6",
        "cif": "phase_7_Pb3WO6_Pnma_prototype.cif",
        "space_group": "Pnma",
        "model_status": "prototype_substitution_U6+_to_W6+",
        "source": "Pb3UO6 prototype, COD 2310493",
    },
    "Pb3O4_minium": {
        "formula": "Pb3O4",
        "cif": "phase_8_Pb3O4_minium.cif",
        "space_group": "P42/mbc",
        "model_status": "identified_database_structure_weak_phase",
        "source": "COD 1537983",
    },
}


def neutralize_unsupported_terms(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "Y"):
        inst[key][1] = 0.0
        inst[key][2] = False
    for key in ("W", "X", "SH/L", "Zero"):
        inst[key][2] = True
    sample = hist.data["Sample Parameters"]
    for key in (
        "Absorption",
        "DisplaceX",
        "DisplaceY",
        "Shift",
        "Transparency",
        "SurfRoughA",
        "SurfRoughB",
    ):
        if key in sample and isinstance(sample[key], list):
            sample[key][0] = 0.0
            sample[key][1] = False

    for phase_index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        if phase.name == "PbO_massicot":
            hap["Mustrain"][2][0] = True
        else:
            hap["Mustrain"][1][0] = 0.0
        hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
        hap["Extinction"] = [0.0, False]
        hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        phase.set_refinements({"Cell": True})

    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("parmMin", 0.0, variable=":0:W")
    project.set_Controls("parmMin", 0.0, variable=":0:X")
    project.set_Controls("parmMin", 0.002, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.2, variable=":0:SH/L")
    project.set_Controls("parmMin", 0.0, variable="3:0:Mustrain;i")
    project.set_Controls("parmMax", 10000.0, variable="3:0:Mustrain;i")


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL_GPX))
    if [phase.name for phase in project.phases()] != list(PHASE_INFO):
        raise RuntimeError("Unexpected phase inventory or ordering")
    neutralize_unsupported_terms(project)
    project.set_Controls("cycles", 12)
    project.save()

    # Exact final save/reopen/replay sequence.
    for _ in range(3):
        project = G2sc.G2Project(str(FINAL_GPX))
        project.refine(makeBack=False)
        project.save()
    project = G2sc.G2Project(str(FINAL_GPX))
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    if not rvals.get("converged", False):
        raise RuntimeError("Final replay did not converge")

    raw_fractions = hist.ComputeMassFracs()
    total = sum(value[0] for value in raw_fractions.values())
    phases_out = []
    residuals = hist.data["data"][0]
    for phase_index, phase in enumerate(project.phases()):
        info = PHASE_INFO[phase.name]
        cif_path = ROOT / info["cif"]
        phase.export_CIF(str(cif_path))
        fraction, fraction_esd = raw_fractions[phase.name]
        phase_rf = residuals.get(f"{phase_index}:0:Rf")
        hap = phase.data["Histograms"][hist.name]
        phase_result = {
            "name": phase.name,
            "formula": info["formula"],
            "space_group": info["space_group"],
            "cif_path": info["cif"],
            "weight_fraction": fraction / total,
            "weight_percent": 100.0 * fraction / total,
            "weight_fraction_formal_esd": fraction_esd / total,
            "model_status": info["model_status"],
            "source_model": info["source"],
            "cell": phase.get_cell(),
            "phase_Rf_percent": phase_rf,
        }
        if phase.name == "PbO_massicot":
            phase_result["isotropic_microstrain"] = hap["Mustrain"][1][0]
        phases_out.append(phase_result)

    arrays = hist.data["data"][1]
    x, observed, calculated, background, difference = (
        arrays[0],
        arrays[1],
        arrays[3],
        arrays[4],
        arrays[5],
    )
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference, background)),
        delimiter=",",
        header=(
            "two_theta_deg,observed_counts,calculated_counts,"
            "difference_counts,background_counts"
        ),
        comments="",
        fmt=("%.8f", "%.8g", "%.8g", "%.8g", "%.8g"),
    )

    inst = hist.data["Instrument Parameters"][0]
    fit_statistics = {
        "Rwp_percent": hist.get_wR(),
        "Rp_percent": residuals["R"],
        "Rexp_percent": residuals["wRmin"],
        "GOF": rvals["GOF"],
        "chi_square": rvals["chisq"],
        "Nobs": rvals["Nobs"],
        "Nvars": rvals["Nvars"],
        "degrees_of_freedom": rvals["Nobs"] - rvals["Nvars"],
        "Durbin_Watson": residuals["Durbin-Watson"],
        "two_theta_min_deg": float(x[0]),
        "two_theta_max_deg": float(x[-1]),
        "weighting": "sigma=sqrt(max(observed_counts,1)); no supplied pointwise uncertainties",
    }
    result = {
        "modeled_crystalline_phase_count": len(phases_out),
        "weight_fraction_normalization": "sum over modeled crystalline phases = 1",
        "phases": phases_out,
        "fit_statistics": fit_statistics,
        "instrument_model": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelength_Kalpha1_angstrom": inst["Lam1"][1],
            "wavelength_Kalpha2_angstrom": inst["Lam2"][1],
            "Kalpha2_to_Kalpha1_ratio": inst["I(L2)/I(L1)"][1],
            "zero_deg": inst["Zero"][1],
            "U": inst["U"][1],
            "V": inst["V"][1],
            "W": inst["W"][1],
            "X": inst["X"][1],
            "Y": inst["Y"][1],
            "SH_over_L": inst["SH/L"][1],
        },
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    (ROOT / ".tmp/final_state.json").write_text(json.dumps(result, indent=2) + "\n")
    print("FINAL_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
