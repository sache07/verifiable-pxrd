#!/usr/bin/env python3
"""Test one March-Dollase axis for the dominant scheelite phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "massicot_strain" / "massicot_strain.gpx"
OUTDIR = ROOT / ".tmp" / "texture_tests"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("h", type=int)
    parser.add_argument("k", type=int)
    parser.add_argument("l", type=int)
    args = parser.parse_args()
    axis = [args.h, args.k, args.l]
    label = "_".join(str(v) for v in axis)
    OUTDIR.mkdir(parents=True, exist_ok=True)
    output = OUTDIR / f"scheelite_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    hist = project.histogram(0)
    phase = project.phase("PbWO4_scheelite")
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = axis
    project.set_Controls("parmMin", 0.2, variable="0:0:MD")
    project.set_Controls("parmMax", 5.0, variable="0:0:MD")
    project.set_Controls("cycles", 12)
    project.save()
    for _ in range(2):
        project = G2sc.G2Project(str(output))
        project.refine(makeBack=False)
        project.save()
    project = G2sc.G2Project(str(output))
    hist = project.histogram(0)
    phase = project.phase("PbWO4_scheelite")
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    summary = {
        "axis": axis,
        "MD": pref[1],
        "Rwp_percent": hist.get_wR(),
        "chi_square": rvals["chisq"],
        "GOF": rvals["GOF"],
        "Nvars": rvals["Nvars"],
        "converged": rvals["converged"],
        "max_shift_over_esd": rvals["Max shft/sig"],
    }
    (OUTDIR / f"scheelite_{label}.json").write_text(json.dumps(summary, indent=2))
    print("TEXTURE_RESULT", json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
