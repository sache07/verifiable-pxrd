#!/usr/bin/env python3
"""Disable one phase and reconverge the common nuisance model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "full8" / "full8.gpx"
OUTDIR = ROOT / ".tmp" / "deletion_tests"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase_index", type=int)
    parser.add_argument("--passes", type=int, default=3)
    args = parser.parse_args()
    OUTDIR.mkdir(parents=True, exist_ok=True)
    seed = G2sc.G2Project(str(BASE))
    omitted = seed.phases()[args.phase_index].name
    output = OUTDIR / f"without_p{args.phase_index}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    hist = project.histogram(0)
    hap = project.phases()[args.phase_index].data["Histograms"][hist.name]
    hap["Use"] = False
    hap["Scale"][1] = False
    project.set_Controls("cycles", 12)
    project.save()
    for _ in range(args.passes):
        project = G2sc.G2Project(str(output))
        project.refine(makeBack=False)
        project.save()
    project = G2sc.G2Project(str(output))
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    raw = hist.ComputeMassFracs()
    active = {
        phase.name
        for phase in project.phases()
        if phase.data["Histograms"][hist.name]["Use"]
    }
    vals = {name: raw[name][0] for name in active}
    total = sum(vals.values())
    summary = {
        "omitted": omitted,
        "Rwp_percent": hist.get_wR(),
        "chi_square": rvals["chisq"],
        "GOF": rvals["GOF"],
        "Nvars": rvals["Nvars"],
        "converged": rvals["converged"],
        "max_shift_over_esd": rvals["Max shft/sig"],
        "fractions": {key: value / total for key, value in vals.items()},
    }
    (OUTDIR / f"without_p{args.phase_index}.json").write_text(
        json.dumps(summary, indent=2)
    )
    print("DELETE_RESULT", json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
