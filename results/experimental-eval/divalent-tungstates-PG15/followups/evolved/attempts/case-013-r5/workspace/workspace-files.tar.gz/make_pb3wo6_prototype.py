#!/usr/bin/env python3
"""Create a Pb3WO6 trial model by U6+ -> W6+ in COD 2310493."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/31/04/2310493.cif"
)
OUTPUT = ROOT / ".tmp" / "models" / "Pb3WO6_Pnma_prototype.cif"


def main() -> None:
    structure = Structure.from_file(SOURCE)
    structure.replace_species({"U": "W"})
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    CifWriter(structure, symprec=0.01).write_file(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    main()
