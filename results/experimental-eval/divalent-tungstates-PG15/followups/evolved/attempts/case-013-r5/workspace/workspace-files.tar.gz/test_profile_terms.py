#!/usr/bin/env python3
"""Challenge common profile terms from a neutral five-phase baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "clean5" / "clean5.gpx"
OUTDIR = ROOT / ".tmp" / "profile_tests"

CASES = {
    "baseline_replay": (),
    "shl": ("SH/L",),
    "u": ("U",),
    "u_shl": ("U", "SH/L"),
}


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    summaries = []
    for label, additions in CASES.items():
        path = OUTDIR / f"{label}.gpx"
        project = G2sc.G2Project(str(BASE), newgpx=str(path))
        hist = project.histogram(0)
        inst = hist.data["Instrument Parameters"][0]
        if "U" in additions:
            inst["U"][1] = 0.0
            project.set_Controls("parmMin", 0.0, variable=":0:U")
            project.set_Controls("parmMax", 200.0, variable=":0:U")
        if "SH/L" in additions:
            inst["SH/L"][1] = 0.002
            project.set_Controls("parmMin", 0.002, variable=":0:SH/L")
            project.set_Controls("parmMax", 0.2, variable=":0:SH/L")
        if additions:
            hist.set_refinements({"Instrument Parameters": list(additions)})
        project.set_Controls("cycles", 12)
        project.save()
        for _ in range(2):
            project.refine(makeBack=False)
        project.save()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        summary = {
            "case": label,
            "Rwp_percent": hist.get_wR(),
            "chi_square": rvals["chisq"],
            "GOF": rvals["GOF"],
            "Nvars": rvals["Nvars"],
            "converged": rvals["converged"],
            "max_shift_over_esd": rvals["Max shft/sig"],
            "profile": {
                key: {"value": inst[key][1], "refined": inst[key][2]}
                for key in ("U", "V", "W", "X", "Y", "SH/L")
            },
        }
        summaries.append(summary)
        print("PROFILE_RESULT", json.dumps(summary, sort_keys=True))
    (OUTDIR / "summary.json").write_text(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
