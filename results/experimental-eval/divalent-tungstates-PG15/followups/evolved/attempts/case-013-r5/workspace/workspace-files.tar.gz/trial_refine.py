#!/usr/bin/env python3
"""Build a small GSAS-II project for phase-inventory screening."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def prepare_inputs(outdir: Path) -> tuple[Path, Path]:
    outdir.mkdir(parents=True, exist_ok=True)
    raw = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    x = raw["two_theta_deg"]
    y = raw["intensity"]
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = outdir / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y, sigma)), fmt=("%.8f", "%.8g", "%.8g"))

    inst = outdir / "lab.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for lab Cu Kalpha reflection data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.30;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:0.0;V:0.0;W:2.0;X:10.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def neutralize_hap(phase, hist) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"] = [
        "isotropic",
        [10.0, 10.0, 1.0],
        [False, False, False],
        [0, 0, 1],
        [10.0, 10.0, 10.0, 0.0, 0.0, 0.0],
        [False] * 6,
    ]
    hap["Mustrain"] = [
        "isotropic",
        [0.0, 0.0, 1.0],
        [False, False, False],
        [0, 0, 1],
        [0.0 for _ in hap["Mustrain"][4]],
        [False for _ in hap["Mustrain"][5]],
    ]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def summarize(project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    out = {
        "label": label,
        "wR": hist.get_wR(),
        "residuals": hist.data["data"][0].copy(),
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) >= 2},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "scale": hap["Scale"][0],
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    print(json.dumps(out, default=str, indent=2))
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", default="trial")
    parser.add_argument("cifs", nargs="+")
    args = parser.parse_args()
    outdir = ROOT / ".tmp" / args.name
    xye, inst = prepare_inputs(outdir)
    gpx_path = outdir / f"{args.name}.gpx"
    project = G2sc.G2Project(newgpx=str(gpx_path))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.set_refinements(
        {
            "Limits": [10.05, 99.90],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 10,
                "coeffs": [600.0, -500.0, 250.0, -120.0, 60.0, -30.0, 15.0, -8.0, 4.0, -2.0],
            },
        }
    )
    for cif in args.cifs:
        phase = project.add_phase(cif, phasename=Path(cif).stem, histograms=[hist], fmthint="CIF")
        neutralize_hap(phase, hist)
        phase.data["Histograms"][hist.name]["Scale"] = [1.0, True]
    # Keep the sample scale fixed; all phase scales are varied.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    project.set_Controls("cycles", 8)
    project.save()

    # Establish background and scales first.
    project.refine(makeBack=False)
    summarize(project, "background_scales")

    # Add one common angular correction, then cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine(makeBack=False)
    summarize(project, "zero")
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine(makeBack=False)
    summarize(project, "cells")

    # Common nonnegative W/X profile; U, V and Y remain zero for screening.
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    project.refine(makeBack=False)
    summarize(project, "profile")
    project.save()


if __name__ == "__main__":
    main()
