#!/usr/bin/env python3
"""Clone, reopen, and replay a GSAS-II project to stable whole-range convergence."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--passes", type=int, default=4)
    args = parser.parse_args()
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(args.source, newgpx=str(output))
    project.set_Controls("cycles", 12)
    project.save()
    for _ in range(args.passes):
        # Reopen each pass to expose stale in-memory calculations or clamps.
        project = G2sc.G2Project(str(output))
        project.refine(makeBack=False)
        project.save()
    project = G2sc.G2Project(str(output))
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    inst = hist.data["Instrument Parameters"][0]
    summary = {
        "Rwp_percent": hist.get_wR(),
        "chi_square": rvals["chisq"],
        "GOF": rvals["GOF"],
        "Nvars": rvals["Nvars"],
        "converged": rvals["converged"],
        "max_shift_over_esd": rvals["Max shft/sig"],
        "zero": inst["Zero"][1],
        "U": inst["U"][1],
        "W": inst["W"][1],
        "X": inst["X"][1],
        "SH/L": inst["SH/L"][1],
        "fractions": {key: list(value) for key, value in hist.ComputeMassFracs().items()},
    }
    print("CONVERGED_RESULT", json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
