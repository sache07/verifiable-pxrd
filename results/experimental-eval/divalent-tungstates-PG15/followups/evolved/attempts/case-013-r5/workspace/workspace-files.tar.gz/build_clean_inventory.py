#!/usr/bin/env python3
"""Build and converge the selected five-phase inventory over the full range."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from trial_refine import neutralize_hap, prepare_inputs


ROOT = Path(__file__).resolve().parent
OUTDIR = ROOT / ".tmp" / "clean5"
SOURCES = [
    (
        "PbWO4_scheelite",
        Path(
            "<HOME>/.local/share/characterizagent/backends/dara/"
            "cod-filtered-2024/cif/9/00/98/9009811.cif"
        ),
    ),
    ("Pb2WO5_C2m_prototype", ROOT / ".tmp" / "models" / "Pb2WO5_start.cif"),
    (
        "WO3_monoclinic",
        Path(
            "<HOME>/.local/share/characterizagent/backends/dara/"
            "cod-filtered-2024/cif/1/52/89/1528915.cif"
        ),
    ),
    (
        "PbO_massicot",
        Path(
            "<HOME>/.local/share/characterizagent/backends/dara/"
            "cod-filtered-2024/cif/2/31/04/2310433.cif"
        ),
    ),
    (
        "PbO_alpha_long_period",
        Path(
            "<HOME>/.local/share/characterizagent/backends/dara/"
            "cod-filtered-2024/cif/1/53/36/1533609.cif"
        ),
    ),
]


def summarize(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    fractions = hist.ComputeMassFracs()
    total = sum(value[0] for value in fractions.values())
    return {
        "Rwp_percent": hist.get_wR(),
        "fractions": {key: value[0] / total for key, value in fractions.items()},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")
        },
    }


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    xye, inst = prepare_inputs(OUTDIR)
    raw = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    project = G2sc.G2Project(newgpx=str(OUTDIR / "clean5.gpx"))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.set_refinements(
        {
            "Limits": [float(raw["two_theta_deg"][0]), float(raw["two_theta_deg"][-1])],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 10,
                "coeffs": [
                    650.0,
                    -580.0,
                    390.0,
                    -225.0,
                    130.0,
                    -75.0,
                    45.0,
                    -32.0,
                    34.0,
                    -12.0,
                ],
            },
        }
    )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    for name, cif in SOURCES:
        phase = project.add_phase(
            str(cif), phasename=name, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase, hist)
        phase.data["Histograms"][hist.name]["Scale"] = [0.1, True]
        phase.set_refinements({"Cell": False})

    project.set_Controls("cycles", 12)
    project.save()

    # Re-establish nuisance terms after the source/inventory change.
    for _ in range(2):
        project.refine(makeBack=False)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine(makeBack=False)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    for _ in range(2):
        project.refine(makeBack=False)
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    for _ in range(3):
        project.refine(makeBack=False)
    project.save()

    summary = summarize(project)
    (OUTDIR / "summary.json").write_text(json.dumps(summary, indent=2))
    print("CLEAN_RESULT", json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
