#!/usr/bin/env python3
"""Build the physically screened eight-phase inventory from source CIFs."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from trial_refine import neutralize_hap, prepare_inputs


ROOT = Path(__file__).resolve().parent
OUTDIR = ROOT / ".tmp" / "clean8"
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
SOURCES = [
    ("PbWO4_scheelite", COD / "9/00/98/9009811.cif"),
    ("Pb2WO5_C2m_prototype", ROOT / ".tmp/models/Pb2WO5_start.cif"),
    ("WO3_monoclinic", COD / "1/52/89/1528915.cif"),
    ("PbO_massicot", COD / "2/31/04/2310433.cif"),
    ("PbO_alpha_long_period", COD / "1/53/36/1533609.cif"),
    ("Pb2O3_monoclinic_tentative", ROOT / ".tmp/models/Pb2O3_corrected.cif"),
    ("Pb3WO6_Pnma_prototype", ROOT / ".tmp/models/Pb3WO6_Pnma_prototype.cif"),
    ("Pb3O4_minium", COD / "1/53/79/1537983.cif"),
]


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    xye, instfile = prepare_inputs(OUTDIR)
    raw = np.genfromtxt(ROOT / "inputs/pattern.csv", delimiter=",", names=True)
    project = G2sc.G2Project(newgpx=str(OUTDIR / "clean8.gpx"))
    hist = project.add_powder_histogram(str(xye), str(instfile), fmthint="xye")
    hist.set_refinements(
        {
            "Limits": [float(raw["two_theta_deg"][0]), float(raw["two_theta_deg"][-1])],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 10,
                "coeffs": [650, -580, 390, -225, 130, -75, 45, -32, 34, -12],
            },
        }
    )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    for index, (name, cif) in enumerate(SOURCES):
        phase = project.add_phase(
            str(cif), phasename=name, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase, hist)
        phase.data["Histograms"][hist.name]["Scale"] = [0.1, True]
        phase.set_refinements({"Cell": False})
        project.set_Controls("parmMin", 1e-12, variable=f"{index}:0:Scale")

    project.set_Controls("parmMin", 0.0, variable=":0:W")
    project.set_Controls("parmMin", 0.0, variable=":0:X")
    project.set_Controls("parmMin", 0.002, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.2, variable=":0:SH/L")
    project.set_Controls("cycles", 12)
    project.save()

    for _ in range(2):
        project.refine(makeBack=False)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine(makeBack=False)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    for _ in range(3):
        project.refine(makeBack=False)
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    for _ in range(3):
        project.refine(makeBack=False)
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    for _ in range(3):
        project.refine(makeBack=False)
    project.save()

    # Reopen once and replay to verify exact project state.
    project = G2sc.G2Project(str(OUTDIR / "clean8.gpx"))
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    inst = hist.data["Instrument Parameters"][0]
    summary = {
        "Rwp_percent": hist.get_wR(),
        "GOF": rvals["GOF"],
        "chi_square": rvals["chisq"],
        "max_shift_over_esd": rvals["Max shft/sig"],
        "fractions": {key: list(value) for key, value in hist.ComputeMassFracs().items()},
        "profile": {key: inst[key][1] for key in ("U", "W", "X", "SH/L", "Zero")},
    }
    (OUTDIR / "summary.json").write_text(json.dumps(summary, indent=2))
    print("CLEAN8_RESULT", json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
