#!/usr/bin/env python3
"""Compare nested Pb-W-O phase inventories under one shared nuisance model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import neutralize_hap


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "pb2wo5_5" / "pb2wo5_5.gpx"
PBO_SUPER = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/53/36/1533609.cif"
)

CONFIGS = {
    "full_five": {"disable": []},
    "no_litharge": {"disable": ["9012700"]},
    "no_massicot": {"disable": ["2310433"]},
    "no_PbO": {"disable": ["9012700", "2310433"]},
    "no_WO3": {"disable": ["1528915"]},
    "no_Pb2WO5": {"disable": ["Pb2WO5_start"]},
    "super_for_litharge": {"disable": ["9012700"], "add": PBO_SUPER},
    "super_only_PbO": {
        "disable": ["9012700", "2310433"],
        "add": PBO_SUPER,
    },
}


def active_fractions(project) -> dict[str, float]:
    hist = project.histogram(0)
    raw = hist.ComputeMassFracs()
    active = {
        p.name
        for p in project.phases()
        if p.data["Histograms"][hist.name]["Use"]
    }
    vals = {name: raw[name][0] for name in active if name in raw}
    total = sum(vals.values())
    return {name: value / total for name, value in vals.items()}


def main() -> None:
    outdir = ROOT / ".tmp" / "inventory_comparisons"
    outdir.mkdir(parents=True, exist_ok=True)
    summaries = []
    for label, config in CONFIGS.items():
        project = G2sc.G2Project(str(BASE), newgpx=str(outdir / f"{label}.gpx"))
        hist = project.histogram(0)
        for name in config["disable"]:
            hap = project.phase(name).data["Histograms"][hist.name]
            hap["Use"] = False
            hap["Scale"][1] = False
        project.set_Controls("cycles", 12)

        if "add" in config:
            phase = project.add_phase(
                str(config["add"]),
                phasename="candidate_1533609",
                histograms=[hist],
                fmthint="CIF",
            )
            neutralize_hap(phase, hist)
            phase.data["Histograms"][hist.name]["Scale"] = [0.05, True]
            phase.set_refinements({"Cell": False})
            project.save()
            for _ in range(2):
                project.refine(makeBack=False)
            phase.set_refinements({"Cell": True})

        for _ in range(3):
            project.refine(makeBack=False)
        project.save()
        inst = hist.data["Instrument Parameters"][0]
        summary = {
            "label": label,
            "wR": hist.get_wR(),
            "fractions": active_fractions(project),
            "zero": inst["Zero"][1],
            "W": inst["W"][1],
            "X": inst["X"][1],
        }
        summaries.append(summary)
        print("INVENTORY_RESULT", json.dumps(summary, sort_keys=True))
    (outdir / "summary.json").write_text(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
