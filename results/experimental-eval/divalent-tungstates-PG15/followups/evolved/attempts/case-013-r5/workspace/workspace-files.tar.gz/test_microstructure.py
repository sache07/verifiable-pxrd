#!/usr/bin/env python3
"""Test isotropic phase size and microstrain one phase at a time."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "profile_tests" / "shl.gpx"
OUTDIR = ROOT / ".tmp" / "microstructure_tests"


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    seed = G2sc.G2Project(str(BASE))
    phase_names = [phase.name for phase in seed.phases()]
    summaries = []
    for phase_name in phase_names:
        for term in ("size", "strain"):
            label = f"{phase_name}__{term}"
            project = G2sc.G2Project(
                str(BASE), newgpx=str(OUTDIR / f"{label}.gpx")
            )
            hist = project.histogram(0)
            phase = project.phase(phase_name)
            hap = phase.data["Histograms"][hist.name]
            if term == "size":
                phase.set_HAP_refinements(
                    {"Size": {"type": "isotropic", "value": 10.0, "refine": True}}
                )
            else:
                hap["Mustrain"][1][0] = 0.0
                phase.set_HAP_refinements(
                    {"Mustrain": {"type": "isotropic", "refine": True}}
                )
            project.set_Controls("cycles", 12)
            project.save()
            for _ in range(2):
                project.refine(makeBack=False)
            project.save()
            rvals = project.data["Covariance"]["data"]["Rvals"]
            summary = {
                "case": label,
                "phase": phase_name,
                "term": term,
                "Rwp_percent": hist.get_wR(),
                "chi_square": rvals["chisq"],
                "GOF": rvals["GOF"],
                "Nvars": rvals["Nvars"],
                "converged": rvals["converged"],
                "max_shift_over_esd": rvals["Max shft/sig"],
                "size_micrometre": hap["Size"][1][0],
                "microstrain": hap["Mustrain"][1][0],
                "vary_list": project.data["Covariance"]["data"]["varyList"],
            }
            summaries.append(summary)
            print("MICRO_RESULT", json.dumps(summary, sort_keys=True))
    (OUTDIR / "summary.json").write_text(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
