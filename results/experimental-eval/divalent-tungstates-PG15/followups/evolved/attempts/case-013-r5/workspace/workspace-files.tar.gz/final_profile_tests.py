#!/usr/bin/env python3
"""Final common-profile ablations on the selected inventory."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp/massicot_strain/massicot_strain.gpx"
OUTDIR = ROOT / ".tmp/final_profile_tests"


def run(label: str) -> dict:
    output = OUTDIR / f"{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    if label == "no_shl":
        inst["SH/L"][1] = 0.002
        inst["SH/L"][2] = False
        passes = 4
    elif label == "u_nonnegative":
        inst["U"][1] = 0.1
        inst["U"][2] = True
        project.set_Controls("parmMin", 0.0, variable=":0:U")
        project.set_Controls("parmMax", 200.0, variable=":0:U")
        passes = 3
    else:
        raise ValueError(label)
    project.set_Controls("cycles", 12)
    project.save()
    for _ in range(passes):
        project = G2sc.G2Project(str(output))
        project.refine(makeBack=False)
        project.save()
    project = G2sc.G2Project(str(output))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "case": label,
        "Rwp_percent": hist.get_wR(),
        "chi_square": rvals["chisq"],
        "GOF": rvals["GOF"],
        "Nvars": rvals["Nvars"],
        "max_shift_over_esd": rvals["Max shft/sig"],
        "profile": {key: inst[key][1] for key in ("U", "W", "X", "SH/L")},
        "frozen": {
            key: [str(item) for item in value]
            for key, value in project.data["Controls"]["data"].get(
                "parmFrozen", {}
            ).items()
        },
    }


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    results = [run("no_shl"), run("u_nonnegative")]
    (OUTDIR / "summary.json").write_text(json.dumps(results, indent=2))
    for result in results:
        print("FINAL_PROFILE_RESULT", json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
