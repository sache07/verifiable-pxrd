#!/usr/bin/env python3
"""Run one bounded phase-broadening challenge in a fresh GSAS-II process."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
DEFAULT_BASE = ROOT / ".tmp" / "clean8_converged" / "clean8_converged.gpx"
OUTDIR = ROOT / ".tmp" / "microstructure_clean8"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase_index", type=int)
    parser.add_argument("term", choices=("size", "strain"))
    parser.add_argument("--base", default=str(DEFAULT_BASE))
    args = parser.parse_args()

    OUTDIR.mkdir(parents=True, exist_ok=True)
    base = Path(args.base)
    seed = G2sc.G2Project(str(base))
    phase_name = seed.phases()[args.phase_index].name
    label = f"p{args.phase_index}_{args.term}"
    project = G2sc.G2Project(
        str(base), newgpx=str(OUTDIR / f"{label}.gpx")
    )
    hist = project.histogram(0)
    phase = project.phases()[args.phase_index]
    hap = phase.data["Histograms"][hist.name]
    if args.term == "size":
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 9.9, "refine": True}}
        )
        variable = f"{args.phase_index}:0:Size;i"
        project.set_Controls("parmMin", 0.01, variable=variable)
        project.set_Controls("parmMax", 10.0, variable=variable)
    else:
        hap["Mustrain"][1][0] = 1.0
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
        variable = f"{args.phase_index}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 10000.0, variable=variable)

    project.set_Controls("cycles", 12)
    project.save()
    project.refine(makeBack=False)
    project.save()
    # Replay after reopening so bound clamps cannot leave a stale profile.
    project = G2sc.G2Project(str(OUTDIR / f"{label}.gpx"))
    project.refine(makeBack=False)
    project.save()
    project = G2sc.G2Project(str(OUTDIR / f"{label}.gpx"))
    hist = project.histogram(0)
    phase = project.phases()[args.phase_index]
    hap = phase.data["Histograms"][hist.name]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    summary = {
        "case": label,
        "phase": phase_name,
        "term": args.term,
        "Rwp_percent": hist.get_wR(),
        "chi_square": rvals["chisq"],
        "GOF": rvals["GOF"],
        "Nvars": rvals["Nvars"],
        "converged": rvals["converged"],
        "max_shift_over_esd": rvals["Max shft/sig"],
        "size_micrometre": hap["Size"][1][0],
        "microstrain": hap["Mustrain"][1][0],
        "frozen": {
            key: [str(item) for item in value]
            for key, value in project.data["Controls"]["data"].get(
                "parmFrozen", {}
            ).items()
        },
    }
    (OUTDIR / f"{label}.json").write_text(json.dumps(summary, indent=2))
    print("MICRO_BOUNDED_RESULT", json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
