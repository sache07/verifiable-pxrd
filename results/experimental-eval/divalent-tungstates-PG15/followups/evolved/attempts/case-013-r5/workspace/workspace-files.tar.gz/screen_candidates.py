#!/usr/bin/env python3
"""Re-challenge a converged GSAS-II phase inventory with candidate CIFs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import neutralize_hap


ROOT = Path(__file__).resolve().parent


def compact_summary(project, candidate_name: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    return {
        "candidate": candidate_name,
        "wR": hist.get_wR(),
        "zero": inst["Zero"][1],
        "W": inst["W"][1],
        "X": inst["X"][1],
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "scales": {
            p.name: p.data["Histograms"][hist.name]["Scale"][0]
            for p in project.phases()
        },
        "cells": {p.name: p.get_cell() for p in project.phases()},
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base_gpx")
    parser.add_argument("cifs", nargs="+")
    parser.add_argument("--outdir", default=".tmp/screens")
    args = parser.parse_args()
    outdir = ROOT / args.outdir
    outdir.mkdir(parents=True, exist_ok=True)

    summaries = []
    for cif_arg in args.cifs:
        cif = Path(cif_arg).resolve()
        name = cif.stem
        gpx_out = outdir / f"plus_{name}.gpx"
        project = G2sc.G2Project(args.base_gpx, newgpx=str(gpx_out))
        hist = project.histogram(0)
        phase = project.add_phase(
            str(cif), phasename=f"candidate_{name}", histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase, hist)
        phase.data["Histograms"][hist.name]["Scale"] = [0.01, True]
        # Respect scale-before-cell screening: first ask whether the source
        # pattern has a reproducible positive contribution at its native cell.
        phase.set_refinements({"Cell": False})
        project.set_Controls("cycles", 12)
        project.save()
        for _ in range(2):
            project.refine(makeBack=False)
        candidate_scale = phase.data["Histograms"][hist.name]["Scale"][0]
        if candidate_scale > 1e-5:
            phase.set_refinements({"Cell": True})
            for _ in range(2):
                project.refine(makeBack=False)
        project.save()
        summary = compact_summary(project, name)
        summaries.append(summary)
        print("SCREEN_RESULT", json.dumps(summary, sort_keys=True))

    (outdir / "summary.json").write_text(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
