#!/usr/bin/env python3
"""Compare symmetry-distinct March-Dollase axes for scheelite SrWO4."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
AXES = {
    "001": [0, 0, 1],
    "100": [1, 0, 0],
    "110": [1, 1, 0],
    "101": [1, 0, 1],
    "112": [1, 1, 2],
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default="cand_WO3_mono_1528915.gpx")
    parser.add_argument("--axis", choices=tuple(AXES), default=None)
    parser.add_argument("--tag", default="")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    results = []
    axes = AXES.items() if args.axis is None else [(args.axis, AXES[args.axis])]
    for label, axis in axes:
        np.seterr(all="warn")
        tag = f"_{args.tag}" if args.tag else ""
        outfile = HERE / f"texture{tag}_{label}.gpx"
        project = G2sc.G2Project(
            str(HERE / args.base), newgpx=str(outfile)
        )
        hist = project.histogram(0)
        phase = project.phase("SrWO4_scheelite")
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = axis
        project.data["Controls"]["data"]["max cyc"] = 16
        project.save()
        project.refine()
        project.save()
        reopened = G2sc.G2Project(str(outfile))
        reopened.refine()
        reopened.save()
        h = reopened.histogram(0)
        p = reopened.phase("SrWO4_scheelite")
        final_po = p.data["Histograms"][h.name]["Pref.Ori."]
        result = {
            "axis": axis,
            "Rwp_percent": h.get_wR(),
            "MD": final_po[1],
            "scales": {
                ph.name: ph.data["Histograms"][h.name]["Scale"][0]
                for ph in reopened.phases()
            },
            "profile": {
                key: h.data["Instrument Parameters"][0][key][1]
                for key in ("U", "W", "X", "SH/L")
            },
            "shift_micrometers": h.data["Sample Parameters"]["Shift"][0],
        }
        results.append(result)
        print(json.dumps(result, indent=2))
    summary_name = f"texture_{args.tag}_summary.json" if args.tag else "texture_summary.json"
    (HERE / summary_name).write_text(
        json.dumps(results, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
