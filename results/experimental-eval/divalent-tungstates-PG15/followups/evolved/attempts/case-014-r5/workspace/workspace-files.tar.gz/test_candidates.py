#!/usr/bin/env python3
"""Reversible candidate-phase challenges against the common baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)

CANDIDATES = {
    "WO3_mono_1528915": "1528915",
    "WO3_mono_2311041": "2311041",
    "WO3_ortho_2107312": "2107312",
    "WO3_triclinic_2106293": "2106293",
    "WO3_oldmono_1010618": "1010618",
    "WO3_tet_1521532": "1521532",
    "SrCO3_9008198": "9008198",
    "Sr3W2O9_2311977": "2311977",
    "SrO_7200689": "7200689",
    "SrWO4_HP_1546037": "1546037",
}


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(phase, hist) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.1, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0e6
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def state(project, label, candidate) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    phases = []
    for phase in project.phases():
        phases.append(
            {
                "name": phase.name,
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "cell": phase.get_cell(),
            }
        )
    return {
        "candidate": candidate,
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "shift_micrometers": hist.data["Sample Parameters"]["Shift"][0],
        "profile": {key: inst[key][1] for key in ("U", "W", "X", "SH/L")},
        "phases": phases,
    }


def main() -> None:
    G2sc.SetPrintLevel("warn")
    summaries = []
    for label, cod_id in CANDIDATES.items():
        out = HERE / f"cand_{label}.gpx"
        project = G2sc.G2Project(str(HERE / "work_one.gpx"), newgpx=str(out))
        hist = project.histogram(0)
        hist.data["Sample Parameters"]["Scale"] = [1.0, False]
        phase = project.add_phase(
            str(cif_path(cod_id)),
            phasename=label,
            histograms=[hist],
            fmthint="CIF",
        )
        neutralize(phase, hist)
        project.data["Controls"]["data"]["max cyc"] = 16
        project.save()

        # Challenge scale under the inherited common nuisance model.
        project.refine()
        scale_only = state(project, "scale_fixed_cell", label)

        # Then reconverge all cells, scales, background, displacement, profile.
        phase.set_refinements({"Cell": True})
        project.refine()
        project.save()
        reopened = G2sc.G2Project(str(out))
        reopened.refine()
        reopened.save()
        final = state(reopened, "cell_reopened_replay", label)
        summaries.append({"scale_only": scale_only, "final": final})
        print(json.dumps(summaries[-1], indent=2, default=float))

    (HERE / "candidate_summary.json").write_text(
        json.dumps(summaries, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
