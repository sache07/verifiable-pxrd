#!/usr/bin/env python3
"""Challenge one third-phase candidate in a fresh GSAS-II process."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("cif")
    parser.add_argument(
        "--base", default="cand_WO3_mono_1528915.gpx",
        help="GSAS-II project used as the common baseline",
    )
    args = parser.parse_args()
    np.seterr(all="warn")
    G2sc.SetPrintLevel("warn")

    base_label = Path(args.base).stem
    out = HERE / f"watch_{base_label}_{args.label}.gpx"
    project = G2sc.G2Project(
        str((HERE / args.base).resolve()), newgpx=str(out)
    )
    hist = project.histogram(0)
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    phase = project.add_phase(
        str(Path(args.cif).resolve()),
        phasename=args.label,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.03, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["max cyc"] = 16
    project.save()

    project.refine()
    fixed_cell = {
        "Rwp_percent": project.histogram(0).get_wR(),
        "scale": project.phase(args.label).data["Histograms"][hist.name]["Scale"][0],
    }
    phase.set_refinements({"Cell": True})
    project.refine()
    project.save()
    reopened = G2sc.G2Project(str(out))
    reopened.refine()
    reopened.save()
    h = reopened.histogram(0)
    p = reopened.phase(args.label)
    result = {
        "label": args.label,
        "fixed_cell": fixed_cell,
        "final_Rwp_percent": h.get_wR(),
        "scale": p.data["Histograms"][h.name]["Scale"][0],
        "cell": p.get_cell(),
        "all_scales": {
            ph.name: ph.data["Histograms"][h.name]["Scale"][0]
            for ph in reopened.phases()
        },
        "profile": {
            key: h.data["Instrument Parameters"][0][key][1]
            for key in ("U", "W", "X", "SH/L")
        },
        "shift_micrometers": h.data["Sample Parameters"]["Shift"][0],
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
