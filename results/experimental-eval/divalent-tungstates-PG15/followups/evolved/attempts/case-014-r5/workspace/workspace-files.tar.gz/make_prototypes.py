#!/usr/bin/env python3
"""Build explicitly justified isovalent Sr-W-O analogue structures."""

from __future__ import annotations

from pathlib import Path

from pymatgen.io.cif import CifParser, CifWriter


HERE = Path(__file__).resolve().parent
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)

PROTOTYPES = {
    # U6+ -> W6+ on the same Sr3M O6 framework.
    "prototype_Sr3WO6_from_Sr3UO6.cif": ("2001752", {"U": "W"}),
    # Alternate Sr3UO6 polymorph (P21) for a symmetry/source challenge.
    "prototype_Sr3WO6_from_Sr3UO6_P21.cif": ("2310471", {"U": "W"}),
    # Same nominal B cation; Ba2+ -> Sr2+ tests the low-symmetry A-site analogue.
    "prototype_Sr3WO6_from_Ba3WO6.cif": ("1534803", {"Ba": "Sr"}),
    # Same W6+ chemistry; Ca2+ -> Sr2+ tests the P21/n alkaline-earth analogue.
    "prototype_Sr3WO6_from_Ca3WO6.cif": ("1563081", {"Ca": "Sr"}),
    # Ba2+ -> Sr2+ and Re6+ -> W6+ in the A2MO5 framework.
    "prototype_Sr2WO5_from_Ba2ReO5.cif": (
        "1529756",
        {"Ba": "Sr", "Re": "W"},
    ),
    # Cr6+ -> W6+ in the SrM2O7 framework.
    "prototype_SrW2O7_from_SrCr2O7.cif": ("1542062", {"Cr": "W"}),
}


def source_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    for output, (cod_id, substitutions) in PROTOTYPES.items():
        structure = CifParser(source_path(cod_id)).parse_structures(
            primitive=False
        )[0]
        structure.replace_species(substitutions)
        CifWriter(structure, symprec=0.01).write_file(HERE / output)
        print(output, structure.composition.reduced_formula, structure.get_space_group_info())


if __name__ == "__main__":
    main()
