#!/usr/bin/env python3
"""Reversible tests of dominant-phase structural terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
BASE = "watch_watch_Sr3W2O9_Sr3WO6.gpx"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("trial", choices=("heavy_u", "all_u", "oxygen_xyz", "polar_fixed_1"))
    args = parser.parse_args()
    np.seterr(all="warn")
    G2sc.SetPrintLevel("warn")

    out = HERE / f"atom_{args.trial}.gpx"
    project = G2sc.G2Project(str(HERE / BASE), newgpx=str(out))
    phase = project.phase("SrWO4_scheelite")
    if args.trial == "heavy_u":
        phase.set_refinements({"Atoms": {"Sr": "U", "W": "U"}})
    elif args.trial == "all_u":
        phase.set_refinements({"Atoms": {"all": "U"}})
    elif args.trial == "oxygen_xyz":
        phase.set_refinements({"Atoms": {"O": "X"}})
    elif args.trial == "polar_fixed_1":
        inst = project.histogram(0).data["Instrument Parameters"][0]
        inst["Polariz."][1] = 1.0
        inst["Polariz."][2] = False

    project.data["Controls"]["data"]["max cyc"] = 16
    project.save()
    project.refine()
    project.save()
    reopened = G2sc.G2Project(str(out))
    reopened.refine()
    reopened.save()

    hist = reopened.histogram(0)
    result = {
        "trial": args.trial,
        "Rwp_percent": hist.get_wR(),
        "polarization": hist.data["Instrument Parameters"][0]["Polariz."],
        "atoms": [],
    }
    for atom in reopened.phase("SrWO4_scheelite").atoms():
        result["atoms"].append({
            "label": atom.label,
            "coordinates": atom.coordinates,
            "adp_flag": atom.adp_flag,
            "adp": atom.ADP,
            "refinement_flags": atom.refinement_flags,
        })
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
