#!/usr/bin/env python3
"""Build the physically screened provisional final GSAS-II project."""

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "replace_Sr3WO6_SrU_P21.gpx"
OUTPUT = HERE / "provisional_final.gpx"


def main() -> None:
    np.seterr(all="warn")
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    hist = project.histogram(0)

    # Retain only the screened common specimen/instrument model.
    inst = hist.data["Instrument Parameters"][0]
    inst["Polariz."] = [0.5, 0.5, False]
    inst["U"] = [0.0, 0.0, False]
    inst["V"] = [0.0, 0.0, False]
    inst["Y"] = [0.0, 0.0, False]
    inst["Z"] = [0.0, 0.0, False]
    inst["SH/L"] = [0.002, 0.002, False]
    inst["W"][2] = True
    inst["X"][2] = True
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"][1] = True
    sample["Transparency"] = [0.0, False]
    sample["Shift"][1] = True

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        if phase.name != "WO3_mono_1528915":
            # 10 micrometres is the GSAS-II neutral upper limit here.
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 10.0
            hap["Size"][2] = [False, False, False]
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]

    project.data["Controls"]["data"]["max cyc"] = 16
    project.save()
    project.refine()
    project.save()
    reopened = G2sc.G2Project(str(OUTPUT))
    reopened.refine()
    reopened.save()
    print("Rwp", reopened.histogram(0).get_wR())
    for phase in reopened.phases():
        hap = phase.data["Histograms"][reopened.histogram(0).name]
        print(phase.name, "scale", hap["Scale"][0], "size", hap["Size"][1][0])


if __name__ == "__main__":
    main()
