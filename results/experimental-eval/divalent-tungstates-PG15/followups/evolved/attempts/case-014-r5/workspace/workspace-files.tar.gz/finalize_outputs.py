#!/usr/bin/env python3
"""Replay the accepted model, save final.gpx, and export exact profiles/CIFs."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "combined_profile.gpx"
FINAL = HERE / "final.gpx"

EXPORTS = {
    "SrWO4_scheelite": "phase_SrWO4.cif",
    "WO3_mono_1528915": "phase_WO3.cif",
    "Sr3W2O9": "phase_Sr3W2O9.cif",
    "SrO_recheck": "phase_SrO.cif",
    "Sr3WO6_SrU_P21": "phase_Sr3WO6_tentative.cif",
}


def main() -> None:
    np.seterr(all="warn")
    G2sc.SetPrintLevel("warn")

    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    project.data["Controls"]["data"]["max cyc"] = 16
    project.save()
    project.refine()
    project.save()

    # Reopen and replay the complete range so exports exactly match final.gpx.
    project = G2sc.G2Project(str(FINAL))
    project.refine()
    project.save()
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)

    for phase_name, filename in EXPORTS.items():
        project.phase(phase_name).export_CIF(str(HERE / filename))

    x, y_obs, weight, y_calc, y_bkg, y_diff = hist.data["data"][1]
    with (HERE / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            (
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "background_counts",
                "difference_counts",
                "weight",
            )
        )
        writer.writerows(
            zip(
                np.asarray(x, dtype=float),
                np.asarray(y_obs, dtype=float),
                np.asarray(y_calc, dtype=float),
                np.asarray(y_bkg, dtype=float),
                np.asarray(y_diff, dtype=float),
                np.asarray(weight, dtype=float),
            )
        )

    mass_fracs = hist.ComputeMassFracs()
    hstats = hist.data["data"][0]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    summary = {
        "fit": {
            "Rwp_percent": hstats["wR"],
            "Rp_percent": hstats["R"],
            "Rexp_percent": hstats["wRmin"],
            "goodness_of_fit": rvals["GOF"],
            "chi_square": rvals["chisq"],
            "Durbin_Watson": hstats["Durbin-Watson"],
            "Nobs": rvals["Nobs"],
            "Nvars": rvals["Nvars"],
            "converged": rvals["converged"],
            "max_shift_over_esd": rvals["Max shft/sig"],
            "two_theta_min_deg": float(x[0]),
            "two_theta_max_deg": float(x[-1]),
        },
        "instrument": {
            "W": inst["W"][1],
            "X": inst["X"][1],
            "polarization": inst["Polariz."][1],
            "SH_over_L": inst["SH/L"][1],
            "specimen_shift_micrometers": sample["Shift"][0],
            "surface_roughness_B": sample["SurfRoughB"][0],
        },
        "phases": [],
        "background": {
            "function": hist.data["Background"][0][0],
            "terms": hist.data["Background"][0][2],
            "min_counts": float(np.min(y_bkg)),
            "max_counts": float(np.max(y_bkg)),
        },
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        frac, frac_esd = mass_fracs[phase.name]
        p_id = phase.data["pId"]
        summary["phases"].append(
            {
                "project_name": phase.name,
                "cif": EXPORTS[phase.name],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "weight_fraction": frac,
                "weight_fraction_esd_statistical": frac_esd,
                "size_micrometers": hap["Size"][1][0],
                "microstrain_ppm": hap["Mustrain"][1][0],
                "Rf_percent": hstats.get(f"{p_id}:0:Rf"),
                "Rf2_percent": hstats.get(f"{p_id}:0:Rf^2"),
                "Nref": hstats.get(f"{p_id}:0:Nref"),
            }
        )
    print(json.dumps(summary, indent=2, default=float))


if __name__ == "__main__":
    main()
