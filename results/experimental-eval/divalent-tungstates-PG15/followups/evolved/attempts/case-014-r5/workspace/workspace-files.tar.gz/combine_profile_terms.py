#!/usr/bin/env python3
"""Combine only the replay-stable minor-phase strain terms."""

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent


def main() -> None:
    np.seterr(all="warn")
    G2sc.SetPrintLevel("warn")
    out = HERE / "combined_profile.gpx"
    p = G2sc.G2Project(str(HERE / "provisional_final.gpx"), newgpx=str(out))
    h = p.histogram(0)
    for name, start in (("Sr3W2O9", 5290.0), ("Sr3WO6_SrU_P21", 7340.0)):
        hap = p.phase(name).data["Histograms"][h.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = start
        hap["Mustrain"][2] = [True, False, False]
    p.data["Controls"]["data"]["max cyc"] = 16
    p.save()
    p.refine()
    p.save()
    q = G2sc.G2Project(str(out))
    q.refine()
    q.save()
    h = q.histogram(0)
    print("Rwp", h.get_wR())
    for ph in q.phases():
        hap = ph.data["Histograms"][h.name]
        print(ph.name, "scale", hap["Scale"][0], "strain", hap["Mustrain"][1][0])


if __name__ == "__main__":
    main()
