#!/usr/bin/env python3
"""Replay a GSAS-II project repeatedly and report convergence."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("--cycles", type=int, default=6)
    args = parser.parse_args()
    np.seterr(all="warn")
    G2sc.SetPrintLevel("warn")
    path = Path(args.project).resolve()
    p = G2sc.G2Project(str(path))
    p.data["Controls"]["data"]["max cyc"] = 16
    for cycle in range(1, args.cycles + 1):
        p.refine()
        p.save()
        h = p.histogram(0)
        cov = p.data.get("Covariance", {}).get("data", {})
        result = {
            "cycle": cycle,
            "Rwp_percent": h.get_wR(),
            "last_shift_over_esd": cov.get("Lastshft"),
            "phases": {
                ph.name: {
                    "scale": ph.data["Histograms"][h.name]["Scale"][0],
                    "cell": ph.get_cell(),
                }
                for ph in p.phases()
            },
        }
        print(json.dumps(result, default=float))


if __name__ == "__main__":
    main()
