#!/usr/bin/env python3
"""Replace one provisional phase and compare physical analogue records."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("cif")
    parser.add_argument("--remove", default="Sr3WO6")
    parser.add_argument(
        "--base",
        default="watch_term_WO3_mono_1528915_size_SrO_recheck.gpx",
    )
    args = parser.parse_args()
    np.seterr(all="warn")
    G2sc.SetPrintLevel("warn")

    out = HERE / f"replace_{args.label}.gpx"
    project = G2sc.G2Project(str(HERE / args.base), newgpx=str(out))
    hist = project.histogram(0)
    project.data["Phases"].pop(args.remove)
    hist.data["Reflection Lists"].pop(args.remove, None)
    for name_tree in project.names:
        if name_tree and name_tree[0] == "Phases":
            name_tree.remove(args.remove)
    project.data["Controls"]["data"]["max cyc"] = 16
    project.save()
    project.refine()
    removed_rwp = project.histogram(0).get_wR()

    phase = project.add_phase(
        str(Path(args.cif).resolve()),
        phasename=args.label,
        histograms=[project.histogram(0)],
        fmthint="CIF",
    )
    hist = project.histogram(0)
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.03, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0e6
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    project.save()
    project.refine()
    fixed = {
        "Rwp_percent": project.histogram(0).get_wR(),
        "scale": project.phase(args.label).data["Histograms"][hist.name]["Scale"][0],
    }

    project.phase(args.label).set_refinements({"Cell": True})
    project.refine()
    project.save()
    reopened = G2sc.G2Project(str(out))
    reopened.refine()
    reopened.save()
    h = reopened.histogram(0)
    p = reopened.phase(args.label)
    result = {
        "label": args.label,
        "Rwp_without_replaced_phase_percent": removed_rwp,
        "fixed_cell": fixed,
        "final_Rwp_percent": h.get_wR(),
        "scale": p.data["Histograms"][h.name]["Scale"][0],
        "cell": p.get_cell(),
        "all_scales": {
            ph.name: ph.data["Histograms"][h.name]["Scale"][0]
            for ph in reopened.phases()
        },
    }
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
