#!/usr/bin/env python3
"""Test one profile, broadening, or polarization term reversibly."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
BASE = "watch_watch_Sr3W2O9_Sr3WO6.gpx"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("trial")
    parser.add_argument("--base", default=BASE)
    args = parser.parse_args()
    np.seterr(all="warn")
    G2sc.SetPrintLevel("warn")
    out = HERE / f"term_{args.trial}.gpx"
    project = G2sc.G2Project(str(HERE / args.base), newgpx=str(out))
    hist = project.histogram(0)

    if args.trial == "polarization":
        inst = hist.data["Instrument Parameters"][0]
        inst["Polariz."][1] = 0.5
        inst["Polariz."][2] = True
    elif args.trial == "polar_rough_b":
        inst = hist.data["Instrument Parameters"][0]
        inst["Polariz."][1] = 0.8
        inst["Polariz."][2] = True
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.02, True]
    elif args.trial == "angular_zero":
        inst = hist.data["Instrument Parameters"][0]
        hist.data["Sample Parameters"]["Shift"] = [0.0, False]
        inst["Zero"] = [0.0, 0.0, True]
    elif args.trial == "angular_zero_seeded":
        inst = hist.data["Instrument Parameters"][0]
        hist.data["Sample Parameters"]["Shift"] = [0.0, False]
        inst["Zero"] = [0.0, 0.31, True]
    elif args.trial == "background6":
        background = hist.data["Background"][0]
        background[:] = background[: 3 + 6]
        background[2] = 6
    elif args.trial == "shl":
        inst = hist.data["Instrument Parameters"][0]
        inst["SH/L"][1] = 0.002
        inst["SH/L"][2] = True
    elif args.trial in ("w_only", "x_only"):
        inst = hist.data["Instrument Parameters"][0]
        if args.trial == "w_only":
            inst["W"] = [60.0, 60.0, True]
            inst["X"] = [0.0, 0.0, False]
        else:
            inst["W"] = [0.0, 0.0, False]
            inst["X"] = [15.0, 15.0, True]
    elif args.trial == "roughness":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.5, True]
        sample["SurfRoughB"] = [0.01, True]
    elif args.trial == "rough_b":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.01, True]
    elif args.trial == "rough_a":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.5, True]
        sample["SurfRoughB"] = [0.01, False]
    else:
        phase_name, kind = args.trial.rsplit("_", 1)
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        if kind == "size":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1.0
            hap["Size"][2] = [True, False, False]
        elif kind == "strain":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 500.0
            hap["Mustrain"][2] = [True, False, False]
        else:
            raise ValueError(args.trial)

    project.data["Controls"]["data"]["max cyc"] = 16
    project.save()
    project.refine()
    project.save()
    reopened = G2sc.G2Project(str(out))
    reopened.refine()
    reopened.save()
    h = reopened.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    result = {
        "trial": args.trial,
        "Rwp_percent": h.get_wR(),
        "instrument": {
            key: {"value": inst[key][1], "refine": inst[key][2]}
            for key in ("Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "shift_micrometers": h.data["Sample Parameters"]["Shift"][0],
        "phases": {},
    }
    for phase in reopened.phases():
        hap = phase.data["Histograms"][h.name]
        result["phases"][phase.name] = {
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
