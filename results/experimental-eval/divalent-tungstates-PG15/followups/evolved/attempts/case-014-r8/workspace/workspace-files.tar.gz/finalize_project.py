#!/usr/bin/env python3
"""Converge, save, reopen, and replay the accepted neutral final model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
START = ROOT / ".tmp" / "final_base.gpx"
OUT = ROOT / "final.gpx"
TRACE = ROOT / ".tmp" / "final_replay_states.json"


def set_flags(gpx: G2sc.G2Project, *, background: bool, model: bool) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = background
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.InstrumentParameters["Zero"] = [0.0, 0.0, False]
    hist.InstrumentParameters["Polariz."][1] = 1.0
    hist.InstrumentParameters["Polariz."][2] = False
    hist.InstrumentParameters["SH/L"][1] = 0.002
    hist.InstrumentParameters["SH/L"][2] = False
    for key in ("U", "W", "X"):
        hist.InstrumentParameters[key][2] = model
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = model
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = model
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = model
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def snapshot(gpx: G2sc.G2Project, step: str) -> dict:
    hist = gpx.histogram(0)
    rvals = gpx["Covariance"]["data"].get("Rvals", {})
    result = {
        "step": step,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "wRmin": hist.residuals.get("wRmin"),
        "GOF": rvals.get("GOF"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "mass_fractions": hist.ComputeMassFracs(),
        "shift_um": hist.SampleParameters["Shift"][0],
        "profile": {
            key: hist.InstrumentParameters[key][1]
            for key in ("U", "V", "W", "X", "Y", "SH/L")
        },
        "cells": {phase.name: phase.get_cell() for phase in gpx.phases()},
    }
    print("FINAL_REPLAY_STATE " + json.dumps(result, default=float), flush=True)
    return result


def main() -> None:
    if OUT.exists():
        OUT.unlink()
    gpx = G2sc.G2Project(str(START), newgpx=str(OUT))
    gpx.set_Controls("cycles", 16)
    states = []
    prior_w_r = None
    for outer in range(1, 7):
        set_flags(gpx, background=True, model=False)
        gpx.refine(makeBack=False)
        set_flags(gpx, background=False, model=True)
        gpx.refine(makeBack=False)
        state = snapshot(gpx, f"outer_{outer}")
        states.append(state)
        max_shift = state["max_shift_over_esd"]
        stable_r = prior_w_r is not None and abs(state["wR"] - prior_w_r) < 1e-4
        if outer >= 2 and max_shift is not None and max_shift < 0.1 and stable_r:
            break
        prior_w_r = state["wR"]
    gpx.save()

    # Exact replay check from the serialized project. The final covariance and
    # profile arrays are produced by this reopened instance.
    gpx = G2sc.G2Project(str(OUT))
    gpx.set_Controls("cycles", 16)
    prior_w_r = None
    for replay in range(1, 5):
        set_flags(gpx, background=False, model=True)
        gpx.refine(makeBack=False)
        state = snapshot(gpx, f"reopen_model_{replay}")
        states.append(state)
        max_shift = state["max_shift_over_esd"]
        stable_r = prior_w_r is not None and abs(state["wR"] - prior_w_r) < 1e-5
        if max_shift is not None and max_shift < 0.1 and stable_r:
            break
        prior_w_r = state["wR"]
    gpx.save()
    TRACE.write_text(json.dumps(states, indent=2))


if __name__ == "__main__":
    main()
