#!/usr/bin/env python3
"""Reversible heavy-atom coordinate trials for the accepted phase inventory."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
BASE = TMP / "two_phase.gpx"
TRIALS = {
    "WO3_W1": (1, ("W1",)),
    "WO3_W2": (1, ("W2",)),
    "WO3_both_W": (1, ("W1", "W2")),
    # The only positional degree of freedom in scheelite is its oxygen site.
    "SrWO4_O": (0, ("O",)),
}


def freeze(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def main() -> None:
    results = []
    for label, (phase_index, atoms) in TRIALS.items():
        print(f"\n===== atom trial {label} =====", flush=True)
        out = TMP / f"atom_{label}.gpx"
        if out.exists():
            out.unlink()
        gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
        freeze(gpx)
        target = gpx.phase(phase_index)
        for atom_label in atoms:
            target.atom(atom_label).refinement_flags = "X"
        gpx.set_Controls("cycles", 12)
        try:
            gpx.refine(makeBack=False)
            status = "ok"
            error = None
        except Exception as exc:
            status = "error"
            error = f"{type(exc).__name__}: {exc}"
        hist = gpx.histogram(0)
        result = {
            "trial": label,
            "status": status,
            "error": error,
            "wR": hist.residuals.get("wR"),
            "R": hist.residuals.get("R"),
            "mass_fractions": hist.ComputeMassFracs() if status == "ok" else {},
            "coordinates": {
                phase.name: {
                    atom.label: atom.coordinates for atom in phase.atoms()
                }
                for phase in gpx.phases()
            },
            "project": str(out),
        }
        gpx.save()
        results.append(result)
        print("ATOM_RESULT " + json.dumps(result, default=float), flush=True)
    (TMP / "atom_results.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
