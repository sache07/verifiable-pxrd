#!/usr/bin/env python3
"""Final watch-list replay after SrO is included in the common profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from candidate_tests import TMP, cif, neutralize


BASE = TMP / "four_phase.gpx"
WATCH = {
    "Sr3W2O9_high_pressure_2311977": cif("2311977"),
    "SrWO4_fergusonite_high_pressure_1546037": cif("1546037"),
    "SrCO3_orthorhombic_9008198": cif("9008198"),
    "SrCO3_rhombohedral_1539128": cif("1539128"),
    "W3O8_2101049": cif("2101049"),
    "Sr2WO5_prototype": TMP / "prototype_Sr2WO5_from_Ba2ReO5_1529756.cif",
}


def freeze(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for phase in gpx.phases():
        neutralize(phase, hist)
        phase.data["General"]["Cell"][0] = False
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def main() -> None:
    results = []
    for label, path in WATCH.items():
        print(f"\n===== fifth-phase challenge {label} =====", flush=True)
        out = TMP / f"fifth_{label}.gpx"
        if out.exists():
            out.unlink()
        gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
        hist = gpx.histogram(0)
        candidate = gpx.add_phase(str(path), phasename=label, histograms=[hist], fmthint="CIF")
        freeze(gpx)
        candidate.data["Histograms"][hist.name]["Scale"][0] = 0.02
        gpx.set_Controls("cycles", 8)
        try:
            gpx.refine(makeBack=False)
            status, error = "ok", None
            masses = hist.ComputeMassFracs()
        except Exception as exc:
            status, error = "error", f"{type(exc).__name__}: {exc}"
            masses = {}
        result = {
            "candidate": label,
            "status": status,
            "error": error,
            "wR": hist.residuals.get("wR"),
            "R": hist.residuals.get("R"),
            "mass_fractions": masses,
            "scale": candidate.data["Histograms"][hist.name]["Scale"][0],
            "candidate_Rf": hist.residuals.get("4:0:Rf"),
            "candidate_Rf2": hist.residuals.get("4:0:Rf^2"),
            "project": str(out),
        }
        gpx.save()
        results.append(result)
        print("FIFTH_PHASE_RESULT " + json.dumps(result, default=float), flush=True)
    (TMP / "fifth_phase_results.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
