#!/usr/bin/env python3
"""Compare isotropic crystallite-size and microstrain terms phase by phase.

The common instrumental profile, background, cells and angular correction are
held at the converged two-phase baseline.  Only both phase scales and one
phase-specific broadening term are varied in each trial.
"""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
BASE = TMP / "two_phase.gpx"


def freeze(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def main() -> None:
    baseline = G2sc.G2Project(str(BASE))
    base_hist = baseline.histogram(0)
    results = [{
        "trial": "none",
        "phase": None,
        "wR": base_hist.residuals.get("wR"),
        "R": base_hist.residuals.get("R"),
        "mass_fractions": base_hist.ComputeMassFracs(),
    }]

    for phase_index, phase_label in enumerate(("SrWO4", "WO3")):
        for term in ("Size", "Mustrain"):
            tag = f"{phase_label}_{term.lower()}"
            out = TMP / f"broadening_{tag}.gpx"
            if out.exists():
                out.unlink()
            gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
            freeze(gpx)
            hist = gpx.histogram(0)
            target = gpx.phase(phase_index)
            hap = target.data["Histograms"][hist.name]
            if term == "Size":
                # Start below the neutral 10-micrometre upper limit so that a
                # finite-size optimum can be found without a zero derivative.
                hap["Size"][1][0] = 1.0
                hap["Size"][2][0] = True
            else:
                hap["Mustrain"][1][0] = 100.0
                hap["Mustrain"][2][0] = True
            gpx.set_Controls("cycles", 10)
            print(f"\n===== broadening {tag} =====", flush=True)
            gpx.refine(makeBack=False)
            result = {
                "trial": term.lower(),
                "phase": phase_label,
                "wR": hist.residuals.get("wR"),
                "R": hist.residuals.get("R"),
                "size_um": hap["Size"][1][0],
                "mustrain_microstrain": hap["Mustrain"][1][0],
                "mass_fractions": hist.ComputeMassFracs(),
                "project": str(out),
            }
            results.append(result)
            gpx.save()
            print("BROADENING_RESULT " + json.dumps(result, default=float), flush=True)

    (TMP / "broadening_results.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
