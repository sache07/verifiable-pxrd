#!/usr/bin/env python3
"""Build and iteratively refine a GSAS-II model for the supplied PXRD data.

This is a working analysis script. It deliberately prints the state after each
small refinement step so profile/inventory choices can be audited.
"""

from __future__ import annotations

import csv
import json
import os
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
TMP.mkdir(exist_ok=True)
PATTERN = ROOT / "inputs" / "pattern.csv"
XYE = TMP / "pattern.xye"
SOURCE_MODE = os.environ.get("PXRD_SOURCE_MODE", "dual").strip().lower()
if SOURCE_MODE not in {"dual", "single"}:
    raise ValueError("PXRD_SOURCE_MODE must be 'dual' or 'single'")
INST = TMP / f"cu_ka_{SOURCE_MODE}_reflection.instprm"
SOURCE_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/54/60/1546036.cif"
)
WORK_GPX = TMP / f"srwo4_{SOURCE_MODE}_work.gpx"


def make_inputs() -> None:
    with PATTERN.open(newline="") as src, XYE.open("w") as dst:
        reader = csv.DictReader(src)
        for row in reader:
            dst.write(f"{row['two_theta_deg']} {row['intensity']}\n")

    if SOURCE_MODE == "dual":
        wavelength_line = (
            "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.70;Azimuth:0.0;"
            "I(L2)/I(L1):0.5\n"
        )
    else:
        wavelength_line = "Lam:1.540598;Zero:0.0;Polariz.:0.70;Azimuth:0.0\n"
    INST.write_text(
        "#GSAS-II instrument parameter file for reflection Cu K-alpha lab data\n"
        "Type:PXC;Bank:1;Diff-type:Bragg-Brentano;InstrName:PIXcel1D-Medipix3\n"
        + wavelength_line
        + "U:20.0;V:0.0;W:100.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )


def snapshot(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.InstrumentParameters
    hap = phase.data["Histograms"][hist.name]
    payload = {
        "step": label,
        "residuals": hist.residuals,
        "cell": phase.get_cell(),
        "instrument": {
            key: inst[key][1]
            for key in (
                "Lam",
                "Lam1",
                "Lam2",
                "I(L2)/I(L1)",
                "Zero",
                "Polariz.",
                "U",
                "V",
                "W",
                "X",
                "Y",
                "Z",
                "SH/L",
            )
            if key in inst
        },
        "background": hist.Background[0],
        "scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "pref_ori": hap["Pref.Ori."],
        "sample": hist.SampleParameters,
    }
    print("STATE " + json.dumps(payload, default=float))


def run_step(gpx: G2sc.G2Project, label: str, settings: dict) -> None:
    print(f"\n===== {label} =====")
    gpx.set_refinement(settings)
    gpx.refine(makeBack=False)
    snapshot(gpx, label)


def main() -> None:
    make_inputs()
    if WORK_GPX.exists():
        WORK_GPX.unlink()

    gpx = G2sc.G2Project(newgpx=str(WORK_GPX))
    hist = gpx.add_powder_histogram(str(XYE), str(INST), fmthint="Topas")
    phase = gpx.add_phase(
        str(SOURCE_CIF),
        phasename="SrWO4_scheelite",
        histograms=[hist],
        fmthint="CIF",
    )
    gpx.set_Controls("cycles", 8)
    hist.set_refinements(
        {
            "Limits": [10.02, 99.98],
            "Background": {
                "type": "chebyschev-1",
                "refine": False,
                "no. coeffs": 6,
                "coeffs": [700.0, -350.0, 250.0, -120.0, 50.0, -20.0],
            },
        }
    )

    # Explicit neutral nuisance state.
    phase.set_HAP_refinements(
        {
            "Scale": False,
            "Size": {"type": "isotropic", "value": 10.0, "refine": False},
            "Mustrain": {"type": "isotropic", "refine": False},
            "Pref.Ori.": False,
            "Extinction": False,
        },
        [hist],
    )
    hap = phase.data["Histograms"][hist.name]
    # Size is in micrometres (10 is the GSAS-II upper/neutral limit) and
    # microstrain is in ppm (zero is neutral). The GSAS-II default of 1000 ppm
    # is intentionally removed before deriving an instrumental profile.
    hap["Mustrain"][1][0] = 0.0
    hap["Size"][1][0] = 10.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    gpx.save()
    snapshot(gpx, "initial")

    run_step(
        gpx,
        "background_scale",
        {"set": {"Background": {"refine": True}, "Scale": True}},
    )
    run_step(
        gpx,
        "zero_cell",
        {"set": {"Instrument Parameters": ["Zero"], "Cell": True}},
    )
    run_step(
        gpx,
        "profile_W",
        {"set": {"Instrument Parameters": ["W"]}},
    )
    run_step(
        gpx,
        "profile_UW",
        {"set": {"Instrument Parameters": ["U", "W"]}},
    )
    run_step(
        gpx,
        "profile_UWX",
        {"set": {"Instrument Parameters": ["U", "W", "X"]}},
    )
    gpx.save()


if __name__ == "__main__":
    main()
