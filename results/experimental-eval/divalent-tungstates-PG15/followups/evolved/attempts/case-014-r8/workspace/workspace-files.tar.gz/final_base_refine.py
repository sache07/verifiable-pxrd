#!/usr/bin/env python3
"""Converge the accepted inventory with the physical final instrument baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
START = TMP / "angular_displacement.gpx"
OUT = TMP / "final_base.gpx"


def flags(gpx: G2sc.G2Project, *, background: bool = False, model: bool = False) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = background
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.InstrumentParameters["Zero"] = [0.0, 0.0, False]
    hist.InstrumentParameters["Polariz."][1] = 1.0
    hist.InstrumentParameters["Polariz."][2] = False
    hist.InstrumentParameters["SH/L"][1] = 0.002
    hist.InstrumentParameters["SH/L"][2] = False
    for key in ("U", "W", "X"):
        hist.InstrumentParameters[key][2] = model
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = model
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = model
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = model
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def state(gpx: G2sc.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    result = {
        "step": label,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Lam", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")
        },
        "shift_um": hist.SampleParameters["Shift"][0],
        "background": hist.Background[0],
        "phases": {
            phase.name: {"cell": phase.get_cell(), "scale": phase.data["Histograms"][hist.name]["Scale"]}
            for phase in gpx.phases()
        },
    }
    print("FINAL_BASE_STATE " + json.dumps(result, default=float), flush=True)
    return result


def main() -> None:
    if OUT.exists():
        OUT.unlink()
    gpx = G2sc.G2Project(str(START), newgpx=str(OUT))
    gpx.set_Controls("cycles", 12)
    gpx.save()
    states = []
    for label, kwargs in (
        ("background_1", {"background": True}),
        ("model_1", {"model": True}),
        ("background_2", {"background": True}),
        ("model_2", {"model": True}),
    ):
        print(f"\n===== {label} =====", flush=True)
        flags(gpx, **kwargs)
        gpx.refine(makeBack=False)
        states.append(state(gpx, label))
    gpx.save()
    (TMP / "final_base_states.json").write_text(json.dumps(states, indent=2))


if __name__ == "__main__":
    main()
