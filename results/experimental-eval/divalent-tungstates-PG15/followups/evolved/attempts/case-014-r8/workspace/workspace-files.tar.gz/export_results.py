#!/usr/bin/env python3
"""Export all submitted artifacts from the serialized final GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"
FIT = ROOT / "fit.csv"
RESULT = ROOT / "result.json"

PHASE_INFO = {
    "SrWO4_scheelite": {
        "name": "SrWO4 scheelite",
        "formula": "SrWO4",
        "cif": "phase_SrWO4.cif",
        "model_source": "COD 1546036",
        "model_status": "identified",
    },
    "WO3_monoclinic_2311041": {
        "name": "WO3 monoclinic",
        "formula": "WO3",
        "cif": "phase_WO3.cif",
        "model_source": "COD 2311041 (neutron structure)",
        "model_status": "identified",
    },
    "Sr3WO6_prototype": {
        "name": "Sr3WO6-like monoclinic prototype",
        "formula": "Sr3WO6",
        "cif": "phase_Sr3WO6_prototype.cif",
        "model_source": "COD 2001752 Sr3UO6 prototype with U(VI) replaced by W(VI)",
        "model_status": "provisional prototype assignment",
    },
    "SrO_rocksalt_7200689": {
        "name": "SrO rocksalt",
        "formula": "SrO",
        "cif": "phase_SrO.cif",
        "model_source": "COD 7200689",
        "model_status": "identified trace phase",
    },
}


def main() -> None:
    gpx = G2sc.G2Project(str(PROJECT))
    hist = gpx.histogram(0)
    profile = hist.data["data"][1]
    low, high = hist.data["Limits"][1]
    first, last = profile[0].searchsorted([low, high])
    last += 1  # GSAS-II includes the point that brackets the upper limit.
    used = slice(first, last)
    with FIT.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        for x, obs, calc, diff, back in zip(
            profile[0][used],
            profile[1][used],
            profile[3][used],
            profile[5][used],
            profile[4][used],
        ):
            writer.writerow(
                [
                    f"{x:.17g}",
                    f"{obs:.17g}",
                    f"{calc:.17g}",
                    f"{diff:.17g}",
                    f"{back:.17g}",
                ]
            )

    mass_fractions = hist.ComputeMassFracs()
    phases = []
    for index, phase in enumerate(gpx.phases()):
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif"]))
        fraction, formal_esd = mass_fractions[phase.name]
        preferred_orientation = phase.data["Histograms"][hist.name]["Pref.Ori."]
        phases.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": info["cif"],
                "weight_fraction": fraction,
                "weight_percent": 100.0 * fraction,
                "formal_weight_fraction_esd": formal_esd,
                "formal_weight_percent_esd": 100.0 * formal_esd,
                "model_source": info["model_source"],
                "model_status": info["model_status"],
                "refined_cell": phase.get_cell(),
                "preferred_orientation": {
                    "model": "March-Dollase" if preferred_orientation[2] else "none",
                    "ratio": preferred_orientation[1],
                    "axis_hkl": preferred_orientation[3],
                },
                "bragg_Rf_percent": hist.residuals.get(f"{index}:0:Rf"),
                "bragg_Rf_squared_percent": hist.residuals.get(f"{index}:0:Rf^2"),
            }
        )

    rvals = gpx["Covariance"]["data"].get("Rvals", {})
    goodness = rvals.get("GOF")
    result = {
        "project_path": PROJECT.name,
        "profile_path": FIT.name,
        "crystalline_phase_count": len(phases),
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": hist.residuals.get("wR"),
            "Rp_percent": hist.residuals.get("R"),
            "Rexp_percent": hist.residuals.get("wRmin"),
            "goodness_of_fit": goodness,
            "reduced_chi_squared": goodness * goodness if goodness is not None else None,
            "chi_squared": rvals.get("chisq"),
            "weighted_Bragg_R_percent": hist.residuals.get("wRb"),
            "Bragg_R_percent": hist.residuals.get("Rb"),
            "n_observations": rvals.get("Nobs"),
            "n_refined_parameters": rvals.get("Nvars"),
            "maximum_shift_over_esd_final_replay": rvals.get("Max shft/sig"),
            "two_theta_range_deg": [low, high],
        },
        "measurement_model": {
            "radiation": "Cu K-alpha1/K-alpha2 doublet",
            "wavelength_Kalpha1_angstrom": hist.InstrumentParameters["Lam1"][1],
            "wavelength_Kalpha2_angstrom": hist.InstrumentParameters["Lam2"][1],
            "Kalpha2_to_Kalpha1_ratio": hist.InstrumentParameters["I(L2)/I(L1)"][1],
            "polarization_factor": hist.InstrumentParameters["Polariz."][1],
            "point_weights": "GSAS-II Poisson count weights (1/observed counts); no pointwise sigmas were supplied",
            "background": "six-coefficient Chebyshev-1 polynomial",
            "profile_parameters": {
                key: hist.InstrumentParameters[key][1]
                for key in ("U", "V", "W", "X", "Y", "SH/L")
            },
            "angular_correction": {
                "type": "specimen displacement",
                "value_micrometers": hist.SampleParameters["Shift"][0],
                "interpretation": "effective calibration/sample-mount correction; not treated as a precise physical height",
            },
        },
        "fraction_normalization": "normalized over the four modeled crystalline phases",
        "uncertainty_note": "Formal covariance ESDs exclude phase-model, source-profile, preferred-orientation, and inventory uncertainty; see report.md.",
    }
    RESULT.write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
