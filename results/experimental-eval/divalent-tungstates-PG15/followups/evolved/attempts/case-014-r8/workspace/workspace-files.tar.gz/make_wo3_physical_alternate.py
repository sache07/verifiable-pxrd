#!/usr/bin/env python3
"""Transform COD 2311041 to a compact monoclinic setting for GSAS-II."""

from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/31/10/2311041.cif"
)
OUTPUT = ROOT / ".tmp" / "WO3_2311041_compact_monoclinic.cif"


def main() -> None:
    structure = Structure.from_file(SOURCE)
    # a' = a + c, b' = b, c' = -a. This determinant-one basis change
    # converts the 136-degree source cell to a compact beta ~= 90.9-degree
    # monoclinic cell without changing the structure.
    structure.make_supercell(np.array([[1, 0, 1], [0, 1, 0], [-1, 0, 0]]))
    CifWriter(structure, symprec=0.02, angle_tolerance=2).write_file(OUTPUT)


if __name__ == "__main__":
    main()
