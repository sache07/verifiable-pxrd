#!/usr/bin/env python3
"""Screen symmetry-distinct March-Dollase axes under a fixed baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
BASE = TMP / "two_phase.gpx"

TRIALS = {
    "WO3": (1, [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1)]),
    "SrWO4": (0, [(0, 0, 1), (1, 0, 0), (1, 1, 0), (1, 0, 1), (1, 1, 1)]),
}


def main() -> None:
    results = []
    for family, (target_index, axes) in TRIALS.items():
        for axis in axes:
            tag = family + "_" + "".join(str(i) for i in axis)
            print(f"\n===== texture {tag} =====", flush=True)
            out = TMP / f"texture_{tag}.gpx"
            if out.exists():
                out.unlink()
            gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
            hist = gpx.histogram(0)
            hist.Background[0][1] = False
            for value in hist.InstrumentParameters.values():
                if isinstance(value, list) and len(value) > 2:
                    value[2] = False
            for value in hist.SampleParameters.values():
                if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
                    value[1] = False
            hist.SampleParameters["Scale"] = [1.0, False]
            for phase in gpx.phases():
                phase.data["General"]["Cell"][0] = False
                hap = phase.data["Histograms"][hist.name]
                hap["Scale"][1] = True
                hap["Pref.Ori."][1] = 1.0
                hap["Pref.Ori."][2] = False
                hap["Size"][2] = [False for _ in hap["Size"][2]]
                hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            target = gpx.phase(target_index)
            pref = target.data["Histograms"][hist.name]["Pref.Ori."]
            pref[0] = "MD"
            pref[1] = 1.0
            pref[2] = True
            pref[3] = list(axis)
            gpx.set_Controls("cycles", 8)
            gpx.refine(makeBack=False)
            result = {
                "phase": family,
                "axis": axis,
                "wR": hist.residuals.get("wR"),
                "R": hist.residuals.get("R"),
                "MD": pref[1],
                "mass_fractions": hist.ComputeMassFracs(),
                "project": str(out),
            }
            results.append(result)
            gpx.save()
            print("TEXTURE_RESULT " + json.dumps(result, default=float), flush=True)
    (TMP / "texture_results.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
