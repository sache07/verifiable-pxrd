#!/usr/bin/env python3
"""Freeze the accepted common profile/cells and replay scales plus Sr3 texture."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from wo3_physical_record_rebuild import flags, snapshot


ROOT = Path(__file__).resolve().parent
START = ROOT / ".tmp" / "wo3_2311041_physical_base.bak0.gpx"
OUT = ROOT / ".tmp" / "wo3_physical_stable_base.gpx"
TRACE = ROOT / ".tmp" / "wo3_physical_stable_replay.json"


def main() -> None:
    if OUT.exists():
        OUT.unlink()
    gpx = G2sc.G2Project(str(START), newgpx=str(OUT))
    gpx.set_Controls("cycles", 16)
    states = []
    previous_rwp = None
    for replay in range(1, 7):
        flags(gpx, scales=True, sr3_texture=True)
        gpx.refine(makeBack=False)
        state = snapshot(gpx, f"stable_replay_{replay}")
        states.append(state)
        gpx.save()
        stable_rwp = previous_rwp is not None and abs(state["Rwp"] - previous_rwp) < 1e-5
        stable_shift = state["max_shift_over_esd"] is not None and state["max_shift_over_esd"] < 0.01
        if stable_rwp and stable_shift:
            break
        previous_rwp = state["Rwp"]
        gpx = G2sc.G2Project(str(OUT))
        gpx.set_Controls("cycles", 16)
    gpx.save()
    TRACE.write_text(json.dumps(states, indent=2))


if __name__ == "__main__":
    main()
