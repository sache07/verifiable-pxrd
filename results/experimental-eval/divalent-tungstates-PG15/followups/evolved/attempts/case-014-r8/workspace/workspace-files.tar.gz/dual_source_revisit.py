#!/usr/bin/env python3
"""Rebuild the accepted inventory with the measured Cu K-alpha doublet."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
START = ROOT / "final.gpx"
OUT = ROOT / ".tmp" / "dual_revisit.gpx"


def install_dual_source(hist: G2sc.G2PwdrData) -> None:
    hist.data["Instrument Parameters"][0] = {
        "Type": ["PXC", "PXC", False],
        "Bank": [1.0, 1.0, False],
        "Lam1": [1.540598, 1.540598, False],
        "Lam2": [1.544426, 1.544426, False],
        "Zero": [0.0, 0.0, False],
        "Polariz.": [0.7, 1.0, False],
        "Azimuth": [0.0, 0.0, False],
        "I(L2)/I(L1)": [0.5, 0.5, False],
        "U": [20.0, 20.0, False],
        "V": [0.0, 0.0, False],
        "W": [20.0, 20.0, False],
        "X": [5.0, 5.0, False],
        "Y": [0.0, 0.0, False],
        "Z": [0.0, 0.0, False],
        "SH/L": [0.002, 0.002, False],
    }


def flags(
    gpx: G2sc.G2Project,
    *,
    background: bool = False,
    model: bool = False,
    profile: tuple[str, ...] = (),
) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = background
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.InstrumentParameters["Zero"] = [0.0, 0.0, False]
    hist.InstrumentParameters["Polariz."][1:] = [1.0, False]
    hist.InstrumentParameters["I(L2)/I(L1)"][1:] = [0.5, False]
    hist.InstrumentParameters["SH/L"][1:] = [0.002, False]
    for key in profile:
        hist.InstrumentParameters[key][2] = True
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = model
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = model
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = model
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][1][0] = 10.0
        hap["Mustrain"][1][0] = 0.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def state(gpx: G2sc.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    result = {
        "step": label,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "profile": {key: hist.InstrumentParameters[key][1] for key in ("U", "V", "W", "X", "Y", "SH/L")},
        "shift_um": hist.SampleParameters["Shift"][0],
        "fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell() for phase in gpx.phases()},
        "max_shift_over_esd": gpx["Covariance"]["data"].get("Rvals", {}).get("Max shft/sig"),
    }
    print("DUAL_REVISIT_STATE " + json.dumps(result, default=float), flush=True)
    return result


def main() -> None:
    if OUT.exists():
        OUT.unlink()
    gpx = G2sc.G2Project(str(START), newgpx=str(OUT))
    install_dual_source(gpx.histogram(0))
    gpx.set_Controls("cycles", 16)
    states = []
    schedule = (
        ("background_0", {"background": True}),
        ("positions_0", {"model": True}),
        ("profile_WX", {"model": True, "profile": ("W", "X")}),
        ("background_1", {"background": True}),
        ("profile_UWX_1", {"model": True, "profile": ("U", "W", "X")}),
        ("background_2", {"background": True}),
        ("profile_UWX_2", {"model": True, "profile": ("U", "W", "X")}),
    )
    for label, kwargs in schedule:
        flags(gpx, **kwargs)
        gpx.refine(makeBack=False)
        states.append(state(gpx, label))
    gpx.save()
    gpx = G2sc.G2Project(str(OUT))
    flags(gpx, model=True, profile=("U", "W", "X"))
    gpx.refine(makeBack=False)
    states.append(state(gpx, "reopen_profile_UWX"))
    gpx.save()
    (ROOT / ".tmp" / "dual_revisit_states.json").write_text(json.dumps(states, indent=2))


if __name__ == "__main__":
    main()
