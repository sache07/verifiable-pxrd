#!/usr/bin/env python3
"""Replace the low-precision WO3 record with physical neutron coordinates."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from candidate_tests import neutralize


ROOT = Path(__file__).resolve().parent
START = ROOT / "final.gpx"
OUT = ROOT / ".tmp" / "wo3_2311041_physical_base.gpx"
SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/31/10/2311041.cif"
)
OLD = "WO3_monoclinic_1528915"
NEW = "WO3_monoclinic_2311041"


def replace_phase(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    old_scale = gpx.phase(OLD).data["Histograms"][hist.name]["Scale"][0]
    del gpx.data["Phases"][OLD]
    for tree_item in gpx.names:
        if tree_item[0] == "Phases":
            tree_item.remove(OLD)
    hist.data.get("Reflection Lists", {}).pop(OLD, None)
    phase = gpx.add_phase(str(SOURCE), phasename=NEW, histograms=[hist], fmthint="CIF")
    neutralize(phase, hist)
    phase.data["Histograms"][hist.name]["Scale"] = [old_scale, True]
    for atom in phase.atoms():
        atom.uiso = 0.01
        atom.refinement_flags = " "

    # Keep deterministic phase order and identifiers after replacement.
    phases = gpx.data["Phases"]
    names = ["SrWO4_scheelite", NEW, "Sr3WO6_prototype", "SrO_rocksalt_7200689"]
    gpx.data["Phases"] = {"data": phases["data"], **{name: phases[name] for name in names}}
    for tree_item in gpx.names:
        if tree_item[0] == "Phases":
            tree_item[:] = ["Phases", *names]
    for phase_id, name in enumerate(names):
        gpx.data["Phases"][name]["pId"] = phase_id


def flags(
    gpx: G2sc.G2Project,
    *,
    background: bool = False,
    scales: bool = False,
    cells: set[str] | None = None,
    profile: bool = False,
    displacement: bool = False,
    sr3_texture: bool = False,
) -> None:
    cells = cells or set()
    hist = gpx.histogram(0)
    hist.Background[0][1] = background
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key in ("W", "X"):
        hist.InstrumentParameters[key][2] = profile
    hist.InstrumentParameters["U"][1:] = [0.0, False]
    hist.InstrumentParameters["V"][1:] = [0.0, False]
    hist.InstrumentParameters["Y"][1:] = [0.0, False]
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = displacement
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = phase.name in cells
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = scales
        hap["Pref.Ori."][2] = sr3_texture and phase.name == "Sr3WO6_prototype"
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def snapshot(gpx: G2sc.G2Project, step: str) -> dict:
    hist = gpx.histogram(0)
    rvals = gpx["Covariance"]["data"].get("Rvals", {})
    result = {
        "step": step,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "mass_fractions": hist.ComputeMassFracs(),
        "profile": {key: hist.InstrumentParameters[key][1] for key in ("U", "W", "X")},
        "displacement_um": hist.SampleParameters["Shift"][0],
        "cells": {phase.name: phase.get_cell() for phase in gpx.phases()},
        "Sr3_MD": gpx.phase("Sr3WO6_prototype").data["Histograms"][hist.name]["Pref.Ori."][1],
    }
    print("WO3_PHYSICAL_REBUILD " + json.dumps(result, default=float), flush=True)
    return result


def main() -> None:
    if OUT.exists():
        OUT.unlink()
    gpx = G2sc.G2Project(str(START), newgpx=str(OUT))
    replace_phase(gpx)
    gpx.set_Controls("cycles", 14)
    all_names = {phase.name for phase in gpx.phases()}
    states = []
    schedule = (
        ("scale", dict(scales=True)),
        ("new_cell", dict(scales=True, cells={NEW})),
        ("background_1", dict(background=True)),
        ("common_model_1", dict(scales=True, cells=all_names, profile=True, displacement=True, sr3_texture=True)),
        ("background_2", dict(background=True)),
        ("common_model_2", dict(scales=True, cells=all_names, profile=True, displacement=True, sr3_texture=True)),
    )
    for label, kwargs in schedule:
        flags(gpx, **kwargs)
        gpx.refine(makeBack=False)
        states.append(snapshot(gpx, label))
    gpx.save()
    gpx = G2sc.G2Project(str(OUT))
    flags(gpx, scales=True, cells=all_names, profile=True, displacement=True, sr3_texture=True)
    gpx.refine(makeBack=False)
    states.append(snapshot(gpx, "reopen_common_model"))
    gpx.save()
    (ROOT / ".tmp" / "wo3_2311041_rebuild.json").write_text(json.dumps(states, indent=2))


if __name__ == "__main__":
    main()
