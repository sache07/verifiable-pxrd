#!/usr/bin/env python3
"""Screen polarization and axial-divergence asymmetry on the accepted inventory."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
BASE = TMP / "angular_displacement.gpx"


def freeze(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def run(label: str, polariz: float = 0.7, refine_polariz: bool = False, refine_shl: bool = False) -> dict:
    out = TMP / f"shape_{label}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    freeze(gpx)
    hist = gpx.histogram(0)
    hist.InstrumentParameters["Polariz."][1] = polariz
    hist.InstrumentParameters["Polariz."][2] = refine_polariz
    hist.InstrumentParameters["SH/L"][2] = refine_shl
    gpx.set_Controls("cycles", 10)
    gpx.refine(makeBack=False)
    result = {
        "trial": label,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "SH_L": hist.InstrumentParameters["SH/L"][1],
        "mass_fractions": hist.ComputeMassFracs(),
        "project": str(out),
    }
    gpx.save()
    print("SHAPE_RESULT " + json.dumps(result, default=float), flush=True)
    return result


def main() -> None:
    results = []
    for value in (0.5, 0.7, 0.9):
        results.append(run(f"polarization_{value:.1f}", polariz=value))
    results.append(run("polarization_refined", polariz=0.7, refine_polariz=True))
    results.append(run("SHL_refined", polariz=0.7, refine_shl=True))
    results.append(run("polarization_and_SHL", polariz=0.7, refine_polariz=True, refine_shl=True))
    (TMP / "instrument_shape_results.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
