#!/usr/bin/env python3
"""Final one-at-a-time size/strain trials under the accepted common profile."""

from __future__ import annotations

import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
BASE = Path(os.environ.get("PXRD_BASE_GPX", str(TMP / "final_base.gpx")))
TAG = os.environ.get("PXRD_SCREEN_TAG", "final")


def freeze(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def main() -> None:
    base = G2sc.G2Project(str(BASE))
    bh = base.histogram(0)
    results = [{"phase": None, "term": "none", "wR": bh.residuals.get("wR"), "R": bh.residuals.get("R")}]
    phase_names = [phase.name for phase in base.phases()]
    for phase_index, phase_name in enumerate(phase_names):
        for term in ("Size", "Mustrain"):
            tag = f"{phase_index}_{term.lower()}"
            print(f"\n===== final broadening {phase_name} {term} =====", flush=True)
            out = TMP / f"{TAG}_broadening_{tag}.gpx"
            if out.exists():
                out.unlink()
            gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
            freeze(gpx)
            hist = gpx.histogram(0)
            hap = gpx.phase(phase_index).data["Histograms"][hist.name]
            if term == "Size":
                hap["Size"][1][0] = 1.0
                hap["Size"][2][0] = True
            else:
                hap["Mustrain"][1][0] = 100.0
                hap["Mustrain"][2][0] = True
            gpx.set_Controls("cycles", 10)
            gpx.refine(makeBack=False)
            result = {
                "phase": phase_name,
                "term": term.lower(),
                "wR": hist.residuals.get("wR"),
                "R": hist.residuals.get("R"),
                "size_um": hap["Size"][1][0],
                "mustrain_microstrain": hap["Mustrain"][1][0],
                "mass_fractions": hist.ComputeMassFracs(),
                "project": str(out),
            }
            gpx.save()
            results.append(result)
            print("FINAL_BROADENING_RESULT " + json.dumps(result, default=float), flush=True)
    (TMP / f"{TAG}_broadening_results.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
