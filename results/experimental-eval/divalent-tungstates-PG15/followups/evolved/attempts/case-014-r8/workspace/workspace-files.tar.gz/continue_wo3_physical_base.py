#!/usr/bin/env python3
"""Converge and replay the rebuilt physical-WO3 common baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from wo3_physical_record_rebuild import NEW, flags, snapshot


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / ".tmp" / "wo3_2311041_physical_base.gpx"
TRACE = ROOT / ".tmp" / "wo3_2311041_convergence.json"


def main() -> None:
    gpx = G2sc.G2Project(str(PROJECT))
    gpx.set_Controls("cycles", 16)
    all_names = {phase.name for phase in gpx.phases()}
    states = []
    previous_rwp = None
    for outer in range(1, 7):
        flags(gpx, background=True)
        gpx.refine(makeBack=False)
        states.append(snapshot(gpx, f"background_{outer}"))
        flags(
            gpx,
            scales=True,
            cells=all_names,
            profile=True,
            displacement=True,
            sr3_texture=True,
        )
        gpx.refine(makeBack=False)
        state = snapshot(gpx, f"common_model_{outer}")
        states.append(state)
        gpx.save()
        stable_rwp = previous_rwp is not None and abs(state["Rwp"] - previous_rwp) < 1e-4
        stable_shift = state["max_shift_over_esd"] is not None and state["max_shift_over_esd"] < 0.05
        if stable_rwp and stable_shift:
            break
        previous_rwp = state["Rwp"]
        gpx = G2sc.G2Project(str(PROJECT))
        gpx.set_Controls("cycles", 16)
    gpx.save()
    TRACE.write_text(json.dumps(states, indent=2))


if __name__ == "__main__":
    main()
