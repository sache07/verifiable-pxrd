#!/usr/bin/env python3
"""Create explicitly documented Sr-W-O prototype substitutions for screening."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


MODELS = {
    # Same A2B(VI)O5 charge/stoichiometry; Ba -> Sr and Re(VI) -> W(VI).
    # The nominally closer index hit 1512486 is excluded because inspection
    # shows that its source CIF is Sr2Mn2O5, not the indexed Sr2MnO5 formula.
    "Sr2WO5_from_Ba2ReO5_1529756": ("1529756", {"Ba": "Sr", "Re": "W"}),
    # Same Sr sublattice and stoichiometry; U(VI) -> W(VI).
    "Sr3WO6_from_Sr3UO6_2001752": ("2001752", {"U": "W"}),
    # Preserve the W(VI)-O framework; expand the alkaline-earth site Ca -> Sr.
    "Sr3WO6_from_Ca3WO6_1563081": ("1563081", {"Ca": "Sr"}),
    # Preserve W(VI), replacing the larger alkaline-earth A site Ba -> Sr.
    "Sr3WO6_from_Ba3WO6_1534803": ("1534803", {"Ba": "Sr"}),
    # Same Sr sublattice and stoichiometry; Cr(VI) -> W(VI).
    "SrW2O7_from_SrCr2O7_1542062": ("1542062", {"Cr": "W"}),
}


def nearest_distances(structure: Structure, center: str, neighbor: str, cutoff: float = 4.0) -> list[float]:
    values = []
    for i, site in enumerate(structure):
        if center not in {sp.symbol for sp in site.species}:
            continue
        for nn in structure.get_neighbors(site, cutoff):
            if neighbor in {sp.symbol for sp in nn.species}:
                values.append(float(nn.nn_distance))
    return values


def main() -> None:
    summary = []
    for name, (cod_id, replacements) in MODELS.items():
        structure = Structure.from_file(cif_path(cod_id), primitive=False)
        structure.replace_species(replacements)
        out = TMP / f"prototype_{name}.cif"
        # Re-detect symmetry after substitution so the challenge model keeps
        # the parent's compact asymmetric unit instead of an expanded P1 cell.
        CifWriter(structure, symprec=1e-3).write_file(out)
        wo = nearest_distances(structure, "W", "O", 3.1)
        sro = nearest_distances(structure, "Sr", "O", 4.0)
        record = {
            "name": name,
            "parent_cod_id": cod_id,
            "substitution": replacements,
            "formula": structure.composition.reduced_formula,
            "space_group": structure.get_space_group_info(),
            "cell": list(structure.lattice.abc) + list(structure.lattice.angles),
            "volume_A3": structure.volume,
            "W_O_range_A": [min(wo), max(wo)] if wo else None,
            "Sr_O_range_A": [min(sro), max(sro)] if sro else None,
            "cif": str(out),
        }
        summary.append(record)
        print(json.dumps(record), flush=True)
    (TMP / "prototype_models.json").write_text(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
