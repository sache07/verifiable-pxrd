#!/usr/bin/env python3
"""Reversible one-at-a-time candidate phase challenges in GSAS-II."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
BASE = TMP / "srwo4_single_work.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = {
    "WO3_triclinic_1010618": "1010618",
    "WO3_triclinic_2106293": "2106293",
    "WO3_monoclinic_1528915": "1528915",
    "WO3_tetragonal_1521532": "1521532",
    "WO3_monoclinic_1563541": "1563541",
    "SrO_rocksalt_7200689": "7200689",
    "Sr3W2O9_2311977": "2311977",
    "SrWO4_fergusonite_1546037": "1546037",
    "SrCO3_orthorhombic_9008198": "9008198",
    "SrCO3_rhombohedral_1539128": "1539128",
    "W3O8_2101049": "2101049",
}


def neutralize(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    phase.set_HAP_refinements(
        {
            "Scale": False,
            "Size": {"type": "isotropic", "value": 10.0, "refine": False},
            "Mustrain": {"type": "isotropic", "refine": False},
            "Pref.Ori.": False,
            "Extinction": False,
        },
        [hist],
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][1][0] = 10.0
    hap["Mustrain"][1][0] = 0.0
    for atom in phase.atoms():
        if atom.adp_flag == "I" and atom.uiso <= 0.0:
            atom.uiso = 0.01


def set_flags(
    gpx: G2sc.G2Project,
    *,
    cells: bool,
    zero: bool,
    profile: bool,
) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.InstrumentParameters["Zero"][2] = zero
    for key in ("U", "W", "X"):
        hist.InstrumentParameters[key][2] = profile
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = cells
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        for i in range(len(hap["Size"][2])):
            hap["Size"][2][i] = False
        for i in range(len(hap["Mustrain"][2])):
            hap["Mustrain"][2][i] = False
        hap["Pref.Ori."][2] = False


def test(name: str, cod_id: str) -> dict:
    out = TMP / f"test_{name}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    phase = gpx.add_phase(
        str(cif(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
    )
    neutralize(phase, hist)
    phase.data["Histograms"][hist.name]["Scale"] = [0.1, True]
    hist.SampleParameters["Scale"] = [1.0, False]
    gpx.set_Controls("cycles", 8)
    try:
        # First determine whether the record has a positive scale under the
        # already established common profile; only then release peak positions.
        set_flags(gpx, cells=False, zero=False, profile=False)
        gpx.refine(makeBack=False)
        set_flags(gpx, cells=True, zero=True, profile=False)
        gpx.refine(makeBack=False)
        # Rebuild the common profile after the inventory change.
        set_flags(gpx, cells=True, zero=True, profile=True)
        gpx.refine(makeBack=False)
        masses = hist.ComputeMassFracs()
        status = "ok"
        error = None
    except Exception as exc:
        masses = {}
        status = "error"
        error = f"{type(exc).__name__}: {exc}"
    result = {
        "candidate": name,
        "cod_id": cod_id,
        "status": status,
        "error": error,
        "residuals": hist.residuals,
        "mass_fractions": masses,
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")
            if key in hist.InstrumentParameters
        },
        "phases": {
            ph.name: {
                "scale": ph.data["Histograms"][hist.name]["Scale"],
                "cell": ph.get_cell(),
            }
            for ph in gpx.phases()
        },
        "project": str(out),
    }
    gpx.save()
    return result


def main() -> None:
    results = []
    for name, cod_id in CANDIDATES.items():
        print(f"\n===== challenge {name} =====", flush=True)
        result = test(name, cod_id)
        results.append(result)
        print("CANDIDATE_RESULT " + json.dumps(result, default=float), flush=True)
    (TMP / "candidate_results.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
