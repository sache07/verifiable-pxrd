#!/usr/bin/env python3
"""Compare no correction, constant zero, and Bragg-Brentano displacement."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
BASE = TMP / "four_phase.gpx"


def set_flags(gpx: G2sc.G2Project, mode: str, background: bool = False) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = background
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    if not background:
        hist.InstrumentParameters["Zero"][2] = mode == "zero"
        hist.SampleParameters["Shift"][1] = mode == "displacement"
        for key in ("U", "W", "X"):
            hist.InstrumentParameters[key][2] = True
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = not background
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = not background
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def main() -> None:
    results = []
    for mode in ("none", "zero", "displacement"):
        print(f"\n===== angular correction {mode} =====", flush=True)
        out = TMP / f"angular_{mode}.gpx"
        if out.exists():
            out.unlink()
        gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
        hist = gpx.histogram(0)
        if mode == "none":
            hist.InstrumentParameters["Zero"][1] = 0.0
            hist.SampleParameters["Shift"] = [0.0, False]
        elif mode == "zero":
            hist.SampleParameters["Shift"] = [0.0, False]
        else:
            hist.InstrumentParameters["Zero"][1] = 0.0
            hist.SampleParameters["Shift"] = [-625.0, True]
        gpx.set_Controls("cycles", 12)
        for _ in range(2):
            set_flags(gpx, mode, background=False)
            gpx.refine(makeBack=False)
            set_flags(gpx, mode, background=True)
            gpx.refine(makeBack=False)
        # End with a model pass so scale uncertainties and fractions are current.
        set_flags(gpx, mode, background=False)
        gpx.refine(makeBack=False)
        result = {
            "mode": mode,
            "wR": hist.residuals.get("wR"),
            "R": hist.residuals.get("R"),
            "zero_deg": hist.InstrumentParameters["Zero"][1],
            "shift_um": hist.SampleParameters["Shift"][0],
            "profile": {key: hist.InstrumentParameters[key][1] for key in ("U", "V", "W", "X", "Y", "SH/L")},
            "mass_fractions": hist.ComputeMassFracs(),
            "cells": {phase.name: phase.get_cell() for phase in gpx.phases()},
            "project": str(out),
        }
        gpx.save()
        results.append(result)
        print("ANGULAR_RESULT " + json.dumps(result, default=float), flush=True)
    (TMP / "angular_results.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
