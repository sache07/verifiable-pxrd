#!/usr/bin/env python3
"""Create final.gpx by exact replay of the accepted four-phase model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
START = ROOT / ".tmp" / "physical_neutral_base.gpx"
OUT = ROOT / "final.gpx"
TRACE = ROOT / ".tmp" / "accepted_final_replay.json"
TEXTURED_PHASES: set[int] = set()


def set_final_flags(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for phase_index, phase in enumerate(gpx.phases()):
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = phase_index in TEXTURED_PHASES
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def snapshot(gpx: G2sc.G2Project, step: str) -> dict:
    hist = gpx.histogram(0)
    rvals = gpx["Covariance"]["data"].get("Rvals", {})
    result = {
        "step": step,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "Rexp": hist.residuals.get("wRmin"),
        "GOF": rvals.get("GOF"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "mass_fractions": hist.ComputeMassFracs(),
        "profile": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Lam1", "Lam2", "I(L2)/I(L1)", "U", "V", "W", "X", "Y", "SH/L")
        },
        "displacement_um": hist.SampleParameters["Shift"][0],
        "preferred_orientation": {
            phase.name: phase.data["Histograms"][hist.name]["Pref.Ori."][1:4]
            for phase in gpx.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in gpx.phases()},
    }
    print("ACCEPTED_FINAL_REPLAY " + json.dumps(result, default=float), flush=True)
    return result


def main() -> None:
    if OUT.exists():
        OUT.unlink()
    gpx = G2sc.G2Project(str(START), newgpx=str(OUT))
    gpx.set_Controls("cycles", 20)
    states = []
    previous_rwp = None
    for replay in range(1, 7):
        set_final_flags(gpx)
        gpx.refine(makeBack=False)
        state = snapshot(gpx, f"replay_{replay}")
        states.append(state)
        gpx.save()
        stable_rwp = previous_rwp is not None and abs(state["Rwp"] - previous_rwp) < 1e-5
        stable_shift = state["max_shift_over_esd"] is not None and state["max_shift_over_esd"] < 0.01
        if stable_rwp and stable_shift:
            break
        previous_rwp = state["Rwp"]
        gpx = G2sc.G2Project(str(OUT))
        gpx.set_Controls("cycles", 20)
    gpx.save()
    TRACE.write_text(json.dumps(states, indent=2))


if __name__ == "__main__":
    main()
