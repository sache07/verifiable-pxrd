#!/usr/bin/env python3
"""Refine physically plausible WO3 records under one common nuisance model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from candidate_tests import BASE, TMP, cif, neutralize


RECORDS = {
    # Room-temperature monoclinic records in different settings/data sources.
    "monoclinic_1528915": "1528915",
    "monoclinic_neutron_2311041": "2311041",
    # The accurately determined low-symmetry room-temperature form.
    "triclinic_2106293": "2106293",
    # Adjacent-temperature polymorph retained as a physical challenge.
    "orthorhombic_2107312": "2107312",
}


def flags(
    gpx: G2sc.G2Project,
    *,
    background: bool = False,
    scales: bool = False,
    cells: bool = False,
    zero: bool = False,
    profile: bool = False,
) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = background
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.InstrumentParameters["Zero"][2] = zero
    for key in ("U", "W", "X"):
        hist.InstrumentParameters[key][2] = profile
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = cells
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = scales
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def run_record(label: str, cod_id: str) -> dict:
    out = TMP / f"wo3_record_{label}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    phase = gpx.add_phase(
        str(cif(cod_id)), phasename=f"WO3_{label}", histograms=[hist], fmthint="CIF"
    )
    for ph in gpx.phases():
        neutralize(ph, hist)
        for atom in ph.atoms():
            if atom.adp_flag == "I" and atom.uiso <= 0:
                atom.uiso = 0.01
    phase.data["Histograms"][hist.name]["Scale"] = [0.1, True]
    hist.SampleParameters["Scale"] = [1.0, False]
    gpx.set_Controls("cycles", 10)

    # Establish the scale, positions/background, and then a fresh common
    # profile. Background and sparse model derivatives are kept separate.
    sequence = (
        dict(scales=True),
        dict(scales=True, cells=True, zero=True),
        dict(background=True),
        dict(scales=True, cells=True, zero=True, profile=True),
        dict(background=True),
        dict(scales=True, cells=True, zero=True, profile=True),
    )
    for n, kwargs in enumerate(sequence, 1):
        flags(gpx, **kwargs)
        print(f"  stage {n}: {kwargs}", flush=True)
        gpx.refine(makeBack=False)

    result = {
        "record": label,
        "cod_id": cod_id,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "mass_fractions": hist.ComputeMassFracs(),
        "candidate_Rf": hist.residuals.get("1:0:Rf"),
        "candidate_Rf2": hist.residuals.get("1:0:Rf^2"),
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")
        },
        "phases": {
            ph.name: {"cell": ph.get_cell(), "scale": ph.data["Histograms"][hist.name]["Scale"]}
            for ph in gpx.phases()
        },
        "project": str(out),
    }
    gpx.save()
    return result


def main() -> None:
    results = []
    for label, cod_id in RECORDS.items():
        print(f"\n===== WO3 record {label} =====", flush=True)
        try:
            result = run_record(label, cod_id)
        except Exception as exc:
            result = {"record": label, "cod_id": cod_id, "error": f"{type(exc).__name__}: {exc}"}
        results.append(result)
        print("WO3_RECORD_RESULT " + json.dumps(result, default=float), flush=True)
    (TMP / "wo3_record_results.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
