#!/usr/bin/env python3
"""Save/reopen/replay one March-Dollase candidate with all scales."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def set_flags(gpx: G2sc.G2Project, target_index: int) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for phase_index, phase in enumerate(gpx.phases()):
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = phase_index == target_index
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def main() -> None:
    source = Path(sys.argv[1])
    output = Path(sys.argv[2])
    target_index = int(sys.argv[3])
    if output.exists():
        output.unlink()
    gpx = G2sc.G2Project(str(source), newgpx=str(output))
    gpx.set_Controls("cycles", 16)
    previous_rwp = None
    states = []
    for replay in range(1, 9):
        set_flags(gpx, target_index)
        gpx.refine(makeBack=False)
        hist = gpx.histogram(0)
        rvals = gpx["Covariance"]["data"].get("Rvals", {})
        pref = gpx.phase(target_index).data["Histograms"][hist.name]["Pref.Ori."]
        state = {
            "replay": replay,
            "Rwp": hist.residuals.get("wR"),
            "Rp": hist.residuals.get("R"),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
            "MD": pref[1],
            "axis": pref[3],
            "mass_fractions": hist.ComputeMassFracs(),
        }
        print("SINGLE_TEXTURE_REPLAY " + json.dumps(state, default=float), flush=True)
        states.append(state)
        gpx.save()
        stable_rwp = previous_rwp is not None and abs(state["Rwp"] - previous_rwp) < 1e-5
        stable_shift = state["max_shift_over_esd"] is not None and state["max_shift_over_esd"] < 0.01
        if stable_rwp and stable_shift:
            break
        previous_rwp = state["Rwp"]
        gpx = G2sc.G2Project(str(output))
        gpx.set_Controls("cycles", 16)
    gpx.save()
    output.with_suffix(".json").write_text(json.dumps(states, indent=2))


if __name__ == "__main__":
    main()
