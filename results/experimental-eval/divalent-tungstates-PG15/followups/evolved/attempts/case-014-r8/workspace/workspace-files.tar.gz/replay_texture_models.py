#!/usr/bin/env python3
"""Replay the no/additional-WO3-texture models under matched nuisance flags."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
MODELS = {
    "no_WO3_texture": (
        TMP / "dual_texture_base.gpx",
        TMP / "replay_no_WO3_texture.gpx",
        {2},
    ),
    "with_WO3_111_texture": (
        TMP / "dualtex_texture_WO3_111.gpx",
        TMP / "replay_with_WO3_111_texture.gpx",
        {1, 2},
    ),
}


def set_flags(gpx: G2sc.G2Project, texture_indices: set[int], background: bool) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = background
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for phase_index, phase in enumerate(gpx.phases()):
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = phase_index in texture_indices
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def snapshot(label: str, stage: str, gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    rvals = gpx["Covariance"]["data"].get("Rvals", {})
    return {
        "model": label,
        "stage": stage,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "GOF": rvals.get("GOF"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "mass_fractions": hist.ComputeMassFracs(),
        "MD": {
            phase.name: phase.data["Histograms"][hist.name]["Pref.Ori."][1]
            for phase in gpx.phases()
        },
        "vary_list": rvals and gpx["Covariance"]["data"].get("varyList"),
    }


def main() -> None:
    results = []
    for label, (source, output, texture_indices) in MODELS.items():
        if output.exists():
            output.unlink()
        gpx = G2sc.G2Project(str(source), newgpx=str(output))
        gpx.set_Controls("cycles", 15)
        # Re-establish the same smooth background with the active texture model.
        for pass_index in range(2):
            set_flags(gpx, texture_indices, background=True)
            gpx.refine(makeBack=False)
            gpx.save()
            row = snapshot(label, f"background_pass_{pass_index + 1}", gpx)
            results.append(row)
            print("TEXTURE_REPLAY " + json.dumps(row, default=float), flush=True)
            gpx = G2sc.G2Project(str(output))
        # Freeze the reconverged background and require exact full-range replay.
        for pass_index in range(2):
            set_flags(gpx, texture_indices, background=False)
            gpx.refine(makeBack=False)
            gpx.save()
            row = snapshot(label, f"fixed_background_replay_{pass_index + 1}", gpx)
            results.append(row)
            print("TEXTURE_REPLAY " + json.dumps(row, default=float), flush=True)
            gpx = G2sc.G2Project(str(output))
    (TMP / "texture_replay_results.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
