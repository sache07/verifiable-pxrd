#!/usr/bin/env python3
"""Cell-only follow-up for weak positive fourth-phase watch-list scales."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
TRIALS = {
    "SrO": TMP / "fourth_SrO_rocksalt_7200689.gpx",
    "Sr3W2O9": TMP / "fourth_Sr3W2O9_high_pressure_2311977.gpx",
    "SrCO3": TMP / "fourth_SrCO3_orthorhombic_9008198.gpx",
}


def freeze_and_release_candidate(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for index, phase in enumerate(gpx.phases()):
        phase.data["General"]["Cell"][0] = index == 3
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def main() -> None:
    results = []
    for label, start in TRIALS.items():
        print(f"\n===== weak candidate cell {label} =====", flush=True)
        out = TMP / f"weak_cell_{label}.gpx"
        if out.exists():
            out.unlink()
        gpx = G2sc.G2Project(str(start), newgpx=str(out))
        freeze_and_release_candidate(gpx)
        gpx.set_Controls("cycles", 12)
        gpx.refine(makeBack=False)
        hist = gpx.histogram(0)
        candidate = gpx.phase(3)
        result = {
            "candidate": label,
            "wR": hist.residuals.get("wR"),
            "R": hist.residuals.get("R"),
            "mass_fractions": hist.ComputeMassFracs(),
            "cell": candidate.get_cell(),
            "scale": candidate.data["Histograms"][hist.name]["Scale"],
            "candidate_Rf": hist.residuals.get("3:0:Rf"),
            "candidate_Rf2": hist.residuals.get("3:0:Rf^2"),
            "project": str(out),
        }
        gpx.save()
        results.append(result)
        print("WEAK_CELL_RESULT " + json.dumps(result, default=float), flush=True)
    (TMP / "weak_cell_results.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
