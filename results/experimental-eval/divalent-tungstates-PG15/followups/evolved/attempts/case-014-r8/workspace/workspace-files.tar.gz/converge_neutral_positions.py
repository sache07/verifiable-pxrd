#!/usr/bin/env python3
"""Finish convergence of cells/displacement in the neutral physical baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from wo3_physical_record_rebuild import flags, snapshot


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / ".tmp" / "physical_neutral_base.gpx"
TRACE = ROOT / ".tmp" / "physical_neutral_positions.json"


def main() -> None:
    gpx = G2sc.G2Project(str(PROJECT))
    gpx.set_Controls("cycles", 16)
    all_names = {phase.name for phase in gpx.phases()}
    states = []
    for replay in range(1, 13):
        flags(gpx, scales=True, cells=all_names, displacement=True)
        gpx.refine(makeBack=False)
        state = snapshot(gpx, f"position_replay_{replay}")
        states.append(state)
        gpx.save()
        if state["max_shift_over_esd"] is not None and state["max_shift_over_esd"] < 0.05:
            break
        gpx = G2sc.G2Project(str(PROJECT))
        gpx.set_Controls("cycles", 16)

    # One final low-order background/profile reconvergence and exact scale replay.
    flags(gpx, background=True)
    gpx.refine(makeBack=False)
    states.append(snapshot(gpx, "background"))
    flags(gpx, scales=True, profile=True)
    gpx.refine(makeBack=False)
    states.append(snapshot(gpx, "profile"))
    flags(gpx, scales=True)
    gpx.refine(makeBack=False)
    states.append(snapshot(gpx, "scale_replay"))
    gpx.save()
    TRACE.write_text(json.dumps(states, indent=2))


if __name__ == "__main__":
    main()
