#!/usr/bin/env python3
"""Rebuild a neutral common baseline after the physical WO3 source change."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from wo3_physical_record_rebuild import flags, snapshot


ROOT = Path(__file__).resolve().parent
START = ROOT / ".tmp" / "wo3_physical_stable_base.gpx"
OUT = ROOT / ".tmp" / "physical_neutral_base.gpx"
TRACE = ROOT / ".tmp" / "physical_neutral_convergence.json"


def neutralize_texture(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    for phase in gpx.phases():
        pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
        pref[0] = "MD"
        pref[1] = 1.0
        pref[2] = False


def main() -> None:
    if OUT.exists():
        OUT.unlink()
    gpx = G2sc.G2Project(str(START), newgpx=str(OUT))
    neutralize_texture(gpx)
    gpx.set_Controls("cycles", 16)
    all_names = {phase.name for phase in gpx.phases()}
    states = []
    previous_rwp = None
    for outer in range(1, 6):
        flags(gpx, background=True)
        gpx.refine(makeBack=False)
        states.append(snapshot(gpx, f"background_{outer}"))

        flags(gpx, scales=True, cells=all_names, displacement=True)
        gpx.refine(makeBack=False)
        states.append(snapshot(gpx, f"positions_{outer}"))

        flags(gpx, scales=True, profile=True)
        gpx.refine(makeBack=False)
        states.append(snapshot(gpx, f"profile_{outer}"))

        flags(gpx, scales=True)
        gpx.refine(makeBack=False)
        state = snapshot(gpx, f"scale_replay_{outer}")
        states.append(state)
        gpx.save()
        stable_rwp = previous_rwp is not None and abs(state["Rwp"] - previous_rwp) < 1e-4
        stable_shift = state["max_shift_over_esd"] is not None and state["max_shift_over_esd"] < 0.05
        if stable_rwp and stable_shift:
            break
        previous_rwp = state["Rwp"]
        gpx = G2sc.G2Project(str(OUT))
        gpx.set_Controls("cycles", 16)
        neutralize_texture(gpx)
    gpx.save()
    TRACE.write_text(json.dumps(states, indent=2))


if __name__ == "__main__":
    main()
