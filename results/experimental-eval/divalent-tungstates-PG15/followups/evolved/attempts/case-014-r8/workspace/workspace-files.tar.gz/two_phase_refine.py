#!/usr/bin/env python3
"""Build the provisional SrWO4 + monoclinic WO3 refinement."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
START = TMP / "screen_WO3_monoclinic_1528915.gpx"
OUT = TMP / "two_phase.gpx"


def set_flags(
    gpx: G2sc.G2Project,
    *,
    background: bool = False,
    scales: bool = False,
    cells: bool = False,
    zero: bool = False,
    profile: bool = False,
) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = background
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.InstrumentParameters["Zero"][2] = zero
    for key in ("U", "W", "X"):
        hist.InstrumentParameters[key][2] = profile
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = cells
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = scales
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def state(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histogram(0)
    print(
        "TWO_PHASE_STATE "
        + json.dumps(
            {
                "step": label,
                "residuals": hist.residuals,
                "mass_fractions": hist.ComputeMassFracs(),
                "instrument": {
                    key: hist.InstrumentParameters[key][1]
                    for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")
                },
                "background": hist.Background[0],
                "phases": {
                    ph.name: {
                        "scale": ph.data["Histograms"][hist.name]["Scale"],
                        "cell": ph.get_cell(),
                        "size": ph.data["Histograms"][hist.name]["Size"],
                        "mustrain": ph.data["Histograms"][hist.name]["Mustrain"],
                    }
                    for ph in gpx.phases()
                },
            },
            default=float,
        ),
        flush=True,
    )


def refine(gpx: G2sc.G2Project, label: str, **flags: bool) -> None:
    print(f"\n===== {label} =====", flush=True)
    set_flags(gpx, **flags)
    gpx.refine(makeBack=False)
    state(gpx, label)


def main() -> None:
    if OUT.exists():
        OUT.unlink()
    gpx = G2sc.G2Project(str(START), newgpx=str(OUT))
    hist = gpx.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][1][0] = 10.0
        hap["Mustrain"][1][0] = 0.0
        for atom in phase.atoms():
            if atom.adp_flag == "I" and atom.uiso <= 0:
                atom.uiso = 0.01
    gpx.set_Controls("cycles", 10)
    gpx.save()
    state(gpx, "start")

    refine(gpx, "scales_zero_cells", scales=True, cells=True, zero=True)
    refine(gpx, "background_1", background=True)
    refine(
        gpx,
        "common_profile_1",
        scales=True,
        cells=True,
        zero=True,
        profile=True,
    )
    refine(gpx, "background_2", background=True)
    refine(
        gpx,
        "common_profile_2",
        scales=True,
        cells=True,
        zero=True,
        profile=True,
    )
    gpx.save()


if __name__ == "__main__":
    main()
