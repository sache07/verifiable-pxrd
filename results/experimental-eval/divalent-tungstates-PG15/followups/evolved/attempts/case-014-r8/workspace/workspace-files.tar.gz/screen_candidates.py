#!/usr/bin/env python3
"""Scale-only candidate screen under one fixed nuisance/profile model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from candidate_tests import BASE, CANDIDATES, TMP, cif, neutralize


def main() -> None:
    results = []
    for name, cod_id in CANDIDATES.items():
        print(f"\n===== fixed-profile challenge {name} =====", flush=True)
        out = TMP / f"screen_{name}.gpx"
        if out.exists():
            out.unlink()
        gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
        hist = gpx.histogram(0)
        phase = gpx.add_phase(
            str(cif(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )
        for ph in gpx.phases():
            neutralize(ph, hist)
            ph.data["General"]["Cell"][0] = False
            ph.data["Histograms"][hist.name]["Scale"][1] = True
        phase.data["Histograms"][hist.name]["Scale"][0] = 0.1
        hist.Background[0][1] = False
        for value in hist.InstrumentParameters.values():
            if isinstance(value, list) and len(value) > 2:
                value[2] = False
        for value in hist.SampleParameters.values():
            if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
                value[1] = False
        hist.SampleParameters["Scale"] = [1.0, False]
        gpx.set_Controls("cycles", 6)
        gpx.refine(makeBack=False)
        result = {
            "candidate": name,
            "cod_id": cod_id,
            "wR": hist.residuals.get("wR"),
            "R": hist.residuals.get("R"),
            "mass_fractions": hist.ComputeMassFracs(),
            "scales": {
                ph.name: ph.data["Histograms"][hist.name]["Scale"][0]
                for ph in gpx.phases()
            },
            "candidate_Rf": hist.residuals.get("1:0:Rf"),
            "candidate_Rf2": hist.residuals.get("1:0:Rf^2"),
            "project": str(out),
        }
        results.append(result)
        gpx.save()
        print("SCREEN_RESULT " + json.dumps(result, default=float), flush=True)
    (TMP / "screen_results.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
