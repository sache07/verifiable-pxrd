#!/usr/bin/env python3
"""Provisional three-phase refinement after the positive Sr3WO6 prototype screen."""

from __future__ import annotations

import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
START = Path(os.environ.get("PXRD_SR3WO6_START", TMP / "third_Sr3WO6_prototype.gpx"))
OUT = Path(os.environ.get("PXRD_SR3WO6_OUT", TMP / "three_phase.gpx"))


def set_flags(
    gpx: G2sc.G2Project,
    *,
    background: bool = False,
    scales: bool = False,
    cells: bool = False,
    candidate_cell_only: bool = False,
    zero: bool = False,
    profile: bool = False,
) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = background
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.InstrumentParameters["Zero"][2] = zero
    for key in ("U", "W", "X"):
        hist.InstrumentParameters[key][2] = profile
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for index, phase in enumerate(gpx.phases()):
        phase.data["General"]["Cell"][0] = bool(cells or (candidate_cell_only and index == 2))
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = scales
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def snapshot(gpx: G2sc.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    result = {
        "step": label,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")
        },
        "background": hist.Background[0],
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"],
            }
            for phase in gpx.phases()
        },
    }
    print("THREE_PHASE_STATE " + json.dumps(result, default=float), flush=True)
    return result


def main() -> None:
    if OUT.exists():
        OUT.unlink()
    gpx = G2sc.G2Project(str(START), newgpx=str(OUT))
    gpx.set_Controls("cycles", 12)
    gpx.save()
    states = [snapshot(gpx, "start")]
    sequence = (
        ("candidate_cell", dict(scales=True, candidate_cell_only=True)),
        ("background_1", dict(background=True)),
        ("common_profile_1", dict(scales=True, cells=True, zero=True, profile=True)),
        ("background_2", dict(background=True)),
        ("common_profile_2", dict(scales=True, cells=True, zero=True, profile=True)),
    )
    for label, kwargs in sequence:
        print(f"\n===== {label} =====", flush=True)
        set_flags(gpx, **kwargs)
        gpx.refine(makeBack=False)
        states.append(snapshot(gpx, label))
    gpx.save()
    (TMP / "three_phase_states.json").write_text(json.dumps(states, indent=2))


if __name__ == "__main__":
    main()
