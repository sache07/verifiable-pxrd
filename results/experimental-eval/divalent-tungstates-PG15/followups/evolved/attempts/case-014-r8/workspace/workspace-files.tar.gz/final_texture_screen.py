#!/usr/bin/env python3
"""Challenge symmetry-distinct March-Dollase axes under the final baseline."""

from __future__ import annotations

import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
BASE = Path(os.environ.get("PXRD_BASE_GPX", str(TMP / "final_base.gpx")))
TAG = os.environ.get("PXRD_SCREEN_TAG", "final")
PHASE_FILTER = os.environ.get("PXRD_PHASE_FILTER")

TRIALS = {
    "SrWO4": (0, [(0, 0, 1), (1, 0, 0), (1, 1, 0), (1, 0, 1), (1, 1, 1)]),
    "WO3": (1, [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1)]),
    "Sr3WO6": (2, [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1)]),
    "SrO": (3, [(1, 0, 0), (1, 1, 0), (1, 1, 1)]),
}


def freeze(gpx: G2sc.G2Project, target_index: int) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for phase_index, phase in enumerate(gpx.phases()):
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][2] = False
        if phase_index == target_index:
            hap["Pref.Ori."][1] = 1.0
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def main() -> None:
    base = G2sc.G2Project(str(BASE))
    hist = base.histogram(0)
    results = [{"phase": None, "axis": None, "wR": hist.residuals.get("wR"), "R": hist.residuals.get("R"), "MD": 1.0}]
    for family, (target_index, axes) in TRIALS.items():
        if PHASE_FILTER and family != PHASE_FILTER:
            continue
        for axis in axes:
            tag = family + "_" + "".join(str(i) for i in axis)
            print(f"\n===== final texture {tag} =====", flush=True)
            out = TMP / f"{TAG}_texture_{tag}.gpx"
            if out.exists():
                out.unlink()
            gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
            freeze(gpx, target_index)
            trial_hist = gpx.histogram(0)
            pref = gpx.phase(target_index).data["Histograms"][trial_hist.name]["Pref.Ori."]
            pref[1] = 1.0
            pref[2] = True
            pref[3] = list(axis)
            gpx.set_Controls("cycles", 10)
            gpx.refine(makeBack=False)
            result = {
                "phase": family,
                "axis": axis,
                "wR": trial_hist.residuals.get("wR"),
                "R": trial_hist.residuals.get("R"),
                "MD": pref[1],
                "mass_fractions": trial_hist.ComputeMassFracs(),
                "project": str(out),
            }
            gpx.save()
            results.append(result)
            print("FINAL_TEXTURE_RESULT " + json.dumps(result, default=float), flush=True)
    (TMP / f"{TAG}_texture_results.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
