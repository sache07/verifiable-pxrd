#!/usr/bin/env python3
"""Converge one angular-correction mode with the physical dual-line profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "dual_u0.gpx"


def flags(gpx: G2sc.G2Project, mode: str, *, background: bool, model: bool) -> None:
    hist = gpx.histogram(0)
    hist.Background[0][1] = background
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.InstrumentParameters["Zero"][2] = model and mode == "zero"
    hist.InstrumentParameters["Polariz."][1:] = [1.0, False]
    hist.InstrumentParameters["I(L2)/I(L1)"][1:] = [0.5, False]
    hist.InstrumentParameters["U"][1:] = [0.0, False]
    hist.InstrumentParameters["SH/L"][1:] = [0.002, False]
    for key in ("W", "X"):
        hist.InstrumentParameters[key][2] = model
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = model and mode == "displacement"
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = model
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = model
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][1][0] = 10.0
        hap["Mustrain"][1][0] = 0.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def snapshot(gpx: G2sc.G2Project, mode: str, step: str) -> dict:
    hist = gpx.histogram(0)
    rvals = gpx["Covariance"]["data"].get("Rvals", {})
    result = {
        "mode": mode,
        "step": step,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "zero_deg": hist.InstrumentParameters["Zero"][1],
        "shift_um": hist.SampleParameters["Shift"][0],
        "profile": {key: hist.InstrumentParameters[key][1] for key in ("U", "V", "W", "X", "Y", "SH/L")},
        "fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell() for phase in gpx.phases()},
        "max_shift_over_esd": rvals.get("Max shft/sig"),
    }
    print("DUAL_ANGULAR_STATE " + json.dumps(result, default=float), flush=True)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("none", "zero", "displacement"))
    args = parser.parse_args()
    mode = args.mode
    out = ROOT / ".tmp" / f"dual_angular_{mode}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    hist.InstrumentParameters["Zero"][1] = 0.0
    if mode in ("none", "zero"):
        hist.SampleParameters["Shift"] = [0.0, False]
    if mode == "displacement":
        hist.SampleParameters["Shift"][1] = True
    gpx.set_Controls("cycles", 16)
    states = []
    for outer in range(1, 9):
        flags(gpx, mode, background=True, model=False)
        gpx.refine(makeBack=False)
        flags(gpx, mode, background=False, model=True)
        gpx.refine(makeBack=False)
        states.append(snapshot(gpx, mode, f"outer_{outer}"))
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    for replay in range(1, 4):
        flags(gpx, mode, background=False, model=True)
        gpx.refine(makeBack=False)
        states.append(snapshot(gpx, mode, f"reopen_{replay}"))
    gpx.save()
    (ROOT / ".tmp" / f"dual_angular_{mode}_states.json").write_text(json.dumps(states, indent=2))


if __name__ == "__main__":
    main()
