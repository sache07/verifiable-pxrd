#!/usr/bin/env python3
"""Rebuild a common profile/source model after an inventory change."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import snapshot


def refine(gpx, log, label):
    gpx.do_refinements([{}])
    log.append(snapshot(gpx, label))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("output")
    args = ap.parse_args()

    output = Path(args.output).resolve()
    gpx = G2sc.G2Project(gpxfile=str(Path(args.base).resolve()))
    gpx.save(str(output))
    gpx.set_Controls("cycles", 12)
    h = gpx.histogram(0)
    log = []

    refine(gpx, log, "common_background_scales_shift_cells")
    for term in ("W", "U", "X"):
        gpx.set_Controls("parmMin", 0.0, variable=f":0:{term}")
        h.set_refinements({"Instrument Parameters": [term]})
        refine(gpx, log, f"plus_{term}")
        if term == "U" and h.InstrumentParameters[term][1] <= 1e-8:
            h.clear_refinements({"Instrument Parameters": [term]})
            h.InstrumentParameters[term][1] = 0.0
            log.append(snapshot(gpx, "pruned_bound_U"))

    gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    h.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(gpx, log, "plus_polarization")
    gpx.save()

    # Reopen and replay the complete range as a persistence check.
    gpx = G2sc.G2Project(gpxfile=str(output))
    gpx.set_Controls("cycles", 12)
    refine(gpx, log, "reopen_replay")
    gpx.save()
    output.with_suffix(".summary.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
