#!/usr/bin/env python3
"""Screen phase-specific isotropic size and strain one phase at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import snapshot


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("prefix")
    ap.add_argument("--phase-index", type=int, action="append",
                    help="limit screening to one or more phase indices")
    args = ap.parse_args()
    base = Path(args.base).resolve()
    results = []

    probe = G2sc.G2Project(gpxfile=str(base))
    names = [p.name for p in probe.phases()]
    selected = set(args.phase_index) if args.phase_index is not None else set(range(len(names)))
    for pidx, name in enumerate(names):
        if pidx not in selected:
            continue
        for kind in ("size", "strain"):
            output = Path(f"{args.prefix}_{pidx}_{kind}.gpx").resolve()
            gpx = G2sc.G2Project(gpxfile=str(base))
            gpx.save(str(output))
            gpx.set_Controls("cycles", 12)
            h = gpx.histogram(0)
            h.clear_refinements({"Instrument Parameters": ["U", "W", "X", "Polariz."]})
            p = gpx.phase(pidx)
            hap = p.data["Histograms"][h.name]
            if kind == "size":
                hap["Size"][0] = "isotropic"
                hap["Size"][1][0] = 1000.0
                p.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [h])
                var = f"{pidx}:0:Size;i"
                gpx.set_Controls("parmMin", 0.01, variable=var)
                gpx.set_Controls("parmMax", 1000.0, variable=var)
            else:
                hap["Mustrain"][0] = "isotropic"
                hap["Mustrain"][1][0] = 0.0
                p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [h])
                var = f"{pidx}:0:Mustrain;i"
                gpx.set_Controls("parmMin", 0.0, variable=var)
                gpx.set_Controls("parmMax", 5000.0, variable=var)
            gpx.do_refinements([{}])
            snap = snapshot(gpx, f"{name}_{kind}")
            snap["trial_file"] = output.name
            results.append(snap)
            gpx.save()
            print(name, kind, h.residuals.get("wR"), flush=True)

    Path(f"{args.prefix}.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
