#!/usr/bin/env python3
"""Challenge an isotropic microstrain term with low-index uniaxial axes."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import snapshot


AXES = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 0, 1),
        (1, 1, 0), (0, 1, 1), (1, 1, 1)]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("prefix")
    ap.add_argument("--phase-index", type=int, required=True)
    ap.add_argument("--start", type=float, default=3000.0)
    args = ap.parse_args()
    base = Path(args.base).resolve()
    results = []
    for axis in AXES:
        tag = "".join(str(i) for i in axis)
        output = Path(f"{args.prefix}_{tag}.gpx").resolve()
        gpx = G2sc.G2Project(gpxfile=str(base))
        gpx.save(str(output))
        gpx.set_Controls("cycles", 16)
        h = gpx.histogram(0)
        h.clear_refinements({"Instrument Parameters": ["U", "W", "X", "Polariz."]})
        p = gpx.phase(args.phase_index)
        ms = p.data["Histograms"][h.name]["Mustrain"]
        ms[0] = "uniaxial"
        ms[1][0] = ms[1][1] = args.start
        ms[2][0] = ms[2][1] = True
        ms[3] = list(axis)
        ms[5] = [False] * len(ms[5])
        for suffix in ("i", "a"):
            var = f"{args.phase_index}:0:Mustrain;{suffix}"
            gpx.set_Controls("parmMin", 0.0, variable=var)
            gpx.set_Controls("parmMax", 5000.0, variable=var)
        gpx.do_refinements([{}])
        snap = snapshot(gpx, f"uniaxial_{tag}")
        snap["axis"] = axis
        snap["trial_file"] = output.name
        results.append(snap)
        gpx.save()
        print(axis, ms[1][0], ms[1][1], h.residuals.get("wR"), flush=True)
    Path(f"{args.prefix}.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
