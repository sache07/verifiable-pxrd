#!/usr/bin/env python3
"""Combine the supported texture terms under the common baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import snapshot


TERMS = {
    1: ([0, 1, 1], 1.50),  # massicot
    5: ([1, 0, 0], 1.20),  # Pb2WO5 prototype
    6: ([0, 0, 1], 2.20),  # Pb3WO6 prototype
}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("output")
    args = ap.parse_args()
    output = Path(args.output).resolve()
    gpx = G2sc.G2Project(gpxfile=str(Path(args.base).resolve()))
    gpx.save(str(output))
    gpx.set_Controls("cycles", 16)
    h = gpx.histogram(0)
    h.clear_refinements({"Instrument Parameters": ["U", "W", "X", "Polariz."]})
    for pidx, (axis, start) in TERMS.items():
        po = gpx.phase(pidx).data["Histograms"][h.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", start, True, axis
        gpx.set_Controls("parmMin", 0.2, variable=f"{pidx}:0:MD")
        gpx.set_Controls("parmMax", 5.0, variable=f"{pidx}:0:MD")
    log = []
    gpx.do_refinements([{}])
    log.append(snapshot(gpx, "combined_texture"))
    gpx.save()
    gpx = G2sc.G2Project(gpxfile=str(output))
    gpx.set_Controls("cycles", 16)
    gpx.do_refinements([{}])
    log.append(snapshot(gpx, "reopen_replay"))
    gpx.save()
    output.with_suffix(".summary.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
