#!/usr/bin/env python3
"""Replace the origin-misread litharge atoms with a verified P4/nmm PbO model."""

from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import snapshot


def main() -> None:
    template_file = Path("litharge_template.gpx").resolve()
    template = G2sc.G2Project(newgpx=str(template_file))
    source = template.add_phase(str(Path("corrected_pbo_litharge_p4nmm.cif").resolve()),
                                phasename="PbO_litharge_corrected", fmthint="CIF")
    template.save()

    output = Path("model7_litharge_corrected.gpx").resolve()
    gpx = G2sc.G2Project(gpxfile=str(Path("model7_strain_common.gpx").resolve()))
    target = gpx.phase(2)
    old_name = target.name
    old_cell = copy.deepcopy(target.data["General"]["Cell"])
    target.data["General"] = copy.deepcopy(source.data["General"])
    target.data["General"]["Name"] = old_name
    target.data["General"]["Cell"] = old_cell
    target.data["General"]["Cell"][0] = True
    target.data["Atoms"] = copy.deepcopy(source.data["Atoms"])
    target.data["Drawing"] = copy.deepcopy(source.data["Drawing"])
    gpx.save(str(output))

    log = []
    gpx = G2sc.G2Project(gpxfile=str(output))
    gpx.set_Controls("cycles", 20)
    gpx.do_refinements([{}])
    log.append(snapshot(gpx, "corrected_litharge_reconverged"))
    gpx.save()
    gpx = G2sc.G2Project(gpxfile=str(output))
    gpx.set_Controls("cycles", 20)
    gpx.do_refinements([{}])
    log.append(snapshot(gpx, "reopen_replay"))
    gpx.save()
    output.with_suffix(".summary.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
