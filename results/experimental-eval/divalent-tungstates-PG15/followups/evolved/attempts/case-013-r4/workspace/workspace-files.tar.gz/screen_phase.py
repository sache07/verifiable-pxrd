#!/usr/bin/env python3
"""Add one watch-list phase to an existing GPX under its common nuisance model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import neutralize_hap, snapshot


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("output")
    ap.add_argument("name")
    ap.add_argument("cif")
    ap.add_argument("--start-scale", type=float, default=0.01)
    args = ap.parse_args()

    output = Path(args.output).resolve()
    gpx = G2sc.G2Project(gpxfile=str(Path(args.base).resolve()))
    gpx.save(str(output))
    h = gpx.histogram(0)
    p = gpx.add_phase(str(Path(args.cif).resolve()), phasename=args.name,
                      histograms=[h], fmthint="CIF")
    neutralize_hap(p, h.name)
    hap = p.data["Histograms"][h.name]
    hap["Scale"][:] = [args.start_scale, True]
    pidx = len(gpx.phases()) - 1
    gpx.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Scale")
    gpx.set_Controls("cycles", 12)

    log = []
    gpx.do_refinements([{}])
    first = snapshot(gpx, "scale_under_common_model")
    log.append(first)
    frac, sig = first.get("mass_fractions", {}).get(args.name, (0.0, float("inf")))
    if hap["Scale"][0] <= 1e-10 or frac <= 3.0 * sig:
        gpx.save()
        output.with_suffix(".summary.json").write_text(json.dumps(log, indent=2) + "\n")
        return
    p.set_refinements({"Cell": True})
    gpx.do_refinements([{}])
    log.append(snapshot(gpx, "plus_candidate_cell"))
    gpx.save()
    output.with_suffix(".summary.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
