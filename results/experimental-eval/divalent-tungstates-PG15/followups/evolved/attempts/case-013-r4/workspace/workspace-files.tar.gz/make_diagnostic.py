#!/usr/bin/env python3
"""Export profile arrays and a low/mid/high-angle diagnostic plot from a GPX."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("gpx")
    ap.add_argument("prefix")
    ap.add_argument("--plot-only", action="store_true")
    args = ap.parse_args()
    if args.plot_only:
        a = np.loadtxt(f"{args.prefix}_arrays.csv", delimiter=",", skiprows=1)
        x, yo, yc, diff, bg = a.T
    else:
        from GSASII import GSASIIscriptable as G2sc
        gpx = G2sc.G2Project(gpxfile=str(Path(args.gpx).resolve()))
        h = gpx.histogram(0)
        x = np.asarray(h.getdata("X"), float)
        yo = np.asarray(h.getdata("Yobs"), float)
        yc = np.asarray(h.getdata("Ycalc"), float)
        bg = np.asarray(h.getdata("Background"), float)
        diff = yo - yc
        np.savetxt(f"{args.prefix}_arrays.csv", np.column_stack([x, yo, yc, diff, bg]),
                   delimiter=",", header="two_theta_deg,observed,calculated,difference,background",
                   comments="")
        try:
            import matplotlib
        except ModuleNotFoundError:
            return

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(3, 1, figsize=(13, 10), constrained_layout=True)
    windows = [(10, 40), (40, 70), (70, 100)]
    for ax, (lo, hi) in zip(axes, windows):
        m = (x >= lo) & (x <= hi)
        scale = max(float(np.max(yo[m]) - np.min(bg[m])), 1.0)
        offset = float(np.min(bg[m])) - 0.18 * scale
        ax.plot(x[m], yo[m], color="black", lw=0.75, label="Observed")
        ax.plot(x[m], yc[m], color="#d62728", lw=0.75, label="Calculated")
        ax.plot(x[m], bg[m], color="#2ca02c", lw=0.65, label="Background")
        ax.plot(x[m], diff[m] + offset, color="#1f77b4", lw=0.65, label="Difference (offset)")
        ax.axhline(offset, color="0.75", lw=0.5)
        ax.set_xlim(lo, hi)
        ax.set_ylabel("counts")
    axes[0].legend(ncol=4, fontsize=9, loc="upper right")
    axes[-1].set_xlabel(r"$2\theta$ (degrees, Cu K$\alpha$)")
    fig.savefig(f"{args.prefix}_profile.png", dpi=180)


if __name__ == "__main__":
    main()
