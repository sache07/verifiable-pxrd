#!/usr/bin/env python3
"""Replay the accepted model, save final.gpx, and export exact derived outputs."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


BASE = Path("model7_corrected_common.gpx")
FINAL = Path("final.gpx")

PHASE_INFO = [
    {
        "name": "PbWO4 stolzite",
        "formula": "PbWO4",
        "cif": "phase_pbwo4_stolzite.cif",
        "structure_basis": "COD 9009811 (ambient-temperature stolzite)",
    },
    {
        "name": "PbO massicot",
        "formula": "PbO",
        "cif": "phase_pbo_massicot.cif",
        "structure_basis": "COD 2310433",
    },
    {
        "name": "PbO litharge",
        "formula": "PbO",
        "cif": "phase_pbo_litharge.cif",
        "structure_basis": "COD 9012700 (ambient-temperature litharge; standard P4/nmm origin choice)",
    },
    {
        "name": "Pb3O4 minium",
        "formula": "Pb3O4",
        "cif": "phase_pb3o4_minium.cif",
        "structure_basis": "COD 9012124 (room-temperature minium)",
    },
    {
        "name": "WO3 monoclinic",
        "formula": "WO3",
        "cif": "phase_wo3_monoclinic.cif",
        "structure_basis": "COD 2311041",
    },
    {
        "name": "Pb2WO5 (Pb2MoO5-type prototype)",
        "formula": "Pb2WO5",
        "cif": "phase_pb2wo5_c2m_prototype.cif",
        "structure_basis": "isovalent Mo6+->W6+ substitution in COD 7220560",
    },
    {
        "name": "Pb3WO6 (Pb3UO6-type prototype)",
        "formula": "Pb3WO6",
        "cif": "phase_pb3wo6_pnam_prototype.cif",
        "structure_basis": "isovalent U6+->W6+ substitution in COD 2310493",
    },
]


def plain_cell(cell):
    return {k: float(v) for k, v in cell.items()}


def main() -> None:
    # Save under the requested name, reopen, and perform one exact full-range replay.
    gpx = G2sc.G2Project(gpxfile=str(BASE.resolve()))
    gpx.save(str(FINAL.resolve()))
    gpx = G2sc.G2Project(gpxfile=str(FINAL.resolve()))
    gpx.set_Controls("cycles", 16)
    gpx.do_refinements([{}])
    gpx.save()

    # Reopen once more; all submitted derivatives are generated from this persisted file.
    gpx = G2sc.G2Project(gpxfile=str(FINAL.resolve()))
    h = gpx.histogram(0)
    phases = gpx.phases()
    if len(phases) != len(PHASE_INFO):
        raise RuntimeError(f"Expected {len(PHASE_INFO)} phases, found {len(phases)}")

    for p, info in zip(phases, PHASE_INFO):
        p.export_CIF(str(Path(info["cif"]).resolve()))

    x = np.asarray(h.getdata("X"), float)
    yo = np.asarray(h.getdata("Yobs"), float)
    yc = np.asarray(h.getdata("Ycalc"), float)
    bg = np.asarray(h.getdata("Background"), float)
    lo, hi = h.data["Limits"][1]
    # GSAS-II uses bin-edge logic at the limits; the two excluded edge points
    # have zero calculated intensity. Select the exact persisted fit profile.
    use = yc != 0.0
    with Path("fit.csv").open("w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(["two_theta_deg", "observed_counts", "calculated_counts",
                         "difference_counts", "background_counts"])
        writer.writerows(zip(x[use], yo[use], yc[use], (yo - yc)[use], bg[use]))

    mass = h.ComputeMassFracs()
    residuals = h.residuals
    result_phases = []
    for pidx, (p, info) in enumerate(zip(phases, PHASE_INFO)):
        frac, sig = mass[p.name]
        hap = p.data["Histograms"][h.name]
        result_phases.append({
            **info,
            "project_phase_name": p.name,
            "space_group": p.data["General"]["SGData"]["SpGrp"].strip(),
            "cell": plain_cell(p.get_cell()),
            "weight_fraction": float(frac),
            "weight_fraction_percent": 100.0 * float(frac),
            "weight_fraction_esd": float(sig),
            "weight_fraction_esd_percent": 100.0 * float(sig),
            "bragg_Rf_percent": float(residuals[f"{pidx}:0:Rf"]),
            "preferred_orientation": {
                "model": hap["Pref.Ori."][0],
                "ratio": float(hap["Pref.Ori."][1]),
                "refined": bool(hap["Pref.Ori."][2]),
                "axis_hkl": list(hap["Pref.Ori."][3]),
            },
        })

    rwp = float(residuals["wR"])
    rexp = float(residuals["wRmin"])
    cov = gpx["Covariance"]["data"]
    output = {
        "phase_fraction_basis": "Normalized over the seven modeled crystalline phases; amorphous or unmodeled material is not quantified.",
        "phases": result_phases,
        "fit_statistics": {
            "Rp_percent": float(residuals["R"]),
            "Rwp_percent": rwp,
            "Rexp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "reduced_chi_square": (rwp / rexp) ** 2,
            "R_background_percent": float(residuals["Rb"]),
            "weighted_R_background_percent": float(residuals["wRb"]),
            "n_observations": int(np.count_nonzero(use)),
            "n_refined_parameters": int(len(cov.get("varyList", []))),
            "two_theta_range_deg": [float(lo), float(hi)],
        },
        "measurement_model": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "uncertainty_model": "Poisson approximation sigma=sqrt(counts), because pointwise uncertainties were not supplied",
        },
        "project": "final.gpx",
        "profile": "fit.csv",
    }
    Path("result.json").write_text(json.dumps(output, indent=2) + "\n")


if __name__ == "__main__":
    main()
