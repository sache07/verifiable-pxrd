#!/usr/bin/env python3
"""Build and refine reproducible GSAS-II trial models for phase screening."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import spsolve

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> Path:
    if cod_id.startswith("@"):
        return Path(cod_id[1:]).resolve()
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def baseline_als(y: np.ndarray, lam: float = 2e8, p: float = 0.002, niter: int = 15) -> np.ndarray:
    """Asymmetric least-squares baseline, used only to seed a low-order polynomial."""
    n = len(y)
    d = sparse.diags([1.0, -2.0, 1.0], [0, 1, 2], shape=(n - 2, n))
    penalty = lam * (d.T @ d)
    w = np.ones(n)
    for _ in range(niter):
        z = spsolve(sparse.spdiags(w, 0, n, n) + penalty, w * y)
        w = p * (y > z) + (1.0 - p) * (y <= z)
    return z


def initial_background(x: np.ndarray, y: np.ndarray, ncoef: int = 8) -> list[float]:
    z = baseline_als(y)
    t = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    return np.polynomial.chebyshev.chebfit(t, z, ncoef - 1).tolist()


def neutralize_hap(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Pref.Ori."][1:4] = [1.0, False, [0, 0, 1]]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1000.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def snapshot(gpx, label: str) -> dict:
    h = gpx.histogram(0)
    def plain(value):
        if isinstance(value, (np.floating, np.integer)):
            return value.item()
        return value
    out = {
        "label": label,
        "residuals": {k: plain(v) for k, v in h.residuals.items()},
        "instrument": {k: v[1] for k, v in h.InstrumentParameters.items() if isinstance(v, list) and len(v) > 1},
        "sample": {k: v[0] for k, v in h.SampleParameters.items() if isinstance(v, list) and len(v) == 2},
        "phases": {},
    }
    try:
        out["mass_fractions"] = {k: [float(a), float(b)] for k, (a, b) in h.ComputeMassFracs().items()}
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        out["phases"][p.name] = {
            "cell": p.get_cell(),
            "scale": list(hap["Scale"]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return out


def refine(gpx, log: list[dict], label: str) -> None:
    gpx.do_refinements([{}])
    log.append(snapshot(gpx, label))
    h = gpx.histogram(0)
    print(label, json.dumps(h.residuals, sort_keys=True))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("output")
    ap.add_argument("phase", nargs="+", help="NAME=COD_ID, or NAME=@local/path.cif")
    ap.add_argument("--profile", action="store_true", help="refine common U/W/X after cells")
    ap.add_argument("--u", type=float, default=5.0)
    ap.add_argument("--w", type=float, default=20.0)
    ap.add_argument("--x", type=float, default=2.0)
    ap.add_argument("--shift", type=float, default=-500.0)
    ap.add_argument("--polarization", type=float, default=0.5)
    args = ap.parse_args()

    output = Path(args.output).resolve()
    gpx = G2sc.G2Project(newgpx=str(output))
    h = gpx.add_powder_histogram("pattern.xye", "instrument.instprm", fmthint="Topas")
    h.Limits("lower", 10.02)
    h.Limits("upper", 99.98)

    # Fix global sample scale and all unused correction terms.
    h.SampleParameters["Scale"][:] = [1.0, False]
    h.SampleParameters["Shift"][:] = [args.shift, False]
    h.SampleParameters["Transparency"][:] = [0.0, False]
    h.SampleParameters["SurfRoughA"][:] = [0.0, False]
    h.SampleParameters["SurfRoughB"][:] = [0.0, False]

    # A moderate, nonnegative common starting profile.
    inst = h.InstrumentParameters
    inst["Polariz."][1] = args.polarization
    inst["Polariz."][2] = False
    for key, value in {"U": args.u, "V": 0.0, "W": args.w, "X": args.x, "Y": 0.0, "Z": 0.0, "SH/L": 0.002}.items():
        inst[key][1] = value
        inst[key][2] = False

    for pidx, spec in enumerate(args.phase):
        name, cod_id = spec.split("=", 1)
        phase = gpx.add_phase(str(cif_path(cod_id)), phasename=name, histograms=[h], fmthint="CIF")
        neutralize_hap(phase, h.name)
        # Phase screening is constrained to physically meaningful nonnegative scales.
        gpx.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Scale")

    x = np.asarray(h.getdata("X"), dtype=float)
    y = np.asarray(h.getdata("Yobs"), dtype=float)
    coeffs = initial_background(x, y, 8)
    h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 8, "coeffs": coeffs, "refine": True}})
    for p in gpx.phases():
        p.set_HAP_refinements({"Scale": True}, [h])

    gpx.set_Controls("cycles", 12)
    gpx.save()
    log: list[dict] = []
    refine(gpx, log, "background_scales")

    h.set_refinements({"Sample Parameters": ["Shift"]})
    refine(gpx, log, "plus_shift")

    for p in gpx.phases():
        p.set_refinements({"Cell": True})
    refine(gpx, log, "plus_cells")

    if args.profile:
        # Release one profile component at a time to avoid compensation.
        for term in ("W", "U", "X"):
            gpx.set_Controls("parmMin", 0.0, variable=f":0:{term}")
            h.set_refinements({"Instrument Parameters": [term]})
            refine(gpx, log, f"plus_{term}")

    gpx.save()
    output.with_suffix(".summary.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
