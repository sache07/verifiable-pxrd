#!/usr/bin/env python3
"""Screen symmetry-distinct March-Dollase axes one phase at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from trial_refine import snapshot


AXES = {
    "tetragonal": [(0, 0, 1), (1, 0, 0), (1, 1, 0), (1, 0, 1)],
    "orthorhombic": [(1, 0, 0), (0, 1, 0), (0, 0, 1),
                     (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1)],
    "monoclinic": [(1, 0, 0), (0, 1, 0), (0, 0, 1),
                   (1, 0, 1), (1, 1, 0), (0, 1, 1), (1, 1, 1)],
}


def crystal_system(phase) -> str:
    laue = phase.data["General"]["SGData"].get("SGLaue", "")
    if "4/m" in laue:
        return "tetragonal"
    if laue == "mmm":
        return "orthorhombic"
    return "monoclinic"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("prefix")
    ap.add_argument("--phase-index", type=int, action="append",
                    help="limit screening to one or more phase indices")
    args = ap.parse_args()
    base = Path(args.base).resolve()
    results = []
    probe = G2sc.G2Project(gpxfile=str(base))
    names = [p.name for p in probe.phases()]
    systems = [crystal_system(p) for p in probe.phases()]
    selected = set(args.phase_index) if args.phase_index is not None else set(range(len(names)))

    for pidx, (name, system) in enumerate(zip(names, systems)):
        if pidx not in selected:
            continue
        for axis in AXES[system]:
            tag = "".join(str(i) for i in axis)
            output = Path(f"{args.prefix}_{pidx}_{tag}.gpx").resolve()
            gpx = G2sc.G2Project(gpxfile=str(base))
            gpx.save(str(output))
            gpx.set_Controls("cycles", 12)
            h = gpx.histogram(0)
            h.clear_refinements({"Instrument Parameters": ["U", "W", "X", "Polariz."]})
            p = gpx.phase(pidx)
            po = p.data["Histograms"][h.name]["Pref.Ori."]
            po[0] = "MD"
            po[1] = 1.0
            po[2] = True
            po[3] = list(axis)
            var = f"{pidx}:0:MD"
            gpx.set_Controls("parmMin", 0.2, variable=var)
            gpx.set_Controls("parmMax", 5.0, variable=var)
            gpx.do_refinements([{}])
            snap = snapshot(gpx, f"{name}_MD_{tag}")
            snap["trial_file"] = output.name
            snap["phase_index"] = pidx
            snap["axis"] = axis
            results.append(snap)
            gpx.save()
            print(name, axis, po[1], h.residuals.get("wR"), flush=True)

    Path(f"{args.prefix}.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
