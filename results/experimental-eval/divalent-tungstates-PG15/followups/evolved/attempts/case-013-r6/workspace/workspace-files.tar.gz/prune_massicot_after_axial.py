from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trial_stolzite_axial_strain.gpx"
TARGET = ROOT / "trial_axial_without_massicot_strain.gpx"


def main():
    shutil.copy2(SOURCE, TARGET)
    g = G2sc.G2Project(str(TARGET))
    h = g.histograms()[0]
    hap = g.phase("PbO_massicot").data["Histograms"][h.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    controls = g.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-5
    rows = []
    for replay in range(1, 5):
        g.save()
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(TARGET))
        h = g.histograms()[0]
        rv = g.data["Covariance"]["data"]["Rvals"]
        row = {
            "replay": replay,
            "Rwp": float(h.get_wR()),
            "GOF": float(rv["GOF"]),
            "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
            "stolzite_axial_strain": float(
                g.phase("PbWO4_stolzite").data["Histograms"][h.name]["Mustrain"][1][1]
            ),
            "massicot_scale": float(
                g.phase("PbO_massicot").data["Histograms"][h.name]["Scale"][0]
            ),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
        if replay >= 2 and row["max_shift_over_esd"] < 0.1:
            break
    (ROOT / "trial_axial_without_massicot_strain_trace.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
