from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
GRID = ROOT / "candidates/pb2o3_grid"


def neutralize(hap):
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def main():
    rows = []
    for cif in sorted(GRID.glob("*.cif")):
        target = ROOT / f"grid_{cif.stem}.gpx"
        shutil.copy2(ROOT / "physical_base7.gpx", target)
        g = G2sc.G2Project(str(target))
        h = g.histograms()[0]
        p = g.add_phase(str(cif), phasename="Pb2O3_grid", histograms=[h], fmthint="CIF")
        hap = p.data["Histograms"][h.name]
        hap["Scale"][:] = [0.59, True]
        neutralize(hap)
        p.set_refinements({"Cell": False})
        controls = g.data["Controls"]["data"]
        controls["max cyc"] = 8
        controls["min dM/M"] = 1.0e-5
        g.do_refinements([{}])
        g.save()
        rv = g.data["Covariance"]["data"]["Rvals"]
        row = {
            "cif": str(cif),
            "Pb2_x": float(cif.stem.rsplit("_", 1)[1].replace("p", ".")),
            "Rwp": float(h.get_wR()),
            "scale": float(hap["Scale"][0]),
            "GOF": float(rv["GOF"]),
            "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    (ROOT / "pb2o3_coordinate_grid.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
