from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "final_axial_candidate.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


WATCH = (
    ("PbWO4_raspite_COD9007617", cod_path("9007617")),
    ("Pb2O_COD1010382", cod_path("1010382")),
    ("PbO2_rutile_COD9007543", cod_path("9007543")),
    ("Pb3O4_orthorhombic_COD9003043", cod_path("9003043")),
    ("Pb7W8O28p8_COD9016035", cod_path("9016035")),
    ("Pb5WO8_from_Pb5MoO8", ROOT / "candidates/Pb5WO8_from_Pb5MoO8_COD_2007541.cif"),
    ("Pb5WO8_from_Pb5CrO8", ROOT / "candidates/Pb5WO8_from_Pb5CrO8_COD_3500065.cif"),
)


def neutralize(hap):
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def freeze_common_profile(g):
    h = g.histograms()[0]
    h.set_refinements({"Background": {"refine": False}})
    inst = h.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "Z", "Zero", "SH/L"):
        if key in inst:
            inst[key][2] = False
    for key, value in h.data["Sample Parameters"].items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in g.phases():
        phase.set_refinements({"Cell": False})
        hap = phase.data["Histograms"][h.name]
        hap["Size"][2][:] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])


def main():
    rows = []
    for label, cif in WATCH:
        target = ROOT / f"watch9_axial_{label}.gpx"
        shutil.copy2(BASE, target)
        g = G2sc.G2Project(str(target))
        h = g.histograms()[0]
        freeze_common_profile(g)
        phase = g.add_phase(str(cif), phasename=label, histograms=[h], fmthint="CIF")
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][:] = [0.05, True]
        neutralize(hap)
        phase.set_refinements({"Cell": False})
        controls = g.data["Controls"]["data"]
        controls["max cyc"] = 10
        controls["min dM/M"] = 1.0e-5
        g.save()
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(target))
        h = g.histograms()[0]
        phase = g.phase(label)
        scale = float(phase.data["Histograms"][h.name]["Scale"][0])
        covariance = g.data["Covariance"]["data"]
        key = f"{phase.data['pId']}:{h.data['data'][0]['hId']}:Scale"
        sigma = None
        if key in covariance["varyList"]:
            sigma = float(covariance["sig"][covariance["varyList"].index(key)])
        rvals = covariance["Rvals"]
        row = {
            "phase": label,
            "cif": str(cif),
            "scale": scale,
            "scale_statistical_su": sigma,
            "scale_over_su": None if not sigma else scale / sigma,
            "Rwp": float(rvals["Rwp"]),
            "GOF": float(rvals["GOF"]),
            "max_shift_over_esd": float(rvals.get("Max shft/sig", 0.0)),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    (ROOT / "watch9_axial_screen.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
