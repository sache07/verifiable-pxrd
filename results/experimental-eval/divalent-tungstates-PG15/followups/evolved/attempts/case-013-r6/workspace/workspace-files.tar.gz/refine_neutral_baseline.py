from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


PHASES = [
    ('PbWO4_stolzite', cod_path('9009811'), 7.18),
    ('Pb2WO5_C2m', ROOT / 'candidates/Pb2WO5_from_Pb2MoO5_COD_7220560.cif', 1.06),
    ('PbO_massicot', cod_path('2310433'), 1.79),
    ('PbO_litharge', ROOT / 'candidates/PbO_litharge_origin2.cif', 0.57),
    ('WO3_monoclinic', cod_path('2311041'), 1.14),
    ('Pb2O3', cod_path('2311012'), 0.575),
    ('Pb3O4', cod_path('1537983'), 0.140),
]


def neutralize_hap(hap):
    # GSAS-II phase broadening terms are active even if their refinement flags
    # are false. Use effectively infinite crystallite size and zero strain.
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][:] = [1.0e6, 1.0e6, 1.0]
    hap['Size'][2][:] = [False, False, False]
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][:] = [0.0, 0.0, 1.0]
    hap['Mustrain'][2][:] = [False, False, False]
    hap['Pref.Ori.'][0:3] = ['MD', 1.0, False]
    hap['HStrain'][0][:] = [0.0] * len(hap['HStrain'][0])
    hap['HStrain'][1][:] = [False] * len(hap['HStrain'][1])
    hap['Extinction'][:] = [0.0, False]
    hap['Babinet']['BabA'][:] = [0.0, False]
    hap['Babinet']['BabU'][:] = [0.0, False]


def summarize(g, label):
    h = g.histograms()[0]
    rv = g.data.get('Covariance', {}).get('data', {}).get('Rvals', {})
    ip = h.data['Instrument Parameters'][0]
    sp = h.data['Sample Parameters']
    out = {
        'label': label,
        'Rwp': h.get_wR(),
        'GOF': rv.get('GOF'),
        'Nvars': rv.get('Nvars'),
        'max_shift_over_esd': rv.get('Max shft/sig'),
        'W': ip['W'][1],
        'X': ip['X'][1],
        'shift_um': sp['Shift'][0],
        'phases': {},
    }
    for p in g.phases():
        hap = p.data['Histograms'][h.name]
        out['phases'][p.name] = {
            'scale': hap['Scale'][0],
            'mass': p.data['General']['Mass'],
            'cell': p.get_cell(),
            'size': hap['Size'][1],
            'mustrain': hap['Mustrain'][1],
        }
    print(json.dumps(out, indent=2, default=float), flush=True)


def refine(g, label):
    g.do_refinements([{}])
    g.save()
    summarize(g, label)


def main():
    out = ROOT / 'neutral_baseline.gpx'
    g = G2sc.G2Project(newgpx=str(out))
    h = g.add_powder_histogram(
        str(ROOT / 'inputs/pattern.csv'),
        str(ROOT / 'instrument.instprm'),
        fmthint='comma',
    )
    h.data['Sample Parameters']['Scale'][:] = [1.0, False]
    h.data['Sample Parameters']['Shift'][:] = [-447.0, False]
    for key in ('DisplaceX', 'DisplaceY', 'Transparency', 'Absorption',
                'SurfRoughA', 'SurfRoughB'):
        if key in h.data['Sample Parameters'] and isinstance(h.data['Sample Parameters'][key], list):
            h.data['Sample Parameters'][key][1] = False

    inst = h.data['Instrument Parameters'][0]
    for key in ('U', 'V', 'Y', 'Z', 'Zero'):
        inst[key][1:] = [0.0, False]
    inst['W'][1:] = [25.0, False]
    inst['X'][1:] = [12.0, False]
    inst['SH/L'][1:] = [0.002, False]

    h.set_refinements({'Background': {
        'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 6,
    }})

    for name, cif, scale in PHASES:
        if not cif.is_file():
            raise FileNotFoundError(cif)
        p = g.add_phase(str(cif), phasename=name, histograms=[h], fmthint='CIF')
        hap = p.data['Histograms'][h.name]
        hap['Scale'][:] = [scale, True]
        neutralize_hap(hap)
        p.set_refinements({'Cell': False})

    controls = g.data['Controls']['data']
    controls['max cyc'] = 12
    controls['min dM/M'] = 0.001
    g.save()

    # First establish phase scales/background against source cells and a fixed
    # broad common profile, then release the sole angular correction and cells.
    refine(g, 'source_cells_scales_background')
    h.data['Sample Parameters']['Shift'][1] = True
    refine(g, 'release_specimen_shift')
    for p in g.phases():
        p.set_refinements({'Cell': True})
    refine(g, 'release_all_cells')
    h.set_refinements({'Instrument Parameters': ['W', 'X']})
    refine(g, 'release_common_W_X')
    refine(g, 'common_profile_replay_1')

    # Save, reopen, and replay the exact full-range refinement.
    g.save()
    g = G2sc.G2Project(str(out))
    refine(g, 'reopen_replay_1')
    g = G2sc.G2Project(str(out))
    refine(g, 'reopen_replay_2')


if __name__ == '__main__':
    main()
