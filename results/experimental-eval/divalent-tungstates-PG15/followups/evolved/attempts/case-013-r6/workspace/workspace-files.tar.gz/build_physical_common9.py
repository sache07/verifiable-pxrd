from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PROJECT = ROOT / "physical_common9_O1B.gpx"


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = [
    ("PbWO4_stolzite", cod_path("9009811"), 7.20),
    ("Pb2WO5_monoclinic", ROOT / "candidates/Pb2WO5_from_Pb2MoO5_COD_7220560.cif", 1.06),
    ("Pb3WO6_orthorhombic", ROOT / "candidates/Pb3WO6_from_Pb3UO6_COD_2310493.cif", 0.13),
    ("PbO_massicot", cod_path("2310433"), 1.55),
    ("PbO_litharge", ROOT / "candidates/PbO_litharge_origin2.cif", 2.04),
    ("WO3_monoclinic", cod_path("2311041"), 1.09),
    ("Pb2O3_monoclinic", ROOT / "candidates/Pb2O3_COD2311012_O1_geometry_B.cif", 0.52),
    ("PbO2_orthorhombic", cod_path("1531016"), 0.37),
    ("Pb3O4_minium", cod_path("9012124"), 0.16),
]


def neutralize(hap):
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def snapshot(g, label):
    h = g.histograms()[0]
    rv = g.data["Covariance"]["data"]["Rvals"]
    ip = h.data["Instrument Parameters"][0]
    out = {
        "label": label,
        "Rwp": float(h.get_wR()),
        "GOF": float(rv["GOF"]),
        "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
        "shift_um": float(h.data["Sample Parameters"]["Shift"][0]),
        "W": float(ip["W"][1]),
        "X": float(ip["X"][1]),
        "SH/L": float(ip["SH/L"][1]),
        "phases": {
            p.name: {
                "scale": float(p.data["Histograms"][h.name]["Scale"][0]),
                "cell": p.get_cell(),
            }
            for p in g.phases()
        },
    }
    print(json.dumps(out), flush=True)
    return out


def refine(g, label, trace):
    g.do_refinements([{}])
    g.save()
    trace.append(snapshot(g, label))
    return g


def main():
    trace = []
    g = G2sc.G2Project(newgpx=str(PROJECT))
    h = g.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    sample = h.data["Sample Parameters"]
    sample["Scale"][:] = [1.0, False]
    sample["Shift"][:] = [-487.0, False]
    for key in (
        "DisplaceX", "DisplaceY", "Transparency", "Absorption",
        "SurfRoughA", "SurfRoughB",
    ):
        if key in sample and isinstance(sample[key], list):
            sample[key][1] = False

    inst = h.data["Instrument Parameters"][0]
    for key in ("U", "V", "Y", "Z", "Zero"):
        inst[key][1:] = [0.0, False]
    inst["W"][1:] = [21.0, False]
    inst["X"][1:] = [11.5, False]
    inst["SH/L"][1:] = [0.02848, False]
    h.set_refinements({
        "Background": {
            "type": "chebyschev-1", "refine": True, "no. coeffs": 6,
        }
    })

    for name, cif, scale in PHASES:
        p = g.add_phase(str(cif), phasename=name, histograms=[h], fmthint="CIF")
        hap = p.data["Histograms"][h.name]
        hap["Scale"][:] = [scale, True]
        neutralize(hap)
        p.set_refinements({"Cell": False})

    controls = g.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-3
    g.save()
    g = refine(g, "source_cells_scales_background", trace)
    h.data["Sample Parameters"]["Shift"][1] = True
    g = refine(g, "release_specimen_shift", trace)
    for p in g.phases():
        p.set_refinements({"Cell": True})
    g = refine(g, "release_cells", trace)
    h.set_refinements({"Instrument Parameters": ["W", "X"]})
    g = refine(g, "release_common_W_X", trace)
    g = refine(g, "common_profile_replay", trace)

    # Re-estimate asymmetry only after the physical inventory is coherent,
    # then fix it to avoid its strong correlation with specimen displacement.
    inst["SH/L"][2] = True
    g = refine(g, "estimate_SH_over_L", trace)
    inst["SH/L"][2] = False
    controls["min dM/M"] = 1.0e-5
    g = refine(g, "fix_SH_over_L", trace)

    for index in range(1, 6):
        g.save()
        g = G2sc.G2Project(str(PROJECT))
        g = refine(g, f"reopen_full_range_replay_{index}", trace)
        if index >= 3 and trace[-1]["max_shift_over_esd"] < 0.1:
            break
    g.save()
    (ROOT / "physical_common9_O1B_trace.json").write_text(
        json.dumps(trace, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
