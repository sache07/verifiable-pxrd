from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
src = ROOT / 'watch_PbO2_orth_COD1531016.gpx'
dst = ROOT / 'inventory8.gpx'
shutil.copy2(src, dst)

cod = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
pb3o4 = cod / '9/01/21/9012124.cif'

g = G2sc.G2Project(str(dst))
h = g.histograms()[0]
old = g.phase('Pb3O4').data['Histograms'][h.name]
old['Use'] = False
old['Scale'][1] = False
p = g.add_phase(str(pb3o4), phasename='Pb3O4_minium', histograms=[h], fmthint='CIF')
hap = p.data['Histograms'][h.name]
hap['Scale'][:] = [0.15, True]
hap['Size'][1][:] = [10.0, 10.0, 1.0]
hap['Size'][2][:] = [False, False, False]
hap['Mustrain'][1][:] = [0.0, 0.0, 1.0]
hap['Mustrain'][2][:] = [False, False, False]
hap['Pref.Ori.'][0:3] = ['MD', 1.0, False]
hap['HStrain'][0][:] = [0.0] * len(hap['HStrain'][0])
hap['HStrain'][1][:] = [False] * len(hap['HStrain'][1])
p.set_refinements({'Cell': False})

def replay(g, n):
    for _ in range(n):
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(dst))
    return g

g = replay(g, 2)
g.phase('Pb3O4_minium').set_refinements({'Cell': True})
g = replay(g, 4)

h = g.histograms()[0]
rv = g.data['Covariance']['data']['Rvals']
out = {
    'Rwp': h.get_wR(),
    'GOF': rv['GOF'],
    'max_shift_over_esd': rv.get('Max shft/sig'),
    'instrument': {k: h.data['Instrument Parameters'][0][k][1]
                   for k in ('U', 'V', 'W', 'X', 'SH/L', 'Zero')},
    'shift_um': h.data['Sample Parameters']['Shift'][0],
    'phases': {},
}
for phase in g.phases():
    hh = phase.data['Histograms'].get(h.name)
    if not hh or not hh.get('Use', True):
        continue
    out['phases'][phase.name] = {
        'scale': hh['Scale'][0],
        'mass': phase.data['General']['Mass'],
        'cell': phase.get_cell(),
    }
print(json.dumps(out, indent=2, default=float))
