from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
MODELS = [
    ("Pb3WO6_from_Pb3UO6", ROOT / "candidates/Pb3WO6_from_Pb3UO6_COD_2310493.cif", 0.10),
    ("Pb5WO8_from_Pb5MoO8", ROOT / "candidates/Pb5WO8_from_Pb5MoO8_COD_2007541.cif", 0.08),
    ("Pb5WO8_from_Pb5CrO8", ROOT / "candidates/Pb5WO8_from_Pb5CrO8_COD_3500065.cif", 0.08),
]


def neutralize(hap):
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def replay(g, path, count):
    for _ in range(count):
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(path))
    return g


def main():
    rows = []
    for label, cif, initial_scale in MODELS:
        target = ROOT / f"replacement_{label}.gpx"
        shutil.copy2(ROOT / "physical_base7.gpx", target)
        g = G2sc.G2Project(str(target))
        h = g.histograms()[0]
        p = g.add_phase(str(cif), phasename="replacement_trial", histograms=[h], fmthint="CIF")
        hap = p.data["Histograms"][h.name]
        hap["Scale"][:] = [initial_scale, True]
        neutralize(hap)
        p.set_refinements({"Cell": False})
        controls = g.data["Controls"]["data"]
        controls["max cyc"] = 15
        controls["min dM/M"] = 1.0e-5
        g.save()
        g = replay(g, target, 2)
        h = g.histograms()[0]
        hap = g.phase("replacement_trial").data["Histograms"][h.name]
        row = {
            "model": label,
            "cif": str(cif),
            "fixed_cell_Rwp": float(h.get_wR()),
            "fixed_cell_scale": float(hap["Scale"][0]),
            "source_cell": g.phase("replacement_trial").get_cell(),
        }
        if hap["Scale"][0] > 1.0e-5:
            g.phase("replacement_trial").set_refinements({"Cell": True})
            g = replay(g, target, 3)
            h = g.histograms()[0]
            hap = g.phase("replacement_trial").data["Histograms"][h.name]
        rv = g.data["Covariance"]["data"]["Rvals"]
        row.update({
            "refined_cell_Rwp": float(h.get_wR()),
            "refined_cell_scale": float(hap["Scale"][0]),
            "refined_cell": g.phase("replacement_trial").get_cell(),
            "GOF": float(rv["GOF"]),
            "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
        })
        rows.append(row)
        print(json.dumps(row), flush=True)
    (ROOT / "replacement_phase_screen.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
