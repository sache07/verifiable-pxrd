from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trial_stolzite_axial_strain.gpx"
TARGET = ROOT / "final_axial_candidate.gpx"


def snapshot(g, replay):
    h = g.histograms()[0]
    rv = g.data["Covariance"]["data"]["Rvals"]
    inst = h.data["Instrument Parameters"][0]
    return {
        "replay": replay,
        "Rwp": float(h.get_wR()),
        "GOF": float(rv["GOF"]),
        "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
        "profile_W": float(inst["W"][1]),
        "profile_X": float(inst["X"][1]),
        "specimen_shift_um": float(h.data["Sample Parameters"]["Shift"][0]),
        "phases": {
            p.name: {
                "scale": float(p.data["Histograms"][h.name]["Scale"][0]),
                "mustrain_type": p.data["Histograms"][h.name]["Mustrain"][0],
                "mustrain_values": [
                    float(x) for x in p.data["Histograms"][h.name]["Mustrain"][1]
                ],
                "mustrain_refine": [
                    bool(x) for x in p.data["Histograms"][h.name]["Mustrain"][2]
                ],
                "cell": p.get_cell(),
            }
            for p in g.phases()
        },
    }


def main():
    shutil.copy2(SOURCE, TARGET)
    g = G2sc.G2Project(str(TARGET))
    h = g.histograms()[0]
    hap = g.phase("PbWO4_stolzite").data["Histograms"][h.name]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][:] = [0.001, 2662.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][3][:] = [0, 0, 1]
    # The corrected Pb2O3 phase has a nearly flat a/c tradeoff that oscillates
    # after reopening without changing chi-square. Retain its fully released
    # converged midpoint cell, but do not claim further cell precision.
    g.phase("Pb2O3_monoclinic").set_refinements({"Cell": False})
    controls = g.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-5
    rows = []
    for replay in range(1, 7):
        g.save()
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(TARGET))
        row = snapshot(g, replay)
        rows.append(row)
        print(json.dumps(row), flush=True)
        if replay >= 3 and row["max_shift_over_esd"] < 0.1:
            break
    (ROOT / "final_axial_candidate_trace.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
