from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'neutral_baseline.gpx'


def result(g, phase_name, kind):
    h = g.histograms()[0]
    p = g.phase(phase_name)
    hap = p.data['Histograms'][h.name]
    rv = g.data['Covariance']['data']['Rvals']
    return {
        'phase': phase_name,
        'term': kind,
        'Rwp': float(h.get_wR()),
        'GOF': float(rv['GOF']),
        'max_shift_over_esd': float(rv.get('Max shft/sig', 0.0)),
        'W': float(h.data['Instrument Parameters'][0]['W'][1]),
        'X': float(h.data['Instrument Parameters'][0]['X'][1]),
        'size_um': float(hap['Size'][1][0]),
        'mustrain': float(hap['Mustrain'][1][0]),
        'scale': float(hap['Scale'][0]),
    }


def main():
    base = G2sc.G2Project(str(BASE))
    phase_names = [p.name for p in base.phases()]
    rows = []
    for phase_name in phase_names:
        for kind in ('size', 'mustrain'):
            safe = phase_name.replace('/', '_')
            target = ROOT / f'trial_{safe}_{kind}.gpx'
            shutil.copy2(BASE, target)
            g = G2sc.G2Project(str(target))
            h = g.histograms()[0]
            p = g.phase(phase_name)
            hap = p.data['Histograms'][h.name]
            if kind == 'size':
                hap['Size'][0] = 'isotropic'
                hap['Size'][1][0] = 2.0
                hap['Size'][1][2] = 1.0
                hap['Size'][2][:] = [True, False, False]
            else:
                hap['Mustrain'][0] = 'isotropic'
                hap['Mustrain'][1][0] = 300.0
                hap['Mustrain'][1][2] = 1.0
                hap['Mustrain'][2][:] = [True, False, False]
            g.data['Controls']['data']['max cyc'] = 10
            g.do_refinements([{}])
            g.save()
            row = result(g, phase_name, kind)
            rows.append(row)
            print(json.dumps(row), flush=True)
    (ROOT / 'profile_term_screen.json').write_text(json.dumps(rows, indent=2) + '\n')


if __name__ == '__main__':
    main()
