#!/usr/bin/env python3
"""Create the Pb2WO5 trial model from the isostructural Pb2MoO5 parent."""

from pathlib import Path

from pymatgen.core import Element, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
MODELS = [
    (
        ROOT / "7/22/05/7220560.cif",
        Element("Mo"),
        Path("candidates/Pb2WO5_from_Pb2MoO5_COD_7220560.cif"),
    ),
    (
        ROOT / "8/10/30/8103050.cif",
        Element("Cr"),
        Path("candidates/Pb2WO5_from_Pb2CrO5_COD_8103050.cif"),
    ),
]


def main() -> None:
    for parent, replaced_element, output in MODELS:
        structure = Structure.from_file(parent)
        structure.replace_species({replaced_element: Element("W")})
        output.parent.mkdir(parents=True, exist_ok=True)
        CifWriter(structure, symprec=0.01, refine_struct=False).write_file(output)


if __name__ == "__main__":
    main()
