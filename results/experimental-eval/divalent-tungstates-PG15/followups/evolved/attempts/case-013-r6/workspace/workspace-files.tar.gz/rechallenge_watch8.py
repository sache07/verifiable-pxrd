from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'inventory8_common.gpx'
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cp(c):
    return COD / c[0] / c[1:3] / c[3:5] / f'{c}.cif'


for name, cod_id in [
    ('raspite', '9007617'),
    ('Pb2O', '1010382'),
    ('PbO2_rutile', '9007543'),
    ('Pb3O4_orth', '9003043'),
]:
    dst = ROOT / f'watch8_{name}.gpx'
    shutil.copy2(BASE, dst)
    g = G2sc.G2Project(str(dst))
    h = g.histograms()[0]
    p = g.add_phase(str(cp(cod_id)), phasename=f'{name}_watch', histograms=[h], fmthint='CIF')
    hap = p.data['Histograms'][h.name]
    hap['Scale'][:] = [0.05, True]
    hap['Size'][1][:] = [10.0, 10.0, 1.0]
    hap['Size'][2][:] = [False, False, False]
    hap['Mustrain'][1][:] = [0.0, 0.0, 1.0]
    hap['Mustrain'][2][:] = [False, False, False]
    hap['Pref.Ori.'][0:3] = ['MD', 1.0, False]
    hap['HStrain'][0][:] = [0.0] * len(hap['HStrain'][0])
    hap['HStrain'][1][:] = [False] * len(hap['HStrain'][1])
    p.set_refinements({'Cell': False})
    for _ in range(2):
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(dst))
    h = g.histograms()[0]
    p = g.phase(f'{name}_watch')
    cov = g.data['Covariance']['data']
    key = f"{p.data['pId']}:{h.data['data'][0]['hId']}:Scale"
    i = cov['varyList'].index(key)
    out = {
        'phase': name,
        'scale': p.data['Histograms'][h.name]['Scale'][0],
        'scale_esd': cov['sig'][i],
        'Rwp': h.get_wR(),
    }
    print(json.dumps(out), flush=True)
