from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "final.gpx"
TARGET = ROOT / "trial_stolzite_uniaxial_strain.gpx"
PHASE = "PbWO4_stolzite"


def snapshot(g, replay):
    h = g.histograms()[0]
    p = g.phase(PHASE)
    hap = p.data["Histograms"][h.name]
    rv = g.data["Covariance"]["data"]["Rvals"]
    covariance = g.data["Covariance"]["data"]
    vary = covariance["varyList"]
    out = {
        "replay": replay,
        "Rwp": float(h.get_wR()),
        "GOF": float(rv["GOF"]),
        "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
        "mustrain_equatorial": float(hap["Mustrain"][1][0]),
        "mustrain_axial": float(hap["Mustrain"][1][1]),
        "axis": list(hap["Mustrain"][3]),
    }
    for label, suffix in (("equatorial", "i"), ("axial", "a")):
        key = f"{p.data['pId']}:{h.data['data'][0]['hId']}:Mustrain;{suffix}"
        if key in vary:
            out[f"mustrain_{label}_statistical_su"] = float(
                covariance["sig"][vary.index(key)]
            )
    return out


def main():
    shutil.copy2(SOURCE, TARGET)
    g = G2sc.G2Project(str(TARGET))
    h = g.histograms()[0]
    hap = g.phase(PHASE).data["Histograms"][h.name]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][:] = [500.0, 500.0, 1.0]
    hap["Mustrain"][2][:] = [True, True, False]
    hap["Mustrain"][3][:] = [0, 0, 1]
    controls = g.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-5
    rows = []
    for replay in range(1, 6):
        g.save()
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(TARGET))
        row = snapshot(g, replay)
        rows.append(row)
        print(json.dumps(row), flush=True)
        if replay >= 3 and row["max_shift_over_esd"] < 0.1:
            break
    (ROOT / "trial_stolzite_uniaxial_strain_trace.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
