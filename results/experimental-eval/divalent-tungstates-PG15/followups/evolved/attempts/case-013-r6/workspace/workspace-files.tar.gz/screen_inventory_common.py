from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'common_profile.gpx'
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def neutralize(hap):
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][:] = [10.0, 10.0, 1.0]
    hap['Size'][2][:] = [False, False, False]
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][:] = [0.0, 0.0, 1.0]
    hap['Mustrain'][2][:] = [False, False, False]
    hap['Pref.Ori.'][0:3] = ['MD', 1.0, False]
    hap['HStrain'][0][:] = [0.0] * len(hap['HStrain'][0])
    hap['HStrain'][1][:] = [False] * len(hap['HStrain'][1])
    hap['Extinction'][:] = [0.0, False]
    hap['Babinet']['BabA'][:] = [0.0, False]
    hap['Babinet']['BabU'][:] = [0.0, False]


def replay(g, n=2):
    for _ in range(n):
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(g.filename)
    return g


def scale_esd(g, p):
    h = g.histograms()[0]
    cov = g.data['Covariance']['data']
    key = f"{p.data['pId']}:{h.data['data'][0]['hId']}:Scale"
    if key not in cov['varyList']:
        return None
    return float(cov['sig'][cov['varyList'].index(key)])


rows = []
base = G2sc.G2Project(str(BASE))
base_rwp = float(base.histograms()[0].get_wR())

# Refit the full range with each non-major phase omitted.
for phase_name in [p.name for p in base.phases() if p.name != 'PbWO4_stolzite']:
    dst = ROOT / f'loo_{phase_name}.gpx'
    shutil.copy2(BASE, dst)
    g = G2sc.G2Project(str(dst))
    h = g.histograms()[0]
    hap = g.phase(phase_name).data['Histograms'][h.name]
    hap['Use'] = False
    hap['Scale'][1] = False
    g = replay(g, 2)
    out = {
        'test': 'leave_one_out',
        'phase': phase_name,
        'Rwp': float(g.histograms()[0].get_wR()),
        'delta_Rwp': float(g.histograms()[0].get_wR() - base_rwp),
        'GOF': float(g.data['Covariance']['data']['Rvals']['GOF']),
    }
    rows.append(out)
    print(json.dumps(out), flush=True)


adds = [
    ('raspite_PbWO4_COD9007617', cod_path('9007617'), 0.10),
    ('Pb2O_COD1010382', cod_path('1010382'), 0.05),
    ('PbO2_rutile_COD9007543', cod_path('9007543'), 0.05),
    ('PbO2_orth_COD1531016', cod_path('1531016'), 0.05),
    ('Pb3O4_orth_COD9003043', cod_path('9003043'), 0.05),
]

# Watch-list phases: scale is tested against the established common model
# before any cell degree of freedom is released.
for name, cif, initial_scale in adds:
    dst = ROOT / f'watch_{name}.gpx'
    shutil.copy2(BASE, dst)
    g = G2sc.G2Project(str(dst))
    h = g.histograms()[0]
    p = g.add_phase(str(cif), phasename=name, histograms=[h], fmthint='CIF')
    hap = p.data['Histograms'][h.name]
    hap['Scale'][:] = [initial_scale, True]
    neutralize(hap)
    p.set_refinements({'Cell': False})
    g = replay(g, 2)
    p = g.phase(name)
    h = g.histograms()[0]
    scale = float(p.data['Histograms'][h.name]['Scale'][0])
    esd = scale_esd(g, p)
    stage = 'scale_only'
    if scale > 1.0e-6 and esd and scale / esd >= 2.0:
        p.set_refinements({'Cell': True})
        g = replay(g, 2)
        p = g.phase(name)
        h = g.histograms()[0]
        scale = float(p.data['Histograms'][h.name]['Scale'][0])
        esd = scale_esd(g, p)
        stage = 'cell_released'
    out = {
        'test': 'watch_list_addition',
        'phase': name,
        'stage': stage,
        'scale': scale,
        'scale_esd': esd,
        'scale_over_esd': scale / esd if esd else None,
        'Rwp': float(h.get_wR()),
        'delta_Rwp': float(h.get_wR() - base_rwp),
    }
    rows.append(out)
    print(json.dumps(out), flush=True)


replacements = [
    ('Pb2WO5_C2m', 'Pb2WO5_Cr_parent', ROOT / 'candidates/Pb2WO5_from_Pb2CrO5_COD_8103050.cif', 1.0),
    ('Pb3O4', 'Pb3O4_alt_COD9012124', cod_path('9012124'), 0.13),
]

for old_name, new_name, cif, initial_scale in replacements:
    dst = ROOT / f'replace_common_{new_name}.gpx'
    shutil.copy2(BASE, dst)
    g = G2sc.G2Project(str(dst))
    h = g.histograms()[0]
    old_hap = g.phase(old_name).data['Histograms'][h.name]
    old_hap['Use'] = False
    old_hap['Scale'][1] = False
    p = g.add_phase(str(cif), phasename=new_name, histograms=[h], fmthint='CIF')
    hap = p.data['Histograms'][h.name]
    hap['Scale'][:] = [initial_scale, True]
    neutralize(hap)
    p.set_refinements({'Cell': False})
    g = replay(g, 2)
    p = g.phase(new_name)
    h = g.histograms()[0]
    scale = float(p.data['Histograms'][h.name]['Scale'][0])
    esd = scale_esd(g, p)
    if scale > 1.0e-6 and esd and scale / esd >= 2.0:
        p.set_refinements({'Cell': True})
        g = replay(g, 2)
        p = g.phase(new_name)
        h = g.histograms()[0]
        scale = float(p.data['Histograms'][h.name]['Scale'][0])
        esd = scale_esd(g, p)
    out = {
        'test': 'physical_record_replacement',
        'replaced': old_name,
        'phase': new_name,
        'scale': scale,
        'scale_esd': esd,
        'scale_over_esd': scale / esd if esd else None,
        'Rwp': float(h.get_wR()),
        'delta_Rwp': float(h.get_wR() - base_rwp),
        'cell': p.get_cell(),
    }
    rows.append(out)
    print(json.dumps(out, default=float), flush=True)

(ROOT / 'inventory_screen_common.json').write_text(json.dumps(rows, indent=2, default=float) + '\n')
