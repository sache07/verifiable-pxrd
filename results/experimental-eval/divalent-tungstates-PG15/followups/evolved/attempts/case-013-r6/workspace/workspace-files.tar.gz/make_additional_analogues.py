#!/usr/bin/env python3
"""Create physical cross-chemistry lead tungstate trial structures."""

from pathlib import Path

from pymatgen.core import Element, Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def main():
    # Pb3UO6 is the closest stoichiometric analogue returned for Pb3WO6.
    # U6+ -> W6+ is isovalent; coordinates and occupancies are retained.
    output = Path("candidates/Pb3WO6_from_Pb3UO6_COD_2310493.cif")
    output.parent.mkdir(parents=True, exist_ok=True)
    # Preserve the parent's Pnam setting because it imports directly into
    # GSAS-II; generic standardization changes to an incompatible Pnma origin.
    parent_text = (ROOT / "2/31/04/2310493.cif").read_text(encoding="utf-8")
    parent_text = parent_text.replace("data_2310493", "data_Pb3WO6_from_Pb3UO6")
    parent_text = parent_text.replace("'O6 Pb3 U'", "'O6 Pb3 W'")
    parent_text = parent_text.replace("'Pb3 (U O6)'", "'Pb3 (W O6)'")
    parent_text = parent_text.replace("'O6 Pb3 U1'", "'O6 Pb3 W1'")
    parent_text = parent_text.replace("U1 U+6", "W1 W+6")
    output.write_text(parent_text, encoding="utf-8")

    # Pb5MoO8 and Pb5CrO8 are charge-balanced structural parents for
    # Pb5WO8. Both substitutions are isovalent; the Mo parent is chemically
    # closer, while the neutron-derived Cr parent supplies an alternate.
    for cod_path, parent_element, name in (
        ("2/00/75/2007541.cif", "Mo", "Pb5WO8_from_Pb5MoO8_COD_2007541.cif"),
        ("3/50/00/3500065.cif", "Cr", "Pb5WO8_from_Pb5CrO8_COD_3500065.cif"),
    ):
        structure = Structure.from_file(ROOT / cod_path)
        structure.replace_species({Element(parent_element): Element("W")})
        output = Path("candidates") / name
        CifWriter(structure, symprec=0.01, refine_struct=False).write_file(output)


if __name__ == "__main__":
    main()
