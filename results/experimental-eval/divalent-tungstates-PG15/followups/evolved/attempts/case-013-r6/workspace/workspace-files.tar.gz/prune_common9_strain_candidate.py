from pathlib import Path
import argparse
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PHASES = (
    "Pb3WO6_orthorhombic",
    "PbO_massicot",
    "PbO_litharge",
    "Pb3O4_minium",
)


def snapshot(g, phase_name, replay_number):
    h = g.histograms()[0]
    p = g.phase(phase_name)
    hap = p.data["Histograms"][h.name]
    rv = g.data["Covariance"]["data"]["Rvals"]
    return {
        "phase": phase_name,
        "pruned_replay": replay_number,
        "Rwp": float(h.get_wR()),
        "GOF": float(rv["GOF"]),
        "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
        "scale": float(hap["Scale"][0]),
        "mustrain": float(hap["Mustrain"][1][0]),
        "profile_W": float(h.data["Instrument Parameters"][0]["W"][1]),
        "profile_X": float(h.data["Instrument Parameters"][0]["X"][1]),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=PHASES)
    args = parser.parse_args()
    source = ROOT / f"full_replay_{args.phase}_mustrain.gpx"
    target = ROOT / f"pruned_replay_{args.phase}_mustrain.gpx"
    shutil.copy2(source, target)
    g = G2sc.G2Project(str(target))
    h = g.histograms()[0]
    hap = g.phase(args.phase).data["Histograms"][h.name]
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    controls = g.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-5
    rows = []
    for replay_number in range(1, 4):
        g.save()
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(target))
        row = snapshot(g, args.phase, replay_number)
        rows.append(row)
        print(json.dumps(row), flush=True)
    output = ROOT / f"pruned_replay_{args.phase}_mustrain.json"
    output.write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
