from pathlib import Path
import csv
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"
PHASE_DIR = ROOT / "phases"

PHASE_INFO = {
    "PbWO4_stolzite": {
        "formula": "PbWO4", "space_group": "I41/a", "space_group_number": 88,
        "cif": "phases/PbWO4_stolzite.cif", "model_source": "COD 9009811",
        "assignment_confidence": "high",
    },
    "Pb2WO5_monoclinic": {
        "formula": "Pb2WO5", "space_group": "C2/m", "space_group_number": 12,
        "cif": "phases/Pb2WO5_monoclinic.cif",
        "model_source": "Pb2MoO5 prototype, COD 7220560, Mo6+ replaced by W6+",
        "assignment_confidence": "moderate",
    },
    "Pb3WO6_orthorhombic": {
        "formula": "Pb3WO6", "space_group": "Pnam", "space_group_number": 62,
        "cif": "phases/Pb3WO6_orthorhombic.cif",
        "model_source": "Pb3UO6 prototype, COD 2310493, U6+ replaced by W6+",
        "assignment_confidence": "tentative",
    },
    "PbO_massicot": {
        "formula": "PbO", "space_group": "Pbcm", "space_group_number": 57,
        "cif": "phases/PbO_massicot.cif", "model_source": "COD 2310433",
        "assignment_confidence": "high",
    },
    "PbO_litharge": {
        "formula": "PbO", "space_group": "P4/nmm", "space_group_number": 129,
        "cif": "phases/PbO_litharge.cif",
        "model_source": "COD 9012700 coordinates transformed to origin choice 2",
        "assignment_confidence": "moderate",
    },
    "WO3_monoclinic": {
        "formula": "WO3", "space_group": "P21/c", "space_group_number": 14,
        "cif": "phases/WO3_monoclinic.cif", "model_source": "COD 2311041",
        "assignment_confidence": "high",
    },
    "Pb2O3_monoclinic": {
        "formula": "Pb2O3", "space_group": "P21/c", "space_group_number": 14,
        "cif": "phases/Pb2O3_monoclinic.cif",
        "model_source": (
            "geometry-constrained variant of COD 2311012; both deposited Pb sites "
            "were retained, while O1 was relocated to (0.471328, 0.053986, "
            "0.261893) because the deposited O1 coordinate gives impossible "
            "1.33 A Pb-O and 1.72 A O-O contacts"
        ),
        "assignment_confidence": "tentative",
    },
    "PbO2_orthorhombic": {
        "formula": "PbO2", "space_group": "Pbcn", "space_group_number": 60,
        "cif": "phases/PbO2_orthorhombic.cif", "model_source": "COD 1531016",
        "assignment_confidence": "tentative",
    },
    "Pb3O4_minium": {
        "formula": "Pb3O4", "space_group": "P42/mbc", "space_group_number": 135,
        "cif": "phases/Pb3O4_minium.cif", "model_source": "COD 9012124",
        "assignment_confidence": "tentative",
    },
}


def plain(values):
    return np.asarray(np.ma.getdata(values), dtype=float)


def main():
    if not PROJECT.is_file():
        raise FileNotFoundError(PROJECT)
    PHASE_DIR.mkdir(exist_ok=True)

    g = G2sc.G2Project(str(PROJECT))
    h = g.histograms()[0]
    phases = g.phases()
    names = [p.name for p in phases]
    if names != list(PHASE_INFO):
        raise RuntimeError(f"Unexpected phase inventory/order: {names}")
    for p in phases:
        hap = p.data["Histograms"][h.name]
        if not hap.get("Use", True):
            raise RuntimeError(f"Disabled phase in final project: {p.name}")

    mass_fracs = h.ComputeMassFracs()
    if not math.isclose(sum(v[0] for v in mass_fracs.values()), 1.0, abs_tol=1e-10):
        raise RuntimeError("Crystalline weight fractions are not normalized")

    phase_rows = []
    for p in phases:
        info = PHASE_INFO[p.name]
        cif_path = ROOT / info["cif"]
        p.export_CIF(str(cif_path))
        cell, cell_su = p.get_cell_and_esd()
        cell_refined = bool(p.data["General"]["Cell"][0])
        frac, frac_su = mass_fracs[p.name]
        hap = p.data["Histograms"][h.name]
        row = {
            "name": p.name,
            "formula": info["formula"],
            "space_group": info["space_group"],
            "space_group_number": info["space_group_number"],
            "cif_path": info["cif"],
            "weight_fraction": frac,
            "weight_fraction_percent": 100.0 * frac,
            "weight_fraction_statistical_su": frac_su,
            "model_source": info["model_source"],
            "assignment_confidence": info["assignment_confidence"],
            "refined_cell": cell,
            "refined_cell_statistical_su": cell_su if cell_refined else None,
            "cell_refined_in_final_project": cell_refined,
        }
        if not cell_refined:
            row["cell_uncertainty_note"] = (
                "fixed at the midpoint of a released-cell refinement ridge; "
                "no reliable cell standard uncertainty is reported"
            )
        if hap["Mustrain"][0] == "uniaxial":
            row["microstrain_model"] = "uniaxial [001]"
            row["microstrain_equatorial_parameter"] = float(hap["Mustrain"][1][0])
            row["microstrain_axial_parameter"] = float(hap["Mustrain"][1][1])
            row["microstrain_parameter_refine_flags"] = [
                bool(hap["Mustrain"][2][0]), bool(hap["Mustrain"][2][1])
            ]
        elif hap["Mustrain"][2][0]:
            row["microstrain_model"] = "isotropic"
            row["isotropic_microstrain_parameter"] = float(hap["Mustrain"][1][0])
            key = f"{p.data['pId']}:{h.data['data'][0]['hId']}:Mustrain;i"
            covariance = g.data["Covariance"]["data"]
            if key in covariance["varyList"]:
                row["isotropic_microstrain_statistical_su"] = float(
                    covariance["sig"][covariance["varyList"].index(key)]
                )
        phase_rows.append(row)

    x = plain(h.getdata("X"))
    yobs = plain(h.getdata("Yobs"))
    ycalc = plain(h.getdata("Ycalc"))
    residual = plain(h.getdata("Residual"))
    background = plain(h.getdata("Background"))
    weights = plain(h.getdata("Yweight"))
    mask = np.ones(x.size, dtype=bool)
    for kind in ("X", "Yobs", "Ycalc", "Residual", "Background", "Yweight"):
        mask &= ~np.ma.getmaskarray(h.getdata(kind))
    mask &= np.isfinite(x + yobs + ycalc + residual + background + weights)
    x, yobs, ycalc = x[mask], yobs[mask], ycalc[mask]
    residual, background, weights = residual[mask], background[mask], weights[mask]
    if not np.allclose(residual, yobs - ycalc, rtol=0.0, atol=1e-8):
        raise RuntimeError("Stored residual is not observed minus calculated")

    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg", "observed_counts", "calculated_counts",
            "difference_counts", "background_counts",
        ])
        for values in zip(x, yobs, ycalc, residual, background):
            writer.writerow([f"{values[0]:.8f}"] + [f"{v:.8f}" for v in values[1:]])

    rv = g.data["Covariance"]["data"]["Rvals"]
    rwp_manual = 100.0 * math.sqrt(
        float(np.sum(weights * residual**2)) / float(np.sum(weights * yobs**2))
    )
    rp = 100.0 * float(np.sum(np.abs(residual))) / float(np.sum(np.abs(yobs)))
    gof = float(rv["GOF"])
    rwp = float(rv["Rwp"])
    rexp = rwp / gof
    fit_stats = {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "Rexp_percent": rexp,
        "goodness_of_fit": gof,
        "chi_square": float(rv["chisq"]),
        "reduced_chi_square": gof**2,
        "number_of_observations": int(rv["Nobs"]),
        "number_of_refined_parameters": int(rv["Nvars"]),
        "maximum_shift_over_su": float(rv["Max shft/sig"]),
        "two_theta_min_deg": float(x.min()),
        "two_theta_max_deg": float(x.max()),
    }
    if not math.isclose(rwp, rwp_manual, rel_tol=0.0, abs_tol=1e-8):
        raise RuntimeError(f"Rwp mismatch: project={rwp}, recomputed={rwp_manual}")

    inst = h.data["Instrument Parameters"][0]
    sample = h.data["Sample Parameters"]
    result = {
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "fraction_basis": "normalized over the modeled crystalline phases; no amorphous fraction determined",
        "phases": phase_rows,
        "fit_statistics": fit_stats,
        "refinement_model": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelength_Kalpha1_angstrom": float(inst["Lam1"][1]),
            "wavelength_Kalpha2_angstrom": float(inst["Lam2"][1]),
            "Kalpha2_to_Kalpha1_ratio": float(inst["I(L2)/I(L1)"][1]),
            "background": "6-term Chebyshev-1",
            "specimen_shift_um": float(sample["Shift"][0]),
            "profile_U": float(inst["U"][1]),
            "profile_V": float(inst["V"][1]),
            "profile_W": float(inst["W"][1]),
            "profile_X": float(inst["X"][1]),
            "profile_SH_over_L": float(inst["SH/L"][1]),
            "stolzite_axial_microstrain_parameter_fixed_after_screen": float(
                g.phase("PbWO4_stolzite").data["Histograms"][h.name]["Mustrain"][1][1]
            ),
            "Pb2O3_cell_fixed_after_released_cell_ridge_screen": True,
            "weighting": "Poisson counting weights (1/I) because pointwise uncertainties were not supplied",
        },
        "uncertainty_note": (
            "Reported statistical standard uncertainties come from the final least-squares covariance matrix "
            "and do not include phase-model, overlap, preferred-orientation, or instrument-profile systematics."
        ),
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
