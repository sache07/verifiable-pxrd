#!/usr/bin/env python3
"""Generate physically screened Pb2O3 Pb2-x coordinate trials."""

from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "candidates/pb2o3_grid"
X_VALUES = (0.388, 0.588, 0.608, 0.738, 0.758, 0.788, 0.838, 0.888)

TEMPLATE = """data_Pb2O3_x_{tag}
_chemical_formula_sum 'Pb2 O3'
_cell_formula_units_Z 4
_space_group_IT_number 14
_symmetry_space_group_name_H-M 'P 1 21/c 1'
_cell_length_a 7.679806
_cell_length_b 5.647949
_cell_length_c 7.723875
_cell_angle_alpha 90
_cell_angle_beta 114.267904
_cell_angle_gamma 90
loop_
_symmetry_equiv_pos_as_xyz
'x,y,z'
'-x,y+1/2,-z+1/2'
'-x,-y,-z'
'x,-y-1/2,z-1/2'
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
_atom_site_occupancy
_atom_site_U_iso_or_equiv
Pb1 Pb 0.087 0.247 0.117 1 0.010
Pb2 Pb {x:.6f} 0.742 0.854 1 0.010
O2  O  0.810 0.100 0.956 1 0.010
O3  O  0.940 0.563 0.150 1 0.010
O1  O  0.367 0.964 0.263 1 0.010
"""


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for x in X_VALUES:
        tag = f"{x:.3f}".replace(".", "p")
        path = OUT / f"Pb2O3_Pb2x_{tag}.cif"
        path.write_text(TEMPLATE.format(tag=tag, x=x), encoding="utf-8")


if __name__ == "__main__":
    main()
