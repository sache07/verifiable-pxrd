from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'common_profile.gpx'

for axis in ([0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 0, 1]):
    tag = ''.join(map(str, axis))
    dst = ROOT / f'trial_texture_stolzite_{tag}.gpx'
    shutil.copy2(BASE, dst)
    g = G2sc.G2Project(str(dst))
    h = g.histograms()[0]
    p = g.phase('PbWO4_stolzite')
    po = p.data['Histograms'][h.name]['Pref.Ori.']
    po[0] = 'MD'
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)
    g.do_refinements([{}])
    g.save()
    g = G2sc.G2Project(str(dst))
    g.do_refinements([{}])
    g.save()
    h = g.histograms()[0]
    po = g.phase('PbWO4_stolzite').data['Histograms'][h.name]['Pref.Ori.']
    cov = g.data['Covariance']['data']
    idx = [i for i, n in enumerate(cov['varyList']) if n.endswith(':MD')]
    out = {
        'axis': axis,
        'Rwp': h.get_wR(),
        'GOF': cov['Rvals']['GOF'],
        'max_shift_over_esd': cov['Rvals'].get('Max shft/sig'),
        'MD': po[1],
        'MD_esd': cov['sig'][idx[0]] if idx else None,
    }
    print(json.dumps(out), flush=True)
