from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "combined_profile3.gpx"
MODELS = (
    ("O1_geometry_A", ROOT / "candidates/Pb2O3_COD2311012_O1_geometry_A.cif"),
    ("O1_geometry_B", ROOT / "candidates/Pb2O3_COD2311012_O1_geometry_B.cif"),
)


def neutralize(hap):
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def freeze_common_model(g):
    h = g.histograms()[0]
    h.set_refinements({"Background": {"refine": False}})
    inst = h.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "Z", "Zero", "SH/L"):
        if key in inst:
            inst[key][2] = False
    for key, value in h.data["Sample Parameters"].items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in g.phases():
        phase.set_refinements({"Cell": False})
        hap = phase.data["Histograms"][h.name]
        hap["Size"][2][:] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])


def main():
    rows = []
    for label, cif in MODELS:
        target = ROOT / f"screen_Pb2O3_{label}.gpx"
        shutil.copy2(BASE, target)
        g = G2sc.G2Project(str(target))
        h = g.histograms()[0]
        old = g.phase("Pb2O3_monoclinic")
        old_hap = old.data["Histograms"][h.name]
        old_hap["Use"] = False
        old_hap["Scale"][1] = False
        old.set_refinements({"Cell": False})
        freeze_common_model(g)
        trial = g.add_phase(str(cif), phasename="Pb2O3_trial", histograms=[h], fmthint="CIF")
        hap = trial.data["Histograms"][h.name]
        hap["Scale"][:] = [0.50, True]
        neutralize(hap)
        trial.set_refinements({"Cell": False})
        controls = g.data["Controls"]["data"]
        controls["max cyc"] = 12
        controls["min dM/M"] = 1.0e-5
        g.save()
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(target))
        h = g.histograms()[0]
        trial = g.phase("Pb2O3_trial")
        hap = trial.data["Histograms"][h.name]
        rvals = g.data["Covariance"]["data"]["Rvals"]
        row = {
            "model": label,
            "cif": str(cif),
            "Rwp": float(rvals["Rwp"]),
            "GOF": float(rvals["GOF"]),
            "scale": float(hap["Scale"][0]),
            "max_shift_over_esd": float(rvals.get("Max shft/sig", 0.0)),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    (ROOT / "pb2o3_physical_O1_screen.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
