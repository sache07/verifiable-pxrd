from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'inventory8_common.gpx'
base = G2sc.G2Project(str(BASE))
h0 = base.histograms()[0]
base_rwp = float(h0.get_wR())
active = [p.name for p in base.phases()
          if p.data['Histograms'].get(h0.name, {}).get('Use', False)]
rows = []
for name in active:
    dst = ROOT / f'loo8_{name}.gpx'
    shutil.copy2(BASE, dst)
    g = G2sc.G2Project(str(dst))
    h = g.histograms()[0]
    hap = g.phase(name).data['Histograms'][h.name]
    hap['Use'] = False
    hap['Scale'][1] = False
    for _ in range(2):
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(dst))
    h = g.histograms()[0]
    out = {
        'phase': name,
        'Rwp_without': float(h.get_wR()),
        'delta_Rwp': float(h.get_wR() - base_rwp),
        'GOF_without': float(g.data['Covariance']['data']['Rvals']['GOF']),
    }
    rows.append(out)
    print(json.dumps(out), flush=True)
(ROOT / 'leave_one_out_inventory8.json').write_text(json.dumps(rows, indent=2) + '\n')
