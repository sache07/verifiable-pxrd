from pathlib import Path
import argparse
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "physical_common9_O1B.gpx"
CANDIDATES = {
    "PbO_massicot": 1108.4,
    "PbO_litharge": 7849.3,
    "WO3_monoclinic": 846.9,
    "Pb2O3_monoclinic": 7044.0,
    "Pb3O4_minium": 8591.6,
}


def snapshot(g, phase_name, replay_number):
    h = g.histograms()[0]
    p = g.phase(phase_name)
    hap = p.data["Histograms"][h.name]
    rv = g.data["Covariance"]["data"]["Rvals"]
    covariance = g.data["Covariance"]["data"]
    key = f"{p.data['pId']}:{h.data['data'][0]['hId']}:Mustrain;i"
    sigma = None
    if key in covariance["varyList"]:
        sigma = float(covariance["sig"][covariance["varyList"].index(key)])
    return {
        "phase": phase_name,
        "replay": replay_number,
        "Rwp": float(h.get_wR()),
        "GOF": float(rv["GOF"]),
        "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
        "scale": float(hap["Scale"][0]),
        "mustrain": float(hap["Mustrain"][1][0]),
        "mustrain_statistical_su": sigma,
        "profile_W": float(h.data["Instrument Parameters"][0]["W"][1]),
        "profile_X": float(h.data["Instrument Parameters"][0]["X"][1]),
        "specimen_shift_um": float(h.data["Sample Parameters"]["Shift"][0]),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=CANDIDATES)
    args = parser.parse_args()
    phase_name = args.phase
    target = ROOT / f"full_replay_{phase_name}_mustrain.gpx"
    shutil.copy2(BASE, target)
    g = G2sc.G2Project(str(target))
    h = g.histograms()[0]
    hap = g.phase(phase_name).data["Histograms"][h.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [CANDIDATES[phase_name], 0.0, 1.0]
    hap["Mustrain"][2][:] = [True, False, False]
    controls = g.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-5
    rows = []
    for replay_number in range(1, 4):
        g.save()
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(target))
        row = snapshot(g, phase_name, replay_number)
        rows.append(row)
        print(json.dumps(row), flush=True)
    output = ROOT / f"full_replay_{phase_name}_mustrain.json"
    output.write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
