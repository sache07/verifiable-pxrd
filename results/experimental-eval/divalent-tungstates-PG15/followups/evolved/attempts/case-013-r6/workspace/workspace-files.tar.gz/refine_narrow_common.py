from pathlib import Path
import shutil
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
src = ROOT / 'neutral_baseline.gpx'
dst = ROOT / 'narrow_common.gpx'
shutil.copy2(src, dst)

g = G2sc.G2Project(str(dst))
h = g.histograms()[0]
inst = h.data['Instrument Parameters'][0]
inst['W'][1:] = [12.0, False]
inst['X'][1:] = [8.0, False]
for p in g.phases():
    hap = p.data['Histograms'][h.name]
    hap['Size'][1][0] = 10.0
    hap['Size'][2][:] = [False, False, False]
    hap['Mustrain'][1][0] = 0.0
    hap['Mustrain'][2][:] = [False, False, False]
g.data['Controls']['data']['max cyc'] = 12
for i in range(3):
    g.do_refinements([{}])
    g.save()
    g = G2sc.G2Project(str(dst))

h = g.histograms()[0]
rv = g.data['Covariance']['data']['Rvals']
print(json.dumps({
    'Rwp': h.get_wR(),
    'GOF': rv['GOF'],
    'max_shift_over_esd': rv.get('Max shft/sig'),
    'W': h.data['Instrument Parameters'][0]['W'][1],
    'X': h.data['Instrument Parameters'][0]['X'][1],
    'shift_um': h.data['Sample Parameters']['Shift'][0],
    'scales': {p.name: p.data['Histograms'][h.name]['Scale'][0] for p in g.phases()},
}, indent=2))
