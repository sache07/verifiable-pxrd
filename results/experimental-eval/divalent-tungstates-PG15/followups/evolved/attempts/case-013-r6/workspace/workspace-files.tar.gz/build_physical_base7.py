from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TARGET = ROOT / "physical_base7.gpx"


def main():
    shutil.copy2(ROOT / "final.gpx", TARGET)
    g = G2sc.G2Project(str(TARGET))
    h = g.histograms()[0]
    phase = g.phase("Pb2O3_monoclinic")
    hap = phase.data["Histograms"][h.name]
    hap["Use"] = False
    hap["Scale"][1] = False
    phase.set_refinements({"Cell": False})
    g.data["Controls"]["data"]["max cyc"] = 20
    g.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    rows = []
    for index in range(4):
        g.do_refinements([{}])
        g.save()
        rv = g.data["Covariance"]["data"]["Rvals"]
        rows.append({
            "pass": index + 1,
            "Rwp": float(h.get_wR()),
            "GOF": float(rv["GOF"]),
            "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
        })
        print(json.dumps(rows[-1]), flush=True)
        g = G2sc.G2Project(str(TARGET))
        h = g.histograms()[0]
    (ROOT / "physical_base7_trace.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
