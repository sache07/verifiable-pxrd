from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "final_axial_candidate.gpx"
PHASES = (
    "Pb3WO6_orthorhombic",
    "Pb2O3_monoclinic",
    "PbO2_orthorhombic",
    "Pb3O4_minium",
)


def snapshot(g, omitted, replay):
    h = g.histograms()[0]
    rv = g.data["Covariance"]["data"]["Rvals"]
    return {
        "omitted_phase": omitted,
        "replay": replay,
        "Rwp": float(h.get_wR()),
        "GOF": float(rv["GOF"]),
        "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
        "remaining_scales": {
            phase.name: float(phase.data["Histograms"][h.name]["Scale"][0])
            for phase in g.phases()
            if phase.name != omitted
        },
    }


def main():
    rows = []
    for omitted in PHASES:
        target = ROOT / f"loo_axial_{omitted}.gpx"
        shutil.copy2(BASE, target)
        g = G2sc.G2Project(str(target))
        h = g.histograms()[0]
        phase = g.phase(omitted)
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][:] = [1.0e-12, False]
        hap["Size"][2][:] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])
        phase.set_refinements({"Cell": False})
        controls = g.data["Controls"]["data"]
        controls["max cyc"] = 20
        controls["min dM/M"] = 1.0e-5
        trial = []
        for replay in range(1, 5):
            g.save()
            g.do_refinements([{}])
            g.save()
            g = G2sc.G2Project(str(target))
            row = snapshot(g, omitted, replay)
            trial.append(row)
            print(json.dumps(row), flush=True)
            if replay >= 2 and row["max_shift_over_esd"] < 0.1:
                break
        rows.extend(trial)
    (ROOT / "leave_one_out_axial.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
