from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PB3WO6 = ROOT / "candidates/Pb3WO6_from_Pb3UO6_COD_2310493.cif"
PB2O3_MODELS = [
    ("Pb2x_0p588_short_contact", ROOT / "candidates/pb2o3_grid/Pb2O3_Pb2x_0p588.cif"),
    ("Pb2x_0p838_balanced_geometry", ROOT / "candidates/pb2o3_grid/Pb2O3_Pb2x_0p838.cif"),
]


def neutralize(hap):
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def replay(g, path, n):
    for _ in range(n):
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(path))
    return g


def main():
    rows = []
    for label, pb2o3_cif in PB2O3_MODELS:
        target = ROOT / f"combined_{label}.gpx"
        shutil.copy2(ROOT / "physical_base7.gpx", target)
        g = G2sc.G2Project(str(target))
        h = g.histograms()[0]

        p3 = g.add_phase(str(PB3WO6), phasename="Pb3WO6_trial", histograms=[h], fmthint="CIF")
        h3 = p3.data["Histograms"][h.name]
        h3["Scale"][:] = [0.14, True]
        neutralize(h3)
        # Seed from the stable single-phase challenge before testing coexistence.
        p3.data["General"]["Cell"][:] = [
            False, 13.5839342756, 12.4070316553, 8.2162273893,
            90.0, 90.0, 90.0, 1384.73258519,
        ]
        p3.set_refinements({"Cell": False})

        p2 = g.add_phase(str(pb2o3_cif), phasename="Pb2O3_trial", histograms=[h], fmthint="CIF")
        h2 = p2.data["Histograms"][h.name]
        h2["Scale"][:] = [0.16, True]
        neutralize(h2)
        p2.set_refinements({"Cell": False})

        controls = g.data["Controls"]["data"]
        controls["max cyc"] = 20
        controls["min dM/M"] = 1.0e-5
        g.save()
        g = replay(g, target, 2)
        fixed_rwp = float(g.histograms()[0].get_wR())
        p3 = g.phase("Pb3WO6_trial")
        p2 = g.phase("Pb2O3_trial")
        p3.set_refinements({"Cell": True})
        p2.set_refinements({"Cell": True})
        g = replay(g, target, 4)
        h = g.histograms()[0]
        p3 = g.phase("Pb3WO6_trial")
        p2 = g.phase("Pb2O3_trial")
        rv = g.data["Covariance"]["data"]["Rvals"]
        row = {
            "model": label,
            "fixed_cell_Rwp": fixed_rwp,
            "Rwp": float(h.get_wR()),
            "GOF": float(rv["GOF"]),
            "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
            "Pb3WO6_scale": float(p3.data["Histograms"][h.name]["Scale"][0]),
            "Pb2O3_scale": float(p2.data["Histograms"][h.name]["Scale"][0]),
            "Pb3WO6_cell": p3.get_cell(),
            "Pb2O3_cell": p2.get_cell(),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    (ROOT / "combined_physical_inventory.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
