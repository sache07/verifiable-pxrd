from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "profile_with_pb3o4_strain.gpx"


def active_phases(g, h):
    for phase in g.phases():
        hap = phase.data["Histograms"].get(h.name)
        if hap and hap.get("Use", True):
            yield phase, hap


def snapshot(g, trial_name):
    h = g.histograms()[0]
    rv = g.data["Covariance"]["data"]["Rvals"]
    values = {}
    for phase, hap in active_phases(g, h):
        values[phase.name] = {
            "scale": float(hap["Scale"][0]),
            "mustrain": float(hap["Mustrain"][1][0]),
            "mustrain_refined": bool(hap["Mustrain"][2][0]),
        }
    return {
        "trial": trial_name,
        "Rwp": float(h.get_wR()),
        "GOF": float(rv["GOF"]),
        "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
        "phases": values,
    }


def replay(g, path, count=2):
    for _ in range(count):
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(path))
    return g


def main():
    original = G2sc.G2Project(str(BASE))
    h0 = original.histograms()[0]
    names = [p.name for p, _ in active_phases(original, h0)]
    rows = []

    # Replay the accepted one-term model to provide a directly comparable base.
    base_path = ROOT / "rescreen_base.gpx"
    shutil.copy2(BASE, base_path)
    base = G2sc.G2Project(str(base_path))
    base.data["Controls"]["data"]["max cyc"] = 20
    base.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    base = replay(base, base_path, count=3)
    row = snapshot(base, "base_Pb3O4_only")
    rows.append(row)
    print(json.dumps(row), flush=True)

    for name in names:
        if name == "Pb3O4_minium":
            continue
        target = ROOT / f"rescreen_{name}_mustrain.gpx"
        shutil.copy2(base_path, target)
        g = G2sc.G2Project(str(target))
        h = g.histograms()[0]
        hap = g.phase(name).data["Histograms"][h.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2][:] = [True, False, False]
        g.data["Controls"]["data"]["max cyc"] = 20
        g.data["Controls"]["data"]["min dM/M"] = 1.0e-5
        g = replay(g, target, count=2)
        row = snapshot(g, name)
        rows.append(row)
        print(json.dumps(row), flush=True)

    (ROOT / "rescreen_final_terms.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
