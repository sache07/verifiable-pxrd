from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "final.gpx"
TARGET = ROOT / "trial_final_U.gpx"


def snapshot(g, replay):
    h = g.histograms()[0]
    rv = g.data["Covariance"]["data"]["Rvals"]
    covariance = g.data["Covariance"]["data"]
    vary = covariance["varyList"]
    u_keys = [key for key in vary if str(key).endswith(":U")]
    u_su = None
    if u_keys:
        u_su = float(covariance["sig"][vary.index(u_keys[0])])
    inst = h.data["Instrument Parameters"][0]
    return {
        "replay": replay,
        "Rwp": float(h.get_wR()),
        "GOF": float(rv["GOF"]),
        "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
        "U": float(inst["U"][1]),
        "U_statistical_su": u_su,
        "W": float(inst["W"][1]),
        "X": float(inst["X"][1]),
        "shift_um": float(h.data["Sample Parameters"]["Shift"][0]),
    }


def main():
    shutil.copy2(SOURCE, TARGET)
    g = G2sc.G2Project(str(TARGET))
    h = g.histograms()[0]
    h.data["Instrument Parameters"][0]["U"][1:] = [1.0, True]
    controls = g.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-5
    rows = []
    for replay in range(1, 7):
        g.save()
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(TARGET))
        row = snapshot(g, replay)
        rows.append(row)
        print(json.dumps(row), flush=True)
        if replay >= 3 and row["max_shift_over_esd"] < 0.1:
            break
    (ROOT / "trial_final_U_trace.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
