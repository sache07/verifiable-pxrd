from pathlib import Path
import argparse
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "combined_profile3.gpx"
PHASES = (
    "Pb3WO6_orthorhombic",
    "Pb2O3_monoclinic",
    "PbO2_orthorhombic",
    "Pb3O4_minium",
)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=PHASES)
    args = parser.parse_args()
    target = ROOT / f"final_loo_{args.phase}.gpx"
    shutil.copy2(SOURCE, target)
    g = G2sc.G2Project(str(target))
    h = g.histograms()[0]
    phase = g.phase(args.phase)
    hap = phase.data["Histograms"][h.name]
    hap["Scale"][:] = [0.0, False]
    hap["Size"][2][:] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])
    phase.set_refinements({"Cell": False})
    controls = g.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-5
    rows = []
    for replay_number in range(1, 4):
        g.save()
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(target))
        h = g.histograms()[0]
        rvals = g.data["Covariance"]["data"]["Rvals"]
        row = {
            "omitted_phase": args.phase,
            "replay": replay_number,
            "Rwp": float(rvals["Rwp"]),
            "GOF": float(rvals["GOF"]),
            "delta_Rwp_from_final": float(rvals["Rwp"] - 11.658857330895092),
            "max_shift_over_esd": float(rvals.get("Max shft/sig", 0.0)),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    output = ROOT / f"final_loo_{args.phase}.json"
    output.write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
