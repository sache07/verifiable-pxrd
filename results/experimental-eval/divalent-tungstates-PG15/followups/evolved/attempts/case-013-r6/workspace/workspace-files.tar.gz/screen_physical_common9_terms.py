from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "physical_common9_O1B.gpx"


def replay(g, path, count=1):
    for _ in range(count):
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(path))
    return g


def freeze_established_baseline(g):
    """Hold the accepted common profile/cells while screening one width term."""
    h = g.histograms()[0]
    h.set_refinements({"Background": {"refine": False}})
    inst = h.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "Z", "Zero", "SH/L"):
        if key in inst:
            inst[key][2] = False
    sample = h.data["Sample Parameters"]
    for key, value in sample.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in g.phases():
        phase.set_refinements({"Cell": False})


def parameter_esd(g, phase, histogram, token):
    covariance = g.data["Covariance"]["data"]
    prefix = f"{phase.data['pId']}:{histogram.data['data'][0]['hId']}:{token}"
    matches = [
        (name, sigma)
        for name, sigma in zip(covariance["varyList"], covariance["sig"])
        if name.startswith(prefix)
    ]
    if not matches:
        return None, None
    return matches[0][0], float(matches[0][1])


def snapshot(g, phase_name, term):
    h = g.histograms()[0]
    p = g.phase(phase_name)
    hap = p.data["Histograms"][h.name]
    rv = g.data["Covariance"]["data"]["Rvals"]
    token = "Size;i" if term == "size" else "Mustrain;i"
    key, sigma = parameter_esd(g, p, h, token)
    value = float(hap["Size"][1][0] if term == "size" else hap["Mustrain"][1][0])
    return {
        "phase": phase_name,
        "term": term,
        "Rwp": float(h.get_wR()),
        "GOF": float(rv["GOF"]),
        "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
        "scale": float(hap["Scale"][0]),
        "term_value": value,
        "term_vary_key": key,
        "term_statistical_su": sigma,
        "profile_W": float(h.data["Instrument Parameters"][0]["W"][1]),
        "profile_X": float(h.data["Instrument Parameters"][0]["X"][1]),
    }


def main():
    source = G2sc.G2Project(str(BASE))
    names = [phase.name for phase in source.phases()]
    rows = []
    for phase_name in names:
        for term in ("size", "mustrain"):
            safe_name = phase_name.replace("/", "_")
            target = ROOT / f"common9_trial_{safe_name}_{term}.gpx"
            shutil.copy2(BASE, target)
            g = G2sc.G2Project(str(target))
            h = g.histograms()[0]
            freeze_established_baseline(g)
            hap = g.phase(phase_name).data["Histograms"][h.name]
            if term == "size":
                hap["Size"][0] = "isotropic"
                hap["Size"][1][:] = [10.0, 10.0, 1.0]
                hap["Size"][2][:] = [True, False, False]
            else:
                hap["Mustrain"][0] = "isotropic"
                hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
                hap["Mustrain"][2][:] = [True, False, False]
            controls = g.data["Controls"]["data"]
            controls["max cyc"] = 10
            controls["min dM/M"] = 1.0e-5
            g.save()
            g = replay(g, target, 1)
            row = snapshot(g, phase_name, term)
            rows.append(row)
            print(json.dumps(row), flush=True)
    (ROOT / "physical_common9_term_screen.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
