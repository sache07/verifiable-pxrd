from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
FINAL = ROOT / "final.gpx"


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = [
    ("PbWO4_stolzite", cod_path("9009811"), 7.16),
    ("Pb2WO5_monoclinic", ROOT / "candidates/Pb2WO5_from_Pb2MoO5_COD_7220560.cif", 1.07),
    ("PbO_massicot", cod_path("2310433"), 1.79),
    ("PbO_litharge", ROOT / "candidates/PbO_litharge_origin2.cif", 1.98),
    ("WO3_monoclinic", cod_path("2311041"), 1.14),
    ("Pb2O3_monoclinic", cod_path("2311012"), 0.59),
    ("PbO2_orthorhombic", cod_path("1531016"), 0.43),
    ("Pb3O4_minium", cod_path("9012124"), 0.225),
]


def neutralize_hap(hap):
    # These GSAS-II terms alter the calculated pattern even when their refine
    # flags are false, so explicitly set neutral physical values.
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def snapshot(g, label):
    h = g.histograms()[0]
    rv = g.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    ip = h.data["Instrument Parameters"][0]
    out = {
        "label": label,
        "Rwp": float(h.get_wR()),
        "GOF": float(rv.get("GOF", 0.0)),
        "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
        "shift_um": float(h.data["Sample Parameters"]["Shift"][0]),
        "W": float(ip["W"][1]),
        "X": float(ip["X"][1]),
        "SH/L": float(ip["SH/L"][1]),
        "phases": {},
    }
    for p in g.phases():
        hap = p.data["Histograms"][h.name]
        out["phases"][p.name] = {
            "scale": float(hap["Scale"][0]),
            "mustrain": float(hap["Mustrain"][1][0]),
            "cell": {key: float(value) for key, value in p.get_cell().items()},
        }
    print(json.dumps(out), flush=True)
    return out


def refine(g, label, trace):
    g.do_refinements([{}])
    g.save()
    trace.append(snapshot(g, label))
    return g


def reopen():
    return G2sc.G2Project(str(FINAL))


def main():
    for _, path, _ in PHASES:
        if not path.is_file():
            raise FileNotFoundError(path)

    trace = []
    g = G2sc.G2Project(newgpx=str(FINAL))
    h = g.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )

    sample = h.data["Sample Parameters"]
    sample["Scale"][:] = [1.0, False]
    sample["Shift"][:] = [-487.0, False]
    for key in (
        "DisplaceX", "DisplaceY", "Transparency", "Absorption",
        "SurfRoughA", "SurfRoughB",
    ):
        if key in sample and isinstance(sample[key], list):
            sample[key][1] = False

    inst = h.data["Instrument Parameters"][0]
    for key in ("U", "V", "Y", "Z", "Zero"):
        inst[key][1:] = [0.0, False]
    inst["W"][1:] = [21.0, False]
    inst["X"][1:] = [11.5, False]
    # Estimated once with the coherent eight-phase inventory, then fixed to
    # avoid its strong correlation with specimen displacement.
    inst["SH/L"][1:] = [0.028483179356454894, False]

    h.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 6,
        }
    })

    for name, cif_path, scale in PHASES:
        p = g.add_phase(
            str(cif_path), phasename=name, histograms=[h], fmthint="CIF"
        )
        hap = p.data["Histograms"][h.name]
        hap["Scale"][:] = [scale, True]
        neutralize_hap(hap)
        p.set_refinements({"Cell": False})

    controls = g.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-3
    g.save()

    # Re-establish the common baseline in reversible stages.
    g = refine(g, "source_cells_scales_background", trace)
    h = g.histograms()[0]
    h.data["Sample Parameters"]["Shift"][1] = True
    g = refine(g, "release_specimen_shift", trace)
    for p in g.phases():
        p.set_refinements({"Cell": True})
    g = refine(g, "release_all_cells", trace)
    h.set_refinements({"Instrument Parameters": ["W", "X"]})
    g = refine(g, "release_common_W_X", trace)
    g = refine(g, "common_profile_replay", trace)

    # The only replay-stable phase term supported by several Pb3O4 families.
    p = g.phase("Pb3O4_minium")
    hap = p.data["Histograms"][h.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [6400.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [True, False, False]
    controls["min dM/M"] = 1.0e-5
    g = refine(g, "release_Pb3O4_isotropic_mustrain", trace)

    # Save/reopen/replay the exact full-range model. Stop only after at least
    # three replays and a small shift/esd, or after the bounded audit length.
    previous = None
    for index in range(1, 8):
        g.save()
        g = reopen()
        g = refine(g, f"reopen_full_range_replay_{index}", trace)
        current = trace[-1]
        if previous is not None and index >= 3:
            drwp = abs(current["Rwp"] - previous["Rwp"])
            old_strain = previous["phases"]["Pb3O4_minium"]["mustrain"]
            new_strain = current["phases"]["Pb3O4_minium"]["mustrain"]
            rel_strain = abs(new_strain - old_strain) / max(abs(new_strain), 1.0)
            if current["max_shift_over_esd"] < 0.1 and drwp < 0.002 and rel_strain < 0.05:
                break
        previous = current

    g.save()
    (ROOT / "final_build_trace.json").write_text(
        json.dumps(trace, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
