from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD_PB2O3 = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/31/10/2311012.cif"
)
MODELS = [
    ("raw_COD2311012", COD_PB2O3),
    ("corrected_Pb2_x_plus_half", ROOT / "candidates/Pb2O3_COD2311012_Pb2x_corrected.cif"),
    ("corrected_Pb2_xz_plus_half", ROOT / "candidates/Pb2O3_COD2311012_Pb2xz_corrected.cif"),
    ("Bi2O3_9012546_parent", ROOT / "candidates/Pb2O3_from_Bi2O3_COD9012546_Pb_cell.cif"),
    ("Bi2O3_9012546_parent_swap_ac", ROOT / "candidates/Pb2O3_from_Bi2O3_COD9012546_Pb_cell_swap_ac.cif"),
]


def neutralize(hap):
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def replay(g, path, count):
    for _ in range(count):
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(path))
    return g


def main():
    rows = []
    for label, cif in MODELS:
        target = ROOT / f"pb2o3_model_{label}.gpx"
        shutil.copy2(ROOT / "final.gpx", target)
        g = G2sc.G2Project(str(target))
        h = g.histograms()[0]
        old = g.phase("Pb2O3_monoclinic")
        old_hap = old.data["Histograms"][h.name]
        old_hap["Use"] = False
        old_hap["Scale"][1] = False
        old.set_refinements({"Cell": False})

        trial = g.add_phase(
            str(cif), phasename="Pb2O3_trial", histograms=[h], fmthint="CIF"
        )
        hap = trial.data["Histograms"][h.name]
        hap["Scale"][:] = [0.59, True]
        neutralize(hap)
        trial.set_refinements({"Cell": False})
        controls = g.data["Controls"]["data"]
        controls["max cyc"] = 15
        controls["min dM/M"] = 1.0e-5
        g.save()

        # Compare scale first at the common source cell, then release cell.
        g = replay(g, target, 2)
        h = g.histograms()[0]
        fixed_cell_rwp = float(h.get_wR())
        fixed_cell_scale = float(
            g.phase("Pb2O3_trial").data["Histograms"][h.name]["Scale"][0]
        )
        g.phase("Pb2O3_trial").set_refinements({"Cell": True})
        g = replay(g, target, 3)
        h = g.histograms()[0]
        rv = g.data["Covariance"]["data"]["Rvals"]
        hap = g.phase("Pb2O3_trial").data["Histograms"][h.name]
        row = {
            "model": label,
            "cif": str(cif),
            "fixed_cell_Rwp": fixed_cell_rwp,
            "fixed_cell_scale": fixed_cell_scale,
            "refined_cell_Rwp": float(h.get_wR()),
            "refined_cell_scale": float(hap["Scale"][0]),
            "cell": g.phase("Pb2O3_trial").get_cell(),
            "GOF": float(rv["GOF"]),
            "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
            "Pb3O4_mustrain": float(
                g.phase("Pb3O4_minium").data["Histograms"][h.name]["Mustrain"][1][0]
            ),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    (ROOT / "pb2o3_model_screen.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
