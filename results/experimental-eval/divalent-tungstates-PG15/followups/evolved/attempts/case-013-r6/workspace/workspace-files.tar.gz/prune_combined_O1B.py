from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "combined_profile_O1B_all.gpx"
TARGET = ROOT / "combined_profile_O1B_pruned.gpx"
PRUNE = ("PbO_massicot",)


def snapshot(g, replay_number):
    h = g.histograms()[0]
    rv = g.data["Covariance"]["data"]["Rvals"]
    covariance = g.data["Covariance"]["data"]
    phase_data = {}
    for phase in g.phases():
        hap = phase.data["Histograms"][h.name]
        row = {
            "scale": float(hap["Scale"][0]),
            "mustrain": float(hap["Mustrain"][1][0]),
            "mustrain_refined": bool(hap["Mustrain"][2][0]),
            "cell": phase.get_cell(),
        }
        key = f"{phase.data['pId']}:{h.data['data'][0]['hId']}:Mustrain;i"
        if key in covariance["varyList"]:
            row["mustrain_statistical_su"] = float(
                covariance["sig"][covariance["varyList"].index(key)]
            )
        phase_data[phase.name] = row
    return {
        "replay": replay_number,
        "Rwp": float(h.get_wR()),
        "GOF": float(rv["GOF"]),
        "max_shift_over_esd": float(rv.get("Max shft/sig", 0.0)),
        "profile_W": float(h.data["Instrument Parameters"][0]["W"][1]),
        "profile_X": float(h.data["Instrument Parameters"][0]["X"][1]),
        "specimen_shift_um": float(h.data["Sample Parameters"]["Shift"][0]),
        "phases": phase_data,
    }


def main():
    shutil.copy2(SOURCE, TARGET)
    g = G2sc.G2Project(str(TARGET))
    h = g.histograms()[0]
    for phase_name in PRUNE:
        hap = g.phase(phase_name).data["Histograms"][h.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
    controls = g.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-5
    rows = []
    for replay_number in range(1, 7):
        g.save()
        g.do_refinements([{}])
        g.save()
        g = G2sc.G2Project(str(TARGET))
        row = snapshot(g, replay_number)
        rows.append(row)
        print(json.dumps(row), flush=True)
        if replay_number >= 3 and row["max_shift_over_esd"] < 0.1:
            break
    (ROOT / "combined_profile_O1B_pruned_trace.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
