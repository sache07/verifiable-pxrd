#!/usr/bin/env python3
"""Extend a converged GSAS-II trial with selected physical effects."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc

G2sc.SetPrintLevel("none")

ROOT = Path(__file__).resolve().parents[1]


def main():
    source = ROOT / sys.argv[1]
    actions = sys.argv[2:]
    tag = source.stem + "_" + "-".join(actions)
    out = ROOT / ".tmp" / f"{tag}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(source), newgpx=str(out))
    hist = gpx.histogram(0)
    wo3, mno2 = gpx.phases()
    gpx.set_Controls("cycles", 12)

    stages = []
    for action in actions:
        if action == "mnsize":
            mno2.setSampleProfile(hist, "size", "isotropic", 0.2, LGmix=0.5)
            mno2.set_HAP_refinements({
                "Size": {"type": "isotropic", "value": 0.2, "refine": True,
                         "LGmix": {"value": 0.5, "refine": False}}
            }, [hist])
            gpx.set_Controls("parmMin", 0.02, "1:0:Size;i")
            gpx.set_Controls("parmMax", 10.0, "1:0:Size;i")
            stages.append({})
        elif action in ("wopo2", "wopo4"):
            order = int(action[-1])
            wo3.HAPvalue("PO", order, [hist])
            wo3.set_HAP_refinements({"Pref.Ori.": True}, [hist])
            stages.append({})
        elif action in ("mnpo2", "mnpo4"):
            order = int(action[-1])
            mno2.HAPvalue("PO", order, [hist])
            mno2.set_HAP_refinements({"Pref.Ori.": True}, [hist])
            stages.append({})
        elif action == "polar":
            gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
            gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
            stages.append({"set": {"Instrument Parameters": ["Polariz."]}})
        elif action == "shl":
            hist.InstrumentParameters["SH/L"][1] = 0.01
            gpx.set_Controls("parmMin", 0.0001, ":0:SH/L")
            gpx.set_Controls("parmMax", 0.2, ":0:SH/L")
            stages.append({"set": {"Instrument Parameters": ["SH/L"]}})
        else:
            raise ValueError(f"Unknown action {action}")
    stages.append({})
    gpx.save()
    gpx.do_refinements(stages)
    gpx.save()

    cov = gpx.data["Covariance"]["data"]
    result = {
        "tag": tag,
        "actions": actions,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "cells": {p.name: p.get_cell_and_esd() for p in gpx.phases()},
        "instrument": {k: hist.InstrumentParameters[k] for k in
                       ("Polariz.", "U", "V", "W", "X", "Y", "SH/L")},
        "hap": {p.name: p.getHAPvalues(hist) for p in gpx.phases()},
        "rvals": cov.get("Rvals", {}),
        "vary_list": cov.get("varyList", []),
        "frozen": gpx.get_Frozen(),
    }
    (ROOT / ".tmp" / f"{tag}.json").write_text(
        json.dumps(result, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x))
    )
    print(json.dumps({
        "tag": tag, "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"), "fractions": hist.ComputeMassFracs(),
        "sizes": {p.name: p.getHAPvalues(hist)["Size"] for p in gpx.phases()},
        "preferred_orientation": {p.name: p.getHAPvalues(hist)["Pref.Ori."] for p in gpx.phases()},
        "instrument": result["instrument"], "frozen": gpx.get_Frozen(),
        "message": cov.get("Rvals", {}).get("msg"),
    }, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)))


if __name__ == "__main__":
    main()
