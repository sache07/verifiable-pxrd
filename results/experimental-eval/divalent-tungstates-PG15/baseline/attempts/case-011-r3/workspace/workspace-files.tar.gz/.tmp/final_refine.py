#!/usr/bin/env python3
"""Create the final two-phase GSAS-II refinement and requested outputs."""

from pathlib import Path
import csv
import json

from GSASII import GSASIIscriptable as G2sc

G2sc.SetPrintLevel("none")

ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def serial(value):
    if hasattr(value, "tolist"):
        return value.tolist()
    return str(value)


def main():
    project_path = ROOT / "final.gpx"
    gpx = G2sc.G2Project(newgpx=str(project_path))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / ".tmp" / "lab_cuka.instprm"),
        fmthint="comma/tab/semicolon",
    )

    # Use the full measured range and Poisson counting weights supplied by the
    # GSAS-II CSV importer (the input has no pointwise standard uncertainties).
    hist.SampleParameters["Scale"][:] = [1.0, False]
    hist.SampleParameters["Shift"][:] = [-600.0, False]
    inst = hist.InstrumentParameters
    inst["U"][:] = [0.0, 0.0, False]
    inst["V"][:] = [0.0, 0.0, False]
    inst["W"][:] = [40.0, 40.0, False]
    inst["X"][:] = [0.0, 0.0, False]
    inst["Y"][:] = [15.0, 15.0, False]

    wo3 = gpx.add_phase(
        str(cod_path("2106293")), phasename="WO3_triclinic_P-1",
        histograms=[hist], fmthint="CIF",
    )
    mno2 = gpx.add_phase(
        str(cod_path("1514110")), phasename="beta-MnO2_pyrolusite",
        histograms=[hist], fmthint="CIF",
    )
    wo3.HAPvalue("Scale", 1.0, [hist])
    mno2.HAPvalue("Scale", 2.0, [hist])
    wo3.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=0.5)
    mno2.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=0.5)

    gpx.set_Controls("cycles", 12)
    bounds = [
        ("0:0:Scale", 0.0, 100.0),
        ("1:0:Scale", 0.0, 200.0),
        (":0:Shift", -2000.0, 2000.0),
        (":0:W", 0.001, 1000.0),
        (":0:Y", 0.0, 200.0),
        ("0:0:Size;i", 0.02, 10.0),
        ("1:0:Size;i", 0.02, 10.0),
    ]
    for variable, lower, upper in bounds:
        gpx.set_Controls("parmMin", lower, variable)
        gpx.set_Controls("parmMax", upper, variable)

    # Stage the refinement to separate position, profile and intensity effects.
    gpx.save()
    gpx.do_refinements([
        {"set": {
            "Background": {"type": "chebyschev-1", "refine": True,
                           "no. coeffs": 15},
            "Scale": True,
        }},
        {"set": {"Sample Parameters": ["Shift"]}},
        {"set": {"Cell": True}},
        {"set": {"Instrument Parameters": ["W", "Y"]}},
        {"set": {"Size": {
            "type": "isotropic", "value": 1.0, "refine": True,
            "LGmix": {"value": 0.5, "refine": False},
        }}, "phases": [wo3]},
        {},
    ])

    # The MnO2 lines require modest phase-specific broadening.
    mno2.setSampleProfile(hist, "size", "isotropic", 0.2, LGmix=0.5)
    mno2.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 0.2, "refine": True,
                 "LGmix": {"value": 0.5, "refine": False}},
    }, [hist])
    gpx.do_refinements([{}, {}])

    # A single symmetry-allowed second-order texture coefficient for the
    # rutile-type phase removes a reproducible relative-intensity bias.
    mno2.HAPvalue("PO", 2, [hist])
    mno2.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    gpx.do_refinements([{}, {}, {}])
    gpx.save()

    cov = gpx.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    if gpx.get_Frozen():
        raise RuntimeError(f"Final refinement has frozen variables: {gpx.get_Frozen()}")
    if not rvals.get("converged", False):
        raise RuntimeError("Final refinement did not converge")

    cif_paths = {
        wo3.name: ROOT / "phase_WO3_triclinic.cif",
        mno2.name: ROOT / "phase_beta_MnO2.cif",
    }
    for phase in gpx.phases():
        phase.export_CIF(str(cif_paths[phase.name]))

    x = hist.getdata("x")
    observed = hist.getdata("yobs")
    calculated = hist.getdata("ycalc")
    difference = hist.getdata("residual")
    background = hist.getdata("background")
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg", "observed_intensity", "calculated_intensity",
            "difference_observed_minus_calculated", "calculated_background",
        ])
        writer.writerows(zip(x, observed, calculated, difference, background))

    fractions = hist.ComputeMassFracs()
    phase_specs = [
        (wo3, "Tungsten trioxide", "WO3", "P -1", "2106293"),
        (mno2, "Pyrolusite (beta-manganese dioxide)", "MnO2", "P 42/m n m", "1514110"),
    ]
    phase_results = []
    for phase, display_name, formula, space_group, source_id in phase_specs:
        fraction, fraction_esd = fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phase_results.append({
            "name": display_name,
            "formula": formula,
            "space_group": space_group,
            "source_structure": f"COD {source_id}",
            "cif_path": cif_paths[phase.name].name,
            "weight_fraction": fraction,
            "weight_fraction_formal_esd": fraction_esd,
            "unit_cell": cell,
            "unit_cell_formal_esd": cell_esd,
        })

    fit_statistics = {
        "Rp_percent": hist.residuals.get("R"),
        "Rwp_percent": hist.residuals.get("wR"),
        "R_expected_percent": hist.residuals.get("wRmin"),
        "goodness_of_fit_sqrt_reduced_chi_squared": rvals.get("GOF"),
        "reduced_chi_squared": (rvals.get("GOF") ** 2
                                if rvals.get("GOF") is not None else None),
        "chi_squared": rvals.get("chisq"),
        "n_observations": rvals.get("Nobs"),
        "n_refined_variables": rvals.get("Nvars"),
        "maximum_shift_over_esd": rvals.get("Max shft/sig"),
        "converged": rvals.get("converged"),
    }
    result = {
        "phases": phase_results,
        "fit_statistics": fit_statistics,
        "profile_path": "fit.csv",
        "gsas_project_path": "final.gpx",
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "uncertainty_note": (
            "Weight-fraction ESDs are formal covariance estimates only; model, "
            "microabsorption, texture, and uncalibrated-profile systematics are larger."
        ),
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, default=serial) + "\n"
    )

    print(json.dumps({
        "residuals": hist.residuals,
        "rvals": {key: rvals.get(key) for key in
                  ("converged", "chisq", "Nobs", "Nvars", "Rwp", "GOF",
                   "Max shft/sig", "msg")},
        "fractions": fractions,
        "cells": {phase.name: phase.get_cell_and_esd()
                  for phase in gpx.phases()},
        "instrument": {key: inst[key] for key in
                       ("Lam1", "Lam2", "I(L2)/I(L1)", "W", "Y")},
        "sample_shift": hist.SampleParameters["Shift"],
        "hap": {phase.name: {
            "scale": phase.getHAPvalues(hist)["Scale"],
            "size": phase.getHAPvalues(hist)["Size"],
            "preferred_orientation": phase.getHAPvalues(hist)["Pref.Ori."],
        } for phase in gpx.phases()},
    }, indent=2, default=serial))


if __name__ == "__main__":
    main()
