#!/usr/bin/env python3
"""Physically constrained GSAS-II comparison refinement."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc

G2sc.SetPrintLevel("none")

ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main():
    wo3_id = sys.argv[1]
    profile = sys.argv[2] if len(sys.argv) > 2 else "wy"
    tag = f"{wo3_id}_{profile}"
    out = ROOT / ".tmp" / f"clean_{tag}.gpx"
    if out.exists():
        out.unlink()

    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / ".tmp" / "lab_cuka.instprm"),
        fmthint="comma/tab/semicolon",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 99.95)
    hist.SampleParameters["Scale"][:] = [1.0, False]
    hist.SampleParameters["Shift"][:] = [-600.0, False]
    inst = hist.InstrumentParameters
    inst["U"][:] = [0.0, 0.0, False]
    inst["V"][:] = [0.0, 0.0, False]
    inst["W"][:] = [40.0, 40.0, False]
    inst["X"][:] = [0.0, 0.0, False]
    inst["Y"][:] = [15.0, 15.0, False]

    wo3_file = (ROOT / ".tmp" / "wo3_loopstra_p21n.cif"
                if wo3_id == "loopstra_std" else cod_path(wo3_id))
    wo3 = gpx.add_phase(str(wo3_file), phasename=f"WO3_{wo3_id}",
                        histograms=[hist], fmthint="CIF")
    mno2 = gpx.add_phase(str(cod_path("1514110")), phasename="beta-MnO2",
                         histograms=[hist], fmthint="CIF")
    wo3.HAPvalue("Scale", 1.0)
    mno2.HAPvalue("Scale", 2.0)
    wo3.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=0.5)
    mno2.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=0.5)

    gpx.set_Controls("cycles", 10)
    for var, lo, hi in [
        ("0:0:Scale", 0.0, 100.0), ("1:0:Scale", 0.0, 100.0),
        (":0:Shift", -2000.0, 2000.0), (":0:U", 0.0, 1000.0),
        (":0:W", 0.001, 1000.0), (":0:Y", 0.0, 200.0),
        ("0:0:Size;i", 0.05, 10.0),
    ]:
        gpx.set_Controls("parmMin", lo, var)
        gpx.set_Controls("parmMax", hi, var)

    profile_vars = ["W", "Y"] if profile == "wy" else ["U", "W", "Y"]
    stages = [
        {"set": {"Background": {"type": "chebyschev-1", "refine": True,
                                  "no. coeffs": 15}, "Scale": True}},
        {"set": {"Sample Parameters": ["Shift"]}},
        {"set": {"Cell": True}},
        {"set": {"Instrument Parameters": profile_vars}},
        {"set": {"Size": {"type": "isotropic", "value": 1.0,
                            "refine": True,
                            "LGmix": {"value": 0.5, "refine": False}}},
         "phases": [wo3]},
        {},
    ]
    gpx.save()
    gpx.do_refinements(stages)
    gpx.save()

    cov = gpx.data["Covariance"]["data"]
    result = {
        "wo3_id": wo3_id,
        "profile": profile,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "cells": {p.name: p.get_cell_and_esd() for p in gpx.phases()},
        "sample": {k: hist.SampleParameters[k] for k in
                   ("Scale", "Type", "Gonio. radius", "Shift", "Transparency")},
        "instrument": {k: inst[k] for k in
                       ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "SH/L")},
        "hap": {p.name: p.getHAPvalues(hist) for p in gpx.phases()},
        "rvals": cov.get("Rvals", {}),
        "vary_list": cov.get("varyList", []),
        "frozen": gpx.get_Frozen(),
    }
    (ROOT / ".tmp" / f"clean_{tag}.json").write_text(
        json.dumps(result, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x))
    )
    print(json.dumps({
        "tag": tag,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "fractions": hist.ComputeMassFracs(),
        "shift": hist.SampleParameters["Shift"],
        "profile_values": {k: inst[k][1] for k in profile_vars},
        "frozen": gpx.get_Frozen(),
        "message": cov.get("Rvals", {}).get("msg"),
    }, indent=2))


if __name__ == "__main__":
    main()
