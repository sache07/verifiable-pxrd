#!/usr/bin/env python3
"""Screen an additional crystalline phase against a converged two-phase model."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc

G2sc.SetPrintLevel("none")

ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main():
    source = ROOT / sys.argv[1]
    candidate_id = sys.argv[2]
    label = sys.argv[3]
    out = ROOT / ".tmp" / f"screen_{candidate_id}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(source), newgpx=str(out))
    hist = gpx.histogram(0)
    cand = gpx.add_phase(str(cod_path(candidate_id)), phasename=label,
                         histograms=[hist], fmthint="CIF")
    cand.HAPvalue("Scale", 0.5, [hist])
    cand.set_HAP_refinements({"Scale": True}, [hist])
    cand.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=0.5)
    gpx.set_Controls("parmMin", 0.0, "2:0:Scale")
    gpx.set_Controls("parmMax", 100.0, "2:0:Scale")
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.do_refinements([{}, {}])
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    result = {
        "candidate_id": candidate_id,
        "label": label,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "scale": cand.HAPvalue("Scale", targethistlist=[hist]),
        "frozen": gpx.get_Frozen(),
        "rvals": cov.get("Rvals", {}),
    }
    (ROOT / ".tmp" / f"screen_{candidate_id}.json").write_text(
        json.dumps(result, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x))
    )
    print(json.dumps(result, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)))


if __name__ == "__main__":
    main()
