#!/usr/bin/env python3
"""Run comparable two-phase GSAS-II trial refinements."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc

G2sc.SetPrintLevel("warn")


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summarize(gpx, label):
    hist = gpx.histogram(0)
    print(f"SUMMARY {label} residuals={hist.residuals}")
    print("INSTRUMENT", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "SH/L")})
    print("SAMPLE", {k: v for k, v in hist.SampleParameters.items()
                     if k in ("Type", "Shift", "Transparency", "Gonio. radius")})
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        print("PHASE", phase.name, "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "mustrain", hap["Mustrain"])
    try:
        print("MASSFRACS", hist.ComputeMassFracs())
    except Exception as exc:
        print("MASSFRACS_ERROR", repr(exc))


def main():
    wo3_id = sys.argv[1]
    out = ROOT / ".tmp" / f"trial_{wo3_id}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / ".tmp" / "lab_cuka.instprm"),
        fmthint="comma/tab/semicolon",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 99.95)
    hist.SampleParameters["Shift"][0] = -500.0
    wo3 = gpx.add_phase(str(cod_path(wo3_id)), phasename=f"WO3_{wo3_id}",
                        histograms=[hist], fmthint="CIF")
    mno2 = gpx.add_phase(str(cod_path("1514110")), phasename="beta-MnO2",
                         histograms=[hist], fmthint="CIF")
    wo3.HAPvalue("Scale", 1.0)
    mno2.HAPvalue("Scale", 0.35)
    wo3.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=0.5)
    mno2.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=0.5)
    gpx.set_Controls("cycles", 8)
    gpx.save()

    stages = [
        {"set": {"Background": {"type": "chebyschev-1", "refine": True,
                                  "no. coeffs": 15},
                 "Scale": True}},
        {"set": {"Sample Parameters": ["Shift"]}},
        {"set": {"Cell": True}},
        {"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}},
        {"set": {"Size": {"type": "isotropic", "refine": True,
                            "LGmix": {"value": 0.5, "refine": True}}}},
    ]
    for i, stage in enumerate(stages, 1):
        try:
            gpx.do_refinements([stage])
            summarize(gpx, f"stage{i}")
        except Exception as exc:
            print(f"STAGE_ERROR {i} {exc!r}")
            summarize(gpx, f"failed_stage{i}")
            raise
    gpx.save()
    summary = {
        "wo3_id": wo3_id,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "sample": {k: v for k, v in hist.SampleParameters.items()
                   if k in ("Type", "Shift", "Transparency", "Gonio. radius")},
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
    }
    (ROOT / ".tmp" / f"trial_{wo3_id}.json").write_text(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
