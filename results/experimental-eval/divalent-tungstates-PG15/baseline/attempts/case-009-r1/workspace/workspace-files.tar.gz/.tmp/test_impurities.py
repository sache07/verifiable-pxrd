from pathlib import Path
from GSASII import GSASIIscriptable as G2sc
G2sc.SetPrintLevel('none')
ROOT=Path(__file__).resolve().parents[1]
DB=Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')

def cif(cid):
    return DB/cid[0]/cid[1:3]/cid[3:5]/f'{cid}.cif'

candidates={
    'Mn3WO6':'2002703',
    'Mn3O4':'9001963',
    'WO3':'1528915',
    'Mn2O3':'1514230',
    'MnO':'1514108',
}
for name,cid in candidates.items():
    out=ROOT/f'.tmp/imp_{name}.gpx'
    p=G2sc.G2Project(gpxfile=str(ROOT/'.tmp/profile_X.gpx'),newgpx=str(out))
    p.data['Controls']['data']['max cyc']=10
    p.data['Controls']['data']['min dM/M']=1e-5
    h=p.histogram(0); major=p.phase(0)
    minor=p.add_phase(str(cif(cid)),phasename=name,histograms=[h],fmthint='CIF')
    smaj=major.getHAPvalues(h)['Scale'][0]
    mmaj=major.data['General']['Mass']; mmin=minor.data['General']['Mass']
    minor.getHAPvalues(h)['Scale']=[smaj*0.01*mmaj/mmin,True]
    p.refine()
    r=p.data['Covariance']['data'].get('Rvals',{})
    try: fr=h.ComputeMassFracs()
    except Exception as e: fr={'error':str(e)}
    print(name,'Rwp',h.get_wR(),'GOF',r.get('GOF'),'conv',r.get('converged'),
          'scales',major.getHAPvalues(h)['Scale'],minor.getHAPvalues(h)['Scale'],
          'fractions',fr,'msg',r.get('msg','').replace('\n',' | '),flush=True)
