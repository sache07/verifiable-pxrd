from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
CIF = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif')
GPX = ROOT / '.tmp' / 'trial.gpx'

gpx = G2sc.G2Project(newgpx=str(GPX))
hist = gpx.add_powder_histogram(
    str(ROOT / 'inputs' / 'pattern.csv'),
    str(ROOT / '.tmp' / 'cu_ka.instprm'),
    fmthint='comma',
)
phase = gpx.add_phase(str(CIF), phasename='MnWO4', histograms=[hist], fmthint='CIF')
hist.set_refinements({
    'Limits': [10.0, 100.0],
    'Background': {
        'type': 'chebyschev-1',
        'refine': True,
        'no. coeffs': 12,
    },
})
phase.set_HAP_refinements({'Scale': True})
hist.data['Sample Parameters']['Scale'] = [1.0, False]
gpx.save()

def state(label):
    inst = hist.data['Instrument Parameters'][0]
    print('\nSTATE', label)
    print('wR', hist.get_wR(), 'residuals', hist.data['data'][0].get('Rvals'))
    print('cell', phase.get_cell())
    print('inst', {k: v for k,v in inst.items() if k in ['Lam1','Lam2','Zero','I(L2)/I(L1)','Polariz.','U','V','W','X','Y','Z','SH/L']})
    print('background', hist.data['Background'][0])
    print('HAP scale', phase.getHAPvalues(hist)['Scale'])
    print('sample', hist.data['Sample Parameters'])
    print('atoms')
    for a in phase.atoms():
        try:
            adp = a.uiso
        except Exception:
            adp = 'anisotropic'
        print(a.label, a.element, a.coordinates, a.occupancy, adp, a.refinement_flags)
    print('cov', {k:gpx.data['Covariance']['data'].get(k) for k in ['Rvals','varyList','variables','sig']})

def run(label):
    try:
        gpx.refine()
        state(label)
    except Exception as exc:
        print('FAILED', label, type(exc).__name__, exc)
        raise

run('scale background')
phase.set_refinements({'Cell': True})
run('cell')
hist.set_refinements({'Instrument Parameters': ['W']})
run('W')
hist.set_refinements({'Instrument Parameters': ['U','V']})
run('UVW')
hist.set_refinements({'Instrument Parameters': ['X','Y']})
run('UV W XY')
hist.set_refinements({'Instrument Parameters': ['SH/L']})
run('SHL')
hist.set_refinements({'Instrument Parameters': ['Zero']})
run('zero')
phase.set_refinements({'Atoms': {'all': 'X'}})
run('atom positions')
gpx.save()
