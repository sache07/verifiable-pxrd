from pathlib import Path
from GSASII import GSASIIscriptable as G2sc
G2sc.SetPrintLevel('none')
ROOT=Path(__file__).resolve().parents[1]
ranges=[(10,40),(40,70),(70,100),(10,50),(50,100)]
for lo,hi in ranges:
 p=G2sc.G2Project(gpxfile=str(ROOT/'final.gpx'),newgpx=str(ROOT/f'.tmp/range_{lo}_{hi}.gpx'))
 p.data['Controls']['data']['max cyc']=10;p.data['Controls']['data']['min dM/M']=1e-5
 h=p.histogram(0)
 h.set_refinements({'Limits':[lo,hi]})
 h.clear_refinements({'Background':True})
 h.clear_refinements({'Instrument Parameters':['W','X'],'Sample Parameters':['Shift','SurfRoughA','SurfRoughB']})
 for ph in p.phases():
  ph.clear_refinements({'Cell':False,'Atoms':[a.label for a in ph.atoms()]})
  ph.clear_HAP_refinements({'Pref.Ori.':True,'Size':True,'Mustrain':True,'HStrain':True,'Extinction':True,'Babinet':['BabA','BabU']})
  ph.set_HAP_refinements({'Scale':True})
 p.refine()
 r=p.data['Covariance']['data']['Rvals']
 print((lo,hi),'Rwp',h.get_wR(),'N',r['Nobs'],'fracs',h.ComputeMassFracs(),'scales',[ph.getHAPvalues(h)['Scale'][0] for ph in p.phases()],'vary',p.data['Covariance']['data']['varyList'],flush=True)
