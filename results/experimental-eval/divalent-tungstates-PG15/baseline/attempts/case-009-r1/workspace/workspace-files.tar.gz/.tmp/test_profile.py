from pathlib import Path
from GSASII import GSASIIscriptable as G2sc
G2sc.SetPrintLevel('none')
ROOT=Path(__file__).resolve().parents[1]
src=ROOT/'.tmp/rough.gpx'
variants={
    'U':['U'],
    'V':['V'],
    'UV':['U','V'],
    'X':['X'],
    'Y':['Y'],
    'XY':['X','Y'],
    'SHL':['SH/L'],
}
for tag,keys in variants.items():
    p=G2sc.G2Project(gpxfile=str(src),newgpx=str(ROOT/f'.tmp/profile_{tag}.gpx'))
    p.data['Controls']['data']['max cyc']=8
    p.data['Controls']['data']['min dM/M']=1e-5
    h=p.histogram(0); inst=h.data['Instrument Parameters'][0]
    if 'X' in keys: inst['X'][0]=inst['X'][1]=1.0
    if 'Y' in keys: inst['Y'][0]=inst['Y'][1]=1.0
    h.set_refinements({'Instrument Parameters':keys})
    p.refine()
    r=p.data['Covariance']['data'].get('Rvals',{})
    print(tag,'Rwp',h.get_wR(),'GOF',r.get('GOF'),'conv',r.get('converged'),'max',r.get('Max shft/sig'),
          {k:inst[k][1] for k in ['U','V','W','X','Y','SH/L']},r.get('msg','').replace('\n',' | '),flush=True)
