from pathlib import Path
from GSASII import GSASIIscriptable as G2sc
G2sc.SetPrintLevel('warn')
ROOT=Path(__file__).resolve().parents[1]
p=G2sc.G2Project(gpxfile=str(ROOT/'.tmp/atoms.gpx'),newgpx=str(ROOT/'.tmp/polar.gpx'))
p.data['Controls']['data']['max cyc']=10
p.data['Controls']['data']['min dM/M']=1e-5
h=p.histogram(0);ph=p.phase(0)
h.set_refinements({'Instrument Parameters':['Polariz.']})
for label in ['polar','repeat']:
    p.refine();r=p.data['Covariance']['data'].get('Rvals',{})
    print(label,h.get_wR(),r.get('GOF'),r.get('converged'),r.get('Max shft/sig'),h.data['Instrument Parameters'][0]['Polariz.'],flush=True)
h.set_refinements({'Instrument Parameters':['SH/L']})
for label in ['SHL','repeat2']:
    p.refine();r=p.data['Covariance']['data'].get('Rvals',{})
    print(label,h.get_wR(),r.get('GOF'),r.get('converged'),r.get('Max shft/sig'),h.data['Instrument Parameters'][0]['Polariz.'],h.data['Instrument Parameters'][0]['SH/L'],flush=True)
p.save()
