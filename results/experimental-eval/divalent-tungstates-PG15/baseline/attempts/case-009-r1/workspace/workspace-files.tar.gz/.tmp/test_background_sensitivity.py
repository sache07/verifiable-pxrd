from pathlib import Path
from GSASII import GSASIIscriptable as G2sc
G2sc.SetPrintLevel('none')
ROOT=Path(__file__).resolve().parents[1]
src=ROOT/'.tmp/combo_Mn2O3_WO3_Mn3O4.gpx'
for n in [8,10,14,16]:
 p=G2sc.G2Project(gpxfile=str(src),newgpx=str(ROOT/f'.tmp/bg_{n}.gpx'))
 p.data['Controls']['data']['max cyc']=10;p.data['Controls']['data']['min dM/M']=1e-5
 h=p.histogram(0);h.set_refinements({'Background':{'type':'chebyschev-1','refine':True,'no. coeffs':n}})
 for _ in range(2): p.refine()
 r=p.data['Covariance']['data']['Rvals']
 print(n,'Rwp',h.get_wR(),'chisq',r.get('chisq'),'Nvars',r.get('Nvars'),'fracs',h.ComputeMassFracs(),flush=True)
