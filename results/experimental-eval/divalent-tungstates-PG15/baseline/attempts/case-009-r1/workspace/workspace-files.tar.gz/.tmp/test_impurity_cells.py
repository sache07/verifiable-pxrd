from pathlib import Path
from GSASII import GSASIIscriptable as G2sc
G2sc.SetPrintLevel('none')
ROOT=Path(__file__).resolve().parents[1]
for name in ['Mn3O4','WO3','Mn2O3']:
 p=G2sc.G2Project(gpxfile=str(ROOT/f'.tmp/imp_{name}.gpx'),newgpx=str(ROOT/f'.tmp/impcell_{name}.gpx'))
 p.data['Controls']['data']['max cyc']=10;p.data['Controls']['data']['min dM/M']=1e-5
 h=p.histogram(0);ph=p.phase(name);ph.set_refinements({'Cell':True})
 for _ in range(2): p.refine()
 r=p.data['Covariance']['data']['Rvals']
 print(name,'Rwp',h.get_wR(),'chisq',r.get('chisq'),'GOF',r.get('GOF'),'conv',r.get('converged'),'max',r.get('Max shft/sig'),
       'cell',ph.get_cell_and_esd(),'fractions',h.ComputeMassFracs(),'msg',r.get('msg','').replace('\n',' | '),flush=True)
