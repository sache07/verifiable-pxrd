from pathlib import Path
from itertools import combinations
from GSASII import GSASIIscriptable as G2sc
G2sc.SetPrintLevel('none')
ROOT=Path(__file__).resolve().parents[1]
DB=Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
ids={'Mn3O4':'9001963','WO3':'1528915','Mn2O3':'1514230'}
def cif(cid): return DB/cid[0]/cid[1:3]/cid[3:5]/f'{cid}.cif'
sets=[('Mn2O3','WO3'),('Mn2O3','Mn3O4'),('WO3','Mn3O4'),('Mn2O3','WO3','Mn3O4')]
for names in sets:
 tag='_'.join(names);p=G2sc.G2Project(gpxfile=str(ROOT/'.tmp/profile_X.gpx'),newgpx=str(ROOT/f'.tmp/combo_{tag}.gpx'))
 p.data['Controls']['data']['max cyc']=10;p.data['Controls']['data']['min dM/M']=1e-5
 h=p.histogram(0);major=p.phase(0);smaj=major.getHAPvalues(h)['Scale'][0];mmaj=major.data['General']['Mass']
 for name in names:
  ph=p.add_phase(str(cif(ids[name])),phasename=name,histograms=[h],fmthint='CIF')
  ph.getHAPvalues(h)['Scale']=[smaj*0.005*mmaj/ph.data['General']['Mass'],True]
 p.refine();r=p.data['Covariance']['data']['Rvals']
 print(names,'Rwp',h.get_wR(),'chisq',r.get('chisq'),'Nvars',r.get('Nvars'),'GOF',r.get('GOF'),'fracs',h.ComputeMassFracs(),'msg',r.get('msg','').replace('\n',' | '),flush=True)
