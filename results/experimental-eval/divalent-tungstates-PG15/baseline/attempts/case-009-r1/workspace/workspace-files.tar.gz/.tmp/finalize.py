from pathlib import Path
import csv
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc

G2sc.SetPrintLevel('warn')
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / '.tmp' / 'bg_16.gpx'
FINAL = ROOT / 'final.gpx'

project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
project.data['Controls']['data']['Author'] = 'Codex PXRD phase analysis'
project.data['Controls']['data']['max cyc'] = 10
project.data['Controls']['data']['min dM/M'] = 1e-5
project.save()
project.refine()
project.save()

hist = project.histogram(0)
fractions = hist.ComputeMassFracs()

phase_info = {
    'MnWO4': {
        'name': 'manganese tungstate (wolframite)',
        'formula': 'MnWO4',
        'space_group': 'P 1 2/c 1',
        'cif': 'MnWO4.cif',
        'status': 'identified and refined',
        'reference_cod_id': '1520200',
    },
    'Mn2O3': {
        'name': 'manganese(III) oxide (bixbyite)',
        'formula': 'Mn2O3',
        'space_group': 'I a -3',
        'cif': 'Mn2O3.cif',
        'status': 'tentative trace; scale refined, structure fixed',
        'reference_cod_id': '1514230',
    },
    'WO3': {
        'name': 'tungsten(VI) oxide',
        'formula': 'WO3',
        'space_group': 'P 1 21/n 1',
        'cif': 'WO3.cif',
        'status': 'tentative trace; scale refined, structure fixed',
        'reference_cod_id': '1528915',
    },
    'Mn3O4': {
        'name': 'hausmannite',
        'formula': 'Mn3O4',
        'space_group': 'I 41/a m d',
        'cif': 'Mn3O4.cif',
        'status': 'tentative trace; scale refined, structure fixed',
        'reference_cod_id': '9001963',
    },
}

phases_json = []
for phase in project.phases():
    info = phase_info[phase.name]
    phase.export_CIF(str(ROOT / info['cif']))
    frac, esd = fractions[phase.name]
    item = dict(info)
    item['cif_path'] = item.pop('cif')
    item['weight_fraction'] = frac
    item['weight_fraction_formal_esd'] = esd
    item['weight_percent'] = 100.0 * frac
    item['weight_percent_formal_esd'] = 100.0 * esd
    phases_json.append(item)

x = np.asarray(hist.getdata('x'))
yobs = np.asarray(hist.getdata('yobs'))
ycalc = np.asarray(hist.getdata('ycalc'))
background = np.asarray(hist.getdata('background'))
residual = np.asarray(hist.getdata('residual'))
used = (ycalc != 0.0) | (background != 0.0)
with (ROOT / 'fit.csv').open('w', newline='') as fp:
    writer = csv.writer(fp)
    writer.writerow([
        'two_theta_deg',
        'observed_intensity_counts',
        'calculated_intensity_counts',
        'difference_observed_minus_calculated_counts',
        'background_intensity_counts',
    ])
    for vals in zip(x[used], yobs[used], ycalc[used], residual[used], background[used]):
        writer.writerow([f'{vals[0]:.8f}', *(f'{v:.8f}' for v in vals[1:])])

hist_stats = hist.data['data'][0]
rvals = project.data['Covariance']['data']['Rvals']
dof = int(rvals['Nobs'] - rvals['Nvars'])
fit_stats = {
    'Rwp_percent': float(rvals['Rwp']),
    'Rp_percent': float(hist_stats['R']),
    'R_expected_percent': float(hist_stats['wRmin']),
    'goodness_of_fit': float(rvals['GOF']),
    'chi_square': float(rvals['chisq']),
    'reduced_chi_square': float(rvals['chisq'] / dof),
    'n_observations': int(rvals['Nobs']),
    'n_refined_variables': int(rvals['Nvars']),
    'degrees_of_freedom': dof,
    'Durbin_Watson': float(hist_stats['Durbin-Watson']),
    'profile_range_two_theta_deg': [float(x[used][0]), float(x[used][-1])],
    'converged': bool(rvals.get('converged', False)),
    'maximum_shift_over_esd': float(rvals.get('Max shft/sig', math.nan)),
}

result = {
    'phases': phases_json,
    'weight_fraction_basis': 'normalized over the modeled crystalline phases; amorphous/unmodeled material excluded',
    'fit_statistics': fit_stats,
    'project_path': 'final.gpx',
    'profile_path': 'fit.csv',
    'weighting': 'Poisson counting weights (sigma = sqrt(counts)); pointwise uncertainties were not supplied',
}
with (ROOT / 'result.json').open('w') as fp:
    json.dump(result, fp, indent=2)
    fp.write('\n')

major = project.phase('MnWO4')
cell, cell_esd = major.get_cell_and_esd()
f = {p['formula']: p for p in phases_json}
report = f"""# PXRD phase analysis

The crystalline product is dominated by wolframite-type MnWO4 (space group P 1 2/c 1), with tentative sub-1 wt% traces of cubic Mn2O3, monoclinic WO3, and tetragonal Mn3O4. The crystalline-normalized result is:

| Phase | Weight fraction | Formal s.u. | Assessment |
|---|---:|---:|---|
| MnWO4 | {f['MnWO4']['weight_percent']:.3f} wt% | {f['MnWO4']['weight_percent_formal_esd']:.3f} wt% | secure |
| Mn2O3 | {f['Mn2O3']['weight_percent']:.3f} wt% | {f['Mn2O3']['weight_percent_formal_esd']:.3f} wt% | tentative trace |
| WO3 | {f['WO3']['weight_percent']:.3f} wt% | {f['WO3']['weight_percent_formal_esd']:.3f} wt% | tentative trace; least secure |
| Mn3O4 | {f['Mn3O4']['weight_percent']:.3f} wt% | {f['Mn3O4']['weight_percent_formal_esd']:.3f} wt% | tentative trace |

## Evidence and refinement

All prominent reflections, including the diagnostic doublets near 23.8/24.3 and 30.1/30.5 degrees 2theta, are indexed by MnWO4. Alternative Mn3WO6 predicts strong peaks near 20 and 29 degrees that are absent. The refined MnWO4 cell is a = {cell['length_a']:.6f}({cell_esd['length_a']*1e6:.0f}) A, b = {cell['length_b']:.6f}({cell_esd['length_b']*1e6:.0f}) A, c = {cell['length_c']:.6f}({cell_esd['length_c']*1e6:.0f}) A, beta = {cell['angle_beta']:.5f}({cell_esd['angle_beta']*1e5:.0f}) degrees, and V = {cell['volume']:.5f} A^3. Its cell and symmetry-constrained atomic coordinates were refined.

The trace phases give positive scales and reduce chi-square from 18988.3 (one phase, 35 variables) to {fit_stats['chi_square']:.1f} (four phases, {fit_stats['n_refined_variables']} variables) with the same profile/background model. Their strongest diagnostic regions are consistent with weak residual intensity (notably Mn2O3 near 33.2 degrees and Mn3O4 near 36.3/60.0 degrees). WO3 relies mostly on overlapped low-angle peaks, so that assignment is the least secure.

The final GSAS-II fit over {fit_stats['profile_range_two_theta_deg'][0]:.3f}-{fit_stats['profile_range_two_theta_deg'][1]:.3f} degrees has Rwp = {fit_stats['Rwp_percent']:.3f}%, Rp = {fit_stats['Rp_percent']:.3f}%, and goodness of fit = {fit_stats['goodness_of_fit']:.3f}. Cu Kalpha1/Kalpha2 wavelengths and the reported 0.5 intensity ratio were fixed; background, sample displacement/surface roughness, MnWO4 cell/coordinates, phase scales, and Gaussian/Lorentzian profile terms were refined.

## Remaining uncertainty

No calibrated instrument profile or pointwise uncertainties were supplied, so Poisson weights were assumed. The trace fractions are model-sensitive: plausible profile/background variants placed Mn2O3 at about 0.3-0.7 wt%, Mn3O4 at about 0.4-0.8 wt%, and WO3 at about 0.3-0.5 wt%. These systematic ranges exceed the formal least-squares s.u. values in the table. There is not enough independent intensity to refine trace-phase cells or atomic positions reliably; their reference structures were held fixed. The reported fractions are normalized only over modeled crystalline phases and do not quantify amorphous content.
"""
(ROOT / 'report.md').write_text(report)

print(json.dumps(result, indent=2))
