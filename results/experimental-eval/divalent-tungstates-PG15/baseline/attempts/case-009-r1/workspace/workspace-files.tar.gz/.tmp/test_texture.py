from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

G2sc.SetPrintLevel('none')
ROOT = Path(__file__).resolve().parents[1]
src = ROOT/'.tmp/trial2.gpx'
axes = [(0,0,1),(1,0,0),(0,1,0),(1,1,0),(1,0,1),(1,0,-1),
        (0,1,1),(0,1,-1),(1,1,1),(1,1,-1),(1,-1,1),(1,-1,-1),
        (2,0,1),(1,0,2),(2,1,0),(1,2,0)]

for axis in axes:
    tag = '_'.join(('m'+str(-v)) if v < 0 else str(v) for v in axis)
    out = ROOT/f'.tmp/md_{tag}.gpx'
    p = G2sc.G2Project(gpxfile=str(src), newgpx=str(out))
    p.data['Controls']['data']['max cyc'] = 6
    p.data['Controls']['data']['min dM/M'] = 1e-4
    h=p.histogram(0); ph=p.phase(0)
    h.clear_refinements({'Instrument Parameters':['X','Y','SH/L','U','V']})
    po=ph.getHAPvalues(h)['Pref.Ori.']
    po[0]='MD'; po[1]=1.0; po[2]=True; po[3]=list(axis)
    p.refine()
    r=p.data['Covariance']['data'].get('Rvals',{})
    print(axis,'Rwp',h.get_wR(),'ratio',po[1],'GOF',r.get('GOF'),'converged',r.get('converged'), flush=True)
