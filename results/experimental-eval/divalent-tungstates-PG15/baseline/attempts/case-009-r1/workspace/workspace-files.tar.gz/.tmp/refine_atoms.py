from pathlib import Path
from GSASII import GSASIIscriptable as G2sc
G2sc.SetPrintLevel('warn')
ROOT=Path(__file__).resolve().parents[1]
p=G2sc.G2Project(gpxfile=str(ROOT/'.tmp/md_1_1_0.gpx'),newgpx=str(ROOT/'.tmp/atoms.gpx'))
p.data['Controls']['data']['max cyc']=10
p.data['Controls']['data']['min dM/M']=1e-5
h=p.histogram(0); ph=p.phase(0)
ph.set_refinements({'Atoms':{'all':'X'}})
for i in range(3):
    p.refine()
    r=p.data['Covariance']['data'].get('Rvals',{})
    print(i,'Rwp',h.get_wR(),'GOF',r.get('GOF'),'conv',r.get('converged'),'max',r.get('Max shft/sig'),flush=True)
    print('cell',ph.get_cell(),flush=True)
    for a in ph.atoms(): print(a.label,a.coordinates,a.refinement_flags,flush=True)
p.save()
