from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

G2sc.SetPrintLevel('warn')
ROOT = Path(__file__).resolve().parents[1]
CIF = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif')
GPX = ROOT / '.tmp' / 'trial2.gpx'

gpx = G2sc.G2Project(newgpx=str(GPX))
hist = gpx.add_powder_histogram(str(ROOT/'inputs/pattern.csv'), str(ROOT/'.tmp/cu_ka.instprm'), fmthint='comma')
phase = gpx.add_phase(str(CIF), phasename='MnWO4', histograms=[hist], fmthint='CIF')
gpx.data['Controls']['data']['max cyc'] = 8
gpx.data['Controls']['data']['min dM/M'] = 1e-4
inst = hist.data['Instrument Parameters'][0]
for k,v in {'U':0.0,'V':0.0,'W':80.0,'X':0.0,'Y':1.0,'Z':0.0,'SH/L':0.01}.items():
    inst[k][0] = inst[k][1] = v
    inst[k][2] = False
hist.set_refinements({'Limits':[10.0,100.0], 'Background':{'type':'chebyschev-1','refine':True,'no. coeffs':12}})
phase.set_HAP_refinements({'Scale':True})
hist.data['Sample Parameters']['Scale'] = [1.0,False]

def show(label):
    r=gpx.data['Covariance']['data'].get('Rvals',{})
    print(label, 'Rwp',hist.get_wR(),'GOF',r.get('GOF'),'conv',r.get('converged'),'shift/esd',r.get('Max shft/sig'))
    print('  cell',phase.get_cell())
    print('  inst',{k:inst[k][1:] for k in ['Zero','U','V','W','X','Y','SH/L']})
    print('  sample',{k:v for k,v in hist.data['Sample Parameters'].items() if k in ['Scale','Shift','Transparency']})
    print('  PO',phase.getHAPvalues(hist)['Pref.Ori.'])

def run(label):
    gpx.refine()
    show(label)

run('scale+bkg')
phase.set_refinements({'Cell':True})
hist.set_refinements({'Sample Parameters':['Shift']})
run('cell+shift')
run('cell+shift repeat')
hist.set_refinements({'Instrument Parameters':['W']})
run('W')
hist.set_refinements({'Instrument Parameters':['Y']})
run('W+Y')
hist.set_refinements({'Instrument Parameters':['X']})
run('W+X+Y')
hist.set_refinements({'Instrument Parameters':['SH/L']})
run('profile+SHL')
gpx.save()
