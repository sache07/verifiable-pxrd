from pathlib import Path
from GSASII import GSASIIscriptable as G2sc
G2sc.SetPrintLevel('warn')
ROOT=Path(__file__).resolve().parents[1]
p=G2sc.G2Project(gpxfile=str(ROOT/'.tmp/atoms.gpx'),newgpx=str(ROOT/'.tmp/rough.gpx'))
p.data['Controls']['data']['max cyc']=10
p.data['Controls']['data']['min dM/M']=1e-5
h=p.histogram(0)
inst=h.data['Instrument Parameters'][0]
inst['Polariz.'][1]=0.5;inst['Polariz.'][2]=False
s=h.data['Sample Parameters']
s['SurfRoughA']=[0.5,True]
s['SurfRoughB']=[0.02,True]
for i in range(3):
    p.refine();r=p.data['Covariance']['data'].get('Rvals',{})
    print(i,h.get_wR(),r.get('GOF'),r.get('converged'),r.get('Max shft/sig'),'A/B',s['SurfRoughA'],s['SurfRoughB'],flush=True)
p.save()
