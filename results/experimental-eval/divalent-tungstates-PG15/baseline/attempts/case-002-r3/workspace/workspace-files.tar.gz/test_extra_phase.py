#!/usr/bin/env python3
"""Add one candidate trace phase to the converged two-phase project."""

import json
import os
import sys

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"


def cod_cif(cod_id):
    return os.path.join(
        COD_ROOT, cod_id[0], cod_id[1:3], cod_id[3:5], cod_id + ".cif"
    )


def main():
    cod_id, phase_name = sys.argv[1:3]
    tag = sys.argv[3] if len(sys.argv) > 3 else cod_id
    project = G2sc.G2Project(
        ".tmp/profile_physical.gpx", newgpx=f".tmp/extra_{tag}.gpx"
    )
    hist = project.histogram(0)
    phase = project.add_phase(
        cod_cif(cod_id),
        phasename=phase_name,
        histograms=[hist],
        fmthint="CIF",
    )
    phase.HAPvalue("Scale", 0.1)
    phase.setSampleProfile(hist, "size", "isotropic", 0.05, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 5000.0, LGmix=0.0)
    phase.set_HAP_refinements({"Scale": True}, [hist])
    project.set_Controls("cycles", 12)
    project.save()
    project.do_refinements([{}])
    project.do_refinements([{}])
    project.save()
    result = {
        "candidate": phase_name,
        "cod_id": cod_id,
        "Rwp_percent": hist.residuals.get("wR"),
        "Rp_percent": hist.residuals.get("R"),
        "GOF": project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "max_shift_esd": project.data["Covariance"]["data"]
        .get("Rvals", {})
        .get("Max shft/sig"),
        "mass_fractions": hist.ComputeMassFracs(),
        "candidate_scale": phase.getHAPvalues(hist.name)["Scale"],
    }
    with open(f".tmp/extra_{tag}.json", "w") as stream:
        json.dump(result, stream, indent=2)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
