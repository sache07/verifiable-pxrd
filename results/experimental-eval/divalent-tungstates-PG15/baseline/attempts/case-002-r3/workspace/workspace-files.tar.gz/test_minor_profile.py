#!/usr/bin/env python3
"""Compare simple broadening models for the minor BaCO3 phase."""

import json
import sys

from GSASII import GSASIIscriptable as G2sc


mode = sys.argv[1]
project = G2sc.G2Project(
    ".tmp/carbonate_refined.gpx", newgpx=f".tmp/minor_{mode}.gpx"
)
hist = project.histogram(0)
phase = project.phase("BaCO3")
hap = phase.getHAPvalues(hist.name)

if mode == "size":
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2][0] = False
    hap["Size"][2][0] = True
elif mode == "strain":
    hap["Size"][1][0] = 1.0
    hap["Size"][2][0] = False
    hap["Mustrain"][1][0] = 5000.0
    hap["Mustrain"][2][0] = True
elif mode == "both":
    hap["Size"][2][0] = True
    hap["Mustrain"][2][0] = True
else:
    raise ValueError(mode)

project.set_Controls("cycles", 15)
project.save()
project.do_refinements([{}])
project.do_refinements([{}])
project.save()
print(
    json.dumps(
        {
            "mode": mode,
            "Rwp": hist.residuals["wR"],
            "GOF": project.data["Covariance"]["data"]["Rvals"].get("GOF"),
            "max_shift_esd": project.data["Covariance"]["data"]["Rvals"].get(
                "Max shft/sig"
            ),
            "mass_fractions": hist.ComputeMassFracs(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "cell": phase.get_cell(),
        }
    )
)
