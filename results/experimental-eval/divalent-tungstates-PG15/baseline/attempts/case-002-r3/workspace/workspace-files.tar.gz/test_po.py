#!/usr/bin/env python3
"""Test a single March-Dollase preferred-orientation axis."""

import json
import sys

from GSASII import GSASIIscriptable as G2sc


phase_name = sys.argv[1]
axis = [int(v) for v in sys.argv[2:5]]
tag = phase_name + "_" + "".join(str(v) for v in axis)
project = G2sc.G2Project(
    ".tmp/carbonate_refined.gpx", newgpx=f".tmp/po_{tag}.gpx"
)
hist = project.histogram(0)
phase = project.phase(phase_name)
po = phase.getHAPvalues(hist.name)["Pref.Ori."]
po[0] = "MD"
po[1] = 1.0
po[2] = True
po[3] = axis
project.set_Controls("cycles", 12)
project.save()
project.do_refinements([{}])
project.do_refinements([{}])
project.save()
print(
    json.dumps(
        {
            "phase": phase_name,
            "axis": axis,
            "ratio": po[1],
            "Rwp": hist.residuals["wR"],
            "GOF": project.data["Covariance"]["data"]["Rvals"].get("GOF"),
            "max_shift_esd": project.data["Covariance"]["data"]["Rvals"].get(
                "Max shft/sig"
            ),
            "mass_fractions": hist.ComputeMassFracs(),
        }
    )
)
