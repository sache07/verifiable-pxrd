#!/usr/bin/env python3
"""Run an identical two-phase GSAS-II refinement for one WO3 CIF model."""

import json
import os
import sys

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"


def cod_cif(cod_id):
    return os.path.join(
        COD_ROOT, cod_id[0], cod_id[1:3], cod_id[3:5], cod_id + ".cif"
    )


def main():
    wo3_id = sys.argv[1]
    tag = sys.argv[2] if len(sys.argv) > 2 else wo3_id
    project_path = os.path.abspath(os.path.join(".tmp", f"screen_{tag}.gpx"))

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(newgpx=project_path)
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    bao2 = project.add_phase(
        cod_cif("1010113"), phasename="BaO2", histograms=[hist], fmthint="CIF"
    )
    wo3 = project.add_phase(
        cod_cif(wo3_id), phasename="WO3", histograms=[hist], fmthint="CIF"
    )

    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.SampleParameters["Scale"][0] = 1.0
    hist.clear_refinements({"Sample Parameters": ["Scale"]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 18,
            }
        }
    )
    for phase in (bao2, wo3):
        phase.HAPvalue("Scale", 1.0)
        phase.setSampleProfile(hist, "size", "isotropic", 0.04, LGmix=0.5)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 3000.0, LGmix=0.5)
        phase.set_HAP_refinements({"Scale": True}, [hist])

    project.set_Controls("cycles", 6)
    project.save()
    project.do_refinements([{}])
    project.do_refinements([{"set": {"Cell": True}}])
    project.do_refinements(
        [
            {
                "set": {
                    "Size": {
                        "type": "isotropic",
                        "refine": True,
                        "LGmix": {"value": 0.5, "refine": False},
                    }
                }
            }
        ]
    )
    project.do_refinements(
        [
            {
                "set": {
                    "Mustrain": {
                        "type": "isotropic",
                        "refine": True,
                        "LGmix": {"value": 0.5, "refine": False},
                    }
                }
            }
        ]
    )
    project.set_Controls("cycles", 10)
    project.do_refinements([{"set": {"Instrument Parameters": ["Zero"]}}])
    project.do_refinements([{}])
    project.save()

    result = {
        "wo3_cod_id": wo3_id,
        "project": project_path,
        "Rwp_percent": hist.residuals.get("wR"),
        "Rp_percent": hist.residuals.get("R"),
        "GOF": project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "mass_fractions": hist.ComputeMassFracs(),
        "zero_deg": hist.InstrumentParameters["Zero"][1],
        "cells": {phase.name: phase.get_cell() for phase in (bao2, wo3)},
        "scales": {
            phase.name: phase.getHAPvalues(hist.name)["Scale"][0]
            for phase in (bao2, wo3)
        },
        "sizes_um": {
            phase.name: phase.getHAPvalues(hist.name)["Size"][1][0]
            for phase in (bao2, wo3)
        },
        "microstrain": {
            phase.name: phase.getHAPvalues(hist.name)["Mustrain"][1][0]
            for phase in (bao2, wo3)
        },
        "max_shift_esd": project.data["Covariance"]["data"]
        .get("Rvals", {})
        .get("Max shft/sig"),
    }
    with open(os.path.join(".tmp", f"screen_{tag}.json"), "w") as stream:
        json.dump(result, stream, indent=2)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
