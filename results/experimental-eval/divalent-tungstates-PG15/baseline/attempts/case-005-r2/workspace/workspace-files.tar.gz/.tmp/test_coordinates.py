from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root=Path(__file__).resolve().parents[1]

def show(label,gpx):
    h=gpx.histogram(0);r=gpx.data['Covariance']['data'].get('Rvals',{});dep=gpx.data['Covariance']['data'].get('depSigDict',{})
    print(label,h.residuals.get('wR'),r.get('GOF'),r.get('Max shft/sig'),r.get('msg'),
          [(a.label,a.coordinates,a.refinement_flags) for a in gpx.phase(0).atoms()],
          [(a.label,a.coordinates,a.refinement_flags) for a in gpx.phase(1).atoms()],
          [dep.get(f'{i}:0:WgtFrac') for i in range(2)],flush=True)

G2sc.SetPrintLevel('warn')
gpx=G2sc.G2Project(gpxfile=root/'.tmp/profile_uwx_continued.gpx',newgpx=root/'.tmp/wcoords.gpx')
for atom in gpx.phase(0).atoms():
    if atom.element=='W': atom.refinement_flags='X'
gpx.set_Controls('cycles',20)
for i in range(4):
    gpx.refine(printFile=root/'.tmp/wcoords.lst');show(f'W{i}',gpx)
gpx.save()

gpx2=G2sc.G2Project(gpxfile=root/'.tmp/wcoords.gpx',newgpx=root/'.tmp/wcoords_cooxygen.gpx')
gpx2.phase(1).atom('O').refinement_flags='X'
for i in range(4):
    gpx2.refine(printFile=root/'.tmp/wcoords_cooxygen.lst');show(f'WCoO{i}',gpx2)
gpx2.save()
