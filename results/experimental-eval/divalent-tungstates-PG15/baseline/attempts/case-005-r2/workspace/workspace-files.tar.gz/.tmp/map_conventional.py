from pathlib import Path
import copy
import math

from GSASII import GSASIIscriptable as G2sc

root=Path(__file__).resolve().parents[1]
src=G2sc.G2Project(root/'.tmp/model_2311041.gpx')
dst=G2sc.G2Project(gpxfile=root/'.tmp/profile_base.gpx',newgpx=root/'.tmp/conventional_mapped.gpx')
hs=src.histogram(0); hd=dst.histogram(0)
hd.data['Background']=copy.deepcopy(hs.data['Background'])
hd.data['Instrument Parameters']=copy.deepcopy(hs.data['Instrument Parameters'])
hd.data['Sample Parameters']=copy.deepcopy(hs.data['Sample Parameters'])
for i in range(2):
    hdph=dst.phase(i); hsph=src.phase(i)
    hdph.data['Histograms'][hd.name]=copy.deepcopy(hsph.data['Histograms'][hs.name])

# Convert the refined P21/c long-c cell to the equivalent conventional P21/n cell:
# a_n = a_c + c_c, b_n = b_c, c_n = -a_c.
cell=src.phase(0).get_cell()
a,b,c,beta=cell['length_a'],cell['length_b'],cell['length_c'],math.radians(cell['angle_beta'])
an=math.sqrt(a*a+c*c+2*a*c*math.cos(beta))
bn=b
cn=a
dot=-(a*a+a*c*math.cos(beta))
betan=math.degrees(math.acos(dot/(an*cn)))
g=dst.phase(0).data['General']
g['Cell'][1:8]=[an,bn,cn,90.0,betan,90.0,cell['volume']]
g2=dst.phase(1).data['General']
c2=src.phase(1).data['General']['Cell']
g2['Cell'][1:8]=copy.deepcopy(c2[1:8])

G2sc.SetPrintLevel('all')
dst.set_Controls('cycles',0)
dst.refine(printFile=root/'.tmp/conventional_mapped_calc.lst')
print('CALC',hd.residuals)
dst.set_Controls('cycles',20)
dst.refine(printFile=root/'.tmp/conventional_mapped_refine.lst')
dst.save()
print('REFINE',hd.residuals)
print('CELLS',[p.get_cell_and_esd() for p in dst.phases()])
print('PROFILE',{k:hd.InstrumentParameters[k][1] for k in ['U','V','W','X','Y']})
print('DEP',dst.data['Covariance']['data'].get('depSigDict'))
print('RVALS',dst.data['Covariance']['data'].get('Rvals'))
