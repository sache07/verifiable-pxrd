from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
cod = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif(cod_id):
    return cod / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def run(wo3_id):
    project = root / ".tmp" / f"model_{wo3_id}.gpx"
    gpx = G2sc.G2Project(newgpx=project)
    hist = gpx.add_powder_histogram(
        root / ".tmp/pattern.xye", root / ".tmp/instrument.instprm", fmthint="xye"
    )
    wo3 = gpx.add_phase(cif(wo3_id), phasename=f"WO3_{wo3_id}", histograms=[hist], fmthint="CIF")
    co3o4 = gpx.add_phase(cif("9005896"), phasename="Co3O4_9005896", histograms=[hist], fmthint="CIF")
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-600.0, False]
    hist.Background[0][:] = ["chebyschev-1", True, 15, 3000.0] + [0.0] * 14
    hist.InstrumentParameters["W"][1] = 30.0
    for phase in (wo3, co3o4):
        phase.data["Histograms"][hist.name]["Scale"] = [1.0, True]
    gpx.set_Controls("cycles", 12)
    limits = {
        ":0:Shift": (-1000.0, 0.0),
        ":0:U": (0.0, 500.0),
        ":0:V": (-500.0, 500.0),
        ":0:W": (0.0, 500.0),
        ":0:X": (0.0, 100.0),
        ":0:Y": (-100.0, 100.0),
    }
    for var, (lo, hi) in limits.items():
        gpx.set_Controls("parmMin", lo, variable=var)
        gpx.set_Controls("parmMax", hi, variable=var)
    gpx.refine()
    hist.SampleParameters["Shift"][1] = True
    gpx.refine()
    for phase in (wo3, co3o4):
        phase.set_refinements({"Cell": True})
    gpx.refine()
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
    gpx.refine()
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    parm = cov.get("parmDict", {})
    sig = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    return {
        "id": wo3_id,
        "residuals": hist.residuals,
        "shift": hist.SampleParameters["Shift"][0],
        "profile": {k: hist.InstrumentParameters[k][1] for k in ["U", "V", "W", "X", "Y"]},
        "wo3_cell": wo3.get_cell(),
        "co3o4_cell": co3o4.get_cell(),
        "scales": [p.data["Histograms"][hist.name]["Scale"][0] for p in (wo3, co3o4)],
        "weight_fractions": [parm.get(f"{i}:0:WgtFrac") for i in range(2)],
        "weight_fraction_esds": [sig.get(f"{i}:0:WgtFrac") for i in range(2)],
    }


G2sc.SetPrintLevel("warn")
results = []
model_ids = sys.argv[1:] or ["1010618", "1528915", "2311041", "2106293", "2107312", "1563541"]
for cod_id in model_ids:
    try:
        result = run(cod_id)
    except Exception as exc:
        result = {"id": cod_id, "error": f"{type(exc).__name__}: {exc}"}
    results.append(result)
    print(json.dumps(result), flush=True)
with open(root / ".tmp/wo3_comparison.json", "w") as fp:
    json.dump(results, fp, indent=2)
