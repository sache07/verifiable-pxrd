from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root=Path(__file__).resolve().parents[1]
gpx=G2sc.G2Project(gpxfile=root/'.tmp/profile_uwx_continued.gpx',newgpx=root/'.tmp/with_cowo4.gpx')
h=gpx.histogram(0)
p=gpx.add_phase(root/'.tmp/cowo4_repaired.cif',phasename='candidate_CoWO4',histograms=[h],fmthint='CIF')
p.data['Histograms'][h.name]['Scale']=[0.02,True]
gpx.set_Controls('parmMin',-10.0,variable='2:0:Scale')
gpx.set_Controls('parmMax',10.0,variable='2:0:Scale')
gpx.set_Controls('cycles',20)
G2sc.SetPrintLevel('warn')
for i in range(3):
    gpx.refine(printFile=root/'.tmp/with_cowo4.lst')
    dep=gpx.data['Covariance']['data'].get('depSigDict',{})
    r=gpx.data['Covariance']['data'].get('Rvals',{})
    print(i,h.residuals.get('wR'),r.get('GOF'),r.get('Max shft/sig'),
          [ph.data['Histograms'][h.name]['Scale'][0] for ph in gpx.phases()],
          [dep.get(f'{j}:0:WgtFrac') for j in range(3)],
          dep.get('2:0:Scale'),flush=True)
gpx.save()
