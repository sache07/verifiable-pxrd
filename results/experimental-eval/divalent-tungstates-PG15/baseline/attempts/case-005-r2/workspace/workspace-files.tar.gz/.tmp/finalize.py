from pathlib import Path
import csv
import json

from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
source = root / ".tmp/profile_uwx_continued.gpx"
final_gpx = root / "final.gpx"

G2sc.SetPrintLevel("warn")
gpx = G2sc.G2Project(gpxfile=source, newgpx=final_gpx)
gpx.set_Controls("cycles", 20)
gpx.refine(printFile=root / ".tmp/final.lst")
gpx.save()

hist = gpx.histogram(0)
phases = gpx.phases()
phase_specs = [
    (phases[0], "monoclinic tungsten(VI) oxide", "WO3", "phase_1_WO3.cif"),
    (phases[1], "cobalt(II,III) oxide spinel", "Co3O4", "phase_2_Co3O4.cif"),
]
for phase, _name, _formula, filename in phase_specs:
    phase.export_CIF(root / filename)

profile = hist.data["data"][1]
with open(root / "fit.csv", "w", newline="") as fp:
    writer = csv.writer(fp)
    writer.writerow([
        "two_theta_deg",
        "observed_intensity",
        "calculated_intensity",
        "difference_observed_minus_calculated",
        "calculated_background",
    ])
    for x, yobs, ycalc, ybkg, ydiff in zip(
        profile[0], profile[1], profile[3], profile[4], profile[5]
    ):
        writer.writerow([
            f"{float(x):.8f}",
            f"{float(yobs):.8f}",
            f"{float(ycalc):.8f}",
            f"{float(ydiff):.8f}",
            f"{float(ybkg):.8f}",
        ])

cov = gpx.data["Covariance"]["data"]
dep = cov.get("depSigDict", {})
rvals = cov.get("Rvals", {})
raw_fracs = [float(dep[f"{i}:0:WgtFrac"][0]) for i in range(len(phases))]
frac_sum = sum(raw_fracs)
fractions = [f / frac_sum for f in raw_fracs]

phase_results = []
for i, ((phase, name, formula, filename), fraction) in enumerate(zip(phase_specs, fractions)):
    cell, cell_esd = phase.get_cell_and_esd()
    phase_results.append({
        "name": name,
        "formula": formula,
        "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
        "cif_path": filename,
        "weight_fraction": fraction,
        "weight_percent": 100.0 * fraction,
        "weight_fraction_esd_formal": float(dep[f"{i}:0:WgtFrac"][1]),
        "cell": {key: float(value) for key, value in cell.items()},
        "cell_esd": {key: float(value) for key, value in cell_esd.items()},
        "bragg_R_F_percent": float(hist.residuals.get(f"{i}:0:Rf")),
        "bragg_R_F2_percent": float(hist.residuals.get(f"{i}:0:Rf^2")),
    })

gof = float(rvals["GOF"])
result = {
    "phases": phase_results,
    "weight_fraction_basis": "normalized over the modeled crystalline phases; sum = 1",
    "fit_statistics": {
        "R_wp_percent": float(hist.residuals["wR"]),
        "R_p_percent": float(hist.residuals["R"]),
        "R_exp_percent": float(hist.residuals["wRmin"]),
        "goodness_of_fit": gof,
        "reduced_chi_squared": gof * gof,
        "chi_squared": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_parameters": int(rvals["Nvars"]),
    },
    "files": {
        "gsasii_project": "final.gpx",
        "profile": "fit.csv",
    },
    "refinement_notes": {
        "intensity_weights": "Poisson counting approximation, sigma(I)=sqrt(I), because pointwise uncertainties were not supplied",
        "radiation": "Cu Kalpha1/Kalpha2, 1.540598/1.544426 angstrom, fixed Kalpha2/Kalpha1=0.5",
        "fractions": "Formal covariance errors exclude model/profile/systematic uncertainty; see report.md",
    },
}
with open(root / "result.json", "w") as fp:
    json.dump(result, fp, indent=2)
    fp.write("\n")

print(json.dumps(result, indent=2))
print("sample_shift_micrometres", hist.SampleParameters["Shift"])
print("profile", {k: hist.InstrumentParameters[k] for k in ["U", "V", "W", "X", "Y"]})
print("max_shift_over_esd", rvals.get("Max shft/sig"))
