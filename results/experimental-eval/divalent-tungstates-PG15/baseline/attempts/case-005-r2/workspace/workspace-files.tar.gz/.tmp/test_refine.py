from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
cod = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif(cod_id):
    return cod / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


gpx = G2sc.G2Project(newgpx=root / ".tmp/two_phase.gpx")
hist = gpx.add_powder_histogram(
    root / ".tmp/pattern.xye", root / ".tmp/instrument.instprm", fmthint="xye"
)
wo3 = gpx.add_phase(cif("1528915"), phasename="monoclinic_WO3", histograms=[hist], fmthint="CIF")
co3o4 = gpx.add_phase(cif("9005896"), phasename="spinel_Co3O4", histograms=[hist], fmthint="CIF")

hist.SampleParameters["Scale"] = [1.0, False]
hist.SampleParameters["Shift"] = [-600.0, False]
hist.Background[0][:] = ["chebyschev-1", True, 15, 3000.0] + [0.0] * 14
hist.InstrumentParameters["W"][1] = 30.0
for phase in (wo3, co3o4):
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]

gpx.set_Controls("cycles", 8)
gpx.set_Controls("parmMin", -1000.0, variable=":0:Shift")
gpx.set_Controls("parmMax", 0.0, variable=":0:Shift")
G2sc.SetPrintLevel("all")

def status(label):
    print("\n===", label, "===")
    print("residuals", hist.residuals)
    print("sample", hist.SampleParameters)
    print("instrument", hist.InstrumentParameters)
    print("background", hist.Background[0])
    for p in gpx.phases():
        print(p.name, p.get_cell_and_esd(), p.data["Histograms"][hist.name])
    print("variables", gpx.get_VaryList())


gpx.refine(printFile=root / ".tmp/two_phase.lst")
status("background scales, fixed shift")

hist.SampleParameters["Shift"][1] = True
gpx.refine(printFile=root / ".tmp/two_phase.lst")
status("plus shift")

for p in gpx.phases():
    p.set_refinements({"Cell": True})
gpx.refine(printFile=root / ".tmp/two_phase.lst")
status("plus cells")

hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
gpx.refine(printFile=root / ".tmp/two_phase.lst")
status("plus profile")

for p in gpx.phases():
    p.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True}})
gpx.refine(printFile=root / ".tmp/two_phase.lst")
status("plus phase size")
gpx.save()
