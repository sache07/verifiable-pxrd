from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
arr = np.genfromtxt(root / "inputs/pattern.csv", delimiter=",", names=True)
with open(root / ".tmp/pattern.xye", "w") as fp:
    fp.write("# Pattern from inputs/pattern.csv; sigma=sqrt(counts)\n")
    for x, y in zip(arr["two_theta_deg"], arr["intensity"]):
        fp.write(f"{x:.8f} {y:.8f} {np.sqrt(max(y, 1.0)):.8f}\n")

gpx = G2sc.G2Project(newgpx=root / ".tmp/probe.gpx")
hist = gpx.add_powder_histogram(
    root / ".tmp/pattern.xye",
    root / ".tmp/instrument.instprm",
    fmthint="xye",
)
print("hist", hist.name)
print("instrument", hist.InstrumentParameters)
print("sample", hist.SampleParameters)
print("background", hist.Background)
print("limits", hist.data["Limits"])
print("data shapes", [getattr(a, "shape", None) for a in hist.data["data"][1]])
