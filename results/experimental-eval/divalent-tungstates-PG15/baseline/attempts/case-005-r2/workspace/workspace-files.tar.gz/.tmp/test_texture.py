from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

root=Path(__file__).resolve().parents[1]
G2sc.SetPrintLevel('warn')
for axis in ([1,0,0],[0,1,0],[0,0,1],[1,1,0],[1,0,1],[0,1,1],[1,1,1]):
    tag=''.join(map(str,axis));out=root/'.tmp'/f'texture_{tag}.gpx'
    gpx=G2sc.G2Project(gpxfile=root/'.tmp/profile_uwx_continued.gpx',newgpx=out)
    h=gpx.histogram(0);hap=gpx.phase(0).data['Histograms'][h.name]
    hap['Pref.Ori.'][0]='MD';hap['Pref.Ori.'][1]=1.0;hap['Pref.Ori.'][2]=True;hap['Pref.Ori.'][3]=axis
    gpx.set_Controls('parmMin',0.5,variable='0:0:MD');gpx.set_Controls('parmMax',2.0,variable='0:0:MD');gpx.set_Controls('cycles',20)
    for i in range(3):gpx.refine()
    dep=gpx.data['Covariance']['data'].get('depSigDict',{});r=gpx.data['Covariance']['data'].get('Rvals',{})
    result={'axis':axis,'Rwp':h.residuals.get('wR'),'GOF':r.get('GOF'),'max_shift_esd':r.get('Max shft/sig'),
            'MD':hap['Pref.Ori.'][1], 'MD_dep':dep.get('0:0:MD'),
            'fractions':[dep.get(f'{j}:0:WgtFrac') for j in range(2)],'message':r.get('msg')}
    print(json.dumps(result),flush=True);gpx.save()
