from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root=Path(__file__).resolve().parents[1]
gpx=G2sc.G2Project(gpxfile=root/'.tmp/profile_base.gpx',newgpx=root/'.tmp/profile_seeded.gpx')
h=gpx.histogram(0)
for key,val in {'U':500.0,'V':-166.35,'W':14.24,'X':17.92,'Y':-36.41}.items():
    h.InstrumentParameters[key][1]=val
h.set_refinements({'Instrument Parameters':['U','V','W','X','Y']})
for var,lo,hi in [(':0:U',0,3000),(':0:V',-1000,1000),(':0:W',-500,1000),(':0:X',0,200),(':0:Y',-200,200)]:
    gpx.set_Controls('parmMin',lo,variable=var);gpx.set_Controls('parmMax',hi,variable=var)
gpx.set_Controls('cycles',20)
G2sc.SetPrintLevel('all')
gpx.refine(printFile=root/'.tmp/profile_seeded.lst')
gpx.save()
print('RES',h.residuals)
print('RVALS',gpx.data['Covariance']['data'].get('Rvals'))
print('PROFILE',{k:h.InstrumentParameters[k][1] for k in ['U','V','W','X','Y']})
print('DEP',gpx.data['Covariance']['data'].get('depSigDict'))
