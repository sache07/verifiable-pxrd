from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
cod_co = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/58/9005896.cif")
base_path = root / ".tmp/profile_base.gpx"


def build_base():
    gpx = G2sc.G2Project(newgpx=base_path)
    hist = gpx.add_powder_histogram(root / ".tmp/pattern.xye", root / ".tmp/instrument.instprm", fmthint="xye")
    wo3 = gpx.add_phase(root / ".tmp/wo3_2311041_conventional.cif", phasename="monoclinic_WO3", histograms=[hist], fmthint="CIF")
    co3o4 = gpx.add_phase(cod_co, phasename="spinel_Co3O4", histograms=[hist], fmthint="CIF")
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-600.0, False]
    hist.Background[0][:] = ["chebyschev-1", True, 15, 3000.0] + [0.0] * 14
    hist.InstrumentParameters["W"][1] = 30.0
    for phase in (wo3, co3o4):
        phase.data["Histograms"][hist.name]["Scale"] = [1.0, True]
    gpx.set_Controls("cycles", 12)
    gpx.set_Controls("parmMin", -1000.0, variable=":0:Shift")
    gpx.set_Controls("parmMax", 0.0, variable=":0:Shift")
    gpx.refine()
    hist.SampleParameters["Shift"][1] = True
    gpx.refine()
    for phase in (wo3, co3o4):
        phase.set_refinements({"Cell": True})
    gpx.refine()
    gpx.save()


def profile_run(name, params, start):
    out = root / ".tmp" / f"profile_{name}.gpx"
    gpx = G2sc.G2Project(gpxfile=base_path, newgpx=out)
    hist = gpx.histogram(0)
    for key, val in start.items():
        hist.InstrumentParameters[key][1] = val
    hist.set_refinements({"Instrument Parameters": params})
    for var, lo, hi in [
        (":0:U", 0.0, 3000.0), (":0:V", -1000.0, 1000.0),
        (":0:W", 0.0, 1000.0), (":0:X", 0.0, 200.0), (":0:Y", -100.0, 100.0),
    ]:
        gpx.set_Controls("parmMin", lo, variable=var)
        gpx.set_Controls("parmMax", hi, variable=var)
    gpx.refine()
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    dep = cov.get("depSigDict", {})
    return {
        "name": name,
        "params": params,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "message": cov.get("Rvals", {}).get("msg", ""),
        "profile": {k: hist.InstrumentParameters[k][1] for k in ["U", "V", "W", "X", "Y"]},
        "fractions": [dep.get(f"{i}:0:WgtFrac") for i in range(2)],
    }


G2sc.SetPrintLevel("warn")
build_base()
tests = [
    ("uvwxy", ["U", "V", "W", "X", "Y"], {"U": 100.0, "V": 0.0, "W": 20.0, "X": 10.0, "Y": 0.0}),
    ("uvwx", ["U", "V", "W", "X"], {"U": 100.0, "V": 0.0, "W": 20.0, "X": 10.0, "Y": 0.0}),
    ("uwx", ["U", "W", "X"], {"U": 100.0, "V": 0.0, "W": 20.0, "X": 10.0, "Y": 0.0}),
    ("uvw", ["U", "V", "W"], {"U": 100.0, "V": 0.0, "W": 20.0, "X": 0.0, "Y": 0.0}),
    ("uwxy", ["U", "W", "X", "Y"], {"U": 100.0, "V": 0.0, "W": 20.0, "X": 10.0, "Y": 0.0}),
]
results=[]
for args in tests:
    result=profile_run(*args)
    results.append(result)
    print(json.dumps(result),flush=True)
with open(root / ".tmp/profile_tests.json","w") as fp:
    json.dump(results,fp,indent=2)
