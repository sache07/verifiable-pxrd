from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root=Path(__file__).resolve().parents[1]
gpx=G2sc.G2Project(gpxfile=root/'.tmp/profile_uwx.gpx',newgpx=root/'.tmp/profile_uwx_continued.gpx')
gpx.set_Controls('cycles',20)
G2sc.SetPrintLevel('warn')
for i in range(6):
    gpx.refine(printFile=root/'.tmp/profile_uwx_continued.lst')
    r=gpx.data['Covariance']['data'].get('Rvals',{})
    h=gpx.histogram(0)
    dep=gpx.data['Covariance']['data'].get('depSigDict',{})
    print(i,h.residuals.get('wR'),r.get('GOF'),r.get('Max shft/sig'),r.get('DelChi2'),r.get('msg'),
          {k:h.InstrumentParameters[k][1] for k in ['U','V','W','X','Y']},
          [dep.get(f'{j}:0:WgtFrac') for j in range(2)],flush=True)
gpx.save()
