#!/usr/bin/env python3
"""Alternate shared profile and phase-size refinements from a converged GPX."""

import json
import sys
from GSASII import GSASIIscriptable as G2sc

src, out = sys.argv[1:3]
keys = sys.argv[3:] or ["U", "W"]
proj = G2sc.G2Project(gpxfile=src, newgpx=out)
hist = proj.histogram(0)
proj.set_Controls("cycles", 12)

# First fit a small shared instrumental parameter set at fixed phase widths.
for ph in proj.phases():
    ph.clear_HAP_refinements({"Size": True})
hist.set_refinements({"Instrument Parameters": keys})
proj.do_refinements([{}])

# Then freeze the profile and update phase-specific sample broadening.
for key in keys:
    hist.data["Instrument Parameters"][0][key][2] = False
for ph in proj.phases():
    ph.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
proj.do_refinements([{}])
proj.do_refinements([{}])
proj.save()
print(json.dumps({
    "wR": hist.get_wR(),
    "Rvals": proj.data["Covariance"]["data"].get("Rvals", {}),
    "mass_fractions": hist.ComputeMassFracs(),
    "instrument": hist.InstrumentParameters,
    "sizes": {p.name: p.data["Histograms"][hist.name]["Size"] for p in proj.phases()},
}, indent=2, default=str))
