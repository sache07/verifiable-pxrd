#!/usr/bin/env python3
"""Build and refine a trial GSAS-II model for one or more CIF phases."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def prepare_inputs(work: Path) -> tuple[Path, Path]:
    src = work / "inputs" / "pattern.csv"
    xye = work / ".tmp" / "pattern.xye"
    inst = work / ".tmp" / "cu_ka1ka2.instprm"
    data = np.loadtxt(src, delimiter=",", skiprows=1)
    # No pointwise uncertainties were supplied. Poisson counting errors are
    # the least-assumptive approximation for the original count data.
    np.savetxt(xye, np.c_[data[:, 0], data[:, 1], np.sqrt(np.maximum(data[:, 1], 1.0))],
               fmt="%.8f %.8g %.8g")
    inst.write_text(
        "#GSAS-II instrument parameter file for supplied Cu Ka reflection data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.5;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:2.0;V:-2.0;W:5.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("name")
    ap.add_argument("cifs", nargs="+")
    ap.add_argument("--atoms", action="store_true")
    ap.add_argument("--profile", choices=("narrow", "medium", "broad"),
                    default="medium")
    args = ap.parse_args()

    work = Path.cwd()
    outdir = work / ".tmp" / args.name
    outdir.mkdir(parents=True, exist_ok=True)
    xye, inst = prepare_inputs(work)
    gpx_path = outdir / "trial.gpx"
    proj = G2sc.G2Project(newgpx=str(gpx_path))
    hist = proj.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    # The histogram and HAP scales are exactly correlated. Keep the former
    # fixed and refine only phase scales, as in a standard multiphase fit.
    hist.data["Sample Parameters"]["Scale"][:] = [1.0, False]
    ip = hist.data["Instrument Parameters"][0]
    profiles = {
        "narrow": {"U": 2.0, "V": -2.0, "W": 5.0, "X": 0.0, "Y": 0.0},
        "medium": {"U": 50.0, "V": 0.0, "W": 40.0, "X": 3.0, "Y": 0.0},
        "broad": {"U": 80.0, "V": 0.0, "W": 50.0, "X": 0.0, "Y": 0.0},
    }
    profile = {"Zero": 0.30, **profiles[args.profile]}
    for key, value in profile.items():
        ip[key][0] = ip[key][1] = value
        ip[key][2] = False
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "no. coeffs": 15, "refine": True},
    })
    phases = []
    for i, cif in enumerate(args.cifs):
        label = f"phase_{i+1}_{Path(cif).stem}"
        ph = proj.add_phase(cif, phasename=label, histograms=[hist], fmthint="CIF")
        # Use small, physically sensible fixed displacement parameters rather
        # than the zero values in several historical reference CIFs.
        for atom in ph.atoms():
            atom.uiso = 0.005 if atom.element.startswith(("W", "Mn")) else 0.010
        ph.data["Histograms"][hist.name]["Scale"][0] = 4.0 if i == 0 else 0.8
        ph.set_HAP_refinements({"Scale": True})
        phases.append(ph)

    proj.set_Controls("cycles", 8)
    # Establish background and phase scales first with a realistic profile
    # and an approximate zero correction.
    proj.do_refinements([{}])
    # Refine zero before allowing lattice metrics to move.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    proj.do_refinements([{}])
    # Then lattice metrics.
    for ph in phases:
        ph.set_refinements({"Cell": True})
    proj.do_refinements([{}])
    # Isotropic crystallite size captures sample broadening while the
    # uncalibrated but physical instrumental profile is held common and fixed.
    for ph in phases:
        ph.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.2, "refine": True}})
    proj.do_refinements([{}])
    if args.atoms:
        # Coordinates of heavy cations are supported by Cu-XRD; unconstrained
        # oxygen-coordinate/U refinements were tested and rejected as unstable.
        for ph in phases:
            refs = {a.label: "X" for a in ph.atoms()
                    if a.element.startswith(("W", "Mn"))}
            if refs:
                ph.set_refinements({"Atoms": refs})
        proj.do_refinements([{}])
    proj.save()

    result = {
        "wR_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": hist.InstrumentParameters,
        "background": hist.Background,
        "mass_fractions": hist.ComputeMassFracs(),
        "phases": [],
    }
    for ph in phases:
        h = ph.data["Histograms"][hist.name]
        result["phases"].append({
            "name": ph.name,
            "cell": ph.get_cell(),
            "composition": ph.composition,
            "density": ph.density,
            "scale": h["Scale"],
            "size": h["Size"],
            "mustrain": h["Mustrain"],
        })
    (outdir / "summary.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    arr = np.column_stack([
        hist.getdata("X"), hist.getdata("Yobs"), hist.getdata("Ycalc"),
        hist.getdata("Background"), hist.getdata("Residual")
    ])
    np.savetxt(outdir / "fit.csv", arr, delimiter=",",
               header="two_theta_deg,observed,calculated,background,difference", comments="",
               fmt="%.8g")
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
