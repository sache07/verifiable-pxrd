#!/usr/bin/env python3
"""Finalize, rename, export and summarize the selected GSAS-II refinement."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / ".tmp" / "shift_prof.gpx"
FINAL = ROOT / "final.gpx"


def rename_phases(proj: G2sc.G2Project, mapping: dict[str, str]) -> None:
    phases = proj.data["Phases"]
    proj.data["Phases"] = {mapping.get(key, key): value for key, value in phases.items()}
    for name in mapping.values():
        proj.data["Phases"][name]["General"]["Name"] = name
    for row in proj.names:
        if row and row[0] == "Phases":
            row[:] = [mapping.get(item, item) for item in row]
    for hist in proj.histograms():
        refl = hist.data.get("Reflection Lists", {})
        hist.data["Reflection Lists"] = {
            mapping.get(key, key): value for key, value in refl.items()
        }
        residuals = hist.data["data"][0]
        for key, value in list(residuals.items()):
            if isinstance(value, str) and value in mapping:
                residuals[key] = mapping[value]
    proj.update_ids()


def main() -> None:
    raw = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if SOURCE.resolve() == FINAL.resolve():
        proj = G2sc.G2Project(gpxfile=str(SOURCE))
    else:
        proj = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    hist = proj.histogram(0)
    hist.set_refinements({"Limits": [float(raw[0, 0]), float(raw[-1, 0])]})
    proj.set_Controls("cycles", 12)
    proj.do_refinements([{}])
    proj.do_refinements([{}])

    mapping = {
        "phase_1_2106293": "WO3_triclinic_P-1",
        "phase_2_mn2o3_min": "Mn2O3_bixbyite_Ia-3",
    }
    rename_phases(proj, mapping)
    proj.save(str(FINAL))

    # Reload the renamed final project, so all exports demonstrably originate
    # from the exact project submitted as final.gpx.
    proj = G2sc.G2Project(str(FINAL))
    hist = proj.histogram(0)
    out_cifs = {
        "WO3_triclinic_P-1": ROOT / "phase_WO3_triclinic.cif",
        "Mn2O3_bixbyite_Ia-3": ROOT / "phase_Mn2O3_bixbyite.cif",
    }
    for phase in proj.phases():
        phase.export_CIF(str(out_cifs[phase.name]))

    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    profile = np.column_stack((x, yobs, ycalc, yobs - ycalc, background))
    np.savetxt(
        ROOT / "fit.csv",
        profile,
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.12g", "%.12g", "%.12g", "%.12g"],
    )

    fractions = hist.ComputeMassFracs()
    cov = proj.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    summary = {
        "histogram_residuals": hist.residuals,
        "mass_fractions": fractions,
        "Rvals": rvals,
        "instrument": hist.InstrumentParameters,
        "sample_parameters": hist.data["Sample Parameters"],
        "limits": [hist.Limits("lower"), hist.Limits("upper")],
        "phases": {},
    }
    for phase in proj.phases():
        cell, cell_esd = phase.get_cell_and_esd()
        hdata = phase.data["Histograms"][hist.name]
        summary["phases"][phase.name] = {
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "composition": phase.composition,
            "cell": cell,
            "cell_esd": cell_esd,
            "density_g_cm3": phase.density,
            "scale": hdata["Scale"],
            "size": hdata["Size"],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": atom.coordinates,
                    "occupancy": atom.occupancy,
                    "uiso": atom.uiso,
                    "refinement_flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    (ROOT / ".tmp" / "final_summary.json").write_text(
        json.dumps(summary, indent=2, default=lambda obj: obj.tolist() if hasattr(obj, "tolist") else str(obj)) + "\n"
    )
    print(json.dumps(summary, indent=2, default=lambda obj: obj.tolist() if hasattr(obj, "tolist") else str(obj)))


if __name__ == "__main__":
    main()
