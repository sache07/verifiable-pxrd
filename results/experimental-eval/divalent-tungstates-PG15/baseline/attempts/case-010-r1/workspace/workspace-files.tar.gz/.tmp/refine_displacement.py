#!/usr/bin/env python3
"""Compare Bragg-Brentano specimen displacement with a constant zero term."""

import json
import sys
from GSASII import GSASIIscriptable as G2sc

src, out, mode = sys.argv[1:4]
proj = G2sc.G2Project(gpxfile=src, newgpx=out)
hist = proj.histogram(0)
inst = hist.data["Instrument Parameters"][0]
sample = hist.data["Sample Parameters"]
if mode == "shift":
    inst["Zero"][:] = [0.0, 0.0, False]
    sample["Shift"][:] = [-530.0, True]
elif mode == "both":
    inst["Zero"][2] = True
    sample["Shift"][:] = [0.0, True]
else:
    raise ValueError(mode)
proj.set_Controls("cycles", 12)
proj.do_refinements([{}])
proj.do_refinements([{}])
proj.save()
print(json.dumps({
    "wR": hist.get_wR(),
    "Rvals": proj.data["Covariance"]["data"].get("Rvals", {}),
    "mass_fractions": hist.ComputeMassFracs(),
    "zero": inst["Zero"],
    "shift_microns": sample["Shift"],
    "cells": {p.name: p.get_cell_and_esd() for p in proj.phases()},
}, indent=2, default=str))
