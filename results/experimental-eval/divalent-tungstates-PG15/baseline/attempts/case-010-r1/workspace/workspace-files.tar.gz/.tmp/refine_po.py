#!/usr/bin/env python3
"""Test one March-Dollase direction from an existing refinement."""

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

src, out, phase_no, h, k, l = sys.argv[1:]
proj = G2sc.G2Project(gpxfile=src, newgpx=out)
hist = proj.histogram(0)
phase = proj.phase(int(phase_no))
po = phase.data["Histograms"][hist.name]["Pref.Ori."]
po[0] = "MD"
po[1] = 1.0
po[2] = True
po[3] = [int(h), int(k), int(l)]
proj.set_Controls("cycles", 12)
proj.do_refinements([{}])
proj.do_refinements([{}])
proj.save()
print(json.dumps({
    "wR": hist.get_wR(),
    "Rvals": proj.data["Covariance"]["data"].get("Rvals", {}),
    "mass_fractions": hist.ComputeMassFracs(),
    "preferred_orientation": po,
}, indent=2, default=str))
