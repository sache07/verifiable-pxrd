#!/usr/bin/env python3
"""Consolidate the selected profile/texture model and repolish metrics."""

import argparse
import json
import os
import sys

from GSASII import GSASIIscriptable as G2sc


def report(project, label):
    hist = project.histogram(0)
    rv = project.data["Covariance"]["data"].get("Rvals", {})
    print("RESULT", json.dumps({
        "label": label,
        "Rwp": rv.get("Rwp"),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "max_shift_esd": rv.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "zero": hist.InstrumentParameters["Zero"],
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
                "preferred_orientation": phase.data["Histograms"][hist.name]["Pref.Ori."],
            }
            for phase in project.phases()
        },
        "frozen": [str(item) for item in project.data["Controls"]["data"]
                   .get("parmFrozen", {}).get("FrozenList", [])],
    }, default=str))


def refine(project, label, repeats=1):
    for repeat in range(repeats):
        project.do_refinements([{}])
        project.save()
        suffix = f"_{repeat + 1}" if repeats > 1 else ""
        report(project, label + suffix)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(args.input, newgpx=os.path.abspath(args.output))
    project.set_Controls("cycles", 32)
    controls = project.data["Controls"]["data"]
    controls["shift factor"] = 0.10
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": [
        "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)"
    ]})

    # Refine the selected nuisance model jointly from its converged sequential
    # endpoint. This captures correlations while keeping all terms bounded.
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [0, 0, 1]
        project.set_Controls("parmMin", 0.005,
                             variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 20.0,
                             variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMin", 0.5,
                             variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 2.0,
                             variable=f"{phase.id}:0:MD")

    wo3 = project.phase(0)
    wo3_hap = wo3.data["Histograms"][hist.name]
    wo3_hap["Mustrain"][0] = "generalized"
    wo3_hap["Mustrain"][2] = [False for _ in wo3_hap["Mustrain"][2]]
    wo3_hap["Mustrain"][5] = [False for _ in wo3_hap["Mustrain"][5]]
    for index in range(len(wo3_hap["Mustrain"][4])):
        if index < 6:
            wo3_hap["Mustrain"][5][index] = True
            variable = f"{wo3.id}:0:Mustrain;{index}"
            project.set_Controls("parmMin", 0.0, variable=variable)
            project.set_Controls("parmMax", 1.0e8, variable=variable)
        else:
            wo3_hap["Mustrain"][4][index] = 0.0

    bao2 = project.phase(1)
    bao2_hap = bao2.data["Histograms"][hist.name]
    bao2_hap["Mustrain"][0] = "isotropic"
    bao2_hap["Mustrain"][2] = [True, False, False]
    bao2_hap["Mustrain"][5] = [False for _ in bao2_hap["Mustrain"][5]]
    project.set_Controls("parmMin", 0.0,
                         variable=f"{bao2.id}:0:Mustrain;i")
    project.set_Controls("parmMax", 50000.0,
                         variable=f"{bao2.id}:0:Mustrain;i")
    refine(project, "joint_profile_texture", repeats=4)

    # Freeze microstructure/texture before the final metric and scale polish.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False

    controls["parmFrozen"] = {"FrozenList": []}
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        refine(project, f"cell_{phase.id}", repeats=3)
        phase.clear_refinements({"Cell": True})

    project.set_Controls("parmMin", -0.5, variable=":0:Zero")
    project.set_Controls("parmMax", 0.5, variable=":0:Zero")
    hist.InstrumentParameters["Zero"][2] = True
    refine(project, "zero", repeats=2)
    hist.InstrumentParameters["Zero"][2] = False

    controls["parmFrozen"] = {"FrozenList": []}
    refine(project, "final_scales")
    project.save()
    report(project, "final")
    return 0


if __name__ == "__main__":
    sys.exit(main())
