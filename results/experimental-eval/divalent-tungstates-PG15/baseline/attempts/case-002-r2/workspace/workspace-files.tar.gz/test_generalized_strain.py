#!/usr/bin/env python3
"""Test Stephens generalized microstrain for the monoclinic WO3 phase."""

import argparse
import json
import os
import sys

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIspc as G2spc


def report(project, label):
    hist = project.histogram(0)
    rv = project.data["Covariance"]["data"].get("Rvals", {})
    print("RESULT", json.dumps({
        "label": label,
        "Rwp": rv.get("Rwp"),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "max_shift_esd": rv.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "profile": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"][:3],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
        "frozen": [str(item) for item in project.data["Controls"]["data"]
                   .get("parmFrozen", {}).get("FrozenList", [])],
    }, default=str))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(args.input, newgpx=os.path.abspath(args.output))
    project.set_Controls("cycles", 24)
    controls = project.data["Controls"]["data"]
    controls["shift factor"] = 0.1
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": [
        "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)"
    ]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]

    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    iso = hap["Mustrain"][1][0]
    sgdata = phase.data["General"]["SGData"]
    cell = phase.data["General"]["Cell"][1:7]
    values = list(G2spc.Muiso2Shkl(iso, sgdata, cell))
    hap["Mustrain"][0] = "generalized"
    hap["Mustrain"][4] = values
    hap["Mustrain"][5] = [True for _ in values]
    for index in range(len(values)):
        variable = f"{phase.id}:0:Mustrain;{index}"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 1.0e8, variable=variable)

    for repeat in range(5):
        project.do_refinements([{}])
        project.save()
        report(project, f"generalized_{repeat + 1}")

    hap["Mustrain"][5] = [False for _ in values]
    project.do_refinements([{}])
    project.save()
    report(project, "final_fixed_profile")
    return 0


if __name__ == "__main__":
    sys.exit(main())
