#!/usr/bin/env python3
"""Coordinate-descent polish of isotropic size/strain broadening.

This starts from an already converged GSAS-II project.  It deliberately
refines one sample-broadening parameter at a time to avoid the severe
size/strain/instrument correlations encountered in a simultaneous fit.
"""

import argparse
import json
import os
import sys

from GSASII import GSASIIscriptable as G2sc


def report(project, label):
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    print("RESULT", json.dumps({
        "label": label,
        "Rwp": rvals.get("Rwp"),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "phases": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"][:3],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"][:3],
            }
            for phase in project.phases()
        },
        "frozen": [
            str(item) for item in project.data["Controls"]["data"]
            .get("parmFrozen", {}).get("FrozenList", [])
        ],
    }, default=str))


def refine(project, label, repeats=2):
    for repeat in range(repeats):
        project.do_refinements([{}])
        project.save()
        report(project, f"{label}_{repeat + 1}")


def set_flags(project, selected_phase=None, selected_kind=None):
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Mustrain"][0] = "isotropic"
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        if phase.id == selected_phase and selected_kind == "size":
            hap["Size"][2][0] = True
        if phase.id == selected_phase and selected_kind == "mustrain":
            hap["Mustrain"][2][0] = True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(args.input, newgpx=os.path.abspath(args.output))
    project.set_Controls("cycles", 16)
    controls = project.data["Controls"]["data"]
    controls["shift factor"] = 0.35
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}

    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": [
        "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)"
    ]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls(
            "parmMin", 0.005, variable=f"{phase.id}:0:Size;i"
        )
        project.set_Controls(
            "parmMax", 20.0, variable=f"{phase.id}:0:Size;i"
        )
        project.set_Controls(
            "parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i"
        )
        project.set_Controls(
            "parmMax", 50000.0, variable=f"{phase.id}:0:Mustrain;i"
        )

    # Repeat coordinate descent twice. Size controls the predominantly
    # Lorentzian 1/cos(theta) contribution and strain the tan(theta) term.
    for outer in range(2):
        for phase in project.phases():
            set_flags(project, phase.id, "size")
            refine(project, f"pass{outer + 1}_{phase.name}_size")
            set_flags(project, phase.id, "mustrain")
            refine(project, f"pass{outer + 1}_{phase.name}_strain")

    set_flags(project)
    refine(project, "final_scales", repeats=1)
    project.save()
    report(project, "final")
    return 0


if __name__ == "__main__":
    sys.exit(main())
