#!/usr/bin/env python3
"""Export the selected GSAS-II refinement and all requested deliverables."""

import csv
import json
import math
import os
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE_PROJECT = "consolidated_final.gpx"
FINAL_PROJECT = "final.gpx"
FIT_CSV = "fit.csv"
RESULT_JSON = "result.json"
REPORT_MD = "report.md"


PHASE_INFO = [
    {
        "formula": "WO3",
        "name": "monoclinic tungsten trioxide",
        "space_group": "P 21/n",
        "space_group_number": 14,
        "cif_path": "phase_1_WO3.cif",
        "source": "COD 2311041 (transformed from P 21/c to P 21/n setting)",
    },
    {
        "formula": "BaO2",
        "name": "tetragonal barium peroxide",
        "space_group": "I 4/m m m",
        "space_group_number": 139,
        "cif_path": "phase_2_BaO2.cif",
        "source": "COD 1010113",
    },
]


def clean_float(value):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"Non-finite value encountered: {value}")
    return value


def main():
    G2sc.SetPrintLevel("warn")
    final_path = os.path.abspath(FINAL_PROJECT)
    project = G2sc.G2Project(SOURCE_PROJECT, newgpx=final_path)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.save()

    hist = project.histogram(0)
    phases = project.phases()
    if len(phases) != 2:
        raise RuntimeError(f"Expected 2 phases, found {len(phases)}")
    if hist.SampleParameters["Scale"][1]:
        raise RuntimeError("Overall sample scale must be fixed for QPA")

    fractions = hist.ComputeMassFracs()
    fraction_sum = sum(value[0] for value in fractions.values())
    if abs(fraction_sum - 1.0) > 1e-10:
        raise RuntimeError(f"Mass fractions do not sum to one: {fraction_sum}")

    for phase, info in zip(phases, PHASE_INFO):
        phase.export_CIF(info["cif_path"])

    x, yobs, weights, ycalc, ybkg, stored_diff = [
        np.asarray(row, dtype=float) for row in hist.data["data"][1]
    ]
    lower, upper = [float(v) for v in hist.data["Limits"][1]]
    # GSAS-II includes the first grid point just above the nominal upper
    # limit. Select the exact calculated range rather than reimplementing its
    # index rounding, so fit.csv has the same 8,284 observations as the GPX.
    selected = (ycalc != 0.0) | (ybkg != 0.0)
    arrays = [x[selected], yobs[selected], ycalc[selected], ybkg[selected]]
    if not all(np.all(np.isfinite(row)) for row in arrays):
        raise RuntimeError("Non-finite value in exported fit profile")
    difference = arrays[1] - arrays[2]
    if np.max(np.abs(difference - stored_diff[selected])) > 1e-6:
        raise RuntimeError("GSAS-II stored difference is inconsistent with Yobs-Ycalc")
    with open(FIT_CSV, "w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg",
            "observed_counts",
            "calculated_counts",
            "background_counts",
            "difference_counts",
        ])
        for values in zip(*arrays, difference):
            writer.writerow([
                f"{values[0]:.8f}",
                f"{values[1]:.6f}",
                f"{values[2]:.6f}",
                f"{values[3]:.6f}",
                f"{values[4]:.6f}",
            ])

    residuals = hist.residuals
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    result_phases = []
    for index, (phase, info) in enumerate(zip(phases, PHASE_INFO)):
        fraction, fraction_esd = fractions[phase.name]
        cell = {key: clean_float(value)
                for key, value in phase.get_cell().items()}
        result_phases.append({
            "phase_id": index + 1,
            "name": info["name"],
            "formula": info["formula"],
            "space_group": info["space_group"],
            "space_group_number": info["space_group_number"],
            "cif_path": info["cif_path"],
            "structure_source": info["source"],
            "weight_fraction": clean_float(fraction),
            "weight_percent": clean_float(100.0 * fraction),
            "weight_fraction_statistical_esd": clean_float(fraction_esd),
            "estimated_absolute_systematic_uncertainty": 0.02,
            "unit_cell": cell,
            "phase_fit_statistics": {
                "R_F_percent": clean_float(residuals[f"{phase.id}:0:Rf"]),
                "R_F_squared_percent": clean_float(
                    residuals[f"{phase.id}:0:Rf^2"]
                ),
                "reflection_count": int(residuals[f"{phase.id}:0:Nref"]),
            },
        })

    result = {
        "project_path": FINAL_PROJECT,
        "fit_path": FIT_CSV,
        "fraction_basis": (
            "Normalized over the two modeled crystalline phases only; "
            "amorphous content and undetected trace phases are excluded."
        ),
        "phases": result_phases,
        "fit_statistics": {
            "refined_two_theta_range_deg": [lower, upper],
            "profile_points": int(np.count_nonzero(selected)),
            "R_p_percent": clean_float(residuals["R"]),
            "R_wp_percent": clean_float(residuals["wR"]),
            "R_exp_percent": clean_float(residuals["wRmin"]),
            "R_background_percent": clean_float(residuals["Rb"]),
            "weighted_R_background_percent": clean_float(residuals["wRb"]),
            "goodness_of_fit": clean_float(rvals["GOF"]),
            "chi_squared": clean_float(rvals["chisq"]),
            "observations": int(rvals["Nobs"]),
            "variables_in_final_scale_background_cycle": int(rvals["Nvars"]),
            "converged": bool(rvals["converged"]),
            "maximum_shift_over_esd": clean_float(rvals["Max shft/sig"]),
        },
        "measurement_model": {
            "radiation": "Cu K-alpha doublet",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "geometry": "reflection (Bragg-Brentano model)",
            "weighting": (
                "Poisson count weights (1/I), because pointwise standard "
                "uncertainties were not supplied"
            ),
        },
    }
    with open(RESULT_JSON, "w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, sort_keys=False)
        stream.write("\n")

    wo3 = result_phases[0]
    bao2 = result_phases[1]
    fit = result["fit_statistics"]
    report = f"""# PXRD phase analysis

## Result

The pattern is described by two crystalline phases, normalized over the modeled crystalline material:

| Phase | Structural model | Weight fraction |
|---|---|---:|
| Monoclinic WO3 | P 21/n (No. 14), COD 2311041 transformed from the published P 21/c setting | {wo3['weight_percent']:.2f} wt% |
| Tetragonal BaO2 | I 4/mmm (No. 139), COD 1010113 | {bao2['weight_percent']:.2f} wt% |

The refined cells are WO3: a = {wo3['unit_cell']['length_a']:.5f}, b = {wo3['unit_cell']['length_b']:.5f}, c = {wo3['unit_cell']['length_c']:.5f} A, beta = {wo3['unit_cell']['angle_beta']:.4f} degrees; and BaO2: a = {bao2['unit_cell']['length_a']:.5f}, c = {bao2['unit_cell']['length_c']:.5f} A. Atomic coordinates were retained from the published structures; lattice parameters, phase scales, zero offset, background, sample broadening and mild preferred orientation were refined.

## Evidence

The 23.42/23.92/24.66 degree triplet and the associated 29.2, 34.4, 41-51 and higher-angle groups identify room-temperature monoclinic WO3. Tetragonal BaO2 accounts for the independent lines near 26.3, 27.1, 33.5, 43.0 and 46.6 degrees. Together the two phases index all prominent peak groups. The strongest expected scheelite BaWO4 line near 31.9 degrees is absent, so BaWO4 was not included. Alternative WO3 settings/published coordinate sets and a BaWO4 trial were inferior to the submitted model.

The final GSAS-II fit over {lower:.1f}-{upper:.1f} degrees gives Rwp = {fit['R_wp_percent']:.3f}%, Rp = {fit['R_p_percent']:.3f}%, Rexp = {fit['R_exp_percent']:.3f}%, and GOF = {fit['goodness_of_fit']:.3f}. Phase-specific RF values are {wo3['phase_fit_statistics']['R_F_percent']:.2f}% for WO3 and {bao2['phase_fit_statistics']['R_F_percent']:.2f}% for BaO2. The Cu K-alpha1/K-alpha2 doublet and reported 0.5 intensity ratio were used; raw counts were weighted as 1/I.

## Uncertainty

The conditional GSAS-II scale-factor esd is about 0.21 wt% for each fraction, but this understates model uncertainty. The instrument profile was not calibrated, the peaks show strong anisotropic broadening, and scale, broadening and preferred orientation are correlated. Comparisons among defensible profile and WO3 models changed the WO3 fraction by about one percentage point; a conservative uncertainty is therefore approximately +/-2 wt percentage points (absolute) on each reported fraction. The lattice parameters likewise carry unquantified systematic uncertainty because no internal angular standard was supplied.

Fractions are normalized only over the modeled crystalline phases. Amorphous material cannot be quantified from these data, and a trace or strongly overlapping crystalline impurity cannot be excluded. No additional crystalline phase can be assigned reliably from the residuals. The GOF above unity and structured residual around several intense/overlapped WO3 groups reflect these line-shape and intensity limitations.
"""
    with open(REPORT_MD, "w", encoding="utf-8") as stream:
        stream.write(report)

    print(json.dumps({
        "project": FINAL_PROJECT,
        "fit": FIT_CSV,
        "result": RESULT_JSON,
        "report": REPORT_MD,
        "cifs": [info["cif_path"] for info in PHASE_INFO],
        "fractions": {info["formula"]: result_phases[i]["weight_fraction"]
                      for i, info in enumerate(PHASE_INFO)},
        "Rwp": fit["R_wp_percent"],
        "GOF": fit["goodness_of_fit"],
    }, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
