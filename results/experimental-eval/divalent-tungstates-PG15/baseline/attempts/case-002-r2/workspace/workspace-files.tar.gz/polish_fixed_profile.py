#!/usr/bin/env python3
"""Polish cells, zero and scales with a fixed, stable profile model."""

import argparse
import json
import os
import sys

from GSASII import GSASIIscriptable as G2sc


def report(project, label):
    hist = project.histogram(0)
    rv = project.data["Covariance"]["data"].get("Rvals", {})
    print("RESULT", json.dumps({
        "label": label,
        "Rwp": rv.get("Rwp"),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "max_shift_esd": rv.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "zero": hist.InstrumentParameters["Zero"],
        "cells": {p.name: p.get_cell() for p in project.phases()},
    }, default=str))


def refine(project, label):
    project.do_refinements([{}])
    project.save()
    report(project, label)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    args = ap.parse_args()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(args.input, newgpx=os.path.abspath(args.output))
    project.set_Controls("cycles", 16)
    ctrl = project.data["Controls"]["data"]
    ctrl["shift factor"] = 0.5
    ctrl["parmFrozen"] = {"FrozenList": []}
    ctrl["parmMinDict"] = {}
    ctrl["parmMaxDict"] = {}
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": [
        "Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"
    ]})
    # Use the stable endpoint from the constrained isotropic trial. These
    # values remain fixed while metrics and quantitative scales are polished.
    hist.InstrumentParameters["W"][1] = 100.0
    hist.InstrumentParameters["Zero"][1] = 0.0442

    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    project.save()
    refine(project, "fixed_profile_scales")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        for n in range(4):
            refine(project, f"cell_{phase.id}_{n + 1}")
        phase.clear_refinements({"Cell": True})

    project.set_Controls("parmMin", -0.5, variable=":0:Zero")
    project.set_Controls("parmMax", 0.5, variable=":0:Zero")
    hist.InstrumentParameters["Zero"][2] = True
    refine(project, "zero_1")
    refine(project, "zero_2")
    hist.InstrumentParameters["Zero"][2] = False
    refine(project, "final_scales")
    project.save()
    report(project, "final")
    return 0


if __name__ == "__main__":
    sys.exit(main())
