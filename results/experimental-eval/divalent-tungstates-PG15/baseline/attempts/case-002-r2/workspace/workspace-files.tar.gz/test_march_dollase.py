#!/usr/bin/env python3
"""Test a single March-Dollase preferred-orientation correction for WO3."""

import argparse
import json
import os
import sys

from GSASII import GSASIIscriptable as G2sc


def report(project, label):
    hist = project.histogram(0)
    rv = project.data["Covariance"]["data"].get("Rvals", {})
    print("RESULT", json.dumps({
        "label": label,
        "Rwp": rv.get("Rwp"),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "max_shift_esd": rv.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "preferred_orientation": {
            p.name: p.data["Histograms"][hist.name]["Pref.Ori."]
            for p in project.phases()
        },
        "frozen": [str(item) for item in project.data["Controls"]["data"]
                   .get("parmFrozen", {}).get("FrozenList", [])],
    }, default=str))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("axis", choices=["100", "010", "001"])
    parser.add_argument("--phase-index", type=int, default=0)
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(args.input, newgpx=os.path.abspath(args.output))
    project.set_Controls("cycles", 20)
    controls = project.data["Controls"]["data"]
    controls["shift factor"] = 0.25
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": [
        "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)"
    ]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False

    phase = project.phase(args.phase_index)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = [int(ch) for ch in args.axis]
    project.set_Controls("parmMin", 0.5, variable=f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 2.0, variable=f"{phase.id}:0:MD")
    for repeat in range(3):
        project.do_refinements([{}])
        project.save()
        report(project, f"MD_{args.axis}_{repeat + 1}")
    po[2] = False
    project.do_refinements([{}])
    project.save()
    report(project, "final_fixed_profile")
    return 0


if __name__ == "__main__":
    sys.exit(main())
