#!/usr/bin/env python3
"""Test a two-parameter uniaxial crystallite-size model for WO3."""

import argparse
import json
import os
import sys

from GSASII import GSASIIscriptable as G2sc


def report(project, label):
    hist = project.histogram(0)
    rv = project.data["Covariance"]["data"].get("Rvals", {})
    print("RESULT", json.dumps({
        "label": label,
        "Rwp": rv.get("Rwp"),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "max_shift_esd": rv.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "size": {
            p.name: p.data["Histograms"][hist.name]["Size"]
            for p in project.phases()
        },
        "frozen": [str(item) for item in project.data["Controls"]["data"]
                   .get("parmFrozen", {}).get("FrozenList", [])],
    }, default=str))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("axis", choices=["100", "010", "001"])
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(args.input, newgpx=os.path.abspath(args.output))
    project.set_Controls("cycles", 20)
    controls = project.data["Controls"]["data"]
    controls["shift factor"] = 0.2
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": [
        "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)"
    ]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]

    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    iso = hap["Size"][1][0]
    hap["Size"][0] = "uniaxial"
    hap["Size"][1][0:2] = [iso, iso]
    hap["Size"][2][0:2] = [True, True]
    hap["Size"][3] = [int(ch) for ch in args.axis]
    for stem in ("Size;i", "Size;a"):
        project.set_Controls("parmMin", 0.005,
                             variable=f"{phase.id}:0:{stem}")
        project.set_Controls("parmMax", 20.0,
                             variable=f"{phase.id}:0:{stem}")
    for repeat in range(3):
        project.do_refinements([{}])
        project.save()
        report(project, f"uniaxial_size_{args.axis}_{repeat + 1}")
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    project.do_refinements([{}])
    project.save()
    report(project, "final_fixed_profile")
    return 0


if __name__ == "__main__":
    sys.exit(main())
