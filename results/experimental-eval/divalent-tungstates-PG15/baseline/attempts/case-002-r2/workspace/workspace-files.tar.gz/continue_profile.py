#!/usr/bin/env python3
"""Test a physically constrained anisotropic sample-broadening model."""

import argparse
import json
import os
import sys
import traceback

from GSASII import GSASIIscriptable as G2sc


def report(project, label):
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    print("RESULT", json.dumps({
        "label": label,
        "Rwp": rvals.get("Rwp"),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "zero": hist.InstrumentParameters["Zero"],
        "W": hist.InstrumentParameters["W"],
        "phases": {
            p.name: {
                "cell": p.get_cell(),
                "scale": p.data["Histograms"][hist.name]["Scale"],
                "size": p.data["Histograms"][hist.name]["Size"][:4],
                "mustrain": p.data["Histograms"][hist.name]["Mustrain"][:4],
            }
            for p in project.phases()
        },
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }, default=str))


def refine(project, label):
    try:
        project.do_refinements([{}])
    except Exception:
        traceback.print_exc()
        return False
    project.save()
    report(project, label)
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    args = ap.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(args.input, newgpx=os.path.abspath(args.output))
    project.set_Controls("cycles", 16)
    controls = project.data["Controls"]["data"]
    controls["shift factor"] = 0.5
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histogram(0)

    # Retain only a modest instrumental Gaussian contribution; the distinct
    # width evolution of the two phases is represented as sample broadening.
    hist.InstrumentParameters["W"][1:] = [20.0, False]
    hist.InstrumentParameters["U"][1:] = [2.0, False]
    hist.InstrumentParameters["V"][1:] = [-2.0, False]
    hist.InstrumentParameters["X"][1:] = [0.0, False]
    hist.InstrumentParameters["Y"][1:] = [0.0, False]
    hist.InstrumentParameters["Zero"][2] = False

    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "uniaxial"
        hap["Size"][1][0:3] = [0.10, 0.10, 0.5]
        hap["Size"][2][0:3] = [True, True, False]
        hap["Size"][3] = [0, 0, 1]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0:3] = [3000.0, 3000.0, 0.5]
        hap["Mustrain"][2][0:3] = [False, False, False]
        hap["Mustrain"][3] = [0, 0, 1]
        for stem in ("Size;i", "Size;a"):
            project.set_Controls("parmMin", 0.005, variable=f"{phase.id}:0:{stem}")
            project.set_Controls("parmMax", 5.0, variable=f"{phase.id}:0:{stem}")
        for stem in ("Mustrain;i", "Mustrain;a"):
            project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:{stem}")
            project.set_Controls("parmMax", 50000.0, variable=f"{phase.id}:0:{stem}")

    project.save()
    if not refine(project, "uniaxial_size_1"):
        return 2
    if not refine(project, "uniaxial_size_2"):
        return 2

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][2][0:2] = [True, True]
    if not refine(project, "uniaxial_strain_1"):
        return 2
    if not refine(project, "uniaxial_strain_2"):
        return 2

    # With peak widths established, return to the phase metrics and specimen
    # zero offset. Refine each cell separately to limit correlation.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        for repeat in range(3):
            if not refine(project, f"cell_{phase.id}_{repeat + 1}"):
                return 2
        phase.clear_refinements({"Cell": True})

    project.set_Controls("parmMin", -0.5, variable=":0:Zero")
    project.set_Controls("parmMax", 0.5, variable=":0:Zero")
    hist.InstrumentParameters["Zero"][2] = True
    if not refine(project, "zero_1"):
        return 2
    if not refine(project, "zero_2"):
        return 2

    project.save()
    report(project, "final")
    return 0


if __name__ == "__main__":
    sys.exit(main())
