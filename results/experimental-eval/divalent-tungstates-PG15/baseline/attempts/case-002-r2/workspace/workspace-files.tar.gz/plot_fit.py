#!/usr/bin/env python3
"""Write a compact diagnostic plot for a GSAS-II powder project."""

import argparse

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("output")
    args = parser.parse_args()
    project = G2sc.G2Project(args.project)
    hist = project.histogram(0)
    x, yobs, _weight, ycalc, ybkg, ydiff = [
        np.asarray(row, dtype=float) for row in hist.data["data"][1]
    ]
    low, high = hist.data["Limits"][1]
    use = (x >= low) & (x <= high)
    x, yobs, ycalc, ybkg, ydiff = [row[use] for row in
                                   (x, yobs, ycalc, ybkg, ydiff)]

    windows = [(10, 35), (35, 60), (60, 100)]
    fig, axes = plt.subplots(4, 1, figsize=(18, 12), constrained_layout=True)
    for axis, (xmin, xmax) in zip(axes[:3], windows):
        select = (x >= xmin) & (x <= xmax)
        axis.plot(x[select], yobs[select], color="black", linewidth=0.8,
                  label="Observed")
        axis.plot(x[select], ycalc[select], color="red", linewidth=1.0,
                  label="Calculated")
        axis.plot(x[select], ybkg[select], color="royalblue", linewidth=0.8,
                  label="Background")
        axis.set_xlim(xmin, xmax)
        axis.set_ylabel("Counts")
    axes[0].legend(loc="upper right", ncol=3, frameon=False)
    axes[2].set_xlabel(r"$2\theta$ (degrees)")
    axes[3].plot(x, ydiff, color="black", linewidth=0.7)
    axes[3].axhline(0, color="red", linewidth=0.7)
    axes[3].set_xlim(low, high)
    axes[3].set_xlabel(r"$2\theta$ (degrees)")
    axes[3].set_ylabel("Obs. - calc.")
    fig.savefig(args.output, dpi=160)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
