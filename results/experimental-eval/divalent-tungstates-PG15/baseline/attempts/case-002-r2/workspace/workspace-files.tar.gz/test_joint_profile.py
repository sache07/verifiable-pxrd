#!/usr/bin/env python3
"""Test a joint bounded refinement of four isotropic sample-width terms."""

import argparse
import json
import os
import sys

from GSASII import GSASIIscriptable as G2sc


def summary(project, label):
    hist = project.histogram(0)
    rv = project.data["Covariance"]["data"].get("Rvals", {})
    print("RESULT", json.dumps({
        "label": label,
        "Rwp": rv.get("Rwp"),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "max_shift_esd": rv.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "profile": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"][:3],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"][:3],
            }
            for phase in project.phases()
        },
        "frozen": [str(item) for item in project.data["Controls"]["data"]
                   .get("parmFrozen", {}).get("FrozenList", [])],
    }, default=str))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(args.input, newgpx=os.path.abspath(args.output))
    project.set_Controls("cycles", 24)
    controls = project.data["Controls"]["data"]
    controls["shift factor"] = 0.2
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": [
        "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)"
    ]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][2] = [True, False, False]
        project.set_Controls("parmMin", 0.005,
                             variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 20.0,
                             variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMin", 0.0,
                             variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 50000.0,
                             variable=f"{phase.id}:0:Mustrain;i")
    for repeat in range(4):
        project.do_refinements([{}])
        project.save()
        summary(project, f"joint_{repeat + 1}")
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    project.do_refinements([{}])
    project.save()
    summary(project, "final_fixed_profile")
    return 0


if __name__ == "__main__":
    sys.exit(main())
