#!/usr/bin/env python3
"""Polish the six even Stephens terms and remove bound-frozen odd terms."""

import argparse
import json
import os
import sys

from GSASII import GSASIIscriptable as G2sc


def report(project, label):
    hist = project.histogram(0)
    rv = project.data["Covariance"]["data"].get("Rvals", {})
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    print("RESULT", json.dumps({
        "label": label,
        "Rwp": rv.get("Rwp"),
        "GOF": rv.get("GOF"),
        "converged": rv.get("converged"),
        "max_shift_esd": rv.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "mustrain": hap["Mustrain"],
        "frozen": [str(item) for item in project.data["Controls"]["data"]
                   .get("parmFrozen", {}).get("FrozenList", [])],
    }, default=str))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(args.input, newgpx=os.path.abspath(args.output))
    project.set_Controls("cycles", 24)
    controls = project.data["Controls"]["data"]
    controls["shift factor"] = 0.15
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": [
        "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)"
    ]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]

    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "generalized"
    for index in range(len(hap["Mustrain"][4])):
        if index < 6:
            hap["Mustrain"][5][index] = True
            variable = f"{phase.id}:0:Mustrain;{index}"
            project.set_Controls("parmMin", 0.0, variable=variable)
            project.set_Controls("parmMax", 1.0e8, variable=variable)
        else:
            hap["Mustrain"][4][index] = 0.0
            hap["Mustrain"][5][index] = False
    for repeat in range(4):
        project.do_refinements([{}])
        project.save()
        report(project, f"even_terms_{repeat + 1}")

    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    controls["parmFrozen"] = {"FrozenList": []}
    project.do_refinements([{}])
    project.save()
    report(project, "final_fixed_profile")
    return 0


if __name__ == "__main__":
    sys.exit(main())
