#!/usr/bin/env python3
"""Build and refine a two-phase GSAS-II trial model."""

import argparse
import json
import os
import sys
import traceback

import numpy as np

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"


def cod_path(cod_id):
    return os.path.join(COD_ROOT, cod_id[0], cod_id[1:3], cod_id[3:5], cod_id + ".cif")


def summary(project, label):
    hist = project.histogram(0)
    out = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {k: v for k, v in hist.InstrumentParameters.items()},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "mass": phase.data["General"]["Mass"],
        }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as err:
        out["mass_fraction_error"] = repr(err)
    try:
        out["Rvals"] = project.data["Covariance"]["data"].get("Rvals", {})
    except Exception:
        pass
    print(json.dumps(out, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)))


def run_step(project, label, refinements=None, phase="all"):
    try:
        project.do_refinements(
            refinements if refinements is not None else [{}], phase=phase
        )
        summary(project, label)
        project.save()
        return True
    except Exception:
        print("STEP_FAILED", label)
        traceback.print_exc()
        project.save()
        return False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("--bao2-id", default="1010113")
    parser.add_argument("--output", default="trial.gpx")
    parser.add_argument("--high", type=float, default=100.0)
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    output = os.path.abspath(args.output)
    if os.path.exists(output):
        os.unlink(output)
    project = G2sc.G2Project(newgpx=output)
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["shift factor"] = 0.5

    hist = project.add_powder_histogram(
        "inputs/pattern.csv",
        "instrument.instprm",
        fmthint="comma/tab/semicolon separated",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", args.high)
    # The importer enables an overall sample scale for Bragg-Brentano data.
    # It is exactly degenerate with phase scales in a multiphase fit, so fix it.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 16,
            "refine": True,
            "coeffs": [600.0] + [0.0] * 15,
        }
    })

    wo3_file = args.wo3_id if os.path.exists(args.wo3_id) else cod_path(args.wo3_id)
    wo3_tag = os.path.splitext(os.path.basename(args.wo3_id))[0]
    project.add_phase(
        wo3_file,
        phasename="WO3_" + wo3_tag,
        histograms=[hist],
        fmthint="CIF",
    )
    project.add_phase(
        cod_path(args.bao2_id),
        phasename="BaO2_" + args.bao2_id,
        histograms=[hist],
        fmthint="CIF",
    )

    # Start scales conservatively; absolute values are arbitrary but should be
    # of the order used for raw-count laboratory patterns.
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][0] = 1e-7
        phase.set_HAP_refinements({"Scale": True}, [hist])

    project.save()
    if not run_step(project, "background_scales"):
        return 2
    if not run_step(project, "background_scales_2"):
        return 2

    project.set_Controls("parmMin", -0.5, variable=":0:Zero")
    project.set_Controls("parmMax", 0.5, variable=":0:Zero")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    if not run_step(project, "initial_zero"):
        return 2
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})

    wo3 = project.phase(0)
    bao2 = project.phase(1)
    wo3.set_refinements({"Cell": True})
    for repeat in range(3):
        if not run_step(project, "cell_wo3_" + str(repeat + 1)):
            return 2
    wo3.clear_refinements({"Cell": True})
    bao2.set_refinements({"Cell": True})
    for repeat in range(2):
        if not run_step(project, "cell_bao2_" + str(repeat + 1)):
            return 2
    bao2.clear_refinements({"Cell": True})

    # Peak widths are predominantly sample-dependent in these data, so fit an
    # isotropic crystallite-size term for each phase before touching the
    # instrumental Caglioti terms.
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 0.10, "refine": True},
        }, [hist])
        pfx = f"{phase.id}:0:Size;i"
        project.set_Controls("parmMin", 0.005, variable=pfx)
        project.set_Controls("parmMax", 10.0, variable=pfx)
    if not run_step(project, "size"):
        return 2

    project.set_Controls("parmMin", 0.01, variable=":0:W")
    project.set_Controls("parmMax", 100.0, variable=":0:W")
    hist.set_refinements({"Instrument Parameters": ["W"]})
    if not run_step(project, "profile_W"):
        return 2

    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Mustrain"][1][0] = 100.0
        phase.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True},
        }, [hist])
        pfx = f"{phase.id}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=pfx)
        project.set_Controls("parmMax", 10000.0, variable=pfx)
    if not run_step(project, "microstrain"):
        return 2

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    if not run_step(project, "final_zero"):
        return 2

    project.save()
    summary(project, "final")
    return 0


if __name__ == "__main__":
    sys.exit(main())
