from pathlib import Path
import shutil
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
SOURCE_CIF = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif')
G2sc.SetPrintLevel('warn')


def status(tag, gpx):
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.InstrumentParameters
    print(tag, 'Rwp', hist.residuals.get('wR'), 'Rp', hist.residuals.get('R'),
          'cell', phase.get_cell(),
          'inst', {k: round(inst[k][1], 6) for k in ['Zero', 'U', 'V', 'W', 'X', 'Y', 'SH/L']},
          'PO', phase.getHAPvalues(hist)['Pref.Ori.'])


def refine(gpx, recipe=None, cycles=15):
    gpx.set_Controls('cycles', cycles)
    gpx.do_refinements([recipe or {}])


basefile = ROOT / 'physical_base.gpx'
gpx = G2sc.G2Project(newgpx=str(basefile))
hist = gpx.add_powder_histogram(str(ROOT/'pattern.xye'), str(ROOT/'instrument.instprm'), fmthint='xye')
phase = gpx.add_phase(str(SOURCE_CIF), phasename='MnWO4', histograms=[hist], fmthint='CIF')
hist.set_refinements({'Limits': [10.0, 100.0]})
hist.clear_refinements({'Sample Parameters': ['Scale']})
hist.SampleParameters['Scale'][0] = 1.0
hist.set_refinements({'Background': {
    'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 14,
    'coeffs': [600.0] + [0.0] * 13,
}})
phase.set_HAP_refinements({'Scale': True})
inst = hist.InstrumentParameters
for key, val in {'U': 2.0, 'V': 0.0, 'W': 80.0, 'X': 0.0, 'Y': 0.0, 'SH/L': 0.002}.items():
    inst[key][1] = val

refine(gpx)
status('scale_bg', gpx)
refine(gpx, {'set': {'Cell': True}})
status('cell', gpx)
refine(gpx, {'set': {'Instrument Parameters': ['Zero']}})
status('zero', gpx)
refine(gpx, {'set': {'Instrument Parameters': ['W']}})
status('W', gpx)
gpx.save()

# Profile branches use bounds to avoid non-physical negative broadening terms.
profile_specs = {
    'W': [],
    'UW': ['U'],
    'UWX': ['U', 'X'],
    'UWY': ['U', 'Y'],
    'UWXY': ['U', 'X', 'Y'],
    'UVW': ['U', 'V'],
}
for name, extra in profile_specs.items():
    branch = ROOT / f'profile_{name}.gpx'
    p = G2sc.G2Project(str(basefile), newgpx=str(branch))
    # Existing W and zero flags remain active.
    for var in ['U', 'W', 'X', 'Y']:
        p.set_Controls('parmMin', 0.0 if var != 'W' else 0.1, variable=f':0:{var}')
        p.set_Controls('parmMax', 1000.0 if var in ['U','W'] else 200.0, variable=f':0:{var}')
    p.set_Controls('parmMin', -1000.0, variable=':0:V')
    p.set_Controls('parmMax', 1000.0, variable=':0:V')
    if extra:
        refine(p, {'set': {'Instrument Parameters': extra}}, cycles=20)
    else:
        refine(p, cycles=20)
    p.save()
    status('PROFILE_'+name, p)

# Test simple March-Dollase axes from the best physical profile branch.
profbase = ROOT / 'profile_UWXY.gpx'
directions = [(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1),(1,1,-1),(1,2,0),(2,1,0)]
for hkl in directions:
    tag = ''.join('m'+str(abs(v)) if v < 0 else str(v) for v in hkl)
    branch = ROOT / f'po_{tag}.gpx'
    p = G2sc.G2Project(str(profbase), newgpx=str(branch))
    ph = p.phase(0); h = p.histogram(0)
    po = ph.getHAPvalues(h)['Pref.Ori.']
    po[0] = 'MD'; po[1] = 1.0; po[2] = True; po[3] = list(hkl)
    p.set_Controls('parmMin', 0.2, variable='0:0:MD')
    p.set_Controls('parmMax', 5.0, variable='0:0:MD')
    refine(p, cycles=20)
    p.save()
    status('PO_'+tag, p)
