from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'profile_UWX.gpx'
G2sc.SetPrintLevel('warn')


def quiet_model(g):
    h = g.histogram(0); p = g.phase(0)
    h.clear_refinements({'Background': False})
    h.clear_refinements({'Instrument Parameters': ['Zero','U','V','W','X','Y','Z','SH/L']})
    p.clear_refinements({'Cell': False, 'Atoms': [a.label for a in p.atoms()]})
    p.set_HAP_refinements({'Scale': True})
    # Clear parameters that were frozen at bounds in exploratory profile fits.
    g.data['Controls']['data']['parmFrozen'] = {}


def isotropic_adps(p, value):
    for atom in p.atoms():
        atom.data[atom.cia] = 'I'
        atom.data[atom.cia + 1] = float(value)
        atom.refinement_flags = ''


def run(g, cycles=12):
    g.set_Controls('cycles', cycles)
    g.do_refinements([{}])


def show(tag, g):
    h=g.histogram(0);p=g.phase(0)
    print(tag, 'Rwp', h.residuals.get('wR'), 'Rp', h.residuals.get('R'),
          'scale', p.getHAPvalues(h)['Scale'][0],
          'ADP', [(a.label,a.adp_flag,a.ADP) for a in p.atoms()],
          'xyz', [(a.label,a.coordinates) for a in p.atoms()],
          'PO',p.getHAPvalues(h)['Pref.Ori.'])


# Fixed, common Uiso scan to avoid over-parameterizing displacement factors.
for u in [0.0,0.001,0.002,0.003,0.004,0.005,0.006,0.008,0.010]:
    out=ROOT/f'adp_{u:.3f}.gpx'
    g=G2sc.G2Project(str(BASE),newgpx=str(out)); quiet_model(g); isotropic_adps(g.phase(0),u)
    run(g);g.save();show(f'ADP_{u:.3f}',g)

ADPBASE=ROOT/'adp_0.001.gpx'

# Coordinate refinements: cations first, then all sites.
for name, atoms in [('cat',['Mn1','W1']),('all',['Mn1','W1','O1','O2'])]:
    out=ROOT/f'coords_{name}.gpx'
    g=G2sc.G2Project(str(ADPBASE),newgpx=str(out));quiet_model(g)
    p=g.phase(0)
    p.set_refinements({'Atoms':{a:'X' for a in atoms}})
    run(g,20);g.save();show('COORD_'+name,g)

# Let four isotropic ADPs refine independently as a diagnostic.
out=ROOT/'adp_refined.gpx'
g=G2sc.G2Project(str(ADPBASE),newgpx=str(out));quiet_model(g)
g.phase(0).set_refinements({'Atoms':{'all':'U'}})
run(g,20);g.save();show('ADP_REFINED',g)

# Preferred orientation tests with all other shape/structure variables fixed.
directions=[(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1),(1,1,-1),(1,2,0),(2,1,0),(0,1,2),(1,0,2)]
for hkl in directions:
    tag=''.join('m'+str(abs(v)) if v<0 else str(v) for v in hkl)
    out=ROOT/f'po_clean_{tag}.gpx'
    g=G2sc.G2Project(str(ADPBASE),newgpx=str(out));quiet_model(g)
    p=g.phase(0);h=g.histogram(0);po=p.getHAPvalues(h)['Pref.Ori.']
    po[0]='MD';po[1]=1.0;po[2]=True;po[3]=list(hkl)
    run(g,20);g.save();show('PO_'+tag,g)
