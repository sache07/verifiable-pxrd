from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
G2sc.SetPrintLevel('all')

gpx = G2sc.G2Project(newgpx=str(ROOT / 'test_one_phase.gpx'))
hist = gpx.add_powder_histogram(
    str(ROOT / 'pattern.xye'),
    str(ROOT / 'instrument.instprm'),
    fmthint='xye',
)
phase = gpx.add_phase(
    '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif',
    phasename='MnWO4', histograms=[hist], fmthint='CIF')

hist.set_refinements({'Limits': [10.0, 100.0]})
hist.set_refinements({'Background': {
    'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 12,
    'coeffs': [600.0] + [0.0] * 11,
}})
phase.set_HAP_refinements({'Scale': True})
gpx.set_Controls('cycles', 8)

steps = [
    ('scale_background', {}),
    ('cell', {'set': {'Cell': True}}),
    ('zero', {'set': {'Instrument Parameters': ['Zero']}}),
    ('W', {'set': {'Instrument Parameters': ['W']}}),
    ('UV', {'set': {'Instrument Parameters': ['U', 'V']}}),
    ('XY', {'set': {'Instrument Parameters': ['X', 'Y']}}),
]
for label, recipe in steps:
    try:
        gpx.do_refinements([recipe])
    except Exception as exc:
        print('STEP_FAIL', label, repr(exc))
        raise
    print('STEP', label, hist.residuals)
    print('CELL', phase.get_cell_and_esd())
    print('INST', {k:v for k,v in hist.InstrumentParameters.items() if k in ['Lam1','Lam2','I(L2)/I(L1)','Zero','U','V','W','X','Y','Z','SH/L']})

gpx.save()
print('FINAL', hist.residuals)
print('HAP', phase.getHAPvalues(hist))
print('COVVARY', gpx.data['Covariance']['data'].get('varyList'))
print('COVSIG', gpx.data['Covariance']['data'].get('sig'))
