#!/usr/bin/env python3
"""Build and incrementally refine a two-phase GSAS-II powder model."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def report(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(f"\n--- {label} ---")
    print("wR(hist):", hist.get_wR())
    print("Rvals:", rvals)
    print("instrument:", {k: v[:2] for k, v in hist.InstrumentParameters.items()})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            phase.name,
            "cell=", phase.get_cell(),
            "scale=", hap["Scale"],
            "size=", hap["Size"],
            "mustrain=", hap["Mustrain"],
            "PO=", hap["Pref.Ori."],
        )
    try:
        print("mass fractions:", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fractions unavailable:", repr(exc))


def refine(project: G2sc.G2Project, refs: dict, label: str) -> None:
    project.do_refinements([refs])
    report(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=str(ROOT / ".tmp" / "trial.gpx"))
    parser.add_argument("--wo3", default=str(ROOT / "wo3_monoclinic_start.cif"))
    parser.add_argument(
        "--profile-only",
        action="store_true",
        help="stop after the global pseudo-Voigt profile refinement",
    )
    args = parser.parse_args()

    project = G2sc.G2Project(newgpx=str(Path(args.out).resolve()))
    project.set_Controls("cycles", 8)
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "laboratory_cuka.instprm"),
        fmthint="comma",
    )
    niwo4 = project.add_phase(
        str(ROOT / "niwo4_start.cif"), histograms=[hist], fmthint="CIF"
    )
    wo3 = project.add_phase(str(Path(args.wo3).resolve()), histograms=[hist], fmthint="CIF")

    # A realistic starting width prevents the first least-squares step from
    # trying to fit narrow spikes to visibly broadened laboratory peaks.
    inst = hist.InstrumentParameters
    inst["U"][1] = 20.0
    inst["V"][1] = 0.0
    inst["W"][1] = 45.0
    inst["X"][1] = 0.0
    inst["Y"][1] = 0.0
    hist.SampleParameters["Scale"][1] = False

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 12,
                "coeffs": [1000.0] + [0.0] * 11,
            }
        }
    )
    niwo4.HAPvalue("Scale", 0.1)
    wo3.HAPvalue("Scale", 0.03)
    refine(project, {"set": {"Scale": True}}, "background + phase scales")
    refine(project, {"set": {"Cell": True}}, "cells")
    refine(project, {"set": {"Instrument Parameters": ["Zero"]}}, "zero")
    refine(
        project,
        {"set": {"Instrument Parameters": ["U", "V", "W"]}},
        "Gaussian profile",
    )
    refine(
        project,
        {"set": {"Instrument Parameters": ["X", "Y"]}},
        "pseudo-Voigt profile",
    )
    if args.profile_only:
        project.save()
        return
    refine(
        project,
        {
            "set": {
                "Size": {"type": "isotropic", "refine": True, "value": 1.0}
            }
        },
        "phase sizes",
    )
    refine(
        project,
        {
            "set": {
                "Mustrain": {"type": "isotropic", "refine": True}
            }
        },
        "phase microstrain",
    )
    project.save()


if __name__ == "__main__":
    main()
