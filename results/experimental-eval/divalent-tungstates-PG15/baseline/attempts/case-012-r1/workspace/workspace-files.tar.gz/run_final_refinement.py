#!/usr/bin/env python3
"""Produce the final two-phase GSAS-II Rietveld refinement and exports."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
WO3_SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/10/62/2106293.cif"
)


def refine(project: G2sc.G2Project, change: dict | None = None) -> None:
    project.do_refinements([change or {}])


def main() -> None:
    build_gpx = ROOT / ".tmp" / "final_build.gpx"
    project = G2sc.G2Project(newgpx=str(build_gpx))
    project.set_Controls("cycles", 12)

    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "laboratory_cuka.instprm"),
        fmthint="comma",
    )
    niwo4 = project.add_phase(
        str(ROOT / "niwo4_start.cif"),
        phasename="NiWO4 (wolframite)",
        histograms=[hist],
        fmthint="CIF",
    )
    wo3 = project.add_phase(
        str(WO3_SOURCE),
        phasename="WO3 (triclinic)",
        histograms=[hist],
        fmthint="CIF",
    )

    # The COD WO3 record has placeholder zero displacement factors. Use
    # conservative, fixed room-temperature Uiso values; refining phase-specific
    # Uiso values is strongly correlated with the quantitative phase scales.
    for atom in wo3.atoms():
        atom.uiso = 0.004 if atom.element == "W" else 0.008

    inst = hist.InstrumentParameters
    inst["U"][1] = 20.0
    inst["V"][1] = 0.0
    inst["W"][1] = 45.0
    inst["X"][1] = 0.0
    inst["Y"][1] = 0.0
    hist.SampleParameters["Scale"][1] = False
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 12,
                "coeffs": [1000.0] + [0.0] * 11,
            }
        }
    )

    niwo4.HAPvalue("Scale", 0.1)
    wo3.HAPvalue("Scale", 0.03)
    refine(project, {"set": {"Scale": True}})
    refine(project, {"set": {"Cell": True}})
    refine(project, {"set": {"Instrument Parameters": ["Zero"]}})
    refine(project, {"set": {"Instrument Parameters": ["U", "V", "W"]}})
    refine(project, {"set": {"Instrument Parameters": ["X", "Y"]}})

    # Only the two symmetry-restricted heavy-atom y coordinates in NiWO4 are
    # refined. Oxygen coordinates and all WO3 coordinates remain at their
    # reference values because laboratory X-ray data do not determine them
    # robustly in this W-rich mixture.
    niwo4.set_refinements({"Atoms": {"Ni1": "X", "W1": "X"}})
    refine(project)

    # Effective polarization was not supplied in metadata, so determine it
    # from the pattern. Keep the reported K-alpha doublet wavelengths/ratio.
    refine(project, {"set": {"Instrument Parameters": ["Polariz."]}})

    # A small but statistically supported texture correction for the dominant
    # phase; scans of low-index axes selected [111].
    po = niwo4.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = [1, 1, 1]
    refine(project)

    # Repeat the complete active model until the saved covariance corresponds
    # to a settled minimum.
    refine(project)
    refine(project)

    # GSAS-II's automatic Z estimate uses site multiplicities and gives Z=2
    # for this P-1 structure; the 8 W and 24 O atoms in the unit cell require
    # Z=8 for the reduced WO3 formula.
    wo3.data["General"]["cellZ"] = 8
    project.save(str(ROOT / "final.gpx"))
    niwo4.export_CIF(str(ROOT / "phase_NiWO4.cif"))
    wo3.export_CIF(str(ROOT / "phase_WO3_triclinic.cif"))

    x = np.asarray(hist.getdata("x"), dtype=float)
    yobs = np.asarray(hist.getdata("yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("ycalc"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    difference = np.asarray(hist.getdata("residual"), dtype=float)
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, yobs, ycalc, difference, background)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference_obs_minus_calc,background",
        comments="",
        fmt=["%.8f", "%.12g", "%.12g", "%.12g", "%.12g"],
    )

    rvals = project.data["Covariance"]["data"]["Rvals"]
    mass = hist.ComputeMassFracs()
    summary = {
        "Rwp_percent": float(rvals["Rwp"]),
        "GOF": float(rvals["GOF"]),
        "reduced_chi_square": float(rvals["GOF"] ** 2),
        "chi_square": float(rvals["chisq"]),
        "Nobs": int(rvals["Nobs"]),
        "Nvars": int(rvals["Nvars"]),
        "converged": bool(rvals["converged"]),
        "SVD_zero_count": int(rvals["SVD0"]),
        "max_shift_over_esd": float(rvals["Max shft/sig"]),
        "mass_fractions": mass,
        "NiWO4_cell": niwo4.get_cell_and_esd(),
        "WO3_cell": wo3.get_cell_and_esd(),
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "March_Dollase_NiWO4_111": float(po[1]),
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
