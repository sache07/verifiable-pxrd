from pathlib import Path
import shutil
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"


def stats(gpx, label):
    h = gpx.histogram(0)
    p = gpx.phase(0)
    cov = gpx.data.get("Covariance", {}).get("data", {})
    print("\nMODEL", label)
    print("wR", h.get_wR(), "residuals", h.data["data"][0])
    print("cell", p.get_cell_and_esd())
    print("sample", h.data["Sample Parameters"])
    print("inst", {k: h.data["Instrument Parameters"][0][k] for k in ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
    print("hap", p.data["Histograms"][h.name])
    print("atoms", [(a.label, a.coordinates, a.uiso, a.refinement_flags) for a in p.atoms()])
    print("vary", cov.get("varyList"))
    print("Rvals", cov.get("Rvals"))


def clean_model():
    src = TMP / "one_phase.gpx"
    dst = TMP / "clean_zero.gpx"
    if dst.exists():
        dst.unlink()
    gpx = G2sc.G2Project(str(src), newgpx=str(dst))
    h = gpx.histogram(0)
    p = gpx.phase(0)
    inst = h.data["Instrument Parameters"][0]
    sample = h.data["Sample Parameters"]
    hap = p.data["Histograms"][h.name]

    # Remove the exact duplicate between histogram and phase scales.
    old_sample_scale = float(sample["Scale"][0])
    hap["Scale"][0] *= old_sample_scale
    sample["Scale"] = [1.0, False]

    # Transfer sample Lorentzian size/strain terms into the empirical
    # instrumental X/Y terms. With no calibrated standard these terms are
    # exactly non-identifiable for a single phase.
    size = float(hap["Size"][1][0])
    strain = float(hap["Mustrain"][1][0])
    wave = float(inst["Lam1"][1])
    inst["X"][1] += 1.8 * wave / (np.pi * size)
    inst["Y"][1] += 0.018 * strain / np.pi
    hap["Size"][1][0] = 1.0e6
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])

    gpx.set_Controls("cycles", 15)
    gpx.refine(printFile=str(TMP / "clean_zero.lst"))
    gpx.save(str(dst))
    stats(gpx, "clean_zero")
    return dst


def uiso_test(src):
    dst = TMP / "clean_zero_uiso.gpx"
    if dst.exists():
        dst.unlink()
    gpx = G2sc.G2Project(str(src), newgpx=str(dst))
    p = gpx.phase(0)
    p.set_refinements({"Atoms": {"all": "XU"}})
    # Keep isotropic displacement parameters in a physically meaningful range.
    for i in range(len(p.atoms())):
        gpx.set_Controls("parmMin", 0.0001, variable=f"0::AUiso:{i}")
        gpx.set_Controls("parmMax", 0.08, variable=f"0::AUiso:{i}")
    gpx.refine(printFile=str(TMP / "clean_zero_uiso.lst"))
    gpx.save(str(dst))
    stats(gpx, "clean_zero_uiso")
    return dst


def shift_test(src):
    dst = TMP / "clean_shift.gpx"
    if dst.exists():
        dst.unlink()
    gpx = G2sc.G2Project(str(src), newgpx=str(dst))
    h = gpx.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    sample = h.data["Sample Parameters"]
    zero = float(inst["Zero"][1])
    radius = float(sample["Gonio. radius"])
    # Convert the prior constant offset to an equivalent initial BB height shift.
    sample["Shift"] = [-zero * np.pi * radius / (0.36), True]
    inst["Zero"] = [inst["Zero"][0], 0.0, False]
    gpx.refine(printFile=str(TMP / "clean_shift.lst"))
    gpx.save(str(dst))
    stats(gpx, "clean_shift")
    return dst


if __name__ == "__main__":
    clean = clean_model()
    uiso_test(clean)
    shift_test(clean)
