from pathlib import Path
import copy
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

CANDIDATES = {
    "hex_1004057": DB / "1/00/40/1004057.cif",
    "old_triclinic_1010618": DB / "1/01/06/1010618.cif",
    "tetragonal_1521532": DB / "1/52/15/1521532.cif",
    "tetragonal_1521533": DB / "1/52/15/1521533.cif",
    "monoclinic_1528915": DB / "1/52/89/1528915.cif",
    "monoclinic_HP_1563541": DB / "1/56/35/1563541.cif",
    "monoclinic_2311041": DB / "2/31/10/2311041.cif",
    "triclinic_2106293": DB / "2/10/62/2106293.cif",
    "orthorhombic_2107312": DB / "2/10/73/2107312.cif",
}


def test(name, cif):
    dst = TMP / f"wo3_{name}.gpx"
    if dst.exists():
        dst.unlink()
    gpx = G2sc.G2Project(str(TMP / "clean_zero.gpx"), newgpx=str(dst))
    h = gpx.histogram(0)
    main = gpx.phase(0)
    phase = gpx.add_phase(str(cif), phasename="WO3", histograms=[h], fmthint="CIF")
    mh = main.data["Histograms"][h.name]
    ph = phase.data["Histograms"][h.name]
    ph["Size"] = copy.deepcopy(mh["Size"])
    ph["Mustrain"] = copy.deepcopy(mh["Mustrain"])
    ph["HStrain"] = copy.deepcopy(mh["HStrain"])
    ph["Scale"][0] = mh["Scale"][0] * (0.02 / 0.98) * (main.data["General"]["Mass"] / phase.data["General"]["Mass"])
    ph["Scale"][1] = True
    # Hold axial divergence at the established one-phase value for a fair comparison.
    h.clear_refinements({"Instrument Parameters": ["SH/L"]})
    gpx.set_Controls("cycles", 12)
    try:
        gpx.refine(printFile=str(TMP / f"wo3_{name}.lst"))
        rv = gpx.data["Covariance"]["data"].get("Rvals", {})
        result = {
            "model": name,
            "Rwp_percent": h.get_wR(),
            "GOF": rv.get("GOF"),
            "converged": rv.get("converged"),
            "max_shift_over_esd": rv.get("Max shft/sig"),
            "fractions": h.ComputeMassFracs(),
            "cell": phase.get_cell(),
        }
    except Exception as exc:
        result = {"model": name, "error": repr(exc)}
    print(json.dumps(result, indent=2, default=float))
    return result


if __name__ == "__main__":
    results = [test(name, cif) for name, cif in CANDIDATES.items()]
    with open(TMP / "wo3_polymorph_tests.json", "w") as fp:
        json.dump(results, fp, indent=2, default=float)
