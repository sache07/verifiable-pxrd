from pathlib import Path
import copy
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = {
    "MnO": DB / "1/51/42/1514231.cif",
    "Mn2O3": DB / "1/51/42/1514230.cif",
    "Mn3O4": DB / "9/00/19/9001963.cif",
    "Mn3WO6": DB / "2/00/27/2002703.cif",
}


def test(name, cif):
    dst = TMP / f"third_{name}.gpx"
    if dst.exists():
        dst.unlink()
    gpx = G2sc.G2Project(str(TMP / "two_phase_stable.gpx"), newgpx=str(dst))
    h = gpx.histogram(0)
    main = gpx.phase("MnWO4")
    cand = gpx.add_phase(str(cif), phasename=name, histograms=[h], fmthint="CIF")
    mh = main.data["Histograms"][h.name]
    ch = cand.data["Histograms"][h.name]
    for key in ["Size", "Mustrain", "HStrain"]:
        ch[key] = copy.deepcopy(mh[key])
    # Initialize at 0.3 wt%.
    ch["Scale"][0] = mh["Scale"][0] * (0.003 / 0.997) * (main.data["General"]["Mass"] / cand.data["General"]["Mass"])
    ch["Scale"][1] = True
    gpx.set_Controls("cycles", 15)
    try:
        gpx.refine(printFile=str(TMP / f"third_{name}.lst"))
        rv = gpx.data["Covariance"]["data"].get("Rvals", {})
        out = {
            "candidate": name,
            "Rwp_percent": h.get_wR(),
            "GOF": rv.get("GOF"),
            "converged": rv.get("converged"),
            "max_shift_over_esd": rv.get("Max shft/sig"),
            "fractions": h.ComputeMassFracs(),
        }
    except Exception as exc:
        out = {"candidate": name, "error": repr(exc)}
    print(json.dumps(out, indent=2, default=float))
    return out


if __name__ == "__main__":
    results = [test(name, cif) for name, cif in CANDIDATES.items()]
    with open(TMP / "third_phase_tests.json", "w") as fp:
        json.dump(results, fp, indent=2, default=float)
