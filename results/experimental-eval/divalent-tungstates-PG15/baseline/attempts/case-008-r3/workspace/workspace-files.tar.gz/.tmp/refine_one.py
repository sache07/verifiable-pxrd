from pathlib import Path
import json
import numpy as np
import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / ".tmp"
GPX = WORK / "one_phase.gpx"


def snapshot(gpx, label):
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    hap = phase.data["Histograms"][hist.name]
    print("\nSNAPSHOT", label)
    print("residuals", hist.data["data"][0])
    print("wR", hist.get_wR())
    print("cell", phase.get_cell())
    print("inst", {k: v for k, v in inst.items() if k in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"]})
    print("scale", hap["Scale"])
    print("size", hap["Size"])
    print("mustrain", hap["Mustrain"])
    print("atoms", [(a.label, a.element, a.coordinates, a.uiso if a.adp_flag == "I" else a.ADP, a.refinement_flags) for a in phase.atoms()])


def main():
    if GPX.exists():
        GPX.unlink()
    gpx = G2sc.G2Project(newgpx=str(GPX))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(WORK / "cu_kalpha.instprm"),
        fmthint="comma",
    )
    phase = gpx.add_phase(
        str(WORK / "mnwo4_start.cif"),
        phasename="MnWO4",
        histograms=[hist],
        fmthint="CIF",
    )
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 18,
        },
    })
    phase.set_HAP_refinements({"Scale": True}, [hist])
    gpx.set_Controls("cycles", 12)
    snapshot(gpx, "initial")

    # Fit the intensity scale and smooth background before moving peaks.
    gpx.refine(printFile=str(WORK / "stage1.lst"))
    snapshot(gpx, "scale_background")

    # Refine the specimen zero offset and monoclinic metric together.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    phase.set_refinements({"Cell": True})
    gpx.refine(printFile=str(WORK / "stage2.lst"))
    snapshot(gpx, "cell_zero")

    # Fit the global instrumental profile.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]})
    gpx.refine(printFile=str(WORK / "stage3.lst"))
    snapshot(gpx, "profile")

    # Test isotropic crystallite-size and microstrain broadening.
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True, "value": 1.0},
        "Mustrain": {"type": "isotropic", "refine": True},
    }, [hist])
    gpx.refine(printFile=str(WORK / "stage4.lst"))
    snapshot(gpx, "sample_broadening")

    # Refine symmetry-allowed coordinates; keep occupancies fixed.
    phase.set_refinements({"Atoms": {"all": "X"}})
    gpx.refine(printFile=str(WORK / "stage5.lst"))
    snapshot(gpx, "coordinates")

    gpx.save(str(GPX))
    x = np.asarray(hist.getdata("X"))
    out = np.column_stack([
        x,
        np.asarray(hist.getdata("Yobs")),
        np.asarray(hist.getdata("Ycalc")),
        np.asarray(hist.getdata("Background")),
        np.asarray(hist.getdata("Residual")),
    ])
    np.savetxt(WORK / "one_profile.csv", out, delimiter=",", header="two_theta_deg,observed,calculated,background,difference", comments="")


if __name__ == "__main__":
    main()
