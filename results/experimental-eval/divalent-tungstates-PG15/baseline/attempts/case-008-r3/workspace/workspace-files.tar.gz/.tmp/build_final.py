from pathlib import Path
import csv
import json
import math
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / ".tmp" / "two_phase_stable.gpx"
FINAL = ROOT / "final.gpx"


def main():
    if FINAL.exists():
        FINAL.unlink()
    gpx = G2sc.G2Project(str(SRC), newgpx=str(FINAL))
    hist = gpx.histogram(0)
    mnwo4 = gpx.phase("MnWO4")
    wo3 = gpx.phase("WO3")

    # Use the complete supplied angular range.
    x_all = np.asarray(hist.getdata("X"), dtype=float)
    hist.set_refinements({"Limits": [float(x_all[0]), float(x_all[-1])]})

    # Explicitly retain a non-redundant final parameterization.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.clear_refinements({"Instrument Parameters": ["SH/L", "I(L2)/I(L1)"]})
    hist.set_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y"]})
    mnwo4.set_refinements({"Cell": True, "Atoms": {"all": "X"}})
    wo3.clear_refinements({"Cell": True, "Atoms": [a.label for a in wo3.atoms()]})
    for phase in (mnwo4, wo3):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])

    gpx.set_Controls("cycles", 20)
    for cycle in range(3):
        gpx.refine(printFile=str(ROOT / ".tmp" / f"final_refine_{cycle}.lst"))
        rvals = gpx.data["Covariance"]["data"].get("Rvals", {})
        if rvals.get("converged") and rvals.get("Max shft/sig", 999.0) < 1.0:
            break
    gpx.save(str(FINAL))

    # Reload to guarantee that every exported artifact is sourced from the
    # exact project bytes submitted as final.gpx.
    gpx = G2sc.G2Project(str(FINAL))
    hist = gpx.histogram(0)
    mnwo4 = gpx.phase("MnWO4")
    wo3 = gpx.phase("WO3")
    mnwo4.export_CIF(str(ROOT / "phase_MnWO4.cif"))
    wo3.export_CIF(str(ROOT / "phase_WO3.cif"))

    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    bkg = np.asarray(hist.getdata("Background"), dtype=float)
    diff = np.asarray(hist.getdata("Residual"), dtype=float)
    with open(ROOT / "fit.csv", "w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
        for row in zip(x, yobs, ycalc, diff, bkg):
            writer.writerow([f"{row[0]:.8f}", f"{row[1]:.8f}", f"{row[2]:.8f}", f"{row[3]:.8f}", f"{row[4]:.8f}"])

    fractions = hist.ComputeMassFracs()
    residuals = hist.data["data"][0]
    covariance = gpx.data["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    phase_rows = []
    for phase, label, cif_name in [
        (mnwo4, "MnWO4 (wolframite)", "phase_MnWO4.cif"),
        (wo3, "WO3 (ambient monoclinic)", "phase_WO3.cif"),
    ]:
        frac, esd = fractions[phase.name]
        phase_rows.append({
            "name": label,
            "formula": "MnWO4" if phase.name == "MnWO4" else "WO3",
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": cif_name,
            "weight_fraction": frac,
            "weight_fraction_esd": esd,
        })

    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "Rp_percent": residuals.get("R"),
            "Rwp_percent": residuals.get("wR"),
            "Rexp_percent": residuals.get("wRmin"),
            "goodness_of_fit": rvals.get("GOF"),
            "chi_squared": rvals.get("chisq"),
            "durbin_watson": residuals.get("Durbin-Watson"),
            "n_observations": rvals.get("Nobs"),
            "n_refined_parameters": rvals.get("Nvars"),
            "converged": bool(rvals.get("converged")),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
            "weighting": "Poisson counting weights (1/I), because pointwise uncertainties were not supplied",
        },
        "profile_path": "fit.csv",
        "gsasii_project_path": "final.gpx",
    }
    with open(ROOT / "result.json", "w") as fp:
        json.dump(result, fp, indent=2)
        fp.write("\n")

    print(json.dumps(result, indent=2))
    print("MnWO4 cell", mnwo4.get_cell_and_esd())
    print("WO3 cell", wo3.get_cell_and_esd())
    print("instrument", hist.data["Instrument Parameters"][0])
    print("sample", hist.data["Sample Parameters"])
    print("Rvals", rvals)


if __name__ == "__main__":
    main()
