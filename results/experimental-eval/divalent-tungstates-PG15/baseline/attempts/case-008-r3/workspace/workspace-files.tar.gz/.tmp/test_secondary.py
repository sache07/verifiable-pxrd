from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

CANDIDATES = {
    "MnO": DB / "1/51/42/1514231.cif",
    "Mn3O4": DB / "9/00/19/9001963.cif",
    "Mn2O3": DB / "1/51/42/1514230.cif",
    "WO3": DB / "1/52/89/1528915.cif",
    "Mn3WO6": DB / "2/00/27/2002703.cif",
}


def run_candidate(name, cif):
    dst = TMP / f"test_{name}.gpx"
    if dst.exists():
        dst.unlink()
    gpx = G2sc.G2Project(str(TMP / "clean_zero.gpx"), newgpx=str(dst))
    h = gpx.histogram(0)
    main = gpx.phase(0)
    cand = gpx.add_phase(str(cif), phasename=name, histograms=[h], fmthint="CIF")
    main_hap = main.data["Histograms"][h.name]
    cand_hap = cand.data["Histograms"][h.name]
    # Initialize at approximately one weight percent.
    mass_main = float(main.data["General"]["Mass"])
    mass_cand = float(cand.data["General"]["Mass"])
    cand_hap["Scale"][0] = main_hap["Scale"][0] * (0.01 / 0.99) * (mass_main / mass_cand)
    cand_hap["Scale"][1] = True
    # Keep the database cell/coordinates fixed for this diagnostic. A phase
    # present at useful abundance will still be selected by its full peak set.
    gpx.set_Controls("cycles", 15)
    try:
        gpx.refine(printFile=str(TMP / f"test_{name}.lst"))
        gpx.save(str(dst))
        fractions = h.ComputeMassFracs()
        cov = gpx.data["Covariance"]["data"]
        result = {
            "candidate": name,
            "Rwp_percent": h.get_wR(),
            "GOF": cov.get("Rvals", {}).get("GOF"),
            "candidate_scale": cand.data["Histograms"][h.name]["Scale"][0],
            "fractions": fractions,
            "converged": cov.get("Rvals", {}).get("converged"),
            "SVD0": cov.get("Rvals", {}).get("SVD0"),
        }
    except Exception as exc:
        result = {"candidate": name, "error": repr(exc)}
    print(json.dumps(result, indent=2, default=float))
    return result


if __name__ == "__main__":
    results = [run_candidate(name, cif) for name, cif in CANDIDATES.items()]
    with open(TMP / "secondary_tests.json", "w") as fp:
        json.dump(results, fp, indent=2, default=float)
