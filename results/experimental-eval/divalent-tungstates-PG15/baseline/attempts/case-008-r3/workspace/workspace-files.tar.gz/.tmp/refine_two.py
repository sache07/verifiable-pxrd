from pathlib import Path
import copy
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
WO3_CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif")


def summarize(gpx, tag):
    h = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    print("\n", tag)
    print("residuals", h.data["data"][0])
    print("Rvals", cov.get("Rvals"))
    print("fractions", h.ComputeMassFracs())
    for p in gpx.phases():
        print(p.name, p.get_cell_and_esd())
        print("HAP", p.data["Histograms"][h.name])
        print("atoms", [(a.label, a.element, a.coordinates, a.uiso if a.adp_flag == "I" else a.ADP, a.refinement_flags) for a in p.atoms()])


def main():
    dst = TMP / "two_phase.gpx"
    if dst.exists():
        dst.unlink()
    gpx = G2sc.G2Project(str(TMP / "clean_zero.gpx"), newgpx=str(dst))
    h = gpx.histogram(0)
    main = gpx.phase(0)
    wo3 = gpx.add_phase(str(WO3_CIF), phasename="WO3", histograms=[h], fmthint="CIF")
    mhap = main.data["Histograms"][h.name]
    whap = wo3.data["Histograms"][h.name]
    # Initialize at 2 wt% and force the same (fixed) sample broadening model.
    mass_main = float(main.data["General"]["Mass"])
    mass_wo3 = float(wo3.data["General"]["Mass"])
    whap["Scale"][0] = mhap["Scale"][0] * (0.02 / 0.98) * (mass_main / mass_wo3)
    whap["Scale"][1] = True
    whap["Size"] = copy.deepcopy(mhap["Size"])
    whap["Mustrain"] = copy.deepcopy(mhap["Mustrain"])
    whap["HStrain"] = copy.deepcopy(mhap["HStrain"])
    gpx.set_Controls("cycles", 15)

    # Establish the minor-phase scale with the database metric fixed.
    gpx.refine(printFile=str(TMP / "two_scale.lst"))
    summarize(gpx, "scale only")

    # Refine the WO3 metric, but not its coordinates/ADPs at this abundance.
    wo3.set_refinements({"Cell": True})
    gpx.refine(printFile=str(TMP / "two_cell.lst"))
    summarize(gpx, "WO3 cell")
    gpx.save(str(dst))

    out = np.column_stack([
        np.asarray(h.getdata("X")),
        np.asarray(h.getdata("Yobs")),
        np.asarray(h.getdata("Ycalc")),
        np.asarray(h.getdata("Background")),
        np.asarray(h.getdata("Residual")),
    ])
    np.savetxt(TMP / "two_profile.csv", out, delimiter=",", header="two_theta_deg,observed,calculated,background,difference", comments="")


if __name__ == "__main__":
    main()
