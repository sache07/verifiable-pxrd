import argparse
import json
import os
import traceback

from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
COD = '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif'


def cif_path(cod_id):
    return os.path.join(COD, cod_id[0], cod_id[1:3], cod_id[3:5], cod_id + '.cif')


def snapshot(gpx, label):
    hist = gpx.histogram(0)
    vals = {
        'step': label,
        'residuals': hist.residuals,
        'shift': hist.SampleParameters.get('Shift'),
        'instrument': {k: v for k, v in hist.InstrumentParameters.items()
                       if k in ('U', 'V', 'W', 'X', 'Y', 'SH/L', 'Zero')},
        'phases': {},
    }
    for phase in gpx.phases():
        hap = phase.data['Histograms'][hist.name]
        vals['phases'][phase.name] = {
            'cell': phase.get_cell(),
            'scale': hap['Scale'],
            'size': hap['Size'][:3],
            'mustrain': hap['Mustrain'][:3],
        }
    print('SNAPSHOT ' + json.dumps(vals, default=float), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('wo3_id')
    parser.add_argument('outfile')
    args = parser.parse_args()

    outfile = os.path.abspath(args.outfile)
    gpx = G2sc.G2Project(newgpx=outfile)
    hist = gpx.add_powder_histogram(
        os.path.join(ROOT, 'inputs', 'pattern.csv'),
        os.path.join(ROOT, 'instrument.instprm'),
        fmthint='comma')
    hist.SampleParameters['Scale'][1] = False
    hist.SampleParameters['Shift'][0] = -600.0
    hist.set_refinements({'Background': {
        'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 8,
    }})

    phase_defs = [('MgWO4', '9013902'), ('WO3', args.wo3_id), ('MgO', '9000499')]
    phases = []
    for name, cod_id in phase_defs:
        phase = gpx.add_phase(cif_path(cod_id), phasename=name,
                              histograms=[hist], fmthint='CIF')
        phase.set_HAP_refinements({'Scale': True})
        phases.append(phase)

    gpx.set_Controls('cycles', 8)
    gpx.save()

    for label, setup in [
        ('scale_background', lambda: None),
        ('cell_shift', lambda: (
            [p.set_refinements({'Cell': True}) for p in phases],
            hist.set_refinements({'Sample Parameters': ['Shift']}))),
        ('profile', lambda: hist.set_refinements({
            'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})),
        ('size', lambda: [p.set_HAP_refinements({
            'Size': {'type': 'isotropic', 'refine': True, 'value': 1.0}
        }) for p in phases]),
    ]:
        setup()
        try:
            gpx.refine(makeBack=False)
        except Exception:
            traceback.print_exc()
            snapshot(gpx, label + '_FAILED')
            gpx.save()
            return 2
        snapshot(gpx, label)
    gpx.save()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
