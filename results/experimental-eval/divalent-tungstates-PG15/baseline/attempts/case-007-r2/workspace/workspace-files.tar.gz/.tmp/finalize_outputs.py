import csv
import json
import math
import os

from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
SOURCE_GPX = os.path.join(ROOT, '.tmp', 'trials', 'model_all.gpx')
FINAL_GPX = os.path.join(ROOT, 'final.gpx')


project = G2sc.G2Project(SOURCE_GPX, newgpx=FINAL_GPX)
project.save()
hist = project.histogram(0)

cif_names = {
    'MgWO4': 'MgWO4.cif',
    'WO3': 'WO3.cif',
    'MgO': 'MgO.cif',
}
formulae = {
    'MgWO4': 'MgWO4',
    'WO3': 'WO3',
    'MgO': 'MgO',
}
common_names = {
    'MgWO4': 'magnesium tungstate',
    'WO3': 'tungsten(VI) oxide',
    'MgO': 'magnesium oxide',
}

for phase in project.phases():
    phase.export_CIF(os.path.join(ROOT, cif_names[phase.name]))

x, yobs, weights, ycalc, background, difference = hist.data['data'][1]
with open(os.path.join(ROOT, 'fit.csv'), 'w', newline='') as stream:
    writer = csv.writer(stream)
    writer.writerow([
        'two_theta_deg',
        'observed_intensity',
        'calculated_intensity',
        'difference_observed_minus_calculated',
        'background_intensity',
    ])
    for row in zip(x, yobs, ycalc, difference, background):
        writer.writerow([
            f'{float(row[0]):.8f}',
            f'{float(row[1]):.6f}',
            f'{float(row[2]):.6f}',
            f'{float(row[3]):.6f}',
            f'{float(row[4]):.6f}',
        ])

mass_fractions = hist.ComputeMassFracs()
residuals = hist.residuals
covariance = project.data['Covariance']['data']
rvals = covariance['Rvals']

phase_results = []
for phase in project.phases():
    fraction, fraction_esd = mass_fractions[phase.name]
    cell, cell_esd = phase.get_cell_and_esd()
    phase_results.append({
        'name': common_names[phase.name],
        'formula': formulae[phase.name],
        'space_group': phase.data['General']['SGData']['SpGrp'],
        'cif_path': cif_names[phase.name],
        'weight_fraction': float(fraction),
        'weight_fraction_formal_esd': float(fraction_esd),
        'bragg_r_factor_percent': float(residuals[f'{phase.id}:0:Rf']),
        'cell': {key: float(value) for key, value in cell.items()},
        'cell_formal_esd': {key: float(value) for key, value in cell_esd.items()},
    })

result = {
    'normalization': 'Weight fractions sum to one over the modeled crystalline phases; no amorphous fraction was determined.',
    'phases': phase_results,
    'fit_statistics': {
        'r_wp_percent': float(residuals['wR']),
        'r_p_percent': float(residuals['R']),
        'r_exp_percent': float(residuals['wRmin']),
        'goodness_of_fit': float(rvals['GOF']),
        'chi_squared': float(rvals['chisq']),
        'reduced_chi_squared': float(rvals['GOF']) ** 2,
        'n_observations': int(rvals['Nobs']),
        'n_refined_variables': int(rvals['Nvars']),
        'difference_definition': 'observed_intensity - calculated_intensity',
        'weighting': '1 / observed counts (pointwise uncertainties were not supplied)',
    },
    'profile_path': 'fit.csv',
    'gsas_project_path': 'final.gpx',
}

with open(os.path.join(ROOT, 'result.json'), 'w') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')

print(json.dumps(result, indent=2))
