from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
DATA = ROOT / 'inputs/pattern.csv'
INST = ROOT / '.tmp/cu_ka.instprm'
OUT = ROOT / '.tmp/model_eval'
OUT.mkdir(parents=True, exist_ok=True)

PHASES = {
    'scheelite': COD / '9/00/98/9009811.cif',
    'massicot': COD / '2/31/04/2310433.cif',
    'litharge': COD / '9/01/27/9012700.cif',
    'wo3_p21m': COD / '1/01/06/1010618.cif',
    'wo3_p21c': COD / '1/52/89/1528915.cif',
    'wo3_p1': COD / '2/10/62/2106293.cif',
    'wo3_pnma': COD / '2/10/73/2107312.cif',
    'wo3_alt': COD / '1/56/35/1563541.cif',
    'wo3_tet': COD / '1/52/15/1521532.cif',
    'pbwo4_mono': COD / '9/00/76/9007617.cif',
    'pb3o4_tet': COD / '1/53/79/1537983.cif',
    'pb3o4_ortho': COD / '9/00/30/9003043.cif',
    'pb2o3': COD / '2/31/10/2311012.cif',
    'pbo2_pbcn': COD / '1/53/10/1531016.cif',
    'pbo2_rutile': COD / '9/00/75/9007543.cif',
    'pbo2_pnma': COD / '9/01/70/9017012.cif',
    'pb2o': COD / '1/01/03/1010382.cif',
    'pb2wo5': ROOT / '.tmp/Pb2WO5_start.cif',
}

MODELS = [
    ('main', ['scheelite']),
    ('main_mass', ['scheelite', 'massicot']),
    ('main_lith', ['scheelite', 'litharge']),
    ('main_both_pbo', ['scheelite', 'massicot', 'litharge']),
    ('main_wo3_p21m', ['scheelite', 'wo3_p21m']),
    ('main_wo3_p21c', ['scheelite', 'wo3_p21c']),
    ('main_wo3_p1', ['scheelite', 'wo3_p1']),
    ('main_wo3_pnma', ['scheelite', 'wo3_pnma']),
    ('main_wo3_alt', ['scheelite', 'wo3_alt']),
    ('main_wo3_tet', ['scheelite', 'wo3_tet']),
    ('main_mono', ['scheelite', 'pbwo4_mono']),
    ('mass_lith_wo3p1', ['scheelite', 'massicot', 'litharge', 'wo3_p1']),
    ('mass_lith_wo3p21c', ['scheelite', 'massicot', 'litharge', 'wo3_p21c']),
    ('mass_lith_wo3p21m', ['scheelite', 'massicot', 'litharge', 'wo3_p21m']),
    ('mass_lith_mono', ['scheelite', 'massicot', 'litharge', 'pbwo4_mono']),
    ('main_pb3o4tet', ['scheelite', 'pb3o4_tet']),
    ('main_pb3o4ortho', ['scheelite', 'pb3o4_ortho']),
    ('main_pb2o3', ['scheelite', 'pb2o3']),
    ('main_pbo2pbcn', ['scheelite', 'pbo2_pbcn']),
    ('main_pbo2rutile', ['scheelite', 'pbo2_rutile']),
    ('main_pbo2pnma', ['scheelite', 'pbo2_pnma']),
    ('main_pb2o', ['scheelite', 'pb2o']),
    ('wo3_pb3o4tet', ['scheelite', 'wo3_p21c', 'pb3o4_tet']),
    ('wo3_pb3o4ortho', ['scheelite', 'wo3_p21c', 'pb3o4_ortho']),
    ('wo3_pb2o3', ['scheelite', 'wo3_p21c', 'pb2o3']),
    ('wo3_pb2o3_pb3o4', ['scheelite', 'wo3_p21c', 'pb2o3', 'pb3o4_tet']),
    ('all_pb3o4', ['scheelite', 'massicot', 'litharge', 'wo3_p21c', 'pb3o4_tet']),
    ('all_pb2o3', ['scheelite', 'massicot', 'litharge', 'wo3_p21c', 'pb2o3']),
    ('all_pb2o3_pb3o4', ['scheelite', 'massicot', 'litharge', 'wo3_p21c', 'pb2o3', 'pb3o4_tet']),
    ('main_pb2wo5', ['scheelite', 'pb2wo5']),
    ('pb2wo5_wo3', ['scheelite', 'pb2wo5', 'wo3_p21c']),
    ('pb2wo5_mass', ['scheelite', 'pb2wo5', 'massicot']),
    ('pb2wo5_lith', ['scheelite', 'pb2wo5', 'litharge']),
    ('pb2wo5_wo3_mass', ['scheelite', 'pb2wo5', 'wo3_p21c', 'massicot']),
    ('pb2wo5_wo3_lith', ['scheelite', 'pb2wo5', 'wo3_p21c', 'litharge']),
    ('pb2wo5_all', ['scheelite', 'pb2wo5', 'wo3_p21c', 'massicot', 'litharge']),
    ('pb2wo5_all_pb3o4', ['scheelite', 'pb2wo5', 'wo3_p21c', 'massicot', 'litharge', 'pb3o4_tet']),
    ('pb2wo5_all_pb2o3', ['scheelite', 'pb2wo5', 'wo3_p21c', 'massicot', 'litharge', 'pb2o3']),
    ('pb2wo5_all_pbo2pbcn', ['scheelite', 'pb2wo5', 'wo3_p21c', 'massicot', 'litharge', 'pbo2_pbcn']),
    ('pb2wo5_all_pbo2rutile', ['scheelite', 'pb2wo5', 'wo3_p21c', 'massicot', 'litharge', 'pbo2_rutile']),
    ('pb2wo5_all_pbo2pnma', ['scheelite', 'pb2wo5', 'wo3_p21c', 'massicot', 'litharge', 'pbo2_pnma']),
    ('pb2wo5_all_wo3pnma', ['scheelite', 'pb2wo5', 'wo3_p21c', 'massicot', 'litharge', 'wo3_pnma']),
    ('pb2wo5_all_wo3p1', ['scheelite', 'pb2wo5', 'wo3_p21c', 'massicot', 'litharge', 'wo3_p1']),
    ('pb2wo5_all_wo3p21m', ['scheelite', 'pb2wo5', 'wo3_p21c', 'massicot', 'litharge', 'wo3_p21m']),
    ('pb2wo5_all_pb2o3_pb3o4', ['scheelite', 'pb2wo5', 'wo3_p21c', 'massicot', 'litharge', 'pb2o3', 'pb3o4_tet']),
    ('pb2wo5_all_pb2o3_pbo2', ['scheelite', 'pb2wo5', 'wo3_p21c', 'massicot', 'litharge', 'pb2o3', 'pbo2_pbcn']),
]


def run_model(tag, names):
    project_path = OUT / f'{tag}.gpx'
    with redirect_stdout(StringIO()):
        project = G2sc.G2Project(newgpx=str(project_path))
        hist = project.add_powder_histogram(str(DATA), str(INST))
        hist.SampleParameters['Scale'][1] = False
        hist.InstrumentParameters['Zero'][1] = 0.28
        phase_objs = []
        for name in names:
            phase = project.add_phase(
                str(PHASES[name]), phasename=name, histograms=[hist], fmthint='CIF'
            )
            phase.data['Histograms'][hist.name]['Scale'][0] = 1.0
            phase_objs.append(phase)

        project.set_Controls('cycles', 8)
        project.do_refinements([{
            'set': {
                'Background': {'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 15},
                'PhaseFraction': True,
            }
        }])
        project.do_refinements([{'set': {'Instrument Parameters': ['Zero'], 'Cell': True}}])
        project.do_refinements([{'set': {'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']}}])
        project.do_refinements([{}])

        hist = project.histogram(0)
        residuals = hist.residuals
        scales = {
            phase.name: phase.data['Histograms'][hist.name]['Scale'][0]
            for phase in project.phases()
        }
        try:
            fracs = hist.ComputeMassFracs()
        except Exception:
            fracs = {}
        cells = {phase.name: phase.get_cell() for phase in project.phases()}
        zero = hist.InstrumentParameters['Zero'][1]
        profile = {key: hist.InstrumentParameters[key][1] for key in ['U', 'V', 'W', 'X', 'Y']}
        project.save()
    return residuals, scales, fracs, cells, zero, profile


requested = set(sys.argv[1:])
for tag, phase_names in MODELS:
    if requested and tag not in requested:
        continue
    try:
        result = run_model(tag, phase_names)
        residuals, scales, fracs, cells, zero, profile = result
        frac_text = ','.join(f'{k}={v[0]:.5f}' for k, v in fracs.items())
        scale_text = ','.join(f'{k}={v:.5g}' for k, v in scales.items())
        print(
            f'{tag:24s} wR={residuals.get("wR", float("nan")):.5f} '
            f'R={residuals.get("R", float("nan")):.5f} '
            f'Rb={residuals.get("Rb", float("nan")):.5f} zero={zero:.5f} '
            f'scales[{scale_text}] wt[{frac_text}] profile={profile}'
        )
    except Exception as exc:
        print(f'{tag:24s} ERROR {type(exc).__name__}: {exc}')
