import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = ROOT / '.tmp/model_eval/corrected_litharge.gpx'
FINAL = ROOT / 'final.gpx'

project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
project.save()
hist = project.histogram(0)

phase_meta = {
    'scheelite': {
        'name': 'lead tungstate (scheelite)',
        'formula': 'PbWO4',
        'space_group': 'I 41/a',
        'cif': 'phase_01_PbWO4_scheelite.cif',
        'model_source': 'COD 9009811',
    },
    'pb2wo5': {
        'name': 'lead oxytungstate',
        'formula': 'Pb2WO5',
        'space_group': 'C 2/m',
        'cif': 'phase_02_Pb2WO5.cif',
        'model_source': 'Pb2MoO5 (COD 7220560) isostructural model with Mo replaced by W; Pb/W coordinates and cell refined',
    },
    'wo3_p21c': {
        'name': 'tungsten trioxide (monoclinic)',
        'formula': 'WO3',
        'space_group': 'P 21/n',
        'cif': 'phase_03_WO3_monoclinic.cif',
        'model_source': 'COD 1528915',
    },
    'massicot': {
        'name': 'lead(II) oxide (massicot)',
        'formula': 'PbO',
        'space_group': 'P b c m',
        'cif': 'phase_04_PbO_massicot.cif',
        'model_source': 'COD 2310433',
    },
    'litharge': {
        'name': 'lead(II) oxide (litharge)',
        'formula': 'PbO',
        'space_group': 'P 4/n m m',
        'cif': 'phase_05_PbO_litharge.cif',
        'model_source': 'COD 9012700',
    },
    'pb2o3': {
        'name': 'lead sesquioxide (mixed-valence lead oxide)',
        'formula': 'Pb2O3',
        'space_group': 'P 21/c',
        'cif': 'phase_06_Pb2O3.cif',
        'model_source': 'COD 2311012',
    },
}

mass_fractions = hist.ComputeMassFracs()
residuals = hist.residuals
phase_results = []
for phase in project.phases():
    meta = phase_meta[phase.name]
    output = ROOT / meta['cif']
    phase.export_CIF(str(output))
    fraction, fraction_esd = mass_fractions[phase.name]
    cell, cell_esd = phase.get_cell_and_esd()
    idx = phase.id
    phase_results.append({
        'name': meta['name'],
        'formula': meta['formula'],
        'space_group': meta['space_group'],
        'cif_path': meta['cif'],
        'weight_fraction': fraction,
        'weight_fraction_esd_formal': fraction_esd,
        'weight_percent': 100.0 * fraction,
        'weight_percent_esd_formal': 100.0 * fraction_esd,
        'bragg_R_F_percent': residuals.get(f'{idx}:0:Rf'),
        'bragg_R_F2_percent': residuals.get(f'{idx}:0:Rf^2'),
        'unit_cell': cell,
        'unit_cell_esd_formal': cell_esd,
        'model_source': meta['model_source'],
    })

profile = hist.data['data'][1]
with (ROOT / 'fit.csv').open('w', newline='') as stream:
    writer = csv.writer(stream)
    writer.writerow([
        'two_theta_deg',
        'observed_counts',
        'calculated_counts',
        'difference_counts',
        'background_counts',
    ])
    for x, observed, calculated, background, difference in zip(
        profile[0], profile[1], profile[3], profile[4], profile[5]
    ):
        writer.writerow([
            f'{float(x):.8f}',
            f'{float(observed):.8f}',
            f'{float(calculated):.8f}',
            f'{float(difference):.8f}',
            f'{float(background):.8f}',
        ])

rvals = project.data['Covariance']['data']['Rvals']
fit_statistics = {
    'Rwp_percent': residuals['wR'],
    'Rp_percent': residuals['R'],
    'R_background_percent': residuals['Rb'],
    'weighted_R_background_percent': residuals['wRb'],
    'R_expected_percent': residuals['wRmin'],
    'goodness_of_fit': rvals['GOF'],
    'chi_square': rvals['chisq'],
    'number_observations': rvals['Nobs'],
    'number_refined_variables': rvals['Nvars'],
    'maximum_shift_over_esd': rvals['Max shft/sig'],
    'durbin_watson': hist.data['data'][0].get('Durbin-Watson'),
    'two_theta_range_deg': [hist.Limits('lower'), hist.Limits('upper')],
}

result = {
    'method': 'multiphasic Rietveld refinement in GSAS-II',
    'final_project': 'final.gpx',
    'profile_path': 'fit.csv',
    'weight_fraction_basis': 'normalized over the six modeled crystalline phases; amorphous/unmodeled material is not quantified',
    'phases': phase_results,
    'fit_statistics': fit_statistics,
    'uncertainty_note': (
        'Reported esds are covariance-only. Systematic uncertainty from the uncalibrated '
        'instrument profile, peak overlap, microabsorption and the isostructural Pb2WO5 '
        'starting model is larger; see report.md.'
    ),
}
with (ROOT / 'result.json').open('w') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')

print(json.dumps({'fit_statistics': fit_statistics, 'phases': phase_results}, indent=2))
