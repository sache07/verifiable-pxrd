from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


path = Path.cwd() / ".tmp/model_eval/corrected_litharge.gpx"
project = G2sc.G2Project(gpxfile=str(path))
project.set_Controls("cycles", 12)

for iteration in range(5):
    project.do_refinements([{}])
    rvals = project.data["Covariance"]["data"]["Rvals"]
    print(
        iteration + 1,
        "Rwp",
        project.histogram(0).residuals["wR"],
        "max_shift_esd",
        rvals["Max shft/sig"],
    )
    if abs(rvals["Max shft/sig"]) < 0.1:
        break

project.save()
