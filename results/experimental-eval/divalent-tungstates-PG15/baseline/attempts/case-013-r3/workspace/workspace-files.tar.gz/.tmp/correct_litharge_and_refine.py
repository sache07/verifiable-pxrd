from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIspc as G2spc


root = Path.cwd()
source = root / "final.gpx"
target = root / ".tmp/model_eval/corrected_litharge.gpx"

project = G2sc.G2Project(str(source), newgpx=str(target))
phase = project.phase("litharge")
atoms = phase.data["Atoms"]

# COD 9012700 is supplied in origin choice 1. GSAS-II converted the origin but
# left the Pb and O Wyckoff representatives interchanged. Put them onto the
# correct Pb 2c and O 2a orbits in GSAS-II's selected origin choice.
pb = next(atom for atom in atoms if atom[1] == "Pb")
oxygen = next(atom for atom in atoms if atom[1] == "O")
pb[2] = "X"
pb[3:6] = [-0.25, -0.25, 0.23510]
oxygen[2] = ""
oxygen[3:6] = [-0.25, 0.25, 0.0]
G2spc.UpdateSytSym(phase.data)
G2sc.SetupGeneral(phase.data, None)

hist = project.histogram(0)
phase.data["Histograms"][hist.name]["Scale"][0] = 2.2
project.set_Controls("cycles", 12)
project.save()

# First optimize the Pb height along with the existing global, cell and scale
# variables, then freeze all atom coordinates for the submitted refinement.
project.do_refinements([{}])
pb[2] = ""
project.do_refinements([{}])
project.do_refinements([{}])
project.save()

print("atoms")
for atom in phase.data["Atoms"]:
    print(atom[:11])
print("composition", phase.data["General"].get("Chemical Formula"))
print("mass", phase.data["General"].get("Mass"))
print("density", phase.data["General"].get("Density"))
print("residuals", hist.residuals)
print("mass_fractions", hist.ComputeMassFracs())
print("cell", phase.get_cell_and_esd())
print("zero", hist.InstrumentParameters["Zero"])
print(
    "profile",
    {key: hist.InstrumentParameters[key] for key in ["U", "V", "W", "X", "Y"]},
)
