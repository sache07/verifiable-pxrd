from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / '.tmp'


def clean(obj):
    if hasattr(obj, 'tolist'):
        return obj.tolist()
    if isinstance(obj, dict):
        return {str(k): clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [clean(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return repr(obj)


results = []
for kind in ('monoclinic_loopstra', 'triclinic_diehl'):
    proj = G2sc.G2Project(str(TMP / f'physical_{kind}.gpx'),
                         newgpx=str(TMP / f'clean_{kind}.gpx'))
    proj.set_Controls('cycles', 15)
    hist = proj.histogram(0)
    for phase in proj.phases():
        phase.clear_HAP_refinements({'Mustrain': True})
        phase.getHAPvalues(hist)['Mustrain'][1][0] = 0.0
    proj.save()
    history = []
    for n in range(3):
        proj.do_refinements([{}])
        history.append({'pass': n + 1, 'Rwp': hist.get_wR(),
                        'GOF': proj.data['Covariance']['data']['Rvals']['GOF'],
                        'mass_fracs': hist.ComputeMassFracs(),
                        'max_shift_esd': proj.data['Covariance']['data']['Rvals'].get('Max shft/sig')})
    proj.save()
    result = {
        'kind': kind, 'history': history,
        'Rwp': hist.get_wR(), 'GOF': proj.data['Covariance']['data']['Rvals']['GOF'],
        'mass_fracs': hist.ComputeMassFracs(),
        'instrument': hist.data['Instrument Parameters'][0],
        'phases': {p.name: {'cell': p.get_cell(), 'hap': p.getHAPvalues(hist)}
                   for p in proj.phases()},
        'residuals': hist.residuals,
    }
    results.append(result)
    print(json.dumps(clean(result), indent=2), flush=True)
with open(TMP / 'clean_results.json', 'w') as fp:
    json.dump(clean(results), fp, indent=2)
