from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
tmp = root / '.tmp'
proj = G2sc.G2Project(newgpx=str(tmp / 'inspect.gpx'))
hist = proj.add_powder_histogram(
    str(root / 'inputs' / 'pattern.csv'),
    str(tmp / 'cu_kalpha.instprm'),
    fmthint='comma',
)
wo3 = proj.add_phase(
    '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif',
    phasename='monoclinic WO3', histograms=[hist], fmthint='CIF')
cowo4 = proj.add_phase(
    str(tmp / 'cowo4_start.cif'), phasename='CoWO4', histograms=[hist], fmthint='CIF')
proj.save()

def compact(obj):
    if hasattr(obj, 'tolist'):
        obj = obj.tolist()
    if isinstance(obj, dict):
        return {str(k): compact(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [compact(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return repr(obj)

print('hist', hist.name)
for key in ['Limits','Background','Instrument Parameters','Sample Parameters']:
    print('\nHIST',key)
    print(json.dumps(compact(hist.data[key]), indent=2)[:10000])
for phase in proj.phases():
    print('\nPHASE',phase.name)
    print('cell',phase.get_cell())
    print('composition',phase.composition)
    print('general',json.dumps(compact(phase.data['General']),indent=2)[:10000])
    print('hap',json.dumps(compact(phase.getHAPvalues(hist)),indent=2)[:10000])
