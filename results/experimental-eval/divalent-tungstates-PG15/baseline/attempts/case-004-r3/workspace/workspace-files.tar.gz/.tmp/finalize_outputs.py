from pathlib import Path
import csv
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / '.tmp' / 'fullrange.gpx'
FINAL = ROOT / 'final.gpx'

# Save the exact refined project under the required final name. All subsequent
# exports in this script are generated from this in-memory project.
proj = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
proj.save()
hist = proj.histogram(0)

phase_outputs = {
    'WO3_triclinic_diehl': ROOT / 'WO3_triclinic.cif',
    'CoWO4': ROOT / 'CoWO4.cif',
}
for phase_name, output in phase_outputs.items():
    proj.phase(phase_name).export_CIF(str(output))

columns = {
    'two_theta_deg': hist.getdata('X'),
    'observed_intensity': hist.getdata('Yobs'),
    'calculated_intensity': hist.getdata('Ycalc'),
    'difference_intensity': hist.getdata('Residual'),
    'background_intensity': hist.getdata('Background'),
}
with open(ROOT / 'fit.csv', 'w', newline='') as fp:
    writer = csv.writer(fp)
    writer.writerow(columns)
    arrays = [np.ma.filled(v, np.nan) for v in columns.values()]
    for x, yo, yc, yd, yb in zip(*arrays):
        writer.writerow([
            f'{float(x):.8f}', f'{float(yo):.6f}', f'{float(yc):.6f}',
            f'{float(yd):.6f}', f'{float(yb):.6f}',
        ])

cov = proj.data['Covariance']['data']
summary = {
    'fit': {
        'residuals': dict(hist.residuals),
        'Rvals': dict(cov['Rvals']),
        'n_profile_points': len(columns['two_theta_deg']),
    },
    'mass_fractions': hist.ComputeMassFracs(),
    'phases': {},
}
for phase in proj.phases():
    cell, cell_esd = phase.get_cell_and_esd()
    summary['phases'][phase.name] = {
        'cell': cell, 'cell_esd': cell_esd,
        'composition': phase.composition,
        'density_g_cm3': phase.density,
        'cif': str(phase_outputs[phase.name].relative_to(ROOT)),
    }
print(json.dumps(summary, indent=2, default=lambda o: o.tolist()))
