from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / '.tmp'
BASE = TMP / 'continued_base.gpx'


def compact_project(proj, tag):
    hist = proj.histogram(0)
    cov = proj.data['Covariance']['data']
    vals = dict(zip(cov.get('varyList', []), cov.get('variables', [])))
    sigs = dict(zip(cov.get('varyList', []), cov.get('sig', [])))
    return {
        'tag': tag, 'Rwp': hist.get_wR(),
        'GOF': cov.get('Rvals', {}).get('GOF'),
        'max_shift_esd': cov.get('Rvals', {}).get('Max shft/sig'),
        'mass_fracs': hist.ComputeMassFracs(),
        'phase_scales': {p.name: p.getHAPvalues(hist)['Scale'][0] for p in proj.phases()},
        'scale_esds': {k: sigs.get(k) for k in vals if k.endswith(':Scale')},
        'cells': {p.name: p.get_cell() for p in proj.phases()},
        'coords': {p.name: {a.label: list(a.coordinates) for a in p.atoms()}
                   for p in proj.phases()},
    }


results = []
candidates = {
    'CoO_fixed': '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/54/16/1541662.cif',
    'Co3O4_fixed': '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/58/9005896.cif',
}
for name, cif in candidates.items():
    proj = G2sc.G2Project(str(BASE), newgpx=str(TMP / f'{name}.gpx'))
    proj.set_Controls('cycles', 15)
    hist = proj.histogram(0)
    phase = proj.add_phase(cif, phasename=name.replace('_fixed',''),
                           histograms=[hist], fmthint='CIF')
    phase.getHAPvalues(hist)['Scale'][:] = [0.02, True]
    phase.getHAPvalues(hist)['Size'][1][0] = 0.1
    proj.save()
    for _ in range(3):
        proj.do_refinements([{}])
    proj.save()
    result = compact_project(proj, name)
    results.append(result)
    print(json.dumps(result, indent=2), flush=True)

# Heavy-cation coordinates: only one symmetry-independent coordinate for each
# cation in P2/c; oxygen coordinates remain fixed because Cu-XRD is insensitive.
proj = G2sc.G2Project(str(BASE), newgpx=str(TMP / 'cation_coords.gpx'))
proj.set_Controls('cycles', 15)
cowo4 = proj.phase('CoWO4')
for atom in cowo4.atoms():
    if atom.element in ('Co', 'W'):
        atom.refinement_flags = 'X'
proj.save()
for _ in range(3):
    proj.do_refinements([{}])
proj.save()
result = compact_project(proj, 'cation_coordinates')
results.append(result)
print(json.dumps(result, indent=2), flush=True)

with open(TMP / 'minor_fixed_results.json', 'w') as fp:
    json.dump(results, fp, indent=2)
