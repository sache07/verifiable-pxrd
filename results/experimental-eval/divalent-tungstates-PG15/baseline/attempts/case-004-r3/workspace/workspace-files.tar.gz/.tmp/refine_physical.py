from pathlib import Path
import json
import traceback

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / '.tmp'
MODELS = {
    'monoclinic_loopstra': '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif',
    'triclinic_diehl': '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/10/62/2106293.cif',
}


def clean(obj):
    if hasattr(obj, 'tolist'):
        return obj.tolist()
    if isinstance(obj, dict):
        return {str(k): clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [clean(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return repr(obj)


def run_model(kind, phasefile):
    proj = G2sc.G2Project(newgpx=str(TMP / f'physical_{kind}.gpx'))
    proj.set_Controls('cycles', 12)
    hist = proj.add_powder_histogram(str(ROOT / 'inputs' / 'pattern.csv'),
        str(TMP / 'cu_kalpha.instprm'), fmthint='comma')
    wo3 = proj.add_phase(phasefile, phasename=f'WO3_{kind}',
                         histograms=[hist], fmthint='CIF')
    cowo4 = proj.add_phase(str(TMP / 'cowo4_start.cif'), phasename='CoWO4',
                           histograms=[hist], fmthint='CIF')
    hist.data['Sample Parameters']['Scale'][1] = False
    hist.set_refinements({'Limits': [10.0, 100.0],
        'Background': {'type': 'chebyschev-1', 'refine': True,
                       'no. coeffs': 15, 'coeffs': [900.0] + [0.0]*14}})
    for phase in (wo3, cowo4):
        hap = phase.getHAPvalues(hist)
        hap['Scale'][:] = [0.5, True]
        hap['Size'][0] = 'isotropic'
        hap['Size'][1][0] = 0.05
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = 1000.0
    proj.save()

    history = []
    steps = [
        ('scale_background', {}),
        ('cells', {'set': {'Cell': True}}),
        ('zero', {'set': {'Instrument Parameters': ['Zero']}}),
        ('size', {'set': {'Size': {'type': 'isotropic', 'refine': True}}}),
        ('microstrain', {'set': {'Mustrain': {'type': 'isotropic', 'refine': True}}}),
        ('instrument_W', {'set': {'Instrument Parameters': ['W']}}),
    ]
    for label, refs in steps:
        try:
            proj.do_refinements([refs])
            history.append({'step': label, 'Rwp': hist.get_wR(),
                            'GOF': proj.data['Covariance']['data'].get('Rvals',{}).get('GOF'),
                            'mass_fracs': hist.ComputeMassFracs()})
        except Exception as exc:
            history.append({'step': label, 'error': repr(exc),
                            'traceback': traceback.format_exc()})
            break
    proj.save()
    return {
        'kind': kind, 'history': history, 'Rwp': hist.get_wR(),
        'residuals': hist.residuals, 'mass_fracs': hist.ComputeMassFracs(),
        'instrument': hist.data['Instrument Parameters'][0],
        'phases': {p.name: {'cell': p.get_cell(),
                            'hap': p.getHAPvalues(hist)} for p in proj.phases()},
        'Rvals': proj.data['Covariance']['data'].get('Rvals',{}),
    }


results = []
for kind, phasefile in MODELS.items():
    print(f'\n=== {kind} ===', flush=True)
    result = run_model(kind, phasefile)
    results.append(result)
    print(json.dumps(clean(result), indent=2), flush=True)
with open(TMP / 'physical_results.json', 'w') as fp:
    json.dump(clean(results), fp, indent=2)
