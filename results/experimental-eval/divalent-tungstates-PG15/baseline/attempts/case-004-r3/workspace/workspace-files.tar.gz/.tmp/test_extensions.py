from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / '.tmp'
BASE = TMP / 'clean_triclinic_diehl.gpx'


def clean(obj):
    if hasattr(obj, 'tolist'):
        return obj.tolist()
    if isinstance(obj, dict):
        return {str(k): clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [clean(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return repr(obj)


def summarize(proj, tag):
    hist = proj.histogram(0)
    cov = proj.data['Covariance']['data']
    return {
        'tag': tag, 'Rwp': hist.get_wR(),
        'GOF': cov.get('Rvals', {}).get('GOF'),
        'max_shift_esd': cov.get('Rvals', {}).get('Max shft/sig'),
        'mass_fracs': hist.ComputeMassFracs(),
        'phases': {p.name: {
            'cell': p.get_cell(), 'composition': p.composition,
            'scale': p.getHAPvalues(hist)['Scale'],
            'atoms': [[a.label, a.element, a.coordinates, a.refinement_flags]
                      for a in p.atoms()],
        } for p in proj.phases()},
        'varyList': cov.get('varyList', []),
        'variables': cov.get('variables', []),
        'sig': cov.get('sig', []),
    }


results = []

# Continue the base model to tighter convergence.
proj = G2sc.G2Project(str(BASE), newgpx=str(TMP / 'continued_base.gpx'))
proj.set_Controls('cycles', 20)
for _ in range(3):
    proj.do_refinements([{}])
proj.save()
results.append(summarize(proj, 'continued_base'))
print(json.dumps(clean(results[-1]), indent=2), flush=True)

# Test chemically plausible unreacted/oxidized cobalt phases.
candidates = {
    'CoO': '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/54/16/1541662.cif',
    'Co3O4': '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/58/9005896.cif',
}
for name, cif in candidates.items():
    p = G2sc.G2Project(str(TMP / 'continued_base.gpx'),
                      newgpx=str(TMP / f'test_{name}.gpx'))
    p.set_Controls('cycles', 15)
    hist = p.histogram(0)
    phase = p.add_phase(cif, phasename=name, histograms=[hist], fmthint='CIF')
    phase.getHAPvalues(hist)['Scale'][:] = [0.05, True]
    phase.getHAPvalues(hist)['Size'][1][0] = 0.1
    phase.set_refinements({'Cell': True})
    p.save()
    for _ in range(2):
        p.do_refinements([{}])
    p.save()
    results.append(summarize(p, f'add_{name}'))
    print(json.dumps(clean(results[-1]), indent=2), flush=True)

# Test refinement of only the heavy-cation coordinates in CoWO4.
p = G2sc.G2Project(str(TMP / 'continued_base.gpx'),
                  newgpx=str(TMP / 'test_cation_coords.gpx'))
p.set_Controls('cycles', 15)
cowo4 = p.phase('CoWO4')
labels = [a.label for a in cowo4.atoms()]
for label in labels:
    atom = cowo4.atom(label)
    if atom.element in ('Co', 'W'):
        atom.refinement_flags = 'X'
p.save()
for _ in range(3):
    p.do_refinements([{}])
p.save()
results.append(summarize(p, 'refine_CoW_coordinates'))
print(json.dumps(clean(results[-1]), indent=2), flush=True)

with open(TMP / 'extension_results.json', 'w') as fp:
    json.dump(clean(results), fp, indent=2)
