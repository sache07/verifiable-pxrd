from pathlib import Path
import json
import traceback

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / '.tmp'
WO3_MODELS = {
    'monoclinic': '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif',
    'triclinic': '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/10/62/2106293.cif',
}


def run_model(kind):
    gpx = TMP / f'compare_{kind}.gpx'
    proj = G2sc.G2Project(newgpx=str(gpx))
    proj.set_Controls('cycles', 8)
    hist = proj.add_powder_histogram(
        str(ROOT / 'inputs' / 'pattern.csv'),
        str(TMP / 'cu_kalpha.instprm'), fmthint='comma')
    wo3 = proj.add_phase(WO3_MODELS[kind], phasename=f'{kind} WO3',
                         histograms=[hist], fmthint='CIF')
    cowo4 = proj.add_phase(str(TMP / 'cowo4_start.cif'), phasename='CoWO4',
                           histograms=[hist], fmthint='CIF')

    # The PWDR specimen scale duplicates all phase scales if left active.
    hist.data['Sample Parameters']['Scale'][1] = False
    hist.set_refinements({
        'Limits': [10.0, 100.0],
        'Background': {
            'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 15,
            'coeffs': [900.0] + [0.0] * 14,
        },
    })
    for phase in (wo3, cowo4):
        phase.set_HAP_refinements({'Scale': True})
    # Keep the weaker phase from starting on exactly the same scale.
    wo3.getHAPvalues(hist)['Scale'][0] = 0.5
    cowo4.getHAPvalues(hist)['Scale'][0] = 0.5
    proj.save()

    history = []
    steps = [
        ('scale_background', {}),
        ('cells', {'set': {'Cell': True}}),
        ('zero', {'set': {'Instrument Parameters': ['Zero']}}),
        ('gaussian_profile', {'set': {'Instrument Parameters': ['U', 'V', 'W']}}),
        ('lorentzian_profile', {'set': {'Instrument Parameters': ['X', 'Y']}}),
    ]
    for label, refs in steps:
        try:
            proj.do_refinements([refs])
            history.append({'step': label, 'Rwp': hist.get_wR(),
                            'residuals': dict(hist.residuals)})
        except Exception as exc:
            history.append({'step': label, 'error': repr(exc),
                            'traceback': traceback.format_exc()})
            break
    proj.save()
    out = {
        'kind': kind,
        'history': history,
        'residuals': dict(hist.residuals),
        'instrument': hist.data['Instrument Parameters'][0],
        'background': hist.data['Background'],
        'phases': {},
        'covariance': {
            k: proj.data['Covariance']['data'].get(k)
            for k in ['Rvals', 'varyList', 'variables', 'sig']
        },
    }
    for phase in proj.phases():
        out['phases'][phase.name] = {
            'cell': phase.get_cell(),
            'hap': phase.getHAPvalues(hist),
            'composition': phase.composition,
            'density': phase.density,
        }
    return out


def clean(obj):
    if hasattr(obj, 'tolist'):
        return obj.tolist()
    if isinstance(obj, dict):
        return {str(k): clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [clean(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return repr(obj)


results = []
for model in WO3_MODELS:
    print(f'\n=== {model} ===', flush=True)
    result = run_model(model)
    results.append(result)
    print(json.dumps(clean(result), indent=2), flush=True)
with open(TMP / 'compare_results.json', 'w') as fp:
    json.dump(clean(results), fp, indent=2)
