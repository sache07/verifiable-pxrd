from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parents[1]
proj = G2sc.G2Project(str(root / '.tmp' / 'fullrange.gpx'))
proj.set_Controls('cycles', 20)
hist = proj.histogram(0)
for i in range(4):
    proj.do_refinements([{}])
    r = proj.data['Covariance']['data']['Rvals']
    print(i + 1, hist.get_wR(), r.get('GOF'), r.get('Max shft/sig'),
          hist.ComputeMassFracs(), flush=True)
proj.save()
