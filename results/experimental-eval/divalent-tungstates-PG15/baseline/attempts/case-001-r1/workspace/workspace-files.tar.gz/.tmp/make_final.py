from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')

def cod_path(cod_id):
    cod_id = str(cod_id)
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'

gpx = G2sc.G2Project(newgpx=str(ROOT / 'final.gpx'), author='OpenAI Codex')
controls = gpx['Controls']['data']
controls['max cyc'] = 20
controls['min dM/M'] = 0.0001

hist = gpx.add_powder_histogram(
    str(ROOT / 'inputs' / 'pattern.csv'),
    str(ROOT / '.tmp' / 'cu_ka.instprm'),
    fmthint='comma',
)
hist.SampleParameters['Scale'] = [1.0, False]
hist.SampleParameters['InstrName'] = 'PIXcel1D-Medipix3 reflection; Cu K-alpha'

wo3 = gpx.add_phase(str(cod_path('2106293')), phasename='WO3',
                    histograms=[hist], fmthint='CIF')
baco3 = gpx.add_phase(str(cod_path('9010928')), phasename='BaCO3',
                      histograms=[hist], fmthint='CIF')
bawo4 = gpx.add_phase(str(cod_path('1527204')), phasename='BaWO4',
                      histograms=[hist], fmthint='CIF')
phases = (wo3, baco3, bawo4)

# Start close to the stable profile determined in preliminary refinements.
initial_instrument = {
    'Zero': 0.3132, 'U': 567.0, 'V': -466.1, 'W': 89.47,
    'X': 9.52, 'Y': 7.37,
}
for key, value in initial_instrument.items():
    hist.InstrumentParameters[key][1] = value

hist.set_refinements({
    'Background': {
        'type': 'chebyschev-1',
        'refine': True,
        'no. coeffs': 12,
        'coeffs': [
            629.64, -711.56, 455.81, -245.73, 146.22, -72.93,
            43.59, -20.55, 17.10, -6.21, 0.33, 0.49,
        ],
    },
    'Instrument Parameters': ['Zero'],
})

for phase, scale in zip(phases, (7.09, 19.61, 0.107)):
    phase.getHAPvalues(hist)['Scale'] = [scale, True]

# Release correlated groups in stages. The trace BaWO4 cell remains fixed to
# the reference structure because its scale is too small for reliable metrics.
gpx.do_refinements([{}])
wo3.set_refinements({'Cell': True})
baco3.set_refinements({'Cell': True})
gpx.do_refinements([{}])
hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
gpx.do_refinements([{}])
gpx.do_refinements([{}])
gpx.save()

# Export exactly the phases and profile stored in final.gpx.
for phase, filename in zip(phases, ('phase_wo3.cif', 'phase_baco3.cif', 'phase_bawo4.cif')):
    phase.export_CIF(str(ROOT / filename))

profile = np.column_stack([
    hist.getdata('x'), hist.getdata('yobs'), hist.getdata('ycalc'),
    hist.getdata('residual'), hist.getdata('background'),
])
np.savetxt(
    ROOT / 'fit.csv', profile, delimiter=',',
    header='two_theta_deg,observed_intensity,calculated_intensity,difference_observed_minus_calculated,background_intensity',
    comments='', fmt=['%.8f', '%.8f', '%.8f', '%.8f', '%.8f'],
)

fractions = hist.ComputeMassFracs()
rvals = gpx['Covariance']['data'].get('Rvals', {})
metrics = {
    'residuals': hist.residuals,
    'refinement': rvals,
    'mass_fractions': {
        name: {'value': float(value), 'esd': float(esd)}
        for name, (value, esd) in fractions.items()
    },
    'phases': {},
    'instrument_parameters': hist.InstrumentParameters,
}
for phase, cod_id, filename in zip(
    phases,
    ('2106293', '9010928', '1527204'),
    ('phase_wo3.cif', 'phase_baco3.cif', 'phase_bawo4.cif'),
):
    cell, cell_esd = phase.get_cell_and_esd()
    metrics['phases'][phase.name] = {
        'cod_id': cod_id,
        'cif': filename,
        'space_group': phase.data['General']['SGData']['SpGrp'],
        'cell': cell,
        'cell_esd': cell_esd,
        'scale': phase.getHAPvalues(hist)['Scale'][0],
    }

with open(ROOT / '.tmp' / 'final_metrics.json', 'w') as stream:
    json.dump(metrics, stream, indent=2,
              default=lambda obj: obj.tolist() if hasattr(obj, 'tolist') else float(obj))

print(json.dumps(metrics, indent=2,
                 default=lambda obj: obj.tolist() if hasattr(obj, 'tolist') else float(obj)))
