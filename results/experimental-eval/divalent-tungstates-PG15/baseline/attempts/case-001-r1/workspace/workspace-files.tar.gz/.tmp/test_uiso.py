from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
gpx = G2sc.G2Project(gpxfile=str(ROOT / '.tmp' / 'three_phase.gpx'),
                     newgpx=str(ROOT / '.tmp' / 'three_phase_uiso.gpx'))
gpx['Controls']['data']['max cyc'] = 20
wo3 = gpx.phase(0)
wvars, ovars = [], []
for idx, atom in enumerate(wo3.atoms()):
    atom.refinement_flags = 'U'
    if atom.element == 'W':
        atom.uiso = 0.004
        wvars.append(f'0::AUiso:{idx}')
    else:
        atom.uiso = 0.010
        ovars.append(f'0::AUiso:{idx}')
gpx.add_EquivConstr(tuple(wvars))
gpx.add_EquivConstr(tuple(ovars))
gpx.save()
gpx.do_refinements([{}])
gpx.do_refinements([{}])
gpx.save()
hist = gpx.histogram(0)
print('RESIDUALS', json.dumps(hist.residuals, default=float))
print('MASS', hist.ComputeMassFracs())
print('UISOS')
for i, atom in enumerate(wo3.atoms()):
    print(i, atom.label, atom.element, atom.uiso, atom.refinement_flags)
cov = gpx['Covariance']['data']
print('VARY')
for name, val, sig in zip(cov.get('varyList', []), cov.get('variables', []), cov.get('sig', [])):
    print(name, val, sig)
