from pathlib import Path
import argparse
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
parser = argparse.ArgumentParser()
parser.add_argument('cod_id')
parser.add_argument('name')
args = parser.parse_args()

cid = args.cod_id
cif = COD / cid[0] / cid[1:3] / cid[3:5] / f'{cid}.cif'
dst = ROOT / '.tmp' / f'candidate_{cid}.gpx'
gpx = G2sc.G2Project(gpxfile=str(ROOT / '.tmp' / 'three_phase.gpx'), newgpx=str(dst))
gpx['Controls']['data']['max cyc'] = 20
hist = gpx.histogram(0)
hist.clear_refinements({'Background': True})
hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'Y']})
for phase in gpx.phases():
    phase.clear_refinements({'Cell': True})
    phase.clear_HAP_refinements({'Scale': True})
candidate = gpx.add_phase(str(cif), phasename=args.name, histograms=[hist], fmthint='CIF')
candidate.getHAPvalues(hist)['Scale'] = [0.01, True]
gpx.do_refinements([{}])
gpx.save()
cov = gpx['Covariance']['data']
vals = dict(zip(cov.get('varyList', []), cov.get('variables', [])))
sigs = dict(zip(cov.get('varyList', []), cov.get('sig', [])))
print('RESIDUALS', json.dumps(hist.residuals, default=float))
print('SCALE', candidate.getHAPvalues(hist)['Scale'])
print('VARIABLES', {k: (v, sigs.get(k)) for k, v in vals.items()})
print('MASS', hist.ComputeMassFracs())
