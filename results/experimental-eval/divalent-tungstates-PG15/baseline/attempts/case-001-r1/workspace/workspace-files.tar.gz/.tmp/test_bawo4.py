from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
src = ROOT / '.tmp' / 'm2106293.gpx'
dst = ROOT / '.tmp' / 'bawo4_scale_test.gpx'
phasefile = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/72/1527204.cif')
gpx = G2sc.G2Project(gpxfile=str(src), newgpx=str(dst))
gpx['Controls']['data']['max cyc'] = 20
hist = gpx.histogram(0)

# Hold the accepted two-phase model fixed and measure only the candidate scale.
hist.clear_refinements({'Background': True})
hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'Y']})
for phase in gpx.phases():
    phase.clear_refinements({'Cell': True})
    phase.clear_HAP_refinements({'Scale': True})

candidate = gpx.add_phase(str(phasefile), phasename='BaWO4_test',
                          histograms=[hist], fmthint='CIF')
candidate.getHAPvalues(hist)['Scale'] = [0.01, True]
gpx.do_refinements([{}])
gpx.save()
cov = gpx['Covariance']['data']
pars = dict(zip(cov.get('varyList', []), cov.get('variables', [])))
sigs = dict(zip(cov.get('varyList', []), cov.get('sig', [])))
print('RESIDUALS', json.dumps(hist.residuals, default=float))
print('SCALE', candidate.getHAPvalues(hist)['Scale'])
print('VARY', json.dumps({k: [pars[k], sigs.get(k)] for k in pars}))
try:
    print('MASS', hist.ComputeMassFracs())
except Exception as exc:
    print('MASS_ERROR', repr(exc))
