from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')

def cod_path(cod_id):
    cod_id = str(cod_id)
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'

gpx_path = ROOT / '.tmp' / 'trial.gpx'
gpx = G2sc.G2Project(newgpx=str(gpx_path))
hist = gpx.add_powder_histogram(
    str(ROOT / 'inputs' / 'pattern.csv'),
    str(ROOT / '.tmp' / 'cu_ka.instprm'),
    fmthint='comma',
)
wo3 = gpx.add_phase(
    str(cod_path('1528915')), phasename='WO3', histograms=[hist], fmthint='CIF'
)
baco3 = gpx.add_phase(
    str(cod_path('9010928')), phasename='BaCO3', histograms=[hist], fmthint='CIF'
)

hist.set_refinements({
    'Limits': [10.0, 100.0],
    'Background': {
        'type': 'chebyschev-1',
        'refine': True,
        'no. coeffs': 12,
        'coeffs': [700.0] + [0.0] * 11,
    },
})
for phase in (wo3, baco3):
    phase.set_HAP_refinements({'Scale': True})

# Sequentially release strongly correlated groups.
gpx.do_refinements([{}])
hist.set_refinements({'Instrument Parameters': ['Zero']})
gpx.do_refinements([{}])
for phase in (wo3, baco3):
    phase.set_refinements({'Cell': True})
gpx.do_refinements([{}])
hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
gpx.do_refinements([{}])

gpx.save()
print('RESIDUALS', json.dumps(hist.residuals, indent=2, default=float))
print('INSTRUMENT')
for k, v in hist.InstrumentParameters.items():
    print(k, v)
print('SAMPLE', hist.SampleParameters)
for phase in (wo3, baco3):
    print('\nPHASE', phase.name)
    print('CELL', phase.get_cell())
    hap = phase.getHAPvalues(hist)
    for k in ('Scale','Size','Mustrain','Pref.Ori.','HStrain'):
        print(k, hap.get(k))
try:
    print('MASSFRACS', hist.ComputeMassFracs())
except Exception as e:
    print('MASSFRACS ERROR', repr(e))
print('COV keys', gpx['Covariance']['data'].keys())
print('VARY')
for n,v,s in zip(gpx['Covariance']['data'].get('varyList',[]),
                 gpx['Covariance']['data'].get('variables',[]),
                 gpx['Covariance']['data'].get('sig',[])):
    print(n, v, s)
