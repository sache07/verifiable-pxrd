from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
src = ROOT / '.tmp' / 'bawo4_scale_test.gpx'
dst = ROOT / '.tmp' / 'three_phase.gpx'
gpx = G2sc.G2Project(gpxfile=str(src), newgpx=str(dst))
gpx['Controls']['data']['max cyc'] = 20
gpx['Controls']['data']['min dM/M'] = 0.0001
hist = gpx.histogram(0)
hist.set_refinements({'Background': True})
hist.set_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'Y']})
for phase in gpx.phases()[:2]:
    phase.set_refinements({'Cell': True})
    phase.set_HAP_refinements({'Scale': True})
candidate = gpx.phase('BaWO4_test')
candidate.clear_refinements({'Cell': True})
candidate.set_HAP_refinements({'Scale': True})
gpx.do_refinements([{}])
gpx.do_refinements([{}])
gpx.save()
print('RESIDUALS', json.dumps(hist.residuals, default=float))
print('MASS', hist.ComputeMassFracs())
print('CELLS')
for phase in gpx.phases():
    print(phase.name, phase.get_cell(), phase.getHAPvalues(hist)['Scale'])
print('INST', hist.InstrumentParameters)
cov = gpx['Covariance']['data']
print('MAXSHIFT', cov.get('Lastshft'))
print('VARY')
for name, val, sig in zip(cov.get('varyList', []), cov.get('variables', []), cov.get('sig', [])):
    print(name, val, sig)
