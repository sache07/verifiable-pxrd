from pathlib import Path
import argparse
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')

def cod_path(cod_id):
    cod_id = str(cod_id)
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'

parser = argparse.ArgumentParser()
parser.add_argument('tag')
parser.add_argument('--wo3', default='1528915')
parser.add_argument('--without-wo3', action='store_true')
parser.add_argument('--without-baco3', action='store_true')
parser.add_argument('--bawo4', action='store_true')
parser.add_argument('--coords', action='store_true')
args = parser.parse_args()

gpx_path = ROOT / '.tmp' / f'{args.tag}.gpx'
gpx = G2sc.G2Project(newgpx=str(gpx_path))
gpx['Controls']['data']['max cyc'] = 12
gpx['Controls']['data']['min dM/M'] = 0.0001
hist = gpx.add_powder_histogram(
    str(ROOT / 'inputs' / 'pattern.csv'),
    str(ROOT / '.tmp' / 'cu_ka.instprm'),
    fmthint='comma',
)
hist.SampleParameters['Scale'] = [1.0, False]

phases = []
if not args.without_wo3:
    phases.append(gpx.add_phase(
        str(cod_path(args.wo3)), phasename=f'WO3_{args.wo3}',
        histograms=[hist], fmthint='CIF'))
if not args.without_baco3:
    phases.append(gpx.add_phase(
        str(cod_path('9010928')), phasename='BaCO3_9010928',
        histograms=[hist], fmthint='CIF'))
if args.bawo4:
    phases.append(gpx.add_phase(
        str(cod_path('1527204')), phasename='BaWO4_1527204',
        histograms=[hist], fmthint='CIF'))

hist.set_refinements({
    'Limits': [10.0, 100.0],
    'Background': {
        'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 12,
        'coeffs': [700.0] + [0.0] * 11,
    },
})
for phase in phases:
    phase.set_HAP_refinements({'Scale': True})

gpx.do_refinements([{}])
hist.set_refinements({'Instrument Parameters': ['Zero']})
gpx.do_refinements([{}])
for phase in phases:
    phase.set_refinements({'Cell': True})
gpx.do_refinements([{}])
hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
gpx.do_refinements([{}])
if args.coords:
    for phase in phases:
        phase.set_refinements({'Atoms': {'all': 'X'}})
    gpx.do_refinements([{}])
gpx.do_refinements([{}])
gpx.save()

out = {
    'tag': args.tag,
    'wo3': args.wo3,
    'residuals': hist.residuals,
    'instrument': {k: v for k, v in hist.InstrumentParameters.items()},
    'sample': hist.SampleParameters,
    'phases': {},
}
try:
    out['mass_fractions'] = hist.ComputeMassFracs()
except Exception as exc:
    out['mass_fractions_error'] = repr(exc)
for phase in phases:
    out['phases'][phase.name] = {
        'cell': phase.get_cell(),
        'scale': phase.getHAPvalues(hist)['Scale'],
        'atoms': [a.data for a in phase.atoms()],
    }
print('SUMMARY_JSON', json.dumps(out, default=lambda x: x.tolist() if hasattr(x, 'tolist') else float(x)))
