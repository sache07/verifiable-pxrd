#!/usr/bin/env python3
"""Remove scale redundancy and settle a two-phase GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("tag")
    parser.add_argument("--cycles", type=int, default=3)
    args = parser.parse_args()

    output = ROOT / ".tmp" / f"stable_{args.tag}.gpx"
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(str(ROOT / args.base), newgpx=str(output))
    hist = project.histogram(0)

    # Histogram and phase scales are exactly redundant for one pattern. Keep
    # the histogram multiplier fixed and refine only the phase scales.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phase.set_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""
    project.save()

    history = []
    for _ in range(args.cycles):
        project.do_refinements([{}])
        history.append(hist.get_wR())
    project.save()
    print(json.dumps({
        "output": str(output), "history": history,
        "masses": hist.ComputeMassFracs(), "residuals": hist.residuals,
        "sample": hist.data["Sample Parameters"],
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }, default=float))


if __name__ == "__main__":
    main()
