#!/usr/bin/env python3
"""Build exploratory GSAS-II Rietveld models for phase identification."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def current_value(entry):
    return entry[1] if isinstance(entry, list) else entry


def set_inst(hist, **values):
    inst = hist.data["Instrument Parameters"][0]
    for key, value in values.items():
        inst[key][1] = float(value)


def summarize(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    print("SUMMARY", label, json.dumps({
        "residuals": hist.residuals,
        "instrument": {k: current_value(inst[k]) for k in
                       ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "SH/L")},
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
            }
            for phase in project.phases()
        },
    }, default=float))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("ids", nargs="+", help="COD IDs")
    parser.add_argument("--names", nargs="*", default=None)
    parser.add_argument("--tag", default="test")
    parser.add_argument("--low", type=float, default=10.05)
    parser.add_argument("--high", type=float, default=99.95)
    args = parser.parse_args()

    out = ROOT / ".tmp" / f"{args.tag}.gpx"
    out.parent.mkdir(exist_ok=True)
    if out.exists():
        out.unlink()
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma/tab/semicolon separated",
    )
    hist.Limits("lower", args.low)
    hist.Limits("upper", args.high)
    names = args.names or args.ids
    if len(names) != len(args.ids):
        raise ValueError("--names must match number of IDs")
    for cod_id, name in zip(args.ids, names):
        project.add_phase(str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF")

    # Broad starting profile prevents position errors from destabilizing the first cycles.
    set_inst(hist, U=20, V=0, W=100, X=0, Y=5, Zero=0.15)
    hist.set_refinements({
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 18},
    })
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.save()

    stages = [
        ("scale_background", {}),
        ("cells", {"phase_cells": True}),
        ("zero", {"instrument": ["Zero"]}),
        ("profile_g", {"instrument": ["U", "V", "W"]}),
        ("profile_l", {"instrument": ["X", "Y"]}),
        ("zero_again", {}),
    ]
    for label, opts in stages:
        if opts.get("phase_cells"):
            for phase in project.phases():
                phase.set_refinements({"Cell": True})
        if opts.get("instrument"):
            hist.set_refinements({"Instrument Parameters": opts["instrument"]})
        try:
            project.do_refinements([{}])
            summarize(project, label)
        except Exception as exc:
            print("FAILED_STAGE", label, repr(exc))
            break
    project.save()
    try:
        print("MASS_FRACS", hist.ComputeMassFracs())
    except Exception as exc:
        print("MASS_FRACS_FAILED", repr(exc))


if __name__ == "__main__":
    main()
