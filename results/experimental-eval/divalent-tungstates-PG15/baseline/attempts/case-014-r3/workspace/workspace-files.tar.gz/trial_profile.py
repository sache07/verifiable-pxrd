#!/usr/bin/env python3
"""Test constrained instrument-profile refinements."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("tag")
    parser.add_argument("--fix-y", type=float)
    parser.add_argument("--fix-x", type=float)
    parser.add_argument("--fix-u", type=float)
    parser.add_argument("--fix-v", type=float)
    parser.add_argument("--fix-w", type=float)
    parser.add_argument("--shl", type=float)
    parser.add_argument("--refine-shl", action="store_true")
    parser.add_argument("--cycles", type=int, default=1)
    args = parser.parse_args()

    output = ROOT / ".tmp" / f"profile_{args.tag}.gpx"
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(str(ROOT / args.base), newgpx=str(output))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    if args.fix_y is not None:
        inst["Y"][1:] = [float(args.fix_y), False]
    if args.fix_x is not None:
        inst["X"][1:] = [float(args.fix_x), False]
    if args.fix_u is not None:
        inst["U"][1:] = [float(args.fix_u), False]
    if args.fix_v is not None:
        inst["V"][1:] = [float(args.fix_v), False]
    if args.fix_w is not None:
        inst["W"][1:] = [float(args.fix_w), False]
    if args.shl is not None:
        inst["SH/L"][1] = float(args.shl)
    inst["SH/L"][2] = bool(args.refine_shl)
    project.save()
    history = []
    for _ in range(args.cycles):
        project.do_refinements([{}])
        history.append(hist.get_wR())
    project.save()
    print(json.dumps({
        "output": str(output), "history": history,
        "masses": hist.ComputeMassFracs(), "residuals": hist.residuals,
        "instrument": {key: inst[key] for key in
                       ("Zero", "U", "V", "W", "X", "Y", "SH/L")},
    }, default=float))


if __name__ == "__main__":
    main()
