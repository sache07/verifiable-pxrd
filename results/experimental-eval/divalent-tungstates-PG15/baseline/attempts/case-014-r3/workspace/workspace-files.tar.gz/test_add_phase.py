#!/usr/bin/env python3
"""Add one candidate phase to the current best exploratory model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("cod_id")
    parser.add_argument("name")
    parser.add_argument("tag")
    parser.add_argument("--base", default=".tmp/wo3_pnma.gpx")
    parser.add_argument("--scale", type=float, default=0.5)
    args = parser.parse_args()
    out = ROOT / ".tmp" / f"add_{args.tag}.gpx"
    if out.exists():
        out.unlink()
    project = G2sc.G2Project(str(ROOT / args.base), newgpx=str(out))
    hist = project.histogram(0)

    # Start the trial phase against a fixed positional/profile model.
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    candidate = project.add_phase(
        str(cod_path(args.cod_id)), phasename=args.name,
        histograms=[hist], fmthint="CIF",
    )
    candidate.data["Histograms"][hist.name]["Scale"][0] = args.scale
    candidate.set_HAP_refinements({"Scale": True}, [hist])
    project.save()

    labels = []
    try:
        project.do_refinements([{}])
        labels.append("scale")
        scale = candidate.data["Histograms"][hist.name]["Scale"][0]
        if scale > 1e-8:
            candidate.set_refinements({"Cell": True})
            project.do_refinements([{}])
            labels.append("candidate_cell")
            for phase in project.phases():
                phase.set_refinements({"Cell": True})
            hist.set_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y"]})
            project.do_refinements([{}])
            labels.append("full")
    except Exception as exc:
        labels.append(f"failed:{exc!r}")
    project.save()
    result = {
        "tag": args.tag,
        "stages": labels,
        "wR": hist.get_wR(),
        "residuals": hist.residuals,
        "masses": hist.ComputeMassFracs(),
        "phases": {
            p.name: {
                "cell": p.get_cell(),
                "scale": p.data["Histograms"][hist.name]["Scale"][0],
            } for p in project.phases()
        },
    }
    print("CANDIDATE_RESULT", json.dumps(result, default=float))


if __name__ == "__main__":
    main()
