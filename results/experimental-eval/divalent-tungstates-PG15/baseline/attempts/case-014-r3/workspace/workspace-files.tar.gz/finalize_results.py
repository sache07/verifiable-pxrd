#!/usr/bin/env python3
"""Create the requested final GSAS-II project and derived deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "profile_uvy0_sh_third.gpx"
FINAL_GPX = ROOT / "final.gpx"


def main() -> None:
    if FINAL_GPX.exists():
        FINAL_GPX.unlink()
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL_GPX))
    hist = project.histogram(0)

    # Include the complete supplied scan and retain the physically constrained
    # profile established in the preceding refinement (U=V=Y=0; W, X and
    # axial divergence refined). Atomic coordinates and Uiso values remain
    # fixed, while phase scales, cells, zero, background and profile are active.
    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    hist.Limits("lower", float(x[0]))
    hist.Limits("upper", float(x[-1]))
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "Y"):
        inst[key][1:] = [0.0, False]
    for key in ("W", "X", "SH/L", "Zero"):
        inst[key][2] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phase.set_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""
    project.save()
    project.do_refinements([{}])
    project.save()

    # Export the exact structural models present in final.gpx.
    cif_paths = {
        "SrWO4": ROOT / "SrWO4.cif",
        "WO3": ROOT / "WO3.cif",
    }
    for phase in project.phases():
        phase.export_CIF(str(cif_paths[phase.name]), quickmode=True)

    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    observed = np.asarray(arrays[1], dtype=float)
    calculated = np.asarray(arrays[3], dtype=float)
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg", "intensity_observed", "intensity_calculated",
            "intensity_difference",
        ])
        writer.writerows(zip(x, observed, calculated, difference))

    mass = hist.ComputeMassFracs()
    covariance = project.data["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    residuals = hist.residuals
    phases = []
    phase_meta = {
        "SrWO4": ("strontium tungstate (scheelite)", "SrWO4", "I 41/a"),
        "WO3": ("tungsten trioxide (triclinic model)", "WO3", "P -1"),
    }
    for phase in project.phases():
        display_name, formula, space_group = phase_meta[phase.name]
        fraction, fraction_esd = mass[phase.name]
        phases.append({
            "name": display_name,
            "formula": formula,
            "space_group": space_group,
            "cif_path": cif_paths[phase.name].name,
            "weight_fraction": float(fraction),
            "weight_fraction_esd_formal": float(fraction_esd),
            "weight_percent": float(100.0 * fraction),
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
        })

    result = {
        "phases": phases,
        "weight_fraction_normalization": "modeled crystalline phases sum to 1.0",
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "GOF": float(rvals.get("GOF", np.sqrt(rvals["chisq"] / (rvals["Nobs"] - rvals["Nvars"])))),
            "chi_square": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_variables": int(rvals["Nvars"]),
        },
        "project_path": FINAL_GPX.name,
        "profile_path": "fit.csv",
        "notes": [
            "Fractions exclude any amorphous material or unmodeled crystalline contribution.",
            "Formal scale-factor esds understate systematic uncertainty because no intensity uncertainties or calibrated instrument profile were supplied.",
            "The exact WO3 polymorph is not uniquely resolved; P -1 was retained because it fit the observed splitting better than P21/n or Pnma models.",
        ],
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    sr = next(item for item in phases if item["formula"] == "SrWO4")
    wo = next(item for item in phases if item["formula"] == "WO3")
    report = f"""# PXRD phase analysis

The modeled crystalline assemblage is **{sr['weight_percent']:.1f} wt% scheelite SrWO4** and **{wo['weight_percent']:.1f} wt% WO3**, normalized over the two modeled crystalline phases. The formal GSAS-II scale-factor esd is {100.0 * sr['weight_fraction_esd_formal']:.2f} wt% for either fraction, but a more realistic systematic uncertainty is about 2 wt% because the scan has no supplied counting uncertainties or calibrated profile and the WO3 polymorph is pseudometric.

## Evidence

- Scheelite SrWO4 (I 41/a) accounts for the dominant lines at approximately 18.33, 27.99, 30.21, 33.39, 38.20, 45.47, 47.75, 51.98, 56.08 and 62.53 degrees 2theta. Its formation is also consistent with heating SrCO3 and WO3 at 900 C.
- WO3 accounts for the characteristic 23.45/23.97/24.73 degree triplet and many weaker lines. Splitting near 20.7 and 41.77/42.20 degrees favors a low-symmetry WO3 model. With the same constrained physical profile, the retained triclinic P -1 model gave Rwp {residuals['wR']:.2f}%, compared with about 17.6% for monoclinic P21/n and 18.2% for orthorhombic Pnma.
- SrCO3, SrO, monoclinic SrWO4 and Sr3W2O9 trial phases either refined to negligible/unstable amounts or required strong reflections that are absent. Residual-line indexing did not produce a coherent third lattice, so no third phase or fraction can be assigned reliably.

## Refinement and uncertainty

The final GSAS-II refinement used Cu Kalpha1/Kalpha2 wavelengths 1.540598/1.544426 A with ratio 0.5, Poisson weights (1/count, since uncertainties were absent), an 18-term Chebyshev background, refined phase scales and cells, zero, W/X profile terms and axial divergence. Atomic coordinates were held to reference structures and nonphysical negative displacement/profile terms were disallowed. The final statistics are Rwp = {residuals['wR']:.3f}%, Rp = {residuals['R']:.3f}%, Rexp = {residuals['wRmin']:.3f}% and GOF = {result['fit_statistics']['GOF']:.3f}.

The refined SrWO4 cell is a = {sr['cell']['length_a']:.5f} A, c = {sr['cell']['length_c']:.5f} A. The WO3 cell is a = {wo['cell']['length_a']:.5f}, b = {wo['cell']['length_b']:.5f}, c = {wo['cell']['length_c']:.5f} A, alpha = {wo['cell']['angle_alpha']:.3f}, beta = {wo['cell']['angle_beta']:.3f}, gamma = {wo['cell']['angle_gamma']:.3f} degrees.

The exact WO3 symmetry is the main unresolved point: P -1 is the best profile model, but P21/n is chemically plausible at room temperature and gives essentially the same WO3 fraction (~12.9 wt%). Remaining misfit, notably near 29.8, 32.6 and 44.7 degrees and in some high-angle peak shapes, prevents a stronger polymorph claim. Amorphous content cannot be measured without an internal standard; reported fractions therefore sum to the modeled crystalline portion only.
"""
    (ROOT / "report.md").write_text(report)

    backup = ROOT / "final.bak0.gpx"
    if backup.exists():
        backup.unlink()
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
