#!/usr/bin/env python3
"""Trial selected coordinate refinements in an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("tag")
    parser.add_argument("--phase", default="WO3")
    parser.add_argument("--atoms", nargs="+", required=True)
    parser.add_argument("--cycles", type=int, default=3)
    parser.add_argument("--refine-oxygen", action="store_true")
    args = parser.parse_args()

    output = ROOT / ".tmp" / f"atoms_{args.tag}.gpx"
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(str(ROOT / args.base), newgpx=str(output))
    hist = project.histogram(0)
    phase = project.phase(args.phase)

    # Keep lattice/profile terms active as in the source project and release
    # only selected coordinates in small stages.
    phase.set_refinements({"Atoms": {label: "X" for label in args.atoms}})
    project.save()
    history = []
    for cycle in range(args.cycles):
        project.do_refinements([{}])
        history.append((f"selected_{cycle + 1}", hist.get_wR()))

    if args.refine_oxygen:
        oxygen = {atom.label: "X" for atom in phase.atoms() if atom.element == "O"}
        phase.set_refinements({"Atoms": oxygen})
        for cycle in range(args.cycles):
            project.do_refinements([{}])
            history.append((f"oxygen_{cycle + 1}", hist.get_wR()))

    project.save()
    print(json.dumps({
        "output": str(output),
        "history": history,
        "residuals": hist.residuals,
        "masses": hist.ComputeMassFracs(),
        "atoms": {
            atom.label: {
                "element": atom.element,
                "xyz": atom.coordinates,
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        },
    }, indent=2, default=float))


if __name__ == "__main__":
    main()
