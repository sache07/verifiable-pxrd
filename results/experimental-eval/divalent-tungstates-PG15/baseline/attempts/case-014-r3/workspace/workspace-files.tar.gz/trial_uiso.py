#!/usr/bin/env python3
"""Evaluate fixed isotropic displacement values without changing chemistry."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("tag")
    parser.add_argument("--srwo4-uiso", type=float, required=True)
    parser.add_argument("--wo3-uiso", type=float, default=0.0)
    parser.add_argument("--cycles", type=int, default=2)
    args = parser.parse_args()

    output = ROOT / ".tmp" / f"uiso_{args.tag}.gpx"
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(str(ROOT / args.base), newgpx=str(output))
    hist = project.histogram(0)
    for atom in project.phase("SrWO4").atoms():
        atom.uiso = args.srwo4_uiso
        atom.refinement_flags = atom.refinement_flags.replace("U", "")
    for atom in project.phase("WO3").atoms():
        atom.uiso = args.wo3_uiso
        atom.refinement_flags = atom.refinement_flags.replace("U", "")
    project.save()
    history = []
    for cycle in range(args.cycles):
        project.do_refinements([{}])
        history.append(hist.get_wR())
    project.save()
    print(json.dumps({
        "output": str(output), "history": history,
        "masses": hist.ComputeMassFracs(), "residuals": hist.residuals,
    }, default=float))


if __name__ == "__main__":
    main()
