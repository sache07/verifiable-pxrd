#!/usr/bin/env python3
"""Autoindex selected unexplained powder lines with GSAS-II."""

from __future__ import annotations

import argparse

import numpy as np
from GSASII import GSASIIindex as G2idx


SETS = {
    # Positive residual maxima that are not dominated by the two modeled phases.
    "core": [15.030, 22.104, 30.906, 32.612, 35.306, 44.673, 53.443,
             61.277, 67.037, 70.775],
    # Expanded list includes weak/superstructure lines that can overlap WO3.
    "expanded": [15.030, 16.616, 20.680, 22.104, 26.233, 29.765, 30.906,
                 32.612, 35.306, 39.045, 41.772, 42.196, 44.673, 48.618,
                 50.552, 53.443, 59.560, 61.277, 67.037, 70.775],
    "strong": [22.104, 29.765, 30.906, 32.612, 35.306, 42.196, 44.673,
               48.618, 53.443, 61.277, 67.037],
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("set", choices=SETS)
    parser.add_argument("--bravais", type=int, nargs="+", default=list(range(13)))
    parser.add_argument("--zero", type=float, default=0.0)
    parser.add_argument("--volume", type=float, default=100.0)
    parser.add_argument("--timeout", type=float, default=8.0)
    args = parser.parse_args()

    wavelength = 1.540598
    peaks = []
    for pos in SETS[args.set]:
        corrected = pos - args.zero
        d = wavelength / (2 * np.sin(np.radians(corrected / 2)))
        peaks.append([pos, 1.0, True, False, 0, 0, 0, d, 0])

    controls = [0, 0.0, 4, args.volume, 0, "P1", 1, 1, 1, 90, 90, 90, 1, "P 1"]
    names = ["cF", "cI", "cP", "hR", "hP", "tI", "tP", "oF", "oI",
             "oA", "oB", "oC", "oP", "mI", "mA", "mC", "mP", "aP"]
    found = []
    for i in args.bravais:
        flags = [False] * 18
        flags[i] = True
        trial = [list(p) for p in peaks]
        ok, dmin, cells = G2idx.DoIndexPeaks(
            trial, controls[:], flags, None, timeout=args.timeout, M20_min=2.0,
            return_Nc=True,
        )
        for cell in cells:
            found.append(cell)
        print(f"SEARCH_DONE {i} {names[i]} ok={ok} count={len(cells)} dmin={dmin}")

    print("BEST_CELLS")
    for cell in sorted(found, key=lambda c: c[0], reverse=True)[:80]:
        print(names[cell[2]], " ".join(f"{v:.7g}" for v in cell))


if __name__ == "__main__":
    main()
