#!/usr/bin/env python3
"""Trial phase-specific broadening or preferred-orientation terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("tag")
    parser.add_argument("--phase", choices=["SrWO4", "WO3", "both"], default="both")
    parser.add_argument("--size", action="store_true")
    parser.add_argument("--mustrain", action="store_true")
    parser.add_argument("--po", nargs=3, type=int)
    parser.add_argument("--cycles", type=int, default=2)
    args = parser.parse_args()

    output = ROOT / ".tmp" / f"hap_{args.tag}.gpx"
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(str(ROOT / args.base), newgpx=str(output))
    hist = project.histogram(0)
    phases = project.phases() if args.phase == "both" else [project.phase(args.phase)]
    for phase in phases:
        refs = {}
        if args.size:
            refs["Size"] = {"type": "isotropic", "refine": True}
        if args.mustrain:
            refs["Mustrain"] = {"type": "isotropic", "refine": True}
        if refs:
            phase.set_HAP_refinements(refs, [hist])
        if args.po:
            po = phase.data["Histograms"][hist.name]["Pref.Ori."]
            po[0] = "MD"
            po[1] = 1.0
            po[2] = True
            po[3] = list(args.po)

    project.save()
    history = []
    for _ in range(args.cycles):
        project.do_refinements([{}])
        history.append(hist.get_wR())
    project.save()
    print(json.dumps({
        "output": str(output), "history": history,
        "masses": hist.ComputeMassFracs(), "residuals": hist.residuals,
        "hap": {
            phase.name: {
                key: phase.data["Histograms"][hist.name][key]
                for key in ("Size", "Mustrain", "Pref.Ori.")
            }
            for phase in project.phases()
        },
    }, default=float))


if __name__ == "__main__":
    main()
