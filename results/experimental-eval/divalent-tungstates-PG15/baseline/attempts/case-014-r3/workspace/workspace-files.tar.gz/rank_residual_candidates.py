#!/usr/bin/env python3
"""Rank COD candidates by linear fit to the positive Rietveld residual."""

from __future__ import annotations

import gzip
import json
import sys
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d

from GSASII import GSASIIscriptable as G2sc

sys.path.append("<HOME>/.local/share/pxrd-baseline/core/lib/python3.11/site-packages")
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
INFO = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def gaussian_profile(x, centers, intensities, fwhm=0.23):
    """Bin line intensities and broaden efficiently on the uniform data grid."""
    out = np.zeros_like(x)
    step = float(np.median(np.diff(x)))
    idx = np.rint((centers - x[0]) / step).astype(int)
    keep = (idx >= 0) & (idx < len(x))
    np.add.at(out, idx[keep], intensities[keep])
    sigma_points = fwhm / (2.354820045 * step)
    return gaussian_filter1d(out, sigma_points, mode="constant")


def main():
    gpx = G2sc.G2Project(str(ROOT / ".tmp" / "wo3_pnma.gpx"))
    hist = gpx.histogram(0)
    data = hist.data["data"][1]
    x = np.asarray(data[0], dtype=float)
    yobs = np.asarray(data[1], dtype=float)
    ycalc = np.asarray(data[3], dtype=float)
    use = (x >= 10.05) & (x <= 99.95)
    x = x[use]
    resid = (yobs - ycalc)[use]
    weights = 1.0 / np.maximum(yobs[use], 1.0)
    chi0 = np.sum(weights * resid * resid)
    zero = hist.data["Instrument Parameters"][0]["Zero"][1]

    with gzip.open(INFO, "rt") as stream:
        info = json.load(stream)
    allowed = {"C", "O", "Sr", "W"}
    candidates = []
    for key, records in info.items():
        elements = set(key.split("-"))
        if not elements <= allowed or not ({"Sr", "W"} & elements):
            continue
        for formula, cod_id, sg, rwp in records:
            candidates.append((key, formula, cod_id, sg, rwp))

    calc = XRDCalculator(wavelength=1.540598)
    results = []
    for key, formula, cod_id, sg, prior_rwp in candidates:
        try:
            structure = Structure.from_file(cod_path(cod_id))
            patt = calc.get_pattern(structure, two_theta_range=(8, 105), scaled=False)
            d = np.asarray(patt.d_hkls, dtype=float)
            inten = np.asarray(patt.y, dtype=float)
        except Exception as exc:
            print("SKIP", cod_id, formula, repr(exc))
            continue
        if not len(d) or np.max(inten) <= 0:
            continue
        inten = 100 * inten / np.max(inten)
        best = None
        for cell_scale in np.linspace(0.94, 1.06, 241):
            centers1 = np.degrees(2 * np.arcsin(1.540598 / (2 * d * cell_scale))) + zero
            centers2 = np.degrees(2 * np.arcsin(1.544426 / (2 * d * cell_scale))) + zero
            keep1 = np.isfinite(centers1) & (centers1 > x[0] - 1) & (centers1 < x[-1] + 1)
            keep2 = np.isfinite(centers2) & (centers2 > x[0] - 1) & (centers2 < x[-1] + 1)
            prof = gaussian_profile(x, centers1[keep1], inten[keep1])
            prof += 0.5 * gaussian_profile(x, centers2[keep2], inten[keep2])
            denom = np.sum(weights * prof * prof)
            if denom <= 0:
                continue
            amp = max(0.0, np.sum(weights * prof * resid) / denom)
            improvement = 100 * (chi0 - np.sum(weights * (resid - amp * prof) ** 2)) / chi0
            score = (improvement, amp, cell_scale)
            if best is None or score[0] > best[0]:
                best = score
        if best:
            results.append((*best, key, formula, cod_id, sg, prior_rwp))

    for improvement, amp, cell_scale, key, formula, cod_id, sg, prior_rwp in sorted(results, reverse=True)[:80]:
        print(f"{improvement:8.3f}% amp={amp:9.4g} scale={cell_scale:7.4f} id={cod_id} sg={sg:3d} {formula:18s} key={key} prior={prior_rwp}")


if __name__ == "__main__":
    main()
