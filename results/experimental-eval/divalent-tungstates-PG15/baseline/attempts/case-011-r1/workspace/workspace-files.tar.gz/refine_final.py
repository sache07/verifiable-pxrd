#!/usr/bin/env python3
"""Build the final two-phase GSAS-II refinement and export deliverables."""

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
SOURCE_CIFS = {
    "monoclinic-WO3": COD / "2/31/10/2311041.cif",
    "beta-MnO2": COD / "1/51/41/1514110.cif",
}


def refine(project, label):
    """Run one staged refinement and fail on a GSAS-II numerical error."""
    project.do_refinements([{}])
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    if not rvals.get("converged", False):
        raise RuntimeError(f"GSAS-II refinement did not converge at stage {label}")
    if rvals.get("SVD0", 0):
        raise RuntimeError(f"GSAS-II reported an SVD singularity at stage {label}")


def main():
    project = G2sc.G2Project(newgpx=str(WORK / "final.gpx"))
    hist = project.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )
    wo3 = project.add_phase(
        str(SOURCE_CIFS["monoclinic-WO3"]),
        phasename="monoclinic-WO3",
        histograms=[hist],
        fmthint="CIF",
    )
    mno2 = project.add_phase(
        str(SOURCE_CIFS["beta-MnO2"]),
        phasename="beta-MnO2",
        histograms=[hist],
        fmthint="CIF",
    )

    project.set_Controls("cycles", 12)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 12,
            }
        }
    )

    # Use one fixed phase scale and an overall scale to avoid scale degeneracy.
    hist.data["Sample Parameters"]["Scale"] = [15.0, True]
    hist.data["Sample Parameters"]["Shift"] = [-540.0, False]
    wo3.getHAPvalues(hist.name)["Scale"] = [1.0, False]
    mno2.getHAPvalues(hist.name)["Scale"] = [4.5, True]
    wo3.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.08, "refine": True}}
    )
    mno2.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.20, "refine": True}}
    )
    refine(project, "background, scales and size")

    # Peak positions: phase cells and Bragg-Brentano specimen-height correction.
    wo3.set_refinements({"Cell": True})
    mno2.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "cells and specimen displacement")
    refine(project, "position convergence")

    # Effective polarization was not supplied in metadata and is identifiable here.
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "effective polarization")
    refine(project, "polarization convergence")

    # Both phases show angle-dependent broadening beyond size broadening.
    wo3.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}
    )
    mno2.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}
    )
    refine(project, "isotropic microstrain")
    refine(project, "final convergence")
    project.save()

    # All submitted numerical artifacts are exported from this final project state.
    cif_paths = {
        "monoclinic-WO3": WORK / "phase_WO3.cif",
        "beta-MnO2": WORK / "phase_beta_MnO2.cif",
    }
    wo3.export_CIF(str(cif_paths["monoclinic-WO3"]))
    mno2.export_CIF(str(cif_paths["beta-MnO2"]))

    x, yobs, weight, ycalc, background, difference = hist.data["data"][1]
    with (WORK / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed",
                "calculated",
                "difference",
                "background",
            ]
        )
        writer.writerows(zip(x, yobs, ycalc, difference, background))

    fractions = hist.ComputeMassFracs()
    residuals = hist.data["data"][0]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    phase_objects = {
        "monoclinic-WO3": wo3,
        "beta-MnO2": mno2,
    }
    formulas = {"monoclinic-WO3": "WO3", "beta-MnO2": "MnO2"}
    source_ids = {"monoclinic-WO3": "COD 2311041", "beta-MnO2": "COD 1514110"}
    phases = []
    for name in ("monoclinic-WO3", "beta-MnO2"):
        phase = phase_objects[name]
        cell, cell_esd = phase.get_cell_and_esd()
        phases.append(
            {
                "name": name,
                "formula": formulas[name],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "structure_source": source_ids[name],
                "cif_path": cif_paths[name].name,
                "weight_fraction": fractions[name][0],
                "weight_fraction_formal_esd": fractions[name][1],
                "cell": cell,
                "cell_formal_esd": cell_esd,
            }
        )

    result = {
        "phases": phases,
        "weight_fraction_basis": (
            "normalized over the two modeled crystalline phases; amorphous or "
            "unmodeled material is excluded"
        ),
        "weight_fraction_sum": sum(item["weight_fraction"] for item in phases),
        "fit_statistics": {
            "Rwp_percent": residuals["wR"],
            "Rp_percent": residuals["R"],
            "Rexp_percent": residuals["wRmin"],
            "goodness_of_fit": rvals["GOF"],
            "chi_squared": rvals["chisq"],
            "durbin_watson": residuals.get("Durbin-Watson"),
            "n_observations": rvals["Nobs"],
            "n_refined_parameters": rvals["Nvars"],
            "converged": bool(rvals["converged"]),
            "maximum_shift_over_esd": rvals.get("Max shft/sig"),
        },
        "profile_path": "fit.csv",
        "gsasii_project_path": "final.gpx",
    }
    with (WORK / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
