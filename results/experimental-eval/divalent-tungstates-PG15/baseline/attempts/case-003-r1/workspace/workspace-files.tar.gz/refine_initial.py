from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


project = G2sc.G2Project(newgpx=str(ROOT / "initial.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma",
)

phase_specs = [
    ("WO3_monoclinic", "2311041"),
    ("CaWO4_scheelite", "7219229"),
    ("CaCO3_calcite", "1547347"),
]
for name, cod_id in phase_specs:
    phase = project.add_phase(
        str(cod_cif(cod_id)),
        phasename=name,
        histograms=[hist],
        fmthint="CIF",
    )
    print(name, phase.get_cell(), phase.data["General"]["SGData"]["SpGrp"])

print("histogram", hist.name)
print("sample", hist.data["Sample Parameters"])
print("instrument", hist.data["Instrument Parameters"])
print("background", hist.data["Background"])
for phase in project.phases():
    print("HAP", phase.name, phase.getHAPvalues(hist))

project.save()
