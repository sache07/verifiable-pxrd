from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_PROJECT = ROOT / "trial_po_calcite.gpx"
FINAL_PROJECT = ROOT / "final.gpx"


# Save under the requested final project name before refining so constraint and
# covariance lookups refer to the submitted project itself.
project = G2sc.G2Project(str(SOURCE_PROJECT), newgpx=str(FINAL_PROJECT))
project.set_Controls("cycles", 20)
project.data["Controls"]["data"]["min dM/M"] = 1.0e-4
project.save()
project.do_refinements([{}])
project.save()

hist = project.histogram(0)
cov = project.data["Covariance"]["data"]
rvals = cov["Rvals"]
hist_r = hist.data["data"][0]
mass_fractions = hist.ComputeMassFracs()


phase_output = {
    "WO3_2311041": {
        "name": "tungsten(VI) oxide (monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif_path": "WO3_monoclinic.cif",
        "reference_structure": "COD 2311041",
    },
    "CaWO4_scheelite": {
        "name": "calcium tungstate (scheelite)",
        "formula": "CaWO4",
        "space_group": "I 41/a",
        "cif_path": "CaWO4_scheelite.cif",
        "reference_structure": "COD 7219229",
    },
    "CaCO3_calcite": {
        "name": "calcium carbonate (calcite)",
        "formula": "CaCO3",
        "space_group": "R -3 c (hexagonal setting)",
        "cif_path": "CaCO3_calcite.cif",
        "reference_structure": "COD 1547347",
    },
}

phases_json = []
for phase in project.phases():
    out = phase_output[phase.name]
    cif_file = ROOT / out["cif_path"]
    phase.export_CIF(str(cif_file), quickmode=True)
    fraction, fraction_esd = mass_fractions[phase.name]
    cell = phase.get_cell()
    phases_json.append(
        {
            **out,
            "weight_fraction": float(fraction),
            "weight_fraction_esd_formal": float(fraction_esd),
            "unit_cell": {key: float(value) for key, value in cell.items()},
        }
    )


x = np.asarray(hist.getdata("X"), dtype=float)
yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
ydiff = np.asarray(hist.getdata("Residual"), dtype=float)
background = np.asarray(hist.getdata("Background"), dtype=float)
with (ROOT / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "difference_observed_minus_calculated",
            "calculated_background",
        ]
    )
    writer.writerows(
        zip(
            (f"{value:.8f}" for value in x),
            (f"{value:.8f}" for value in yobs),
            (f"{value:.8f}" for value in ycalc),
            (f"{value:.8f}" for value in ydiff),
            (f"{value:.8f}" for value in background),
        )
    )


gof = float(rvals["GOF"])
result = {
    "phases": phases_json,
    "weight_fraction_basis": (
        "Normalized over the three modeled crystalline phases; amorphous or "
        "unmodeled content is not quantified."
    ),
    "fit_statistics": {
        "Rwp_percent": float(hist_r["wR"]),
        "Rp_percent": float(hist_r["R"]),
        "Rexp_percent": float(hist_r["wRmin"]),
        "goodness_of_fit": gof,
        "reduced_chi_squared": gof * gof,
        "chi_squared": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_variables": int(rvals["Nvars"]),
        "weighted_bragg_R_percent": float(hist_r["wRb"]),
        "bragg_R_percent": float(hist_r["Rb"]),
    },
    "files": {
        "project": "final.gpx",
        "profile": "fit.csv",
        "report": "report.md",
    },
}
with (ROOT / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps(result, indent=2))
