from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summary(project, label):
    hist = project.histogram(0)
    print(f"\n--- {label}: wR={hist.get_wR()} ---")
    print("residuals", hist.data["data"][0])
    inst = hist.data["Instrument Parameters"][0]
    print("inst", {k: v[1] for k, v in inst.items() if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")})
    print("sample", {k: v for k, v in hist.data["Sample Parameters"].items() if k in ("Scale", "Shift", "Transparency")})
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        print(phase.name, "cell", phase.get_cell(), "scale", hap["Scale"], "size", hap["Size"], "strain", hap["Mustrain"], "wt", hap.get("wtFraction"))


def build_and_refine(wo3_id: str):
    outfile = ROOT / f"trial_wo3_{wo3_id}.gpx"
    project = G2sc.G2Project(newgpx=str(outfile))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    for name, cod_id in [
        (f"WO3_{wo3_id}", wo3_id),
        ("CaWO4_scheelite", "7219229"),
        ("CaCO3_calcite", "1547347"),
    ]:
        project.add_phase(
            str(cod_cif(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )

    # Remove an otherwise redundant overall intensity scale and start near the
    # common observed peak-position offset.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Instrument Parameters"][0]["Zero"][1] = 0.28
    project.set_Controls("cycles", 8)

    steps = [
        {"set": {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12}, "Scale": True}},
        {"set": {"Instrument Parameters": ["Zero"]}},
        {"set": {"Cell": True}},
        {"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}},
    ]
    for idx, step in enumerate(steps, 1):
        try:
            project.do_refinements([step])
            summary(project, f"{wo3_id} step {idx}")
        except Exception as exc:
            print(f"FAILED {wo3_id} step {idx}: {type(exc).__name__}: {exc}")
            break
    project.save()
    return project


for candidate in ("2311041", "1528915", "2106293", "1010618"):
    build_and_refine(candidate)
