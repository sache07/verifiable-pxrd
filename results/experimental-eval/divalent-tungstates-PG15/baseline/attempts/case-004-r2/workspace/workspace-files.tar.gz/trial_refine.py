#!/usr/bin/env python3
"""Run staged GSAS-II trial refinements for candidate phase sets."""

import argparse
import os

import numpy as np
from scipy.ndimage import percentile_filter, gaussian_filter1d
from GSASII import GSASIIscriptable as G2sc


PHASE_FILES = {
    "cowo4": ("cowo4_start.cif", "CoWO4"),
    "wo3": ("wo3_start.cif", "WO3"),
    "wo3tri": ("wo3_triclinic_start.cif", "WO3_triclinic"),
    "coo": ("coo_start.cif", "CoO"),
    "co3o4": ("co3o4_start.cif", "Co3O4"),
}


def report(project, label):
    hist = project.histogram(0)
    print(f"\nREPORT {label}")
    print("residuals", hist.residuals)
    print("instrument", {k: v[1] for k, v in hist.InstrumentParameters.items()
                         if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)")})
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        print("phase", phase.name, "scale", hap["Scale"], "cell", phase.get_cell())
    try:
        project.save()
        print("massfracs", hist.ComputeMassFracs())
    except Exception as err:
        print("massfracs unavailable", repr(err))


def refine(project, label):
    project.refine(makeBack=False)
    report(project, label)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("phases", nargs="+")
    parser.add_argument("--atoms", action="store_true")
    args = parser.parse_args()

    unknown = set(args.phases) - set(PHASE_FILES)
    if unknown:
        raise SystemExit(f"Unknown phases: {sorted(unknown)}")

    outfile = os.path.abspath(f"trial_{args.name}.gpx")
    project = G2sc.G2Project(newgpx=outfile)
    hist = project.add_powder_histogram("inputs/pattern.csv", "instrument.instprm")
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)

    # Initialize a smooth background from a robust lower envelope. GSAS-II's
    # chebyschev-1 function is the ordinary Chebyshev basis on [-1, 1].
    x = np.asarray(hist.data["data"][1][0])
    y = np.asarray(hist.data["data"][1][1])
    baseline = percentile_filter(y, percentile=18, size=401, mode="nearest")
    baseline = gaussian_filter1d(baseline, sigma=80)
    xp = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    coeffs = np.polynomial.chebyshev.chebfit(xp, baseline, deg=11)
    hist.set_refinements({"Background": {
        "type": "chebyschev-1", "no. coeffs": 12,
        "coeffs": coeffs.tolist(), "refine": True,
    }})

    # Keep the common sample multiplier fixed and refine independent phase
    # scales; this removes the exact scale-factor correlation.
    hist.SampleParameters["Scale"] = [1.0, False]
    for key in args.phases:
        filename, phasename = PHASE_FILES[key]
        phase = project.add_phase(filename, phasename=phasename,
                                  histograms=[hist], fmthint="CIF")
        phase.getHAPvalues(hist)["Scale"] = [0.5, True]

    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.save()

    refine(project, "background_scales")

    # Lattice constants and a shared zero offset establish peak positions.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "cells_zero")

    # Use one global profile because no calibrated instrumental profile is
    # supplied. Refinement is staged to reduce U/V/W/X/Y correlations.
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(project, "profile_WX")
    hist.set_refinements({"Instrument Parameters": ["U", "V", "Y"]})
    refine(project, "profile_all")
    refine(project, "settle")

    if args.atoms:
        # Refine heavy-atom positions only. Oxygen coordinates are weakly
        # determined by Cu X-ray data in the presence of W and are retained
        # from the literature starting models.
        for phase in project.phases():
            flags = {}
            for atom in phase.atoms():
                if atom.element in ("W", "Co"):
                    flags[atom.label] = "X"
            if flags:
                phase.set_refinements({"Atoms": flags})
        refine(project, "heavy_atoms")
        refine(project, "heavy_atoms_settle")

    project.save()
    report(project, "final")


if __name__ == "__main__":
    main()
