#!/usr/bin/env python3
"""Test a bounded positive profile: common Gaussian W + phase sizes."""

import os
from GSASII import GSASIIscriptable as G2sc


def show(project, label):
    hist = project.histogram(0)
    print("\nREPORT", label, hist.residuals, hist.ComputeMassFracs())
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("U", "V", "W", "X", "Y", "Zero")})
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        print(phase.name, "scale", hap["Scale"], "size", hap["Size"],
              "mustrain", hap["Mustrain"], "cell", phase.get_cell())


def run(project, label):
    project.refine(makeBack=False)
    show(project, label)


def main():
    project = G2sc.G2Project("trial_triclinic.gpx",
                             newgpx=os.path.abspath("trial_bounded_profile.gpx"))
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    for key, value in {"U": 2.0, "V": 0.0, "W": 20.0,
                       "X": 0.0, "Y": 0.0}.items():
        inst[key][1] = value
        inst[key][2] = False
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5

    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.05
        hap["Size"][1][2] = 0.5
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
    project.save()
    for pid in range(len(project.phases())):
        project.set_Controls("parmMin", 0.005, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 5.0, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Size;mx")
        project.set_Controls("parmMax", 1.0, variable=f"{pid}:0:Size;mx")
    project.set_Controls("parmMin", 0.01, variable=":0:W")
    project.set_Controls("parmMax", 500.0, variable=":0:W")
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMax", 500.0, variable=":0:U")
    run(project, "size")

    inst["W"][2] = True
    run(project, "size_W")

    for phase in project.phases():
        phase.getHAPvalues(hist)["Size"][2][2] = True
    run(project, "size_W_mix")

    inst["U"][2] = True
    run(project, "size_W_mix_U")
    run(project, "settle")
    project.save()


if __name__ == "__main__":
    main()
