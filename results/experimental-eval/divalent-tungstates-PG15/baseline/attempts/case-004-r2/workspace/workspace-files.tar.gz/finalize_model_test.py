#!/usr/bin/env python3
"""Converge the selected two-phase model with a parsimonious profile."""

import os
from GSASII import GSASIIscriptable as G2sc


def show(project, label):
    hist = project.histogram(0)
    print("\nREPORT", label, hist.residuals, hist.ComputeMassFracs())
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("U", "V", "W", "X", "Y", "Zero")})
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        print(phase.name, "scale", hap["Scale"], "size", hap["Size"],
              "cell", phase.get_cell())
        print("atoms", [(a.label, a.coordinates, a.refinement_flags)
                        for a in phase.atoms()])


def run(project, label):
    project.refine(makeBack=False)
    show(project, label)


def main():
    project = G2sc.G2Project("trial_triclinic.gpx",
                             newgpx=os.path.abspath("trial_selected_model.gpx"))
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    for key, value, refine in [
            ("U", 2.0, False), ("V", 0.0, False), ("W", 85.0, True),
            ("X", 0.0, False), ("Y", 0.0, False)]:
        inst[key][1] = value
        inst[key][2] = refine
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5

    sizes = [0.085, 0.054]
    for phase, size in zip(project.phases(), sizes):
        hap = phase.getHAPvalues(hist)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][1][2] = 0.5
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.save()
    run(project, "profile")
    run(project, "profile_settle")

    # Only the two symmetry-allowed cation y coordinates in wolframite are
    # released; the oxygen and triclinic-WO3 coordinates remain literature
    # values because they are not independently stable in this data set.
    cowo4 = project.phase("CoWO4")
    cowo4.atom("Co1").refinement_flags = "X"
    cowo4.atom("W1").refinement_flags = "X"
    run(project, "cations")
    run(project, "cations_settle")
    project.save()


if __name__ == "__main__":
    main()
