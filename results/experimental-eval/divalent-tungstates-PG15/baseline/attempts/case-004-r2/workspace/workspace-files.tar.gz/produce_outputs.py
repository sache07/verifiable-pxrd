#!/usr/bin/env python3
"""Create the requested deliverables from the selected GSAS-II model."""

import csv
import json
import os

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.dirname(__file__))


def fmt_cell(cell, esd):
    order = ["length_a", "length_b", "length_c", "angle_alpha",
             "angle_beta", "angle_gamma", "volume"]
    return {key: {"value": float(cell[key]), "esd": float(esd[key])}
            for key in order}


def main():
    final_path = os.path.join(ROOT, "final.gpx")
    project = G2sc.G2Project(os.path.join(ROOT, "trial_selected_model.gpx"),
                             newgpx=final_path)
    hist = project.histogram(0)

    # Include every supplied point in the final refinement/profile export.
    xall = np.asarray(hist.data["data"][1][0], dtype=float)
    hist.Limits("lower", float(xall[0]))
    hist.Limits("upper", float(xall[-1]))
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.save()
    project.refine(makeBack=False)
    # A second call verifies convergence after changing the fitted limits.
    project.refine(makeBack=False)
    project.save()

    # Reload exactly what is on disk before all exports.
    project = G2sc.G2Project(final_path)
    hist = project.histogram(0)
    # GSAS-II's quick CIF exporter otherwise estimates Z only from the
    # greatest common site multiplicity, which undercounts a P-1 cell with
    # several independent general sites. Store the chemically correct Z.
    project.phase("CoWO4").data["General"]["cellZ"] = 2
    project.phase("WO3_triclinic").data["General"]["cellZ"] = 8
    project.save()
    fractions = hist.ComputeMassFracs()

    phase_specs = [
        ("CoWO4", "CoWO4", "CoWO4.cif", "P 2/c"),
        ("WO3_triclinic", "WO3", "WO3_triclinic.cif", "P -1"),
    ]
    phase_records = []
    for project_name, formula, filename, space_group in phase_specs:
        phase = project.phase(project_name)
        phase.export_CIF(os.path.join(ROOT, filename))
        cell, cell_esd = phase.get_cell_and_esd()
        fraction, fraction_esd = fractions[project_name]
        phase_records.append({
            "name": project_name,
            "formula": formula,
            "space_group": space_group,
            "cif_path": filename,
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(fraction_esd),
            "unit_cell": fmt_cell(cell, cell_esd),
        })

    data = hist.data["data"][1]
    x = np.asarray(data[0], dtype=float)
    yobs = np.asarray(data[1], dtype=float)
    weight = np.asarray(data[2], dtype=float)
    ycalc = np.asarray(data[3], dtype=float)
    background = np.asarray(data[4], dtype=float)
    difference = np.asarray(data[5], dtype=float)
    with open(os.path.join(ROOT, "fit.csv"), "w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg", "observed_intensity", "calculated_intensity",
            "background_intensity", "difference_observed_minus_calculated",
            "weight",
        ])
        writer.writerows(zip(x, yobs, ycalc, background, difference, weight))

    residuals = hist.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    fit_statistics = {
        "r_wp_percent": float(residuals["wR"]),
        "r_p_percent": float(residuals["R"]),
        "r_exp_percent": float(residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_parameters": int(rvals["Nvars"]),
        "two_theta_range_deg": [float(x[0]), float(x[-1])],
        "phase_r_f_percent": {
            "CoWO4": float(residuals["0:0:Rf"]),
            "WO3_triclinic": float(residuals["1:0:Rf"]),
        },
    }
    result = {
        "phases": phase_records,
        "weight_fraction_basis": (
            "Normalized over the two modeled crystalline phases; amorphous "
            "material, if present, is not included."
        ),
        "fit_statistics": fit_statistics,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    with open(os.path.join(ROOT, "result.json"), "w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    co = phase_records[0]
    wo = phase_records[1]
    co_pct = 100.0 * co["weight_fraction"]
    wo_pct = 100.0 * wo["weight_fraction"]
    co_su = 100.0 * co["weight_fraction_esd"]
    wo_su = 100.0 * wo["weight_fraction_esd"]
    report = f"""# PXRD phase analysis

The modeled crystalline material contains two phases: triclinic WO3 (P -1), {wo_pct:.2f} wt%, and wolframite CoWO4 (P 2/c), {co_pct:.2f} wt%. The fractions are normalized over these crystalline phases only. Their formal least-squares standard uncertainties are {wo_su:.2f} and {co_su:.2f} wt%, respectively.

## Evidence

WO3 is identified by the intense 23.17/23.67/24.41 degree triplet and its higher-angle multiplets near 33--34, 41--42, 50, and 56 degrees 2-theta. Peak splitting in the 33--34 degree region is reproduced substantially better by a triclinic P -1 model than by the pseudosymmetric monoclinic P21/n alternative (matched trial Rwp about 7.35% versus 7.81% before the final cation refinement). CoWO4 accounts for the diagnostic reflections near 15.62, 19.09, 30.71, 36.44, 38.61, 54.15, and 61.80 degrees.

The final GSAS-II Rietveld fit uses the reported Cu Kalpha1/Kalpha2 wavelengths and fixed 0.5 intensity ratio, a refined zero offset, 12-term smooth background, refined cells and phase scales, a positive common Gaussian width, and positive isotropic phase-size broadening. It gives Rwp = {fit_statistics['r_wp_percent']:.3f}%, Rp = {fit_statistics['r_p_percent']:.3f}%, Rexp = {fit_statistics['r_exp_percent']:.3f}%, and goodness of fit = {fit_statistics['goodness_of_fit']:.3f} over {fit_statistics['n_observations']} points.

## Uncertainty and limits

The formal fraction uncertainties understate practical uncertainty because no calibrated instrumental profile or supplied pointwise uncertainties were available; Poisson weights derived from the counts were used. Peak overlap, profile choice, preferred orientation and absorption can therefore shift the fractions. A realistic reading is approximately WO3 {wo_pct:.1f} +/- 2 wt% and CoWO4 {co_pct:.1f} +/- 2 wt% among crystalline phases.

Co3O4 was tested and its scale collapsed to zero. A CoO trial refined to only about 0.8 wt% while improving Rwp by approximately 0.008 percentage point; its lattice parameter expanded to about 4.277 angstrom so that its six lines overlapped existing peaks, and no phase-specific line was resolved. CoO is therefore not reported as a determined phase, though roughly <=1 wt% cannot be excluded. No amorphous fraction can be obtained without an internal standard.

The CoWO4 cation y coordinates were stable enough to refine; its oxygen coordinates and all WO3 atomic coordinates were retained from literature starting models because releasing them was not independently stable against this laboratory powder pattern. Thus the phase types and cells are reliable, while fine atomic coordinates should not be interpreted as a new structure determination. The weak triclinic distortion of WO3 is supported by peak splitting but remains pseudosymmetric, so monoclinic indexing is the principal structural alternative.
"""
    with open(os.path.join(ROOT, "report.md"), "w") as stream:
        stream.write(report)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
