#!/usr/bin/env python3
"""Replace an empirical global profile with positive phase broadening terms."""

import os
from GSASII import GSASIIscriptable as G2sc


def show(project, label):
    hist = project.histogram(0)
    print("\nREPORT", label, hist.residuals, hist.ComputeMassFracs())
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("U", "V", "W", "X", "Y", "Zero")})
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        print(phase.name, "scale", hap["Scale"], "size", hap["Size"],
              "mustrain", hap["Mustrain"], "cell", phase.get_cell())


def main():
    project = G2sc.G2Project("trial_triclinic.gpx",
                             newgpx=os.path.abspath("trial_physical_profile.gpx"))
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    for key, value in {"U": 2.0, "V": -2.0, "W": 5.0,
                       "X": 0.0, "Y": 0.0}.items():
        inst[key][1] = value
        inst[key][2] = False
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5

    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.10
        hap["Size"][1][2] = 0.5
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][2] = 0.5
        hap["Mustrain"][2] = [False, False, False]
    project.save()
    project.refine(makeBack=False)
    show(project, "size")

    for phase in project.phases():
        phase.getHAPvalues(hist)["Mustrain"][2][0] = True
    project.refine(makeBack=False)
    show(project, "size_strain")
    project.refine(makeBack=False)
    project.save()
    show(project, "settle")


if __name__ == "__main__":
    main()
