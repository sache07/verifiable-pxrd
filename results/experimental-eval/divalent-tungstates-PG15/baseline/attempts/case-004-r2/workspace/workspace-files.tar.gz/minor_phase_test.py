#!/usr/bin/env python3
"""Add one candidate minor phase to the converged two-phase trial model."""

import argparse
import os
from GSASII import GSASIIscriptable as G2sc


FILES = {
    "coo": ("coo_start.cif", "CoO"),
    "co3o4": ("co3o4_start.cif", "Co3O4"),
}


def show(project, label):
    hist = project.histogram(0)
    print("\nREPORT", label, hist.residuals)
    print("massfracs", hist.ComputeMassFracs())
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        print(phase.name, "scale", hap["Scale"], "cell", phase.get_cell())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("candidate", choices=FILES)
    args = ap.parse_args()
    out = os.path.abspath(f"trial_two_plus_{args.candidate}.gpx")
    project = G2sc.G2Project("trial_two.gpx", newgpx=out)
    hist = project.histogram(0)
    filename, name = FILES[args.candidate]
    phase = project.add_phase(filename, phasename=name,
                              histograms=[hist], fmthint="CIF")
    phase.getHAPvalues(hist)["Scale"] = [0.05, True]
    project.set_Controls("cycles", 8)
    project.save()
    project.refine(makeBack=False)
    show(project, "scale")
    phase.set_refinements({"Cell": True})
    project.refine(makeBack=False)
    show(project, "scale_cell")
    project.refine(makeBack=False)
    project.save()
    show(project, "settle")


if __name__ == "__main__":
    main()
