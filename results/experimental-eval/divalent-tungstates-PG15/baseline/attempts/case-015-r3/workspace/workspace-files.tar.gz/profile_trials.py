#!/usr/bin/env python3
"""Evaluate physically interpretable high-angle/profile corrections."""

import argparse
from pathlib import Path
from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent


def make_trial(tag, zero_adp=False, instrument=()):
    out = root / ".tmp" / f"profile_{tag}.gpx"
    gpx = G2sc.G2Project(str(root / "final.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    gpx.data["Controls"]["data"]["max cyc"] = 25
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-7

    # Retain the accepted structural/profile degrees of freedom and add only
    # the explicitly requested trial terms.
    hist.Background[0][1] = True
    for key, val in hist.InstrumentParameters.items():
        if isinstance(val, list) and len(val) > 2:
            val[2] = key in ({"Zero"} | set(instrument))
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Size"][2] = [True, False, True]
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = phase.name == "ZnWO4"
        for atom in phase.atoms():
            atom.refinement_flags = " "
            if zero_adp:
                atom.ADP = 0.0 if atom.adp_flag == "I" else [0.0] * 6
    for atom in gpx.phase("ZnWO4").atoms():
        if atom.element in ("W", "Zn"):
            atom.refinement_flags = "X"
    for atom in gpx.phase("WO3").atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"

    for _ in range(3):
        gpx.refine()
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    print("TRIAL", tag)
    print("RES", hist.residuals)
    print("MASS", hist.ComputeMassFracs())
    print("INST", {k: v for k, v in hist.InstrumentParameters.items()
                   if k in set(instrument) | {"Zero"}})
    print("GOF", cov.get("Rvals", {}).get("GOF"),
          "SHIFT", cov.get("Rvals", {}).get("Max shft/sig"),
          "CONVERGED", cov.get("Rvals", {}).get("converged"))
    for phase in gpx.phases():
        print("HAP", phase.name, "size", phase.getHAPvalues(hist)["Size"])


trials = {
    "polar": dict(instrument=("Polariz.",)),
    "zero_adp": dict(zero_adp=True),
    "zero_adp_polar": dict(zero_adp=True, instrument=("Polariz.",)),
    "uvw": dict(instrument=("U", "V", "W")),
}
parser = argparse.ArgumentParser()
parser.add_argument("trial", choices=trials)
args = parser.parse_args()
make_trial(args.trial, **trials[args.trial])
