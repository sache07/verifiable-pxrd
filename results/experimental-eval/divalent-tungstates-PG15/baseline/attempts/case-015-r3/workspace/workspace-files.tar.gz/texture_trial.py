#!/usr/bin/env python3
"""Screen simple March-Dollase axes for the dominant ZnWO4 phase."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
src = root / ".tmp/heavy_trial.gpx"
axes = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1), (1, 1, -1)]

for axis in axes:
    tag = "_".join(str(v).replace("-", "m") for v in axis)
    gpx = G2sc.G2Project(str(src), newgpx=str(root / f".tmp/texture_{tag}.gpx"))
    h = gpx.histogram(0)
    gpx.data["Controls"]["data"]["max cyc"] = 15
    h.Background[0][1] = False
    for val in h.InstrumentParameters.values():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    for p in gpx.phases():
        p.data["General"]["Cell"][0] = False
        hap = p.getHAPvalues(h)
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        for atom in p.atoms():
            atom.refinement_flags = " "
    pref = gpx.phase("ZnWO4").getHAPvalues(h)["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = list(axis)
    gpx.refine()
    gpx.save()
    sig = gpx.data["Covariance"]["data"].get("sig")
    vary = gpx.data["Covariance"]["data"].get("varyList")
    print("AXIS", axis, "R", h.residuals, "MASS", h.ComputeMassFracs(),
          "PREF", pref, "SU", sig[vary.index("0:0:MD")])
