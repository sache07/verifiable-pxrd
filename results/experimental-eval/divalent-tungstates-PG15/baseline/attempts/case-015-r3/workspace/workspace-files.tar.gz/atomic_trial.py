#!/usr/bin/env python3
"""Trial coordinate refinements, isolated from the accepted final candidate."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(root / ".tmp/three_refined.gpx"),
                     newgpx=str(root / ".tmp/atomic_trial.gpx"))
h = gpx.histogram(0)
gpx.data["Controls"]["data"]["max cyc"] = 20

# Hold peak positions/shapes/background fixed while testing structure factors;
# phase scales remain active.
h.Background[0][1] = False
for val in h.InstrumentParameters.values():
    if isinstance(val, list) and len(val) > 2:
        val[2] = False
for p in gpx.phases():
    p.data["General"]["Cell"][0] = False
    hap = p.getHAPvalues(h)
    hap["Scale"][1] = True
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    for atom in p.atoms():
        atom.refinement_flags = " "

zwo = gpx.phase("ZnWO4")
for atom in zwo.atoms():
    atom.refinement_flags = "X"
gpx.refine()
print("ZWO", h.residuals, h.ComputeMassFracs())
for atom in zwo.atoms():
    print(zwo.name, atom.label, atom.coordinates, atom.refinement_flags)

# Test only the heavy-atom coordinates for the minority WO3 phase.
wo3 = gpx.phase("WO3")
for atom in wo3.atoms():
    if atom.element == "W":
        atom.refinement_flags = "X"
gpx.refine()
print("WO3_W", h.residuals, h.ComputeMassFracs())
for atom in wo3.atoms():
    print(wo3.name, atom.label, atom.coordinates, atom.refinement_flags)
gpx.save()
print("VARY", gpx.data["Covariance"]["data"].get("varyList"))
print("SIG", gpx.data["Covariance"]["data"].get("sig"))
