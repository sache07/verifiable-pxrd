#!/usr/bin/env python3
"""Test only X-ray-sensitive heavy-atom coordinates."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(root / ".tmp/three_refined.gpx"),
                     newgpx=str(root / ".tmp/heavy_trial.gpx"))
h = gpx.histogram(0)
gpx.data["Controls"]["data"]["max cyc"] = 20
h.Background[0][1] = False
for val in h.InstrumentParameters.values():
    if isinstance(val, list) and len(val) > 2:
        val[2] = False
for p in gpx.phases():
    p.data["General"]["Cell"][0] = False
    hap = p.getHAPvalues(h)
    hap["Scale"][1] = True
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    for atom in p.atoms():
        atom.refinement_flags = " "

for atom in gpx.phase("ZnWO4").atoms():
    if atom.element in ("W", "Zn"):
        atom.refinement_flags = "X"
gpx.refine()
print("ZWO_HEAVY", h.residuals, h.ComputeMassFracs())
for atom in gpx.phase("ZnWO4").atoms():
    print("ZnWO4", atom.label, atom.coordinates, atom.refinement_flags)

for atom in gpx.phase("WO3").atoms():
    if atom.element == "W":
        atom.refinement_flags = "X"
gpx.refine()
print("ALL_HEAVY", h.residuals, h.ComputeMassFracs())
for atom in gpx.phase("WO3").atoms():
    print("WO3", atom.label, atom.coordinates, atom.refinement_flags)
gpx.save()
print("VARY", gpx.data["Covariance"]["data"].get("varyList"))
print("SIG", gpx.data["Covariance"]["data"].get("sig"))
