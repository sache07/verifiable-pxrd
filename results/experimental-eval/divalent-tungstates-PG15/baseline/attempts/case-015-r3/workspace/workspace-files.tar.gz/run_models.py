#!/usr/bin/env python3
"""Build staged GSAS-II trial refinements for phase-model selection."""

from __future__ import annotations

import csv
import json
import math
import os
import sys
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

CANDIDATES = {
    "ZnWO4": COD / "1/52/06/1520641.cif",
    "ZnO": COD / "9/00/41/9004178.cif",
    # Neutron-derived monoclinic gamma-WO3 model with a complete, chemically
    # sensible distorted WO6 octahedron (equivalent setting to P21/n source).
    "WO3": ROOT / ".tmp/wo3_niggli.cif",
}

MODELS = {
    "zwo": ["ZnWO4"],
    "zwo_zno": ["ZnWO4", "ZnO"],
    "zwo_wo3": ["ZnWO4", "WO3"],
    "zwo_zno_wo3": ["ZnWO4", "ZnO", "WO3"],
}


def make_xye() -> Path:
    src = ROOT / "inputs/pattern.csv"
    dst = ROOT / ".tmp/pattern.xye"
    dst.parent.mkdir(exist_ok=True)
    rows = []
    with src.open(newline="") as fp:
        for row in csv.DictReader(fp):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            rows.append((x, y, math.sqrt(max(y, 1.0))))
    np.savetxt(dst, np.asarray(rows), fmt=("%.8f", "%.8g", "%.8g"))
    return dst


def report_state(gpx: G2sc.G2Project, tag: str) -> None:
    hist = gpx.histogram(0)
    vals = {
        "tag": tag,
        "residuals": hist.residuals,
        "instrument": {
            k: v[1]
            for k, v in hist.InstrumentParameters.items()
            if isinstance(v, list) and len(v) >= 2
        },
        "sample": hist.SampleParameters,
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        vals["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "composition": phase.composition,
            "density": phase.density,
        }
    print("STATE " + json.dumps(vals, default=str))


def refine_model(name: str, phase_names: list[str], xye: Path) -> dict:
    out = ROOT / ".tmp" / f"{name}.gpx"
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(xye), str(ROOT / "instrument.instprm"), fmthint="xye"
    )
    phases = [
        gpx.add_phase(str(CANDIDATES[p]), phasename=p, histograms=[hist])
        for p in phase_names
    ]
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    # Use enough cycles for broad, overlapping peaks while keeping derivatives stable.
    gpx.data["Controls"]["data"]["max cyc"] = 12
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
    # Keep the histogram scale fixed; otherwise it is exactly redundant with
    # all HAP phase scales and makes quantitative phase scales singular.
    hist.SampleParameters["Scale"] = [1.0, False]
    # Start minor phases at a low scale so they do not swamp the first cycle.
    for i, phase in enumerate(phases):
        phase.getHAPvalues(hist)["Scale"][0] = 1.0 if i == 0 else 0.03

    recipes = [
        {"set": {"Background": {"type": "chebyschev-1", "refine": True,
                                  "no. coeffs": 12},
                  "PhaseFraction": True}},
        {"set": {"Size": {"type": "isotropic", "value": 0.1,
                            "refine": True,
                            "LGmix": {"value": 0.5, "refine": False}}}},
        {"set": {"Cell": True}},
        {"set": {"Instrument Parameters": ["Zero"]}},
        # A final scale/background/profile pass after peak positions settle.
        {},
    ]
    for i, recipe in enumerate(recipes):
        try:
            gpx.do_refinements([recipe])
            report_state(gpx, f"{name}:{i}")
        except Exception as exc:
            print(f"REFINE_ERROR {name}:{i} {type(exc).__name__}: {exc}")
            break
    gpx.save()
    hist = gpx.histogram(0)
    result = {
        "model": name,
        "project": str(out),
        "residuals": hist.residuals,
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        result["phases"][phase.name] = {
            "scale": hap["Scale"][0],
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "density": phase.density,
        }
    return result


def main() -> None:
    xye = make_xye()
    requested = sys.argv[1:] or list(MODELS)
    results = []
    for name in requested:
        print(f"START_MODEL {name}")
        results.append(refine_model(name, MODELS[name], xye))
    print("SUMMARY " + json.dumps(results, default=str))


if __name__ == "__main__":
    main()
