#!/usr/bin/env python3
"""Staged full refinement of the accepted ZnWO4 + WO3 + ZnO model."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
gpx = G2sc.G2Project(
    str(root / ".tmp/zwo_wo3_zno_test.gpx"),
    newgpx=str(root / ".tmp/three_refined.gpx"),
)
hist = gpx.histogram(0)
gpx.data["Controls"]["data"]["max cyc"] = 15
gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
hist.SampleParameters["Scale"] = [1.0, False]


def state(tag):
    print("STATE", tag, "residuals", json.dumps(hist.residuals))
    print("MASS", hist.ComputeMassFracs())
    for p in gpx.phases():
        h = p.getHAPvalues(hist)
        print(tag, p.name, "scale", h["Scale"], "size", h["Size"],
              "mustrain", h["Mustrain"], "cell", p.get_cell())


# Remove all trial microstrain flags and retain strictly positive defaults.
for p in gpx.phases():
    h = p.getHAPvalues(hist)
    h["Scale"][1] = True
    h["Mustrain"][1][0] = 1000.0
    h["Mustrain"][2] = [False] * len(h["Mustrain"][2])
    p.data["General"]["Cell"][0] = False
    h["Size"][2] = [False] * len(h["Size"][2])

# First establish a data-driven but positive width for the added ZnO phase.
zno = gpx.phase("ZnO")
zno.set_HAP_refinements({
    "Size": {"type": "isotropic", "value": 0.03, "refine": True,
             "LGmix": {"value": 0.5, "refine": False}}
}, [hist])
gpx.refine()
state("zno_size")

# Then allow its lattice to demonstrate that the assignment is chemically sane.
zno.data["General"]["Cell"][0] = True
gpx.refine()
state("zno_cell")

# Reoptimize all phase cells and independent isotropic sizes.
for p in gpx.phases():
    p.data["General"]["Cell"][0] = True
    p.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True,
                 "LGmix": {"value": 0.5, "refine": False}}
    }, [hist])
gpx.refine()
state("all_shape")

# Final joint background/zero/phase pass.
hist.Background[0][1] = True
hist.InstrumentParameters["Zero"][2] = True
gpx.refine()
state("joint")
gpx.refine()
state("final")
gpx.save()

print("VARY", gpx.data["Covariance"]["data"].get("varyList"))
print("SIG", gpx.data["Covariance"]["data"].get("sig"))
