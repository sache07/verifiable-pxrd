#!/usr/bin/env python3
"""Add ZnO to the stable ZnWO4+WO3 model as a nested detection test."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
src = root / ".tmp/zwo_wo3.gpx"
dst = root / ".tmp/zwo_wo3_zno_test.gpx"
zno_cif = Path("<HOME>/.local/share/characterizagent/backends/dara/") / (
    "cod-filtered-2024/cif/9/00/41/9004178.cif"
)

gpx = G2sc.G2Project(str(src), newgpx=str(dst))
hist = gpx.histogram(0)

# Freeze the accepted baseline shape/position model. Refit both accepted phase
# scales together with the candidate scale so the candidate is not penalized by
# a fixed normalization.
hist.Background[0][1] = False
for key, val in hist.InstrumentParameters.items():
    if isinstance(val, list) and len(val) > 2:
        val[2] = False
for phase in gpx.phases():
    phase.data["General"]["Cell"][0] = False
    hap = phase.getHAPvalues(hist)
    hap["Scale"][1] = True
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])

zno = gpx.add_phase(str(zno_cif), phasename="ZnO", histograms=[hist])
hap = zno.getHAPvalues(hist)
hap["Scale"] = [0.05, True]
hap["Size"][0] = "isotropic"
hap["Size"][1][0] = 0.03
hap["Size"][2] = [False] * len(hap["Size"][2])
gpx.data["Controls"]["data"]["max cyc"] = 20
gpx.refine()
gpx.save()

print("residuals", hist.residuals)
print("mass_fracs", hist.ComputeMassFracs())
for phase in gpx.phases():
    h = phase.getHAPvalues(hist)
    print(phase.name, "scale", h["Scale"], "cell", phase.get_cell(), "size", h["Size"])
print("vary", gpx.data["Covariance"]["data"].get("varyList"))
print("sig", gpx.data["Covariance"]["data"].get("sig"))
