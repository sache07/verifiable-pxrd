#!/usr/bin/env python3
"""Create final.gpx and export all numerical products directly from it."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
source = root / ".tmp/lgmix_trial.gpx"
project_path = root / "final.gpx"

gpx = G2sc.G2Project(str(source), newgpx=str(project_path))
hist = gpx.histogram(0)
gpx.data["Controls"]["data"]["max cyc"] = 20
gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
hist.SampleParameters["Scale"] = [1.0, False]

# Include all supplied observations in both the refinement and fit.csv.
xall = hist.getdata("X")
hist.Limits("lower", float(np.min(xall)))
hist.Limits("upper", float(np.max(xall)))

# Empirical background and only the zero correction are refined. The profile
# baseline remains fixed because no calibrated instrumental profile was supplied;
# sample broadening is represented by positive phase-specific isotropic sizes.
hist.Background[0][1] = True
for key, val in hist.InstrumentParameters.items():
    if isinstance(val, list) and len(val) > 2:
        val[2] = key == "Zero"

for phase in gpx.phases():
    phase.data["General"]["Cell"][0] = True
    hap = phase.getHAPvalues(hist)
    hap["Scale"][1] = True
    hap["Size"][0] = "isotropic"
    # Refine both isotropic domain size and its bounded L/G mixing term.
    hap["Size"][2] = [True, False, True]
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][2] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "

# X-rays constrain these heavy-atom positions; oxygen positions are retained
# from the source structures to avoid the chemically implausible unconstrained
# oxygen shifts found in a rejected trial.
for atom in gpx.phase("ZnWO4").atoms():
    if atom.element in ("W", "Zn"):
        atom.refinement_flags = "X"
for atom in gpx.phase("WO3").atoms():
    if atom.element == "W":
        atom.refinement_flags = "X"

pref = gpx.phase("ZnWO4").getHAPvalues(hist)["Pref.Ori."]
pref[0] = "MD"
pref[2] = True
pref[3] = [1, 0, 0]

# Repeat joint refinement to ensure the expanded limits and coupled parameters
# have settled before saving.
for cycle in range(3):
    gpx.refine()
    print("PASS", cycle + 1, json.dumps(hist.residuals))
gpx.save()

# Reload from disk: all submitted values below therefore demonstrably come from
# final.gpx rather than an in-memory precursor.
final = G2sc.G2Project(str(project_path))
h = final.histogram(0)

phase_files = {
    "ZnWO4": root / "ZnWO4.cif",
    "WO3": root / "WO3.cif",
    "ZnO": root / "ZnO.cif",
}
for phase in final.phases():
    phase.export_CIF(str(phase_files[phase.name]))

x = np.asarray(h.getdata("X"), dtype=float)
yobs = np.asarray(h.getdata("Yobs"), dtype=float)
ycalc = np.asarray(h.getdata("Ycalc"), dtype=float)
bkg = np.asarray(h.getdata("Background"), dtype=float)
diff = np.asarray(h.getdata("Residual"), dtype=float)
np.savetxt(
    root / "fit.csv",
    np.column_stack([x, yobs, ycalc, diff, bkg]),
    delimiter=",",
    header=("two_theta_deg,observed_intensity,calculated_intensity,"
            "difference_obs_minus_calc,calculated_background"),
    comments="",
    fmt=["%.8f", "%.8g", "%.8g", "%.8g", "%.8g"],
)

summary = {
    "residuals": h.residuals,
    "mass_fractions": h.ComputeMassFracs(),
    "instrument": {
        key: val[1]
        for key, val in h.InstrumentParameters.items()
        if isinstance(val, list) and len(val) >= 2
    },
    "limits": [h.Limits("lower"), h.Limits("upper")],
    "n_points": int(len(x)),
    "vary_list": final.data["Covariance"]["data"].get("varyList", []),
    "sigmas": final.data["Covariance"]["data"].get("sig", []).tolist(),
    "phases": {},
}
for phase in final.phases():
    hap = phase.getHAPvalues(h)
    cell, cell_esd = phase.get_cell_and_esd()
    summary["phases"][phase.name] = {
        "cif": phase_files[phase.name].name,
        "composition": phase.composition,
        "cell": cell,
        "cell_esd": cell_esd,
        "density_g_cm3": phase.density,
        "scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": atom.coordinates,
                "refinement_flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
    }
print("FINAL_SUMMARY " + json.dumps(summary, default=str))
