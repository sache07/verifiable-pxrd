#!/usr/bin/env python3
"""Test phase-specific Lorentzian/Gaussian size-broadening mixtures."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(root / "final.gpx"),
                     newgpx=str(root / ".tmp/lgmix_trial.gpx"))
h = gpx.histogram(0)
gpx.data["Controls"]["data"]["max cyc"] = 20
h.Background[0][1] = False
for val in h.InstrumentParameters.values():
    if isinstance(val, list) and len(val) > 2:
        val[2] = False
for p in gpx.phases():
    p.data["General"]["Cell"][0] = False
    hap = p.getHAPvalues(h)
    hap["Scale"][1] = True
    hap["Size"][2] = [True, False, True]
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][2] = False
    for atom in p.atoms(): atom.refinement_flags = " "
gpx.refine()
gpx.save()
print("RES", h.residuals, "MASS", h.ComputeMassFracs())
for p in gpx.phases(): print(p.name, p.getHAPvalues(h)["Size"])
print("VARY",gpx.data["Covariance"]["data"].get("varyList"))
print("SIG",gpx.data["Covariance"]["data"].get("sig"))
