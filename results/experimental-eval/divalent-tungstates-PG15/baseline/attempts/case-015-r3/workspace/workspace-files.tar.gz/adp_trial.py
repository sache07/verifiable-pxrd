#!/usr/bin/env python3
"""Check whether ZnWO4 isotropic displacement terms are data-supported."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root=Path(__file__).resolve().parent
gpx=G2sc.G2Project(str(root/'final.gpx'),newgpx=str(root/'.tmp/adp_trial.gpx'))
h=gpx.histogram(0); gpx.data['Controls']['data']['max cyc']=20
h.Background[0][1]=False
for val in h.InstrumentParameters.values():
    if isinstance(val,list) and len(val)>2: val[2]=False
for p in gpx.phases():
    p.data['General']['Cell'][0]=False
    hap=p.getHAPvalues(h); hap['Scale'][1]=True
    hap['Size'][2]=[False]*len(hap['Size'][2]); hap['Mustrain'][2]=[False]*len(hap['Mustrain'][2]); hap['Pref.Ori.'][2]=False
    for a in p.atoms(): a.refinement_flags=' '
for a in gpx.phase('ZnWO4').atoms(): a.refinement_flags='U'
gpx.refine(); gpx.save()
print('RES',h.residuals,'MASS',h.ComputeMassFracs())
for a in gpx.phase('ZnWO4').atoms(): print(a.label,a.uiso,a.refinement_flags)
print('VARY',gpx.data['Covariance']['data'].get('varyList'))
print('SIG',gpx.data['Covariance']['data'].get('sig'))
