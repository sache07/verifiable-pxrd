import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


BASE = Path(".tmp/staged_07_XY_1.gpx")


def values(path):
    project = G2sc.G2Project(gpxfile=str(path))
    residuals = project.data["Covariance"]["data"]["Rvals"]
    return residuals["chisq"], residuals["Rwp"]


for md in (0.65, 0.70, 0.75, 0.775, 0.80, 0.825, 0.85, 0.875, 0.90, 0.95, 1.00):
    start = Path(f".tmp/md_scan_{md:.3f}_start.gpx")
    project = G2sc.G2Project(gpxfile=str(BASE), newgpx=str(start))
    histogram = project.histogram(0)
    texture = project.phase("calcite_CaCO3").data["Histograms"][histogram.name][
        "Pref.Ori."
    ]
    texture[0] = "MD"
    texture[1] = md
    texture[2] = False
    texture[3] = [1, 0, 4]
    project.set_Controls("cycles", 1)
    project.save()

    accepted = None
    best = float("inf")
    for iteration in range(5):
        source = accepted or start
        trial = Path(f".tmp/md_scan_{md:.3f}_{iteration}.gpx")
        project = G2sc.G2Project(gpxfile=str(source), newgpx=str(trial))
        project.set_Controls("cycles", 1)
        project.save()
        project.do_refinements([{}])
        project.save()
        chi, rwp = values(trial)
        print("SCAN", md, iteration, chi, rwp, flush=True)
        if accepted is None or chi < best - 0.01:
            accepted = trial
            best = chi
        else:
            break

    final = Path(f".tmp/md_scan_{md:.3f}_best.gpx")
    shutil.copyfile(accepted, final)
    project = G2sc.G2Project(gpxfile=str(final))
    print(
        "BEST",
        md,
        *values(final),
        {key: val[0] for key, val in project.histogram(0).ComputeMassFracs().items()},
        flush=True,
    )
