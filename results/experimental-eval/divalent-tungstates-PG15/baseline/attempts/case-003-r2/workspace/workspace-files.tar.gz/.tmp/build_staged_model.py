import json
import os
import shutil

import GSASIIscriptable as G2sc


WORK = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
TMP = os.path.join(WORK, ".tmp")
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"


def cif_path(cod_id):
    return f"{COD}/{cod_id[0]}/{cod_id[1:3]}/{cod_id[3:5]}/{cod_id}.cif"


def rvals(path):
    project = G2sc.G2Project(path)
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine_stage(current, stage_index, stage_name, configure, max_iterations=8):
    configured = os.path.join(TMP, f"staged_{stage_index:02d}_{stage_name}_start.gpx")
    project = G2sc.G2Project(current, newgpx=configured)
    configure(project)
    project.set_Controls("cycles", 1)
    project.save()

    previous = rvals(current).get("chisq", float("inf"))
    accepted = configured
    best = previous
    for iteration in range(max_iterations):
        trial = os.path.join(TMP, f"staged_{stage_index:02d}_{stage_name}_{iteration}.gpx")
        project = G2sc.G2Project(accepted, newgpx=trial)
        project.set_Controls("cycles", 1)
        project.save()
        project.do_refinements([{}])
        project.save()
        fit = project.data["Covariance"]["data"]["Rvals"]
        chi = fit["chisq"]
        print(
            "STAGE",
            stage_name,
            iteration,
            "chisq",
            chi,
            "Rwp",
            fit["Rwp"],
            "delta",
            fit.get("DelChi2"),
            "max_shift_esd",
            fit.get("Max shft/sig"),
            flush=True,
        )
        if chi < best - max(0.01, 1e-7 * chi):
            accepted = trial
            best = chi
        else:
            break
    if accepted == configured:
        # The first refinement is required for a newly constructed project.
        accepted = trial
    return accepted


initial = os.path.join(TMP, "staged_initial.gpx")
project = G2sc.G2Project(newgpx=initial)
hist = project.add_powder_histogram(
    os.path.join(TMP, "pattern.xye"), os.path.join(TMP, "cu_kalpha12.instprm")
)
phase_specs = [
    ("monoclinic_WO3", "2311041"),
    ("calcite_CaCO3", "1547347"),
    ("scheelite_CaWO4", "7219229"),
]
for name, cod_id in phase_specs:
    phase = project.add_phase(cif_path(cod_id), phasename=name, histograms=[hist], fmthint="CIF")
    phase.HAPvalue("Scale", 1e-7)
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0 if name != "scheelite_CaWO4" else 0.05
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]

hist.SampleParameters["Scale"] = [1.0, False]
hist.SampleParameters["Shift"][0] = -520.0
hist.InstrumentParameters["U"][1] = 10.0
hist.InstrumentParameters["V"][1] = -5.0
hist.InstrumentParameters["W"][1] = 100.0
hist.Background[0] = ["chebyschev-1", False, 12] + [1000.0] + [0.0] * 11
project.save()


def set_background(p):
    p.set_refinement({"set": {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12}}})


def set_scales(p):
    p.set_refinement({"set": {"Scale": True}})


def set_shift(p):
    p.set_refinement({"set": {"Sample Parameters": ["Shift"]}})


def set_cells(p):
    p.set_refinement({"set": {"Cell": True}})


def set_w(p):
    p.set_refinement({"set": {"Instrument Parameters": ["W"]}})


def set_uvw(p):
    p.set_refinement({"set": {"Instrument Parameters": ["U", "V", "W"]}})


def set_xy(p):
    p.set_refinement({"set": {"Instrument Parameters": ["X", "Y"]}})


def set_calcite_texture(p):
    hist = p.histogram(0)
    po = p.phase("calcite_CaCO3").data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = [1, 0, 4]


def set_cawo4_size(p):
    hist = p.histogram(0)
    phase = p.phase("scheelite_CaWO4")
    phase.data["Histograms"][hist.name]["Size"][2][0] = True
    p.update_ids()
    p.save()
    p.set_Controls("parmMin", 0.005, variable=f"{phase.id}:{hist.id}:Size;i")
    p.set_Controls("parmMax", 10.0, variable=f"{phase.id}:{hist.id}:Size;i")


stages = [
    ("background", set_background),
    ("scales", set_scales),
    ("shift", set_shift),
    ("cells", set_cells),
    ("W", set_w),
    ("UVW", set_uvw),
    ("XY", set_xy),
    ("calcite_texture", set_calcite_texture),
    ("cawo4_size", set_cawo4_size),
]

current = initial
for index, (name, configure) in enumerate(stages, start=1):
    current = refine_stage(current, index, name, configure)

final_path = os.path.join(TMP, "staged_best.gpx")
shutil.copyfile(current, final_path)
project = G2sc.G2Project(final_path)
hist = project.histogram(0)
summary = {
    "project": final_path,
    "fit": project.data["Covariance"]["data"]["Rvals"],
    "mass_fractions": hist.ComputeMassFracs(),
    "shift": hist.SampleParameters["Shift"],
    "instrument": {key: hist.InstrumentParameters[key] for key in ["U", "V", "W", "X", "Y"]},
    "phases": {
        phase.name: {
            "cell": phase.get_cell(),
            "scale": phase.HAPvalue("Scale"),
            "size": phase.getHAPvalues(hist)["Size"],
            "preferred_orientation": phase.getHAPvalues(hist)["Pref.Ori."],
        }
        for phase in project.phases()
    },
}
print("STAGED_RESULT", json.dumps(summary, sort_keys=True), flush=True)
