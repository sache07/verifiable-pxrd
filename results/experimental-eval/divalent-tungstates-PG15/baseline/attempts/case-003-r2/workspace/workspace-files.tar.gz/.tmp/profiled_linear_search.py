import json
from pathlib import Path

import numpy as np
from scipy.optimize import lsq_linear
from GSASII import GSASIIscriptable as G2sc


SOURCE = Path(".tmp/staged_08_calcite_texture_0.gpx")
PHASES = ("monoclinic_WO3", "calcite_CaCO3", "scheelite_CaWO4")
N_BACKGROUND = 12
counter = 0


source_project = G2sc.G2Project(gpxfile=str(SOURCE))
source_histogram = source_project.histogram(0)
x, observed, weight = [
    np.asarray(source_histogram.data["data"][1][index], dtype=float)
    for index in (0, 1, 2)
]


def calculated_column(md, size, phase_name=None, background_index=None):
    global counter
    counter += 1
    target = Path(f".tmp/design_{counter:03d}.gpx")
    project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(target))
    histogram = project.histogram(0)

    texture = project.phase("calcite_CaCO3").data["Histograms"][histogram.name][
        "Pref.Ori."
    ]
    texture[1] = float(md)
    texture[2] = False
    size_terms = project.phase("scheelite_CaWO4").data["Histograms"][
        histogram.name
    ]["Size"]
    size_terms[1][0] = float(size)
    size_terms[2][0] = False

    for phase in project.phases():
        phase.data["Histograms"][histogram.name]["Scale"] = [0.0, False]
    if phase_name is not None:
        project.phase(phase_name).data["Histograms"][histogram.name]["Scale"][0] = 1.0

    background = histogram.data["Background"][0]
    background[1] = False
    background[2] = N_BACKGROUND
    background[3:] = [0.0] * N_BACKGROUND
    if background_index is not None:
        background[3 + background_index] = 1.0

    project.set_Controls("cycles", 0)
    project.save()
    project.do_refinements([{}])
    project.save()
    return np.asarray(histogram.data["data"][1][3], dtype=float).copy()


offset = calculated_column(0.84, 0.0492)
print("OFFSET_MAX", float(np.max(np.abs(offset))), flush=True)
background_columns = [
    calculated_column(0.84, 0.0492, background_index=index) - offset
    for index in range(N_BACKGROUND)
]
wo3_column = calculated_column(0.84, 0.0492, phase_name="monoclinic_WO3") - offset


def solve(calcite_column, cawo4_column):
    design = np.column_stack(
        [wo3_column, calcite_column, cawo4_column, *background_columns]
    )
    root_weight = np.sqrt(weight)
    weighted_design = design * root_weight[:, None]
    weighted_observed = (observed - offset) * root_weight
    lower = np.array([0.0, 0.0, 0.0] + [-np.inf] * N_BACKGROUND)
    upper = np.full(3 + N_BACKGROUND, np.inf)
    fit = lsq_linear(
        weighted_design,
        weighted_observed,
        bounds=(lower, upper),
        method="bvls",
        tol=1e-12,
        max_iter=1000,
    )
    calculated = offset + design @ fit.x
    chi = float(np.sum(weight * (observed - calculated) ** 2))
    return chi, fit.x, calculated


fixed_size = 0.0492
cawo4_fixed = (
    calculated_column(0.84, fixed_size, phase_name="scheelite_CaWO4") - offset
)


def scan_md(values, cawo4_column, tag):
    trials = []
    for md in values:
        calcite = calculated_column(
            float(md), fixed_size, phase_name="calcite_CaCO3"
        ) - offset
        chi, coefficients, _ = solve(calcite, cawo4_column)
        trials.append((chi, float(md), coefficients, calcite))
        print("MD_SCAN", tag, float(md), chi, coefficients[:3].tolist(), flush=True)
    return min(trials, key=lambda item: item[0])


coarse_md = np.arange(0.65, 1.0001, 0.025)
best_chi, best_md, best_coefficients, best_calcite = scan_md(
    coarse_md, cawo4_fixed, "coarse"
)
fine_md = np.arange(best_md - 0.025, best_md + 0.0251, 0.005)
best_chi, best_md, best_coefficients, best_calcite = scan_md(
    fine_md, cawo4_fixed, "fine"
)


def scan_size(values, calcite_column, tag):
    trials = []
    for size in values:
        cawo4 = calculated_column(
            best_md, float(size), phase_name="scheelite_CaWO4"
        ) - offset
        chi, coefficients, _ = solve(calcite_column, cawo4)
        trials.append((chi, float(size), coefficients, cawo4))
        print("SIZE_SCAN", tag, float(size), chi, coefficients[:3].tolist(), flush=True)
    return min(trials, key=lambda item: item[0])


coarse_size = np.arange(0.035, 0.0801, 0.003)
best_chi, best_size, best_coefficients, best_cawo4 = scan_size(
    coarse_size, best_calcite, "coarse"
)
fine_size = np.arange(best_size - 0.003, best_size + 0.0031, 0.0005)
best_chi, best_size, best_coefficients, best_cawo4 = scan_size(
    fine_size, best_calcite, "fine"
)

# Re-profile texture once at the selected CaWO4 size.
refined_md = np.arange(best_md - 0.015, best_md + 0.0151, 0.0025)
best_chi, best_md, best_coefficients, best_calcite = scan_md(
    refined_md, best_cawo4, "final"
)
best_chi, best_coefficients, calculated = solve(best_calcite, best_cawo4)

output = Path(".tmp/profiled_best.gpx")
project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(output))
histogram = project.histogram(0)
texture = project.phase("calcite_CaCO3").data["Histograms"][histogram.name][
    "Pref.Ori."
]
texture[1] = best_md
texture[2] = False
size_terms = project.phase("scheelite_CaWO4").data["Histograms"][histogram.name][
    "Size"
]
size_terms[1][0] = best_size
size_terms[2][0] = False
for phase_name, scale in zip(PHASES, best_coefficients[:3]):
    project.phase(phase_name).data["Histograms"][histogram.name]["Scale"] = [
        float(scale),
        True,
    ]
background = histogram.data["Background"][0]
background[1] = True
background[2] = N_BACKGROUND
background[3:] = [float(value) for value in best_coefficients[3:]]
project.set_Controls("cycles", 0)
project.save()
project.do_refinements([{}])
project.save()

arrays = histogram.data["data"][1]
exact_chi = float(np.sum(arrays[2] * (arrays[1] - arrays[3]) ** 2))
masses = {
    phase.name: phase.data["General"]["Mass"] * best_coefficients[index]
    for index, phase in enumerate(project.phases())
}
mass_sum = sum(masses.values())
fractions = {key: value / mass_sum for key, value in masses.items()}
summary = {
    "project": str(output),
    "chi_squared_profiled": best_chi,
    "chi_squared_exact_gsasii": exact_chi,
    "Rwp_percent": histogram.data["data"][0]["wR"],
    "calcite_MD_104": best_md,
    "CaWO4_size_micrometre": best_size,
    "scales": {
        phase_name: float(value)
        for phase_name, value in zip(PHASES, best_coefficients[:3])
    },
    "weight_fractions": fractions,
    "background_coefficients": [float(value) for value in best_coefficients[3:]],
}
print("PROFILED_FINAL", json.dumps(summary, sort_keys=True), flush=True)
