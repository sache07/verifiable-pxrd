import json
import os
import sys

import GSASIIscriptable as G2sc


mode = sys.argv[1]
work = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
output = os.path.join(work, ".tmp", f"broadening_{mode}.gpx")
project = G2sc.G2Project(os.path.join(work, ".tmp", "po_calcite.gpx"), newgpx=output)
hist = project.histogram(0)

# The instrumental line shape has already been fit. Hold it while estimating
# phase-specific broadening to avoid exchanging width arbitrarily between terms.
hist.clear_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
for phase in project.phases():
    if mode in ("size", "both"):
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    if mode in ("strain", "both"):
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})

project.set_Controls("cycles", 20)
project.save()
project.do_refinements([{}])
project.save()
rvals = project.data["Covariance"]["data"]["Rvals"]
print(
    "BROADENING_RESULT",
    json.dumps(
        {
            "mode": mode,
            "Rwp": rvals["Rwp"],
            "chisq": rvals["chisq"],
            "GOF": rvals["GOF"],
            "mass": hist.ComputeMassFracs(),
            "hap": {
                phase.name: {
                    "Size": phase.getHAPvalues(hist)["Size"],
                    "Mustrain": phase.getHAPvalues(hist)["Mustrain"],
                }
                for phase in project.phases()
            },
        },
        sort_keys=True,
    ),
)
