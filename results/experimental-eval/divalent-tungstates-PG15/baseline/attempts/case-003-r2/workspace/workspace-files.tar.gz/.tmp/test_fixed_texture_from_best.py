from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


for md in (0.84, 0.85, 0.86, 0.8617099194099783, 0.87):
    target = Path(f".tmp/fixed_from_best_{md:.6f}.gpx")
    project = G2sc.G2Project(
        gpxfile=".tmp/staged_08_calcite_texture_0.gpx", newgpx=str(target)
    )
    histogram = project.histogram(0)
    texture = project.phase("calcite_CaCO3").data["Histograms"][histogram.name][
        "Pref.Ori."
    ]
    texture[1] = md
    texture[2] = False
    project.set_Controls("cycles", 1)
    project.save()
    project.do_refinements([{}])
    project.save()
    fit = project.data["Covariance"]["data"]["Rvals"]
    print(
        "FIXED",
        md,
        fit["chisq"],
        fit["Rwp"],
        fit.get("DelChi2"),
        fit.get("Max shft/sig"),
        {k: v[0] for k, v in histogram.ComputeMassFracs().items()},
        flush=True,
    )
