import json
import os
import traceback

import GSASIIscriptable as G2sc


WORK = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"


def cif_path(cod_id):
    return f"{COD}/{cod_id[0]}/{cod_id[1:3]}/{cod_id[3:5]}/{cod_id}.cif"


def refine_candidate(tag, tungsten_id, calcite_id="1547347", cawo4_id="7219229"):
    project_path = os.path.join(WORK, ".tmp", f"screen_{tag}.gpx")
    project = G2sc.G2Project(newgpx=project_path)
    hist = project.add_powder_histogram(
        os.path.join(WORK, ".tmp", "pattern.xye"),
        os.path.join(WORK, ".tmp", "cu_kalpha12.instprm"),
    )
    phases = [
        project.add_phase(cif_path(tungsten_id), phasename=f"W_phase_{tungsten_id}", histograms=[hist], fmthint="CIF"),
        project.add_phase(cif_path(calcite_id), phasename="calcite_CaCO3", histograms=[hist], fmthint="CIF"),
        project.add_phase(cif_path(cawo4_id), phasename="scheelite_CaWO4", histograms=[hist], fmthint="CIF"),
    ]
    hist.InstrumentParameters["U"][1] = 10.0
    hist.InstrumentParameters["V"][1] = -5.0
    hist.InstrumentParameters["W"][1] = 100.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][0] = -520.0
    hist.Background[0] = ["chebyschev-1", False, 12] + [1000.0] + [0.0] * 11
    for phase in phases:
        phase.HAPvalue("Scale", 1e-7)
    project.set_Controls("cycles", 12)
    project.save()
    steps = [
        {"set": {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12}}},
        {"set": {"Scale": True}},
        {"set": {"Sample Parameters": ["Shift"]}},
        {"set": {"Cell": True}},
        {"set": {"Instrument Parameters": ["U", "V", "W"]}},
        {"set": {"Instrument Parameters": ["X", "Y"]}},
    ]
    for step in steps:
        project.do_refinements([step])
    project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "tag": tag,
        "tungsten_id": tungsten_id,
        "Rwp": rvals["Rwp"],
        "GOF": rvals["GOF"],
        "chisq": rvals["chisq"],
        "mass_fractions": {name: vals[0] for name, vals in hist.ComputeMassFracs().items()},
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "project": project_path,
    }


candidates = [
    ("wo3_2311041", "2311041"),
    ("wo3_1528915", "1528915"),
    ("wo3_2106293", "2106293"),
    ("wo3_1010618", "1010618"),
    ("wo3_2107312", "2107312"),
    ("wo3_1563541", "1563541"),
    ("w18o49_1528166", "1528166"),
    ("w10o29_1538317", "1538317"),
]

results = []
for tag, cod_id in candidates:
    print(f"\n######## {tag} ########", flush=True)
    try:
        result = refine_candidate(tag, cod_id)
        results.append(result)
        print("RESULT", json.dumps(result, sort_keys=True), flush=True)
    except Exception as exc:
        traceback.print_exc()
        results.append({"tag": tag, "tungsten_id": cod_id, "error": repr(exc)})

with open(os.path.join(WORK, ".tmp", "screen_models.json"), "w") as stream:
    json.dump(results, stream, indent=2)
