from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE = Path(".tmp/staged_08_calcite_texture_0.gpx")

for index in range(23):
    size = 0.030 + index * 0.0025
    target = Path(f".tmp/size_objective_{size:.4f}.gpx")
    project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(target))
    histogram = project.histogram(0)
    texture = project.phase("calcite_CaCO3").data["Histograms"][histogram.name][
        "Pref.Ori."
    ]
    texture[1] = 0.84
    texture[2] = False
    size_terms = project.phase("scheelite_CaWO4").data["Histograms"][
        histogram.name
    ]["Size"]
    size_terms[1][0] = size
    size_terms[2][0] = False
    project.set_Controls("cycles", 0)
    project.save()
    project.do_refinements([{}])
    project.save()
    arrays = histogram.data["data"][1]
    chisq = float(np.sum(arrays[2] * (arrays[1] - arrays[3]) ** 2))
    print("SIZE_OBJECTIVE", size, chisq, histogram.data["data"][0]["wR"], flush=True)
