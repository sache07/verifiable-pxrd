import numpy as np
from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(
    gpxfile=".tmp/profiled_best.gpx", newgpx=".tmp/final_covariance_test.gpx"
)
histogram = project.histogram(0)
histogram.clear_refinements({"Background": True})
histogram.clear_refinements({"Sample Parameters": ["Shift"]})
histogram.clear_refinements(
    {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}
)
histogram.set_refinements({"Background": True})
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements(
        {"Scale": True, "Pref.Ori.": True, "Size": True, "Mustrain": True}
    )
    phase.set_HAP_refinements({"Scale": True})
project.set_Controls("cycles", 1)
project.save()
before = histogram.data["data"][1]
before_chi = float(np.sum(before[2] * (before[1] - before[3]) ** 2))
project.do_refinements([{}])
project.save()
after = histogram.data["data"][1]
after_chi = float(np.sum(after[2] * (after[1] - after[3]) ** 2))
print("COVARIANCE_TEST", before_chi, after_chi)
print(project.data["Covariance"]["data"].get("Rvals"))
print(histogram.ComputeMassFracs())
