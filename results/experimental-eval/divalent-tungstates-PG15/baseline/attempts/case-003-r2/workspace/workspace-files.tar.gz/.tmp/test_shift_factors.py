from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SOURCE = Path(".tmp/staged_08_calcite_texture_0.gpx")

for shift_factor in (0.05, 0.1, 0.2, 0.3, 0.5, 0.75):
    target = Path(f".tmp/shift_factor_{shift_factor:.2f}.gpx")
    project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(target))
    project.data["Controls"]["data"]["shift factor"] = shift_factor
    project.set_Controls("cycles", 1)
    project.save()
    project.do_refinements([{}])
    project.save()
    values = project.data["Covariance"]["data"]["Rvals"]
    histogram = project.histogram(0)
    fractions = {
        key: value[0] for key, value in histogram.ComputeMassFracs().items()
    }
    texture = project.phase("calcite_CaCO3").data["Histograms"][histogram.name][
        "Pref.Ori."
    ][1]
    print(
        shift_factor,
        values["chisq"],
        values["Rwp"],
        values.get("Max shft/sig"),
        texture,
        fractions,
        flush=True,
    )
