from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE = Path(".tmp/staged_08_calcite_texture_0.gpx")


def evaluate(label, md, size):
    target = Path(f".tmp/fine_{label}.gpx")
    project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(target))
    histogram = project.histogram(0)
    texture = project.phase("calcite_CaCO3").data["Histograms"][histogram.name][
        "Pref.Ori."
    ]
    texture[1] = md
    texture[2] = False
    size_terms = project.phase("scheelite_CaWO4").data["Histograms"][
        histogram.name
    ]["Size"]
    size_terms[1][0] = size
    size_terms[2][0] = False
    project.set_Controls("cycles", 0)
    project.save()
    project.do_refinements([{}])
    project.save()
    arrays = histogram.data["data"][1]
    chisq = float(np.sum(arrays[2] * (arrays[1] - arrays[3]) ** 2))
    print("FINE", label, md, size, chisq, histogram.data["data"][0]["wR"], flush=True)


for md in np.arange(0.838, 0.845, 0.001):
    evaluate(f"md_{md:.3f}", float(md), 0.0493)
for size in np.arange(0.0486, 0.0501, 0.0002):
    evaluate(f"size_{size:.4f}", 0.841, float(size))
