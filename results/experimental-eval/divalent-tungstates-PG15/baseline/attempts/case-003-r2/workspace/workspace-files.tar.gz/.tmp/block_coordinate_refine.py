import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE = Path(".tmp/staged_08_calcite_texture_0.gpx")
START = Path(".tmp/block_00_start.gpx")


def objective(project):
    arrays = project.histogram(0).data["data"][1]
    return float(np.sum(arrays[2] * (arrays[1] - arrays[3]) ** 2))


def clear_flags(project):
    histogram = project.histogram(0)
    histogram.clear_refinements(
        {
            "Background": True,
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["U", "V", "W", "X", "Y"],
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Scale": True, "Pref.Ori.": True, "Size": True, "Mustrain": True}
        )


def configure(project, block):
    clear_flags(project)
    histogram = project.histogram(0)
    if "background" in block:
        histogram.set_refinements({"Background": True})
    if "shift" in block:
        histogram.set_refinements({"Sample Parameters": ["Shift"]})
    instrument = [key for key in ("U", "V", "W", "X", "Y") if key in block]
    if instrument:
        histogram.set_refinements({"Instrument Parameters": instrument})
    if "cells" in block:
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
    if "scales" in block:
        for phase in project.phases():
            phase.set_HAP_refinements({"Scale": True})
    if "texture" in block:
        project.phase("calcite_CaCO3").set_HAP_refinements({"Pref.Ori.": True})
    if "size" in block:
        project.phase("scheelite_CaWO4").set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}
        )


def run_block(current, index, label, block, max_iterations=6):
    configured = Path(f".tmp/block_{index:02d}_{label}_configured.gpx")
    project = G2sc.G2Project(gpxfile=str(current), newgpx=str(configured))
    configure(project, block)
    project.set_Controls("cycles", 1)
    project.save()
    best = objective(project)
    accepted = configured
    print("BLOCK_START", index, label, best, flush=True)
    for iteration in range(max_iterations):
        trial = Path(f".tmp/block_{index:02d}_{label}_{iteration}.gpx")
        project = G2sc.G2Project(gpxfile=str(accepted), newgpx=str(trial))
        project.set_Controls("cycles", 1)
        project.save()
        project.do_refinements([{}])
        project.save()
        chi = objective(project)
        print("BLOCK_TRIAL", index, label, iteration, chi, flush=True)
        if chi < best - 0.01:
            accepted = trial
            best = chi
        else:
            break
    selected = Path(f".tmp/block_{index:02d}_{label}_best.gpx")
    shutil.copyfile(accepted, selected)
    return selected


# Recalculate the starting profile at the one-dimensional texture minimum.
project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(START))
histogram = project.histogram(0)
texture = project.phase("calcite_CaCO3").data["Histograms"][histogram.name][
    "Pref.Ori."
]
texture[1] = 0.84
texture[2] = False
clear_flags(project)
project.set_Controls("cycles", 0)
project.save()
project.do_refinements([{}])
project.save()
print("RECALCULATED_START", objective(project), flush=True)

stages = [
    ("background_scales", {"background", "scales"}),
    ("texture", {"texture"}),
    ("scales", {"scales"}),
    ("cells_shift", {"cells", "shift"}),
    ("background_scales_2", {"background", "scales"}),
    ("W", {"W"}),
    ("UVW", {"U", "V", "W"}),
    ("XY", {"X", "Y"}),
    ("size", {"size"}),
    ("scales_2", {"scales"}),
    ("texture_2", {"texture"}),
    ("background_scales_3", {"background", "scales"}),
    ("cells_shift_2", {"cells", "shift"}),
    ("profile", {"U", "V", "W", "X", "Y"}),
    ("texture_3", {"texture"}),
    ("background_scales_final", {"background", "scales"}),
]

current = START
for index, (label, block) in enumerate(stages, start=1):
    current = run_block(current, index, label, block)

FINAL = Path(".tmp/block_final.gpx")
shutil.copyfile(current, FINAL)
project = G2sc.G2Project(gpxfile=str(FINAL))
histogram = project.histogram(0)
fractions = histogram.ComputeMassFracs()
print(
    "FINAL",
    objective(project),
    histogram.data["data"][0],
    fractions,
    "texture",
    project.phase("calcite_CaCO3").data["Histograms"][histogram.name][
        "Pref.Ori."
    ],
    "size",
    project.phase("scheelite_CaWO4").data["Histograms"][histogram.name]["Size"],
    flush=True,
)
