import json
import os
import sys

import GSASIIscriptable as G2sc


phase_name = sys.argv[1]
axis = [int(value) for value in sys.argv[2:5]]
tag = "_".join(str(value).replace("-", "m") for value in axis)
work = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
output = os.path.join(work, ".tmp", f"po_test_{phase_name}_{tag}.gpx")

project = G2sc.G2Project(os.path.join(work, ".tmp", "po_calcite.gpx"), newgpx=output)
hist = project.histogram(0)
hist.clear_refinements(
    {
        "Background": True,
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L", "Zero"],
    }
)
for phase in project.phases():
    phase.clear_refinements({"Cell": False})
    phase.clear_HAP_refinements({"Scale": False, "Pref.Ori.": False})

phase = project.phase(phase_name)
po = phase.data["Histograms"][hist.name]["Pref.Ori."]
po[0] = "MD"
po[1] = 1.0
po[2] = True
po[3] = axis
project.set_Controls("cycles", 12)
project.save()
project.do_refinements([{}])
project.save()
rvals = project.data["Covariance"]["data"]["Rvals"]
print(
    "PO_RESULT",
    json.dumps(
        {
            "phase": phase_name,
            "axis": axis,
            "MD": po[1],
            "Rwp": rvals["Rwp"],
            "chisq": rvals["chisq"],
            "GOF": rvals["GOF"],
        },
        sort_keys=True,
    ),
)
