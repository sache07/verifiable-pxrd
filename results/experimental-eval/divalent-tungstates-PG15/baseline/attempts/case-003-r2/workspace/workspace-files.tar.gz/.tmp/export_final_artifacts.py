import csv
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SOURCE = Path(".tmp/final_covariance_test.gpx")
PROJECT = Path("final.gpx")
CIF_PATHS = {
    "monoclinic_WO3": Path("phase_1_WO3_monoclinic.cif"),
    "calcite_CaCO3": Path("phase_2_CaCO3_calcite.cif"),
    "scheelite_CaWO4": Path("phase_3_CaWO4_scheelite.cif"),
}

project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(PROJECT))
project.save()

for phase_name, output in CIF_PATHS.items():
    project.phase(phase_name).export_CIF(str(output), quickmode=True)

histogram = project.histogram(0)
x, observed, _weight, calculated, background, difference = histogram.data["data"][1]
with Path("fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "difference_intensity",
            "background_intensity",
        ]
    )
    writer.writerows(zip(x, observed, calculated, difference, background))

print("PROJECT", PROJECT.resolve())
for phase_name, output in CIF_PATHS.items():
    print("CIF", phase_name, output.resolve())
print("FIT", Path("fit.csv").resolve(), len(x))
