from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SOURCE = Path(".tmp/staged_08_calcite_texture_0.gpx")

for index in range(25):
    md = 0.78 + index * 0.005
    target = Path(f".tmp/md_objective_{md:.3f}.gpx")
    project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(target))
    histogram = project.histogram(0)
    texture = project.phase("calcite_CaCO3").data["Histograms"][histogram.name][
        "Pref.Ori."
    ]
    texture[1] = md
    texture[2] = False
    project.set_Controls("cycles", 0)
    project.save()
    project.do_refinements([{}])
    project.save()
    arrays = histogram.data["data"][1]
    residuals = histogram.data["data"][0]
    chisq = float(((arrays[1] - arrays[3]) ** 2 * arrays[2]).sum())
    fractions = {}
    denominator = 0.0
    for phase in project.phases():
        scale = phase.data["Histograms"][histogram.name]["Scale"][0]
        product = scale * phase.data["General"]["Mass"]
        fractions[phase.name] = product
        denominator += product
    fractions = {key: val / denominator for key, val in fractions.items()}
    print("OBJECTIVE", md, chisq, residuals["wR"], fractions, flush=True)
