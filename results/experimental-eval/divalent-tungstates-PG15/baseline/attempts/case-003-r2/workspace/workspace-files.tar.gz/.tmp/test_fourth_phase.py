import json
import os
import sys

import GSASIIscriptable as G2sc


cod_id = sys.argv[1]
phase_name = sys.argv[2]
work = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
cod_root = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"
cif = f"{cod_root}/{cod_id[0]}/{cod_id[1:3]}/{cod_id[3:5]}/{cod_id}.cif"
output = os.path.join(work, ".tmp", f"fourth_{phase_name}_{cod_id}.gpx")

project = G2sc.G2Project(os.path.join(work, ".tmp", "po_calcite.gpx"), newgpx=output)
hist = project.histogram(0)

hist.clear_refinements(
    {
        "Background": True,
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L", "Zero"],
    }
)
for phase in project.phases():
    phase.clear_refinements({"Cell": False})
    phase.clear_HAP_refinements({"Scale": False, "Pref.Ori.": False})

candidate = project.add_phase(cif, phasename=phase_name, histograms=[hist], fmthint="CIF")
candidate.HAPvalue("Scale", 0.001)
candidate.set_HAP_refinements({"Scale": True})
project.update_ids()
project.save()
project.set_Controls("parmMin", 0.0, variable=f"{candidate.id}:{hist.id}:Scale")
project.set_Controls("cycles", 8)
project.do_refinements([{}])
project.save()

rvals = project.data["Covariance"]["data"]["Rvals"]
mass = hist.ComputeMassFracs()
print(
    "FOURTH_RESULT",
    json.dumps(
        {
            "cod_id": cod_id,
            "phase": phase_name,
            "scale": candidate.HAPvalue("Scale"),
            "mass_fraction": mass[phase_name][0],
            "mass_fraction_su": mass[phase_name][1],
            "Rwp": rvals["Rwp"],
            "chisq": rvals["chisq"],
            "GOF": rvals["GOF"],
        },
        sort_keys=True,
    ),
)
