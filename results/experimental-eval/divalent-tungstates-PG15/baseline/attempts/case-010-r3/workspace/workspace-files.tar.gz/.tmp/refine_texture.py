#!/usr/bin/env python3
"""Test a low-order spherical-harmonics preferred-orientation correction."""

from pathlib import Path
import json
import sys
import numpy as np

from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()),
                         newgpx=str(Path(sys.argv[2]).resolve()))
project.set_Controls("cycles", 20)
hist = project.histogram(0)
phase = project.phase(0)
order = int(sys.argv[3])
phase.HAPvalue("PO", order, targethistlist=[hist])
phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])

for iteration in range(1, 5):
    np.seterr(all="warn", under="ignore")
    project.do_refinements([{}])
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    record = {
        "iteration": iteration,
        "Rwp": hist.residuals.get("wR"),
        "GOF": rvals.get("GOF"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "preferred_orientation": phase.getHAPvalues(hist.name)["Pref.Ori."],
    }
    print("TEXTURE_RESULT", json.dumps(record, default=float), flush=True)
    if rvals.get("Max shft/sig", 999) < 0.1:
        break
project.save()
