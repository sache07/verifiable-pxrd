#!/usr/bin/env python3
"""Test positive phase-specific isotropic microstrain broadening."""

from pathlib import Path
import json
import sys
import numpy as np

from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()),
                         newgpx=str(Path(sys.argv[2]).resolve()))
project.set_Controls("cycles", 20)
hist = project.histogram(0)
for phase in project.phases():
    phase.setSampleProfile(hist, "microstrain", "isotropic", 500.0)
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])

for iteration in range(1, 5):
    np.seterr(all="warn", under="ignore")
    project.do_refinements([{}])
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    rec = {
        "iteration": iteration,
        "Rwp": hist.residuals.get("wR"),
        "GOF": rvals.get("GOF"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "microstrain": {phase.name: phase.getHAPvalues(hist.name)["Mustrain"]
                        for phase in project.phases()},
        "instrument": {k: hist.InstrumentParameters[k][1]
                       for k in ["U", "V", "W", "X", "Y"]},
    }
    print("MICROSTRAIN_RESULT", json.dumps(rec, default=float), flush=True)
    if rvals.get("Max shft/sig", 999) < 0.1:
        break
project.save()
