#!/usr/bin/env python3
"""Refine one constrained mean isotropic displacement parameter per phase."""

from pathlib import Path
import json
import sys
import numpy as np

from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()),
                         newgpx=str(Path(sys.argv[2]).resolve()))
project.set_Controls("cycles", 20)
hist = project.histogram(0)
fixed_value = float(sys.argv[3]) if len(sys.argv) > 3 else None

for p_index, phase in enumerate(project.phases()):
    variables = []
    for a_index, atom in enumerate(phase.atoms()):
        if atom.adp_flag != "I":
            raise RuntimeError(f"Expected isotropic atom: {phase.name} {atom.label}")
        atom.uiso = fixed_value if fixed_value is not None else 0.005
        atom.refinement_flags = " " if fixed_value is not None else "U"
        variables.append(f"{p_index}::AUiso:{a_index}")
    if fixed_value is None and len(variables) > 1:
        project.add_EquivConstr(variables, reloadIdx=(p_index == 0))

for iteration in range(1, 7):
    np.seterr(all="warn", under="ignore")
    project.do_refinements([{}])
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    rec = {
        "iteration": iteration,
        "Rwp": hist.residuals.get("wR"),
        "GOF": rvals.get("GOF"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "uiso": {phase.name: [atom.uiso for atom in phase.atoms()]
                  for phase in project.phases()},
    }
    print("ADP_RESULT", json.dumps(rec, default=float), flush=True)
    if rvals.get("Max shft/sig", 999) < 0.1:
        break
project.save()
