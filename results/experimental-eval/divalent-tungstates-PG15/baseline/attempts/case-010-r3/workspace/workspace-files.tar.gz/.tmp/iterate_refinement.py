#!/usr/bin/env python3
"""Continue an existing GSAS-II refinement until parameter shifts stabilize."""

from pathlib import Path
import json
import sys
import numpy as np

from GSASII import GSASIIscriptable as G2sc


source = Path(sys.argv[1]).resolve()
target = Path(sys.argv[2]).resolve()
project = G2sc.G2Project(gpxfile=str(source), newgpx=str(target))
project.set_Controls("cycles", 20)

if len(sys.argv) > 3 and sys.argv[3] == "wx-only":
    hist = project.histogram(0)
    for key, value in {"U": 2.0, "V": -2.0, "Y": 0.0}.items():
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False
    for key in ["W", "X"]:
        hist.InstrumentParameters[key][2] = True
if len(sys.argv) > 3 and sys.argv[3] == "polarization":
    project.histogram(0).InstrumentParameters["Polariz."][2] = True
if len(sys.argv) > 3 and sys.argv[3] == "refine-v":
    project.histogram(0).InstrumentParameters["V"][2] = True

for iteration in range(1, 7):
    np.seterr(all="warn", under="ignore")
    project.do_refinements([{}])
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    record = {
        "iteration": iteration,
        "Rwp": hist.residuals.get("wR"),
        "GOF": rvals.get("GOF"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "instrument": {k: hist.InstrumentParameters[k][1]
                       for k in ["U", "V", "W", "X", "Y"]},
        "shift": hist.SampleParameters["Shift"][0],
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }
    print("ITERATION_RESULT", json.dumps(record, default=float), flush=True)
    if rvals.get("Max shft/sig", 999) < 0.1:
        break

project.save()
