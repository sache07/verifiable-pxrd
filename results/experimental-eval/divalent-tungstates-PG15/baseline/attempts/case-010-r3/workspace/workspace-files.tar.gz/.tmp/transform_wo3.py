#!/usr/bin/env python3
"""Put COD 2311041 WO3 in a near-orthogonal monoclinic setting."""

from pathlib import Path
import numpy as np
from pymatgen.core import Structure, Lattice
from pymatgen.io.cif import CifWriter


root = Path(__file__).resolve().parents[1]
source = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif")
structure = Structure.from_file(source)

# a' = -(a+c), b' = b, c' = a; this is a unimodular setting change.
transform = np.array([[-1, 0, -1], [0, 1, 0], [1, 0, 0]], dtype=int)
new_lattice = Lattice(transform @ structure.lattice.matrix)
new_frac = np.asarray(structure.frac_coords) @ np.linalg.inv(transform)
standard = Structure(new_lattice, structure.species, new_frac,
                     site_properties=structure.site_properties,
                     to_unit_cell=True)
CifWriter(standard, symprec=1e-4, refine_struct=False).write_file(root / ".tmp" / "wo3_standard.cif")
print("cell", standard.lattice.abc, standard.lattice.angles, standard.volume)
print("space group", standard.get_space_group_info(symprec=1e-4))
