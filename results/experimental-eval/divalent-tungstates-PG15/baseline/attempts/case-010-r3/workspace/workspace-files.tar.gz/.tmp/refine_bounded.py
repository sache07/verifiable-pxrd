#!/usr/bin/env python3
"""Apply physical parameter bounds and re-refine an existing GSAS-II model."""

from pathlib import Path
import json
import sys
import numpy as np

from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()),
                         newgpx=str(Path(sys.argv[2]).resolve()))
project.set_Controls("cycles", 20)
hist = project.histogram(0)
hist.InstrumentParameters["Polariz."][1] = 0.95
hist.InstrumentParameters["Polariz."][2] = True

for variable in [":0:Polariz."]:
    project.set_Controls("parmMin", 0.0, variable=variable)
    project.set_Controls("parmMax", 1.0, variable=variable)
for variable in [":0:W", ":0:X", "0:0:Mustrain;i", "1:0:Mustrain;i",
                 "0:0:Scale", "1:0:Scale"]:
    project.set_Controls("parmMin", 0.0, variable=variable)

for iteration in range(1, 6):
    np.seterr(all="warn", under="ignore")
    project.do_refinements([{}])
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    rec = {
        "iteration": iteration,
        "Rwp": hist.residuals.get("wR"),
        "GOF": rvals.get("GOF"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "polarization": hist.InstrumentParameters["Polariz."],
        "frozen": project.data["Controls"]["data"].get("parmFrozen"),
    }
    print("BOUNDED_RESULT", json.dumps(rec, default=str), flush=True)
    if rvals.get("Max shft/sig", 999) < 0.1:
        break
project.save()
