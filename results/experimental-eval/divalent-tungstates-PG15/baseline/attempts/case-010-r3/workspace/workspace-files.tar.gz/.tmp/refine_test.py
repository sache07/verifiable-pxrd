#!/usr/bin/env python3
"""Focused, conservative GSAS-II refinements used to compare phase models."""

from pathlib import Path
import json
import sys
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main(ids):
    tag = "_".join(ids)
    out = ROOT / ".tmp" / f"test_{tag}.gpx"
    if out.exists():
        out.unlink()
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / ".tmp" / "pattern.xye"),
        str(ROOT / ".tmp" / "cu_ka.instprm"), fmthint="xye")
    phases = [project.add_phase(str(cod_path(i)), phasename=i,
                                histograms=[hist], fmthint="CIF") for i in ids]
    hist.SampleParameters["Scale"][1] = False
    hist.SampleParameters["Shift"][0] = -250.0
    hist.set_refinements({"Limits": [10.0, 100.0]})
    project.set_Controls("cycles", 10)

    steps = [
        ("scale_background", {"set": {"Background": {
            "type": "chebyschev-1", "refine": True, "no. coeffs": 18},
            "Scale": True}}),
        ("sample_shift", {"set": {"Sample Parameters": ["Shift"]}}),
        ("cell", {"set": {"Cell": True}}),
        ("profile_WX", {"set": {"Instrument Parameters": ["W", "X"]}}),
        ("profile_UY", {"set": {"Instrument Parameters": ["U", "Y"]}}),
    ]
    records = []
    for name, settings in steps:
        np.seterr(all="warn", under="ignore")
        project.do_refinements([settings])
        rec = {
            "step": name,
            "residuals": dict(hist.residuals),
            "shift": hist.SampleParameters["Shift"][0],
            "instrument": {k: hist.InstrumentParameters[k][1]
                           for k in ["U", "V", "W", "X", "Y"]},
            "phases": {p.name: {"cell": p.get_cell(),
                                  "scale": p.HAPvalue("Scale", targethistlist=[hist])}
                       for p in phases},
        }
        records.append(rec)
        print("STEP_RESULT", json.dumps(rec, default=float), flush=True)
    project.save()
    with (ROOT / ".tmp" / f"test_{tag}.json").open("w") as stream:
        json.dump(records, stream, indent=2, default=float)


if __name__ == "__main__":
    main(sys.argv[1:])
