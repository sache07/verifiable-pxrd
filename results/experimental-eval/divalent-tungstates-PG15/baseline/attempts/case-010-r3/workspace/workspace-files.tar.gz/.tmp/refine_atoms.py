#!/usr/bin/env python3
"""Test coordinate refinement from a converged profile/cell model."""

from pathlib import Path
import json
import sys
import numpy as np

from GSASII import GSASIIscriptable as G2sc


source = Path(sys.argv[1]).resolve()
target = Path(sys.argv[2]).resolve()
mode = sys.argv[3]
project = G2sc.G2Project(gpxfile=str(source), newgpx=str(target))
project.set_Controls("cycles", 15)

selected = []
if mode in ("wo3", "both"):
    selected.append(project.phase(0))
if mode in ("mn2o3", "both"):
    selected.append(project.phase(1))
for phase in selected:
    phase.set_refinements({"Atoms": {"all": "X"}})
if mode == "w-only":
    for atom in project.phase(0).atoms():
        atom.refinement_flags = "X" if atom.element == "W" else " "
if mode == "cations":
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "X" if atom.element in ("W", "Mn") else " "

for iteration in range(1, 5):
    np.seterr(all="warn", under="ignore")
    project.do_refinements([{}])
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    record = {
        "iteration": iteration,
        "Rwp": hist.residuals.get("wR"),
        "GOF": rvals.get("GOF"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "coordinates": {phase.name: {atom.label: atom.coordinates
                                      for atom in phase.atoms()}
                        for phase in project.phases()},
    }
    print("ATOM_RESULT", json.dumps(record, default=float), flush=True)
    if rvals.get("Max shft/sig", 999) < 0.1:
        break

project.save()
