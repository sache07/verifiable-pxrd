#!/usr/bin/env python3
"""Run comparable one-phase GSAS-II fits for candidate reference structures."""

from pathlib import Path
import json
import traceback
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
IDS = [
    "1010618", "1528915", "1563541", "2311041", "2106293",
    "1521532", "1521533", "1004057",
]


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def refine_one(cod_id):
    gpx_path = ROOT / ".tmp" / f"screen_{cod_id}.gpx"
    if gpx_path.exists():
        gpx_path.unlink()
    project = G2sc.G2Project(newgpx=str(gpx_path))
    hist = project.add_powder_histogram(
        str(ROOT / ".tmp" / "pattern.xye"),
        str(ROOT / ".tmp" / "cu_ka.instprm"),
        fmthint="xye",
    )
    phase = project.add_phase(
        str(cod_path(cod_id)), phasename=cod_id, histograms=[hist], fmthint="CIF"
    )
    # A histogram scale and all phase scales cannot be varied together.
    hist.SampleParameters["Scale"][1] = False
    hist.set_refinements({"Limits": [10.0, 100.0]})
    project.set_Controls("cycles", 12)

    steps = [
        {"set": {"Background": {"type": "chebyschev-1", "refine": True,
                                  "no. coeffs": 18}, "Scale": True}},
        {"set": {"Cell": True, "Sample Parameters": ["DisplaceX"]}},
        {"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}},
        {"set": {"Size": {"type": "isotropic", "value": 1.0, "refine": True},
                  "Mustrain": {"type": "isotropic", "refine": True}}},
    ]
    history = []
    for n, step in enumerate(steps, 1):
        np.seterr(all="warn", under="ignore")
        project.do_refinements([step])
        history.append({"step": n, "residuals": dict(hist.residuals),
                        "cell": dict(phase.get_cell())})
    project.save()
    return {
        "id": cod_id,
        "formula": phase.data["General"].get("Name", phase.name),
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "cell": phase.get_cell(),
        "residuals": hist.residuals,
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items()
                       if k in ["Zero", "U", "V", "W", "X", "Y", "SH/L"]},
        "sample": {k: v[0] for k, v in hist.SampleParameters.items()
                   if k in ["DisplaceX", "DisplaceY", "Shift", "Transparency"]},
        "hap": phase.getHAPvalues(hist.name),
        "history": history,
    }


results = []
for candidate in IDS:
    print(f"\n===== {candidate} =====", flush=True)
    try:
        result = refine_one(candidate)
        results.append(result)
        print("RESULT", candidate, result["residuals"], result["cell"], flush=True)
    except Exception as exc:
        results.append({"id": candidate, "error": repr(exc)})
        traceback.print_exc()

with (ROOT / ".tmp" / "screen_results.json").open("w") as stream:
    json.dump(results, stream, indent=2, default=str)
