#!/usr/bin/env python3
"""Create, refine, export, and validate the final two-phase GSAS-II model."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
GPX = ROOT / "final.gpx"

PHASES = [
    {
        "name": "gamma-WO3_monoclinic",
        "display_name": "gamma-WO3 (monoclinic)",
        "formula": "WO3",
        "cod_id": "2311041",
        "cif": ROOT / "phase_WO3.cif",
        "space_group": "P 1 21/c 1",
        "space_group_number": 14,
    },
    {
        "name": "alpha-Mn2O3_bixbyite",
        "display_name": "alpha-Mn2O3 (bixbyite)",
        "formula": "Mn2O3",
        "cod_id": "1514230",
        "cif": ROOT / "phase_Mn2O3.cif",
        "space_group": "I a -3",
        "space_group_number": 206,
    },
]


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_xye() -> tuple[float, float, int]:
    """Convert supplied counts to GSAS-II xye with Poisson surrogate sigmas."""
    source = ROOT / "inputs" / "pattern.csv"
    target = TMP / "pattern.xye"
    xmin = math.inf
    xmax = -math.inf
    count = 0
    with source.open(newline="") as src, target.open("w") as dst:
        rows = csv.DictReader(src)
        dst.write("# 2theta intensity sigma; sigma=sqrt(counts)\n")
        for row in rows:
            angle = float(row["two_theta_deg"])
            intensity = float(row["intensity"])
            sigma = math.sqrt(max(intensity, 1.0))
            dst.write(f"{angle:.8f} {intensity:.8f} {sigma:.8f}\n")
            xmin = min(xmin, angle)
            xmax = max(xmax, angle)
            count += 1
    if count == 0:
        raise RuntimeError("No diffraction points found")
    return xmin, xmax, count


def remove_old_outputs() -> None:
    for path in [
        GPX,
        ROOT / "final.bak0.gpx",
        ROOT / "final.lst",
        ROOT / "phase_WO3.cif",
        ROOT / "phase_Mn2O3.cif",
        ROOT / "fit.csv",
        ROOT / "result.json",
        ROOT / "report.md",
    ]:
        if path.exists():
            path.unlink()


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "step": label,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "GOF": rvals.get("GOF"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "fractions": hist.ComputeMassFracs(),
        "sample_shift_um": hist.SampleParameters["Shift"][0],
        "polarization": hist.InstrumentParameters["Polariz."][1],
    }
    print("REFINEMENT", json.dumps(result, default=float), flush=True)
    return result


def run_refinement() -> tuple[G2sc.G2Project, int]:
    xmin, xmax, npoints = prepare_xye()
    remove_old_outputs()

    project = G2sc.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(
        str(TMP / "pattern.xye"),
        str(TMP / "cu_ka.instprm"),
        fmthint="xye",
    )
    phases = []
    for spec in PHASES:
        phases.append(
            project.add_phase(
                str(cod_path(spec["cod_id"])),
                phasename=spec["name"],
                histograms=[hist],
                fmthint="CIF",
            )
        )

    # Absolute histogram scale is redundant with the phase scales.
    hist.SampleParameters["Scale"][1] = False
    hist.SampleParameters["Shift"][0] = -250.0
    hist.set_refinements({"Limits": [xmin, xmax]})

    # The source structures use unlike/legacy ADPs. A common fixed value avoids
    # biasing the scale ratio while leaving coordinates at the literature model.
    for phase in phases:
        for atom in phase.atoms():
            if atom.adp_flag != "I":
                raise RuntimeError(f"Non-isotropic ADP in {phase.name}: {atom.label}")
            atom.uiso = 0.005
            atom.refinement_flags = " "

    project.set_Controls("cycles", 20)
    for variable in [":0:Polariz."]:
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 1.0, variable=variable)
    for variable in [
        ":0:W",
        ":0:X",
        "0:0:Scale",
        "1:0:Scale",
        "0:0:Mustrain;i",
        "1:0:Mustrain;i",
    ]:
        project.set_Controls("parmMin", 0.0, variable=variable)

    steps = [
        (
            "phase scales and background",
            {
                "set": {
                    "Background": {
                        "type": "chebyschev-1",
                        "refine": True,
                        "no. coeffs": 18,
                    },
                    "Scale": True,
                }
            },
        ),
        ("specimen displacement", {"set": {"Sample Parameters": ["Shift"]}}),
        ("unit cells", {"set": {"Cell": True}}),
        ("instrument W and X", {"set": {"Instrument Parameters": ["W", "X"]}}),
    ]
    np.seterr(all="warn", under="ignore")
    for label, controls in steps:
        project.do_refinements([controls])
        snapshot(project, label)

    hist.InstrumentParameters["Polariz."][1] = 0.7
    project.do_refinements([{"set": {"Instrument Parameters": ["Polariz."]}}])
    snapshot(project, "effective polarization")

    for phase in phases:
        phase.setSampleProfile(hist, "microstrain", "isotropic", 500.0)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    project.do_refinements([{}])
    snapshot(project, "phase isotropic microstrain")

    # Repeat all-active least squares until shifts are comfortably converged.
    for iteration in range(1, 9):
        project.do_refinements([{}])
        state = snapshot(project, f"stabilization {iteration}")
        shift = state["max_shift_over_esd"]
        if shift is not None and shift < 0.1:
            break
    else:
        raise RuntimeError("Final least-squares refinement did not stabilize")

    frozen = project.data["Controls"]["data"].get("parmFrozen", {})
    if any(frozen.values()) if isinstance(frozen, dict) else bool(frozen):
        raise RuntimeError(f"GSAS-II froze bounded parameters: {frozen}")

    project.save()
    return project, npoints


def export_outputs(project: G2sc.G2Project, npoints: int) -> dict:
    # Reloading makes this export/summary depend solely on the submitted GPX.
    project = G2sc.G2Project(gpxfile=str(GPX))
    hist = project.histogram(0)
    phases = project.phases()

    for phase, spec in zip(phases, PHASES, strict=True):
        phase.export_CIF(str(spec["cif"]))

    arrays = {
        key: np.asarray(hist.getdata(key), dtype=float)
        for key in ["X", "Yobs", "Ycalc", "Residual", "Background"]
    }
    lengths = {key: len(values) for key, values in arrays.items()}
    if set(lengths.values()) != {npoints}:
        raise RuntimeError(f"Unexpected exported profile lengths: {lengths}")
    if not np.allclose(
        arrays["Residual"], arrays["Yobs"] - arrays["Ycalc"], atol=1e-8, rtol=1e-10
    ):
        raise RuntimeError("GSAS-II residual does not equal observed minus calculated")

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_intensity",
                "background_intensity",
            ]
        )
        writer.writerows(
            zip(
                arrays["X"],
                arrays["Yobs"],
                arrays["Ycalc"],
                arrays["Residual"],
                arrays["Background"],
                strict=True,
            )
        )

    fractions = hist.ComputeMassFracs()
    total = sum(value[0] for value in fractions.values())
    if not math.isclose(total, 1.0, rel_tol=0.0, abs_tol=1e-10):
        raise RuntimeError(f"Mass fractions do not sum to one: {total}")

    rvals = project.data["Covariance"]["data"]["Rvals"]
    phase_results = []
    for phase, spec in zip(phases, PHASES, strict=True):
        cell, cell_esd = phase.get_cell_and_esd()
        fraction, fraction_esd = fractions[phase.name]
        phase_results.append(
            {
                "name": spec["display_name"],
                "formula": spec["formula"],
                "space_group": spec["space_group"],
                "space_group_number": spec["space_group_number"],
                "cif_path": spec["cif"].name,
                "weight_fraction": fraction,
                "weight_fraction_formal_esd": fraction_esd,
                "weight_fraction_estimated_systematic_uncertainty": 0.02,
                "cell": {key: float(value) for key, value in cell.items()},
                "cell_formal_esd": {
                    key: float(value) for key, value in cell_esd.items()
                },
                "reference": f"Crystallography Open Database {spec['cod_id']}",
            }
        )

    result = {
        "phases": phase_results,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": hist.residuals["wR"],
            "Rp_percent": hist.residuals["R"],
            "Rexp_percent": hist.residuals["wRmin"],
            "goodness_of_fit": rvals["GOF"],
            "chi_square": rvals["chisq"],
            "number_of_observations": rvals["Nobs"],
            "number_of_variables": rvals["Nvars"],
            "max_shift_over_esd": rvals["Max shft/sig"],
            "two_theta_range_deg": [
                float(arrays["X"].min()),
                float(arrays["X"].max()),
            ],
            "weighting": "Poisson surrogate sigma=sqrt(counts); no pointwise uncertainties were supplied",
        },
        "refinement": {
            "software": "GSAS-II",
            "project_path": GPX.name,
            "radiation": "Cu K-alpha1/K-alpha2",
            "wavelengths_angstrom": [1.540598, 1.544426],
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "fixed_common_Uiso_angstrom_squared": 0.005,
            "effective_polarization": hist.InstrumentParameters["Polariz."][1],
            "sample_displacement_micrometers": hist.SampleParameters["Shift"][0],
            "instrument_profile": {
                key: hist.InstrumentParameters[key][1]
                for key in ["U", "V", "W", "X", "Y", "SH/L"]
            },
            "phase_isotropic_microstrain_ppm": {
                spec["formula"]: phase.getHAPvalues(hist.name)["Mustrain"][1][0]
                for phase, spec in zip(phases, PHASES, strict=True)
            },
            "atomic_coordinates_refined": False,
        },
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    return result


def write_report(result: dict) -> None:
    wo3, mn2o3 = result["phases"]
    fit = result["fit_statistics"]
    report = f"""# Powder diffraction phase analysis

## Result

The pattern is described by two crystalline phases: monoclinic γ-WO₃ ({100 * wo3['weight_fraction']:.2f} wt%) and cubic bixbyite α-Mn₂O₃ ({100 * mn2o3['weight_fraction']:.2f} wt%). Fractions are normalized only over these modeled crystalline phases. Their formal one-standard-deviation scale-factor uncertainty is about {100 * wo3['weight_fraction_formal_esd']:.2f} wt%, while a more realistic model-dependent uncertainty is approximately 2 wt% absolute for either fraction.

The final Rietveld fit has Rwp = {fit['Rwp_percent']:.3f}%, Rp = {fit['Rp_percent']:.3f}%, Rexp = {fit['Rexp_percent']:.3f}%, and goodness of fit = {fit['goodness_of_fit']:.3f}. The calculated pattern, observed pattern, difference, and background are tabulated in `fit.csv`; the exact GSAS-II model is in `final.gpx`.

## Evidence

The diagnostic γ-WO₃ cluster at approximately 23.43, 23.91, and 24.68° 2θ, together with its split reflections from 33–35°, requires the monoclinic WO₃ model. Reflections near 33.27, 38.53, 49.61, 55.49, and 66.03° are accounted for independently by bixbyite Mn₂O₃. A one-phase WO₃ refinement left these peaks unexplained and gave Rwp near 11%; adding Mn₂O₃ reduced Rwp to about 8% before the final profile treatment and to {fit['Rwp_percent']:.3f}% in the submitted refinement.

Candidate manganese tungstates were tested but rejected: the prominent MnWO₄ doublet near 30–31° and its low-angle line near 18.5° are absent, as are the strongest expected Mn₃WO₆ features near 20–21°. Thus the crystalline material is best interpreted as largely unreacted oxide precursors after the reported 500 °C treatment, with no detectable crystalline manganese tungstate required by the data.

## Structural refinement and uncertainty

Starting structures were COD 2311041 for γ-WO₃ (P2₁/c, No. 14) and COD 1514230 for α-Mn₂O₃ (Ia-3, No. 206). Unit-cell parameters, phase scales, specimen displacement, background, selected profile terms, effective polarization, and one isotropic microstrain term per phase were refined. Atomic coordinates were retained from the references. A common fixed Uiso = 0.005 Å² was used so unlike legacy displacement parameters in the two references could not bias the quantitative scale ratio. The unconventional but valid P2₁/c cell setting of COD 2311041 was retained in the WO₃ CIF.

The structural assignments are strong, but the exact fractions are less certain than their formal covariance errors. No calibrated instrumental profile or pointwise measurement uncertainties were supplied; Poisson counting uncertainties were used, and profile/polarization and common-ADP choices shift the WO₃ fraction by roughly 2 wt%. No microabsorption correction was possible, and any amorphous material is excluded from the normalization. A triclinic WO₃ candidate can mimic the pseudosymmetric peak set, but its freely refined cell angles moved close to 90°, favoring the room-temperature monoclinic assignment; subtle WO₃ polymorph intergrowth cannot be excluded. The refined microstrain values are empirical peak-width terms and should not be interpreted quantitatively without an instrumental standard.
"""
    (ROOT / "report.md").write_text(report)


def validate_outputs(result: dict, npoints: int) -> None:
    required = [
        GPX,
        ROOT / "phase_WO3.cif",
        ROOT / "phase_Mn2O3.cif",
        ROOT / "fit.csv",
        ROOT / "result.json",
        ROOT / "report.md",
    ]
    missing = [str(path) for path in required if not path.is_file() or path.stat().st_size == 0]
    if missing:
        raise RuntimeError(f"Missing/empty outputs: {missing}")
    with (ROOT / "fit.csv").open(newline="") as stream:
        if sum(1 for _ in stream) != npoints + 1:
            raise RuntimeError("fit.csv does not contain every measured point")
    if not math.isclose(
        sum(item["weight_fraction"] for item in result["phases"]),
        1.0,
        rel_tol=0.0,
        abs_tol=1e-10,
    ):
        raise RuntimeError("result.json phase fractions are not normalized")
    for item in result["phases"]:
        if not (ROOT / item["cif_path"]).is_file():
            raise RuntimeError(f"Missing CIF path in result.json: {item['cif_path']}")


def main() -> None:
    project, npoints = run_refinement()
    result = export_outputs(project, npoints)
    write_report(result)
    validate_outputs(result, npoints)
    print("FINAL_RESULT", json.dumps(result, indent=2, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
