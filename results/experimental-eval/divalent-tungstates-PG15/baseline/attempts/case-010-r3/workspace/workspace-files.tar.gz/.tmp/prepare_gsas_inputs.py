#!/usr/bin/env python3
"""Convert the supplied two-column CSV into a GSAS-II xye input."""

from pathlib import Path
import csv
import math


root = Path(__file__).resolve().parents[1]
source = root / "inputs" / "pattern.csv"
target = root / ".tmp" / "pattern.xye"

with source.open(newline="") as src, target.open("w") as dst:
    rows = csv.DictReader(src)
    dst.write("# 2theta intensity sigma; sigma=sqrt(counts)\n")
    for row in rows:
        angle = float(row["two_theta_deg"])
        intensity = float(row["intensity"])
        dst.write(f"{angle:.8f} {intensity:.8f} {math.sqrt(max(intensity, 1.0)):.8f}\n")
