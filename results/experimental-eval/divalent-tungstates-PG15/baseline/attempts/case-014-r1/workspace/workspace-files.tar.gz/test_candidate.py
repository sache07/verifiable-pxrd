"""Test one candidate phase against the residual of the converged SrWO4 fit."""

from pathlib import Path
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
cod_id = sys.argv[1]
name = sys.argv[2]
start_scale = float(sys.argv[3]) if len(sys.argv) > 3 else 1e-4
base_stem = sys.argv[4] if len(sys.argv) > 4 else "SrWO4"
cod = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
cif = cod / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
src = ROOT / ".tmp" / "screens" / f"{base_stem}.gpx"
dst = ROOT / ".tmp" / f"test_{base_stem}_{name}.gpx"

gpx = G2sc.G2Project(str(src), newgpx=str(dst))
gpx.set_Controls("cycles", 8)
hist = gpx.histogram(0)
hist.clear_refinements({
    "Sample Parameters": ["Scale", "Shift"],
    "Instrument Parameters": ["U", "V", "W", "X", "Y"],
    "Background": False,
})
for old in gpx.phases():
    old.clear_refinements({"Cell": False})
    old.clear_HAP_refinements({"Scale": False, "Size": False, "Mustrain": False,
                               "HStrain": False, "Pref.Ori.": False})

phase = gpx.add_phase(str(cif), phasename=name, histograms=[hist])
for atom in phase.atoms():
    if atom.element == "W":
        atom.type = "W+6"
G2sc.SetupGeneral(phase.data, None)
phase.HAPvalue("Scale", start_scale)
phase.set_HAP_refinements({"Scale": True})
phase.clear_refinements({"Cell": False})

def state(label):
    print("STATE", label, "Rwp", hist.get_wR())
    print("mass", hist.ComputeMassFracs())
    print("cell", phase.get_cell())
    print("scale", phase.HAPvalue("Scale"))

state("initial")
gpx.refine()
state("scale")

if phase.HAPvalue("Scale") > 1e-8:
    phase.set_refinements({"Cell": True})
    gpx.refine()
    state("cell")
gpx.save()

a = hist.data["data"][1]
np.savetxt(ROOT / ".tmp" / f"test_{base_stem}_{name}_profile.csv",
           np.array([a[0], a[1], a[3], a[4], a[5]]).T,
           delimiter=",", header="two_theta,y_obs,y_calc,y_bkg,y_diff", comments="")
