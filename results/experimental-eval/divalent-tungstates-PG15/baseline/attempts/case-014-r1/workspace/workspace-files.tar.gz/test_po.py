"""Screen one March-Dollase preferred-orientation axis."""

from pathlib import Path
import json
import sys
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
phase_name = sys.argv[1]
axis = [int(v) for v in sys.argv[2:5]]
tag = phase_name + "_" + "_".join(str(v).replace("-", "m") for v in axis)
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "three_polar.gpx"),
                     newgpx=str(ROOT / ".tmp" / f"po_{tag}.gpx"))
gpx.set_Controls("cycles", 16)
hist = gpx.histogram(0)
phases = {p.name: p for p in gpx.phases()}

hist.clear_refinements({
    "Sample Parameters": ["Scale", "Shift"],
    "Instrument Parameters": ["U", "V", "W", "X", "Y", "Polariz."],
    "Background": False,
})
for phase in phases.values():
    phase.clear_refinements({"Cell": False, "Atoms": [a.label for a in phase.atoms()]})
    phase.clear_HAP_refinements({
        "Scale": False, "Size": False, "Mustrain": False,
        "HStrain": False, "Pref.Ori.": False,
    })

po = phases[phase_name].data["Histograms"][hist.name]["Pref.Ori."]
po[0] = "MD"
po[1] = 1.0
po[2] = True
po[3] = axis

gpx.refine()
print("SUMMARY", json.dumps({
    "phase": phase_name, "axis": axis, "Rwp": hist.get_wR(),
    "MD": po[1], "mass": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
}))
gpx.save()
