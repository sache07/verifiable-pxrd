"""Create a diagnostic Le Bail residual for the identified SrWO4 and WO3 cells."""

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
source = ROOT / ".tmp" / "screens" / "SrWO4+WO3_mono.gpx"
target = ROOT / ".tmp" / "lebail.gpx"
gpx = G2sc.G2Project(str(source), newgpx=str(target))
gpx.set_Controls("cycles", 12)
gpx.data["Controls"]["data"]["newLeBail"] = True
for phase in gpx.phases():
    phase.set_refinements({"LeBail": True})
    phase.clear_refinements({"Cell": False})
    phase.clear_HAP_refinements({"Scale": False})

# Keep background/shift/profile fixed: only extracted reflection intensities change.
hist = gpx.histogram(0)
hist.clear_refinements({
    "Background": False,
    "Sample Parameters": ["Scale", "Shift"],
    "Instrument Parameters": ["U", "V", "W", "X", "Y"],
})
gpx.refine()
gpx.save()
a = hist.data["data"][1]
np.savetxt(
    ROOT / ".tmp" / "lebail_profile.csv",
    np.array([a[0], a[1], a[3], a[4], a[5]]).T,
    delimiter=",",
    header="two_theta,y_obs,y_calc,y_bkg,y_diff",
    comments="",
)
print(hist.residuals)
