from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


gpx = G2sc.G2Project(newgpx=str(ROOT / ".tmp" / "inspect.gpx"))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "cu_ka.instprm"),
    fmthint="comma",
)
phase = gpx.add_phase(str(cod_cif("1546036")), phasename="SrWO4", histograms=[hist])

print("hist", hist.name)
print("limits", hist.data["Limits"])
print("background", hist.data["Background"])
print("sample", hist.data["Sample Parameters"])
print("instrument", hist.data["Instrument Parameters"])
print("phase general", phase.data["General"])
print("HAP", phase.data["Histograms"])
print("residuals", hist.residuals)
gpx.save()
