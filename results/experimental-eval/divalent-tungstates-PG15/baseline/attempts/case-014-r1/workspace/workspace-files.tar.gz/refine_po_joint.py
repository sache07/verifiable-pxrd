"""Joint final-candidate refinement including Sr3W2O9 preferred orientation."""

from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "po_Sr3W2O9_2_0_m4.gpx"),
                     newgpx=str(ROOT / ".tmp" / "final_model_stage.gpx"))
gpx.set_Controls("cycles", 16)
hist = gpx.histogram(0)
phases = {p.name: p for p in gpx.phases()}

def freeze():
    hist.clear_refinements({
        "Sample Parameters": ["Scale", "Shift"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "Polariz."],
        "Background": False,
    })
    for phase in phases.values():
        phase.clear_refinements({"Cell": False, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({
            "Scale": False, "Size": False, "Mustrain": False,
            "HStrain": False, "Pref.Ori.": False,
        })

def report(label):
    po = phases["Sr3W2O9"].data["Histograms"][hist.name]["Pref.Ori."]
    print("SUMMARY", json.dumps({
        "stage": label,
        "Rwp": hist.get_wR(),
        "Rp": hist.residuals.get("R"),
        "mass": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "scales": {p.name: p.HAPvalue("Scale") for p in phases.values()},
        "cells": {p.name: p.get_cell() for p in phases.values()},
        "shift": hist.data["Sample Parameters"]["Shift"][0],
        "polarization": hist.data["Instrument Parameters"][0]["Polariz."][1],
        "MD": po[1], "MD_axis": po[3],
    }))

def run(label, count):
    for i in range(count):
        gpx.refine()
        report(f"{label}_{i + 1}")
        gpx.save()

freeze()
phases["Sr3W2O9"].set_HAP_refinements({"Pref.Ori.": True, "Scale": True})
phases["WO3_mono"].set_HAP_refinements({"Scale": True})
hist.set_refinements({"Instrument Parameters": ["Polariz."]})
hist.set_refinements({"Sample Parameters": ["Scale"]})
hist.set_refinements({"Background": True})
run("intensities", 3)

for phase in phases.values():
    phase.set_refinements({"Cell": True})
hist.set_refinements({"Sample Parameters": ["Shift"]})
run("positions", 3)
