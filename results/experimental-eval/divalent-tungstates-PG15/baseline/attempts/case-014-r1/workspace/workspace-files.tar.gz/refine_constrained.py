"""Constrained final refinement: polarization fixed at its physical upper bound."""

from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "final_refined.gpx"),
                     newgpx=str(ROOT / ".tmp" / "final_constrained.gpx"))
gpx.set_Controls("cycles", 20)
hist = gpx.histogram(0)
phases = {p.name: p for p in gpx.phases()}
inst = hist.data["Instrument Parameters"][0]

hist.clear_refinements({
    "Sample Parameters": ["Scale", "Shift"],
    "Instrument Parameters": ["U", "V", "W", "X", "Y", "Polariz."],
    "Background": False,
})
for phase in phases.values():
    phase.clear_refinements({"Cell": False, "Atoms": [a.label for a in phase.atoms()]})
    phase.clear_HAP_refinements({
        "Scale": False, "Size": False, "Mustrain": False,
        "HStrain": False, "Pref.Ori.": False,
    })

# A polarization fraction above one is nonphysical. Its optimum lies beyond
# this boundary, so fix it at the admissible endpoint.
inst["Polariz."][1] = 1.0
inst["Polariz."][2] = False
inst["X"][0] = inst["X"][1] = 0.0
inst["Y"][0] = inst["Y"][1] = 0.0

phases["Sr3W2O9"].set_HAP_refinements({"Pref.Ori.": True, "Scale": True})
phases["WO3_mono"].set_HAP_refinements({"Scale": True})
for phase in phases.values():
    phase.set_refinements({"Cell": True})
hist.set_refinements({"Sample Parameters": ["Scale", "Shift"]})
hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
hist.set_refinements({"Background": True})

for cycle in range(4):
    gpx.refine()
    theta = np.linspace(5.05, 49.95, 500)
    tangent = np.tan(np.deg2rad(theta))
    sig2 = inst["U"][1] * tangent**2 + inst["V"][1] * tangent + inst["W"][1]
    po = phases["Sr3W2O9"].data["Histograms"][hist.name]["Pref.Ori."]
    print("SUMMARY", json.dumps({
        "cycle": cycle + 1, "Rwp": hist.get_wR(), "Rp": hist.residuals.get("R"),
        "mass": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "cells": {p.name: p.get_cell() for p in phases.values()},
        "shift": hist.data["Sample Parameters"]["Shift"][0],
        "polarization": inst["Polariz."][1], "MD": po[1],
        "profile": {k: inst[k][1] for k in ["U", "V", "W", "X", "Y"]},
        "min_sigma2": float(sig2.min()),
    }))
    gpx.save()
