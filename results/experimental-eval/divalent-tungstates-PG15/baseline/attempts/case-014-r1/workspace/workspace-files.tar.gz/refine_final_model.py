"""Final joint refinement with a positive Gaussian Caglioti profile."""

from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "profile_uvw.gpx"),
                     newgpx=str(ROOT / ".tmp" / "final_refined.gpx"))
gpx.set_Controls("cycles", 16)
hist = gpx.histogram(0)
phases = {p.name: p for p in gpx.phases()}

def freeze():
    hist.clear_refinements({
        "Sample Parameters": ["Scale", "Shift"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "Polariz."],
        "Background": False,
    })
    for phase in phases.values():
        phase.clear_refinements({"Cell": False, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({
            "Scale": False, "Size": False, "Mustrain": False,
            "HStrain": False, "Pref.Ori.": False,
        })

def report(label):
    inst = hist.data["Instrument Parameters"][0]
    theta = np.linspace(5.05, 49.95, 500)
    tangent = np.tan(np.deg2rad(theta))
    sig2 = inst["U"][1] * tangent**2 + inst["V"][1] * tangent + inst["W"][1]
    po = phases["Sr3W2O9"].data["Histograms"][hist.name]["Pref.Ori."]
    print("SUMMARY", json.dumps({
        "stage": label, "Rwp": hist.get_wR(), "Rp": hist.residuals.get("R"),
        "mass": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "cells": {p.name: p.get_cell() for p in phases.values()},
        "shift": hist.data["Sample Parameters"]["Shift"][0],
        "polarization": inst["Polariz."][1], "MD": po[1],
        "profile": {k: inst[k][1] for k in ["U", "V", "W", "X", "Y"]},
        "min_sigma2": float(sig2.min()),
    }))

def run(label, count):
    for i in range(count):
        gpx.refine()
        report(f"{label}_{i + 1}")
        gpx.save()

freeze()
phases["Sr3W2O9"].set_HAP_refinements({"Pref.Ori.": True, "Scale": True})
phases["WO3_mono"].set_HAP_refinements({"Scale": True})
hist.set_refinements({"Instrument Parameters": ["Polariz."]})
hist.set_refinements({"Sample Parameters": ["Scale"]})
hist.set_refinements({"Background": True})
run("intensities", 2)

for phase in phases.values():
    phase.set_refinements({"Cell": True})
hist.set_refinements({"Sample Parameters": ["Shift"]})
run("positions", 2)

# U,V,W are retained only when sigma^2 stays positive over the fitted range.
hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
run("joint_profile", 2)
