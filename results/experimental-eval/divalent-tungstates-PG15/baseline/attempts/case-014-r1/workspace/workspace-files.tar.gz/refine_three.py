"""Joint staged refinement of SrWO4, WO3 and Sr3W2O9."""

from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
src = ROOT / ".tmp" / "three_joint.gpx"
dst = ROOT / ".tmp" / "three_joint2.gpx"

gpx = G2sc.G2Project(str(src), newgpx=str(dst))
gpx.set_Controls("cycles", 16)
hist = gpx.histogram(0)
phases = {p.name: p for p in gpx.phases()}

def freeze_all():
    hist.clear_refinements({
        "Sample Parameters": ["Scale", "Shift"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y"],
        "Background": False,
    })
    for phase in phases.values():
        phase.clear_refinements({"Cell": False, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({
            "Scale": False, "Size": False, "Mustrain": False,
            "HStrain": False, "Pref.Ori.": False,
        })

def summary(label):
    cov = gpx.data.get("Covariance", {}).get("data", {})
    print("SUMMARY", json.dumps({
        "stage": label,
        "Rwp": hist.get_wR(),
        "Rp": hist.residuals.get("R"),
        "Rb": hist.residuals.get("Rb"),
        "last_shift": cov.get("Lastshft"),
        "mass_fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "sample_scale": hist.data["Sample Parameters"]["Scale"][0],
        "shift_microns": hist.data["Sample Parameters"]["Shift"][0],
        "cells": {p.name: p.get_cell() for p in phases.values()},
        "hap_scales": {p.name: p.HAPvalue("Scale") for p in phases.values()},
    }, sort_keys=True, default=lambda value: value.tolist() if hasattr(value, "tolist") else float(value)))

def run(label, repeats=1):
    for i in range(repeats):
        gpx.refine()
        summary(f"{label}_{i + 1}")
        gpx.save()

freeze_all()

# Finish locating the residual phase while the established model stays fixed.
phases["Sr3W2O9"].set_refinements({"Cell": True})
phases["Sr3W2O9"].set_HAP_refinements({"Scale": True})
run("third_cell", 2)

# Rebalance all phase intensities and the background.
phases["Sr3W2O9"].clear_refinements({"Cell": False})
phases["WO3_mono"].set_HAP_refinements({"Scale": True})
hist.set_refinements({"Sample Parameters": ["Scale"]})
hist.set_refinements({"Background": True})
run("scales_background", 2)

# Jointly refine peak positions only after the phase scales are stable.
for phase in phases.values():
    phase.set_refinements({"Cell": True})
hist.set_refinements({"Sample Parameters": ["Shift"]})
run("joint_cells", 3)

gpx.save()
a = hist.data["data"][1]
np.savetxt(ROOT / ".tmp" / "three_joint2_profile.csv",
           np.array([a[0], a[1], a[3], a[4], a[5]]).T,
           delimiter=",", header="two_theta,y_obs,y_calc,y_bkg,y_diff", comments="")
