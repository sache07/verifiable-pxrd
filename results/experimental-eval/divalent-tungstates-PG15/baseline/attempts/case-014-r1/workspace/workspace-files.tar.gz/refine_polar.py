"""Refine the unknown effective polarization with phase scales/background."""

from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "three_joint2.gpx"),
                     newgpx=str(ROOT / ".tmp" / "three_polar.gpx"))
gpx.set_Controls("cycles", 16)
hist = gpx.histogram(0)
phases = {p.name: p for p in gpx.phases()}

hist.clear_refinements({
    "Sample Parameters": ["Scale", "Shift"],
    "Instrument Parameters": ["U", "V", "W", "X", "Y", "Polariz."],
    "Background": False,
})
for phase in phases.values():
    phase.clear_refinements({"Cell": False, "Atoms": [a.label for a in phase.atoms()]})
    phase.clear_HAP_refinements({
        "Scale": False, "Size": False, "Mustrain": False,
        "HStrain": False, "Pref.Ori.": False,
    })

hist.set_refinements({"Instrument Parameters": ["Polariz."]})
hist.set_refinements({"Sample Parameters": ["Scale"]})
hist.set_refinements({"Background": True})
phases["WO3_mono"].set_HAP_refinements({"Scale": True})
phases["Sr3W2O9"].set_HAP_refinements({"Scale": True})

for cycle in range(3):
    gpx.refine()
    print("SUMMARY", json.dumps({
        "cycle": cycle + 1,
        "Rwp": hist.get_wR(),
        "polarization": hist.data["Instrument Parameters"][0]["Polariz."],
        "mass": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "scales": {p.name: p.HAPvalue("Scale") for p in phases.values()},
    }))
    gpx.save()
