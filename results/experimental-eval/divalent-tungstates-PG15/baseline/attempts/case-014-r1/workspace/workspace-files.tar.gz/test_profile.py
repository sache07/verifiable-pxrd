"""Compare reduced, physically valid powder-profile parameterizations."""

from pathlib import Path
import json
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
variant = sys.argv[1]
gpx = G2sc.G2Project(str(ROOT / ".tmp" / "final_model_stage.gpx"),
                     newgpx=str(ROOT / ".tmp" / f"profile_{variant}.gpx"))
gpx.set_Controls("cycles", 20)
hist = gpx.histogram(0)
phases = {p.name: p for p in gpx.phases()}

hist.clear_refinements({
    "Sample Parameters": ["Scale", "Shift"],
    "Instrument Parameters": ["U", "V", "W", "X", "Y", "Polariz."],
    "Background": False,
})
for phase in phases.values():
    phase.clear_refinements({"Cell": False, "Atoms": [a.label for a in phase.atoms()]})
    phase.clear_HAP_refinements({
        "Scale": False, "Size": False, "Mustrain": False,
        "HStrain": False, "Pref.Ori.": False,
    })

inst = hist.data["Instrument Parameters"][0]
starts = {"U": 5.0, "V": 0.0, "W": 70.0, "X": 8.0, "Y": 0.0}
for key, val in starts.items():
    inst[key][0] = val
    inst[key][1] = val

if variant == "uvw":
    terms = ["U", "V", "W"]
    inst["X"][0] = inst["X"][1] = 0.0
elif variant == "uvwx":
    terms = ["U", "V", "W", "X"]
elif variant == "uwx":
    terms = ["U", "W", "X"]
else:
    raise ValueError(variant)
hist.set_refinements({"Instrument Parameters": terms})

for cycle in range(2):
    gpx.refine()

theta = np.linspace(5.05, 49.95, 500)
u, v, w, x, y = [inst[k][1] for k in ["U", "V", "W", "X", "Y"]]
sig2 = u * np.tan(np.deg2rad(theta)) ** 2 + v * np.tan(np.deg2rad(theta)) + w
gam = x / np.cos(np.deg2rad(theta)) + y * np.tan(np.deg2rad(theta))
print("SUMMARY", json.dumps({
    "variant": variant, "Rwp": hist.get_wR(),
    "profile": {k: inst[k][1] for k in ["U", "V", "W", "X", "Y"]},
    "min_sig2": float(sig2.min()), "min_gamma": float(gam.min()),
}))
gpx.save()
