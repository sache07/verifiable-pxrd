"""Export the exact constrained GSAS-II model selected for submission."""

from pathlib import Path
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
source = ROOT / ".tmp" / "final_constrained.gpx"
gpx = G2sc.G2Project(str(source), newgpx=str(ROOT / "final.gpx"))
gpx.save()

phase_files = {
    "SrWO4": ROOT / "SrWO4.cif",
    "WO3_mono": ROOT / "WO3.cif",
    "Sr3W2O9": ROOT / "Sr3W2O9.cif",
}
for phase in gpx.phases():
    phase.export_CIF(str(phase_files[phase.name]))

hist = gpx.histogram(0)
x, yobs, weights, ycalc, background, difference = hist.data["data"][1]
low, high = hist.data["Limits"][1]
use = (x >= low) & (x <= high)
profile = np.column_stack((x[use], yobs[use], ycalc[use], difference[use], background[use]))
np.savetxt(
    ROOT / "fit.csv",
    profile,
    delimiter=",",
    header="two_theta_deg,observed_intensity,calculated_intensity,observed_minus_calculated,background_intensity",
    comments="",
    fmt="%.8g",
)

print("Rwp", hist.residuals["wR"])
print("mass fractions", hist.ComputeMassFracs())
print("fit points", profile.shape[0], "range", profile[0, 0], profile[-1, 0])
