"""Add the candidate Sr(OH)2 structure to the converged two-phase model."""

from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
src = ROOT / ".tmp" / "screens" / "SrWO4+WO3_mono.gpx"
dst = ROOT / ".tmp" / "sroh2_from_twophase.gpx"
cif = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/81/9008161.cif")

gpx = G2sc.G2Project(str(src), newgpx=str(dst))
gpx.set_Controls("cycles", 8)
hist = gpx.histogram(0)

# Freeze the converged two-phase model while the third-phase scale is tested.
hist.clear_refinements({
    "Sample Parameters": ["Scale", "Shift"],
    "Instrument Parameters": ["U", "V", "W", "X", "Y"],
    "Background": False,
})
for phase in gpx.phases():
    phase.clear_refinements({"Cell": False})
    phase.clear_HAP_refinements({"Scale": False, "Size": False, "Mustrain": False})

phase = gpx.add_phase(str(cif), phasename="SrOH2", histograms=[hist])
phase.HAPvalue("Scale", 0.001)
phase.set_HAP_refinements({"Scale": True})
phase.clear_refinements({"Cell": False})

def state(label):
    print("STATE", label, "Rwp", hist.get_wR(), "mass", hist.ComputeMassFracs())
    print("cells", {p.name: p.get_cell() for p in gpx.phases()})
    print("scales", {p.name: p.data["Histograms"][hist.name]["Scale"] for p in gpx.phases()})

state("initial")
gpx.refine()
state("scale")

# Refine its three orthorhombic cell constants only after a nonzero scale is found.
phase.set_refinements({"Cell": True})
gpx.refine()
state("cell")
gpx.save()

a = hist.data["data"][1]
np.savetxt(ROOT / ".tmp" / "sroh2_profile.csv",
           np.array([a[0], a[1], a[3], a[4], a[5]]).T,
           delimiter=",", header="two_theta,y_obs,y_calc,y_bkg,y_diff", comments="")
