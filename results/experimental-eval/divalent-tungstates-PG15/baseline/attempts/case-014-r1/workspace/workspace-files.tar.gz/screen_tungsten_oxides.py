#!/usr/bin/env python3
"""Compare tungsten-oxide structure models against the residual pattern."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp" / "oxide_screens"
TMP.mkdir(parents=True, exist_ok=True)
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

CANDIDATES = {
    "WO3_1004057_P6mmm": "1004057",
    "WO3_1010618_Pminus1": "1010618",
    "WO3_1521532_P4ncc": "1521532",
    "WO3_1521533_P4nmm": "1521533",
    "WO3_1528915_P21c": "1528915",
    "WO3_1563541_P21c": "1563541",
    "WO3_2311041_P21c": "2311041",
    "WO3_2106293_Pminus1": "2106293",
    "WO3_2107312_Pnma": "2107312",
    "W18O49_1528166": "1528166",
    "W18O49_1538315": "1538315",
    "W10O29_1538317": "1538317",
    "W17O47_2107065": "2107065",
    "W3O8_2101049": "2101049",
    "W3O8_2101050": "2101050",
    "WO2_1548686": "1548686",
    "WO2_5910153": "5910153",
    "W3O10_9014468": "9014468",
}


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def run(name: str, cod_id: str) -> dict:
    path = TMP / f"{name}.gpx"
    gpx = G2sc.G2Project(str(ROOT / ".tmp" / "screens" / "SrWO4.gpx"), newgpx=str(path))
    gpx.set_Controls("cycles", 8)
    hist = gpx.histogram(0)
    # Freeze the converged one-phase nuisance parameters for the initial test.
    hist.clear_refinements({
        "Background": False,
        "Sample Parameters": ["Scale", "Shift"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y"],
    })
    major = gpx.phase(0)
    major.clear_refinements({"Cell": False, "Atoms": [a.label for a in major.atoms()]})
    major.clear_HAP_refinements({"Scale": False, "Size": False, "Mustrain": False})

    phase = gpx.add_phase(str(cod_cif(cod_id)), phasename=name, histograms=[hist])
    phase.HAPvalue("Scale", 0.10)
    phase.set_HAP_refinements({"Scale": True})
    stages = []

    gpx.refine()
    stages.append(["scale", hist.get_wR(), phase.HAPvalue("Scale")])
    scale = phase.HAPvalue("Scale")
    if scale > 1e-8:
        phase.set_refinements({"Cell": True})
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        gpx.refine()
        stages.append(["cell_shift", hist.get_wR(), phase.HAPvalue("Scale")])
        # Let common background/profile parameters readjust after phase inclusion.
        hist.set_refinements({
            "Background": {"refine": True},
            "Instrument Parameters": ["U", "V", "W", "X", "Y"],
        })
        major.set_refinements({"Cell": True})
        gpx.refine()
        stages.append(["all_profile", hist.get_wR(), phase.HAPvalue("Scale")])
    gpx.save()
    out = {
        "name": name,
        "cod_id": cod_id,
        "stages": stages,
        "Rwp": hist.get_wR(),
        "scale": phase.HAPvalue("Scale"),
        "cell": phase.get_cell(),
    }
    try:
        out["mass_fractions"] = {k: list(v) for k, v in hist.ComputeMassFracs().items()}
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    return out


results = []
for name, cod_id in CANDIDATES.items():
    try:
        result = run(name, cod_id)
    except Exception as exc:
        result = {"name": name, "cod_id": cod_id, "error": repr(exc)}
    results.append(result)
    print("OXIDE", json.dumps(result, sort_keys=True))

print("SUMMARY")
for result in sorted(results, key=lambda r: r.get("Rwp", 1e9)):
    print(result.get("name"), result.get("Rwp"), result.get("scale"), result.get("stages"), result.get("error"))
