#!/usr/bin/env python3
"""Screen chemically plausible phase combinations by GSAS-II Rietveld fits."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp" / "screens"
TMP.mkdir(parents=True, exist_ok=True)
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

PHASES = {
    "SrWO4": "1546036",
    "WO3_mono": "1528915",
    "WO3_mono_alt": "2311041",
    "SrCO3_orth": "9008198",
    "SrCO3_rhom": "1539128",
    "Sr3W2O9": "2311977",
    "SrOH2": "9008161",
    "W18O49": "1528166",
    "W18O49_alt": "1538315",
}

COMBINATIONS = [
    ["SrWO4", "W18O49"],
]


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summarize(gpx: G2sc.G2Project, label: str, stages: list[dict]) -> dict:
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    out = {
        "label": label,
        "stages": stages,
        "residuals": {k: float(v) if np.isscalar(v) and not isinstance(v, str) else v
                      for k, v in hist.residuals.items()},
        "sample_scale": sample["Scale"][0],
        "shift": sample["Shift"][0],
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "phases": {},
    }
    for phase in gpx.phases():
        out["phases"][phase.name] = {
            "scale": phase.data["Histograms"][hist.name]["Scale"][0],
            "cell": phase.get_cell(),
        }
    try:
        out["mass_fractions"] = {k: list(v) for k, v in hist.ComputeMassFracs().items()}
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    return out


def run(combo: list[str]) -> dict:
    label = "+".join(combo)
    path = TMP / f"{label}.gpx"
    gpx = G2sc.G2Project(newgpx=str(path))
    gpx.set_Controls("cycles", 8)
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "cu_ka.instprm"),
        fmthint="comma",
    )
    hist.set_refinements({
        "Limits": [10.1, 99.9],
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 15},
    })
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 10.0, "V": 0.0, "W": 100.0, "X": 0.0, "Y": 0.0}.items():
        inst[key][0] = value
        inst[key][1] = value

    phases = []
    for name in combo:
        phase = gpx.add_phase(
            str(cod_cif(PHASES[name])),
            phasename=name,
            histograms=[hist],
        )
        # GSAS-II has no W+5 X-ray scattering table. The difference from W+6
        # is negligible here, so normalize mixed-valence tungsten labels.
        if name.startswith("W18O49"):
            for atom in phase.atoms():
                if atom.element == "W":
                    atom.type = "W+6"
            G2sc.SetupGeneral(phase.data, None)
        phases.append(phase)

    # The sample scale is the overall intensity scale. Fix the major phase HAP
    # scale to 1 and refine minor HAP scales relative to it.
    phases[0].HAPvalue("Scale", 1.0)
    phases[0].clear_HAP_refinements({"Scale": False})
    for phase in phases[1:]:
        phase.HAPvalue("Scale", 0.05)
        phase.set_HAP_refinements({"Scale": True})

    stages: list[dict] = []

    def refine(stage: str) -> None:
        try:
            gpx.refine()
            stages.append({"stage": stage, "Rwp": hist.get_wR(), "ok": True})
        except Exception as exc:
            stages.append({"stage": stage, "ok": False, "error": repr(exc)})
            raise

    # Establish intensities/background, then positions, then widths.
    refine("scale_background")
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine("shift_cells")
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    refine("uvw")
    hist.set_refinements({"Instrument Parameters": ["X", "Y"]})
    refine("xy")
    refine("repeat")
    gpx.save()
    return summarize(gpx, label, stages)


results = []
for combination in COMBINATIONS:
    try:
        result = run(combination)
    except Exception as exc:
        result = {"label": "+".join(combination), "fatal_error": repr(exc)}
    results.append(result)
    print("SCREEN", json.dumps(result, sort_keys=True))

print("SUMMARY")
for result in results:
    residuals = result.get("residuals", {})
    scales = {k: v["scale"] for k, v in result.get("phases", {}).items()}
    print(result["label"], "Rwp", residuals.get("wR"), "GOF", residuals.get("GOF"), "scales", scales)
