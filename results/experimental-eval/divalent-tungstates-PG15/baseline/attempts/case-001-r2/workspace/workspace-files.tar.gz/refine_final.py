#!/usr/bin/env python3
"""Build the final GSAS-II refinement and requested machine-readable outputs."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
TMP = WORK / ".tmp"
INPUT_PATTERN = WORK / "inputs" / "pattern.csv"
GPX = WORK / "final.gpx"
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/"
    "dara/cod-filtered-2024/cif"
)


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_inputs() -> tuple[Path, Path]:
    """Convert the supplied CSV to a GSAS-II-readable xye file and write the instrument file."""
    TMP.mkdir(exist_ok=True)
    xye = TMP / "final_pattern.xye"
    inst = TMP / "final_cu_ka.instprm"
    with INPUT_PATTERN.open(newline="") as source, xye.open("w") as target:
        rows = csv.DictReader(source)
        for row in rows:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            # No pointwise uncertainties were supplied. Counting-statistical
            # uncertainties are used, with unit minimum variance protection.
            sigma = math.sqrt(max(y, 1.0))
            target.write(f"{x:.8f} {y:.8f} {sigma:.8f}\n")
    inst.write_text(
        "#GSAS-II instrument parameter file for supplied Cu K-alpha data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.30;Polariz.:0.70;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:2.0;V:-2.0;W:6.0;X:12.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def run_refinement(project: G2sc.G2Project, label: str) -> None:
    project.save()
    project.do_refinements([{}])
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    print(
        f"{label}: Rwp={rvals.get('Rwp', float('nan')):.5f}% "
        f"GOF={rvals.get('GOF', float('nan')):.5f} "
        f"max_shift/esd={rvals.get('Max shft/sig', float('nan')):.3f}"
    )


def build_project() -> G2sc.G2Project:
    xye, instfile = make_inputs()
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(
        str(xye), str(instfile), fmthint="Topas"
    )

    # Ambient witherite structure: COD 9010928 (Antao & Hassan, 2007).
    baco3 = project.add_phase(
        str(cod_cif("9010928")),
        phasename="BaCO3_witherite",
        histograms=[hist],
        fmthint="CIF",
    )
    # The observed WO3 peak splitting is better represented by triclinic P-1
    # than by the closely related monoclinic P21/c model. COD 2106293 is the
    # room-temperature triclinic refinement of Diehl, Brandt & Salje (1978).
    wo3 = project.add_phase(
        str(cod_cif("2106293")),
        phasename="WO3_triclinic",
        histograms=[hist],
        fmthint="CIF",
    )

    project.set_Controls("cycles", 25)
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 15,
            }
        }
    )

    # Start close to the scale-factor basin found during phase screening.
    baco3.HAPvalue("Scale", 20.0)
    wo3.HAPvalue("Scale", 7.5)
    for phase in (baco3, wo3):
        phase.set_HAP_refinements({"Scale": True})

    # Staged refinement keeps scale/background, metric, and profile parameters
    # from becoming strongly coupled before the major intensity terms settle.
    run_refinement(project, "scale/background")

    for phase in (baco3, wo3):
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, "cells/zero")

    hist.set_refinements(
        {"Instrument Parameters": ["W", "X", "Polariz."]}
    )
    run_refinement(project, "profile/polarization")

    # A modest [110] March-Dollase correction is supported for pressed
    # witherite crystallites. WO3 returned a ratio indistinguishable from one,
    # so no preferred-orientation term is used for that phase.
    pref_ori = baco3.getHAPvalues(hist)["Pref.Ori."]
    pref_ori[0] = "MD"
    pref_ori[1] = 1.0
    pref_ori[3] = [1, 1, 0]
    baco3.set_HAP_refinements({"Pref.Ori.": True})
    run_refinement(project, "witherite preferred orientation")

    # A second pass is used to ensure convergence after all selected variables
    # have reached the same least-squares cycle.
    run_refinement(project, "final convergence")
    project.save()
    return project


def export_outputs(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    phase_info = {
        "BaCO3_witherite": {
            "name": "witherite",
            "formula": "BaCO3",
            "space_group": "Pmcn (No. 62)",
            "cif_path": "BaCO3.cif",
        },
        "WO3_triclinic": {
            "name": "triclinic tungsten(VI) oxide",
            "formula": "WO3",
            "space_group": "P-1 (No. 2)",
            "cif_path": "WO3.cif",
        },
    }

    for phase in project.phases():
        phase.export_CIF(str(WORK / phase_info[phase.name]["cif_path"]))

    data = hist.data["data"][1]
    x = np.asarray(data[0], dtype=float)
    y_obs = np.asarray(data[1], dtype=float)
    y_calc = np.asarray(data[3], dtype=float)
    y_bkg = np.asarray(data[4], dtype=float)
    difference = y_obs - y_calc
    with (WORK / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_observed_minus_calculated",
                "calculated_background",
            ]
        )
        writer.writerows(
            zip(
                (f"{v:.8f}" for v in x),
                (f"{v:.8f}" for v in y_obs),
                (f"{v:.8f}" for v in y_calc),
                (f"{v:.8f}" for v in difference),
                (f"{v:.8f}" for v in y_bkg),
            )
        )

    mass_fractions = hist.ComputeMassFracs()
    phases = []
    for phase in project.phases():
        value, esd = mass_fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        item = dict(phase_info[phase.name])
        item.update(
            {
                "weight_fraction": value,
                "weight_fraction_formal_esd": esd,
                "weight_percent": 100.0 * value,
                "unit_cell": cell,
                "unit_cell_formal_esd": cell_esd,
            }
        )
        phases.append(item)

    hstats = hist.data["data"][0]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "normalization": "modeled crystalline phases only; fractions sum to 1",
        "phases": phases,
        "fit_statistics": {
            "Rp_percent": hstats["R"],
            "Rwp_percent": hstats["wR"],
            "Rexp_percent": hstats["wRmin"],
            "goodness_of_fit": rvals["GOF"],
            "chi_square": rvals["chisq"],
            "reduced_chi_square": rvals["GOF"] ** 2,
            "n_observations": rvals["Nobs"],
            "n_variables": rvals["Nvars"],
            "durbin_watson": hstats["Durbin-Watson"],
            "converged": bool(rvals.get("converged", False)),
            "maximum_shift_over_esd": rvals.get("Max shft/sig"),
        },
        "measurement_model": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "uncertainties": "Poisson counting estimates sqrt(max(I,1)); none supplied",
            "profile": "GSAS-II CW pseudo-Voigt; W and X refined",
            "background": "15-term Chebyshev-1",
            "preferred_orientation": (
                "March-Dollase [110] correction refined for BaCO3; none for WO3"
            ),
        },
        "unresolved_candidates": [
            {
                "phase": "BaWO4 (scheelite)",
                "status": "not reliably detected or quantified",
                "reason": (
                    "A conventional I41/a model refined to a fraction statistically "
                    "indistinguishable from zero; sub-1 wt% estimates were strongly "
                    "dependent on the selected oxygen-coordinate model."
                ),
            }
        ],
    }
    (WORK / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    final_project = build_project()
    export_outputs(final_project)
