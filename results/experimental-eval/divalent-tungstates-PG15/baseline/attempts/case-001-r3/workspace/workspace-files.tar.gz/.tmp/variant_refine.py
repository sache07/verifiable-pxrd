from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('wo3_id')
    ap.add_argument('--bawo4', action='store_true')
    args = ap.parse_args()
    tag = args.wo3_id + ('_plus_bawo4' if args.bawo4 else '')
    gpxpath = ROOT / '.tmp' / f'variant_{tag}.gpx'
    if gpxpath.exists():
        gpxpath.unlink()

    proj = G2sc.G2Project(newgpx=str(gpxpath))
    hist = proj.add_powder_histogram(str(ROOT / 'pattern.xye'),
                                     str(ROOT / 'instrument.instprm'),
                                     fmthint='xye')
    baco3 = proj.add_phase(str(cod_path('9010928')), phasename='BaCO3_witherite',
                           histograms=[hist], fmthint='CIF')
    wo3 = proj.add_phase(str(cod_path(args.wo3_id)), phasename='WO3_candidate',
                         histograms=[hist], fmthint='CIF')
    phases = [baco3, wo3]
    if args.bawo4:
        bawo4 = proj.add_phase(str(cod_path('1527204')), phasename='BaWO4_scheelite',
                               histograms=[hist], fmthint='CIF')
        phases.append(bawo4)

    proj.set_Controls('cycles', 12)
    inst = hist.data['Instrument Parameters'][0]
    inst['Zero'][1] = 0.30
    inst['U'][1], inst['V'][1], inst['W'][1] = 50.0, -10.0, 120.0
    inst['X'][1], inst['Y'][1], inst['Z'][1] = 5.0, 5.0, 0.0
    hist.data['Sample Parameters']['Scale'] = [1.0, False]
    hist.set_refinements({'Background': {
        'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 15,
        'coeffs': [800.0] + [0.0] * 14,
    }})
    for phase in phases:
        phase.HAPvalue('Scale', 10.0 if phase is not wo3 else 5.0)
        phase.set_HAP_refinements({'Scale': True}, [hist])
    if args.bawo4:
        bawo4.HAPvalue('Scale', 0.01)

    proj.save()
    proj.refine(makeBack=False)
    for phase in phases:
        phase.set_refinements({'Cell': True})
    proj.refine(makeBack=False)
    hist.set_refinements({'Instrument Parameters': ['Zero']})
    proj.refine(makeBack=False)
    hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
    proj.refine(makeBack=False)
    proj.save()

    result = {
        'tag': tag,
        'gpx': str(gpxpath),
        'residuals': hist.data['data'][0],
        'mass_fractions': {k: {'value': v[0], 'esd': v[1]}
                           for k, v in hist.ComputeMassFracs().items()},
        'instrument': {k: v[1] for k, v in inst.items()
                       if isinstance(v, list) and len(v) >= 2},
        'phases': {p.name: {'cell': p.get_cell(),
                            'scale': p.HAPvalue('Scale', targethistlist=[hist])}
                   for p in phases},
    }
    out = ROOT / '.tmp' / f'variant_{tag}.json'
    out.write_text(json.dumps(result, indent=2))
    print('SUMMARY', json.dumps({
        'tag': tag,
        'wR': result['residuals'].get('wR'),
        'R': result['residuals'].get('R'),
        'mass_fractions': result['mass_fractions'],
        'cells': {k: v['cell'] for k, v in result['phases'].items()},
    }))


if __name__ == '__main__':
    main()
