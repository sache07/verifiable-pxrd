from pathlib import Path
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def refine(project):
    project.refine(makeBack=False)


def main():
    gpx_path = ROOT / 'final.gpx'
    if gpx_path.exists():
        gpx_path.unlink()

    project = G2sc.G2Project(newgpx=str(gpx_path))
    histogram = project.add_powder_histogram(
        str(ROOT / 'pattern.xye'), str(ROOT / 'instrument.instprm'),
        fmthint='xye')
    baco3 = project.add_phase(
        str(cod_path('9010928')), phasename='BaCO3_witherite',
        histograms=[histogram], fmthint='CIF')
    wo3 = project.add_phase(
        str(ROOT / '.tmp' / 'wo3_standard.cif'),
        phasename='WO3_monoclinic', histograms=[histogram], fmthint='CIF')

    project.set_Controls('cycles', 20)
    histogram.data['Sample Parameters']['Scale'] = [1.0, False]
    instrument = histogram.data['Instrument Parameters'][0]
    instrument['Zero'][1] = 0.30

    histogram.set_refinements({'Background': {
        'type': 'chebyschev-1',
        'refine': True,
        'no. coeffs': 15,
        'coeffs': [800.0] + [0.0] * 14,
    }})
    baco3.HAPvalue('Scale', 10.0)
    wo3.HAPvalue('Scale', 5.0)
    baco3.set_HAP_refinements({'Scale': True}, [histogram])
    wo3.set_HAP_refinements({'Scale': True}, [histogram])
    project.save()
    refine(project)

    baco3.set_refinements({'Cell': True})
    wo3.set_refinements({'Cell': True})
    refine(project)

    histogram.set_refinements({'Instrument Parameters': ['Zero']})
    refine(project)

    # Restart the profile terms in a positive-width basin. U, W and X are
    # bounded nonnegative; V and Y may be signed while the total Gaussian
    # variance and Lorentzian width remain positive over the measured range.
    histogram.clear_refinements({
        'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
    for key, value in {
        'U': 300.0, 'V': 0.0, 'W': 20.0, 'X': 10.0, 'Y': 0.0,
    }.items():
        instrument[key][1] = value
    histogram.set_refinements({
        'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
    for key in ('U', 'W', 'X'):
        project.set_Controls('parmMin', 0.0, variable=f':0:{key}')
    refine(project)

    # A small [001] March-Dollase correction is supported for witherite.
    po = baco3.data['Histograms'][histogram.name]['Pref.Ori.']
    po[0], po[1], po[2], po[3] = 'MD', 1.0, True, [0, 0, 1]
    refine(project)
    refine(project)
    project.save()

    baco3.export_CIF(str(ROOT / 'phase_BaCO3.cif'))
    wo3.export_CIF(str(ROOT / 'phase_WO3.cif'))

    x = histogram.getdata('x')
    yobs = histogram.getdata('yobs')
    ycalc = histogram.getdata('ycalc')
    background = histogram.getdata('background')
    difference = histogram.getdata('residual')
    profile = np.column_stack([x, yobs, ycalc, difference, background])
    np.savetxt(
        ROOT / 'fit.csv', profile, delimiter=',', fmt='%.8g',
        header='two_theta_deg,observed,calculated,difference_obs_minus_calc,background',
        comments='')

    fractions = histogram.ComputeMassFracs()
    residuals = histogram.data['data'][0]
    weights = histogram.getdata('yweight')
    chi_squared = float(np.ma.sum(weights * difference * difference))
    n_obs = int(residuals['Nobs'])
    n_parameters = len(project.get_VaryList())
    dof = n_obs - n_parameters
    reduced_chi_squared = chi_squared / dof

    summary = {
        'phases': [],
        'fit_statistics': {
            'Rwp_percent': float(residuals['wR']),
            'Rp_percent': float(residuals['R']),
            'Rexp_percent': 100.0 * math.sqrt(dof / float(residuals['sumwYo'])),
            'goodness_of_fit': math.sqrt(reduced_chi_squared),
            'chi_squared': chi_squared,
            'reduced_chi_squared': reduced_chi_squared,
            'n_observations': n_obs,
            'n_refined_parameters': n_parameters,
            'durbin_watson': float(residuals['Durbin-Watson']),
        },
        'instrument': {key: float(instrument[key][1]) for key in (
            'Lam1', 'Lam2', 'I(L2)/I(L1)', 'Zero', 'U', 'V', 'W', 'X', 'Y')},
        'background_coefficients': [float(v) for v in histogram.data['Background'][0][3:]],
    }
    for phase, cif_name, formula, cod_id in (
        (baco3, 'phase_BaCO3.cif', 'BaCO3', '9010928'),
        (wo3, 'phase_WO3.cif', 'WO3', '2311041'),
    ):
        cell, cell_esd = phase.get_cell_and_esd()
        wt, wt_esd = fractions[phase.name]
        summary['phases'].append({
            'name': phase.name,
            'formula': formula,
            'reference_cod_id': cod_id,
            'space_group': phase.data['General']['SGData']['SpGrp'].strip(),
            'cif': cif_name,
            'weight_fraction': float(wt),
            'weight_fraction_esd_formal': float(wt_esd),
            'cell': {k: float(v) for k, v in cell.items()},
            'cell_esd': {k: float(v) for k, v in cell_esd.items()},
        })
    (ROOT / '.tmp' / 'final_summary.json').write_text(json.dumps(summary, indent=2))
    print('FINAL_SUMMARY')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
