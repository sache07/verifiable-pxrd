from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('model', choices=['uwx', 'uwxy', 'uvwx', 'uvwxy_bound'])
    ap.add_argument('--size', action='store_true')
    args = ap.parse_args()
    source = ROOT / '.tmp' / 'variant_2311041.gpx'
    tag = args.model + ('_size' if args.size else '')
    target = ROOT / '.tmp' / f'profile_{tag}.gpx'
    proj = G2sc.G2Project(str(source), newgpx=str(target))
    proj.set_Controls('cycles', 20)
    hist = proj.histogram(0)
    inst = hist.data['Instrument Parameters'][0]
    hist.clear_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
    starts = {'U': 300.0, 'V': 0.0, 'W': 20.0, 'X': 10.0, 'Y': 0.0}
    for key, val in starts.items():
        inst[key][1] = val
    flags = {
        'uwx': ['U', 'W', 'X'],
        'uwxy': ['U', 'W', 'X', 'Y'],
        'uvwx': ['U', 'V', 'W', 'X'],
        'uvwxy_bound': ['U', 'V', 'W', 'X', 'Y'],
    }[args.model]
    hist.set_refinements({'Instrument Parameters': flags})
    if args.model == 'uvwxy_bound':
        for key in ['U', 'W', 'X']:
            proj.set_Controls('parmMin', 0.0, variable=f':0:{key}')
    proj.refine(makeBack=False)
    if args.size:
        for phase in proj.phases():
            phase.set_HAP_refinements({
                'Size': {'type': 'isotropic', 'refine': True, 'value': 1.0},
            }, [hist])
        proj.refine(makeBack=False)
    proj.save()
    result = {
        'tag': tag,
        'wR': hist.get_wR(),
        'R': hist.data['data'][0].get('R'),
        'fractions': {k: {'value': v[0], 'esd': v[1]}
                      for k, v in hist.ComputeMassFracs().items()},
        'instrument': {k: [inst[k][1], inst[k][2]] for k in starts},
        'size': {p.name: p.data['Histograms'][hist.name]['Size'][1][0]
                 for p in proj.phases()},
    }
    print('SUMMARY', json.dumps(result))


if __name__ == '__main__':
    main()
