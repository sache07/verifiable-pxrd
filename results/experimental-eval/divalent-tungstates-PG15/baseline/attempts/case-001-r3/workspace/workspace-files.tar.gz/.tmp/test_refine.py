from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def report(proj, label):
    hist = proj.histogram(0)
    print(f'\n===== {label} =====')
    print('residuals', hist.data['data'][0])
    print('instrument', hist.data['Instrument Parameters'][0])
    print('sample', hist.data['Sample Parameters'])
    print('background', hist.data['Background'][0])
    for phase in proj.phases():
        print('phase', phase.name, 'cell', phase.get_cell(),
              'scale', phase.HAPvalue('Scale', targethistlist=[hist]))
        print('HAP', phase.data['Histograms'][hist.name])
    try:
        print('mass fractions', hist.ComputeMassFracs())
    except Exception as err:
        print('mass fraction error', repr(err))
    print('vary', [str(x) for x in (proj.get_VaryList() or [])])


def do_refine(proj, label):
    proj.refine(makeBack=False)
    report(proj, label)


def main():
    out = ROOT / '.tmp' / 'two_phase.gpx'
    if out.exists():
        out.unlink()
    proj = G2sc.G2Project(newgpx=str(out))
    hist = proj.add_powder_histogram(
        str(ROOT / 'pattern.xye'), str(ROOT / 'instrument.instprm'),
        fmthint='xye')
    baco3 = proj.add_phase(str(cod_path('9010928')), phasename='BaCO3_witherite',
                           histograms=[hist], fmthint='CIF')
    wo3 = proj.add_phase(str(cod_path('1528915')), phasename='WO3_monoclinic',
                         histograms=[hist], fmthint='CIF')
    proj.set_Controls('cycles', 12)

    # Use the approximate constant shift inferred from the indexed peak list.
    inst = hist.data['Instrument Parameters'][0]
    inst['Zero'][1] = 0.30
    inst['U'][1], inst['V'][1], inst['W'][1] = 50.0, -10.0, 120.0
    inst['X'][1], inst['Y'][1], inst['Z'][1] = 5.0, 5.0, 0.0
    # The histogram scale and phase scales are exactly correlated; hold the
    # former at unity so the latter carry the quantitative phase information.
    hist.data['Sample Parameters']['Scale'] = [1.0, False]

    # A flexible smooth background, initialized near the mean baseline.
    hist.set_refinements({'Background': {
        'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 15,
        'coeffs': [800.0] + [0.0] * 14,
    }})
    baco3.HAPvalue('Scale', 5.0e-8)
    wo3.HAPvalue('Scale', 5.0e-8)
    baco3.set_HAP_refinements({'Scale': True}, [hist])
    wo3.set_HAP_refinements({'Scale': True}, [hist])
    proj.save()
    do_refine(proj, 'background + phase scales')

    baco3.set_refinements({'Cell': True})
    wo3.set_refinements({'Cell': True})
    do_refine(proj, 'add cells')

    hist.set_refinements({'Instrument Parameters': ['Zero']})
    do_refine(proj, 'add zero')

    hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
    do_refine(proj, 'add profile')

    proj.save()


if __name__ == '__main__':
    main()
