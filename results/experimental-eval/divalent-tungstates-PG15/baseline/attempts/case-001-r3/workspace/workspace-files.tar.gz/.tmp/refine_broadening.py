from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('tag')
    ap.add_argument('--size-only', action='store_true')
    args = ap.parse_args()
    source = ROOT / '.tmp' / f'variant_{args.tag}.gpx'
    suffix = 'size' if args.size_only else 'broad'
    target = ROOT / '.tmp' / f'variant_{args.tag}_{suffix}.gpx'
    proj = G2sc.G2Project(str(source), newgpx=str(target))
    hist = proj.histogram(0)
    proj.set_Controls('cycles', 15)

    for phase in proj.phases():
        phase.set_HAP_refinements({
            'Size': {'type': 'isotropic', 'refine': True, 'value': 1.0},
        }, [hist])
    proj.refine(makeBack=False)
    if not args.size_only:
        for phase in proj.phases():
            phase.set_HAP_refinements({
                'Mustrain': {'type': 'isotropic', 'refine': True},
            }, [hist])
        proj.refine(makeBack=False)
    proj.save()

    result = {
        'tag': args.tag + '_' + suffix,
        'gpx': str(target),
        'wR': hist.data['data'][0].get('wR'),
        'R': hist.data['data'][0].get('R'),
        'mass_fractions': {k: {'value': v[0], 'esd': v[1]}
                           for k, v in hist.ComputeMassFracs().items()},
        'hap': {p.name: {
            'Size': p.data['Histograms'][hist.name]['Size'],
            'Mustrain': p.data['Histograms'][hist.name]['Mustrain'],
        } for p in proj.phases()},
    }
    print('SUMMARY', json.dumps(result))


if __name__ == '__main__':
    main()
