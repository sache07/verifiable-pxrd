from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('tag')
    ap.add_argument('--all-atoms', action='store_true')
    args = ap.parse_args()
    source = ROOT / '.tmp' / f'variant_{args.tag}.gpx'
    mode = 'allatoms' if args.all_atoms else 'heavy'
    target = ROOT / '.tmp' / f'variant_{args.tag}_{mode}.gpx'
    proj = G2sc.G2Project(str(source), newgpx=str(target))
    proj.set_Controls('cycles', 15)
    before = {}
    for phase in proj.phases():
        before[phase.name] = {a.label: list(a.coordinates) for a in phase.atoms()}
        for atom in phase.atoms():
            if args.all_atoms or atom.element in ('Ba', 'W'):
                atom.refinement_flags = 'X'
    proj.refine(makeBack=False)
    proj.save()
    hist = proj.histogram(0)
    result = {
        'tag': args.tag + '_' + mode,
        'wR': hist.data['data'][0].get('wR'),
        'R': hist.data['data'][0].get('R'),
        'mass_fractions': {k: {'value': v[0], 'esd': v[1]}
                           for k, v in hist.ComputeMassFracs().items()},
        'coordinates': {p.name: {a.label: {
            'before': before[p.name][a.label], 'after': list(a.coordinates),
        } for a in p.atoms()} for p in proj.phases()},
    }
    print('SUMMARY', json.dumps(result))


if __name__ == '__main__':
    main()
