from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def parse_axis(text):
    return [int(v) for v in text.split(',')]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('baco3_axis', type=parse_axis)
    ap.add_argument('wo3_axis', type=parse_axis)
    args = ap.parse_args()
    btag = ''.join(map(str, args.baco3_axis))
    wtag = ''.join(map(str, args.wo3_axis))
    target = ROOT / '.tmp' / f'po_{btag}_{wtag}.gpx'
    proj = G2sc.G2Project(str(ROOT / '.tmp' / 'profile_uvwxy_bound.gpx'),
                          newgpx=str(target))
    proj.set_Controls('cycles', 20)
    hist = proj.histogram(0)
    axes = [args.baco3_axis, args.wo3_axis]
    for phase, axis in zip(proj.phases(), axes):
        hap = phase.data['Histograms'][hist.name]
        hap['Pref.Ori.'][0] = 'MD'
        hap['Pref.Ori.'][1] = 1.0
        hap['Pref.Ori.'][2] = True
        hap['Pref.Ori.'][3] = axis
    proj.refine(makeBack=False)
    proj.save()
    result = {
        'axes': axes,
        'wR': hist.get_wR(),
        'R': hist.data['data'][0].get('R'),
        'fractions': {k: v[0] for k, v in hist.ComputeMassFracs().items()},
        'MD': {p.name: p.data['Histograms'][hist.name]['Pref.Ori.'][1]
               for p in proj.phases()},
    }
    print('SUMMARY', json.dumps(result))


if __name__ == '__main__':
    main()
