#!/usr/bin/env python3
"""Build and refine the final two-phase GSAS-II model."""

from pathlib import Path
import csv
import json

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
WO3_CIF = COD / "2/10/62/2106293.cif"
BAO2_CIF = COD / "1/52/14/1521428.cif"


def print_state(project, label):
    hist = project.histogram(0)
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "mustrain", hap["Mustrain"])


def refine(project, label):
    project.refine(makeBack=False)
    print_state(project, label)


def main():
    gpx_path = ROOT / "final.gpx"
    if gpx_path.exists():
        gpx_path.unlink()

    project = G2sc.G2Project(newgpx=str(gpx_path))
    project.set_Controls("cycles", 12)
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    wo3 = project.add_phase(str(WO3_CIF), phasename="triclinic WO3",
                            histograms=[hist], fmthint="CIF")
    bao2 = project.add_phase(str(BAO2_CIF), phasename="BaO2",
                             histograms=[hist], fmthint="CIF")

    # COD 1521428 provides the better modern peroxide O coordinate, but its
    # reported vacancy concentration is not independently measurable here.
    # Use nominal full BaO2 occupancy and let the symmetry-allowed O z
    # coordinate refine later.
    bao2.atom("O1").occupancy = 1.0
    G2sc.SetupGeneral(bao2.data, None)

    # GSAS-II's generic CSV import enables the specimen scale by default. It is
    # exactly redundant with all phase scales, so fix it to one for a
    # full-rank quantitative phase refinement.
    hist.SampleParameters["Scale"] = [1.0, False]

    x_data = hist.data["data"][1][0]
    hist.set_refinements({
        "Limits": [float(x_data[0]), float(x_data[-1])],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 15,
        },
    })
    for phase in (wo3, bao2):
        phase.set_HAP_refinements({"Scale": True})
    refine(project, "background and scales")

    for phase in (wo3, bao2):
        phase.set_refinements({"Cell": True})
    refine(project, "cells")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "zero offset")

    # With no calibrated instrumental profile, use only the two Lorentzian
    # profile terms. Refining U/V/W simultaneously is numerically degenerate
    # over this angular range and gives physically meaningless coefficients.
    hist.set_refinements({"Instrument Parameters": ["X", "Y"]})
    refine(project, "instrument profile")

    bao2.set_refinements({"Atoms": {"O1": "X"}})
    refine(project, "BaO2 oxygen coordinate")

    # A final pass after all selected parameters have approached their minima.
    refine(project, "final pass")
    project.save(str(gpx_path))

    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    print("mass fractions", fractions)

    wo3_cif = ROOT / "phase_1_WO3.cif"
    bao2_cif = ROOT / "phase_2_BaO2.cif"
    wo3.export_CIF(str(wo3_cif))
    bao2.export_CIF(str(bao2_cif))

    x, observed, weights, calculated, background, difference = hist.data["data"][1]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg", "observed_intensity", "calculated_intensity",
            "difference_observed_minus_calculated",
        ])
        writer.writerows(zip(x, observed, calculated, difference))

    residuals = hist.residuals
    gof = residuals["wR"] / residuals["wRmin"]
    result = {
        "phases": [
            {
                "name": "triclinic tungsten(VI) oxide",
                "formula": "WO3",
                "space_group": "P -1",
                "cif_path": wo3_cif.name,
                "weight_fraction": fractions["triclinic WO3"][0],
                "weight_fraction_esd": fractions["triclinic WO3"][1],
            },
            {
                "name": "barium peroxide",
                "formula": "BaO2",
                "space_group": "I 4/mmm",
                "cif_path": bao2_cif.name,
                "weight_fraction": fractions["BaO2"][0],
                "weight_fraction_esd": fractions["BaO2"][1],
            },
        ],
        "fractions_basis": "normalized over modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": residuals["wR"],
            "Rp_percent": residuals["R"],
            "Rwp_expected_percent": residuals["wRmin"],
            "goodness_of_fit": gof,
            "reduced_chi_squared": gof * gof,
            "WO3_R_F_percent": residuals["0:0:Rf"],
            "WO3_R_F_squared_percent": residuals["0:0:Rf^2"],
            "BaO2_R_F_percent": residuals["1:0:Rf"],
            "BaO2_R_F_squared_percent": residuals["1:0:Rf^2"],
            "data_points": len(x),
            "refined_parameters": len(project.data["Covariance"]["data"]["varyList"]),
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
        },
        "profile_path": "fit.csv",
        "gsasii_project_path": "final.gpx",
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    wo3_cell, wo3_cell_esd = wo3.get_cell_and_esd()
    bao2_cell, bao2_cell_esd = bao2.get_cell_and_esd()
    wf_wo3, su_wo3 = fractions["triclinic WO3"]
    wf_bao2, su_bao2 = fractions["BaO2"]
    report = f"""# Powder diffraction phase analysis

## Result

Two crystalline phases were required. The crystalline-only quantitative result is **triclinic WO3 (P -1): {100*wf_wo3:.2f} wt%** and **BaO2 (I 4/mmm): {100*wf_bao2:.2f} wt%**. The formal covariance-matrix standard uncertainty is {100*su_wo3:.2f} percentage point for each normalized fraction; model-dependent uncertainty is larger (about 2 percentage points).

The refined WO3 cell is a = {wo3_cell['length_a']:.5f} A, b = {wo3_cell['length_b']:.5f} A, c = {wo3_cell['length_c']:.5f} A, alpha = {wo3_cell['angle_alpha']:.4f} deg, beta = {wo3_cell['angle_beta']:.4f} deg, gamma = {wo3_cell['angle_gamma']:.4f} deg (P -1). The refined BaO2 cell is a = {bao2_cell['length_a']:.5f} A and c = {bao2_cell['length_c']:.5f} A (I 4/mmm).

## Evidence

The resolved WO3 triplet at approximately 23.43, 23.92 and 24.65 deg 2theta and its split 33--35 deg group match low-symmetry WO3. A triclinic model (COD 2106293) fit the resolved splitting materially better than the monoclinic alternatives tested. BaO2 is identified by the paired 26.3/27.1 deg reflections and the consistent 43.0, 46.6, 48.0 and 55--56 deg series. No separate unmodeled peak family remains, and the diagnostic BaWO4 reflections (especially near 31.8 deg) are absent.

The final GSAS-II Rietveld fit has Rwp = {residuals['wR']:.3f}%, Rp = {residuals['R']:.3f}%, Rexp = {residuals['wRmin']:.3f}% and goodness of fit = {gof:.3f}. Cu K-alpha1/K-alpha2 wavelengths and their reported 0.5 ratio were fixed from metadata. Refined terms were the phase scales and cells, a common zero offset, two common Lorentzian profile terms, a 15-term Chebyshev background, and the symmetry-allowed BaO2 oxygen z coordinate; other atomic coordinates were held to reference values. With no supplied point uncertainties, GSAS-II used counting-statistical weights (1/I).

## Uncertainty and limits

Fractions are normalized only over the two modeled crystalline phases; amorphous content and absolute sample composition cannot be obtained from this scan. The triclinic WO3 model is preferred by the resolved splitting and fit quality, but its metric is close to monoclinic and the broad peaks do not make that polymorph distinction absolute. The peroxide lattice and intensities are compatible with BaO2/BaO2-x, but Cu X-ray contrast beside Ba is insufficient to determine oxygen-vacancy concentration reliably, so the submitted model uses nominal full-occupancy BaO2. Plausible peroxide structural templates shift the phase result by roughly 1--2 wt%, which dominates the formal scale-factor uncertainty. Remaining residuals are concentrated around the strongest overlapping WO3 peaks and are attributable mainly to imperfect line-shape/structure modeling rather than a resolved third phase.
"""
    (ROOT / "report.md").write_text(report)


if __name__ == "__main__":
    main()
