from __future__ import annotations

import argparse
import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

HERE = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = {
    "wo3_mono": ("WO3_monoclinic", "2311041", 10.0),
    "wo3_mono_old": ("WO3_monoclinic_old", "1528915", 10.0),
    "wo3_tri": ("WO3_triclinic", "2106293", 10.0),
    "wo3_tri_minor": ("WO3_triclinic_minor", "2106293", 0.10),
    "wo3_ortho": ("WO3_orthorhombic", "2107312", 10.0),
    "wo3_ortho_minor": ("WO3_orthorhombic_minor", "2107312", 0.10),
    "wo3_p21m": ("WO3_monoclinic_P21m", "1010618", 10.0),
    "mn2o3_bix": ("Mn2O3_bixbyite", "1514230", 1.5),
    "mn2o3_ortho": ("Mn2O3_orthorhombic", "1514103", 1.5),
    "mn2o3_ortho_minor": ("Mn2O3_orthorhombic_minor", "1514103", 0.10),
    "mn3o4": ("Mn3O4_hausmannite", "9001302", 0.10),
    "mno2": ("MnO2", "1514110", 0.10),
    "mnwo4": ("MnWO4_wolframite", "1520200", 0.10),
    "mn3wo6": ("Mn3WO6", "2002703", 0.10),
    "w18o49": ("W18O49", "1528166", 0.10),
}

MODELS = {
    "mono_only": ["wo3_mono"],
    "mono_bix": ["wo3_mono", "mn2o3_bix"],
    "mono_ortho_mn": ["wo3_mono", "mn2o3_ortho"],
    "tri_bix": ["wo3_tri", "mn2o3_bix"],
    "ortho_bix": ["wo3_ortho", "mn2o3_bix"],
    "p21m_bix": ["wo3_p21m", "mn2o3_bix"],
    "mono_old_bix": ["wo3_mono_old", "mn2o3_bix"],
    "mono_bix_mnwo4": ["wo3_mono", "mn2o3_bix", "mnwo4"],
    "mono_bix_mn3wo6": ["wo3_mono", "mn2o3_bix", "mn3wo6"],
    "mono_bix_w18o49": ["wo3_mono", "mn2o3_bix", "w18o49"],
    "mono_bix_both_tungstates": ["wo3_mono", "mn2o3_bix", "mnwo4", "mn3wo6"],
    "mono_bix_tri_minor": ["wo3_mono", "mn2o3_bix", "wo3_tri_minor"],
    "mono_bix_ortho_wo3_minor": ["wo3_mono", "mn2o3_bix", "wo3_ortho_minor"],
    "mono_bix_ortho_mn_minor": ["wo3_mono", "mn2o3_bix", "mn2o3_ortho_minor"],
    "mono_bix_mn3o4": ["wo3_mono", "mn2o3_bix", "mn3o4"],
    "mono_bix_mno2": ["wo3_mono", "mn2o3_bix", "mno2"],
}


def run_model(model: str) -> dict:
    out = HERE / f"model_{model}.gpx"
    if out.exists():
        out.unlink()

    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(HERE / "inputs/pattern.csv"),
        str(HERE / "cu_ka.instprm"),
        fmthint="comma",
    )
    phase_objects = []
    for key in MODELS[model]:
        name, cid, start_scale = PHASES[key]
        ph = gpx.add_phase(str(cod(cid)), phasename=name, histograms=[hist], fmthint="CIF")
        ph.getHAPvalues(hist.name)["Scale"][:] = [start_scale, False]
        phase_objects.append(ph)

    gpx.set_Controls("cycles", 7)
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "refine": True,
            },
        }
    )
    hist.SampleParameters["Scale"][:] = [1.0, False]

    for ph in phase_objects:
        ph.set_HAP_refinements({"Scale": True})
    gpx.do_refinements([{}])

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    gpx.do_refinements([{}])

    hist.set_refinements({"Instrument Parameters": ["W", "Y"]})
    gpx.do_refinements([{}])

    hist.set_refinements({"Instrument Parameters": ["U", "V", "X"]})
    gpx.do_refinements([{}])

    for ph in phase_objects:
        ph.set_refinements({"Cell": True})
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save()

    try:
        mass = {k: {"value": v[0], "esd": v[1]} for k, v in hist.ComputeMassFracs().items()}
    except Exception:
        # One-phase models intentionally have no GSAS-II mass-fraction result.
        mass = {phase_objects[0].name: {"value": 1.0, "esd": 0.0}}
    result = {
        "model": model,
        "project": out.name,
        "residuals": hist.residuals,
        "mass_fractions": mass,
        "zero": hist.InstrumentParameters["Zero"][1],
        "profile": {
            k: hist.InstrumentParameters[k][1]
            for k in ["U", "V", "W", "X", "Y"]
        },
        "phases": {
            ph.name: {
                "scale": ph.getHAPvalues(hist.name)["Scale"][0],
                "cell": ph.get_cell(),
            }
            for ph in phase_objects
        },
        "n_variables": len(gpx.data["Covariance"]["data"].get("varyList", [])),
        "n_observations": int(sum(1 for xx in hist.data["data"][1][0] if 10.0 <= xx <= 100.0)),
    }
    (HERE / f"model_{model}.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("model", choices=MODELS)
    args = parser.parse_args()
    # GSAS-II is very chatty; retain a concise machine-readable comparison line.
    with contextlib.redirect_stdout(io.StringIO()):
        result = run_model(args.model)
    print(json.dumps(result, separators=(",", ":")))
