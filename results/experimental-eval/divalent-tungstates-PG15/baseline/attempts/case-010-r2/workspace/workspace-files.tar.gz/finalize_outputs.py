from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "test_polarization_converged.gpx"
FINAL = HERE / "final.gpx"

phase_metadata = {
    "WO3_monoclinic": {
        "formula": "WO3",
        "display": "Monoclinic WO3 (gamma-WO3)",
        "cif": "WO3_monoclinic.cif",
        "reference": "COD 2311041",
        "confidence": "high",
    },
    "Mn2O3_bixbyite": {
        "formula": "Mn2O3",
        "display": "Cubic alpha-Mn2O3 (bixbyite)",
        "cif": "Mn2O3_bixbyite.cif",
        "reference": "COD 1514230",
        "confidence": "high",
    },
    "MnWO4_wolframite": {
        "formula": "MnWO4",
        "display": "Monoclinic MnWO4 (wolframite)",
        "cif": "MnWO4_wolframite.cif",
        "reference": "COD 1520200",
        "confidence": "tentative minor phase",
    },
}

# Clone the converged project under the required final name. All subsequent
# exports are made from this object so the CIFs, fractions and profile remain
# tied to one exact GSAS-II state.
project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
project.save()
hist = project.histogram(0)

fractions = hist.ComputeMassFracs()
residuals = hist.residuals
covariance = project.data["Covariance"]["data"]
rvals = covariance.get("Rvals", {})

phases_out = []
for phase in project.phases():
    meta = phase_metadata[phase.name]
    cif_path = HERE / meta["cif"]
    phase.export_CIF(str(cif_path))
    fraction, esd = fractions[phase.name]
    phase_id = phase.id
    phases_out.append(
        {
            "name": meta["display"],
            "project_phase_name": phase.name,
            "formula": meta["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": meta["cif"],
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(esd),
            "weight_percent": float(100.0 * fraction),
            "weight_percent_esd": float(100.0 * esd),
            "confidence": meta["confidence"],
            "reference_structure": meta["reference"],
            "cell": {k: float(v) for k, v in phase.get_cell().items()},
            "bragg_Rf_percent": float(residuals[f"{phase_id}:0:Rf"]),
            "bragg_Rf2_percent": float(residuals[f"{phase_id}:0:Rf^2"]),
        }
    )

profile = hist.data["data"][1]
with (HERE / "fit.csv").open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "difference_observed_minus_calculated",
            "calculated_background",
        ]
    )
    for x, yobs, ycalc, ydiff, background in zip(
        profile[0], profile[1], profile[3], profile[5], profile[4]
    ):
        writer.writerow(
            [
                f"{float(x):.8f}",
                f"{float(yobs):.8f}",
                f"{float(ycalc):.8f}",
                f"{float(ydiff):.8f}",
                f"{float(background):.8f}",
            ]
        )

gof = float(rvals["GOF"])
result = {
    "pattern_path": "inputs/pattern.csv",
    "project_path": "final.gpx",
    "weight_fraction_basis": "normalized over the modeled crystalline phases",
    "number_of_modeled_crystalline_phases": len(phases_out),
    "phases": phases_out,
    "fit_statistics": {
        "Rp_percent": float(residuals["R"]),
        "Rwp_percent": float(residuals["wR"]),
        "Rexp_percent": float(residuals["wRmin"]),
        "goodness_of_fit": gof,
        "reduced_chi_square": gof * gof,
        "chi_square": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_variables": int(rvals["Nvars"]),
        "max_shift_over_esd_final_cycle": float(rvals["Max shft/sig"]),
        "background_subtracted_Rp_percent": float(residuals["Rb"]),
        "background_subtracted_Rwp_percent": float(residuals["wRb"]),
    },
    "measurement_model": {
        "radiation": "Cu K-alpha1 + K-alpha2",
        "wavelength_Kalpha1_angstrom": float(hist.InstrumentParameters["Lam1"][1]),
        "wavelength_Kalpha2_angstrom": float(hist.InstrumentParameters["Lam2"][1]),
        "Kalpha2_to_Kalpha1_ratio": float(hist.InstrumentParameters["I(L2)/I(L1)"][1]),
        "refined_zero_offset_deg_two_theta": float(hist.InstrumentParameters["Zero"][1]),
        "refined_polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "profile_range_deg_two_theta": [
            float(hist.data["Limits"][1][0]),
            float(hist.data["Limits"][1][1]),
        ],
        "weights": "Poisson approximation 1/I because pointwise uncertainties were not supplied",
    },
    "uncertainty_note": (
        "Reported esds are covariance-matrix values. Practical quantitative-phase uncertainty is larger "
        "because no calibrated instrumental profile, particle-size/microabsorption information, or "
        "independent standard was supplied. The approximately 1 wt% MnWO4 assignment is tentative."
    ),
}

(HERE / "result.json").write_text(json.dumps(result, indent=2) + "\n")

phase_rows = "\n".join(
    f"| {p['name']} | {p['space_group']} | {p['weight_percent']:.2f} +/- {p['weight_percent_esd']:.2f} | {p['confidence']} |"
    for p in phases_out
)

report = f"""# Powder diffraction phase analysis

## Result

The crystalline model contains three phases, normalized over the modeled crystalline material:

| Phase | Space group | Weight percent (formal esd) | Confidence |
|---|---:|---:|---|
{phase_rows}

The sample is therefore predominantly unreacted monoclinic WO3 and cubic alpha-Mn2O3, with about 1 wt% MnWO4 as a weak reaction product. The WO3 CIF uses the valid nonconventional P 21/c setting inherited from the best-matching neutron reference; its beta angle is consequently about 136 degrees rather than the more familiar near-91-degree setting.

## Evidence and refinement

Monoclinic WO3 is identified by the intense 23.43, 23.91, and 24.68 degree triplet and the complete higher-angle line sequence. Cubic Mn2O3 is independently required by lines at approximately 33.27, 38.53, 49.60, 55.49, and 66.03 degrees. A WO3-only control gave Rwp = 10.59%, compared with 6.94% for WO3 + Mn2O3. The minor MnWO4 model adds weak, independently positioned intensity near 18.84, 30.14, 30.57, and 36.09 degrees and lowers the weighted residual further. Mn3WO6 and common manganese-oxide alternatives fit less well.

The final GSAS-II refinement used the full {hist.data['Limits'][1][0]:.6f}-{hist.data['Limits'][1][1]:.6f} degree range, the reported Cu Kalpha1/Kalpha2 wavelengths and 0.5 intensity ratio, a 12-term Chebyshev background, refined zero/profile/polarization terms, phase scales, and the WO3 and Mn2O3 cells. The weak MnWO4 cell was provisionally refined and then fixed for stable final cycles. Atomic coordinates were held to reference values: attempts to refine WO3 heavy-atom coordinates produced about 98% correlations and oscillatory shifts, so the data do not determine atomic positions reliably.

Final statistics are Rp = {residuals['R']:.3f}%, Rwp = {residuals['wR']:.3f}%, Rexp = {residuals['wRmin']:.3f}%, and goodness of fit = {gof:.3f}. The final maximum shift/esd was {rvals['Max shft/sig']:.3f}.

## Remaining uncertainty

The MnWO4 assignment is tentative because its fraction is near the laboratory-data detection limit and many of its reflections overlap the two major phases. Its strongest contribution is nevertheless supported by several non-overlapped residual features. Background/range tests placed it at roughly 0.7-1.0 wt%; a practical uncertainty of about +/-0.3 wt% is more realistic than the formal +/-{100.0 * phases_out[2]['weight_fraction_esd']:.2f} wt% esd. A small orthorhombic-WO3 component can numerically improve peak shoulders, but it lacks independent reflections and is indistinguishable from anisotropic broadening without a calibrated instrument profile, so it was not counted as a separate phase.

The major-phase formal errors (about 0.2 wt%) likewise omit microabsorption, preferred-orientation, and profile-model systematics. Practical uncertainties of order 1-2 wt% for the major fractions are appropriate. No amorphous fraction or absolute crystalline content can be obtained without an internal standard; all fractions here are normalized only over the three modeled crystalline phases.
"""

(HERE / "report.md").write_text(report)
print(json.dumps(result, indent=2))
