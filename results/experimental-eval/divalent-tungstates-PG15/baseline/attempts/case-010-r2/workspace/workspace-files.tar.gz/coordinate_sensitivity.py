from __future__ import annotations

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "sensitivity_range_full.gpx"


def run(tag, atom_sets):
    p = G2sc.G2Project(str(SOURCE), newgpx=str(HERE / f"coordinate_{tag}.gpx"))
    h = p.histogram(0)
    for phase_index, labels in atom_sets.items():
        p.phase(phase_index).set_refinements({"Atoms": {label: "X" for label in labels}})
    p.set_Controls("cycles", 7)
    p.do_refinements([{}])
    p.do_refinements([{}])
    p.save()
    return {
        "tag": tag,
        "Rwp": h.residuals["wR"],
        "fractions": {k: {"value": v[0], "esd": v[1]} for k, v in h.ComputeMassFracs().items()},
        "atoms": {
            ph.name: {a.label: list(a.coordinates) for a in ph.atoms()}
            for ph in p.phases()
        },
        "n_variables": len(p.data["Covariance"]["data"].get("varyList", [])),
    }


cases = [
    ("wo3_W", {0: ["W1", "W2"]}),
    ("mn2o3", {1: ["Mn2", "O1"]}),
    ("wo3_W_mn2o3", {0: ["W1", "W2"], 1: ["Mn2", "O1"]}),
    ("wo3_all", {0: ["O6", "O2", "W1", "O5", "O3", "O1", "W2", "O4"]}),
]

with contextlib.redirect_stdout(io.StringIO()):
    results = [run(*case) for case in cases]
print(json.dumps(results, indent=2))
