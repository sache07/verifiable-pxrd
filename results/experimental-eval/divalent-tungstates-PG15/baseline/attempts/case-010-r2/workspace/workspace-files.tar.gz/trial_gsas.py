from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc

HERE = Path(__file__).resolve().parent
WO3 = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif")
MN2O3 = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/51/42/1514230.cif")

gpx = G2sc.G2Project(newgpx=str(HERE / "trial.gpx"))
hist = gpx.add_powder_histogram(str(HERE / "inputs/pattern.csv"), str(HERE / "cu_ka.instprm"), fmthint="comma")
p1 = gpx.add_phase(str(WO3), phasename="WO3_monoclinic", histograms=[hist], fmthint="CIF")
p2 = gpx.add_phase(str(MN2O3), phasename="Mn2O3_bixbyite", histograms=[hist], fmthint="CIF")

gpx.set_Controls("cycles", 8)
hist.set_refinements({"Limits": [10.0, 100.0], "Background": {"type": "chebyschev-1", "no. coeffs": 12, "refine": True}})
# Absolute histogram scale and HAP scales are exactly correlated. Keep the
# former fixed so both phase scales (and hence mass fractions) are estimable.
hist.SampleParameters["Scale"][:] = [1.0, False]
p1.getHAPvalues(hist.name)["Scale"][:] = [10.0, False]
p2.getHAPvalues(hist.name)["Scale"][:] = [1.5, False]

def status(label):
    print("\nSTATUS", label)
    print("residuals", hist.residuals)
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items() if k in ["Lam1","Lam2","I(L2)/I(L1)","Zero","U","V","W","X","Y","Z","SH/L"]})
    for ph in gpx.phases():
        print(ph.name, "cell", ph.get_cell(), "mass", ph.composition, "HAP", ph.getHAPvalues(hist.name))
    try:
        print("massfracs", hist.ComputeMassFracs())
    except Exception as exc:
        print("massfracs error", repr(exc))

# Establish background and phase scale factors with fixed positions/profile.
for ph in gpx.phases():
    ph.set_HAP_refinements({"Scale": True})
gpx.do_refinements([{}])
status("scales-background")

# Refine the common displacement first.
hist.set_refinements({"Instrument Parameters": ["Zero"]})
gpx.do_refinements([{}])
status("zero")

# Add the dominant Gaussian and Lorentzian profile terms in stages.
hist.set_refinements({"Instrument Parameters": ["W", "Y"]})
gpx.do_refinements([{}])
status("profile-WY")
hist.set_refinements({"Instrument Parameters": ["U", "V", "X"]})
gpx.do_refinements([{}])
status("instrument-profile")

# Refine lattice metrics after the common offset/profile are stable.
for ph in gpx.phases():
    ph.set_refinements({"Cell": True})
gpx.do_refinements([{}])
status("zero-cell")

# Add isotropic sample broadening by phase.
for ph in gpx.phases():
    ph.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 1.0, "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
gpx.do_refinements([{}])
status("sample-profile")

gpx.save()

d = hist.data["data"][1]
print("arrays", [a.shape for a in d], "first", [float(a[0]) for a in d])
