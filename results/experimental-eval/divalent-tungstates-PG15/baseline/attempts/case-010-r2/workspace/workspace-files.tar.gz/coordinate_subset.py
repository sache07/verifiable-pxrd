from __future__ import annotations

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "sensitivity_range_full.gpx"


def run(tag, phase_index, labels):
    p = G2sc.G2Project(str(SOURCE), newgpx=str(HERE / f"subset_{tag}.gpx"))
    h = p.histogram(0)
    ph = p.phase(phase_index)
    ph.set_refinements({"Atoms": {label: "X" for label in labels}})
    p.set_Controls("cycles", 9)
    for _ in range(4):
        p.do_refinements([{}])
    p.save()
    c = p.data["Covariance"]["data"]
    return {
        "tag": tag,
        "Rwp": h.residuals["wR"],
        "GOF": c.get("Rvals", {}).get("GOF"),
        "max_shift_esd": c.get("Rvals", {}).get("Max shft/sig"),
        "message": c.get("Rvals", {}).get("msg"),
        "fractions": {k: {"value": v[0], "esd": v[1]} for k, v in h.ComputeMassFracs().items()},
        "coordinates": {a.label: list(a.coordinates) for a in ph.atoms()},
    }


with contextlib.redirect_stdout(io.StringIO()):
    results = [
        run("wo3_W1", 0, ["W1"]),
        run("wo3_W2", 0, ["W2"]),
        run("mn2o3_Mn2", 1, ["Mn2"]),
    ]
print(json.dumps(results, indent=2))
