import numpy as np
import pandas as pd
from scipy.ndimage import minimum_filter1d, gaussian_filter1d
from scipy.signal import find_peaks, peak_widths
import matplotlib.pyplot as plt

df = pd.read_csv("inputs/pattern.csv")
x = df.iloc[:, 0].to_numpy(float)
y = df.iloc[:, 1].to_numpy(float)

# A broad rolling minimum followed by smoothing gives a conservative baseline
# suitable only for peak discovery (GSAS-II will refine its own background).
step = float(np.median(np.diff(x)))
baseline = gaussian_filter1d(minimum_filter1d(y, size=max(5, round(2.5 / step))), 0.45 / step)
signal = y - baseline
noise = 1.4826 * np.median(np.abs(np.diff(y) - np.median(np.diff(y)))) / np.sqrt(2)
idx, props = find_peaks(signal, prominence=max(6 * noise, 80), distance=max(2, round(0.08 / step)), width=1)
width = peak_widths(signal, idx, rel_height=0.5)[0] * step
order = np.argsort(props["prominences"])[::-1]

print(f"points={len(x)} range={x[0]:.6f}..{x[-1]:.6f} step={step:.8f}")
print(f"intensity min/median/max={y.min():.1f}/{np.median(y):.1f}/{y.max():.1f}; diff-noise~{noise:.2f}")
print(f"detected peaks={len(idx)}")
print("rank  2theta       Iobs    prominence   FWHM")
for rank, j in enumerate(order[:100], 1):
    i = idx[j]
    print(f"{rank:3d} {x[i]:10.5f} {y[i]:10.1f} {props['prominences'][j]:11.1f} {width[j]:7.4f}")

fig, ax = plt.subplots(figsize=(16, 7))
ax.plot(x, y, lw=0.65, color="black")
ax.plot(x, baseline, lw=0.8, color="tab:orange")
ax.scatter(x[idx], y[idx], s=8, color="tab:red", zorder=3)
ax.set(xlabel=r"$2\theta$ (deg, Cu K$\alpha$)", ylabel="Counts", xlim=(x.min(), x.max()))
fig.tight_layout()
fig.savefig("pattern_overview.png", dpi=160)

fig, axes = plt.subplots(3, 1, figsize=(16, 10))
for ax, (lo, hi) in zip(axes, [(9.9, 40), (38, 70), (68, 100.1)]):
    sel = (x >= lo) & (x <= hi)
    ax.plot(x[sel], y[sel], lw=0.7, color="black")
    psel = idx[(x[idx] >= lo) & (x[idx] <= hi)]
    ax.scatter(x[psel], y[psel], s=9, color="tab:red")
    ax.set_xlim(lo, hi)
    ax.set_ylabel("Counts")
axes[-1].set_xlabel(r"$2\theta$ (deg, Cu K$\alpha$)")
fig.tight_layout()
fig.savefig("pattern_segments.png", dpi=160)
