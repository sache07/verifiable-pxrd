from __future__ import annotations

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "sensitivity_range_full.gpx"


def run(tag, phase_index, axis):
    p = G2sc.G2Project(str(SOURCE), newgpx=str(HERE / f"texture_{tag}.gpx"))
    h = p.histogram(0)
    ph = p.phase(phase_index)
    po = ph.getHAPvalues(h.name)["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)
    p.set_Controls("cycles", 7)
    p.do_refinements([{}])
    p.do_refinements([{}])
    p.save()
    return {
        "tag": tag,
        "phase": ph.name,
        "axis": axis,
        "MD": po[1],
        "Rwp": h.residuals["wR"],
        "fractions": {k: {"value": v[0], "esd": v[1]} for k, v in h.ComputeMassFracs().items()},
    }


cases = [
    ("wo3_100", 0, [1, 0, 0]),
    ("wo3_010", 0, [0, 1, 0]),
    ("wo3_001", 0, [0, 0, 1]),
    ("wo3_10m1", 0, [1, 0, -1]),
    ("wo3_101", 0, [1, 0, 1]),
    ("mn2o3_111", 1, [1, 1, 1]),
    ("mn2o3_100", 1, [1, 0, 0]),
]

with contextlib.redirect_stdout(io.StringIO()):
    results = [run(*case) for case in cases]
print(json.dumps(results, indent=2))
