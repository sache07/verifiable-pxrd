import gzip
import json
from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import minimum_filter1d, gaussian_filter1d
from scipy.optimize import nnls

ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
INFO = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")

df = pd.read_csv("inputs/pattern.csv")
x = df.iloc[:, 0].to_numpy(float)
y = df.iloc[:, 1].to_numpy(float)
step = np.median(np.diff(x))
bg0 = gaussian_filter1d(minimum_filter1d(y, size=round(2.5 / step)), 0.45 / step)

with gzip.open(INFO, "rt") as f:
    info = json.load(f)

rows = []
for key in ("Mn-O", "O-W", "Mn-O-W"):
    rows.extend((key, *r) for r in info[key])

def cif_path(codid):
    return ROOT / codid[0] / codid[1:3] / codid[3:5] / f"{codid}.cif"

def sticks(struct, wavelength):
    pat = XRDCalculator(wavelength=wavelength, symprec=0).get_pattern(
        struct, two_theta_range=(x[0] - 1, x[-1] + 1), scaled=False
    )
    return np.asarray(pat.x), np.asarray(pat.y)

def profile(sticksets, shift, fwhm0=0.14, fwhm_tan=0.08):
    out = np.zeros_like(x)
    # Gaussian approximation, evaluated locally with a width increasing with tan(theta).
    for sx, sy, weight in sticksets:
        for pos, inten in zip(sx + shift, sy * weight):
            if pos < x[0] - 1 or pos > x[-1] + 1:
                continue
            theta = np.deg2rad(pos / 2)
            fwhm = np.sqrt(fwhm0**2 + (fwhm_tan * np.tan(theta))**2)
            sigma = fwhm / 2.35482
            lo = np.searchsorted(x, pos - 4 * sigma)
            hi = np.searchsorted(x, pos + 4 * sigma)
            if hi > lo:
                out[lo:hi] += inten * np.exp(-0.5 * ((x[lo:hi] - pos) / sigma) ** 2)
    return out

# Smooth background basis; profile coefficient constrained nonnegative by nnls.
t = 2 * (x - x.min()) / (x.max() - x.min()) - 1
poly = np.column_stack([np.ones_like(t), t, t**2, t**3, t**4, t**5])
weights = 1 / np.sqrt(np.maximum(y, 1))

results = []
for key, formula, codid, sg, rval in rows:
    p = cif_path(codid)
    try:
        s = Structure.from_file(p, primitive=False)
        ss = [(*sticks(s, 1.540598), 1.0), (*sticks(s, 1.544426), 0.5)]
    except Exception as exc:
        print("SKIP", codid, formula, repr(exc))
        continue
    best = None
    for shift in np.arange(-0.60, 0.601, 0.02):
        calc = profile(ss, shift)
        # Fit profile and flexible polynomial, using ordinary LS; negative scale is rejected.
        A = np.column_stack([calc, poly])
        coef, *_ = np.linalg.lstsq(A * weights[:, None], y * weights, rcond=None)
        if coef[0] <= 0:
            continue
        resid = (y - A @ coef) * weights
        score = np.mean(resid**2)
        if best is None or score < best[0]:
            best = (score, shift, coef[0], s)
    if best:
        results.append((best[0], key, formula, codid, sg, rval, best[1], best[2], best[3]))

results.sort(key=lambda z: z[0])
print("rank score set formula codid SG R shift scale lattice")
for i, z in enumerate(results, 1):
    score, key, formula, codid, sg, rval, shift, scale, s = z
    print(i, f"{score:.4g}", key, formula, codid, sg, rval, f"shift={shift:+.3f}", f"scale={scale:.4g}", s.lattice)
    if i <= 12:
        pat = XRDCalculator(wavelength=1.540598, symprec=0).get_pattern(s, two_theta_range=(9.9, 60), scaled=True)
        top = sorted(zip(pat.y, pat.x, pat.hkls), reverse=True)[:18]
        print(" peaks:", " ".join(f"{px:.3f}({py:.0f})" for py, px, _ in top))
