from __future__ import annotations

import contextlib
import io
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "model_mono_bix_mnwo4.gpx"


def refine_variant(tag, n_background=12, limits=None, clear_profile=()):
    out = HERE / f"sensitivity_{tag}.gpx"
    p = G2sc.G2Project(str(SOURCE), newgpx=str(out))
    h = p.histogram(0)
    h.set_refinements(
        {
            "Background": {"no. coeffs": n_background, "refine": True},
            **({"Limits": limits} if limits else {}),
        }
    )
    if clear_profile:
        h.clear_refinements({"Instrument Parameters": list(clear_profile)})
    p.set_Controls("cycles", 7)
    p.do_refinements([{}])
    p.do_refinements([{}])
    p.save()
    return {
        "tag": tag,
        "background_coefficients": n_background,
        "limits": h.data["Limits"][1],
        "cleared_profile": list(clear_profile),
        "Rwp": h.residuals["wR"],
        "fractions": {
            k: {"value": v[0], "esd": v[1]}
            for k, v in h.ComputeMassFracs().items()
        },
    }


variants = [
    ("bg8", 8, None, ()),
    ("bg10", 10, None, ()),
    ("bg16", 16, None, ()),
    ("bg20", 20, None, ()),
    ("range_full", 12, [9.90343322, 100.09488522], ()),
    ("range_10_80", 12, [10.0, 80.0], ()),
    ("range_20_100", 12, [20.0, 100.0], ()),
    ("fixed_profile", 12, None, ("U", "V", "W", "X", "Y")),
]

with contextlib.redirect_stdout(io.StringIO()):
    results = [refine_variant(*args) for args in variants]
print(json.dumps(results, indent=2))
