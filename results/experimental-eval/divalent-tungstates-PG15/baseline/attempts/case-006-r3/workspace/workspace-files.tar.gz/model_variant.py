#!/usr/bin/env python3
"""Test narrowly scoped refinements against the current two-phase model."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2sc


variant = sys.argv[1]
base = sys.argv[2]
out = sys.argv[3]
p = G2sc.G2Project(gpxfile=base, newgpx=out)
h = p.histogram(0)
x = h.data["data"][1][0]
h.Limits("lower", float(x[0]))
h.Limits("upper", float(x[-1]))
p.set_Controls("cycles", 12)
p.data["Controls"]["data"]["min dM/M"] = 1.0e-6

if variant == "base":
    pass
elif variant == "shl":
    h.set_refinements({"Instrument Parameters": ["SH/L"]})
elif variant == "shl_z":
    h.set_refinements({"Instrument Parameters": ["SH/L", "Z"]})
elif variant == "z":
    h.set_refinements({"Instrument Parameters": ["Z"]})
elif variant == "background16":
    h.set_refinements({"Background": {"type": "chebyschev-1", "refine": True,
                                      "no. coeffs": 16}})
elif variant == "cu_o_xyz":
    phase = p.phase(0)
    for atom in phase.atoms():
        if atom.element != "W":
            atom.refinement_flags = "X"
elif variant == "o_xyz":
    phase = p.phase(0)
    for atom in phase.atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
elif variant == "cu_xyz":
    phase = p.phase(0)
    for atom in phase.atoms():
        if atom.element == "Cu":
            atom.refinement_flags = "X"
elif variant == "pref001":
    p.phase(0).set_HAP_refinements({"Pref.Ori.": True}, [h])
else:
    raise ValueError(variant)

p.save()
p.refine()
p.save()

print("VARIANT", variant)
print("RESIDUALS", h.residuals)
print("FRACTIONS", h.ComputeMassFracs())
print("INSTRUMENT", {k: v for k, v in h.InstrumentParameters.items()
                     if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)")})
print("RVALS", p.data["Covariance"]["data"].get("Rvals"))
for phase in p.phases():
    print("PHASE", phase.name, phase.get_cell())
    print("HAP", phase.getHAPvalues(h.name))
    for atom in phase.atoms():
        print("ATOM", atom.label, atom.element, atom.coordinates, atom.uiso, atom.refinement_flags)
