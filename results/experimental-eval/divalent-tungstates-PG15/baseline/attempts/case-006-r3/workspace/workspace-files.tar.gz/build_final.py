#!/usr/bin/env python3
"""Build and export the final two-phase GSAS-II Rietveld model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "inputs" / "pattern.csv"
TMP = ROOT / ".tmp"
XYE = TMP / "final_pattern.xye"
INST = TMP / "final_lab_cuka.instprm"
GPX = ROOT / "final.gpx"
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_histogram_files() -> np.ndarray:
    TMP.mkdir(parents=True, exist_ok=True)
    arr = np.genfromtxt(INPUT, delimiter=",", names=True)
    sigma = np.sqrt(np.maximum(arr["intensity"], 1.0))
    np.savetxt(
        XYE,
        np.column_stack((arr["two_theta_deg"], arr["intensity"], sigma)),
        fmt=("%.8f", "%.8f", "%.8f"),
        header="2theta intensity sigma",
    )
    INST.write_text(
        "#GSAS-II instrument parameter file for measured Cu Kalpha lab data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.300;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:20.0;V:0.0;W:30.0;X:1.0;Y:1.0;Z:0.0;SH/L:0.002\n"
    )
    return arr


def refinement_summary(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(label, hist.residuals)
    for phase in project.phases():
        print(label, phase.name, phase.get_cell(), phase.getHAPvalues(hist.name)["Scale"])


def refine(project: G2sc.G2Project, label: str) -> None:
    print(f"\n--- {label} ---")
    project.refine()
    refinement_summary(project, label)


def json_float(value):
    return float(value) if value is not None else None


def main() -> None:
    arr = prepare_histogram_files()
    project = G2sc.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(str(XYE), str(INST), fmthint="xye")
    hist.Limits("lower", float(arr["two_theta_deg"][0]))
    hist.Limits("upper", float(arr["two_theta_deg"][-1]))

    cuwo4 = project.add_phase(
        str(cod_path("4000806")), phasename="CuWO4", histograms=[hist], fmthint="CIF"
    )
    wo3 = project.add_phase(
        str(cod_path("1528915")), phasename="WO3", histograms=[hist], fmthint="CIF"
    )

    # Use a close ambient-pressure CuWO4 cell as the start. Atomic coordinates
    # remain those of COD 4000806 until the Cu site is refined below.
    cuwo4_start = [4.7026, 5.8389, 4.8785, 91.68, 92.47, 82.81]
    cuwo4.data["General"]["Cell"][1:7] = cuwo4_start
    cuwo4.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cuwo4_start))

    # Avoid the exact degeneracy between global histogram and phase scales.
    hist.SampleParameters["Scale"] = [1.0, False]
    cuwo4.data["Histograms"][hist.name]["Scale"] = [90.0, False]
    wo3.data["Histograms"][hist.name]["Scale"] = [0.7, False]

    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.save()

    # Staged refinement limits parameter correlations and keeps the trace phase
    # cell stable until its scale is established.
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12}}
    )
    cuwo4.set_HAP_refinements({"Scale": True}, [hist])
    wo3.set_HAP_refinements({"Scale": True}, [hist])
    refine(project, "background and phase scales")

    cuwo4.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "major-phase cell and zero")

    wo3.set_refinements({"Cell": True})
    refine(project, "both phase cells")

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
    refine(project, "profile coefficients")

    # W fixes the coordinate frame and O coordinates are too weakly constrained
    # by these X-ray data. Only the Cu site is released.
    for atom in cuwo4.atoms():
        if atom.element == "Cu":
            atom.refinement_flags = "X"
    refine(project, "Cu coordinate")

    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 16}}
    )
    refine(project, "final background")
    refine(project, "final convergence")
    project.save()

    residuals = hist.residuals
    fractions = hist.ComputeMassFracs()
    covariance = project.data["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})

    # Export one phase CIF directly from this final project.
    cif_names = {"CuWO4": "CuWO4.cif", "WO3": "WO3.cif"}
    for phase in project.phases():
        phase.export_CIF(str(ROOT / cif_names[phase.name]))

    # GSAS-II stores total calculated intensity (including background) and
    # observed-minus-calculated difference in rows 3 and 5, respectively.
    x, yobs, weight, ycalc, background, difference = hist.data["data"][1]
    profile = np.column_stack(
        (
            np.asarray(x, dtype=float),
            np.asarray(yobs, dtype=float),
            np.asarray(ycalc, dtype=float),
            np.asarray(difference, dtype=float),
            np.asarray(background, dtype=float),
        )
    )
    np.savetxt(
        ROOT / "fit.csv",
        profile,
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference_observed_minus_calculated,background",
        comments="",
        fmt="%.8g",
    )

    phase_records = []
    source_ids = {"CuWO4": "4000806", "WO3": "1528915"}
    for index, phase in enumerate(project.phases()):
        cell, cell_esd = phase.get_cell_and_esd()
        fraction, fraction_esd = fractions[phase.name]
        key = f"{index}:0:Rf^2"
        phase_records.append(
            {
                "name": phase.name,
                "formula": phase.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": cif_names[phase.name],
                "weight_fraction": json_float(fraction),
                "weight_fraction_esd": json_float(fraction_esd),
                "cell_angstrom_degrees": {k: json_float(v) for k, v in cell.items()},
                "cell_esd": {k: json_float(v) for k, v in cell_esd.items()},
                "R_F_squared_percent": json_float(residuals.get(key)),
                "reference_cod_id": source_ids[phase.name],
            }
        )

    result = {
        "phases": phase_records,
        "fit_statistics": {
            "R_wp_percent": json_float(residuals.get("wR")),
            "R_p_percent": json_float(residuals.get("R")),
            "R_exp_percent": json_float(residuals.get("wRmin")),
            "goodness_of_fit": json_float(rvals.get("GOF")),
            "total_chi_squared": json_float(rvals.get("chisq")),
            "reduced_chi_squared": json_float(
                rvals.get("chisq", 0.0) / max(1, rvals.get("Nobs", 0) - rvals.get("Nvars", 0))
            ),
            "n_observations": int(rvals.get("Nobs", len(profile))),
            "n_refined_variables": int(rvals.get("Nvars", 0)),
        },
        "profile_path": "fit.csv",
        "gsas_project_path": "final.gpx",
        "weighting": "sigma=sqrt(counts), since pointwise uncertainties were not supplied",
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    project.save()
    print("\nFINAL RESULT")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
