#!/usr/bin/env python3
"""Exploratory GSAS-II Rietveld refinement for the supplied PXRD pattern."""

from pathlib import Path
import json
import sys

import numpy as np

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
CSV = ROOT / "inputs" / "pattern.csv"
XYE = ROOT / ".tmp" / "pattern.xye"
INST = ROOT / ".tmp" / "lab_cuka.instprm"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_inputs() -> None:
    XYE.parent.mkdir(parents=True, exist_ok=True)
    arr = np.genfromtxt(CSV, delimiter=",", names=True)
    # With no supplied point uncertainties, use counting-statistical sigma.
    sigma = np.sqrt(np.maximum(arr["intensity"], 1.0))
    np.savetxt(
        XYE,
        np.column_stack((arr["two_theta_deg"], arr["intensity"], sigma)),
        fmt=("%.8f", "%.8f", "%.8f"),
        header="2theta intensity sigma",
    )
    INST.write_text(
        "#GSAS-II instrument parameter file for measured Cu Kalpha lab data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.300;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:20.0;V:0.0;W:30.0;X:1.0;Y:1.0;Z:0.0;SH/L:0.002\n"
    )


def summarize(gpx: G2sc.G2Project, tag: str) -> None:
    hist = gpx.histogram(0)
    print(f"\nSUMMARY {tag}")
    print("residuals", hist.residuals)
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)")})
    print("background", hist.Background[0])
    for phase in gpx.phases():
        print("phase", phase.name, "cell", phase.get_cell())
        print("hap", phase.getHAPvalues(hist.name))
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fractions unavailable", repr(exc))


def build(outname: str, phase_ids: list[str]) -> None:
    prepare_inputs()
    out = ROOT / outname
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(str(XYE), str(INST), fmthint="xye")
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)

    phases = []
    for cod_id in phase_ids:
        name = {
            "4000806": "CuWO4_P-1",
            "4000807": "CuWO4_P2c",
            "1011194": "CuO_C2c",
            "9016057": "CuO_Cc",
            "1010618": "WO3_P21m",
            "1528915": "WO3_P21c",
            "2106293": "WO3_P-1",
            "2107312": "WO3_Pnma",
        }.get(cod_id, cod_id)
        phase = gpx.add_phase(str(cod_path(cod_id)), phasename=name,
                              histograms=[hist], fmthint="CIF")
        phases.append(phase)

    # A modern ambient CuWO4 cell provides a close start; coordinates are from
    # COD 4000806. Refinement determines the final cell from this dataset.
    if phase_ids and phase_ids[0] == "4000806":
        cell = [4.7026, 5.8389, 4.8785, 91.68, 92.47, 82.81]
        phases[0].data["General"]["Cell"][1:7] = cell
        phases[0].data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))

    # Keep the global histogram scale fixed so phase scales are identifiable.
    hist.SampleParameters["Scale"] = [1.0, False]

    # Sensible initial phase scales for staged least-squares refinement.
    for index, phase in enumerate(phases):
        phase.data["Histograms"][hist.name]["Scale"][0] = 90.0 if index == 0 else 1.0

    gpx.set_Controls("cycles", 8)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    gpx.save()
    summarize(gpx, "initial")

    steps = [
        {"set": {"Background": {"type": "chebyschev-1", "refine": True,
                                  "no. coeffs": 12}, "Scale": True}},
        {"set": {"Cell": True, "Instrument Parameters": ["Zero"]}},
        {"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}},
    ]
    for i, step in enumerate(steps, start=1):
        print(f"\nREFINEMENT STEP {i}: {step}")
        gpx.do_refinements([step])
        summarize(gpx, f"step {i}")
    gpx.save()

    # Save a compact machine-readable snapshot for comparing trial models.
    data = hist.data["data"][1]
    trial = {
        "gpx": str(out),
        "residuals": gpx.histogram(0).residuals,
        "phases": [
            {"name": p.name, "cell": p.get_cell(),
             "hap": p.getHAPvalues(gpx.histogram(0).name)} for p in gpx.phases()
        ],
    }
    (ROOT / ".tmp" / (Path(outname).stem + ".json")).write_text(json.dumps(trial, indent=2, default=float))


if __name__ == "__main__":
    outname = sys.argv[1] if len(sys.argv) > 1 else ".tmp/trial_cuwo4.gpx"
    phase_ids = sys.argv[2:] or ["4000806"]
    build(outname, phase_ids)
