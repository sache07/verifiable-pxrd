#!/usr/bin/env python3
"""Staged two-phase GSAS-II refinement for ZnWO4 + monoclinic WO3."""

from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "fixed_1528915_P21c.gpx"
PROJECT = ROOT / "working.gpx"


def snapshot(project, label):
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    info = {
        "label": label,
        "residuals": hist.residuals,
        "fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "scales": {
            phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()
        },
        "instrument": {
            key: value[1]
            for key, value in hist.data["Instrument Parameters"][0].items()
            if isinstance(value, list) and len(value) > 1
        },
        "shift": hist.data["Sample Parameters"]["Shift"][0],
        "vary": cov.get("varyList", []),
        "sig": cov.get("sig", []).tolist() if hasattr(cov.get("sig", []), "tolist") else cov.get("sig", []),
    }
    print("SNAPSHOT", json.dumps(info, default=str, sort_keys=True), flush=True)


def run(project, label, cycles=5):
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    snapshot(project, label)


def freeze_all_but_scales(project):
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})


def main():
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(SOURCE), newgpx=str(PROJECT))
    hist = project.histogram(0)
    znwo4, wo3 = project.phases()
    freeze_all_but_scales(project)
    project.save()
    snapshot(project, "start")

    # Refine each lattice against its own line positions while the common profile is fixed.
    wo3.set_refinements({"Cell": True})
    run(project, "wo3_cell", cycles=5)
    wo3.clear_refinements({"Cell": True})
    znwo4.set_refinements({"Cell": True})
    run(project, "znwo4_cell", cycles=5)

    # Flexible but smooth background, then common specimen displacement.
    hist.set_refinements({
        "Background": {"type": "chebyschev-1", "no. coeffs": 16, "refine": True}
    })
    run(project, "background", cycles=5)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run(project, "sample_shift", cycles=5)

    # Re-establish the shared profile with the two-phase model.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    run(project, "gaussian_profile", cycles=6)
    hist.set_refinements({"Instrument Parameters": ["X", "Y"]})
    run(project, "lorentzian_profile", cycles=6)
    hist.set_refinements({"Instrument Parameters": ["SH/L", "I(L2)/I(L1)"]})
    run(project, "asymmetry_doublet", cycles=5)

    # Refine coordinates only for the dominant phase; keep all ADPs and WO3 atoms fixed.
    znwo4.set_refinements({"Atoms": {"all": "X"}})
    run(project, "znwo4_coordinates", cycles=7)

    # Final joint lattice/profile/background cycle from the staged solution.
    wo3.set_refinements({"Cell": True})
    run(project, "joint_final", cycles=7)
    project.save()


if __name__ == "__main__":
    main()
