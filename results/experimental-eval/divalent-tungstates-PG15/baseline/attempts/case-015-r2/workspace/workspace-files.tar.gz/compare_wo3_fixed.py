#!/usr/bin/env python3
"""Fast fixed-cell scale comparison for candidate WO3 polymorphs."""

from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = {
    "1010618_P21m": COD / "1/01/06/1010618.cif",
    "1521532_P4ncc": COD / "1/52/15/1521532.cif",
    "1521533_P4nmm": COD / "1/52/15/1521533.cif",
    "1528915_P21c": COD / "1/52/89/1528915.cif",
    "2311041_P21c_alt": COD / "2/31/10/2311041.cif",
    "2106293_P-1": COD / "2/10/62/2106293.cif",
    "2107312_Pnma": COD / "2/10/73/2107312.cif",
}


def freeze_non_scale(project):
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    return hist


def normalize_adps(phase):
    for atom in phase.atoms():
        # Some COD records omit displacement factors. Use a neutral fixed Uiso
        # solely for like-for-like phase-search comparisons.
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.01


def main():
    G2sc.SetPrintLevel("warn")
    results = []
    for key, cif in CANDIDATES.items():
        project = G2sc.G2Project(
            str(ROOT / "explore.gpx"), newgpx=str(ROOT / f"fixed_{key}.gpx")
        )
        hist = freeze_non_scale(project)
        phase1 = project.phase(0)
        phase1.set_HAP_refinements({"Scale": True})
        phase2 = project.add_phase(
            str(cif), phasename=f"WO3_{key}", histograms=[hist], fmthint="CIF"
        )
        normalize_adps(phase2)
        phase2.data["Histograms"][hist.name]["Scale"][0] = 0.5
        phase2.set_HAP_refinements({"Scale": True})
        project.set_Controls("cycles", 4)
        project.refine(makeBack=False)
        result = {
            "candidate": key,
            "wR": hist.residuals["wR"],
            "R": hist.residuals["R"],
            "scales": [
                p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()
            ],
            "fractions": hist.ComputeMassFracs(),
        }
        print("RESULT", json.dumps(result, sort_keys=True))
        results.append(result)
        project.save()
    print("SUMMARY")
    for result in sorted(results, key=lambda item: item["wR"]):
        print(result["candidate"], result["wR"], result["fractions"])


if __name__ == "__main__":
    main()
