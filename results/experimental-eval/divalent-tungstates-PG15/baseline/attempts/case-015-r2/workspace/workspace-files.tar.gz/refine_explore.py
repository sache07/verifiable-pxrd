#!/usr/bin/env python3
"""Build and iteratively refine an exploratory GSAS-II ZnWO4 model."""

from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INST = ROOT / "instrument.instprm"
START_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/06/1520641.cif"
)
PROJECT = ROOT / "explore.gpx"


def snapshot(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    hap = phase.data["Histograms"][hist.name]
    values = {
        "label": label,
        "residuals": hist.residuals,
        "cell": phase.get_cell(),
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "sample": hist.data["Sample Parameters"],
        "scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "background": hist.data["Background"][0],
    }
    print("SNAPSHOT", json.dumps(values, default=str, sort_keys=True))


def refine(project, label):
    project.refine(makeBack=False)
    snapshot(project, label)


def main():
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(newgpx=str(PROJECT))
    hist = project.add_powder_histogram(
        str(PATTERN), str(INST), fmthint="comma/tab/semicolon separated"
    )
    phase = project.add_phase(
        str(START_CIF), phasename="ZnWO4_wolframite", histograms=[hist], fmthint="CIF"
    )
    project.set_Controls("cycles", 8)
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "no. coeffs": 12, "refine": True},
    })
    # Reflection-mode sample metadata supplied by the importer for dual wavelength data.
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"

    # Stage 1: scale and background only.
    phase.set_HAP_refinements({"Scale": True})
    refine(project, "scale_background")

    # Stage 2: lattice and specimen displacement (peak positions).
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "cell_shift")

    # Stage 3: Gaussian and Lorentzian profile terms.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
    refine(project, "profile")

    # Stage 4: crystallite size and microstrain; these may be cleared later if redundant.
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 1.0, "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    refine(project, "size_mustrain")

    # Stage 5: axial divergence and doublet ratio.
    hist.set_refinements({"Instrument Parameters": ["SH/L", "I(L2)/I(L1)"]})
    refine(project, "asymmetry_doublet")

    project.save()


if __name__ == "__main__":
    main()
