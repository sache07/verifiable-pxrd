#!/usr/bin/env python3
"""Export submission artifacts from the authoritative final GSAS-II model."""

from pathlib import Path
import csv
import json
import math

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "threephase_working.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = [
    {
        "name": "ZnWO4 (wolframite)",
        "formula": "ZnWO4",
        "space_group": "P 2/c",
        "cif_path": "ZnWO4_wolframite.cif",
        "source_structure": "COD 1520641",
    },
    {
        "name": "WO3 (gamma-monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif_path": "WO3_gamma_monoclinic.cif",
        "source_structure": "COD 1528915",
    },
    {
        "name": "ZnO (wurtzite)",
        "formula": "ZnO",
        "space_group": "P 63mc",
        "cif_path": "ZnO_wurtzite.cif",
        "source_structure": "COD 9004178",
    },
]


def clean_cell(cell):
    return {key: float(value) for key, value in cell.items()}


def main():
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    project.save()
    # Reload from final.gpx so all exports demonstrably derive from this exact file.
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)
    phases = project.phases()

    for phase, info in zip(phases, PHASE_INFO):
        phase.export_CIF(str(ROOT / info["cif_path"]))

    x, observed, weight, calculated, background, residual = hist.data["data"][1]
    low, high = hist.data["Limits"][1]
    use = (x >= low) & (x <= high)
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity_counts",
                "calculated_intensity_counts",
                "difference_observed_minus_calculated_counts",
                "calculated_background_counts",
            ]
        )
        for values in zip(
            x[use], observed[use], calculated[use], residual[use], background[use]
        ):
            writer.writerow([f"{float(v):.10g}" for v in values])

    fractions = hist.ComputeMassFracs()
    residuals = hist.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    phase_records = []
    for index, (phase, info) in enumerate(zip(phases, PHASE_INFO)):
        fraction, fraction_esd = fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        record = dict(info)
        record.update(
            {
                "weight_fraction": float(fraction),
                "weight_percent": 100.0 * float(fraction),
                "formal_weight_fraction_esd": float(fraction_esd),
                "cell": clean_cell(cell),
                "cell_formal_esd": clean_cell(cell_esd),
                "bragg_R_percent": float(residuals[f"{index}:0:Rf"]),
            }
        )
        phase_records.append(record)

    result = {
        "phases": phase_records,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "reduced_chi_squared": float(rvals["GOF"]) ** 2,
            "chi_squared_sum": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
            "converged": bool(rvals["converged"]),
        },
        "profile": {
            "path": "fit.csv",
            "two_theta_range_deg": [float(low), float(high)],
            "difference_definition": "observed - calculated",
        },
        "project": "final.gpx",
        "fraction_basis": "normalized over the modeled crystalline phases",
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
