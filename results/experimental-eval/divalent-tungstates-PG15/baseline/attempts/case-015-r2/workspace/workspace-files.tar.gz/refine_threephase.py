#!/usr/bin/env python3
"""Final staged refinement for ZnWO4 + monoclinic WO3 + wurtzite ZnO."""

from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "test_threephase_fixed.gpx"
PROJECT = ROOT / "threephase_working.gpx"


def snapshot(project, label):
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    print(
        "SNAPSHOT",
        json.dumps(
            {
                "label": label,
                "residuals": hist.residuals,
                "fractions": hist.ComputeMassFracs(),
                "cells": {p.name: p.get_cell() for p in project.phases()},
                "scales": {
                    p.name: p.data["Histograms"][hist.name]["Scale"][0]
                    for p in project.phases()
                },
                "instrument": {
                    k: v[1]
                    for k, v in hist.data["Instrument Parameters"][0].items()
                    if isinstance(v, list) and len(v) > 1
                },
                "shift": hist.data["Sample Parameters"]["Shift"][0],
                "max_shift_over_esd": max(
                    (abs(float(v)) for v in cov.get("Lastshft", [])), default=0.0
                ),
                "vary": cov.get("varyList", []),
            },
            default=str,
            sort_keys=True,
        ),
        flush=True,
    )


def run(project, label, cycles=8):
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    snapshot(project, label)


def main():
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(SOURCE), newgpx=str(PROJECT))
    hist = project.histogram(0)
    znwo4, wo3, zno = project.phases()
    project.save()
    snapshot(project, "start")

    # Lattice positions, one phase at a time.
    zno.set_refinements({"Cell": True})
    run(project, "zno_cell", 7)
    zno.clear_refinements({"Cell": True})
    wo3.set_refinements({"Cell": True})
    run(project, "wo3_cell", 7)
    wo3.clear_refinements({"Cell": True})
    znwo4.set_refinements({"Cell": True})
    run(project, "znwo4_cell", 7)

    # Shared experimental terms. Keep the reported doublet ratio and a small
    # fixed axial-divergence term; fit a physically nonnegative X term with Y=0.
    hist.set_refinements({
        "Background": {"type": "chebyschev-1", "no. coeffs": 16, "refine": True},
        "Sample Parameters": ["Shift"],
    })
    run(project, "background_shift", 10)
    inst = hist.data["Instrument Parameters"][0]
    inst["I(L2)/I(L1)"][1:] = [0.5, False]
    inst["SH/L"][1:] = [0.002, False]
    inst["Y"][1:] = [0.0, False]
    inst["X"][2] = True
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    run(project, "profile", 12)

    # Coordinates are supported only for the dominant ZnWO4 phase.
    znwo4.set_refinements({"Atoms": {"all": "X"}})
    run(project, "znwo4_coordinates", 12)

    # Joint final lattice cycle; minor-phase coordinates and all ADPs remain fixed.
    wo3.set_refinements({"Cell": True})
    zno.set_refinements({"Cell": True})
    run(project, "joint_final", 15)
    project.save()


if __name__ == "__main__":
    main()
