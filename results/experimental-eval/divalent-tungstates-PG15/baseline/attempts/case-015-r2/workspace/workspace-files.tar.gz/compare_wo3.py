#!/usr/bin/env python3
"""Compare COD WO3 polymorphs as a second phase in the ZnWO4 fit."""

from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "explore.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = {
    "1004057_P6mmm": COD / "1/00/40/1004057.cif",
    "1010618_P21m": COD / "1/01/06/1010618.cif",
    "1521532_P4ncc": COD / "1/52/15/1521532.cif",
    "1521533_P4nmm": COD / "1/52/15/1521533.cif",
    "1528915_P21c": COD / "1/52/89/1528915.cif",
    "1563541_P21c": COD / "1/56/35/1563541.cif",
    "2311041_P21c": COD / "2/31/10/2311041.cif",
    "2106293_P-1": COD / "2/10/62/2106293.cif",
    "2107312_Pnma": COD / "2/10/73/2107312.cif",
}


def main():
    G2sc.SetPrintLevel("warn")
    results = []
    for key, cif in CANDIDATES.items():
        outfile = ROOT / f"trial_{key}.gpx"
        project = G2sc.G2Project(str(SOURCE), newgpx=str(outfile))
        hist = project.histogram(0)
        # Only the HAP scales carry phase abundance; fix the redundant histogram scale.
        hist.data["Sample Parameters"]["Scale"][1] = False
        phase1 = project.phase(0)
        phase1.clear_HAP_refinements({"Size": True, "Mustrain": True})
        phase1.set_HAP_refinements({"Scale": True})
        phase2 = project.add_phase(
            str(cif), phasename=f"WO3_{key}", histograms=[hist], fmthint="CIF"
        )
        phase2.set_HAP_refinements({"Scale": True})
        project.set_Controls("cycles", 10)
        # Establish abundance before allowing this candidate's lattice to move.
        project.refine(makeBack=False)
        phase2.set_refinements({"Cell": True})
        project.refine(makeBack=False)
        try:
            fracs = hist.ComputeMassFracs()
        except Exception as exc:
            fracs = {"error": str(exc)}
        result = {
            "candidate": key,
            "residuals": hist.residuals,
            "cell": phase2.get_cell(),
            "scales": {
                p.name: p.data["Histograms"][hist.name]["Scale"] for p in project.phases()
            },
            "mass_fractions": fracs,
        }
        print("RESULT", json.dumps(result, default=str, sort_keys=True))
        results.append(result)
        project.save()
    print("SUMMARY")
    for r in sorted(results, key=lambda q: q["residuals"]["wR"]):
        print(r["candidate"], r["residuals"]["wR"], r["mass_fractions"])


if __name__ == "__main__":
    main()
