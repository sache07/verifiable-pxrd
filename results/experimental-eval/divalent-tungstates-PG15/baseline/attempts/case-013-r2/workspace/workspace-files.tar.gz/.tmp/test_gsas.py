from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id):
    return DB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


gpx = ROOT / ".tmp" / "onephase.gpx"
project = G2sc.G2Project(newgpx=str(gpx))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / ".tmp" / "instrument.instprm"),
    fmthint="comma",
)
# Fix the histogram scale to remove exact correlation with phase scales.
hist.data["Sample Parameters"]["Scale"] = [1.0, False]
hist.data["Instrument Parameters"][0]["Zero"][0] = 0.33
hist.data["Instrument Parameters"][0]["Zero"][1] = 0.33
phase = project.add_phase(
    str(cif_path("9009811")),
    phasename="PbWO4_scheelite",
    histograms=[hist],
)
hist.set_refinements({
    "Limits": [10.02, 99.98],
    "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 16},
})
phase.set_HAP_refinements({"Scale": True})
project.save()
print("hist", hist.name)
print("phase", phase.name, phase.get_cell(), phase.composition)
print("inst", hist.data["Instrument Parameters"])
print("bkg", hist.data["Background"])
project.do_refinements([
    {},
    {"set": {"Cell": True}},
    {"set": {"Instrument Parameters": ["Zero"]}},
    {"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}},
])
print("residuals", hist.data["data"][0])
print("cell", phase.get_cell_and_esd())
print("scale", phase.data["Histograms"][hist.name]["Scale"])
project.save()
