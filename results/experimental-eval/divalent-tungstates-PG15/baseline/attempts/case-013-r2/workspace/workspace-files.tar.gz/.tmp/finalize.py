from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "models" / "extra_repeat.gpx"
FINAL = ROOT / "final.gpx"

PHASE_METADATA = {
    "PbWO4_scheelite": {
        "name": "PbWO4 (scheelite)",
        "formula": "PbWO4",
        "cif_path": "phase_PbWO4_scheelite.cif",
        "model_source": "COD 9009811",
    },
    "PbO_massicot": {
        "name": "PbO (massicot)",
        "formula": "PbO",
        "cif_path": "phase_PbO_massicot.cif",
        "model_source": "COD 2310433",
    },
    "WO3_monoclinic": {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif_path": "phase_WO3_monoclinic.cif",
        "model_source": "COD 2311041",
    },
    "Pb2WO5": {
        "name": "Pb2WO5",
        "formula": "Pb2WO5",
        "cif_path": "phase_Pb2WO5.cif",
        "model_source": "Pb2MoO5 prototype, COD 7220560, with Mo replaced by W",
    },
}


project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
project.data["Controls"]["data"]["max cyc"] = 12
project.data["Controls"]["data"]["min dM/M"] = 0.00001
hist = project.histogram(0)

# Use every supplied point in the final refinement and exported profile.
x = np.asarray(hist.data["data"][1][0])
hist.data["Limits"][1] = [float(x[0]), float(x[-1])]
project.save()
project.do_refinements([{}])
project.save()

# A repeat from the refined state gives a clean final convergence check and
# ensures the covariance matrix in final.gpx corresponds to the exported files.
rvals = project.data["Covariance"]["data"].get("Rvals", {})
if not rvals.get("converged", False) or rvals.get("Max shft/sig", 1.0) > 0.1:
    project.do_refinements([{}])
    project.save()

rvals = project.data["Covariance"]["data"].get("Rvals", {})
mass = hist.ComputeMassFracs()
mass_sum = sum(value[0] for value in mass.values())

phases_out = []
for phase in project.phases():
    metadata = PHASE_METADATA[phase.name]
    phase.export_CIF(str(ROOT / metadata["cif_path"]))
    cell, cell_esd = phase.get_cell_and_esd()
    fraction, fraction_esd = mass[phase.name]
    phases_out.append(
        {
            **metadata,
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "weight_fraction": float(fraction / mass_sum),
            "weight_fraction_formal_esd": float(fraction_esd / mass_sum),
            "unit_cell": {key: float(value) for key, value in cell.items()},
            "unit_cell_esd": {key: float(value) for key, value in cell_esd.items()},
        }
    )

profile = hist.data["data"][1]
x, yobs, weights, ycalc, ybkg, ydiff = map(np.asarray, profile)
low, high = hist.data["Limits"][1]
mask = (x >= low) & (x <= high)
with (ROOT / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "difference_observed_minus_calculated",
            "background_intensity",
        ]
    )
    writer.writerows(
        zip(x[mask], yobs[mask], ycalc[mask], ydiff[mask], ybkg[mask])
    )

rwp = float(hist.get_wR())
gof = float(rvals["GOF"])
nobs = int(rvals["Nobs"])
nvars = int(rvals["Nvars"])
result = {
    "phase_count": len(phases_out),
    "phases": phases_out,
    "fit_statistics": {
        "r_wp_percent": rwp,
        "r_p_percent": float(hist.data["data"][0]["R"]),
        "r_exp_percent": float(rwp / gof),
        "goodness_of_fit": gof,
        "chi_squared": float(rvals["chisq"]),
        "reduced_chi_squared": float(rvals["chisq"] / (nobs - nvars)),
        "n_observations": nobs,
        "n_refined_parameters": nvars,
        "converged": bool(rvals.get("converged", False)),
        "maximum_shift_over_esd": float(rvals.get("Max shft/sig", 0.0)),
    },
    "refinement": {
        "software": "GSAS-II",
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "radiation": "Cu Kalpha1/Kalpha2",
        "wavelengths_angstrom": [1.540598, 1.544426],
        "kalpha2_over_kalpha1": 0.5,
        "profile_range_two_theta_deg": [float(low), float(high)],
        "weighting": "Poisson estimate, w = 1 / observed intensity (no uncertainties supplied)",
        "weight_fraction_basis": "normalized over the four modeled crystalline phases",
    },
}

with (ROOT / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps(result, indent=2))
