from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = ROOT / ".tmp" / "models"
OUT.mkdir(exist_ok=True)

PHASES = {
    "scheelite": ("9009811", "PbWO4_scheelite"),
    "raspite": ("9007617", "PbWO4_raspite"),
    "massicot": ("2310433", "PbO_massicot"),
    "litharge": ("9012700", "PbO_litharge"),
    "wo3_p21c": ("2311041", "WO3_monoclinic"),
    "wo3_std": ("1528915", "WO3_monoclinic"),
    "wo3_p21m": ("1010618", "WO3_P21m"),
    "wo3_tric": ("2106293", "WO3_triclinic"),
    "wo3_pnma": ("2107312", "WO3_Pnma"),
    "pb7w8": ("9016035", "Pb7W8O28.8"),
    "w2o7": ("1001358", "W2O7"),
    "pb2o": ("1010382", "Pb2O"),
    # Pb2WO5 is initialized from the isostructural Pb2MoO5 model (COD 7220560)
    # and the tetrahedral cation is replaced before refinement.
    "pb2wo5": ("7220560", "Pb2WO5"),
}

MODELS = {
    "s": ["scheelite"],
    "sm": ["scheelite", "massicot"],
    "sw": ["scheelite", "wo3_p21c"],
    "sx": ["scheelite", "pb2wo5"],
    "smw": ["scheelite", "massicot", "wo3_p21c"],
    "smwt": ["scheelite", "massicot", "wo3_tric"],
    "smwp": ["scheelite", "massicot", "wo3_pnma"],
    "smr": ["scheelite", "massicot", "raspite"],
    "smx": ["scheelite", "massicot", "pb2wo5"],
    "swx": ["scheelite", "wo3_p21c", "pb2wo5"],
    "swr": ["scheelite", "wo3_p21c", "raspite"],
    "smwr": ["scheelite", "massicot", "wo3_p21c", "raspite"],
    "smwb": ["scheelite", "massicot", "wo3_p21c", "pb7w8"],
    "smw7": ["scheelite", "massicot", "wo3_p21c", "w2o7"],
    "smwo": ["scheelite", "massicot", "wo3_p21c", "pb2o"],
    "smwx": ["scheelite", "massicot", "wo3_p21c", "pb2wo5"],
    "smwxs": ["scheelite", "massicot", "wo3_std", "pb2wo5"],
    "smwxt": ["scheelite", "massicot", "wo3_tric", "pb2wo5"],
    "smwxp": ["scheelite", "massicot", "wo3_pnma", "pb2wo5"],
}


def cif_path(cod_id):
    return DB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def refine(model_key):
    phase_keys = MODELS[model_key]
    gpx = OUT / f"{model_key}.gpx"
    project = G2sc.G2Project(newgpx=str(gpx))
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / ".tmp" / "instrument.instprm"),
        fmthint="comma",
    )
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    inst = hist.data["Instrument Parameters"][0]
    # Starting values from the well-resolved scheelite peaks.
    start_inst = {
        "Zero": 0.27,
        "U": 150.0,
        "V": -140.0,
        "W": 60.0,
        "X": 9.0,
        "Y": -10.0,
    }
    for key, value in start_inst.items():
        inst[key][0] = value
        inst[key][1] = value
        inst[key][2] = False
    phases = []
    for key in phase_keys:
        cid, name = PHASES[key]
        phase = project.add_phase(
            str(cif_path(cid)),
            phasename=name,
            histograms=[hist],
        )
        if key == "pb2wo5":
            for atom in phase.atoms():
                if atom.element == "Mo":
                    atom.type = "W"
                    atom.label = atom.label.replace("Mo", "W")
            G2sc.SetupGeneral(phase.data, None)
        phase.HAPvalue("Scale", 6.0 if key == "scheelite" else 0.5)
        phase.set_HAP_refinements({"Scale": True})
        phases.append(phase)
    hist.set_refinements({
        "Limits": [10.02, 99.98],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 16,
        },
    })
    project.save()
    project.do_refinements([
        {},
        {"set": {"Cell": True}},
        {"set": {"Instrument Parameters": ["Zero"]}},
        {"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}},
    ])
    project.save()
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    result = {
        "model": model_key,
        "phases": phase_keys,
        "Rwp": hist.get_wR(),
        "Rp": hist.data["data"][0].get("R"),
        "GOF": rvals.get("GOF"),
        "chisq": rvals.get("chisq"),
        "Nvars": rvals.get("Nvars"),
        "converged": rvals.get("converged"),
        "zero": inst["Zero"][1],
        "profile": {k: inst[k][1] for k in ["U", "V", "W", "X", "Y"]},
        "mass_fracs": hist.ComputeMassFracs() if len(phases) > 1 else {},
        "phase_data": {
            p.name: {
                "cell": p.get_cell(),
                "scale": p.HAPvalue("Scale"),
            }
            for p in phases
        },
    }
    print("RESULT", json.dumps(result, sort_keys=True))
    return result


if __name__ == "__main__":
    keys = sys.argv[1:] or list(MODELS)
    for model_key in keys:
        refine(model_key)
