from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
mode = sys.argv[1]
source = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / ".tmp/models/smwx.gpx"
target = ROOT / ".tmp/models" / f"extra_{mode}.gpx"
project = G2sc.G2Project(str(source), newgpx=str(target))
project.data["Controls"]["data"]["max cyc"] = 12
project.data["Controls"]["data"]["min dM/M"] = 0.00001
hist = project.histogram(0)
inst = hist.data["Instrument Parameters"][0]

if mode == "size":
    inst["X"][2] = False
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True, "value": 1.0}
        })
elif mode == "strain":
    inst["Y"][2] = False
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True}
        })
        phase.data["Histograms"][hist.name]["Mustrain"][1][0] = 500.0
elif mode == "size_strain":
    inst["X"][2] = False
    inst["Y"][2] = False
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True, "value": 1.0},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
        phase.data["Histograms"][hist.name]["Mustrain"][1][0] = 500.0
elif mode == "shl":
    inst["SH/L"][2] = True
elif mode == "polar":
    inst["Polariz."][2] = True
elif mode == "shl_polar":
    inst["SH/L"][2] = True
    inst["Polariz."][2] = True
elif mode == "repeat":
    pass
elif mode == "coord_main":
    project.phase("PbWO4_scheelite").set_refinements({"Atoms": {"O": "X"}})
else:
    raise ValueError(mode)

project.save()
project.do_refinements([{}])
project.save()
rvals = project.data["Covariance"]["data"].get("Rvals", {})
out = {
    "mode": mode,
    "Rwp": hist.get_wR(),
    "Rp": hist.data["data"][0].get("R"),
    "GOF": rvals.get("GOF"),
    "Nvars": rvals.get("Nvars"),
    "converged": rvals.get("converged"),
    "mass": hist.ComputeMassFracs(),
    "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
    "hap": {
        phase.name: {
            "Size": phase.data["Histograms"][hist.name]["Size"],
            "Mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
        }
        for phase in project.phases()
    },
}
print("RESULT", json.dumps(out, sort_keys=True))
