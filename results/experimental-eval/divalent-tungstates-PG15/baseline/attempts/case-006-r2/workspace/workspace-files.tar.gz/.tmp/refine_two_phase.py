from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "imp_wo3m.gpx"
OUT = ROOT / ".tmp" / "two_phase.gpx"


def show(gpx, label):
    hist = gpx.histogram(0)
    print("\nTWO-PHASE", label, hist.residuals)
    print("instrument", {k: hist.InstrumentParameters[k] for k in
          ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]})
    for phase in gpx.phases():
        print(phase.name, "scale", phase.HAPvalue("Scale"), "cell", phase.get_cell())
        for atom in phase.atoms():
            print(" atom", atom.label, atom.coordinates, atom.ADP, atom.refinement_flags)
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fraction error", repr(exc))


def refine(gpx, label):
    gpx.save()
    gpx.do_refinements([{}])
    show(gpx, label)


def main():
    if OUT.exists():
        OUT.unlink()
    gpx = G2sc.G2Project(str(BASE), newgpx=str(OUT))
    gpx.set_Controls("cycles", 10)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-7
    hist = gpx.histogram(0)
    cuwo4 = gpx.phase("CuWO4")
    wo3 = gpx.phase("WO3_monoclinic")

    # Stage 1: locate the weak WO3 lines by its cell while holding the already
    # fitted CuWO4 model fixed.
    wo3.set_refinements({"Cell": True})
    wo3.set_HAP_refinements({"Scale": True})
    refine(gpx, "WO3 cell")

    # Stage 2: release global intensity, background and peak-position terms.
    hist.Background[0][1] = True
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    cuwo4.set_refinements({"Cell": True})
    cuwo4.set_HAP_refinements({"Scale": True})
    refine(gpx, "global positions/scales")

    # Stage 3: update peak shape. The uncalibrated profile is empirical.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
    refine(gpx, "profile")

    # Stage 4: refine supported CuWO4 coordinates and the unknown effective
    # polarization. WO3 coordinates remain at the reference values because its
    # ~1 wt% contribution cannot determine them reliably.
    cuwo4.set_refinements({"Atoms": {"all": "X"}})
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(gpx, "coordinates/polarization")

    # Final repeat for covariance and a settled calculated profile.
    refine(gpx, "final repeat")
    gpx.save()


if __name__ == "__main__":
    main()
