from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "all_xyz.gpx"
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id):
    return DB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = {
    "CuO": ("1011194", 4.0),
    "WO3_monoclinic": ("1528915", 0.8),
    "WO3_triclinic": ("2106293", 0.8),
    "Cu3WO6": ("1527404", 0.5),
    "Cu2WO4": ("2002403", 0.5),
}


def freeze_base(gpx):
    hist = gpx.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in gpx.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": False})


def run_case(case, names):
    out = ROOT / ".tmp" / f"imp_{case}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    gpx.set_Controls("cycles", 10)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-7
    freeze_base(gpx)
    hist = gpx.histogram(0)
    added = []
    for name in names:
        cod_id, start_scale = CANDIDATES[name]
        phase = gpx.add_phase(str(cif_path(cod_id)), phasename=name,
                              histograms=[hist], fmthint="CIF")
        phase.HAPvalue("Scale", start_scale)
        phase.set_HAP_refinements({"Scale": True})
        added.append(phase)
    gpx.save()
    gpx.do_refinements([{}])
    print("\nSCREEN", case, "residuals", hist.residuals)
    for phase in gpx.phases():
        print("phase", phase.name, "scale", phase.HAPvalue("Scale"),
              "mass", phase.data["General"]["Mass"], "cell", phase.get_cell())
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fractions failed", repr(exc))
    print("vary", gpx.get_VaryList())
    gpx.save()


def main():
    cases = {
        "cuo": ["CuO"],
        "wo3m": ["WO3_monoclinic"],
        "wo3t": ["WO3_triclinic"],
        "cuo_wo3m": ["CuO", "WO3_monoclinic"],
        "cu3wo6": ["Cu3WO6"],
        "cu2wo4": ["Cu2WO4"],
    }
    for case, names in cases.items():
        try:
            run_case(case, names)
        except Exception as exc:
            print("\nSCREEN FAILED", case, repr(exc))


if __name__ == "__main__":
    main()
