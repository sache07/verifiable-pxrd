from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / ".tmp" / "opt_shl.gpx"
OUT = ROOT / ".tmp" / "selected.gpx"

if OUT.exists():
    OUT.unlink()
gpx = G2sc.G2Project(str(SRC), newgpx=str(OUT))
gpx.set_Controls("cycles", 20)
gpx.data["Controls"]["data"]["min dM/M"] = 1e-7
hist = gpx.histogram(0)

# The fitted negative Y term is clipped by the profile implementation and has
# no effect (the constrained trial gives the same Rwp). Store the simpler,
# physical profile with Y=0 fixed.
hist.InstrumentParameters["Y"][1] = 0.0
hist.InstrumentParameters["Y"][2] = False

gpx.save()
gpx.do_refinements([{}])
gpx.do_refinements([{}])
print("residuals", hist.residuals)
print("mass", hist.ComputeMassFracs())
print("instrument", {k: hist.InstrumentParameters[k] for k in
      ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]})
for phase in gpx.phases():
    print("phase", phase.name, "scale", phase.HAPvalue("Scale"),
          "cell", phase.get_cell())
    for atom in phase.atoms():
        print("atom", atom.label, atom.coordinates, atom.ADP, atom.refinement_flags)
print("vary", gpx.get_VaryList())
gpx.save()
