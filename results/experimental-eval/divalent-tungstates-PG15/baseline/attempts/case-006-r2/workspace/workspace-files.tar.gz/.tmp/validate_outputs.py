import json
from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


root = Path(__file__).resolve().parents[1]
result = json.loads((root / "result.json").read_text())
assert abs(sum(p["weight_fraction"] for p in result["phases"]) - 1.0) < 1e-12

fit = pd.read_csv(root / "fit.csv")
assert len(fit) == result["fit_statistics"]["n_observations"] == 8284
diff_error = np.max(np.abs(
    fit["difference_intensity"]
    - (fit["observed_intensity"] - fit["calculated_intensity"])
))
assert diff_error < 1e-10
print("profile", len(fit), fit.two_theta_deg.iloc[0],
      fit.two_theta_deg.iloc[-1], "max_diff_error", diff_error)

for path in [root / "CuWO4.cif", root / "WO3.cif"]:
    structure = Structure.from_file(path)
    analyzer = SpacegroupAnalyzer(structure, symprec=1e-3)
    print(
        path.name,
        structure.composition.reduced_formula,
        len(structure),
        analyzer.get_space_group_symbol(),
        tuple(round(v, 6) for v in structure.lattice.abc),
        tuple(round(v, 6) for v in structure.lattice.angles),
    )
