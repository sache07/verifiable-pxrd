import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parents[1]
result = json.loads((root / "result.json").read_text())
gpx = G2sc.G2Project(str(root / "final.gpx"))
hist = gpx.histogram(0)

assert [phase.name for phase in gpx.phases()] == ["CuWO4", "WO3"]
assert list(hist.data["Reflection Lists"]) == ["CuWO4", "WO3"]
assert not any(str(key).startswith("2:") for key in hist.data["data"][0])

fractions = hist.ComputeMassFracs()
for phase_result in result["phases"]:
    assert abs(
        fractions[phase_result["name"]][0] - phase_result["weight_fraction"]
    ) < 1e-14

x = np.asarray(hist.getdata("X"), dtype=float)
y_obs = np.asarray(hist.getdata("Yobs"), dtype=float)
y_calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
mask = y_calc != 0.0
profile = np.genfromtxt(root / "fit.csv", delimiter=",", names=True)

assert np.array_equal(profile["two_theta_deg"], x[mask])
assert np.array_equal(profile["observed_intensity"], y_obs[mask])
assert np.array_equal(profile["calculated_intensity"], y_calc[mask])
assert np.allclose(
    profile["difference_intensity"], y_obs[mask] - y_calc[mask],
    rtol=0.0, atol=1e-12,
)

rvals = gpx.data["Covariance"]["data"]["Rvals"]
assert rvals["converged"]
assert abs(rvals["Rwp"] - result["fit_statistics"]["r_wp_percent"]) < 1e-14
assert int(rvals["Nobs"]) == len(profile)
print("validated final.gpx, CIF-linked fractions, and fit.csv")
print("Rwp", rvals["Rwp"], "GOF", rvals["GOF"], "points", len(profile))
