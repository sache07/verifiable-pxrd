from pathlib import Path
import copy
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / ".tmp" / "selected_shl.gpx"
OUT = ROOT / ".tmp" / "test_wo3_modern.gpx"

if OUT.exists():
    OUT.unlink()
gpx = G2sc.G2Project(str(SRC), newgpx=str(OUT))
gpx.set_Controls("cycles", 10)
gpx.data["Controls"]["data"]["min dM/M"] = 1e-7
hist = gpx.histogram(0)
main = gpx.phase("CuWO4")
old = gpx.phase("WO3_monoclinic")
old.HAPvalue("Use", False)

# Freeze the converged main model for initial minor-phase placement.
hist.Background[0][1] = False
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
main.set_refinements({"Cell": False, "Atoms": {"all": " "}})
main.set_HAP_refinements({"Scale": False})
old.set_refinements({"Cell": False, "Atoms": {"all": " "}})
old.set_HAP_refinements({"Scale": False})

new = gpx.add_phase("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif",
                    phasename="WO3_modern", histograms=[hist], fmthint="CIF")
new.HAPvalue("Scale", 0.75)
new.set_refinements({"Cell": True})
new.set_HAP_refinements({"Scale": True})
gpx.save()
gpx.do_refinements([{}])
print("stage1", hist.residuals, new.get_cell(), new.HAPvalue("Scale"))

# Restore supported global/main refinements for a fair model comparison.
hist.Background[0][1] = True
hist.set_refinements({"Instrument Parameters": ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]})
main.set_refinements({"Cell": True, "Atoms": {"all": "X"}})
main.set_HAP_refinements({"Scale": True})
gpx.do_refinements([{}])
print("stage2", hist.residuals, new.get_cell(), new.HAPvalue("Scale"))

# Recalculate from final cells and restore covariance for consistent output.
cov = copy.deepcopy(gpx.data["Covariance"]["data"])
hist.data["Reflection Lists"] = {}
gpx.set_Controls("cycles", 0)
gpx.save()
gpx.do_refinements([{}])
gpx.data["Covariance"]["data"] = cov
gpx.set_Controls("cycles", 10)
x=np.asarray(hist.getdata('X'));yo=np.asarray(hist.getdata('Yobs'));yc=np.asarray(hist.getdata('Ycalc'));w=np.asarray(hist.getdata('Yweight'))
lo,hi=hist.data['Limits'][1];m=(x>=lo)&(x<=hi)&(w>0)
print("final",hist.residuals,"manual",100*np.sqrt(np.sum(w[m]*(yo[m]-yc[m])**2)/np.sum(w[m]*yo[m]**2)))
for phase in gpx.phases():
    print(phase.name,phase.HAPvalue("Use"),phase.HAPvalue("Scale"),phase.get_cell())
gpx.save()
