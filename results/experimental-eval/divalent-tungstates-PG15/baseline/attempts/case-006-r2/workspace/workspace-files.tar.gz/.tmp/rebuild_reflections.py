from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / ".tmp" / "selected_shl.gpx"
OUT = ROOT / ".tmp" / "rebuilt.gpx"

if OUT.exists():
    OUT.unlink()
gpx = G2sc.G2Project(str(SRC), newgpx=str(OUT))
gpx.set_Controls("cycles", 12)
gpx.data["Controls"]["data"]["min dM/M"] = 1e-7
hist = gpx.histogram(0)
# Force reflection generation from the final cells before the final least-
# squares pass. This avoids carrying reflection lists generated for an older
# intermediate cell.
hist.data["Reflection Lists"] = {}
gpx.save()
gpx.do_refinements([{}])
hist.data["Reflection Lists"] = {}
gpx.save()
gpx.do_refinements([{}])
print("residuals", hist.residuals)
print("mass", hist.ComputeMassFracs())
print("instrument", {k: hist.InstrumentParameters[k] for k in
      ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]})
for phase in gpx.phases():
    print("phase", phase.name, "scale", phase.HAPvalue("Scale"),
          "cell", phase.get_cell())
    for atom in phase.atoms():
        print("atom", atom.label, atom.coordinates, atom.ADP, atom.refinement_flags)
print("vary", gpx.get_VaryList())
gpx.save()
