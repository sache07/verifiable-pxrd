from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "clean_modern.gpx"
PROJECT = ROOT / "final.gpx"

if PROJECT.exists():
    PROJECT.unlink()

gpx = G2sc.G2Project(str(SOURCE), newgpx=str(PROJECT))
hist = gpx.histogram(0)

# The old comparison model had already been removed from the project, but its
# phase-specific residual summary remained in the histogram dictionary. Remove
# those stale reporting fields; this does not alter the converged refinement.
for key in list(hist.data["data"][0]):
    if isinstance(key, str) and key.startswith("2:"):
        del hist.data["data"][0][key]

phase_names = [phase.name for phase in gpx.phases()]
assert phase_names == ["CuWO4", "WO3"], phase_names
assert set(hist.data["Reflection Lists"]) == set(phase_names)
assert not any(str(key).startswith("2:") for key in hist.data["data"][0])

gpx.save()

for phase in gpx.phases():
    phase.export_CIF(str(ROOT / f"{phase.name}.cif"))

mass_fractions = hist.ComputeMassFracs()
assert abs(sum(item[0] for item in mass_fractions.values()) - 1.0) < 1e-12

x = np.asarray(hist.getdata("X"), dtype=float)
y_obs = np.asarray(hist.getdata("Yobs"), dtype=float)
y_calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
y_bkg = np.asarray(hist.getdata("Background"), dtype=float)
weight = np.asarray(hist.getdata("Yweight"), dtype=float)
y_diff = y_obs - y_calc

# GSAS-II leaves calculated intensities at zero outside the fitted profile.
# Export exactly the points used in the reported least-squares calculation.
fit_mask = y_calc != 0.0
rvals = gpx.data["Covariance"]["data"]["Rvals"]
assert int(np.count_nonzero(fit_mask)) == int(rvals["Nobs"])
assert np.all(np.isfinite(np.column_stack((x[fit_mask], y_obs[fit_mask],
                                           y_calc[fit_mask], y_diff[fit_mask],
                                           y_bkg[fit_mask], weight[fit_mask]))))

with (ROOT / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow([
        "two_theta_deg",
        "observed_intensity",
        "calculated_intensity",
        "difference_intensity",
        "background_intensity",
        "least_squares_weight",
    ])
    writer.writerows(zip(
        x[fit_mask],
        y_obs[fit_mask],
        y_calc[fit_mask],
        y_diff[fit_mask],
        y_bkg[fit_mask],
        weight[fit_mask],
    ))

phase_specs = {
    "CuWO4": {"formula": "CuWO4", "space_group": "P -1"},
    "WO3": {"formula": "WO3", "space_group": "P 21/c"},
}
phase_results = []
for phase in gpx.phases():
    fraction, fraction_esd = mass_fractions[phase.name]
    phase_results.append({
        "name": phase.name,
        "formula": phase_specs[phase.name]["formula"],
        "space_group": phase_specs[phase.name]["space_group"],
        "cif_path": f"{phase.name}.cif",
        "weight_fraction": float(fraction),
        "weight_fraction_esd": float(fraction_esd),
        "weight_percent": float(100.0 * fraction),
        "weight_percent_esd": float(100.0 * fraction_esd),
    })

result = {
    "method": "Rietveld refinement with GSAS-II",
    "weight_fraction_basis": (
        "Normalized over the modeled crystalline phases; no amorphous fraction "
        "was determined."
    ),
    "phases": phase_results,
    "fit_statistics": {
        "r_wp_percent": float(rvals["Rwp"]),
        "r_p_percent": float(hist.residuals["R"]),
        "r_exp_percent": float(hist.residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "reduced_chi_squared": float(rvals["GOF"] ** 2),
        "chi_squared": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_variables": int(rvals["Nvars"]),
        "converged": bool(rvals["converged"]),
        "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
        "nominal_fit_range_two_theta_deg": [10.0, 100.0],
        "exported_profile_range_two_theta_deg": [
            float(x[fit_mask][0]),
            float(x[fit_mask][-1]),
        ],
    },
    "measurement_model": {
        "radiation": "Cu Kalpha1/Kalpha2",
        "wavelengths_angstrom": [1.540598, 1.544426],
        "kalpha2_to_kalpha1_ratio": 0.5,
        "weights": "Poisson approximation, sigma=sqrt(max(counts,1))",
    },
    "files": {
        "gsasii_project": "final.gpx",
        "profile": "fit.csv",
    },
}

with (ROOT / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps(result, indent=2))
print("project", PROJECT, PROJECT.stat().st_size)
print("profile_rows", int(np.count_nonzero(fit_mask)))
