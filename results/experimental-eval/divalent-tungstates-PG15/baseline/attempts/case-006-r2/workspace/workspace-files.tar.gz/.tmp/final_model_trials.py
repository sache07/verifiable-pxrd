from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "two_phase.gpx"


def load(name):
    out = ROOT / ".tmp" / f"opt_{name}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    gpx.set_Controls("cycles", 10)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-7
    return gpx, gpx.histogram(0), gpx.phase("CuWO4"), gpx.phase("WO3_monoclinic")


def run(name, setup):
    gpx, hist, cuwo4, wo3 = load(name)
    setup(gpx, hist, cuwo4, wo3)
    gpx.save()
    gpx.do_refinements([{}])
    print("\nOPTION", name, hist.residuals)
    print("mass", hist.ComputeMassFracs())
    print("inst", {k: hist.InstrumentParameters[k] for k in
          ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]})
    print("PO", cuwo4.getHAPvalues(hist.name)["Pref.Ori."][:4])
    print("size", cuwo4.getHAPvalues(hist.name)["Size"])
    print("strain", cuwo4.getHAPvalues(hist.name)["Mustrain"])
    for atom in cuwo4.atoms():
        print("atom", atom.label, atom.coordinates, atom.ADP, atom.refinement_flags)
    gpx.save()


def shl(gpx, hist, cuwo4, wo3):
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})


def po(axis):
    def setup(gpx, hist, cuwo4, wo3):
        hap = cuwo4.getHAPvalues(hist.name)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = list(axis)
        cuwo4.set_HAP_refinements({"Pref.Ori.": True})
    return setup


def adp(gpx, hist, cuwo4, wo3):
    cuwo4.set_refinements({"Atoms": {"all": "XU"}})
    gpx.set_Controls("parmMin", 0.0001, "0::AUiso:*")
    gpx.set_Controls("parmMax", 0.05, "0::AUiso:*")


def genstrain(gpx, hist, cuwo4, wo3):
    # Instrumental broadening is frozen while testing phase-specific,
    # reflection-dependent strain broadening.
    hist.clear_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
    cuwo4.set_HAP_refinements({"Mustrain": {"type": "generalized", "refine": True}})


def ellipsize(gpx, hist, cuwo4, wo3):
    hist.clear_refinements({"Instrument Parameters": ["X", "Y"]})
    cuwo4.set_HAP_refinements({"Size": {"type": "ellipsoidal", "value": 1.0, "refine": True}})


def y_nonnegative(gpx, hist, cuwo4, wo3):
    hist.InstrumentParameters["Y"][1] = 0.0
    hist.set_refinements({"Instrument Parameters": ["Y"]})
    gpx.set_Controls("parmMin", 0.0, ":0:Y")


def shl_po100(gpx, hist, cuwo4, wo3):
    shl(gpx, hist, cuwo4, wo3)
    po((1, 0, 0))(gpx, hist, cuwo4, wo3)


def main():
    options = {
        "shl": shl,
        "po100": po((1, 0, 0)),
        "po010": po((0, 1, 0)),
        "po001": po((0, 0, 1)),
        "adp_bounded": adp,
        "genstrain": genstrain,
        "ellipsize": ellipsize,
        "y_nonnegative": y_nonnegative,
        "shl_po100": shl_po100,
    }
    for name, setup in options.items():
        try:
            run(name, setup)
        except Exception as exc:
            print("\nOPTION FAILED", name, repr(exc))


if __name__ == "__main__":
    main()
