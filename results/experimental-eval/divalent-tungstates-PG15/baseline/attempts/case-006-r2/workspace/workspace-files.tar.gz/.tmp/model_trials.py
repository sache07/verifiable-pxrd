from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "trial.gpx"


def load_case(name):
    out = ROOT / ".tmp" / f"{name}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-7
    hist = gpx.histogram(0)
    phase = gpx.phase(0)

    # Remove the exact sample-scale/phase-scale redundancy introduced by the
    # importer while retaining their fitted product.
    sample_scale = hist.SampleParameters["Scale"][0]
    phase_scale = phase.HAPvalue("Scale")
    hist.SampleParameters["Scale"] = [1.0, False]
    phase.HAPvalue("Scale", sample_scale * phase_scale)
    phase.set_HAP_refinements({"Scale": True})
    return gpx, hist, phase


def run_case(name, atom_flags=None, polarization=False, po_axis=None,
             size=False, strain=False):
    gpx, hist, phase = load_case(name)
    if atom_flags:
        phase.set_refinements({"Atoms": atom_flags})
    if polarization:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    if po_axis is not None:
        hap = phase.getHAPvalues(hist.name)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = list(po_axis)
        phase.set_HAP_refinements({"Pref.Ori.": True})
    if size:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 10.0, "refine": True}})
    if strain:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    gpx.save()
    gpx.do_refinements([{}])
    print("\nCASE", name)
    print("residuals", hist.residuals)
    print("cell", phase.get_cell())
    print("sample scale", hist.SampleParameters["Scale"], "phase scale", phase.HAPvalue("Scale"))
    print("polarization", hist.InstrumentParameters["Polariz."])
    print("PO", phase.getHAPvalues(hist.name)["Pref.Ori."][:4])
    print("size", phase.getHAPvalues(hist.name)["Size"][:3])
    print("strain", phase.getHAPvalues(hist.name)["Mustrain"][:3])
    for atom in phase.atoms():
        print("atom", atom.label, atom.coordinates, atom.ADP, atom.refinement_flags)
    print("vary", gpx.get_VaryList())
    gpx.save()


def main():
    cases = [
        ("clean", None, False, None, False, False),
        ("heavy_xyz", {"Cu1": "X", "W1": "X"}, False, None, False, False),
        ("all_xyz", {"all": "X"}, False, None, False, False),
        ("all_xyz_u", {"all": "XU"}, False, None, False, False),
        ("polarization", None, True, None, False, False),
        ("po_100", None, False, (1, 0, 0), False, False),
        ("po_010", None, False, (0, 1, 0), False, False),
        ("po_001", None, False, (0, 0, 1), False, False),
        ("size", None, False, None, True, False),
        ("strain", None, False, None, False, True),
    ]
    for args in cases:
        try:
            run_case(*args)
        except Exception as exc:
            print("\nCASE FAILED", args[0], repr(exc))


if __name__ == "__main__":
    main()
