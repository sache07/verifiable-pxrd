from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "selected_shl.gpx"
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def path(cod):
    return DB / cod[0] / cod[1:3] / cod[3:5] / f"{cod}.cif"


def freeze(gpx):
    hist = gpx.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in gpx.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": False})


def case(name, cod, scale):
    out = ROOT / ".tmp" / f"screen_final_{name}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    gpx.set_Controls("cycles", 8)
    freeze(gpx)
    hist = gpx.histogram(0)
    phase = gpx.add_phase(str(path(cod)), phasename=name, histograms=[hist], fmthint="CIF")
    phase.HAPvalue("Scale", scale)
    phase.set_HAP_refinements({"Scale": True})
    gpx.save()
    gpx.do_refinements([{}])
    print("\n", name, hist.residuals)
    print("scale", phase.HAPvalue("Scale"), "mass fractions", hist.ComputeMassFracs())
    try:
        shifts, sigmas = gpx.get_LastFitResults()
        var = f"{phase.id}:0:Scale"
        print("scale shift/esd", shifts.get(var), sigmas.get(var))
    except Exception as exc:
        print("esd failed", repr(exc))
    gpx.save()


for args in [
    ("CuO", "1011194", 0.2),
    ("Cu3WO6", "1527404", 0.02),
    ("Cu2O", "1010941", 0.02),
]:
    try:
        case(*args)
    except Exception as exc:
        print("FAILED", args[0], repr(exc))
