from pathlib import Path
import copy
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / ".tmp" / "test_wo3_modern.gpx"
OUT = ROOT / ".tmp" / "clean_modern.gpx"

if OUT.exists():
    OUT.unlink()
gpx = G2sc.G2Project(str(SRC), newgpx=str(OUT))

# Remove the superseded screening model and rename the selected WO3 model.
del gpx.data["Phases"]["WO3_monoclinic"]
phase_names = next(x for x in gpx.names if x[0] == "Phases")
phase_names.remove("WO3_monoclinic")
modern = gpx.data["Phases"].pop("WO3_modern")
modern["General"]["Name"] = "WO3"
gpx.data["Phases"]["WO3"] = modern
phase_names[phase_names.index("WO3_modern")] = "WO3"
gpx.update_ids()

hist = gpx.histogram(0)
hist.data["Reflection Lists"] = {}
# SH/L was estimated in the profile-selection run. Fix it here to remove its
# 97.6% correlation with Zero for a stable final covariance calculation.
hist.InstrumentParameters["SH/L"][2] = False
gpx.set_Controls("cycles", 12)
gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
gpx.save()
gpx.do_refinements([{}])
print("refined", hist.residuals)
print("Rvals", gpx.data["Covariance"]["data"].get("Rvals"))
print("mass", hist.ComputeMassFracs())
gpx.do_refinements([{}])
print("repeat", hist.residuals)
print("Rvals repeat", gpx.data["Covariance"]["data"].get("Rvals"))

# Store a calculated profile generated afresh from the final cells, while
# retaining the converged covariance matrix for uncertainties and CIF export.
cov = copy.deepcopy(gpx.data["Covariance"]["data"])
hist.data["Reflection Lists"] = {}
gpx.set_Controls("cycles", 0)
gpx.save()
gpx.do_refinements([{}])
gpx.data["Covariance"]["data"] = cov
gpx.set_Controls("cycles", 12)

x=np.asarray(hist.getdata('X'));yo=np.asarray(hist.getdata('Yobs'));yc=np.asarray(hist.getdata('Ycalc'));w=np.asarray(hist.getdata('Yweight'))
lo,hi=hist.data['Limits'][1];m=(x>=lo)&(x<=hi)&(w>0)
print("recalculated",hist.residuals,"manual",100*np.sqrt(np.sum(w[m]*(yo[m]-yc[m])**2)/np.sum(w[m]*yo[m]**2)))
print("mass2", hist.ComputeMassFracs())
for phase in gpx.phases(): print(phase.name, phase.id, phase.HAPvalue('Scale'), phase.get_cell())
print("instrument",{k:hist.InstrumentParameters[k] for k in ['Zero','Polariz.','U','V','W','X','Y','SH/L']})
print("cov keys",gpx.data['Covariance']['data'].keys())
gpx.save()
