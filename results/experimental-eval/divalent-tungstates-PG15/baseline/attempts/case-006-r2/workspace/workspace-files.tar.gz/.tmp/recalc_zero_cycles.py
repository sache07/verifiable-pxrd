from pathlib import Path
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / ".tmp" / "selected_shl.gpx"
OUT = ROOT / ".tmp" / "recalc0.gpx"

if OUT.exists():
    OUT.unlink()
gpx = G2sc.G2Project(str(SRC), newgpx=str(OUT))
gpx.set_Controls("cycles", 0)
hist = gpx.histogram(0)
hist.data["Reflection Lists"] = {}
gpx.save()
gpx.do_refinements([{}])
x = np.asarray(hist.getdata("X"))
yo = np.asarray(hist.getdata("Yobs"))
yc = np.asarray(hist.getdata("Ycalc"))
w = np.asarray(hist.getdata("Yweight"))
lo, hi = hist.data["Limits"][1]
sel = (x >= lo) & (x <= hi) & (w > 0)
print("stored", hist.residuals)
print("manual Rwp", 100*np.sqrt(np.sum(w[sel]*(yo[sel]-yc[sel])**2)/np.sum(w[sel]*yo[sel]**2)))
print("mass", hist.ComputeMassFracs())
gpx.save()
