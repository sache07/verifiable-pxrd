from pathlib import Path
import csv
import math
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
PATTERN = ROOT / "inputs" / "pattern.csv"
XYE = ROOT / ".tmp" / "pattern.xye"
INST = ROOT / ".tmp" / "cu_kalpha.instprm"
GPX = ROOT / ".tmp" / "trial.gpx"


def prepare_inputs():
    with PATTERN.open(newline="") as src, XYE.open("w") as dst:
        rows = csv.DictReader(src)
        for row in rows:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            # No pointwise uncertainties were supplied. Counting-statistical
            # sigma=sqrt(I) is the least-assumptive weighting model.
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    INST.write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha reflection data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.300;Polariz.:0.5;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:2.0;V:-2.0;W:5.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )


def summarize(gpx, label):
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.InstrumentParameters
    print("\nSUMMARY", label)
    print("residuals", hist.residuals)
    print("cell", phase.get_cell())
    print("inst", {k: v for k, v in inst.items() if k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)"]})
    print("scale", phase.HAPvalue("Scale"))
    print("background", hist.Background[0])
    print("vary", gpx.get_VaryList())


def main():
    prepare_inputs()
    if GPX.exists():
        GPX.unlink()
    gpx = G2sc.G2Project(newgpx=str(GPX))
    hist = gpx.add_powder_histogram(str(XYE), str(INST), fmthint="xye")
    phase = gpx.add_phase(str(ROOT / "cuwo4_start.cif"), phasename="CuWO4", histograms=[hist], fmthint="CIF")
    hist.set_refinements({"Limits": [10.0, 100.0]})
    gpx.set_Controls("cycles", 8)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6

    # Build the fit in stable blocks: intensity/background, cell/offset,
    # then peak shape. Keep the reported K-alpha doublet fixed to metadata.
    steps = [
        {"set": {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12}, "Scale": True}},
        {"set": {"Cell": True, "Instrument Parameters": ["Zero"]}},
        {"set": {"Instrument Parameters": ["U", "V", "W"]}},
        {"set": {"Instrument Parameters": ["X", "Y"]}},
    ]
    for i, step in enumerate(steps, 1):
        try:
            gpx.do_refinements([step])
        finally:
            summarize(gpx, f"step {i}")
    gpx.save()


if __name__ == "__main__":
    main()
