#!/usr/bin/env python3
"""Export the final GSAS-II project, CIFs, fit profile and summary files."""

from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_GPX = ROOT / "trial_fullrange.gpx"
FINAL_GPX = ROOT / "final.gpx"


def main():
    project = G2sc.G2Project(str(SOURCE_GPX), newgpx=str(FINAL_GPX))
    project.save()
    hist = project.histogram(0)

    cif_names = {
        "WO3_gamma": "WO3_gamma.cif",
        "Co3O4_spinel": "Co3O4_spinel.cif",
    }
    formulas = {
        "WO3_gamma": "WO3",
        "Co3O4_spinel": "Co3O4",
    }
    display_names = {
        "WO3_gamma": "gamma-WO3",
        "Co3O4_spinel": "Co3O4 spinel",
    }
    for phase in project.phases():
        phase.export_CIF(str(ROOT / cif_names[phase.name]))

    x = np.asarray(hist.getdata("X"), dtype=float)
    observed = np.asarray(hist.getdata("Yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("Ycalc"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    difference = observed - calculated
    profile = np.column_stack((x, observed, calculated, difference, background))
    np.savetxt(
        ROOT / "fit.csv",
        profile,
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference_obs_minus_calc,background",
        comments="",
        fmt=["%.8f", "%.6f", "%.6f", "%.6f", "%.6f"],
    )

    fractions = hist.ComputeMassFracs()
    residuals = hist.residuals
    refinement = project.data["Covariance"]["data"]["Rvals"]
    phase_rows = []
    for phase in project.phases():
        fraction, fraction_esd = fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        pid = phase.id
        phase_rows.append({
            "name": display_names[phase.name],
            "formula": formulas[phase.name],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": cif_names[phase.name],
            "weight_fraction": fraction,
            "weight_fraction_esd": fraction_esd,
            "weight_percent": 100.0 * fraction,
            "weight_percent_esd": 100.0 * fraction_esd,
            "unit_cell": cell,
            "unit_cell_esd": cell_esd,
            "R_F_percent": residuals.get(f"{pid}:0:Rf"),
            "R_F_squared_percent": residuals.get(f"{pid}:0:Rf^2"),
        })

    nobs = int(refinement["Nobs"])
    nvars = int(refinement["Nvars"])
    result = {
        "phases": phase_rows,
        "weight_fraction_basis": "normalized over the modeled crystalline phases; amorphous content not quantified",
        "fit_statistics": {
            "R_p_percent": residuals["R"],
            "R_wp_percent": residuals["wR"],
            "R_exp_percent": residuals["wRmin"],
            "goodness_of_fit": refinement["GOF"],
            "chi_square": refinement["chisq"],
            "reduced_chi_square": refinement["chisq"] / (nobs - nvars),
            "n_observations": nobs,
            "n_refined_variables": nvars,
            "converged": bool(refinement["converged"]),
            "maximum_shift_over_esd": refinement["Max shft/sig"],
        },
        "profile_path": "fit.csv",
        "project_path": "final.gpx",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    wo = next(row for row in phase_rows if row["formula"] == "WO3")
    co = next(row for row in phase_rows if row["formula"] == "Co3O4")
    report = f"""# Powder diffraction phase analysis

## Result

The crystalline pattern is modeled by two residual precursor phases:

- monoclinic gamma-WO3, space group P 21/n: **{wo['weight_percent']:.2f} wt%** (formal 1-sigma {wo['weight_percent_esd']:.2f} wt%);
- cubic Co3O4 spinel, space group F d -3 m: **{co['weight_percent']:.2f} wt%** (formal 1-sigma {co['weight_percent_esd']:.2f} wt%).

Fractions are normalized only over these modeled crystalline phases. No amorphous fraction was measured.

## Evidence and refinement

The WO3 assignment is fixed by the resolved low-angle triplet at 23.465, 23.954 and 24.714 degrees 2theta and its matching higher-angle multiplets. The Co3O4 assignment is independently supported by its 220/311/400/511/440 series near 31.636, 37.200, 45.143, 59.672 and 65.551 degrees. A specimen-displacement correction accounts coherently for the positive, angle-dependent offset of both phases. The refined cells are a={wo['unit_cell']['length_a']:.5f}, b={wo['unit_cell']['length_b']:.5f}, c={wo['unit_cell']['length_c']:.5f} A, beta={wo['unit_cell']['angle_beta']:.4f} degrees for gamma-WO3, and a={co['unit_cell']['length_a']:.5f} A for Co3O4.

Whole-pattern Rietveld refinement used the reported Cu Kalpha1/Kalpha2 wavelengths and 0.5 intensity ratio. Refined quantities were phase scales, lattice metrics, a reflection-geometry specimen displacement, global profile terms, a smooth 20-term background, and one symmetry-constrained isotropic displacement parameter for Co3O4. Atomic coordinates were retained from COD 2311041 (WO3, transformed to the near-orthogonal P 21/n setting) and COD 9005896 (Co3O4), because positional refinement was correlated and not reliable from this mixture pattern. The final fit has Rp={residuals['R']:.3f}%, Rwp={residuals['wR']:.3f}%, Rexp={residuals['wRmin']:.3f}% and goodness-of-fit={refinement['GOF']:.3f}.

CoWO4 was specifically tested because it is the expected reaction product. Its strongest diagnostic reflection would occur near 30.9 degrees after the fitted displacement, where no peak is present; adding a CoWO4 phase drove its scale to the lower bound. A triclinic WO3 alternative also fit worse and refined toward the monoclinic metric. Thus neither is included in the submitted phase list.

## Remaining uncertainty

The formal scale-factor uncertainties are about {wo['weight_percent_esd']:.2f} wt%, but they understate model uncertainty. The instrument profile was not calibrated, thermal parameters are weakly constrained, and structured residuals remain around some overlapping WO3 peaks. A realistic fraction uncertainty is about +/-2 wt% absolute. Trace additional phases below a few weight percent cannot be excluded. The oxygen coordinates and a fully independent WO3 displacement model cannot be determined reliably from these data and were therefore not refined.
"""
    (ROOT / "report.md").write_text(report)


if __name__ == "__main__":
    main()
