#!/usr/bin/env python3
"""Build and refine a two-phase GSAS-II model for pattern.csv."""

from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
WO3_CIF = ROOT / "wo3_loopstra_near_orthogonal.cif"
CO3O4_CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/58/9005896.cif")


def show(project, label):
    hist = project.histogram(0)
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "SH/L")})
    print("sample", {k: v for k, v in hist.SampleParameters.items()
                     if k in ("Type", "Shift", "Transparency", "Gonio. radius", "Scale")})
    for phase in project.phases():
        print(phase.name, phase.get_cell(), phase.composition,
              "HAP scale", phase.getHAPvalues(hist.name)["Scale"],
              "size", phase.getHAPvalues(hist.name)["Size"],
              "mustrain", phase.getHAPvalues(hist.name)["Mustrain"])
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fractions unavailable", repr(exc))


def main():
    gpx_path = ROOT / "trial_conv.gpx"
    project = G2sc.G2Project(newgpx=str(gpx_path))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.SampleParameters["Shift"][0] = -580.0
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    # A smooth empirical background is adequate for this high, slowly varying baseline.
    hist.set_refinements({"Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": 16,
        "coeffs": [3150.0] + [0.0] * 15,
    }})

    wo3 = project.add_phase(str(WO3_CIF), phasename="WO3_gamma", histograms=[hist], fmthint="CIF")
    co3o4 = project.add_phase(str(CO3O4_CIF), phasename="Co3O4_spinel", histograms=[hist], fmthint="CIF")
    # Keep literature coordinates fixed; only profile, cells and quantitative scales are warranted.
    wo3.getHAPvalues(hist.name)["Scale"][0] = 16.85
    co3o4.getHAPvalues(hist.name)["Scale"][0] = 6.45
    project.set_Controls("cycles", 12)
    project.save()

    # Establish background and scales with the physically inferred displacement held fixed.
    project.do_refinements([
        {"set": {"Background": {"refine": True}, "Scale": True}},
    ])
    show(project, "background + phase scales")

    # Refine displacement against the unrefined reference cells, then hold it fixed.
    project.do_refinements([
        {"set": {"Sample Parameters": ["Shift"]}},
    ])
    show(project, "sample displacement")
    project.set_refinement({"clear": {"Sample Parameters": ["Shift"]}})

    # Refine lattice metrics and a restrained set of global profile terms progressively.
    project.do_refinements([
        {"set": {"Cell": True}},
        {"set": {"Instrument Parameters": ["W", "X"]}},
        {"set": {"Instrument Parameters": ["U", "Y"]}},
    ])
    show(project, "cells + profile")

    # Final joint scale/background/cell/profile cycles.
    project.do_refinements([{}])
    project.save()
    show(project, "final trial")


if __name__ == "__main__":
    main()
