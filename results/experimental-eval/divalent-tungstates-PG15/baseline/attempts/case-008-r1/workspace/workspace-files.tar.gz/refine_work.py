#!/usr/bin/env python3
"""Build and refine the GSAS-II model for the supplied powder pattern.

This is kept as a reproducibility aid; final deliverables are written in the
workspace root.
"""

from pathlib import Path
import csv
import json
import math
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
XYE = ROOT / "pattern.xye"
INST = ROOT / "instrument.instprm"
GPX = ROOT / "trial.gpx"
MNWO4_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)


def prepare_inputs():
    arr = np.genfromtxt(PATTERN, delimiter=",", names=True)
    x = arr["two_theta_deg"]
    y = arr["intensity"]
    # No pointwise uncertainties were supplied. Counting-statistical weights
    # are the least-assumptive choice for unprocessed count data.
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(XYE, np.column_stack([x, y, sigma]), fmt="%.8f %.8f %.8f")
    INST.write_text(
        "#GSAS-II instrument parameter file for Cu Ka1/Ka2 reflection data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.5;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:5.0;V:-2.0;W:5.0;X:0.0;Y:2.0;Z:0.0;SH/L:0.002\n"
    )


def build_initial():
    prepare_inputs()
    gpx = G2sc.G2Project(newgpx=str(GPX))
    hist = gpx.add_powder_histogram(str(XYE), str(INST), fmthint="xye")
    phase = gpx.add_phase(
        str(MNWO4_CIF),
        phasename="MnWO4_wolframite",
        histograms=[hist],
        fmthint="CIF",
    )
    gpx.save()
    print("histogram", hist.name)
    print("limits", hist.data["Limits"])
    print("background", hist.data["Background"])
    print("instrument", hist.data["Instrument Parameters"])
    print("sample", hist.data["Sample Parameters"])
    print("HAP", phase.data["Histograms"][hist.name])
    print("cell", phase.get_cell())
    print("atoms")
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.uiso, atom.refinement_flags)


if __name__ == "__main__":
    build_initial()
