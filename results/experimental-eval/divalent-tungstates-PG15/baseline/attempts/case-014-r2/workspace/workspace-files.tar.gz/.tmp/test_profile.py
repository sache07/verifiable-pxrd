import json
import os
import sys

from GSASII import GSASIIscriptable as G2sc


BASE = os.path.abspath(".tmp/trial_srwo4m.gpx")

CASES = {
    "fixed": {"U": (20.0, False), "V": (0.0, False), "W": (50.0, False), "X": (5.0, False), "Y": (2.0, False)},
    "wxy": {"U": (0.0, False), "V": (0.0, False), "W": (50.0, True), "X": (5.0, True), "Y": (2.0, True)},
    "uwxy": {"U": (10.0, True), "V": (0.0, False), "W": (50.0, True), "X": (5.0, True), "Y": (2.0, True)},
    "uwy": {"U": (10.0, True), "V": (0.0, False), "W": (50.0, True), "X": (5.0, False), "Y": (2.0, True)},
    "wy": {"U": (0.0, False), "V": (0.0, False), "W": (50.0, True), "X": (5.0, False), "Y": (2.0, True)},
}


def run_one(name):
    output = os.path.abspath(f".tmp/profile_{name}.gpx")
    proj = G2sc.G2Project(gpxfile=BASE, newgpx=output)
    hist = proj.histogram(0)
    for key, (value, refine) in CASES[name].items():
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = refine
    proj.set_Controls("cycles", 8)
    proj.do_refinements([{}])
    proj.save()
    print(json.dumps({
        "case": name,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "profile": {key: hist.InstrumentParameters[key][1] for key in ("U", "V", "W", "X", "Y")},
        "fractions": {key: value[0] for key, value in hist.ComputeMassFracs().items()},
        "output": output,
    }, sort_keys=True))


for case in sys.argv[1:]:
    run_one(case)
