import argparse
import json
import os

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", required=True)
    ap.add_argument("--phase", action="append", nargs=3, metavar=("NAME", "CIF", "CELL_SCALE"), required=True)
    ap.add_argument("--atoms", action="store_true")
    args = ap.parse_args()

    out = os.path.abspath(args.output)
    if os.path.exists(out):
        os.remove(out)
    proj = G2sc.G2Project(newgpx=out)
    hist = proj.add_powder_histogram(
        os.path.abspath(".tmp/pattern.xye"),
        os.path.abspath(".tmp/cu_dual.instprm"),
        fmthint="xye",
    )
    hist.Limits("lower", 10.05)
    hist.Limits("upper", 99.95)
    hist.SampleParameters["Scale"][1] = False
    inst = hist.InstrumentParameters
    inst["Zero"][1] = 0.40

    phases = []
    for phase_index, (name, cif, cell_scale_text) in enumerate(args.phase):
        ph = proj.add_phase(os.path.abspath(cif), phasename=name, histograms=[hist], fmthint="CIF")
        scale = float(cell_scale_text)
        cell = ph.data["General"]["Cell"]
        cell[1] *= scale
        cell[2] *= scale
        cell[3] *= scale
        from GSASII import GSASIIlattice as G2lat
        cell[7] = G2lat.calc_V(G2lat.cell2A(cell[1:7]))
        ph.getHAPvalues(hist.name)["Scale"][0] = 10.0 if phase_index == 0 else 1.0
        phases.append(ph)

    proj.set_Controls("cycles", 8)
    proj.save()

    recipe = [
        {"set": {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 18}, "Scale": True}},
        {"set": {"Cell": True, "Instrument Parameters": ["Zero"]}},
        {"set": {"Instrument Parameters": ["U", "V", "W"]}},
        {},
    ]
    if args.atoms:
        recipe.append({"set": {"Atoms": {"all": "XU"}}})

    for step, ref in enumerate(recipe, 1):
        try:
            proj.do_refinements([ref])
            print("STEP", step, json.dumps(hist.residuals, default=float, sort_keys=True))
        except Exception as exc:
            print("FAILED STEP", step, repr(exc))
            break

    proj.save()
    print("FINAL", json.dumps(hist.residuals, default=float, sort_keys=True))
    print("INST", {k: v for k, v in hist.InstrumentParameters.items() if k in ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
    try:
        print("MASSFRACS", hist.ComputeMassFracs())
    except Exception as exc:
        print("MASSFRACS_FAILED", repr(exc))
    for ph in phases:
        print("PHASE", ph.name, ph.get_cell(), ph.getHAPvalues(hist.name)["Scale"],
              "Mass", ph.data["General"].get("Mass"),
              "Size", ph.getHAPvalues(hist.name).get("Size"),
              "Mustrain", ph.getHAPvalues(hist.name).get("Mustrain"))


if __name__ == "__main__":
    main()
