import json
import os
import sys

from GSASII import GSASIIscriptable as G2sc


BASE = os.path.abspath(".tmp/trial_srwo4m.gpx")


for case in sys.argv[1:]:
    output = os.path.abspath(f".tmp/shift_{case}.gpx")
    proj = G2sc.G2Project(gpxfile=BASE, newgpx=output)
    hist = proj.histogram(0)
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False
    if case == "shift":
        hist.InstrumentParameters["Zero"][1] = 0.0
        hist.InstrumentParameters["Zero"][2] = False
        hist.SampleParameters["Shift"] = [-600.0, True]
    elif case == "both":
        hist.InstrumentParameters["Zero"][2] = True
        hist.SampleParameters["Shift"] = [0.0, True]
    elif case == "zero":
        hist.InstrumentParameters["Zero"][2] = True
        hist.SampleParameters["Shift"] = [0.0, False]
    proj.set_Controls("cycles", 8)
    proj.do_refinements([{}])
    proj.save()
    print(json.dumps({
        "case": case,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "zero": hist.InstrumentParameters["Zero"][1],
        "shift_microns": hist.SampleParameters["Shift"][0],
        "fractions": {key: value[0] for key, value in hist.ComputeMassFracs().items()},
        "cells": {phase.name: phase.get_cell() for phase in proj.phases()},
        "output": output,
    }, sort_keys=True))
