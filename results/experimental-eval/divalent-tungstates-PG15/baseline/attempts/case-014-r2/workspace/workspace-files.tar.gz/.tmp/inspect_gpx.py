import json
import os
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc


proj = G2sc.G2Project(gpxfile=os.path.abspath(sys.argv[1]))
hist = proj.histogram(0)
print("residuals", json.dumps(hist.residuals, default=float, sort_keys=True))
print("instrument", {key: value for key, value in hist.InstrumentParameters.items() if key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")})
print("sample", hist.SampleParameters)
print("hist data keys", hist.data.keys())
print("raw data structure", type(hist.data.get("data")).__name__, len(hist.data.get("data", [])), [type(item).__name__ for item in hist.data.get("data", [])])
if isinstance(hist.data.get("data"), list) and len(hist.data["data"]) > 1:
    print("profile arrays", type(hist.data["data"][1]).__name__, len(hist.data["data"][1]), [np.shape(item) for item in hist.data["data"][1]])
print("fractions", hist.ComputeMassFracs())
for index, phase in enumerate(proj.phases()):
    hap = phase.data["Histograms"][hist.name]
    print("phase", index, phase.name, phase.get_cell(), "scale", hap["Scale"], "PO", hap["Pref.Ori."])
    for atom in phase.atoms():
        print("atom", atom.label, atom.element, atom.coordinates, atom.refinement_flags, atom.uiso)
