import csv
import json
import math
import os

import numpy as np
from pymatgen.core import Structure


required = [
    "final.gpx",
    "fit.csv",
    "result.json",
    "report.md",
    "phase_SrWO4_scheelite.cif",
    "phase_WO3_monoclinic.cif",
    "phase_SrWO4_fergusonite_type.cif",
]
for path in required:
    assert os.path.isfile(path) and os.path.getsize(path) > 0, path

with open("result.json") as handle:
    result = json.load(handle)
assert len(result["phases"]) == 3
fraction_sum = sum(item["weight_fraction"] for item in result["phases"])
assert abs(fraction_sum - 1.0) < 1e-10, fraction_sum
for item in result["phases"]:
    structure = Structure.from_file(item["cif_path"])
    assert len(structure) > 0
    assert structure.volume > 0

with open("fit.csv", newline="") as handle:
    reader = csv.DictReader(handle)
    assert reader.fieldnames == ["two_theta_deg", "observed", "calculated", "difference"]
    rows = list(reader)
assert len(rows) == result["fit_statistics"]["number_of_profile_points"]
for row in rows:
    values = [float(row[key]) for key in reader.fieldnames]
    assert all(math.isfinite(value) for value in values)
    assert abs(values[1] - values[2] - values[3]) < 2e-6

print(json.dumps({
    "required_files": len(required),
    "phase_count": len(result["phases"]),
    "weight_fraction_sum": fraction_sum,
    "fit_rows": len(rows),
    "Rwp_percent": result["fit_statistics"]["Rwp_percent"],
}, sort_keys=True))
