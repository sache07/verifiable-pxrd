import json
import os
import sys

from GSASII import GSASIIscriptable as G2sc


BASE = os.path.abspath(".tmp/trial_srwo4m.gpx")


def enable(phase, labels):
    for atom in phase.atoms():
        if labels == "all" or atom.label in labels:
            atom.refinement_flags = "X"


def run_one(case):
    output = os.path.abspath(f".tmp/atoms_{case}.gpx")
    proj = G2sc.G2Project(gpxfile=BASE, newgpx=output)
    hist = proj.histogram(0)
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False

    if case in ("p0", "p0p2", "allx"):
        enable(proj.phase(0), "all")
    if case in ("p2", "p0p2", "allx"):
        enable(proj.phase(2), "all")
    if case == "p2heavy":
        enable(proj.phase(2), {"Sr", "W"})
    if case in ("wo3w", "allx"):
        enable(proj.phase(1), {"W1", "W2"})
    if case == "wo3all":
        enable(proj.phase(1), "all")

    proj.set_Controls("cycles", 8)
    proj.do_refinements([{}])
    proj.save()
    print(json.dumps({
        "case": case,
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "fractions": {key: value[0] for key, value in hist.ComputeMassFracs().items()},
        "atoms": {
            phase.name: {atom.label: atom.coordinates for atom in phase.atoms()}
            for phase in proj.phases()
        },
        "output": output,
    }, sort_keys=True))


for name in sys.argv[1:]:
    run_one(name)
