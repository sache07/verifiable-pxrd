import gzip
import json
import math
import os
import sys
import warnings

import numpy as np
import pandas as pd
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d


warnings.filterwarnings("ignore")
INDEX = "<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz"
ROOT = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"


def cif_path(cod_id):
    return os.path.join(ROOT, cod_id[0], cod_id[1:3], cod_id[3:5], cod_id + ".cif")


with gzip.open(INDEX, "rt") as handle:
    index = json.load(handle)

rows = []
for key in (
    "O-Sr-W", "O-W", "O-Sr", "C-O-Sr",
    "Ca-O-W", "Ba-O-W", "Cd-O-W", "O-Pb-W", "Mg-O-W", "O-W-Zn",
):
    for formula, cod_id, space_group, quality in index.get(key, []):
        rows.append((key, formula, cod_id, space_group, quality))

profile = pd.read_csv(sys.argv[1] if len(sys.argv) > 1 else ".tmp/trial_srw_wo3_profile.csv")
x = profile["two_theta"].to_numpy()
residual = profile["difference"].to_numpy()
use = (x >= 12.0) & (x <= 98.0)
x = x[use]
target = np.maximum(residual[use], 0.0)
step = float(np.median(np.diff(x)))
# Suppress counting noise while preserving the measured peak widths.
target = gaussian_filter1d(target, 0.04 / step)

calculator = XRDCalculator(wavelength=1.540598)
results = []
seen = set()
for key, formula, cod_id, space_group, quality in rows:
    if cod_id in seen:
        continue
    seen.add(cod_id)
    path = cif_path(cod_id)
    try:
        structure = Structure.from_file(path)
        pattern = calculator.get_pattern(structure, two_theta_range=(8.0, 110.0), scaled=False)
    except Exception as exc:
        print("SKIP", cod_id, type(exc).__name__)
        continue
    peak_x = np.asarray(pattern.x, dtype=float)
    peak_y = np.asarray(pattern.y, dtype=float)
    if not len(peak_x) or not np.max(peak_y):
        continue
    peak_y /= np.max(peak_y)

    best = None
    # Uniform metric scaling allows for temperature, pressure and solid-solution
    # shifts during this screening pass; the subsequent Rietveld model refines
    # the complete cell rather than applying this approximation.
    for metric_scale in np.linspace(0.93, 1.08, 76):
        arg = np.sin(np.radians(peak_x / 2.0)) / metric_scale
        valid = (arg > 0) & (arg < 1)
        shifted = np.degrees(2.0 * np.arcsin(arg[valid]))
        intensities = peak_y[valid]
        trial = np.zeros_like(x)
        indices = np.rint((shifted - x[0]) / step).astype(int)
        keep = (indices >= 0) & (indices < len(x))
        np.add.at(trial, indices[keep], intensities[keep])
        trial = gaussian_filter1d(trial, 0.09 / step)
        denom = float(np.dot(trial, trial))
        if denom <= 0:
            continue
        amplitude = max(0.0, float(np.dot(target, trial) / denom))
        improvement = 2.0 * amplitude * float(np.dot(target, trial)) - amplitude * amplitude * denom
        cosine = float(np.dot(target, trial) / math.sqrt(np.dot(target, target) * denom))
        score = (improvement, cosine, metric_scale, amplitude)
        if best is None or score[0] > best[0]:
            best = score
    if best:
        results.append({
            "key": key,
            "formula": formula,
            "cod_id": cod_id,
            "space_group": space_group,
            "quality": quality,
            "improvement": best[0],
            "cosine": best[1],
            "metric_scale": best[2],
            "amplitude": best[3],
            "path": path,
        })

for result in sorted(results, key=lambda item: item["improvement"], reverse=True):
    print(json.dumps(result, sort_keys=True))
