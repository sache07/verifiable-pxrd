import gzip
import json


PATH = "<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz"

with gzip.open(PATH, "rt") as handle:
    data = json.load(handle)

print(type(data).__name__)
if isinstance(data, dict):
    print("top-level keys", list(data)[:20], "count", len(data))
    first_key = next(iter(data))
    print("first", first_key, data[first_key])
else:
    print("count", len(data))
    for row in data[:3]:
        print(row)

for key in ("O-Sr-W", "Sr-W", "C-O-Sr", "O-Sr", "O-W", "Ca-O-W", "Ba-O-W", "Cd-O-W", "O-Pb-W", "Mg-O-W", "O-W-Zn"):
    print("\nKEY", key, "count", len(data.get(key, [])))
    for row in data.get(key, []):
        print(row)
