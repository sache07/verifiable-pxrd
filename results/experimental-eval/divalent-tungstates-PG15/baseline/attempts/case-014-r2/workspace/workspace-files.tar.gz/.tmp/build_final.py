import csv
import json
import math
import os

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = os.path.abspath(".")
DATA = os.path.join(ROOT, ".tmp", "pattern.xye")
INSTRUMENT = os.path.join(ROOT, ".tmp", "cu_dual.instprm")
PROJECT = os.path.join(ROOT, "final.gpx")

PHASES = [
    {
        "name": "SrWO4_scheelite",
        "formula": "SrWO4",
        "cif": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/54/60/1546036.cif",
        "cell_scale": 1.005,
        "initial_scale": 10.0,
        "output_cif": "phase_SrWO4_scheelite.cif",
        "assignment_confidence": "high",
    },
    {
        "name": "WO3_monoclinic",
        "formula": "WO3",
        "cif": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif",
        "cell_scale": 1.0015,
        "initial_scale": 1.0,
        "output_cif": "phase_WO3_monoclinic.cif",
        "assignment_confidence": "high",
    },
    {
        "name": "SrWO4_fergusonite_type",
        "formula": "SrWO4",
        "cif": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/54/60/1546037.cif",
        "cell_scale": 0.982,
        "initial_scale": 1.0,
        "output_cif": "phase_SrWO4_fergusonite_type.cif",
        "assignment_confidence": "provisional",
    },
]


def remove_old_outputs():
    for filename in [
        PROJECT,
        os.path.join(ROOT, "fit.csv"),
        os.path.join(ROOT, "result.json"),
        *[os.path.join(ROOT, item["output_cif"]) for item in PHASES],
    ]:
        if os.path.exists(filename):
            os.remove(filename)


def main():
    remove_old_outputs()
    project = G2sc.G2Project(newgpx=PROJECT)
    histogram = project.add_powder_histogram(DATA, INSTRUMENT, fmthint="xye")
    histogram.Limits("lower", 10.05)
    histogram.Limits("upper", 99.95)

    # The specimen was measured in reflection geometry. A specimen-height
    # correction gives physically credible cells; zero and specimen shift are
    # too correlated to refine together, so nominal zero is held at zero.
    histogram.SampleParameters["Scale"][1] = False
    histogram.SampleParameters["Shift"] = [-570.0, False]
    histogram.InstrumentParameters["Zero"][1] = 0.0
    histogram.InstrumentParameters["Zero"][2] = False

    phase_objects = []
    for item in PHASES:
        phase = project.add_phase(
            item["cif"],
            phasename=item["name"],
            histograms=[histogram],
            fmthint="CIF",
        )
        cell = phase.data["General"]["Cell"]
        for index in (1, 2, 3):
            cell[index] *= item["cell_scale"]
        cell[7] = G2lat.calc_V(G2lat.cell2A(cell[1:7]))
        phase.getHAPvalues(histogram.name)["Scale"][0] = item["initial_scale"]
        phase_objects.append(phase)

    project.set_Controls("cycles", 8)
    project.save()

    recipe = [
        {"set": {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 18}, "Scale": True}},
        {"set": {"Cell": True, "Sample Parameters": ["Shift"]}},
        {"set": {"Instrument Parameters": ["U", "V", "W"]}},
        {},
    ]
    for step, refinement in enumerate(recipe, 1):
        project.do_refinements([refinement])
        print("STEP", step, json.dumps(histogram.residuals, default=float, sort_keys=True))

    # Freeze the empirical profile after fitting it because there is no
    # calibrated standard. The last cycle determines scales, cells and sample
    # displacement with that profile held fixed and supplies their covariance.
    for key in ("U", "V", "W"):
        histogram.InstrumentParameters[key][2] = False
    project.do_refinements([{}])
    project.save()

    mass_fractions = histogram.ComputeMassFracs()
    for phase, item in zip(phase_objects, PHASES):
        phase.export_CIF(os.path.join(ROOT, item["output_cif"]))

    x, observed, weights, calculated, background, stored_difference = histogram.data["data"][1]
    lower, upper = histogram.data["Limits"][1]
    selected = (x >= lower) & (x <= upper)
    with open(os.path.join(ROOT, "fit.csv"), "w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        for angle, obs, calc in zip(x[selected], observed[selected], calculated[selected]):
            writer.writerow([f"{angle:.8f}", f"{obs:.8f}", f"{calc:.8f}", f"{obs - calc:.8f}"])

    residuals = histogram.residuals
    rwp = float(residuals["wR"])
    rp = float(residuals["R"])
    rexp = float(residuals["wRmin"])
    result_phases = []
    for phase, item in zip(phase_objects, PHASES):
        fraction, fraction_esd = mass_fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        result_phases.append({
            "name": item["name"],
            "formula": item["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": item["output_cif"],
            "weight_fraction": float(fraction),
            "weight_fraction_formal_esd": float(fraction_esd),
            "assignment_confidence": item["assignment_confidence"],
            "cell_angstrom_degrees": {key: float(value) for key, value in cell.items()},
            "cell_formal_esd": {key: float(value) for key, value in cell_esd.items()},
        })

    result = {
        "phases": result_phases,
        "fit_statistics": {
            "Rp_percent": rp,
            "Rwp_percent": rwp,
            "Rexp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "reduced_chi_squared": (rwp / rexp) ** 2,
            "refined_range_two_theta_deg": [float(lower), float(upper)],
            "number_of_profile_points": int(np.count_nonzero(selected)),
        },
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "refinement_notes": {
            "radiation": "Cu Kalpha1/Kalpha2 doublet",
            "wavelengths_angstrom": [1.540598, 1.544426],
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "point_weights": "Poisson approximation, sigma=sqrt(counts), because pointwise uncertainties were not supplied",
            "sample_displacement_micrometers": float(histogram.SampleParameters["Shift"][0]),
            "instrument_profile": "Empirically fitted U/V/W then fixed; no calibrated standard was supplied",
            "weight_fraction_basis": "Normalized over the three modeled crystalline phases; amorphous content is not quantified",
        },
    }
    with open(os.path.join(ROOT, "result.json"), "w") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")

    print("FINAL", json.dumps(histogram.residuals, default=float, sort_keys=True))
    print("MASS_FRACTIONS", mass_fractions)
    print("SAMPLE_SHIFT", histogram.SampleParameters["Shift"])
    print("PROFILE", {key: histogram.InstrumentParameters[key] for key in ("U", "V", "W", "X", "Y")})
    for phase in phase_objects:
        print("CELL", phase.name, phase.get_cell_and_esd())


if __name__ == "__main__":
    main()
