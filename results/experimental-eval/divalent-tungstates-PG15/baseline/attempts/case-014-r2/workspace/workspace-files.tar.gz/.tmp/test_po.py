import json
import os
import sys

from GSASII import GSASIIscriptable as G2sc


BASE = os.path.abspath(".tmp/trial_srwo4m.gpx")


def run_one(phase_index, axis):
    tag = f"p{phase_index}_{''.join(str(i).replace('-', 'm') for i in axis)}"
    output = os.path.abspath(f".tmp/po_{tag}.gpx")
    proj = G2sc.G2Project(gpxfile=BASE, newgpx=output)
    hist = proj.histogram(0)
    phase = proj.phase(phase_index)

    # Isolate the effect of one March-Dollase term. Keep the converged
    # instrument profile fixed while phase scales, cells and background
    # continue to settle.
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)

    proj.set_Controls("cycles", 5)
    proj.do_refinements([{}])
    proj.save()
    fractions = hist.ComputeMassFracs()
    print(json.dumps({
        "phase_index": phase_index,
        "phase": phase.name,
        "axis": axis,
        "MD": po[1],
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "fractions": {key: value[0] for key, value in fractions.items()},
        "output": output,
    }, sort_keys=True))


def main():
    phase_index = int(sys.argv[1])
    for text in sys.argv[2:]:
        axis = tuple(int(item) for item in text.split(","))
        run_one(phase_index, axis)


if __name__ == "__main__":
    main()
