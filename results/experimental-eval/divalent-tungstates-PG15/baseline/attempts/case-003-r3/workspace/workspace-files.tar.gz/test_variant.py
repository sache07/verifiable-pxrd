#!/usr/bin/env python3
"""Extend a converged trial GSAS-II model with one optional parameter."""

from __future__ import annotations

import argparse

import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("tag")
    ap.add_argument("--po", nargs=4, metavar=("PHASE", "H", "K", "L"))
    ap.add_argument("--polarization", action="store_true")
    args = ap.parse_args()

    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project("trial_b_fixed_clean.gpx", newgpx=f"variant_{args.tag}.gpx")
    hist = gpx.histogram(0)
    if args.po:
        phase_name, h, k, l = args.po
        phase = gpx.phase(phase_name)
        po = phase.getHAPvalues(hist)["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = [int(h), int(k), int(l)]
    if args.polarization:
        hist.InstrumentParameters["Polariz."][2] = True
    gpx.save()
    for cycle in range(4):
        gpx.do_refinements([{}])
        cov = gpx.data["Covariance"]["data"]
        print("ROUND", cycle + 1, "Rwp", hist.get_wR(),
              "GOF", cov.get("Rvals", {}).get("GOF"),
              "mass", hist.ComputeMassFracs())
    print("POL", hist.InstrumentParameters["Polariz."])
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        print("PHASE", phase.name, "PO", hap["Pref.Ori."],
              "scale", hap["Scale"], "size", hap["Size"],
              "strain", hap["Mustrain"])
    gpx.save()


if __name__ == "__main__":
    main()
