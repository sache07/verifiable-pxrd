#!/usr/bin/env python3
"""Test a physically constrained uniaxial WO3 microstrain model."""

from __future__ import annotations

import argparse

import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("tag")
    parser.add_argument("h", type=int)
    parser.add_argument("k", type=int)
    parser.add_argument("l", type=int)
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(
        "variant_wo3_u.gpx", newgpx=f"variant_strain_{args.tag}.gpx"
    )
    histogram = project.histogram(0)
    phase = project.phase("WO3_monoclinic_alt")
    strain = phase.getHAPvalues(histogram)["Mustrain"]
    isotropic_value = strain[1][0]
    strain[0] = "uniaxial"
    strain[1][0] = isotropic_value
    strain[1][1] = isotropic_value
    strain[2][0] = True
    strain[2][1] = True
    strain[3] = [args.h, args.k, args.l]
    strain[5] = [False] * len(strain[5])
    project.save()

    for cycle in range(4):
        project.do_refinements([{}])
    covariance = project["Covariance"]["data"]["Rvals"]
    print(
        args.tag,
        "Rwp", histogram.get_wR(),
        "GOF", covariance.get("GOF"),
        "converged", covariance.get("converged"),
        "max_shift", covariance.get("Max shft/sig"),
        "message", covariance.get("msg"),
        "strain", strain,
        "mass", histogram.ComputeMassFracs(),
    )
    project.save()


if __name__ == "__main__":
    main()
