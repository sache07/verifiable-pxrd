#!/usr/bin/env python3
"""Build and refine trial GSAS-II models for the supplied powder pattern."""

from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import numpy as np

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PHASES = {
    "cawo4": ("7219229", "CaWO4_scheelite"),
    "wo3a": ("1528915", "WO3_monoclinic"),
    "wo3b": ("2311041", "WO3_monoclinic_alt"),
    "wo3c": ("1010618", "WO3_triclinic"),
    "wo3d": ("1563541", "WO3_monoclinic_smallcell"),
    "wo3e": ("2106293", "WO3_triclinic_modern"),
    "wo3f": ("2107312", "WO3_orthorhombic"),
    "calcite": ("1547347", "CaCO3_calcite"),
    "ca3wo6": ("1563081", "Ca3WO6"),
}


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_inputs() -> tuple[Path, Path]:
    xye = ROOT / "pattern.xye"
    with (ROOT / "inputs/pattern.csv").open(newline="") as src, xye.open("w") as dst:
        reader = csv.DictReader(src)
        dst.write("# Original counts; sigma set to sqrt(counts)\n")
        for row in reader:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")

    inst = ROOT / "cuka.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha reflection data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.285;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:10.0;V:-2.0;W:35.0;X:2.0;Y:2.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def summarize(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histogram(0)
    print(f"SUMMARY {label} residuals={hist.residuals}")
    print("INSTR", {k: v for k, v in hist.InstrumentParameters.items()
                    if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)")})
    print("BACKGROUND", hist.Background[0])
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        print("PHASE", phase.name, "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "mustrain", hap["Mustrain"])
    try:
        print("MASS", hist.ComputeMassFracs())
    except Exception as exc:
        print("MASS_ERROR", repr(exc))


def refine(keys: list[str], tag: str, stop: str, profile_mode: str) -> None:
    xye, inst = make_inputs()
    outfile = ROOT / f"trial_{tag}.gpx"
    gpx = G2sc.G2Project(newgpx=str(outfile), author="OpenAI Codex")
    hist = gpx.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    # The default imported histogram scale is refinable. Fix it to remove the
    # exact degeneracy with the HAP phase scales used for quantitative analysis.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements({"Background": {
        "type": "chebyschev-1", "refine": True, "no. coeffs": 12,
        "coeffs": [1200.0] + [0.0] * 11,
    }})

    phases = []
    for key in keys:
        cod_id, name = PHASES[key]
        phase = gpx.add_phase(str(cod_path(cod_id)), phasename=name, histograms=[hist])
        phase.getHAPvalues(hist)["Scale"][0] = 1.0 / len(keys)
        phases.append(phase)
    gpx.save()

    # Staged refinement: scales/background; cells/zero; then profile terms.
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    gpx.do_refinements([{}])
    summarize(gpx, "scales")
    if stop == "scales":
        return

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    gpx.do_refinements([{}])
    summarize(gpx, "cells_zero")
    if stop == "cells":
        return

    inst_dict = hist.InstrumentParameters
    if profile_mode == "free":
        profile_terms = ["U", "V", "W", "X", "Y"]
    elif profile_mode == "physical":
        for key, value in {"U": 20.0, "V": 0.0, "W": 30.0,
                           "X": 0.0, "Y": 0.0}.items():
            inst_dict[key][1] = value
            inst_dict[key][2] = False
        profile_terms = ["U", "W"]
    elif profile_mode == "mixed":  # one Gaussian and one Lorentzian angular term
        for key, value in {"U": 20.0, "V": 0.0, "W": 30.0,
                           "X": 0.0, "Y": 10.0}.items():
            inst_dict[key][1] = value
            inst_dict[key][2] = False
        profile_terms = ["W", "Y"]
    else:  # narrow, fixed instrumental contribution; phase widths carry broadening
        for key, value in {"U": 10.0, "V": 0.0, "W": 15.0,
                           "X": 0.0, "Y": 5.0}.items():
            inst_dict[key][1] = value
            inst_dict[key][2] = False
        profile_terms = []
    hist.set_refinements({"Instrument Parameters": profile_terms})
    gpx.do_refinements([{}])
    summarize(gpx, "profile")
    if stop == "profile":
        return

    # Phase-dependent broadening is needed because the three constituents have
    # visibly different line widths. Refine size first and then microstrain.
    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 1.0, "refine": True},
        }, [hist])
    gpx.do_refinements([{}])
    summarize(gpx, "size")
    if stop == "size":
        return

    for phase in phases:
        phase.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True},
        }, [hist])
    gpx.do_refinements([{}])
    gpx.save()
    summarize(gpx, "final")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("tag")
    parser.add_argument("phases", nargs="+", choices=sorted(PHASES))
    parser.add_argument("--stop", choices=["scales", "cells", "profile", "size", "strain"],
                        default="strain")
    parser.add_argument("--profile-mode", choices=["free", "physical", "mixed", "fixed"], default="free")
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")
    refine(args.phases, args.tag, args.stop, args.profile_mode)


if __name__ == "__main__":
    main()
