#!/usr/bin/env python3
"""Export the selected GSAS-II refinement and its requested deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_PROJECT = ROOT / "variant_wo3_wcoord_strainb.gpx"
FINAL_PROJECT = ROOT / "final.gpx"
FIT_CSV = ROOT / "fit.csv"
RESULT_JSON = ROOT / "result.json"
REPORT_MD = ROOT / "report.md"

PHASE_INFO = {
    "CaWO4_scheelite": {
        "name": "scheelite calcium tungstate",
        "formula": "CaWO4",
        "cif_path": "CaWO4_scheelite.cif",
        "cod_id": "7219229",
    },
    "WO3_monoclinic_alt": {
        "name": "gamma tungsten trioxide (monoclinic)",
        "formula": "WO3",
        "cif_path": "WO3_gamma_monoclinic.cif",
        "cod_id": "2311041",
    },
    "CaCO3_calcite": {
        "name": "calcite calcium carbonate",
        "formula": "CaCO3",
        "cif_path": "CaCO3_calcite.cif",
        "cod_id": "1547347",
    },
}

OUTPUT_ORDER = ["WO3_monoclinic_alt", "CaCO3_calcite", "CaWO4_scheelite"]


def clean_float(value: object) -> float:
    return float(value)


def main() -> None:
    G2sc.SetPrintLevel("warn")

    # Save under the requested name first, then generate every output from that
    # exact saved project state.
    project = G2sc.G2Project(str(SOURCE_PROJECT), newgpx=str(FINAL_PROJECT))
    project["Controls"]["data"]["Author"] = "OpenAI Codex"
    project.save()
    project = G2sc.G2Project(str(FINAL_PROJECT))
    histogram = project.histogram(0)

    residuals = histogram.residuals
    covariance = project["Covariance"]["data"]
    r_values = covariance["Rvals"]
    if not r_values.get("converged") or r_values.get("SVD0", 0):
        raise RuntimeError(f"Selected refinement is not cleanly converged: {r_values}")

    mass_fractions = histogram.ComputeMassFracs()
    mass_total = sum(item[0] for item in mass_fractions.values())
    if not np.isclose(mass_total, 1.0, atol=1e-10):
        raise RuntimeError(f"Unexpected mass-fraction sum: {mass_total}")

    phase_records: dict[str, dict[str, object]] = {}
    for internal_name in OUTPUT_ORDER:
        phase = project.phase(internal_name)
        info = PHASE_INFO[internal_name]
        output_path = ROOT / info["cif_path"]
        phase.export_CIF(str(output_path))

        fraction, fraction_esd = mass_fractions[internal_name]
        cell, cell_esd = phase.get_cell_and_esd()
        phase_id = phase.id
        phase_records[internal_name] = {
            "name": info["name"],
            "formula": info["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": info["cif_path"],
            "weight_fraction": clean_float(fraction / mass_total),
            "weight_fraction_formal_esd": clean_float(fraction_esd),
            "reference": {
                "database": "Crystallography Open Database",
                "cod_id": info["cod_id"],
            },
            "unit_cell": {
                "a_angstrom": clean_float(cell["length_a"]),
                "b_angstrom": clean_float(cell["length_b"]),
                "c_angstrom": clean_float(cell["length_c"]),
                "alpha_deg": clean_float(cell["angle_alpha"]),
                "beta_deg": clean_float(cell["angle_beta"]),
                "gamma_deg": clean_float(cell["angle_gamma"]),
                "volume_angstrom3": clean_float(cell["volume"]),
                "formal_esd": {
                    "a_angstrom": clean_float(cell_esd["length_a"]),
                    "b_angstrom": clean_float(cell_esd["length_b"]),
                    "c_angstrom": clean_float(cell_esd["length_c"]),
                    "alpha_deg": clean_float(cell_esd["angle_alpha"]),
                    "beta_deg": clean_float(cell_esd["angle_beta"]),
                    "gamma_deg": clean_float(cell_esd["angle_gamma"]),
                    "volume_angstrom3": clean_float(cell_esd["volume"]),
                },
            },
            "phase_fit_statistics": {
                "R_F_percent": clean_float(residuals[f"{phase_id}:0:Rf"]),
                "R_F_squared_percent": clean_float(residuals[f"{phase_id}:0:Rf^2"]),
                "reflections": int(residuals[f"{phase_id}:0:Nref"]),
            },
        }

    x = np.asarray(histogram.getdata("x"), dtype=float)
    observed = np.asarray(histogram.getdata("yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("ycalc"), dtype=float)
    background = np.asarray(histogram.getdata("background"), dtype=float)
    weights = np.asarray(histogram.getdata("yweight"), dtype=float)
    # GSAS-II leaves calculated/background arrays as zero outside the selected
    # limits. This mask reproduces the exact Nobs set used for refinement.
    fitted = background != 0.0
    if int(np.count_nonzero(fitted)) != int(r_values["Nobs"]):
        raise RuntimeError("Profile mask does not match GSAS-II Nobs")
    difference = observed - calculated

    with FIT_CSV.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_observed_minus_calculated",
                "background_intensity",
            ]
        )
        for values in zip(
            x[fitted],
            observed[fitted],
            calculated[fitted],
            difference[fitted],
            background[fitted],
        ):
            writer.writerow([f"{value:.8f}" for value in values])

    # Independently reproduce Rwp from the arrays that feed fit.csv.
    rwp_check = 100.0 * np.sqrt(
        np.sum(weights[fitted] * difference[fitted] ** 2)
        / np.sum(weights[fitted] * observed[fitted] ** 2)
    )
    if not np.isclose(rwp_check, residuals["wR"], atol=1e-9):
        raise RuntimeError((rwp_check, residuals["wR"]))

    fit_statistics = {
        "Rwp_percent": clean_float(residuals["wR"]),
        "Rp_percent": clean_float(residuals["R"]),
        "Rexp_percent": clean_float(residuals["wRmin"]),
        "goodness_of_fit": clean_float(r_values["GOF"]),
        "chi_squared": clean_float(r_values["chisq"]),
        "observations": int(r_values["Nobs"]),
        "refined_variables": int(r_values["Nvars"]),
        "converged": bool(r_values["converged"]),
        "maximum_shift_over_esd": clean_float(r_values["Max shft/sig"]),
        "nominal_two_theta_range_deg": [10.0, 100.0],
        "exported_profile_two_theta_range_deg": [
            clean_float(x[fitted][0]),
            clean_float(x[fitted][-1]),
        ],
    }

    result = {
        "method": "GSAS-II Rietveld refinement",
        "radiation": {
            "source": "Cu K-alpha doublet",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
        },
        "normalization": "Weight fractions sum to one over the modeled crystalline phases; no amorphous fraction was determined.",
        "phases": [phase_records[name] for name in OUTPUT_ORDER],
        "fit_statistics": fit_statistics,
        "files": {
            "GSASII_project": "final.gpx",
            "fit_profile": "fit.csv",
            "report": "report.md",
        },
    }
    with RESULT_JSON.open("w") as stream:
        json.dump(result, stream, indent=2, ensure_ascii=False)
        stream.write("\n")

    wo3 = phase_records["WO3_monoclinic_alt"]
    calcite = phase_records["CaCO3_calcite"]
    cawo4 = phase_records["CaWO4_scheelite"]
    report = f"""# Powder X-ray diffraction phase analysis

## Result

Three crystalline phases are required by the pattern. The quantitative result is normalized over those modeled crystalline phases:

| Phase | Space group | Weight percent | Formal 1σ (wt.%-points) | Structural model |
|---|---:|---:|---:|---|
| γ-WO₃ | {wo3['space_group']} | {100 * wo3['weight_fraction']:.2f} | {100 * wo3['weight_fraction_formal_esd']:.2f} | [{wo3['cif_path']}]({wo3['cif_path']}) |
| Calcite CaCO₃ | {calcite['space_group']} | {100 * calcite['weight_fraction']:.2f} | {100 * calcite['weight_fraction_formal_esd']:.2f} | [{calcite['cif_path']}]({calcite['cif_path']}) |
| Scheelite CaWO₄ | {cawo4['space_group']} | {100 * cawo4['weight_fraction']:.2f} | {100 * cawo4['weight_fraction_formal_esd']:.2f} | [{cawo4['cif_path']}]({cawo4['cif_path']}) |

The monoclinic WO₃ CIF uses the valid nonstandard *P*2₁/*c* cell inherited from COD 2311041 (β ≈ {wo3['unit_cell']['beta_deg']:.3f}°); it is an alternative setting of room-temperature γ-WO₃.

## Evidence and refinement

The phase assignments are supported by complete peak families, not single lines: the dominant γ-WO₃ multiplet near 23.4–24.7° 2θ and its dense higher-angle pattern; calcite peaks near 29.7, 36.3, 39.7, 43.5 and 64.9°; and scheelite CaWO₄ peaks near 18.9, 29.0 and 31.7°. These phases are chemically consistent with partial reaction of the supplied CaCO₃ and WO₃ precursors at 500 °C. Preliminary two-phase fits were much worse (best Rwp 16.75%, versus {fit_statistics['Rwp_percent']:.3f}% here), and the final residual contains no coherent family requiring another crystalline phase.

The fit used the reported Cu Kα₁/Kα₂ wavelengths and 0.5 intensity ratio, Poisson estimates σ = √counts because pointwise uncertainties were absent, a 12-term Chebyshev background, and {fit_statistics['observations']} points over nominal 10–100° 2θ. Refined terms included phase scales and cells, common zero, phase-dependent size/strain, a March–Dollase calcite (104) texture term, and constrained W positions plus common W/O isotropic displacement terms in WO₃. Oxygen coordinates and the CaWO₄/CaCO₃ atomic coordinates were held at their reference values because this overlapped laboratory pattern did not determine them robustly. Final statistics are Rwp = {fit_statistics['Rwp_percent']:.3f}%, Rp = {fit_statistics['Rp_percent']:.3f}%, Rexp = {fit_statistics['Rexp_percent']:.3f}%, and goodness-of-fit = {fit_statistics['goodness_of_fit']:.3f}.

## Remaining uncertainty

The tabulated 1σ values are covariance-only precision estimates and are smaller than the true uncertainty. There was no calibrated instrumental profile or external/internal standard; physically plausible profile and texture choices move the fractions by several weight-percentage points. Thus the phase identities and three-phase requirement are reliable, while the reported fractions should be treated as approximate (roughly a few wt.%-points systematic uncertainty). The analysis cannot quantify amorphous material, and a trace crystalline phase below the residual/model-error level cannot be excluded. Fractions therefore sum to 100% only over the three modeled crystalline phases.

The submitted profile is [fit.csv](fit.csv), and the exact project used for all values and CIF exports is [final.gpx](final.gpx).
"""
    REPORT_MD.write_text(report)

    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
