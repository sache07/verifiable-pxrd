#!/usr/bin/env python3
"""Compare candidate WO3 structure models with a common GSAS-II refinement."""

import csv
import math
import os
import sys

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
WORK = os.path.dirname(__file__)
PATTERN = os.path.join(ROOT, "inputs", "pattern.csv")
XYE = os.path.join(WORK, "pattern.xye")
INST = os.path.join(WORK, "cu_ka.instprm")
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"
MN_CIF = os.path.join(COD, "1", "51", "41", "1514110.cif")


def cod_path(cod_id):
    return os.path.join(COD, cod_id[0], cod_id[1:3], cod_id[3:5], cod_id + ".cif")


def prepare_inputs():
    with open(PATTERN, newline="") as src, open(XYE, "w") as dst:
        reader = csv.DictReader(src)
        dst.write("# two_theta_deg intensity sigma_Poisson\n")
        for row in reader:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    with open(INST, "w") as dst:
        dst.write("#GSAS-II instrument parameter file for lab CuKa data\n")
        dst.write("Type:PXC;Bank:1\n")
        dst.write(
            "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.5;"
            "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        )
        dst.write("U:2.0;V:-2.0;W:30.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.002\n")


def summarize(project, tag):
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    print(f"SUMMARY {tag} residuals={hist.residuals}")
    print(
        "INSTR",
        {k: inst[k] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)") if k in inst},
    )
    print("SAMPLE", sample)
    for phase in project.phases():
        print(
            "PHASE",
            phase.name,
            "cell=",
            phase.get_cell(),
            "scale=",
            phase.HAPvalue("Scale", targethistlist=[hist]),
            "hap=",
            {
                k: phase.getHAPvalues(hist).get(k)
                for k in ("Scale", "Size", "Mustrain", "Pref.Ori.")
            },
        )
    try:
        print("MASS", hist.ComputeMassFracs())
    except Exception as err:
        print("MASS ERROR", repr(err))


def run_candidate(cod_id):
    gpx = os.path.join(WORK, f"candidate_{cod_id}.gpx")
    if os.path.exists(gpx):
        os.unlink(gpx)
    project = G2sc.G2Project(newgpx=gpx)
    hist = project.add_powder_histogram(XYE, INST, fmthint="xye")
    wo3 = project.add_phase(cod_path(cod_id), phasename=f"WO3_{cod_id}", histograms=[hist], fmthint="CIF")
    mno2 = project.add_phase(MN_CIF, phasename="beta_MnO2", histograms=[hist], fmthint="CIF")

    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 12,
            "coeffs": [1100.0] + [0.0] * 11,
        },
    })
    # The histogram scale is kept fixed; both phase scale factors are refined.
    hist.SampleParameters["Scale"] = [1.0, False]
    # Peak positions show an approximately +0.3 degree sample-displacement shift.
    hist.SampleParameters["Shift"] = [-520.0, True]
    wo3.HAPvalue("Scale", 0.5, targethistlist=[hist])
    mno2.HAPvalue("Scale", 0.5, targethistlist=[hist])
    project.set_refinement({"set": {"PhaseFraction": True}})

    # Stage 1: background, phase scales, and specimen displacement.
    project.refine()
    summarize(project, f"{cod_id}:scale")

    # Stage 2: specimen displacement and lattice metrics.
    project.set_refinement({"set": {"Cell": True}})
    project.refine()
    summarize(project, f"{cod_id}:cell_shift")

    # Stage 3: common instrumental profile. Keep wavelength and Ka ratio fixed.
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    project.refine()
    hist.set_refinements({"Instrument Parameters": ["U", "V", "Y", "SH/L"]})
    project.refine()
    summarize(project, f"{cod_id}:profile")

    # Stage 4: phase-specific isotropic size broadening.
    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True, "value": 1.0}},
            [hist],
        )
    project.refine()
    summarize(project, f"{cod_id}:size")
    project.save()
    return hist.residuals.get("wR", float("nan"))


if __name__ == "__main__":
    prepare_inputs()
    candidates = sys.argv[1:] or ["1528915", "2311041", "2106293", "1010618"]
    for candidate in candidates:
        try:
            wr = run_candidate(candidate)
            print(f"FINAL {candidate} {wr:.8g}")
        except Exception as err:
            print(f"FAILED {candidate}: {err!r}")
            raise
