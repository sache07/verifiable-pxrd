#!/usr/bin/env python3
"""Test physically motivated ADP and preferred-orientation additions."""

import os

from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
SOURCE = os.path.join(os.path.dirname(__file__), "candidate_2106293.gpx")
TARGET = os.path.join(os.path.dirname(__file__), "options_2106293.gpx")


def summary(project, stage):
    hist = project.histogram(0)
    print("OPTION", stage, "RESIDUALS", hist.residuals)
    print("OPTION", stage, "MASS", hist.ComputeMassFracs())
    print("OPTION", stage, "PROFILE", {
        k: hist.InstrumentParameters[k][1]
        for k in ("U", "V", "W", "X", "Y", "SH/L")
    })
    print("OPTION", stage, "SAMPLE", hist.SampleParameters["Shift"])
    for phase in project.phases():
        print("OPTION", stage, phase.name, "CELL", phase.get_cell())
        print("OPTION", stage, phase.name, "HAP", {
            k: phase.getHAPvalues(hist).get(k)
            for k in ("Scale", "Size", "Mustrain", "Pref.Ori.")
        })
        print("OPTION", stage, phase.name, "ATOMS", [
            (a.label, a.element, a.uiso, a.refinement_flags) for a in phase.atoms()
        ])


if os.path.exists(TARGET):
    os.unlink(TARGET)
project = G2sc.G2Project(SOURCE, newgpx=TARGET)
hist = project.histogram(0)
wo3, mno2 = project.phases()
project.set_Controls("cycles", 15)
project.data["Controls"]["data"]["min dM/M"] = 1.0e-6

# Keep the useful refined broadening values, but remove the singular size flags.
for phase in project.phases():
    phase.clear_HAP_refinements({"Size": True}, [hist])
# SH/L and specimen displacement are nearly collinear; hold SH/L at its refined value.
hist.clear_refinements({"Instrument Parameters": ["SH/L"]})

# Replace nonphysical zero ADPs in the archival WO3 CIF and refine one Uiso per
# element. MnO2 has one crystallographic site per element.
for phase in project.phases():
    for atom in phase.atoms():
        atom.uiso = 0.006 if atom.element in ("W", "Mn") else 0.009
        atom.refinement_flags = "U"

project.save()
w_indices = [i for i, atom in enumerate(wo3.atoms()) if atom.element == "W"]
o_indices = [i for i, atom in enumerate(wo3.atoms()) if atom.element == "O"]
project.add_EquivConstr([f"0::AUiso:{i}" for i in w_indices], reloadIdx=False)
project.add_EquivConstr([f"0::AUiso:{i}" for i in o_indices], reloadIdx=False)
for p_id in (0, 1):
    project.set_Controls("parmMin", 0.0001, f"{p_id}::AUiso:*")
    project.set_Controls("parmMax", 0.05, f"{p_id}::AUiso:*")

project.refine()
summary(project, "adp")

# Test the expected fiber texture of rutile-type MnO2 with the c axis as the
# March-Dollase direction. This directly tests the anomalously strong 110 line.
mno2.set_HAP_refinements({"Pref.Ori.": True}, [hist])
project.refine()
summary(project, "adp_md")
project.save()
