#!/usr/bin/env python3
"""Build, refine, and export the final two-phase GSAS-II model."""

import csv
import json
import math
import os

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
WORK = os.path.dirname(__file__)
PATTERN = os.path.join(ROOT, "inputs", "pattern.csv")
XYE = os.path.join(WORK, "final_pattern.xye")
INST = os.path.join(WORK, "final_cu_ka.instprm")
WORK_GPX = os.path.join(WORK, "final_work.gpx")
FINAL_GPX = os.path.join(ROOT, "final.gpx")
FIT_CSV = os.path.join(ROOT, "fit.csv")
RESULT_JSON = os.path.join(ROOT, "result.json")
CIF_WO3 = os.path.join(ROOT, "phase_1_WO3_triclinic.cif")
CIF_MNO2 = os.path.join(ROOT, "phase_2_MnO2_beta.cif")

COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"
WO3_SOURCE = os.path.join(COD, "2", "10", "62", "2106293.cif")
MNO2_SOURCE = os.path.join(COD, "1", "51", "41", "1514110.cif")


def prepare_inputs():
    x_values = []
    with open(PATTERN, newline="") as src, open(XYE, "w") as dst:
        reader = csv.DictReader(src)
        dst.write("# two_theta_deg intensity sigma_Poisson\n")
        for row in reader:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            x_values.append(x)
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")

    with open(INST, "w") as dst:
        dst.write("#GSAS-II instrument parameter file for lab CuKa data\n")
        dst.write("Type:PXC;Bank:1\n")
        dst.write(
            "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.5;"
            "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        )
        # U, V and W are held at non-negative values. X and Y are refined.
        dst.write(
            "U:0.0;V:0.0;W:5.0;X:9.0;Y:5.0;Z:0.0;SH/L:0.02713720465724668\n"
        )
    return min(x_values), max(x_values)


def set_cell(phase, values):
    phase.data["General"]["Cell"][1:8] = list(values)


for path in (WORK_GPX, FINAL_GPX, FIT_CSV, RESULT_JSON, CIF_WO3, CIF_MNO2):
    if os.path.exists(path):
        os.unlink(path)

x_min, x_max = prepare_inputs()
project = G2sc.G2Project(newgpx=WORK_GPX, author="OpenAI Codex")
hist = project.add_powder_histogram(XYE, INST, fmthint="xye")
wo3 = project.add_phase(
    WO3_SOURCE,
    phasename="triclinic_WO3",
    histograms=[hist],
    fmthint="CIF",
)
mno2 = project.add_phase(
    MNO2_SOURCE,
    phasename="beta_MnO2_pyrolusite",
    histograms=[hist],
    fmthint="CIF",
)

project.set_Controls("cycles", 20)
project.data["Controls"]["data"]["min dM/M"] = 1.0e-6

# Starting values come from the preceding database-model comparison. Atomic
# coordinates and occupancies remain fixed at the cited COD values.
set_cell(
    wo3,
    (
        7.306820730994459,
        7.536364380834312,
        7.69316174097008,
        89.89431546386054,
        90.76944964659401,
        89.98140077494766,
        423.59934003361667,
    ),
)
set_cell(
    mno2,
    (
        4.398729317585904,
        4.398729317585904,
        2.8739953323888647,
        90.0,
        90.0,
        90.0,
        55.60841724462028,
    ),
)

background = [
    1024.1669091163785,
    -544.600585971002,
    390.69354252242255,
    -253.1961686028759,
    142.4519127206369,
    -76.42231214370904,
    37.12180109178606,
    -26.840210671702025,
    19.823646260468678,
    -6.615194721871547,
    -6.344202075868987,
    -10.066583697690238,
]
hist.set_refinements(
    {
        "Limits": [x_min, x_max],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": len(background),
            "coeffs": background,
        },
        "Instrument Parameters": ["X", "Y"],
    }
)
hist.SampleParameters["Scale"] = [1.0, False]
hist.SampleParameters["Shift"] = [-591.56, True]

wo3.HAPvalue("Scale", 19.07, targethistlist=[hist])
mno2.HAPvalue("Scale", 84.73, targethistlist=[hist])
project.set_refinement({"set": {"Cell": True, "PhaseFraction": True}})

# WO3 peaks are measurably broader than the MnO2 peaks. The fitted isotropic
# coherent-domain term is used for WO3; MnO2 is effectively instrument-limited.
wo3.set_HAP_refinements(
    {"Size": {"type": "isotropic", "refine": True, "value": 0.12025}},
    [hist],
)
mno2.setSampleProfile(hist.name, "size", "isotropic", 10.0)
mno2.getHAPvalues(hist)["Pref.Ori."][1] = 1.0978
mno2.set_HAP_refinements({"Pref.Ori.": True}, [hist])

# Two passes ensure both the chi-square and shift/esd convergence tests settle.
project.refine()
project.refine()

rvals = project.data["Covariance"]["data"]["Rvals"]
if not rvals.get("converged", False):
    raise RuntimeError(f"Final refinement did not converge: {rvals}")

# Set conventional formula-unit counts before CIF export. The GSAS-II quick
# exporter otherwise infers only the common divisor of site multiplicities.
wo3.data["General"]["cellZ"] = 8
mno2.data["General"]["cellZ"] = 2

# Save the exact project from which all submitted products are exported.
project.save(FINAL_GPX)
mass_fracs = hist.ComputeMassFracs()

wo3.export_CIF(CIF_WO3)
mno2.export_CIF(CIF_MNO2)

data = hist.data["data"][1]
x, y_obs, weights, y_calc, y_bkg, stored_diff = data
with open(FIT_CSV, "w", newline="") as fp:
    writer = csv.writer(fp)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "background_intensity",
            "difference_observed_minus_calculated",
        ]
    )
    for vals in zip(x, y_obs, y_calc, y_bkg):
        xx, obs, calc, bkg = (float(v) for v in vals)
        writer.writerow(
            [f"{xx:.8f}", f"{obs:.6f}", f"{calc:.6f}", f"{bkg:.6f}", f"{obs-calc:.6f}"]
        )


def phase_record(phase, display_name, formula, cif_name, cod_id):
    cell, cell_esd = phase.get_cell_and_esd()
    fraction, fraction_esd = mass_fracs[phase.name]
    p_id = phase.id
    return {
        "name": display_name,
        "formula": formula,
        "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
        "source_structure": f"COD {cod_id}",
        "cif_path": cif_name,
        "weight_fraction": float(fraction),
        "weight_fraction_esd_formal": float(fraction_esd),
        "unit_cell": {key: float(value) for key, value in cell.items()},
        "unit_cell_esd": {key: float(value) for key, value in cell_esd.items()},
        "phase_fit_statistics": {
            "Rf_percent": float(hist.residuals.get(f"{p_id}:0:Rf", float("nan"))),
            "Rf_squared_percent": float(
                hist.residuals.get(f"{p_id}:0:Rf^2", float("nan"))
            ),
        },
    }


fit_stats = {
    "Rwp_percent": float(hist.residuals["wR"]),
    "Rp_percent": float(hist.residuals["R"]),
    "Rexp_percent": float(hist.residuals["wRmin"]),
    "goodness_of_fit": float(rvals["GOF"]),
    "chi_square": float(rvals["chisq"]),
    "reduced_chi_square": float(rvals["GOF"] ** 2),
    "n_observations": int(rvals["Nobs"]),
    "n_refined_variables": int(rvals["Nvars"]),
    "converged": bool(rvals["converged"]),
    "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
}

result = {
    "number_of_modeled_crystalline_phases": 2,
    "fraction_basis": "normalized over the modeled crystalline phases",
    "phases": [
        phase_record(
            wo3,
            "triclinic tungsten(VI) oxide",
            "WO3",
            os.path.basename(CIF_WO3),
            "2106293",
        ),
        phase_record(
            mno2,
            "beta-manganese(IV) oxide (pyrolusite)",
            "MnO2",
            os.path.basename(CIF_MNO2),
            "1514110",
        ),
    ],
    "fit_statistics": fit_stats,
    "profile_path": os.path.basename(FIT_CSV),
    "gsasii_project_path": os.path.basename(FINAL_GPX),
    "weighting": "Poisson counting uncertainties assumed as sigma=sqrt(intensity); none were supplied",
}
with open(RESULT_JSON, "w") as fp:
    json.dump(result, fp, indent=2)
    fp.write("\n")

print(json.dumps(result, indent=2))
