#!/usr/bin/env python3
"""Test MnO2 March-Dollase correction from the clean two-phase fit."""

import os
from GSASII import GSASIIscriptable as G2sc

base = os.path.dirname(__file__)
source = os.path.join(base, "candidate_2106293.gpx")
target = os.path.join(base, "md_clean_2106293.gpx")
if os.path.exists(target):
    os.unlink(target)
project = G2sc.G2Project(source, newgpx=target)
hist = project.histogram(0)
wo3, mno2 = project.phases()
project.set_Controls("cycles", 20)
project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
for phase in project.phases():
    phase.clear_HAP_refinements({"Size": True}, [hist])
hist.clear_refinements({"Instrument Parameters": ["SH/L"]})
mno2.set_HAP_refinements({"Pref.Ori.": True}, [hist])
project.refine()
print("MD CLEAN RESIDUALS", hist.residuals)
print("MD CLEAN MASS", hist.ComputeMassFracs())
print("MD CLEAN PO", mno2.getHAPvalues(hist)["Pref.Ori."])
print("MD CLEAN PROFILE", {k: hist.InstrumentParameters[k] for k in ("U", "V", "W", "X", "Y", "SH/L")})
print("MD CLEAN SHIFT", hist.SampleParameters["Shift"])
for phase in project.phases():
    print("MD CLEAN CELL", phase.name, phase.get_cell())
project.save()
