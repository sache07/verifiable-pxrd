#!/usr/bin/env python3
"""Replace a correlated Caglioti fit with a stable positive profile model."""

import os
from GSASII import GSASIIscriptable as G2sc

base = os.path.dirname(__file__)
source = os.path.join(base, "md_clean_2106293.gpx")
target = os.path.join(base, "stable_2106293.gpx")
if os.path.exists(target):
    os.unlink(target)
project = G2sc.G2Project(source, newgpx=target)
hist = project.histogram(0)
wo3, mno2 = project.phases()
project.set_Controls("cycles", 20)
project.data["Controls"]["data"]["min dM/M"] = 1.0e-6

inst = hist.InstrumentParameters
for key, val in {"U": 0.0, "V": 0.0, "W": 5.0, "X": 9.0, "Y": 5.0}.items():
    inst[key][0] = val
    inst[key][1] = val
hist.clear_refinements({"Instrument Parameters": ["U", "V", "W", "SH/L"]})
hist.set_refinements({"Instrument Parameters": ["X", "Y"]})

for phase in project.phases():
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
wo3.set_HAP_refinements({
    "Size": {"type": "isotropic", "refine": True, "value": 0.40}
}, [hist])
mno2.setSampleProfile(hist.name, "size", "isotropic", 10.0)

project.refine()
print("STABLE RESIDUALS", hist.residuals)
print("STABLE MASS", hist.ComputeMassFracs())
print("STABLE PROFILE", {k: inst[k] for k in ("U", "V", "W", "X", "Y", "SH/L")})
print("STABLE PO", mno2.getHAPvalues(hist)["Pref.Ori."])
print("STABLE SIZE WO3", wo3.getHAPvalues(hist)["Size"])
print("STABLE SIZE MNO2", mno2.getHAPvalues(hist)["Size"])
print("STABLE RVALS", project.data["Covariance"]["data"]["Rvals"])
project.save()
