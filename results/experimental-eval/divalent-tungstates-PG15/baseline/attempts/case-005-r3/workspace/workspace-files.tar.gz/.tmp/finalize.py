from pathlib import Path
import json
import math

import numpy as np
import GSASII.GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "broad_m2311041_full_no_w.gpx"

gpx = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(ROOT / "final.gpx"))
hist = gpx.histogram(0)
hist.Limits("lower", hist.data["Limits"][0][0])
hist.Limits("upper", hist.data["Limits"][0][1])
gpx.set_Controls("cycles", 12)
gpx.do_refinements([{}, {}])
# Both retained cells contain eight reduced formula units. Recording this
# explicitly prevents the CIF writer from inferring Z only from site
# multiplicities in the nonstandard WO3 setting.
for phase in gpx.phases():
    phase.data["General"]["cellZ"] = 8
gpx.save()

cif_names = ["phase_1_WO3.cif", "phase_2_Co3O4.cif"]
for phase, cif_name in zip(gpx.phases(), cif_names):
    phase.export_CIF(str(ROOT / cif_name))

x = np.asarray(hist.getdata("X"), dtype=float)
y_obs = np.asarray(hist.getdata("Yobs"), dtype=float)
y_calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
background = np.asarray(hist.getdata("Background"), dtype=float)
residual = np.asarray(hist.getdata("Residual"), dtype=float)
np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x, y_obs, y_calc, background, residual)),
    delimiter=",",
    header="two_theta_deg,observed_intensity,calculated_intensity,background_intensity,observed_minus_calculated",
    comments="",
    fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
)

mass_fracs = hist.ComputeMassFracs()
rvals = gpx.data["Covariance"]["data"]["Rvals"]
wo3_cell = gpx.phase(0).data["General"]["Cell"][1:8]
a, b, c, alpha, beta, gamma, volume = wo3_cell
beta_rad = math.radians(beta)
short_a = math.sqrt(a * a + c * c + 2.0 * a * c * math.cos(beta_rad))
conv_beta = math.degrees(math.acos(-(a + c * math.cos(beta_rad)) / short_a))

summary = {
    "mass_fractions": mass_fracs,
    "residuals": hist.residuals,
    "Rvals": rvals,
    "sample_shift_um": hist.SampleParameters["Shift"][0],
    "instrument": {key: hist.InstrumentParameters[key][1] for key in ("W", "Polariz.", "SH/L")},
    "phases": [],
    "wo3_equivalent_conventional_cell": {
        "a_angstrom": short_a,
        "b_angstrom": b,
        "c_angstrom": a,
        "alpha_deg": 90.0,
        "beta_deg": conv_beta,
        "gamma_deg": 90.0,
        "volume_angstrom3": volume,
    },
}
for phase, cif_name in zip(gpx.phases(), cif_names):
    hap = phase.getHAPvalues(hist)
    summary["phases"].append(
        {
            "name": phase.name,
            "cif": cif_name,
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cell": phase.data["General"]["Cell"][1:8],
            "scale": hap["Scale"][0],
            "size_micrometre": hap["Size"][1][0],
            "mass_fraction": mass_fracs[phase.name],
            "bragg_R_F_percent": hist.residuals.get(f"{phase.id}:0:Rf"),
            "bragg_R_F2_percent": hist.residuals.get(f"{phase.id}:0:Rf^2"),
        }
    )
(ROOT / ".tmp" / "final_summary.json").write_text(json.dumps(summary, indent=2, default=float) + "\n")
print(json.dumps(summary, indent=2, default=float))
