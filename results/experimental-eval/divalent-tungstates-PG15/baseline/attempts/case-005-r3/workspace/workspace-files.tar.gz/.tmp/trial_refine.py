from pathlib import Path
import sys

import numpy as np
import GSASII.GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
WO3_CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif")
CO3O4_CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/58/9005896.cif")


def show(gpx, label):
    hist = gpx.histogram(0)
    print("\n=====", label, "=====")
    print("residuals", hist.residuals)
    print("sample", {k: hist.SampleParameters[k] for k in ("Scale", "Shift", "Gonio. radius")})
    print("instrument", {k: hist.InstrumentParameters[k] for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)")})
    print("background", hist.data["Background"][0])
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        print(phase.name, "cell", phase.data["General"]["Cell"], "scale", hap["Scale"], "size", hap["Size"], "mustrain", hap["Mustrain"])
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fractions unavailable", repr(exc))


gpx = G2sc.G2Project(newgpx=str(ROOT / ".tmp" / "trial.gpx"))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / ".tmp" / "instrument.instprm"),
    fmthint="comma",
)
wo3 = gpx.add_phase(str(WO3_CIF), phasename="WO3_monoclinic", histograms=[hist], fmthint="CIF")
co3o4 = gpx.add_phase(str(CO3O4_CIF), phasename="Co3O4_spinel", histograms=[hist], fmthint="CIF")

hist.Limits("lower", 10.0)
hist.Limits("upper", 100.0)
hist.SampleParameters["Scale"] = [1.0, False]
hist.SampleParameters["Shift"] = [-670.0, False]
hist.data["Background"][0] = ["chebyschev-1", False, 15, 3000.0] + [0.0] * 14
inst = hist.InstrumentParameters
for key, value in {"U": 2.0, "V": -2.0, "W": 20.0, "X": 2.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002}.items():
    inst[key][0] = inst[key][1] = value
wo3.data["Histograms"][hist.name]["Scale"] = [12.0, False]
co3o4.data["Histograms"][hist.name]["Scale"] = [6.0, False]

gpx.set_Controls("cycles", 8)
gpx.save()

steps = [
    ("background + scales", {"set": {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 15}, "Scale": True}}),
    ("shift + cells", {"set": {"Sample Parameters": ["Shift"], "Cell": True}}),
    ("W profile", {"set": {"Instrument Parameters": ["W"]}}),
    ("X profile", {"set": {"Instrument Parameters": ["X"]}}),
    ("U V Y profile", {"set": {"Instrument Parameters": ["U", "V", "Y"]}}),
    ("phase size", {"set": {"Size": {"type": "isotropic", "value": 1000.0, "refine": True}}}),
    ("phase microstrain", {"set": {"Mustrain": {"type": "isotropic", "refine": True}}}),
]

for label, refs in steps:
    try:
        gpx.do_refinements([refs])
        show(gpx, label)
    except Exception as exc:
        print("FAILED AT", label, repr(exc))
        show(gpx, "after failure")
        raise

gpx.save()
