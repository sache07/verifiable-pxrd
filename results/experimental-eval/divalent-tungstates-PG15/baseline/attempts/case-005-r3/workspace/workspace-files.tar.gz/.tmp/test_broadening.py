from pathlib import Path
import argparse
import json

import GSASII.GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("key")
parser.add_argument("mode", choices=("size", "size_mix", "size_strain", "shl", "polariz", "atoms", "heavy_atoms", "full", "full_no_w", "uiso"))
args = parser.parse_args()

source = ROOT / ".tmp" / (f"broad_{args.key}_full.gpx" if args.mode == "uiso" else f"compare_{args.key}.gpx")
dest = ROOT / ".tmp" / f"broad_{args.key}_{args.mode}.gpx"
gpx = G2sc.G2Project(gpxfile=str(source), newgpx=str(dest))
hist = gpx.histogram(0)
gpx.set_Controls("cycles", 12)

if args.mode.startswith("size"):
    hist.InstrumentParameters["X"] = [0.0, 0.0, False]
    for phase in gpx.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.09, "refine": True}})
    gpx.do_refinements([{}])
    if args.mode == "size_mix":
        for phase in gpx.phases():
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "LGmix": {"value": 1.0, "refine": True}}})
        gpx.do_refinements([{}])
    elif args.mode == "size_strain":
        for phase in gpx.phases():
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        gpx.do_refinements([{}])
elif args.mode == "shl":
    gpx.do_refinements([{"set": {"Instrument Parameters": ["SH/L"]}}])
elif args.mode == "polariz":
    gpx.do_refinements([{"set": {"Instrument Parameters": ["Polariz."]}}])
elif args.mode == "atoms":
    gpx.do_refinements([{"set": {"Atoms": {"all": "X"}}}])
elif args.mode == "heavy_atoms":
    wo3, co3o4 = gpx.phases()
    wo3.set_refinements({"Atoms": {a.label: "X" for a in wo3.atoms() if a.element == "W"}})
    co3o4.set_refinements({"Atoms": {a.label: "X" for a in co3o4.atoms() if a.element == "O"}})
    gpx.do_refinements([{}])
elif args.mode == "full":
    hist.InstrumentParameters["X"] = [0.0, 0.0, False]
    for phase in gpx.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.09, "refine": True}})
    gpx.do_refinements([{}])
    gpx.do_refinements([{"set": {"Instrument Parameters": ["Polariz."]}}])
    wo3, co3o4 = gpx.phases()
    wo3.set_refinements({"Atoms": {a.label: "X" for a in wo3.atoms() if a.element == "W"}})
    co3o4.set_refinements({"Atoms": {a.label: "X" for a in co3o4.atoms() if a.element == "O"}})
    gpx.do_refinements([{}])
elif args.mode == "full_no_w":
    hist.InstrumentParameters["X"] = [0.0, 0.0, False]
    for phase in gpx.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.09, "refine": True}})
    gpx.do_refinements([{}])
    gpx.do_refinements([{"set": {"Instrument Parameters": ["Polariz."]}}])
    co3o4 = gpx.phases()[1]
    co3o4.set_refinements({"Atoms": {a.label: "X" for a in co3o4.atoms() if a.element == "O"}})
    gpx.do_refinements([{}])
elif args.mode == "uiso":
    wo3, co3o4 = gpx.phases()
    for phase in (wo3, co3o4):
        for atom in phase.atoms():
            atom.uiso = 0.005 if atom.element in ("W", "Co") else 0.008
            atom.refinement_flags = "".join(sorted(set(atom.refinement_flags.strip() + "U")))
    gpx.save()
    for element in ("W", "O"):
        indices = [i for i, atom in enumerate(wo3.atoms()) if atom.element == element]
        if len(indices) > 1:
            gpx.add_EquivConstr([f"0::AUiso:{i}" for i in indices])
    gpx.do_refinements([{}])

gpx.do_refinements([{}])
gpx.save()
result = {
    "key": args.key,
    "mode": args.mode,
    "residuals": hist.residuals,
    "mass_fractions": hist.ComputeMassFracs(),
    "instrument": {k: hist.InstrumentParameters[k] for k in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")},
    "phases": {
        p.name: {
            "cell": p.data["General"]["Cell"],
            "scale": p.getHAPvalues(hist)["Scale"],
            "size": p.getHAPvalues(hist)["Size"],
            "mustrain": p.getHAPvalues(hist)["Mustrain"],
            "atoms": [(a.label, a.coordinates, a.uiso, a.refinement_flags) for a in p.atoms()],
        }
        for p in gpx.phases()
    },
}
(ROOT / ".tmp" / f"broad_{args.key}_{args.mode}.json").write_text(json.dumps(result, indent=2, default=float) + "\n")
print(json.dumps(result, indent=2, default=float))
