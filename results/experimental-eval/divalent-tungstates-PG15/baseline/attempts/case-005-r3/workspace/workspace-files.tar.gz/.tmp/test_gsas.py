from pathlib import Path
import json

import GSASII.GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
WO3_CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif")
CO3O4_CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/58/9005896.cif")

gpx = G2sc.G2Project(newgpx=str(ROOT / ".tmp" / "initial.gpx"))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / ".tmp" / "instrument.instprm"),
    fmthint="comma",
)
wo3 = gpx.add_phase(str(WO3_CIF), phasename="WO3_monoclinic", histograms=[hist], fmthint="CIF")
co3o4 = gpx.add_phase(str(CO3O4_CIF), phasename="Co3O4_spinel", histograms=[hist], fmthint="CIF")

print("hist", hist.name)
print("sample", hist.SampleParameters)
print("instrument", hist.InstrumentParameters)
print("background", hist.data["Background"])
for ph in gpx.phases():
    print("phase", ph.name)
    print("composition", ph.composition)
    print("general cell", ph.data["General"]["Cell"])
    print("space group", ph.data["General"]["SGData"]["SpGrp"])
    print("mass", ph.data["General"]["Mass"])
    print("atoms", [(a.label, a.element, a.coordinates, a.uiso) for a in ph.atoms()])
    print("HAP", ph.getHAPvalues(hist))
gpx.save()
