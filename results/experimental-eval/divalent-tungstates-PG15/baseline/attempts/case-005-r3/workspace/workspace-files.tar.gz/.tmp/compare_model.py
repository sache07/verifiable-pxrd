from pathlib import Path
import argparse
import json

import GSASII.GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
CO3O4_CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/58/9005896.cif")
MODELS = {
    "m1528915": Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif"),
    "m2311041": Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif"),
    "tri2106293": Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/10/62/2106293.cif"),
    "ortho2107312": Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/10/73/2107312.cif"),
    "half1010618": Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/06/1010618.cif"),
    "m1563541": Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/56/35/1563541.cif"),
}


def summarize(gpx, key):
    hist = gpx.histogram(0)
    phases = gpx.phases()
    return {
        "key": key,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "shift_um": hist.SampleParameters["Shift"][0],
        "instrument": {k: hist.InstrumentParameters[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L")},
        "phases": {
            p.name: {
                "cell": p.data["General"]["Cell"][1:],
                "space_group": p.data["General"]["SGData"]["SpGrp"],
                "scale": p.getHAPvalues(hist)["Scale"][0],
            }
            for p in phases
        },
    }


parser = argparse.ArgumentParser()
parser.add_argument("key", choices=MODELS)
args = parser.parse_args()
key = args.key
outbase = ROOT / ".tmp" / f"compare_{key}"

gpx = G2sc.G2Project(newgpx=str(outbase.with_suffix(".gpx")))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / ".tmp" / "instrument.instprm"),
    fmthint="comma",
)
wo3 = gpx.add_phase(str(MODELS[key]), phasename="WO3", histograms=[hist], fmthint="CIF")
co3o4 = gpx.add_phase(str(CO3O4_CIF), phasename="Co3O4", histograms=[hist], fmthint="CIF")

hist.Limits("lower", 10.0)
hist.Limits("upper", 100.0)
hist.SampleParameters["Scale"] = [1.0, False]
hist.SampleParameters["Shift"] = [-670.0, False]
hist.data["Background"][0] = ["chebyschev-1", False, 15, 3000.0] + [0.0] * 14
for name, value in {"U": 2.0, "V": -2.0, "W": 20.0, "X": 2.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002}.items():
    hist.InstrumentParameters[name][0] = hist.InstrumentParameters[name][1] = value
wo3.data["Histograms"][hist.name]["Scale"] = [12.0, False]
co3o4.data["Histograms"][hist.name]["Scale"] = [6.0, False]
gpx.set_Controls("cycles", 10)
gpx.save()

steps = [
    {"set": {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 15}, "Scale": True}},
    {"set": {"Sample Parameters": ["Shift"], "Cell": True}},
    {"set": {"Instrument Parameters": ["W"]}},
    {"set": {"Instrument Parameters": ["X"]}},
    {},
]
gpx.do_refinements(steps)
gpx.save()
result = summarize(gpx, key)
outbase.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
print(json.dumps(result, indent=2, default=float))
