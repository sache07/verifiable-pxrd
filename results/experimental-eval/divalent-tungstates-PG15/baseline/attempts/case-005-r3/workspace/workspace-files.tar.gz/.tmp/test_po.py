from pathlib import Path
import argparse
import json

import GSASII.GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("h", type=int)
parser.add_argument("k", type=int)
parser.add_argument("l", type=int)
args = parser.parse_args()
axis = [args.h, args.k, args.l]
tag = "".join("m" + str(-v) if v < 0 else str(v) for v in axis)
gpx = G2sc.G2Project(
    gpxfile=str(ROOT / ".tmp" / "broad_m2311041_full_no_w.gpx"),
    newgpx=str(ROOT / ".tmp" / f"po_{tag}.gpx"),
)
hist = gpx.histogram(0)
wo3 = gpx.phase(0)
po = wo3.data["Histograms"][hist.name]["Pref.Ori."]
po[0], po[1], po[2], po[3] = "MD", 1.0, True, axis
gpx.set_Controls("cycles", 12)
gpx.do_refinements([{}])
gpx.do_refinements([{}])
gpx.save()
out = {
    "axis": axis,
    "MD": po[1],
    "residuals": hist.residuals,
    "mass_fractions": hist.ComputeMassFracs(),
}
(ROOT / ".tmp" / f"po_{tag}.json").write_text(json.dumps(out, indent=2, default=float) + "\n")
print(json.dumps(out, indent=2, default=float))
