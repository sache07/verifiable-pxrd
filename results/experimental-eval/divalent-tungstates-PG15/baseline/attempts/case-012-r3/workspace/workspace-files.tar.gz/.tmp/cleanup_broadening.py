from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / '.tmp'


def clean(source, target, mode):
    gpx = G2sc.G2Project(str(TMP / f'{source}.gpx'), newgpx=str(TMP / f'{target}.gpx'))
    hist = gpx.histogram(0)
    for ph in gpx.phases():
        ph.setSampleProfile(hist, 'size', 'isotropic', 10.0)
        ph.clear_HAP_refinements({'Size': True}, [hist])
        if mode == 'none':
            ph.setSampleProfile(hist, 'microstrain', 'isotropic', 0.0)
            ph.clear_HAP_refinements({'Mustrain': True}, [hist])
        elif mode == 'strain':
            ph.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}}, [hist])
    gpx.data['Controls']['data']['max cyc'] = 12
    gpx.data['Controls']['data']['min dM/M'] = 0.00005
    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()
    out = {
        'source': source,
        'target': target,
        'mode': mode,
        'residuals': {k: v for k, v in hist.residuals.items() if k in ('wR','R','wRb','Rb','wRmin')},
        'mass_fractions': {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        'profile': {k: hist.InstrumentParameters[k][1] for k in ('U','V','W','X','Y','Zero')},
        'shift': hist.SampleParameters['Shift'][0],
        'broadening': {ph.name: {'size': ph.data['Histograms'][hist.name]['Size'][1][0],
                                  'strain': ph.data['Histograms'][hist.name]['Mustrain'][1][0]}
                       for ph in gpx.phases()},
        'cells': {ph.name: ph.get_cell() for ph in gpx.phases()},
    }
    print('CLEAN_RESULT ' + json.dumps(out, sort_keys=True), flush=True)


if __name__ == '__main__':
    specs = {
        'mono_zero_strain': ('mono_zero', 'strain'),
        'mono_zero_none': ('mono_zero', 'none'),
        'mono_shift_strain': ('mono_shift', 'strain'),
        'mono_shift_none': ('mono_shift', 'none'),
        'triclinic_zero_strain': ('triclinic_zero', 'strain'),
        'triclinic_zero_none': ('triclinic_zero', 'none'),
        'loopstra_zero_strain': ('loopstra_zero', 'strain'),
        'loopstra_zero_none': ('loopstra_zero', 'none'),
        'loopstra_shift_strain': ('loopstra_shift', 'strain'),
        'loopstra_shift_none': ('loopstra_shift', 'none'),
    }
    for target in (sys.argv[1:] or specs):
        source, mode = specs[target]
        clean(source, target, mode)
