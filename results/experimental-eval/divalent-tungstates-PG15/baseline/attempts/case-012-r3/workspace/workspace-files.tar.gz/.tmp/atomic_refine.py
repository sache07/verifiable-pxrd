from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / '.tmp'


def run(target, mode):
    source = 'loopstra_zero_none'
    gpx = G2sc.G2Project(str(TMP / f'{source}.gpx'), newgpx=str(TMP / f'{target}.gpx'))
    hist = gpx.histogram(0)
    ni = gpx.phase('NiWO4')
    wo = gpx.phase('WO3')
    if mode in ('niheavy', 'niall', 'allheavy', 'all'):
        ni.set_refinements({'Atoms': {'Ni1': 'X', 'W1': 'X'}})
    if mode in ('niall', 'all'):
        ni.set_refinements({'Atoms': {'O1': 'X', 'O2': 'X'}})
    if mode in ('allheavy', 'all'):
        wo.set_refinements({'Atoms': {'W1': 'X', 'W2': 'X'}})
    if mode == 'all':
        wo.set_refinements({'Atoms': {'all': 'X'}})
    gpx.data['Controls']['data']['max cyc'] = 15
    gpx.data['Controls']['data']['min dM/M'] = 0.00002
    gpx.save()
    gpx.do_refinements([{}])
    gpx.save()
    cov = gpx.data['Covariance']['data']
    atom_sig = {name: sig for name, sig in zip(cov['varyList'], cov['sig']) if ':A' in name}
    out = {
        'target': target,
        'mode': mode,
        'residuals': {k: v for k, v in hist.residuals.items() if k in ('wR','R','wRb','Rb','wRmin')},
        'mass_fractions': {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        'cells': {ph.name: ph.get_cell() for ph in gpx.phases()},
        'atoms': {ph.name: {a.label: {'xyz': list(a.coordinates), 'flags': a.refinement_flags}
                             for a in ph.atoms()} for ph in gpx.phases()},
        'atom_sigmas': atom_sig,
        'nvars': len(cov['varyList']),
    }
    print('ATOM_RESULT ' + json.dumps(out, sort_keys=True), flush=True)


if __name__ == '__main__':
    specs = {
        'loopstra_atom_niheavy': 'niheavy',
        'loopstra_atom_niall': 'niall',
        'loopstra_atom_allheavy': 'allheavy',
        'loopstra_atom_all': 'all',
    }
    for target in (sys.argv[1:] or specs):
        run(target, specs[target])
