from pathlib import Path
import csv
import json
import math
import sys

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / '.tmp'
TRICLINIC_CIF = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/10/62/2106293.cif')
LOOPSTRA_CIF = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif')
BRAEKKEN_CIF = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/06/1010618.cif')


def make_xye():
    out = TMP / 'pattern.xye'
    if out.exists():
        return out
    with (ROOT / 'inputs' / 'pattern.csv').open(newline='') as src, out.open('w') as dst:
        for row in csv.DictReader(src):
            x = float(row['two_theta_deg'])
            y = float(row['intensity'])
            dst.write(f'{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n')
    return out


def set_flags(hist, phases, zero_mode, sample_broadening):
    # There is one redundant overall scale for a multiphase histogram. Hold
    # the histogram scale and refine only phase scales to avoid singularity.
    hist.SampleParameters['Scale'][0] = 1.0
    hist.SampleParameters['Scale'][1] = False
    hist.SampleParameters['Shift'][0] = 0.0
    hist.SampleParameters['Shift'][1] = (zero_mode == 'shift')
    hist.InstrumentParameters['Zero'][1] = 0.0
    hist.InstrumentParameters['Zero'][2] = (zero_mode == 'zero')
    if sample_broadening:
        for ph in phases:
            ph.set_HAP_refinements({
                'Size': {'type': 'isotropic', 'value': 1.0, 'refine': True},
                'Mustrain': {'type': 'isotropic', 'refine': True},
            }, [hist])


def run_model(name, wo3_cif, zero_mode='zero', atoms='none', sample_broadening=True):
    target = TMP / f'{name}.gpx'
    gpx = G2sc.G2Project(newgpx=str(target))
    hist = gpx.add_powder_histogram(str(make_xye()), str(TMP / 'cu_kalpha.instprm'), fmthint='xye')
    ni = gpx.add_phase(str(TMP / 'niwo4_start.cif'), phasename='NiWO4', histograms=[hist], fmthint='CIF')
    wo = gpx.add_phase(str(wo3_cif), phasename='WO3', histograms=[hist], fmthint='CIF')
    phases = [ni, wo]
    hist.Limits('lower', 10.05)
    hist.Limits('upper', 99.90)
    ni.HAPvalue('Scale', 1.0)
    wo.HAPvalue('Scale', 0.25)
    hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12,
                                          'coeffs': [1000.0] + [0.0] * 11,
                                          'refine': True}})
    set_flags(hist, phases, zero_mode, False)
    gpx.data['Controls']['data']['max cyc'] = 8
    gpx.data['Controls']['data']['min dM/M'] = 0.0001
    gpx.save()

    # Staged release reduces correlations and keeps profile terms physical.
    gpx.do_refinements([{'set': {'Scale': True}}])
    gpx.do_refinements([{'set': {'Cell': True}}])
    if zero_mode == 'zero':
        gpx.do_refinements([{'set': {'Instrument Parameters': ['Zero']}}])
    elif zero_mode == 'shift':
        gpx.do_refinements([{'set': {'Sample Parameters': ['Shift']}}])
    gpx.do_refinements([{'set': {'Instrument Parameters': ['U', 'V', 'W']}}])
    gpx.do_refinements([{'set': {'Instrument Parameters': ['X', 'Y']}}])
    if sample_broadening:
        set_flags(hist, phases, zero_mode, True)
        gpx.do_refinements([{}])
    if atoms == 'ni-heavy':
        ni.set_refinements({'Atoms': {'Ni1': 'X', 'W1': 'X'}})
        gpx.do_refinements([{}])
    elif atoms == 'ni-all':
        ni.set_refinements({'Atoms': {'all': 'X'}})
        gpx.do_refinements([{}])
    elif atoms == 'all-heavy':
        ni.set_refinements({'Atoms': {'Ni1': 'X', 'W1': 'X'}})
        wo.set_refinements({'Atoms': {'W1': 'X', 'W2': 'X'}})
        gpx.do_refinements([{}])
    gpx.save()

    mass = hist.ComputeMassFracs()
    out = {
        'name': name,
        'residuals': {k: v for k, v in hist.residuals.items() if k in ('wR','R','wRb','Rb','wRmin')},
        'mass_fractions': {k: list(v) for k, v in mass.items()},
        'zero': hist.InstrumentParameters['Zero'][1],
        'shift': hist.SampleParameters['Shift'][0],
        'profile': {k: hist.InstrumentParameters[k][1] for k in ('U','V','W','X','Y')},
        'cells': {ph.name: ph.get_cell() for ph in phases},
        'scales': {ph.name: ph.HAPvalue('Scale', targethistlist=[hist]) for ph in phases},
        'atoms': {ph.name: {a.label: list(a.coordinates) for a in ph.atoms()} for ph in phases},
    }
    print('MODEL_RESULT ' + json.dumps(out, sort_keys=True), flush=True)
    return out


if __name__ == '__main__':
    specs = {
        'mono_fixed': (TMP / 'wo3_start.cif', 'fixed', 'none', True),
        'mono_zero': (TMP / 'wo3_start.cif', 'zero', 'none', True),
        'mono_shift': (TMP / 'wo3_start.cif', 'shift', 'none', True),
        'triclinic_zero': (TRICLINIC_CIF, 'zero', 'none', True),
        'loopstra_zero': (LOOPSTRA_CIF, 'zero', 'none', True),
        'loopstra_shift': (LOOPSTRA_CIF, 'shift', 'none', True),
        'braekken_zero': (BRAEKKEN_CIF, 'zero', 'none', True),
        'mono_zero_niheavy': (TMP / 'wo3_start.cif', 'zero', 'ni-heavy', True),
        'mono_zero_niall': (TMP / 'wo3_start.cif', 'zero', 'ni-all', True),
        'mono_zero_allheavy': (TMP / 'wo3_start.cif', 'zero', 'all-heavy', True),
    }
    selected = sys.argv[1:] or list(specs)
    results = []
    for name in selected:
        results.append(run_model(name, *specs[name]))
    (TMP / 'model_comparison.json').write_text(json.dumps(results, indent=2) + '\n')
