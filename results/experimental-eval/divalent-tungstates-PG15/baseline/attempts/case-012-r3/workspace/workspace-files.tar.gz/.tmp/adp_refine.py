from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / '.tmp'


def run(target, mode):
    gpx = G2sc.G2Project(str(TMP / 'loopstra_atom_niheavy.gpx'), newgpx=str(TMP / f'{target}.gpx'))
    hist = gpx.histogram(0)
    ni = gpx.phase('NiWO4')
    wo = gpx.phase('WO3')
    for ph in (ni, wo):
        for atom in ph.atoms():
            atom.uiso = 0.01
            atom.refinement_flags = atom.refinement_flags.replace('U', '')
    if mode in ('heavy', 'heavy_tied'):
        for atom in ni.atoms():
            if atom.element in ('Ni', 'W'):
                atom.refinement_flags += 'U'
        for atom in wo.atoms():
            if atom.element == 'W':
                atom.refinement_flags += 'U'
    gpx.data['Controls']['data']['max cyc'] = 15
    gpx.data['Controls']['data']['min dM/M'] = 0.00002
    gpx.save()
    if mode == 'heavy_tied':
        # WO3 W1 and W2 are atom records 2 and 6 in the imported model.
        gpx.add_EquivConstr(('1::AUiso:2', '1::AUiso:6'))
    gpx.do_refinements([{}])
    gpx.save()
    cov = gpx.data['Covariance']['data']
    out = {
        'target': target,
        'mode': mode,
        'residuals': {k: v for k, v in hist.residuals.items() if k in ('wR','R','wRb','Rb','wRmin')},
        'mass_fractions': {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        'uiso': {ph.name: {a.label: a.uiso for a in ph.atoms()} for ph in gpx.phases()},
        'uiso_sigmas': {name: sig for name, sig in zip(cov['varyList'], cov['sig']) if 'AUiso' in name},
        'nvars': len(cov['varyList']),
    }
    print('ADP_RESULT ' + json.dumps(out, sort_keys=True), flush=True)


if __name__ == '__main__':
    specs = {
        'loopstra_uiso_fixed': 'fixed',
        'loopstra_uiso_heavy': 'heavy',
        'loopstra_uiso_heavy_tied': 'heavy_tied',
    }
    for target in (sys.argv[1:] or specs):
        run(target, specs[target])
