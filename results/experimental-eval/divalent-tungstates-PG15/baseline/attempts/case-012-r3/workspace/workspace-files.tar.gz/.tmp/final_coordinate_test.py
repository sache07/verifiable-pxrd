from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / '.tmp'

gpx = G2sc.G2Project(str(TMP / 'loopstra_uiso_heavy_tied.gpx'),
                     newgpx=str(TMP / 'loopstra_uiso_heavy_tied_wxyz.gpx'))
hist = gpx.histogram(0)
wo = gpx.phase('WO3')
for label in ('W1', 'W2'):
    wo.atom(label).refinement_flags = 'XU'
gpx.data['Controls']['data']['max cyc'] = 15
gpx.data['Controls']['data']['min dM/M'] = 0.00002
gpx.save()
gpx.do_refinements([{}])
gpx.save()
cov = gpx.data['Covariance']['data']
out = {
    'residuals': {k: v for k, v in hist.residuals.items() if k in ('wR','R','wRb','Rb','wRmin')},
    'mass_fractions': {k: list(v) for k, v in hist.ComputeMassFracs().items()},
    'cells': {ph.name: ph.get_cell() for ph in gpx.phases()},
    'atoms': {ph.name: {a.label: {'xyz': list(a.coordinates), 'uiso': a.uiso,
                                  'flags': a.refinement_flags}
                         for a in ph.atoms()} for ph in gpx.phases()},
    'coordinate_sigmas': {name: sig for name, sig in zip(cov['varyList'], cov['sig'])
                           if any(t in name for t in ('dAx:', 'dAy:', 'dAz:'))},
    'uiso_sigmas': {name: sig for name, sig in zip(cov['varyList'], cov['sig'])
                    if 'AUiso' in name},
}
print('FINAL_COORD_RESULT ' + json.dumps(out, sort_keys=True))
