from pathlib import Path
import csv
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / '.tmp' / 'loopstra_uiso_heavy_tied.gpx'
FINAL = ROOT / 'final.gpx'

gpx = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
hist = gpx.histogram(0)
x = np.asarray(hist.getdata('x'), dtype=float)
hist.Limits('lower', float(x[0]))
hist.Limits('upper', float(x[-1]))
gpx.data['Controls']['data']['max cyc'] = 15
gpx.data['Controls']['data']['min dM/M'] = 0.00002
gpx.save()
gpx.do_refinements([{}])
gpx.save()

# Export one CIF from this exact final project for each modeled phase.
cif_paths = {}
for phase in gpx.phases():
    out = ROOT / f'phase_{phase.name}.cif'
    phase.export_CIF(str(out), quickmode=True)
    cif_paths[phase.name] = out.name

# Export the profile over the range actually included in the refinement.
x = np.asarray(hist.getdata('x'), dtype=float)
yobs = np.asarray(hist.getdata('yobs'), dtype=float)
ycalc = np.asarray(hist.getdata('ycalc'), dtype=float)
ybkg = np.asarray(hist.getdata('background'), dtype=float)
ydiff = np.asarray(hist.getdata('residual'), dtype=float)
low = hist.Limits('lower')
high = hist.Limits('upper')
used = (x >= low) & (x <= high)
with (ROOT / 'fit.csv').open('w', newline='') as fp:
    writer = csv.writer(fp)
    writer.writerow(['two_theta_deg', 'observed_intensity', 'calculated_intensity',
                     'difference_observed_minus_calculated', 'background_intensity'])
    for row in zip(x[used], yobs[used], ycalc[used], ydiff[used], ybkg[used]):
        writer.writerow([f'{v:.10g}' for v in row])

mass = hist.ComputeMassFracs()
cov = gpx.data['Covariance']['data']
rvals = cov['Rvals']
summary = {
    'project': FINAL.name,
    'profile': 'fit.csv',
    'refinement_range_two_theta_deg': [float(low), float(high)],
    'phases': [],
    'fit_statistics': {
        'Rwp_percent': float(hist.residuals['wR']),
        'Rp_percent': float(hist.residuals['R']),
        'Rwp_background_subtracted_percent': float(hist.residuals['wRb']),
        'Rp_background_subtracted_percent': float(hist.residuals['Rb']),
        'expected_Rwp_percent': float(hist.residuals['wRmin']),
        'goodness_of_fit': float(rvals['GOF']),
        'chi_squared': float(rvals['chisq']),
        'n_observations': int(rvals['Nobs']),
        'n_refined_parameters': int(rvals['Nvars']),
    },
    'instrument': {
        'effective_zero_offset_deg': float(hist.InstrumentParameters['Zero'][1]),
        'wavelength_Kalpha1_angstrom': float(hist.InstrumentParameters['Lam1'][1]),
        'wavelength_Kalpha2_angstrom': float(hist.InstrumentParameters['Lam2'][1]),
        'Kalpha2_to_Kalpha1_ratio': float(hist.InstrumentParameters['I(L2)/I(L1)'][1]),
    },
}
for phase in gpx.phases():
    general = phase.data['General']
    frac, sig = mass[phase.name]
    summary['phases'].append({
        'name': phase.name,
        'formula': general.get('Data plot type', general.get('Name', phase.name)),
        'space_group': general['SGData']['SpGrp'],
        'cif': cif_paths[phase.name],
        'weight_fraction': float(frac),
        'weight_fraction_formal_su': float(sig),
        'cell': phase.get_cell(),
        'Bragg_Rf_percent': float(hist.residuals[f'{phase.id}:0:Rf']),
    })
(ROOT / '.tmp' / 'final_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('FINAL_SUMMARY ' + json.dumps(summary, sort_keys=True))
