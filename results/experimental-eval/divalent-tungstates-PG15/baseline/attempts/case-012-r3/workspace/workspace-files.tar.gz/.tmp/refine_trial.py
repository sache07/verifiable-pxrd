from pathlib import Path
import csv
import json
import math
import numpy as np

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / '.tmp'


def make_xye():
    out = TMP / 'pattern.xye'
    with (ROOT / 'inputs' / 'pattern.csv').open(newline='') as src, out.open('w') as dst:
        rows = csv.DictReader(src)
        for row in rows:
            x = float(row['two_theta_deg'])
            y = float(row['intensity'])
            # Counting-statistics sigma; metadata states that pointwise
            # uncertainties were not supplied.
            dst.write(f'{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n')
    return out


def summary(gpx, label):
    hist = gpx.histogram(0)
    print('\nSUMMARY', label)
    print('residuals', hist.residuals)
    print('instrument', {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ('Zero','U','V','W','X','Y','Z','SH/L','I(L2)/I(L1)','Polariz.')})
    print('background', hist.Background[0])
    print('sample', hist.SampleParameters)
    for ph in gpx.phases():
        hname = hist.name
        print('phase', ph.name)
        print('cell', ph.get_cell())
        print('hap', ph.data['Histograms'][hname])


def main():
    xye = make_xye()
    trial = TMP / 'trial.gpx'
    gpx = G2sc.G2Project(newgpx=str(trial))
    hist = gpx.add_powder_histogram(str(xye), str(TMP / 'cu_kalpha.instprm'), fmthint='xye')
    ni = gpx.add_phase(str(TMP / 'niwo4_start.cif'), phasename='NiWO4', histograms=[hist], fmthint='CIF')
    wo = gpx.add_phase(str(TMP / 'wo3_start.cif'), phasename='WO3', histograms=[hist], fmthint='CIF')
    hist.Limits('lower', 10.05)
    hist.Limits('upper', 99.90)

    # Start both phase scales at plausible positive values.
    ni.HAPvalue('Scale', 1.0)
    wo.HAPvalue('Scale', 0.25)
    # A modest polynomial captures the high fluorescence/air-scatter background.
    hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12,
                                          'coeffs': [1000.0] + [0.0] * 11,
                                          'refine': True}})
    gpx.save()
    summary(gpx, 'initial')

    steps = [
        {'set': {'Scale': True}},
        {'set': {'Cell': True}},
        {'set': {'Instrument Parameters': ['Zero']}},
        {'set': {'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']}},
        {'set': {'Sample Parameters': ['Shift']}},
        {'set': {'Size': {'type': 'isotropic', 'value': 1.0, 'refine': True},
                 'Mustrain': {'type': 'isotropic', 'refine': True}}},
    ]
    for i, step in enumerate(steps, 1):
        try:
            gpx.do_refinements([step])
            summary(gpx, f'step {i}')
        except Exception as exc:
            print('FAILED STEP', i, repr(exc))
            raise
    gpx.save()
    summary(gpx, 'final')


if __name__ == '__main__':
    main()
