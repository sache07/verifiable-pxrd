from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / '.tmp'
NIO = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/00/1010093.cif')

gpx = G2sc.G2Project(str(TMP / 'loopstra_uiso_heavy_tied.gpx'),
                     newgpx=str(TMP / 'nio_challenge.gpx'))
hist = gpx.histogram(0)
nio = gpx.add_phase(str(NIO), phasename='NiO', histograms=[hist], fmthint='CIF')
nio.HAPvalue('Scale', 0.05)
nio.set_HAP_refinements({'Scale': True}, [hist])
gpx.data['Controls']['data']['max cyc'] = 15
gpx.data['Controls']['data']['min dM/M'] = 0.00002
gpx.save()
gpx.do_refinements([{}])
gpx.save()
out = {
    'residuals': {k: v for k, v in hist.residuals.items() if k in ('wR','R','wRb','Rb','wRmin')},
    'mass_fractions': {k: list(v) for k, v in hist.ComputeMassFracs().items()},
    'scales': {ph.name: ph.HAPvalue('Scale', targethistlist=[hist]) for ph in gpx.phases()},
}
print('NIO_RESULT ' + json.dumps(out, sort_keys=True))
