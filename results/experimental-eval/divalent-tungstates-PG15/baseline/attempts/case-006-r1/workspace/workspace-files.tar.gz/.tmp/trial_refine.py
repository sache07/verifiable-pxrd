from pathlib import Path
import csv
import math
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / '.tmp'
XYE = TMP / 'pattern.xye'
GPX = TMP / 'trial.gpx'


def make_xye():
    with (ROOT / 'inputs' / 'pattern.csv').open(newline='') as src, XYE.open('w') as dst:
        reader = csv.DictReader(src)
        dst.write('# Original counts; sigma=sqrt(counts)\n')
        for row in reader:
            x = float(row['two_theta_deg'])
            y = float(row['intensity'])
            dst.write(f'{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n')


def status(gpx, label):
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.data['Instrument Parameters'][0]
    sample = hist.data['Sample Parameters']
    print(f'\nSTATUS {label}')
    print('residuals', hist.data['data'][0])
    print('wR', hist.get_wR())
    print('cell', phase.get_cell_and_esd())
    print('instrument', {k: v for k, v in inst.items() if k in ['Zero','U','V','W','X','Y','Z','SH/L','I(L2)/I(L1)']})
    print('sample', {k: v for k, v in sample.items() if k in ['Scale','Shift','Transparency','Gonio. radius','Type']})
    print('HAP', phase.data['Histograms'][hist.name])


def main():
    make_xye()
    if GPX.exists():
        GPX.unlink()
    gpx = G2sc.G2Project(newgpx=str(GPX))
    hist = gpx.add_powder_histogram(str(XYE), str(TMP / 'cu_ka.instprm'), fmthint='Topas')
    phase = gpx.add_phase(str(TMP / 'cuwo4_start.cif'), phasename='CuWO4', histograms=[hist], fmthint='CIF')
    # Reflection-mode setup is selected automatically for dual-wavelength data.
    hist.data['Sample Parameters']['Shift'][0] = -500.0
    hist.data['Sample Parameters']['Scale'][0] = 1.0
    hist.data['Background'][0][0] = 'chebyschev-1'
    hist.data['Background'][0][2] = 12
    hist.data['Background'][0][3:] = [1600.0] + [0.0] * 11
    hist.data['Limits'][1] = [10.0, 100.0]
    gpx.set_Controls('cycles', 8)
    gpx.save()
    status(gpx, 'initial')

    # Establish background, phase scale, and the large specimen displacement.
    phase.set_HAP_refinements({'Scale': True})
    hist.set_refinements({'Background': {'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 12},
                          'Sample Parameters': ['Shift']})
    gpx.do_refinements([{}])
    status(gpx, 'background scale shift')

    # Refine all independent triclinic cell terms.
    phase.set_refinements({'Cell': True})
    gpx.do_refinements([{}])
    status(gpx, 'cell')

    # Empirical uncalibrated laboratory profile, introduced in stages.
    hist.set_refinements({'Instrument Parameters': ['W', 'X', 'Y']})
    gpx.do_refinements([{}])
    status(gpx, 'profile WXY')
    hist.set_refinements({'Instrument Parameters': ['U', 'V', 'SH/L']})
    gpx.do_refinements([{}])
    status(gpx, 'profile UVSHL')

    gpx.save()


if __name__ == '__main__':
    main()
