#!/usr/bin/env python3
"""Compare a WOx candidate (plus optional ZnO) against a common ZnWO4 fit."""

import argparse
import json
from pathlib import Path

import GSASII.GSASIIscriptable as G2sc


ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
CANDIDATES = {
    "wo3m": ("WO3_P21c", "1528915"),
    "wo3m2": ("WO3_P21c_alt", "2311041"),
    "wo3tri": ("WO3_P-1", "2106293"),
    "wo3ortho": ("WO3_Pnma", "2107312"),
    "wo3tet": ("WO3_P4nmm", "1521533"),
    "wo3p21m": ("WO3_P21m", "1010618"),
    "w18": ("W18O49", "1538315"),
    "w3o8": ("W3O8", "2101050"),
}


def cod_path(cod_id):
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summary(project):
    hist = project.histogram(0)
    return {
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "fractions": hist.ComputeMassFracs(),
        "phases": {
            phase.name: {
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "cell": phase.get_cell(),
            }
            for phase in project.phases()
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", choices=CANDIDATES)
    parser.add_argument("--no-zno", action="store_true")
    args = parser.parse_args()

    phase_name, cod_id = CANDIDATES[args.candidate]
    out = Path(".tmp/trials") / f"cmp_{args.candidate}.gpx"
    project = G2sc.G2Project(".tmp/trials/v2_zwo.gpx", newgpx=str(out))
    project.set_Controls("cycles", 6)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y"]}
    )

    candidate = project.add_phase(
        str(cod_path(cod_id)),
        phasename=phase_name,
        histograms=[hist],
        fmthint="CIF",
    )
    candidate.data["Histograms"][hist.name]["Scale"][0] = 0.07
    candidate.set_HAP_refinements({"Scale": True}, [hist])
    project.refine(makeBack=False)
    candidate.set_refinements({"Cell": True})
    project.refine(makeBack=False)

    if not args.no_zno:
        zno = project.add_phase(
            str(cod_path("9004178")),
            phasename="ZnO",
            histograms=[hist],
            fmthint="CIF",
        )
        zno.data["Histograms"][hist.name]["Scale"][0] = 0.30
        zno.set_HAP_refinements({"Scale": True}, [hist])
        project.refine(makeBack=False)
        zno.set_refinements({"Cell": True})
        project.refine(makeBack=False)

    project.save()
    print("FINAL_JSON " + json.dumps(summary(project), default=float))


if __name__ == "__main__":
    main()
