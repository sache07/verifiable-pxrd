#!/usr/bin/env python3
"""Run a staged GSAS-II refinement for candidate Zn/W/O phase sets."""

import argparse
import json
from pathlib import Path

import numpy as np
import GSASII.GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = {
    "zwo": ("ZnWO4", "1520641"),
    "zno": ("ZnO", "9004178"),
    "wo3m": ("WO3_monoclinic", "1528915"),
    "wo3m2": ("WO3_monoclinic_alt", "2311041"),
    "wo3tri": ("WO3_triclinic", "2106293"),
    "wo3ortho": ("WO3_orthorhombic", "2107312"),
    "wo3tet": ("WO3_tetragonal", "1521533"),
    "w18": ("W18O49", "1538315"),
}


def snapshot(project, label):
    hist = project.histogram(0)
    row = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {
            key: val[1]
            for key, val in hist.InstrumentParameters.items()
            if isinstance(val, list) and len(val) >= 2
        },
        "sample": {
            key: val[0]
            for key, val in hist.data["Sample Parameters"].items()
            if isinstance(val, list) and val and isinstance(val[0], (int, float))
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    try:
        row["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        row["mass_fraction_error"] = repr(exc)
    print(json.dumps(row, indent=2, default=float))
    return row


def run_refinement(project, label):
    try:
        project.refine(makeBack=False)
    except Exception:
        snapshot(project, label + "_FAILED")
        raise
    return snapshot(project, label)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("phases", nargs="+")
    parser.add_argument("--low", type=float, default=10.0)
    parser.add_argument("--high", type=float, default=100.0)
    parser.add_argument("--bkg", type=int, default=15)
    parser.add_argument("--minor-scale", type=float, default=0.05)
    parser.add_argument("--sample-broadening", action="store_true")
    parser.add_argument("--size", type=float, default=0.03)
    parser.add_argument("--strain", type=float, default=1200.0)
    args = parser.parse_args()

    out = Path(".tmp/trials") / f"{args.name}.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    project.set_Controls("cycles", 8)
    hist = project.add_powder_histogram(
        "inputs/pattern.csv",
        "instrument.instprm",
        fmthint="comma",
    )
    hist.set_refinements(
        {
            "Limits": [args.low, args.high],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": args.bkg,
            },
        }
    )

    phase_objects = []
    for key in args.phases:
        phase_name, cod_id = PHASES[key]
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=phase_name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase_objects.append(phase)

    # The histogram scale carries the overall intensity. Hold the dominant
    # phase HAP scale at one and refine relative scales for other phases.
    for phase in phase_objects[1:]:
        phase.data["Histograms"][hist.name]["Scale"][0] = args.minor_scale
        phase.set_HAP_refinements({"Scale": True}, [hist])

    history = []
    history.append(run_refinement(project, "scale_background"))

    # Establish the dominant phase peak positions first.
    phase_objects[0].set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    history.append(run_refinement(project, "dominant_cell_zero"))

    # The metadata supplies no calibrated profile. Refine a common Caglioti
    # profile from a broad but physically plausible starting point.
    hist.set_refinements({"Instrument Parameters": ["W"]})
    history.append(run_refinement(project, "profile_W"))
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    history.append(run_refinement(project, "profile_UVW"))

    # Refine minor-phase cells only after their scale and common profile are
    # established. Do this one phase at a time to limit correlations.
    for phase in phase_objects[1:]:
        phase.set_refinements({"Cell": True})
        history.append(run_refinement(project, f"cell_{phase.name}"))

    if args.sample_broadening:
        # Optional diagnostic: add phase-specific size only. Microstrain is
        # deliberately not co-refined here because it is strongly correlated
        # with an uncalibrated U/V/W profile.
        for phase in phase_objects:
            phase.set_HAP_refinements(
                {
                    "Size": {
                        "type": "isotropic",
                        "value": args.size,
                        "refine": True,
                        "LGmix": {"value": 0.5, "refine": False},
                    },
                },
                [hist],
            )
        history.append(run_refinement(project, "phase_size"))

    project.save()
    Path(".tmp/trials", f"{args.name}.json").write_text(
        json.dumps(history, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
