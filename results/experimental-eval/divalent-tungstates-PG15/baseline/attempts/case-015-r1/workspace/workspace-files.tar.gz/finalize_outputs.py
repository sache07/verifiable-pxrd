#!/usr/bin/env python3
"""Export the requested deliverables from the converged GSAS-II project."""

import csv
import json
from pathlib import Path

import numpy as np
import GSASII.GSASIIscriptable as G2sc


SOURCE_PROJECT = Path(".tmp/trials/comprehensive.gpx")
FINAL_PROJECT = Path("final.gpx")

PHASE_OUTPUTS = {
    "ZnWO4": {
        "name": "zinc tungstate",
        "formula": "ZnWO4",
        "cif_path": "phase_1_ZnWO4.cif",
        "source_structure": "COD 1520641",
    },
    "WO3_P21c": {
        "name": "tungsten(VI) oxide (monoclinic)",
        "formula": "WO3",
        "cif_path": "phase_2_WO3.cif",
        "source_structure": "COD 1528915",
    },
    "ZnO": {
        "name": "zinc oxide (zincite)",
        "formula": "ZnO",
        "cif_path": "phase_3_ZnO.cif",
        "source_structure": "COD 9004178",
    },
}


def plain_float(value):
    return float(np.asarray(value))


def main():
    project = G2sc.G2Project(str(SOURCE_PROJECT), newgpx=str(FINAL_PROJECT))
    project.save()
    histogram = project.histogram(0)

    mass_fractions = histogram.ComputeMassFracs()
    if set(mass_fractions) != set(PHASE_OUTPUTS):
        raise RuntimeError(f"Unexpected phase set: {set(mass_fractions)}")

    phases_json = []
    for phase in project.phases():
        info = PHASE_OUTPUTS[phase.name]
        phase.export_CIF(info["cif_path"])
        fraction, fraction_esd = mass_fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phases_json.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": info["cif_path"],
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(fraction_esd),
                "weight_percent": 100.0 * float(fraction),
                "source_structure": info["source_structure"],
                "refined_cell": {key: float(value) for key, value in cell.items()},
                "refined_cell_esd": {
                    key: float(value) for key, value in cell_esd.items()
                },
            }
        )

    fraction_sum = sum(item["weight_fraction"] for item in phases_json)
    if not np.isclose(fraction_sum, 1.0, atol=1e-10):
        raise RuntimeError(f"Weight fractions sum to {fraction_sum}, not one")

    x = np.asarray(histogram.getdata("X"), dtype=float)
    observed = np.asarray(histogram.getdata("Yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    background = np.asarray(histogram.getdata("Background"), dtype=float)
    difference = np.asarray(histogram.getdata("Residual"), dtype=float)
    if not np.allclose(difference, observed - calculated, rtol=0, atol=1e-8):
        raise RuntimeError("GSAS-II residual is not observed minus calculated")

    with Path("fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "background_intensity",
                "difference_intensity",
            ]
        )
        writer.writerows(zip(x, observed, calculated, background, difference))

    residuals = histogram.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "phase_count": len(phases_json),
        "fraction_basis": "normalized over modeled crystalline phases",
        "phases": phases_json,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rwp_background_subtracted_percent": float(residuals["wRb"]),
            "Rp_background_subtracted_percent": float(residuals["Rb"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "number_of_observations": int(rvals["Nobs"]),
            "number_of_variables": int(rvals["Nvars"]),
            "converged": bool(rvals["converged"]),
            "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
        },
        "profile": {
            "path": "fit.csv",
            "difference_definition": "observed_intensity - calculated_intensity",
            "two_theta_min_deg": plain_float(x[0]),
            "two_theta_max_deg": plain_float(x[-1]),
            "point_count": int(x.size),
        },
        "gsasii_project": str(FINAL_PROJECT),
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
