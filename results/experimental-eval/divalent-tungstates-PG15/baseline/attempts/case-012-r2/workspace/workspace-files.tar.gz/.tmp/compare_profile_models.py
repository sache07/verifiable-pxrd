import os

from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC = os.path.join(ROOT, ".tmp", "profile.gpx")


def configure_common(gpx):
    h = gpx.histogram(0)
    # The histogram scale is exactly redundant with all phase scales. Keep it
    # fixed so the Hessian and phase-fraction uncertainties are well defined.
    h.data["Sample Parameters"]["Scale"] = [1.0, False]
    inst = h.data["Instrument Parameters"][0]
    for key, val, refine in [
        ("Zero", -0.0945, True), ("U", 3.0, True), ("V", 0.0, False),
        ("W", 22.0, True), ("X", 0.0, False), ("Y", 0.0, False),
        ("Z", 0.0, False),
    ]:
        inst[key][1] = val
        inst[key][2] = refine
    return h


def set_profile(phase, hist, size, strain, refine_size, refine_strain):
    phase.setSampleProfile(hist, "size", "isotropic", size, LGmix=0.5)
    phase.setSampleProfile(hist, "microstrain", "isotropic", strain, LGmix=0.5)
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
    if refine_size:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    if refine_strain:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])


def fit_model(name, profiles):
    dst = os.path.join(ROOT, ".tmp", name + ".gpx")
    gpx = G2sc.G2Project(SRC, newgpx=dst)
    h = configure_common(gpx)
    for phase_name, args in profiles.items():
        set_profile(gpx.phase(phase_name), h, *args)
    gpx.set_Controls("cycles", 12)
    # Phase scales need to readjust after fixing the redundant histogram scale.
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save(dst)
    r = h.data["data"][0]
    print("MODEL", name, "Rwp", r.get("wR"), "Rp", r.get("R"),
          "GOF", r.get("wR") / r.get("wRmin"), "DW", r.get("Durbin-Watson"),
          "Nvars", gpx.data["Covariance"]["data"].get("Rvals", {}).get("Nvars"),
          "SVD0", gpx.data["Covariance"]["data"].get("Rvals", {}).get("SVD0"))
    print("FRACS", name, h.ComputeMassFracs())
    for p in gpx.phases():
        hap = p.getHAPvalues(h)
        print("PROFILE", name, p.name, "size", hap["Size"][1][0],
              "strain", hap["Mustrain"][1][0], "scale", hap["Scale"])
    print("MESSAGE", gpx.data["Covariance"]["data"].get("Rvals", {}).get("msg"))


def main():
    # (size [micrometre], strain [microstrain], refine size, refine strain)
    models = {
        "size_only": {
            "NiWO4": (0.055, 0.0, True, False),
            "WO3": (0.055, 0.0, True, False),
        },
        "strain_only": {
            "NiWO4": (1000.0, 1200.0, False, True),
            "WO3": (1000.0, 3000.0, False, True),
        },
        "hybrid": {
            "NiWO4": (0.055, 0.0, True, False),
            "WO3": (1000.0, 4000.0, False, True),
        },
    }
    for name, profiles in models.items():
        fit_model(name, profiles)


if __name__ == "__main__":
    main()
