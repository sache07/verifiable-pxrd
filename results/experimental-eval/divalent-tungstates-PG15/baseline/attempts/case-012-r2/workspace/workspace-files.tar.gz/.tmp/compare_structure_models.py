import math
import os

from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC = os.path.join(ROOT, ".tmp", "size_only.gpx")


def atom_table(phase):
    return [(a.label, a.element, tuple(round(v, 6) for v in a.coordinates),
             a.refinement_flags, round(a.uiso, 6)) for a in phase.atoms()]


def fit(name, ni_atoms=False, wo_w_atoms=False, texture=False):
    dst = os.path.join(ROOT, ".tmp", name + ".gpx")
    gpx = G2sc.G2Project(SRC, newgpx=dst)
    h = gpx.histogram(0)
    ni = gpx.phase("NiWO4")
    wo = gpx.phase("WO3")
    # Reset coordinate and preferred-orientation flags before configuring the branch.
    for p in (ni, wo):
        for a in p.atoms():
            a.refinement_flags = " "
        hap = p.getHAPvalues(h)
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    if ni_atoms:
        ni.set_refinements({"Atoms": {"all": "X"}})
    if wo_w_atoms:
        wo.set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
    if texture:
        ni_hap = ni.getHAPvalues(h)
        wo_hap = wo.getHAPvalues(h)
        ni_hap["Pref.Ori."][3] = [1, 1, 1]
        wo_hap["Pref.Ori."][3] = [0, 1, 0]
        ni.set_HAP_refinements({"Pref.Ori.": True}, [h])
        wo.set_HAP_refinements({"Pref.Ori.": True}, [h])
    gpx.set_Controls("cycles", 12)
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save(dst)
    r = h.data["data"][0]
    rv = gpx.data["Covariance"]["data"].get("Rvals", {})
    print("MODEL", name, "Rwp", r.get("wR"), "Rp", r.get("R"),
          "GOF", r.get("wR") / r.get("wRmin"), "DW", r.get("Durbin-Watson"),
          "Nvars", rv.get("Nvars"), "SVD0", rv.get("SVD0"), "MSG", rv.get("msg"))
    print("FRACS", h.ComputeMassFracs())
    print("NIATOMS", atom_table(ni))
    print("WOATOMS", atom_table(wo))
    print("PO", ni.getHAPvalues(h)["Pref.Ori."], wo.getHAPvalues(h)["Pref.Ori."])


def main():
    fit("texture", texture=True)
    fit("ni_coords", ni_atoms=True)
    fit("ni_wo_w_coords", ni_atoms=True, wo_w_atoms=True)
    fit("coords_texture", ni_atoms=True, wo_w_atoms=True, texture=True)


if __name__ == "__main__":
    main()
