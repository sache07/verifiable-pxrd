import os
import sys

from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC = os.path.join(ROOT, ".tmp", "initial.gpx")


def report(gpx, label):
    h = gpx.histogram(0)
    d = h.data["data"][0]
    inst = h.data["Instrument Parameters"][0]
    print("RESULT", label, "Rwp", d.get("wR"), "Rp", d.get("R"),
          "GOF", d.get("wR", 0) / d.get("wRmin", 1), "DW", d.get("Durbin-Watson"))
    print("INST", {k: inst[k] for k in ["Zero", "U", "V", "W", "X", "Y", "Z"]})
    print("FRACS", h.ComputeMassFracs())
    for p in gpx.phases():
        hap = p.getHAPvalues(h)
        print("P", p.name, p.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "strain", hap["Mustrain"])


def main():
    out = os.path.join(ROOT, ".tmp", "profile.gpx")
    gpx = G2sc.G2Project(SRC, newgpx=out)
    h = gpx.histogram(0)
    ni = gpx.phase("NiWO4")
    wo = gpx.phase("WO3")
    inst = h.data["Instrument Parameters"][0]
    # Deliberately simple uncalibrated instrumental contribution; allow the
    # two crystalline phases to have distinct physical sample broadening.
    vals = {"Zero": -0.095, "U": 30.0, "V": 0.0, "W": 25.0,
            "X": 0.0, "Y": 0.0, "Z": 0.0}
    for key, val in vals.items():
        inst[key][1] = val
        inst[key][2] = False
    for p, size, strain in [(ni, 0.10, 1000.0), (wo, 0.18, 600.0)]:
        p.setSampleProfile(h, "size", "isotropic", size, LGmix=0.5)
        p.setSampleProfile(h, "microstrain", "isotropic", strain, LGmix=0.5)
        p.clear_HAP_refinements({"Size": True, "Mustrain": True}, [h])
    gpx.set_Controls("cycles", 10)
    recipes = [
        ({"Size": {"type": "isotropic", "refine": True}}, "size"),
        ({"Mustrain": {"type": "isotropic", "refine": True}}, "strain"),
        ({"Instrument Parameters": ["W"]}, "W"),
        ({"Instrument Parameters": ["U"]}, "U"),
        ({"Instrument Parameters": ["Zero"]}, "zero"),
        ({}, "settle"),
    ]
    for settings, name in recipes:
        if settings:
            gpx.do_refinements([{"set": settings}])
        else:
            gpx.do_refinements([{}])
        report(gpx, name)
    gpx.save(out)


if __name__ == "__main__":
    main()
