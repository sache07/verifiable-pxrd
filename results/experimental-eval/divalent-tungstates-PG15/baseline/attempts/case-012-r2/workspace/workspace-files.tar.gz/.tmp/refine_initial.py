import csv
import math
import os
import sys

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TMP = os.path.join(ROOT, ".tmp")


def write_xye():
    src = os.path.join(ROOT, "inputs", "pattern.csv")
    dst = os.path.join(TMP, "pattern.xye")
    data = np.loadtxt(src, delimiter=",", skiprows=1)
    # Counts are unprocessed and pointwise s.u.'s were not supplied. Use the
    # Poisson counting approximation required by weighted least squares.
    sig = np.sqrt(np.maximum(data[:, 1], 1.0))
    np.savetxt(dst, np.column_stack((data, sig)), fmt="%.8f %.8f %.8f")
    return dst


def summarize(gpx, tag):
    h = gpx.histogram(0)
    print("SUMMARY", tag, h.data["data"][0])
    print("INST", {k: v for k, v in h.data["Instrument Parameters"][0].items()
                   if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)")})
    for p in gpx.phases():
        hap = p.getHAPvalues(h)
        print("PHASE", p.name, "CELL", p.get_cell(), "SCALE", hap["Scale"],
              "SIZE", hap["Size"], "MUSTRAIN", hap["Mustrain"])


def main():
    xye = write_xye()
    project = os.path.join(TMP, "initial.gpx")
    gpx = G2sc.G2Project(newgpx=project)
    h = gpx.add_powder_histogram(xye, os.path.join(TMP, "cu_ka.instprm"), fmthint="xye")
    niwo4 = gpx.add_phase(os.path.join(TMP, "nickel_tungstate_start.cif"),
                          phasename="NiWO4", histograms=[h], fmthint="CIF")
    wo3 = gpx.add_phase(os.path.join(TMP, "tungsten_trioxide_start.cif"),
                        phasename="WO3", histograms=[h], fmthint="CIF")
    h.set_refinements({"Limits": [10.02, 99.98]})
    # A flexible but smooth whole-pattern background. Start at the measured
    # low-angle level to keep early scale cycles stable.
    h.set_refinements({"Background": {"type": "chebyschev-1", "refine": True,
                                             "no. coeffs": 12,
                                             "coeffs": [900.0, -500.0, 300.0, -180.0,
                                                        100.0, -55.0, 30.0, -15.0,
                                                        8.0, -4.0, 2.0, -1.0]}})
    # Refine in stages to avoid cell/zero and profile/sample-broadening
    # correlations. Atomic coordinates remain fixed because laboratory PXRD
    # does not independently determine them here.
    stages = [
        {"set": {"Background": {"refine": True}, "Scale": True}},
        {"set": {"Cell": True}},
        {"set": {"Instrument Parameters": ["Zero"]}},
        {"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}},
        {},
    ]
    gpx.set_Controls("cycles", 8)
    for i, stage in enumerate(stages, 1):
        try:
            gpx.do_refinements([stage])
            summarize(gpx, f"stage{i}")
        except Exception as exc:
            print("REFINEMENT_ERROR", i, repr(exc))
            gpx.save(project)
            raise
    gpx.save(project)
    summarize(gpx, "final")
    print("MASSFRACS", h.ComputeMassFracs())


if __name__ == "__main__":
    main()
