import csv
import json
import math
import os

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SOURCE_GPX = os.path.join(ROOT, ".tmp", "polar_both_po.gpx")
FINAL_GPX = os.path.join(ROOT, "final.gpx")


def fmt_cell(cell, esd):
    return {
        key: {"value": float(cell[key]), "esd": float(esd[key])}
        for key in cell
    }


def main():
    gpx = G2sc.G2Project(SOURCE_GPX, newgpx=FINAL_GPX)
    hist = gpx.histogram(0)

    # Include every supplied point in the submitted calculation. The earlier
    # working refinement omitted one endpoint at each side only to avoid edge
    # handling while profile choices were being tested.
    x_all = np.asarray(hist.getdata("X"), dtype=float)
    hist.set_refinements({"Limits": [float(x_all.min()) - 1e-5,
                                     float(x_all.max()) + 1e-5]})
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    gpx.set_Controls("cycles", 12)
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save(FINAL_GPX)

    cov = gpx.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    if not rvals.get("converged", False) or rvals.get("SVD0", 1) != 0:
        raise RuntimeError(f"Final refinement is not a clean convergence: {rvals}")

    # Export structures from the exact final project.
    cif_names = {"NiWO4": "NiWO4.cif", "WO3": "WO3.cif"}
    for phase in gpx.phases():
        phase.export_CIF(os.path.join(ROOT, cif_names[phase.name]))

    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    diff = np.asarray(hist.getdata("Residual"), dtype=float)
    bkg = np.asarray(hist.getdata("Background"), dtype=float)
    with open(os.path.join(ROOT, "fit.csv"), "w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow([
            "two_theta_deg", "observed_intensity", "calculated_intensity",
            "difference_observed_minus_calculated", "calculated_background",
        ])
        for row in zip(x, yobs, ycalc, diff, bkg):
            writer.writerow([f"{row[0]:.8f}", *(f"{v:.6f}" for v in row[1:])])

    mass_fracs = hist.ComputeMassFracs()
    hist_stats = hist.data["data"][0]
    phase_results = []
    for phase in gpx.phases():
        value, esd = mass_fracs[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        hap = phase.getHAPvalues(hist)
        pid = phase.id
        phase_results.append({
            "phase": phase.name,
            "formula": "NiWO4" if phase.name == "NiWO4" else "WO3",
            "starting_structure_source": ("Crystallography Open Database 5910277"
                                          if phase.name == "NiWO4" else
                                          "Crystallography Open Database 1528915"),
            "space_group": "P 2/c (No. 13)" if phase.name == "NiWO4" else "P 21/n (No. 14)",
            "cif_path": cif_names[phase.name],
            "weight_fraction": float(value),
            "weight_percent": float(100.0 * value),
            "weight_fraction_statistical_esd": float(esd),
            "weight_percent_statistical_esd": float(100.0 * esd),
            "estimated_systematic_uncertainty_weight_percent_absolute": 1.0,
            "unit_cell": fmt_cell(cell, cell_esd),
            "isotropic_coherent_domain_size_nm": float(1000.0 * hap["Size"][1][0]),
            "march_dollase_ratio": float(hap["Pref.Ori."][1]),
            "phase_r_f_squared_percent": float(hist_stats.get(f"{pid}:0:Rf^2")),
        })

    result = {
        "modeled_crystalline_phases": phase_results,
        "weight_fraction_basis": "normalized over the modeled crystalline phases; sums to 1.0",
        "modeled_crystalline_weight_fraction_sum": float(sum(p["weight_fraction"] for p in phase_results)),
        "fit_statistics": {
            "r_wp_percent": float(hist_stats["wR"]),
            "r_p_percent": float(hist_stats["R"]),
            "r_exp_percent": float(hist_stats["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "durbin_watson": float(hist_stats["Durbin-Watson"]),
            "converged": bool(rvals["converged"]),
            "svd_zero_count": int(rvals["SVD0"]),
            "two_theta_range_deg": [float(x.min()), float(x.max())],
        },
        "measurement_model": {
            "radiation": "Cu K-alpha1 + K-alpha2",
            "wavelength_kalpha1_angstrom": 1.540598,
            "wavelength_kalpha2_angstrom": 1.544426,
            "kalpha2_to_kalpha1_ratio": 0.5,
            "weighting": "Poisson approximation, sigma=sqrt(max(observed counts,1)); pointwise uncertainties were not supplied",
            "difference_definition": "observed - calculated",
        },
        "files": {
            "gsasii_project": "final.gpx",
            "profile": "fit.csv",
            "report": "report.md",
        },
        "notes": [
            "No amorphous fraction or unmodeled crystalline fraction is included in the normalization.",
            "The statistical fraction ESDs are smaller than the estimated approximately 1 wt% absolute systematic uncertainty from profile, texture, absorption, and uncalibrated-instrument choices.",
            "A trial NiO phase refined to zero; its model-dependent 3-sigma statistical upper bound was approximately 0.3 wt%, with a more conservative practical detection limit near 1 wt%.",
        ],
    }
    with open(os.path.join(ROOT, "result.json"), "w") as fp:
        json.dump(result, fp, indent=2)
        fp.write("\n")

    ni = next(p for p in phase_results if p["phase"] == "NiWO4")
    wo = next(p for p in phase_results if p["phase"] == "WO3")
    inst = hist.data["Instrument Parameters"][0]
    report = f"""# PXRD phase analysis

## Result

The pattern is described by two crystalline phases, normalized over the modeled crystalline material:

| Phase | Structure | Weight fraction | Refined cell (Å, °) |
|---|---|---:|---|
| NiWO₄ | wolframite, P 2/c (No. 13) | {ni['weight_percent']:.2f} wt% | a={ni['unit_cell']['length_a']['value']:.5f}, b={ni['unit_cell']['length_b']['value']:.5f}, c={ni['unit_cell']['length_c']['value']:.5f}, β={ni['unit_cell']['angle_beta']['value']:.4f} |
| WO₃ | room-temperature monoclinic, P 2₁/n (No. 14) | {wo['weight_percent']:.2f} wt% | a={wo['unit_cell']['length_a']['value']:.5f}, b={wo['unit_cell']['length_b']['value']:.5f}, c={wo['unit_cell']['length_c']['value']:.5f}, β={wo['unit_cell']['angle_beta']['value']:.4f} |

For practical reporting, use NiWO₄ {ni['weight_percent']:.1f} ± 1.0 wt% and WO₃ {wo['weight_percent']:.1f} ± 1.0 wt% (absolute). The GSAS-II counting-statistical ESD is only about {100*ni['weight_fraction_statistical_esd']:.2f} wt%, but it does not include instrumental-profile, preferred-orientation, microabsorption, or model-choice uncertainty. Amorphous material, if present, cannot be quantified without an internal standard.

## Evidence and refinement

NiWO₄ accounts for the dominant reflections at approximately 15.6, 19.2, 23.9, 24.85, 30.87, 36.53, 41.62, 52.27, 54.58, and 62–66° 2θ. Monoclinic WO₃ is required by its resolved 23.05/23.54/24.29° triplet and companion peaks near 26.53, 28.83, and 33–34°. This assignment is chemically consistent with reaction of the stated NiO and WO₃ precursors at 900 °C. A three-phase trial including rocksalt NiO drove the NiO scale to zero; the characteristic non-overlapped NiO reflection near 43.3° is absent. No residual peak series supports another crystalline phase.

The starting models were COD 5910277 (NiWO₄, reduced to its asymmetric unit) and COD 1528915 (WO₃). The submitted GSAS-II refinement used the stated Cu Kα1/Kα2 wavelengths and 0.5 intensity ratio, a smooth 12-term Chebyshev background, refined phase scales and cells, zero offset ({inst['Zero'][1]:.4f}°), effective polarization ({inst['Polariz.'][1]:.3f}), simple U/W instrumental broadening, phase-specific isotropic size broadening, and small March–Dollase corrections. NiWO₄ coordinates were refined; WO₃ coordinates were held at the starting literature model because minority-phase coordinate refinement was strongly correlated. The refined coherent-domain sizes ({ni['isotropic_coherent_domain_size_nm']:.0f} nm NiWO₄ and {wo['isotropic_coherent_domain_size_nm']:.0f} nm WO₃) should be viewed as effective profile parameters because no calibrated instrumental profile was supplied.

The final fit has Rwp={hist_stats['wR']:.3f}%, Rp={hist_stats['R']:.3f}%, Rexp={hist_stats['wRmin']:.3f}%, GOF={rvals['GOF']:.3f}, and χ²={rvals['chisq']:.1f} for {rvals['Nobs']} points and {rvals['Nvars']} refined parameters. The refinement converged without Hessian singularities. Detailed oxygen positions, the small texture corrections, and the formal cell ESDs should not be over-interpreted because the instrument profile and sample displacement were not independently calibrated.

Files: [NiWO4.cif](NiWO4.cif), [WO3.cif](WO3.cif), [fit.csv](fit.csv), [final.gpx](final.gpx), and [result.json](result.json).
"""
    with open(os.path.join(ROOT, "report.md"), "w") as fp:
        fp.write(report)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
