import os

from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC = os.path.join(ROOT, ".tmp", "size_only.gpx")


def run(name, wo=False, texture=False):
    dst = os.path.join(ROOT, ".tmp", name + ".gpx")
    gpx = G2sc.G2Project(SRC, newgpx=dst)
    h = gpx.histogram(0)
    ni = gpx.phase("NiWO4")
    wop = gpx.phase("WO3")
    for p in (ni, wop):
        for atom in p.atoms():
            atom.refinement_flags = " "
        p.getHAPvalues(h)["Pref.Ori."][2] = False
        p.getHAPvalues(h)["Pref.Ori."][1] = 1.0
    ni.set_refinements({"Atoms": {"Ni1": "X", "W1": "X"}})
    if wo:
        wop.set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
    if texture:
        ni.getHAPvalues(h)["Pref.Ori."][3] = [1, 1, 1]
        wop.getHAPvalues(h)["Pref.Ori."][3] = [0, 1, 0]
        ni.set_HAP_refinements({"Pref.Ori.": True}, [h])
        wop.set_HAP_refinements({"Pref.Ori.": True}, [h])
    gpx.set_Controls("cycles", 12)
    gpx.do_refinements([{}])
    gpx.do_refinements([{}])
    gpx.save(dst)
    d = h.data["data"][0]
    rv = gpx.data["Covariance"]["data"].get("Rvals", {})
    print("MODEL", name, d.get("wR"), d.get("R"), d.get("Durbin-Watson"),
          rv.get("Nvars"), rv.get("SVD0"), h.ComputeMassFracs())
    for p in (ni, wop):
        print(p.name, [(a.label, tuple(round(x, 6) for x in a.coordinates),
                        a.refinement_flags) for a in p.atoms()], p.getHAPvalues(h)["Pref.Ori."])


def main():
    run("heavy_niwo4")
    run("heavy_all", wo=True)
    run("heavy_texture", wo=True, texture=True)


if __name__ == "__main__":
    main()
