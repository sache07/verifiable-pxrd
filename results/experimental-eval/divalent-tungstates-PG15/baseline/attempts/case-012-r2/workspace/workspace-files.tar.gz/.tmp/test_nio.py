import os

from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
src = os.path.join(ROOT, ".tmp", "size_only.gpx")
dst = os.path.join(ROOT, ".tmp", "nio_test.gpx")
gpx = G2sc.G2Project(src, newgpx=dst)
h = gpx.histogram(0)
nio = gpx.add_phase(os.path.join(ROOT, ".tmp", "nickel_oxide_test.cif"),
                    phasename="NiO_test", histograms=[h], fmthint="CIF")
nio.HAPvalue("Scale", 0.01)
nio.setSampleProfile(h, "size", "isotropic", 0.05, LGmix=0.5)
nio.setSampleProfile(h, "microstrain", "isotropic", 0.0, LGmix=0.5)
nio.set_HAP_refinements({"Scale": True}, [h])
gpx.set_Controls("cycles", 12)
gpx.do_refinements([{}])
gpx.do_refinements([{}])
gpx.save(dst)
print("R", h.data["data"][0])
print("F", h.ComputeMassFracs())
print("SCALE", nio.getHAPvalues(h)["Scale"])
cov = gpx.data["Covariance"]["data"]
for key, val, sig in zip(cov.get("varyList", []), cov.get("variables", []), cov.get("sig", [])):
    if key.endswith(":Scale"):
        print("SCALEVAR", key, val, sig)
