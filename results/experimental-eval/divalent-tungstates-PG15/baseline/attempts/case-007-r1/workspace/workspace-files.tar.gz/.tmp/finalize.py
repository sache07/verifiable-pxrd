from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "fix_X2.gpx"
FINAL = ROOT / "final.gpx"
EFFECTIVE_POLARIZATION = 0.7725


gpx = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
h = gpx.histogram(0)
raw = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
x_in = raw["two_theta_deg"]
step = float(np.median(np.diff(x_in)))

# Include every measured point. GSAS-II slices the upper limit exclusively,
# hence the half-step extension beyond the final measured position.
h.Limits("lower", float(x_in[0]))
h.Limits("upper", float(x_in[-1] + 0.5 * step))
h.SampleParameters["Type"] = "Bragg-Brentano"
h.SampleParameters["Scale"][1] = False

inst = h.InstrumentParameters
inst["Polariz."][1:] = [EFFECTIVE_POLARIZATION, False]
inst["Zero"][2] = True
inst["U"][1:] = [0.0, False]
inst["V"][1:] = [0.0, False]
inst["W"][2] = True
inst["X"][2] = False
inst["Y"][1:] = [0.0, False]
inst["Z"][1:] = [0.0, False]
inst["SH/L"][2] = False

for p in gpx.phases():
    p.data["General"]["Cell"][0] = True
    hap = p.data["Histograms"][h.name]
    hap["Use"] = True
    hap["Scale"][1] = True
    if p.name == "MgWO4":
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [1, 1, 0]
        for atom in p.atoms():
            atom.refinement_flags = "X" if atom.element in ("Mg", "W") else " "
    else:
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        for atom in p.atoms():
            atom.refinement_flags = " "

gpx.set_Controls("cycles", 12)
gpx.do_refinements([{}, {}, {}])
gpx.save()

# Export phase CIFs from the exact final project and covariance state.
cif_names = {"MgWO4": "MgWO4.cif", "WO3": "WO3.cif", "MgO": "MgO.cif"}
for p in gpx.phases():
    p.export_CIF(str(ROOT / cif_names[p.name]))

# Export the combined observed/calculated/difference profile.
x = np.asarray(h.getdata("X"), dtype=float)
y_obs = np.asarray(h.getdata("Yobs"), dtype=float)
y_calc = np.asarray(h.getdata("Ycalc"), dtype=float)
difference = y_obs - y_calc
with (ROOT / "fit.csv").open("w", newline="") as fp:
    writer = csv.writer(fp)
    writer.writerow(
        ["two_theta_deg", "observed_intensity", "calculated_intensity", "difference_intensity"]
    )
    writer.writerows(
        (f"{xx:.8f}", f"{yo:.8f}", f"{yc:.8f}", f"{dd:.8f}")
        for xx, yo, yc, dd in zip(x, y_obs, y_calc, difference)
    )

mass_fracs = h.ComputeMassFracs()
res = h.residuals
rvals = gpx.data["Covariance"]["data"]["Rvals"]
formulas = {"MgWO4": "MgWO4", "WO3": "WO3", "MgO": "MgO"}
source_ids = {"MgWO4": "COD 9013902", "WO3": "COD 1528915", "MgO": "COD 9000499"}

phase_rows = []
for p in gpx.phases():
    cell, cell_esd = p.get_cell_and_esd()
    fraction, fraction_esd = mass_fracs[p.name]
    phase_rows.append(
        {
            "name": p.name,
            "formula": formulas[p.name],
            "space_group": p.data["General"]["SGData"]["SpGrp"].strip(),
            "structure_source": source_ids[p.name],
            "cif_path": cif_names[p.name],
            "weight_fraction": fraction,
            "weight_fraction_esd": fraction_esd,
            "unit_cell": {key: float(value) for key, value in cell.items()},
            "unit_cell_esd": {key: float(value) for key, value in cell_esd.items()},
        }
    )

fit_stats = {
    "Rp_percent": float(res["R"]),
    "Rwp_percent": float(res["wR"]),
    "Rexp_percent": float(res["wRmin"]),
    "goodness_of_fit": float(rvals["GOF"]),
    "chi_square": float(rvals["chisq"]),
    "reduced_chi_square": float(rvals["GOF"] ** 2),
    "n_observations": int(rvals["Nobs"]),
    "n_refined_parameters": int(rvals["Nvars"]),
    "converged": bool(rvals["converged"]),
    "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
}

result = {
    "normalization": "modeled crystalline phases only",
    "phases": phase_rows,
    "fit_statistics": fit_stats,
    "measurement_model": {
        "geometry": "Bragg-Brentano reflection",
        "radiation": "Cu Kalpha1/Kalpha2",
        "wavelengths_angstrom": [1.540598, 1.544426],
        "kalpha2_to_kalpha1_intensity_ratio": 0.5,
        "effective_polarization_factor": EFFECTIVE_POLARIZATION,
        "polarization_source": "profile-likelihood grid; not supplied in metadata",
        "weighting": "Poisson, sigma=sqrt(observed counts)",
    },
    "profile_path": "fit.csv",
    "gsas_project_path": "final.gpx",
}
with (ROOT / "result.json").open("w") as fp:
    json.dump(result, fp, indent=2)
    fp.write("\n")

phase_by_name = {row["name"]: row for row in phase_rows}
mgw = phase_by_name["MgWO4"]
wo = phase_by_name["WO3"]
mgo = phase_by_name["MgO"]
report = f"""# Quantitative crystalline-phase analysis

The pattern is modeled by three crystalline phases: wolframite-type MgWO4, monoclinic WO3, and rocksalt MgO. Fractions are normalized over these modeled crystalline phases; amorphous material, if present, is not quantified.

| Phase | Space group | Refined cell (angstrom, degrees) | Weight fraction |
|---|---|---|---:|
| MgWO4 | P 1 2/c 1 | a={mgw['unit_cell']['length_a']:.5f}, b={mgw['unit_cell']['length_b']:.5f}, c={mgw['unit_cell']['length_c']:.5f}, beta={mgw['unit_cell']['angle_beta']:.4f} | {100*mgw['weight_fraction']:.2f}% ({100*mgw['weight_fraction_esd']:.2f}% formal s.u.) |
| WO3 | P 1 21/n 1 | a={wo['unit_cell']['length_a']:.5f}, b={wo['unit_cell']['length_b']:.5f}, c={wo['unit_cell']['length_c']:.5f}, beta={wo['unit_cell']['angle_beta']:.4f} | {100*wo['weight_fraction']:.2f}% ({100*wo['weight_fraction_esd']:.2f}% formal s.u.) |
| MgO | F m -3 m | a={mgo['unit_cell']['length_a']:.5f} | {100*mgo['weight_fraction']:.2f}% ({100*mgo['weight_fraction_esd']:.2f}% formal s.u.) |

## Evidence and refinement

MgWO4 accounts for the dominant wolframite sequence at about 15.93, 19.24, 24.21/24.92, 30.81/31.11, 36.79, and 41.86 degrees 2theta. Monoclinic WO3 is required by the separate 23.43/23.93/24.67 degree triplet and its corroborating lines near 26.91, 28.94/29.23, 33.57/33.87/34.47, 47.54, 48.53, and 50.21 degrees. MgO is fixed by its cubic series, especially 43.21 and 62.54 degrees; removing MgO raised Rwp from {fit_stats['Rwp_percent']:.2f}% to 10.49%.

The GSAS-II Rietveld refinement used Poisson counting weights (sigma=sqrt(counts)), Cu Kalpha1/Kalpha2 wavelengths 1.540598/1.544426 angstrom with the reported 0.5 intensity ratio, a 15-term smooth background, refined phase scales and cells, and an effective common peak profile. Because detector polarization was not supplied, its effective factor was selected by a one-dimensional profile-likelihood grid and fixed at {EFFECTIVE_POLARIZATION:.4f} in the final refinement. A mild MgWO4 [110] March-Dollase correction was refined. The reported dual-wavelength model is supported over a Kalpha1-only trial, which raised Rwp to 12.91%. Final statistics are Rp={fit_stats['Rp_percent']:.3f}%, Rwp={fit_stats['Rwp_percent']:.3f}%, Rexp={fit_stats['Rexp_percent']:.3f}%, and goodness-of-fit={fit_stats['goodness_of_fit']:.3f}.

## Remaining uncertainty

The formal fraction uncertainties above are covariance estimates and are smaller than the likely systematic uncertainty. No calibrated instrument profile, supplied polarization factor, or pointwise uncertainties were available, and reflection geometry can introduce preferred-orientation and microabsorption bias (especially between W-rich phases and MgO). Practical absolute uncertainties of roughly 1–2 wt% are more realistic. The monoclinic WO3 assignment is favored over the tested triclinic and higher-symmetry alternatives by the resolved splitting, but the subtle monoclinic-versus-triclinic distortion is less certain than the WO3 phase identity. Oxygen coordinates in MgWO4 and WO3 could not be refined reliably from this X-ray pattern without chemically implausible bond shifts, so validated literature coordinates were retained; only the MgWO4 cation y coordinates and all unit cells were refined.
"""
(ROOT / "report.md").write_text(report)

print(json.dumps(result, indent=2))
