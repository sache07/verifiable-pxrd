from __future__ import annotations

import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


source = Path(sys.argv[1]).resolve()
target = Path(sys.argv[2]).resolve()
key = sys.argv[3]
value = float(sys.argv[4])

gpx = G2sc.G2Project(gpxfile=str(source), newgpx=str(target))
h = gpx.histogram(0)
gpx.set_Controls("cycles", 12)
h.InstrumentParameters[key][1] = value
h.InstrumentParameters[key][2] = False
gpx.do_refinements([{}, {}])
gpx.save()
print("PARAM", key, value)
print("RESIDUALS", h.residuals)
print("MASSFRAC", h.ComputeMassFracs())
print("RVALS", gpx.data["Covariance"]["data"]["Rvals"])
