from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
PATTERN = ROOT / "inputs" / "pattern.csv"
CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PHASE_FILES = {
    "MgWO4": CIF_ROOT / "9/01/39/9013902.cif",
    "MgO": CIF_ROOT / "9/00/04/9000499.cif",
    "WO3_1528915": CIF_ROOT / "1/52/89/1528915.cif",
    "WO3_2311041": CIF_ROOT / "2/31/10/2311041.cif",
    "WO3_2106293": CIF_ROOT / "2/10/62/2106293.cif",
}


def prepare_inputs() -> tuple[Path, Path]:
    raw = np.genfromtxt(PATTERN, delimiter=",", names=True)
    x, y = raw["two_theta_deg"], raw["intensity"]
    xye = TMP / "pattern.xye"
    np.savetxt(
        xye,
        np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]),
        fmt=("%.8f", "%.8f", "%.8f"),
    )
    inst = TMP / "cu_dual_multi.instprm"
    inst.write_text(
        """#GSAS-II instrument parameter file for lab data, Cu Kalpha doublet
Type:PXC;Bank:1
Lam1:1.540598;Lam2:1.544426;Zero:0.33;Polariz.:0.5;Azimuth:0.0;I(L2)/I(L1):0.5
U:200.0;V:0.0;W:100.0;X:5.0;Y:0.0;Z:0.0;SH/L:0.03
"""
    )
    return xye, inst


def show(gpx: G2sc.G2Project, stage: str) -> None:
    h = gpx.histogram(0)
    print("RESULT", stage, h.residuals, flush=True)
    print("MASSFRAC", h.ComputeMassFracs(), flush=True)
    print("INST", {k: v[1] for k, v in h.InstrumentParameters.items()}, flush=True)
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        print("PHASE", p.name, "cell", p.get_cell(), "scale", hap["Scale"], flush=True)


def run_refine(gpx: G2sc.G2Project, stage: str, refs: dict) -> None:
    print("STAGE", stage, flush=True)
    gpx.do_refinements([refs])
    gpx.save()
    show(gpx, stage)


def build(wo_key: str, include_mgo: bool, mode: str) -> None:
    xye, inst = prepare_inputs()
    suffix = "_mgo" if include_mgo else ""
    out = TMP / f"multi_{wo_key}{suffix}_{mode}.gpx"
    gpx = G2sc.G2Project(newgpx=str(out), author="OpenAI Codex")
    h = gpx.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    h.SampleParameters["Type"] = "Bragg-Brentano"
    h.SampleParameters["Scale"] = [1.0, False]
    h.Limits("lower", float(np.genfromtxt(PATTERN, delimiter=",", names=True, max_rows=1)["two_theta_deg"]))
    h.Limits("upper", 100.0)
    h.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 15}}
    )

    names = ["MgWO4", wo_key] + (["MgO"] if include_mgo else [])
    starts = {"MgWO4": 80.0, wo_key: 8.0, "MgO": 15.0}
    for key in names:
        display = "WO3" if key.startswith("WO3") else key
        p = gpx.add_phase(
            str(PHASE_FILES[key]), phasename=display, histograms=[h], fmthint="CIF"
        )
        p.data["Histograms"][h.name]["Scale"] = [starts[key], True]

    gpx.set_Controls("cycles", 6)
    run_refine(gpx, "scale_background", {})
    run_refine(gpx, "zero", {"set": {"Instrument Parameters": ["Zero"]}})
    run_refine(gpx, "cells", {"set": {"Cell": True}})
    if mode == "quick":
        return

    # Profile terms are introduced one at a time to keep the Caglioti
    # coefficients identifiable without a calibrated standard profile.
    run_refine(gpx, "profile_W", {"set": {"Instrument Parameters": ["W"]}})
    run_refine(gpx, "profile_U", {"set": {"Instrument Parameters": ["U"]}})
    run_refine(gpx, "profile_X", {"set": {"Instrument Parameters": ["X"]}})
    run_refine(gpx, "profile_Y", {"set": {"Instrument Parameters": ["Y"]}})
    run_refine(gpx, "asymmetry", {"set": {"Instrument Parameters": ["SH/L"]}})


if __name__ == "__main__":
    wo = sys.argv[1]
    include_mgo = sys.argv[2].lower() == "mgo"
    mode = sys.argv[3] if len(sys.argv) > 3 else "quick"
    build(wo, include_mgo, mode)
