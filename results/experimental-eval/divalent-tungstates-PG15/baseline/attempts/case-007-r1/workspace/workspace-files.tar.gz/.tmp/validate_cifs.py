from pathlib import Path

from pymatgen.core import Structure


root = Path(__file__).resolve().parents[1]
expected = {
    "MgWO4.cif": ("MgWO4", 13),
    "WO3.cif": ("WO3", 14),
    "MgO.cif": ("MgO", 225),
}
for name, (formula, number) in expected.items():
    structure = Structure.from_file(root / name)
    sg_symbol, sg_number = structure.get_space_group_info(symprec=0.05)
    assert structure.composition.reduced_formula == formula, (name, structure.composition)
    assert sg_number == number, (name, sg_symbol, sg_number)
    print(name, structure.composition.reduced_formula, sg_symbol, sg_number, len(structure))
print("cif_parse_and_symmetry=OK")
