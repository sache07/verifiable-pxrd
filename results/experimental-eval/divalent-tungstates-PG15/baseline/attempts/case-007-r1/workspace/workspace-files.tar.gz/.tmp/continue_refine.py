from __future__ import annotations

import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def show(gpx: G2sc.G2Project, stage: str) -> None:
    h = gpx.histogram(0)
    print("RESULT", stage, h.residuals, flush=True)
    print("MASSFRAC", h.ComputeMassFracs(), flush=True)
    print("INST", {k: v[1] for k, v in h.InstrumentParameters.items()}, flush=True)
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        print("PHASE", p.name, "cell", p.get_cell(), "scale", hap["Scale"], flush=True)


def run(gpx: G2sc.G2Project, stage: str, refs: dict) -> None:
    print("STAGE", stage, flush=True)
    gpx.do_refinements([refs])
    gpx.save()
    show(gpx, stage)


source = Path(sys.argv[1]).resolve()
target = Path(sys.argv[2]).resolve()
gpx = G2sc.G2Project(gpxfile=str(source), newgpx=str(target))
gpx.set_Controls("cycles", 8)

# Complete convergence of the lattice/zero refinement first.
run(gpx, "cells_repeat", {})
run(gpx, "profile_W", {"set": {"Instrument Parameters": ["W"]}})
run(gpx, "profile_U", {"set": {"Instrument Parameters": ["U"]}})
run(gpx, "profile_X", {"set": {"Instrument Parameters": ["X"]}})
run(gpx, "profile_Y", {"set": {"Instrument Parameters": ["Y"]}})
run(gpx, "asymmetry", {"set": {"Instrument Parameters": ["SH/L"]}})
