from __future__ import annotations

import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


source = Path(sys.argv[1]).resolve()
target = Path(sys.argv[2]).resolve()
phase_name = sys.argv[3]
axis = [int(v) for v in sys.argv[4:7]]

gpx = G2sc.G2Project(gpxfile=str(source), newgpx=str(target))
h = gpx.histogram(0)
gpx.set_Controls("cycles", 10)
h.InstrumentParameters["SH/L"][2] = False
for p in gpx.phases():
    for atom in p.atoms():
        atom.refinement_flags = " "
p = gpx.phase(phase_name)
po = p.data["Histograms"][h.name]["Pref.Ori."]
po[1], po[2], po[3] = 1.0, True, axis

gpx.do_refinements([{}])
gpx.save()
print("AXIS", phase_name, axis)
print("RESIDUALS", h.residuals)
print("MASSFRAC", h.ComputeMassFracs())
for p in gpx.phases():
    print("PO", p.name, p.data["Histograms"][h.name]["Pref.Ori."])
