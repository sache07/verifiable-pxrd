from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parents[1]
required = [
    "final.gpx",
    "MgWO4.cif",
    "WO3.cif",
    "MgO.cif",
    "fit.csv",
    "result.json",
    "report.md",
]
for name in required:
    path = root / name
    assert path.is_file() and path.stat().st_size > 0, name

result = json.loads((root / "result.json").read_text())
assert result["normalization"] == "modeled crystalline phases only"
assert {p["name"] for p in result["phases"]} == {"MgWO4", "WO3", "MgO"}
assert abs(sum(p["weight_fraction"] for p in result["phases"]) - 1.0) < 1e-12
for row in result["phases"]:
    assert (root / row["cif_path"]).is_file()

raw = np.genfromtxt(root / "inputs" / "pattern.csv", delimiter=",", names=True)
with (root / "fit.csv").open(newline="") as fp:
    reader = csv.DictReader(fp)
    assert reader.fieldnames == [
        "two_theta_deg",
        "observed_intensity",
        "calculated_intensity",
        "difference_intensity",
    ]
    fit = np.asarray(
        [
            [
                float(row["two_theta_deg"]),
                float(row["observed_intensity"]),
                float(row["calculated_intensity"]),
                float(row["difference_intensity"]),
            ]
            for row in reader
        ]
    )
assert fit.shape == (len(raw), 4) == (8301, 4)
assert np.isfinite(fit).all()
assert np.max(np.abs(fit[:, 0] - raw["two_theta_deg"])) < 5e-9
assert np.max(np.abs(fit[:, 1] - raw["intensity"])) < 5e-9
assert np.max(np.abs(fit[:, 3] - (fit[:, 1] - fit[:, 2]))) < 1.1e-8

gpx = G2sc.G2Project(gpxfile=str(root / "final.gpx"))
h = gpx.histogram(0)
assert len(gpx.phases()) == 3
assert np.max(np.abs(fit[:, 0] - np.asarray(h.getdata("X")))) < 5e-9
assert np.max(np.abs(fit[:, 1] - np.asarray(h.getdata("Yobs")))) < 5e-9
assert np.max(np.abs(fit[:, 2] - np.asarray(h.getdata("Ycalc")))) < 5e-9
assert h.InstrumentParameters["Polariz."][1] == 0.7725
assert h.InstrumentParameters["Lam1"][1] == 1.540598
assert h.InstrumentParameters["Lam2"][1] == 1.544426
assert h.InstrumentParameters["I(L2)/I(L1)"][1] == 0.5

mass = h.ComputeMassFracs()
by_name = {row["name"]: row for row in result["phases"]}
for name, (fraction, esd) in mass.items():
    assert abs(fraction - by_name[name]["weight_fraction"]) < 1e-12
    assert abs(esd - by_name[name]["weight_fraction_esd"]) < 1e-12

stats = result["fit_statistics"]
rvals = gpx.data["Covariance"]["data"]["Rvals"]
assert abs(h.residuals["R"] - stats["Rp_percent"]) < 1e-12
assert abs(h.residuals["wR"] - stats["Rwp_percent"]) < 1e-12
assert abs(h.residuals["wRmin"] - stats["Rexp_percent"]) < 1e-12
assert abs(rvals["GOF"] - stats["goodness_of_fit"]) < 1e-12
assert abs(rvals["chisq"] - stats["chi_square"]) < 1e-9
assert rvals["Nobs"] == stats["n_observations"] == 8301
assert rvals["Nvars"] == stats["n_refined_parameters"] == 32
assert rvals["converged"] and stats["converged"]

print("required_outputs=OK")
print("profile_rows=8301; x/yobs/ycalc/difference=OK")
print("fractions_sum=", sum(v[0] for v in mass.values()))
print("project_result_crosscheck=OK")
print("Rwp=", h.residuals["wR"], "GOF=", rvals["GOF"], "max_shift_esd=", rvals["Max shft/sig"])

