from __future__ import annotations

import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


source = Path(sys.argv[1]).resolve()
target = Path(sys.argv[2]).resolve()
stage = sys.argv[3]
gpx = G2sc.G2Project(gpxfile=str(source), newgpx=str(target))
h = gpx.histogram(0)
gpx.set_Controls("cycles", 12)

if stage == "profile_clean":
    inst = h.InstrumentParameters
    inst["Y"][1:] = [0.0, False]
    inst["U"][1:] = [0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True
    inst["SH/L"][2] = True
elif stage == "fix_X":
    h.InstrumentParameters["X"][2] = False
elif stage == "fix_W":
    h.InstrumentParameters["W"][2] = False
elif stage == "to_single":
    inst = h.InstrumentParameters
    inst["Lam"] = [1.540598, 1.540598, False]
    for key in ("Lam1", "Lam2", "I(L2)/I(L1)"):
        inst.pop(key, None)
    inst["W"][2] = True
    inst["X"][2] = False
elif stage == "refine_asym_fixzero":
    inst = h.InstrumentParameters
    inst["Zero"][2] = False
    inst["SH/L"][2] = True
    inst["X"][2] = False
elif stage == "disable_MgO":
    hap = gpx.phase("MgO").data["Histograms"][h.name]
    hap["Use"] = False
    hap["Scale"][1] = False
elif stage == "mgwo4_xyz":
    gpx.phase("MgWO4").set_refinements({"Atoms": {"all": "X"}})
elif stage == "mgwo4_cation_xyz":
    p = gpx.phase("MgWO4")
    for atom in p.atoms():
        atom.refinement_flags = "X" if atom.element in ("Mg", "W") else " "
elif stage == "wo3_w_xyz":
    p = gpx.phase("WO3")
    for atom in p.atoms():
        atom.uiso = 0.006 if atom.element.startswith("W") else 0.010
        atom.refinement_flags = "X" if atom.element.startswith("W") else " "
elif stage == "wo3_w_xyz_raw":
    p = gpx.phase("WO3")
    for atom in p.atoms():
        atom.refinement_flags = "X" if atom.element.startswith("W") else " "
elif stage == "wo3_all_xyz":
    p = gpx.phase("WO3")
    for atom in p.atoms():
        atom.refinement_flags = "X"
elif stage == "mgwo4_u":
    p = gpx.phase("MgWO4")
    for atom in p.atoms():
        atom.refinement_flags = "U"
elif stage == "all_off":
    for p in gpx.phases():
        for atom in p.atoms():
            atom.refinement_flags = " "
else:
    raise ValueError(stage)

print("STAGE", stage, flush=True)
gpx.do_refinements([{}])
gpx.save()
print("RESIDUALS", h.residuals, flush=True)
print("MASSFRAC", h.ComputeMassFracs(), flush=True)
print("INST", {k: v for k, v in h.InstrumentParameters.items()}, flush=True)
for p in gpx.phases():
    print("PHASE", p.name, p.get_cell(), flush=True)
    for atom in p.atoms():
        print(
            "ATOM", p.name, atom.label, atom.element, atom.coordinates,
            atom.uiso, atom.refinement_flags, flush=True
        )
