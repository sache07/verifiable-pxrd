from __future__ import annotations

import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


source = Path(sys.argv[1]).resolve()
target = Path(sys.argv[2]).resolve()
phase_name = sys.argv[3]
axis = [int(v) for v in sys.argv[4:7]]

gpx = G2sc.G2Project(gpxfile=str(source), newgpx=str(target))
h = gpx.histogram(0)
gpx.set_Controls("cycles", 10)

# Avoid the known near-collinearity of axial divergence and zero while
# comparing orientation axes.
h.InstrumentParameters["SH/L"][2] = False
for p in gpx.phases():
    for atom in p.atoms():
        atom.refinement_flags = " "
    po = p.data["Histograms"][h.name]["Pref.Ori."]
    po[1] = 1.0
    po[2] = p.name == phase_name
    if p.name == phase_name:
        po[3] = axis

gpx.do_refinements([{}])
gpx.save()
p = gpx.phase(phase_name)
print("AXIS", phase_name, axis)
print("RESIDUALS", h.residuals)
print("MASSFRAC", h.ComputeMassFracs())
print("PO", p.data["Histograms"][h.name]["Pref.Ori."])
