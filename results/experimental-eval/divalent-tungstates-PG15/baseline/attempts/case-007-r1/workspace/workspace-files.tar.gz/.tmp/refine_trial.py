from __future__ import annotations

import json
import math
import os
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
PATTERN = ROOT / "inputs" / "pattern.csv"
MGWO4_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/9/01/39/9013902.cif"
)


def write_inputs(kind: str) -> tuple[Path, Path]:
    raw = np.genfromtxt(PATTERN, delimiter=",", names=True)
    x = raw["two_theta_deg"]
    y = raw["intensity"]
    xye = TMP / "pattern.xye"
    # No pointwise uncertainties were supplied. Raw counts justify Poisson
    # standard uncertainties as the least-assumptive weighting model.
    np.savetxt(
        xye,
        np.column_stack(
            [x, y, np.sqrt(np.maximum(y, 1.0))]
        ),
        fmt=("%.8f", "%.8f", "%.8f"),
    )
    inst = TMP / f"cu_{kind}.instprm"
    if kind == "dual":
        text = """#GSAS-II instrument parameter file for lab data, Cu Kalpha doublet
Type:PXC;Bank:1
Lam1:1.540598;Lam2:1.544426;Zero:0.36;Polariz.:0.5;Azimuth:0.0;I(L2)/I(L1):0.5
U:30.0;V:-5.0;W:30.0;X:0.0;Y:2.0;Z:0.0;SH/L:0.02
"""
    elif kind == "single":
        text = """#GSAS-II instrument parameter file for lab data, Cu Kalpha1
Type:PXC;Bank:1
Lam:1.540598;Zero:0.36;Polariz.:0.5;Azimuth:0.0
U:30.0;V:-5.0;W:30.0;X:0.0;Y:2.0;Z:0.0;SH/L:0.02
"""
    else:
        raise ValueError(kind)
    inst.write_text(text)
    return xye, inst


def summarize(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    print("SUMMARY", label)
    print(" residuals", hist.residuals)
    print(" cell", phase.get_cell())
    print(" inst", {k: v for k, v in hist.InstrumentParameters.items()})
    print(" sample", hist.SampleParameters)
    print(" hap", phase.data["Histograms"][hist.name])
    print(" atoms")
    for a in phase.atoms():
        print(a.label, a.element, a.coordinates, a.occupancy, a.uiso, a.refinement_flags)


def refine(kind: str) -> None:
    xye, inst = write_inputs(kind)
    out = TMP / f"trial_{kind}.gpx"
    gpx = G2sc.G2Project(newgpx=str(out), author="OpenAI Codex")
    hist = gpx.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    phase = gpx.add_phase(
        str(MGWO4_CIF), phasename="MgWO4", histograms=[hist], fmthint="CIF"
    )
    hist.Limits("lower", float(np.genfromtxt(PATTERN, delimiter=",", names=True, max_rows=1)["two_theta_deg"]))
    hist.Limits("upper", 100.0)
    # A flexible but smooth background is needed for the strongly sloping
    # low-angle background. The coefficients are refined from GSAS-II defaults.
    hist.set_refinements(
        {
            "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 15},
        }
    )
    phase.set_HAP_refinements({"Scale": True})
    gpx.set_Controls("cycles", 8)
    # Stage refinements to avoid exchanging the large zero offset with the cell.
    for name, refs in [
        ("scale_background", {}),
        ("zero", {"set": {"Instrument Parameters": ["Zero"]}}),
        ("cell", {"set": {"Cell": True}}),
        ("profile_gaussian", {"set": {"Instrument Parameters": ["U", "V", "W"]}}),
        ("profile_lorentz", {"set": {"Instrument Parameters": ["X", "Y"]}}),
        ("asymmetry", {"set": {"Instrument Parameters": ["SH/L"]}}),
    ]:
        print("STAGE", kind, name)
        gpx.do_refinements([refs])
        print(hist.residuals)
    gpx.save()
    summarize(gpx, kind)


if __name__ == "__main__":
    refine(sys.argv[1])
