#!/usr/bin/env python3
"""Build and refine candidate GSAS-II phase models for the supplied PXRD data."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import spsolve
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PHASE_FILES = {
    "WO3": COD / "1/52/89/1528915.cif",
    "CoWO4": ROOT / "cowo4_start.cif",
    "CoO": COD / "1/54/16/1541662.cif",
    "Co3O4": COD / "9/00/58/9005896.cif",
}


def make_xye() -> Path:
    arr = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    # No pointwise uncertainties were supplied. Counting-statistics estimates
    # are the least-assumptive weights for the original count data.
    out = np.column_stack((arr[:, 0], arr[:, 1], np.sqrt(np.maximum(arr[:, 1], 1.0))))
    path = ROOT / "pattern.xye"
    np.savetxt(path, out, fmt=("%.8f", "%.8f", "%.8f"), header="2theta intensity sigma")
    return path


def arpls_baseline(y: np.ndarray, lam: float = 3.0e7, max_iter: int = 30) -> np.ndarray:
    """Asymmetrically reweighted penalized-least-squares baseline."""
    y = np.asarray(y, dtype=float)
    n = y.size
    diff2 = sparse.diags((np.ones(n - 2), -2 * np.ones(n - 2), np.ones(n - 2)),
                         (0, 1, 2), shape=(n - 2, n), format="csc")
    penalty = lam * (diff2.T @ diff2)
    weights = np.ones(n)
    baseline = y.copy()
    for _ in range(max_iter):
        weight_matrix = sparse.spdiags(weights, 0, n, n)
        baseline = spsolve(weight_matrix + penalty, weights * y)
        residual = y - baseline
        negative = residual[residual < 0]
        if negative.size < 2:
            break
        mean = negative.mean()
        std = max(negative.std(), 1e-12)
        exponent = np.clip(2.0 * (residual - (2.0 * std - mean)) / std, -60, 60)
        new_weights = 1.0 / (1.0 + np.exp(exponent))
        if np.linalg.norm(new_weights - weights) / max(np.linalg.norm(weights), 1e-12) < 1e-3:
            weights = new_weights
            break
        weights = new_weights
    return baseline


def print_state(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"\nSTATE {label}")
    print("residuals", json.dumps(hist.residuals, sort_keys=True, default=float))
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("phase", phase.name, "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap.get("Size"), "mustrain", hap.get("Mustrain"))
    if project.data.get("Covariance", {}).get("data", {}).get("covMatrix") is not None:
        try:
            print("mass_fractions", hist.ComputeMassFracs())
        except Exception as exc:
            print("mass_fraction_error", repr(exc))


def refine_stage(project: G2sc.G2Project, label: str) -> None:
    project.refine(makeBack=False)
    print_state(project, label)


def build_model(names: list[str], output: Path) -> G2sc.G2Project:
    xye = make_xye()
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(xye), str(ROOT / "lab_cuka.instprm"), fmthint="xye"
    )
    x_values = np.asarray(hist.data["data"][1][0])
    hist.set_refinements({"Limits": [float(x_values[0]), float(x_values[-1])]})
    # Histogram scale and phase scales are exactly degenerate. Keep the
    # histogram scale fixed and refine only the phase scales.
    hist.SampleParameters["Scale"][0] = 1.0
    hist.SampleParameters["Scale"][1] = False

    phases = []
    for name in names:
        phase = project.add_phase(
            str(PHASE_FILES[name]), phasename=name, histograms=[hist], fmthint="CIF"
        )
        phases.append(phase)
        # The literature WO3 CIF stores zero displacement parameters. Set a
        # conservative room-temperature starting value; coordinates stay fixed.
        if name == "WO3":
            for atom in phase.atoms():
                if atom.adp_flag == "I":
                    atom.uiso = 0.005 if atom.element == "W" else 0.008

    # Use a robust, smooth baseline as a fixed component, with a small refined
    # polynomial correction. The cloned baseline is not linked to any phase.
    autobkg = arpls_baseline(np.asarray(hist.data["data"][1][1]), lam=3.0e7)
    if not hasattr(hist.data["data"][1][1], "mask"):
        hist.data["data"][1][1] = np.ma.MaskedArray(
            hist.data["data"][1][1], mask=np.zeros(len(autobkg), dtype=bool)
        )
    bkg_hist = project.clone_powder_histogram(hist, "autobackground", np.asarray(autobkg))
    hist.set_background("fixedHist", bkg_hist)
    hist.set_background("fixedFileMult", 1.0)
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 6,
            "coeffs": [0.0] * 6,
        }
    })

    # Sensible positive starting phase scales. These are proportional phase
    # amounts; GSAS-II converts them to mass fractions using unit-cell masses.
    starts = {"WO3": 0.55, "CoWO4": 0.35, "CoO": 0.02, "Co3O4": 0.02}
    for phase in phases:
        phase.data["Histograms"][hist.name]["Scale"][0] = starts[phase.name]
        phase.set_HAP_refinements({"Scale": True})

    project.set_Controls("cycles", 12)
    project.save()
    project.index_ids()
    for phase in phases:
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")

    # Stage 1: intensities and smooth background.
    refine_stage(project, "scales_background")

    # Stage 2: line positions. Wavelengths and Kalpha2 ratio remain fixed to metadata.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_stage(project, "cells_zero")

    # Stage 3: a compact physical line-breadth model. Refine only the positive
    # Gaussian Caglioti W term plus phase-specific Lorentzian size terms; the
    # more correlated U/V/X/Y and strain terms remain fixed.
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 0.07, "refine": True}
        })
        project.set_Controls("parmMin", 0.005, variable=f"{phase.id}:{hist.id}:Size;i")
    hist.set_refinements({"Instrument Parameters": ["W"]})
    project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:W")
    refine_stage(project, "physical_profile")

    project.save()
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phases", nargs="+", choices=PHASE_FILES, required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    build_model(args.phases, args.output.resolve())


if __name__ == "__main__":
    main()
