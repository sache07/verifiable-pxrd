#!/usr/bin/env python3
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


source = Path("model_two_phase_compact.gpx").resolve()
output = Path("model_cowo4_atoms.gpx").resolve()
project = G2sc.G2Project(str(source), newgpx=str(output))
hist = project.histogram(0)

# Simplify the global Gaussian width to one positive constant term.
hist.InstrumentParameters["U"][1] = 0.0
hist.InstrumentParameters["U"][2] = False
hist.InstrumentParameters["W"][2] = True
project.set_Controls("cycles", 12)
project.refine(makeBack=False)
print("before atoms", hist.residuals, hist.ComputeMassFracs())

# Refine only heavy-atom coordinates. Oxygen coordinates and all Uiso values
# remain tied to the literature starting structures.
for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = (
            "X" if phase.name == "CoWO4" and atom.element in ("W", "Co") else " "
        )
project.refine(makeBack=False)

print("after atoms", hist.residuals, hist.ComputeMassFracs())
for phase in project.phases():
    print(phase.name, phase.get_cell())
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.uiso, atom.refinement_flags)
project.save()
