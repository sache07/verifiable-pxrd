#!/usr/bin/env python3
import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("gpx", type=Path)
parser.add_argument("--png", type=Path, default=Path("fit_diagnostic.png"))
args = parser.parse_args()

project = G2sc.G2Project(str(args.gpx))
hist = project.histogram(0)
x, yobs, weight, ycalc, ybkg, diff = hist.data["data"][1]
x = np.asarray(x)
yobs = np.asarray(yobs)
ycalc = np.asarray(ycalc)
ybkg = np.asarray(ybkg)
diff = np.asarray(diff)

fig, (ax, ax2) = plt.subplots(2, 1, figsize=(15, 8), sharex=True,
                              gridspec_kw={"height_ratios": [3, 1]})
ax.plot(x, yobs, color="black", lw=0.7, label="observed")
ax.plot(x, ycalc, color="tab:red", lw=0.8, label="calculated")
ax.plot(x, ybkg, color="tab:blue", lw=0.7, label="background")
ax.legend(loc="upper right")
ax.set_ylabel("counts")
ax2.axhline(0, color="0.6", lw=0.7)
ax2.plot(x, diff, color="tab:green", lw=0.7)
ax2.set_xlabel(r"$2\theta$ (deg)")
ax2.set_ylabel("obs - calc")
fig.suptitle(f"{args.gpx.name}: Rwp={hist.residuals.get('wR', float('nan')):.3f}%")
fig.tight_layout()
fig.savefig(args.png, dpi=180)
