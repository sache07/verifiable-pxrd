import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import minimum_filter1d, gaussian_filter1d
from scipy.signal import find_peaks
from pymatgen.core import Lattice, Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator


data = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
x, y = data.T

# Broad lower envelope for visualization and peak picking only.
lower = minimum_filter1d(y, size=151, mode="nearest")
background = gaussian_filter1d(lower, 80)
signal = y - background
peaks, props = find_peaks(signal, prominence=80, distance=6, width=1)

# The COD entry explicitly lists symmetry-related duplicates. Reconstruct its
# asymmetric unit so that the diffraction intensities are chemically valid.
structure = Structure.from_spacegroup(
    "P 1 2/c 1",
    Lattice.monoclinic(4.66, 5.69, 4.98, 90.0),
    ["Co", "W", "O", "O"],
    [[0.5, 0.653, 0.25], [0.0, 0.18, 0.25], [0.22, 0.11, -0.04], [0.26, 0.38, 0.39]],
)
calc = XRDCalculator(wavelength=1.540598)
pattern = calc.get_pattern(structure, two_theta_range=(x.min(), x.max()), scaled=True)

wo3_files = {
    "WO3 monoclinic P21/n": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif",
    "WO3 triclinic P-1": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/10/62/2106293.cif",
    "WO3 monoclinic P21/c (small cell)": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/56/35/1563541.cif",
}
wo3_patterns = {}
for name, filename in wo3_files.items():
    s = Structure.from_file(filename, primitive=False)
    wo3_patterns[name] = calc.get_pattern(s, two_theta_range=(x.min(), x.max()), scaled=True)

print(structure)
print("Calculated CoWO4 peaks")
for angle, intensity, hkls in zip(pattern.x, pattern.y, pattern.hkls):
    if intensity >= 0.5:
        labels = ",".join(str(item["hkl"]) for item in hkls)
        print(f"{angle:9.4f} {intensity:8.3f} {labels}")

print("\nObserved peaks")
for idx in peaks:
    if props["prominences"][np.where(peaks == idx)[0][0]] >= 100:
        print(f"{x[idx]:9.4f} {y[idx]:8.1f} net={signal[idx]:8.1f}")

for name, pat in wo3_patterns.items():
    print(f"\n{name}")
    for angle, intensity in zip(pat.x, pat.y):
        if intensity >= 1:
            print(f"{angle:9.4f} {intensity:8.3f}")

fig, axes = plt.subplots(2, 1, figsize=(14, 8), sharex=True)
axes[0].plot(x, y, lw=0.65, color="black")
axes[0].plot(x, background, lw=1, color="tab:orange")
axes[0].set_ylabel("counts")
axes[1].plot(x, signal, lw=0.65, color="black")
tick_offsets = [-120, -210, -300, -390]
for angle in pattern.x:
    axes[1].vlines(angle, tick_offsets[0] - 25, tick_offsets[0] + 25, color="tab:red", lw=0.8)
for offset, (name, pat) in zip(tick_offsets[1:], wo3_patterns.items()):
    for angle in pat.x:
        axes[1].vlines(angle, offset - 25, offset + 25, lw=0.8)
axes[1].set_ylim(-450, max(signal) * 1.05)
axes[1].set_xlabel(r"$2\theta$ (deg)")
axes[1].set_ylabel("background-subtracted / CoWO4 ticks")
fig.tight_layout()
fig.savefig("explore_pattern.png", dpi=180)
