#!/usr/bin/env python3
"""Test whether a chemically plausible extra crystalline phase is warranted."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = {
    "CoO": COD / "1/54/16/1541662.cif",
    "Co3O4": COD / "9/00/58/9005896.cif",
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", choices=CANDIDATES)
    parser.add_argument("--base", type=Path, default=ROOT / "model_two_phase_compact.gpx")
    args = parser.parse_args()
    output = ROOT / f"test_{args.candidate}.gpx"
    project = G2sc.G2Project(str(args.base.resolve()), newgpx=str(output))
    hist = project.histogram(0)

    # Hold line positions, breadths and atomic models at the converged two-phase
    # solution; re-optimize only background and phase amounts when adding one
    # candidate. This is a conservative one-parameter phase-presence test.
    hist.SampleParameters["Scale"][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Scale": True})
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])

    extra = project.add_phase(
        str(CANDIDATES[args.candidate]), phasename=args.candidate,
        histograms=[hist], fmthint="CIF"
    )
    hap = extra.data["Histograms"][hist.name]
    hap["Scale"][0] = 0.10
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.10
    extra.set_HAP_refinements({"Scale": True}, histograms=[hist])

    project.set_Frozen()
    project.set_Controls("cycles", 6)
    project.save()
    project.index_ids()
    project.refine(makeBack=False)

    print("candidate", args.candidate)
    print("residuals", hist.residuals)
    print("fractions", hist.ComputeMassFracs())
    print("candidate_hap", extra.data["Histograms"][hist.name])
    vary = project.data["Covariance"]["data"].get("varyList", [])
    sig = project.data["Covariance"]["data"].get("sig", [])
    print("candidate_scale_sigma", [(str(v), float(s)) for v, s in zip(vary, sig)
                                     if str(v) == f"{extra.id}:{hist.id}:Scale"])
    print("frozen", project.get_Frozen())
    project.save()


if __name__ == "__main__":
    main()
