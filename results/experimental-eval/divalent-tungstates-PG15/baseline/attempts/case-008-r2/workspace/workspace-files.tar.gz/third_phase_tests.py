from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "twophase_cell.gpx"
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


for name, cod_id in {
    "MnO": "1514108",
    "Mn3O4": "9001963",
    "Mn2O3": "1010586",
    "Mn3WO6": "2002703",
}.items():
    project = G2sc.G2Project(
        str(SOURCE), newgpx=str(ROOT / ".tmp" / f"third_{name}.gpx")
    )
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cod_cif(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
    )
    phase.data["Histograms"][hist.name]["Scale"] = [0.1, True]
    project.set_Controls("cycles", 15)
    project.refine()
    project.refine()
    project.save()
    print(f"RESULT {name} {cod_id}")
    print("wR", hist.residuals.get("wR"), "R", hist.residuals.get("R"))
    print("fractions", hist.ComputeMassFracs())
