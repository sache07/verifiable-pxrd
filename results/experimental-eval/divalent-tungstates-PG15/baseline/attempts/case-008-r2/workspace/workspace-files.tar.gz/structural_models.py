from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "profile_wx.gpx"


def show(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    print(f"\nRESULT {label}")
    print("residuals", hist.residuals)
    print("cell", phase.get_cell_and_esd())
    print(
        "instrument",
        {key: inst[key] for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")},
    )
    print("preferred_orientation", phase.data["Histograms"][hist.name]["Pref.Ori."])
    for atom in phase.atoms():
        print(
            "atom",
            atom.label,
            atom.element,
            atom.coordinates,
            atom.occupancy,
            atom.adp_flag,
            atom.ADP,
            atom.refinement_flags,
        )


# Refine symmetry-allowed atom coordinates, starting from the physical W/X profile.
pos_gpx = ROOT / ".tmp" / "structure_positions.gpx"
pos = G2sc.G2Project(str(SOURCE), newgpx=str(pos_gpx))
pos.set_Controls("cycles", 15)
pos.set_refinement({"set": {"Atoms": {"all": "X"}}})
pos.refine()
pos.refine()
pos.save()
show(pos, "positions")

# Test an unknown effective polarization correction.
pol_gpx = ROOT / ".tmp" / "structure_positions_pol.gpx"
pol = G2sc.G2Project(str(pos_gpx), newgpx=str(pol_gpx))
pol.set_refinement({"set": {"Instrument Parameters": ["Polariz."]}})
pol.refine()
pol.refine()
pol.save()
show(pol, "positions + polarization")

# Test axial-divergence asymmetry separately.
shl_gpx = ROOT / ".tmp" / "structure_positions_shl.gpx"
shl = G2sc.G2Project(str(pos_gpx), newgpx=str(shl_gpx))
shl.set_refinement({"set": {"Instrument Parameters": ["SH/L"]}})
shl.refine()
shl.refine()
shl.save()
show(shl, "positions + SH/L")

# Test both corrections together.
both_gpx = ROOT / ".tmp" / "structure_positions_pol_shl.gpx"
both = G2sc.G2Project(str(pos_gpx), newgpx=str(both_gpx))
both.set_refinement(
    {"set": {"Instrument Parameters": ["Polariz.", "SH/L"]}}
)
both.refine()
both.refine()
both.save()
show(both, "positions + polarization + SH/L")

# Test four isotropic displacement parameters (more supportable than the
# source CIF's single-crystal anisotropic tensors for this powder pattern).
uiso_gpx = ROOT / ".tmp" / "structure_positions_pol_uiso.gpx"
uiso = G2sc.G2Project(str(pol_gpx), newgpx=str(uiso_gpx))
uiso_phase = uiso.phase(0)
for atom in uiso_phase.atoms():
    atom.data[atom.cia] = "I"
    atom.data[atom.cia + 1] = {"Mn1": 0.0078, "W1": 0.0070, "O1": 0.0066, "O2": 0.0090}[atom.label]
    atom.refinement_flags = "XU"
uiso.refine()
uiso.refine()
uiso.save()
show(uiso, "positions + polarization + isotropic ADPs")
