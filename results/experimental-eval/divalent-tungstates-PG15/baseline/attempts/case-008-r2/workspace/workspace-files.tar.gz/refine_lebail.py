from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
GPX = ROOT / ".tmp" / "mnwo4_lebail.gpx"
CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)


def summary(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print("cell", phase.get_cell())
    print(
        "instrument",
        {key: inst[key] for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")},
    )
    print("sample scale", hist.SampleParameters["Scale"])
    print("phase scale", phase.data["Histograms"][hist.name]["Scale"])


project = G2sc.G2Project(newgpx=str(GPX))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "cu_kalpha.instprm"),
    fmthint="comma",
)
phase = project.add_phase(
    str(CIF), phasename="MnWO4", histograms=[hist], fmthint="CIF"
)
hist.SampleParameters["Scale"] = [1.0, False]

project.set_Controls("cycles", 12)
project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
hist.Limits("lower", 10.0)
hist.Limits("upper", 100.0)

inst = hist.InstrumentParameters
inst["Zero"][1] = 0.30
inst["U"][1] = 10.0
inst["V"][1] = 0.0
inst["W"][1] = 20.0
inst["X"][1] = 3.0
inst["Y"][1] = 1.0

project.set_refinement(
    {
        "set": {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 15,
            },
            "Scale": True,
        }
    }
)
project.refine()
summary(project, "Rietveld initialization")

# A first Rietveld calculation creates the reflection list needed by Le Bail.
project.set_refinement({"set": {"LeBail": True}})
project.refine()
summary(project, "Le Bail background + scale")

project.set_refinement({"set": {"Cell": True}})
project.refine()
summary(project, "Le Bail cell")

project.set_refinement({"set": {"Instrument Parameters": ["Zero"]}})
project.refine()
summary(project, "Le Bail zero")

project.set_refinement({"set": {"Instrument Parameters": ["W", "X"]}})
project.refine()
summary(project, "Le Bail W + X")

project.set_refinement({"set": {"Instrument Parameters": ["U", "Y"]}})
project.refine()
summary(project, "Le Bail U + Y")

project.set_refinement({"clear": {"LeBail": True}})
project.refine()
summary(project, "Rietveld fixed structure")
project.save()
