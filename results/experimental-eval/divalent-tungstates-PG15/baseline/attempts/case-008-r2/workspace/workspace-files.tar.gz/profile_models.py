from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE_GPX = ROOT / ".tmp" / "profile_base.gpx"
CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)


def show(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    print(f"\nRESULT {label}")
    print("residuals", hist.residuals)
    print("cell", phase.get_cell())
    print(
        "profile",
        {key: inst[key] for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")},
    )
    print("phase_scale", phase.data["Histograms"][hist.name]["Scale"])


project = G2sc.G2Project(newgpx=str(BASE_GPX))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "cu_kalpha.instprm"),
    fmthint="comma",
)
phase = project.add_phase(
    str(CIF), phasename="MnWO4", histograms=[hist], fmthint="CIF"
)
hist.SampleParameters["Scale"] = [1.0, False]
project.set_Controls("cycles", 10)
project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
hist.Limits("lower", 10.0)
hist.Limits("upper", 100.0)
inst = hist.InstrumentParameters
for key, val in {"Zero": 0.25, "U": 10.0, "V": 0.0, "W": 20.0, "X": 10.0, "Y": 0.0}.items():
    inst[key][1] = val

project.set_refinement(
    {
        "set": {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 15,
            },
            "Scale": True,
        }
    }
)
project.refine()
project.set_refinement({"set": {"Cell": True}})
project.refine()
project.set_refinement({"set": {"Instrument Parameters": ["Zero"]}})
project.refine()
project.save()
show(project, "base")

models = {
    "wx": ["W", "X"],
    "uwx": ["U", "W", "X"],
    "wxy": ["W", "X", "Y"],
    "uvwx": ["U", "V", "W", "X"],
    "uvw": ["U", "V", "W"],
}
for name, terms in models.items():
    branch = ROOT / ".tmp" / f"profile_{name}.gpx"
    test = G2sc.G2Project(str(BASE_GPX), newgpx=str(branch))
    test.set_Controls("cycles", 14)
    ti = test.histogram(0).InstrumentParameters
    for key in ("U", "V", "W", "X", "Y"):
        ti[key][2] = False
    test.set_refinement({"set": {"Instrument Parameters": terms}})
    test.refine()
    test.refine()
    test.save()
    show(test, name)
