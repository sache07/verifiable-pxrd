from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "structure_positions_pol.gpx"
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


models = {
    "monoclinic_P21n": "1528915",
    "triclinic_P-1": "2106293",
    "orthorhombic_Pnma": "2107312",
    "old_pseudosym": "1010618",
    "tetragonal_P4ncc": "1521532",
    "tetragonal_P4nmm": "1521533",
    "hexagonal_P6mmm": "1004057",
    "monoclinic_smallcell": "1563541",
}

for label, cod_id in models.items():
    project = G2sc.G2Project(
        str(SOURCE), newgpx=str(ROOT / ".tmp" / f"wo3_{label}.gpx")
    )
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cod_cif(cod_id)),
        phasename=f"WO3_{label}",
        histograms=[hist],
        fmthint="CIF",
    )
    phase.data["Histograms"][hist.name]["Scale"] = [0.4, True]
    project.set_Controls("cycles", 15)
    project.refine()
    project.refine()
    project.save()
    print(f"RESULT {label} {cod_id}")
    print("wR", hist.residuals.get("wR"), "R", hist.residuals.get("R"))
    print("fractions", hist.ComputeMassFracs())
