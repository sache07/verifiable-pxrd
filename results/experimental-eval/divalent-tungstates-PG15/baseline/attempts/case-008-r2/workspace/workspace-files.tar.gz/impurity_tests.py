from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "structure_positions_pol.gpx"
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


candidates = {
    "MnO": "1514108",
    "WO3": "1528915",
    "Mn3O4": "9001963",
    "Mn2O3": "1010586",
    "Mn3WO6": "2002703",
}

for name, cod_id in candidates.items():
    output = ROOT / ".tmp" / f"test_{name}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cod_cif(cod_id)),
        phasename=name,
        histograms=[hist],
        fmthint="CIF",
    )
    phase.data["Histograms"][hist.name]["Scale"] = [0.5, True]
    project.set_Controls("cycles", 15)
    project.refine()
    project.refine()
    project.save()

    vary = project.data["Covariance"]["data"].get("varyList", [])
    sig = project.data["Covariance"]["data"].get("sig", [])
    scale_var = f"{phase.id}:{hist.id}:Scale"
    scale_esd = sig[vary.index(scale_var)] if scale_var in vary else None
    print(f"\nRESULT {name} COD {cod_id}")
    print("residuals", hist.residuals)
    print("candidate_scale", phase.data["Histograms"][hist.name]["Scale"], scale_esd)
    try:
        print("mass_fractions", hist.ComputeMassFracs())
    except Exception as err:
        print("mass_fraction_error", repr(err))
