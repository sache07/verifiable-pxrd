from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "twophase_cell.gpx"

directions = {
    "100": [1, 0, 0],
    "010": [0, 1, 0],
    "001": [0, 0, 1],
    "110": [1, 1, 0],
    "101": [1, 0, 1],
    "011": [0, 1, 1],
    "11m1": [1, 1, -1],
    "111": [1, 1, 1],
}

for label, hkl in directions.items():
    project = G2sc.G2Project(
        str(SOURCE), newgpx=str(ROOT / ".tmp" / f"texture_{label}.gpx")
    )
    hist = project.histogram(0)
    phase = project.phase(0)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[1] = 1.0
    pref[3] = hkl
    phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    project.set_Controls("cycles", 15)
    project.refine()
    project.refine()
    project.save()
    print(
        "RESULT",
        label,
        "wR",
        hist.residuals.get("wR"),
        "R",
        hist.residuals.get("R"),
        "MD",
        phase.data["Histograms"][hist.name]["Pref.Ori."],
        "fractions",
        hist.ComputeMassFracs(),
    )
