import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "twophase_cell.gpx"
FINAL_GPX = ROOT / "final.gpx"

# Reload the selected two-phase model under its submitted filename and perform
# the final least-squares cycle there, so the covariance, profile and CIFs all
# derive from final.gpx itself.
project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL_GPX))
project.set_Controls("cycles", 15)
project.refine()
project.refine()
project.save()

hist = project.histogram(0)
mnwo4 = project.phase(0)
wo3 = project.phase(1)

mnwo4.export_CIF(str(ROOT / "MnWO4.cif"))
wo3.export_CIF(str(ROOT / "WO3.cif"))

# GSAS-II leaves profile arrays outside the refinement limits as zeros. Export
# exactly the points carrying a calculated profile, which is the fitted range.
x = np.asarray(hist.getdata("x"), dtype=float)
yobs = np.asarray(hist.getdata("yobs"), dtype=float)
ycalc = np.asarray(hist.getdata("ycalc"), dtype=float)
ydiff = np.asarray(hist.getdata("residual"), dtype=float)
bkg = np.asarray(hist.getdata("background"), dtype=float)
used = ycalc != 0.0
with (ROOT / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "difference_intensity",
            "background_intensity",
        ]
    )
    writer.writerows(
        zip(x[used], yobs[used], ycalc[used], ydiff[used], bkg[used])
    )

fractions = hist.ComputeMassFracs()
rvals = project.data["Covariance"]["data"]["Rvals"]
residuals = hist.residuals

result = {
    "phases": [
        {
            "name": "manganese tungstate (wolframite)",
            "formula": "MnWO4",
            "space_group": "P 2/c",
            "cif_path": "MnWO4.cif",
            "weight_fraction": fractions[mnwo4.name][0],
            "weight_fraction_esd": fractions[mnwo4.name][1],
        },
        {
            "name": "tungsten trioxide (gamma, monoclinic)",
            "formula": "WO3",
            "space_group": "P 21/n",
            "cif_path": "WO3.cif",
            "weight_fraction": fractions[wo3.name][0],
            "weight_fraction_esd": fractions[wo3.name][1],
        },
    ],
    "fit_statistics": {
        "rp_percent": residuals["R"],
        "rwp_percent": residuals["wR"],
        "rwp_min_percent": residuals["wRmin"],
        "goodness_of_fit": rvals["GOF"],
        "chi_square": rvals["chisq"],
        "reduced_chi_square": rvals["GOF"] ** 2,
        "number_observations": rvals["Nobs"],
        "number_variables": rvals["Nvars"],
        "durbin_watson": hist.data["data"][0]["Durbin-Watson"],
        "two_theta_min_deg": float(x[used][0]),
        "two_theta_max_deg": float(x[used][-1]),
    },
}
with (ROOT / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps(result, indent=2))
print("MnWO4 cell", mnwo4.get_cell_and_esd())
print("WO3 cell", wo3.get_cell_and_esd())
print("instrument", hist.InstrumentParameters)
