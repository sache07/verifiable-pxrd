#!/usr/bin/env python3
"""Build and refine trial Pb-W-O phase models with GSAS-II."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    path = COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
    if not path.exists():
        raise FileNotFoundError(path)
    return path


def summarize(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histogram(0)
    print(f"\nSUMMARY {label}")
    print("residuals", json.dumps(hist.data["data"][0], default=str, sort_keys=True))
    print("instrument")
    for key, val in hist.data["Instrument Parameters"][0].items():
        print(" ", key, val)
    print("sample", hist.data["Sample Parameters"])
    try:
        print("mass_fracs", hist.ComputeMassFracs())
    except Exception as err:
        print("mass_frac_error", repr(err))
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        print("phase", phase.name, "cell", phase.get_cell(), "density", phase.density)
        print("  composition", phase.composition)
        print("  scale", hap["Scale"], "size", hap["Size"], "mustrain", hap["Mustrain"])
    print("variables")
    cov = gpx.data.get("Covariance", {}).get("data", {})
    vals = dict(zip(cov.get("varyList", []), cov.get("variables", [])))
    sigs = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    for key in cov.get("varyList", []):
        print(" ", key, vals[key], sigs.get(key))


def run(ids: list[str], out: Path) -> None:
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / ".tmp" / "instrument.instprm"),
        fmthint="comma",
    )
    sample = hist.data["Sample Parameters"]
    sample.update(
        {
            "Type": "Bragg-Brentano",
            "Scale": [1.0, False],
            "Shift": [0.0, False],
            "Transparency": [0.0, False],
            "SurfRoughA": [0.0, False],
            "SurfRoughB": [0.0, False],
        }
    )
    names = {
        "9009811": "PbWO4_scheelite",
        "1527935": "PbWO4_scheelite_old",
        "9016035": "Pb7W8O28.8",
        "2310433": "PbO_massicot",
        "1533609": "PbO_massicot_alt",
        "9012700": "PbO_litharge",
        "1528915": "WO3_monoclinic",
        "1010618": "WO3_low_symmetry",
        "2106293": "WO3_triclinic",
        "2311041": "WO3_monoclinic_alt",
    }
    phases = []
    for cod_id in ids:
        phases.append(
            gpx.add_phase(
                str(cod_path(cod_id)),
                phasename=names.get(cod_id, cod_id),
                histograms=[hist],
                fmthint="CIF",
            )
        )

    # Give the minor phases conservative starting scales. The overall
    # histogram scale is fixed, so all independent phase scales can vary.
    starts = [100.0] + [10.0] * (len(phases) - 1)
    for phase, scale in zip(phases, starts):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][1][0] = 0.05

    # Fit a smooth initial background to baseline points found with arPLS.
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 18}}
    )
    yobs = np.asarray(hist.getdata("Yobs"))
    xobs = np.asarray(hist.getdata("X"))
    baseline = gaussian_filter1d(
        percentile_filter(yobs, percentile=12, size=401, mode="nearest"), sigma=80
    )
    hist.set_refinements(
        {"Background": {"FixedPoints": list(zip(xobs[::80], baseline[::80]))}}
    )
    hist.fit_fixed_points()
    gpx.set_Controls("cycles", 8)

    # Scales/background first, then the common zero offset and cells.
    gpx.refine()
    summarize(gpx, "scales_background")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    gpx.refine()
    summarize(gpx, "zero")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    gpx.refine()
    summarize(gpx, "cells")

    # Crystallite size is the dominant broadening term. Refine it before
    # allowing a modest global Gaussian profile adjustment.
    for phase in phases:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.05, "refine": True}}, [hist]
        )
    gpx.refine()
    summarize(gpx, "size")

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
    gpx.refine()
    summarize(gpx, "profile")

    gpx.refine()
    gpx.save()
    summarize(gpx, "final")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("ids", nargs="+")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    run(args.ids, args.out.resolve())


if __name__ == "__main__":
    main()
