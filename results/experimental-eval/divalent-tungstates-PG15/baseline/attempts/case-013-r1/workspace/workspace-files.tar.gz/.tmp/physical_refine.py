#!/usr/bin/env python3
"""Explore a stable physical broadening model from the three-phase trial."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def show(gpx, label):
    h = gpx.histogram(0)
    print("\n", label, "Rwp", h.get_wR(), "mass", h.ComputeMassFracs())
    print("inst", h.data["Instrument Parameters"][0])
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        print(p.name, "cell", p.get_cell(), "scale", hap["Scale"], "size", hap["Size"], "strain", hap["Mustrain"])


def main():
    src = Path(".tmp/trial_3phase.gpx").resolve()
    dst = Path(".tmp/physical_3phase.gpx").resolve()
    gpx = G2sc.G2Project(str(src), newgpx=str(dst))
    h = gpx.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    for key, value in {"U": 0.0, "V": 0.0, "W": 5.0, "X": 0.0, "Y": 0.0}.items():
        inst[key][1] = value
        inst[key][2] = key == "W"
    for atom in gpx.phase("PbWO4_scheelite").atoms():
        atom.uiso = 0.0
        atom.refinement_flags = " "
    gpx.set_Controls("cycles", 12)
    gpx.refine()
    show(gpx, "W plus size")

    # Freeze the global Gaussian term before separating phase-specific
    # strain broadening, to avoid instrument/sample width correlations.
    inst = h.data["Instrument Parameters"][0]
    inst["W"][2] = False
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2][0] = True
    gpx.refine()
    show(gpx, "phase size and strain")

    # Test one physically motivated March-Dollase correction for the
    # exceptionally strong scheelite (112) reflection.
    hap = gpx.phase("PbWO4_scheelite").data["Histograms"][h.name]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = [1, 1, 2]
    gpx.refine()
    show(gpx, "scheelite texture")

    gpx.refine()
    gpx.save()
    show(gpx, "final")


if __name__ == "__main__":
    main()
