#!/usr/bin/env python3
"""Refine a compact, consistently parameterized candidate phase model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
NAMES = {
    "9009811": "PbWO4_scheelite",
    "9016035": "Pb7W8O28.8_vacancy_ordered",
    "2310433": "PbO_massicot",
    "9012700": "PbO_litharge",
    "1528915": "WO3_monoclinic",
    "1010618": "WO3_low_symmetry",
}


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def refine(ids: list[str], out: Path) -> dict:
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(newgpx=str(out))
    h = gpx.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / ".tmp/instrument.instprm"),
        fmthint="comma",
    )
    h.data["Sample Parameters"].update(
        {
            "Type": "Bragg-Brentano",
            "Scale": [1.0, False],
            "Shift": [0.0, False],
            "Transparency": [0.0, False],
            "SurfRoughA": [0.0, False],
            "SurfRoughB": [0.0, False],
        }
    )
    phases = [
        gpx.add_phase(
            str(cod_path(i)), phasename=NAMES[i], histograms=[h], fmthint="CIF"
        )
        for i in ids
    ]
    for index, p in enumerate(phases):
        hap = p.data["Histograms"][h.name]
        hap["Scale"] = [100.0 if index == 0 else 10.0, True]
        hap["Size"][1][0] = 0.05
        for atom in p.atoms():
            atom.uiso = 0.0
            atom.refinement_flags = " "

    h.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 18}}
    )
    x = np.asarray(h.getdata("X"))
    y = np.asarray(h.getdata("Yobs"))
    baseline = gaussian_filter1d(
        percentile_filter(y, percentile=12, size=401, mode="nearest"), sigma=80
    )
    h.set_refinements(
        {"Background": {"FixedPoints": list(zip(x[::80], baseline[::80]))}}
    )
    h.fit_fixed_points()
    gpx.set_Controls("cycles", 10)
    gpx.refine()

    h.set_refinements({"Instrument Parameters": ["Zero"]})
    gpx.refine()
    for p in phases:
        p.set_refinements({"Cell": True})
    gpx.refine()
    for p in phases:
        p.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.05, "refine": True}}, [h]
        )
    gpx.refine()

    inst = h.data["Instrument Parameters"][0]
    for key, value in {"U": 0.0, "V": 0.0, "W": 5.0, "X": 0.0, "Y": 0.0}.items():
        inst[key][1] = value
        inst[key][2] = key == "W"
    gpx.refine()
    gpx.refine()
    gpx.save()

    h = gpx.histogram(0)
    result = {
        "ids": ids,
        "Rwp_percent": h.get_wR(),
        "Rp_percent": h.data["data"][0].get("R"),
        "reduced_chi_squared": (h.get_wR() / h.data["data"][0]["wRmin"]) ** 2,
        "weight_fractions": {
            key: {"value": val[0], "esd": val[1]}
            for key, val in h.ComputeMassFracs().items()
        },
        "zero_deg": h.data["Instrument Parameters"][0]["Zero"][1],
        "W": h.data["Instrument Parameters"][0]["W"][1],
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
    }
    out.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("ids", nargs="+")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(refine(args.ids, args.out.resolve()), indent=2))


if __name__ == "__main__":
    main()
