#!/usr/bin/env python3
"""Try physically constrained profile and displacement refinements."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def show(gpx, label):
    h = gpx.histogram(0)
    print("\n", label, "Rwp", h.get_wR(), "residuals", h.data["data"][0])
    print("mass", h.ComputeMassFracs())
    print("inst", h.data["Instrument Parameters"][0])
    for p in gpx.phases():
        print(p.name, p.get_cell(), p.data["Histograms"][h.name]["Scale"])
        for a in p.atoms():
            print(" ", a.label, a.element, a.coordinates, a.uiso, a.refinement_flags)


def main():
    src = Path(".tmp/trial_3phase.gpx").resolve()
    dst = Path(".tmp/continued_3phase.gpx").resolve()
    gpx = G2sc.G2Project(str(src), newgpx=str(dst))
    h = gpx.histogram(0)
    inst = h.data["Instrument Parameters"][0]

    # X/Y Lorentzian instrument terms are inseparable from the phase-size
    # terms without a profile standard. Keep them at zero and retain the
    # independently useful U/V/W angular dependence.
    for key in ("X", "Y"):
        inst[key][1] = 0.0
        inst[key][2] = False
    gpx.refine()
    show(gpx, "physical profile")

    # The reference scheelite CIF omitted displacement parameters and was
    # imported with Uiso=0.01 A^2. Refine the two heavy-atom Uiso values;
    # oxygen contributes little to Cu X-ray intensities and remains fixed.
    main_phase = gpx.phase("PbWO4_scheelite")
    for atom_index, atom in enumerate(main_phase.atoms()):
        if atom.element in ("Pb", "W"):
            atom.refinement_flags = "U"
            gpx.set_Controls("parmMin", 0.0, variable=f"0::AUiso:{atom_index}")
            gpx.set_Controls("parmMax", 0.03, variable=f"0::AUiso:{atom_index}")
    gpx.refine()
    show(gpx, "heavy atom Uiso")

    gpx.refine()
    gpx.save()
    show(gpx, "final")


if __name__ == "__main__":
    main()
