#!/usr/bin/env python3
"""Export all requested deliverables from the selected final GSAS-II model."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE_GPX = ROOT / ".tmp" / "cmp_shl.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_INFO = {
    "PbWO4_scheelite": {
        "name": "lead tungstate (scheelite/stolzite)",
        "formula": "PbWO4",
        "space_group": "I 41/a",
        "space_group_number": 88,
        "source_structure": "COD 9009811",
        "cif_path": "phase_1_PbWO4.cif",
    },
    "PbO_massicot": {
        "name": "lead(II) oxide (massicot)",
        "formula": "PbO",
        "space_group": "Pbcm",
        "space_group_number": 57,
        "source_structure": "COD 2310433",
        "cif_path": "phase_2_PbO_massicot.cif",
    },
    "WO3_monoclinic": {
        "name": "tungsten(VI) oxide (gamma-monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/n",
        "space_group_number": 14,
        "source_structure": "COD 1528915",
        "cif_path": "phase_3_WO3_monoclinic.cif",
    },
}


def plain_floats(values):
    return {key: float(value) for key, value in values.items()}


def main() -> None:
    gpx = G2sc.G2Project(str(SOURCE_GPX), newgpx=str(FINAL_GPX))
    gpx.save()
    hist = gpx.histogram(0)

    fractions = hist.ComputeMassFracs()
    phases_json = []
    for phase in gpx.phases():
        info = dict(PHASE_INFO[phase.name])
        cif_path = ROOT / info["cif_path"]
        phase.export_CIF(str(cif_path))
        cell, cell_esd = phase.get_cell_and_esd()
        fraction, fraction_esd = fractions[phase.name]
        info.update(
            {
                "phase_id": phase.name,
                "cif_path": info["cif_path"],
                "weight_fraction": float(fraction),
                "weight_fraction_esd_statistical": float(fraction_esd),
                "weight_percent": 100.0 * float(fraction),
                "weight_percent_esd_statistical": 100.0 * float(fraction_esd),
                "cell": plain_floats(cell),
                "cell_esd": plain_floats(cell_esd),
            }
        )
        phases_json.append(info)

    x = np.asarray(hist.getdata("X"), dtype=float)
    observed = np.asarray(hist.getdata("Yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("Ycalc"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_observed_minus_calculated",
                "calculated_background",
            ]
        )
        writer.writerows(
            zip(x, observed, calculated, difference, background, strict=True)
        )

    residuals = hist.data["data"][0]
    rwp = float(hist.get_wR())
    rexp = float(residuals["wRmin"])
    reduced_chi_squared = (rwp / rexp) ** 2
    phase_rf = {
        phase.name: {
            "Rf_percent": float(residuals[f"{phase.id}:0:Rf"]),
            "Rf_squared_percent": float(residuals[f"{phase.id}:0:Rf^2"]),
        }
        for phase in gpx.phases()
    }
    result = {
        "phases": phases_json,
        "quantification_basis": (
            "Weight fractions are normalized to sum to 1 over the modeled "
            "crystalline phases; amorphous or unidentified material is not quantified."
        ),
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": rexp,
            "goodness_of_fit": math.sqrt(reduced_chi_squared),
            "reduced_chi_squared": reduced_chi_squared,
            "durbin_watson": float(residuals["Durbin-Watson"]),
            "n_observations": int(residuals["Nobs"]),
            "n_refined_parameters": len(gpx.data["Covariance"]["data"]["varyList"]),
            "phase_R_factors": phase_rf,
        },
        "measurement_model": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "fit_range_two_theta_deg": [float(x[0]), float(x[-1])],
            "difference_definition": "observed_intensity - calculated_intensity",
            "weights": (
                "Poisson proxy 1/I assigned by GSAS-II because pointwise "
                "standard uncertainties were not supplied."
            ),
        },
        "profile_path": "fit.csv",
        "gsas_project_path": "final.gpx",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
