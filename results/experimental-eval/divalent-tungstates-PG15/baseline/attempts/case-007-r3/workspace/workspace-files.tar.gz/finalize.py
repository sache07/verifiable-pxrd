#!/usr/bin/env python3
"""Create the final GSAS-II project and requested QPA deliverables."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_GPX = ROOT / ".tmp" / "rietveld" / "profile_ratio05.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_INFO = {
    "MgWO4": {
        "name": "MgWO4",
        "formula": "MgWO4",
        "cif": "MgWO4.cif",
        "reference": "COD 9013902",
    },
    "WO3_P21c_2311041": {
        "name": "WO3",
        "formula": "WO3",
        "cif": "WO3.cif",
        "reference": "COD 2311041 (Loopstra and Boldrini, neutron diffraction)",
    },
    "MgO": {
        "name": "MgO",
        "formula": "MgO",
        "cif": "MgO.cif",
        "reference": "COD 9000499",
    },
}


def plain_array(values: np.ndarray) -> np.ndarray:
    """Convert a GSAS-II masked array to an ordinary float array."""
    return np.asarray(np.ma.filled(values, np.nan), dtype=float)


def fmt_cell(cell: dict[str, float]) -> str:
    if abs(cell["angle_beta"] - 90.0) < 1e-6:
        if (
            abs(cell["length_a"] - cell["length_b"]) < 1e-6
            and abs(cell["length_a"] - cell["length_c"]) < 1e-6
        ):
            return f"a = {cell['length_a']:.6f} A"
        return (
            f"a = {cell['length_a']:.6f}, b = {cell['length_b']:.6f}, "
            f"c = {cell['length_c']:.6f} A"
        )
    return (
        f"a = {cell['length_a']:.6f}, b = {cell['length_b']:.6f}, "
        f"c = {cell['length_c']:.6f} A, beta = {cell['angle_beta']:.5f} deg"
    )


def main() -> None:
    if not SOURCE_GPX.exists():
        raise FileNotFoundError(SOURCE_GPX)

    project = G2sc.G2Project(gpxfile=str(SOURCE_GPX))
    project.save(str(FINAL_GPX))
    hist = project.histogram(0)

    # Include every supplied point in the final calculation. Half-step padding
    # avoids dropping an endpoint through integer search/slicing conventions.
    x = plain_array(hist.getdata("x"))
    step = float(np.median(np.diff(x)))
    hist.Limits("lower", float(x[0] - step / 2.0))
    hist.Limits("upper", float(x[-1] + step / 2.0))

    # Preserve the wavelengths and intensity ratio reported with the data.
    inst = hist.InstrumentParameters
    inst["Lam1"][1:3] = [1.540598, False]
    inst["Lam2"][1:3] = [1.544426, False]
    inst["I(L2)/I(L1)"][1:3] = [0.5, False]

    project.set_Controls("cycles", 12)
    for _ in range(3):
        project.do_refinements([{}])
        rvals = project.data["Covariance"]["data"].get("Rvals", {})
        if rvals.get("converged") and abs(rvals.get("Max shft/sig", math.inf)) < 0.1:
            break
    project.save()

    # Export structural models and collect quantitative results from the same
    # in-memory project that generated the calculated profile.
    mass_fractions = hist.ComputeMassFracs()
    hmeta = hist.data["data"][0]
    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    result_phases: list[dict] = []
    report_rows: list[str] = []

    for index, phase in enumerate(project.phases()):
        info = PHASE_INFO[phase.name]
        cif_path = ROOT / info["cif"]
        phase.export_CIF(str(cif_path))
        value, esd = mass_fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        space_group = phase.data["General"]["SGData"]["SpGrp"].strip()
        phase_entry = {
            "name": info["name"],
            "formula": info["formula"],
            "space_group": space_group,
            "cif_path": info["cif"],
            "weight_fraction": float(value),
            "weight_fraction_formal_esd": float(esd),
            "weight_percent": float(100.0 * value),
            "weight_percent_formal_esd": float(100.0 * esd),
            "cell": {key: float(val) for key, val in cell.items()},
            "cell_formal_esd": {key: float(val) for key, val in cell_esd.items()},
            "reference_structure": info["reference"],
            "fit": {
                "R_F_percent": float(hmeta[f"{index}:0:Rf"]),
                "R_F_squared_percent": float(hmeta[f"{index}:0:Rf^2"]),
                "reflections": int(hmeta[f"{index}:0:Nref"]),
            },
        }
        result_phases.append(phase_entry)
        report_rows.append(
            f"| {info['name']} | {space_group} | {100.0 * value:.2f} | "
            f"{100.0 * esd:.2f} | {fmt_cell(cell)} |"
        )

    # Profile arrays are updated by the last GSAS-II refinement.
    x = plain_array(hist.getdata("x"))
    observed = plain_array(hist.getdata("yobs"))
    calculated = plain_array(hist.getdata("ycalc"))
    background = plain_array(hist.getdata("background"))
    difference = observed - calculated
    if not all(np.all(np.isfinite(a)) for a in (x, observed, calculated, background, difference)):
        raise RuntimeError("Non-finite value in final profile")

    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        for values in zip(x, observed, calculated, difference, background):
            writer.writerow(
                [
                    f"{values[0]:.8f}",
                    f"{values[1]:.8f}",
                    f"{values[2]:.8f}",
                    f"{values[3]:.8f}",
                    f"{values[4]:.8f}",
                ]
            )

    fit_statistics = {
        "Rwp_percent": float(hmeta["wR"]),
        "Rp_percent": float(hmeta["R"]),
        "R_background_percent": float(hmeta["Rb"]),
        "weighted_R_background_percent": float(hmeta["wRb"]),
        "Rexp_percent": float(hmeta["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "reduced_chi_squared": float(rvals["GOF"] ** 2),
        "chi_squared_sum": float(rvals["chisq"]),
        "durbin_watson": float(hmeta["Durbin-Watson"]),
        "observations": int(rvals["Nobs"]),
        "refined_parameters": int(rvals["Nvars"]),
        "two_theta_range_deg": [float(x[0]), float(x[-1])],
        "converged": bool(rvals["converged"]),
        "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
    }
    result = {
        "analysis": "GSAS-II Rietveld refinement",
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "radiation": {
            "type": "Cu Kalpha doublet",
            "wavelength_1_angstrom": 1.540598,
            "wavelength_2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_intensity_ratio": 0.5,
        },
        "phase_fraction_basis": "normalized over the modeled crystalline phases",
        "phases": result_phases,
        "fit_statistics": fit_statistics,
        "profile_columns": {
            "difference_counts": "observed_counts - calculated_counts",
            "background_counts": "refined GSAS-II background contribution",
        },
        "uncertainty_note": (
            "Reported phase-fraction esds are formal least-squares values. "
            "Systematic uncertainty is larger because no calibrated instrumental "
            "profile or supplied intensity uncertainties were available."
        ),
    }
    with (ROOT / "result.json").open("w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, sort_keys=False)
        stream.write("\n")

    report = f"""# Quantitative phase analysis

## Result

The pattern is described by three crystalline phases. Fractions are normalized over those modeled crystalline phases; they do not measure any amorphous content.

| Phase | Space group | wt% | Formal esd (wt%) | Refined cell |
|---|---:|---:|---:|---|
{chr(10).join(report_rows)}

The refined profile gives Rwp = {fit_statistics['Rwp_percent']:.2f}%, Rp = {fit_statistics['Rp_percent']:.2f}%, Rexp = {fit_statistics['Rexp_percent']:.2f}%, and GSAS-II goodness of fit = {fit_statistics['goodness_of_fit']:.2f} over {fit_statistics['observations']} observations. `fit.csv` defines the difference as observed minus calculated.

## Evidence

The dominant wolframite-type MgWO4 model accounts for the main low-angle reflection at about 15.93 deg 2theta and the dense peak set through the full scan. Monoclinic WO3 is required by the resolved group near 23.45, 24.00, and 24.68 deg and by many weaker reflections. Rock-salt MgO is independently supported by its complete allowed sequence near 37.27, 43.20, 62.63, 74.95, 78.90, and 94.25 deg; omitting it leaves coherent positive residuals at those positions. This assemblage is chemically consistent with MgO + WO3 -> MgWO4 at 900 degC with residual starting oxides.

Reference models were COD 9013902 (MgWO4, P2/c), COD 2311041 (WO3, P21/c; neutron structure), and COD 9000499 (MgO, Fm-3m). The WO3 CIF retains a valid historical high-beta P21/c cell setting. Its W-O distances remain chemically plausible, as do the Mg/W coordination polyhedra in MgWO4.

## Refinement and uncertainty

GSAS-II used the supplied Cu Kalpha wavelengths (1.540598/1.544426 A) with Kalpha2/Kalpha1 fixed at 0.500. Because the input supplied no point uncertainties, sigma = sqrt(max(counts, 1)) was assigned. Refined terms included phase scales and cells, zero offset, a 15-term Chebyshev background, and empirical U/V/W peak-width terms. Phase-dependent isotropic size/strain terms were estimated in preliminary cycles and then held fixed; they should not be interpreted as calibrated crystallite sizes or microstrains. MgWO4 coordinates and the two WO3 W sites were refined in staged cycles; WO3 oxygen coordinates were retained from the neutron reference and all WO3 sites shared one refined isotropic displacement parameter.

The formal phase-fraction esds (0.11-0.16 wt%) are conditional and underestimate total uncertainty. Peak-profile alternatives changed individual fractions by at most about 0.4 wt%, but the lack of a measured instrumental profile, the inferred counting statistics, strong profile-parameter correlation, and serially correlated residuals make approximately +/-1 wt% absolute a more realistic working uncertainty. Oxygen coordinates in the minor WO3 phase are not independently determined by this laboratory X-ray pattern. Trace phases may remain below detection, and no amorphous fraction can be quantified without an internal standard.
"""
    (ROOT / "report.md").write_text(report, encoding="utf-8")

    # Saving once more records final.gpx as the project associated with all
    # exported artifacts.
    project.save()
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
