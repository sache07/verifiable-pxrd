#!/usr/bin/env python3
"""Exploratory GSAS-II refinements for phase-model selection."""

from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
DATA_CSV = ROOT / "inputs" / "pattern.csv"
WORK = ROOT / ".tmp" / "rietveld"
WORK.mkdir(parents=True, exist_ok=True)

COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PHASE_FILES = {
    "MgWO4": COD / "9/01/39/9013902.cif",
    "WO3": COD / "1/52/89/1528915.cif",
    "WO3_P1": COD / "2/10/62/2106293.cif",
    "WO3_P21c_good": WORK / "wo3_2311041_reduced2.cif",
    "WO3_P21c_2311041": COD / "2/31/10/2311041.cif",
    "MgO": COD / "9/00/04/9000499.cif",
}


def prepare_inputs() -> tuple[Path, Path]:
    """Convert the supplied CSV to xye and write measured Cu Ka parameters."""
    xye = WORK / "pattern.xye"
    inst = WORK / "cu_ka.instprm"
    data = np.genfromtxt(DATA_CSV, delimiter=",", names=True)
    with xye.open("w", encoding="ascii") as stream:
        stream.write("# pattern.csv; Poisson counting s.u. assigned as sqrt(I)\n")
        for x, y in zip(data["two_theta_deg"], data["intensity"]):
            stream.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    inst.write_text(
        "#GSAS-II instrument parameter file for supplied Cu Kalpha data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.28;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:5.0;V:-2.0;W:25.0;X:0.0;Y:5.0;Z:0.0;SH/L:0.002\n",
        encoding="ascii",
    )
    return xye, inst


def summarize(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"SUMMARY {label} residuals={hist.residuals}")
    print("INSTRUMENT", {k: v for k, v in hist.InstrumentParameters.items() if k in (
        "Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"
    )})
    print("BACKGROUND", hist.Background[0])
    for phase in project.phases():
        print("PHASE", phase.name, phase.get_cell(), phase.data["Histograms"][hist.name])
    try:
        print("MASSFRACS", hist.ComputeMassFracs())
    except Exception as exc:
        print("MASSFRACS_ERROR", repr(exc))


def run(phases: list[str], tag: str) -> None:
    xye, inst = prepare_inputs()
    gpx_path = WORK / f"{tag}.gpx"
    project = G2sc.G2Project(newgpx=str(gpx_path))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    for phase_name in phases:
        project.add_phase(
            str(PHASE_FILES[phase_name]),
            phasename=phase_name,
            histograms=[hist],
            fmthint="CIF",
        )
    # Good initial values prevent the phase-scale/background refinement from
    # becoming trapped before the cell/zero corrections are introduced.
    hist.InstrumentParameters["Zero"][0:2] = [0.28, 0.28]
    hist.InstrumentParameters["U"][0:2] = [5.0, 5.0]
    hist.InstrumentParameters["V"][0:2] = [-2.0, -2.0]
    hist.InstrumentParameters["W"][0:2] = [25.0, 25.0]
    hist.InstrumentParameters["X"][0:2] = [0.0, 0.0]
    hist.InstrumentParameters["Y"][0:2] = [5.0, 5.0]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.Background[0][:] = ["chebyschev-1", False, 10] + [800.0] + [0.0] * 9
    # Give every phase a nonzero starting contribution.
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][0] = 1.0 / len(phases)
    project.set_Controls("cycles", 12)
    project.save()

    recipes = [
        {"set": {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 10},
                  "Scale": True}},
        {"set": {"Cell": True, "Instrument Parameters": ["Zero"]}},
        {"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}},
        {"set": {"Size": {"type": "isotropic", "value": 1.0, "refine": True},
                  "Mustrain": {"type": "isotropic", "refine": True}}},
    ]
    for index, recipe in enumerate(recipes, start=1):
        print(f"\n=== REFINEMENT {index} {recipe} ===")
        try:
            project.do_refinements([recipe])
        except Exception as exc:
            print("REFINEMENT_ERROR", index, repr(exc))
            break
        summarize(project, f"step{index}")
    project.save()
    summarize(project, "final")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phases", nargs="+", choices=sorted(PHASE_FILES))
    parser.add_argument("--tag", default=None)
    args = parser.parse_args()
    run(args.phases, args.tag or "_".join(args.phases))


if __name__ == "__main__":
    main()
