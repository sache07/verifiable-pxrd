#!/usr/bin/env python3
"""Refine accepted phase coordinates from the best bounded profile checkpoint."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def atom_state(phase: G2sc.G2Phase) -> list[dict]:
    return [
        {
            "label": atom.label,
            "element": atom.element,
            "coordinates": list(atom.coordinates),
            "uiso": atom.uiso,
            "flags": atom.refinement_flags,
        }
        for atom in phase.atoms()
    ]


def state(gpx: G2sc.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    return {
        "label": label,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "atoms": atom_state(phase),
                "profile": {
                    key: phase.data["Histograms"][hist.name][key]
                    for key in ["Scale", "Size", "Mustrain", "Pref.Ori."]
                },
            }
            for phase in gpx.phases()
        },
    }


def refine_and_checkpoint(
    gpx: G2sc.G2Project,
    output: Path,
    label: str,
    log: list[dict],
) -> None:
    gpx.refine(makeBack=False)
    gpx.save()
    checkpoint = output.with_name(f"{output.stem}_{label}.gpx")
    shutil.copy2(output, checkpoint)
    item = state(gpx, label)
    log.append(item)
    print(json.dumps(item, default=float), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--preserve-uiso", action="store_true")
    args = parser.parse_args()
    source = Path(".tmp/physical/both.bak0.gpx")
    stem = "structure_sourceuiso" if args.preserve_uiso else "structure"
    output = Path(".tmp/refinement") / f"{stem}.gpx"
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()

    gpx = G2sc.G2Project(str(source), newgpx=str(output))
    gpx.save()
    gpx.set_Controls("cycles", 10)
    hist = gpx.histogram(0)

    # Keep parameters that reached their physical bounds fixed. Continue the
    # supported size/Mn-strain and scale/background/cell/calibration terms.
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    phases = gpx.phases()
    phases[0].clear_HAP_refinements({"Mustrain": True})
    gpx.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []

    # Optionally initialize the source WO3 CIF's unreported Uiso. A parallel
    # branch retains source values so coordinate evidence is not conflated
    # with a displacement-parameter assumption.
    for atom in phases[0].atoms():
        if not args.preserve_uiso:
            atom.uiso = 0.01
        atom.refinement_flags = " "
    for atom in phases[1].atoms():
        atom.refinement_flags = " "

    log = [state(gpx, "start")]
    if not args.preserve_uiso:
        refine_and_checkpoint(gpx, output, "uiso_initialized", log)

    # Heavy atoms first.
    for phase in phases:
        for atom in phase.atoms():
            if atom.element in {"W", "Mn"}:
                atom.refinement_flags = "X"
    refine_and_checkpoint(gpx, output, "heavy_coordinates", log)

    # The single oxygen orbit in bixbyite is well constrained by symmetry and
    # is introduced before the lower-symmetry WO3 oxygen framework.
    for atom in phases[1].atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    refine_and_checkpoint(gpx, output, "mn_oxygen", log)

    for atom in phases[0].atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    refine_and_checkpoint(gpx, output, "all_coordinates", log)

    gpx.save()
    output.with_suffix(".json").write_text(json.dumps(log, indent=2, default=float) + "\n")
    for phase in phases:
        phase.export_CIF(str(output.with_name(f"screen_{phase.name}.cif")))


if __name__ == "__main__":
    main()
