#!/usr/bin/env python3
"""Build and refine comparable GSAS-II branches for candidate phase models."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_inputs(work: Path) -> tuple[Path, Path]:
    work.mkdir(parents=True, exist_ok=True)
    xye = work / "pattern.xye"
    with Path("inputs/pattern.csv").open(newline="") as source, xye.open("w") as out:
        reader = csv.DictReader(source)
        for row in reader:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            out.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")

    inst = work / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for lab CuKa data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "mass": phase.data["General"]["Mass"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    return {
        "label": label,
        "residuals": hist.residuals,
        "sample": hist.SampleParameters,
        "instrument": hist.InstrumentParameters,
        "background": hist.Background[0],
        "phases": phases,
    }


def refine(project: G2sc.G2Project, label: str, log: list[dict]) -> None:
    project.refine(makeBack=False)
    project.save()
    state = snapshot(project, label)
    log.append(state)
    print(json.dumps(state, default=float), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", required=True)
    parser.add_argument("--mn2o3", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--work", default=".tmp/branches")
    args = parser.parse_args()

    work = Path(args.work)
    xye, inst = prepare_inputs(work)
    gpx_path = work / f"{args.name}.gpx"
    if gpx_path.exists():
        gpx_path.unlink()

    project = G2sc.G2Project(newgpx=str(gpx_path))
    project.set_Controls("cycles", 8)
    hist = project.add_powder_histogram(
        str(xye), str(inst), fmthint="xye"
    )
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 12,
            },
        }
    )
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"][0] = -500.0
    hist.SampleParameters["Scale"][1] = False

    wo3 = project.add_phase(
        str(cod_path(args.wo3)),
        phasename=f"WO3_COD_{args.wo3}",
        histograms=[hist],
        fmthint="CIF",
    )
    mn2o3 = project.add_phase(
        str(cod_path(args.mn2o3)),
        phasename=f"Mn2O3_COD_{args.mn2o3}",
        histograms=[hist],
        fmthint="CIF",
    )
    wo3.HAPvalue("Scale", 1.0)
    mn2o3.HAPvalue("Scale", 0.2)
    wo3.set_HAP_refinements({"Scale": True})
    mn2o3.set_HAP_refinements({"Scale": True})

    project.save()
    log: list[dict] = [snapshot(project, "initial")]

    # First stabilize intensity/background with the specimen shift near the
    # value estimated from the coherent peak displacement.
    refine(project, "scale_background", log)

    # Refine specimen height before allowing cell metrics to move.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "shift", log)

    # Candidate models are compared after the same physically necessary cell
    # and calibration degrees of freedom have been introduced.
    wo3.set_refinements({"Cell": True})
    mn2o3.set_refinements({"Cell": True})
    refine(project, "cells", log)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "zero", log)

    # Common instrument broadening only; phase-specific broadening is deferred
    # until the phase inventory and topology have been accepted.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X"]})
    refine(project, "common_profile", log)

    project.save()
    (work / f"{args.name}.json").write_text(
        json.dumps(log, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
