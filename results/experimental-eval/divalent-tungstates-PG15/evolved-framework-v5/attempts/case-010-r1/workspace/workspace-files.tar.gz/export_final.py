#!/usr/bin/env python3
"""Export all submission artifacts from the selected physical GSAS-II model."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE = Path(".tmp/finalsearch/p0_mustrain_110.gpx")
FINAL_GPX = Path("final.gpx")

PHASE_INFO = {
    "WO3_COD_2311041": {
        "name": "monoclinic tungsten(VI) oxide",
        "formula": "WO3",
        "cif_path": "phase_WO3_monoclinic.cif",
        "reference_database": "Crystallography Open Database",
        "reference_id": "2311041",
    },
    "Mn2O3_COD_1514230": {
        "name": "bixbyite manganese(III) oxide",
        "formula": "Mn2O3",
        "cif_path": "phase_Mn2O3_bixbyite.cif",
        "reference_database": "Crystallography Open Database",
        "reference_id": "1514230",
    },
}


def scalar_array(hist: G2sc.G2PwdrData, key: str) -> np.ndarray:
    return np.asarray(hist.getdata(key), dtype=float)


def main() -> None:
    if FINAL_GPX.exists():
        FINAL_GPX.unlink()
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL_GPX))
    project.save()
    hist = project.histogram(0)

    x = scalar_array(hist, "X")
    yobs = scalar_array(hist, "Yobs")
    ycalc = scalar_array(hist, "Ycalc")
    background = scalar_array(hist, "Background")
    difference = yobs - ycalc
    weights = scalar_array(hist, "Yweight")

    with Path("fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed",
                "calculated",
                "difference",
                "background",
            ]
        )
        for row in zip(x, yobs, ycalc, difference, background):
            writer.writerow(
                [f"{row[0]:.8f}", *(f"{value:.8f}" for value in row[1:])]
            )

    mass_fractions = hist.ComputeMassFracs()
    residuals = hist.residuals
    phase_entries = []
    for index, phase in enumerate(project.phases()):
        info = PHASE_INFO[phase.name]
        phase.export_CIF(info["cif_path"])
        fraction, fraction_esd = mass_fractions[phase.name]
        sg = phase.data["General"]["SGData"]["SpGrp"]
        phase_entries.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "space_group": sg,
                "cif_path": info["cif_path"],
                "weight_fraction": fraction,
                "weight_fraction_esd": fraction_esd,
                "weight_percent": 100.0 * fraction,
                "weight_percent_esd": 100.0 * fraction_esd,
                "cell": phase.get_cell(),
                "reference": {
                    "database": info["reference_database"],
                    "id": info["reference_id"],
                },
                "bragg_R_F_percent": residuals[f"{index}:0:Rf"],
                "bragg_R_F_squared_percent": residuals[f"{index}:0:Rf^2"],
            }
        )

    n_points = len(x)
    n_parameters = 25
    chi_square = float(np.sum(weights * difference**2))
    degrees_of_freedom = n_points - n_parameters
    reduced_chi_square = chi_square / degrees_of_freedom
    result = {
        "phases": phase_entries,
        "fraction_basis": (
            "normalized over the modeled crystalline phases; amorphous or "
            "unmodeled content is not quantified"
        ),
        "fit_statistics": {
            "Rwp_percent": residuals["wR"],
            "Rp_percent": residuals["R"],
            "Rexp_percent": residuals["wRmin"],
            "goodness_of_fit": math.sqrt(reduced_chi_square),
            "chi_square": chi_square,
            "reduced_chi_square": reduced_chi_square,
            "background_R_percent": residuals["Rb"],
            "weighted_background_R_percent": residuals["wRb"],
            "n_observations": n_points,
            "n_refined_parameters": n_parameters,
            "degrees_of_freedom": degrees_of_freedom,
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
        },
        "profile_path": "fit.csv",
        "gsas_project_path": "final.gpx",
        "measurement_model": {
            "radiation": "Cu K-alpha1/K-alpha2 doublet",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "intensity_weighting": (
                "Poisson approximation sigma=sqrt(max(observed counts,1)); "
                "input supplied no pointwise standard uncertainties"
            ),
        },
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
