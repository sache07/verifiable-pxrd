#!/usr/bin/env python3
"""Make a stable full-grid checkpoint and screen bounded uniaxial broadening."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SOURCE = Path(".tmp/physical/both.bak0.gpx")
OUTDIR = Path(".tmp/finalsearch")


def set_bound(gpx: G2sc.G2Project, var: str, low: float, high: float) -> None:
    gpx.set_Controls("parmMin", low, variable=var)
    gpx.set_Controls("parmMax", high, variable=var)


def snapshot(gpx: G2sc.G2Project, label: str, path: Path) -> dict:
    hist = gpx.histogram(0)
    phases = {}
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return {
        "label": label,
        "project": str(path),
        "limits": hist.data.get("Limits"),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: hist.InstrumentParameters[key]
            for key in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "SH/L"]
        },
        "sample": {
            key: hist.SampleParameters[key]
            for key in ["Shift", "SurfRoughA", "SurfRoughB"]
        },
        "phases": phases,
    }


def prepare_baseline() -> tuple[G2sc.G2Project, Path]:
    output = OUTDIR / "baseline.gpx"
    if output.exists():
        output.unlink()
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    gpx.set_Controls("cycles", 15)
    gpx.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    hist = gpx.histogram(0)
    x = hist.getdata("X")
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})

    # Retain the accepted bounded model, but remove parameters that ended a
    # trial at a limit and all unsupported preferred orientation refinements.
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L"]}
    )
    # Zero and specimen displacement are 99.98% correlated for this single
    # scan. Use the nominal zero and let the physically interpretable specimen
    # displacement carry the peak-position correction.
    hist.InstrumentParameters["Zero"][1] = 0.0
    for phase in gpx.phases():
        phase.clear_HAP_refinements({"Pref.Ori.": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
    # The monoclinic phase's isotropic microstrain ended at the lower bound;
    # keep that physical boundary value fixed while screening anisotropy.
    gpx.phases()[0].clear_HAP_refinements({"Mustrain": True})
    gpx.save()
    return gpx, output


def refine_twice(gpx: G2sc.G2Project, label: str, output: Path) -> list[dict]:
    states = []
    for iteration in (1, 2):
        gpx.refine(makeBack=False)
        gpx.save()
        item = snapshot(gpx, f"{label}_{iteration}", output)
        states.append(item)
        print(json.dumps(item, default=float), flush=True)
    return states


def screen_uniaxial(
    baseline: Path, phase_index: int, axis: tuple[int, int, int]
) -> dict:
    tag = f"p{phase_index}_mustrain_{axis[0]}{axis[1]}{axis[2]}"
    output = OUTDIR / f"{tag}.gpx"
    if output.exists():
        output.unlink()
    gpx = G2sc.G2Project(str(baseline), newgpx=str(output))
    gpx.set_Controls("cycles", 15)
    gpx.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    hist = gpx.histogram(0)
    phase = gpx.phases()[phase_index]
    hap = phase.data["Histograms"][hist.name]
    start = max(300.0, float(hap["Mustrain"][1][0]))
    phase.setSampleProfile(
        hist, "microstrain", "uniaxial", start, start, axis, LGmix=1.0
    )
    # GSAS-II's scripting wrapper accepts one uniaxial component at a time;
    # set both component flags directly after defining the profile.
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    set_bound(gpx, f"{phase_index}:0:Mustrain;i", 300.0, 8000.0)
    set_bound(gpx, f"{phase_index}:0:Mustrain;a", 300.0, 8000.0)
    gpx.save()
    states = refine_twice(gpx, tag, output)
    return states[-1]


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    baseline, baseline_path = prepare_baseline()
    baseline_states = refine_twice(baseline, "baseline", baseline_path)
    results = {"baseline": baseline_states, "uniaxial": []}

    for axis in [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (1, 1, 1)]:
        results["uniaxial"].append(screen_uniaxial(baseline_path, 0, axis))
    for axis in [(1, 0, 0), (1, 1, 0), (1, 1, 1)]:
        results["uniaxial"].append(screen_uniaxial(baseline_path, 1, axis))

    (OUTDIR / "results.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
