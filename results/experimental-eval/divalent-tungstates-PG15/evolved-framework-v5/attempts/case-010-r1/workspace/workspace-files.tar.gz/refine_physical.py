#!/usr/bin/env python3
"""Refine bounded, physically interpretable profile models for accepted phases."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def state(gpx: G2sc.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    result = {
        "label": label,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs() if hist.residuals else {},
        "sample": {
            key: hist.SampleParameters[key]
            for key in ["Shift", "SurfRoughA", "SurfRoughB"]
        },
        "instrument": {
            key: hist.InstrumentParameters[key]
            for key in ["Zero", "Polariz.", "U", "V", "W", "X", "SH/L"]
        },
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return result


def do_refine(gpx: G2sc.G2Project, label: str, log: list[dict]) -> None:
    gpx.refine(makeBack=False)
    gpx.save()
    item = state(gpx, label)
    log.append(item)
    print(json.dumps(item, default=float), flush=True)


def set_bound(gpx: G2sc.G2Project, var: str, low: float, high: float) -> None:
    gpx.set_Controls("parmMin", low, variable=var)
    gpx.set_Controls("parmMax", high, variable=var)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["size", "strain", "both"], default="both")
    parser.add_argument("--name", default="physical")
    args = parser.parse_args()

    source = Path(".tmp/branches/p21c_ia3.bak0.gpx")
    output = Path(".tmp/physical") / f"{args.name}.gpx"
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()

    gpx = G2sc.G2Project(str(source), newgpx=str(output))
    gpx.save()
    gpx.set_Controls("cycles", 10)
    hist = gpx.histogram(0)

    # Reset the common profile to values inside the stated instrument domain.
    hist.clear_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]})
    starts = {"U": 20.0, "V": 0.0, "W": 20.0, "X": 2.0, "SH/L": 0.03}
    for key, value in starts.items():
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False

    # Keep the already indexed calibration/cells active, but constrain them to
    # the laboratory's declared physical ranges.
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
    }
    for var, (low, high) in bounds.items():
        set_bound(gpx, var, low, high)

    phases = gpx.phases()
    for index, phase in enumerate(phases):
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        phase.setSampleProfile(hist, "size", "isotropic", 0.30, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=1.0)
        set_bound(gpx, f"{index}:0:Size;i", 0.04, 1.5)
        set_bound(gpx, f"{index}:0:Mustrain;i", 300.0, 8000.0)
        set_bound(gpx, f"{index}:0:Scale", 1.0e-8, 1000.0)

    log = [state(gpx, "reset")]
    do_refine(gpx, "reset_profile", log)

    if args.mode in ("size", "both"):
        for phase in phases:
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "refine": True}}
            )
        do_refine(gpx, "phase_size", log)

    if args.mode in ("strain", "both"):
        for phase in phases:
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
        do_refine(gpx, "phase_microstrain", log)

    # Add one supported common-profile complexity at a time. V remains fixed at
    # zero because it is not part of the stated instrument distribution.
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    do_refine(gpx, "instrument_WX", log)
    hist.set_refinements({"Instrument Parameters": ["U"]})
    do_refine(gpx, "instrument_U", log)
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    do_refine(gpx, "axial_divergence", log)

    gpx.save()
    output.with_suffix(".json").write_text(json.dumps(log, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
