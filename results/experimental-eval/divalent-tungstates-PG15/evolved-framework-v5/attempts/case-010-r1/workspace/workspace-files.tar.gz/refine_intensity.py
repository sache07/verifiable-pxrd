#!/usr/bin/env python3
"""Test grouped Uiso and bounded intensity corrections on the physical model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def summarize(gpx: G2sc.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    return {
        "label": label,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "sample": {
            key: hist.SampleParameters[key]
            for key in ["Shift", "SurfRoughA", "SurfRoughB"]
        },
        "instrument": {
            key: hist.InstrumentParameters[key]
            for key in ["Zero", "Polariz.", "U", "V", "W", "X", "SH/L"]
        },
        "atoms": {
            phase.name: [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "uiso": atom.uiso,
                    "coordinates": list(atom.coordinates),
                }
                for atom in phase.atoms()
            ]
            for phase in gpx.phases()
        },
    }


def checkpoint(
    gpx: G2sc.G2Project,
    output: Path,
    label: str,
    log: list[dict],
) -> None:
    gpx.refine(makeBack=False)
    gpx.save()
    shutil.copy2(output, output.with_name(f"{output.stem}_{label}.gpx"))
    item = summarize(gpx, label)
    log.append(item)
    print(json.dumps(item, default=float), flush=True)


def bound(gpx: G2sc.G2Project, variable: str, low: float, high: float) -> None:
    gpx.set_Controls("parmMin", low, variable=variable)
    gpx.set_Controls("parmMax", high, variable=variable)


def main() -> None:
    source = Path(".tmp/physical/both.bak0.gpx")
    output = Path(".tmp/refinement/intensity.gpx")
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()
    gpx = G2sc.G2Project(str(source), newgpx=str(output))
    gpx.save()
    gpx.set_Controls("cycles", 10)
    hist = gpx.histogram(0)

    hist.clear_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    gpx.phases()[0].clear_HAP_refinements({"Mustrain": True})
    gpx.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []

    # Refine one Uiso for each element in each phase. This avoids unstable
    # site-by-site displacement parameters while allowing the heavy and oxygen
    # sublattices to have different thermal motion.
    for phase_index, phase in enumerate(gpx.phases()):
        by_element: dict[str, list[str]] = {}
        for atom_index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            atom.uiso = 0.005 if atom.element in {"W", "Mn"} else 0.010
            variable = f"{phase_index}::AUiso:{atom_index}"
            by_element.setdefault(atom.element, []).append(variable)
            bound(gpx, variable, 0.001, 0.030)
        for variables in by_element.values():
            if len(variables) > 1:
                gpx.add_EquivConstr(tuple(variables), reloadIdx=False)

    log = [summarize(gpx, "start")]
    checkpoint(gpx, output, "grouped_uiso", log)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    bound(gpx, ":0:Polariz.", 0.5, 1.0)
    checkpoint(gpx, output, "polarization", log)

    hist.SampleParameters["SurfRoughA"][0] = 0.10
    hist.SampleParameters["SurfRoughB"][0] = 0.10
    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    bound(gpx, ":0:SurfRoughA", 0.05, 0.60)
    bound(gpx, ":0:SurfRoughB", 0.02, 0.50)
    checkpoint(gpx, output, "surface_roughness", log)

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    bound(gpx, ":0:SH/L", 0.005, 0.10)
    checkpoint(gpx, output, "axial_divergence", log)

    output.with_suffix(".json").write_text(json.dumps(log, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
