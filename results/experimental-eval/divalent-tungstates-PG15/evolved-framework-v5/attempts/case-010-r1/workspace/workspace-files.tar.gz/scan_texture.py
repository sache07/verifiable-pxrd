#!/usr/bin/env python3
"""Screen a small bounded set of March-Dollase axes for accepted phases."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SOURCE = Path(".tmp/physical/both.bak0.gpx")
OUTDIR = Path(".tmp/texture")


def prepare(output: Path) -> tuple[G2sc.G2Project, G2sc.G2PwdrData]:
    if output.exists():
        output.unlink()
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    gpx.save()
    gpx.set_Controls("cycles", 10)
    hist = gpx.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    gpx.phases()[0].clear_HAP_refinements({"Mustrain": True})
    gpx.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    for phase in gpx.phases():
        phase.clear_HAP_refinements({"Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    return gpx, hist


def set_bound(gpx: G2sc.G2Project, var: str, low: float, high: float) -> None:
    gpx.set_Controls("parmMin", low, variable=var)
    gpx.set_Controls("parmMax", high, variable=var)


def run_one(phase_index: int, axis: tuple[int, int, int]) -> dict:
    tag = f"p{phase_index}_{axis[0]}{axis[1]}{axis[2]}"
    output = OUTDIR / f"{tag}.gpx"
    gpx, hist = prepare(output)
    phase = gpx.phases()[phase_index]
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)
    set_bound(gpx, f"{phase_index}:0:MD", 0.70, 1.40)
    gpx.refine(makeBack=False)
    gpx.save()
    return {
        "tag": tag,
        "phase": phase.name,
        "axis": axis,
        "ratio": phase.data["Histograms"][hist.name]["Pref.Ori."][1],
        "rwp": hist.residuals.get("wR"),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "project": str(output),
    }


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    results = []
    for axis in [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]:
        item = run_one(0, axis)
        results.append(item)
        print(json.dumps(item, default=float), flush=True)
    for axis in [(1, 0, 0), (1, 1, 0), (1, 1, 1)]:
        item = run_one(1, axis)
        results.append(item)
        print(json.dumps(item, default=float), flush=True)
    (OUTDIR / "results.json").write_text(json.dumps(results, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
