#!/usr/bin/env python3
"""Bounded heavy-then-light coordinate refinement for accepted phases."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    out = {
        "label": label,
        "residuals": copy.deepcopy(hist.residuals),
        "phases": {},
    }
    for phase in project.phases():
        out["phases"][phase.name] = {
            "cell": copy.deepcopy(phase.get_cell()),
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    try:
        out["mass_fractions"] = {
            k: [float(v[0]), float(v[1])]
            for k, v in hist.ComputeMassFracs().items()
        }
    except Exception as err:
        out["mass_fraction_error"] = repr(err)
    return out


def checkpoint(project: G2sc.G2Project, work: Path, log: list, label: str) -> None:
    project.refine(makeBack=False)
    log.append(snapshot(project, label))
    project.save(str(work / f"{label}.gpx"))
    for phase in project.phases():
        phase.export_CIF(str(work / f"{label}-{phase.name}.cif"))
    project.save(str(work / "coordinates.gpx"))
    print(label, "wR", log[-1]["residuals"].get("wR"))


def bound_atom(project: G2sc.G2Project, phase, atom_index: int, width: float) -> None:
    # GSAS-II varies symmetry-aware coordinate displacements (dAx, dAy,
    # dAz), which are reset around the current coordinates at each fit.
    for axis in ("x", "y", "z"):
        var = f"{phase.id}::dA{axis}:{atom_index}"
        project.set_Controls("parmMin", -width, variable=var)
        project.set_Controls("parmMax", width, variable=var)


def activate(phase, elements: set[str], project: G2sc.G2Project, width: float) -> None:
    for i, atom in enumerate(phase.atoms()):
        if atom.element in elements:
            atom.refinement_flags = "X"
            bound_atom(project, phase, i, width)


def freeze(phase, elements: set[str]) -> None:
    for atom in phase.atoms():
        if atom.element in elements:
            atom.refinement_flags = " "


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input_gpx")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    work = Path(args.out).resolve()
    work.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(args.input_gpx, newgpx=str(work / "coordinates.gpx"))
    project.save()
    project.set_Controls("cycles", 12)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}

    hist = project.histogram(0)
    # Coordinate steps keep the already established scales, background,
    # cells and calibration, while all specimen/profile terms are held.
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "Zero"):
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True}
        )

    log = [snapshot(project, "initial")]

    wo3 = project.phase("WO3_monoclinic")
    activate(wo3, {"W"}, project, width=0.012)
    checkpoint(project, work, log, "heavy_wo3")
    freeze(wo3, {"W"})

    cawo4 = project.phase("CaWO4_scheelite")
    activate(cawo4, {"O"}, project, width=0.015)
    checkpoint(project, work, log, "light_cawo4")
    freeze(cawo4, {"O"})

    activate(wo3, {"O"}, project, width=0.015)
    checkpoint(project, work, log, "light_wo3")
    freeze(wo3, {"O"})

    calcite = project.phase("CaCO3_calcite")
    activate(calcite, {"O"}, project, width=0.010)
    checkpoint(project, work, log, "light_calcite")
    freeze(calcite, {"O"})

    (work / "log.json").write_text(json.dumps(log, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
