#!/usr/bin/env python3
"""Diagnostic refinement of one atom group from a physical checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input_gpx")
    ap.add_argument("output_gpx")
    ap.add_argument("--phase", required=True)
    ap.add_argument("--element", required=True)
    ap.add_argument("--cycles", type=int, default=1)
    args = ap.parse_args()

    output = Path(args.output_gpx).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(args.input_gpx, newgpx=str(output))
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    project.set_Controls("cycles", args.cycles)
    hist = project.histogram(0)
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "Zero"):
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for phase in project.phases():
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True}
        )
        for atom in phase.atoms():
            atom.refinement_flags = " "
    selected = project.phase(args.phase)
    before = {a.label: list(a.coordinates) for a in selected.atoms()}
    for atom in selected.atoms():
        if atom.element == args.element:
            atom.refinement_flags = "X"
    project.save()
    project.refine(makeBack=False)
    project.save()
    stem = output.with_suffix("")
    for phase in project.phases():
        phase.export_CIF(str(stem.parent / f"{stem.name}-{phase.name}.cif"))
    after = {a.label: list(a.coordinates) for a in selected.atoms()}
    result = {
        "residuals": hist.residuals,
        "mass_fractions": {
            k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()
        },
        "before": before,
        "after": after,
    }
    (stem.parent / f"{stem.name}.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    print(json.dumps(result["residuals"], sort_keys=True))


if __name__ == "__main__":
    main()
