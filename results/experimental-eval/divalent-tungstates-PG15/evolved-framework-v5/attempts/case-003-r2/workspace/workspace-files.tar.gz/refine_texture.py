#!/usr/bin/env python3
"""Test one bounded March-Dollase preferred-orientation branch."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input_gpx")
    ap.add_argument("output_gpx")
    ap.add_argument("--phase", required=True)
    ap.add_argument("--axis", required=True, help="comma-separated h,k,l")
    args = ap.parse_args()
    axis = [int(v) for v in args.axis.split(",")]
    output = Path(args.output_gpx).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(args.input_gpx, newgpx=str(output))
    project.set_Controls("cycles", 10)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histogram(0)
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "Zero"):
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True}
        )
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[1] = 1.0
        po[2] = False
    selected = project.phase(args.phase)
    po = selected.data["Histograms"][hist.name]["Pref.Ori."]
    po[3] = axis
    po[2] = True
    # Physical range used only as an acceptance screen after fitting; GSAS-II
    # parameter-limit freezing is avoided because it can invalidate branches.
    project.save()
    project.refine(makeBack=False)
    project.save()
    result = {
        "phase": args.phase,
        "axis": axis,
        "ratio": po[1],
        "residuals": hist.residuals,
        "mass_fractions": {
            k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()
        },
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"wR": hist.get_wR(), "ratio": po[1]}))


if __name__ == "__main__":
    main()
