#!/usr/bin/env python3
"""Freeze the accepted refinement and export all requested deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "tuned" / "polarization.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "CaWO4_scheelite": {
        "name": "CaWO4 scheelite",
        "formula": "CaWO4",
        "space_group": "I 41/a",
        "reference": "COD 7219229",
        "cif": "phase_CaWO4_scheelite.cif",
    },
    "WO3_monoclinic": {
        "name": "WO3 monoclinic",
        "formula": "WO3",
        "space_group": "P 1 21/c 1",
        "reference": "COD 2311041",
        "cif": "phase_WO3_monoclinic.cif",
    },
    "CaCO3_calcite": {
        "name": "CaCO3 calcite",
        "formula": "CaCO3",
        "space_group": "R -3 c",
        "reference": "COD 1547347",
        "cif": "phase_CaCO3_calcite.cif",
    },
}


def freeze_refinement_flags(project: G2sc.G2Project) -> None:
    """Retain parameter values while making the submitted checkpoint stable."""
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for key, value in hist.InstrumentParameters.items():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
            }
        )
        for atom in phase.atoms():
            atom.refinement_flags = " "


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    freeze_refinement_flags(project)
    project.save()

    # Reload the submitted file so every table below is demonstrably exported
    # from final.gpx rather than from an in-memory precursor.
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()

    phases = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif"]))
        fraction, esd = fractions[phase.name]
        phases.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "space_group": info["space_group"],
                "reference_structure": info["reference"],
                "cif": info["cif"],
                "cif_path": info["cif"],
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(esd),
                "weight_percent": 100.0 * float(fraction),
            }
        )

    x = hist.getdata("X")
    yobs = hist.getdata("Yobs")
    ycalc = hist.getdata("Ycalc")
    diff = hist.getdata("Residual")
    background = hist.getdata("Background")
    # Preserve the specimen's original angle strings in the submitted table;
    # the intermediate GSAS-II xye file rounded them only at the 1e-8 degree
    # level, which is immaterial to the model but needlessly changes the grid.
    with (ROOT / "inputs" / "pattern.csv").open(newline="", encoding="utf-8") as fp:
        input_rows = list(csv.DictReader(fp))
    if len(input_rows) != len(x):
        raise RuntimeError("final profile length differs from the specimen grid")
    input_x = [row["two_theta_deg"] for row in input_rows]
    input_y = [row["intensity"] for row in input_rows]
    if any(abs(float(xx) - gx) > 1.0e-7 for xx, gx in zip(input_x, x)):
        raise RuntimeError("final profile angles do not match the specimen grid")
    if any(float(yy) != gy for yy, gy in zip(input_y, yobs)):
        raise RuntimeError("final observed intensities differ from the specimen")
    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as fp:
        writer = csv.writer(fp)
        writer.writerow(
            [
                "two_theta_deg",
                "observed",
                "calculated",
                "difference_observed_minus_calculated",
                "background",
            ]
        )
        writer.writerows(zip(input_x, input_y, ycalc, diff, background))

    residuals = hist.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "phases": phases,
        "weight_fraction_basis": "normalized over the modeled crystalline phases; sum = 1",
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "weighted_sum_of_squares": float(rvals["chisq"]),
            "reduced_chi_squared": float(rvals["GOF"]) ** 2,
            "n_observations": int(rvals["Nobs"]),
            "n_refined_variables": int(rvals["Nvars"]),
            "converged": bool(rvals["converged"]),
        },
        "profile": "fit.csv",
        "gsasii_project": "final.gpx",
        "refinement_histogram": hist.name,
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
