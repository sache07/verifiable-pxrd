#!/usr/bin/env python3
"""Test one uniaxial microstrain model from a physical checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input_gpx")
    ap.add_argument("output_gpx")
    ap.add_argument("--phase", required=True)
    ap.add_argument("--axis", required=True)
    args = ap.parse_args()
    axis = [int(v) for v in args.axis.split(",")]
    output = Path(args.output_gpx).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(args.input_gpx, newgpx=str(output))
    project.set_Controls("cycles", 10)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histogram(0)
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "Zero"):
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True}
        )
    selected = project.phase(args.phase)
    ms = selected.data["Histograms"][hist.name]["Mustrain"]
    isotropic = float(ms[1][0])
    ms[1][1] = isotropic
    selected.set_HAP_refinements(
        {
            "Mustrain": {
                "type": "uniaxial",
                "direction": axis,
                "refine": True,
            }
        }
    )
    project.save()
    project.refine(makeBack=False)
    project.save()
    result = {
        "phase": args.phase,
        "axis": axis,
        "equatorial": ms[1][0],
        "axial": ms[1][1],
        "residuals": hist.residuals,
        "mass_fractions": {
            k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()
        },
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"wR": hist.get_wR(), "eq": ms[1][0], "ax": ms[1][1]}))


if __name__ == "__main__":
    main()
