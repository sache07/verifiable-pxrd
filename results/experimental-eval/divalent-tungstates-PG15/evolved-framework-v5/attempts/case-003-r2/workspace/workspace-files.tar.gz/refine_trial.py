#!/usr/bin/env python3
"""Create and refine a three-phase GSAS-II trial project.

Run with the GSAS-II Python interpreter. This is an analysis helper, not a
specimen result: the final project and exports are produced separately after
model selection.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inputs(work: Path, pattern: Path) -> tuple[Path, Path]:
    arr = np.genfromtxt(pattern, delimiter=",", names=True)
    x = np.asarray(arr["two_theta_deg"], dtype=float)
    y = np.asarray(arr["intensity"], dtype=float)
    sig = np.sqrt(np.maximum(y, 1.0))

    xye = work / "pattern.xye"
    with xye.open("w", encoding="ascii") as fp:
        fp.write("# 2theta intensity sigma\n")
        for xx, yy, ss in zip(x, y, sig):
            fp.write(f"{xx:.8f} {yy:.8f} {ss:.8f}\n")

    inst = work / "instrument.instprm"
    with inst.open("w", encoding="ascii") as fp:
        fp.write("#GSAS-II instrument parameter file for Cu Kalpha lab data\n")
        fp.write("Type:PXC;Bank:1\n")
        fp.write(
            "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;"
            "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        )
        fp.write("U:20.0;V:0.0;W:20.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n")
    return xye, inst


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    out = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in (
                "Zero",
                "Polariz.",
                "U",
                "V",
                "W",
                "X",
                "Y",
                "Z",
                "SH/L",
                "I(L2)/I(L1)",
            )
            if key in hist.InstrumentParameters
        },
        "sample": {
            key: val[0] if isinstance(val, list) else val
            for key, val in hist.SampleParameters.items()
            if key
            in (
                "Type",
                "Gonio. radius",
                "Shift",
                "Transparency",
                "SurfRoughA",
                "SurfRoughB",
            )
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    try:
        out["mass_fractions"] = {
            key: [float(val[0]), float(val[1])]
            for key, val in hist.ComputeMassFracs().items()
        }
    except Exception as err:
        out["mass_fraction_error"] = repr(err)
    try:
        cov = project.data["Covariance"]["data"]
        out["covariance"] = {
            "Rvals": cov.get("Rvals", {}),
            "varyList": cov.get("varyList", []),
            "variables": [float(v) for v in cov.get("variables", [])],
            "sig": [float(v) for v in cov.get("sig", [])],
        }
    except Exception:
        pass
    return out


def set_bounds(project: G2sc.G2Project) -> None:
    # Histogram and sample bounds. Wildcards keep these usable if IDs shift.
    for name, lo, hi in (
        (":*:Shift", -800.0, 800.0),
        (":*:Zero", -0.25, 0.25),
        (":*:Polariz.", 0.5, 1.0),
        (":*:U", 0.0, 40.0),
        (":*:W", 2.0, 40.0),
        (":*:X", 0.1, 6.0),
        (":*:SH/L", 0.005, 0.1),
    ):
        project.set_Controls("parmMin", lo, variable=name)
        project.set_Controls("parmMax", hi, variable=name)


def refine_step(project: G2sc.G2Project, log: list, label: str, work: Path) -> None:
    project.refine(makeBack=False)
    log.append(snapshot(project, label))
    project.save(str(work / f"{label}.gpx"))
    # Keep the named checkpoint immutable; subsequent refinements operate on
    # trial.gpx rather than overwriting the just-saved checkpoint.
    project.save(str(work / "trial.gpx"))
    print(label, json.dumps(log[-1]["residuals"], sort_keys=True))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True, help="trial directory")
    ap.add_argument("--cawo4", default="7219229")
    ap.add_argument("--wo3", default="2311041")
    ap.add_argument("--caco3", default="1547347")
    ap.add_argument("--pattern", default="inputs/pattern.csv")
    ap.add_argument("--through", choices=("cell", "profile"), default="profile")
    args = ap.parse_args()

    work = Path(args.out).resolve()
    work.mkdir(parents=True, exist_ok=True)
    xye, inst = write_inputs(work, Path(args.pattern).resolve())
    gpx_path = work / "trial.gpx"
    project = G2sc.G2Project(newgpx=str(gpx_path))
    hist = project.add_powder_histogram(
        str(xye), str(inst), fmthint="Topas xye"
    )
    phases = [
        ("CaWO4_scheelite", args.cawo4),
        ("WO3_monoclinic", args.wo3),
        ("CaCO3_calcite", args.caco3),
    ]
    for name, cod_id in phases:
        project.add_phase(
            str(cod_path(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )

    project.set_Controls("cycles", 12)
    set_bounds(project)
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"][0] = -520.0
    # Absolute histogram scale is arbitrary and exactly correlated with every
    # phase scale, so keep it fixed and refine the phase scales only.
    hist.SampleParameters["Scale"][0] = 1.0
    hist.SampleParameters["Scale"][1] = False
    hist.Background[0][0] = "chebyschev-1"
    hist.set_refinements(
        {
            "Limits": [float(hist.getdata("X")[0]), float(hist.getdata("X")[-1])],
            "Background": {"type": "chebyschev-1", "no. coeffs": 15, "refine": True},
        }
    )

    # Keep initial widths broad enough that the displaced reference peaks are
    # captured, then refine scales/background/geometry before cell/profile.
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})

    log: list[dict] = [snapshot(project, "initial")]
    refine_step(project, log, "scale_background_shift", work)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine_step(project, log, "cells", work)

    # Separate the constant angular zero from the cos(theta) specimen shift
    # only after each phase cell has adjusted to the observed family spacings.
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_step(project, log, "zero_and_cells", work)
    # Alternate the two strongly correlated calibration terms rather than
    # refining them simultaneously.
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_step(project, log, "shift_and_cells", work)
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    if args.through == "cell":
        project.save()
        (work / "log.json").write_text(json.dumps(log, indent=2), encoding="utf-8")
        return

    # The laboratory profile family specifies U, W and X; V, Y and Z remain
    # zero. Add supported profile complexity one term family at a time.
    hist.set_refinements({"Instrument Parameters": ["U", "W"]})
    refine_step(project, log, "profile_uw", work)
    hist.set_refinements({"Instrument Parameters": ["X"]})
    refine_step(project, log, "profile_uwx", work)
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine_step(project, log, "profile_axial", work)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine_step(project, log, "profile_polarization", work)

    project.save()
    (work / "log.json").write_text(json.dumps(log, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
