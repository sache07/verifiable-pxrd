#!/usr/bin/env python3
"""Test Bragg-Brentano surface roughness from a physical checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input_gpx")
    ap.add_argument("output_gpx")
    ap.add_argument("--a", type=float, required=True)
    ap.add_argument("--b", type=float, required=True)
    args = ap.parse_args()
    output = Path(args.output_gpx).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(args.input_gpx, newgpx=str(output))
    project.set_Controls("cycles", 10)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histogram(0)
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "Zero"):
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "HStrain": True})
    hist.SampleParameters["SurfRoughA"] = [args.a, True]
    hist.SampleParameters["SurfRoughB"] = [args.b, True]
    project.save()
    project.refine(makeBack=False)
    project.save()
    result = {
        "A": hist.SampleParameters["SurfRoughA"][0],
        "B": hist.SampleParameters["SurfRoughB"][0],
        "residuals": hist.residuals,
        "mass_fractions": {
            k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()
        },
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"wR": hist.get_wR(), "A": result["A"], "B": result["B"]}))


if __name__ == "__main__":
    main()
