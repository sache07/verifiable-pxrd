#!/usr/bin/env python3
"""Refine phase-dependent broadening from a complete GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def state(project: G2sc.G2Project, label: str) -> dict:
    h = project.histogram(0)
    result = {
        "label": label,
        "residuals": h.residuals,
        "instrument": {
            k: h.InstrumentParameters[k][1]
            for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")
        },
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in h.SampleParameters.items()
            if k in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "phases": {},
    }
    for p in project.phases():
        hap = p.data["Histograms"][h.name]
        result["phases"][p.name] = {
            "cell": p.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    try:
        result["mass_fractions"] = {
            k: [float(v[0]), float(v[1])] for k, v in h.ComputeMassFracs().items()
        }
    except Exception as err:
        result["mass_fraction_error"] = repr(err)
    return result


def checkpoint(project: G2sc.G2Project, work: Path, log: list, label: str) -> None:
    project.refine(makeBack=False)
    log.append(state(project, label))
    project.save(str(work / f"{label}.gpx"))
    project.save(str(work / "profile.gpx"))
    print(label, "wR", log[-1]["residuals"].get("wR"))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input_gpx")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    work = Path(args.out).resolve()
    work.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(args.input_gpx, newgpx=str(work / "profile.gpx"))
    project.save()
    project.set_Controls("cycles", 12)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}

    h = project.histogram(0)
    # Return to a mid-range physical common profile. Phase-dependent terms
    # should explain only broadening beyond this baseline.
    for key, value in (("U", 20.0), ("V", 0.0), ("W", 20.0), ("X", 2.0),
                       ("Y", 0.0), ("Z", 0.0), ("SH/L", 0.03)):
        h.InstrumentParameters[key][1] = value
        h.InstrumentParameters[key][2] = False
    h.SampleParameters["Scale"][1] = False
    h.SampleParameters["Shift"][1] = False
    h.InstrumentParameters["Zero"][2] = False

    starts = {
        "CaWO4_scheelite": (0.12, 1500.0),
        "WO3_monoclinic": (0.40, 700.0),
        "CaCO3_calcite": (0.40, 700.0),
    }
    for p in project.phases():
        for atom in p.atoms():
            atom.refinement_flags = " "
        size, strain = starts[p.name]
        p.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": size, "refine": True}}
        )
        hap = p.data["Histograms"][h.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][2][0] = False

    log = [state(project, "initial")]
    checkpoint(project, work, log, "size")

    # Hold size while first introducing strain to reduce size/strain exchange.
    for p in project.phases():
        p.clear_HAP_refinements({"Size": True})
        p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    checkpoint(project, work, log, "strain")

    for p in project.phases():
        p.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    checkpoint(project, work, log, "size_strain")

    # Alternate the common Gaussian and Lorentzian profile terms with the
    # phase terms held, then make one joint pass if all remain physical.
    for p in project.phases():
        p.clear_HAP_refinements({"Size": True, "Mustrain": True})
    h.set_refinements({"Instrument Parameters": ["U", "W"]})
    checkpoint(project, work, log, "instrument_uw")
    h.set_refinements({"Instrument Parameters": ["X"]})
    checkpoint(project, work, log, "instrument_uwx")

    for p in project.phases():
        p.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    checkpoint(project, work, log, "joint_profile")
    (work / "log.json").write_text(json.dumps(log, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
