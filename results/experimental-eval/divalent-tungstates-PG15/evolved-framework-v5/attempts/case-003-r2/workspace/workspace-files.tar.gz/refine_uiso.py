#!/usr/bin/env python3
"""Test physically positive common W/O Uiso values for monoclinic WO3."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input_gpx")
    ap.add_argument("output_gpx")
    args = ap.parse_args()

    output = Path(args.output_gpx).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(args.input_gpx, newgpx=str(output))
    project.set_Controls("cycles", 8)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}

    hist = project.histogram(0)
    hist.Background[0][1] = False
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "Zero"):
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1:
            value[1] = False

    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
            }
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "

    wo3 = project.phase("WO3_monoclinic")
    pid = wo3.data["pId"]
    w_indices = []
    o_indices = []
    for index, atom in enumerate(wo3.atoms()):
        atom.uiso = 0.006 if atom.element == "W" else 0.010
        atom.refinement_flags = "U"
        (w_indices if atom.element == "W" else o_indices).append(index)

    def var(index: int) -> str:
        return f"{pid}::AUiso:{index}"

    project.add_EquivConstr(tuple(var(i) for i in w_indices))
    project.add_EquivConstr(tuple(var(i) for i in o_indices))
    for index in w_indices + o_indices:
        project.set_Controls("parmMin", 0.0005, variable=var(index))
        project.set_Controls("parmMax", 0.0300, variable=var(index))

    project.save()
    project.refine(makeBack=False)
    project.save()

    result = {
        "residuals": hist.residuals,
        "mass_fractions": {
            key: [float(value[0]), float(value[1])]
            for key, value in hist.ComputeMassFracs().items()
        },
        "uiso": {
            atom.label: float(atom.uiso)
            for atom in wo3.atoms()
        },
        "scales": {
            phase.name: float(phase.data["Histograms"][hist.name]["Scale"][0])
            for phase in project.phases()
        },
    }
    output.with_suffix(".json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
