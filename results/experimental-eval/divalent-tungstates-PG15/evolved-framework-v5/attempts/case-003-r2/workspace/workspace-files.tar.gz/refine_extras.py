#!/usr/bin/env python3
"""Sequentially test supported common profile and calibration terms."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def snap(project: G2sc.G2Project, label: str) -> dict:
    h = project.histogram(0)
    return {
        "label": label,
        "wR": h.get_wR(),
        "residuals": copy.deepcopy(h.residuals),
        "instrument": {
            k: h.InstrumentParameters[k][1]
            for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            k: v[0]
            for k, v in h.SampleParameters.items()
            if k in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "mass_fractions": {
            k: [float(v[0]), float(v[1])] for k, v in h.ComputeMassFracs().items()
        },
    }


def step(project: G2sc.G2Project, work: Path, log: list, label: str) -> None:
    project.refine(makeBack=False)
    log.append(snap(project, label))
    project.save(str(work / f"{label}.gpx"))
    project.save(str(work / "extras.gpx"))
    print(label, log[-1]["wR"], log[-1]["instrument"], log[-1]["sample"])


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input_gpx")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    work = Path(args.out).resolve()
    work.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(args.input_gpx, newgpx=str(work / "extras.gpx"))
    project.set_Controls("cycles", 10)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    h = project.histogram(0)
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "Zero"):
        if key in h.InstrumentParameters:
            h.InstrumentParameters[key][2] = False
    for key, value in h.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for p in project.phases():
        for atom in p.atoms():
            atom.refinement_flags = " "
        p.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True}
        )
    project.save()
    log = [snap(project, "initial")]

    h.set_refinements({"Instrument Parameters": ["SH/L"]})
    step(project, work, log, "axial")
    h.clear_refinements({"Instrument Parameters": ["SH/L"]})

    h.set_refinements({"Instrument Parameters": ["Polariz."]})
    step(project, work, log, "polarization")
    h.clear_refinements({"Instrument Parameters": ["Polariz."]})

    h.set_refinements({"Instrument Parameters": ["Zero"]})
    step(project, work, log, "zero")
    h.clear_refinements({"Instrument Parameters": ["Zero"]})

    h.set_refinements({"Sample Parameters": ["Shift"]})
    step(project, work, log, "shift")
    h.clear_refinements({"Sample Parameters": ["Shift"]})

    h.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    step(project, work, log, "common_profile")

    (work / "log.json").write_text(json.dumps(log, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
