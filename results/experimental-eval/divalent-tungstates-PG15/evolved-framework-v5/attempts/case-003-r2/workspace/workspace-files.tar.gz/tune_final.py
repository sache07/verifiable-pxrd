#!/usr/bin/env python3
"""Tune accepted profile/specimen terms, preserving replayable checkpoints."""

from __future__ import annotations

import argparse

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def snap(project: G2sc.G2Project, label: str) -> dict:
    h = project.histogram(0)
    phases = {}
    for p in project.phases():
        hap = p.data["Histograms"][h.name]
        phases[p.name] = {
            "size": copy.deepcopy(hap["Size"]),
            "mustrain": copy.deepcopy(hap["Mustrain"]),
            "pref_ori": copy.deepcopy(hap["Pref.Ori."]),
        }
    return {
        "label": label,
        "wR": h.get_wR(),
        "residuals": copy.deepcopy(h.residuals),
        "instrument": {
            k: h.InstrumentParameters[k][1]
            for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            k: v[0]
            for k, v in h.SampleParameters.items()
            if k in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "phases": phases,
        "mass_fractions": {
            k: [float(v[0]), float(v[1])] for k, v in h.ComputeMassFracs().items()
        },
    }


def checkpoint(project: G2sc.G2Project, work: Path, log: list, label: str) -> None:
    project.refine(makeBack=False)
    log.append(snap(project, label))
    project.save(str(work / f"{label}.gpx"))
    project.save(str(work / "tuned.gpx"))
    print(label, "wR", log[-1]["wR"])


def clear_profile_flags(project: G2sc.G2Project) -> None:
    h = project.histogram(0)
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "Zero"):
        if key in h.InstrumentParameters:
            h.InstrumentParameters[key][2] = False
    for key, value in h.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for p in project.phases():
        for atom in p.atoms():
            atom.refinement_flags = " "
        p.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True}
        )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input_gpx")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    work = Path(args.out).resolve()
    work.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(args.input_gpx, newgpx=str(work / "tuned.gpx"))
    project.set_Controls("cycles", 10)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    clear_profile_flags(project)
    project.save()
    h = project.histogram(0)
    log = [snap(project, "initial")]

    h.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    checkpoint(project, work, log, "common_profile")
    h.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})

    for name, label in (
        ("CaWO4_scheelite", "size_cawo4"),
        ("WO3_monoclinic", "size_wo3"),
        ("CaCO3_calcite", "size_calcite"),
    ):
        phase = project.phase(name)
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        checkpoint(project, work, log, label)
        phase.clear_HAP_refinements({"Size": True})

    wo3 = project.phase("WO3_monoclinic")
    wo3.set_HAP_refinements(
        {
            "Mustrain": {
                "type": "uniaxial",
                "direction": [1, 1, 0],
                "refine": True,
            }
        }
    )
    checkpoint(project, work, log, "strain_wo3")
    wo3.clear_HAP_refinements({"Mustrain": True})

    h.set_refinements({"Instrument Parameters": ["SH/L"]})
    checkpoint(project, work, log, "axial")
    h.clear_refinements({"Instrument Parameters": ["SH/L"]})

    h.set_refinements({"Instrument Parameters": ["Polariz."]})
    checkpoint(project, work, log, "polarization")
    h.clear_refinements({"Instrument Parameters": ["Polariz."]})

    calcite = project.phase("CaCO3_calcite")
    calcite.set_HAP_refinements({"Pref.Ori.": True})
    checkpoint(project, work, log, "texture_calcite")
    calcite.clear_HAP_refinements({"Pref.Ori.": True})

    # One joint diagnostic pass. It is accepted only if all values remain
    # physical and it improves over the preceding immutable checkpoint.
    h.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    for p in project.phases():
        p.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    wo3.set_HAP_refinements(
        {"Mustrain": {"type": "uniaxial", "direction": [1, 1, 0], "refine": True}}
    )
    calcite.set_HAP_refinements({"Pref.Ori.": True})
    checkpoint(project, work, log, "joint")

    (work / "log.json").write_text(json.dumps(log, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
