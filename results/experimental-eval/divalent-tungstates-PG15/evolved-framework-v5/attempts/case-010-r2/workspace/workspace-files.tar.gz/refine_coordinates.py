#!/usr/bin/env python3
"""Refine heavy and then light atom coordinates from a physical checkpoint."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def freeze_profile(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    for val in hist.data["Instrument Parameters"][0].values():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def save_checkpoint(project: G2.G2Project, outdir: Path, label: str) -> None:
    main = outdir / "coordinates.gpx"
    project.save(str(main))
    shutil.copy2(main, outdir / f"checkpoint_{label}.gpx")
    for phase in project.phases():
        phase.export_CIF(str(outdir / f"{label}_{phase.name}.cif"))


def run_stage(project: G2.G2Project, outdir: Path, label: str) -> None:
    project.refine()
    h = project.histogram(0)
    print(f"STAGE {label:>16s} wR={h.get_wR():.6f}", flush=True)
    for phase in project.phases():
        print("PHASE", phase.name, phase.get_cell(), flush=True)
        for atom in phase.atoms():
            print(
                "ATOM",
                phase.name,
                atom.label,
                atom.element,
                tuple(round(v, 8) for v in atom.coordinates),
                round(float(atom.uiso), 7),
                atom.refinement_flags,
                flush=True,
            )
    save_checkpoint(project, outdir, label)


def set_elements(phase: G2.G2Phase, elements: set[str], flags: str) -> None:
    for atom in phase.atoms():
        atom.refinement_flags = flags if atom.element in elements else " "


def set_coordinate_bounds(
    project: G2.G2Project, phase_index: int, phase: G2.G2Phase, elements: set[str], width: float
) -> None:
    for atom_index, atom in enumerate(phase.atoms()):
        if atom.element not in elements:
            continue
        for axis in "xyz":
            var = f"{phase_index}::dA{axis}:{atom_index}"
            project.set_Controls("parmMin", -width, variable=var)
            project.set_Controls("parmMax", width, variable=var)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--out", default=".tmp/coordinates")
    parser.add_argument("--skip-mn-heavy", action="store_true")
    parser.add_argument("--bounded", action="store_true")
    args = parser.parse_args()
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    main = outdir / "coordinates.gpx"
    project = G2.G2Project(args.input, newgpx=str(main))
    G2.SetPrintLevel("warn")
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.15
    # Parameter-limit freezes from a previous profile branch should not affect
    # a coordinate-only branch.
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    freeze_profile(project)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "

    wo, mn = project.phases()
    set_elements(wo, {"W"}, "X")
    if args.bounded:
        set_coordinate_bounds(project, 0, wo, {"W"}, 0.006)
    run_stage(project, outdir, "W_coordinates")

    if not args.skip_mn_heavy:
        set_elements(mn, {"Mn"}, "X")
        if args.bounded:
            set_coordinate_bounds(project, 1, mn, {"Mn"}, 0.006)
        run_stage(project, outdir, "heavy_coordinates")

    set_elements(wo, {"O"}, "X")
    if args.bounded:
        set_coordinate_bounds(project, 0, wo, {"O"}, 0.008)
    run_stage(project, outdir, "WO3_O_coordinates")

    set_elements(mn, {"O"}, "X")
    if args.bounded:
        set_coordinate_bounds(project, 1, mn, {"O"}, 0.008)
    run_stage(project, outdir, "all_coordinates")


if __name__ == "__main__":
    main()
