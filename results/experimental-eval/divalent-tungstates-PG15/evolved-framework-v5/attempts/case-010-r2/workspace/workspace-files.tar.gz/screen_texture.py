#!/usr/bin/env python3
"""Screen the small allowed set of March-Dollase axes on a fixed inventory."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def freeze_nontexture(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    for val in hist.data["Instrument Parameters"][0].values():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--out", default=".tmp/texture")
    args = parser.parse_args()
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    results = []
    for pidx in range(2):
        for axis in AXES:
            tag = f"p{pidx}_{axis[0]}{axis[1]}{axis[2]}"
            project = G2.G2Project(args.input, newgpx=str(outdir / f"{tag}.gpx"))
            project.set_Controls("cycles", 8)
            project.data["Controls"]["data"]["shift factor"] = 0.3
            project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
            freeze_nontexture(project)
            hist = project.histogram(0)
            phase = project.phase(pidx)
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
            project.set_Controls("parmMin", 0.7, variable=f"{pidx}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pidx}:0:MD")
            project.refine()
            wr = float(hist.get_wR())
            ratio = float(hap["Pref.Ori."][1])
            project.save()
            results.append((wr, pidx, axis, ratio, str(outdir / f"{tag}.gpx")))
            print("RESULT", wr, pidx, axis, ratio, flush=True)
    print("SUMMARY")
    for row in sorted(results):
        print(row)


if __name__ == "__main__":
    main()
