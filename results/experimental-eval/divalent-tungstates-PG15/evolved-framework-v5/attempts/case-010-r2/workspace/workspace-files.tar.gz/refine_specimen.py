#!/usr/bin/env python3
"""Refine bounded polarization and test Bragg-Brentano surface roughness."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def checkpoint(project: G2.G2Project, outdir: Path, label: str) -> None:
    target = outdir / "specimen.gpx"
    project.save(str(target))
    shutil.copy2(target, outdir / f"checkpoint_{label}.gpx")
    print(
        "STAGE",
        label,
        "wR",
        project.histogram(0).get_wR(),
        "instrument",
        project.histogram(0).data["Instrument Parameters"][0],
        "sample",
        project.histogram(0).data["Sample Parameters"],
        flush=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--out", default=".tmp/specimen")
    args = parser.parse_args()
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input, newgpx=str(outdir / "specimen.gpx"))
    G2.SetPrintLevel("warn")
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.2
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)

    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.refine()
    checkpoint(project, outdir, "polarization")

    hist.data["Instrument Parameters"][0]["Polariz."][2] = False
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.20, True]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.10, True]
    project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    project.refine()
    checkpoint(project, outdir, "surface_roughness")


if __name__ == "__main__":
    main()
