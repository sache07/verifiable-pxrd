#!/usr/bin/env python3
"""Test supported uniaxial microstrain branches for each accepted phase."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0)]


def freeze(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    for val in hist.data["Instrument Parameters"][0].values():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--out", default=".tmp/anisotropy")
    args = parser.parse_args()
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    results = []
    for pidx in range(2):
        for axis in AXES:
            tag = f"p{pidx}_{axis[0]}{axis[1]}{axis[2]}"
            project = G2.G2Project(args.input, newgpx=str(outdir / f"{tag}.gpx"))
            project.set_Controls("cycles", 8)
            project.data["Controls"]["data"]["shift factor"] = 0.2
            project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
            freeze(project)
            hist = project.histogram(0)
            phase = project.phase(pidx)
            hap = phase.data["Histograms"][hist.name]
            ms = hap["Mustrain"]
            start = float(ms[1][0])
            ms[0] = "uniaxial"
            ms[1][0] = start
            ms[1][1] = start
            ms[2][0] = True
            ms[2][1] = True
            ms[2][2] = False
            ms[3] = list(axis)
            for suffix in ["i", "a"]:
                project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;{suffix}")
                project.set_Controls("parmMax", 8000.0, variable=f"{pidx}:0:Mustrain;{suffix}")
            project.refine()
            wr = float(hist.get_wR())
            vals = tuple(float(v) for v in ms[1][:2])
            project.save()
            results.append((wr, pidx, axis, vals, str(outdir / f"{tag}.gpx")))
            print("RESULT", wr, pidx, axis, vals, flush=True)
    print("SUMMARY")
    for row in sorted(results):
        print(row)


if __name__ == "__main__":
    main()
