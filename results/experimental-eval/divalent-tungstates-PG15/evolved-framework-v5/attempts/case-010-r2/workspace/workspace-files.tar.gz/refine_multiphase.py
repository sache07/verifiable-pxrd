#!/usr/bin/env python3
"""Build and refine the chemically ordinary WO3 + manganese-oxide model."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
WO_CELL = [7.6938287794, 7.5368268014, 10.5442550884, 90.0, 136.1525310393, 90.0]
BG = [
    1052.4675,
    -541.2203,
    349.8721,
    -207.9206,
    144.8159,
    -79.5698,
    43.1458,
    -34.5637,
    14.1113,
    6.7971,
    0.0671,
    -14.0090,
]


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_files(outdir: Path) -> tuple[Path, Path]:
    outdir.mkdir(parents=True, exist_ok=True)
    raw = np.genfromtxt(ROOT / "inputs/pattern.csv", delimiter=",", names=True)
    x = np.asarray(raw["two_theta_deg"], float)
    y = np.asarray(raw["intensity"], float)
    xye = outdir / "pattern.xye"
    np.savetxt(xye, np.c_[x, y, np.sqrt(np.maximum(y, 1.0))], fmt="%.8f %.8f %.8f")
    inst = outdir / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha lab data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.032;Polariz.:0.7;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:8.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.018\n"
    )
    return xye, inst


def set_cell(phase: G2.G2Phase, cell: list[float]) -> None:
    phase.data["General"]["Cell"][1:7] = cell
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def set_value(pair: list, value: float) -> None:
    pair[0] = float(value)
    pair[1] = float(value)


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histogram(0)
    terms = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        terms.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
    terms = np.asarray(terms)
    return (terms / terms.sum()).tolist()


def report_stage(project: G2.G2Project, label: str, outdir: Path) -> None:
    project.refine()
    hist = project.histogram(0)
    print(
        f"STAGE {label:>20s} wR={hist.get_wR():9.5f} "
        f"fractions={fractions(project)}",
        flush=True,
    )
    project.save(str(outdir / f"checkpoint_{label}.gpx"))


def add_bounds(project: G2.G2Project, phases: list[G2.G2Phase]) -> None:
    bounds = {
        ":0:Zero": (-0.5, 0.5),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.1),
        "0:0:Scale": (0.0, 100.0),
        "1:0:Scale": (0.0, 100.0),
        "0:0:Size;i": (0.04, 1.5),
        "1:0:Size;i": (0.04, 1.5),
        "0:0:Mustrain;i": (0.0, 8000.0),
        "1:0:Mustrain;i": (0.0, 8000.0),
    }
    for var, (lo, hi) in bounds.items():
        project.set_Controls("parmMin", lo, variable=var)
        project.set_Controls("parmMax", hi, variable=var)
    for pidx, phase in enumerate(phases):
        avec = G2lat.cell2A(phase.data["General"]["Cell"][1:7])
        for i, val in enumerate(avec):
            width = max(abs(val) * 0.08, max(avec[:3]) * 0.005)
            lo, hi = val - width, val + width
            if i < 3:
                lo = max(lo, val * 0.88)
            project.set_Controls("parmMin", lo, variable=f"{pidx}::A{i}")
            project.set_Controls("parmMax", hi, variable=f"{pidx}::A{i}")


def configure_hap(phase: G2.G2Phase, hist: G2.G2PwdrData, scale: float) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(scale), False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.15
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1500.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo-id", default="2311041")
    parser.add_argument("--mn-id", default="1514230")
    parser.add_argument("--out", default=".tmp/multiphase")
    args = parser.parse_args()
    outdir = (ROOT / args.out).resolve()
    xye, instfile = prepare_files(outdir)
    G2.SetPrintLevel("warn")

    project = G2.G2Project(newgpx=str(outdir / "model.gpx"))
    wo = project.add_phase(str(cod_path(args.wo_id)), phasename="WO3", fmthint="CIF")
    mn = project.add_phase(str(cod_path(args.mn_id)), phasename="Mn_oxide", fmthint="CIF")
    set_cell(wo, WO_CELL)
    for phase in [wo, mn]:
        for atom in phase.atoms():
            atom.uiso = 0.01
    hist = project.add_powder_histogram(
        str(xye), str(instfile), phases=[wo, mn], fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [-484.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(BG),
                "coeffs": BG,
                "refine": True,
            },
        }
    )
    configure_hap(wo, hist, 15.0)
    configure_hap(mn, hist, 1.5)
    for phase in [wo, mn]:
        phase.set_HAP_refinements({"Scale": True})

    project.set_Controls("cycles", 7)
    project.data["Controls"]["data"]["shift factor"] = 0.35
    add_bounds(project, [wo, mn])

    report_stage(project, "scales_background", outdir)

    wo.set_refinements({"Cell": True})
    mn.set_refinements({"Cell": True})
    report_stage(project, "cells", outdir)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    report_stage(project, "shift", outdir)
    hist.data["Sample Parameters"]["Shift"][1] = False
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    report_stage(project, "zero", outdir)
    hist.data["Instrument Parameters"][0]["Zero"][2] = False

    for phase in [wo, mn]:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    report_stage(project, "phase_profile", outdir)

    for phase in [wo, mn]:
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    report_stage(project, "instrument_profile", outdir)

    # One alternating phase-profile update with the common instrument fixed.
    for key in ["U", "W", "X", "SH/L"]:
        hist.data["Instrument Parameters"][0][key][2] = False
    for phase in [wo, mn]:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    report_stage(project, "phase_profile_2", outdir)
    project.save(str(outdir / "baseline.gpx"))

    print("FINAL FRACTIONS", fractions(project))
    print("FINAL CELLS", [p.get_cell() for p in project.phases()])
    print("INSTRUMENT", hist.data["Instrument Parameters"][0])
    print("SAMPLE", hist.data["Sample Parameters"])
    for phase in project.phases():
        print("HAP", phase.name, phase.data["Histograms"][hist.name])


if __name__ == "__main__":
    main()
