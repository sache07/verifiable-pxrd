#!/usr/bin/env python3
"""Alternate physically bounded phase and instrument profile refinements."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2


def weight_fractions(project: G2.G2Project) -> list[float]:
    hist = project.histogram(0)
    vals = np.array(
        [
            p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
            for p in project.phases()
        ],
        float,
    )
    return (vals / vals.sum()).tolist()


def checkpoint(project: G2.G2Project, outdir: Path, label: str) -> None:
    target = outdir / "profile.gpx"
    project.save(str(target))
    shutil.copy2(target, outdir / f"checkpoint_{label}.gpx")
    hist = project.histogram(0)
    print("STAGE", label, "wR", hist.get_wR(), "fractions", weight_fractions(project), flush=True)
    print("INST", hist.data["Instrument Parameters"][0], flush=True)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("HAP", phase.name, "size", hap["Size"], "mustrain", hap["Mustrain"], flush=True)


def phase_profile_flags(project: G2.G2Project, enabled: bool) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [enabled, False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])
        if hap["Mustrain"][0] == "uniaxial":
            hap["Mustrain"][2] = [enabled, enabled, False]
        else:
            hap["Mustrain"][2] = [enabled, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def instrument_flags(hist: G2.G2PwdrData, keys: list[str], enabled: bool) -> None:
    inst = hist.data["Instrument Parameters"][0]
    for key in keys:
        inst[key][2] = enabled


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--out", default=".tmp/final_profile")
    args = parser.parse_args()
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input, newgpx=str(outdir / "profile.gpx"))
    G2.SetPrintLevel("warn")
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.2
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    project.data["Constraints"]["data"]["Phase"] = []
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sp = hist.data["Sample Parameters"]

    # Retain the bounded phase Uiso estimates and make the project replayable.
    for atom in project.phase(0).atoms():
        atom.uiso = 0.0133168771
        atom.refinement_flags = " "
    for atom in project.phase(1).atoms():
        atom.uiso = 0.020
        atom.refinement_flags = " "
    for key in ["Shift", "SurfRoughA", "SurfRoughB"]:
        if key in sp and isinstance(sp[key], list):
            sp[key][1] = False
    instrument_flags(hist, ["Zero", "Polariz.", "U", "W", "X", "SH/L"], False)
    phase_profile_flags(project, False)
    project.refine()
    checkpoint(project, outdir, "fixed_uiso")

    # Phase-specific broadening with the common instrument fixed.
    for pidx in range(2):
        for suffix, lo, hi in [("Size;i", 0.04, 1.5), ("Mustrain;i", 0.0, 8000.0), ("Mustrain;a", 0.0, 8000.0)]:
            project.set_Controls("parmMin", lo, variable=f"{pidx}:0:{suffix}")
            project.set_Controls("parmMax", hi, variable=f"{pidx}:0:{suffix}")
    phase_profile_flags(project, True)
    project.refine()
    checkpoint(project, outdir, "phase_profile")

    # Common instrumental broadening with phase terms held.
    phase_profile_flags(project, False)
    bounds = {"U": (0.0, 40.0), "W": (2.0, 40.0), "X": (0.1, 6.0), "SH/L": (0.005, 0.1)}
    for key, (lo, hi) in bounds.items():
        project.set_Controls("parmMin", lo, variable=f":0:{key}")
        project.set_Controls("parmMax", hi, variable=f":0:{key}")
    instrument_flags(hist, list(bounds), True)
    project.refine()
    checkpoint(project, outdir, "instrument_profile")

    # Final phase update at the accepted common instrument.
    instrument_flags(hist, list(bounds), False)
    phase_profile_flags(project, True)
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    project.refine()
    checkpoint(project, outdir, "phase_profile_2")

    # Re-estimate polarization and a stable one-parameter roughness correction.
    phase_profile_flags(project, False)
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    inst["Polariz."][2] = True
    sp["SurfRoughB"] = [0.02, False]
    sp["SurfRoughA"][1] = True
    project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
    project.refine()
    checkpoint(project, outdir, "polarization_roughness")


if __name__ == "__main__":
    main()
