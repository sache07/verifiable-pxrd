#!/usr/bin/env python3
"""Refine only the bixbyite oxygen site from a heavy-atom checkpoint."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    output = Path(args.output).resolve()
    project = G2.G2Project(args.input, newgpx=str(output))
    G2.SetPrintLevel("warn")
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.15
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    for val in hist.data["Instrument Parameters"][0].values():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    for atom in project.phase(1).atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    project.refine()
    project.save()
    print("wR", hist.get_wR())
    for phase in project.phases():
        phase.export_CIF(str(output.with_name(output.stem + "_" + phase.name + ".cif")))
        for atom in phase.atoms():
            print(phase.name, atom.label, atom.coordinates, atom.refinement_flags)


if __name__ == "__main__":
    main()
