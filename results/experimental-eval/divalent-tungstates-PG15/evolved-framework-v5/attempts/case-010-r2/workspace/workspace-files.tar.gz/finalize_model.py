#!/usr/bin/env python3
"""Create the frozen full-grid project and exports from the accepted checkpoint."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histogram(0)
    values = np.array(
        [
            phase.data["Histograms"][hist.name]["Scale"][0]
            * phase.data["General"]["Mass"]
            for phase in project.phases()
        ],
        float,
    )
    return (values / values.sum()).tolist()


def freeze(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key, value in hist.data["Sample Parameters"].items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    args = parser.parse_args()
    root = Path.cwd()
    final = root / "final.gpx"
    project = G2.G2Project(args.input, newgpx=str(final))
    G2.SetPrintLevel("warn")
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["shift factor"] = 0.15
    hist = project.histogram(0)
    x = np.asarray(hist.data["data"][1][0], float)
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    # The accepted checkpoint has only background, cell and phase scales active.
    # Refit those over the exact supplied grid.
    project.refine()
    active_wr = float(hist.get_wR())
    active_fractions = fractions(project)

    # Freeze every parameter and force a zero-cycle replay. This guarantees that
    # the saved arrays, CIFs and fractions all arise from the persisted model.
    freeze(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(final))
    replay_wr = float(hist.get_wR())
    replay_fractions = fractions(project)

    names = ["phase_WO3.cif", "phase_Mn2O3.cif"]
    for phase, name in zip(project.phases(), names):
        phase.export_CIF(str(root / name))

    arrays = [np.asarray(v, float) for v in hist.data["data"][1]]
    xx, yobs, weights, ycalc, ybkg, ydiff = arrays
    with (root / "inputs" / "pattern.csv").open(newline="") as source:
        rows = list(csv.reader(source))
    original_x = [row[0] for row in rows[1:]]
    if len(original_x) != len(xx):
        raise ValueError("input and GSAS-II profile grids have different lengths")
    with (root / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        writer.writerows(zip(original_x, yobs, ycalc, ydiff))

    residuals = dict(hist.data["data"][0])
    cov = project.data.get("Covariance", {}).get("data", {})
    summary = {
        "histogram": hist.name,
        "active_refinement_Rwp_percent": active_wr,
        "replay_Rwp_percent": replay_wr,
        "active_fractions": active_fractions,
        "replay_fractions": replay_fractions,
        "cells": [phase.get_cell() for phase in project.phases()],
        "space_groups": [phase.data["General"]["SGData"]["SpGrp"] for phase in project.phases()],
        "residuals": {
            key: value
            for key, value in residuals.items()
            if isinstance(value, (int, float, str, bool))
        },
        "covariance_Rvals": {
            key: value
            for key, value in cov.get("Rvals", {}).items()
            if isinstance(value, (int, float, str, bool))
        },
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "profiles": {
            phase.name: {
                "scale": phase.data["Histograms"][hist.name]["Scale"],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
                "preferred_orientation": phase.data["Histograms"][hist.name]["Pref.Ori."],
            }
            for phase in project.phases()
        },
        "profile_rows": int(len(xx)),
        "profile_minmax": [float(xx[0]), float(xx[-1])],
        "edge_ycalc": [float(ycalc[0]), float(ycalc[-1])],
    }
    (root / ".tmp" / "final_summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
