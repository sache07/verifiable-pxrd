#!/usr/bin/env python3
"""Refine one constrained isotropic displacement parameter per phase."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    output = Path(args.output).resolve()
    project = G2.G2Project(args.input, newgpx=str(output))
    G2.SetPrintLevel("warn")
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.2
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)
    # Keep the accepted profile/specimen values fixed while Uiso is estimated.
    for val in hist.data["Instrument Parameters"][0].values():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    for key in ["Shift", "SurfRoughA", "SurfRoughB"]:
        if key in hist.data["Sample Parameters"] and isinstance(hist.data["Sample Parameters"][key], list):
            hist.data["Sample Parameters"][key][1] = False
    for pidx, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        vars_ = []
        for aidx, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            var = f"{pidx}::AUiso:{aidx}"
            vars_.append(var)
            project.set_Controls("parmMin", 0.003, variable=var)
            project.set_Controls("parmMax", 0.020, variable=var)
        if len(vars_) > 1:
            project.add_EquivConstr(vars_, reloadIdx=True)
    project.refine()
    project.save()
    print("wR", hist.get_wR())
    for phase in project.phases():
        print("PHASE", phase.name)
        phase.export_CIF(str(output.with_name(output.stem + "_" + phase.name + ".cif")))
        for atom in phase.atoms():
            print(atom.label, atom.element, atom.uiso, atom.refinement_flags)


if __name__ == "__main__":
    main()
