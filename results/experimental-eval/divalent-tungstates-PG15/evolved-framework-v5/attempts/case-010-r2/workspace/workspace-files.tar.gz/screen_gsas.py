#!/usr/bin/env python3
"""Screen candidate COD structures against the specimen with GSAS-II.

This script is exploratory. It creates one single-phase project per candidate,
uses identical Poisson weights and refinement stages, and prints comparable
Rietveld residuals and fitted cells.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_files(outdir: Path) -> tuple[Path, Path]:
    outdir.mkdir(parents=True, exist_ok=True)
    raw = np.genfromtxt(ROOT / "inputs/pattern.csv", delimiter=",", names=True)
    x = np.asarray(raw["two_theta_deg"], dtype=float)
    y = np.asarray(raw["intensity"], dtype=float)
    xye = outdir / "pattern.xye"
    np.savetxt(xye, np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]), fmt="%.8f %.8f %.8f")
    inst = outdir / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha lab data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.10;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst


def stage(project: G2.G2Project, label: str) -> float:
    project.refine()
    hist = project.histogram(0)
    wr = float(hist.get_wR())
    print(f"STAGE {label:>18s}  wR={wr:10.5f}", flush=True)
    return wr


def fit_one(cod_id: str, outdir: Path, xye: Path, inst: Path) -> dict:
    print(f"\n=== {cod_id} ===", flush=True)
    gpx = outdir / f"{cod_id}.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    phase = project.add_phase(
        str(cod_path(cod_id)), phasename=f"COD_{cod_id}", fmthint="CIF"
    )
    hist = project.add_powder_histogram(
        str(xye), str(inst), phases=[phase], fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    # Fix the histogram scale so independent HAP scales are identifiable.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1100.0] + [0.0] * 11,
                "refine": True,
            },
        }
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.20
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    phase.set_HAP_refinements({"Scale": True})
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.25
    # Keep nonlinear trial steps in a physically useful range.
    project.set_Controls("parmMin", 0.0, variable="0:0:Scale")
    project.set_Controls("parmMax", 1000.0, variable="0:0:Scale")
    project.set_Controls("parmMin", -0.5, variable=":0:Zero")
    project.set_Controls("parmMax", 0.5, variable=":0:Zero")
    project.set_Controls("parmMin", -1000.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1000.0, variable=":0:Shift")
    avec = G2lat.cell2A(phase.data["General"]["Cell"][1:7])
    for i, val in enumerate(avec):
        width = max(abs(val) * 0.20, max(avec[:3]) * 0.02)
        low = val - width
        high = val + width
        if i < 3:
            low = max(low, val * 0.75)
        project.set_Controls("parmMin", low, variable=f"0::A{i}")
        project.set_Controls("parmMax", high, variable=f"0::A{i}")
    for key, low, high in [
        ("U", 0.0, 60.0),
        ("W", 0.1, 60.0),
        ("X", 0.01, 10.0),
        ("SH/L", 0.002, 0.2),
    ]:
        project.set_Controls("parmMin", low, variable=f":0:{key}")
        project.set_Controls("parmMax", high, variable=f":0:{key}")

    wrs = []
    wrs.append(stage(project, "scale_background"))

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    wrs.append(stage(project, "zero"))

    phase.set_refinements({"Cell": True})
    wrs.append(stage(project, "cell_zero"))

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    wrs.append(stage(project, "cell_zero_shift"))

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    wrs.append(stage(project, "instrument_profile"))

    project.save()

    instp = hist.data["Instrument Parameters"][0]
    sp = hist.data["Sample Parameters"]
    result = {
        "id": cod_id,
        "wR": wrs[-1],
        "cell": phase.get_cell(),
        "zero": instp["Zero"][1],
        "U": instp["U"][1],
        "W": instp["W"][1],
        "X": instp["X"][1],
        "SH/L": instp["SH/L"][1],
        "shift": sp["Shift"][0],
        "scale": hap["Scale"][0],
        "size": hap["Size"][1],
        "mustrain": hap["Mustrain"][1],
    }
    print("RESULT", result, flush=True)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("ids", nargs="+")
    parser.add_argument("--out", default=".tmp/gsas_screen")
    args = parser.parse_args()
    outdir = (ROOT / args.out).resolve()
    xye, inst = prepare_files(outdir)
    G2.SetPrintLevel("warn")
    results = []
    for cod_id in args.ids:
        try:
            results.append(fit_one(cod_id, outdir, xye, inst))
        except Exception as exc:
            print(f"FAILED {cod_id}: {type(exc).__name__}: {exc}", flush=True)
    print("\n=== SUMMARY ===")
    for item in sorted(results, key=lambda d: d["wR"]):
        print(item["id"], item["wR"], item["cell"])


if __name__ == "__main__":
    main()
