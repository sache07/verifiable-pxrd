#!/usr/bin/env python3
"""Evaluate a bounded interpolation toward a coordinate-refinement trial."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("base", type=Path)
parser.add_argument("trial", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("phase")
parser.add_argument("elements", help="comma-separated element symbols")
parser.add_argument("fraction", type=float)
args = parser.parse_args()
elements = set(args.elements.split(","))

G2.SetPrintLevel("warn")
args.output.parent.mkdir(parents=True, exist_ok=True)
project = G2.G2Project(str(args.base.resolve()), newgpx=str(args.output.resolve()))
trial = G2.G2Project(str(args.trial.resolve()))
hist = project.histogram(0)
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
for phase in project.phases():
    phase.clear_refinements({"Cell": False})
    phase.clear_HAP_refinements({"Size": False, "Mustrain": False, "Pref.Ori.": False}, [hist])
    for atom in phase.atoms():
        atom.refinement_flags = " "

base_phase = project.phase(args.phase)
trial_phase = trial.phase(args.phase)
for atom in base_phase.atoms():
    if atom.element not in elements:
        continue
    target = trial_phase.atom(atom.label)
    delta = np.asarray(target.coordinates) - np.asarray(atom.coordinates)
    delta -= np.round(delta)
    atom.coordinates = np.asarray(atom.coordinates) + args.fraction * delta

project.set_Controls("cycles", 10)
project.refine(makeBack=False)
project.save()
for phase in project.phases():
    phase.export_CIF(str(args.output.with_name(args.output.stem + "-" + phase.name + ".cif")))

result = {
    "phase": args.phase,
    "elements": sorted(elements),
    "fraction": args.fraction,
    "Rwp_percent": hist.get_wR(),
    "GOF": project.data["Covariance"]["data"]["Rvals"].get("GOF"),
    "mass_fractions": {
        key: [float(x) for x in value] for key, value in hist.ComputeMassFracs().items()
    },
    "coordinates": {
        atom.label: [float(x) for x in atom.coordinates] for atom in base_phase.atoms()
    },
}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
