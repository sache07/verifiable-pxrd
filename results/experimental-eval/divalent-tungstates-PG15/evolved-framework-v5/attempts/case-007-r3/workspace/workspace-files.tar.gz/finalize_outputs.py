#!/usr/bin/env python3
"""Freeze the selected GSAS-II checkpoint and export consistent deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


root = Path(__file__).resolve().parent
source = Path(sys.argv[1]).resolve()
final_gpx = root / "final.gpx"

G2.SetPrintLevel("warn")
project = G2.G2Project(str(source), newgpx=str(final_gpx))
project.save()
hist = project.histogram(0)
x, observed, weights, calculated, background, difference = [
    np.asarray(values, dtype=float) for values in hist.data["data"][1]
]

phase_files = {
    "MgWO4": "MgWO4.cif",
    "WO3": "WO3.cif",
    "MgO": "MgO.cif",
}
for phase in project.phases():
    phase.export_CIF(str(root / phase_files[phase.name]))

with (root / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(["two_theta", "observed", "calculated", "difference", "background"])
    for row in zip(x, observed, calculated, difference, background):
        writer.writerow([f"{row[0]:.8f}", f"{row[1]:.8f}", *(f"{v:.10f}" for v in row[2:])])

mass_fractions = hist.ComputeMassFracs()
denominator = float(np.sum(weights * observed**2))
chi_squared = float(np.sum(weights * (observed - calculated) ** 2))
n_variables = len(project.data["Covariance"]["data"].get("varyList", []))
rwp = float(100 * np.sqrt(chi_squared / denominator))
rp = float(100 * np.sum(np.abs(observed - calculated)) / np.sum(observed))
rexp = float(100 * np.sqrt((len(observed) - n_variables) / denominator))
gof = float(project.data["Covariance"]["data"]["Rvals"]["GOF"])

provenance = {
    "MgWO4": "COD 9013902; refined wolframite-type MgWO4",
    "WO3": "COD 2311041; refined room-temperature monoclinic WO3 neutron model",
    "MgO": "COD 9000499; refined rocksalt MgO",
}
phase_rows = []
for phase in project.phases():
    fraction, sigma = mass_fractions[phase.name]
    phase_rows.append(
        {
            "name": phase.name,
            "formula": phase.name,
            "cif_path": phase_files[phase.name],
            "weight_fraction": float(fraction),
            "weight_fraction_standard_uncertainty": float(sigma),
            "provenance": provenance[phase.name],
            "cell": phase.get_cell(),
        }
    )

result = {
    "schema_version": 1,
    "refinement_histogram": hist.name,
    "phases": phase_rows,
    "fit_statistics": {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "Rexp_percent": rexp,
        "goodness_of_fit": gof,
        "chi_squared": chi_squared,
        "n_points": int(len(observed)),
        "n_refined_variables_last_cycle": int(n_variables),
        "weighting": "Poisson, w=1/max(observed_counts,1)",
    },
}
(root / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
