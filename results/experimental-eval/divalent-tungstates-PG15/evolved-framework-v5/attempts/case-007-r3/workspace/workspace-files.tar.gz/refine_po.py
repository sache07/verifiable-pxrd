#!/usr/bin/env python3
"""Test one bounded March-Dollase preferred-orientation branch."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("phase")
parser.add_argument("axis", help="comma-separated h,k,l")
args = parser.parse_args()
axis = [int(x) for x in args.axis.split(",")]

G2.SetPrintLevel("warn")
args.output.parent.mkdir(parents=True, exist_ok=True)
project = G2.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
hist = project.histogram(0)
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
for phase in project.phases():
    phase.clear_refinements({"Cell": False})
    phase.clear_HAP_refinements(
        {"Size": False, "Mustrain": False, "Pref.Ori.": False}, [hist]
    )
    for atom in phase.atoms():
        atom.refinement_flags = " "

phase = project.phase(args.phase)
po = phase.data["Histograms"][hist.name]["Pref.Ori."]
po[0] = "MD"
po[1] = 1.0
po[2] = True
po[3] = axis
project.set_Controls("cycles", 15)
project.refine(makeBack=False)
project.save()

result = {
    "phase": args.phase,
    "axis": axis,
    "ratio": phase.data["Histograms"][hist.name]["Pref.Ori."][1],
    "Rwp_percent": hist.get_wR(),
    "GOF": project.data["Covariance"]["data"]["Rvals"].get("GOF"),
    "converged": project.data["Covariance"]["data"]["Rvals"].get("converged"),
    "mass_fractions": {
        key: [float(x) for x in value] for key, value in hist.ComputeMassFracs().items()
    },
}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
