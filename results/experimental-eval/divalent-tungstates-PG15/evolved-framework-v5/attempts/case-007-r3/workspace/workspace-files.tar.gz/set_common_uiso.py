#!/usr/bin/env python3
"""Evaluate one bounded common isotropic displacement value for a phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("phase")
parser.add_argument("uiso", type=float)
args = parser.parse_args()

G2.SetPrintLevel("warn")
args.output.parent.mkdir(parents=True, exist_ok=True)
project = G2.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
hist = project.histogram(0)
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
for phase in project.phases():
    phase.clear_refinements({"Cell": False})
    phase.clear_HAP_refinements({"Size": False, "Mustrain": False, "Pref.Ori.": False}, [hist])
    for atom in phase.atoms():
        atom.refinement_flags = " "

phase = project.phase(args.phase)
for atom in phase.atoms():
    atom.uiso = args.uiso
project.set_Controls("cycles", 12)
project.refine(makeBack=False)
project.save()
for phase_obj in project.phases():
    phase_obj.export_CIF(
        str(args.output.with_name(args.output.stem + "-" + phase_obj.name + ".cif"))
    )

result = {
    "phase": args.phase,
    "uiso_A2": args.uiso,
    "Rwp_percent": hist.get_wR(),
    "GOF": project.data["Covariance"]["data"]["Rvals"].get("GOF"),
    "mass_fractions": {
        key: [float(x) for x in value] for key, value in hist.ComputeMassFracs().items()
    },
}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
