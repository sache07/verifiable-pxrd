#!/usr/bin/env python3
"""Apply one controlled GSAS-II refinement stage to a saved checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def clear_atoms(project: G2.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def set_coord_flags(phase: G2.G2Phase, elements: set[str]) -> None:
    for atom in phase.atoms():
        if atom.element in elements:
            atom.refinement_flags = "X"


def summary(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    return {
        "Rwp_percent": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "converged": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("converged"),
        "mass_fractions": {
            key: [float(x) for x in val] for key, val in hist.ComputeMassFracs().items()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "coordinates": {
            phase.name: {
                atom.label: [float(x) for x in atom.coordinates] for atom in phase.atoms()
            }
            for phase in project.phases()
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "stage",
        choices=[
            "mgwo4_W", "wo3_W", "mgwo4_light", "wo3_O", "mgwo4_WU",
            "wo3_WU", "mgo_U",
            "mgwo4_size", "mgwo4_strain", "wo3_size", "wo3_strain",
            "mgo_size", "mgo_strain", "inst_W", "inst_U", "inst_X",
            "inst_SHL", "polarization", "zero", "shift", "mgwo4_cell",
            "wo3_cell", "mgo_cell", "calculate",
        ],
    )
    parser.add_argument("--cycles", type=int, default=10)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    clear_atoms(project)
    if args.stage in {
        "mgwo4_W", "wo3_W", "mgwo4_light", "wo3_O", "mgwo4_WU",
        "wo3_WU", "mgo_U",
    }:
        hist.clear_refinements(
            {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
        )
        hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
        for phase in project.phases():
            phase.clear_refinements({"Cell": False})
            phase.clear_HAP_refinements(
                {"Size": False, "Mustrain": False, "Pref.Ori.": False}, [hist]
            )
    if args.stage == "mgwo4_W":
        set_coord_flags(project.phase("MgWO4"), {"W"})
    elif args.stage == "wo3_W":
        set_coord_flags(project.phase("WO3"), {"W"})
    elif args.stage == "mgwo4_light":
        set_coord_flags(project.phase("MgWO4"), {"Mg", "O"})
    elif args.stage == "wo3_O":
        set_coord_flags(project.phase("WO3"), {"O"})
    elif args.stage == "mgwo4_WU":
        for atom in project.phase("MgWO4").atoms():
            if atom.element == "W":
                atom.refinement_flags = "U"
    elif args.stage == "wo3_WU":
        for atom in project.phase("WO3").atoms():
            if atom.element == "W":
                atom.refinement_flags = "U"
    elif args.stage == "mgo_U":
        for atom in project.phase("MgO").atoms():
            atom.refinement_flags = "U"
    elif args.stage in {
        "mgwo4_size", "mgwo4_strain", "wo3_size", "wo3_strain",
        "mgo_size", "mgo_strain", "inst_W", "inst_U", "inst_X",
        "inst_SHL", "polarization", "zero", "shift", "mgwo4_cell",
        "wo3_cell", "mgo_cell",
    }:
        # Preserve the accepted cell/calibration checkpoint while profile terms
        # are tested individually.
        hist.clear_refinements(
            {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
        )
        hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
        for phase in project.phases():
            phase.clear_refinements({"Cell": False})
            phase.clear_HAP_refinements({"Size": False, "Mustrain": False}, [hist])
        phase_map = {"mgwo4": "MgWO4", "wo3": "WO3", "mgo": "MgO"}
        prefix = args.stage.split("_")[0]
        if args.stage == "zero":
            hist.set_refinements({"Instrument Parameters": ["Zero"]})
        elif args.stage == "shift":
            hist.set_refinements({"Sample Parameters": ["Shift"]})
        elif args.stage.endswith("_cell"):
            project.phase(phase_map[prefix]).set_refinements({"Cell": True})
        elif prefix in phase_map:
            phase = project.phase(phase_map[prefix])
            term = args.stage.split("_")[1]
            if term == "size":
                phase.set_HAP_refinements(
                    {"Size": {"type": "isotropic", "refine": True}}, [hist]
                )
            else:
                phase.set_HAP_refinements(
                    {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
                )
        elif args.stage == "polarization":
            hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        else:
            names = {"inst_W": "W", "inst_U": "U", "inst_X": "X", "inst_SHL": "SH/L"}
            hist.set_refinements({"Instrument Parameters": [names[args.stage]]})

    project.set_Controls("cycles", args.cycles)
    project.refine(makeBack=False)
    project.save()
    for phase in project.phases():
        phase.export_CIF(str(args.output.with_name(args.output.stem + "-" + phase.name + ".cif")))
    result = summary(project)
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
