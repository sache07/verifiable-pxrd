#!/usr/bin/env python3
"""Test one uniaxial microstrain branch."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("phase")
parser.add_argument("axis", help="comma-separated h,k,l")
args = parser.parse_args()
axis = [int(x) for x in args.axis.split(",")]

G2.SetPrintLevel("warn")
args.output.parent.mkdir(parents=True, exist_ok=True)
project = G2.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
hist = project.histogram(0)
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
for phase in project.phases():
    phase.clear_refinements({"Cell": False})
    phase.clear_HAP_refinements({"Size": False, "Mustrain": False, "Pref.Ori.": False}, [hist])
    for atom in phase.atoms():
        atom.refinement_flags = " "

phase = project.phase(args.phase)
strain = phase.data["Histograms"][hist.name]["Mustrain"]
base = float(strain[1][0])
strain[0] = "uniaxial"
strain[1][0] = base
strain[1][1] = base
strain[2] = [True, True, False]
strain[3] = axis
project.set_Controls("cycles", 20)
project.refine(makeBack=False)
project.save()

strain = phase.data["Histograms"][hist.name]["Mustrain"]
result = {
    "phase": args.phase,
    "axis": axis,
    "equatorial_microstrain_ppm": strain[1][0],
    "axial_microstrain_ppm": strain[1][1],
    "axial_ratio": strain[1][1] / strain[1][0] if strain[1][0] else None,
    "Rwp_percent": hist.get_wR(),
    "GOF": project.data["Covariance"]["data"]["Rvals"].get("GOF"),
    "converged": project.data["Covariance"]["data"]["Rvals"].get("converged"),
}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
