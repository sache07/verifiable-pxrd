#!/usr/bin/env python3
"""Refine the two-parameter Suortti surface-roughness correction."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("A", type=float)
parser.add_argument("B", type=float)
args = parser.parse_args()

G2.SetPrintLevel("warn")
args.output.parent.mkdir(parents=True, exist_ok=True)
project = G2.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
hist = project.histogram(0)
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
for phase in project.phases():
    phase.clear_refinements({"Cell": False})
    phase.clear_HAP_refinements({"Size": False, "Mustrain": False, "Pref.Ori.": False}, [hist])
    for atom in phase.atoms():
        atom.refinement_flags = " "
hist.SampleParameters["SurfRoughA"] = [args.A, True]
hist.SampleParameters["SurfRoughB"] = [args.B, True]
project.set_Controls("cycles", 20)
project.refine(makeBack=False)
project.save()

result = {
    "SurfRoughA": hist.SampleParameters["SurfRoughA"][0],
    "SurfRoughB": hist.SampleParameters["SurfRoughB"][0],
    "Rwp_percent": hist.get_wR(),
    "GOF": project.data["Covariance"]["data"]["Rvals"].get("GOF"),
    "converged": project.data["Covariance"]["data"]["Rvals"].get("converged"),
}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
