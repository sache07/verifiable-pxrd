#!/usr/bin/env python3
"""Build comparable three-phase GSAS-II branches for WO3 model selection."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    out = {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "instrument": {
            key: value[1]
            for key, value in hist.data["Instrument Parameters"][0].items()
            if isinstance(value, list) and len(value) >= 3
        },
        "sample": {
            key: value[0]
            for key, value in hist.data["Sample Parameters"].items()
            if isinstance(value, list) and len(value) >= 2
        },
        "phase_scales": {
            phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()
        },
        "profiles": {
            phase.name: {
                "Size": phase.data["Histograms"][hist.name]["Size"],
                "Mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
                "Pref.Ori.": phase.data["Histograms"][hist.name]["Pref.Ori."],
            }
            for phase in project.phases()
        },
    }
    try:
        out["mass_fractions"] = {
            key: [float(v) for v in value] for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    return out


def refine(project: G2.G2Project, label: str, history: list[dict], cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    rec = snapshot(project, label)
    history.append(rec)
    print(label, "Rwp", rec["Rwp_percent"], "GOF", rec["GOF"], flush=True)


def build(wo3_id: str, output: Path, quick: bool = False) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(output / "branch.gpx"))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma/tab/semicolon separated",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-300.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 15,
                "coeffs": [750.0] + [0.0] * 14,
                "refine": True,
            },
        }
    )

    phase_specs = [
        ("MgWO4", "9013902", 0.72),
        ("WO3", wo3_id, 0.24),
        ("MgO", "9000499", 0.04),
    ]
    phases = []
    for name, cod_id, fraction in phase_specs:
        phase = project.add_phase(
            str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"])
        hap["Scale"] = [3.0e6 * fraction / mass, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        phases.append(phase)

    history: list[dict] = []
    # Place the reference patterns with common specimen displacement first.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "scale_background_zero", history, cycles=6)

    # Separate the constant zero term from the specimen-height cosine term.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "add_specimen_shift", history, cycles=6)

    # Lattice mismatch is expected for every database reference.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "add_all_cells", history, cycles=8)

    if quick:
        project.save(str(output / "branch.gpx"))
        result = {
            "wo3_cod_id": wo3_id,
            "project": str(output / "branch.gpx"),
            "history": history,
        }
        (output / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
        return result

    # Fit each phase's supported isotropic broadening without intensity-shape terms.
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, "add_profiles", history)

    project.save(str(output / "branch.gpx"))
    result = {
        "wo3_cod_id": wo3_id,
        "project": str(output / "branch.gpx"),
        "history": history,
    }
    (output / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("output", type=Path)
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    try:
        result = build(args.wo3_id, args.output.resolve(), quick=args.quick)
        print(json.dumps(result["history"][-1], indent=2))
        return 0
    except Exception:
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
