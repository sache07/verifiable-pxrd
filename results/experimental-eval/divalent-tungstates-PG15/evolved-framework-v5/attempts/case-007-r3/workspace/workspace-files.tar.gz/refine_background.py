#!/usr/bin/env python3
"""Evaluate a smooth Chebyshev background order at a fixed model checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("terms", type=int)
args = parser.parse_args()
G2.SetPrintLevel("warn")
args.output.parent.mkdir(parents=True, exist_ok=True)
project = G2.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
hist = project.histogram(0)
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
for phase in project.phases():
    phase.clear_refinements({"Cell": False})
    phase.clear_HAP_refinements({"Size": False, "Mustrain": False, "Pref.Ori.": False}, [hist])
    for atom in phase.atoms():
        atom.refinement_flags = " "
hist.set_refinements(
    {"Background": {"type": "chebyschev-1", "no. coeffs": args.terms, "refine": True}}
)
project.set_Controls("cycles", 15)
project.refine(makeBack=False)
project.save()
result = {
    "terms": args.terms,
    "Rwp_percent": hist.get_wR(),
    "GOF": project.data["Covariance"]["data"]["Rvals"].get("GOF"),
    "mass_fractions": {
        key: [float(x) for x in value] for key, value in hist.ComputeMassFracs().items()
    },
}
args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
