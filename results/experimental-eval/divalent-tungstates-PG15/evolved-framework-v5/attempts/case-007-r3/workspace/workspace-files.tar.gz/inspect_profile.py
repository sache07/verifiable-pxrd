#!/usr/bin/env python3
"""Export diagnostic plots and residual extrema from a GSAS-II project."""

from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2


project = G2.G2Project(sys.argv[1])
stem = Path(sys.argv[2])
hist = project.histogram(0)
x, obs, wt, calc, bkg, diff = [np.asarray(a, dtype=float) for a in hist.data["data"][1]]

np.savez_compressed(stem.with_suffix(".npz"), x=x, obs=obs, wt=wt, calc=calc, bkg=bkg, diff=diff)

sm = gaussian_filter1d(diff, 2.0)
pos, pprop = find_peaks(sm, prominence=80, distance=5)
neg, nprop = find_peaks(-sm, prominence=80, distance=5)
print("Rwp", hist.get_wR())
print("positive residual extrema")
for idx in np.argsort(pprop["prominences"])[::-1][:50]:
    i = pos[idx]
    print(f"{x[i]:9.4f} {diff[i]:10.2f} {pprop['prominences'][idx]:10.2f}")
print("negative residual extrema")
for idx in np.argsort(nprop["prominences"])[::-1][:50]:
    i = neg[idx]
    print(f"{x[i]:9.4f} {diff[i]:10.2f} {nprop['prominences'][idx]:10.2f}")
