#!/usr/bin/env python3
"""Plot arrays exported by inspect_profile.py."""

from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


source = Path(sys.argv[1])
output = Path(sys.argv[2])
data = np.load(source)
x, obs, calc, bkg, diff = [data[key] for key in ["x", "obs", "calc", "bkg", "diff"]]
fig, axes = plt.subplots(4, 1, figsize=(15, 13), constrained_layout=True)
axes[0].plot(x, obs, color="black", lw=0.6, label="observed")
axes[0].plot(x, calc, color="crimson", lw=0.7, label="calculated")
axes[0].plot(x, bkg, color="royalblue", lw=0.6, label="background")
axes[0].legend(ncol=3)
axes[0].set_xlim(10, 100)
axes[0].set_ylabel("counts")
for ax, limits in zip(axes[1:], [(10, 40), (40, 70), (70, 100)]):
    mask = (x >= limits[0]) & (x <= limits[1])
    ax.plot(x[mask], diff[mask], color="black", lw=0.6)
    ax.axhline(0, color="crimson", lw=0.5)
    ax.set_xlim(*limits)
    ax.set_ylabel("obs - calc")
axes[-1].set_xlabel(r"2$\theta$ (deg)")
fig.savefig(output, dpi=160)
