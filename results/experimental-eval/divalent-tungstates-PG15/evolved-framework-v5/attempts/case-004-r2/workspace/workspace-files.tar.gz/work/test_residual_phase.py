from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "work" / "oxygen_line_search" / "zn_0.180" / "fit.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = {
    "CoO": ("1541662", "CoO"),
    "Co3O4": ("9005896", "Co3O4"),
}


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main(candidate: str) -> None:
    if candidate not in CANDIDATES:
        raise SystemExit("usage: test_residual_phase.py CoO|Co3O4")
    G2.SetPrintLevel("error")
    cod_id, phase_name = CANDIDATES[candidate]
    out = ROOT / "work" / "residual_tests" / candidate
    out.mkdir(parents=True, exist_ok=True)
    g = G2.G2Project(str(SRC), newgpx=str(out / "fit.gpx"))
    h = g.histogram(0)
    candidate_phase = g.add_phase(
        str(cod_path(cod_id)), phasename=phase_name, histograms=[h], fmthint="CIF"
    )

    h.clear_refinements({"Background": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]})
    h.clear_refinements({"Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for p in g.phases():
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        p.set_HAP_refinements({"Scale": True})
        for atom in p.atoms():
            atom.refinement_flags = " "
    hap = candidate_phase.data["Histograms"][h.name]
    hap["Scale"] = [0.05, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.10
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    controls = g.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    g.set_Controls("cycles", 6)
    g.refine()
    refined_rwp = g.histogram(0).residuals.get("wR")
    vary = g.data["Covariance"]["data"].get("varyList", [])
    vals = g.data["Covariance"]["data"].get("variables", [])
    sigs = g.data["Covariance"]["data"].get("sig", [])
    scale_detail = {
        str(name): {"value": float(value), "sigma": float(sig)}
        for name, value, sig in zip(vary, vals, sigs)
        if str(name).endswith(":Scale")
    }

    for p in g.phases():
        p.clear_HAP_refinements({"Scale": True})
    g.set_Controls("cycles", 0)
    g.refine()
    g.save()
    h = g.histogram(0)
    mass_terms = {
        p.name: p.data["Histograms"][h.name]["Scale"][0] * p.data["General"]["Mass"]
        for p in g.phases()
    }
    positive_total = sum(max(0.0, value) for value in mass_terms.values())
    result = {
        "candidate": candidate,
        "cod_id": cod_id,
        "refined_rwp": refined_rwp,
        "replay_rwp": h.residuals.get("wR"),
        "scale_detail": scale_detail,
        "phase_scales": {
            p.name: p.data["Histograms"][h.name]["Scale"][0] for p in g.phases()
        },
        "positive_mass_fractions": {
            name: max(0.0, value) / positive_total for name, value in mass_terms.items()
        },
    }
    (out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "")
