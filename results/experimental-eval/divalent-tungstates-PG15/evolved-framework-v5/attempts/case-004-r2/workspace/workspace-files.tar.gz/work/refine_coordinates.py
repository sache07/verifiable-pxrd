from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "work" / "profile_screen" / "broad" / "fit.gpx"
BASE = ROOT / "work" / "coordinate_refine"

MG_COORDS = {
    "W": (0.0, 0.18190, 0.25),
    "Co": (0.5, 0.67420, 0.25),
    "O1": (0.21600, 0.10700, 0.93700),
    "O2": (0.25600, 0.37660, 0.39700),
}


def state(g: G2.G2Project, tag: str, initial: dict[tuple[str, str], tuple[float, float, float]]) -> dict:
    h = g.histogram(0)
    atoms = []
    max_disp = 0.0
    for p in g.phases():
        # Fractional displacement with minimum-image wrapping, transformed by the
        # current direct-lattice vectors.
        cell = p.data["General"]["Cell"]
        a, b, c, al, be, ga = cell[1:7]
        # GSAS-II lattice matrix convention is not exposed here; construct it.
        ar, br, gr = np.radians([al, be, ga])
        matrix = np.array(
            [
                [a, 0.0, 0.0],
                [b * np.cos(gr), b * np.sin(gr), 0.0],
                [
                    c * np.cos(br),
                    c * (np.cos(ar) - np.cos(br) * np.cos(gr)) / np.sin(gr),
                    c
                    * np.sqrt(
                        max(
                            0.0,
                            1.0
                            - np.cos(br) ** 2
                            - ((np.cos(ar) - np.cos(br) * np.cos(gr)) / np.sin(gr)) ** 2,
                        )
                    ),
                ],
            ]
        )
        for atom in p.atoms():
            key = (p.name, atom.label)
            start = np.array(initial[key], float)
            now = np.array(atom.coordinates, float)
            delta = now - start
            delta -= np.round(delta)
            disp = float(np.linalg.norm(delta @ matrix))
            max_disp = max(max_disp, disp)
            atoms.append(
                {
                    "phase": p.name,
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "uiso": atom.uiso,
                    "displacement_A": disp,
                    "flags": atom.refinement_flags,
                }
            )
    return {
        "tag": tag,
        "rwp": h.residuals.get("wR"),
        "residuals": h.residuals,
        "max_coordinate_displacement_A": max_disp,
        "atoms": atoms,
    }


def save(g: G2.G2Project, out: Path, checkpoint: str, accepted: bool = True) -> None:
    working = out / "working.gpx"
    g.save(str(working))
    shutil.copy2(working, out / f"{checkpoint}.gpx")
    if accepted:
        shutil.copy2(working, out / "accepted.gpx")
    for p in g.phases():
        p.export_CIF(str(out / f"{checkpoint}_{p.name}.cif"))


def run_trial(
    g: G2.G2Project,
    out: Path,
    tag: str,
    initial: dict[tuple[str, str], tuple[float, float, float]],
    log: list[dict],
) -> G2.G2Project:
    before = state(g, "before", initial)
    g.set_Controls("cycles", 8)
    g.refine()
    after = state(g, tag, initial)
    physical = after["max_coordinate_displacement_A"] <= 0.15
    if physical and after["rwp"] is not None and after["rwp"] <= before["rwp"] + 1e-6:
        after["accepted"] = True
        log.append(after)
        save(g, out, tag)
        print(
            f"ACCEPT {tag}: {before['rwp']:.5f} -> {after['rwp']:.5f}; "
            f"max displacement {after['max_coordinate_displacement_A']:.4f} A",
            flush=True,
        )
        return g
    after["accepted"] = False
    log.append(after)
    print(
        f"ROLLBACK {tag}: {before['rwp']:.5f} -> {after['rwp']}; "
        f"max displacement {after['max_coordinate_displacement_A']:.4f} A",
        flush=True,
    )
    return G2.G2Project(str(out / "accepted.gpx"), newgpx=str(out / "working.gpx"))


def main(start: str) -> None:
    if start not in {"zn", "mg"}:
        raise SystemExit("usage: refine_coordinates.py zn|mg")
    G2.SetPrintLevel("error")
    out = BASE / start
    out.mkdir(parents=True, exist_ok=True)
    g = G2.G2Project(str(SRC), newgpx=str(out / "working.gpx"))
    h = g.histogram(0)

    # Hold calibration, cells, background and profile at the accepted physical
    # checkpoint. Scales remain active while structure factors change.
    h.clear_refinements({"Background": True})
    h.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]}
    )
    h.clear_refinements(
        {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
    )
    for p in g.phases():
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        p.set_HAP_refinements({"Scale": True})
        for atom in p.atoms():
            atom.refinement_flags = " "

    if start == "mg":
        co = g.phase("CoWO4")
        for label, coords in MG_COORDS.items():
            co.atom(label).coordinates = coords

    # Recalculate after selecting the coordinate start so the branch baseline is
    # internally consistent (especially for the Mg analogue start).
    g.set_Controls("cycles", 0)
    g.refine()

    initial = {
        (p.name, atom.label): tuple(atom.coordinates)
        for p in g.phases()
        for atom in p.atoms()
    }
    log = [state(g, f"{start}_start", initial)]
    save(g, out, "s00_start")
    print(f"START {start} Rwp={log[0]['rwp']:.5f}", flush=True)

    for p in g.phases():
        for atom in p.atoms():
            atom.refinement_flags = "X" if atom.element in {"Co", "W"} else " "
    g = run_trial(g, out, "s01_heavy", initial, log)

    for p in g.phases():
        for atom in p.atoms():
            atom.refinement_flags = "X" if atom.element == "O" else " "
    g = run_trial(g, out, "s02_oxygen", initial, log)

    save(g, out, "s99_accepted")
    (out / "coordinate_log.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "")
