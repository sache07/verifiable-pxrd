from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "work" / "final_inventory_refine" / "accepted.gpx"
BASE = ROOT / "work" / "uiso_screen"


def clear_all(g: G2.G2Project) -> None:
    h = g.histogram(0)
    h.clear_refinements({"Background": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    h.clear_refinements({"Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for p in g.phases():
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True})
        for atom in p.atoms():
            atom.refinement_flags = " "


def parse_value(text: str) -> float | None:
    return None if text == "source" else float(text)


def main(label: str, co_value: float | None, wo_value: float | None) -> None:
    G2.SetPrintLevel("error")
    out = BASE / label
    out.mkdir(parents=True, exist_ok=True)
    g = G2.G2Project(str(SRC), newgpx=str(out / "fit.gpx"))
    if co_value is not None:
        for atom in g.phase("CoWO4").atoms():
            atom.uiso = co_value
    if wo_value is not None:
        for atom in g.phase("WO3").atoms():
            atom.uiso = wo_value
    clear_all(g)
    h = g.histogram(0)
    h.set_refinements({"Background": True})
    for p in g.phases():
        p.set_HAP_refinements({"Scale": True})
    g.set_Controls("cycles", 4)
    g.refine()
    fit_rwp = g.histogram(0).residuals.get("wR")
    clear_all(g)
    g.set_Controls("cycles", 0)
    g.refine()
    g.save()
    h = g.histogram(0)
    result = {
        "label": label,
        "co_uiso": co_value,
        "wo3_uiso": wo_value,
        "fit_rwp": fit_rwp,
        "replay_rwp": h.residuals.get("wR"),
        "scales": {p.name: p.data["Histograms"][h.name]["Scale"][0] for p in g.phases()},
    }
    (out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit("usage: screen_uiso.py LABEL CO_UISO|source WO3_UISO|source")
    main(sys.argv[1], parse_value(sys.argv[2]), parse_value(sys.argv[3]))
