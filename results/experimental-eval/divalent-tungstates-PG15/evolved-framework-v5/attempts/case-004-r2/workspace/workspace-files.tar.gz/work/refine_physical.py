from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
SOURCE = WORK / "parent_comparison" / "co_from_zn_1520641__wo3_2311041" / "compare.gpx"
OUT = WORK / "refinement"
OUT.mkdir(exist_ok=True)


def stats(g: G2.G2Project, tag: str) -> dict:
    h = g.histogram(0)
    result = {
        "tag": tag,
        "r": h.residuals,
        "instrument": {
            k: h.InstrumentParameters[k][1]
            for k in ("Zero", "U", "V", "W", "X", "SH/L")
        },
        "sample": {
            k: h.SampleParameters[k][0]
            for k in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "phases": [],
    }
    for phase in g.phases():
        hap = phase.data["Histograms"][h.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "mass": phase.data["General"]["Mass"],
                "size": hap["Size"][1][0],
                "mustrain": hap["Mustrain"][1][0],
                "md": hap["Pref.Ori."][1],
            }
        )
    return result


def save_stage(g: G2.G2Project, index: int, tag: str, log: list[dict]) -> None:
    path = OUT / f"p{index:02d}_{tag}.gpx"
    g.save(str(path))
    result = stats(g, tag)
    log.append(result)
    print(
        f"{index:02d} {tag:20s} Rwp={result['r'].get('wR', float('nan')):.5f} "
        f"Zero={result['instrument']['Zero']:.5f} Shift={result['sample']['Shift']:.2f}",
        flush=True,
    )


def set_bound(g: G2.G2Project, variable: str, low: float, high: float) -> None:
    g.set_Controls("parmMin", low, variable=variable)
    g.set_Controls("parmMax", high, variable=variable)


def refine(g: G2.G2Project, cycles: int = 8, repeats: int = 1) -> None:
    g.set_Controls("cycles", cycles)
    for _ in range(repeats):
        g.refine()


def main() -> None:
    G2.SetPrintLevel("error")
    log: list[dict] = []
    g = G2.G2Project(str(SOURCE), newgpx=str(OUT / "working.gpx"))
    h = g.histogram(0)

    # Return the broadening model to the physically allowed generator domain.
    for key, value in {"U": 20.0, "V": 0.0, "W": 20.0, "X": 3.0, "SH/L": 0.03}.items():
        h.InstrumentParameters[key][1] = value
        h.InstrumentParameters[key][2] = False
    h.InstrumentParameters["Zero"][2] = True
    h.SampleParameters["Shift"] = [0.0, False]
    h.SampleParameters["SurfRoughA"] = [0.0, False]
    h.SampleParameters["SurfRoughB"] = [0.0, False]
    for phase in g.phases():
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.20
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        phase.set_refinements({"Cell": True})
    save_stage(g, 0, "physical_reset", log)

    set_bound(g, ":0:Zero", -0.25, 0.25)
    set_bound(g, ":0:U", 0.0, 40.0)
    set_bound(g, ":0:W", 2.0, 40.0)
    set_bound(g, ":0:X", 0.1, 6.0)
    set_bound(g, ":0:SH/L", 0.005, 0.10)
    set_bound(g, ":0:Shift", -800.0, 800.0)
    for pid in range(len(g.phases())):
        set_bound(g, f"{pid}:0:Scale", 0.0, 100.0)
        set_bound(g, f"{pid}:0:Size;i", 0.04, 1.5)
        set_bound(g, f"{pid}:0:Mustrain;i", 0.0, 8000.0)

    refine(g, cycles=8, repeats=2)
    save_stage(g, 1, "scales_cells_zero", log)

    h.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(g, cycles=8, repeats=1)
    save_stage(g, 2, "common_profile", log)

    h.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine(g, cycles=8, repeats=1)
    save_stage(g, 3, "axial_divergence", log)

    for phase in g.phases():
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True, "value": 0.20}}
        )
    refine(g, cycles=8, repeats=1)
    save_stage(g, 4, "phase_size", log)

    for phase in g.phases():
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    refine(g, cycles=8, repeats=1)
    save_stage(g, 5, "phase_strain", log)

    # Separate specimen displacement from lattice metrics with cells fixed, then
    # re-release the cells for a final calibration/cell pass.
    for phase in g.phases():
        phase.clear_refinements({"Cell": True})
    h.set_refinements({"Sample Parameters": ["Shift"]})
    refine(g, cycles=8, repeats=1)
    save_stage(g, 6, "sample_shift", log)

    for phase in g.phases():
        phase.set_refinements({"Cell": True})
    refine(g, cycles=8, repeats=1)
    save_stage(g, 7, "cells_released", log)

    old = h.Background[0]
    h.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": list(old[3:]) + [0.0] * (12 - old[2]),
                "refine": True,
            }
        }
    )
    refine(g, cycles=8, repeats=1)
    save_stage(g, 8, "background12", log)
    (OUT / "physical_log.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
