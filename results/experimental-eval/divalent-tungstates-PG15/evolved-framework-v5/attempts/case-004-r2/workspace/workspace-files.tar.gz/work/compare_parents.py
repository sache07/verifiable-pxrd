from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
OUT = WORK / "parent_comparison"
OUT.mkdir(exist_ok=True)

# Stable common-profile checkpoint from the first complete two-phase fit. These
# values are held common while structural parents are compared; phase-specific
# broadening and coordinates are deliberately not varied in this screen.
PROFILE = {
    "U": 35.1180575314,
    "V": -114.6703551062,
    "W": 67.4450274183,
    "X": 15.2622059203,
    "SH/L": 0.0324444398,
    "Zero": 0.0884915649,
}
BACKGROUND = [
    855.7473043,
    -459.1744232,
    462.0861079,
    -275.5711135,
    141.2518545,
    -70.4283968,
    25.7875017,
    -15.9719926,
]


def fit_pair(co_file: str, wo_file: str) -> dict:
    label = f"{Path(co_file).stem}__{Path(wo_file).stem}"
    folder = OUT / label
    folder.mkdir(exist_ok=True)
    gpx = folder / "compare.gpx"
    if gpx.exists():
        gpx.unlink()

    g = G2.G2Project(newgpx=str(gpx))
    co = g.add_phase(str(WORK / co_file), phasename="CoWO4", fmthint="CIF")
    wo = g.add_phase(str(WORK / wo_file), phasename="WO3", fmthint="CIF")
    h = g.add_powder_histogram(
        str(WORK / "pattern.xye"),
        str(WORK / "instrument.instprm"),
        phases="all",
        fmthint="xye",
    )
    h.SampleParameters["Type"] = "Bragg-Brentano"
    h.SampleParameters["Gonio. radius"] = 200.0
    h.SampleParameters["Scale"] = [1.0, False]
    for key, value in PROFILE.items():
        h.InstrumentParameters[key][1] = value
        h.InstrumentParameters[key][2] = key == "Zero"
    h.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(BACKGROUND),
                "coeffs": BACKGROUND,
                "refine": True,
            },
        }
    )
    for phase, scale in ((co, 8.43), (wo, 6.21)):
        phase.data["Histograms"][h.name]["Scale"] = [scale, True]
        phase.set_refinements({"Cell": True})

    g.set_Controls("cycles", 8)
    g.refine()
    g.refine()
    g.save()

    result = {
        "label": label,
        "co_parent": co_file,
        "wo_parent": wo_file,
        "residuals": h.residuals,
        "zero": h.InstrumentParameters["Zero"][1],
        "phases": [],
    }
    for phase in g.phases():
        hap = phase.data["Histograms"][h.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "mass": phase.data["General"]["Mass"],
            }
        )
    (folder / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> None:
    G2.SetPrintLevel("error")
    co_models = [
        "co_from_mg_9013902.cif",
        "co_from_mn_1520200.cif",
        "co_from_zn_1520641.cif",
    ]
    wo_models = [
        "wo3_1528915.cif",
        "wo3_2311041.cif",
        "wo3_1010618.cif",
    ]
    results = []
    for co_file in co_models:
        for wo_file in wo_models:
            try:
                result = fit_pair(co_file, wo_file)
                results.append(result)
                print(f"{result['residuals']['wR']:8.4f} {result['label']}", flush=True)
            except Exception as exc:
                print(f"FAILED {co_file} {wo_file}: {type(exc).__name__}: {exc}", flush=True)
    results.sort(key=lambda item: item["residuals"]["wR"])
    (OUT / "all_results.json").write_text(json.dumps(results, indent=2) + "\n")
    print("RANKED", flush=True)
    for result in results:
        print(f"{result['residuals']['wR']:8.4f} {result['label']}", flush=True)


if __name__ == "__main__":
    main()
