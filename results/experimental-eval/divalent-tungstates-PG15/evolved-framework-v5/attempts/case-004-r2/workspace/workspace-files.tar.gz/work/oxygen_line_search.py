from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]


def main(start: str, fraction: float) -> None:
    if start not in {"zn", "mg"} or not 0.0 <= fraction <= 0.25:
        raise SystemExit("usage: oxygen_line_search.py zn|mg FRACTION_0_TO_0.25")
    G2.SetPrintLevel("error")
    source_dir = ROOT / "work" / "coordinate_refine" / start
    out = ROOT / "work" / "oxygen_line_search" / f"{start}_{fraction:.3f}"
    out.mkdir(parents=True, exist_ok=True)
    g = G2.G2Project(str(source_dir / "accepted.gpx"), newgpx=str(out / "fit.gpx"))
    h = g.histogram(0)
    log = json.loads((source_dir / "coordinate_log.json").read_text())
    rejected = next(item for item in log if item["tag"] == "s02_oxygen")
    target = {
        (item["phase"], item["label"]): np.array(item["coordinates"], float)
        for item in rejected["atoms"]
        if item["element"] == "O"
    }

    max_fractional_shift = 0.0
    for p in g.phases():
        for atom in p.atoms():
            atom.refinement_flags = " "
            if atom.element != "O":
                continue
            old = np.array(atom.coordinates, float)
            delta = target[(p.name, atom.label)] - old
            delta -= np.round(delta)
            atom.coordinates = old + fraction * delta
            max_fractional_shift = max(max_fractional_shift, float(np.linalg.norm(fraction * delta)))
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        p.set_HAP_refinements({"Scale": True})
    h.clear_refinements({"Background": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]})
    h.clear_refinements({"Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    controls = g.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    g.set_Controls("cycles", 4)
    g.refine()
    refined = g.histogram(0).residuals.get("wR")

    for p in g.phases():
        p.clear_HAP_refinements({"Scale": True})
    g.set_Controls("cycles", 0)
    g.refine()
    g.save()
    replay = g.histogram(0).residuals.get("wR")
    for p in g.phases():
        p.export_CIF(str(out / f"{p.name}.cif"))
    result = {
        "start": start,
        "fraction": fraction,
        "max_fractional_coordinate_shift": max_fractional_shift,
        "refined_rwp": refined,
        "replay_rwp": replay,
        "scales": {
            p.name: p.data["Histograms"][h.name]["Scale"][0] for p in g.phases()
        },
    }
    (out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: oxygen_line_search.py zn|mg FRACTION")
    main(sys.argv[1], float(sys.argv[2]))
