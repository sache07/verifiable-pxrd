from __future__ import annotations

import csv
import math
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def substitute_cif(cod_id: str, old: str, new: str, output: Path) -> None:
    text = cod_path(cod_id).read_text()
    text = re.sub(rf"\b{re.escape(old)}\b", new, text)
    text = re.sub(rf"\b{re.escape(old)}(?=\d)", new, text)
    output.write_text(
        f"# Analogue-derived model: COD {cod_id}, {old} replaced by {new}.\n" + text
    )


WORK.mkdir(exist_ok=True)

with (ROOT / "inputs" / "pattern.csv").open(newline="") as src, (
    WORK / "pattern.xye"
).open("w") as dst:
    rows = csv.DictReader(src)
    for row in rows:
        x = float(row["two_theta_deg"])
        y = float(row["intensity"])
        dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")

(WORK / "instrument.instprm").write_text(
    "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
    "Type:PXC;Bank:1\n"
    "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
    "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
    "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
)

parents = {
    "co_from_mg_9013902.cif": ("9013902", "Mg"),
    "co_from_mn_1520200.cif": ("1520200", "Mn"),
    "co_from_zn_1520641.cif": ("1520641", "Zn"),
    "co_from_fe_1567215.cif": ("1567215", "Fe"),
}
for name, (cod_id, old) in parents.items():
    substitute_cif(cod_id, old, "Co", WORK / name)

for cod_id in ("1528915", "2311041", "1010618", "2106293"):
    (WORK / f"wo3_{cod_id}.cif").write_text(cod_path(cod_id).read_text())

print("Prepared", WORK / "pattern.xye")
for path in sorted(WORK.glob("*.cif")):
    print(path.name)
