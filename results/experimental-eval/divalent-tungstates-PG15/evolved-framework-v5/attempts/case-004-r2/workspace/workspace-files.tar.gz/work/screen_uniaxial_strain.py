from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "work" / "microstrain_tests" / "WO3" / "accepted.gpx"
BASE = ROOT / "work" / "uniaxial_strain_screen"


def clear_all(g: G2.G2Project) -> None:
    h = g.histogram(0)
    h.clear_refinements({"Background": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    h.clear_refinements({"Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for p in g.phases():
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True})
        for atom in p.atoms():
            atom.refinement_flags = " "


def main(axis: list[int]) -> None:
    G2.SetPrintLevel("error")
    label = "".join(str(v) for v in axis)
    out = BASE / label
    out.mkdir(parents=True, exist_ok=True)
    g = G2.G2Project(str(SRC), newgpx=str(out / "fit.gpx"))
    before = g.histogram(0).residuals.get("wR")
    clear_all(g)
    h = g.histogram(0)
    h.set_refinements({"Background": True})
    for p in g.phases():
        p.set_HAP_refinements({"Scale": True})
    p = g.phase("WO3")
    ms = p.data["Histograms"][h.name]["Mustrain"]
    iso = ms[1][0]
    ms[0] = "uniaxial"
    ms[1][0] = iso
    ms[1][1] = iso
    ms[2][0] = True
    ms[2][1] = True
    ms[3] = axis
    controls = g.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    g.set_Controls("cycles", 6)
    g.refine()
    fit_rwp = g.histogram(0).residuals.get("wR")
    equatorial, axial = ms[1][0], ms[1][1]
    clear_all(g)
    g.set_Controls("cycles", 0)
    g.refine()
    replay_rwp = g.histogram(0).residuals.get("wR")
    physical = 300 <= equatorial <= 8000 and 300 <= axial <= 8000
    accepted = bool(physical and replay_rwp < before)
    g.save(str(out / ("accepted.gpx" if accepted else "rejected.gpx")))
    result = {
        "axis": axis,
        "equatorial_ppm": equatorial,
        "axial_ppm": axial,
        "before_rwp": before,
        "fit_rwp": fit_rwp,
        "replay_rwp": replay_rwp,
        "physical": bool(physical),
        "accepted": accepted,
    }
    (out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit("usage: screen_uniaxial_strain.py h k l")
    main([int(v) for v in sys.argv[1:]])
