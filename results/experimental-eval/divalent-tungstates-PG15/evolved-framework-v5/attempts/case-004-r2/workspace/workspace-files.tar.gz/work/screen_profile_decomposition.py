from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "work" / "refinement" / "p00_physical_reset.gpx"
BASE = ROOT / "work" / "profile_screen"


def clear_all(g: G2.G2Project, keep_background: bool, keep_scales: bool, keep_size: bool) -> None:
    h = g.histogram(0)
    h.clear_refinements({"Background": True})
    if keep_background:
        h.set_refinements({"Background": True})
    h.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]}
    )
    h.clear_refinements(
        {"Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]}
    )
    for p in g.phases():
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        if keep_scales:
            p.set_HAP_refinements({"Scale": True})
        if keep_size:
            p.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        for atom in p.atoms():
            atom.refinement_flags = " "


def main(label: str, u: float, w: float, x: float) -> None:
    G2.SetPrintLevel("error")
    out = BASE / label
    out.mkdir(parents=True, exist_ok=True)
    g = G2.G2Project(str(SRC), newgpx=str(out / "fit.gpx"))
    h = g.histogram(0)
    for key, value in {"U": u, "V": 0.0, "W": w, "X": x, "SH/L": 0.03}.items():
        h.InstrumentParameters[key][1] = float(value)
    # Remove the earlier boundary controls entirely for this unconstrained,
    # post-screened decomposition.
    controls = g.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    for p in g.phases():
        hap = p.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.10
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
    clear_all(g, keep_background=True, keep_scales=True, keep_size=True)
    g.set_Controls("cycles", 8)
    g.refine()
    refined_rwp = g.histogram(0).residuals.get("wR")

    # Explicit frozen-model recalculation: this is the Rwp used to rank models.
    clear_all(g, keep_background=False, keep_scales=False, keep_size=False)
    g.set_Controls("cycles", 0)
    g.refine()
    g.save()
    h = g.histogram(0)
    result = {
        "label": label,
        "refined_rwp": refined_rwp,
        "replay_rwp": h.residuals.get("wR"),
        "residuals": h.residuals,
        "instrument": {k: h.InstrumentParameters[k][1] for k in ("Zero", "U", "V", "W", "X", "SH/L")},
        "phases": [],
    }
    for p in g.phases():
        hap = p.data["Histograms"][h.name]
        result["phases"].append(
            {
                "name": p.name,
                "cell": p.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"][1][0],
                "strain": hap["Mustrain"][1][0],
            }
        )
    (out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 5:
        raise SystemExit("usage: screen_profile_decomposition.py LABEL U W X")
    main(sys.argv[1], *(float(v) for v in sys.argv[2:]))
