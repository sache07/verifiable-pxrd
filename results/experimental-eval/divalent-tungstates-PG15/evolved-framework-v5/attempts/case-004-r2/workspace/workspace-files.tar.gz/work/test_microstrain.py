from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "work" / "roughness_screen" / "high" / "accepted.gpx"
BASE = ROOT / "work" / "microstrain_tests"


def clear_all(g: G2.G2Project) -> None:
    h = g.histogram(0)
    h.clear_refinements({"Background": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    h.clear_refinements({"Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for p in g.phases():
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True})
        for atom in p.atoms():
            atom.refinement_flags = " "


def main(phase_name: str) -> None:
    if phase_name not in {"CoWO4", "WO3"}:
        raise SystemExit("usage: test_microstrain.py CoWO4|WO3")
    G2.SetPrintLevel("error")
    out = BASE / phase_name
    out.mkdir(parents=True, exist_ok=True)
    g = G2.G2Project(str(SRC), newgpx=str(out / "fit.gpx"))
    before = g.histogram(0).residuals.get("wR")
    clear_all(g)
    h = g.histogram(0)
    h.set_refinements({"Background": True})
    for p in g.phases():
        p.set_HAP_refinements({"Scale": True})
    p = g.phase(phase_name)
    hap = p.data["Histograms"][h.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    controls = g.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    g.set_Controls("cycles", 6)
    g.refine()
    fit_rwp = g.histogram(0).residuals.get("wR")
    strain = p.data["Histograms"][h.name]["Mustrain"][1][0]
    clear_all(g)
    g.set_Controls("cycles", 0)
    g.refine()
    replay_rwp = g.histogram(0).residuals.get("wR")
    physical = strain == 0.0 or 300.0 <= strain <= 8000.0
    accepted = physical and strain >= 300.0 and replay_rwp < before
    g.save(str(out / ("accepted.gpx" if accepted else "rejected.gpx")))
    result = {
        "phase": phase_name,
        "strain_ppm": strain,
        "before_rwp": before,
        "fit_rwp": fit_rwp,
        "replay_rwp": replay_rwp,
        "physical": physical,
        "accepted": accepted,
    }
    (out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "")
