from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "work" / "uniaxial_strain_screen" / "100" / "accepted.gpx"
OUT = ROOT / "work" / "polished"
OUT.mkdir(exist_ok=True)
WORKING = OUT / "working.gpx"
ACCEPTED = OUT / "accepted.gpx"


def clear_all(g: G2.G2Project) -> None:
    h = g.histogram(0)
    h.clear_refinements({"Background": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    h.clear_refinements({"Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for p in g.phases():
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True})
        for atom in p.atoms():
            atom.refinement_flags = " "


def snapshot(g: G2.G2Project, tag: str, initial_heavy: dict[tuple[str, str], np.ndarray]) -> dict:
    h = g.histogram(0)
    max_heavy_shift = 0.0
    atoms = []
    for p in g.phases():
        lengths = np.array(p.data["General"]["Cell"][1:4], float)
        for atom in p.atoms():
            if atom.element not in {"Co", "W"}:
                continue
            delta = np.array(atom.coordinates) - initial_heavy[(p.name, atom.label)]
            delta -= np.round(delta)
            shift = float(np.linalg.norm(delta * lengths))
            max_heavy_shift = max(max_heavy_shift, shift)
            atoms.append({"phase": p.name, "label": atom.label, "coordinates": list(atom.coordinates), "shift_A_approx": shift})
    phases = []
    for p in g.phases():
        hap = p.data["Histograms"][h.name]
        phases.append(
            {
                "name": p.name,
                "cell": p.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"][1][0],
                "mustrain_type": hap["Mustrain"][0],
                "mustrain": list(hap["Mustrain"][1][:2]),
                "md_ratio": hap["Pref.Ori."][1],
                "md_axis": list(hap["Pref.Ori."][3]),
            }
        )
    return {
        "tag": tag,
        "rwp": h.residuals.get("wR"),
        "residuals": h.residuals,
        "zero": h.InstrumentParameters["Zero"][1],
        "roughness_A": h.SampleParameters["SurfRoughA"][0],
        "roughness_B": h.SampleParameters["SurfRoughB"][0],
        "max_heavy_shift_A_approx": max_heavy_shift,
        "heavy_atoms": atoms,
        "phases": phases,
    }


def physical(item: dict) -> bool:
    if not (-0.25 <= item["zero"] <= 0.25):
        return False
    if not (0.05 <= item["roughness_A"] <= 0.6 and 0.02 <= item["roughness_B"] <= 0.5):
        return False
    if item["max_heavy_shift_A_approx"] > 0.10:
        return False
    for p in item["phases"]:
        if p["scale"] <= 0 or not (0.04 <= p["size"] <= 1.5) or not (0.7 <= p["md_ratio"] <= 1.4):
            return False
        if min(p["cell"]["length_a"], p["cell"]["length_b"], p["cell"]["length_c"], p["cell"]["volume"]) <= 0:
            return False
        if p["name"] == "WO3":
            if not all(300 <= value <= 8000 for value in p["mustrain"]):
                return False
    return True


def freeze_recalculate(g: G2.G2Project) -> None:
    clear_all(g)
    g.set_Controls("cycles", 0)
    g.refine()


def save(g: G2.G2Project, tag: str | None = None) -> None:
    g.save(str(WORKING))
    shutil.copy2(WORKING, ACCEPTED)
    if tag:
        shutil.copy2(WORKING, OUT / f"{tag}.gpx")


def trial(g: G2.G2Project, tag: str, log: list[dict], initial_heavy: dict, cycles: int = 6) -> G2.G2Project:
    before = snapshot(g, "before", initial_heavy)
    g.set_Controls("cycles", cycles)
    g.refine()
    fit_rwp = g.histogram(0).residuals.get("wR")
    freeze_recalculate(g)
    after = snapshot(g, tag, initial_heavy)
    after["fit_rwp_before_replay"] = fit_rwp
    if physical(after) and after["rwp"] <= before["rwp"] + 1e-6:
        after["accepted"] = True
        log.append(after)
        save(g, tag)
        print(f"ACCEPT {tag}: {before['rwp']:.5f} -> {after['rwp']:.5f}", flush=True)
        return g
    after["accepted"] = False
    log.append(after)
    print(f"ROLLBACK {tag}: {before['rwp']:.5f} -> {after['rwp']} physical={physical(after)}", flush=True)
    return G2.G2Project(str(ACCEPTED), newgpx=str(WORKING))


def enable_intensity(g: G2.G2Project) -> None:
    h = g.histogram(0)
    h.set_refinements({"Background": True, "Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for p in g.phases():
        p.set_HAP_refinements({"Scale": True, "Pref.Ori.": True})


def main() -> None:
    G2.SetPrintLevel("error")
    g = G2.G2Project(str(SRC), newgpx=str(WORKING))
    controls = g.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    initial_heavy = {
        (p.name, atom.label): np.array(atom.coordinates, float)
        for p in g.phases()
        for atom in p.atoms()
        if atom.element in {"Co", "W"}
    }
    freeze_recalculate(g)
    save(g, "u00_start")
    log = [snapshot(g, "start", initial_heavy)]
    print(f"START Rwp={log[0]['rwp']:.5f}", flush=True)

    enable_intensity(g)
    g = trial(g, "u01_intensity", log, initial_heavy)

    h = g.histogram(0)
    h.set_refinements({"Background": True})
    for p in g.phases():
        p.set_HAP_refinements({"Scale": True, "Size": {"type": "isotropic", "refine": True}})
    wo = g.phase("WO3")
    ms = wo.data["Histograms"][h.name]["Mustrain"]
    ms[0] = "uniaxial"
    ms[2][0] = ms[2][1] = True
    g = trial(g, "u02_profiles", log, initial_heavy)

    h = g.histogram(0)
    h.set_refinements({"Background": True, "Instrument Parameters": ["Zero"]})
    for p in g.phases():
        p.set_HAP_refinements({"Scale": True})
        p.set_refinements({"Cell": True})
    g = trial(g, "u03_cells", log, initial_heavy)

    h = g.histogram(0)
    h.set_refinements({"Background": True})
    for p in g.phases():
        p.set_HAP_refinements({"Scale": True})
        for atom in p.atoms():
            atom.refinement_flags = "X" if atom.element in {"Co", "W"} else " "
    g = trial(g, "u04_heavy", log, initial_heavy)

    enable_intensity(g)
    g = trial(g, "u05_intensity_final", log, initial_heavy)
    save(g, "u99_accepted")
    (OUT / "polish_log.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
