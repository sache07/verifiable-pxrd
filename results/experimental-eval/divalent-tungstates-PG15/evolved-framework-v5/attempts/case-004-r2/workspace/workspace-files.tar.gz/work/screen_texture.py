from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "work" / "final_inventory_refine" / "accepted.gpx"
BASE = ROOT / "work" / "texture_screen"


def clear_all(g: G2.G2Project) -> None:
    h = g.histogram(0)
    h.clear_refinements({"Background": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    h.clear_refinements({"Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for p in g.phases():
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True})
        for atom in p.atoms():
            atom.refinement_flags = " "


def main(phase_name: str, axis: list[int]) -> None:
    G2.SetPrintLevel("error")
    label = f"{phase_name}_{axis[0]}{axis[1]}{axis[2]}"
    out = BASE / label
    out.mkdir(parents=True, exist_ok=True)
    g = G2.G2Project(str(SRC), newgpx=str(out / "fit.gpx"))
    clear_all(g)
    h = g.histogram(0)
    h.set_refinements({"Background": True})
    for p in g.phases():
        p.set_HAP_refinements({"Scale": True})
    p = g.phase(phase_name)
    po = p.data["Histograms"][h.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = axis
    controls = g.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    g.set_Controls("cycles", 5)
    g.refine()
    fit_rwp = g.histogram(0).residuals.get("wR")
    ratio = p.data["Histograms"][h.name]["Pref.Ori."][1]
    clear_all(g)
    g.set_Controls("cycles", 0)
    g.refine()
    g.save()
    result = {
        "phase": phase_name,
        "axis": axis,
        "ratio": ratio,
        "fit_rwp": fit_rwp,
        "replay_rwp": g.histogram(0).residuals.get("wR"),
    }
    (out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 5:
        raise SystemExit("usage: screen_texture.py PHASE h k l")
    main(sys.argv[1], [int(v) for v in sys.argv[2:]])
