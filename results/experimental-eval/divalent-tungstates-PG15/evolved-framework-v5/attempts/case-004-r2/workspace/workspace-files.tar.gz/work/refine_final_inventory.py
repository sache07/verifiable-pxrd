from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "work" / "oxygen_line_search" / "zn_0.180" / "fit.gpx"
OUT = ROOT / "work" / "final_inventory_refine"
OUT.mkdir(exist_ok=True)
WORKING = OUT / "working.gpx"
ACCEPTED = OUT / "accepted.gpx"


def clear_all(g: G2.G2Project) -> None:
    h = g.histogram(0)
    h.clear_refinements({"Background": True})
    h.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
    )
    h.clear_refinements(
        {"Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]}
    )
    for p in g.phases():
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        for atom in p.atoms():
            atom.refinement_flags = " "


def snapshot(g: G2.G2Project, tag: str) -> dict:
    h = g.histogram(0)
    return {
        "tag": tag,
        "rwp": h.residuals.get("wR"),
        "residuals": h.residuals,
        "limits": list(h.data["Limits"][1]),
        "instrument": {k: h.InstrumentParameters[k][1] for k in ("Zero", "U", "V", "W", "X", "SH/L", "Polariz.")},
        "sample": {k: h.SampleParameters[k][0] for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "phases": [
            {
                "name": p.name,
                "cell": p.get_cell(),
                "scale": p.data["Histograms"][h.name]["Scale"][0],
                "size": p.data["Histograms"][h.name]["Size"][1][0],
                "strain": p.data["Histograms"][h.name]["Mustrain"][1][0],
            }
            for p in g.phases()
        ],
    }


def freeze_recalculate(g: G2.G2Project) -> None:
    clear_all(g)
    g.set_Controls("cycles", 0)
    g.refine()


def save(g: G2.G2Project, tag: str | None = None) -> None:
    g.save(str(WORKING))
    shutil.copy2(WORKING, ACCEPTED)
    if tag:
        shutil.copy2(WORKING, OUT / f"{tag}.gpx")


def is_physical(item: dict) -> bool:
    inst = item["instrument"]
    sample = item["sample"]
    if not (-0.25 <= inst["Zero"] <= 0.25 and -800.0 <= sample["Shift"] <= 800.0):
        return False
    for p in item["phases"]:
        c = p["cell"]
        if min(c["length_a"], c["length_b"], c["length_c"], c["volume"]) <= 0:
            return False
        if not (0.04 <= p["size"] <= 1.5):
            return False
        if p["scale"] <= 0:
            return False
    return True


def trial(g: G2.G2Project, tag: str, log: list[dict], cycles: int = 6) -> G2.G2Project:
    before = snapshot(g, "before")
    g.set_Controls("cycles", cycles)
    g.refine()
    fitted = g.histogram(0).residuals.get("wR")
    freeze_recalculate(g)
    after = snapshot(g, tag)
    after["fit_rwp_before_replay"] = fitted
    if is_physical(after) and after["rwp"] is not None and after["rwp"] <= before["rwp"] + 1e-6:
        after["accepted"] = True
        log.append(after)
        save(g, tag)
        print(f"ACCEPT {tag}: {before['rwp']:.5f} -> {after['rwp']:.5f}", flush=True)
        return g
    after["accepted"] = False
    log.append(after)
    print(f"ROLLBACK {tag}: {before['rwp']:.5f} -> {after['rwp']} physical={is_physical(after)}", flush=True)
    return G2.G2Project(str(ACCEPTED), newgpx=str(WORKING))


def main() -> None:
    G2.SetPrintLevel("error")
    g = G2.G2Project(str(SRC), newgpx=str(WORKING))
    h = g.histogram(0)
    controls = g.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    h.set_refinements({"Limits": [9.90343322, 100.09488522]})
    freeze_recalculate(g)
    save(g, "t00_full_grid")
    log = [snapshot(g, "full_grid_start")]
    print(f"START full-grid Rwp={log[0]['rwp']:.5f}", flush=True)

    h = g.histogram(0)
    h.set_refinements({"Background": True})
    for p in g.phases():
        p.set_HAP_refinements({"Scale": True})
    g = trial(g, "t01_scales_background", log)

    h = g.histogram(0)
    h.set_refinements({"Background": True, "Instrument Parameters": ["Zero"]})
    for p in g.phases():
        p.set_HAP_refinements({"Scale": True})
        p.set_refinements({"Cell": True})
    g = trial(g, "t02_cells_zero", log)

    h = g.histogram(0)
    h.set_refinements(
        {"Background": True, "Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]}
    )
    for p in g.phases():
        p.set_HAP_refinements({"Scale": True})
    g = trial(g, "t03_shift", log)

    h = g.histogram(0)
    h.set_refinements({"Background": True})
    for p in g.phases():
        p.set_HAP_refinements(
            {"Scale": True, "Size": {"type": "isotropic", "refine": True}}
        )
    g = trial(g, "t04_sizes", log)

    save(g, "t99_accepted")
    (OUT / "refinement_log.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
