from pathlib import Path

import polish_final as polish


ROOT = Path(__file__).resolve().parents[1]
polish.SRC = ROOT / "work" / "polished" / "accepted.gpx"
polish.OUT = ROOT / "work" / "polished_cycle2"
polish.OUT.mkdir(exist_ok=True)
polish.WORKING = polish.OUT / "working.gpx"
polish.ACCEPTED = polish.OUT / "accepted.gpx"


if __name__ == "__main__":
    polish.main()
