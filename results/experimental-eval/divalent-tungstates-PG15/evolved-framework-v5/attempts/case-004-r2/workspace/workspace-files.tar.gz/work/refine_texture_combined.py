from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "work" / "final_inventory_refine" / "accepted.gpx"
OUT = ROOT / "work" / "texture_combined"
OUT.mkdir(exist_ok=True)


def clear_all(g: G2.G2Project) -> None:
    h = g.histogram(0)
    h.clear_refinements({"Background": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    h.clear_refinements({"Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for p in g.phases():
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True})
        for atom in p.atoms():
            atom.refinement_flags = " "


def main() -> None:
    G2.SetPrintLevel("error")
    g = G2.G2Project(str(SRC), newgpx=str(OUT / "fit.gpx"))
    before = g.histogram(0).residuals.get("wR")
    clear_all(g)
    h = g.histogram(0)
    h.set_refinements({"Background": True})
    settings = {
        "CoWO4": ([0, 0, 1], 0.933),
        "WO3": ([1, 1, 0], 1.100),
    }
    for p in g.phases():
        p.set_HAP_refinements({"Scale": True})
        axis, ratio = settings[p.name]
        po = p.data["Histograms"][h.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", ratio, True, axis
    g.set_Controls("cycles", 6)
    g.refine()
    fit_rwp = g.histogram(0).residuals.get("wR")
    ratios = {
        p.name: p.data["Histograms"][h.name]["Pref.Ori."][1] for p in g.phases()
    }
    clear_all(g)
    g.set_Controls("cycles", 0)
    g.refine()
    replay_rwp = g.histogram(0).residuals.get("wR")
    accepted = replay_rwp < before and all(0.7 <= value <= 1.4 for value in ratios.values())
    g.save(str(OUT / ("accepted.gpx" if accepted else "rejected.gpx")))
    result = {
        "before_rwp": before,
        "fit_rwp": fit_rwp,
        "replay_rwp": replay_rwp,
        "ratios": ratios,
        "axes": {name: axis for name, (axis, _) in settings.items()},
        "accepted": accepted,
    }
    (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
