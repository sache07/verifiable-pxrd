from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "work" / "texture_combined" / "accepted.gpx"
BASE = ROOT / "work" / "roughness_screen"


def clear_all(g: G2.G2Project) -> None:
    h = g.histogram(0)
    h.clear_refinements({"Background": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    h.clear_refinements({"Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for p in g.phases():
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True})
        for atom in p.atoms():
            atom.refinement_flags = " "


def main(label: str, a0: float, b0: float) -> None:
    G2.SetPrintLevel("error")
    out = BASE / label
    out.mkdir(parents=True, exist_ok=True)
    g = G2.G2Project(str(SRC), newgpx=str(out / "fit.gpx"))
    before = g.histogram(0).residuals.get("wR")
    clear_all(g)
    h = g.histogram(0)
    h.SampleParameters["SurfRoughA"] = [a0, True]
    h.SampleParameters["SurfRoughB"] = [b0, True]
    h.set_refinements({"Background": True})
    for p in g.phases():
        p.set_HAP_refinements({"Scale": True})
    controls = g.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    g.set_Controls("cycles", 6)
    g.refine()
    fit_rwp = g.histogram(0).residuals.get("wR")
    a = h.SampleParameters["SurfRoughA"][0]
    b = h.SampleParameters["SurfRoughB"][0]
    clear_all(g)
    g.set_Controls("cycles", 0)
    g.refine()
    replay_rwp = g.histogram(0).residuals.get("wR")
    physical = 0.05 <= a <= 0.6 and 0.02 <= b <= 0.5
    accepted = physical and replay_rwp < before
    g.save(str(out / ("accepted.gpx" if accepted else "rejected.gpx")))
    result = {
        "label": label,
        "start": [a0, b0],
        "A": a,
        "B": b,
        "before_rwp": before,
        "fit_rwp": fit_rwp,
        "replay_rwp": replay_rwp,
        "physical": physical,
        "accepted": accepted,
    }
    (out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit("usage: screen_roughness.py LABEL A B")
    main(sys.argv[1], float(sys.argv[2]), float(sys.argv[3]))
