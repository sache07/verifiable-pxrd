from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "work" / "profile_refine" / "accepted.gpx"
OUT = ROOT / "work" / "calibration_refine"
OUT.mkdir(exist_ok=True)
WORKING = OUT / "working.gpx"
ACCEPTED = OUT / "accepted.gpx"


def state(g: G2.G2Project, tag: str) -> dict:
    h = g.histogram(0)
    return {
        "tag": tag,
        "rwp": h.residuals.get("wR"),
        "residuals": h.residuals,
        "zero": h.InstrumentParameters["Zero"][1],
        "shift": h.SampleParameters["Shift"][0],
        "sh_l": h.InstrumentParameters["SH/L"][1],
        "background_coefficients": list(h.Background[0][3:]),
        "cells": {p.name: p.get_cell() for p in g.phases()},
    }


def save(g: G2.G2Project, checkpoint: str | None = None) -> None:
    g.save(str(WORKING))
    shutil.copy2(WORKING, ACCEPTED)
    if checkpoint:
        shutil.copy2(WORKING, OUT / f"{checkpoint}.gpx")


def trial(g: G2.G2Project, tag: str, log: list[dict], cycles: int = 8) -> G2.G2Project:
    before = state(g, "before")
    g.set_Controls("cycles", cycles)
    g.refine()
    after = state(g, tag)
    physical = (
        -0.25 - 1e-8 <= after["zero"] <= 0.25 + 1e-8
        and -800.0 - 1e-6 <= after["shift"] <= 800.0 + 1e-6
        and 0.005 - 1e-8 <= after["sh_l"] <= 0.10 + 1e-8
    )
    if physical and after["rwp"] is not None and after["rwp"] <= before["rwp"] + 1e-6:
        after["accepted"] = True
        log.append(after)
        save(g, tag)
        print(f"ACCEPT {tag}: {before['rwp']:.5f} -> {after['rwp']:.5f}", flush=True)
        return g
    after["accepted"] = False
    log.append(after)
    print(f"ROLLBACK {tag}: {before['rwp']:.5f} -> {after['rwp']} physical={physical}", flush=True)
    return G2.G2Project(str(ACCEPTED), newgpx=str(WORKING))


def main() -> None:
    G2.SetPrintLevel("error")
    g = G2.G2Project(str(SRC), newgpx=str(WORKING))
    h = g.histogram(0)
    # The zero-valued microstrain trial was unsupported; retain zero but remove it
    # from the active model before calibration work.
    for p in g.phases():
        p.clear_HAP_refinements({"Mustrain": True})
        p.data["Histograms"][h.name]["Mustrain"][1][0] = 0.0
    save(g, "r00_profile")
    log = [state(g, "profile_start")]
    print(f"START Rwp={log[0]['rwp']:.5f}", flush=True)

    for p in g.phases():
        p.clear_refinements({"Cell": True})
    h.set_refinements({"Sample Parameters": ["Shift"]})
    g = trial(g, "r01_shift", log)

    for p in g.phases():
        p.set_refinements({"Cell": True})
    g = trial(g, "r02_cells", log)

    h = g.histogram(0)
    h.set_refinements({"Instrument Parameters": ["SH/L"]})
    g = trial(g, "r03_axial", log)

    h = g.histogram(0)
    old = list(h.Background[0][3:])
    h.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": old + [0.0] * (12 - len(old)),
                "refine": True,
            }
        }
    )
    g = trial(g, "r04_background12", log)
    save(g)
    (OUT / "calibration_log.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
