from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
OUT = WORK / "candidate_fits"
OUT.mkdir(exist_ok=True)


def summarize(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "mass": phase.data["General"]["Mass"],
            }
        )
    return {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {
            k: v[:3] if isinstance(v, list) else v
            for k, v in hist.InstrumentParameters.items()
            if k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "SH/L")
        },
        "sample": {
            k: hist.SampleParameters.get(k)
            for k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius")
        },
        "phases": phases,
    }


def one_fit(co_name: str, wo_name: str) -> dict:
    label = f"{Path(co_name).stem}__{Path(wo_name).stem}"
    folder = OUT / label
    folder.mkdir(exist_ok=True)
    gpx = folder / "fit.gpx"
    if gpx.exists():
        gpx.unlink()
    project = G2.G2Project(newgpx=str(gpx))
    co = project.add_phase(str(WORK / co_name), phasename="CoWO4", fmthint="CIF")
    wo = project.add_phase(str(WORK / wo_name), phasename="WO3", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(WORK / "pattern.xye"),
        str(WORK / "instrument.instprm"),
        phases="all",
        fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [800.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            },
        }
    )
    for phase in (co, wo):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]

    project.set_Controls("cycles", 5)
    project.refine()
    # Let both unit cells and a common zero correction move after scales/background settle.
    for phase in (co, wo):
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    # Instrument broadening is common to all phases at this checkpoint.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]})
    project.refine()
    # Add phase-isotropic broadening only after the common profile is stable.
    for phase in (co, wo):
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True, "value": 1.0},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    project.refine()
    project.save()
    result = summarize(project, label)
    (folder / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> None:
    G2.SetPrintLevel("warn")
    co_models = [
        "co_from_mg_9013902.cif",
        "co_from_mn_1520200.cif",
        "co_from_zn_1520641.cif",
        "co_from_fe_1567215.cif",
    ]
    wo_models = [
        "wo3_1528915.cif",
        "wo3_2311041.cif",
        "wo3_1010618.cif",
        "wo3_2106293.cif",
    ]
    results = []
    for co_name in co_models:
        for wo_name in wo_models:
            try:
                result = one_fit(co_name, wo_name)
                results.append(result)
                print(label_line(result), flush=True)
            except Exception as exc:
                print(f"FAILED {co_name} {wo_name}: {type(exc).__name__}: {exc}", flush=True)
    results.sort(key=lambda item: item["residuals"].get("wR", 1e99))
    (OUT / "all_results.json").write_text(json.dumps(results, indent=2) + "\n")
    print("\nRANKED")
    for result in results:
        print(label_line(result))


def label_line(result: dict) -> str:
    return f"{result['residuals'].get('wR', float('nan')):9.4f}  {result['label']}"


if __name__ == "__main__":
    main()
