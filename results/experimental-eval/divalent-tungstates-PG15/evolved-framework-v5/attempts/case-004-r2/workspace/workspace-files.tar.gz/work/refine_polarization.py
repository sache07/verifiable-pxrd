from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "work" / "final_inventory_refine" / "accepted.gpx"
OUT = ROOT / "work" / "polarization_refine"
OUT.mkdir(exist_ok=True)


def clear_all(g: G2.G2Project) -> None:
    h = g.histogram(0)
    h.clear_refinements({"Background": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    h.clear_refinements({"Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for p in g.phases():
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True})
        for atom in p.atoms():
            atom.refinement_flags = " "


def main() -> None:
    G2.SetPrintLevel("error")
    g = G2.G2Project(str(SRC), newgpx=str(OUT / "trial.gpx"))
    before = g.histogram(0).residuals.get("wR")
    clear_all(g)
    h = g.histogram(0)
    h.set_refinements({"Background": True, "Instrument Parameters": ["Polariz."]})
    for p in g.phases():
        p.set_HAP_refinements({"Scale": True})
    g.set_Controls("cycles", 6)
    g.refine()
    fitted = g.histogram(0).residuals.get("wR")
    clear_all(g)
    g.set_Controls("cycles", 0)
    g.refine()
    after = g.histogram(0).residuals.get("wR")
    polarization = g.histogram(0).InstrumentParameters["Polariz."][1]
    accepted = after <= before and 0.5 <= polarization <= 1.0
    output = OUT / ("accepted.gpx" if accepted else "rejected.gpx")
    g.save(str(output))
    result = {
        "before_rwp": before,
        "fit_rwp": fitted,
        "replay_rwp": after,
        "polarization": polarization,
        "accepted": accepted,
    }
    (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
