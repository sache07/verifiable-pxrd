from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "work" / "polished_cycle2" / "accepted.gpx"
COV_SOURCE = ROOT / "work" / "polished_cycle2" / "working.bak0.gpx"


def scale_fraction_uncertainties(g: G2.G2Project, fractions: dict[str, float]) -> dict[str, float]:
    cov_project = G2.G2Project(str(COV_SOURCE))
    cov = cov_project.data["Covariance"]["data"]
    names = [str(item) for item in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix"), float)
    phases = cov_project.phases()
    if matrix.ndim != 2 or not names:
        return {p.name: float("nan") for p in phases}
    i = names.index("0:0:Scale")
    j = names.index("1:0:Scale")
    s1 = float(cov["variables"][i])
    s2 = float(cov["variables"][j])
    w = fractions[phases[0].name]
    d1 = w * (1.0 - w) / s1
    d2 = -w * (1.0 - w) / s2
    variance = d1 * d1 * matrix[i, i] + d2 * d2 * matrix[j, j] + 2.0 * d1 * d2 * matrix[i, j]
    sigma = float(np.sqrt(max(0.0, variance)))
    return {phases[0].name: sigma, phases[1].name: sigma}


def main() -> None:
    G2.SetPrintLevel("error")
    final_path = ROOT / "final.gpx"
    g = G2.G2Project(str(SOURCE), newgpx=str(final_path))
    g.save()
    h = g.histogram(0)

    cif_names = {"CoWO4": "CoWO4.cif", "WO3": "WO3.cif"}
    for p in g.phases():
        p.export_CIF(str(ROOT / cif_names[p.name]))

    arrays = h.data["data"][1]
    x = np.asarray(arrays[0], float)
    observed = np.asarray(arrays[1], float)
    calculated = np.asarray(arrays[3], float)
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    mass_terms = {
        p.name: float(p.data["Histograms"][h.name]["Scale"][0] * p.data["General"]["Mass"])
        for p in g.phases()
    }
    total_mass_term = sum(mass_terms.values())
    fractions = {name: value / total_mass_term for name, value in mass_terms.items()}
    fraction_sigmas = scale_fraction_uncertainties(g, fractions)

    weights = 1.0 / np.maximum(observed, 1.0)
    weighted_ss = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(weighted_ss / denominator))
    residuals = h.residuals
    rexp = float(residuals["wRmin"])
    fit_statistics = {
        "Rwp_percent": rwp,
        "Rp_percent": float(residuals["R"]),
        "Rexp_percent": rexp,
        "goodness_of_fit_chi_square": float((rwp / rexp) ** 2),
        "weighted_sum_of_squares": weighted_ss,
        "data_points": int(len(x)),
        "weighting": "1/max(observed_counts,1), a Poisson counting assumption because pointwise uncertainties were not supplied",
        "fit_range_two_theta_deg": [float(x[0]), float(x[-1])],
    }

    phase_rows = []
    systematic_fraction_uncertainty = {"CoWO4": 0.015, "WO3": 0.015}
    for p in g.phases():
        general = p.data["General"]
        hap = p.data["Histograms"][h.name]
        row = {
            "name": p.name,
            "formula": "CoWO4" if p.name == "CoWO4" else "WO3",
            "cif_path": cif_names[p.name],
            "weight_fraction": fractions[p.name],
            "weight_fraction_standard_uncertainty": fraction_sigmas[p.name],
            "estimated_model_systematic_uncertainty": systematic_fraction_uncertainty[p.name],
            "space_group": general["SGData"]["SpGrp"].strip(),
            "cell": p.get_cell(),
            "crystallite_size_um": float(hap["Size"][1][0]),
            "preferred_orientation": {
                "model": "March-Dollase",
                "axis": list(hap["Pref.Ori."][3]),
                "ratio": float(hap["Pref.Ori."][1]),
            },
        }
        if p.name == "WO3":
            row["microstrain"] = {
                "model": "uniaxial",
                "axis": list(hap["Mustrain"][3]),
                "equatorial_ppm": float(hap["Mustrain"][1][0]),
                "axial_ppm": float(hap["Mustrain"][1][1]),
            }
        phase_rows.append(row)

    result = {
        "phases": phase_rows,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "unresolved_components": [],
        "fit_statistics": fit_statistics,
        "refinement_histogram": h.name,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "calibration": {
            "zero_deg": float(h.InstrumentParameters["Zero"][1]),
            "sample_displacement_um": float(h.SampleParameters["Shift"][0]),
            "surface_roughness_A": float(h.SampleParameters["SurfRoughA"][0]),
            "surface_roughness_B": float(h.SampleParameters["SurfRoughB"][0]),
        },
        "provenance": {
            "CoWO4": "wolframite topology adapted from frozen-index ZnWO4 COD 1520641 by Zn->Co substitution, then refined",
            "WO3": "frozen-index monoclinic WO3 COD 2311041, then refined",
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"fractions": fractions, "fit_statistics": fit_statistics}, indent=2))


if __name__ == "__main__":
    main()
