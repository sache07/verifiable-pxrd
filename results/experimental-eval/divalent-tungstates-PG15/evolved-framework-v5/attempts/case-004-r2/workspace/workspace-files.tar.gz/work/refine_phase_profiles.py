from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "work" / "refinement" / "p01_scales_cells_zero.gpx"
OUT = ROOT / "work" / "profile_refine"
OUT.mkdir(exist_ok=True)
WORKING = OUT / "working.gpx"


def describe(g: G2.G2Project, tag: str) -> dict:
    h = g.histogram(0)
    out = {
        "tag": tag,
        "rwp": h.residuals.get("wR"),
        "residuals": h.residuals,
        "instrument": {k: h.InstrumentParameters[k][1] for k in ("Zero", "U", "V", "W", "X", "SH/L")},
        "sample_shift": h.SampleParameters["Shift"][0],
        "phases": [],
    }
    for p in g.phases():
        hap = p.data["Histograms"][h.name]
        out["phases"].append(
            {
                "name": p.name,
                "cell": p.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"][1][0],
                "strain": hap["Mustrain"][1][0],
            }
        )
    return out


def checkpoint(g: G2.G2Project, name: str) -> None:
    g.save(str(WORKING))
    shutil.copy2(WORKING, OUT / f"{name}.gpx")


def run_refinement(g: G2.G2Project, cycles: int = 8) -> None:
    g.set_Controls("cycles", cycles)
    g.refine()
    g.save(str(WORKING))


def accept_or_rollback(g: G2.G2Project, tag: str, before: dict, log: list[dict]) -> G2.G2Project:
    after = describe(g, tag)
    physical = all(
        0.04 - 1e-9 <= p["size"] <= 1.5 + 1e-9
        and 0.0 - 1e-9 <= p["strain"] <= 8000.0 + 1e-9
        for p in after["phases"]
    )
    improved = after["rwp"] is not None and after["rwp"] <= before["rwp"] + 1e-6
    if physical and improved:
        checkpoint(g, tag)
        after["accepted"] = True
        log.append(after)
        print(f"ACCEPT {tag}: Rwp {before['rwp']:.5f} -> {after['rwp']:.5f}", flush=True)
        return g
    print(
        f"ROLLBACK {tag}: Rwp {before['rwp']:.5f} -> {after['rwp']} physical={physical}",
        flush=True,
    )
    rolled = G2.G2Project(str(OUT / "accepted.gpx"), newgpx=str(WORKING))
    after["accepted"] = False
    log.append(after)
    return rolled


def save_accepted(g: G2.G2Project) -> None:
    g.save(str(WORKING))
    shutil.copy2(WORKING, OUT / "accepted.gpx")


def main() -> None:
    G2.SetPrintLevel("error")
    g = G2.G2Project(str(SRC), newgpx=str(WORKING))
    h = g.histogram(0)
    # The common instrument checkpoint is retained exactly while phase terms are tested.
    for key in ("U", "V", "W", "X", "SH/L"):
        h.InstrumentParameters[key][2] = False
    save_accepted(g)
    log = [describe(g, "common_profile")]
    print(f"START Rwp={log[0]['rwp']:.5f}", flush=True)

    before = describe(g, "before_size")
    for p in g.phases():
        p.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    run_refinement(g)
    g = accept_or_rollback(g, "q01_size", before, log)
    save_accepted(g)

    before = describe(g, "before_strain")
    h = g.histogram(0)
    for p in g.phases():
        hap = p.data["Histograms"][h.name]
        hap["Mustrain"][1][0] = 500.0
        p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    run_refinement(g)
    g = accept_or_rollback(g, "q02_strain", before, log)
    save_accepted(g)

    (OUT / "profile_log.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
