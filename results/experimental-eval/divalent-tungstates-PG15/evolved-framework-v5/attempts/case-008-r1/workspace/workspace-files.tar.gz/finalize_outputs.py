#!/usr/bin/env python3
"""Export the selected GSAS-II checkpoint as the final analysis artifacts."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "branches" / "final_settle.gpx"
FINAL = ROOT / "final.gpx"
OBSERVED = ROOT / "inputs" / "pattern.csv"


def scalar(value):
    """Convert numpy/GSAS scalar values into JSON-native values."""
    if isinstance(value, np.generic):
        return value.item()
    return value


def scale_fraction_esds(project, hist, phases, masses, scales):
    """Propagate the GSAS covariance of phase scales into normalized fractions."""
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = [str(v) for v in covariance.get("varyList", [])]
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    scale_names = [f"{phase.id}:{hist.id}:Scale" for phase in phases]
    if matrix.ndim != 2 or any(name not in names for name in scale_names):
        return [None] * len(phases)
    indices = [names.index(name) for name in scale_names]
    scale_cov = matrix[np.ix_(indices, indices)]
    terms = np.asarray(masses) * np.asarray(scales)
    total = float(terms.sum())
    esds = []
    for i, mass_i in enumerate(masses):
        gradient = np.empty(len(phases), dtype=float)
        for j, mass_j in enumerate(masses):
            gradient[j] = (
                mass_i * total - terms[i] * mass_j
                if i == j
                else -terms[i] * mass_j
            ) / total**2
        variance = float(gradient @ scale_cov @ gradient)
        esds.append(math.sqrt(max(variance, 0.0)))
    return esds


def main():
    if not SOURCE.is_file():
        raise FileNotFoundError(SOURCE)
    shutil.copy2(SOURCE, FINAL)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(FINAL))
    hist = project.histogram(0)
    phases = list(project.phases())

    public = np.loadtxt(OBSERVED, delimiter=",", skiprows=1, ndmin=2)
    x = np.asarray(hist.getdata("X"), dtype=float)
    observed = np.asarray(hist.getdata("Yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("Ycalc"), dtype=float)
    if public.shape != (len(x), 2):
        raise ValueError("The selected histogram does not have the original grid size")
    if not np.allclose(public[:, 0], x, rtol=0, atol=1e-7):
        raise ValueError("The selected histogram does not have the original 2theta grid")
    if not np.allclose(public[:, 1], observed, rtol=0, atol=1e-5):
        raise ValueError("The selected histogram does not contain the original counts")
    if not np.all(np.isfinite(calculated)):
        raise ValueError("Calculated profile contains nonfinite values")

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta",
                "observed",
                "calculated",
                "difference",
            ]
        )
        writer.writerows(
            zip(
                (f"{value:.8f}" for value in x),
                (f"{value:.10g}" for value in observed),
                (f"{value:.10g}" for value in calculated),
                (f"{value:.10g}" for value in observed - calculated),
            )
        )

    cif_names = ["MnWO4.cif", "WO3.cif"]
    if len(phases) != len(cif_names):
        raise ValueError(f"Expected two accepted phases, found {len(phases)}")
    for phase, filename in zip(phases, cif_names):
        phase.export_CIF(str(ROOT / filename))

    cell_masses = [float(phase.data["General"]["Mass"]) for phase in phases]
    scales = [
        float(phase.data["Histograms"][hist.name]["Scale"][0]) for phase in phases
    ]
    weighted_masses = np.asarray(cell_masses) * np.asarray(scales)
    fractions = weighted_masses / weighted_masses.sum()
    fraction_esds = scale_fraction_esds(
        project, hist, phases, cell_masses, scales
    )

    residuals = hist.residuals
    covariance = project.data.get("Covariance", {}).get("data", {})
    gof = float(covariance.get("Rvals", {}).get("GOF"))
    fit_statistics = {
        "Rwp_percent": float(residuals["wR"]),
        "Rp_percent": float(residuals["R"]),
        "R_expected_percent": float(residuals["wRmin"]),
        "goodness_of_fit": gof,
        "reduced_chi_squared": gof**2,
        "n_profile_points": int(len(x)),
    }
    friendly_names = ["MnWO4 (wolframite)", "WO3 (monoclinic gamma-WO3)"]
    result_phases = []
    for phase, name, cif_name, fraction, esd, mass, scale in zip(
        phases,
        friendly_names,
        cif_names,
        fractions,
        fraction_esds,
        cell_masses,
        scales,
    ):
        item = {
            "name": name,
            "project_phase_name": phase.name,
            "cif": cif_name,
            "cif_path": cif_name,
            "weight_fraction": float(fraction),
            "weight_percent": float(100.0 * fraction),
            "GSAS_cell_mass": mass,
            "GSAS_scale": scale,
        }
        if esd is not None:
            item["weight_fraction_statistical_esd"] = float(esd)
        result_phases.append(item)

    result = {
        "phases": result_phases,
        "weight_fraction_basis": (
            "normalized over the modeled crystalline phases; no amorphous or "
            "absolute phase fraction was determined"
        ),
        "fit_statistics": fit_statistics,
        "refinement_histogram": hist.name,
        "profile_file": "fit.csv",
        "GSAS_project": "final.gpx",
        "weighting": "Poisson counting weights, sigma=sqrt(max(counts,1))",
        "project_sha256": hashlib.sha256(FINAL.read_bytes()).hexdigest(),
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )

    inst = hist.InstrumentParameters
    theta = np.deg2rad(x / 2.0)
    gaussian = (
        float(inst["U"][1]) * np.tan(theta) ** 2
        + float(inst["V"][1]) * np.tan(theta)
        + float(inst["W"][1])
    )
    lorentzian = (
        float(inst["X"][1]) / np.cos(theta)
        + float(inst["Y"][1]) * np.tan(theta)
        + float(inst["Z"][1])
    )
    validation = {
        "source_checkpoint": str(SOURCE.relative_to(ROOT)),
        "histogram": hist.name,
        "grid_matches_input": True,
        "observed_matches_input": True,
        "project_sha256": result["project_sha256"],
        "fit_statistics": fit_statistics,
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "instrument": {
            key: float(inst[key][1])
            for key in [
                "Lam1",
                "Lam2",
                "I(L2)/I(L1)",
                "Zero",
                "Polariz.",
                "U",
                "V",
                "W",
                "X",
                "Y",
                "Z",
                "SH/L",
            ]
        },
        "sample": {
            key: scalar(hist.SampleParameters[key][0])
            for key in ["Shift", "SurfRoughA", "SurfRoughB"]
        },
        "minimum_gaussian_width_term": float(gaussian.min()),
        "minimum_lorentzian_width_term": float(lorentzian.min()),
        "last_max_shift_over_esd": float(
            np.max(np.abs(np.asarray(covariance.get("Lastshft", [np.nan]), dtype=float)))
        ),
        "phases": result_phases,
    }
    validation_path = ROOT / ".tmp" / "final_validation.json"
    validation_path.parent.mkdir(parents=True, exist_ok=True)
    validation_path.write_text(
        json.dumps(validation, indent=2, allow_nan=False, default=scalar) + "\n"
    )
    print(json.dumps(validation, indent=2, allow_nan=False, default=scalar))


if __name__ == "__main__":
    main()
