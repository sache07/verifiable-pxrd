#!/usr/bin/env python3
"""Build and refine a replayable GSAS-II powder model.

This is a specimen-analysis helper, not a general search program.  It imports
the original count grid with Poisson weights, runs conservative staged
refinements, and saves every checkpoint so that a later branch can always be
compared with the last physical model.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def instrument_text() -> str:
    return (
        "# Cu Kalpha Bragg-Brentano instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.15;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:20.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def parse_phase(spec: str) -> tuple[str, Path]:
    try:
        name, path = spec.split("=", 1)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("phase must be NAME=PATH") from exc
    return name.strip(), Path(path).resolve()


def set_inst_value(inst: dict, key: str, value: float) -> None:
    item = inst[key]
    if isinstance(item, list):
        if len(item) >= 2:
            item[0] = float(value)
            item[1] = float(value)
        else:
            item[0] = float(value)
    else:
        inst[key] = float(value)


def project_summary(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "composition": phase.composition,
                "scale": float(hap["Scale"][0]),
                "size": hap.get("Size"),
                "mustrain": hap.get("Mustrain"),
                "preferred_orientation": hap.get("Pref.Ori."),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": [float(v) for v in atom.coordinates],
                        "occupancy": float(atom.occupancy),
                        "adp": atom.ADP,
                        "refinement_flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "stage": label,
        "residuals": hist.residuals,
        "gof": cov.get("Rvals", {}).get("GOF"),
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "instrument": {
            k: (v[1] if isinstance(v, list) and len(v) > 1 else v)
            for k, v in inst.items()
            if k in {"Lam", "Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in sample.items()
            if k in {"Type", "Gonio. radius", "Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
        },
        "background": hist.Background,
        "phases": phases,
    }


def finite_physical(project: G2.G2Project) -> tuple[bool, str]:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    for key in ("U", "W", "X", "SH/L"):
        val = float(inst[key][1])
        if not math.isfinite(val):
            return False, f"nonfinite instrument {key}"
    # Analytic profile terms must not be negative over the measured range.
    x = np.asarray(hist.getdata("X"), float)
    theta = np.deg2rad(x / 2.0)
    u, v, w = (float(inst[k][1]) for k in ("U", "V", "W"))
    xx, yy, zz = (float(inst[k][1]) for k in ("X", "Y", "Z"))
    sig = u * np.tan(theta) ** 2 + v * np.tan(theta) + w
    gam = xx / np.cos(theta) + yy * np.tan(theta) + zz
    if np.min(sig) < 0 or np.min(gam) < 0:
        return False, f"negative profile width sigma={np.min(sig):.6g}, gamma={np.min(gam):.6g}"
    sample = hist.SampleParameters
    shift = float(sample["Shift"][0])
    rough_a = float(sample["SurfRoughA"][0])
    rough_b = float(sample["SurfRoughB"][0])
    if abs(shift) > 800.001:
        return False, f"sample shift outside physical range: {shift:.6g} um"
    if not ((rough_a == 0 and rough_b == 0) or (0 <= rough_a <= 1 and rough_b >= 0)):
        return False, f"nonphysical surface roughness A={rough_a:.6g}, B={rough_b:.6g}"
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if not math.isfinite(float(hap["Scale"][0])) or float(hap["Scale"][0]) <= 0:
            return False, f"nonpositive scale for {phase.name}"
        size = hap.get("Size", [None, [1]])
        mustrain = hap.get("Mustrain", [None, [0]])
        if size[0] == "isotropic" and (not math.isfinite(float(size[1][0])) or float(size[1][0]) <= 0):
            return False, f"nonpositive size for {phase.name}"
        if mustrain[0] == "isotropic" and (not math.isfinite(float(mustrain[1][0])) or float(mustrain[1][0]) < 0):
            return False, f"negative microstrain for {phase.name}"
        cell = phase.get_cell()
        if any(not math.isfinite(float(v)) or float(v) <= 0 for k, v in cell.items() if k != "volume"):
            return False, f"invalid cell for {phase.name}"
        for atom in phase.atoms():
            if not math.isfinite(float(atom.occupancy)) or not 0 < float(atom.occupancy) <= 1.01:
                return False, f"invalid occupancy for {phase.name}:{atom.label}"
            if atom.adp_flag == "I":
                if float(atom.ADP) < 0:
                    return False, f"negative Uiso for {phase.name}:{atom.label}"
            else:
                u11, u22, u33, u12, u13, u23 = (float(v) for v in atom.ADP)
                tensor = np.array([[u11, u12, u13], [u12, u22, u23], [u13, u23, u33]])
                if np.linalg.eigvalsh(tensor).min() < -1.0e-8:
                    return False, f"non-positive displacement tensor for {phase.name}:{atom.label}"
    return True, "ok"


def run_stage(project: G2.G2Project, out: Path, index: int, label: str, cycles: int = 12) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    ok, reason = finite_physical(project)
    summary = project_summary(project, label)
    summary["physical"] = ok
    summary["physical_reason"] = reason
    checkpoint = out / f"{index:02d}_{label}.gpx"
    project.save(str(checkpoint))
    # Continue from a dedicated working file so the next GSAS refinement does
    # not overwrite this checkpoint in place.
    project.save(str(out / "working.gpx"))
    print(
        f"{index:02d} {label:24s} "
        f"Rwp={summary['residuals'].get('wR', float('nan')):.5f} "
        f"GOF={summary.get('gof')} physical={ok} {reason}",
        flush=True,
    )
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", default="inputs/pattern.csv")
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase", action="append", type=parse_phase, required=True)
    parser.add_argument("--background-coeffs", type=int, default=12)
    parser.add_argument("--roughness-b", type=float, default=0.10)
    parser.add_argument("--test-size", action="store_true")
    parser.add_argument(
        "--coordinate-phase",
        action="append",
        default=[],
        help="phase name whose coordinates may refine; repeat as needed (default: all)",
    )
    parser.add_argument("--through", choices=["calibration", "coordinates", "full"], default="full")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    pattern = np.genfromtxt(args.pattern, delimiter=",", names=True)
    x = np.asarray(pattern["two_theta_deg"], float)
    y = np.asarray(pattern["intensity"], float)

    datafile = out / "observed.xye"
    with datafile.open("w", newline="") as stream:
        stream.write("# two_theta intensity sigma\n")
        writer = csv.writer(stream, delimiter=" ")
        for xx, yy in zip(x, y):
            writer.writerow([f"{xx:.10f}", f"{yy:.10f}", f"{math.sqrt(max(yy, 1.0)):.10f}"])
    instfile = out / "instrument.instprm"
    instfile.write_text(instrument_text())

    gpx = out / "working.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    phases = [
        project.add_phase(str(path), phasename=name, fmthint="CIF")
        for name, path in args.phase
    ]
    hist = project.add_powder_histogram(
        str(datafile), str(instfile), phases=phases, fmthint="xye"
    )
    # Full original grid is retained.  Use the known reflection geometry and
    # stated 200 mm radius from the lab setup.
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]
    sample = hist.SampleParameters
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst = hist.InstrumentParameters
    for key, value in {
        "Zero": 0.15,
        "Polariz.": 0.70,
        "U": 10.0,
        "V": 0.0,
        "W": 20.0,
        "X": 2.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.03,
    }.items():
        set_inst_value(inst, key, value)

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_coeffs,
                "coeffs": [float(np.percentile(y, 15))] + [0.0] * (args.background_coeffs - 1),
                "refine": True,
            }
        }
    )
    for phase in phases:
        phase.HAPvalue("Scale", 1.0, targethistlist=[hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
        # Keep sample broadening negligible until the accepted atomic model is
        # refined; total isotropic width is initially carried by U/W/X.
        phase.setSampleProfile(hist, "size", "isotropic", 10.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0)
        # GSAS imports can carry profile flags from defaults; set the native
        # arrays explicitly so no hidden sample term participates early.
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]

    summaries = []
    project.save()
    # Use broad physical bounds. The simulator's distribution is not treated
    # as a calibrated property of this specimen.
    bounds = {
        ":0:Zero": (-1.0, 1.0),
        ":0:Polariz.": (0.0, 1.0),
        ":0:U": (0.0, 200.0),
        ":0:W": (0.01, 200.0),
        ":0:X": (0.01, 50.0),
        ":0:SH/L": (0.001, 0.50),
        ":0:Shift": (-2000.0, 2000.0),
        ":0:SurfRoughA": (0.001, 0.999),
        ":0:SurfRoughB": (0.001, 1.0),
    }
    for phase in phases:
        bounds[f"{phase.id}:{hist.id}:Scale"] = (0.0, 1.0e6)
        bounds[f"{phase.id}:{hist.id}:Size;i"] = (0.04, 10.0)
        bounds[f"{phase.id}:{hist.id}:Mustrain;i"] = (0.0, 20000.0)
    for variable, (lower, upper) in bounds.items():
        project.set_Controls("parmMin", lower, variable)
        project.set_Controls("parmMax", upper, variable)
    summaries.append(run_stage(project, out, 1, "scale_background"))

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    summaries.append(run_stage(project, out, 2, "zero"))

    for phase in phases:
        phase.set_refinements({"Cell": True})
    summaries.append(run_stage(project, out, 3, "cell_zero"))

    sample["Shift"] = [0.0, True]
    summaries.append(run_stage(project, out, 4, "cell_zero_shift"))

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    summaries.append(run_stage(project, out, 5, "profile_uwx"))

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    summaries.append(run_stage(project, out, 6, "axial_divergence"))

    if args.through == "calibration":
        project.save(str(out / "best.gpx"))
        (out / "stages.json").write_text(json.dumps(summaries, indent=2, default=float) + "\n")
        return

    coordinate_names = set(args.coordinate_phase) or {phase.name for phase in phases}
    for phase in phases:
        if phase.name not in coordinate_names:
            continue
        heavy = {
            atom.label: "X"
            for atom in phase.atoms()
            if atom.element not in {"O", "H", "C"}
        }
        if heavy:
            phase.set_refinements({"Atoms": heavy})
    summaries.append(run_stage(project, out, 7, "heavy_coordinates", cycles=25))

    for phase in phases:
        if phase.name not in coordinate_names:
            continue
        light = {
            atom.label: "X"
            for atom in phase.atoms()
            if atom.element in {"O", "H", "C"}
        }
        if light:
            phase.set_refinements({"Atoms": light})
    summaries.append(run_stage(project, out, 8, "light_coordinates", cycles=25))

    if args.through == "coordinates":
        project.save(str(out / "best.gpx"))
        (out / "stages.json").write_text(json.dumps(summaries, indent=2, default=float) + "\n")
        return

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    summaries.append(run_stage(project, out, 9, "polarization"))

    # A and B are strongly correlated. Fix B at a physically plausible trial
    # value and refine A; separate runs can compare a small B grid.
    sample["SurfRoughA"] = [0.20, True]
    sample["SurfRoughB"] = [float(args.roughness_b), False]
    summaries.append(run_stage(project, out, 10, "surface_roughness_A"))

    # Last, test one supported phase-profile complexity term at a time.  The
    # isotropic terms are allowed to absorb specimen size/strain only after the
    # accepted structure and calibration have stabilized.
    summaries.append(run_stage(project, out, 11, "final_settle", cycles=25))

    if args.test_size:
        # Isotropic size is exactly degenerate with instrument X for one phase;
        # freeze X before a diagnostic size branch.
        hist.clear_refinements({"Instrument Parameters": ["X"]})
        for phase in phases:
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}, [hist]
            )
        summaries.append(run_stage(project, out, 12, "isotropic_size"))

    project.save(str(out / "best.gpx"))
    (out / "stages.json").write_text(json.dumps(summaries, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
