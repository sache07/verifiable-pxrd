#!/usr/bin/env python3
"""Apply one bounded profile/texture refinement branch to a saved GSAS project."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def axis(text: str) -> list[int]:
    vals = [int(v) for v in text.split(",")]
    if len(vals) != 3 or vals == [0, 0, 0]:
        raise argparse.ArgumentTypeError("axis must be h,k,l and nonzero")
    return vals


def set_bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable)
    project.set_Controls("parmMax", high, variable)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument(
        "--mode",
        choices=["settle", "mustrain_iso", "mustrain_uni", "minor_size", "po", "instrument_v", "coordinate_perturb", "uiso", "background"],
        required=True,
    )
    parser.add_argument("--axis", type=axis, default=[0, 0, 1])
    parser.add_argument("--phase", type=int, default=0)
    parser.add_argument("--cycles", type=int, default=30)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--uiso", type=float, default=0.01)
    parser.add_argument("--background-coeffs", type=int, default=12)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    project.save()
    hist = project.histogram(0)
    inst = hist.InstrumentParameters

    # Remove optimizer bookkeeping from older branches. Hold two parameters
    # that had reached a boundary or were inseparable from specimen position.
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    inst["W"][2] = False
    inst["Zero"][2] = False
    inst["W"][1] = max(float(inst["W"][1]), 0.01)

    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]

    if args.mode == "mustrain_iso":
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [hist],
        )
        set_bound(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 20000.0)
    elif args.mode == "mustrain_uni":
        phase.setSampleProfile(
            hist, "microstrain", "uniaxial", 1000.0, 1000.0, args.axis, LGmix=1.0
        )
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "direction": args.axis,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [hist],
        )
        set_bound(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 20000.0)
        set_bound(project, f"{phase.id}:{hist.id}:Mustrain;a", 0.0, 20000.0)
    elif args.mode == "minor_size":
        phase.setSampleProfile(hist, "size", "isotropic", 0.5, LGmix=1.0)
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 0.5,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [hist],
        )
        set_bound(project, f"{phase.id}:{hist.id}:Size;i", 0.04, 10.0)
    elif args.mode == "po":
        po = hap["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(args.axis)
        set_bound(project, f"{phase.id}:{hist.id}:MD", 0.5, 2.0)
    elif args.mode == "instrument_v":
        inst["V"][2] = True
        set_bound(project, f":{hist.id}:V", -200.0, 200.0)
    elif args.mode == "coordinate_perturb":
        rng = np.random.default_rng(args.seed)
        for atom in phase.atoms():
            xyz = np.array(atom.coordinates, float)
            if atom.element in {"O", "H", "C"}:
                xyz += rng.normal(0.0, 0.012, 3)
            else:
                xyz[1] += rng.normal(0.0, 0.004)
            atom.coordinates = np.mod(xyz, 1.0)
    elif args.mode == "uiso":
        if not 0 <= args.uiso <= 0.05:
            raise ValueError("Uiso trial must be between 0 and 0.05 A^2")
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = float(args.uiso)
    elif args.mode == "background":
        if not 4 <= args.background_coeffs <= 24:
            raise ValueError("background coefficient count must be 4..24")
        back = hist.Background[0]
        current = int(back[2])
        target = int(args.background_coeffs)
        if target > current:
            back.extend([0.0] * (target - current))
        elif target < current:
            del back[3 + target : 3 + current]
        back[2] = target
        back[1] = True

    project.set_Controls("cycles", args.cycles)
    project.refine(makeBack=False)
    project.save(str(output))

    h = project.histogram(0)
    x = np.asarray(h.getdata("X"), float)
    theta = np.deg2rad(x / 2)
    ip = h.InstrumentParameters
    sig = ip["U"][1] * np.tan(theta) ** 2 + ip["V"][1] * np.tan(theta) + ip["W"][1]
    gam = ip["X"][1] / np.cos(theta) + ip["Y"][1] * np.tan(theta) + ip["Z"][1]
    masses = []
    phases = []
    physical = bool(np.min(sig) >= 0 and np.min(gam) >= 0)
    for ph in project.phases():
        hp = ph.data["Histograms"][h.name]
        contribution = float(ph.data["General"]["Mass"] * hp["Scale"][0])
        masses.append(contribution)
        size = hp["Size"]
        strain = hp["Mustrain"]
        if size[0] == "isotropic" and float(size[1][0]) <= 0:
            physical = False
        if strain[0] in {"isotropic", "uniaxial"} and min(float(v) for v in strain[1][:2]) < 0:
            physical = False
        phases.append(
            {
                "name": ph.name,
                "cell": ph.get_cell(),
                "scale": float(hp["Scale"][0]),
                "size": size,
                "mustrain": strain,
                "preferred_orientation": hp["Pref.Ori."],
            }
        )
    for item, mass in zip(phases, masses):
        item["weight_fraction"] = mass / sum(masses)
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "mode": args.mode,
        "axis": args.axis,
        "Rwp": h.get_wR(),
        "residuals": h.residuals,
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "physical": physical,
        "min_sigma": float(np.min(sig)),
        "min_gamma": float(np.min(gam)),
        "instrument": {
            k: float(ip[k][1]) for k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
        },
        "sample": {
            k: (float(h.SampleParameters[k][0]) if isinstance(h.SampleParameters[k], list) else h.SampleParameters[k])
            for k in ["Shift", "SurfRoughA", "SurfRoughB"]
        },
        "phases": phases,
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "frozen": str(project.data["Controls"]["data"].get("parmFrozen", {})),
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps({k: result[k] for k in ["mode", "axis", "Rwp", "GOF", "physical", "instrument", "sample"]}, indent=2))
    for item in phases:
        print(item["name"], "wt", item["weight_fraction"], "size", item["size"][:3], "strain", item["mustrain"][:3], "PO", item["preferred_orientation"][:4])


if __name__ == "__main__":
    main()
