#!/usr/bin/env python3
"""Build exploratory GSAS-II refinements for the MgO-WO3 specimen.

Run with the GSAS-II Python interpreter. Outputs are kept under .tmp until a
physically screened branch is selected for the final deliverables.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_inputs() -> tuple[Path, Path]:
    TMP.mkdir(exist_ok=True)
    xye = TMP / "pattern.xye"
    inst = TMP / "lab.instprm"
    rows = []
    with (ROOT / "inputs" / "pattern.csv").open(newline="") as fp:
        for row in csv.DictReader(fp):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            rows.append((x, y, math.sqrt(max(y, 1.0))))
    with xye.open("w") as fp:
        fp.write("# two_theta intensity sigma\n")
        for x, y, sig in rows:
            fp.write(f"{x:.8f} {y:.8f} {sig:.8f}\n")
    with inst.open("w") as fp:
        fp.write("#GSAS-II instrument parameter file\n")
        fp.write("Type:PXC;Bank:1\n")
        fp.write(
            "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.70;"
            "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        )
        fp.write("U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n")
    return xye, inst


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    out = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {
            key: val[1] if isinstance(val, list) and len(val) > 1 else val
            for key, val in hist.InstrumentParameters.items()
        },
        "sample": hist.SampleParameters,
        "phases": {},
    }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    print(json.dumps(out, indent=2, default=str))
    return out


def refine_once(project: G2.G2Project, label: str, history: list[dict]) -> None:
    project.refine(makeBack=False)
    project.save()
    history.append(snapshot(project, label))
    checkpoint = TMP / f"{Path(project.filename).stem}-{label}.gpx"
    shutil.copy2(project.filename, checkpoint)


def build(args: argparse.Namespace) -> None:
    xye, inst = prepare_inputs()
    out = TMP / args.output
    if out.exists():
        out.unlink()
    project = G2.G2Project(newgpx=str(out))
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1.0e-5
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.set_refinements({"Limits": [10.0, 100.0]})
    # Refine phase scales only. Refining sample and all phase scales together
    # introduces an exact scale singularity.
    hist.SampleParameters["Scale"][1] = False
    hist.set_refinements(
        {
            "Background": {
                "type": args.background,
                "refine": True,
                "no. coeffs": args.bkg_terms,
                "coeffs": [900.0] + [0.0] * (args.bkg_terms - 1),
            }
        }
    )

    refs = [
        ("MgWO4", args.mgwo4),
        ("WO3", args.wo3),
        ("MgO", args.mgo),
    ]
    phases = []
    for name, cod_id in refs:
        phase = project.add_phase(
            str(cod_cif(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )
        phases.append(phase)
        phase.set_HAP_refinements({"Scale": True})

    # Keep the initial profile physically within the laboratory ranges.
    ip = hist.InstrumentParameters
    for key, value in {"U": 10.0, "V": 0.0, "W": 10.0, "X": 1.0, "Y": 0.0, "SH/L": 0.02}.items():
        ip[key][1] = value

    project.save()
    print("Initial instrument", hist.InstrumentParameters)
    print("Initial sample", hist.SampleParameters)
    history: list[dict] = []

    # Complete, conservative three-phase fit first.
    refine_once(project, "scales_background", history)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_once(project, "zero_shift", history)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine_once(project, "cells", history)

    # Zero, height and phase cells are nearly collinear. Keep the physically
    # plausible calibrated checkpoint while profile and specimen terms are fit.
    hist.InstrumentParameters["Zero"][2] = False
    hist.SampleParameters["Shift"][1] = False

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine_once(project, "instrument_profile", history)

    if args.broadening in ("size", "both"):
        for phase in phases:
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 0.3, "refine": True}}
            )
        refine_once(project, "isotropic_size", history)

    if args.broadening in ("strain", "both"):
        for phase in phases:
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
        refine_once(project, "isotropic_mustrain", history)

    with (TMP / (out.stem + "-history.json")).open("w") as fp:
        json.dump(history, fp, indent=2, default=str)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="branch.gpx")
    parser.add_argument("--mgwo4", default="9013902")
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--mgo", default="9000499")
    parser.add_argument("--background", default="chebyschev-1")
    parser.add_argument("--bkg-terms", type=int, default=15)
    parser.add_argument("--cycles", type=int, default=20)
    parser.add_argument(
        "--broadening", choices=("none", "size", "strain", "both"), default="none"
    )
    args = parser.parse_args()
    build(args)


if __name__ == "__main__":
    main()
