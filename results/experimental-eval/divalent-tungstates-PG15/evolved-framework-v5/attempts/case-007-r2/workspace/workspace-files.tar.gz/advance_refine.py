#!/usr/bin/env python3
"""Apply one bounded refinement step to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def set_limit(project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def phase_atom_selection(project, spec: str):
    phase_name, element_text = spec.split(":", 1)
    phase = project.phase(phase_name)
    elements = set(element_text.split(","))
    return phase, [atom for atom in phase.atoms() if atom.element in elements]


def summarize(project, output: Path) -> dict:
    hist = project.histogram(0)
    out = {
        "project": str(output),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: value[1] if isinstance(value, list) and len(value) > 1 else value
            for key, value in hist.InstrumentParameters.items()
        },
        "sample": hist.SampleParameters,
        "frozen": project.get_Frozen(),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": atom.coordinates,
                    "uiso": atom.uiso,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    with output.with_suffix(".json").open("w") as fp:
        json.dump(out, fp, indent=2, default=str)
    print(json.dumps(out, indent=2, default=str))
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--cycles", type=int, default=20)
    parser.add_argument(
        "--full-grid",
        action="store_true",
        help="refine over every measured point rather than nominal scan limits",
    )
    parser.add_argument("--keep-frozen", action="store_true")
    parser.add_argument("--size", action="store_true")
    parser.add_argument("--size-phases", default="all")
    parser.add_argument("--size-start", type=float, default=0.3)
    parser.add_argument("--strain", action="store_true")
    parser.add_argument("--strain-phases", default="all")
    parser.add_argument("--strain-start", type=float, default=1000.0)
    parser.add_argument(
        "--uniaxial-strain",
        action="append",
        default=[],
        help="phase:h,k,l, refine equatorial and axial microstrain",
    )
    parser.add_argument("--x-start", type=float)
    parser.add_argument("--u-start", type=float)
    parser.add_argument("--w-start", type=float)
    parser.add_argument("--fix-x", action="store_true")
    parser.add_argument("--fix-u", action="store_true")
    parser.add_argument("--fix-w", action="store_true")
    parser.add_argument("--hold-profile", action="store_true")
    parser.add_argument("--release-profile", action="store_true")
    parser.add_argument("--hold-cells", action="store_true")
    parser.add_argument("--release-cells", action="store_true")
    parser.add_argument("--hold-atoms", action="store_true")
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--polarization-start", type=float, default=0.7)
    parser.add_argument("--fix-polarization", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--rough-a", type=float, default=0.1)
    parser.add_argument("--rough-b", type=float, default=0.1)
    parser.add_argument("--fix-rough-a", action="store_true")
    parser.add_argument("--fix-rough-b", action="store_true")
    parser.add_argument(
        "--texture",
        action="append",
        default=[],
        help="phase:h,k,l[:start], for example MgWO4:0,0,1:1.0",
    )
    parser.add_argument(
        "--coordinates",
        action="append",
        default=[],
        help="phase:comma-separated elements, for example MgWO4:W,Mg",
    )
    parser.add_argument(
        "--uiso",
        action="append",
        default=[],
        help="phase:comma-separated elements",
    )
    parser.add_argument(
        "--common-uiso",
        action="append",
        default=[],
        help="phase[:start], constrain all phase atoms to one Uiso",
    )
    args = parser.parse_args()

    src = Path(args.input).resolve()
    out = Path(args.output).resolve()
    if out.exists():
        out.unlink()
    project = G2.G2Project(gpxfile=str(src), newgpx=str(out))
    if not args.keep_frozen:
        project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)
    if args.full_grid:
        hist.set_refinements({"Limits": list(hist.data["Limits"][0])})
    ip = hist.InstrumentParameters

    # Laboratory-supported profile bounds.
    for var, low, high in (
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.1),
    ):
        set_limit(project, var, low, high)
    if args.x_start is not None:
        ip["X"][1] = args.x_start
    if args.u_start is not None:
        ip["U"][1] = args.u_start
    if args.w_start is not None:
        ip["W"][1] = args.w_start
    if args.fix_x:
        ip["X"][2] = False
    if args.fix_u:
        ip["U"][2] = False
    if args.fix_w:
        ip["W"][2] = False
    if args.hold_profile:
        for key in ("U", "V", "W", "X", "Y", "SH/L"):
            if key in ip:
                ip[key][2] = False
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][2] = [False for _ in hap["Size"][2]]
            hap["Size"][5] = [False for _ in hap["Size"][5]]
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    if args.release_profile:
        for key in ("U", "W", "X", "SH/L"):
            ip[key][2] = True
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][2][0] = True
            set_limit(project, f"{phase.id}:0:Size;i", 0.04, 1.5)
    if args.hold_cells:
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = False
    if args.release_cells:
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
    if args.hold_atoms:
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = ""

    if args.size:
        selected = project.phases() if args.size_phases == "all" else [project.phase(n) for n in args.size_phases.split(",")]
        for phase in selected:
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": args.size_start, "refine": True}}
            )
            set_limit(project, f"{phase.id}:0:Size;i", 0.04, 1.5)

    if args.strain:
        selected = project.phases() if args.strain_phases == "all" else [project.phase(n) for n in args.strain_phases.split(",")]
        for phase in selected:
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
            phase.data["Histograms"][hist.name]["Mustrain"][1][0] = args.strain_start
            set_limit(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)

    for spec in args.uniaxial_strain:
        phase_name, axis_text = spec.split(":", 1)
        phase = project.phase(phase_name)
        axis = [int(v) for v in axis_text.split(",")]
        hap = phase.data["Histograms"][hist.name]
        old = float(hap["Mustrain"][1][0])
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}}
        )
        hap["Mustrain"][1][0] = old
        hap["Mustrain"][1][1] = old
        set_limit(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
        set_limit(project, f"{phase.id}:0:Mustrain;a", 0.0, 8000.0)

    if args.polarization:
        ip["Polariz."][1] = args.polarization_start
        ip["Polariz."][2] = not args.fix_polarization
        set_limit(project, ":0:Polariz.", 0.5, 1.0)

    if args.roughness:
        hist.SampleParameters["SurfRoughA"] = [args.rough_a, not args.fix_rough_a]
        hist.SampleParameters["SurfRoughB"] = [args.rough_b, not args.fix_rough_b]
        set_limit(project, ":0:SurfRoughA", 0.05, 0.6)
        set_limit(project, ":0:SurfRoughB", 0.02, 0.5)

    for spec in args.texture:
        parts = spec.split(":")
        phase = project.phase(parts[0])
        axis = [int(v) for v in parts[1].split(",")]
        start = float(parts[2]) if len(parts) > 2 else 1.0
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", start, True, axis
        set_limit(project, f"{phase.id}:0:MD", 0.7, 1.4)

    for spec in args.coordinates:
        phase, atoms = phase_atom_selection(project, spec)
        for atom in atoms:
            atom.refinement_flags = "X"

    for spec in args.uiso:
        phase, atoms = phase_atom_selection(project, spec)
        for atom in atoms:
            atom.refinement_flags = atom.refinement_flags + "U"
            set_limit(project, f"{phase.id}::AUiso:{atom.atomid}", 0.001, 0.04)

    for spec in args.common_uiso:
        parts = spec.split(":")
        phase = project.phase(parts[0])
        start = float(parts[1]) if len(parts) > 1 else 0.008
        variables = []
        for atom_index, atom in enumerate(phase.atoms()):
            atom.uiso = start
            atom.refinement_flags = atom.refinement_flags + "U"
            variable = f"{phase.id}::AUiso:{atom_index}"
            variables.append(variable)
            set_limit(project, variable, 0.003, 0.02)
        if len(variables) > 1:
            project.add_EquivConstr(tuple(variables), reloadIdx=True)

    project.save()
    project.refine(makeBack=False)
    project.save()
    summarize(project, out)


if __name__ == "__main__":
    main()
