#!/usr/bin/env python3
"""Export the selected GSAS-II checkpoint into the requested deliverables."""

from __future__ import annotations

import csv
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE_GPX = ROOT / ".tmp" / "final-fullgrid-replay.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_META = {
    "MgWO4": {
        "formula": "MgWO4",
        "cif_path": "phase_MgWO4.cif",
        "reference": {"database": "COD", "entry": "9013902"},
    },
    "WO3": {
        "formula": "WO3",
        "cif_path": "phase_WO3.cif",
        "reference": {"database": "COD", "entry": "2311041"},
    },
    "MgO": {
        "formula": "MgO",
        "cif_path": "phase_MgO.cif",
        "reference": {"database": "COD", "entry": "9000499"},
    },
}


def as_float(value):
    return float(value)


def main() -> None:
    shutil.copy2(SOURCE_GPX, FINAL_GPX)
    project = G2.G2Project(gpxfile=str(FINAL_GPX))
    histogram = project.histogram(0)

    fractions = histogram.ComputeMassFracs()
    residuals = histogram.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]

    phases_json = []
    for phase in project.phases():
        meta = PHASE_META[phase.name]
        phase.export_CIF(str(ROOT / meta["cif_path"]))
        fraction, fraction_esd = fractions[phase.name]
        cell = phase.get_cell()
        pid = phase.id
        phases_json.append(
            {
                "name": phase.name,
                "formula": meta["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": meta["cif_path"],
                "weight_fraction": as_float(fraction),
                "weight_fraction_esd": as_float(fraction_esd),
                "reference_structure": meta["reference"],
                "unit_cell": {key: as_float(value) for key, value in cell.items()},
                "phase_Rf_percent": as_float(residuals[f"{pid}:0:Rf"]),
                "phase_Rf_squared_percent": as_float(residuals[f"{pid}:0:Rf^2"]),
            }
        )

    x = np.asarray(histogram.getdata("x"), dtype=float)
    observed = np.asarray(histogram.getdata("yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("ycalc"), dtype=float)
    difference = np.asarray(histogram.getdata("residual"), dtype=float)
    background = np.asarray(histogram.getdata("background"), dtype=float)
    if not np.allclose(difference, observed - calculated, rtol=0.0, atol=1e-8):
        raise RuntimeError("GSAS-II residual array is not observed minus calculated")
    if len(x) != int(rvals["Nobs"]):
        raise RuntimeError("Final project does not model every measured point")

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_intensity",
                "background_intensity",
            ]
        )
        for row in zip(x, observed, calculated, difference, background):
            writer.writerow([f"{row[0]:.8f}", *[f"{value:.10f}" for value in row[1:]]])

    result = {
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "histogram": histogram.name,
        "radiation": {
            "source": "Cu K-alpha",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
        },
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "phases": phases_json,
        "fit_statistics": {
            "Rwp_percent": as_float(residuals["wR"]),
            "Rp_percent": as_float(residuals["R"]),
            "R_background_percent": as_float(residuals["Rb"]),
            "Rwp_background_percent": as_float(residuals["wRb"]),
            "Rwp_minimum_percent": as_float(residuals["wRmin"]),
            "goodness_of_fit": as_float(rvals["GOF"]),
            "chi_squared": as_float(rvals["chisq"]),
            "number_of_observations": int(rvals["Nobs"]),
            "number_of_refined_variables": int(rvals["Nvars"]),
            "converged": bool(rvals["converged"]),
            "SVD_zero_count": int(rvals["SVD0"]),
            "maximum_shift_over_esd": as_float(rvals["Max shft/sig"]),
        },
    }
    if abs(sum(item["weight_fraction"] for item in phases_json) - 1.0) > 1e-10:
        raise RuntimeError("Crystalline phase fractions are not normalized")
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
