#!/usr/bin/env python3
"""Extend an accepted GSAS-II checkpoint to the exact measured grid and stabilize it."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def state(project: G2sc.G2Project, tag: str) -> dict:
    hist = project.histogram(0)
    return {
        "tag": tag,
        "limits_deg": [hist.Limits("lower"), hist.Limits("upper")],
        "Rwp_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "mass_fractions": {name: list(value) for name, value in hist.ComputeMassFracs().items()},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "coordinates": {
            phase.name: {
                atom.label: list(atom.coordinates) for atom in phase.atoms()
            }
            for phase in project.phases()
        },
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()

    outdir = args.outdir.resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(gpxfile=str(args.source.resolve()))
    project.save(str(outdir / "work.gpx"))
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("x"), dtype=float)
    hist.Limits("lower", float(x[0]))
    hist.Limits("upper", float(x[-1]))
    project.save()

    states = [state(project, "limits_extended")]
    for number in range(1, 4):
        project.refine(makeBack=False)
        tag = f"full_grid_{number}"
        states.append(state(project, tag))
        shutil.copy2(project.filename, outdir / f"{tag}.gpx")
        for phase in project.phases():
            phase.export_CIF(str(outdir / f"{tag}_{phase.name}.cif"))
        (outdir / "trajectory.json").write_text(
            json.dumps(states, indent=2, default=str) + "\n"
        )


if __name__ == "__main__":
    main()
