#!/usr/bin/env python3
"""Continue a GSAS-II refinement with bounded, physical profile models."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


def state(project: G2sc.G2Project, tag: str) -> dict:
    hist = project.histogram(0)
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "scale": hap["Scale"][0],
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    try:
        fracs = {k: list(v) for k, v in hist.ComputeMassFracs().items()}
    except Exception as exc:
        fracs = {"error": str(exc)}
    out = {
        "tag": tag,
        "wR_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "mass_fractions": fracs,
        "instrument": {
            k: list(hist.InstrumentParameters[k])
            for k in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"]
            if k in hist.InstrumentParameters
        },
        "sample": {
            k: hist.SampleParameters.get(k)
            for k in ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"]
        },
        "phases": phases,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "frozen": project.get_Frozen(),
    }
    print("STATE", json.dumps(out, default=str, sort_keys=True))
    return out


def checkpoint(project: G2sc.G2Project, outdir: Path, tag: str, states: list[dict]) -> None:
    project.refine(makeBack=False)
    item = state(project, tag)
    if item["wR_percent"] is None or not np.isfinite(item["wR_percent"]):
        raise RuntimeError(f"invalid refinement at {tag}")
    shutil.copy2(project.filename, outdir / f"{tag}.gpx")
    states.append(item)
    (outdir / "trajectory.json").write_text(json.dumps(states, indent=2, default=str) + "\n")


def set_limit(project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable)
    project.set_Controls("parmMax", high, variable)


def initialize_profile(project: G2sc.G2Project, strategy: str) -> None:
    hist = project.histogram(0)
    # Remove all prior profile flags and any bounds-triggered frozen list.
    project.set_Frozen()
    hist.clear_refinements(
        {"Instrument Parameters": [k for k in ["Zero", "U", "V", "W", "X", "Y", "SH/L"] if k in hist.InstrumentParameters]}
    )
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])

    if strategy == "low":
        inst = {"U": 1.0, "W": 2.0, "X": 0.2, "SH/L": 0.03}
        size, strain = 0.40, 1000.0
    else:
        inst = {"U": 10.0, "W": 10.0, "X": 2.0, "SH/L": 0.03}
        size, strain = 1.0, 1000.0
    for key, val in inst.items():
        hist.InstrumentParameters[key][1] = val
        hist.InstrumentParameters[key][0] = val
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain

    # Generator-supported physical ranges; also keep specimen calibration physical.
    set_limit(project, ":0:U", 0.0, 40.0)
    set_limit(project, ":0:W", 2.0, 40.0)
    set_limit(project, ":0:X", 0.1, 6.0)
    set_limit(project, ":0:SH/L", 0.005, 0.10)
    set_limit(project, ":0:Zero", -0.25, 0.25)
    set_limit(project, ":0:Shift", -800.0, 800.0)
    for pid, _phase in enumerate(project.phases()):
        set_limit(project, f"{pid}:0:Size;i", 0.03, 5.0)
        set_limit(project, f"{pid}:0:Mustrain;i", 100.0, 10000.0)


def run(source: Path, outdir: Path, strategy: str) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(gpxfile=str(source.resolve()))
    project.save(str((outdir / "work.gpx").resolve()))
    project.set_Controls("cycles", 8)
    initialize_profile(project, strategy)
    project.save()
    states = [state(project, "initialized")]
    hist = project.histogram(0)

    # Resolve common instrumental broadening first, one independent term at a time.
    hist.set_refinements({"Instrument Parameters": ["W"]})
    checkpoint(project, outdir, "p01_W", states)
    hist.set_refinements({"Instrument Parameters": ["X"]})
    checkpoint(project, outdir, "p02_X", states)
    hist.set_refinements({"Instrument Parameters": ["U"]})
    checkpoint(project, outdir, "p03_U", states)

    # Then allocate supported phase-dependent width to size and microstrain.
    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    checkpoint(project, outdir, "p04_size", states)
    for phase in project.phases():
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    checkpoint(project, outdir, "p05_strain", states)

    # Re-optimize all active physical profile terms.
    checkpoint(project, outdir, "p06_profile_joint", states)

    # Refine axial asymmetry without specimen shift, then re-establish shift.
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    checkpoint(project, outdir, "p07_asym", states)
    hist.clear_refinements({"Instrument Parameters": ["SH/L"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    checkpoint(project, outdir, "p08_shift", states)

    # Split constant zero from the cosine-dependent specimen displacement.
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    checkpoint(project, outdir, "p09_zero", states)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    checkpoint(project, outdir, "p10_shift2", states)

    shutil.copy2(project.filename, outdir / "profile_final.gpx")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--strategy", choices=["low", "mid"], default="mid")
    args = parser.parse_args()
    run(args.source, args.outdir.resolve(), args.strategy)


if __name__ == "__main__":
    main()
