#!/usr/bin/env python3
"""Jointly refine only the accepted physical model terms and checkpoint."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def summary(p, tag):
    h = p.histogram(0)
    out = {
        "tag": tag,
        "wR_percent": h.get_wR(),
        "residuals": h.residuals,
        "mass_fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "sample": {k: h.SampleParameters[k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "instrument": {k: h.InstrumentParameters[k][1] for k in ["Zero", "U", "V", "W", "X", "Y", "SH/L"]},
        "phases": {},
        "frozen": p.get_Frozen(),
    }
    for phase in p.phases():
        hap = phase.data["Histograms"][h.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
            "atoms": [
                {"label": a.label, "element": a.element, "xyz": list(a.coordinates), "uiso": a.uiso, "flags": a.refinement_flags}
                for a in phase.atoms()
            ],
        }
    print("CONSOLIDATED", json.dumps(out, default=str, sort_keys=True))
    return out


def refine_checkpoint(p, outdir, tag, states):
    p.refine(makeBack=False)
    states.append(summary(p, tag))
    shutil.copy2(p.filename, outdir / f"{tag}.gpx")
    for phase in p.phases():
        phase.export_CIF(str(outdir / f"{tag}_{phase.name}.cif"))
    (outdir / "trajectory.json").write_text(json.dumps(states, indent=2, default=str) + "\n")


def run(source, outdir):
    outdir.mkdir(parents=True, exist_ok=True)
    p = G2sc.G2Project(gpxfile=str(source.resolve()))
    p.save(str((outdir / "work.gpx").resolve()))
    p.set_Frozen()
    h = p.histogram(0)
    p.set_Controls("cycles", 10)

    # Freeze every optional term, then explicitly activate the accepted ones.
    h.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB", "Transparency"]})
    h.SampleParameters["SurfRoughA"][0] = 0.05
    h.set_refinements({"Sample Parameters": ["SurfRoughB"]})
    p.set_Controls("parmMin", 0.001, ":0:SurfRoughB")
    p.set_Controls("parmMax", 0.80, ":0:SurfRoughB")
    for phase in p.phases():
        phase.clear_HAP_refinements({"Mustrain": True, "Pref.Ori.": True, "Size": True}, [h])
        for atom in phase.atoms():
            atom.refinement_flags = " "

    baco3 = p.phase("BaCO3_9010928")
    wo3 = p.phase("WO3_2311041")
    baco3.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "direction": [1, 0, 0], "refine": True}}, [h])
    baco3.set_HAP_refinements({"Pref.Ori.": True}, [h])
    wo3.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "direction": [0, 1, 0], "refine": True}}, [h])
    p.set_Controls("parmMin", 0.60, f"{baco3.id}:0:MD")
    p.set_Controls("parmMax", 1.60, f"{baco3.id}:0:MD")
    for phase in [baco3, wo3]:
        for suffix in ["i", "a"]:
            p.set_Controls("parmMin", 100.0, f"{phase.id}:0:Mustrain;{suffix}")
            p.set_Controls("parmMax", 8000.0, f"{phase.id}:0:Mustrain;{suffix}")

    p.save()
    states = [summary(p, "initialized")]
    refine_checkpoint(p, outdir, "c01_joint_specimen", states)

    # Re-optimize only heavy coordinates under the accepted specimen model.
    p.phase("BaCO3_9010928").atom("Ba").refinement_flags = "X"
    p.phase("WO3_2311041").atom("W1").refinement_flags = "X"
    p.phase("WO3_2311041").atom("W2").refinement_flags = "X"
    refine_checkpoint(p, outdir, "c02_heavy", states)
    refine_checkpoint(p, outdir, "c03_stable", states)
    shutil.copy2(p.filename, outdir / "consolidated_candidate.gpx")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("outdir", type=Path)
    a = ap.parse_args()
    run(a.source, a.outdir.resolve())


if __name__ == "__main__":
    main()
