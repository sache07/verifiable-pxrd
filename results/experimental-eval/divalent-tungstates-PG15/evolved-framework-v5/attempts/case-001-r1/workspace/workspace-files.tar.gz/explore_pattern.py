#!/usr/bin/env python3
"""Exploratory peak extraction and reference-pattern screening."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.optimize import nnls
from scipy.signal import find_peaks, peak_widths


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = {
    "BaCO3-9010928": "9010928",
    "BaCO3-1011149": "1011149",
    "BaCO3-1539129": "1539129",
    "BaCO3-1539130": "1539130",
    "BaCO3-9006847": "9006847",
    "WO3-1004057": "1004057",
    "WO3-1010618": "1010618",
    "WO3-1521532": "1521532",
    "WO3-1521533": "1521533",
    "WO3-1528915": "1528915",
    "WO3-1563541": "1563541",
    "WO3-2311041": "2311041",
    "WO3-2106293": "2106293",
    "WO3-2107312": "2107312",
    "BaWO4-1527204": "1527204",
    "Ba3W2O9-1533878": "1533878",
    "Ba0.9W6O18-1001273": "1001273",
    "Ba3WO6-1534803": "1534803",
}


def sticks(structure: Structure, wavelength: float = 1.540598):
    patt = XRDCalculator(wavelength=wavelength, symprec=0).get_pattern(
        structure, two_theta_range=(9.5, 101.0), scaled=False
    )
    return np.asarray(patt.x), np.asarray(patt.y)


def profile_from_sticks(x, sx, sy, shift=0.0, fwhm=0.13, scale_2theta=1.0):
    # Preserve integrated intensity on the measured uniform grid.
    dx = float(np.median(np.diff(x)))
    impulse = np.zeros_like(x)
    positions = np.asarray(sx) * scale_2theta + shift
    inds = np.rint((positions - x[0]) / dx).astype(int)
    valid = (inds >= 0) & (inds < len(x))
    np.add.at(impulse, inds[valid], np.asarray(sy)[valid])
    sigma_bins = fwhm / 2.35482 / dx
    return gaussian_filter1d(impulse, sigma_bins, mode="constant")


def main():
    raw = pd.read_csv(ROOT / "inputs/pattern.csv")
    x = raw.iloc[:, 0].to_numpy(float)
    y = raw.iloc[:, 1].to_numpy(float)
    dx = np.median(np.diff(x))
    baseline = percentile_filter(y, percentile=18, size=301, mode="nearest")
    baseline = gaussian_filter1d(baseline, 80)
    signal = y - baseline
    peaks, props = find_peaks(signal, prominence=120, distance=max(2, int(0.055 / dx)))
    widths = peak_widths(signal, peaks, rel_height=0.5)[0] * dx
    order = np.argsort(props["prominences"])[::-1]
    print(f"grid n={len(x)} range={x[0]:.6f}..{x[-1]:.6f} step={dx:.7f}")
    print(f"counts min/median/max={y.min():.1f}/{np.median(y):.1f}/{y.max():.1f}")
    print(f"peaks found={len(peaks)}")
    print("rank  2theta      net_height prominence fwhm")
    for rank, j in enumerate(order[:100], 1):
        i = peaks[j]
        print(
            f"{rank:3d} {x[i]:10.5f} {signal[i]:10.1f} "
            f"{props['prominences'][j]:10.1f} {widths[j]:7.4f}"
        )

    refs = {}
    print("\nREFERENCE STRUCTURES")
    for label, cod_id in CANDIDATES.items():
        path = cod_path(cod_id)
        try:
            s = Structure.from_file(path, primitive=False, merge_tol=0.01)
            sx, sy = sticks(s)
            refs[label] = (s, sx, sy)
            print(
                f"{label:22s} {s.composition.reduced_formula:12s} "
                f"SG={s.get_space_group_info()[0]:10s} n={len(s):3d} "
                f"abc=({s.lattice.a:.5f},{s.lattice.b:.5f},{s.lattice.c:.5f}) "
                f"ang=({s.lattice.alpha:.3f},{s.lattice.beta:.3f},{s.lattice.gamma:.3f})"
            )
            top = np.argsort(sy)[::-1][:12]
            print("  sticks:", " ".join(f"{sx[k]:.3f}:{sy[k]:.0f}" for k in top))
        except Exception as exc:
            print(f"{label:22s} ERROR {exc}")

    # Full-profile screens: one reference at a time plus a smooth polynomial
    # background. Optimize broadening and global angular shift coarsely.
    z = (x - x.mean()) / (np.ptp(x) / 2)
    bg = np.column_stack([np.ones_like(x), z, z**2, z**3, z**4, np.exp(-(x - x[0]) / 8)])
    print("\nSINGLE-REFERENCE PROFILE SCREENS (lower weighted SSE is better)")
    screens = []
    w = 1.0 / np.sqrt(np.maximum(y, 1.0))
    for label, (_, sx, sy) in refs.items():
        best = None
        for fwhm in np.arange(0.07, 0.321, 0.02):
            for shift in np.arange(-0.35, 0.351, 0.02):
                p = profile_from_sticks(x, sx, sy, shift=shift, fwhm=fwhm)
                A = np.column_stack([bg, p])
                coef, _ = nnls(A * w[:, None], y * w)
                calc = A @ coef
                sse = np.sum(((y - calc) * w) ** 2)
                if best is None or sse < best[0]:
                    best = (sse, shift, fwhm, coef[-1])
        screens.append((best[0], label, *best[1:]))
    for row in sorted(screens):
        print(f"{row[1]:22s} wsse={row[0]:12.2f} shift={row[2]:+.3f} fwhm={row[3]:.3f} scale={row[4]:.4g}")


if __name__ == "__main__":
    main()
