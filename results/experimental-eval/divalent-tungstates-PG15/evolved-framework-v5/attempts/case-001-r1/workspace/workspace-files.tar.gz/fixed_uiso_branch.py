#!/usr/bin/env python3
"""Evaluate fixed, physical phase-average Uiso values with scales re-refined."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def run(source, outdir, baco3_u, wo3_u):
    outdir.mkdir(parents=True, exist_ok=True)
    p = G2sc.G2Project(gpxfile=str(source.resolve()))
    p.save(str((outdir / "work.gpx").resolve()))
    p.set_Frozen()
    p.data["Constraints"]["data"]["Phase"] = []
    for phase in p.phases():
        value = {"BaCO3_9010928": baco3_u, "WO3_2311041": wo3_u, "BaWO4_scheelite": 0.010}[phase.name]
        for atom in phase.atoms():
            atom.uiso = value
            atom.refinement_flags = " "
    p.set_Controls("cycles", 6)
    p.refine(makeBack=False)
    h = p.histogram(0)
    result = {
        "baco3_uiso": baco3_u,
        "wo3_uiso": wo3_u,
        "wR_percent": h.get_wR(),
        "mass_fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()},
    }
    print("FIXED_UISO", json.dumps(result, sort_keys=True))
    shutil.copy2(p.filename, outdir / "refined.gpx")
    (outdir / "result.json").write_text(json.dumps(result, indent=2) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--baco3", type=float, required=True)
    ap.add_argument("--wo3", type=float, required=True)
    a = ap.parse_args()
    run(a.source, a.outdir.resolve(), a.baco3, a.wo3)


if __name__ == "__main__":
    main()
