#!/usr/bin/env python3
"""Report coherent residual peaks and reflection coverage from a GSAS-II project."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks, peak_widths

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx", type=Path)
    parser.add_argument("--prominence", type=float, default=60.0)
    args = parser.parse_args()

    project = G2sc.G2Project(gpxfile=str(args.gpx.resolve()))
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("x"), dtype=float)
    y = np.asarray(hist.getdata("yobs"), dtype=float)
    calc = np.asarray(hist.getdata("ycalc"), dtype=float)
    back = np.asarray(hist.getdata("background"), dtype=float)
    diff = np.asarray(hist.getdata("residual"), dtype=float)
    lo = np.searchsorted(x, hist.Limits("lower"))
    hi = np.searchsorted(x, hist.Limits("upper"), side="right")
    xx, dd = x[lo:hi], diff[lo:hi]
    peaks, props = find_peaks(dd, prominence=args.prominence, distance=4)
    widths = peak_widths(dd, peaks, rel_height=0.5)[0] * np.median(np.diff(xx))
    order = np.argsort(props["prominences"])[::-1]
    print(f"project={args.gpx} wR={hist.get_wR():.6f}% limits={hist.Limits('lower'):.3f}..{hist.Limits('upper'):.3f}")
    print(f"obs range={y.min():.1f}..{y.max():.1f}; residual rms={np.sqrt(np.mean(dd**2)):.3f}")
    print("POSITIVE RESIDUAL PEAKS")
    print("rank 2theta diff prominence fwhm yobs ycalc background")
    for rank, j in enumerate(order[:80], 1):
        i = peaks[j]
        ii = i + lo
        print(
            f"{rank:3d} {xx[i]:9.5f} {dd[i]:8.1f} {props['prominences'][j]:10.1f} "
            f"{widths[j]:7.4f} {y[ii]:8.1f} {calc[ii]:8.1f} {back[ii]:8.1f}"
        )

    npeaks, nprops = find_peaks(-dd, prominence=args.prominence, distance=4)
    norder = np.argsort(nprops["prominences"])[::-1]
    print("NEGATIVE RESIDUAL PEAKS")
    print("rank 2theta diff prominence")
    for rank, j in enumerate(norder[:40], 1):
        i = npeaks[j]
        print(f"{rank:3d} {xx[i]:9.5f} {dd[i]:8.1f} {nprops['prominences'][j]:10.1f}")

    print("REFLECTION LIST SUMMARY")
    for name, data in hist.reflections().items():
        refl = np.asarray(data["RefList"])
        # CW nuclear lists: h,k,l,mult,d,pos,sig,gam,Fobs2,Fcalc2,...
        print(name, "shape", refl.shape)
        if refl.size:
            print("first", refl[:5].tolist())


if __name__ == "__main__":
    main()
