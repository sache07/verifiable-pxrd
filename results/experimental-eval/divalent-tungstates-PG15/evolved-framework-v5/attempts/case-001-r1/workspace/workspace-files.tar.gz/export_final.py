#!/usr/bin/env python3
"""Export the selected physical GSAS-II checkpoint and submission artifacts."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PHASES = {
    "BaCO3_9010928": {
        "name": "witherite",
        "formula": "BaCO3",
        "space_group": "Pmcn (No. 62, nonstandard setting of Pnma)",
        "cif": "phase_BaCO3.cif",
        "model_source": (
            "COD 9010928 topology/cell/Ba sublattice; regular carbonate-group "
            "coordinates transferred from same-topology COD 1011149"
        ),
        "cell_refined": True,
    },
    "WO3_2311041": {
        "name": "monoclinic tungsten trioxide",
        "formula": "WO3",
        "space_group": "P21/c (No. 14)",
        "cif": "phase_WO3.cif",
        "model_source": "COD 2311041",
        "cell_refined": True,
    },
    "BaWO4_scheelite": {
        "name": "scheelite barium tungstate",
        "formula": "BaWO4",
        "space_group": "I41/a (No. 88)",
        "cif": "phase_BaWO4.cif",
        "model_source": (
            "full-occupancy scheelite coordinates from BaMoO4 COD 2300459, "
            "Mo replaced by W; BaWO4 cell fitted then fixed"
        ),
        "cell_refined": False,
    },
}


def rounded_dict(values: dict, digits: int = 10) -> dict:
    return {key: round(float(value), digits) for key, value in values.items()}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("outdir", type=Path, nargs="?", default=Path("."))
    args = parser.parse_args()

    outdir = args.outdir.resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    final_path = outdir / "final.gpx"
    project = G2sc.G2Project(gpxfile=str(args.source.resolve()))
    project.save(str(final_path))

    # Reload the submitted project, so every other artifact is demonstrably
    # generated from final.gpx rather than from an in-memory precursor.
    project = G2sc.G2Project(gpxfile=str(final_path))
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("x"), dtype=float)
    observed = np.asarray(hist.getdata("yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("ycalc"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    difference = np.asarray(hist.getdata("residual"), dtype=float)
    if not all(len(array) == len(x) for array in [observed, calculated, background, difference]):
        raise RuntimeError("profile arrays do not have equal lengths")
    if not np.all(np.isfinite(np.column_stack([x, observed, calculated, background, difference]))):
        raise RuntimeError("profile contains non-finite values")
    if not np.allclose(difference, observed - calculated, rtol=0.0, atol=1e-7):
        raise RuntimeError("GSAS-II residual is not observed minus calculated")

    with (outdir / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        writer.writerows(
            zip(
                (f"{value:.8f}" for value in x),
                (f"{value:.8f}" for value in observed),
                (f"{value:.8f}" for value in calculated),
                (f"{value:.8f}" for value in difference),
                (f"{value:.8f}" for value in background),
            )
        )

    masses = hist.ComputeMassFracs()
    if set(masses) != set(PHASES):
        raise RuntimeError(f"unexpected phase inventory: {sorted(masses)}")
    if not np.isclose(sum(value[0] for value in masses.values()), 1.0, atol=1e-10):
        raise RuntimeError("crystalline mass fractions are not normalized")

    residuals = hist.residuals
    phase_number = {residuals[f"{index}::Name"]: index for index in range(len(PHASES))}
    phase_results = []
    for phase in project.phases():
        info = PHASES[phase.name]
        phase.export_CIF(str(outdir / info["cif"]))
        cell, cell_esd = phase.get_cell_and_esd()
        index = phase_number[phase.name]
        fraction, fraction_esd = masses[phase.name]
        phase_results.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "project_phase_name": phase.name,
                "space_group": info["space_group"],
                "cif_path": info["cif"],
                "weight_fraction": float(fraction),
                "weight_fraction_esd_formal": float(fraction_esd),
                "weight_percent": 100.0 * float(fraction),
                "weight_percent_esd_formal": 100.0 * float(fraction_esd),
                "cell_angstrom_degrees": rounded_dict(cell),
                "cell_esd_formal": rounded_dict(cell_esd),
                "cell_refined_in_final_model": info["cell_refined"],
                "model_source": info["model_source"],
                "bragg_R_F_percent": float(residuals[f"{index}:0:Rf"]),
                "bragg_R_F2_percent": float(residuals[f"{index}:0:Rf^2"]),
                "number_of_reflections": int(residuals[f"{index}:0:Nref"]),
            }
        )

    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    nobs = int(rvals["Nobs"])
    nvars = int(rvals["Nvars"])
    gof = float(rvals["GOF"])
    result = {
        "phase_count": len(phase_results),
        "fraction_basis": "normalized over the modeled crystalline phases only",
        "phases": phase_results,
        "fit_statistics": {
            "R_wp_percent": float(residuals["wR"]),
            "R_p_percent": float(residuals["R"]),
            "R_exp_percent": float(residuals["wRmin"]),
            "goodness_of_fit_S": gof,
            "reduced_chi_squared": gof * gof,
            "chi_squared": float(rvals["chisq"]),
            "observations": nobs,
            "refined_parameters": nvars,
            "degrees_of_freedom": nobs - nvars,
            "converged": bool(rvals["converged"]),
            "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
            "two_theta_min_deg": float(x[0]),
            "two_theta_max_deg": float(x[-1]),
        },
        "measurement_model": {
            "radiation": "Cu K-alpha doublet",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "profile_points": len(x),
            "weighting": "sigma=sqrt(max(observed_counts,1)); no pointwise uncertainties were supplied",
        },
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    (outdir / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    by_formula = {item["formula"]: item for item in phase_results}
    baco3 = by_formula["BaCO3"]
    wo3 = by_formula["WO3"]
    bawo4 = by_formula["BaWO4"]
    fit = result["fit_statistics"]
    report = f"""# Powder XRD phase analysis

## Result

The specimen is a three-phase crystalline mixture dominated by unreacted precursor phases, with only trace scheelite product. Fractions are normalized over the modeled crystalline phases:

| Phase | Space group | Weight fraction | Formal 1σ |
|---|---|---:|---:|
| BaCO3 (witherite) | Pmcn, No. 62 | {baco3['weight_percent']:.2f} wt% | {baco3['weight_percent_esd_formal']:.2f} wt% |
| WO3 (monoclinic) | P21/c, No. 14 | {wo3['weight_percent']:.2f} wt% | {wo3['weight_percent_esd_formal']:.2f} wt% |
| BaWO4 (scheelite) | I41/a, No. 88 | {bawo4['weight_percent']:.2f} wt% | {bawo4['weight_percent_esd_formal']:.2f} wt% |

The full-grid GSAS-II fit uses all {fit['observations']} measured points from {fit['two_theta_min_deg']:.6f} to {fit['two_theta_max_deg']:.6f}° 2θ. Fit statistics are Rwp = {fit['R_wp_percent']:.4f}%, Rp = {fit['R_p_percent']:.4f}%, Rexp = {fit['R_exp_percent']:.4f}%, and goodness-of-fit S = {fit['goodness_of_fit_S']:.3f}.

## Evidence and model choice

The BaCO3 and WO3 assignments are chemically expected from the stated BaCO3 + WO3 precursor mixture heated at only 400 °C, and each is supported across the pattern rather than by a single line. The final reflection lists contain {baco3['number_of_reflections']} BaCO3 and {wo3['number_of_reflections']} WO3 reflections. Representative strong calculated positions are 24.219, 34.877, 42.307, 45.166, and 47.075° for BaCO3, and 23.427, 23.909, 24.662, 34.464, 50.172, and 56.169° for WO3. Exact-composition WO3 references were screened in the same multiphase fit; COD 2311041 gave the broad, coherent family match and a physical octahedral W–O geometry.

BaWO4 is supported by a stable positive scale and a family of scheelite reflections, including 26.793, 43.312, 49.072, 53.864, 54.798, 68.116, and 69.309° 2θ. Its scale remains near 0.5 wt% when the oxygen model is changed. Remaining large residual extrema sit on accepted-phase peaks and alternate in sign, indicating imperfect intensity/profile descriptions rather than a separate coherent reflection family. No fourth crystalline phase was justified.

The BaCO3 topology and Ba sublattice began from COD 9010928. Its published carbonate coordinates contain a 1.407 Å C–O bond, so the same-topology regular carbonate group from COD 1011149 was mapped into that Pmcn setting and held fixed; the submitted model has C–O = 1.239–1.241 Å and Ba–O = 2.710–2.920 Å. This physical model was selected even though the distorted source coordinates lower Rwp by 0.029 percentage point. The WO3 model is COD 2311041 with refined W positions and fixed parent O positions; its two W sites have six W–O distances spanning 1.720–2.199 Å. The trace BaWO4 CIF is a full-occupancy scheelite model derived from BaMoO4 COD 2300459 by Mo→W substitution and a fitted BaWO4 cell; it gives four W–O bonds of 1.721 Å. The sole exact-composition BaWO4 reference available in the frozen index (COD 1527204) was rejected because split half-occupancy O sites produced 1.46 Å W–O and 1.16 Å O–O contacts.

## Uncertainty

The quoted standard uncertainties are covariance-derived counting-statistics values and do not include model selection, background/profile correlation, preferred orientation, microabsorption, or amorphous material. With no internal standard, amorphous content and absolute specimen composition cannot be determined; only crystalline-normalized fractions are reported. The two major fractions are well supported, but the BaWO4 amount should be read as about 0.5 wt%, with systematic uncertainty plausibly larger than its formal ±{bawo4['weight_percent_esd_formal']:.2f} wt% (roughly ±0.1 wt% is more realistic from model branches).

Light-atom coordinates and displacement parameters are not independently determined by this heavy-atom-dominated laboratory X-ray pattern. Unconstrained O refinements generated implausible bonds and were rolled back. The BaWO4 oxygen coordinates are analogue-derived, so the scheelite topology and reflection family are supported but its detailed oxygen structure is not reliably refined here. WO3 isotropic displacement entries retained from the source include zero placeholders; they must not be interpreted as measured thermal motion. Because no calibrated instrumental profile was supplied, instrument broadening, crystallite size, and microstrain are also not uniquely separable; bounded physical profile/strain terms were used only to describe peak shapes.
"""
    (outdir / "report.md").write_text(report)


if __name__ == "__main__":
    main()
