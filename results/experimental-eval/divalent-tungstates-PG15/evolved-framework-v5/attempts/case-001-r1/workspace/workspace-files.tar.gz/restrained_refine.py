#!/usr/bin/env python3
"""Test physically restrained light-atom refinements from a heavy-atom checkpoint."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def capture(project, tag):
    h = project.histogram(0)
    result = {
        "tag": tag,
        "wR_percent": h.get_wR(),
        "mass_fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "phases": {},
    }
    for p in project.phases():
        result["phases"][p.name] = {
            "cell": p.get_cell(),
            "atoms": [
                {"label": a.label, "element": a.element, "xyz": list(a.coordinates), "uiso": a.uiso}
                for a in p.atoms()
            ],
        }
    print("RESTRAINED_STATE", json.dumps(result, sort_keys=True))
    return result


def refine_save(project, outdir, tag, states):
    project.refine(makeBack=False)
    states.append(capture(project, tag))
    shutil.copy2(project.filename, outdir / f"{tag}.gpx")
    for p in project.phases():
        p.export_CIF(str(outdir / f"{tag}_{p.name}.cif"))
    (outdir / "trajectory.json").write_text(json.dumps(states, indent=2) + "\n")


def run(source: Path, outdir: Path, wo_weight: float, co_weight: float):
    outdir.mkdir(parents=True, exist_ok=True)
    p = G2sc.G2Project(gpxfile=str(source.resolve()))
    p.save(str((outdir / "work.gpx").resolve()))
    p.set_Controls("cycles", 8)
    p.set_Frozen()
    for phase in p.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    states = [capture(p, "initialized")]

    def ensure_bond_restraints(phase):
        restraints = p.data["Restraints"]["data"]
        restraints.setdefault(phase.name, {})
        restraints[phase.name].setdefault(
            "Bond", {"wtFactor": 1.0, "Range": 1.1, "Bonds": [], "Use": True}
        )

    # Preserve sixfold WO3 coordination while allowing oxygen displacements.
    wo3 = p.phase("WO3_2311041")
    ensure_bond_restraints(wo3)
    wo3.clearDistRestraint()
    oxygen = [a for a in wo3.atoms() if a.element == "O"]
    count = wo3.addDistRestraint(["W1", "W2"], oxygen, 1.93, factor=1.27, ESD=0.10)
    wo3.setDistRestraintWeight(wo_weight)
    for atom in oxygen:
        atom.refinement_flags = "X"
    print("WO_RESTRAINTS", count, wo_weight)
    refine_save(p, outdir, "r01_wo3_oxygen", states)

    # Freeze WO3 light atoms and refine the carbonate group near equal C-O bonds.
    for atom in wo3.atoms():
        atom.refinement_flags = " "
    carb = p.phase("BaCO3_9010928")
    ensure_bond_restraints(carb)
    carb.clearDistRestraint()
    c_oxygen = [a for a in carb.atoms() if a.element == "O"]
    count = carb.addDistRestraint(["C"], c_oxygen, 1.29, factor=1.20, ESD=0.03)
    carb.setDistRestraintWeight(co_weight)
    for atom in carb.atoms():
        if atom.element in {"C", "O"}:
            atom.refinement_flags = "X"
    print("CO_RESTRAINTS", count, co_weight)
    refine_save(p, outdir, "r02_carbonate", states)

    shutil.copy2(p.filename, outdir / "restrained_candidate.gpx")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--weight", type=float)
    ap.add_argument("--wo-weight", type=float)
    ap.add_argument("--co-weight", type=float)
    a = ap.parse_args()
    wo_weight = a.wo_weight if a.wo_weight is not None else a.weight
    co_weight = a.co_weight if a.co_weight is not None else a.weight
    if wo_weight is None or co_weight is None:
        ap.error("supply --weight or both --wo-weight and --co-weight")
    run(a.source, a.outdir.resolve(), wo_weight, co_weight)


if __name__ == "__main__":
    main()
