#!/usr/bin/env python3
"""Rewrite the physical witherite reference in a GSAS-II-compatible setting."""

from __future__ import annotations

import argparse
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    structure = Structure.from_file(args.source, primitive=False, merge_tol=0.01)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    CifWriter(
        structure,
        symprec=0.01,
        significant_figures=8,
        refine_struct=True,
    ).write_file(args.output)


if __name__ == "__main__":
    main()
