#!/usr/bin/env python3
"""Refine one symmetry-constrained isotropic displacement factor per major phase."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def run(source: Path, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    p = G2sc.G2Project(gpxfile=str(source.resolve()))
    p.save(str((outdir / "work.gpx").resolve()))
    p.set_Frozen()
    # Coordinates have already been screened; isolate displacement factors.
    for phase in p.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    p.set_Controls("cycles", 8)

    for phase_name in ["BaCO3_9010928", "WO3_2311041"]:
        phase = p.phase(phase_name)
        pid = phase.id
        variables = []
        for i, atom in enumerate(phase.atoms()):
            atom.uiso = 0.010
            atom.refinement_flags = "U"
            variables.append(f"{pid}::AUiso:{i}")
        p.add_EquivConstr(variables, reloadIdx=False)
        p.set_Controls("parmMin", 0.001, variables[0])
        p.set_Controls("parmMax", 0.030, variables[0])

    p.save()
    p.refine(makeBack=False)
    h = p.histogram(0)
    result = {
        "wR_percent": h.get_wR(),
        "mass_fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "uiso": {phase.name: [a.uiso for a in phase.atoms()] for phase in p.phases()},
        "vary_list": p.data["Covariance"]["data"].get("varyList", []),
        "constraints": p.data["Constraints"]["data"],
    }
    print("UISO_STATE", json.dumps(result, default=str, sort_keys=True))
    shutil.copy2(p.filename, outdir / "uiso_refined.gpx")
    for phase in p.phases():
        phase.export_CIF(str(outdir / f"uiso_{phase.name}.cif"))
    (outdir / "result.json").write_text(json.dumps(result, indent=2, default=str) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("outdir", type=Path)
    a = ap.parse_args()
    run(a.source, a.outdir.resolve())


if __name__ == "__main__":
    main()
