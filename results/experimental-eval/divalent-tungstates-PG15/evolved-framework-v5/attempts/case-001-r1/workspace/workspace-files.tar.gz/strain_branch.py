#!/usr/bin/env python3
"""Screen one bounded uniaxial microstrain model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def run(source, outdir, phase_name, axis):
    outdir.mkdir(parents=True, exist_ok=True)
    p = G2sc.G2Project(gpxfile=str(source.resolve()))
    p.save(str((outdir / "work.gpx").resolve()))
    p.set_Frozen()
    h = p.histogram(0)
    h.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for phase in p.phases():
        phase.clear_HAP_refinements({"Mustrain": True, "Pref.Ori.": True}, [h])
        for atom in phase.atoms():
            atom.refinement_flags = " "
    phase = p.phase(phase_name)
    ms = phase.data["Histograms"][h.name]["Mustrain"]
    initial = ms[1][0]
    ms[0] = "uniaxial"
    ms[1][0] = initial
    ms[1][1] = initial
    ms[2][0] = True
    ms[2][1] = True
    ms[3] = axis
    for suffix in ["i", "a"]:
        p.set_Controls("parmMin", 100.0, f"{phase.id}:0:Mustrain;{suffix}")
        p.set_Controls("parmMax", 8000.0, f"{phase.id}:0:Mustrain;{suffix}")
    p.set_Controls("cycles", 8)
    p.refine(makeBack=False)
    ms = phase.data["Histograms"][h.name]["Mustrain"]
    result = {
        "phase": phase_name,
        "axis": axis,
        "equatorial": ms[1][0],
        "axial": ms[1][1],
        "wR_percent": h.get_wR(),
        "mass_fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "frozen": p.get_Frozen(),
    }
    print("STRAIN", json.dumps(result, sort_keys=True))
    shutil.copy2(p.filename, outdir / "refined.gpx")
    (outdir / "result.json").write_text(json.dumps(result, indent=2) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--phase", required=True)
    ap.add_argument("--axis", nargs=3, type=int, required=True)
    a = ap.parse_args()
    run(a.source, a.outdir.resolve(), a.phase, a.axis)


if __name__ == "__main__":
    main()
