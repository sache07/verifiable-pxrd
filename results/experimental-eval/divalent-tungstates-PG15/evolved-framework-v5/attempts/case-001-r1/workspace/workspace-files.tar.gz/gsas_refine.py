#!/usr/bin/env python3
"""Build and refine GSAS-II branches for the BaCO3/WO3 specimen."""

from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
import sys
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PHASE_LIBRARY = {
    "BaCO3_9010928": "9010928",
    "BaCO3_1011149": "1011149",
    "WO3_2311041": "2311041",
    "WO3_1528915": "1528915",
    "WO3_2106293": "2106293",
    "WO3_1010618": "1010618",
    "WO3_2107312": "2107312",
    "WO3_1563541": "1563541",
    "BaWO4_1527204": "1527204",
}


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_inputs(outdir: Path) -> tuple[Path, Path]:
    outdir.mkdir(parents=True, exist_ok=True)
    xye = outdir / "pattern.xye"
    inst = outdir / "instrument.instprm"
    with (ROOT / "inputs/pattern.csv").open(newline="") as src, xye.open("w") as dst:
        reader = csv.DictReader(src)
        for row in reader:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    inst.write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha Bragg-Brentano data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:10.0;V:0.0;W:10.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def build_project(outdir: Path, phase_keys: list[str]) -> G2sc.G2Project:
    xye, inst = prepare_inputs(outdir)
    gpx_path = outdir / "branch.gpx"
    project = G2sc.G2Project(newgpx=str(gpx_path))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [800.0] + [0.0] * 11,
                "refine": False,
            }
        }
    )
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"][1] = False
    hist.SampleParameters["Shift"][0] = -500.0
    for key in phase_keys:
        project.add_phase(
            str(cod_path(PHASE_LIBRARY[key])),
            phasename=key,
            histograms=[hist],
            fmthint="CIF",
        )
    # Give the linear scale search a physically positive starting point.
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][0] = 1.0
    project.save()
    return project


def summarize(project: G2sc.G2Project, tag: str) -> dict:
    hist = project.histogram(0)
    result = {
        "tag": tag,
        "wR_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": {
            k: hist.InstrumentParameters[k][1]
            for k in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"]
            if k in hist.InstrumentParameters
        },
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in hist.SampleParameters.items()
            if k in ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"]
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "scale": hap["Scale"][0],
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    print("SUMMARY", json.dumps(result, default=str, sort_keys=True))
    return result


def refine_checked(project: G2sc.G2Project, outdir: Path, tag: str) -> dict:
    project.refine(makeBack=False)
    project.save(str(outdir / f"{tag}.gpx"))
    state = summarize(project, tag)
    if not np.isfinite(state["wR_percent"]):
        raise RuntimeError(f"nonfinite refinement result at {tag}")
    return state


def run(outdir: Path, phase_keys: list[str], mode: str) -> None:
    project = build_project(outdir, phase_keys)
    hist = project.histogram(0)
    print("HISTOGRAM", hist.name)
    print("INSTRUMENT", hist.InstrumentParameters)
    print("SAMPLE", hist.SampleParameters)
    summarize(project, "initial")
    if mode == "build":
        return

    states = []
    # 1. Establish background and positive phase scales with positions held.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])
    states.append(refine_checked(project, outdir, "s01_bg_scales"))

    # 2. Fit the common specimen height shift.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    states.append(refine_checked(project, outdir, "s02_shift"))

    # 3. Refine phase cells against all reflection families.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    states.append(refine_checked(project, outdir, "s03_cells"))

    # 4. Refine stable instrumental width terms, then asymmetry.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    states.append(refine_checked(project, outdir, "s04_profile"))
    if mode == "screen":
        project.save(str(outdir / "refined.gpx"))
        (outdir / "trajectory.json").write_text(json.dumps(states, indent=2, default=str) + "\n")
        return
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    states.append(refine_checked(project, outdir, "s05_asym"))

    # Keep a canonical branch project and machine-readable trajectory.
    project.save(str(outdir / "refined.gpx"))
    (outdir / "trajectory.json").write_text(json.dumps(states, indent=2, default=str) + "\n")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("outdir", type=Path)
    p.add_argument("phases", nargs="+", choices=sorted(PHASE_LIBRARY))
    p.add_argument("--mode", choices=["build", "screen", "refine"], default="refine")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run(args.outdir.resolve(), args.phases, args.mode)
