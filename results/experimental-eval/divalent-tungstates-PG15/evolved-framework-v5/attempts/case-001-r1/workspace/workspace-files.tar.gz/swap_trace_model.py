#!/usr/bin/env python3
"""Replace the split-site BaWO4 source with a full-occupancy scheelite model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


OLD = "BaWO4_1527204"
NEW = "BaWO4_scheelite"


def remove_phase(project, name: str) -> None:
    del project.data["Phases"][name]
    for entry in project.names:
        if entry and entry[0] == "Phases" and name in entry:
            entry.remove(name)
    for hist in project.histograms():
        hist.data.get("Reflection Lists", {}).pop(name, None)
    project.data["Restraints"]["data"].pop(name, None)
    project.update_ids()


def summary(project, tag):
    h = project.histogram(0)
    out = {
        "tag": tag,
        "wR_percent": h.get_wR(),
        "mass_fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "phases": {
            p.name: {
                "cell": p.get_cell(),
                "scale": p.data["Histograms"][h.name]["Scale"][0],
                "composition": p.composition,
                "atoms": [
                    {"label": a.label, "element": a.element, "xyz": list(a.coordinates), "occ": a.occupancy, "uiso": a.uiso}
                    for a in p.atoms()
                ],
            }
            for p in project.phases()
        },
    }
    print("TRACE_STATE", json.dumps(out, sort_keys=True))
    return out


def run(source: Path, model: Path, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    p = G2sc.G2Project(gpxfile=str(source.resolve()))
    p.save(str((outdir / "work.gpx").resolve()))
    p.set_Frozen()
    h = p.histogram(0)
    remove_phase(p, OLD)
    trace = p.add_phase(str(model.resolve()), phasename=NEW, histograms=[h], fmthint="CIF")
    hap = trace.data["Histograms"][h.name]
    hap["Scale"] = [0.10, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.30
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    trace.set_refinements({"Cell": True})
    for atom in trace.atoms():
        atom.refinement_flags = " "
    p.set_Controls("cycles", 8)
    p.save()
    states = [summary(p, "initialized")]

    p.refine(makeBack=False)
    states.append(summary(p, "t01_refined_cell"))
    shutil.copy2(p.filename, outdir / "t01_refined_cell.gpx")
    for phase in p.phases():
        phase.export_CIF(str(outdir / f"t01_{phase.name}.cif"))

    # Fix the weak trace cell after the first converged family fit and stabilize scales.
    p.phase(NEW).clear_refinements({"Cell": True})
    p.refine(makeBack=False)
    states.append(summary(p, "t02_stable"))
    shutil.copy2(p.filename, outdir / "physical_trace.gpx")
    for phase in p.phases():
        phase.export_CIF(str(outdir / f"t02_{phase.name}.cif"))
    (outdir / "trajectory.json").write_text(json.dumps(states, indent=2) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("model", type=Path)
    ap.add_argument("outdir", type=Path)
    a = ap.parse_args()
    run(a.source, a.model, a.outdir.resolve())


if __name__ == "__main__":
    main()
