#!/usr/bin/env python3
"""Create a physical BaWO4 scheelite model from the BaMoO4 analogue COD 2300459."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/30/04/2300459.cif"
)
OUT = Path(__file__).resolve().parent / "models" / "BaWO4_scheelite_from_BaMoO4_2300459.cif"


def main() -> None:
    structure = Structure.from_file(SOURCE, primitive=False)
    structure.replace_species({"Mo": "W"})
    # Peak-position result from the trace BaWO4 family; coordinates are transferred
    # from the full-occupancy BaMoO4 scheelite model without further adjustment.
    structure = Structure(
        Lattice.tetragonal(5.5835940430, 12.6991767243),
        structure.species,
        structure.frac_coords,
        site_properties=structure.site_properties,
    )
    OUT.parent.mkdir(parents=True, exist_ok=True)
    CifWriter(structure, symprec=1e-5, refine_struct=False).write_file(OUT)
    print(OUT)


if __name__ == "__main__":
    main()
