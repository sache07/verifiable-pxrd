#!/usr/bin/env python3
"""Screen one bounded March-Dollase preferred-orientation axis."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def run(source, outdir, phase_name, axis):
    outdir.mkdir(parents=True, exist_ok=True)
    p = G2sc.G2Project(gpxfile=str(source.resolve()))
    p.save(str((outdir / "work.gpx").resolve()))
    p.set_Frozen()
    h = p.histogram(0)
    h.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for phase in p.phases():
        phase.clear_HAP_refinements({"Pref.Ori.": True}, [h])
        for atom in phase.atoms():
            atom.refinement_flags = " "
    phase = p.phase(phase_name)
    po = phase.data["Histograms"][h.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = axis
    p.set_Controls("parmMin", 0.60, f"{phase.id}:0:MD")
    p.set_Controls("parmMax", 1.60, f"{phase.id}:0:MD")
    p.set_Controls("cycles", 8)
    p.refine(makeBack=False)
    result = {
        "phase": phase_name,
        "axis": axis,
        "ratio": phase.data["Histograms"][h.name]["Pref.Ori."][1],
        "wR_percent": h.get_wR(),
        "mass_fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "frozen": p.get_Frozen(),
    }
    print("PO", json.dumps(result, sort_keys=True))
    shutil.copy2(p.filename, outdir / "refined.gpx")
    (outdir / "result.json").write_text(json.dumps(result, indent=2) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--phase", required=True)
    ap.add_argument("--axis", nargs=3, type=int, required=True)
    a = ap.parse_args()
    run(a.source, a.outdir.resolve(), a.phase, a.axis)


if __name__ == "__main__":
    main()
