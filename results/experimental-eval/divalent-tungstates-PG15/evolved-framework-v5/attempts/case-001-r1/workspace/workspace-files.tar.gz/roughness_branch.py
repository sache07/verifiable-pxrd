#!/usr/bin/env python3
"""Refine Suortti surface roughness from bounded starting points."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def run(source, outdir, start_a, start_b, fix_a=False):
    outdir.mkdir(parents=True, exist_ok=True)
    p = G2sc.G2Project(gpxfile=str(source.resolve()))
    p.save(str((outdir / "work.gpx").resolve()))
    p.set_Frozen()
    h = p.histogram(0)
    for phase in p.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    h.SampleParameters["SurfRoughA"][0] = start_a
    h.SampleParameters["SurfRoughB"][0] = start_b
    params = ["SurfRoughB"] if fix_a else ["SurfRoughA", "SurfRoughB"]
    h.set_refinements({"Sample Parameters": params})
    p.set_Controls("parmMin", 0.001, ":0:SurfRoughA")
    p.set_Controls("parmMax", 0.99, ":0:SurfRoughA")
    p.set_Controls("parmMin", 0.001, ":0:SurfRoughB")
    p.set_Controls("parmMax", 0.80, ":0:SurfRoughB")
    p.set_Controls("cycles", 8)
    p.refine(makeBack=False)
    result = {
        "start_a": start_a,
        "start_b": start_b,
        "fix_a": fix_a,
        "a": h.SampleParameters["SurfRoughA"][0],
        "b": h.SampleParameters["SurfRoughB"][0],
        "wR_percent": h.get_wR(),
        "mass_fractions": {k: list(v) for k, v in h.ComputeMassFracs().items()},
        "frozen": p.get_Frozen(),
    }
    print("ROUGHNESS", json.dumps(result, sort_keys=True))
    shutil.copy2(p.filename, outdir / "refined.gpx")
    (outdir / "result.json").write_text(json.dumps(result, indent=2) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--a", type=float, required=True)
    ap.add_argument("--b", type=float, required=True)
    ap.add_argument("--fix-a", action="store_true")
    x = ap.parse_args()
    run(x.source, x.outdir.resolve(), x.a, x.b, x.fix_a)


if __name__ == "__main__":
    main()
