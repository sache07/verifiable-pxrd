#!/usr/bin/env python3
"""Test regular carbonate-group coordinates in the accepted BaCO3 topology."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def summary(project: G2sc.G2Project, tag: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase("BaCO3_9010928")
    return {
        "tag": tag,
        "Rwp_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "mass_fractions": {
            name: list(value) for name, value in hist.ComputeMassFracs().items()
        },
        "cell": phase.get_cell(),
        "baco3_coordinates": {
            atom.label: list(atom.coordinates) for atom in phase.atoms()
        },
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()

    outdir = args.outdir.resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(gpxfile=str(args.source.resolve()))
    project.save(str(outdir / "work.gpx"))
    project.set_Frozen()
    phase = project.phase("BaCO3_9010928")

    # COD 1011149 gives a regular carbonate group in this topology. Map its
    # relative coordinates into the accepted Pmcn origin while retaining the
    # diffraction-supported Ba sublattice and refined cell.
    phase.atom("C").coordinates = (0.25, 0.7500, -0.0711)
    phase.atom("O1").coordinates = (0.25, 0.8890, -0.0711)
    phase.atom("O2").coordinates = (0.4520, 0.6800, -0.0711)
    for label in ["C", "O1", "O2"]:
        phase.atom(label).refinement_flags = " "

    project.set_Controls("cycles", 10)
    project.save()
    states = [summary(project, "regular_carbonate_start")]
    for number in range(1, 4):
        project.refine(makeBack=False)
        tag = f"regular_carbonate_{number}"
        states.append(summary(project, tag))
        shutil.copy2(project.filename, outdir / f"{tag}.gpx")
        for item in project.phases():
            item.export_CIF(str(outdir / f"{tag}_{item.name}.cif"))
        (outdir / "trajectory.json").write_text(
            json.dumps(states, indent=2, default=str) + "\n"
        )


if __name__ == "__main__":
    main()
