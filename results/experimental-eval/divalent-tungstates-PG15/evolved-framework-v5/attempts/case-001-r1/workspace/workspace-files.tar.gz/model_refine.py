#!/usr/bin/env python3
"""Refine structural coordinates in heavy-to-light order with checkpoints."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


def project_state(project: G2sc.G2Project, tag: str) -> dict:
    hist = project.histogram(0)
    out = {
        "tag": tag,
        "wR_percent": hist.get_wR(),
        "mass_fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "instrument": {k: hist.InstrumentParameters[k][1] for k in ["Zero", "U", "V", "W", "X", "Y", "SH/L"]},
        "sample": {k: hist.SampleParameters[k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "phases": {},
        "vary_list": list(project.data["Covariance"]["data"].get("varyList", [])),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": list(atom.coordinates),
                    "uiso": atom.uiso,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    print("MODEL_STATE", json.dumps(out, default=str, sort_keys=True))
    return out


def save_checkpoint(project, outdir: Path, tag: str, states: list[dict]) -> None:
    project.refine(makeBack=False)
    s = project_state(project, tag)
    if s["wR_percent"] is None or not np.isfinite(s["wR_percent"]):
        raise RuntimeError(f"invalid refinement at {tag}")
    shutil.copy2(project.filename, outdir / f"{tag}.gpx")
    for phase in project.phases():
        phase.export_CIF(str(outdir / f"{tag}_{phase.name}.cif"))
    states.append(s)
    (outdir / "trajectory.json").write_text(json.dumps(states, indent=2, default=str) + "\n")


def reset_model(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    project.set_Frozen()
    # Retain a physical bounded common profile but stop its tradeoff with structure.
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
    hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB", "Transparency"]})
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        for atom in phase.atoms():
            atom.refinement_flags = " "

    # The trace phase cannot support independent profile refinement.
    profiles = {
        "BaCO3_9010928": (5.0, 1450.0),
        "WO3_2311041": (5.0, 3475.0),
        "BaWO4_1527204": (0.30, 1000.0),
    }
    for phase in project.phases():
        size, strain = profiles[phase.name]
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
    # Trace cell shifts are poorly conditioned; keep its last reasonable cell.
    project.phase("BaWO4_1527204").clear_refinements({"Cell": True})


def run(source: Path, outdir: Path) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(gpxfile=str(source.resolve()))
    project.save(str((outdir / "work.gpx").resolve()))
    project.set_Controls("cycles", 8)
    reset_model(project)
    project.save()
    states = [project_state(project, "initialized")]

    # Re-establish scales/cells after fixing the trace profile.
    save_checkpoint(project, outdir, "m01_baseline", states)

    # Heavy scatterers first: Ba in carbonate and both unique W sites in WO3.
    project.phase("BaCO3_9010928").atom("Ba").refinement_flags = "X"
    project.phase("WO3_2311041").atom("W1").refinement_flags = "X"
    project.phase("WO3_2311041").atom("W2").refinement_flags = "X"
    save_checkpoint(project, outdir, "m02_heavy", states)
    save_checkpoint(project, outdir, "m03_heavy_stable", states)

    # Oxygen coordinates in the major WO3 phase.
    for atom in project.phase("WO3_2311041").atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    save_checkpoint(project, outdir, "m04_wo3_oxygen", states)

    # Carbonate-group coordinates, accepted only after a geometry screen.
    for atom in project.phase("BaCO3_9010928").atoms():
        if atom.element in {"C", "O"}:
            atom.refinement_flags = "X"
    save_checkpoint(project, outdir, "m05_all_light", states)
    save_checkpoint(project, outdir, "m06_all_stable", states)

    shutil.copy2(project.filename, outdir / "model_final_candidate.gpx")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    run(args.source, args.outdir.resolve())


if __name__ == "__main__":
    main()
