#!/usr/bin/env python3
"""Test a physical same-space-group BaCO3 model in the accepted full-grid fit."""

from __future__ import annotations

import argparse
import copy
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


OLD = "BaCO3_9010928"
NEW = "BaCO3_1011149"


def remove_phase(project: G2sc.G2Project, name: str) -> None:
    del project.data["Phases"][name]
    for entry in project.names:
        if entry and entry[0] == "Phases" and name in entry:
            entry.remove(name)
    for hist in project.histograms():
        hist.data.get("Reflection Lists", {}).pop(name, None)
    project.data["Restraints"]["data"].pop(name, None)
    project.update_ids()


def summary(project: G2sc.G2Project, tag: str) -> dict:
    hist = project.histogram(0)
    out = {
        "tag": tag,
        "Rwp_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "mass_fractions": {
            name: list(value) for name, value in hist.ComputeMassFracs().items()
        },
        "phases": {},
        "frozen": project.get_Frozen(),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": list(atom.coordinates),
                    "uiso": atom.uiso,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    print("BACO3_STATE", json.dumps(out, default=str, sort_keys=True))
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("model", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()

    outdir = args.outdir.resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(gpxfile=str(args.source.resolve()))
    project.save(str(outdir / "work.gpx"))
    project.set_Frozen()
    hist = project.histogram(0)
    old = project.phase(OLD)
    old_cell = copy.deepcopy(old.data["General"]["Cell"])
    old_hap = copy.deepcopy(old.data["Histograms"][hist.name])
    remove_phase(project, OLD)

    phase = project.add_phase(
        str(args.model.resolve()), phasename=NEW, histograms=[hist], fmthint="CIF"
    )
    # The standardized Pnma reference uses (a,b,c) = (c,a,b) relative to the
    # accepted Pmcn phase. Initialize it in the equivalent refined metric.
    mapped_cell = copy.deepcopy(old_cell)
    mapped_cell[1:8] = [
        old_cell[3],
        old_cell[1],
        old_cell[2],
        old_cell[4],
        old_cell[5],
        old_cell[6],
        old_cell[7],
    ]
    phase.data["General"]["Cell"] = mapped_cell
    phase.data["Histograms"][hist.name] = old_hap
    phase.data["Histograms"][hist.name]["Mustrain"][3] = [0, 1, 0]
    phase.data["Histograms"][hist.name]["Pref.Ori."][3] = [0, 1, 1]
    phase.set_refinements({"Cell": True})
    for atom in phase.atoms():
        atom.refinement_flags = "X" if atom.element == "Ba" else " "

    project.set_Controls("cycles", 10)
    project.set_Controls("parmMin", 0.60, f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 1.60, f"{phase.id}:0:MD")
    for suffix in ["i", "a"]:
        project.set_Controls("parmMin", 100.0, f"{phase.id}:0:Mustrain;{suffix}")
        project.set_Controls("parmMax", 8000.0, f"{phase.id}:0:Mustrain;{suffix}")
    project.save()

    states = [summary(project, "model_swapped")]
    for number in range(1, 4):
        project.refine(makeBack=False)
        tag = f"physical_baco3_{number}"
        states.append(summary(project, tag))
        shutil.copy2(project.filename, outdir / f"{tag}.gpx")
        for item in project.phases():
            item.export_CIF(str(outdir / f"{tag}_{item.name}.cif"))
        (outdir / "trajectory.json").write_text(
            json.dumps(states, indent=2, default=str) + "\n"
        )


if __name__ == "__main__":
    main()
