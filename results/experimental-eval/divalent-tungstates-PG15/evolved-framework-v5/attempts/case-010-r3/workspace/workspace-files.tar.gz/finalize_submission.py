#!/usr/bin/env python3
"""Freeze the selected GSAS-II checkpoint and export all requested artifacts."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "bounded_o_final_repeat.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "WO3_monoclinic": {
        "name": "monoclinic WO3",
        "formula": "WO3",
        "reference": "COD 2311041",
        "cif": "phase_WO3_monoclinic.cif",
    },
    "Mn2O3_alpha": {
        "name": "alpha-Mn2O3",
        "formula": "Mn2O3",
        "reference": "COD 1514103",
        "cif": "phase_Mn2O3_alpha.cif",
    },
    "MnWO4_test": {
        "name": "wolframite MnWO4",
        "formula": "MnWO4",
        "reference": "COD 1520200 topology; ambient-cell checkpoint",
        "cif": "phase_MnWO4_wolframite.cif",
    },
}


G2.SetPrintLevel("warn")
gpx = G2.G2Project(gpxfile=str(SOURCE))
gpx.save(str(FINAL))
gpx = G2.G2Project(gpxfile=str(FINAL))
h = gpx.histogram(0)

if len(gpx.histograms()) != 1:
    raise RuntimeError("final project must contain exactly one powder histogram")
if set(p.name for p in gpx.phases()) != set(PHASE_INFO):
    raise RuntimeError("unexpected final phase inventory")

x = np.asarray(h.getdata("X"), float)
yobs = np.asarray(h.getdata("Yobs"), float)
ycalc = np.asarray(h.getdata("Ycalc"), float)
background = np.asarray(h.getdata("Background"), float)
if not all(np.isfinite(a).all() for a in (x, yobs, ycalc, background)):
    raise RuntimeError("nonfinite final profile")
if np.any(ycalc < 0) or np.any(background < 0):
    raise RuntimeError("negative calculated intensity or background")

np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x, yobs, ycalc, yobs - ycalc, background)),
    delimiter=",",
    header="two_theta,observed,calculated,difference,background",
    comments="",
    fmt="%.10f",
)

# Normalized project mass fractions and covariance-only standard uncertainties.
phases = gpx.phases()
masses_per_scale = np.asarray([p.data["General"]["Mass"] for p in phases], float)
scales = np.asarray([p.getHAPvalues(h.name)["Scale"][0] for p in phases], float)
mass_scales = masses_per_scale * scales
fractions = mass_scales / mass_scales.sum()

cov = gpx.data.get("Covariance", {}).get("data", {})
vary = list(cov.get("varyList", []))
full_cov = np.asarray(cov.get("covMatrix", np.zeros((len(vary), len(vary)))), float)
scale_indices = [vary.index(f"{i}:0:Scale") for i in range(len(phases))]
scale_cov = full_cov[np.ix_(scale_indices, scale_indices)]
total = mass_scales.sum()
jac = np.empty((len(phases), len(phases)))
for i in range(len(phases)):
    for j in range(len(phases)):
        jac[i, j] = ((masses_per_scale[i] if i == j else 0.0) * total
                     - mass_scales[i] * masses_per_scale[j]) / total**2
fraction_cov = jac @ scale_cov @ jac.T
fraction_su = np.sqrt(np.maximum(np.diag(fraction_cov), 0.0))

phase_rows = []
for i, phase in enumerate(phases):
    info = PHASE_INFO[phase.name]
    phase.export_CIF(str(ROOT / info["cif"]))
    cell = list(map(float, phase.data["General"]["Cell"][1:8]))
    phase_rows.append({
        "name": info["name"],
        "formula": info["formula"],
        "cif_path": info["cif"],
        "weight_fraction": float(fractions[i]),
        "weight_fraction_standard_uncertainty_covariance_only": float(fraction_su[i]),
        "reference_model": info["reference"],
        "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
        "cell": {
            "a_angstrom": cell[0], "b_angstrom": cell[1], "c_angstrom": cell[2],
            "alpha_deg": cell[3], "beta_deg": cell[4], "gamma_deg": cell[5],
            "volume_angstrom3": cell[6],
        },
    })

rvals = cov.get("Rvals", {})
result = {
    "phases": phase_rows,
    "fraction_basis": "normalized over all modeled crystalline phases",
    "refinement_histogram": h.name,
    "fit_statistics": {
        "rwp_percent": float(h.residuals["wR"]),
        "rp_percent": float(h.residuals["R"]),
        "gof": float(rvals.get("GOF", np.nan)),
        "chi_square": float(rvals.get("chisq", np.nan)),
        "number_of_observations": int(rvals.get("Nobs", len(x))),
        "number_of_refined_variables": int(rvals.get("Nvars", len(vary))),
        "converged": bool(rvals.get("converged", False)),
        "weighting": "1/max(observed_counts,1); pointwise uncertainties were not supplied",
    },
    "calibration": {
        "zero_deg": float(h.InstrumentParameters["Zero"][1]),
        "sample_displacement_micrometre": float(h.SampleParameters["Shift"][0]),
        "wavelength_Kalpha1_angstrom": float(h.InstrumentParameters["Lam1"][1]),
        "wavelength_Kalpha2_angstrom": float(h.InstrumentParameters["Lam2"][1]),
        "Kalpha2_to_Kalpha1_ratio": float(h.InstrumentParameters["I(L2)/I(L1)"][1]),
    },
    "profile_file": "fit.csv",
    "project_file": "final.gpx",
    "unresolved_components": [],
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

wp = 100 * fractions
su = 100 * fraction_su
report = f"""# Powder XRD phase analysis

The scan is best described by three crystalline phases: **monoclinic WO3
({wp[0]:.2f} wt%)**, **alpha-Mn2O3 ({wp[1]:.2f} wt%)**, and trace
**wolframite MnWO4 ({wp[2]:.2f} wt%)**. Fractions are normalized over the
modeled crystalline phases. The covariance-only standard uncertainties are
{su[0]:.2f}, {su[1]:.2f}, and {su[2]:.2f} percentage points, respectively;
they do not include model or reference-structure uncertainty.

## Evidence

The metadata gives Mn2O3 and WO3 precursors heated at 500 C and a Cu K-alpha
reflection scan. Monoclinic WO3 accounts for the dominant 23.4--24.7 degree
triplet and its high-angle families. Alpha-Mn2O3 accounts for the coherent
families near 33.27, 38.53, 45.03, 49.6, 55.0, and 66.0 degrees. A physical
monoclinic WO3 model (COD 2311041) was preferred over a marginally closer
legacy intensity model that produced an implausibly short O--O contact.

After both precursor phases were complete, weak residuals at the wolframite
positions (especially the 30.1/30.6 degree pair and the 36.3, 51.5, and 60.9
degree families) gave a positive MnWO4 scale. It remained approximately
0.5--0.8 wt% over tested cell and peak-width checkpoints. The submitted
MnWO4 model uses the COD 1520200 wolframite topology with a bounded
ambient-cell checkpoint. Mn3WO6 was also tested, but its very small apparent
scale was driven by mixed peak overlaps rather than broad family support and
was not retained.

## Refinement and uncertainty

The final GSAS-II fit used the stated Cu K-alpha doublet, a Chebyshev
background, calibrated zero/sample displacement, physical size and strain
broadening, and bounded surface/profile terms. Heavy WO3 coordinates and two
small bounded oxygen-coordinate starts were checked; the 0.05-A start retained
physical W--O and O--O distances. The full-grid fit gives
Rwp = {h.residuals['wR']:.3f}%, Rp = {h.residuals['R']:.3f}%, and
GOF = {float(rvals.get('GOF')):.3f}.

Because pointwise uncertainties were not supplied, Poisson count weights were
used. The largest remaining residuals track relative-intensity/split-profile
errors of WO3 rather than a new coherent reflection family. A realistic
systematic uncertainty is therefore larger than the covariance values: about
1--2 percentage points for the two major fractions and roughly 0.2--0.3
percentage point for trace MnWO4. The MnWO4 topology is supported, but its
atomic coordinates and exact cell cannot be independently refined reliably at
this abundance; its structure and fraction should be treated as approximate.
"""
(ROOT / "report.md").write_text(report)

print(json.dumps({
    "histogram": h.name,
    "rwp_percent": h.residuals["wR"],
    "fractions": fractions.tolist(),
    "fraction_su": fraction_su.tolist(),
    "points": len(x),
}, indent=2))
