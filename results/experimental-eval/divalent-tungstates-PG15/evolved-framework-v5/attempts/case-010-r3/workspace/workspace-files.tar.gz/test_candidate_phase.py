#!/usr/bin/env python3
"""Test a candidate phase against a frozen accepted multiphase fit.

Only the phase scales are varied. This makes the sign and magnitude of the
candidate contribution a direct test against the residual rather than a
consequence of reoptimizing the whole model.
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def volume(a, b, c, alpha, beta, gamma):
    ar, br, gr = map(math.radians, (alpha, beta, gamma))
    factor = 1 + 2 * math.cos(ar) * math.cos(br) * math.cos(gr)
    factor -= math.cos(ar) ** 2 + math.cos(br) ** 2 + math.cos(gr) ** 2
    return a * b * c * math.sqrt(factor)


ap = argparse.ArgumentParser()
ap.add_argument("project")
ap.add_argument("cif")
ap.add_argument("name")
ap.add_argument("output")
ap.add_argument("--scale", type=float, default=0.05)
ap.add_argument("--cell", nargs=6, type=float, metavar=("A", "B", "C", "ALPHA", "BETA", "GAMMA"))
ap.add_argument("--size", type=float, default=0.10, help="fixed isotropic crystallite size (micrometres)")
ap.add_argument("--mustrain", type=float, default=4000.0, help="fixed isotropic microstrain (ppm)")
ap.add_argument("--refine-cell", action="store_true")
ap.add_argument("--cycles", type=int, default=8)
args = ap.parse_args()

G2.SetPrintLevel("warn")
out = Path(args.output).resolve()
gpx = G2.G2Project(gpxfile=args.project)
gpx.set_Controls("cycles", args.cycles)
# Adding a phase causes GSAS-II to update the project file immediately. Clone
# the checkpoint first so a branch can never alter its parent project.
gpx.save(str(out))
gpx = G2.G2Project(gpxfile=str(out))
gpx.set_Controls("cycles", args.cycles)
h = gpx.histogram(0)

# Freeze all non-scale variables from the accepted checkpoint.
h.clear_refinements({
    "Instrument Parameters": list(h.InstrumentParameters),
    "Sample Parameters": [
        key for key, value in h.SampleParameters.items()
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)
    ],
    # GSAS-II's Background branch returns from clear_refinements(), so keep
    # this last after all instrument/sample flags have been cleared.
    "Background": True,
})
for p in gpx.phases():
    p.clear_refinements({"Cell": True, "Atoms": [a.label for a in p.atoms()]})
    p.clear_HAP_refinements({
        "Scale": True,
        "Size": True,
        "Mustrain": True,
        "HStrain": True,
        "Pref.Ori.": True,
        "Extinction": True,
    })
    p.set_HAP_refinements({"Scale": True})

# add_phase() indexes the on-disk project, so persist the frozen parent flags
# before making the candidate phase.
gpx.save(str(out))
gpx = G2.G2Project(gpxfile=str(out))
gpx.set_Controls("cycles", args.cycles)
h = gpx.histogram(0)

candidate = gpx.add_phase(args.cif, phasename=args.name, histograms=[h], fmthint="CIF")
if args.cell:
    a, b, c, alpha, beta, gamma = args.cell
    candidate.data["General"]["Cell"][1:8] = [
        a, b, c, alpha, beta, gamma, volume(a, b, c, alpha, beta, gamma)
    ]
candidate.HAPvalue("Scale", args.scale)
candidate.setSampleProfile(h.name, "size", "isotropic", args.size, LGmix=1.0)
candidate.setSampleProfile(h.name, "microstrain", "isotropic", args.mustrain, LGmix=0.0)
candidate.set_HAP_refinements({"Scale": True})
if args.refine_cell:
    candidate.set_refinements({"Cell": True})

gpx.save(str(out))
gpx = G2.G2Project(gpxfile=str(out))
gpx.set_Controls("cycles", args.cycles)
gpx.refine(makeBack=False)
h = gpx.histogram(0)

masses = []
for p in gpx.phases():
    hap = p.getHAPvalues(h.name)
    masses.append(p.data["General"]["Mass"] * hap["Scale"][0])
    print("PHASE", p.name, "scale", hap["Scale"][0], "mass_scale", masses[-1])
total = sum(masses)
print("RESULT Rwp", h.residuals.get("wR"), "fractions", [m / total for m in masses])
