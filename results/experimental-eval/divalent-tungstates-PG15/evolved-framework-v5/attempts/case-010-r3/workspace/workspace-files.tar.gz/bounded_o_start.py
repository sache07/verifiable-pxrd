#!/usr/bin/env python3
"""Test a bounded WO3 oxygen-coordinate start toward an LSQ trial solution."""

import argparse
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

ap = argparse.ArgumentParser()
ap.add_argument("project")
ap.add_argument("target")
ap.add_argument("output")
ap.add_argument("max_displacement", type=float, help="largest O displacement in Angstrom")
ap.add_argument("--cycles", type=int, default=12)
args = ap.parse_args()

G2.SetPrintLevel("warn")
out = Path(args.output).resolve()
gpx = G2.G2Project(gpxfile=args.project)
target = G2.G2Project(gpxfile=args.target).phase("WO3_monoclinic")
gpx.save(str(out))
gpx = G2.G2Project(gpxfile=str(out))
gpx.set_Controls("cycles", args.cycles)
phase = gpx.phase("WO3_monoclinic")

a, b, c, alpha, beta, gamma, _ = map(float, phase.data["General"]["Cell"][1:8])
if abs(alpha - 90) > 1e-6 or abs(gamma - 90) > 1e-6:
    raise ValueError("This bounded-start helper expects the monoclinic b-unique cell")
br = math.radians(beta)
lattice = np.array([[a, 0, 0], [0, b, 0], [c * math.cos(br), 0, c * math.sin(br)]])

vectors = {}
largest = 0.0
for atom in phase.atoms():
    if atom.element != "O":
        continue
    trial = target.atom(atom.label)
    delta = np.asarray(trial.coordinates, float) - np.asarray(atom.coordinates, float)
    delta -= np.rint(delta)
    vectors[atom.label] = delta
    largest = max(largest, float(np.linalg.norm(delta @ lattice)))
factor = min(1.0, args.max_displacement / largest)
for atom in phase.atoms():
    if atom.label in vectors:
        atom.coordinates = (np.asarray(atom.coordinates, float) + factor * vectors[atom.label]) % 1
        atom.refinement_flags = " "

gpx.save(str(out))
gpx = G2.G2Project(gpxfile=str(out))
gpx.set_Controls("cycles", args.cycles)
gpx.refine(makeBack=False)
h = gpx.histogram(0)
masses = [p.data["General"]["Mass"] * p.getHAPvalues(h.name)["Scale"][0] for p in gpx.phases()]
print("RESULT bound", args.max_displacement, "factor", factor, "target_max", largest,
      "Rwp", h.residuals.get("wR"), "fractions", [m / sum(masses) for m in masses])
for atom in gpx.phase("WO3_monoclinic").atoms():
    if atom.element == "O":
        print("O", atom.label, *map(float, atom.coordinates))
