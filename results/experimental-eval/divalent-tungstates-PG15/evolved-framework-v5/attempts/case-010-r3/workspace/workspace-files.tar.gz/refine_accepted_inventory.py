#!/usr/bin/env python3
"""Refine the accepted WO3 + Mn2O3 + trace MnWO4 inventory in stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ap = argparse.ArgumentParser()
ap.add_argument("project")
ap.add_argument("output")
ap.add_argument("--cycles", type=int, default=12)
args = ap.parse_args()

G2.SetPrintLevel("warn")
out = Path(args.output).resolve()
checkpoint_dir = out.parent / (out.stem + "_checkpoints")
checkpoint_dir.mkdir(exist_ok=True)

# Clone first so this branch cannot alter the parent checkpoint.
gpx = G2.G2Project(gpxfile=args.project)
gpx.save(str(out))
gpx = G2.G2Project(gpxfile=str(out))
gpx.set_Controls("cycles", args.cycles)
h = gpx.histogram(0)

# Start from explicit flags; the parameter values are inherited from the
# accepted two-phase refinement and trace-phase scale/cell grid.
h.clear_refinements({
    "Instrument Parameters": list(h.InstrumentParameters),
    "Sample Parameters": [
        key for key, value in h.SampleParameters.items()
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)
    ],
    "Background": True,
})
for p in gpx.phases():
    p.clear_refinements({"Cell": True, "Atoms": [a.label for a in p.atoms()]})
    p.clear_HAP_refinements({
        "Scale": True, "Size": True, "Mustrain": True, "HStrain": True,
        "Pref.Ori.": True, "Extinction": True,
    })
    p.set_HAP_refinements({"Scale": True})
gpx.save(str(out))


def summary(label):
    global gpx, h
    h = gpx.histogram(0)
    masses = []
    rows = []
    for p in gpx.phases():
        hap = p.getHAPvalues(h.name)
        m = p.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(m)
        rows.append({
            "name": p.name,
            "scale": float(hap["Scale"][0]),
            "cell": list(map(float, p.data["General"]["Cell"][1:8])),
            "size": list(map(float, hap["Size"][1][:3])),
            "mustrain": list(map(float, hap["Mustrain"][1][:3])),
        })
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = float(mass / sum(masses))
    inst = h.InstrumentParameters
    sample = h.SampleParameters
    info = {
        "stage": label,
        "rwp": float(h.residuals["wR"]),
        "phases": rows,
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "surface": {k: float(sample[k][0]) for k in ("SurfRoughA", "SurfRoughB")},
        "vary_list": list(gpx.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }
    print(json.dumps(info, indent=2))
    return info


def physical():
    h = gpx.histogram(0)
    inst = h.InstrumentParameters
    checks = {
        "U": (0.0, 40.0), "W": (2.0, 40.0), "X": (0.1, 6.0),
        "SH/L": (0.005, 0.1), "Polariz.": (0.5, 1.0), "Zero": (-0.25, 0.25),
    }
    for key, (lo, hi) in checks.items():
        value = float(inst[key][1])
        if not lo - 1e-8 <= value <= hi + 1e-8:
            return False, f"instrument {key}={value} outside [{lo}, {hi}]"
    for key, (lo, hi) in {"SurfRoughA": (0.05, 0.6), "SurfRoughB": (0.02, 0.5)}.items():
        value = float(h.SampleParameters[key][0])
        if not lo <= value <= hi:
            return False, f"surface {key}={value} outside [{lo}, {hi}]"
    for p in gpx.phases():
        hap = p.getHAPvalues(h.name)
        if hap["Scale"][0] <= 0:
            return False, f"nonpositive scale for {p.name}"
        if not 0.04 <= hap["Size"][1][0] <= 1.5:
            return False, f"size outside prior for {p.name}: {hap['Size'][1][0]}"
        if p.name != "MnWO4_trace":
            strain = hap["Mustrain"][1]
            if not 300 <= strain[0] <= 8000:
                return False, f"equatorial strain outside prior for {p.name}: {strain[0]}"
            if hap["Mustrain"][0] == "uniaxial" and not .25 <= strain[1] / strain[0] <= 4:
                return False, f"uniaxial strain ratio outside prior for {p.name}"
    return True, "ok"


history = []


def refine_stage(label):
    global gpx, h
    gpx.save(str(out))
    gpx = G2.G2Project(gpxfile=str(out))
    gpx.set_Controls("cycles", args.cycles)
    gpx.refine(makeBack=False)
    ok, why = physical()
    info = summary(label)
    info["physical"] = {"ok": ok, "reason": why}
    history.append(info)
    gpx.save(str(checkpoint_dir / f"{label}.gpx"))
    gpx.save(str(out))
    gpx = G2.G2Project(gpxfile=str(out))
    h = gpx.histogram(0)
    if not ok:
        raise RuntimeError(why)


# Scales/background first on the complete inventory.
h.set_refinements({"Background": True})
refine_stage("01_scales_background")

# Common calibration and well-supported major-phase cells.
h.set_refinements({"Instrument Parameters": ["Zero"]})
gpx.phase("WO3_monoclinic").set_refinements({"Cell": True})
gpx.phase("Mn2O3_alpha").set_refinements({"Cell": True})
refine_stage("02_major_cells_zero")

# Heavy-atom coordinates were supported in the two-phase checkpoint.
gpx.phase("WO3_monoclinic").set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
refine_stage("03_wo3_heavy_atoms")

# Major-phase broadening. The trace phase remains on its tested fixed profile.
for name in ("WO3_monoclinic", "Mn2O3_alpha"):
    p = gpx.phase(name)
    p.set_HAP_refinements({"Size": {"type": p.getHAPvalues(h.name)["Size"][0], "refine": True}})
    mode = p.getHAPvalues(h.name)["Mustrain"][0]
    p.set_HAP_refinements({"Mustrain": {"type": mode, "refine": True}})
refine_stage("04_major_profiles")

# Shared axial/profile and physical surface terms; U, W and polarization are
# held at their bounded-grid checkpoint values.
h.set_refinements({
    "Instrument Parameters": ["X", "SH/L"],
    "Sample Parameters": ["SurfRoughA", "SurfRoughB"],
})
refine_stage("05_shared_profile_surface")

(out.parent / (out.stem + "_history.json")).write_text(json.dumps(history, indent=2) + "\n")
