import argparse
import pandas as pd
import matplotlib.pyplot as plt

ap = argparse.ArgumentParser()
ap.add_argument("csv")
ap.add_argument("--out", default="fit_diagnostic.png")
args = ap.parse_args()
d = pd.read_csv(args.csv)
x = d.two_theta_deg
fig, ax = plt.subplots(2, 1, figsize=(16, 8), sharex=True,
                       gridspec_kw={"height_ratios": [2, 1]})
ax[0].plot(x, d.observed, color="black", lw=0.6, label="observed")
ax[0].plot(x, d.calculated, color="tab:red", lw=0.7, label="calculated")
ax[0].legend()
ax[0].set_ylabel("Counts")
ax[1].plot(x, d.difference, color="tab:blue", lw=0.6)
ax[1].axhline(0, color="black", lw=0.4)
ax[1].set_ylabel("Observed - calculated")
ax[1].set_xlabel(r"$2\theta$ (deg)")
fig.tight_layout()
fig.savefig(args.out, dpi=160)
