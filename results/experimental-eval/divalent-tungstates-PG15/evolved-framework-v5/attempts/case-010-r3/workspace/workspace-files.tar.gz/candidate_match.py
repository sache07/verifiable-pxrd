import gzip
import json
from pathlib import Path
import warnings

import numpy as np
import pandas as pd
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy import ndimage, signal

warnings.filterwarnings("ignore")

INDEX = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/venv/"
    "lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz"
)
CIFROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cif_path(codid):
    return CIFROOT / codid[0] / codid[1:3] / codid[3:5] / f"{codid}.cif"


d = pd.read_csv("inputs/pattern.csv")
x = d.two_theta_deg.to_numpy(float)
y = d.intensity.to_numpy(float)
dx = np.median(np.diff(x))
base = ndimage.percentile_filter(y, percentile=12, size=401, mode="nearest")
base = signal.savgol_filter(base, 801, 3)
obs = np.maximum(y - base, 0.0)
# Suppress count-noise contributions outside diffraction maxima.
obs[obs < 100] = 0
obs /= np.linalg.norm(obs)

with gzip.open(INDEX, "rt") as fh:
    idx = json.load(fh)

records = []
for key in ("Mn-O-W", "Mn-O", "Mn-Mn-O", "O-W"):
    for formula, codid, sg, rval in idx.get(key, []):
        records.append((key, formula, codid, sg, rval))

calc = XRDCalculator(wavelength=1.540598)
grid_offset = np.linspace(-0.55, 0.55, 45)
grid_strain = np.linspace(-0.006, 0.006, 13)
results = []
patterns = {}

for key, formula, codid, sg, rval in records:
    try:
        s = Structure.from_file(cif_path(codid), primitive=False)
        pat = calc.get_pattern(s, two_theta_range=(8, 103), scaled=False)
        pp = np.asarray(pat.x, float)
        ii = np.asarray(pat.y, float)
        # Relative integrated intensities, with a broad Gaussian only for
        # screening. Detailed profiles are handled in GSAS-II later.
        ii /= max(ii.max(), 1e-12)
        best = (-np.inf, None, None)
        for strain in grid_strain:
            # d -> d*(1+strain)
            th = np.radians(pp / 2)
            q = np.sin(th) / (1 + strain)
            ok = np.abs(q) < 1
            pos0 = np.degrees(2 * np.arcsin(q[ok]))
            amp0 = ii[ok]
            for off in grid_offset:
                sim = np.zeros_like(x)
                pos = pos0 + off
                ids = np.rint((pos - x[0]) / dx).astype(int)
                good = (ids >= 0) & (ids < len(sim))
                np.add.at(sim, ids[good], amp0[good])
                sim = ndimage.gaussian_filter1d(sim, 0.11 / 2.355 / dx)
                norm = np.linalg.norm(sim)
                score = float(sim @ obs / norm) if norm else 0.0
                if score > best[0]:
                    best = (score, off, strain)
        results.append((best[0], key, formula, codid, sg, rval, best[1], best[2]))
        patterns[codid] = (pp, ii)
    except Exception as exc:
        results.append((-1, key, formula, codid, sg, rval, np.nan, np.nan))
        print(f"ERROR {codid}: {exc}")

for row in sorted(results, reverse=True):
    print(
        f"score={row[0]:.4f} key={row[1]:8s} formula={row[2]:16s} "
        f"COD={row[3]} SG={row[4]:3d} R={row[5]} off={row[6]:+.3f} "
        f"strain={row[7]:+.4f}"
    )

print("\nTOP PEAKS FOR BEST DISTINCT CANDIDATES")
seen = set()
for row in sorted(results, reverse=True):
    if row[2] in seen or row[0] < 0:
        continue
    seen.add(row[2])
    pp, ii = patterns[row[3]]
    order = np.argsort(ii)[::-1][:20]
    vals = " ".join(f"{pp[j]:.3f}({100*ii[j]:.0f})" for j in order)
    print(f"{row[2]} COD {row[3]}: {vals}")
    if len(seen) >= 12:
        break
