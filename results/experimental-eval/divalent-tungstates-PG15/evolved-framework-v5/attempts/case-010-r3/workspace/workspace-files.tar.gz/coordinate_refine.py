#!/usr/bin/env python3
"""Coordinate checkpoints for the accepted WO3 + Mn2O3 inventory."""

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ap = argparse.ArgumentParser()
ap.add_argument("project")
ap.add_argument("--prefix", default="coord")
ap.add_argument("--cycles", type=int, default=12)
ap.add_argument("--keep-uiso", action="store_true")
ap.add_argument("--no-o", action="store_true")
ap.add_argument("--mn-heavy", action="store_true")
args = ap.parse_args()

G2.SetPrintLevel("warn")
gpx = G2.G2Project(gpxfile=args.project)
gpx.set_Controls("cycles", args.cycles)
h = gpx.histogram(0)


def report(label):
    masses = []
    for p in gpx.phases():
        masses.append(p.data["General"]["Mass"] * p.getHAPvalues(h.name)["Scale"][0])
    print("STAGE", label, "Rwp", h.residuals.get("wR"), "fractions", [m / sum(masses) for m in masses])
    for p in gpx.phases():
        print("PHASE", p.name, "cell", p.data["General"]["Cell"][1:8])
        for a in p.atoms():
            print("ATOM", p.name, a.label, a.element, list(a.coordinates), a.uiso, a.refinement_flags)


def stage(label):
    out = Path(f"{args.prefix}_{label}.gpx").resolve()
    gpx.save(str(out))
    # Reload so the refinement is guaranteed to update the named checkpoint.
    fresh = G2.G2Project(gpxfile=str(out))
    fresh.set_Controls("cycles", args.cycles)
    fresh.refine(makeBack=False)
    return fresh


wo = gpx.phase("WO3_monoclinic")
if not args.keep_uiso:
    for a in wo.atoms():
        a.uiso = 0.01
gpx = stage("00_wo3_uiso")
h = gpx.histogram(0)
report("00_wo3_uiso")

wo = gpx.phase("WO3_monoclinic")
wo.set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
gpx = stage("01_wo3_W")
h = gpx.histogram(0)
report("01_wo3_W")

if args.mn_heavy:
    mn = gpx.phase("Mn2O3_alpha")
    mn.set_refinements({"Atoms": {"Mn3": "X", "Mn4": "X", "Mn5": "X"}})
    gpx = stage("015_mn_heavy")
    h = gpx.histogram(0)
    report("015_mn_heavy")

if args.no_o:
    raise SystemExit(0)
wo = gpx.phase("WO3_monoclinic")
wo.set_refinements({"Atoms": {f"O{i}": "X" for i in range(1, 7)}})
gpx = stage("02_wo3_O")
h = gpx.histogram(0)
report("02_wo3_O")
