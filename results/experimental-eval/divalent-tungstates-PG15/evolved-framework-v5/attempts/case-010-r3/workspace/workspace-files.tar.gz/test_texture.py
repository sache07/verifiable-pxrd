#!/usr/bin/env python3
import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2

ap = argparse.ArgumentParser()
ap.add_argument("project")
ap.add_argument("phase")
ap.add_argument("axis", help="comma-separated h,k,l")
ap.add_argument("output")
ap.add_argument("--cycles", type=int, default=8)
args = ap.parse_args()

axis = [int(v) for v in args.axis.split(",")]
G2.SetPrintLevel("warn")
gpx = G2.G2Project(gpxfile=args.project)
gpx.set_Controls("cycles", args.cycles)
h = gpx.histogram(0)
p = gpx.phase(args.phase)
hap = p.getHAPvalues(h.name)
hap["Pref.Ori."][0] = "MD"
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = True
hap["Pref.Ori."][3] = axis
gpx.save(str(Path(args.output).resolve()))
gpx = G2.G2Project(gpxfile=str(Path(args.output).resolve()))
gpx.set_Controls("cycles", args.cycles)
gpx.refine(makeBack=False)
h = gpx.histogram(0)
p = gpx.phase(args.phase)
hap = p.getHAPvalues(h.name)
masses = [q.data["General"]["Mass"] * q.getHAPvalues(h.name)["Scale"][0] for q in gpx.phases()]
print("RESULT", args.phase, axis, "Rwp", h.residuals.get("wR"),
      "ratio", hap["Pref.Ori."][1], "fractions", [m / sum(masses) for m in masses])
