#!/usr/bin/env python3
"""Build and incrementally refine the physically ordinary Mn2O3 + WO3 model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy import ndimage, signal
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif(codid: str) -> str:
    return str(COD / codid[0] / codid[1:3] / codid[3:5] / f"{codid}.cif")


PHASES = [
    ("WO3_monoclinic", "1528915", 4.0, 1.00, 3000.0),
    ("Mn2O3_alpha", "1514103", 1.0, 1.00, 1000.0),
]


def background_coefficients(n=12):
    data = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    x, y = data.T
    baseline = ndimage.percentile_filter(y, percentile=12, size=401, mode="nearest")
    baseline = signal.savgol_filter(baseline, 801, 3)
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, baseline, n - 1).tolist()


def summarize(gpx, label):
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    phases = []
    masses = []
    for p in gpx.phases():
        hap = p.getHAPvalues(hist.name)
        mass_scale = p.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        phases.append(
            {
                "name": p.name,
                "cell": list(map(float, p.data["General"]["Cell"][1:8])),
                "scale": float(hap["Scale"][0]),
                "mass_scale": float(mass_scale),
                "size": [hap["Size"][0], *map(float, hap["Size"][1])],
                "mustrain": [hap["Mustrain"][0], *map(float, hap["Mustrain"][1])],
                "pref_ori": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for p, m in zip(phases, masses):
        p["weight_fraction"] = float(m / total) if total > 0 else None
    cov = gpx.data.get("Covariance", {}).get("data", {})
    result = {
        "stage": label,
        "residuals": hist.residuals,
        "instrument": {
            k: float(inst[k][1])
            for k in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
            if k in inst
        },
        "sample": {
            k: (float(v[0]) if isinstance(v, list) else v)
            for k, v in sample.items()
            if k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type"]
        },
        "phases": phases,
        "vary_list": list(cov.get("varyList", [])),
        "sig": [float(v) for v in cov.get("sig", [])],
        "Rvals": cov.get("Rvals", {}),
    }
    print(json.dumps(result, indent=2, default=str))
    return result


def physical(gpx):
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    for key in ("U", "W", "X", "SH/L"):
        if key in inst and (not np.isfinite(inst[key][1]) or inst[key][1] <= 0):
            return False, f"nonpositive instrument {key}={inst[key][1]}"
    for p in gpx.phases():
        cell = np.asarray(p.data["General"]["Cell"][1:8], float)
        hap = p.getHAPvalues(hist.name)
        if not np.all(np.isfinite(cell)) or np.any(cell[:3] <= 0) or cell[6] <= 0:
            return False, f"invalid cell for {p.name}"
        if hap["Scale"][0] <= 0:
            return False, f"nonpositive scale for {p.name}"
        if hap["Size"][1][0] <= 0 or hap["Mustrain"][1][0] < 0:
            return False, f"invalid profile for {p.name}"
    return True, "ok"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="base_two_phase.gpx")
    ap.add_argument("--cycles", type=int, default=8)
    ap.add_argument("--shift", type=float, default=-500.0,
                    help="fixed Bragg-Brentano sample shift in micrometres")
    ap.add_argument("--zero", type=float, default=None,
                    help="starting zero offset; default is estimated from fixed shift")
    ap.add_argument("--wo3-id", default="1528915",
                    help="COD identifier for the exact-composition WO3 reference")
    args = ap.parse_args()

    out = ROOT / args.out
    cdir = ROOT / f"checkpoints_{out.stem}"
    cdir.mkdir(exist_ok=True)
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    if args.zero is None:
        # Empirical near-collinearity from the peak-location checkpoint;
        # sufficient to start each bounded shift-grid branch on the peaks.
        hist.InstrumentParameters["Zero"][1] = 0.274 + 0.00055 * args.shift
    else:
        hist.InstrumentParameters["Zero"][1] = float(args.zero)
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    # Sample scale is redundant with all HAP scales. Keep it fixed.
    hist.SampleParameters["Scale"][1] = False
    hist.SampleParameters["Shift"] = [float(args.shift), False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(hist.getdata("X")[0]), float(hist.getdata("X")[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": background_coefficients(12),
                "refine": True,
            },
        }
    )

    phases = []
    phase_specs = [
        (name, args.wo3_id if name == "WO3_monoclinic" else codid, scale, size, mustrain)
        for name, codid, scale, size, mustrain in PHASES
    ]
    for name, codid, scale, size, mustrain in phase_specs:
        p = gpx.add_phase(cif(codid), phasename=name, histograms=[hist], fmthint="CIF")
        p.HAPvalue("Scale", scale)
        p.setSampleProfile(hist.name, "size", "isotropic", size, LGmix=1.0)
        p.setSampleProfile(hist.name, "microstrain", "isotropic", mustrain, LGmix=0.0)
        p.set_HAP_refinements({"Scale": True})
        phases.append(p)

    gpx.set_Controls("cycles", args.cycles)
    history = []

    def stage(label):
        before = cdir / f"{label}_before.gpx"
        after = cdir / f"{label}.gpx"
        gpx.save(str(before))
        gpx.refine(newfile=str(after), makeBack=False)
        ok, reason = physical(gpx)
        info = summarize(gpx, label)
        info["physical"] = {"ok": ok, "reason": reason}
        history.append(info)
        if not ok:
            raise RuntimeError(f"Unphysical refinement at {label}: {reason}")

    # Complete ordinary inventory first: background and both positive scales.
    stage("01_scales_background")

    # Common peak-location term before phase cells. Shift is held to a
    # physically bounded grid because it is nearly collinear with Zero.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stage("02_zero")

    for p in phases:
        p.set_refinements({"Cell": True})
    stage("03_cells_calibration")

    # Phase-specific broadening before the shared instrumental profile.
    for p in phases:
        p.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    stage("04_sizes")
    for p in phases:
        p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    stage("05_isotropic_mustrain")
    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    stage("06_instrument_W_X_SHL")
    hist.set_refinements({"Instrument Parameters": ["U"]})
    stage("07_instrument_U")

    gpx.save(str(out))
    (ROOT / f"{out.stem}_history.json").write_text(json.dumps(history, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
