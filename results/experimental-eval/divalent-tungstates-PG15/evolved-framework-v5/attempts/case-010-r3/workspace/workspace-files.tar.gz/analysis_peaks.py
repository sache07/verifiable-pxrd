import numpy as np
import pandas as pd
from scipy import signal, ndimage
import matplotlib.pyplot as plt

d = pd.read_csv("inputs/pattern.csv")
x = d.iloc[:, 0].to_numpy(float)
y = d.iloc[:, 1].to_numpy(float)

# A broad percentile filter follows the slowly varying counting background
# without absorbing the narrow diffraction maxima.
baseline = ndimage.percentile_filter(y, percentile=15, size=401, mode="nearest")
baseline = signal.savgol_filter(baseline, 801, 3)
net = y - baseline

peaks, props = signal.find_peaks(
    net,
    prominence=120,
    height=100,
    distance=max(1, int(0.08 / np.median(np.diff(x)))),
    width=(1, int(1.5 / np.median(np.diff(x)))),
)
widths = signal.peak_widths(net, peaks, rel_height=0.5)[0] * np.median(np.diff(x))
order = np.argsort(props["prominences"])[::-1]
print("x y baseline net prominence fwhm_deg")
for j in order:
    i = peaks[j]
    print(
        f"{x[i]:9.5f} {y[i]:9.1f} {baseline[i]:9.1f} {net[i]:9.1f} "
        f"{props['prominences'][j]:9.1f} {widths[j]:8.4f}"
    )

fig, axes = plt.subplots(2, 1, figsize=(15, 8), sharex=True)
axes[0].plot(x, y, lw=0.6, color="black")
axes[0].plot(x, baseline, lw=1, color="tab:orange")
axes[0].set_ylabel("Counts")
axes[1].plot(x, net, lw=0.6, color="black")
axes[1].scatter(x[peaks], net[peaks], s=8, color="tab:red")
axes[1].set_ylabel("Baseline-subtracted counts")
axes[1].set_xlabel(r"$2\theta$ (deg, Cu K$\alpha$)")
fig.tight_layout()
fig.savefig("observed_peaks.png", dpi=160)
