#!/usr/bin/env python3
"""Grid a fixed common isotropic U for WO3 and reoptimize active terms."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2

ap = argparse.ArgumentParser()
ap.add_argument("project")
ap.add_argument("output")
ap.add_argument("uiso", type=float)
ap.add_argument("--cycles", type=int, default=10)
args = ap.parse_args()

G2.SetPrintLevel("warn")
out = Path(args.output).resolve()
gpx = G2.G2Project(gpxfile=args.project)
gpx.save(str(out))
gpx = G2.G2Project(gpxfile=str(out))
gpx.set_Controls("cycles", args.cycles)
for atom in gpx.phase("WO3_monoclinic").atoms():
    atom.uiso = args.uiso
gpx.save(str(out))
gpx = G2.G2Project(gpxfile=str(out))
gpx.set_Controls("cycles", args.cycles)
gpx.refine(makeBack=False)
h = gpx.histogram(0)
masses = [p.data["General"]["Mass"] * p.getHAPvalues(h.name)["Scale"][0] for p in gpx.phases()]
print("RESULT Uiso", args.uiso, "Rwp", h.residuals.get("wR"),
      "fractions", [m / sum(masses) for m in masses])
