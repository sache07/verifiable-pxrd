#!/usr/bin/env python3
import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2

ap = argparse.ArgumentParser()
ap.add_argument("project")
ap.add_argument("output")
ap.add_argument("--params", default="W,X,SH/L")
ap.add_argument("--cycles", type=int, default=10)
ap.add_argument("--fix-w", type=float)
ap.add_argument("--fix-u", type=float)
ap.add_argument("--fix-polarization", type=float)
ap.add_argument("--polarization", action="store_true")
ap.add_argument("--surface", action="store_true")
args = ap.parse_args()

G2.SetPrintLevel("warn")
gpx = G2.G2Project(gpxfile=args.project)
gpx.set_Controls("cycles", args.cycles)
h = gpx.histogram(0)
if args.fix_w is not None:
    h.InstrumentParameters["W"][1] = args.fix_w
    h.InstrumentParameters["W"][2] = False
if args.fix_u is not None:
    h.InstrumentParameters["U"][1] = args.fix_u
    h.InstrumentParameters["U"][2] = False
if args.fix_polarization is not None:
    h.InstrumentParameters["Polariz."][1] = args.fix_polarization
    h.InstrumentParameters["Polariz."][2] = False
params = [p for p in args.params.split(",") if p]
if args.polarization and "Polariz." not in params:
    params.append("Polariz.")
if params:
    h.set_refinements({"Instrument Parameters": params})
if args.surface:
    h.SampleParameters["SurfRoughA"] = [0.2, True]
    h.SampleParameters["SurfRoughB"] = [0.1, True]
gpx.save(str(Path(args.output).resolve()))
gpx = G2.G2Project(gpxfile=str(Path(args.output).resolve()))
gpx.set_Controls("cycles", args.cycles)
gpx.refine(makeBack=False)
h = gpx.histogram(0)
masses = [q.data["General"]["Mass"] * q.getHAPvalues(h.name)["Scale"][0] for q in gpx.phases()]
print("RESULT Rwp", h.residuals.get("wR"),
      "instrument", {k: h.InstrumentParameters[k][1] for k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]},
      "surface", {k: h.SampleParameters[k][0] for k in ["SurfRoughA", "SurfRoughB"]},
      "fractions", [m / sum(masses) for m in masses])
