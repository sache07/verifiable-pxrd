#!/usr/bin/env python3
import argparse
from pathlib import Path

import numpy as np
from scipy import signal
from GSASII import GSASIIscriptable as G2

ap = argparse.ArgumentParser()
ap.add_argument("project")
ap.add_argument("--stem", default="gpx_diagnostic")
args = ap.parse_args()

G2.SetPrintLevel("error")
gpx = G2.G2Project(gpxfile=args.project)
h = gpx.histogram(0)
x = np.asarray(h.getdata("X"), float)
yo = np.asarray(h.getdata("Yobs"), float)
yc = np.asarray(h.getdata("Ycalc"), float)
yb = np.asarray(h.getdata("Background"), float)
dy = yo - yc

np.savetxt(
    f"{args.stem}.csv",
    np.column_stack([x, yo, yc, dy, yb]),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference,background",
    comments="",
)

peaks, props = signal.find_peaks(
    dy,
    prominence=100,
    height=80,
    distance=max(1, int(0.08 / np.median(np.diff(x)))),
)
order = np.argsort(props["prominences"])[::-1]
print("Positive residual maxima: 2theta residual prominence")
for j in order[:80]:
    i = peaks[j]
    print(f"{x[i]:10.5f} {dy[i]:10.1f} {props['prominences'][j]:10.1f}")

print("\nResiduals:", h.residuals)
masses = []
for p in gpx.phases():
    hap = p.getHAPvalues(h.name)
    masses.append(p.data["General"]["Mass"] * hap["Scale"][0])
for p, m in zip(gpx.phases(), masses):
    print(p.name, "wtfrac", m / sum(masses), "cell", p.data["General"]["Cell"][1:8])
