#!/usr/bin/env python3
"""Continue staged refinement of the accepted six-phase inventory."""

from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "branch_pb3wo6.gpx"
WORK = ROOT / "accepted_work.gpx"
CHECKPOINTS = ROOT / "checkpoints_accepted"


def fractions(project, hist):
    terms = np.array([
        phase.data["Histograms"][hist.name]["Scale"][0] * phase.data["General"]["Mass"]
        for phase in project.phases()
    ])
    return terms / terms.sum()


def report(project, tag):
    hist = project.histograms()[0]
    cov = project.data["Covariance"]["data"]
    print(f"\n[{tag}] Rwp={hist.get_wR():.6f} GOF={cov.get('Rvals', {}).get('GOF')}")
    print("fractions", dict(zip([p.name for p in project.phases()], fractions(project, hist))))
    print("instrument", {key: hist.InstrumentParameters[key] for key in
                         ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    print("sample", {key: hist.SampleParameters[key] for key in
                     ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"][:3], "strain", hap["Mustrain"][:3],
              "PO", hap["Pref.Ori."][:4])
    print("message", cov.get("Rvals", {}).get("msg"))


def checkpoint(project, tag):
    project.save(str(WORK))
    CHECKPOINTS.mkdir(exist_ok=True)
    shutil.copy2(WORK, CHECKPOINTS / f"{tag}.gpx")
    report(project, tag)


def refine(project, tag, cycles=15):
    project.set_Controls("cycles", cycles)
    project.refine()
    checkpoint(project, tag)


def set_value(parameter, value):
    parameter[1] = float(value)


def main():
    G2.SetPrintLevel("warn")
    shutil.copy2(SOURCE, WORK)
    project = G2.G2Project(str(WORK))
    hist = project.histograms()[0]

    # Reset every refinement flag inherited from exploratory branches.
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})

    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        # The low-symmetry ordered Pb3WO6 analogue is kept at its physically
        # transformed parent cell until its profile contribution is mature.
        if phase.name != "Pb3WO6_ordered":
            phase.set_refinements({"Cell": True})
    refine(project, "01_scales_background_cells", 15)

    # Alternate the highly correlated zero and specimen displacement terms.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "02_zero", 12)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "03_shift", 12)
    hist.clear_refinements({"Sample Parameters": ["Shift"]})

    # Replace the nonphysical exploratory profile by a physical instrument
    # start and allow phase-specific isotropic crystallite size to broaden it.
    set_value(hist.InstrumentParameters["U"], 10.0)
    set_value(hist.InstrumentParameters["W"], 20.0)
    set_value(hist.InstrumentParameters["X"], 2.0)
    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.20, "refine": True}})
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 1.50, variable=f"{phase.id}:0:Size;i")
    refine(project, "04_phase_sizes", 20)

    for variable, lower, upper in [
        (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0), (":0:SH/L", 0.005, 0.10),
    ]:
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "05_instrument_and_sizes", 25)

    # Add only the isotropic strain complexity supported by the laboratory model.
    for phase in project.phases():
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;i")
    refine(project, "06_isotropic_microstrain", 25)


if __name__ == "__main__":
    main()
