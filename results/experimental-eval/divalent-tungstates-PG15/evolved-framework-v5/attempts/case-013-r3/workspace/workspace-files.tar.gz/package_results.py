#!/usr/bin/env python3
"""Export all deliverables from the accepted full-grid GSAS-II checkpoint."""

import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "checkpoints_final" / "22_full_grid_converged.gpx"
FINAL = ROOT / "final.gpx"

EXPORTS = {
    "PbWO4_scheelite": ("PbWO4 (scheelite)", "PbWO4", "phase_1_PbWO4_scheelite.cif", "COD 9009811"),
    "PbO_massicot": ("PbO (massicot)", "PbO", "phase_2_PbO_massicot.cif", "COD 2310433"),
    "PbO_litharge": ("PbO (litharge)", "PbO", "phase_3_PbO_litharge.cif", "COD 9012700; origin-choice transform repaired"),
    "Pb2WO5_monoclinic": ("Pb2WO5 (monoclinic)", "Pb2WO5", "phase_4_Pb2WO5.cif", "Pb2MoO5 COD 7220560 with isovalent Mo6+ to W6+ substitution"),
    "Pb3WO6_ordered": ("Pb3WO6 (ordered model)", "Pb3WO6", "phase_5_Pb3WO6.cif", "ordered Pb analogue derived from Ba3WO6 COD 1534803"),
    "WO3_monoclinic_physical": ("WO3 (monoclinic)", "WO3", "phase_6_WO3_monoclinic.cif", "COD 2311041"),
}


def fraction_values_and_esds(project, hist):
    phases = project.phases()
    scales = np.array([p.data["Histograms"][hist.name]["Scale"][0] for p in phases])
    masses = np.array([p.data["General"]["Mass"] for p in phases])
    terms = scales * masses
    total = terms.sum()
    fractions = terms / total

    covariance = project.data["Covariance"]["data"]
    names = [str(v) for v in covariance["varyList"]]
    indices = [names.index(f"{p.id}:{hist.id}:Scale") for p in phases]
    scale_cov = np.asarray(covariance["covMatrix"])[np.ix_(indices, indices)]
    esds = []
    for i in range(len(phases)):
        gradient = np.array([
            (masses[i] * (1.0 if i == j else 0.0) * total - terms[i] * masses[j]) / total**2
            for j in range(len(phases))
        ])
        esds.append(float(np.sqrt(max(0.0, gradient @ scale_cov @ gradient))))
    return fractions, np.array(esds)


def main():
    G2.SetPrintLevel("error")
    shutil.copy2(SOURCE, FINAL)
    project = G2.G2Project(str(FINAL))
    hist = project.histograms()[0]
    phases = project.phases()
    if set(p.name for p in phases) != set(EXPORTS):
        raise RuntimeError("Unexpected phase inventory")

    fractions, fraction_esds = fraction_values_and_esds(project, hist)
    rows = []
    for phase, fraction, esd in zip(phases, fractions, fraction_esds):
        display, formula, filename, model_source = EXPORTS[phase.name]
        phase.export_CIF(str(ROOT / filename))
        rows.append({
            "name": display,
            "formula": formula,
            "cif_path": filename,
            "weight_fraction": float(fraction),
            "weight_fraction_esd_statistical": float(esd),
            "model_source": model_source,
        })

    profile = np.asarray(hist.data["data"][1], dtype=float)
    two_theta, observed, calculated = profile[0], profile[1], profile[3]
    difference = observed - calculated
    original = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if not (np.allclose(two_theta, original[:, 0], atol=1e-10, rtol=0)
            and np.allclose(observed, original[:, 1], atol=1e-10, rtol=0)):
        raise RuntimeError("Project histogram does not match the supplied pattern")
    if len(two_theta) != 8282 or np.any(calculated < 0) or not np.isfinite(profile).all():
        raise RuntimeError("Invalid exported full-grid profile")
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([two_theta, observed, calculated, difference]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.10f",
    )

    metadata = hist.data["data"][0]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "phases": rows,
        "weight_fraction_basis": "normalized over the six modeled crystalline phases; sum = 1",
        "fit_statistics": {
            "Rwp_percent": float(hist.get_wR()),
            "Rp_percent": float(metadata["R"]),
            "GOF": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "N_observations": int(rvals["Nobs"]),
            "N_variables": int(rvals["Nvars"]),
            "Durbin_Watson": float(metadata["Durbin-Watson"]),
            "converged": bool(rvals["converged"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
        },
        "refinement_histogram": hist.name,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "measurement": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelengths_angstrom": [1.540598, 1.544426],
            "kalpha2_to_kalpha1_ratio": 0.5,
            "geometry": "Bragg-Brentano reflection",
        },
        "calibration": {
            "zero_offset_deg": float(hist.InstrumentParameters["Zero"][1]),
            "sample_displacement_micrometers": float(hist.SampleParameters["Shift"][0]),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
