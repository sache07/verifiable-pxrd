#!/usr/bin/env python3
"""Create an ordered, physical Pb3WO6 model from disordered Ba3WO6."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifParser, CifWriter


SOURCE = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/53/48/1534803.cif")
OUTPUT = Path(__file__).resolve().parent / "candidate_pb3wo6.cif"

parent = CifParser(str(SOURCE), occupancy_tolerance=2).parse_structures(primitive=False)[0]

# The Ba parent contains four mutually exclusive half-occupied split sites
# (indices 4--7). Sites 4 and 7 are the ordered pair with physical cation
# separation and no Pb--O contact below 2.0 A after substitution.
keep = list(range(4)) + [4, 7] + list(range(8, len(parent)))
species = []
coords = []
for index in keep:
    site = parent[index]
    elements = {str(element) for element in site.species.elements}
    species.append("Pb" if "Ba" in elements else str(next(iter(site.species.elements))))
    coords.append(site.frac_coords)

structure = Structure(parent.lattice, species, coords)
# Pb2+ is smaller than Ba2+; this modest contraction places the principal
# residual family while preserving W--O and Pb--O geometry.
structure.scale_lattice(structure.volume * 0.975**3)
CifWriter(structure, symprec=None, write_site_properties=False).write_file(OUTPUT)
print(OUTPUT)
