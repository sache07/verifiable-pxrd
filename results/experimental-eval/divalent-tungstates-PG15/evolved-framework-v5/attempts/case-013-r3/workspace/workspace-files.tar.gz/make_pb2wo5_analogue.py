#!/usr/bin/env python3
"""Create a Pb2WO5 model from the isostructural Pb2MoO5 COD reference."""

from pathlib import Path

from pymatgen.io.cif import CifParser, CifWriter


SOURCE = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/7/22/05/7220560.cif")
OUTPUT = Path(__file__).resolve().parent / "candidate_pb2wo5.cif"

structure = CifParser(str(SOURCE)).parse_structures(primitive=False)[0]
structure.replace_species({"Mo": "W"})
CifWriter(structure, symprec=0.01, refine_struct=False, write_site_properties=False).write_file(OUTPUT)
print(OUTPUT)
