#!/usr/bin/env python3
"""Refine the physical six-phase checkpoint without boundary-only variables."""

from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "checkpoints_physical" / "15_physical_wo3_profile_cells.gpx"
WORK = ROOT / "final_work.gpx"
CHECKPOINTS = ROOT / "checkpoints_final"


def clear_all(project):
    hist = project.histograms()[0]
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]
    })
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for p in project.phases():
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        p.clear_refinements({"Atoms": [a.label for a in p.atoms()]})


def fractions(project, hist):
    values = np.array([
        p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
        for p in project.phases()
    ])
    return values / values.sum()


def report(project, tag):
    hist = project.histograms()[0]
    cov = project.data["Covariance"]["data"]
    print(f"\n[{tag}] Rwp={hist.get_wR():.8f} GOF={cov.get('Rvals', {}).get('GOF')}")
    print("fractions", dict(zip([p.name for p in project.phases()], fractions(project, hist))))
    print("varyList", cov.get("varyList", []))
    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        print(p.name, "cell", p.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"][:3], "strain", hap["Mustrain"][:3],
              "PO", hap["Pref.Ori."][:4])
    print("instrument", {k: hist.InstrumentParameters[k] for k in
                         ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    print("sample", {k: hist.SampleParameters[k] for k in
                     ["Shift", "SurfRoughA", "SurfRoughB"]})
    print("message", cov.get("Rvals", {}).get("msg"))


def main():
    G2.SetPrintLevel("warn")
    shutil.copy2(SOURCE, WORK)
    project = G2.G2Project(str(WORK))
    clear_all(project)
    hist = project.histograms()[0]

    # In GSAS-II the previous unconstrained WO3 isotropic strain crossed zero.
    # Hold its physically equivalent positive magnitude while the supported
    # profile terms are re-optimized.
    wo3 = project.phase("WO3_monoclinic_physical")
    wo3_hap = wo3.data["Histograms"][hist.name]
    wo3_hap["Mustrain"][1][0] = abs(wo3_hap["Mustrain"][1][0])
    wo3_hap["Pref.Ori."][1:4] = [0.7670222596388249, False, [0, 1, 1]]

    hist.set_refinements({"Background": True})
    # U and X have reached their physical bounds; W and axial divergence remain
    # interior and identifiable.
    hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
    for p in project.phases():
        p.set_HAP_refinements({"Scale": True})
        if p.name != "Pb3WO6_ordered":
            p.set_refinements({"Cell": True})

    # Refine only interior size/strain values; boundary values are retained but
    # not allowed to destabilize the replay.
    for name in ("PbWO4_scheelite", "WO3_monoclinic_physical"):
        project.phase(name).set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.phase("Pb2WO5_monoclinic").set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True}
    })
    for name in ("PbO_massicot", "Pb2WO5_monoclinic", "WO3_monoclinic_physical"):
        project.phase(name).set_HAP_refinements({"Pref.Ori.": True})

    for variable, lower, upper in [(":0:W", 2.0, 40.0), (":0:SH/L", 0.005, 0.10)]:
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    for p in project.phases():
        project.set_Controls("parmMin", 0.04, variable=f"{p.id}:0:Size;i")
        project.set_Controls("parmMax", 1.50, variable=f"{p.id}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{p.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{p.id}:0:Mustrain;i")
        project.set_Controls("parmMin", 0.65, variable=f"{p.id}:0:MD")
        project.set_Controls("parmMax", 1.40, variable=f"{p.id}:0:MD")

    project.set_Controls("cycles", 35)
    project.refine()
    project.save(str(WORK))
    CHECKPOINTS.mkdir(exist_ok=True)
    shutil.copy2(WORK, CHECKPOINTS / "17_physical_supported_profile.gpx")
    report(project, "17_physical_supported_profile")


if __name__ == "__main__":
    main()
