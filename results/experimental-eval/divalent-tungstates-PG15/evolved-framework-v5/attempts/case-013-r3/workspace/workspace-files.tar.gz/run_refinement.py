#!/usr/bin/env python3
"""Build and stage the three-phase GSAS-II refinement."""

from pathlib import Path
import shutil

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
WORK = ROOT / "model_work.gpx"
CHECKPOINTS = ROOT / "checkpoints"

PHASES = [
    ("9009811", "PbWO4_scheelite"),
    ("1528915", "WO3_monoclinic"),
    ("2310433", "PbO_massicot"),
]


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def background_coefficients(ncoeff=14):
    x, y = np.genfromtxt(ROOT / "inputs/pattern.csv", delimiter=",", skip_header=1).T
    # A broad lower-envelope estimate supplies a stable starting background.
    baseline = percentile_filter(y, percentile=12, size=301, mode="nearest")
    baseline = gaussian_filter1d(baseline, 80)
    xpos = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    return np.polynomial.chebyshev.chebfit(xpos, baseline, ncoeff - 1).tolist()


def phase_fractions(project, histogram):
    terms = []
    for phase in project.phases():
        scale = phase.data["Histograms"][histogram.name]["Scale"][0]
        terms.append(scale * phase.data["General"]["Mass"])
    terms = np.asarray(terms, float)
    return terms / terms.sum()


def summary(project, tag):
    hist = project.histograms()[0]
    result = hist.data["data"][0]
    print(f"\n[{tag}] wR={hist.get_wR():.6g} Rp={result.get('Rp')} GOF={result.get('GOF')}")
    print("fractions", dict(zip([p.name for p in project.phases()], phase_fractions(project, hist))))
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    print("sample", {k: hist.SampleParameters.get(k) for k in
                     ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"][:3], "mustrain", hap["Mustrain"][:3],
              "PO", hap["Pref.Ori."][:4])


def checkpoint(project, tag):
    project.save(str(WORK))
    CHECKPOINTS.mkdir(exist_ok=True)
    shutil.copy2(WORK, CHECKPOINTS / f"{tag}.gpx")
    summary(project, tag)


def refine(project, tag, cycles=8):
    project.set_Controls("cycles", cycles)
    project.refine()
    checkpoint(project, tag)


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(WORK))
    phases = [project.add_phase(str(cod_path(cid)), phasename=name, fmthint="CIF")
              for cid, name in PHASES]
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"), str(ROOT / "instrument.instprm"), phases=phases
    )
    hist.SampleParameters["Scale"][1] = False
    hist.set_refinements({
        "Limits": [10.05, 99.95],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 14,
            "coeffs": background_coefficients(14),
            "refine": True,
        },
    })
    # The observed families are displaced about +0.2 to +0.3 degrees.
    hist.InstrumentParameters["Zero"][:2] = [0.25, 0.25]
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    refine(project, "stage1_background_scales", 10)

    # Per-phase cells absorb source-to-specimen reference mismatch; refine the
    # common zero only after every phase has a stable positive scale.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "stage2_cells_zero", 12)

    # Bragg-Brentano specimen displacement has a distinct cos(theta) signature.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "stage3_displacement", 12)

    # Instrument terms represented in the stated measurement model.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "stage4_instrument_profile", 15)


if __name__ == "__main__":
    main()
