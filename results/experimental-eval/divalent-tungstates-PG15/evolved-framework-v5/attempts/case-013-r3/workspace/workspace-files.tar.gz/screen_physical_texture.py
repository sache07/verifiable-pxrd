#!/usr/bin/env python3
"""Screen one March-Dollase axis for the physical monoclinic WO3 model."""

import json
from pathlib import Path
import shutil
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "checkpoints_physical" / "15_physical_wo3_profile_cells.gpx"


def clear_all(project):
    hist = project.histograms()[0]
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]
    })
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for p in project.phases():
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        p.clear_refinements({"Atoms": [a.label for a in p.atoms()]})


def main():
    G2.SetPrintLevel("error")
    axis = [int(v) for v in sys.argv[1:4]]
    label = "_".join("m" + str(-v) if v < 0 else str(v) for v in axis)
    outdir = ROOT / "physical_texture_screen"
    outdir.mkdir(exist_ok=True)
    branch = outdir / f"axis_{label}.gpx"
    shutil.copy2(BASE, branch)
    project = G2.G2Project(str(branch))
    clear_all(project)
    phase = project.phase("WO3_monoclinic_physical")
    hist = project.histograms()[0]
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[1], po[3] = 1.0, axis
    phase.set_HAP_refinements({"Pref.Ori.": True})
    project.set_Controls("parmMin", 0.65, variable=f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 1.40, variable=f"{phase.id}:0:MD")
    project.set_Controls("cycles", 15)
    project.refine()
    project.save()
    payload = {"axis": axis, "ratio": po[1], "Rwp": hist.get_wR(), "gpx": str(branch)}
    (outdir / f"axis_{label}.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload))


if __name__ == "__main__":
    main()
