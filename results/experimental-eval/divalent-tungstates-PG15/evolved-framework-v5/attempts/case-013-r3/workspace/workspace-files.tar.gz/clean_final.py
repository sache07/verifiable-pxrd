#!/usr/bin/env python3
"""Remove stale exploratory freezes and converge the accepted physical model."""

from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "checkpoints_final" / "19_clean_converged.gpx"
WORK = ROOT / "final_candidate.gpx"
CHECKPOINT = ROOT / "checkpoints_final" / "20_clean_converged.gpx"


def main():
    G2.SetPrintLevel("warn")
    shutil.copy2(SOURCE, WORK)
    project = G2.G2Project(str(WORK))
    # The old list refers to boundary trials whose flags are no longer active.
    # Removing it makes the submitted replay self-contained and transparent.
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 30)
    project.refine()
    project.save(str(WORK))
    shutil.copy2(WORK, CHECKPOINT)
    hist = project.histograms()[0]
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    print({
        "Rwp": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "chisq": rvals.get("chisq"),
        "Nobs": rvals.get("Nobs"),
        "Nvars": rvals.get("Nvars"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "message": rvals.get("msg"),
    })


if __name__ == "__main__":
    main()
