#!/usr/bin/env python3
"""Converge the accepted model over every supplied pattern point."""

from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "checkpoints_final" / "21_full_grid.gpx"
WORK = ROOT / "full_grid_candidate.gpx"
CHECKPOINT = ROOT / "checkpoints_final" / "22_full_grid_converged.gpx"


def main():
    G2.SetPrintLevel("warn")
    shutil.copy2(SOURCE, WORK)
    project = G2.G2Project(str(WORK))
    hist = project.histograms()[0]
    outer = hist.data["Limits"][0]
    hist.data["Limits"][1] = [float(outer[0]), float(outer[1])]
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 30)
    project.refine()
    project.save(str(WORK))
    shutil.copy2(WORK, CHECKPOINT)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    calc = hist.data["data"][1][3]
    print({
        "Rwp": hist.get_wR(), "Rp": hist.data["data"][0].get("R"),
        "GOF": rvals.get("GOF"), "Nobs": rvals.get("Nobs"),
        "Nvars": rvals.get("Nvars"), "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "message": rvals.get("msg"), "limits": hist.data["Limits"],
        "nonzero_calculated_points": int((calc != 0).sum()),
    })


if __name__ == "__main__":
    main()
