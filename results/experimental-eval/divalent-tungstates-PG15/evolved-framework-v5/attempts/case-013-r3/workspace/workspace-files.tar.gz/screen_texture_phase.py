#!/usr/bin/env python3
"""Screen the allowed March-Dollase axes for one accepted phase."""

import json
from pathlib import Path
import shutil
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "calib_both.gpx"
AXES = [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]


def clear_all(project):
    hist = project.histograms()[0]
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})


def main():
    G2.SetPrintLevel("error")
    phase_index = int(sys.argv[1])
    outdir = ROOT / "texture_screen" / f"phase_{phase_index}"
    outdir.mkdir(parents=True, exist_ok=True)
    results = []
    for axis in AXES:
        label = "".join(str(v) for v in axis)
        branch = outdir / f"axis_{label}.gpx"
        shutil.copy2(BASE, branch)
        project = G2.G2Project(str(branch))
        clear_all(project)
        hist = project.histograms()[0]
        phase = project.phases()[phase_index]
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[1] = 1.0
        po[3] = axis
        phase.set_HAP_refinements({"Pref.Ori.": True})
        project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")
        project.set_Controls("cycles", 10)
        project.refine()
        project.save()
        hist = project.histograms()[0]
        phase = project.phases()[phase_index]
        ratio = phase.data["Histograms"][hist.name]["Pref.Ori."][1]
        results.append({"axis": axis, "ratio": ratio, "Rwp": hist.get_wR(), "path": str(branch)})
    payload = {"phase_index": phase_index, "phase": project.phases()[phase_index].name,
               "base_Rwp": G2.G2Project(str(BASE)).histograms()[0].get_wR(), "results": results}
    (outdir / "results.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload))


if __name__ == "__main__":
    main()
