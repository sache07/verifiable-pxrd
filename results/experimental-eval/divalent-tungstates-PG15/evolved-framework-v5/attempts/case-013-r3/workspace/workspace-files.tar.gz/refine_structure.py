#!/usr/bin/env python3
"""Apply supported texture and staged coordinate refinement."""

from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "calib_both.gpx"
WORK = ROOT / "structure_work.gpx"
CHECKPOINTS = ROOT / "checkpoints_structure"


def mass_fractions(project, hist):
    values = np.array([
        phase.data["Histograms"][hist.name]["Scale"][0] * phase.data["General"]["Mass"]
        for phase in project.phases()
    ])
    return values / values.sum()


def report(project, tag):
    hist = project.histograms()[0]
    cov = project.data["Covariance"]["data"]
    print(f"\n[{tag}] Rwp={hist.get_wR():.6f} GOF={cov.get('Rvals', {}).get('GOF')}")
    print("fractions", dict(zip([p.name for p in project.phases()], mass_fractions(project, hist))))
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"][:3], "strain", hap["Mustrain"][:3],
              "PO", hap["Pref.Ori."][:4],
              "atoms", [(a.label, a.element, a.refinement_flags) for a in phase.atoms()])
    print("instrument", {key: hist.InstrumentParameters[key] for key in
                         ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    print("sample", {key: hist.SampleParameters[key] for key in
                     ["Shift", "SurfRoughA", "SurfRoughB"]})
    print("message", cov.get("Rvals", {}).get("msg"))


def checkpoint(project, tag):
    project.save(str(WORK))
    CHECKPOINTS.mkdir(exist_ok=True)
    shutil.copy2(WORK, CHECKPOINTS / f"{tag}.gpx")
    report(project, tag)


def refine(project, tag, cycles=20):
    project.set_Controls("cycles", cycles)
    project.refine()
    checkpoint(project, tag)


def main():
    G2.SetPrintLevel("warn")
    shutil.copy2(SOURCE, WORK)
    project = G2.G2Project(str(WORK))
    hist = project.histograms()[0]

    # Restore the supported profile/cell flags around the calibrated checkpoint.
    hist.set_refinements({"Background": True})
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Scale": True,
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
        if phase.name != "Pb3WO6_ordered":
            phase.set_refinements({"Cell": True})

    # Only axes with a clear single-phase checkpoint improvement are retained.
    texture = {
        "WO3_monoclinic": ([1, 1, 0], 0.77534),
        "PbO_massicot": ([1, 1, 1], 0.71542),
        "Pb2WO5_monoclinic": ([1, 0, 0], 1.15597),
    }
    for phase in project.phases():
        if phase.name not in texture:
            continue
        axis, ratio = texture[phase.name]
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[1] = ratio
        po[3] = axis
        phase.set_HAP_refinements({"Pref.Ori.": True})
        project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")
    refine(project, "07_supported_texture", 25)

    # Heavy-atom coordinates first. Pb3WO6 is too minor and too low-symmetry
    # for unconstrained P1 coordinate refinement, so its ordered parent is held.
    for phase in project.phases()[:5]:
        heavy = {atom.label: "X" for atom in phase.atoms() if atom.element != "O"}
        if heavy:
            phase.set_refinements({"Atoms": heavy})
    refine(project, "08_heavy_coordinates", 25)


if __name__ == "__main__":
    main()
