#!/usr/bin/env python3
"""Repair the litharge origin transform and refine the accepted inventory."""

from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIspc as G2spc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "checkpoints_structure" / "08_heavy_coordinates.gpx"
WORK = ROOT / "repaired_work.gpx"
CHECKPOINTS = ROOT / "checkpoints_repaired"


def clear_all(project):
    hist = project.histograms()[0]
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]
    })
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True
        })
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})


def fractions(project, hist):
    terms = np.array([
        phase.data["Histograms"][hist.name]["Scale"][0] * phase.data["General"]["Mass"]
        for phase in project.phases()
    ])
    return terms / terms.sum()


def report(project, tag):
    hist = project.histograms()[0]
    cov = project.data["Covariance"]["data"]
    print(f"\n[{tag}] Rwp={hist.get_wR():.8f} GOF={cov.get('Rvals', {}).get('GOF')}")
    print("fractions", dict(zip([p.name for p in project.phases()], fractions(project, hist))))
    for phase in project.phases():
        general = phase.data["General"]
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "mass", general["Mass"], "composition", general.get("NoAtoms"),
              "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"][:3], "strain", hap["Mustrain"][:3],
              "PO", hap["Pref.Ori."][:4])
    print("instrument", {key: hist.InstrumentParameters[key] for key in
                         ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    print("sample", {key: hist.SampleParameters[key] for key in
                     ["Shift", "SurfRoughA", "SurfRoughB"]})
    print("message", cov.get("Rvals", {}).get("msg"))


def checkpoint(project, tag):
    project.save(str(WORK))
    CHECKPOINTS.mkdir(exist_ok=True)
    shutil.copy2(WORK, CHECKPOINTS / f"{tag}.gpx")
    report(project, tag)


def refine(project, tag, cycles=25):
    project.set_Controls("cycles", cycles)
    project.refine()
    checkpoint(project, tag)


def repair_litharge(project):
    phase = next(p for p in project.phases() if p.name == "PbO_litharge")
    atoms = {atom[0]: atom for atom in phase.data["Atoms"]}
    # COD 9012700 is P4/nmm origin choice 1. In origin choice 2 its sites are
    # Pb 2c (1/4,1/4,z) and O 2a (1/4,3/4,0). The stock importer applied the
    # wrong x-origin sign to Pb, spuriously changing its multiplicity 2 -> 4.
    atoms["Pb"][3:6] = [0.25, 0.25, 0.23510]
    atoms["O"][3:6] = [0.25, 0.75, 0.0]
    G2spc.UpdateSytSym(phase.data)
    G2.SetupGeneral(phase.data, str(ROOT))
    assert phase.data["General"]["NoAtoms"] == {"Pb": 2.0, "O": 2.0}


def main():
    G2.SetPrintLevel("warn")
    shutil.copy2(SOURCE, WORK)
    project = G2.G2Project(str(WORK))
    clear_all(project)
    repair_litharge(project)
    checkpoint(project, "09_litharge_repaired_unrefined")

    hist = project.histograms()[0]
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    refine(project, "10_repaired_scales_background", 20)

    # Re-optimize all previously supported profile, cell and texture terms.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
        if phase.name != "Pb3WO6_ordered":
            phase.set_refinements({"Cell": True})
    for name in ("WO3_monoclinic", "PbO_massicot", "Pb2WO5_monoclinic"):
        next(p for p in project.phases() if p.name == name).set_HAP_refinements({"Pref.Ori.": True})
    refine(project, "11_repaired_profile_cells_texture", 30)

    # Heavy-atom coordinates are the only supported coordinate complexity.
    for phase in project.phases()[:5]:
        heavy = {atom.label: "X" for atom in phase.atoms() if atom.element != "O"}
        if heavy:
            phase.set_refinements({"Atoms": heavy})
    refine(project, "12_repaired_heavy_coordinates", 30)


if __name__ == "__main__":
    main()
