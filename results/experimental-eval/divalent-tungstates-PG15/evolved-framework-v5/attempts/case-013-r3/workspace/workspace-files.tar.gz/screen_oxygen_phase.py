#!/usr/bin/env python3
"""Refine oxygen coordinates for one phase with all other terms held."""

import json
from pathlib import Path
import shutil
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "checkpoints_structure/08_heavy_coordinates.gpx"


def clear_all(project):
    hist = project.histograms()[0]
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})


def main():
    G2.SetPrintLevel("error")
    phase_index = int(sys.argv[1])
    outdir = ROOT / "oxygen_screen"
    outdir.mkdir(exist_ok=True)
    branch = outdir / f"phase_{phase_index}.gpx"
    shutil.copy2(BASE, branch)
    project = G2.G2Project(str(branch))
    clear_all(project)
    phase = project.phases()[phase_index]
    oxygens = {atom.label: "X" for atom in phase.atoms() if atom.element == "O"}
    phase.set_refinements({"Atoms": oxygens})
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    phase = project.phases()[phase_index]
    hist = project.histograms()[0]
    cif = outdir / f"phase_{phase_index}.cif"
    phase.export_CIF(str(cif))
    payload = {
        "phase_index": phase_index,
        "phase": phase.name,
        "Rwp": hist.get_wR(),
        "varyList": project.data["Covariance"]["data"].get("varyList", []),
        "atoms": [{"label": a.label, "element": a.element, "coordinates": list(a.coordinates),
                   "flags": a.refinement_flags} for a in phase.atoms()],
        "gpx": str(branch),
        "cif": str(cif),
    }
    (outdir / f"phase_{phase_index}.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload))


if __name__ == "__main__":
    main()
