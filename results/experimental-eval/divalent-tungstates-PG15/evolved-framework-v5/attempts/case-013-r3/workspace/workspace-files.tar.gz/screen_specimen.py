#!/usr/bin/env python3
"""Screen one supported calibration/specimen term from the physical checkpoint."""

import json
from pathlib import Path
import shutil
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "checkpoints_final" / "17_physical_supported_profile.gpx"


def clear_all(project):
    hist = project.histograms()[0]
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]
    })
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for p in project.phases():
        p.clear_refinements({"Cell": True})
        p.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        p.clear_refinements({"Atoms": [a.label for a in p.atoms()]})


def main():
    G2.SetPrintLevel("error")
    mode = sys.argv[1]
    outdir = ROOT / "specimen_screen"
    outdir.mkdir(exist_ok=True)
    branch = outdir / f"{mode}.gpx"
    shutil.copy2(BASE, branch)
    project = G2.G2Project(str(branch))
    clear_all(project)
    hist = project.histograms()[0]

    if mode == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        project.set_Controls("parmMin", -0.08, variable=":0:Zero")
        project.set_Controls("parmMax", 0.08, variable=":0:Zero")
    elif mode == "shift":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        project.set_Controls("parmMin", -600.0, variable=":0:Shift")
        project.set_Controls("parmMax", 600.0, variable=":0:Shift")
    elif mode == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif mode == "roughness":
        hist.SampleParameters["SurfRoughA"][0] = 0.10
        hist.SampleParameters["SurfRoughB"][0] = 0.10
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        project.set_Controls("parmMin", 0.01, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.80, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.01, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.80, variable=":0:SurfRoughB")
    else:
        raise ValueError(mode)

    project.set_Controls("cycles", 20)
    project.refine()
    project.save()
    payload = {
        "mode": mode,
        "Rwp": hist.get_wR(),
        "zero": hist.InstrumentParameters["Zero"],
        "shift": hist.SampleParameters["Shift"],
        "polarization": hist.InstrumentParameters["Polariz."],
        "roughness_A": hist.SampleParameters["SurfRoughA"],
        "roughness_B": hist.SampleParameters["SurfRoughB"],
        "message": project.data["Covariance"]["data"].get("Rvals", {}).get("msg"),
        "gpx": str(branch),
    }
    (outdir / f"{mode}.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload))


if __name__ == "__main__":
    main()
