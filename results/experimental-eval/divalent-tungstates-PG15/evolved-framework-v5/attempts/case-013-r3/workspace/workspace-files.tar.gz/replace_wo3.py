#!/usr/bin/env python3
"""Replace the geometrically defective WO3 reference by physical COD 2311041."""

from copy import deepcopy
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "checkpoints_repaired" / "12_repaired_heavy_coordinates.gpx"
WO3_CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/") / \
    "cod-filtered-2024/cif/2/31/10/2311041.cif"
WORK = ROOT / "physical_work.gpx"
CHECKPOINTS = ROOT / "checkpoints_physical"


def clear_all(project):
    hist = project.histograms()[0]
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]
    })
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True
        })
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})


def fractions(project, hist):
    terms = np.array([
        p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
        for p in project.phases()
    ])
    return terms / terms.sum()


def report(project, tag):
    hist = project.histograms()[0]
    cov = project.data["Covariance"]["data"]
    print(f"\n[{tag}] Rwp={hist.get_wR():.8f} GOF={cov.get('Rvals', {}).get('GOF')}")
    print("fractions", dict(zip([p.name for p in project.phases()], fractions(project, hist))))
    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        print(p.name, "mass", p.data["General"]["Mass"], "cell", p.get_cell(),
              "scale", hap["Scale"], "size", hap["Size"][:3],
              "strain", hap["Mustrain"][:3], "PO", hap["Pref.Ori."][:4])
    print("instrument", {k: hist.InstrumentParameters[k] for k in
                         ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    print("sample", {k: hist.SampleParameters[k] for k in
                     ["Shift", "SurfRoughA", "SurfRoughB"]})
    print("message", cov.get("Rvals", {}).get("msg"))


def checkpoint(project, tag):
    project.save(str(WORK))
    CHECKPOINTS.mkdir(exist_ok=True)
    shutil.copy2(WORK, CHECKPOINTS / f"{tag}.gpx")
    report(project, tag)


def refine(project, tag, cycles=25):
    project.set_Controls("cycles", cycles)
    project.refine()
    checkpoint(project, tag)


def replace_wo3(project):
    hist = project.histograms()[0]
    old_name = "WO3_monoclinic"
    old = project.phase(old_name)
    old_hap = deepcopy(old.data["Histograms"][hist.name])
    new = project.add_phase(
        str(WO3_CIF), phasename="WO3_monoclinic_physical", histograms=[hist], fmthint="CIF"
    )
    new.data["Histograms"][hist.name] = old_hap
    # The March-Dollase axis from the defective cell setting is not transferable.
    new.data["Histograms"][hist.name]["Pref.Ori."][1:4] = [1.0, False, [0, 1, 0]]

    del project.data["Phases"][old_name]
    for item in project.names:
        if item and item[0] == "Phases":
            item.remove(old_name)
            break
    hist.data["Reflection Lists"].pop(old_name, None)
    project.update_ids()
    clear_all(project)


def set_bounds(project):
    for variable, lower, upper in [
        (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0), (":0:SH/L", 0.005, 0.10),
    ]:
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    for p in project.phases():
        project.set_Controls("parmMin", 0.04, variable=f"{p.id}:0:Size;i")
        project.set_Controls("parmMax", 1.50, variable=f"{p.id}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{p.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{p.id}:0:Mustrain;i")
    for p in project.phases():
        if p.name in ("PbO_massicot", "Pb2WO5_monoclinic"):
            project.set_Controls("parmMin", 0.65, variable=f"{p.id}:0:MD")
            project.set_Controls("parmMax", 1.40, variable=f"{p.id}:0:MD")


def main():
    G2.SetPrintLevel("warn")
    shutil.copy2(SOURCE, WORK)
    project = G2.G2Project(str(WORK))
    replace_wo3(project)
    set_bounds(project)
    checkpoint(project, "13_physical_wo3_unrefined")

    hist = project.histograms()[0]
    hist.set_refinements({"Background": True})
    for p in project.phases():
        p.set_HAP_refinements({"Scale": True})
    refine(project, "14_physical_wo3_scales_background", 20)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for p in project.phases():
        p.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
        if p.name != "Pb3WO6_ordered":
            p.set_refinements({"Cell": True})
        if p.name in ("PbO_massicot", "Pb2WO5_monoclinic"):
            p.set_HAP_refinements({"Pref.Ori.": True})
    refine(project, "15_physical_wo3_profile_cells", 30)

    wo3 = project.phase("WO3_monoclinic_physical")
    wo3.set_refinements({"Atoms": {a.label: "X" for a in wo3.atoms() if a.element == "W"}})
    refine(project, "16_physical_wo3_heavy_coordinates", 25)


if __name__ == "__main__":
    main()
