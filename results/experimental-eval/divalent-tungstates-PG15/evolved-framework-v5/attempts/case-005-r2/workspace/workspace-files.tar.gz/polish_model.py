#!/usr/bin/env python3
"""Polish a physically screened coordinate checkpoint with bounded profile terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import metrics


def bound(project: G2.G2Project, var: str, lo: float, hi: float) -> None:
    project.set_Controls("parmMin", lo, variable=var)
    project.set_Controls("parmMax", hi, variable=var)


def collect(project: G2.G2Project, label: str) -> dict:
    out = metrics(project)
    out["step"] = label
    hist = project.histogram(0)
    out["profiles"] = {}
    out["atoms"] = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["profiles"][phase.name] = {
            "size": hap["Size"],
            "microstrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
        out["atoms"][phase.name] = [
            {"label": a.label, "element": a.element, "xyz": list(a.coordinates), "uiso": a.uiso}
            for a in phase.atoms()
        ]
    return out


def refine_twice(project: G2.G2Project) -> None:
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    project.set_Controls("cycles", 6)
    project.refine(makeBack=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--wo3-uiso", type=float)
    parser.add_argument("--co3o4-uiso", type=float)
    parser.add_argument("--anisotropic-phase", choices=["WO3", "Co3O4"])
    parser.add_argument("--anisotropic-axis", nargs=3, type=int, default=[0, 0, 1])
    parser.add_argument("--keep-anisotropy", action="store_true")
    parser.add_argument("--texture-phase", choices=["WO3", "Co3O4"])
    parser.add_argument("--texture-axis", nargs=3, type=int, default=[0, 0, 1])
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(Path(args.input).resolve()), newgpx=str(outdir / "polished.gpx"))
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()

    # Coordinates passed the previous physical screen and are now held fixed.
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = " "
            if "WO3" in phase.name and args.wo3_uiso is not None:
                atom.uiso = args.wo3_uiso
            if "Co3O4" in phase.name and args.co3o4_uiso is not None:
                atom.uiso = args.co3o4_uiso

    inst = hist.data["Instrument Parameters"][0]
    for name in ("U", "W", "X", "SH/L"):
        inst[name][2] = True
    inst["V"][1] = 0.0
    inst["V"][2] = False
    bound(project, ":0:U", 0.0, 40.0)
    bound(project, ":0:W", 2.0, 40.0)
    bound(project, ":0:X", 0.1, 6.0)
    bound(project, ":0:SH/L", 0.005, 0.10)
    bound(project, ":0:Shift", -800.0, 800.0)

    for i, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][2][0] = True
        if args.keep_anisotropy and hap["Mustrain"][0] == "uniaxial":
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][1] = True
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2][0] = True
            if len(hap["Mustrain"][2]) > 1:
                hap["Mustrain"][2][1] = False
        hap["Pref.Ori."][2] = False
        bound(project, f"{i}:0:Size;i", 0.04, 1.50)
        bound(project, f"{i}:0:Mustrain;i", 0.0, 8000.0)
        bound(project, f"{i}:0:Mustrain;a", 0.0, 8000.0)
        bound(project, f"{i}:0:MD", 0.70, 1.40)

    refine_twice(project)
    history = [collect(project, "01_isotropic_polish")]
    project.save(outdir / "01_isotropic_polish.gpx")

    if args.anisotropic_phase:
        for i, phase in enumerate(phases):
            if args.anisotropic_phase in phase.name:
                hap = phase.data["Histograms"][hist.name]
                current = max(0.0, float(hap["Mustrain"][1][0]))
                hap["Mustrain"][0] = "uniaxial"
                hap["Mustrain"][1][0] = current
                hap["Mustrain"][1][1] = max(current, 300.0)
                hap["Mustrain"][2][0] = True
                hap["Mustrain"][2][1] = True
                hap["Mustrain"][3] = list(args.anisotropic_axis)
        project.set_Frozen()
        refine_twice(project)
        history.append(collect(project, "02_anisotropic_strain"))
        project.save(outdir / "02_anisotropic_strain.gpx")

    if args.texture_phase:
        for i, phase in enumerate(phases):
            if args.texture_phase in phase.name:
                hap = phase.data["Histograms"][hist.name]
                hap["Pref.Ori."][0] = "MD"
                hap["Pref.Ori."][1] = 1.0
                hap["Pref.Ori."][2] = True
                hap["Pref.Ori."][3] = list(args.texture_axis)
        project.set_Frozen()
        refine_twice(project)
        history.append(collect(project, "03_texture"))
        project.save(outdir / "03_texture.gpx")

    for phase in phases:
        phase.export_CIF(str(outdir / f"{phase.name}.cif"))
    project.save(outdir / "polished.gpx")
    (outdir / "summary.json").write_text(json.dumps({"steps": history}, indent=2, default=str) + "\n")
    print(json.dumps(history[-1], default=str))


if __name__ == "__main__":
    main()
