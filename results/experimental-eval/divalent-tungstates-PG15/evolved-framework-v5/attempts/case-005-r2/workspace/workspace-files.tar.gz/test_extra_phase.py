#!/usr/bin/env python3
"""Test a proposed residual phase with positive-scale and family-support checks."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import metrics


def snap(project: G2.G2Project, label: str) -> dict:
    out = metrics(project)
    out["step"] = label
    hist = project.histogram(0)
    out["raw_scales"] = {
        phase.name: phase.data["Histograms"][hist.name]["Scale"] for phase in project.phases()
    }
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--cif", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(Path(args.input).resolve()), newgpx=str(outdir / "extra.gpx"))
    project.set_Frozen()
    hist = project.histogram(0)
    phase = project.add_phase(str(Path(args.cif).resolve()), phasename=args.name, histograms=[hist], fmthint="CIF")
    phase.HAPvalue("Scale", 0.01)
    phase.set_HAP_refinements({"Scale": True})
    phase.setSampleProfile(hist.name, "size", "isotropic", 0.30)
    phase.setSampleProfile(hist.name, "microstrain", "isotropic", 1000.0)
    pidx = len(project.phases()) - 1
    project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Scale")
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    project.set_Controls("cycles", 5)
    project.refine(makeBack=False)
    history = [snap(project, "01_positive_scale")]
    project.save(outdir / "01_positive_scale.gpx")

    fraction = history[-1]["phase_fractions"][args.name]
    if fraction > 0.001:
        phase.set_refinements({"Cell": True})
        project.set_Controls("cycles", 10)
        project.refine(makeBack=False)
        history.append(snap(project, "02_cell"))
        project.save(outdir / "02_cell.gpx")
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        project.set_Controls("parmMin", 0.04, variable=f"{pidx}:0:Size;i")
        project.set_Controls("parmMax", 1.50, variable=f"{pidx}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pidx}:0:Mustrain;i")
        project.set_Frozen()
        project.set_Controls("cycles", 10)
        project.refine(makeBack=False)
        history.append(snap(project, "03_profile"))
        project.save(outdir / "03_profile.gpx")

    project.save(outdir / "extra.gpx")
    (outdir / "summary.json").write_text(json.dumps({"steps": history}, indent=2, default=str) + "\n")
    print(json.dumps(history[-1], default=str))


if __name__ == "__main__":
    main()
