#!/usr/bin/env python3
"""Refine coordinates in heavy-then-light stages and preserve checkpoints."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import metrics


def snapshot(project: G2.G2Project, outdir: Path, label: str) -> dict:
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    result = metrics(project)
    result["step"] = label
    result["atoms"] = {}
    for phase in project.phases():
        result["atoms"][phase.name] = [
            {
                "label": atom.label,
                "element": atom.element,
                "xyz": list(atom.coordinates),
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ]
        phase.export_CIF(str(outdir / f"{label}_{phase.name}.cif"))
    project.save(outdir / f"{label}.gpx")
    print(json.dumps(result, default=str))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(Path(args.input).resolve()), newgpx=str(outdir / "coordinates.gpx"))
    hist = project.histogram(0)
    phases = project.phases()

    # Hold broadening and calibration at the accepted physical checkpoint while
    # coordinates are introduced. Scales/background/cells continue to adjust.
    for name in ("U", "V", "W", "X", "SH/L"):
        hist.data["Instrument Parameters"][0][name][2] = False
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False

    history = []
    # Heavy coordinates: only general-position W in WO3. Co sites in spinel are
    # symmetry-fixed and are deliberately not released.
    for phase in phases:
        heavy = {atom.label: "X" for atom in phase.atoms() if atom.element == "W"}
        if heavy:
            phase.set_refinements({"Atoms": heavy})
    history.append(snapshot(project, outdir, "01_heavy_W"))

    # Add oxygen coordinates in both structures; GSAS-II applies site-symmetry
    # constraints, so spinel O retains its single positional degree of freedom.
    for phase in phases:
        oxygen = {atom.label: "X" for atom in phase.atoms() if atom.element == "O"}
        if oxygen:
            phase.set_refinements({"Atoms": oxygen})
    history.append(snapshot(project, outdir, "02_with_O"))

    project.save(outdir / "coordinates.gpx")
    (outdir / "summary.json").write_text(json.dumps({"steps": history}, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
