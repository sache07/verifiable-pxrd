#!/usr/bin/env python3
"""Test a bounded oxygen-coordinate start from the accepted heavy-atom checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import metrics


WO3_SOURCE = {
    "O6": (0.714, 0.487, 0.721),
    "O2": (0.225, 0.474, 0.007),
    "W1": (0.028, 0.037, 0.746),
    "O5": (0.716, 0.043, 0.708),
    "O3": (0.998, 0.262, 0.712),
    "O1": (0.206, 0.042, 0.995),
    "W2": (0.534, 0.023, 0.750),
    "O4": (0.519, 0.259, 0.789),
}
CO3O4_SOURCE = {"Co1": (0.125, 0.125, 0.125), "Co2": (0.5, 0.5, 0.5), "O": (0.2632, 0.2632, 0.2632)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--source", help="project supplying the unperturbed coordinate centers")
    parser.add_argument("--out", required=True)
    parser.add_argument("--delta", required=True, type=float, help="symmetric fractional-coordinate bound")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(Path(args.input).resolve()), newgpx=str(outdir / "bounded.gpx"))
    project.set_Frozen()
    phases = project.phases()

    source_by_phase = {}
    if args.source:
        source_project = G2.G2Project(str(Path(args.source).resolve()))
        for phase in source_project.phases():
            source_by_phase[phase.name] = {atom.label: tuple(atom.coordinates) for atom in phase.atoms()}

    for pidx, phase in enumerate(phases):
        source = source_by_phase.get(phase.name)
        if source is None:
            source = WO3_SOURCE if "WO3" in phase.name else CO3O4_SOURCE
        oxygen = {atom.label: "X" for atom in phase.atoms() if atom.element == "O"}
        if oxygen:
            phase.set_refinements({"Atoms": oxygen})
        for aidx, atom in enumerate(phase.atoms()):
            if atom.label not in source or atom.element not in ("W", "O"):
                continue
            for axis, value in zip("xyz", source[atom.label]):
                variable = f"{pidx}::dA{axis}:{aidx}"
                project.set_Controls("parmMin", value - args.delta, variable=variable)
                project.set_Controls("parmMax", value + args.delta, variable=variable)

    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    # GSAS-II clamps and freezes an out-of-bounds variable at the end of a
    # refinement. Recalculate/refine once more with those bounded values active.
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    result = metrics(project)
    result["delta"] = args.delta
    result["frozen"] = project.get_Frozen()
    result["atoms"] = {}
    for phase in phases:
        result["atoms"][phase.name] = [
            {"label": atom.label, "element": atom.element, "xyz": list(atom.coordinates)}
            for atom in phase.atoms()
        ]
        phase.export_CIF(str(outdir / f"{phase.name}.cif"))
    project.save(outdir / "bounded.gpx")
    (outdir / "summary.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, default=str))


if __name__ == "__main__":
    main()
