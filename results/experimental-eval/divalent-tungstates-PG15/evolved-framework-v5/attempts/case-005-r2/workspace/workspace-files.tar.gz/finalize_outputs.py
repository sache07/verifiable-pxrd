#!/usr/bin/env python3
"""Create the final replayable GSAS-II project and all requested deliverables."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE_PROJECT = Path(".tmp/uiso-co-0.006/uiso.gpx").resolve()
FINAL_PROJECT = Path("final.gpx").resolve()


def clean(value):
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    return value


G2.SetPrintLevel("warn")
project = G2.G2Project(str(SOURCE_PROJECT), newgpx=str(FINAL_PROJECT))
project.set_Frozen()
hist = project.histogram(0)
x = np.asarray(hist.data["data"][1][0], dtype=float)

# Submit a full-grid checkpoint. Atomic coordinates and common Uiso values have
# already passed the physical screen and are held fixed for this final nuisance polish.
hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = " "
project.set_Controls("cycles", 8)
project.refine(makeBack=False)
project.set_Controls("cycles", 5)
project.refine(makeBack=False)
project.save(FINAL_PROJECT)

# Reload exactly what was saved before exporting and reporting.
project = G2.G2Project(str(FINAL_PROJECT))
hist = project.histogram(0)
data = hist.data["data"][1]
x = np.asarray(data[0], dtype=float)
yobs = np.asarray(data[1], dtype=float)
weight = np.asarray(data[2], dtype=float)
ycalc = np.asarray(data[3], dtype=float)
background = np.asarray(data[4], dtype=float)
diff = yobs - ycalc
if not (np.isfinite(ycalc).all() and np.min(ycalc) >= 0):
    raise RuntimeError("final calculated profile is nonfinite or negative")

chi2 = float(np.sum(weight * diff**2))
denom = float(np.sum(weight * yobs**2))
rwp = 100.0 * math.sqrt(chi2 / denom)
rp = 100.0 * float(np.sum(np.abs(diff)) / np.sum(np.abs(yobs)))
nvar = len(project.data.get("Covariance", {}).get("data", {}).get("varyList", []))
dof = max(1, len(x) - nvar)
reduced_chi2 = chi2 / dof
gof = math.sqrt(reduced_chi2)

np.savetxt(
    "fit.csv",
    np.column_stack([x, yobs, ycalc, diff, background]),
    delimiter=",",
    header="two_theta,observed,calculated,difference,background",
    comments="",
    fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
)

phase_rows = []
mass_scales = []
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    mass_scales.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
total = sum(mass_scales)

export_names = {
    "WO3_2311041": "phase_WO3.cif",
    "Co3O4_9005896": "phase_Co3O4.cif",
}
display_names = {
    "WO3_2311041": "monoclinic WO3",
    "Co3O4_9005896": "spinel Co3O4",
}
for phase, mass_scale in zip(project.phases(), mass_scales):
    cif_name = export_names[phase.name]
    phase.export_CIF(cif_name)
    phase_rows.append(
        {
            "name": display_names[phase.name],
            "project_phase": phase.name,
            "formula": "WO3" if "WO3" in phase.name else "Co3O4",
            "cif_path": cif_name,
            "weight_fraction": mass_scale / total,
            "weight_percent": 100.0 * mass_scale / total,
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cell": phase.get_cell(),
        }
    )

inst = hist.data["Instrument Parameters"][0]
instrument = {
    key: value[1]
    for key, value in inst.items()
    if key in ("Lam1", "Lam2", "I(L2)/I(L1)", "U", "V", "W", "X", "SH/L", "Polariz.")
}
sample = hist.data["Sample Parameters"]
fit_stats = {
    "Rwp_percent": rwp,
    "Rp_percent": rp,
    "chi_square": chi2,
    "reduced_chi_square": reduced_chi2,
    "goodness_of_fit": gof,
    "n_points": int(len(x)),
    "n_refined_parameters_last_cycle": int(nvar),
    "weighting": "1/max(observed_counts,1)",
}
result = {
    "phases": phase_rows,
    "fit_statistics": fit_stats,
    "refinement_histogram": hist.name,
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
    "fraction_basis": "GSAS-II HAP scale multiplied by unit-cell mass, normalized over modeled crystalline phases",
    "instrument_parameters": instrument,
    "sample_parameters": {
        "geometry": sample["Type"],
        "goniometer_radius_mm": sample["Gonio. radius"],
        "specimen_shift_um": sample["Shift"][0],
    },
}
Path("result.json").write_text(json.dumps(clean(result), indent=2, allow_nan=False) + "\n")

wo = next(row for row in phase_rows if row["formula"] == "WO3")
co = next(row for row in phase_rows if row["formula"] == "Co3O4")
report = f"""# Powder XRD phase analysis

The pattern is modeled as unreacted monoclinic WO3 and spinel Co3O4; no crystalline cobalt tungstate is required. The refined crystalline-phase fractions are **{100*wo['weight_fraction']:.2f} wt% WO3** and **{100*co['weight_fraction']:.2f} wt% Co3O4**, normalized over these two modeled phases.

## Evidence

The WO3 model accounts for the strong 23.46/23.95/24.71 degree triplet and the associated 33.6–34.5, 42.2, 47.6, 50.3 and 56.2 degree families. Co3O4 is independently fixed by its 31.64, 37.20, 45.14, 59.68, 65.56, 77.20 and 94.34 degree reflections. Their refined fraction ratio is also close to the 74.3:25.7 mass ratio expected for an unreacted 1:1 Co:W mixture of WO3 and one-third mole Co3O4.

The selected WO3 reference is the physical room-temperature P21/c neutron model COD 2311041. A triclinic WO3 checkpoint was slightly worse under the same physical profile constraints. A malformed short-cell WO3 reference with a 0.46 Angstrom contact was rejected. W coordinates were refined first; O coordinates were accepted only from a bounded start (about 0.054 Angstrom O-site RMS movement from the reference). The final structures retain sensible nearest distances (WO3 W-O >= about 1.73 Angstrom; Co3O4 Co-O >= about 1.91 Angstrom).

An analogue-derived wolframite CoWO4 test (ZnWO4 COD 1520641 with Zn replaced by Co) refined to the positive-scale floor, and the diagnostic 30.4–30.7 degree wolframite doublet is absent. Adding a second exact-composition WO3 model produced only 1.4–2.0 wt% with strong scale anticorrelation (-0.81 to -0.91) against the main WO3 phase; this cannot be distinguished reliably from reference/intensity mismatch and is not reported as a separate phase.

## Fit and uncertainty

The full-grid fit has Rwp = **{rwp:.3f}%**, Rp = **{rp:.3f}%**, and goodness of fit = **{gof:.3f}** for {len(x)} points with Poisson count weights. Residual structure is concentrated around the strongest WO3 peaks, so the exact oxygen coordinates and any sub-2 wt% WO3 polymorph are not uniquely determined. Common-Uiso/profile trials move the phase fractions by roughly 1–2 percentage points; that is a more realistic fraction uncertainty than the small least-squares scale e.s.d. No amorphous fraction is quantified, and the reported fractions are only over modeled crystalline material.

The submitted CIFs, fractions and `fit.csv` were exported from `final.gpx`.
"""
Path("report.md").write_text(report)

print(json.dumps({"Rwp_percent": rwp, "fractions": {r["formula"]: r["weight_fraction"] for r in phase_rows}}, indent=2))
