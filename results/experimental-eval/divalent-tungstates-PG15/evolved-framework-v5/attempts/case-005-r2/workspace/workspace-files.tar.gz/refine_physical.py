#!/usr/bin/env python3
"""Continue the best inventory from its pre-profile checkpoint with physical bounds."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import metrics


def checkpoint(project: G2.G2Project, outdir: Path, label: str) -> dict:
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    result = metrics(project)
    result["step"] = label
    hist = project.histogram(0)
    result["profiles"] = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["profiles"][phase.name] = {
            "size": hap["Size"],
            "microstrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    project.save(outdir / f"{label}.gpx")
    print(json.dumps(result, default=str))
    return result


def set_bound(project: G2.G2Project, variable: str, lower: float, upper: float) -> None:
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--texture", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(Path(args.input).resolve()), newgpx=str(outdir / "physical.gpx"))
    hist = project.histogram(0)
    phases = project.phases()
    inst = hist.data["Instrument Parameters"][0]

    # Reset to a physical profile near the center of the documented ranges.
    for name, value in {"U": 15.0, "V": 0.0, "W": 15.0, "X": 2.0, "SH/L": 0.03}.items():
        inst[name][1] = value
        inst[name][2] = name != "V"
    for i, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])

    set_bound(project, ":0:U", 0.0, 40.0)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:X", 0.1, 6.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    for i in range(len(phases)):
        set_bound(project, f"{i}:0:Size;i", 0.04, 1.50)
        set_bound(project, f"{i}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{i}:0:MD", 0.70, 1.40)

    history = []
    project.set_Frozen()
    history.append(checkpoint(project, outdir, "01_bounded_instrument"))

    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project.set_Frozen()
    history.append(checkpoint(project, outdir, "02_bounded_phase_profiles"))

    # Re-release any parameter that hit a bound in the first pass; with phase
    # broadening now present it can move back into the allowed interior.
    project.set_Frozen()
    history.append(checkpoint(project, outdir, "03_joint_profile_polish"))

    if args.texture:
        for phase in phases:
            phase.set_HAP_refinements({"Pref.Ori.": True})
        project.set_Frozen()
        history.append(checkpoint(project, outdir, "04_texture_test"))

    project.save(outdir / "physical.gpx")
    (outdir / "summary.json").write_text(json.dumps({"steps": history}, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
