#!/usr/bin/env python3
"""Create a physical CoWO4 wolframite model from the exact-topology ZnWO4 analogue."""

from pathlib import Path

from pymatgen.core import Structure


SOURCE = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/06/1520641.cif")
OUTPUT = Path("models/CoWO4_from_ZnWO4_1520641.cif")

structure = Structure.from_file(SOURCE, primitive=False)
structure.replace_species({"Zn": "Co"})
OUTPUT.parent.mkdir(parents=True, exist_ok=True)
structure.to(filename=OUTPUT)
print(OUTPUT)
