#!/usr/bin/env python3
"""Low-dimensional positive-scale test for highly correlated residual phases."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import metrics


parser = argparse.ArgumentParser()
parser.add_argument("--input", required=True)
parser.add_argument("--cif", required=True)
parser.add_argument("--name", required=True)
parser.add_argument("--out", required=True)
args = parser.parse_args()

G2.SetPrintLevel("warn")
outdir = Path(args.out).resolve()
outdir.mkdir(parents=True, exist_ok=True)
project = G2.G2Project(str(Path(args.input).resolve()), newgpx=str(outdir / "scale_only.gpx"))
project.set_Frozen()
hist = project.histogram(0)

# Freeze all nuisance and structural terms from the accepted checkpoint.
hist.data["Background"][0][1] = False
for value in hist.data["Instrument Parameters"][0].values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for key, value in hist.data["Sample Parameters"].items():
    if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
        value[1] = False
for phase in project.phases():
    phase.set_refinements({"Cell": False})
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][2] = False

extra = project.add_phase(str(Path(args.cif).resolve()), phasename=args.name, histograms=[hist], fmthint="CIF")
extra.HAPvalue("Scale", 0.01)
extra.set_HAP_refinements({"Scale": True})
pidx = len(project.phases()) - 1
project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Scale")
project.set_Controls("cycles", 5)
project.refine(makeBack=False)
project.set_Controls("cycles", 3)
project.refine(makeBack=False)

result = metrics(project)
result["raw_scales"] = {
    phase.name: phase.data["Histograms"][hist.name]["Scale"] for phase in project.phases()
}
project.save(outdir / "scale_only.gpx")
(outdir / "summary.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
print(json.dumps(result, default=str))
