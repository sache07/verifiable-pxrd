#!/usr/bin/env python3
"""Set one common fixed Uiso per phase and repolish all active non-atomic terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import metrics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--wo3", required=True, type=float)
    parser.add_argument("--co3o4", required=True, type=float)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(Path(args.input).resolve()), newgpx=str(outdir / "uiso.gpx"))
    project.set_Frozen()
    for phase in project.phases():
        value = args.wo3 if "WO3" in phase.name else args.co3o4
        for atom in phase.atoms():
            atom.uiso = value
            atom.refinement_flags = " "
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.set_Controls("cycles", 5)
    project.refine(makeBack=False)
    result = metrics(project)
    result["uiso"] = {"WO3": args.wo3, "Co3O4": args.co3o4}
    hist = project.histogram(0)
    result["profiles"] = {
        phase.name: {
            "size": phase.data["Histograms"][hist.name]["Size"],
            "microstrain": phase.data["Histograms"][hist.name]["Mustrain"],
            "preferred_orientation": phase.data["Histograms"][hist.name]["Pref.Ori."],
        }
        for phase in project.phases()
    }
    for phase in project.phases():
        phase.export_CIF(str(outdir / f"{phase.name}.cif"))
    project.save(outdir / "uiso.gpx")
    (outdir / "summary.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, default=str))


if __name__ == "__main__":
    main()
