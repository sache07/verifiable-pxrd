#!/usr/bin/env python3
"""Build staged, replayable GSAS-II trial refinements for candidate phase inventories."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def metrics(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    data = hist.data["data"][1]
    x = np.asarray(data[0], dtype=float)
    yobs = np.asarray(data[1], dtype=float)
    weight = np.asarray(data[2], dtype=float)
    ycalc = np.asarray(data[3], dtype=float)
    limits = hist.data["Limits"][1]
    use = (x >= limits[0]) & (x <= limits[1]) & np.isfinite(yobs) & np.isfinite(ycalc)
    diff = yobs - ycalc
    rwp = 100.0 * math.sqrt(np.sum(weight[use] * diff[use] ** 2) / np.sum(weight[use] * yobs[use] ** 2))
    rp = 100.0 * np.sum(np.abs(diff[use])) / np.sum(np.abs(yobs[use]))
    scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        scales.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
    scales = np.asarray(scales)
    fractions = scales / scales.sum()
    return {
        "Rwp_percent_recomputed": float(rwp),
        "Rp_percent_recomputed": float(rp),
        "Rwp_percent_GSASII": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "phase_fractions": {phase.name: float(frac) for phase, frac in zip(project.phases(), fractions)},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "instrument": {k: v[1] for k, v in hist.data["Instrument Parameters"][0].items() if isinstance(v, list) and len(v) > 1},
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"][0],
    }


def run_step(project: G2.G2Project, label: str, outdir: Path) -> dict:
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    result = metrics(project)
    result["step"] = label
    project.save(outdir / f"{label}.gpx")
    print(json.dumps(result, default=str))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", required=True, help="COD identifier for WO3")
    parser.add_argument("--co3o4", default="9005896", help="COD identifier for Co3O4")
    parser.add_argument("--out", required=True)
    parser.add_argument("--coordinates", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.out).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(outdir / "trial.gpx"))
    hist = project.add_powder_histogram(
        str(Path("pattern.xye").resolve()),
        str(Path("instrument.instprm").resolve()),
        fmthint="xye",
    )
    wo3 = project.add_phase(str(cod_path(args.wo3)), phasename=f"WO3_{args.wo3}", histograms=[hist], fmthint="CIF")
    co3o4 = project.add_phase(str(cod_path(args.co3o4)), phasename=f"Co3O4_{args.co3o4}", histograms=[hist], fmthint="CIF")

    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    # Keep the histogram scale fixed: refining it with every phase scale is singular.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    # The peak-family map gives an approximately +0.3 degree low-angle shift,
    # corresponding to a negative specimen displacement near 0.55 mm at R=200 mm.
    hist.data["Sample Parameters"]["Shift"] = [-550.0, False]
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [3000.0] + [0.0] * 11,
            "refine": True,
        }
    })
    for phase in (wo3, co3o4):
        phase.HAPvalue("Scale", 0.001)
        phase.set_HAP_refinements({"Scale": True})
        phase.setSampleProfile(hist.name, "size", "isotropic", 0.3)
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", 1000.0)

    history = []
    history.append(run_step(project, "01_scale_background", outdir))

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    history.append(run_step(project, "02_shift", outdir))

    for phase in (wo3, co3o4):
        phase.set_refinements({"Cell": True})
    history.append(run_step(project, "03_cells", outdir))

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]})
    history.append(run_step(project, "04_instrument", outdir))

    for phase in (wo3, co3o4):
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    history.append(run_step(project, "05_phase_profiles", outdir))

    if args.coordinates:
        # Heavy-atom coordinates first, followed by oxygen. ADPs remain fixed.
        for phase in (wo3, co3o4):
            heavy = {a.label: "X" for a in phase.atoms() if a.element != "O"}
            if heavy:
                phase.set_refinements({"Atoms": heavy})
        history.append(run_step(project, "06_heavy_coordinates", outdir))
        for phase in (wo3, co3o4):
            oxygen = {a.label: "X" for a in phase.atoms() if a.element == "O"}
            if oxygen:
                phase.set_refinements({"Atoms": oxygen})
        history.append(run_step(project, "07_all_coordinates", outdir))

    project.save(outdir / "trial.gpx")
    (outdir / "summary.json").write_text(json.dumps({"steps": history}, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
