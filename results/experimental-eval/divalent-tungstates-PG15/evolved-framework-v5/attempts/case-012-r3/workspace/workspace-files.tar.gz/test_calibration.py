#!/usr/bin/env python3
"""Refine supported angular calibration terms from the best full model."""
from pathlib import Path
import json,sys
import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIobj as G2obj
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'.tmp/strains/p1-uni-100-combined/model.gpx'
def plain(v):
    if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [plain(x) for x in v]
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    return v
def main():
    mode=sys.argv[1];out=ROOT/'.tmp'/f'calibration-{mode}';out.mkdir(parents=True,exist_ok=True)
    G2.SetPrintLevel('warn');p=G2.G2Project(gpxfile=str(SRC),filename=str(out/'model.gpx'));h=p.histogram(0)
    h.clear_refinements({'Instrument Parameters':['Zero'],'Sample Parameters':['Shift']})
    if mode in ('zero','both'):h.set_refinements({'Instrument Parameters':['Zero']})
    if mode in ('shift','both'):h.set_refinements({'Sample Parameters':['Shift']})
    p.index_ids();c=p.data['Controls']['data'];c['parmFrozen']={}
    c.setdefault('parmMinDict',{})[G2obj.G2VarObj(':0:Zero')]=-0.25;c.setdefault('parmMaxDict',{})[G2obj.G2VarObj(':0:Zero')]=0.25
    c.setdefault('parmMinDict',{})[G2obj.G2VarObj(':0:Shift')]=-800;c.setdefault('parmMaxDict',{})[G2obj.G2VarObj(':0:Shift')]=800
    p.set_Controls('cycles',60);p.refine(makeBack=False);p.save(str(out/'model.gpx'))
    raw=[max(0,q.data['Histograms'][h.name]['Scale'][0])*q.data['General']['Mass'] for q in p.phases()];frac=[x/sum(raw) for x in raw]
    rec={'mode':mode,'wR':h.get_wR(),'fraction':frac,'instrument':h.data['Instrument Parameters'][0],
         'sample':h.data['Sample Parameters'],'residuals':h.residuals,'frozen':p.get_Frozen()}
    (out/'result.json').write_text(json.dumps(plain(rec),indent=2)+'\n');print(mode,h.get_wR(),h.data['Instrument Parameters'][0]['Zero'],h.data['Sample Parameters']['Shift'],frac,p.get_Frozen())
if __name__=='__main__':main()
