#!/usr/bin/env python3
"""Apply the same bounded profile refinement to a selected accepted checkpoint."""
from pathlib import Path
import json
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def plain(v):
    if isinstance(v, dict): return {str(k): plain(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)): return [plain(x) for x in v]
    if isinstance(v, np.ndarray): return v.tolist()
    if isinstance(v, np.generic): return v.item()
    return v


def fractions(p):
    h = p.histogram(0)
    x = [max(0.0, q.data['Histograms'][h.name]['Scale'][0]) * q.data['General']['Mass'] for q in p.phases()]
    return [v / sum(x) for v in x]


def save(p, out, tag):
    p.save(str(out / 'profile.gpx'))
    shutil.copy2(out / 'profile.gpx', out / f'{tag}.gpx')
    h = p.histogram(0)
    rec = {'tag': tag, 'wR': h.get_wR(), 'residuals': h.residuals,
           'instrument': h.data['Instrument Parameters'][0], 'sample': h.data['Sample Parameters'],
           'fractions': fractions(p), 'frozen': p.get_Frozen(),
           'phases': [{'name':q.name,'cell':q.data['General']['Cell'],
                       'hap':q.data['Histograms'][h.name], 'atoms':q.data['Atoms']} for q in p.phases()]}
    (out / f'{tag}.json').write_text(json.dumps(plain(rec), indent=2, default=str)+'\n')
    print(tag, h.get_wR(), fractions(p), p.get_Frozen(), flush=True)


def refine(p, out, tag):
    p.set_Controls('cycles', 24)
    p.refine(makeBack=False)
    save(p, out, tag)


def main():
    if len(sys.argv) != 3:
        raise SystemExit('usage: profile_from_checkpoint.py INPUT_GPX LABEL')
    source = Path(sys.argv[1]).resolve()
    label = sys.argv[2]
    out = ROOT / '.tmp' / f'profile-{label}'
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel('warn')
    p = G2.G2Project(gpxfile=str(source), filename=str(out/'profile.gpx'))
    h = p.histogram(0)
    # Retain roughness bounds/frozen state, but permit the instrument U trial.
    frozen = p.data['Controls']['data'].setdefault('parmFrozen',{}).setdefault('FrozenList',[])
    p.data['Controls']['data']['parmFrozen']['FrozenList'] = [v for v in frozen if str(v) != ':0:U']
    h.set_refinements({'Instrument Parameters':['U','W','SH/L']})
    refine(p, out, 'p01_instrument')
    for ph in p.phases():
        ph.set_HAP_refinements({'Size':{'type':'isotropic','refine':True}})
    refine(p, out, 'p02_sizes')


if __name__ == '__main__':
    main()
