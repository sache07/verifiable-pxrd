#!/usr/bin/env python3
"""Test residual NiO against the complete accepted two-phase checkpoint."""
from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIobj as G2obj
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'.tmp/strains/p1-uni-100-combined/model.gpx'
NIO=Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/00/1010093.cif')
def plain(v):
    if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [plain(x) for x in v]
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    return v
def main():
    out=ROOT/'.tmp/test-nio';out.mkdir(parents=True,exist_ok=True);G2.SetPrintLevel('warn')
    p=G2.G2Project(gpxfile=str(SRC),filename=str(out/'model.gpx'));h=p.histogram(0)
    ni=p.add_phase(str(NIO),phasename='NiO_test',histograms=[h],fmthint='CIF');hap=ni.data['Histograms'][h.name]
    hap['Scale']=[0.2,True];hap['Size'][0]='isotropic';hap['Size'][1][0]=0.2;hap['Size'][2]=[False,False,False]
    hap['Mustrain'][0]='isotropic';hap['Mustrain'][1][0]=1000.;hap['Mustrain'][2]=[False,False,False]
    ni.set_refinements({'Cell':True});p.index_ids();c=p.data['Controls']['data'];c['parmFrozen']={}
    c.setdefault('parmMinDict',{})[G2obj.G2VarObj('2:0:Scale')]=0.;c.setdefault('parmMaxDict',{})[G2obj.G2VarObj('2:0:Scale')]=5.
    p.set_Controls('cycles',80);p.refine(makeBack=False);p.save(str(out/'model.gpx'))
    raw=[max(0,q.data['Histograms'][h.name]['Scale'][0])*q.data['General']['Mass'] for q in p.phases()];frac=[x/sum(raw) for x in raw]
    rec={'wR':h.get_wR(),'fraction':frac,'residuals':h.residuals,'frozen':p.get_Frozen(),'nio_cell':ni.data['General']['Cell'],
         'nio_hap':hap};(out/'result.json').write_text(json.dumps(plain(rec),indent=2,default=str)+'\n')
    print(h.get_wR(),frac,ni.data['General']['Cell'],hap,p.get_Frozen())
if __name__=='__main__':main()
