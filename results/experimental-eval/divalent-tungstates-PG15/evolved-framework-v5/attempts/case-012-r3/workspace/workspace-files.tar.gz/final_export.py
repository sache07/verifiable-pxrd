#!/usr/bin/env python3
"""Package and independently replay the accepted physical GSAS-II model."""

from __future__ import annotations

from pathlib import Path
import csv
import hashlib
import json
import shutil
import subprocess
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "strains" / "p1-uni-100-combined" / "model.gpx"
FINAL_GPX = ROOT / "final.gpx"
PATTERN = ROOT / "inputs" / "pattern.csv"
REPLAY_WORKER = ROOT / "learned" / "divalent-tungstates" / "scorer" / "runtime" / "replay_worker.py"
REPLAY_DIR = ROOT / ".tmp" / "replay-final"


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_fit(path: Path, x: np.ndarray, observed: np.ndarray, calculated: np.ndarray) -> None:
    with path.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        for row in zip(x, observed, calculated, observed - calculated):
            writer.writerow([f"{row[0]:.8f}", f"{row[1]:.8f}", f"{row[2]:.8f}", f"{row[3]:.8f}"])


def main() -> None:
    G2.SetPrintLevel("warn")
    if not SOURCE.is_file():
        raise FileNotFoundError(SOURCE)

    # Byte-copy the accepted checkpoint so no additional refinement or project
    # mutation separates the submitted project from the selected model.
    shutil.copy2(SOURCE, FINAL_GPX)
    project = G2.G2Project(gpxfile=str(FINAL_GPX))
    hist = project.histogram(0)
    phases = project.phases()
    if len(phases) != 2:
        raise RuntimeError(f"expected two accepted phases, found {len(phases)}")

    # Export saved atoms, not any possibly stale covariance values.
    project.data.setdefault("Covariance", {}).setdefault("data", {}).clear()
    cif_names = ["phase_NiWO4.cif", "phase_WO3.cif"]
    for phase, name in zip(phases, cif_names):
        phase.export_CIF(str(ROOT / name))

    histogram_name = hist.name
    raw_masses = []
    phase_records = []
    for phase, cif_name in zip(phases, cif_names):
        general = phase.data["General"]
        hap = phase.data["Histograms"][histogram_name]
        raw_mass = float(general["Mass"]) * float(hap["Scale"][0])
        if raw_mass <= 0:
            raise RuntimeError(f"non-positive crystalline contribution for {phase.name}")
        raw_masses.append(raw_mass)
        cell = [float(v) for v in general["Cell"][1:8]]
        phase_records.append({
            "name": "nickel tungstate (wolframite)" if "NiWO4" in phase.name else "tungsten(VI) oxide",
            "project_phase": phase.name,
            "formula": "NiWO4" if "NiWO4" in phase.name else "WO3",
            "space_group": str(general["SGData"]["SpGrp"]),
            "cif_path": cif_name,
            "cell": {
                "a_angstrom": cell[0], "b_angstrom": cell[1], "c_angstrom": cell[2],
                "alpha_deg": cell[3], "beta_deg": cell[4], "gamma_deg": cell[5],
                "volume_angstrom3": cell[6],
            },
        })
    fractions = np.asarray(raw_masses, dtype=float) / sum(raw_masses)
    for record, fraction in zip(phase_records, fractions):
        record["weight_fraction"] = float(fraction)

    # Recalculate the complete profile from the atomic model in a fresh process.
    REPLAY_DIR.mkdir(parents=True, exist_ok=True)
    request_path = REPLAY_DIR / "request.json"
    request = {
        "project": str(FINAL_GPX),
        "observed": str(PATTERN),
        "histogram": histogram_name,
    }
    request_path.write_text(json.dumps(request, indent=2) + "\n")
    completed = subprocess.run(
        [sys.executable, str(REPLAY_WORKER), str(request_path)],
        cwd=REPLAY_DIR,
        text=True,
        capture_output=True,
        check=False,
    )
    replay = json.loads((REPLAY_DIR / "replay.json").read_text())
    if completed.returncode or replay.get("status") != "replayed":
        raise RuntimeError(f"GSAS-II replay failed: {replay}\n{completed.stdout}\n{completed.stderr}")
    if replay.get("profile_review_flags"):
        raise RuntimeError(f"physical replay flags: {replay['profile_review_flags']}")

    prediction = np.load(REPLAY_DIR / "prediction.npz")
    x = np.asarray(prediction["x"], dtype=float)
    observed = np.asarray(prediction["observed"], dtype=float)
    calculated = np.asarray(prediction["predicted"], dtype=float)
    background = np.asarray(prediction["background"], dtype=float)
    if np.any(calculated < 0) or np.any(background < 0):
        raise RuntimeError("accepted model has a negative calculated profile or background")
    public = np.loadtxt(PATTERN, delimiter=",", skiprows=1)
    if not (np.array_equal(x, public[:, 0]) and np.array_equal(observed, public[:, 1])):
        raise RuntimeError("replayed observations/grid differ from pattern.csv")
    write_fit(ROOT / "fit.csv", x, observed, calculated)

    replay_fractions = np.asarray([p["weight_fraction"] for p in replay["phases"]], dtype=float)
    if not np.allclose(replay_fractions, fractions, atol=1e-12, rtol=0):
        raise RuntimeError(f"replay fraction mismatch: {replay_fractions} versus {fractions}")

    weights = 1.0 / np.maximum(observed, 1.0)
    residual = observed - calculated
    weighted_ss = float(np.sum(weights * residual ** 2))
    weighted_denominator = float(np.sum(weights * observed ** 2))
    rwp = float(100.0 * np.sqrt(weighted_ss / weighted_denominator))
    rp = float(100.0 * np.sum(np.abs(residual)) / np.sum(np.abs(observed)))
    residuals = plain(hist.residuals)
    rexp = float(residuals.get("wRmin", np.nan))
    fit_statistics = {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "rexp_percent": rexp,
        "goodness_of_fit_rwp_over_rexp": float(rwp / rexp),
        "weighted_residual_sum_squares": weighted_ss,
        "n_points": int(len(x)),
        "gsas_saved_rwp_percent": float(hist.get_wR()),
    }

    result = {
        "phases": phase_records,
        "fit_statistics": fit_statistics,
        "refinement_histogram": histogram_name,
        "profile_file": "fit.csv",
        "project_file": "final.gpx",
        "measurement": {
            "radiation": "Cu K-alpha1/K-alpha2",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
        },
        "calibration": {
            "zero_offset_deg": float(hist.data["Instrument Parameters"][0]["Zero"][1]),
            "specimen_displacement_micrometre": float(hist.data["Sample Parameters"]["Shift"][0]),
        },
        "verification": {
            "native_atomic_forward_replay": replay["status"],
            "profile_review_flags": replay["profile_review_flags"],
            "project_sha256": sha256(FINAL_GPX),
            "fit_sha256": sha256(ROOT / "fit.csv"),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(plain(result), indent=2, allow_nan=False) + "\n")

    diagnostics = {
        "project_phase_names": [p.name for p in phases],
        "fractions": fractions,
        "histogram": histogram_name,
        "fit_statistics": fit_statistics,
        "saved_residuals": residuals,
        "calculated_min": float(calculated.min()),
        "background_min": float(background.min()),
        "background_max": float(background.max()),
        "replay": replay,
    }
    (REPLAY_DIR / "packaging_diagnostics.json").write_text(
        json.dumps(plain(diagnostics), indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(plain(diagnostics), indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
