#!/usr/bin/env python3
"""Test one supported isotropic or uniaxial microstrain term."""
from pathlib import Path
import json,sys
import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIobj as G2obj
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'.tmp/continue-release_u/model.gpx'
def plain(v):
    if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [plain(x) for x in v]
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    return v
def main():
    phase=int(sys.argv[1]);kind=sys.argv[2];axis=[0,0,1] if len(sys.argv)<4 else [int(x) for x in sys.argv[3].split(',')]
    source=Path(sys.argv[4]).resolve() if len(sys.argv)>4 else SRC
    suffix='-combined' if len(sys.argv)>4 else ''
    key=f'p{phase}-{kind}-'+''.join(map(str,axis))+suffix;out=ROOT/'.tmp'/'strains'/key;out.mkdir(parents=True,exist_ok=True)
    G2.SetPrintLevel('warn');p=G2.G2Project(gpxfile=str(source),filename=str(out/'model.gpx'));h=p.histogram(0)
    for ph in p.phases():ph.clear_HAP_refinements({'Mustrain':True})
    ph=p.phases()[phase];ms=ph.data['Histograms'][h.name]['Mustrain'];start=float(ms[1][0])
    if kind=='iso':
        ms[0]='isotropic';ms[2][0]=True
    elif kind=='uni':
        ms[0]='uniaxial';ms[1][0]=start;ms[1][1]=start;ms[2][0]=True;ms[2][1]=True;ms[3]=axis
    else:raise SystemExit('iso or uni')
    p.index_ids();c=p.data['Controls']['data'];c['parmFrozen']={}
    for var in [f'{phase}:0:Mustrain;i',f'{phase}:0:Mustrain;a']:
        c.setdefault('parmMinDict',{})[G2obj.G2VarObj(var)]=0.0;c.setdefault('parmMaxDict',{})[G2obj.G2VarObj(var)]=8000.0
    p.set_Controls('cycles',50);p.refine(makeBack=False);p.save(str(out/'model.gpx'))
    raw=[max(0,q.data['Histograms'][h.name]['Scale'][0])*q.data['General']['Mass'] for q in p.phases()];frac=[x/sum(raw) for x in raw]
    rec={'key':key,'wR':h.get_wR(),'fraction':frac,'mustrain':ms,'residuals':h.residuals,'frozen':p.get_Frozen(),
         'instrument':h.data['Instrument Parameters'][0]}
    (out/'result.json').write_text(json.dumps(plain(rec),indent=2)+'\n');print(key,h.get_wR(),ms,frac,p.get_Frozen())
if __name__=='__main__':main()
