#!/usr/bin/env python3
"""Converge the best physical checkpoint with/without surface roughness."""
from pathlib import Path
import json
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'.tmp/profile-a05_ni_oxygen/p02_sizes.gpx'

def plain(v):
    if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [plain(x) for x in v]
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    return v

def main():
    mode=sys.argv[1]
    if mode not in ('zero','minimum','release_u'):raise SystemExit('zero, minimum or release_u')
    source=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else SOURCE
    out=ROOT/'.tmp'/f'continue-{mode}';out.mkdir(parents=True,exist_ok=True)
    G2.SetPrintLevel('warn')
    p=G2.G2Project(gpxfile=str(source),filename=str(out/'model.gpx'))
    h=p.histogram(0);s=h.data['Sample Parameters']
    p.data['Controls']['data']['parmFrozen']={}
    if mode=='zero':
        s['SurfRoughA']=[0.0,False];s['SurfRoughB']=[0.0,False]
    else:
        s['SurfRoughA']=[0.05,False];s['SurfRoughB']=[0.02,False]
    if mode == 'release_u' and len(sys.argv) <= 2:
        h.data['Instrument Parameters'][0]['U'][1] = 10.0
    p.set_Controls('cycles',60);p.refine(makeBack=False);p.save(str(out/'model.gpx'))
    raw=[max(0,q.data['Histograms'][h.name]['Scale'][0])*q.data['General']['Mass'] for q in p.phases()]
    frac=[x/sum(raw) for x in raw]
    rec={'mode':mode,'wR':h.get_wR(),'residuals':h.residuals,'instrument':h.data['Instrument Parameters'][0],
         'sample':s,'background':h.data['Background'],'fractions':frac,'frozen':p.get_Frozen(),
         'phases':[{'name':q.name,'cell':q.data['General']['Cell'],'hap':q.data['Histograms'][h.name],
                    'atoms':q.data['Atoms']} for q in p.phases()],
         'covariance':p.data.get('Covariance',{}).get('data',{})}
    (out/'model.json').write_text(json.dumps(plain(rec),indent=2,default=str)+'\n')
    print(mode,h.get_wR(),frac,p.get_Frozen())
if __name__=='__main__':main()
