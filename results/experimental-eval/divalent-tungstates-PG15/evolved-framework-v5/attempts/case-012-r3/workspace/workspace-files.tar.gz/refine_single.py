#!/usr/bin/env python3
"""Build a staged, replayable GSAS-II refinement for the NiWO4 first model."""
from pathlib import Path
import csv
import json
import math
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
GPX = ROOT / ".tmp" / "single" / "single.gpx"
WORK = GPX.parent


def prepare_inputs():
    WORK.mkdir(parents=True, exist_ok=True)
    arr = np.genfromtxt(PATTERN, delimiter=",", names=True)
    x = np.asarray(arr["two_theta_deg"], float)
    y = np.asarray(arr["intensity"], float)
    sig = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(WORK / "pattern.xye", np.column_stack([x, y, sig]), fmt="%.10g")
    (WORK / "instrument.instprm").write_text(
        "# GSAS-II Cu Kalpha laboratory instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return x, y


def snapshot(project, label):
    path = WORK / f"{label}.gpx"
    project.save(str(path))
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append({
            "name": phase.name,
            "cell": phase.data["General"]["Cell"][1:8],
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        })
    record = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "phases": phases,
        "varyList": cov.get("varyList", []),
        "variables": {str(k): v for k, v in cov.get("variables", {}).items()} if isinstance(cov.get("variables"), dict) else cov.get("variables"),
        "sig": cov.get("sig"),
        "Rvals": cov.get("Rvals"),
    }
    (WORK / f"{label}.json").write_text(json.dumps(record, indent=2, default=str) + "\n")
    print(label, "wR", hist.get_wR(), "GOF", hist.residuals.get("GOF"), flush=True)


def refine(project, label):
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    snapshot(project, label)


def main():
    G2.SetPrintLevel("warn")
    x, y = prepare_inputs()
    project = G2.G2Project(newgpx=str(GPX))
    phase = project.add_phase(str(ROOT / "niwo4_start.cif"), phasename="NiWO4", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(WORK / "pattern.xye"), str(WORK / "instrument.instprm"),
        phases=[phase], fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    # An interpolated background is a stable broad first fit; analytic-family
    # assessment is done from the resulting peak-subtracted residual later.
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])],
                          "Background": {"type": "chebyschev-1", "no. coeffs": 12,
                                         "coeffs": [float(np.percentile(y, 15))] + [0.0] * 11,
                                         "refine": True}})
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.3
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    snapshot(project, "s00_initial")

    refine(project, "s01_background_scale")

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "s02_cell_zero")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "s03_shift")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "s04_instrument")

    phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.3, "refine": True}})
    refine(project, "s05_size")

    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, "s06_mustrain")

    project.save(str(GPX))
    print("GSAS-II", GSASIIpath.GetVersionNumber(), "saved", GPX)


if __name__ == "__main__":
    main()
