#!/usr/bin/env python3
"""Refine the accepted NiWO4 + monoclinic WO3 inventory in physical stages."""
from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIobj as G2obj


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "multi-2311041" / "model.gpx"
WORK = ROOT / ".tmp" / "accepted"
CANON = WORK / "accepted.gpx"


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def phase_fractions(project):
    hist = project.histogram(0)
    raw = [max(0.0, float(p.data["Histograms"][hist.name]["Scale"][0])) *
           float(p.data["General"]["Mass"]) for p in project.phases()]
    total = sum(raw)
    return [v / total for v in raw]


def checkpoint(project, label):
    project.save(str(CANON))
    shutil.copy2(CANON, WORK / f"{label}.gpx")
    hist = project.histogram(0)
    phases = []
    for p, f in zip(project.phases(), phase_fractions(project)):
        hap = p.data["Histograms"][hist.name]
        phases.append({
            "name": p.name,
            "fraction": f,
            "cell": p.data["General"]["Cell"][1:8],
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "atoms": p.data["Atoms"],
        })
    cov = project.data.get("Covariance", {}).get("data", {})
    out = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "phases": phases,
        "varyList": cov.get("varyList", []),
        "variables": cov.get("variables"),
        "sig": cov.get("sig"),
        "Rvals": cov.get("Rvals"),
        "frozen": project.get_Frozen(),
    }
    (WORK / f"{label}.json").write_text(json.dumps(plain(out), indent=2, default=str) + "\n")
    print(label, "wR", hist.get_wR(), "fractions", phase_fractions(project),
          "frozen", project.get_Frozen(), flush=True)


def refine(project, label, cycles=20):
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    checkpoint(project, label)


def set_limits(project):
    # Index random IDs before constructing G2VarObj keys; otherwise the keys
    # lose their phase/histogram fields when a project is first assembled.
    project.index_ids()
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    lo = {
        ":0:U": 0.0, ":0:W": 2.0, ":0:X": 0.1, ":0:SH/L": 0.005,
        ":0:Polariz.": 0.5, ":0:Shift": -800.0,
        ":0:SurfRoughA": 0.05, ":0:SurfRoughB": 0.02,
    }
    hi = {
        ":0:U": 40.0, ":0:W": 40.0, ":0:X": 6.0, ":0:SH/L": 0.1,
        ":0:Polariz.": 1.0, ":0:Shift": 800.0,
        ":0:SurfRoughA": 0.6, ":0:SurfRoughB": 0.5,
    }
    for p in project.phases():
        pid = p.id
        lo.update({f"{pid}:0:Scale": 0.0, f"{pid}:0:Size;i": 0.04,
                   f"{pid}:0:Mustrain;i": 0.0})
        hi.update({f"{pid}:0:Size;i": 1.5, f"{pid}:0:Mustrain;i": 8000.0})
        for i, _ in enumerate(p.atoms()):
            lo[f"{pid}::AUiso:{i}"] = 0.002
            hi[f"{pid}::AUiso:{i}"] = 0.03
    controls["parmMinDict"] = {G2obj.G2VarObj(k): v for k, v in lo.items()}
    controls["parmMaxDict"] = {G2obj.G2VarObj(k): v for k, v in hi.items()}


def add_common_uiso(project, phase):
    variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
    if len(variables) > 1:
        project.add_EquivConstr(variables, reloadIdx=False)
    for atom in phase.atoms():
        atom.data[phase.data["General"]["AtomPtrs"][3] + 1] = 0.01
        if "U" not in atom.refinement_flags:
            atom.refinement_flags += "U"


def set_element_coordinate_flags(phase, elements):
    for atom in phase.atoms():
        flags = atom.refinement_flags
        if atom.element in elements and "X" not in flags:
            flags += "X"
        atom.refinement_flags = flags


def main():
    G2.SetPrintLevel("warn")
    WORK.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), filename=str(CANON))
    hist = project.histogram(0)
    ni, wo = project.phases()

    # Clear the exploratory profile flags and restore a physically allowed,
    # profile-equivalent decomposition before structural refinement.
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
                            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    hist.set_refinements({"Background": True})
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"Zero": -0.048, "U": 40.0, "W": 22.0, "X": 1.50,
                       "SH/L": 0.0595, "Polariz.": 0.70}.items():
        inst[key][1] = value
    sample = hist.data["Sample Parameters"]
    sample["Shift"] = [-3.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    for p in project.phases():
        p.set_refinements({"Cell": True})
        p.set_HAP_refinements({"Scale": True})
        p.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom in p.atoms():
            atom.refinement_flags = " "
    hni = ni.data["Histograms"][hist.name]
    hwo = wo.data["Histograms"][hist.name]
    hni["Size"][0] = hwo["Size"][0] = "isotropic"
    hni["Size"][1][0] = 0.113
    hwo["Size"][1][0] = 1.50
    hni["Size"][2] = hwo["Size"][2] = [False, False, False]
    hni["Mustrain"][0] = hwo["Mustrain"][0] = "isotropic"
    hni["Mustrain"][1][0] = 885.0
    hwo["Mustrain"][1][0] = 4136.0
    hni["Mustrain"][2] = hwo["Mustrain"][2] = [False, False, False]
    set_limits(project)
    refine(project, "a00_physical_profile")

    # Test the laboratory's supported whole-specimen low-angle deficit.
    sample["SurfRoughA"] = [0.15, True]
    sample["SurfRoughB"] = [0.10, True]
    refine(project, "a01_surface_roughness")

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "a02_polarization")

    # Heavy-atom coordinates first. Ni is included because it contributes
    # appreciably for Cu radiation; O remains fixed at this checkpoint.
    set_element_coordinate_flags(ni, {"Ni", "W"})
    set_element_coordinate_flags(wo, {"W"})
    refine(project, "a03_heavy_coordinates")

    # The generator convention uses one isotropic U per phase. Enforce that
    # compact model instead of allowing atom-by-atom ADPs to absorb intensity.
    add_common_uiso(project, ni)
    add_common_uiso(project, wo)
    refine(project, "a04_common_uiso")

    set_element_coordinate_flags(ni, {"O"})
    refine(project, "a05_ni_oxygen")

    set_element_coordinate_flags(wo, {"O"})
    refine(project, "a06_wo3_oxygen")

    # Finally allow only supported profile terms, with hard physical bounds.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    refine(project, "a07_instrument_profile")

    for p in project.phases():
        p.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine(project, "a08_sizes")

    for p in project.phases():
        p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, "a09_strains")
    project.save(str(CANON))


if __name__ == "__main__":
    main()
