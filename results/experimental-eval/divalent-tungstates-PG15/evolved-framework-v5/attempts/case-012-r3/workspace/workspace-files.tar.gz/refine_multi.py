#!/usr/bin/env python3
"""Compare complete NiWO4 + WO3 GSAS-II models on the measured profile."""
from pathlib import Path
import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIobj as G2obj


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_inputs(work):
    work.mkdir(parents=True, exist_ok=True)
    arr = np.genfromtxt(PATTERN, delimiter=",", names=True)
    x = np.asarray(arr["two_theta_deg"], float)
    y = np.asarray(arr["intensity"], float)
    sig = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(work / "pattern.xye", np.column_stack([x, y, sig]), fmt="%.10g")
    (work / "instrument.instprm").write_text(
        "# GSAS-II Cu Kalpha laboratory instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:12.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.06\n"
    )
    return x, y


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def weights(project):
    hist = project.histogram(0)
    raw = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw.append(max(0.0, float(hap["Scale"][0])) * float(phase.data["General"]["Mass"]))
    total = sum(raw)
    return [v / total for v in raw] if total else [0.0 for v in raw]


def snapshot(project, work, label):
    path = work / f"{label}.gpx"
    project.save(str(path))
    hist = project.histogram(0)
    phase_records = []
    fractions = weights(project)
    for phase, fraction in zip(project.phases(), fractions):
        hap = phase.data["Histograms"][hist.name]
        phase_records.append({
            "name": phase.name,
            "cell": phase.data["General"]["Cell"][1:8],
            "mass": phase.data["General"]["Mass"],
            "scale": hap["Scale"][0],
            "weight_fraction": fraction,
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        })
    cov = project.data.get("Covariance", {}).get("data", {})
    record = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "phases": phase_records,
        "varyList": cov.get("varyList", []),
        "variables": cov.get("variables"),
        "sig": cov.get("sig"),
        "Rvals": cov.get("Rvals"),
        "frozen": project.get_Frozen(),
    }
    (work / f"{label}.json").write_text(json.dumps(plain(record), indent=2, default=str) + "\n")
    print(label, "wR", hist.get_wR(), "fractions", fractions, "frozen", project.get_Frozen(), flush=True)


def reset_frozen(project):
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}


def limits(project):
    controls = project.data["Controls"]["data"]
    lo = {
        ":0:U": 0.0, ":0:W": 2.0, ":0:X": 0.1, ":0:SH/L": 0.005,
        ":0:Polariz.": 0.5, ":0:Shift": -800.0,
    }
    hi = {
        ":0:U": 40.0, ":0:W": 40.0, ":0:X": 6.0, ":0:SH/L": 0.1,
        ":0:Polariz.": 1.0, ":0:Shift": 800.0,
    }
    for phase in project.phases():
        pid = phase.id
        lo.update({f"{pid}:0:Scale": 0.0, f"{pid}:0:Size;i": 0.04,
                   f"{pid}:0:Mustrain;i": 0.0})
        hi.update({f"{pid}:0:Size;i": 1.5, f"{pid}:0:Mustrain;i": 8000.0})
    controls["parmMinDict"] = {G2obj.G2VarObj(k): v for k, v in lo.items()}
    controls["parmMaxDict"] = {G2obj.G2VarObj(k): v for k, v in hi.items()}


def refine(project, work, label, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    snapshot(project, work, label)


def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: refine_multi.py WO3_COD_ID")
    cod_id = sys.argv[1]
    G2.SetPrintLevel("warn")
    work = ROOT / ".tmp" / f"multi-{cod_id}"
    gpx = work / "model.gpx"
    x, y = prepare_inputs(work)
    project = G2.G2Project(newgpx=str(gpx))
    ni = project.add_phase(str(ROOT / "niwo4_start.cif"), phasename="NiWO4", fmthint="CIF")
    wo = project.add_phase(str(cod_path(cod_id)), phasename=f"WO3_{cod_id}", fmthint="CIF")
    hist = project.add_powder_histogram(str(work / "pattern.xye"), str(work / "instrument.instprm"),
                                       phases=[ni, wo], fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])],
                          "Background": {"type": "chebyschev-1", "no. coeffs": 14,
                                         "coeffs": [float(np.percentile(y, 15))] + [0.0] * 13,
                                         "refine": True}})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    limits(project)
    snapshot(project, work, "m00_initial")
    refine(project, work, "m01_background_scales")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, work, "m02_cells")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, work, "m03_zero")

    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, work, "m04_shift")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    refine(project, work, "m05_instrument")

    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.3, "refine": True}})
    refine(project, work, "m06_sizes")

    for phase in project.phases():
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, work, "m07_strains")

    # One final common zero adjustment after cells and specimen displacement settle.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, work, "m08_joint_calibration")
    project.save(str(gpx))


if __name__ == "__main__":
    main()
