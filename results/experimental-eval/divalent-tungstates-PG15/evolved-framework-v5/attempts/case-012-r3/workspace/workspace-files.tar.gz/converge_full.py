#!/usr/bin/env python3
"""Converge all accepted physical terms together from the best checkpoint."""
from pathlib import Path
import json,shutil
import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIobj as G2obj
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'.tmp/strains/p1-uni-100-combined/model.gpx';OUT=ROOT/'.tmp/full-converge'
def plain(v):
    if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [plain(x) for x in v]
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    return v
def snap(p,n):
    h=p.histogram(0);p.save(str(OUT/'model.gpx'));shutil.copy2(OUT/'model.gpx',OUT/f'cycle-{n}.gpx')
    raw=[max(0,q.data['Histograms'][h.name]['Scale'][0])*q.data['General']['Mass'] for q in p.phases()];frac=[x/sum(raw) for x in raw]
    rec={'cycle':n,'wR':h.get_wR(),'fraction':frac,'residuals':h.residuals,'instrument':h.data['Instrument Parameters'][0],
         'sample':h.data['Sample Parameters'],'background':h.data['Background'],'frozen':p.get_Frozen(),
         'phases':[{'name':q.name,'cell':q.data['General']['Cell'],'hap':q.data['Histograms'][h.name],
                    'atoms':q.data['Atoms']} for q in p.phases()]}
    (OUT/f'cycle-{n}.json').write_text(json.dumps(plain(rec),indent=2,default=str)+'\n');print(n,h.get_wR(),frac,p.get_Frozen(),flush=True)
def main():
    OUT.mkdir(parents=True,exist_ok=True);G2.SetPrintLevel('warn');p=G2.G2Project(gpxfile=str(SRC),filename=str(OUT/'model.gpx'));h=p.histogram(0)
    p.data['Controls']['data']['parmFrozen']={};p.index_ids();c=p.data['Controls']['data']
    for i,q in enumerate(p.phases()):
        ms=q.data['Histograms'][h.name]['Mustrain'];ms[0]='uniaxial';ms[2][0]=ms[2][1]=True;ms[3]=[1,0,0]
        for v in ('Mustrain;i','Mustrain;a'):
            c.setdefault('parmMinDict',{})[G2obj.G2VarObj(f'{i}:0:{v}')]=0.;c.setdefault('parmMaxDict',{})[G2obj.G2VarObj(f'{i}:0:{v}')]=8000.
    for n in (1,2,3):
        p.set_Controls('cycles',60);p.refine(makeBack=False);snap(p,n)
if __name__=='__main__':main()
