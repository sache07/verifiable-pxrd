#!/usr/bin/env python3
"""One final light-atom coordinate trial for accepted monoclinic WO3."""
from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'.tmp/strains/p1-uni-100-combined/model.gpx'
def plain(v):
    if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [plain(x) for x in v]
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    return v
def main():
    out=ROOT/'.tmp/wo3-oxygen-final';out.mkdir(parents=True,exist_ok=True)
    G2.SetPrintLevel('warn');p=G2.G2Project(gpxfile=str(SRC),filename=str(out/'model.gpx'));h=p.histogram(0);wo=p.phases()[1]
    for atom in wo.atoms():
        if atom.element=='O' and 'X' not in atom.refinement_flags:atom.refinement_flags += 'X'
    p.data['Controls']['data']['parmFrozen']={};p.set_Controls('cycles',80);p.refine(makeBack=False);p.save(str(out/'model.gpx'))
    raw=[max(0,q.data['Histograms'][h.name]['Scale'][0])*q.data['General']['Mass'] for q in p.phases()];frac=[x/sum(raw) for x in raw]
    rec={'wR':h.get_wR(),'fraction':frac,'residuals':h.residuals,'instrument':h.data['Instrument Parameters'][0],
         'sample':h.data['Sample Parameters'],'frozen':p.get_Frozen(),'phases':[{'name':q.name,'cell':q.data['General']['Cell'],
         'hap':q.data['Histograms'][h.name],'atoms':q.data['Atoms']} for q in p.phases()]}
    (out/'result.json').write_text(json.dumps(plain(rec),indent=2,default=str)+'\n')
    for i,q in enumerate(p.phases()):q.export_CIF(str(out/f'phase-{i}.cif'))
    print(h.get_wR(),frac,p.get_Frozen())
if __name__=='__main__':main()
