#!/usr/bin/env python3
"""Test one bounded March-Dollase texture axis from the converged model."""
from pathlib import Path
import json,sys
import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIobj as G2obj
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'.tmp/continue-minimum/model.gpx'
def plain(v):
    if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [plain(x) for x in v]
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    return v
def main():
    phase=int(sys.argv[1]);axis=[int(x) for x in sys.argv[2].split(',')];start=float(sys.argv[3])
    key=f'p{phase}-'+''.join(map(str,axis))+f'-{start:g}';out=ROOT/'.tmp'/'textures'/key;out.mkdir(parents=True,exist_ok=True)
    G2.SetPrintLevel('warn');p=G2.G2Project(gpxfile=str(SRC),filename=str(out/'model.gpx'));h=p.histogram(0);ph=p.phases()[phase]
    po=ph.data['Histograms'][h.name]['Pref.Ori.'];po[0]='MD';po[1]=start;po[2]=True;po[3]=axis
    p.index_ids();c=p.data['Controls']['data'];c.setdefault('parmMinDict',{})[G2obj.G2VarObj(f'{phase}:0:MD')]=0.7;c.setdefault('parmMaxDict',{})[G2obj.G2VarObj(f'{phase}:0:MD')]=1.4
    c['parmFrozen']={}
    p.set_Controls('cycles',30);p.refine(makeBack=False);p.save(str(out/'model.gpx'))
    raw=[max(0,q.data['Histograms'][h.name]['Scale'][0])*q.data['General']['Mass'] for q in p.phases()];frac=[x/sum(raw) for x in raw]
    rec={'key':key,'wR':h.get_wR(),'fraction':frac,'po':po,'residuals':h.residuals,'frozen':p.get_Frozen()}
    (out/'result.json').write_text(json.dumps(plain(rec),indent=2)+'\n');print(key,h.get_wR(),po,frac,p.get_Frozen())
if __name__=='__main__':main()
