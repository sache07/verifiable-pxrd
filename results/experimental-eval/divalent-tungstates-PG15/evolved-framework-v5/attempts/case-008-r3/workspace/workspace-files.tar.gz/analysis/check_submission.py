#!/usr/bin/env python3
"""Check that the submitted machine-readable artifacts match final.gpx."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


WORKSPACE = Path(__file__).resolve().parents[1]


def main() -> None:
    result = json.loads((WORKSPACE / "result.json").read_text())
    fit = np.genfromtxt(WORKSPACE / "fit.csv", delimiter=",", names=True)
    observed_input = np.genfromtxt(
        WORKSPACE / "inputs" / "pattern.csv", delimiter=",", names=True
    )
    project = G2.G2Project(gpxfile=str(WORKSPACE / "final.gpx"))
    hist = project.histogram(result["refinement_histogram"])
    profile = hist.data["data"][1]

    assert len(fit) == len(observed_input) == len(profile[0]) == 8301
    assert np.allclose(fit["two_theta_deg"], observed_input["two_theta_deg"], atol=1e-10)
    assert np.array_equal(fit["observed"], observed_input["intensity"])
    assert np.allclose(fit["calculated"], profile[3], rtol=0.0, atol=1e-10)
    assert np.allclose(fit["difference"], profile[1] - profile[3], rtol=0.0, atol=1e-10)
    assert np.all(np.isfinite(fit["calculated"]))
    assert not project.get_Frozen()

    products = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        products.append(hap["Scale"][0] * phase.data["General"]["Mass"])
    project_fractions = np.asarray(products) / sum(products)
    reported_fractions = np.asarray(
        [phase["weight_fraction"] for phase in result["phases"]]
    )
    assert np.isclose(reported_fractions.sum(), 1.0, atol=1e-12)
    assert np.allclose(project_fractions, reported_fractions, rtol=0.0, atol=1e-12)
    assert np.isclose(
        hist.get_wR(), result["fit_statistics"]["rwp_percent"], atol=1e-12
    )
    assert all((WORKSPACE / phase["cif_path"]).is_file() for phase in result["phases"])

    print(
        json.dumps(
            {
                "status": "ok",
                "points": len(fit),
                "fraction_sum": float(reported_fractions.sum()),
                "rwp_percent": hist.get_wR(),
                "frozen_parameters": project.get_Frozen(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
