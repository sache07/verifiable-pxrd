#!/usr/bin/env python3
"""Print the refinement state needed to audit a GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx")
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=args.gpx)
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    covariance = project.data.get("Covariance", {}).get("data", {})
    profile = hist.data.get("data", [None, []])[1]
    profile_summary = {
        "array_count": len(profile),
        "lengths": [len(array) for array in profile],
        "first_values": [float(array[0]) for array in profile],
        "last_values": [float(array[-1]) for array in profile],
    }
    products = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        product = float(hap["Scale"][0] * phase.data["General"]["Mass"])
        products.append(product)
        phases.append(
            {
                "name": phase.name,
                "general_name": phase.data["General"].get("Name"),
                "formula": phase.data["General"].get("Map"),
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cell": phase.get_cell(),
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": phase.data["Atoms"],
            }
        )
    total = sum(products)
    for phase, product in zip(phases, products):
        phase["weight_fraction"] = product / total

    info = {
        "filename": project.filename,
        "histogram": hist.name,
        "wR_percent": hist.get_wR(),
        "histogram_keys": list(hist.data),
        "histogram_summary": hist.data.get("data", [None])[0],
        "profile_summary": profile_summary,
        "limits": hist.data["Limits"],
        "instrument": {key: inst.get(key) for key in inst},
        "sample": sample,
        "phases": phases,
        "frozen": project.get_Frozen(),
        "covariance_keys": list(covariance),
        "Rvals": covariance.get("Rvals"),
        "varyList": covariance.get("varyList"),
        "variables": covariance.get("variables"),
        "sig": covariance.get("sig"),
    }
    print(json.dumps(info, indent=2, default=str))


if __name__ == "__main__":
    main()
