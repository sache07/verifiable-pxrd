#!/usr/bin/env python3
"""Independent geometry checks for the submitted phase CIFs."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


WORKSPACE = Path(__file__).resolve().parents[1]


def coordination_shell(structure: Structure, index: int, element: str, count: int) -> list[float]:
    neighbors = [
        neighbor.nn_distance
        for neighbor in structure.get_neighbors(structure[index], 3.2)
        if neighbor.specie.symbol == element
    ]
    return sorted(float(value) for value in neighbors)[:count]


def inspect(path: Path) -> dict:
    structure = Structure.from_file(path)
    analyzer = SpacegroupAnalyzer(structure, symprec=1e-3, angle_tolerance=1.0)
    pair_distances = []
    for index, site in enumerate(structure):
        for neighbor in structure.get_neighbors(site, 3.2):
            if neighbor.index > index:
                pair_distances.append(float(neighbor.nn_distance))

    metal_shells = []
    for index, site in enumerate(structure):
        if site.specie.symbol in {"Mn", "W"}:
            metal_shells.append(
                {
                    "site": f"{site.specie.symbol}{index + 1}",
                    "six_nearest_oxygen_angstrom": coordination_shell(
                        structure, index, "O", 6
                    ),
                }
            )
    return {
        "path": path.name,
        "reduced_formula": structure.composition.reduced_formula,
        "composition": str(structure.composition),
        "space_group": analyzer.get_space_group_symbol(),
        "space_group_number": analyzer.get_space_group_number(),
        "volume_angstrom3": structure.volume,
        "minimum_pair_distance_angstrom": min(pair_distances),
        "metal_oxygen_shells": metal_shells,
    }


def main() -> None:
    result = [inspect(WORKSPACE / name) for name in ("MnWO4.cif", "WO3.cif")]
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
