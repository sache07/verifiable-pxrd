#!/usr/bin/env python3
"""Add one COD candidate to a converged GSAS-II project and test its scale/cell."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def phase_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    products = []
    for phase in project.phases():
        scale = phase.data["Histograms"][hist.name]["Scale"][0]
        mass = phase.data["General"]["Mass"]
        products.append(scale * mass)
    total = sum(products)
    return {
        phase.name: float(value / total)
        for phase, value in zip(project.phases(), products)
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_gpx")
    parser.add_argument("outdir")
    parser.add_argument("cod_id")
    args = parser.parse_args()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    source = cod_path(args.cod_id)
    if not source.is_file():
        raise FileNotFoundError(source)

    project = G2.G2Project(
        gpxfile=str(Path(args.source_gpx).resolve()),
        newgpx=str(outdir / "working.gpx"),
    )
    hist = project.histogram(0)
    main_phase = project.phase(0)
    candidate = project.add_phase(
        str(source),
        phasename=f"COD_{args.cod_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    main_hap = main_phase.data["Histograms"][hist.name]
    cand_hap = candidate.data["Histograms"][hist.name]
    main_product = main_hap["Scale"][0] * main_phase.data["General"]["Mass"]
    cand_mass = candidate.data["General"]["Mass"]
    # Start at 5 wt%; this is large enough for stable derivatives but small
    # enough not to overwhelm a minor residual family.
    cand_hap["Scale"] = [main_product * (0.05 / 0.95) / cand_mass, True]
    cand_hap["Size"][0] = "isotropic"
    cand_hap["Size"][1][0] = 1.0
    cand_hap["Size"][2] = [False, False, False]
    cand_hap["Mustrain"][0] = "isotropic"
    cand_hap["Mustrain"][1][0] = 0.0
    cand_hap["Mustrain"][2] = [False, False, False]
    cand_hap["Pref.Ori."][0] = "MD"
    cand_hap["Pref.Ori."][1] = 1.0
    cand_hap["Pref.Ori."][2] = False
    cand_hap["Pref.Ori."][3] = [0, 0, 1]
    cand_hap["Extinction"] = [0.0, False]
    candidate.set_refinements({"Cell": True})
    main_phase.set_HAP_refinements({"Scale": True})
    project.save()

    project.set_Controls("cycles", 25)
    project.refine()
    project.save()
    candidate.export_CIF(str(outdir / "candidate.cif"))
    main_phase.export_CIF(str(outdir / "main.cif"))
    info = {
        "cod_id": args.cod_id,
        "formula": candidate.data["General"].get("Name", candidate.name),
        "space_group": candidate.data["General"]["SGData"]["SpGrp"],
        "wR_percent": hist.get_wR(),
        "weight_fractions": phase_fractions(project),
        "candidate_scale": cand_hap["Scale"][0],
        "candidate_mass": cand_mass,
        "candidate_cell": candidate.get_cell(),
        "frozen": project.get_Frozen(),
    }
    (outdir / "result.json").write_text(json.dumps(info, indent=2) + "\n")
    print(json.dumps(info, indent=2), flush=True)


if __name__ == "__main__":
    main()
