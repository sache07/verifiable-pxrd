#!/usr/bin/env python3
"""Test a tightly bounded oxygen-coordinate refinement for MnWO4."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_gpx")
    parser.add_argument("outdir")
    parser.add_argument("--fractional-bound", type=float, default=0.008)
    args = parser.parse_args()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(Path(args.source_gpx).resolve()),
        newgpx=str(outdir / "working.gpx"),
    )
    project.save()
    phase = project.phase(0)
    hist = project.histogram(0)
    before = {
        atom.label: list(atom.coordinates)
        for atom in phase.atoms()
    }

    bound = float(args.fractional_bound)
    for atom_index in (2, 3):
        for axis in ("x", "y", "z"):
            variable = f"0::dA{axis}:{atom_index}"
            project.set_Controls("parmMin", -bound, variable=variable)
            project.set_Controls("parmMax", bound, variable=variable)
    phase.set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
    project.set_Controls("cycles", 15)
    project.refine()
    project.save()
    phase.export_CIF(str(outdir / "bounded_oxygen.cif"))
    info = {
        "wR_percent": hist.get_wR(),
        "fractional_bound": bound,
        "before": before,
        "after": {atom.label: list(atom.coordinates) for atom in phase.atoms()},
        "frozen": project.get_Frozen(),
        "cell": phase.get_cell(),
    }
    (outdir / "result.json").write_text(json.dumps(info, indent=2) + "\n")
    print(json.dumps(info, indent=2), flush=True)


if __name__ == "__main__":
    main()
