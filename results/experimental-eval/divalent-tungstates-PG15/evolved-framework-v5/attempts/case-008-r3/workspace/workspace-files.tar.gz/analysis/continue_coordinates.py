#!/usr/bin/env python3
"""Continue a GSAS-II refinement with heavy-to-light coordinate stages."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(0)
    atoms = []
    for atom in phase.atoms():
        atoms.append(
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(atom.coordinates),
                "occupancy": atom.occupancy,
                "flags": atom.refinement_flags,
                "raw_adp": atom.data[9:17],
            }
        )
    return {
        "stage": label,
        "wR_percent": hist.get_wR(),
        "cell": phase.get_cell(),
        "atoms": atoms,
        "vary_list": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
        "variables": project.data.get("Covariance", {}).get("data", {}).get("variables", []).tolist()
        if hasattr(project.data.get("Covariance", {}).get("data", {}).get("variables", []), "tolist")
        else project.data.get("Covariance", {}).get("data", {}).get("variables", []),
    }


def checkpoint(project: G2.G2Project, outdir: Path, label: str) -> dict:
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    project.phase(0).export_CIF(str(outdir / f"{label}.cif"))
    info = state(project, label)
    print(json.dumps(info, indent=2, default=str), flush=True)
    return info


def run_refinement(project: G2.G2Project, outdir: Path, label: str, cycles: int = 10) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine()
    return checkpoint(project, outdir, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_gpx")
    parser.add_argument("outdir")
    args = parser.parse_args()

    source = Path(args.source_gpx).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(outdir / "working.gpx"))
    phase = project.phase(0)

    records = [checkpoint(project, outdir, "00_input")]

    phase.set_refinements({"Atoms": {"W1": "X"}})
    records.append(run_refinement(project, outdir, "01_W_position"))

    phase.set_refinements({"Atoms": {"Mn1": "X"}})
    records.append(run_refinement(project, outdir, "02_Mn_position"))

    phase.set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
    records.append(run_refinement(project, outdir, "03_O_positions", cycles=15))

    (outdir / "stages.json").write_text(json.dumps(records, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
