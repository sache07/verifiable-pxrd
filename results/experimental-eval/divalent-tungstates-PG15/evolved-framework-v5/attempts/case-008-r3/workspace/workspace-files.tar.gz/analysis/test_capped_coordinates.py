#!/usr/bin/env python3
"""Evaluate a physical coordinate step capped by Cartesian displacement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def metric_from_cell(cell: dict) -> np.ndarray:
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    alpha = np.deg2rad(cell["angle_alpha"])
    beta = np.deg2rad(cell["angle_beta"])
    gamma = np.deg2rad(cell["angle_gamma"])
    return np.array(
        [
            [a * a, a * b * np.cos(gamma), a * c * np.cos(beta)],
            [a * b * np.cos(gamma), b * b, b * c * np.cos(alpha)],
            [a * c * np.cos(beta), b * c * np.cos(alpha), c * c],
        ]
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_gpx")
    parser.add_argument("direction_gpx")
    parser.add_argument("outdir")
    parser.add_argument("--max-displacement", type=float, required=True)
    args = parser.parse_args()

    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(Path(args.source_gpx).resolve()),
        newgpx=str(outdir / "working.gpx"),
    )
    direction = G2.G2Project(gpxfile=str(Path(args.direction_gpx).resolve()))
    phase = project.phase(0)
    dphase = direction.phase(0)
    metric = metric_from_cell(phase.get_cell())
    shifts = {}

    for label in ("O1", "O2"):
        atom = phase.atom(label)
        target = np.asarray(dphase.atom(label).coordinates, float)
        start = np.asarray(atom.coordinates, float)
        delta = target - start
        delta -= np.round(delta)
        trial_norm = float(np.sqrt(delta @ metric @ delta))
        scale = min(1.0, args.max_displacement / trial_norm)
        applied = delta * scale
        atom.coordinates = tuple(start + applied)
        atom.refinement_flags = ""
        shifts[label] = {
            "unbounded_displacement_A": trial_norm,
            "applied_displacement_A": float(np.sqrt(applied @ metric @ applied)),
            "fractional_shift": applied.tolist(),
        }

    project.set_Controls("cycles", 15)
    project.refine()
    project.save()
    phase.export_CIF(str(outdir / "capped_coordinates.cif"))
    info = {
        "wR_percent": project.histogram(0).get_wR(),
        "max_displacement_A": args.max_displacement,
        "shifts": shifts,
        "coordinates": {atom.label: list(atom.coordinates) for atom in phase.atoms()},
        "cell": phase.get_cell(),
    }
    (outdir / "result.json").write_text(json.dumps(info, indent=2) + "\n")
    print(json.dumps(info, indent=2), flush=True)


if __name__ == "__main__":
    main()
