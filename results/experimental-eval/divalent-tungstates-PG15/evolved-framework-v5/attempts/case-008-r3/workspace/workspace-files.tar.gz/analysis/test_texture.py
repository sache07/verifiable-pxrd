#!/usr/bin/env python3
"""Test one bounded March-Dollase preferred-orientation axis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_gpx")
    parser.add_argument("outdir")
    parser.add_argument("axis", nargs=3, type=int)
    args = parser.parse_args()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(Path(args.source_gpx).resolve()),
        newgpx=str(outdir / "working.gpx"),
    )
    hist = project.histogram(0)
    phase = project.phase(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(args.axis)
    project.set_Controls("parmMin", 0.70, variable="0:0:MD")
    project.set_Controls("parmMax", 1.40, variable="0:0:MD")
    physical_limits = {
        ":*:U": (0.0, 40.0),
        ":*:W": (2.0, 40.0),
        ":*:X": (0.1, 6.0),
        ":*:SH/L": (0.005, 0.10),
        ":*:Polariz.": (0.5, 1.0),
        ":*:Shift": (-800.0, 800.0),
    }
    for variable, (lower, upper) in physical_limits.items():
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    project.set_Controls("cycles", 15)
    project.refine()
    project.save()
    phase.export_CIF(str(outdir / "phase.cif"))
    info = {
        "axis": args.axis,
        "MD_ratio": hap["Pref.Ori."][1],
        "wR_percent": hist.get_wR(),
        "frozen": project.get_Frozen(),
        "vary_list": project.data["Covariance"]["data"].get("varyList", []),
    }
    (outdir / "result.json").write_text(json.dumps(info, indent=2) + "\n")
    print(json.dumps(info, indent=2), flush=True)


if __name__ == "__main__":
    main()
