#!/usr/bin/env python3
"""Export the accepted full-grid GSAS-II replay and submission artifacts."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


WORKSPACE = Path(__file__).resolve().parents[1]
SOURCE = WORKSPACE / "analysis" / "trials" / "final_uiso2" / "working.gpx"
FINAL_GPX = WORKSPACE / "final.gpx"

PHASE_METADATA = {
    "COD_1520200": {
        "name": "wolframite MnWO4",
        "formula": "MnWO4",
        "cif_path": "MnWO4.cif",
        "reference": "COD 1520200",
    },
    "COD_2311041": {
        "name": "monoclinic WO3",
        "formula": "WO3",
        "cif_path": "WO3.cif",
        "reference": "COD 2311041",
    },
}


def fraction_esds(project: G2.G2Project, products: list[float]) -> list[float]:
    """Propagate the final scale covariance into normalized phase fractions."""
    covariance = project.data["Covariance"]["data"]
    vary = list(covariance["varyList"])
    matrix = np.asarray(covariance["covMatrix"], dtype=float)
    total = float(sum(products))
    fractions = np.asarray(products, dtype=float) / total
    masses = [float(phase.data["General"]["Mass"]) for phase in project.phases()]
    scales = [
        float(phase.data["Histograms"][project.histogram(0).name]["Scale"][0])
        for phase in project.phases()
    ]

    esds = []
    for target, fraction in enumerate(fractions):
        gradient = np.zeros(len(vary), dtype=float)
        for source in range(len(products)):
            variable = f"{source}:0:Scale"
            if variable not in vary:
                continue
            # d(w_target)/d(scale_source), including normalization.
            if source == target:
                derivative = masses[source] * (1.0 - fraction) / total
            else:
                derivative = -fraction * masses[source] / total
            gradient[vary.index(variable)] = derivative
        variance = float(gradient @ matrix @ gradient)
        esds.append(float(np.sqrt(max(variance, 0.0))))
    return esds


def main() -> None:
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL_GPX))
    project.save()
    hist = project.histogram(0)
    profile = hist.data["data"][1]
    x, observed, _weights, calculated, background, stored_difference = profile
    difference = observed - calculated
    if not np.allclose(difference, stored_difference, rtol=0.0, atol=1e-7):
        raise RuntimeError("GSAS-II difference profile is inconsistent with observed-calculated")

    with (WORKSPACE / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference", "background"]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    phases = project.phases()
    products = []
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        products.append(float(hap["Scale"][0] * phase.data["General"]["Mass"]))
    total = float(sum(products))
    fractions = [value / total for value in products]
    esds = fraction_esds(project, products)

    phase_results = []
    for phase, fraction, esd in zip(phases, fractions, esds):
        metadata = PHASE_METADATA[phase.name]
        phase.export_CIF(str(WORKSPACE / metadata["cif_path"]))
        cell = phase.get_cell()
        phase_results.append(
            {
                "name": metadata["name"],
                "formula": metadata["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": metadata["cif_path"],
                "weight_fraction": fraction,
                "weight_fraction_statistical_esd": esd,
                "weight_percent": 100.0 * fraction,
                "reference_model": metadata["reference"],
                "unit_cell": {
                    "a_angstrom": cell["length_a"],
                    "b_angstrom": cell["length_b"],
                    "c_angstrom": cell["length_c"],
                    "alpha_deg": cell["angle_alpha"],
                    "beta_deg": cell["angle_beta"],
                    "gamma_deg": cell["angle_gamma"],
                    "volume_angstrom3": cell["volume"],
                },
            }
        )

    summary = hist.data["data"][0]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "schema_version": 1,
        "refinement_histogram": hist.name,
        "phases": phase_results,
        "fit_statistics": {
            "rwp_percent": float(summary["wR"]),
            "rp_percent": float(summary["R"]),
            "gof": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_variables": int(rvals["Nvars"]),
            "durbin_watson": float(summary["Durbin-Watson"]),
            "converged": bool(rvals["converged"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
        },
        "profile_path": "fit.csv",
        "gsas_project_path": "final.gpx",
        "fraction_basis": "Normalized scale times unit-cell mass over modeled crystalline phases",
    }
    (WORKSPACE / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
