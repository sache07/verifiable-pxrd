#!/usr/bin/env python3
"""Create a compact diagnostic plot of the submitted full-grid fit."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


WORKSPACE = Path(__file__).resolve().parents[1]


def main() -> None:
    data = np.genfromtxt(WORKSPACE / "fit.csv", delimiter=",", names=True)
    x = data["two_theta_deg"]
    observed = data["observed"]
    calculated = data["calculated"]
    difference = data["difference"]

    fig, axes = plt.subplots(3, 1, figsize=(14, 10), constrained_layout=True)
    ranges = [(9.9, 42.0), (42.0, 72.0), (72.0, 100.1)]
    for axis, (low, high) in zip(axes, ranges):
        use = (x >= low) & (x <= high)
        axis.plot(x[use], observed[use], color="black", lw=0.65, label="observed")
        axis.plot(x[use], calculated[use], color="#c62828", lw=0.8, label="calculated")
        axis.plot(x[use], difference[use] - 700.0, color="#1565c0", lw=0.55, label="difference - 700")
        axis.axhline(-700.0, color="0.6", lw=0.5)
        axis.set_xlim(low, high)
        axis.set_ylabel("counts")
    axes[0].legend(loc="upper right", ncol=3, fontsize=8)
    axes[-1].set_xlabel(r"2$\theta$ (degrees)")
    fig.savefig(WORKSPACE / "analysis" / "final_fit_diagnostic.png", dpi=180)


if __name__ == "__main__":
    main()
