#!/usr/bin/env python3
"""Refine bounded angular calibration and axial-divergence asymmetry."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def report(project: G2.G2Project, outdir: Path, label: str) -> dict:
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    project.phase(0).export_CIF(str(outdir / f"{label}.cif"))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    info = {
        "stage": label,
        "wR_percent": hist.get_wR(),
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "shift_um": sample["Shift"][0],
        "cell": project.phase(0).get_cell(),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(info, indent=2, default=str), flush=True)
    return info


def refine(project: G2.G2Project, outdir: Path, label: str, cycles: int = 15) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine()
    return report(project, outdir, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_gpx")
    parser.add_argument("outdir")
    args = parser.parse_args()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(Path(args.source_gpx).resolve()),
        newgpx=str(outdir / "working.gpx"),
    )
    hist = project.histogram(0)
    records = [report(project, outdir, "00_input")]

    project.set_Controls("parmMin", -0.25, variable=":*:Zero")
    project.set_Controls("parmMax", 0.25, variable=":*:Zero")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    records.append(refine(project, outdir, "01_zero"))

    project.set_Controls("parmMin", 0.005, variable=":*:SH/L")
    project.set_Controls("parmMax", 0.10, variable=":*:SH/L")
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    records.append(refine(project, outdir, "02_SHL"))

    (outdir / "stages.json").write_text(json.dumps(records, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
