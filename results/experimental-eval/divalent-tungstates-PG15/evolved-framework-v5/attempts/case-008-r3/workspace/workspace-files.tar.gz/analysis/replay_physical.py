#!/usr/bin/env python3
"""Replay a selected checkpoint with all accepted physical limits active."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_gpx")
    parser.add_argument("outdir")
    parser.add_argument(
        "--full-grid",
        action="store_true",
        help="include every observed point in the refinement and profile",
    )
    parser.add_argument(
        "--physical-minor-adps",
        action="store_true",
        help="replace zero placeholder WO3 ADPs with fixed physical values",
    )
    args = parser.parse_args()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    project = G2.G2Project(
        gpxfile=str(Path(args.source_gpx).resolve()),
        newgpx=str(outdir / "working.gpx"),
    )
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    if args.full_grid:
        x = hist.data["data"][1][0]
        hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    if args.physical_minor_adps:
        minor = project.phase(1)
        for atom in minor.data["Atoms"]:
            atom[9] = "I"
            atom[10] = 0.005 if atom[1].strip() == "W" else 0.008

    # SurfRoughA reached the physically allowed lower limit in the preceding
    # branch. Keep that value fixed and clear the historical frozen marker so
    # that this is a clean, independently replayed checkpoint.
    sample["SurfRoughA"] = [0.05, False]
    project.set_Frozen()

    limits = {
        ":*:Polariz.": (0.50, 1.00),
        ":*:SH/L": (0.005, 0.10),
        ":*:X": (0.10, 6.00),
        ":*:Shift": (-800.0, 800.0),
        ":*:SurfRoughB": (0.02, 0.50),
        "0:0:Scale": (0.0, None),
        "1:0:Scale": (0.0, None),
        "0:0:MD": (0.70, 1.40),
        "0:0:Mustrain;i": (300.0, 8000.0),
        "1:0:Mustrain;i": (300.0, 8000.0),
    }
    for variable, (minimum, maximum) in limits.items():
        if minimum is not None:
            project.set_Controls("parmMin", minimum, variable=variable)
        if maximum is not None:
            project.set_Controls("parmMax", maximum, variable=variable)

    project.set_Controls("cycles", 25)
    project.save()
    project.refine()
    project.save()

    products = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        products.append(hap["Scale"][0] * phase.data["General"]["Mass"])
        phases.append(
            {
                "name": phase.name,
                "scale": hap["Scale"],
                "cell": phase.get_cell(),
                "mustrain": hap["Mustrain"],
                "size": hap["Size"],
            }
        )
    total = sum(products)
    for phase, product in zip(phases, products):
        phase["weight_fraction"] = product / total

    covariance = project.data["Covariance"]["data"]
    report = {
        "wR_percent": hist.get_wR(),
        "Rvals": covariance.get("Rvals", {}),
        "phases": phases,
        "sample": sample,
        "frozen": project.get_Frozen(),
    }
    (outdir / "replay.json").write_text(json.dumps(report, indent=2, default=str) + "\n")
    print(json.dumps(report, indent=2, default=str), flush=True)


if __name__ == "__main__":
    main()
