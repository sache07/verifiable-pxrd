#!/usr/bin/env python3
"""Build and refine a trial GSAS-II project for the PXRD specimen.

This is intentionally a small, deterministic driver around GSASIIscriptable.
It keeps a project checkpoint after every refinement stage so that numerical or
physical regressions can be rolled back.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


WORKSPACE = Path(__file__).resolve().parents[1]
PATTERN = WORKSPACE / "inputs" / "pattern.csv"
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def instrument_text() -> str:
    return (
        "#GSAS-II Cu K-alpha Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def prepare_observed(outdir: Path) -> tuple[Path, Path]:
    arr = np.genfromtxt(PATTERN, delimiter=",", names=True)
    x = np.asarray(arr["two_theta_deg"], float)
    y = np.asarray(arr["intensity"], float)
    # Counting statistics are the only defensible pointwise weights when the
    # raw counts have no supplied uncertainties.
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = outdir / "observed.xye"
    np.savetxt(xye, np.column_stack([x, y, sigma]), fmt="%.8f %.8f %.8f")
    inst = outdir / "instrument.instprm"
    inst.write_text(instrument_text())
    return xye, inst


def summary(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "stage": label,
        "wR_percent": hist.get_wR(),
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
            if key in inst
        },
        "sample": {
            key: sample[key][0] if isinstance(sample.get(key), list) else sample.get(key)
            for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if key in sample
        },
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "hap_scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    print(json.dumps(result, indent=2, default=str), flush=True)
    return result


def checkpoint(project: G2.G2Project, outdir: Path, label: str) -> dict:
    project.save()
    target = outdir / f"{label}.gpx"
    shutil.copy2(project.filename, target)
    return summary(project, label)


def refine(project: G2.G2Project, outdir: Path, label: str, cycles: int = 8) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine()
    return checkpoint(project, outdir, label)


def build(args: argparse.Namespace) -> None:
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    xye, instfile = prepare_observed(outdir)
    project = G2.G2Project(newgpx=str(outdir / "working.gpx"))

    phases = []
    for cod_id in args.cod_ids:
        source = cod_path(cod_id)
        if not source.is_file():
            raise FileNotFoundError(source)
        phases.append(
            project.add_phase(str(source), phasename=f"COD_{cod_id}", fmthint="CIF")
        )
    hist = project.add_powder_histogram(
        str(xye), str(instfile), phases=phases, fmthint="xye"
    )
    hist.set_refinements({"Limits": [float(args.low), float(args.high)]})

    sample = hist.data["Sample Parameters"]
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [-500.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.2, False]
    sample["SurfRoughB"] = [0.0, False]

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [1000.0] + [0.0] * 9,
                "refine": False,
            }
        }
    )
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / len(phases), False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]

    records = [checkpoint(project, outdir, "00_initial")]

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1", "no. coeffs": 10, "refine": True
            }
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    records.append(refine(project, outdir, "01_scale_background", cycles=15))

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    records.append(refine(project, outdir, "02_cell_shift", cycles=20))

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    records.append(refine(project, outdir, "03_profile_W_X", cycles=15))

    hist.set_refinements({"Instrument Parameters": ["U"]})
    records.append(refine(project, outdir, "04_profile_U", cycles=12))

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    records.append(refine(project, outdir, "05_polarization", cycles=10))

    (outdir / "stages.json").write_text(json.dumps(records, indent=2, default=str) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("outdir")
    parser.add_argument("cod_ids", nargs="+")
    parser.add_argument("--low", type=float, default=10.0)
    parser.add_argument("--high", type=float, default=100.0)
    build(parser.parse_args())


if __name__ == "__main__":
    main()
