#!/usr/bin/env python3
"""Test physical isotropic displacement models for the accepted phase."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def make_isotropic(phase, uiso: float, refine_elements: set[str]) -> None:
    pid = phase.data["pId"]
    project = phase.proj
    for index, atom in enumerate(phase.atoms()):
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = float(uiso)
        for j in range(2, 8):
            atom.data[atom.cia + j] = 0.0
        atom.refinement_flags = "XU" if atom.element in refine_elements else "X"
        variable = f"{pid}::AUiso:{index}"
        project.set_Controls("parmMin", 0.001, variable=variable)
        project.set_Controls("parmMax", 0.05, variable=variable)


def run(source: Path, root: Path, label: str, uiso: float, refine_elements: set[str]) -> dict:
    folder = root / label
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "branch.gpx"
    shutil.copyfile(source, path)
    project = G2.G2Project(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    phase = project.phase(0)
    hist.data["Sample Parameters"]["SurfRoughA"][1] = False
    hist.data["Sample Parameters"]["SurfRoughB"][1] = False
    make_isotropic(phase, uiso, refine_elements)
    project.refine()
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "label": label,
        "path": str(path),
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "uiso_A2": {atom.label: float(atom.data[atom.cia + 1]) for atom in phase.atoms()},
        "cell": phase.get_cell(),
        "coordinates": {atom.label: list(atom.coordinates) for atom in phase.atoms()},
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(row, indent=2))
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, default=Path("analysis/adp_branches"))
    args = parser.parse_args()
    source = args.source.resolve()
    root = args.out.resolve()
    specs = []
    for uiso in (0.003, 0.005, 0.008, 0.010, 0.015, 0.020):
        specs.append((f"common_fixed_{uiso:.3f}".replace(".", "p"), uiso, set()))
    specs.extend(
        [
            ("heavy_refined", 0.010, {"Mn", "W"}),
            ("oxygen_refined", 0.010, {"O"}),
            ("all_refined", 0.010, {"Mn", "W", "O"}),
        ]
    )
    rows = []
    for label, uiso, elements in specs:
        try:
            rows.append(run(source, root, label, uiso, elements))
        except Exception as exc:
            row = {"label": label, "error": repr(exc)}
            rows.append(row)
            print(json.dumps(row, indent=2))
    (root / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
