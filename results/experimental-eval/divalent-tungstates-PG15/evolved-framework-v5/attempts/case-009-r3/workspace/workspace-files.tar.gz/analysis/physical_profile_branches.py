#!/usr/bin/env python3
"""Refit a physical V=0 profile with optional isotropic/uniaxial strain."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def run(source: Path, root: Path, spec: dict) -> dict:
    folder = root / spec["label"]
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "branch.gpx"
    shutil.copyfile(source, path)
    project = G2.G2Project(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 16)
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    for key, value in (("U", 30.0), ("V", 0.0), ("W", 30.0), ("X", 4.0), ("SH/L", 0.03)):
        inst[key][1] = value
    inst["U"][2] = True
    inst["V"][2] = False
    inst["W"][2] = True
    inst["X"][2] = True
    inst["SH/L"][2] = True
    hist.data["Sample Parameters"]["SurfRoughA"][1] = False
    hist.data["Sample Parameters"]["SurfRoughB"][1] = False
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][1][2] = 1.0
    hap["Size"][2] = [False, False, False]
    strain = hap["Mustrain"]
    strain[0] = spec["type"]
    strain[1][0] = float(spec.get("equatorial", 0.0))
    strain[1][1] = float(spec.get("axial", 0.0))
    strain[1][2] = 1.0
    strain[2] = [spec.get("refine", False), spec["type"] == "uniaxial" and spec.get("refine", False), False]
    strain[3] = list(spec.get("axis", [0, 0, 1]))
    pid = phase.data["pId"]
    hid = hist.data["data"][0]["hId"]
    bounds = {
        f":{hid}:U": (0.0, 1000.0),
        f":{hid}:W": (0.0, 1000.0),
        f":{hid}:X": (0.0, 100.0),
        f":{hid}:SH/L": (0.002, 0.2),
        f"{pid}:{hid}:Mustrain;i": (0.0, 30000.0),
        f"{pid}:{hid}:Mustrain;a": (0.0, 30000.0),
    }
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    project.refine()
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "label": spec["label"],
        "path": str(path),
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "profile": {key: float(inst[key][1]) for key in ("U", "V", "W", "X", "SH/L")},
        "strain_type": strain[0],
        "strain_values_ppm": [float(v) for v in strain[1][:2]],
        "strain_axis": list(strain[3]),
        "cell": phase.get_cell(),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(row, indent=2))
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, default=Path("analysis/physical_profile_branches"))
    args = parser.parse_args()
    specs = [{"label": "no_strain", "type": "isotropic", "refine": False}]
    specs.append({"label": "isotropic_strain", "type": "isotropic", "equatorial": 1000.0, "refine": True})
    axes = {"001": [0, 0, 1], "100": [1, 0, 0], "010": [0, 1, 0], "110": [1, 1, 0], "111": [1, 1, 1]}
    for name, axis in axes.items():
        for tag, ratio in (("r0p5", 0.5), ("r2", 2.0)):
            specs.append(
                {
                    "label": f"uniaxial_{name}_{tag}",
                    "type": "uniaxial",
                    "equatorial": 1000.0,
                    "axial": 1000.0 * ratio,
                    "axis": axis,
                    "refine": True,
                }
            )
    rows = []
    for spec in specs:
        try:
            rows.append(run(args.source.resolve(), args.out.resolve(), spec))
        except Exception as exc:
            row = {"label": spec["label"], "error": repr(exc)}
            rows.append(row)
            print(json.dumps(row, indent=2))
    (args.out / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
