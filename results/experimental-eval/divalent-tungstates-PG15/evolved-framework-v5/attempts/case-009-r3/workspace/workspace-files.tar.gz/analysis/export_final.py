#!/usr/bin/env python3
"""Export the accepted GSAS-II checkpoint and human-readable deliverables."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def sf(value: object) -> float:
    return float(value)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("prediction", type=Path)
    parser.add_argument("--root", type=Path, default=Path("."))
    args = parser.parse_args()

    root = args.root.resolve()
    source = args.source.resolve()
    final_project = root / "final.gpx"
    shutil.copyfile(source, final_project)

    project = G2.G2Project(str(final_project))
    histogram = project.histogram(0)
    phase = project.phase(0)
    cif_name = "phase_MnWO4.cif"
    phase.export_CIF(str(root / cif_name))

    with np.load(args.prediction.resolve(), allow_pickle=False) as replay:
        x = np.asarray(replay["x"], dtype=float)
        observed = np.asarray(replay["observed"], dtype=float)
        calculated = np.asarray(replay["predicted"], dtype=float)
        background = np.asarray(replay["background"], dtype=float)
    difference = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = sf(np.sum(weights * difference**2))
    denominator = sf(np.sum(weights * observed**2))
    rwp = 100.0 * np.sqrt(chi_square / denominator)
    rp = 100.0 * sf(np.sum(np.abs(difference)) / np.sum(np.abs(observed)))

    covariance = project.data.get("Covariance", {}).get("data", {})
    rvalues = covariance.get("Rvals", {})
    nvars = int(rvalues.get("Nvars", len(covariance.get("varyList", []))))
    nobs = int(rvalues.get("Nobs", len(x)))
    dof = nobs - nvars
    gof = np.sqrt(chi_square / dof)
    cell, cell_esd = phase.get_cell_and_esd()
    instrument = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    hap = phase.data["Histograms"][histogram.name]
    pref = hap["Pref.Ori."]
    atoms = phase.atoms()

    np.savetxt(
        root / "fit.csv",
        np.column_stack([x, observed, calculated, difference, background]),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt="%.10g",
    )

    result = {
        "phases": [
            {
                "name": "MnWO4 (wolframite)",
                "formula": "MnWO4",
                "space_group": "P 2/c",
                "space_group_number": 13,
                "cif_path": cif_name,
                "weight_fraction": 1.0,
                "weight_fraction_basis": "normalized over modeled crystalline phases",
                "unit_cell": {key: sf(value) for key, value in cell.items()},
                "unit_cell_esd": {key: sf(value) for key, value in cell_esd.items()},
            }
        ],
        "fit_statistics": {
            "rwp_percent": sf(rwp),
            "rp_percent": sf(rp),
            "chi_square": chi_square,
            "goodness_of_fit": sf(gof),
            "observations": nobs,
            "refined_variables": nvars,
            "weighting": "1/max(observed_counts,1); no pointwise uncertainties supplied",
            "evaluation_range_two_theta_deg": [sf(x[0]), sf(x[-1])],
        },
        "calibration": {
            "zero_offset_deg": sf(instrument["Zero"][1]),
            "specimen_displacement_um": sf(sample["Shift"][0]),
            "specimen_displacement_refined_in_final_cycle": bool(sample["Shift"][1]),
        },
        "refinement_histogram": histogram.name,
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
    }
    (root / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

    uiso = {atom.label: sf(atom.data[atom.cia + 1]) for atom in atoms}
    report = f"""# Powder XRD phase analysis

## Result

The modeled crystalline material is single-phase **MnWO4, wolframite type** (monoclinic `P 2/c`, No. 13). Its weight fraction is **1.000 (100 wt%) after normalization over the modeled crystalline phases**. This is not an absolute crystallinity measurement: an amorphous fraction or a crystalline impurity below the pattern's detection sensitivity cannot be quantified without an internal standard.

The refined cell is `a = {cell['length_a']:.6f}({cell_esd['length_a']*1e6:.0f}) A`, `b = {cell['length_b']:.6f}({cell_esd['length_b']*1e6:.0f}) A`, `c = {cell['length_c']:.6f}({cell_esd['length_c']*1e6:.0f}) A`, `beta = {cell['angle_beta']:.5f}({cell_esd['angle_beta']*1e5:.0f}) deg`, and `V = {cell['volume']:.5f} A^3`. Formal standard uncertainties are conditional on the chosen calibration model.

## Evidence and model selection

The Mn-W-O reference index contains an exact-composition wolframite MnWO4 model (COD 1520200) and Mn3WO6 (COD 2002703). The wolframite model accounts for the complete observed reflection family, including the diagnostic low-angle lines near 15.67 and 18.63 deg 2theta and the dense higher-angle sequence. Mn3WO6 predicts strong lines near 19.95, 20.49, 28.75, and 35.24 deg that are absent. Separate Mn3O4, Mn oxides, or WO3 precursor phases did not form coherent residual families. After the full MnWO4 refinement, the remaining maxima are shoulders or intensity residuals at MnWO4 reflections rather than an independently indexable family, so phase searching was stopped.

COD 1520200 supplied the topology only; its reported high-pressure cell and all atomic parameters used here were refined against this specimen. The final geometry remains chemically ordinary: six Mn-O distances span about 2.120-2.315 A and six W-O distances span about 1.762-2.127 A. All occupancies are unity and all refined isotropic displacement parameters are positive (`Uiso`: Mn {uiso['Mn1']:.4f}, W {uiso['W1']:.4f}, O1 {uiso['O1']:.4f}, O2 {uiso['O2']:.4f} A^2). A very weak, reproducible March-Dollase [100] term refined to {pref[1]:.5f}; no microstrain term was retained because the apparent gains were unstable or boundary-limited.

## Fit and uncertainty

The replayed atomic GSAS-II model gives `Rwp = {rwp:.4f}%`, `Rp = {rp:.4f}%`, `chi-square = {chi_square:.2f}`, and `GOF = {gof:.4f}` on all {nobs} measured points. The Cu Kalpha1/Kalpha2 wavelengths and 0.5 intensity ratio from the metadata were fixed. The final project passed an independent no-refinement forward replay with no negative-width, negative-background, displacement-parameter, or scale flags.

Zero offset and reflection-geometry specimen displacement were highly correlated when varied together. The final stable checkpoint fixes the jointly converged displacement at {sample['Shift'][0]:.1f} micrometres and refines the zero offset to {instrument['Zero'][1]:.5f} deg. Consequently, the space group, phase identity, and relative crystalline fraction are reliable, but the quoted cell standard uncertainties do not include the larger systematic uncertainty from that calibration correlation. Oxygen coordinates are also less precise than the heavy-atom framework in this X-ray pattern.
"""
    (root / "report.md").write_text(report)

    print(json.dumps({"final_project": str(final_project), "cif": cif_name, "rwp_percent": rwp, "gof": gof}, indent=2))


if __name__ == "__main__":
    main()
