#!/usr/bin/env python3
"""Test bounded isotropic/uniaxial microstrain branches in GSAS-II."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def run_branch(source: Path, root: Path, spec: dict) -> dict:
    folder = root / spec["label"]
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "branch.gpx"
    shutil.copyfile(source, path)
    project = G2.G2Project(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    strain = hap["Mustrain"]
    strain[0] = spec["type"]
    strain[1][0] = float(spec.get("equatorial", 1000.0))
    strain[1][1] = float(spec.get("axial", 1000.0))
    strain[1][2] = 1.0
    strain[2] = [True, spec["type"] == "uniaxial", False]
    strain[3] = list(spec.get("axis", [0, 0, 1]))
    # Keep the physically interpretable Suortti parameters at the already
    # refined values while assessing peak-width complexity.
    hist.data["Sample Parameters"]["SurfRoughA"][1] = False
    hist.data["Sample Parameters"]["SurfRoughB"][1] = False
    pid = phase.data["pId"]
    hid = hist.data["data"][0]["hId"]
    for term in ("i", "a"):
        variable = f"{pid}:{hid}:Mustrain;{term}"
        project.set_Controls("parmMin", 1.0, variable=variable)
        project.set_Controls("parmMax", 30000.0, variable=variable)
    project.refine()
    project.save()
    strain = phase.data["Histograms"][hist.name]["Mustrain"]
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "label": spec["label"],
        "path": str(path),
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "type": strain[0],
        "values_ppm": [float(v) for v in strain[1][:2]],
        "axis": list(strain[3]),
        "instrument": {
            key: float(hist.data["Instrument Parameters"][0][key][1])
            for key in ("U", "V", "W", "X", "SH/L")
        },
        "cell": phase.get_cell(),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(row, indent=2))
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, default=Path("analysis/profile_branches"))
    args = parser.parse_args()
    source = args.source.resolve()
    root = args.out.resolve()
    specs = [{"label": "isotropic", "type": "isotropic"}]
    axes = {
        "001": [0, 0, 1],
        "100": [1, 0, 0],
        "010": [0, 1, 0],
        "110": [1, 1, 0],
        "111": [1, 1, 1],
    }
    for name, axis in axes.items():
        for ratio_name, ratio in (("r0p5", 0.5), ("r1", 1.0), ("r2", 2.0)):
            specs.append(
                {
                    "label": f"uniaxial_{name}_{ratio_name}",
                    "type": "uniaxial",
                    "axis": axis,
                    "equatorial": 1000.0,
                    "axial": 1000.0 * ratio,
                }
            )
    rows = []
    for spec in specs:
        try:
            rows.append(run_branch(source, root, spec))
        except Exception as exc:
            row = {"label": spec["label"], "error": repr(exc)}
            rows.append(row)
            print(json.dumps(row, indent=2))
    (root / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
