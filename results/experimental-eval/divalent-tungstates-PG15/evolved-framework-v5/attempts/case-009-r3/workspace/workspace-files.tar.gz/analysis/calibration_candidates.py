#!/usr/bin/env python3
"""Remove the zero/displacement covariance while preserving the best profile."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def run(source: Path, root: Path, label: str, fixed_key: str, reset_fixed: bool) -> dict:
    folder = root / label
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "candidate.gpx"
    shutil.copyfile(source, path)
    project = G2.G2Project(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 16)
    histogram = project.histogram(0)
    sample = histogram.data["Sample Parameters"]
    instrument = histogram.data["Instrument Parameters"][0]
    if fixed_key == "Shift":
        if reset_fixed:
            sample["Shift"][0] = 0.0
        sample["Shift"][1] = False
        instrument["Zero"][2] = True
    else:
        if reset_fixed:
            instrument["Zero"][1] = 0.0
        instrument["Zero"][2] = False
        sample["Shift"][1] = True
    project.refine()
    project.save()
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "label": label,
        "path": str(path),
        "rwp_percent": float(histogram.get_wR()),
        "gof": float(covariance.get("Rvals", {}).get("GOF", float("nan"))),
        "zero_deg": float(instrument["Zero"][1]),
        "shift_um": float(sample["Shift"][0]),
        "cell": project.phase(0).get_cell(),
        "maximum_shift_esd": float(max(abs(x) for x in covariance.get("Lastshft", [0.0]))),
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, default=Path("analysis/calibration_candidates"))
    args = parser.parse_args()
    specs = [
        ("fix_refined_shift", "Shift", False),
        ("fix_refined_zero", "Zero", False),
        ("zero_only", "Shift", True),
        ("shift_only", "Zero", True),
    ]
    rows = []
    for label, key, reset in specs:
        try:
            row = run(args.source.resolve(), args.out.resolve(), label, key, reset)
        except Exception as exc:
            row = {"label": label, "error": repr(exc)}
        rows.append(row)
        print(json.dumps(row, indent=2))
    (args.out / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
