#!/usr/bin/env python3
"""Inspect candidate COD structures against the observed powder pattern."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser
from scipy.ndimage import percentile_filter
from scipy.signal import find_peaks


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def show_reference(cod_id: str, cutoff: float) -> None:
    structure = CifParser(cif_path(cod_id)).parse_structures(primitive=False)[0]
    pattern = XRDCalculator(wavelength=1.540598, symprec=0).get_pattern(
        structure, two_theta_range=(9.8, 100.2)
    )
    print(f"\n{cod_id} {structure.composition.reduced_formula} {structure.get_space_group_info()}")
    for x, y, hkls in zip(pattern.x, pattern.y, pattern.hkls):
        if y >= cutoff:
            labels = "/".join(str(item["hkl"]) for item in hkls)
            print(f"  {x:9.4f} {y:8.2f}  {labels}")


def show_observed(path: Path, prominence: float) -> None:
    x, y = np.loadtxt(path, delimiter=",", skiprows=1).T
    # A broad percentile background is robust to the intense crystalline lines.
    points = max(11, round(2.0 / np.median(np.diff(x))))
    background = percentile_filter(y, percentile=35, size=points, mode="nearest")
    residual = y - background
    peaks, props = find_peaks(residual, prominence=prominence, distance=4)
    order = np.argsort(x[peaks])
    print("Observed candidate peaks (2theta, intensity, prominence):")
    for k in order:
        i = peaks[k]
        print(f"  {x[i]:9.4f} {y[i]:9.1f} {props['prominences'][k]:9.1f}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("ids", nargs="*")
    parser.add_argument("--cutoff", type=float, default=5.0)
    parser.add_argument("--observed", type=Path)
    parser.add_argument("--prominence", type=float, default=250.0)
    args = parser.parse_args()
    if args.observed:
        show_observed(args.observed, args.prominence)
    for cod_id in args.ids:
        show_reference(cod_id, args.cutoff)


if __name__ == "__main__":
    main()
