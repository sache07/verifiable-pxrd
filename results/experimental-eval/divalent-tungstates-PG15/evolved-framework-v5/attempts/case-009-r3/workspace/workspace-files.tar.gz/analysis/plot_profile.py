#!/usr/bin/env python3
"""Plot a profile CSV exported by diagnose_project.py."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("profile", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    data = np.genfromtxt(args.profile, delimiter=",", names=True)
    x = data["two_theta_deg"]
    obs = data["observed"]
    calc = data["calculated"]
    diff = data["difference"]
    bkg = data["background"]
    smooth = gaussian_filter1d(diff, 3.2)
    fig, axes = plt.subplots(2, 1, figsize=(16, 8), sharex=True, gridspec_kw={"height_ratios": [3, 1]})
    axes[0].plot(x, obs, color="black", linewidth=0.5, label="Observed")
    axes[0].plot(x, calc, color="#d62728", linewidth=0.7, label="Calculated")
    axes[0].plot(x, bkg, color="#1f77b4", linewidth=0.6, label="Background")
    axes[0].legend(loc="upper right", frameon=False)
    axes[0].set_ylabel("Counts")
    axes[1].axhline(0, color="0.45", linewidth=0.5)
    axes[1].plot(x, diff, color="0.65", linewidth=0.35)
    axes[1].plot(x, smooth, color="#006d2c", linewidth=0.8)
    axes[1].set_ylabel("Observed − calculated")
    axes[1].set_xlabel(r"$2\theta$ (degrees)")
    axes[1].set_xlim(x[0], x[-1])
    fig.tight_layout()
    fig.savefig(args.output, dpi=180)


if __name__ == "__main__":
    main()
