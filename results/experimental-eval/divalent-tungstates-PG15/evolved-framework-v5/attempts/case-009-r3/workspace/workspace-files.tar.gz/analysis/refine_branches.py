#!/usr/bin/env python3
"""Run bounded GSAS-II specimen/profile branches from a physical checkpoint."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def set_refine_flags(hist, *, polarization: bool, rough_a: bool, rough_b: bool) -> None:
    inst = hist.data["Instrument Parameters"][0]
    inst["Polariz."][2] = polarization
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"][1] = rough_a
    sample["SurfRoughB"][1] = rough_b


def physical_summary(project: G2.G2Project, label: str, path: Path) -> dict:
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    x = np.asarray(hist.getdata("X"), float)
    background = np.asarray(hist.getdata("Background"), float)
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "label": label,
        "path": str(path),
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "cell": phase.get_cell(),
        "coordinates": {a.label: list(a.coordinates) for a in phase.atoms()},
        "instrument": {
            key: float(inst[key][1])
            for key in ("Zero", "Polariz.", "U", "V", "W", "X", "SH/L")
        },
        "sample": {
            key: float(sample[key][0])
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "background_min": float(np.min(background)),
        "background_max": float(np.max(background)),
        "frozen": project.get_Frozen(),
    }


def run_one(source: Path, root: Path, spec: dict) -> dict:
    label = spec["label"]
    folder = root / label
    folder.mkdir(parents=True, exist_ok=True)
    destination = folder / "branch.gpx"
    shutil.copyfile(source, destination)
    project = G2.G2Project(str(destination))
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    inst = hist.data["Instrument Parameters"][0]
    sample["SurfRoughA"][0] = float(spec["a"])
    sample["SurfRoughB"][0] = float(spec["b"])
    inst["Polariz."][1] = float(spec.get("polarization", 0.7))
    set_refine_flags(
        hist,
        polarization=spec.get("refine_polarization", False),
        rough_a=spec.get("refine_a", False),
        rough_b=spec.get("refine_b", False),
    )
    hid = hist.data["data"][0]["hId"]
    prefix = f":{hid}:"
    bounds = {
        "Polariz.": (0.0, 1.0),
        "SurfRoughA": (0.0, 1.0),
        "SurfRoughB": (0.0, 1.0),
        "Shift": (-2000.0, 2000.0),
        "SH/L": (0.002, 0.2),
        "X": (0.0, 100.0),
    }
    for name, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=prefix + name)
        project.set_Controls("parmMax", high, variable=prefix + name)
    project.refine()
    project.save()
    return physical_summary(project, label, destination)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, default=Path("analysis/specimen_branches"))
    args = parser.parse_args()
    args.source = args.source.resolve()
    args.out = args.out.resolve()

    specs = [
        {"label": "no_rough_pol", "a": 0.0, "b": 0.0, "refine_polarization": True},
        {"label": "fixed_rough_pol", "a": 0.2, "b": 0.1, "refine_polarization": True},
        {"label": "rough_a_only", "a": 0.2, "b": 0.1, "refine_a": True},
        {"label": "rough_b_only", "a": 0.2, "b": 0.1, "refine_b": True},
        {"label": "rough_both", "a": 0.2, "b": 0.1, "refine_a": True, "refine_b": True},
        {"label": "pol_rough_a", "a": 0.2, "b": 0.1, "refine_polarization": True, "refine_a": True},
        {"label": "pol_rough_b", "a": 0.2, "b": 0.1, "refine_polarization": True, "refine_b": True},
        {"label": "pol_rough_both", "a": 0.2, "b": 0.1, "refine_polarization": True, "refine_a": True, "refine_b": True},
    ]
    for a in (0.02, 0.05, 0.10, 0.30, 0.50):
        specs.append(
            {
                "label": f"pol_b_at_a_{a:.2f}".replace(".", "p"),
                "a": a,
                "b": 0.1,
                "refine_polarization": True,
                "refine_b": True,
            }
        )
    rows = []
    for spec in specs:
        try:
            row = run_one(args.source, args.out, spec)
        except Exception as exc:
            row = {"label": spec["label"], "error": repr(exc)}
        rows.append(row)
        print(json.dumps(row, indent=2))
    (args.out / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
