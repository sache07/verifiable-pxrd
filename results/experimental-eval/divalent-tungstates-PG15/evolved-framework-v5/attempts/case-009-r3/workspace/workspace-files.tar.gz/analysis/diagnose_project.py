#!/usr/bin/env python3
"""Export and diagnose the observed/calculated residual from a GSAS-II GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks, peak_widths

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--out", type=Path, default=Path("analysis/diagnostic"))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    project = G2.G2Project(str(args.project.resolve()))
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"), float)
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    bkg = np.asarray(hist.getdata("Background"), float)
    diff = obs - calc
    np.savetxt(
        args.out / "profile.csv",
        np.column_stack([x, obs, calc, diff, bkg]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt="%.10g",
    )

    step = float(np.median(np.diff(x)))
    smooth = gaussian_filter1d(diff, sigma=max(1.0, 0.035 / step))
    peaks, props = find_peaks(smooth, prominence=25.0, distance=max(2, round(0.08 / step)))
    widths = peak_widths(smooth, peaks, rel_height=0.5)[0] * step
    rows = []
    for k, i in enumerate(peaks):
        rows.append(
            {
                "two_theta_deg": float(x[i]),
                "smoothed_difference": float(smooth[i]),
                "observed": float(obs[i]),
                "calculated": float(calc[i]),
                "prominence": float(props["prominences"][k]),
                "fwhm_deg_approx": float(widths[k]),
            }
        )
    rows.sort(key=lambda row: row["prominence"], reverse=True)
    (args.out / "residual_peaks.json").write_text(json.dumps(rows, indent=2) + "\n")
    for row in rows[:80]:
        print(
            f"{row['two_theta_deg']:9.4f}  diff={row['smoothed_difference']:8.2f} "
            f"prom={row['prominence']:8.2f} width={row['fwhm_deg_approx']:7.4f} "
            f"obs/calc={row['observed']:.1f}/{row['calculated']:.1f}"
        )

if __name__ == "__main__":
    main()
