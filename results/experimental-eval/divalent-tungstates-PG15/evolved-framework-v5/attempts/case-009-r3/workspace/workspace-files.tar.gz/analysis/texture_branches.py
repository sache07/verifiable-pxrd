#!/usr/bin/env python3
"""Test a small set of physically plausible March-Dollase texture axes."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def run(source: Path, root: Path, label: str, axis: list[int], ratio: float) -> dict:
    folder = root / label
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "branch.gpx"
    shutil.copyfile(source, path)
    project = G2.G2Project(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    pref = hap["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = float(ratio)
    pref[2] = True
    pref[3] = list(axis)
    hist.data["Sample Parameters"]["SurfRoughA"][1] = False
    hist.data["Sample Parameters"]["SurfRoughB"][1] = False
    pid = phase.data["pId"]
    hid = hist.data["data"][0]["hId"]
    variable = f"{pid}:{hid}:MD"
    project.set_Controls("parmMin", 0.3, variable=variable)
    project.set_Controls("parmMax", 3.0, variable=variable)
    project.refine()
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "label": label,
        "path": str(path),
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "axis": list(pref[3]),
        "md_ratio": float(pref[1]),
        "cell": phase.get_cell(),
        "coordinates": {a.label: list(a.coordinates) for a in phase.atoms()},
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(row, indent=2))
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, default=Path("analysis/texture_branches"))
    args = parser.parse_args()
    axes = {
        "001": [0, 0, 1],
        "100": [1, 0, 0],
        "010": [0, 1, 0],
        "110": [1, 1, 0],
        "111": [1, 1, 1],
    }
    rows = []
    for name, axis in axes.items():
        for tag, ratio in (("r0p8", 0.8), ("r1p2", 1.2)):
            label = f"md_{name}_{tag}"
            try:
                rows.append(run(args.source.resolve(), args.out.resolve(), label, axis, ratio))
            except Exception as exc:
                row = {"label": label, "error": repr(exc)}
                rows.append(row)
                print(json.dumps(row, indent=2))
    (args.out / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
