#!/usr/bin/env python3
"""Test the final weak-texture term on the accepted positive-ADP model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def run(source: Path, root: Path, label: str, ratio: float, refine: bool) -> dict:
    folder = root / label
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "candidate.gpx"
    shutil.copyfile(source, path)
    project = G2.G2Project(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", 16)
    histogram = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][histogram.name]
    pref = hap["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = float(ratio)
    pref[2] = bool(refine)
    pref[3] = [1, 0, 0]
    histogram.data["Sample Parameters"]["SurfRoughA"][1] = False
    histogram.data["Sample Parameters"]["SurfRoughB"][1] = False
    pid = phase.data["pId"]
    hid = histogram.data["data"][0]["hId"]
    project.set_Controls("parmMin", 0.3, variable=f"{pid}:{hid}:MD")
    project.set_Controls("parmMax", 3.0, variable=f"{pid}:{hid}:MD")
    project.refine()
    project.save()

    covariance = project.data.get("Covariance", {}).get("data", {})
    variables = list(covariance.get("varyList", []))
    sigmas = list(covariance.get("sig", []))
    md_sigma = None
    for variable, sigma in zip(variables, sigmas):
        if str(variable).endswith(":MD"):
            md_sigma = float(sigma)
            break
    return {
        "label": label,
        "path": str(path),
        "rwp_percent": float(histogram.get_wR()),
        "gof": float(covariance.get("Rvals", {}).get("GOF", float("nan"))),
        "md_ratio": float(pref[1]),
        "md_sigma": md_sigma,
        "cell": phase.get_cell(),
        "uiso_A2": {a.label: float(a.data[a.cia + 1]) for a in phase.atoms()},
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, default=Path("analysis/final_candidates"))
    args = parser.parse_args()
    root = args.out.resolve()
    source = args.source.resolve()
    specs = [
        ("no_texture", 1.0, False),
        ("md100_start_0p8", 0.8, True),
        ("md100_start_1p2", 1.2, True),
    ]
    rows = []
    for label, ratio, refine in specs:
        try:
            row = run(source, root, label, ratio, refine)
        except Exception as exc:
            row = {"label": label, "error": repr(exc)}
        rows.append(row)
        print(json.dumps(row, indent=2))
    (root / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
