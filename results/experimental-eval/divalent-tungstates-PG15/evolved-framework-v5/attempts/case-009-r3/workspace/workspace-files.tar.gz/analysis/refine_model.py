#!/usr/bin/env python3
"""Build and refine a full-grid GSAS-II model for the specimen."""

from __future__ import annotations

import argparse
import csv
import json
import shutil
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


DEFAULT_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)


def make_data_files(pattern_csv: Path, work: Path, n_background: int) -> tuple[Path, Path, list[float]]:
    work.mkdir(parents=True, exist_ok=True)
    x, y = np.loadtxt(pattern_csv, delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = work / "observed.xye"
    np.savetxt(xye, np.column_stack([x, y, sigma]), fmt=["%.10f", "%.8f", "%.8f"])

    inst = work / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )

    # Robust low-envelope estimate, represented in GSAS-II's full-range
    # Chebyshev coordinate convention. This is only the refinement start.
    width = max(31, int(round(2.5 / np.median(np.diff(x)))))
    baseline = percentile_filter(y, percentile=30, size=width, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    coeffs = np.polynomial.chebyshev.chebfit(t, baseline, n_background - 1).tolist()
    return xye, inst, coeffs


def set_instrument_value(hist, name: str, value: float) -> None:
    record = hist.data["Instrument Parameters"][0][name]
    record[0] = float(value)
    if len(record) > 1:
        record[1] = float(value)


def snapshot(project: G2.G2Project, checkpoint_dir: Path, label: str) -> None:
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    project.save(str(checkpoint_dir / f"{label}.gpx"))


def report_state(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phase_rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phase_rows.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": [float(v) for v in atom.coordinates],
                        "occupancy": float(atom.occupancy),
                        "refinement_flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
                "hap": {
                    "Size": hap.get("Size"),
                    "Mustrain": hap.get("Mustrain"),
                    "Pref.Ori.": hap.get("Pref.Ori."),
                },
            }
        )
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "chisq": cov.get("Rvals", {}).get("chisq"),
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "instrument": {
            key: float(inst[key][1])
            for key in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
            if key in inst
        },
        "sample": {
            key: (value[0] if isinstance(value, list) else value)
            for key, value in sample.items()
            if key in ("Scale", "Type", "Gonio. radius", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "background": hist.data["Background"][0],
        "phases": phase_rows,
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(row, indent=2, default=str))
    return row


def run_refinement(project: G2.G2Project, label: str, checkpoint_dir: Path, log: list[dict]) -> None:
    project.refine()
    log.append(report_state(project, label))
    snapshot(project, checkpoint_dir, label)


def build(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    work = args.output.parent / "workfiles"
    checkpoints = args.output.parent / "checkpoints"
    xye, inst, background_coeffs = make_data_files(args.pattern, work, args.background_terms)

    project = G2.G2Project(newgpx=str(args.output))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    phase = project.add_phase(str(args.cif), phasename=args.phase_name, histograms=[hist], fmthint="CIF")
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.20, False]
    hist.SampleParameters["SurfRoughB"] = [0.10, False]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": background_coeffs,
                "refine": False,
            }
        }
    )
    phase.data["Histograms"][hist.name]["Scale"][0] = 10.0
    project.set_Controls("cycles", 8)
    project.save()

    log: list[dict] = []
    log.append(report_state(project, "00_initial"))
    snapshot(project, checkpoints, "00_initial")

    # Establish the complete one-phase profile with only scale/background free.
    hist.set_refinements({"Background": {"refine": True}})
    phase.set_HAP_refinements({"Scale": True}, [hist])
    run_refinement(project, "01_scale_background", checkpoints, log)

    # Refine lattice and two physically distinct angular corrections.
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, "02_cell_zero", checkpoints, log)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(project, "03_cell_zero_shift", checkpoints, log)

    # Heavy-atom coordinates first; special-position constraints are supplied
    # by GSAS-II. Keep a checkpoint before every coordinate expansion.
    for atom in phase.atoms():
        if atom.element in {"W", "Mn"}:
            atom.refinement_flags = "X"
    run_refinement(project, "04_heavy_coordinates", checkpoints, log)
    for atom in phase.atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    run_refinement(project, "05_all_coordinates", checkpoints, log)

    # Instrument peak-shape terms. Y and Z remain zero because X already gives
    # the ordinary Caglioti/Lorentzian laboratory form without redundant terms.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]})
    run_refinement(project, "06_instrument_profile", checkpoints, log)

    # Polarization and surface roughness alter relative intensities smoothly;
    # they are deferred until after structural coordinates.
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    run_refinement(project, "07_specimen_intensity", checkpoints, log)

    project.save(str(args.output))
    (args.output.parent / "refinement_log.json").write_text(
        json.dumps(
            {
                "GSAS_II_revision": GSASIIpath.GetVersionNumber(),
                "source_cif": str(args.cif),
                "stages": log,
            },
            indent=2,
            default=str,
        )
        + "\n"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--cif", type=Path, default=DEFAULT_CIF)
    parser.add_argument("--phase-name", default="MnWO4_wolframite")
    parser.add_argument("--background-terms", type=int, default=12)
    parser.add_argument("--output", type=Path, default=Path("analysis/trial_single/final.gpx"))
    args = parser.parse_args()
    args.pattern = args.pattern.resolve()
    args.cif = args.cif.resolve()
    args.output = args.output.resolve()
    build(args)


if __name__ == "__main__":
    main()
