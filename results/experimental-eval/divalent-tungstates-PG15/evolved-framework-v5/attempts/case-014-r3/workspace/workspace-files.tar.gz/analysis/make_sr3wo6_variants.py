#!/usr/bin/env python3
"""Create physical ordered realizations of the Ba3WO6 split-site analogue."""

from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifParser, CifWriter


SOURCE = Path("analysis/refs/analogue_Sr3WO6_from_Ba3WO6.cif")
OUT = Path("analysis/refs/sr3wo6_variants")


def periodic_midpoint(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    delta = (b - a + 0.5) % 1.0 - 0.5
    return (a + 0.5 * delta) % 1.0


def write_variant(source: Structure, name: str, choices: list[tuple[str, np.ndarray]]) -> None:
    sites = []
    labels = []
    # Keep the four fully occupied Sr, two W and twelve O sites.
    for site in source:
        if site.label in {"Sr5", "Sr6", "Sr7", "Sr8"}:
            continue
        element = next(iter(site.species)).symbol
        sites.append((element, site.frac_coords))
        labels.append(site.label)
    for label, coordinates in choices:
        sites.append(("Sr", coordinates % 1.0))
        labels.append(label)
    structure = Structure(
        source.lattice,
        [species for species, _ in sites],
        [coordinates for _, coordinates in sites],
        site_properties={"label": labels},
    )
    path = OUT / f"Sr3WO6_{name}.cif"
    CifWriter(structure, symprec=None, refine_struct=False).write_file(path)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    source = CifParser(SOURCE).parse_structures(primitive=False)[0]
    by_label = {site.label: site for site in source}
    first = ["Sr7", "Sr8"]
    second = ["Sr5", "Sr6"]
    for a in first:
        for b in second:
            write_variant(
                source,
                f"ordered_{a}_{b}",
                [(a, by_label[a].frac_coords), (b, by_label[b].frac_coords)],
            )
    write_variant(
        source,
        "ordered_midpoints",
        [
            (
                "Sr78",
                periodic_midpoint(by_label["Sr7"].frac_coords, by_label["Sr8"].frac_coords),
            ),
            (
                "Sr56",
                periodic_midpoint(by_label["Sr5"].frac_coords, by_label["Sr6"].frac_coords),
            ),
        ],
    )


if __name__ == "__main__":
    main()
