#!/usr/bin/env python3
"""Create the requested submission files from a replay-verified GSAS project."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PHASE_OUTPUT = {
    "SrWO4": ("SrWO4", "phase_SrWO4.cif", "scheelite, I41/a"),
    "WO3_2311041": ("WO3", "phase_WO3.cif", "monoclinic, P21/c"),
    "Sr3WO6_P21n": (
        "Sr3WO6",
        "phase_Sr3WO6.cif",
        "ordered double-perovskite-type, P21/n",
    ),
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", required=True)
    parser.add_argument("--prediction", required=True)
    parser.add_argument("--directory", default=".")
    args = parser.parse_args()

    out = Path(args.directory).resolve()
    out.mkdir(parents=True, exist_ok=True)
    final_project = out / "final.gpx"
    shutil.copy2(Path(args.project).resolve(), final_project)

    project = G2.G2Project(gpxfile=str(final_project))
    hist = project.histograms()[0]
    profile = np.load(Path(args.prediction).resolve())
    x = np.asarray(profile["x"], float)
    observed = np.asarray(profile["observed"], float)
    calculated = np.asarray(profile["predicted"], float)
    difference = observed - calculated
    np.savetxt(
        out / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8g", "%.10g", "%.10g"],
    )

    weights = np.asarray(hist.data["data"][1][2], float)
    chi_square = float(np.sum(weights * difference * difference))
    rwp = float(np.sqrt(chi_square / np.sum(weights * observed * observed)) * 100.0)
    rp = float(np.sum(np.abs(difference)) / np.sum(np.abs(observed)) * 100.0)
    covariance = project.data.get("Covariance", {}).get("data", {})
    n_parameters = len(covariance.get("varyList", []))
    gof = float(np.sqrt(chi_square / (len(observed) - n_parameters)))

    masses = []
    phase_rows = []
    for phase in project.phases():
        if phase.name not in PHASE_OUTPUT:
            continue
        formula, filename, structure = PHASE_OUTPUT[phase.name]
        phase.export_CIF(str(out / filename))
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(mass_scale)
        phase_rows.append(
            {
                "name": formula,
                "project_phase": phase.name,
                "structure": structure,
                "cif": filename,
                "weight_fraction": None,
            }
        )
    total = sum(masses)
    if total <= 0:
        raise ValueError("No positive crystalline mass-scale sum")
    for row, value in zip(phase_rows, masses):
        row["weight_fraction"] = value / total

    result = {
        "phases": phase_rows,
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "chi_square": chi_square,
            "goodness_of_fit": gof,
            "n_points": int(len(observed)),
            "n_refined_parameters": int(n_parameters),
        },
        "refinement_histogram": hist.name,
        "project": "final.gpx",
        "fit_profile": "fit.csv",
        "calculated_profile_source": "fresh GSAS-II atomic forward replay of final.gpx",
    }
    (out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
