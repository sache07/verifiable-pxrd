#!/usr/bin/env python3
"""Add one candidate phase to a GSAS-II checkpoint for targeted testing."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


def run_refinement(project: G2.G2Project, label: str, log: list[dict]) -> None:
    project.refine()
    project.save()
    state = snapshot(project, label)
    log.append(state)
    print(label, "Rwp", state["rwp_percent"])
    for row in state["phases"]:
        print(" ", row["name"], row["weight_fraction"], row["cell"][:6])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--cif", required=True)
    parser.add_argument("--cycles", type=int, default=4)
    parser.add_argument("--refine-cell", action="store_true")
    parser.add_argument("--disable-phase", action="append", default=[])
    parser.add_argument("--size", type=float, default=0.12)
    parser.add_argument("--mustrain", type=float, default=1000.0)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    project = G2.G2Project(gpxfile=str(Path(args.base).resolve()))
    project.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histograms()[0]

    # Freeze the accepted checkpoint while asking whether the new structure has
    # a stable positive scale. This prevents an unrelated reoptimization from
    # being mistaken for evidence for the candidate.
    hist.data["Background"][0][1] = False
    for values in hist.data["Instrument Parameters"][0].values():
        if isinstance(values, list) and len(values) > 2:
            values[2] = False
    for key, values in hist.data["Sample Parameters"].items():
        if isinstance(values, list) and len(values) > 1 and isinstance(values[1], bool):
            values[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
        for atom in phase.data["Atoms"]:
            atom[ct + 1] = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        if phase.name in args.disable_phase:
            hap["Use"] = False
            hap["Scale"] = [0.0, False]

    candidate = project.add_phase(
        str(Path(args.cif).resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = candidate.data["Histograms"][hist.name]
    hap["Scale"] = [0.2, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = args.size
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = args.mustrain
    hap["Mustrain"][2] = [False, False, False]

    project.set_Controls("cycles", args.cycles)
    log: list[dict] = []
    run_refinement(project, "candidate_scale", log)

    if args.refine_cell and hap["Scale"][0] > 1e-8:
        candidate.data["General"]["Cell"][0] = True
        run_refinement(project, "candidate_cell_scale", log)

    output.with_suffix(".json").write_text(json.dumps(log, indent=2, allow_nan=True) + "\n")


if __name__ == "__main__":
    main()
