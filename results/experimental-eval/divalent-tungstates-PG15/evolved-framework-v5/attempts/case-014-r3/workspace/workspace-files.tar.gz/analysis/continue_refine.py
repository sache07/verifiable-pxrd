#!/usr/bin/env python3
"""Continue the refinement flags stored in a GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--clear-frozen", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    project = G2.G2Project(gpxfile=str(Path(args.base).resolve()))
    project.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    if args.clear_frozen:
        project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    log = []
    for index in range(1, args.repeats + 1):
        project.refine()
        project.save()
        state = snapshot(project, f"repeat_{index}")
        state["frozen"] = project.get_Frozen()
        log.append(state)
        print(
            "repeat", index, "Rwp", state["rwp_percent"],
            "frozen", state["frozen"],
        )
        for phase in state["phases"]:
            print(" ", phase["name"], phase["weight_fraction"], phase["cell"][:6])
    output.with_suffix(".json").write_text(json.dumps(log, indent=2, allow_nan=True) + "\n")


if __name__ == "__main__":
    main()
