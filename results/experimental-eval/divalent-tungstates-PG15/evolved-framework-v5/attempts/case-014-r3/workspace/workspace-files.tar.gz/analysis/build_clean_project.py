#!/usr/bin/env python3
"""Build a clean three-phase project from an accepted physical checkpoint."""

from __future__ import annotations

import argparse
import copy
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


DEFAULT_PHASES = ("SrWO4", "WO3_1528915", "Sr3WO6_P21n")


def checkpoint(project: G2.G2Project, output: Path, label: str, log: list[dict]) -> float:
    project.save()
    saved = output.with_name(f"{output.stem}_{label}.gpx")
    shutil.copy2(output, saved)
    state = snapshot(project, label)
    state["project"] = str(saved)
    state["frozen"] = project.get_Frozen()
    log.append(state)
    print(label, "Rwp", state["rwp_percent"], "frozen", state["frozen"])
    for row in state["phases"]:
        print(
            " ", row["name"], "wf", row["weight_fraction"],
            "size", row["size"][1][0], "strain", row["mustrain"][1][0],
            "cell", row["cell"][:6],
        )
    return state["rwp_percent"]


def refine_repeated(
    project: G2.G2Project,
    output: Path,
    label: str,
    log: list[dict],
    repeats: int,
) -> None:
    for index in range(1, repeats + 1):
        project.refine()
        checkpoint(project, output, f"{label}_{index}", log)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--data", default="analysis/pattern.xye")
    parser.add_argument("--instrument", default="analysis/instrument.instprm")
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--position-stage", action="store_true")
    parser.add_argument("--phase", action="append", default=[])
    args = parser.parse_args()
    phase_names = tuple(args.phase) if args.phase else DEFAULT_PHASES

    G2.SetPrintLevel("warn")
    source = G2.G2Project(gpxfile=str(Path(args.source).resolve()))
    source_hist = source.histograms()[0]
    output = Path(args.output).resolve()
    export_dir = output.parent / f"{output.stem}_structures"
    export_dir.mkdir(parents=True, exist_ok=True)

    cif_paths: dict[str, Path] = {}
    for name in phase_names:
        phase = source.phase(name)
        if phase is None:
            raise ValueError(f"Source project lacks {name!r}")
        path = export_dir / f"{name}.cif"
        phase.export_CIF(str(path))
        cif_paths[name] = path

    project = G2.G2Project(newgpx=str(output))
    phases = [
        project.add_phase(str(cif_paths[name]), phasename=name, fmthint="CIF")
        for name in phase_names
    ]
    hist = project.add_powder_histogram(
        str(Path(args.data).resolve()),
        str(Path(args.instrument).resolve()),
        phases=phases,
        fmthint="xye",
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = copy.deepcopy(
        source_hist.data["Sample Parameters"]["Shift"]
    )
    hist.data["Sample Parameters"]["Shift"][1] = False
    hist.data["Background"] = copy.deepcopy(source_hist.data["Background"])
    hist.data["Background"][0][1] = False

    src_inst = source_hist.data["Instrument Parameters"][0]
    dst_inst = hist.data["Instrument Parameters"][0]
    for key, values in dst_inst.items():
        if key not in src_inst or not isinstance(values, list):
            continue
        if len(values) > 1 and len(src_inst[key]) > 1:
            values[1] = copy.deepcopy(src_inst[key][1])
        if len(values) > 2 and isinstance(values[2], bool):
            values[2] = False

    for phase in phases:
        source_phase = source.phase(phase.name)
        source_hap = source_phase.data["Histograms"][source_hist.name]
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        for key in ("Scale", "Size", "Mustrain", "Pref.Ori."):
            hap[key] = copy.deepcopy(source_hap[key])
        hap["Scale"][1] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""

    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.1, variable=":0:SH/L")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    hid = hist.data["data"][0]["hId"]
    for phase in phases:
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 1e-10, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:{hid}:Mustrain;i")

    log: list[dict] = []
    project.save()
    for phase in phases:
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    hist.data["Background"][0][1] = True
    refine_repeated(project, output, "scale_background", log, 3)

    dst_inst["SH/L"][2] = True
    refine_repeated(project, output, "axial", log, 2)

    for phase in phases:
        phase.data["Histograms"][hist.name]["Size"][2][0] = True
    refine_repeated(project, output, "sizes", log, 3)

    if args.position_stage:
        for phase in phases:
            phase.data["General"]["Cell"][0] = True
        hist.data["Sample Parameters"]["Shift"][1] = True
        refine_repeated(project, output, "positions", log, 2)

    output.with_suffix(".json").write_text(json.dumps(log, indent=2, allow_nan=True) + "\n")


if __name__ == "__main__":
    main()
