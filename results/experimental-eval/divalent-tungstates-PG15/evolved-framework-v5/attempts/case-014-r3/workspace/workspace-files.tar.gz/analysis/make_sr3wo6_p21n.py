#!/usr/bin/env python3
"""Transfer the physical Ca3WO6 P21/n double-perovskite topology to Sr3WO6."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser, CifWriter


SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/56/30/1563081.cif"
)
OUTPUT = Path("analysis/refs/Sr3WO6_P21n_from_Ca3WO6.cif")


def main() -> None:
    source = CifParser(SOURCE).parse_structures(primitive=False)[0]
    species = ["Sr" if site.species_string == "Ca" else site.species for site in source]
    model = Structure(
        Lattice.monoclinic(6.0592, 6.0642, 8.6825, 90.74),
        species,
        [site.frac_coords for site in source],
    )
    # Recover the inherited P21/n symmetry so only its physical cell degrees
    # of freedom are refined in GSAS-II.
    CifWriter(model, symprec=0.02, refine_struct=False).write_file(OUTPUT)
    print(model.composition.reduced_formula, model.lattice.parameters)
    pairs = sorted(
        (model.get_distance(i, j), model[i].species_string, model[j].species_string)
        for i in range(len(model))
        for j in range(i + 1, len(model))
    )
    print(*pairs[:30], sep="\n")


if __name__ == "__main__":
    main()
