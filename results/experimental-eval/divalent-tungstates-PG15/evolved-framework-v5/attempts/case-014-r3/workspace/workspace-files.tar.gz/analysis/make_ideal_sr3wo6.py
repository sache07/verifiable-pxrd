#!/usr/bin/env python3
"""Generate physical Sr3WO6 ordered-double-perovskite P1 trial models."""

from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


OUT = Path("analysis/refs/sr3wo6_ideal")


def make_model(oxygen_x: float, cubic_a: float = 8.671) -> Structure:
    # Fm-3m A2BB'O6 model: Sr(A)=8c, Sr(B)=4a, W=4b, O=24e.
    conventional = Structure.from_spacegroup(
        "Fm-3m",
        Lattice.cubic(cubic_a),
        ["Sr", "W", "Sr", "O"],
        [
            [0.0, 0.0, 0.0],
            [0.5, 0.5, 0.5],
            [0.25, 0.25, 0.25],
            [oxygen_x, 0.0, 0.0],
        ],
    )
    primitive = conventional.get_primitive_structure(tolerance=0.01)
    # Convert one F primitive cell (Z=1) to the body-centered tetragonal
    # Z=2 setting used by the indexed Ba3WO6 family.
    primitive.make_supercell(np.array([[0, 0, 1], [1, -1, 0], [1, 1, -1]]))
    primitive = primitive.get_sorted_structure()
    return Structure(
        primitive.lattice,
        [site.species for site in primitive],
        [site.frac_coords for site in primitive],
    )


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for oxygen_x in np.arange(0.270, 0.301, 0.005):
        model = make_model(float(oxygen_x))
        tag = f"x{oxygen_x:.3f}".replace(".", "p")
        CifWriter(model, symprec=None, refine_struct=False).write_file(
            OUT / f"Sr3WO6_double_perovskite_{tag}.cif"
        )
        # Also test the same physical topology in the independently indexed
        # residual-family metric. Fractional coordinates are unchanged.
        indexed = Structure(
            Lattice.from_parameters(
                6.0592139691,
                6.0642276932,
                8.6825248756,
                90.7595578433,
                89.7413921302,
                90.7705546419,
            ),
            [site.species for site in model],
            [site.frac_coords for site in model],
        )
        CifWriter(indexed, symprec=None, refine_struct=False).write_file(
            OUT / f"Sr3WO6_double_perovskite_indexed_{tag}.cif"
        )
        distances = sorted(
            (
                model.get_distance(i, j),
                model[i].species_string,
                model[j].species_string,
            )
            for i in range(len(model))
            for j in range(i + 1, len(model))
        )
        print(tag, model.composition.reduced_formula, model.lattice.parameters, distances[:4])


if __name__ == "__main__":
    main()
