#!/usr/bin/env python3
"""Refine a bounded subset of atomic coordinates from a GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--element", action="append", default=[])
    parser.add_argument("--label", action="append", default=[])
    parser.add_argument("--exclude-label", action="append", default=[])
    parser.add_argument("--delta", type=float, default=0.012)
    parser.add_argument("--cycles", type=int, default=4)
    parser.add_argument("--all-scales-background", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.base).resolve()))
    output = Path(args.output).resolve()
    project.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    project.set_Frozen()
    hist = project.histograms()[0]

    # Hold calibration, cells, profiles and other structures at the accepted
    # checkpoint so an intensity change is attributable to this coordinate set.
    hist.data["Background"][0][1] = args.all_scales_background
    for values in hist.data["Instrument Parameters"][0].values():
        if isinstance(values, list) and len(values) > 2:
            values[2] = False
    for values in hist.data["Sample Parameters"].values():
        if isinstance(values, list) and len(values) > 1 and isinstance(values[1], bool):
            values[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = (
            bool(hap.get("Use", True) and hap["Scale"][0] > 0)
            if args.all_scales_background
            else phase.name == args.phase
        )
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False

    target = project.phase(args.phase)
    if target is None:
        raise ValueError(f"Unknown phase {args.phase!r}")
    selected = []
    for index, atom in enumerate(target.atoms()):
        use = (not args.element and not args.label) or atom.element in args.element or atom.label in args.label
        if atom.label in args.exclude_label:
            use = False
        if not use:
            continue
        atom.refinement_flags = "X"
        selected.append({"index": index, "label": atom.label, "element": atom.element})
        pid = target.data["pId"]
        for axis, coordinate in zip("xyz", atom.coordinates):
            variable = f"{pid}::dA{axis}:{index}"
            # Bounds on dA variables are compared by GSAS-II against the
            # resulting absolute Ax/Ay/Az coordinate.
            project.set_Controls("parmMin", coordinate - args.delta, variable=variable)
            project.set_Controls("parmMax", coordinate + args.delta, variable=variable)

    if not selected:
        raise ValueError("No atoms selected")
    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save()
    state = snapshot(project, "bounded_coordinates")
    state["selected_atoms"] = selected
    state["coordinates"] = [
        {
            "label": atom.label,
            "element": atom.element,
            "occupancy": atom.occupancy,
            "xyz": list(atom.coordinates),
        }
        for atom in target.atoms()
    ]
    output.with_suffix(".json").write_text(json.dumps(state, indent=2, allow_nan=True) + "\n")
    print("Rwp", state["rwp_percent"], "selected", [row["label"] for row in selected])
    print("frozen", project.get_Frozen())


if __name__ == "__main__":
    main()
