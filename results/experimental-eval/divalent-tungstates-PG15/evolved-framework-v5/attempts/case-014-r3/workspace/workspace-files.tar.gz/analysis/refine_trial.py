#!/usr/bin/env python3
"""Build and refine trial GSAS-II phase models for the specimen pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    phases = project.phases()
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "label": label,
        "rwp_percent": float(hist.get_wR()),
        "instrument": {
            key: float(inst[key][1])
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
            if key in inst
        },
        "sample": {
            key: float(sample[key][0])
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if key in sample and isinstance(sample[key], list)
        },
        "phases": [],
    }
    masses = []
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(0.0, mass_scale))
        result["phases"].append(
            {
                "name": phase.name,
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
                "scale": float(hap["Scale"][0]),
                "mass_scale": mass_scale,
                "size": hap.get("Size"),
                "mustrain": hap.get("Mustrain"),
                "pref_ori": hap.get("Pref.Ori."),
            }
        )
    total = sum(masses)
    for row, value in zip(result["phases"], masses):
        row["weight_fraction"] = value / total if total > 0 else None
    cov = project.data.get("Covariance", {}).get("data", {})
    result["gof"] = float(cov.get("GOF", np.nan))
    result["vary_list"] = [str(v) for v in cov.get("varyList", [])]
    return result


def refine(project: G2.G2Project, log: list[dict], label: str) -> None:
    project.refine()
    project.save()
    state = snapshot(project, label)
    log.append(state)
    print(label, "Rwp", state["rwp_percent"], "GOF", state["gof"])
    for row in state["phases"]:
        print(" ", row["name"], "wf", row["weight_fraction"], "cell", row["cell"][:6])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--instrument", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", action="append", nargs=2, metavar=("NAME", "CIF"), required=True)
    parser.add_argument("--start", choices=("basic", "positions", "profiles"), default="profiles")
    parser.add_argument("--zero", type=float, default=0.0)
    parser.add_argument("--cycles", type=int, default=6)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    project = G2.G2Project(newgpx=str(output))
    phases = [
        project.add_phase(str(Path(cif).resolve()), phasename=name, fmthint="CIF")
        for name, cif in args.phase
    ]
    hist = project.add_powder_histogram(
        str(Path(args.data).resolve()),
        str(Path(args.instrument).resolve()),
        phases=phases,
        fmthint="xye",
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    # The overall histogram and HAP scales are exactly redundant. Keep the
    # histogram scale fixed and use only the phase scales for quantification.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Instrument Parameters"][0]["Zero"][1] = float(args.zero)
    hist.set_refinements(
        {
            "Limits": [10.00943322, 99.99442286],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [700.0] + [0.0] * 11,
                "refine": True,
            },
        }
    )
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][1][1] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        phase.set_HAP_refinements({"Scale": True})

    # Keep refinements inside the laboratory/specimen ranges supplied for this
    # experiment. GSAS-II freezes a parameter if a cycle crosses its bound.
    project.set_Controls("cycles", args.cycles)
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    project.set_Controls("parmMin", 2.0, variable=":0:W")
    project.set_Controls("parmMax", 40.0, variable=":0:W")
    project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.1, variable=":0:SH/L")
    for phase in phases:
        pid = phase.data["pId"]
        hid = hist.data["data"][0]["hId"]
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:{hid}:Mustrain;i")

    log: list[dict] = []
    refine(project, log, "scale_background")

    if args.start in ("positions", "profiles"):
        for phase in phases:
            phase.set_refinements({"Cell": True})
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        refine(project, log, "shift_cells")

    if args.start == "profiles":
        # Size/X and microstrain/U are near-exactly correlated for a single
        # phase. Keep U and X at physical starting values, refine the common
        # W and axial-divergence terms, and put phase-specific broadening in
        # the HAP size/microstrain terms.
        hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
        refine(project, log, "common_profile")
        for phase in phases:
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                }
            )
        refine(project, log, "phase_profiles")

    output.with_suffix(".json").write_text(json.dumps(log, indent=2, allow_nan=True) + "\n")


if __name__ == "__main__":
    main()
