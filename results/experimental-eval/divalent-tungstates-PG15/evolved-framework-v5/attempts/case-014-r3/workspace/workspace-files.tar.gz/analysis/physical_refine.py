#!/usr/bin/env python3
"""Re-refine an accepted multiphase checkpoint with physical profile bounds."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


DEFAULT_ACTIVE = ("SrWO4", "WO3_1528915", "Sr3WO6_ordered_midpoints")


def freeze_all(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = False
    for values in hist.data["Instrument Parameters"][0].values():
        if isinstance(values, list) and len(values) > 2:
            values[2] = False
    for values in hist.data["Sample Parameters"].values():
        if isinstance(values, list) and len(values) > 1 and isinstance(values[1], bool):
            values[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False


def report(project: G2.G2Project, label: str, log: list[dict], active: tuple[str, ...]) -> None:
    project.save()
    state = snapshot(project, label)
    state["frozen"] = [str(value) for value in project.get_Frozen()]
    log.append(state)
    print(label, "Rwp", state["rwp_percent"], "GOF", state["gof"])
    print(" instrument", state["instrument"], "sample", state["sample"])
    for phase in state["phases"]:
        if phase["name"] in active:
            print(
                " ",
                phase["name"],
                "wf",
                phase["weight_fraction"],
                "size",
                phase["size"][1][0],
                "strain",
                phase["mustrain"][1][0],
            )


def run(project: G2.G2Project, label: str, log: list[dict], active: tuple[str, ...]) -> None:
    project.refine()
    report(project, label, log, active)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--cycles", type=int, default=6)
    parser.add_argument("--w", type=float, default=20.0)
    parser.add_argument("--u", type=float, default=10.0)
    parser.add_argument("--strain", type=float, default=500.0)
    parser.add_argument("--refine-u", action="store_true")
    parser.add_argument("--refine-polarization", action="store_true")
    parser.add_argument("--active", action="append", default=[])
    args = parser.parse_args()
    active = tuple(args.active) if args.active else DEFAULT_ACTIVE

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    project = G2.G2Project(gpxfile=str(Path(args.base).resolve()))
    project.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histograms()[0]
    freeze_all(project)
    # A prior bounded branch may have left variables on GSAS-II's automatic
    # frozen list. Start this checkpoint with a clean list and apply the bounds
    # below afresh.
    project.set_Frozen()

    # One overall scale is enough. Phase scales carry the quantitative result.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1] = float(args.u)
    inst["W"][1] = float(args.w)
    inst["X"][1] = 1.0
    for key in ("V", "Y", "Z"):
        if key in inst:
            inst[key][1] = 0.0

    # Restore positive, generator-supported broadening for every accepted phase.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if phase.name not in active:
            hap["Use"] = False
            hap["Scale"] = [0.0, False]
            continue
        hap["Use"] = True
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        size = float(hap["Size"][1][0])
        hap["Size"][1][0] = min(1.5, max(0.04, size))
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = float(args.strain)
        hap["Mustrain"][2] = [False, False, False]

    project.set_Controls("cycles", args.cycles)
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMax", 40.0, variable=":0:U")
    project.set_Controls("parmMin", 2.0, variable=":0:W")
    project.set_Controls("parmMax", 40.0, variable=":0:W")
    project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.1, variable=":0:SH/L")
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    hid = hist.data["data"][0]["hId"]
    for phase in project.phases():
        if phase.name not in active:
            continue
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 1e-10, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:{hid}:Mustrain;i")

    log: list[dict] = []
    hist.data["Background"][0][1] = True
    run(project, "physical_scale_background", log, active)

    names = ["W", "SH/L"]
    if args.refine_u:
        names.insert(0, "U")
    if args.refine_polarization:
        names.append("Polariz.")
    hist.set_refinements({"Instrument Parameters": names})
    run(project, "common_profile", log, active)

    for phase in project.phases():
        if phase.name in active:
            phase.data["Histograms"][hist.name]["Size"][2][0] = True
    run(project, "crystallite_sizes", log, active)

    for phase in project.phases():
        if phase.name in active:
            phase.data["Histograms"][hist.name]["Mustrain"][2][0] = True
    run(project, "microstrain", log, active)

    hist.data["Sample Parameters"]["Shift"][1] = True
    for phase in project.phases():
        if phase.name in active:
            phase.data["General"]["Cell"][0] = True
    run(project, "cells_shift_profiles", log, active)

    output.with_suffix(".json").write_text(json.dumps(log, indent=2, allow_nan=True) + "\n")


if __name__ == "__main__":
    main()
