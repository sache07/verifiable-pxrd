#!/usr/bin/env python3
"""Test one bounded March-Dollase preferred-orientation axis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--axis", nargs=3, type=int, required=True)
    parser.add_argument("--cycles", type=int, default=6)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    project = G2.G2Project(gpxfile=str(Path(args.base).resolve()))
    project.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    project.set_Frozen()
    hist = project.histograms()[0]

    hist.data["Background"][0][1] = True
    for values in hist.data["Instrument Parameters"][0].values():
        if isinstance(values, list) and len(values) > 2:
            values[2] = False
    for values in hist.data["Sample Parameters"].values():
        if isinstance(values, list) and len(values) > 1 and isinstance(values[1], bool):
            values[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = bool(hap.get("Use", True) and hap["Scale"][0] > 0)
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    phase = project.phase(args.phase)
    if phase is None:
        raise ValueError(f"Unknown phase {args.phase!r}")
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(args.axis)
    pid = phase.data["pId"]
    hid = hist.data["data"][0]["hId"]
    project.set_Controls("parmMin", 0.7, variable=f"{pid}:{hid}:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{pid}:{hid}:MD")
    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save()
    state = snapshot(project, "preferred_orientation")
    state["tested_phase"] = args.phase
    state["tested_axis"] = list(args.axis)
    state["frozen"] = project.get_Frozen()
    output.with_suffix(".json").write_text(json.dumps(state, indent=2, allow_nan=True) + "\n")
    print("Rwp", state["rwp_percent"], "phase", args.phase, "axis", args.axis)
    for row in state["phases"]:
        if row["name"] == args.phase:
            print("MD", row["pref_ori"], "wf", row["weight_fraction"])
    print("frozen", project.get_Frozen())


if __name__ == "__main__":
    main()
