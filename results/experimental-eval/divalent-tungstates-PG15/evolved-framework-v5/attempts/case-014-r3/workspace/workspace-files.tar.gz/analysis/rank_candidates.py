#!/usr/bin/env python3
"""Rank COD phase candidates against a saved positive GSAS-II residual."""

from __future__ import annotations

import gzip
import json
import argparse
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d


INDEX = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/venv/"
    "lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz"
)
CIFS = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> Path:
    return CIFS / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--profile",
        default="analysis/trials/two_1528915b_profile.csv",
        help="CSV columns: angle, observed, calculated, background, difference",
    )
    parser.add_argument("--output", default="analysis/candidate_ranking.json")
    args = parser.parse_args()
    profile = np.genfromtxt(
        args.profile, delimiter=",", skip_header=1
    )
    x, observed, _calculated, _background, difference = profile.T
    # A small smoothing kernel estimates the coherent residual signal while
    # retaining the observed laboratory peak widths.
    residual = gaussian_filter1d(difference, 2.0)

    with gzip.open(INDEX, "rt") as handle:
        index = json.load(handle)

    specimen_elements = {"Sr", "W", "O", "C"}
    analogue_metals = {"Mg", "Ca", "Ba", "Pb", "Zn", "Cu", "Co", "Ni", "Mn"}
    records: dict[str, dict] = {}
    for key, rows in index.items():
        elements = set(key.split("-"))
        exact = elements <= specimen_elements and bool(elements & {"Sr", "W"})
        analogue = "O" in elements and "W" in elements and len(elements) == 3 and bool(elements & analogue_metals)
        if not (exact or analogue):
            continue
        for formula, cod_id, space_group, r_factor in rows:
            records[cod_id] = {
                "formula": formula,
                "elements": sorted(elements),
                "space_group": space_group,
                "r_factor": r_factor,
                "basis": "exact" if exact else "cross_chemistry",
            }

    calc = XRDCalculator(wavelength=1.540598, symprec=0)
    results = []
    a_values = np.linspace(0.05, 0.65, 25)  # zero/displacement-like cos(theta)
    b_values = np.linspace(-3.0, 3.0, 49)  # cell-like tan(theta)
    for cod_id, metadata in records.items():
        try:
            structure = CifParser(str(cif_path(cod_id))).parse_structures(primitive=False)[0]
            pattern = calc.get_pattern(structure, two_theta_range=(10, 100), scaled=True)
        except Exception as exc:
            results.append({"cod_id": cod_id, **metadata, "error": str(exc)})
            continue
        positions = np.asarray(pattern.x, float)
        intensities = np.asarray(pattern.y, float)
        keep = intensities >= 1.0
        positions, intensities = positions[keep], intensities[keep]
        if not len(positions):
            continue
        intensities /= np.sqrt(np.sum(intensities * intensities))
        best = None
        theta = np.deg2rad(positions / 2)
        for a in a_values:
            base = positions + a * np.cos(theta)
            for b in b_values:
                transformed = base + b * np.tan(theta)
                valid = (transformed >= x[0]) & (transformed <= x[-1])
                if np.count_nonzero(valid) < 2:
                    continue
                pos = transformed[valid]
                inten = intensities[valid]
                sampled = np.interp(pos, x, residual)
                local_y = np.interp(pos, x, observed)
                weights = 1.0 / np.maximum(local_y, 1.0)
                numerator = float(np.sum(weights * inten * sampled))
                denominator = float(np.sum(weights * inten * inten))
                scale = max(0.0, numerator / denominator)
                improvement = 2 * scale * numerator - scale * scale * denominator
                coverage = float(np.sum(inten[sampled > 2 * np.sqrt(local_y)]) / np.sum(inten))
                candidate = (improvement, coverage, a, b, scale, pos, inten, sampled)
                if best is None or candidate[:2] > best[:2]:
                    best = candidate
        if best is None:
            continue
        improvement, coverage, a, b, scale, pos, inten, sampled = best
        matches = sorted(
            (
                {
                    "two_theta": float(t),
                    "relative_stick": float(100 * i / np.max(inten)),
                    "residual_counts": float(r),
                }
                for t, i, r in zip(pos, inten, sampled)
            ),
            key=lambda row: row["relative_stick"],
            reverse=True,
        )[:12]
        results.append(
            {
                "cod_id": cod_id,
                **metadata,
                "parsed_formula": structure.composition.reduced_formula,
                "n_sites": len(structure),
                "lattice": [float(v) for v in (*structure.lattice.abc, *structure.lattice.angles)],
                "score": float(improvement),
                "coverage": coverage,
                "angle_a": float(a),
                "angle_b": float(b),
                "matches": matches,
            }
        )
    results.sort(key=lambda row: row.get("score", -np.inf), reverse=True)
    Path(args.output).write_text(json.dumps(results, indent=2) + "\n")
    for row in results[:40]:
        if "error" in row:
            continue
        print(
            f"{row['cod_id']} {row['formula']:14s} {row['basis']:15s} "
            f"score={row['score']:11.1f} cov={row['coverage']:.3f} "
            f"a={row['angle_a']:+.3f} b={row['angle_b']:+.3f}"
        )


if __name__ == "__main__":
    main()
