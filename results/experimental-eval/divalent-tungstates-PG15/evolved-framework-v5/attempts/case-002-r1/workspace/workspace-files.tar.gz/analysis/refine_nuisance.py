#!/usr/bin/env python3
"""Refine supported asymmetry, polarization and phase-wise common Uiso terms."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path("analysis/nuisance")


def save_checkpoint(project: G2.G2Project, name: str) -> None:
    project.save(str(ROOT / f"{name}.gpx"))
    print(f"{name}: Rwp={project.histogram(0).get_wR():.6f}")


def main() -> None:
    G2.SetPrintLevel("warn")
    ROOT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        "analysis/profile/physical_broad/model.gpx", newgpx=str(ROOT / "working.gpx")
    )
    project.set_Frozen()
    project.set_Controls("cycles", 10)
    project.index_ids()
    hist = project.histogram(0)

    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.set_Controls("parmMin", 0.005, ":0:SH/L")
    project.set_Controls("parmMax", 0.10, ":0:SH/L")
    project.refine(makeBack=False)
    save_checkpoint(project, "shl")

    hist.clear_refinements({"Instrument Parameters": ["SH/L"]})
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.3, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    project.set_Frozen()
    project.refine(makeBack=False)
    save_checkpoint(project, "polarization")

    hist.clear_refinements({"Instrument Parameters": ["Polariz."]})
    # The specimen model assigns one isotropic displacement amplitude per
    # phase. Use equality constraints rather than independent atom Uiso terms.
    for phase_index, phase in enumerate(project.phases()):
        variables = []
        for atom_index, atom in enumerate(phase.atoms()):
            atom.uiso = 0.01
            atom.refinement_flags = "U"
            variables.append(f"{phase_index}::AUiso:{atom_index}")
        if len(variables) > 1:
            project.add_EquivConstr(variables)
        project.set_Controls("parmMin", 0.001, variables[0])
        project.set_Controls("parmMax", 0.05, variables[0])
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    save_checkpoint(project, "uiso")

    out = {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items() if isinstance(v, list) and len(v) > 1},
        "sample": {k: v[0] for k, v in hist.SampleParameters.items() if isinstance(v, list) and v},
        "phases": {},
    }
    for phase in project.phases():
        phase.export_CIF(str(ROOT / f"uiso_{phase.name}.cif"))
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "uiso": [atom.uiso for atom in phase.atoms()],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "short_distances": phase.ShortDistances(),
        }
    (ROOT / "summary.json").write_text(json.dumps(out, indent=2, default=str) + "\n")
    print(json.dumps(out, indent=2, default=str))


if __name__ == "__main__":
    main()
