#!/usr/bin/env python3
"""Refit a physically bounded common instrument profile from several starts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


STARTS = {
    "narrow": (5.0, 5.0, 1.0),
    "middle": (20.0, 10.0, 2.0),
    "broad": (40.0, 2.0, 4.0),
}


def run_refine(project: G2.G2Project, label: str) -> None:
    project.refine(makeBack=False)
    print(f"{label}: Rwp={project.histogram(0).get_wR():.6f}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("start", choices=STARTS)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    root = Path("analysis/profile") / f"physical_{args.start}"
    root.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project("analysis/profile/bao2_001/model.gpx", newgpx=str(root / "model.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 10)
    project.index_ids()
    hist = project.histogram(0)

    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for key, value in zip(("U", "W", "X"), STARTS[args.start]):
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = True

    for variable, low, high in (
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
    ):
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)
    run_refine(project, "instrument")

    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.set_Frozen()
    for index, phase in enumerate(project.phases()):
        phase.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "refine": True}})
        project.set_Controls("parmMin", 0.0, f"{index}:0:Mustrain;i")
        project.set_Controls("parmMax", 15000.0, f"{index}:0:Mustrain;i")
        project.set_Controls("parmMin", 0.0, f"{index}:0:Mustrain;a")
        project.set_Controls("parmMax", 15000.0, f"{index}:0:Mustrain;a")
    run_refine(project, "strain")

    for phase in project.phases():
        phase.clear_HAP_refinements({"Mustrain": True})
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.set_Frozen()
    for index in range(len(project.phases())):
        project.set_Controls("parmMin", 0.02, f"{index}:0:Size;i")
        project.set_Controls("parmMax", 2.0, f"{index}:0:Size;i")
    run_refine(project, "size")
    project.save()

    out = {
        "start": args.start,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items() if isinstance(v, list) and len(v) > 1},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "short_distances": phase.ShortDistances(),
        }
    (root / "summary.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
