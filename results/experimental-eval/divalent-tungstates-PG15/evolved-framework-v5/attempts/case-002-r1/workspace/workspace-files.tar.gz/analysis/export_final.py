#!/usr/bin/env python3
"""Create the submitted project, CIFs, profile and machine-readable result."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path.cwd()
PHASE_META = {
    "WO3": {
        "name": "triclinic tungsten trioxide",
        "formula": "WO3",
        "space_group": "P -1",
        "cif_path": "phase_1_WO3.cif",
        "reference": "COD 2106293",
    },
    "BaO2": {
        "name": "barium peroxide",
        "formula": "BaO2",
        "space_group": "I 4/mmm",
        "cif_path": "phase_2_BaO2.cif",
        "reference": "COD 1010113",
    },
}


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project("analysis/final/best.gpx", newgpx=str(ROOT / "final.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 8)
    hist = project.histogram(0)

    # Remove now-unused Uiso equality constraints; the refined common values
    # are retained as fixed atom parameters in the phase models.
    project.data["Constraints"]["data"]["Phase"] = []
    x = np.asarray(hist.data["data"][1][0], dtype=float)
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    project.refine(makeBack=False)
    project.save(str(ROOT / "final.gpx"))

    fractions = hist.ComputeMassFracs()
    phases = []
    for phase in project.phases():
        meta = PHASE_META[phase.name]
        phase.export_CIF(str(ROOT / meta["cif_path"]))
        value, esd = fractions[phase.name]
        phases.append(
            {
                "name": meta["name"],
                "formula": meta["formula"],
                "space_group": meta["space_group"],
                "cif_path": meta["cif_path"],
                "weight_fraction": value,
                "weight_fraction_esd": esd,
                "structure_reference": meta["reference"],
            }
        )

    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    observed = np.asarray(arrays[1], dtype=float)
    calculated = np.asarray(arrays[3], dtype=float)
    background = np.asarray(arrays[4], dtype=float)
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference", "background"]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    residuals = hist.residuals
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    rexp = float(residuals.get("wRmin", np.nan))
    rwp = float(residuals["wR"])
    result = {
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": rexp,
            "goodness_of_fit": float(rvals.get("GOF", rwp / rexp)),
            "chi_squared_reduced": float((rwp / rexp) ** 2),
            "n_points": int(len(x)),
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
        },
        "refinement_histogram": hist.name,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
