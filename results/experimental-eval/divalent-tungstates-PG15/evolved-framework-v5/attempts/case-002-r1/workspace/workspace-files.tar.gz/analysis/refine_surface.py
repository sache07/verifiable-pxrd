#!/usr/bin/env python3
"""Diagnostic branch for one supported common surface-roughness term."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


STARTS = {"low": (0.1, 0.05), "high": (0.5, 0.2)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("start", choices=STARTS)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    root = Path("analysis/surface") / args.start
    root.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project("analysis/final/best.gpx", newgpx=str(root / "model.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.index_ids()
    hist = project.histogram(0)
    hist.SampleParameters["SurfRoughA"] = [STARTS[args.start][0], True]
    hist.SampleParameters["SurfRoughB"] = [STARTS[args.start][1], True]
    project.set_Controls("parmMin", 0.0, ":0:SurfRoughA")
    project.set_Controls("parmMax", 1.0, ":0:SurfRoughA")
    project.set_Controls("parmMin", 0.001, ":0:SurfRoughB")
    project.set_Controls("parmMax", 1.0, ":0:SurfRoughB")
    project.refine(makeBack=False)
    project.save()
    out = {
        "start": args.start,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "surface": {
            "A": hist.SampleParameters["SurfRoughA"][0],
            "B": hist.SampleParameters["SurfRoughB"][0],
        },
    }
    (root / "summary.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
