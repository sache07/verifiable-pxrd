#!/usr/bin/env python3
"""Bounded heavy-then-light coordinate refinement with replayable checkpoints."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


INPUT = "analysis/profile/wo3_100/model.gpx"
ROOT = Path("analysis/coordinates")


def coordinate_bounds(project: G2.G2Project, phase_index: int, atom_indices: list[int], limit: float) -> None:
    for atom_index in atom_indices:
        for axis in ("x", "y", "z"):
            variable = f"{phase_index}::dA{axis}:{atom_index}"
            project.set_Controls("parmMin", -limit, variable)
            project.set_Controls("parmMax", limit, variable)


def snapshot(project: G2.G2Project, name: str) -> dict:
    project.save(str(ROOT / f"{name}.gpx"))
    for phase in project.phases():
        phase.export_CIF(str(ROOT / f"{name}_{phase.name}.cif"))
    hist = project.histogram(0)
    out = {
        "checkpoint": name,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "phases": {},
    }
    for phase in project.phases():
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "short_distances": phase.ShortDistances(),
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "uiso": atom.uiso,
                }
                for atom in phase.atoms()
            ],
        }
    (ROOT / f"{name}.json").write_text(json.dumps(out, indent=2) + "\n")
    print(f"{name}: Rwp={hist.get_wR():.6f}, short={ {p.name: p.ShortDistances() for p in project.phases()} }")
    return out


def main() -> None:
    G2.SetPrintLevel("warn")
    ROOT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(INPUT, newgpx=str(ROOT / "working.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)

    # Freeze specimen broadening while atomic intensities are optimized.
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})

    snapshot(project, "start")
    # Atom-bound variables are keyed by GSAS-II random IDs internally; force
    # indexing for this project before constructing those variable objects.
    project.index_ids()

    heavy_by_phase: dict[int, list[int]] = {}
    light_by_phase: dict[int, list[int]] = {}
    for phase_index, phase in enumerate(project.phases()):
        heavy, light = [], []
        for atom_index, atom in enumerate(phase.atoms()):
            if atom.element == "O":
                light.append(atom_index)
            else:
                heavy.append(atom_index)
        heavy_by_phase[phase_index] = heavy
        light_by_phase[phase_index] = light
        coordinate_bounds(project, phase_index, heavy, 0.012)
        for atom_index in heavy:
            phase.atoms()[atom_index].refinement_flags = "X"

    project.refine(makeBack=False)
    snapshot(project, "heavy")

    project.set_Frozen()
    project.set_Controls("cycles", 16)
    project.index_ids()
    for phase_index, phase in enumerate(project.phases()):
        coordinate_bounds(project, phase_index, light_by_phase[phase_index], 0.012)
        for atom_index in light_by_phase[phase_index]:
            phase.atoms()[atom_index].refinement_flags = "X"

    project.refine(makeBack=False)
    snapshot(project, "light")


if __name__ == "__main__":
    main()
