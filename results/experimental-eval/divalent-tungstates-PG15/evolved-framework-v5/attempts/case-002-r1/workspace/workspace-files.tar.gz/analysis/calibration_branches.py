#!/usr/bin/env python3
"""Compare defensible zero/displacement calibrations from a fixed profile checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("shift", "zero", "both"))
    parser.add_argument("--input", default="analysis/branches/wo3_2106293_bao2/model.gpx")
    parser.add_argument("--outdir", default="analysis/calibration")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    root = Path(args.outdir) / args.mode
    root.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input, newgpx=str(root / "model.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)

    # Hold the current profile decomposition fixed while resolving peak positions.
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})

    zero = hist.InstrumentParameters["Zero"]
    shift = hist.SampleParameters["Shift"]
    zero[2] = args.mode in ("zero", "both")
    shift[1] = args.mode in ("shift", "both")
    if args.mode == "zero":
        shift[0] = 0.0
    if args.mode == "shift":
        zero[1] = 0.0

    project.set_Controls("parmMin", -0.5, ":0:Zero")
    project.set_Controls("parmMax", 0.5, ":0:Zero")
    project.set_Controls("parmMin", -1200.0, ":0:Shift")
    project.set_Controls("parmMax", 1200.0, ":0:Shift")
    project.refine(makeBack=False)
    project.save()

    out = {
        "mode": args.mode,
        "residuals": hist.residuals,
        "zero_deg": hist.InstrumentParameters["Zero"][1],
        "shift_um": hist.SampleParameters["Shift"][0],
        "mass_fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "vary": [str(v) for v in project.data["Covariance"]["data"]["varyList"]],
    }
    (root / "summary.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
