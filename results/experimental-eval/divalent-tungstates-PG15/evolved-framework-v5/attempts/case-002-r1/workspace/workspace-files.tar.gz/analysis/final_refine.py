#!/usr/bin/env python3
"""Final staged profile refinement from the best physical structural checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path("analysis/final")


def checkpoint(project: G2.G2Project, name: str) -> dict:
    hist = project.histogram(0)
    out = {
        "name": name,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
    }
    project.save(str(ROOT / f"{name}.gpx"))
    (ROOT / f"{name}.json").write_text(json.dumps(out, indent=2) + "\n")
    print(f"{name}: Rwp={hist.get_wR():.6f}, fractions={out['mass_fractions']}")
    return out


def main() -> None:
    G2.SetPrintLevel("warn")
    ROOT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project("analysis/nuisance/uiso.gpx", newgpx=str(ROOT / "working.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.index_ids()
    hist = project.histogram(0)

    # Freeze the accepted atomic model and common instrument profile.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    checkpoint(project, "start")

    for index, phase in enumerate(project.phases()):
        phase.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "refine": True}})
        for suffix in ("Mustrain;i", "Mustrain;a"):
            project.set_Controls("parmMin", 0.0, f"{index}:0:{suffix}")
            project.set_Controls("parmMax", 15000.0, f"{index}:0:{suffix}")
    project.refine(makeBack=False)
    checkpoint(project, "strain")

    for index, phase in enumerate(project.phases()):
        phase.clear_HAP_refinements({"Mustrain": True})
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        project.set_Controls("parmMin", 0.02, f"{index}:0:Size;i")
        project.set_Controls("parmMax", 2.0, f"{index}:0:Size;i")
    project.set_Frozen()
    project.refine(makeBack=False)
    checkpoint(project, "size")

    # A final calibration/background/scale cycle with profile terms held fixed
    # supplies a stable full-grid replay checkpoint.
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    project.set_Frozen()
    project.refine(makeBack=False)
    checkpoint(project, "best")

    out = {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items() if isinstance(v, list) and len(v) > 1},
        "sample": {k: v[0] for k, v in hist.SampleParameters.items() if isinstance(v, list) and v},
        "phases": {},
        "vary": [str(v) for v in project.data["Covariance"]["data"]["varyList"]],
    }
    for phase in project.phases():
        phase.export_CIF(str(ROOT / f"{phase.name}.cif"))
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "uiso": [atom.uiso for atom in phase.atoms()],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "scale": hap["Scale"],
            "short_distances": phase.ShortDistances(),
        }
    (ROOT / "summary.json").write_text(json.dumps(out, indent=2, default=str) + "\n")
    print(json.dumps(out, indent=2, default=str))


if __name__ == "__main__":
    main()
