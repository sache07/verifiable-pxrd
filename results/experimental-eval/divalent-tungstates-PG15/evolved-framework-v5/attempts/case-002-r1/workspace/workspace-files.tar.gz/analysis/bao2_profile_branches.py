#!/usr/bin/env python3
"""Test the two symmetry-distinct uniaxial strain axes for tetragonal BaO2."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = {"100": [1, 0, 0], "001": [0, 0, 1]}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("axis", choices=AXES)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    root = Path("analysis/profile") / f"bao2_{args.axis}"
    root.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project("analysis/profile/wo3_100/model.gpx", newgpx=str(root / "model.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    wo3, bao2 = project.phase("WO3"), project.phase("BaO2")

    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for phase in (wo3, bao2):
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})

    bhap = bao2.data["Histograms"][hist.name]
    iso = bhap["Mustrain"][1][0]
    bhap["Mustrain"][0] = "uniaxial"
    bhap["Mustrain"][1][0] = iso
    bhap["Mustrain"][1][1] = iso
    bhap["Mustrain"][2][0] = True
    bhap["Mustrain"][2][1] = True
    bhap["Mustrain"][3] = AXES[args.axis]

    project.index_ids()
    for suffix, low, high in (
        ("Mustrain;i", 0.0, 20000.0),
        ("Mustrain;a", 0.0, 20000.0),
        ("Size;i", 0.015, 10.0),
    ):
        variable = f"1:0:{suffix}"
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)

    project.refine(makeBack=False)
    print(f"strain Rwp={hist.get_wR():.6f}")
    bao2.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.refine(makeBack=False)
    project.save()

    out = {
        "axis": args.axis,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "bao2_size": bhap["Size"],
        "bao2_mustrain": bhap["Mustrain"],
        "short_distances": {phase.name: phase.ShortDistances() for phase in project.phases()},
    }
    (root / "summary.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
