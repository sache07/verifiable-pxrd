#!/usr/bin/env python3
"""Test one supported uniaxial microstrain term for the dominant WO3 phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = {"100": [1, 0, 0], "010": [0, 1, 0], "001": [0, 0, 1]}


def refine(project: G2.G2Project, label: str) -> None:
    project.refine(makeBack=False)
    print(f"{label} Rwp={project.histogram(0).get_wR():.6f}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("axis", choices=AXES)
    parser.add_argument("--input", default="analysis/calibration/shift/model.gpx")
    parser.add_argument("--outdir", default="analysis/profile")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    root = Path(args.outdir) / f"wo3_{args.axis}"
    root.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input, newgpx=str(root / "model.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    wo3 = project.phase("WO3")
    bao2 = project.phase("BaO2")

    # Hold common instrument broadening and crystallite size while testing
    # the single new anisotropic strain term.
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for phase in (wo3, bao2):
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})

    whap = wo3.data["Histograms"][hist.name]
    whap["Mustrain"][0] = "uniaxial"
    whap["Mustrain"][1][0] = 8000.0
    whap["Mustrain"][1][1] = 8000.0
    whap["Mustrain"][2][0] = True
    whap["Mustrain"][2][1] = True
    whap["Mustrain"][3] = AXES[args.axis]

    bhap = bao2.data["Histograms"][hist.name]
    bhap["Mustrain"][0] = "isotropic"
    bhap["Mustrain"][2][0] = True

    for index in (0, 1):
        for suffix, low, high in (
            ("Mustrain;i", 0.0, 20000.0),
            ("Mustrain;a", 0.0, 20000.0),
            ("Size;i", 0.015, 10.0),
        ):
            variable = f"{index}:0:{suffix}"
            project.set_Controls("parmMin", low, variable)
            project.set_Controls("parmMax", high, variable)

    refine(project, "strain")

    # With the strain direction selected in this branch, re-optimize the
    # already-supported isotropic size terms.
    for phase in (wo3, bao2):
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine(project, "size")

    project.save()
    out = {
        "axis": args.axis,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items() if isinstance(v, list) and len(v) > 1},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "short_distances": phase.ShortDistances(),
        }
    (root / "summary.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
