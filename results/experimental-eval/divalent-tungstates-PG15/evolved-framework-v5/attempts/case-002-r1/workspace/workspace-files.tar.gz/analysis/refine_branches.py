#!/usr/bin/env python3
"""Create comparable first-pass GSAS-II fits for candidate phase inventories."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summarize(gpx: G2.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    out = {
        "label": label,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) >= 2},
        "sample": {k: v[0] for k, v in sample.items() if isinstance(v, list) and v},
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "short_distances": phase.ShortDistances(),
        }
    print(json.dumps(out, indent=2, default=lambda x: float(x) if isinstance(x, np.generic) else str(x)))
    return out


def refine_step(gpx: G2.G2Project, label: str) -> None:
    gpx.refine(makeBack=False)
    hist = gpx.histogram(0)
    print(f"STEP {label}: wR={hist.get_wR():.5f} residuals={hist.residuals}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("phase", nargs="+", help="name=COD-ID")
    parser.add_argument("--outdir", default="analysis/branches")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    root = Path(args.outdir) / args.label
    root.mkdir(parents=True, exist_ok=True)
    gpx = G2.G2Project(newgpx=str(root / "model.gpx"))
    hist = gpx.add_powder_histogram(
        "analysis/pattern.xye", "analysis/instrument.instprm", fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [500.0] + [0.0] * 11,
            "refine": True,
        },
    })

    phases = []
    for spec in args.phase:
        name, cod_id = spec.split("=", 1)
        phase = gpx.add_phase(str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF")
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        phases.append(phase)

    gpx.set_Controls("cycles", 8)
    # Keep calibration and profile terms in broad but physical regions.
    for variable, low, high in (
        (":0:Shift", -1200.0, 1200.0),
        (":0:U", 0.0, 100.0),
        (":0:W", 0.0, 100.0),
        (":0:X", 0.0, 15.0),
    ):
        gpx.set_Controls("parmMin", low, variable)
        gpx.set_Controls("parmMax", high, variable)
    for index in range(len(phases)):
        for suffix, low, high in (("Size;i", 0.02, 10.0), ("Mustrain;i", 0.0, 10000.0)):
            variable = f"{index}:0:{suffix}"
            gpx.set_Controls("parmMin", low, variable)
            gpx.set_Controls("parmMax", high, variable)
    refine_step(gpx, "background+scales")

    # Refine a common angular correction before allowing the individual cells to move.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_step(gpx, "+sample shift")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine_step(gpx, "+cells")

    # Add phase-specific broadening first, then the common instrument width.
    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    refine_step(gpx, "+phase profile")
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine_step(gpx, "+instrument profile")

    gpx.save()
    out = summarize(gpx, args.label)
    (root / "summary.json").write_text(json.dumps(out, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
