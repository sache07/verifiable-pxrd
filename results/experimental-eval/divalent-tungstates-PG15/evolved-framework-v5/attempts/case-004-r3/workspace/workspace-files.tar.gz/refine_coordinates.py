from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def report(g, label):
    h = g.histograms()[0]
    rows = []
    for p in g.phases():
        atoms = []
        for a in p.atoms():
            atoms.append({'label': a.label, 'xyz': list(a.coordinates),
                          'uiso': a.data[p.data['General']['AtomPtrs'][3] + 1],
                          'flags': a.refinement_flags})
        rows.append({'name': p.name, 'cell': p.get_cell(), 'atoms': atoms})
        p.export_CIF(str(ROOT / f'{label}_{p.name}.cif'))
    print(json.dumps({'stage': label, 'rwp': h.get_wR(),
                      'gof': g.data['Covariance']['data'].get('Rvals', {}).get('GOF'),
                      'phases': rows}), flush=True)


def run(g, label):
    g.set_Controls('cycles', 5)
    g.refine()
    out = ROOT / f'{label}.gpx'
    g.save(str(out))
    report(g, label)


def main():
    G2.SetPrintLevel('warn')
    g = G2.G2Project(gpxfile=str(ROOT / 'fixed_profile_2.gpx'))
    g.set_Frozen()
    co, wo = g.phases()
    # Hold phase-specific broadening fixed during coordinate recovery.
    for p in [co, wo]:
        p.clear_HAP_refinements({'Size': True, 'Mustrain': True})
        p.set_refinements({'Cell': False})
    co.set_refinements({'Atoms': {'W1': 'X', 'Co1': 'X'}})
    run(g, 'coord_1_co_heavy')
    wo.set_refinements({'Atoms': {'W1': 'X', 'W2': 'X'}})
    run(g, 'coord_2_all_heavy')
    co.set_refinements({'Atoms': {'O1': 'X', 'O2': 'X'}})
    run(g, 'coord_3_co_oxygen')
    for label in ['O1', 'O2', 'O3', 'O4', 'O5', 'O6']:
        wo.set_refinements({'Atoms': {label: 'X'}})
    run(g, 'coord_4_all_oxygen')


if __name__ == '__main__':
    main()
