from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'initial_zero.gpx'
TRIALS = [
    # U, W, X, Co size, Co strain, WO3 size, WO3 strain
    (20., 25., 2.5, 0.040, 0., 0.061, 1120.),
    (35., 35., 5.0, 0.040, 0., 0.084, 1265.),
    (40., 40., 6.0, 0.040, 0., 0.103, 1375.),
    (20., 20., 2.0, 0.050, 1000., 0.100, 2000.),
]


def main():
    G2.SetPrintLevel('warn')
    for i, vals in enumerate(TRIALS):
        u, w, x, cs, cm, ws, wm = vals
        g = G2.G2Project(gpxfile=str(BASE))
        out = ROOT / f'physical_grid_{i}.gpx'
        g.save(str(out))
        g.set_Frozen()
        h = g.histograms()[0]
        inst = h.data['Instrument Parameters'][0]
        for key, value in [('U', u), ('V', 0.), ('W', w), ('X', x), ('Y', 0.), ('Z', 0.)]:
            inst[key][1] = value
            inst[key][2] = False
        for p, size, strain in zip(g.phases(), [cs, ws], [cm, wm]):
            for a in p.atoms():
                a.refinement_flags = ''
            p.set_refinements({'Cell': True})
            p.clear_HAP_refinements({'Size': True, 'Mustrain': True})
            hap = p.data['Histograms'][h.name]
            hap['Size'][0] = 'isotropic'
            hap['Size'][1][0] = size
            hap['Mustrain'][0] = 'isotropic'
            hap['Mustrain'][1][0] = strain
        # Remove old bound controls entirely; all profile values are now fixed.
        g.data['Controls']['data']['parmMinDict'] = {}
        g.data['Controls']['data']['parmMaxDict'] = {}
        g.data['Controls']['data']['parmFrozen'] = {}
        g.set_Controls('cycles', 10)
        g.refine()
        row = {'trial': i, 'rwp': h.get_wR(), 'instrument': [u,w,x], 'zero': inst['Zero'][1],
               'phases': []}
        for p in g.phases():
            hap = p.data['Histograms'][h.name]
            row['phases'].append([p.name, hap['Scale'][0], list(p.get_cell().values()),
                                  hap['Size'][1][0], hap['Mustrain'][1][0]])
        print(json.dumps(row), flush=True)
        g.save(str(out))


if __name__ == '__main__':
    main()
