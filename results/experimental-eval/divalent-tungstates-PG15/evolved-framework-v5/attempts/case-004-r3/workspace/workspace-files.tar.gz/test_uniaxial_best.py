from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent
AXES=[[0,0,1],[1,0,0],[0,1,0]]

def main():
    G2.SetPrintLevel('warn')
    for axis in AXES:
        tag=''.join(map(str,axis));g=G2.G2Project(gpxfile=str(ROOT/'inst_grid_1.gpx'))
        out=ROOT/f'uniax_best_{tag}.gpx';g.save(str(out));h=g.histograms()[0];inst=h.data['Instrument Parameters'][0]
        for k in inst:
            if isinstance(inst[k],list)and len(inst[k])>2:inst[k][2]=False
        for p in g.phases():p.set_refinements({'Cell':False});p.clear_HAP_refinements({'Size':True,'Mustrain':True,'Pref.Ori.':True})
        p=g.phase('WO3');m=p.data['Histograms'][h.name]['Mustrain'];iso=m[1][0]
        m[0]='uniaxial';m[1][0]=iso;m[1][1]=iso;m[2]=[False,True,False];m[3]=axis
        g.set_Controls('cycles',8)
        for i in range(3):g.refine()
        print(json.dumps({'axis':axis,'rwp':h.get_wR(),'eq':m[1][0],'ax':m[1][1],
          'ratio':m[1][1]/m[1][0],'max_shift':g.data['Covariance']['data'].get('Rvals',{}).get('Max shft/sig')}),flush=True)
        g.save(str(out))

if __name__=='__main__':main()
