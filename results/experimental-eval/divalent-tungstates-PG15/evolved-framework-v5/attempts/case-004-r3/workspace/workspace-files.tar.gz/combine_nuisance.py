from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def main():
    G2.SetPrintLevel('warn')
    g = G2.G2Project(gpxfile=str(ROOT / 'bounded_oxygen.gpx'))
    out = ROOT / 'nuisance_combined.gpx'
    g.save(str(out))
    h = g.histograms()[0]
    inst = h.data['Instrument Parameters'][0]
    starts = {'U':20.0, 'V':0.0, 'W':21.73, 'X':1.378, 'Y':0.0, 'Z':0.0,
              'SH/L':0.03, 'Polariz.':0.7618}
    for key, val in starts.items():
        inst[key][1] = val
        inst[key][2] = key in ['W','X','Polariz.']
    inst['Zero'][2] = True
    h.SampleParameters['Shift'] = [0.0, False]
    g.set_Controls('cycles', 8)
    for i in range(4):
        g.refine()
        print(json.dumps({'pass':i+1, 'rwp':h.get_wR(),
                          'values':{k:inst[k][1] for k in ['Zero','U','W','X','SH/L','Polariz.']},
                          'max_shift':g.data['Covariance']['data'].get('Rvals',{}).get('Max shft/sig')}),flush=True)
    g.save(str(out))


if __name__ == '__main__':
    main()
