from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
MODELS = {
    '2311041': COD / '2/31/10/2311041.cif',
    '2106293': COD / '2/10/62/2106293.cif',
}
BACKGROUND = [863.109824442517, -476.44379969176276, 487.0469062862509,
              -287.43641714262054, 159.8843778320702, -80.27078515577611,
              45.15053397850302, -25.205208010052402, 26.033231598712835,
              -8.211061760306828, 4.806625031820622, -4.529960989078882]


def main():
    G2.SetPrintLevel('warn')
    for codid, cif in MODELS.items():
        out = ROOT / f'wo3_model_{codid}.gpx'
        g = G2.G2Project(newgpx=str(out))
        co = g.add_phase(str(ROOT / 'co_wo4_start.cif'), phasename='CoWO4', fmthint='CIF')
        wo = g.add_phase(str(cif), phasename='WO3', fmthint='CIF')
        h = g.add_powder_histogram(str(ROOT / 'inputs/pattern.csv'), str(ROOT / 'instrument.instprm'),
                                   phases=[co, wo], fmthint='comma/tab/semicolon')
        h.SampleParameters['Type'] = 'Bragg-Brentano'
        h.SampleParameters['Gonio. radius'] = 200.0
        y = np.asarray(h.data['data'][1][1], float)
        h.data['data'][1][2] = 1.0 / np.maximum(y, 1.0)
        h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12,
                                          'coeffs': BACKGROUND, 'refine': True}})
        inst = h.data['Instrument Parameters'][0]
        for key, value in [('Zero', 0.0893), ('U', 20.), ('V', 0.), ('W', 25.),
                           ('X', 2.5), ('Y', 0.), ('Z', 0.)]:
            inst[key][1] = value
            inst[key][2] = key == 'Zero'
        for p, scale, size, strain in [(co, 8.9, 0.040, 0.), (wo, 6.03, 0.061, 1120.)]:
            p.set_refinements({'Cell': True})
            hap = p.data['Histograms'][h.name]
            hap['Scale'] = [scale, True]
            hap['Size'][0] = 'isotropic'
            hap['Size'][1][0] = size
            hap['Size'][2] = [False, False, False]
            hap['Mustrain'][0] = 'isotropic'
            hap['Mustrain'][1][0] = strain
            hap['Mustrain'][2] = [False, False, False]
        g.set_Controls('cycles', 10)
        for i in range(5):
            g.refine()
            print(json.dumps({'model': codid, 'pass': i + 1, 'rwp': h.get_wR(),
                              'max_shift': g.data['Covariance']['data'].get('Rvals', {}).get('Max shft/sig')}), flush=True)
        g.save(str(out))
        for p in g.phases():
            p.export_CIF(str(ROOT / f'wo3_model_{codid}_{p.name}.cif'))


if __name__ == '__main__':
    main()
