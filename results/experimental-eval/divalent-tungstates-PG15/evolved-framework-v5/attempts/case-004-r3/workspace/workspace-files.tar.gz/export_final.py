from __future__ import annotations

from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE_PROJECT = ROOT / "best_physical.bak0.gpx"
FINAL_PROJECT = ROOT / "final.gpx"


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE_PROJECT))
    histogram = project.histograms()[0]

    # Preserve the complete converged refinement state, including covariance,
    # in the submitted replayable project.
    project.save(str(FINAL_PROJECT))

    profile = np.asarray(histogram.data["data"][1], dtype=float)
    two_theta, observed, weights, calculated, background, _saved_difference = profile
    difference = observed - calculated
    fit = np.column_stack(
        (two_theta, observed, calculated, difference, background)
    )
    np.savetxt(
        ROOT / "fit.csv",
        fit,
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f", "%.10f"],
    )

    phases = project.phases()
    masses = np.asarray([p.data["General"]["Mass"] for p in phases], dtype=float)
    scales = np.asarray(
        [p.data["Histograms"][histogram.name]["Scale"][0] for p in phases],
        dtype=float,
    )
    mass_scale = masses * scales
    fractions = mass_scale / mass_scale.sum()

    # Export exactly the saved atom records. Clearing only the in-memory
    # covariance prevents an exporter from substituting stale covariance values;
    # final.gpx above retains its full covariance and refinement history.
    project.data["Covariance"]["data"] = {}
    cif_paths = []
    for phase in phases:
        path = ROOT / f"phase_{phase.name}.cif"
        phase.export_CIF(str(path))
        cif_paths.append(path.name)

    rvals = G2.G2Project(gpxfile=str(FINAL_PROJECT)).data["Covariance"]["data"][
        "Rvals"
    ]
    denominator = float(np.sum(weights * observed**2))
    loss = float(np.sum(weights * difference**2))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    metrics = {
        "histogram": histogram.name,
        "phases": [
            {
                "name": phase.name,
                "cif_path": cif_path,
                "cell_mass": float(mass),
                "scale": float(scale),
                "weight_fraction": float(fraction),
                "cell": {k: float(v) for k, v in phase.get_cell().items()},
            }
            for phase, cif_path, mass, scale, fraction in zip(
                phases, cif_paths, masses, scales, fractions
            )
        ],
        "fit_statistics": {
            "rwp_percent": float(100.0 * np.sqrt(loss / denominator)),
            "rp_percent": rp,
            "chi_square": loss,
            "goodness_of_fit": float(rvals["GOF"]),
            "reduced_chi_square": float(rvals["GOF"] ** 2),
            "n_observations": int(rvals["Nobs"]),
            "n_variables": int(rvals["Nvars"]),
        },
        "project_rwp_percent": float(rvals["Rwp"]),
        "max_shift_over_sigma": float(rvals["Max shft/sig"]),
        "profile_rows": int(len(two_theta)),
        "profile_range_deg": [float(two_theta[0]), float(two_theta[-1])],
        "calculated_minimum": float(calculated.min()),
        "background_minimum": float(background.min()),
    }
    (ROOT / "final_metrics.json").write_text(
        json.dumps(metrics, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(metrics, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
