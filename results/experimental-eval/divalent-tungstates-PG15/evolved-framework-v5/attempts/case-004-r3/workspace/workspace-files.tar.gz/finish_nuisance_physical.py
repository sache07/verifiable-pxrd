from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def main():
    G2.SetPrintLevel('warn')
    g = G2.G2Project(gpxfile=str(ROOT / 'nuisance_combined.bak0.gpx'))
    out = ROOT / 'nuisance_physical.gpx'
    g.save(str(out))
    h = g.histograms()[0]
    inst = h.data['Instrument Parameters'][0]
    inst['X'][1], inst['X'][2] = 0.1, False
    inst['W'][2] = True
    inst['Polariz.'][2] = True
    inst['U'][2] = False
    inst['Zero'][2] = True
    g.set_Controls('cycles',8)
    for i in range(5):
        g.refine()
        print(json.dumps({'pass':i+1,'rwp':h.get_wR(),
                          'values':{k:inst[k][1] for k in ['Zero','U','W','X','Polariz.']},
                          'max_shift':g.data['Covariance']['data'].get('Rvals',{}).get('Max shft/sig')}),flush=True)
    g.save(str(out))


if __name__ == '__main__':
    main()
