from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent
TRIALS=[('CoWO4','Size'),('CoWO4','Mustrain'),('WO3','Size'),('WO3','Mustrain')]

def main():
    G2.SetPrintLevel('warn')
    for pname,target in TRIALS:
        g=G2.G2Project(gpxfile=str(ROOT/'texture_nuisance.gpx'))
        out=ROOT/f'profile_{pname}_{target}.gpx';g.save(str(out))
        h=g.histograms()[0];inst=h.data['Instrument Parameters'][0]
        for k in inst:
            if isinstance(inst[k],list)and len(inst[k])>2:inst[k][2]=False
        for p in g.phases():
            p.set_refinements({'Cell':False})
            p.clear_HAP_refinements({'Size':True,'Mustrain':True,'Pref.Ori.':True})
        p=g.phase(pname)
        if target=='Size':p.set_HAP_refinements({'Size':{'type':'isotropic','refine':True}})
        else:p.set_HAP_refinements({'Mustrain':{'type':'isotropic','refine':True}})
        g.set_Controls('cycles',8)
        for i in range(3):g.refine()
        hap=p.data['Histograms'][h.name]
        print(json.dumps({'phase':pname,'term':target,'rwp':h.get_wR(),
          'size':hap['Size'][1][0],'mustrain':hap['Mustrain'][1][0],
          'max_shift':g.data['Covariance']['data'].get('Rvals',{}).get('Max shft/sig')}),flush=True)
        g.save(str(out))

if __name__=='__main__':main()
