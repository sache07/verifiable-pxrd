from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent

# Instrument starts and phase starts: U, W, X, Co size/strain, WO3 size/strain.
STARTS = [
    (5., 10., 1., 0.10, 500., 0.30, 3000.),
    (15., 20., 2., 0.12, 1000., 0.35, 3000.),
    (30., 30., 4., 0.16, 1000., 0.45, 2000.),
    (10., 35., 5., 0.20, 2000., 0.60, 1000.),
    (35., 8., 1., 0.08, 3000., 0.25, 5000.),
    (20., 25., 5.5, 0.30, 3000., 0.80, 4000.),
]


def summary(gpx, branch):
    h = gpx.histograms()[0]
    inst = h.data['Instrument Parameters'][0]
    phases = []
    for p in gpx.phases():
        hap = p.data['Histograms'][h.name]
        phases.append({
            'name': p.name,
            'cell': list(p.get_cell().values()),
            'scale': hap['Scale'][0],
            'size': hap['Size'][1][0],
            'mustrain': hap['Mustrain'][1][0],
        })
    print(json.dumps({
        'branch': branch,
        'rwp': h.get_wR(),
        'gof': gpx.data['Covariance']['data'].get('Rvals', {}).get('GOF'),
        'instrument': {k: inst[k][1] for k in ['Zero', 'U', 'V', 'W', 'X', 'SH/L']},
        'frozen': gpx.get_Frozen(),
        'phases': phases,
    }))


def main():
    G2.SetPrintLevel('warn')
    for i, start in enumerate(STARTS):
        u, w, x, cs, cm, ws, wm = start
        gpx = G2.G2Project(gpxfile=str(ROOT / 'initial_zero.gpx'))
        h = gpx.histograms()[0]
        inst = h.data['Instrument Parameters'][0]
        for key, val in [('U', u), ('V', 0.), ('W', w), ('X', x), ('Y', 0.), ('Z', 0.)]:
            inst[key][1] = val
            inst[key][2] = key in ['U', 'W', 'X']
        h.set_refinements({'Instrument Parameters': ['U', 'W', 'X']})
        for p, size, strain in zip(gpx.phases(), [cs, ws], [cm, wm]):
            hap = p.data['Histograms'][h.name]
            hap['Size'][0] = 'isotropic'
            hap['Size'][1][0] = size
            hap['Size'][2] = [True, False, False]
            hap['Mustrain'][0] = 'isotropic'
            hap['Mustrain'][1][0] = strain
            hap['Mustrain'][2] = [True, False, False]
        out = ROOT / f'profile_branch_{i}.gpx'
        gpx.save(str(out))
        # Bounds are the physical support of the frozen laboratory model.
        for var, lo, hi in [
            (':0:U', 0., 40.), (':0:W', 2., 40.), (':0:X', 0.1, 6.),
            ('0:0:Size;i', 0.04, 1.5), ('1:0:Size;i', 0.04, 1.5),
            ('0:0:Mustrain;i', 0., 8000.), ('1:0:Mustrain;i', 0., 8000.),
        ]:
            gpx.set_Controls('parmMin', lo, variable=var)
            gpx.set_Controls('parmMax', hi, variable=var)
        gpx.set_Controls('cycles', 12)
        gpx.refine()
        summary(gpx, i)
        gpx.save(str(out))


if __name__ == '__main__':
    main()
