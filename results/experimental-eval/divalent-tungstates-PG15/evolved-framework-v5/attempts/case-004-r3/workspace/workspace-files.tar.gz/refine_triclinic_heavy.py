from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def report(g, stage, ipass):
    h = g.histograms()[0]
    print(json.dumps({'stage': stage, 'pass': ipass, 'rwp': h.get_wR(),
                      'max_shift': g.data['Covariance']['data'].get('Rvals', {}).get('Max shft/sig'),
                      'coords': {p.name: {a.label: list(a.coordinates) for a in p.atoms()
                                          if a.refinement_flags == 'X'} for p in g.phases()}}), flush=True)


def main():
    G2.SetPrintLevel('warn')
    g = G2.G2Project(gpxfile=str(ROOT / 'wo3_model_2106293.gpx'))
    out = ROOT / 'triclinic_heavy.gpx'
    g.save(str(out))
    co, wo = g.phases()
    for p in [co, wo]:
        p.clear_HAP_refinements({'Size': True, 'Mustrain': True})
        for a in p.atoms(): a.refinement_flags = ''
    # A bounded-start analogue adjustment for CoWO4.
    co.atom('W1').coordinates = [0.0, 0.1783, 0.25]
    co.atom('Co1').coordinates = [0.5, 0.6667, 0.25]
    co.set_refinements({'Atoms': {'W1': 'X', 'Co1': 'X'}})
    g.set_Controls('cycles', 8)
    for i in range(3):
        g.refine()
        report(g, 'CoWO4 heavy', i + 1)
    # Retain the Co/W solution and add all four independent WO3 W sites.
    for label in ['W1', 'W2', 'W3', 'W4']:
        wo.set_refinements({'Atoms': {label: 'X'}})
    for i in range(3):
        g.refine()
        report(g, 'all heavy', i + 1)
    g.save(str(out))
    for p in g.phases(): p.export_CIF(str(ROOT / f'triclinic_heavy_{p.name}.cif'))


if __name__ == '__main__':
    main()
