from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'physical_converged.gpx'
TRIALS = [
    ('co_W1', 'CoWO4', 'W1'),
    ('co_Co1', 'CoWO4', 'Co1'),
    ('wo_W1', 'WO3', 'W1'),
    ('wo_W2', 'WO3', 'W2'),
]


def main():
    G2.SetPrintLevel('warn')
    for tag, pname, atom in TRIALS:
        g = G2.G2Project(gpxfile=str(BASE))
        out = ROOT / f'single_{tag}.gpx'
        # Change the current filename before any refinement so BASE stays immutable.
        g.save(str(out))
        for p in g.phases():
            p.set_refinements({'Cell': False})
            p.clear_HAP_refinements({'Size': True, 'Mustrain': True})
            for a in p.atoms():
                a.refinement_flags = ''
        p = g.phase(pname)
        p.set_refinements({'Atoms': {atom: 'X'}})
        g.set_Controls('cycles', 8)
        g.refine()
        h = g.histograms()[0]
        row = {'trial': tag, 'rwp': h.get_wR(), 'atoms': {}}
        for phase in g.phases():
            row['atoms'][phase.name] = {a.label: list(a.coordinates) for a in phase.atoms()
                                         if a.label in ['W1', 'W2', 'Co1']}
        print(json.dumps(row), flush=True)
        g.save(str(out))


if __name__ == '__main__':
    main()
