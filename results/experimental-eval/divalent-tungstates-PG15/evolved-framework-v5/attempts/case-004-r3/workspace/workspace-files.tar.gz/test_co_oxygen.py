from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def main():
    G2.SetPrintLevel('warn')
    for label in ['O1', 'O2']:
        g = G2.G2Project(gpxfile=str(ROOT / 'triclinic_heavy.gpx'))
        out = ROOT / f'test_co_{label}.gpx'
        g.save(str(out))
        for p in g.phases():
            for a in p.atoms(): a.refinement_flags = ''
            p.clear_HAP_refinements({'Size': True, 'Mustrain': True})
        co = g.phase('CoWO4')
        co.set_refinements({'Atoms': {label: 'X'}})
        g.set_Controls('cycles', 8)
        for i in range(2): g.refine()
        h = g.histograms()[0]
        print(json.dumps({'site': label, 'rwp': h.get_wR(),
                          'coord': list(co.atom(label).coordinates),
                          'max_shift': g.data['Covariance']['data'].get('Rvals', {}).get('Max shft/sig')}), flush=True)
        g.save(str(out))
        co.export_CIF(str(ROOT / f'test_co_{label}.cif'))


if __name__ == '__main__':
    main()
