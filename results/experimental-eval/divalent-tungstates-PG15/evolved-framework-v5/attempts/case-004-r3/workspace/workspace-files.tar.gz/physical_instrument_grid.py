from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent
TRIALS=[(0.,28.,0.95),(0.,40.,1.0),(10.,35.,0.98),(20.,28.,0.95)]

def main():
    G2.SetPrintLevel('warn')
    for j,(u,w,pol) in enumerate(TRIALS):
        g=G2.G2Project(gpxfile=str(ROOT/'uiso_physical.gpx'));out=ROOT/f'inst_grid_{j}.gpx';g.save(str(out))
        h=g.histograms()[0];inst=h.data['Instrument Parameters'][0]
        for k in inst:
            if isinstance(inst[k],list)and len(inst[k])>2:inst[k][2]=False
        for k,v in [('U',u),('V',0.),('W',w),('X',0.1),('Y',0.),('Z',0.),('Polariz.',pol)]:inst[k][1]=v
        inst['Zero'][2]=True;h.SampleParameters['Scale']=[1.0,False]
        co,wo=g.phases()
        for p in [co,wo]:p.set_refinements({'Cell':True});p.clear_HAP_refinements({'Size':True,'Mustrain':True})
        co.set_HAP_refinements({'Size':{'type':'isotropic','refine':True},'Pref.Ori.':True})
        wo.set_HAP_refinements({'Size':{'type':'isotropic','refine':True},
                                'Mustrain':{'type':'isotropic','refine':True},'Pref.Ori.':True})
        g.set_Controls('cycles',8)
        for i in range(4):g.refine()
        print(json.dumps({'trial':j,'fixed':[u,w,pol],'rwp':h.get_wR(),
          'profile':{p.name:{'size':p.data['Histograms'][h.name]['Size'][1][0],
                             'strain':p.data['Histograms'][h.name]['Mustrain'][1][0],
                             'md':p.data['Histograms'][h.name]['Pref.Ori.'][1]}for p in g.phases()},
          'zero':inst['Zero'][1],
          'max_shift':g.data['Covariance']['data'].get('Rvals',{}).get('Max shft/sig')}),flush=True)
        g.save(str(out))

if __name__=='__main__':main()
