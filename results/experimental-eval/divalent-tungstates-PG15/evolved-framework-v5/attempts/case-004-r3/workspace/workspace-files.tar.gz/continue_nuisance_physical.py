from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def main():
    G2.SetPrintLevel('warn')
    g=G2.G2Project(gpxfile=str(ROOT/'nuisance_physical.gpx'))
    out=ROOT/'nuisance_physical_cont.gpx';g.save(str(out))
    h=g.histograms()[0];inst=h.data['Instrument Parameters'][0]
    g.set_Controls('cycles',8)
    for i in range(6):
        g.refine()
        print(json.dumps({'pass':i+1,'rwp':h.get_wR(),
          'values':{k:inst[k][1] for k in ['Zero','U','W','X','Polariz.']},
          'max_shift':g.data['Covariance']['data'].get('Rvals',{}).get('Max shft/sig')}),flush=True)
    g.save(str(out))

if __name__=='__main__':main()
