from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
TRIALS = [
    ('CoO', COD / '1/54/16/1541662.cif', 0.50),
    ('Co3O4', COD / '9/00/58/9005896.cif', 0.10),
]


def main():
    G2.SetPrintLevel('warn')
    for name, cif, scale in TRIALS:
        g = G2.G2Project(gpxfile=str(ROOT / 'wo3_model_2106293.gpx'))
        out = ROOT / f'residual_{name}.gpx'
        g.save(str(out))
        h = g.histograms()[0]
        for p in g.phases():
            p.set_refinements({'Cell': False})
            for a in p.atoms(): a.refinement_flags = ''
        new = g.add_phase(str(cif), phasename=name, histograms=[h], fmthint='CIF')
        new.set_refinements({'Cell': False})
        hap = new.data['Histograms'][h.name]
        hap['Scale'] = [scale, True]
        hap['Size'][0] = 'isotropic'
        hap['Size'][1][0] = 0.10
        hap['Size'][2] = [False, False, False]
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = 1000.0
        hap['Mustrain'][2] = [False, False, False]
        g.set_Controls('cycles', 8)
        for i in range(3):
            g.refine()
        masses = [p.data['General']['Mass'] * p.data['Histograms'][h.name]['Scale'][0]
                  for p in g.phases()]
        print(json.dumps({'trial': name, 'rwp': h.get_wR(),
                          'scales': {p.name: p.data['Histograms'][h.name]['Scale'][0] for p in g.phases()},
                          'fractions': {p.name: m/sum(masses) for p,m in zip(g.phases(),masses)},
                          'cell': new.get_cell()}), flush=True)
        g.save(str(out))


if __name__ == '__main__':
    main()
