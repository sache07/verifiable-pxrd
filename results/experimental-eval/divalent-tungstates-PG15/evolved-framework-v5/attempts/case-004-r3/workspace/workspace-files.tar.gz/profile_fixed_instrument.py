from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
STARTS = [
    # U, W, X, Co size/strain, WO3 size/strain
    (10., 15., 1.0, 0.08, 3000., 0.20, 4000.),
    (20., 25., 2.5, 0.08, 3000., 0.20, 4000.),
    (35., 35., 5.0, 0.08, 3000., 0.20, 4000.),
    (40., 40., 6.0, 0.06, 1000., 0.15, 2000.),
]


def main():
    G2.SetPrintLevel('warn')
    for i, vals in enumerate(STARTS):
        u, w, x, cs, cm, ws, wm = vals
        g = G2.G2Project(gpxfile=str(ROOT / 'initial_zero.gpx'))
        h = g.histograms()[0]
        inst = h.data['Instrument Parameters'][0]
        for key, value in [('U', u), ('V', 0.), ('W', w), ('X', x), ('Y', 0.), ('Z', 0.)]:
            inst[key][1] = value
            inst[key][2] = False
        for p, size, strain in zip(g.phases(), [cs, ws], [cm, wm]):
            p.set_refinements({'Cell': False})
            hap = p.data['Histograms'][h.name]
            hap['Size'][0] = 'isotropic'
            hap['Size'][1][0] = size
            hap['Size'][2] = [True, False, False]
            hap['Mustrain'][0] = 'isotropic'
            hap['Mustrain'][1][0] = strain
            hap['Mustrain'][2] = [True, False, False]
        out = ROOT / f'fixed_profile_{i}.gpx'
        g.save(str(out))
        for var, lo, hi in [
            ('0:0:Size;i', 0.04, 1.5), ('1:0:Size;i', 0.04, 1.5),
            ('0:0:Mustrain;i', 0., 8000.), ('1:0:Mustrain;i', 0., 8000.),
        ]:
            g.set_Controls('parmMin', lo, variable=var)
            g.set_Controls('parmMax', hi, variable=var)
        g.set_Controls('cycles', 5)
        g.refine()
        phases = []
        for p in g.phases():
            hap = p.data['Histograms'][h.name]
            phases.append([p.name, hap['Scale'][0], hap['Size'][1][0], hap['Mustrain'][1][0]])
        print(json.dumps({'branch': i, 'rwp': h.get_wR(), 'instrument': [u,w,x],
                          'zero': inst['Zero'][1], 'phases': phases,
                          'frozen': g.get_Frozen()}), flush=True)
        g.save(str(out))


if __name__ == '__main__':
    main()
