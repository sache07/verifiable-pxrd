from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent

def main():
    G2.SetPrintLevel('warn')
    g=G2.G2Project(gpxfile=str(ROOT/'uniax_best_010.gpx'))
    out=ROOT/'best_physical.gpx';g.save(str(out));h=g.histograms()[0];inst=h.data['Instrument Parameters'][0]
    for k in inst:
        if isinstance(inst[k],list)and len(inst[k])>2:inst[k][2]=False
    for k,v in [('U',0.),('V',0.),('W',40.),('X',0.1),('Y',0.),('Z',0.),('Polariz.',1.0)]:inst[k][1]=v
    inst['Zero'][2]=True
    h.SampleParameters['Scale']=[1.0,False];h.SampleParameters['Shift']=[0.0,False]
    h.SampleParameters['SurfRoughA']=[0.0,False];h.SampleParameters['SurfRoughB']=[0.0,False]
    co,wo=g.phases()
    for p in [co,wo]:p.set_refinements({'Cell':True});p.clear_HAP_refinements({'Size':True,'Mustrain':True})
    co.set_HAP_refinements({'Size':{'type':'isotropic','refine':True},'Pref.Ori.':True})
    m=wo.data['Histograms'][h.name]['Mustrain'];m[0]='uniaxial';m[2]=[True,True,False];m[3]=[0,1,0]
    wo.set_HAP_refinements({'Size':{'type':'isotropic','refine':True},'Pref.Ori.':True})
    g.set_Controls('cycles',8)
    for i in range(8):
        g.refine()
        print(json.dumps({'pass':i+1,'rwp':h.get_wR(),'zero':inst['Zero'][1],
          'phase':{p.name:{'cell':list(p.get_cell().values()),'scale':p.data['Histograms'][h.name]['Scale'][0],
                            'size':p.data['Histograms'][h.name]['Size'][1][0],
                            'strain':p.data['Histograms'][h.name]['Mustrain'][1][:2],
                            'md':p.data['Histograms'][h.name]['Pref.Ori.'][1]}for p in g.phases()},
          'max_shift':g.data['Covariance']['data'].get('Rvals',{}).get('Max shft/sig')}),flush=True)
    g.save(str(out))

if __name__=='__main__':main()
