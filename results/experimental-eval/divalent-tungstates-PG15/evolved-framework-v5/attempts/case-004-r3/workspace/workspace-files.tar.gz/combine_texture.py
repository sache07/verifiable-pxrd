from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent

def main():
    G2.SetPrintLevel('warn')
    g=G2.G2Project(gpxfile=str(ROOT/'stable_scale.gpx'))
    out=ROOT/'texture_combined.gpx';g.save(str(out))
    h=g.histograms()[0];inst=h.data['Instrument Parameters'][0]
    for key in inst:
        if isinstance(inst[key],list) and len(inst[key])>2:inst[key][2]=False
    specs={'CoWO4':([0,0,1],0.953),'WO3':([1,1,1],0.915)}
    for p in g.phases():
        p.set_refinements({'Cell':False})
        axis,ratio=specs[p.name];po=p.data['Histograms'][h.name]['Pref.Ori.']
        po[0]='MD';po[1]=ratio;po[2]=True;po[3]=axis
    g.set_Controls('cycles',8)
    for i in range(4):
        g.refine()
        print(json.dumps({'pass':i+1,'rwp':h.get_wR(),
          'texture':{p.name:{'ratio':p.data['Histograms'][h.name]['Pref.Ori.'][1],
                             'axis':p.data['Histograms'][h.name]['Pref.Ori.'][3]}for p in g.phases()},
          'max_shift':g.data['Covariance']['data'].get('Rvals',{}).get('Max shft/sig')}),flush=True)
    g.save(str(out))

if __name__=='__main__':main()
