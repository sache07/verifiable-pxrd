from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
TRIALS = ['U', 'W', 'X', 'SH/L', 'Polariz.', 'Shift']


def main():
    G2.SetPrintLevel('warn')
    for target in TRIALS:
        g = G2.G2Project(gpxfile=str(ROOT / 'bounded_oxygen.gpx'))
        tag = target.replace('/', '_').replace('.', '')
        out = ROOT / f'nuisance_{tag}.gpx'
        g.save(str(out))
        h = g.histograms()[0]
        inst = h.data['Instrument Parameters'][0]
        for key in ['U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L', 'Polariz.']:
            inst[key][2] = False
        h.SampleParameters['Shift'][1] = False
        if target == 'Shift':
            inst['Zero'][2] = False
            h.SampleParameters['Shift'] = [0.0, True]
        else:
            inst['Zero'][2] = True
            inst[target][2] = True
        g.set_Controls('cycles', 8)
        for i in range(3): g.refine()
        vals = {k: inst[k][1] for k in ['Zero','U','V','W','X','Y','Z','SH/L','Polariz.']}
        vals['Shift'] = h.SampleParameters['Shift'][0]
        print(json.dumps({'trial': target, 'rwp': h.get_wR(), 'values': vals,
                          'max_shift': g.data['Covariance']['data'].get('Rvals', {}).get('Max shft/sig')}), flush=True)
        g.save(str(out))


if __name__ == '__main__':
    main()
