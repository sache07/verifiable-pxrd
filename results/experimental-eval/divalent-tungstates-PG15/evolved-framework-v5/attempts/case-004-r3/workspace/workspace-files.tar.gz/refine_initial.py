from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
WO3 = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif')


def snapshot(gpx, label):
    h = gpx.histograms()[0]
    row = {
        'label': label,
        'rwp': h.get_wR(),
        'gof': gpx.data.get('Covariance', {}).get('data', {}).get('Rvals', {}).get('GOF'),
        'instrument': {k: v for k, v in h.data['Instrument Parameters'][0].items()
                       if k in ['Lam1', 'Lam2', 'I(L2)/I(L1)', 'Zero', 'Polariz.', 'U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L']},
        'sample': h.data['Sample Parameters'],
        'background': h.data['Background'][0],
        'phases': []
    }
    for p in gpx.phases():
        hap = p.data['Histograms'][h.name]
        row['phases'].append({
            'name': p.name,
            'cell': p.get_cell(),
            'mass': p.data['General']['Mass'],
            'scale': hap['Scale'],
            'size': hap['Size'],
            'mustrain': hap['Mustrain'],
            'pref_ori': hap['Pref.Ori.'],
            'atoms': [a.data for a in p.atoms()],
        })
    print(json.dumps(row, default=str))


def refine(gpx, label):
    gpx.refine()
    snapshot(gpx, label)
    gpx.save(str(ROOT / f'initial_{label}.gpx'))


def main():
    G2.SetPrintLevel('warn')
    gpx = G2.G2Project(newgpx=str(ROOT / 'initial_work.gpx'))
    co = gpx.add_phase(str(ROOT / 'co_wo4_start.cif'), phasename='CoWO4', fmthint='CIF')
    wo = gpx.add_phase(str(WO3), phasename='WO3', fmthint='CIF')
    hist = gpx.add_powder_histogram(str(ROOT / 'inputs/pattern.csv'), str(ROOT / 'instrument.instprm'),
                                    phases=[co, wo], fmthint='comma/tab/semicolon')
    hist.SampleParameters['Type'] = 'Bragg-Brentano'
    hist.SampleParameters['Gonio. radius'] = 200.0
    hist.data['Limits'][1] = [float(hist.data['data'][1][0][0]), float(hist.data['data'][1][0][-1])]
    # Poisson weights are appropriate for the original count data.
    y = np.asarray(hist.data['data'][1][1], float)
    hist.data['data'][1][2] = 1.0 / np.maximum(y, 1.0)
    hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12,
                                         'coeffs': [900.0] + [0.0] * 11, 'refine': True}})
    hist.SampleParameters['Scale'] = [1.0, False]
    for p, scale in [(co, 0.003), (wo, 0.003)]:
        hap = p.data['Histograms'][hist.name]
        hap['Scale'] = [scale, True]
        hap['Size'][0] = 'isotropic'
        hap['Size'][1][0] = 0.15
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = 1000.0
    gpx.set_Controls('cycles', 8)
    snapshot(gpx, 'setup')
    refine(gpx, 'scales_background')
    # Refine a single angular offset first, then cells.
    hist.set_refinements({'Instrument Parameters': ['Zero']})
    refine(gpx, 'zero')
    co.set_refinements({'Cell': True})
    wo.set_refinements({'Cell': True})
    refine(gpx, 'cells')
    # Peak widths: instrument terms first, then phase broadening.
    hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X']})
    refine(gpx, 'instrument_profile')
    hist.clear_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X']})
    for p in [co, wo]:
        p.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True},
                               'Mustrain': {'type': 'isotropic', 'refine': True}})
    refine(gpx, 'phase_profile')
    gpx.save(str(ROOT / 'initial_two_phase.gpx'))


if __name__ == '__main__':
    main()
