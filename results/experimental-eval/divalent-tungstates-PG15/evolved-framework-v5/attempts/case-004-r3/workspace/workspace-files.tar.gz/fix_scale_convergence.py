from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent

def main():
    G2.SetPrintLevel('warn')
    g=G2.G2Project(gpxfile=str(ROOT/'nuisance_physical_cont.gpx'))
    out=ROOT/'stable_scale.gpx';g.save(str(out))
    h=g.histograms()[0];h.SampleParameters['Scale']=[1.0,False]
    inst=h.data['Instrument Parameters'][0]
    g.set_Controls('cycles',8)
    for i in range(8):
        g.refine()
        print(json.dumps({'pass':i+1,'rwp':h.get_wR(),
          'sample_scale':h.SampleParameters['Scale'],
          'phase_scales':{p.name:p.data['Histograms'][h.name]['Scale'][0]for p in g.phases()},
          'instrument':{k:inst[k][1]for k in ['Zero','U','W','X','Polariz.']},
          'max_shift':g.data['Covariance']['data'].get('Rvals',{}).get('Max shft/sig')}),flush=True)
    g.save(str(out))

if __name__=='__main__':main()
