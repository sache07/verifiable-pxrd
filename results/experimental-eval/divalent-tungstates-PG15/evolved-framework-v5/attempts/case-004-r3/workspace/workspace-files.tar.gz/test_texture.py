from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent
AXES=[[0,0,1],[1,0,0],[0,1,0],[1,1,0],[1,1,1]]

def main():
    G2.SetPrintLevel('warn')
    for pname in ['CoWO4','WO3']:
        for axis in AXES:
            tag=''.join(map(str,axis))
            g=G2.G2Project(gpxfile=str(ROOT/'stable_scale.gpx'))
            out=ROOT/f'texture_{pname}_{tag}.gpx';g.save(str(out))
            h=g.histograms()[0];inst=h.data['Instrument Parameters'][0]
            for key in inst: 
                if isinstance(inst[key],list) and len(inst[key])>2:inst[key][2]=False
            for p in g.phases():
                p.set_refinements({'Cell':False})
                po=p.data['Histograms'][h.name]['Pref.Ori.'];po[1]=1.0;po[2]=False
            p=g.phase(pname);po=p.data['Histograms'][h.name]['Pref.Ori.']
            po[0]='MD';po[1]=1.0;po[2]=True;po[3]=axis
            g.set_Controls('cycles',8)
            for i in range(2):g.refine()
            print(json.dumps({'phase':pname,'axis':axis,'ratio':po[1],'rwp':h.get_wR(),
              'max_shift':g.data['Covariance']['data'].get('Rvals',{}).get('Max shft/sig')}),flush=True)
            g.save(str(out))

if __name__=='__main__':main()
