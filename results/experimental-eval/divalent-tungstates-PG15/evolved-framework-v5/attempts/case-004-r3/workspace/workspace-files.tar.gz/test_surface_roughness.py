from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent
STARTS=[(0.1,0.05),(0.3,0.1),(0.5,0.3)]

def main():
    G2.SetPrintLevel('warn')
    for j,(a,b) in enumerate(STARTS):
        g=G2.G2Project(gpxfile=str(ROOT/'uiso_physical.gpx'));out=ROOT/f'roughness_{j}.gpx';g.save(str(out))
        h=g.histograms()[0];inst=h.data['Instrument Parameters'][0]
        for k in inst:
            if isinstance(inst[k],list)and len(inst[k])>2:inst[k][2]=False
        for p in g.phases():
            p.set_refinements({'Cell':False});p.clear_HAP_refinements({'Size':True,'Mustrain':True,'Pref.Ori.':True})
        h.SampleParameters['SurfRoughA']=[a,True];h.SampleParameters['SurfRoughB']=[b,True]
        h.SampleParameters['Shift'][1]=False
        g.set_Controls('cycles',8)
        for i in range(3):g.refine()
        print(json.dumps({'start':[a,b],'rwp':h.get_wR(),
          'A':h.SampleParameters['SurfRoughA'][0],'B':h.SampleParameters['SurfRoughB'][0],
          'max_shift':g.data['Covariance']['data'].get('Rvals',{}).get('Max shft/sig')}),flush=True)
        g.save(str(out))

if __name__=='__main__':main()
