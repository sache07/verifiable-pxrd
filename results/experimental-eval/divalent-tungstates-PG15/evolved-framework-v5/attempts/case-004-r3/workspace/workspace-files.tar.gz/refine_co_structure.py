from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def emit(g, stage, i):
    h = g.histograms()[0]
    co = g.phase('CoWO4')
    print(json.dumps({'stage': stage, 'pass': i, 'rwp': h.get_wR(),
                      'coords': {a.label: list(a.coordinates) for a in co.atoms()},
                      'max_shift': g.data['Covariance']['data'].get('Rvals', {}).get('Max shft/sig')}), flush=True)


def main():
    G2.SetPrintLevel('warn')
    g = G2.G2Project(gpxfile=str(ROOT / 'triclinic_heavy.gpx'))
    out = ROOT / 'triclinic_co_structure.gpx'
    g.save(str(out))
    for p in g.phases():
        for a in p.atoms(): a.refinement_flags = ''
        p.clear_HAP_refinements({'Size': True, 'Mustrain': True})
    co = g.phase('CoWO4')
    co.atom('O1').coordinates = [0.22542, 0.10555, -0.07776]
    co.atom('O2').coordinates = [0.25690, 0.38570, 0.41839]
    co.set_refinements({'Atoms': {'O1': 'X', 'O2': 'X'}})
    g.set_Controls('cycles', 8)
    for i in range(2):
        g.refine(); emit(g, 'oxygen', i + 1)
    co.set_refinements({'Atoms': {'W1': 'X', 'Co1': 'X'}})
    for i in range(2):
        g.refine(); emit(g, 'all CoWO4', i + 1)
    g.save(str(out))
    for p in g.phases(): p.export_CIF(str(ROOT / f'triclinic_co_structure_{p.name}.cif'))


if __name__ == '__main__':
    main()
