from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent

def main():
    G2.SetPrintLevel('warn')
    g=G2.G2Project(gpxfile=str(ROOT/'texture_combined.gpx'))
    out=ROOT/'texture_nuisance.gpx';g.save(str(out))
    h=g.histograms()[0];inst=h.data['Instrument Parameters'][0]
    for p in g.phases():p.set_refinements({'Cell':True})
    for key in inst:
        if isinstance(inst[key],list)and len(inst[key])>2:inst[key][2]=False
    inst['Zero'][2]=True;inst['W'][2]=True;inst['Polariz.'][2]=True
    inst['X'][1],inst['X'][2]=0.1,False
    h.SampleParameters['Scale']=[1.0,False]
    g.set_Controls('cycles',8)
    for i in range(8):
        g.refine()
        print(json.dumps({'pass':i+1,'rwp':h.get_wR(),
          'instrument':{k:inst[k][1]for k in ['Zero','U','W','X','Polariz.']},
          'texture':{p.name:p.data['Histograms'][h.name]['Pref.Ori.'][1]for p in g.phases()},
          'max_shift':g.data['Covariance']['data'].get('Rvals',{}).get('Max shft/sig')}),flush=True)
    g.save(str(out))

if __name__=='__main__':main()
