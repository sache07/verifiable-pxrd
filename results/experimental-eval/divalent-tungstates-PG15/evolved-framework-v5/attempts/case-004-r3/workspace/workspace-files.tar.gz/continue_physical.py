from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def main():
    G2.SetPrintLevel('warn')
    g = G2.G2Project(gpxfile=str(ROOT / 'physical_grid_0.gpx'))
    out = ROOT / 'physical_converged.gpx'
    g.save(str(out))
    g.set_Controls('cycles', 10)
    for i in range(6):
        g.refine()
        h = g.histograms()[0]
        print(json.dumps({'pass': i + 1, 'rwp': h.get_wR(),
                          'max_shift': g.data['Covariance']['data'].get('Rvals', {}).get('Max shft/sig')}), flush=True)
    g.save(str(out))


if __name__ == '__main__':
    main()
