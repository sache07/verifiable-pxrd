from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent

def main():
    G2.SetPrintLevel('warn')
    g=G2.G2Project(gpxfile=str(ROOT/'texture_nuisance.gpx'))
    out=ROOT/'profile_combined.gpx';g.save(str(out))
    h=g.histograms()[0];inst=h.data['Instrument Parameters'][0]
    for k in inst:
        if isinstance(inst[k],list)and len(inst[k])>2:inst[k][2]=False
    co,wo=g.phases()
    for p in [co,wo]:
        p.set_refinements({'Cell':False})
        p.clear_HAP_refinements({'Size':True,'Mustrain':True,'Pref.Ori.':True})
    hc=co.data['Histograms'][h.name];hc['Size'][1][0]=0.06874
    co.set_HAP_refinements({'Size':{'type':'isotropic','refine':True}})
    hw=wo.data['Histograms'][h.name];hw['Size'][1][0]=0.05621;hw['Mustrain'][1][0]=1901.1
    wo.set_HAP_refinements({'Size':{'type':'isotropic','refine':True},
                            'Mustrain':{'type':'isotropic','refine':True}})
    g.set_Controls('cycles',8)
    for i in range(4):
        g.refine()
        print(json.dumps({'pass':i+1,'rwp':h.get_wR(),
          'profile':{p.name:{'size':p.data['Histograms'][h.name]['Size'][1][0],
                             'mustrain':p.data['Histograms'][h.name]['Mustrain'][1][0]}for p in g.phases()},
          'max_shift':g.data['Covariance']['data'].get('Rvals',{}).get('Max shft/sig')}),flush=True)
    g.save(str(out))

if __name__=='__main__':main()
