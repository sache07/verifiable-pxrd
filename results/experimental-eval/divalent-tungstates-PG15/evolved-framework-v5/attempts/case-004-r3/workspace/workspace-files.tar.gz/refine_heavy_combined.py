from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def main():
    G2.SetPrintLevel('warn')
    g = G2.G2Project(gpxfile=str(ROOT / 'physical_converged.gpx'))
    out = ROOT / 'heavy_combined.gpx'
    g.save(str(out))
    co, wo = g.phases()
    for p in [co, wo]:
        p.clear_HAP_refinements({'Size': True, 'Mustrain': True})
        for a in p.atoms():
            a.refinement_flags = ''
    starts = {
        ('CoWO4', 'W1'): [0.0, 0.17803, 0.25],
        ('CoWO4', 'Co1'): [0.5, 0.66500, 0.25],
        ('WO3', 'W1'): [0.25139, 0.02949, 0.28585],
        ('WO3', 'W2'): [0.24886, 0.03504, 0.78206],
    }
    for (pname, label), xyz in starts.items():
        atom = g.phase(pname).atom(label)
        atom.coordinates = xyz
        atom.refinement_flags = 'X'
    g.set_Controls('cycles', 8)
    for i in range(3):
        g.refine()
        h = g.histograms()[0]
        print(json.dumps({'pass': i + 1, 'rwp': h.get_wR(),
                          'max_shift': g.data['Covariance']['data'].get('Rvals', {}).get('Max shft/sig'),
                          'coords': {p.name: {a.label: list(a.coordinates) for a in p.atoms()
                                              if a.refinement_flags == 'X'} for p in g.phases()}}), flush=True)
    g.save(str(out))
    for p in g.phases():
        p.export_CIF(str(ROOT / f'heavy_combined_{p.name}.cif'))


if __name__ == '__main__':
    main()
