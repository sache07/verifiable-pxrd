from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent


def main():
    G2.SetPrintLevel('warn')
    g = G2.G2Project(gpxfile=str(ROOT / 'triclinic_heavy.gpx'))
    out = ROOT / 'bounded_oxygen.gpx'
    g.save(str(out))
    for p in g.phases():
        for a in p.atoms(): a.refinement_flags = ''
        p.clear_HAP_refinements({'Size': True, 'Mustrain': True})
    co = g.phase('CoWO4')
    # Independent-site optima from the physical heavy-atom checkpoint.
    co.atom('O1').coordinates = [0.22542216, 0.10554982, -0.07776474]
    co.atom('O2').coordinates = [0.25690079, 0.38570098, 0.41839331]
    g.set_Controls('cycles', 8)
    for i in range(3):
        g.refine()
        h = g.histograms()[0]
        print(json.dumps({'pass': i + 1, 'rwp': h.get_wR(),
                          'max_shift': g.data['Covariance']['data'].get('Rvals', {}).get('Max shft/sig')}), flush=True)
    g.save(str(out))
    for p in g.phases(): p.export_CIF(str(ROOT / f'bounded_oxygen_{p.name}.cif'))


if __name__ == '__main__':
    main()
