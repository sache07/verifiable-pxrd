from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent

def main():
    G2.SetPrintLevel('warn')
    for pname in ['CoWO4','WO3']:
        g=G2.G2Project(gpxfile=str(ROOT/'profile_combined.gpx'))
        out=ROOT/f'uiso_{pname}.gpx';g.save(str(out));h=g.histograms()[0]
        inst=h.data['Instrument Parameters'][0]
        for k in inst:
            if isinstance(inst[k],list)and len(inst[k])>2:inst[k][2]=False
        for p in g.phases():
            p.set_refinements({'Cell':False});p.clear_HAP_refinements({'Size':True,'Mustrain':True,'Pref.Ori.':True})
            for a in p.atoms():a.refinement_flags=''
        p=g.phase(pname);pid=p.data['pId'];vars=[]
        for i,a in enumerate(p.atoms()):
            a.uiso=0.01;a.refinement_flags='U';vars.append(f'{pid}::AUiso:{i}')
        g.add_EquivConstr(vars)
        g.set_Controls('cycles',8)
        for i in range(3):g.refine()
        print(json.dumps({'phase':pname,'rwp':h.get_wR(),
          'uiso':[a.uiso for a in p.atoms()],
          'max_shift':g.data['Covariance']['data'].get('Rvals',{}).get('Max shft/sig')}),flush=True)
        g.save(str(out))

if __name__=='__main__':main()
