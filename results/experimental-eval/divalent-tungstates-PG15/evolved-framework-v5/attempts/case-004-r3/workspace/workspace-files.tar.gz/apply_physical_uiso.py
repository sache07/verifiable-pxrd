from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent

def main():
    G2.SetPrintLevel('warn')
    g=G2.G2Project(gpxfile=str(ROOT/'profile_combined.gpx'))
    out=ROOT/'uiso_physical.gpx';g.save(str(out));h=g.histograms()[0]
    inst=h.data['Instrument Parameters'][0]
    for k in inst:
        if isinstance(inst[k],list)and len(inst[k])>2:inst[k][2]=False
    for p in g.phases():
        p.set_refinements({'Cell':False});p.clear_HAP_refinements({'Size':True,'Mustrain':True,'Pref.Ori.':True})
        for a in p.atoms():a.uiso=0.003;a.refinement_flags=''
    g.set_Controls('cycles',8)
    for i in range(3):
        g.refine();print(json.dumps({'pass':i+1,'rwp':h.get_wR(),
          'max_shift':g.data['Covariance']['data'].get('Rvals',{}).get('Max shft/sig')}),flush=True)
    g.save(str(out))

if __name__=='__main__':main()
