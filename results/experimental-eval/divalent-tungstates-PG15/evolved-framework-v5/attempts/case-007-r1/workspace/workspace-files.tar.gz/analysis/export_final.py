#!/usr/bin/env python3
"""Freeze the selected GSAS-II model and export submission CIFs/profile."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "closure" / "best.gpx"
PHASE_FILES = {
    "MgWO4": "phase_MgWO4.cif",
    "WO3": "phase_WO3.cif",
    "MgO": "phase_MgO.cif",
}


def serial(value):
    if isinstance(value, dict):
        return {str(k): serial(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serial(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.clear_refinements(
        {
            "Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
            "Instrument Parameters": ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"],
            "Background": True,
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True,
             "HStrain": True, "Extinction": True}
        )


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    hist = project.histograms()[0]
    mass_fracs = hist.ComputeMassFracs()
    residuals = dict(hist.data["data"][0])
    covariance = dict(project.data["Covariance"]["data"])
    arrays = [np.asarray(a, float).copy() for a in hist.data["data"][1]]

    clear_flags(project)
    # Export from saved full-precision phase records, without a stale covariance
    # dictionary supplying alternate serialized values.
    project.data["Covariance"]["data"] = {}
    project.save(str(ROOT / "final.gpx"))
    for phase in project.phases():
        phase.export_CIF(str(ROOT / PHASE_FILES[phase.name]))

    x, obs, weight, calc, background, difference = arrays
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, obs, calc, obs - calc]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
    )
    phases = []
    for phase in project.phases():
        fraction, esd = mass_fracs[phase.name]
        phases.append(
            {
                "name": phase.name,
                "cif_path": PHASE_FILES[phase.name],
                "weight_fraction": fraction,
                "weight_fraction_esd_statistical": esd,
                "cell": phase.get_cell(),
            }
        )
    summary = {
        "source_project": str(SOURCE.relative_to(ROOT)),
        "final_project": "final.gpx",
        "refinement_histogram": hist.name,
        "phases": phases,
        "residuals": residuals,
        "n_refined_parameters_last_cycle": len(covariance.get("varyList", [])),
    }
    (ROOT / "analysis" / "final_model_summary.json").write_text(
        json.dumps(serial(summary), indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
