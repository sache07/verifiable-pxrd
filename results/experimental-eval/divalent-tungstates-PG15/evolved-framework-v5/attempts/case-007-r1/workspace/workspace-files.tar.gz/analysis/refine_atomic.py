#!/usr/bin/env python3
"""Refine atomic parameters from the selected physical multiphase checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
START = ROOT / "analysis" / "candidates" / "2311041" / "11_cells_closed.gpx"
OUT = ROOT / "analysis" / "atomic_refinement"


def serial(value):
    if isinstance(value, dict):
        return {str(k): serial(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serial(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.clear_refinements(
        {
            "Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
            "Instrument Parameters": ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"],
        }
    )
    # Scale and the smooth background remain active in every coordinate step.
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})


def add_atomic_bounds(project: G2.G2Project) -> None:
    project.index_ids()
    controls = project.data["Controls"]["data"]
    mins = controls.setdefault("parmMinDict", {})
    maxs = controls.setdefault("parmMaxDict", {})
    for phase in project.phases():
        pid = phase.id
        for i, atom in enumerate(phase.atoms()):
            for axis, center in zip("xyz", atom.coordinates):
                var = project.make_var_obj(f"{pid}::dA{axis}:{i}", reloadIdx=False)
                # Despite the historical dA name, GSAS-II applies these limits
                # to the absolute fractional coordinate during phase update.
                mins[var], maxs[var] = float(center) - 0.03, float(center) + 0.03
            var = project.make_var_obj(f"{pid}::AUiso:{i}", reloadIdx=False)
            mins[var], maxs[var] = 0.001, 0.05


def phase_state(phase, hist_name: str) -> dict:
    hap = phase.data["Histograms"][hist_name]
    return {
        "name": phase.name,
        "cell": phase.get_cell(),
        "scale": float(hap["Scale"][0]),
        "mass_scale": float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]),
        "atoms": [
            {
                "label": a.label,
                "element": a.element,
                "coordinates": list(a.coordinates),
                "occupancy": float(a.occupancy),
                "uiso_A2": float(a.uiso),
                "refinement_flags": a.refinement_flags,
            }
            for a in phase.atoms()
        ],
    }


def snapshot(project: G2.G2Project, tag: str) -> dict:
    path = OUT / f"{tag}.gpx"
    project.save(str(path))
    hist = project.histograms()[0]
    phases = [phase_state(p, hist.name) for p in project.phases()]
    total = sum(max(0.0, p["mass_scale"]) for p in phases)
    for p in phases:
        p["weight_fraction"] = max(0.0, p["mass_scale"]) / total
    report = {
        "tag": tag,
        "rwp_percent": hist.get_wR(),
        "residuals": hist.data["data"][0],
        "phases": phases,
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
        "variables": project.data.get("Covariance", {}).get("data", {}).get("variables", []),
        "sig": project.data.get("Covariance", {}).get("data", {}).get("sig", []),
    }
    (OUT / f"{tag}.json").write_text(json.dumps(serial(report), indent=2) + "\n")
    export_dir = OUT / f"{tag}_cifs"
    export_dir.mkdir(exist_ok=True)
    for phase in project.phases():
        phase.export_CIF(str(export_dir / f"{phase.name}.cif"))
    print(f"{tag:24s} Rwp={hist.get_wR():.6f}")
    return report


def run_refinement(project: G2.G2Project, tag: str) -> dict:
    # GSAS-II's current scriptable refine() ignores its documented newfile
    # argument. Select the checkpoint explicitly before refinement so the
    # preceding physical checkpoint remains untouched.
    project.save(str(OUT / f"{tag}.gpx"))
    project.refine(makeBack=False)
    return snapshot(project, tag)


def set_atom_flags(phase, labels, flags="X") -> None:
    wanted = set(labels)
    for atom in phase.atoms():
        atom.refinement_flags = flags if atom.label in wanted else " "


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(START))
    project.set_Controls("cycles", 18)
    project.data["Controls"]["data"]["min dM/M"] = 1e-4
    clear_flags(project)
    add_atomic_bounds(project)
    snapshot(project, "00_selected_start")

    # Heavy scatterers first. MgWO4 W has one free symmetry coordinate;
    # monoclinic WO3 has two independent general W sites.
    set_atom_flags(project.phase("MgWO4"), ["W"])
    set_atom_flags(project.phase("WO3"), ["W1", "W2"])
    run_refinement(project, "01_heavy_w")

    clear_flags(project)
    set_atom_flags(project.phase("MgWO4"), ["Mg"])
    run_refinement(project, "02_mg_cation")

    clear_flags(project)
    set_atom_flags(project.phase("MgWO4"), ["O1", "O2"])
    run_refinement(project, "03_mgwo4_oxygen")

    clear_flags(project)
    set_atom_flags(project.phase("WO3"), ["O1", "O2", "O3", "O4", "O5", "O6"])
    run_refinement(project, "04_wo3_oxygen")

    # The specimen model applies one isotropic displacement parameter per
    # phase. Preserve that physical parameterization with equivalence
    # constraints instead of fitting an independent Uiso for every atom.
    clear_flags(project)
    initial_uiso = {"MgWO4": 0.007, "WO3": 0.008, "MgO": 0.0032}
    project.index_ids()
    for phase in project.phases():
        variables = []
        for i, atom in enumerate(phase.atoms()):
            atom.uiso = initial_uiso[phase.name]
            atom.refinement_flags = "U"
            variables.append(f"{phase.id}::AUiso:{i}")
        project.add_EquivConstr(variables, reloadIdx=False)
    run_refinement(project, "05_phase_uiso")


if __name__ == "__main__":
    main()
