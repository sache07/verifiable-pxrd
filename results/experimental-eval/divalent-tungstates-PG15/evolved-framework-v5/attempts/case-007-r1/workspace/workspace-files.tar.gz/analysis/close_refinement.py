#!/usr/bin/env python3
"""Close the accepted physical model with alternating, checkpointed refinements."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
START = ROOT / "analysis" / "anisotropy_round2" / "1_WO3_010.gpx"
OUT = ROOT / "analysis" / "closure"


def serial(value):
    if isinstance(value, dict):
        return {str(k): serial(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serial(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.clear_refinements(
        {
            "Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
            "Instrument Parameters": ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"],
        }
    )
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})


def state(project: G2.G2Project, tag: str, accepted: bool, before: float) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    phases, masses = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        masses.append(max(0.0, mass))
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass_scale": mass,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": a.label,
                        "element": a.element,
                        "coordinates": list(a.coordinates),
                        "uiso_A2": float(a.uiso),
                    }
                    for a in phase.atoms()
                ],
            }
        )
    total = sum(masses)
    for row, mass in zip(phases, masses):
        row["weight_fraction"] = mass / total
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "tag": tag,
        "accepted": accepted,
        "rwp_before_percent": before,
        "rwp_percent": float(hist.get_wR()),
        "instrument": {k: inst[k] for k in ["Zero", "Polariz.", "U", "V", "W", "X", "SH/L"]},
        "sample": hist.SampleParameters,
        "phases": phases,
        "varyList": cov.get("varyList", []),
        "variables": cov.get("variables", []),
        "sig": cov.get("sig", []),
        "Rvals": cov.get("Rvals", {}),
    }


def attempt(best_path: Path, tag: str, configure) -> Path:
    project = G2.G2Project(gpxfile=str(best_path))
    before = float(project.histograms()[0].get_wR())
    project.set_Controls("cycles", 18)
    project.data["Controls"]["data"]["min dM/M"] = 1e-4
    clear_flags(project)
    configure(project)
    trial = OUT / f"{tag}.gpx"
    project.save(str(trial))
    project.refine(makeBack=False)
    after = float(project.histograms()[0].get_wR())
    accepted = np.isfinite(after) and after <= before + 1e-7
    report = state(project, tag, accepted, before)
    (OUT / f"{tag}.json").write_text(json.dumps(serial(report), indent=2) + "\n")
    print(f"{tag:24s} {before:.6f} -> {after:.6f} {'ACCEPT' if accepted else 'REJECT'}", flush=True)
    return trial if accepted else best_path


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    best = START

    best = attempt(best, "01_cells", lambda p: [ph.set_refinements({"Cell": True}) for ph in p.phases()])
    best = attempt(best, "02_specimen_shift", lambda p: p.histograms()[0].set_refinements({"Sample Parameters": ["Shift"]}))
    best = attempt(best, "03_angular_zero", lambda p: p.histograms()[0].set_refinements({"Instrument Parameters": ["Zero"]}))
    best = attempt(best, "04_cells_closed", lambda p: [ph.set_refinements({"Cell": True}) for ph in p.phases()])

    def sizes(p):
        for ph in p.phases():
            ph.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})

    best = attempt(best, "05_sizes", sizes)

    def strains(p):
        hist = p.histograms()[0]
        for ph in p.phases():
            strain = ph.data["Histograms"][hist.name]["Mustrain"]
            if strain[0] == "uniaxial":
                strain[2][0] = strain[2][1] = True
            else:
                strain[2][0] = True

    best = attempt(best, "06_strains", strains)

    best = attempt(best, "07_texture", lambda p: p.phase("MgWO4").set_HAP_refinements({"Pref.Ori.": True}))
    best = attempt(best, "08_polarization", lambda p: p.histograms()[0].set_refinements({"Instrument Parameters": ["Polariz."]}))

    def uiso(p):
        for ph in p.phases():
            for atom in ph.atoms():
                atom.refinement_flags = "U"

    best = attempt(best, "09_phase_uiso", uiso)

    # Revisit bounded coordinates from the same published-reference limits.
    # Remove only coordinate entries from the automatically frozen list.
    def unfreeze_coordinates(p):
        frozen = p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])
        p.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = [
            v for v in frozen if "dA" not in str(v)
        ]

    def atom_flags(phase_name, labels):
        def configure(p):
            unfreeze_coordinates(p)
            wanted = set(labels)
            for atom in p.phase(phase_name).atoms():
                atom.refinement_flags = "X" if atom.label in wanted else " "
        return configure

    best = attempt(best, "10_heavy_w", lambda p: (
        unfreeze_coordinates(p),
        [setattr(a, "refinement_flags", "X" if a.element == "W" else " ") for ph in [p.phase("MgWO4"), p.phase("WO3")] for a in ph.atoms()],
    ))
    best = attempt(best, "11_mg_cation", atom_flags("MgWO4", ["Mg"]))
    best = attempt(best, "12_mgwo4_oxygen", atom_flags("MgWO4", ["O1", "O2"]))
    best = attempt(best, "13_wo3_oxygen", atom_flags("WO3", ["O1", "O2", "O3", "O4", "O5", "O6"]))

    # One final cell closure after all accepted intensity/profile changes.
    best = attempt(best, "14_final_cells", lambda p: [ph.set_refinements({"Cell": True}) for ph in p.phases()])
    (OUT / "best_path.txt").write_text(str(best.relative_to(ROOT)) + "\n")
    final = G2.G2Project(gpxfile=str(best))
    final.save(str(OUT / "best.gpx"))
    print(f"BEST {best} Rwp={final.histograms()[0].get_wR():.6f}")


if __name__ == "__main__":
    main()
