#!/usr/bin/env python3
"""Test bounded March-Dollase texture axes from one fixed checkpoint."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "profile_refinement" / "04_isotropic_strain_rejected.gpx"
OUT = ROOT / "analysis" / "texture_tests"
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.clear_refinements(
        {
            "Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
            "Instrument Parameters": ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"],
        }
    )
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})


def bound(project: G2.G2Project, name: str, lower: float, upper: float) -> None:
    project.index_ids()
    controls = project.data["Controls"]["data"]
    var = project.make_var_obj(name, reloadIdx=False)
    controls.setdefault("parmMinDict", {})[var] = lower
    controls.setdefault("parmMaxDict", {})[var] = upper


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, default=BASE)
    parser.add_argument("--out", type=Path, default=OUT)
    parser.add_argument("--phases", nargs="*")
    args = parser.parse_args()
    base_path = args.base if args.base.is_absolute() else ROOT / args.base
    out = args.out if args.out.is_absolute() else ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    base = G2.G2Project(gpxfile=str(base_path))
    base_rwp = float(base.histograms()[0].get_wR())
    rows = []
    for phase_index, phase_name in enumerate([p.name for p in base.phases()]):
        if args.phases and phase_name not in args.phases:
            continue
        for axis in AXES:
            axis_tag = "".join(str(v) for v in axis)
            tag = f"{phase_index}_{phase_name}_{axis_tag}"
            path = out / f"{tag}.gpx"
            shutil.copy2(base_path, path)
            project = G2.G2Project(gpxfile=str(path))
            project.set_Controls("cycles", 15)
            project.data["Controls"]["data"]["min dM/M"] = 1e-4
            clear_flags(project)
            phase = project.phase(phase_name)
            hap = phase.data["Histograms"][project.histograms()[0].name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
            bound(project, f"{phase.id}:0:MD", 0.7, 1.4)
            project.refine(makeBack=False)
            hist = project.histograms()[0]
            ratio = float(phase.data["Histograms"][hist.name]["Pref.Ori."][1])
            row = {
                "tag": tag,
                "phase": phase_name,
                "axis": list(axis),
                "md_ratio": ratio,
                "rwp_percent": float(hist.get_wR()),
                "delta_rwp": float(hist.get_wR()) - base_rwp,
                "project": str(path.relative_to(ROOT)),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
    rows.sort(key=lambda r: r["rwp_percent"])
    (out / "summary.json").write_text(
        json.dumps({"base_rwp_percent": base_rwp, "tests": rows}, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
