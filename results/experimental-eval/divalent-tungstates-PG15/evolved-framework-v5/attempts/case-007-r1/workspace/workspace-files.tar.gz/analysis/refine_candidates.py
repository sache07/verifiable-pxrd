#!/usr/bin/env python3
"""Build and refine three-phase GSAS-II candidate projects.

This is intentionally conservative: candidate comparison is done before any
atomic-coordinate refinement, so a poorer WO3 topology cannot win by moving
atoms into an unphysical arrangement.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, minimum_filter1d
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def set_value(entry: dict, key: str, value: float) -> None:
    """Set both current and original instrument values where present."""
    row = entry[key]
    row[0] = float(value)
    if len(row) > 1 and isinstance(row[1], (int, float)):
        row[1] = float(value)


def snapshot(project: G2.G2Project, outdir: Path, tag: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.SampleParameters
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        masses.append(max(0.0, mass_scale))
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "mass_scale": mass_scale,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for row, mass in zip(phases, masses):
        row["weight_fraction"] = mass / total if total > 0 else None
    result = {
        "tag": tag,
        "rwp_percent": hist.get_wR(),
        "residuals": hist.data["data"][0],
        "instrument": {k: inst[k] for k in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"] if k in inst},
        "sample": {k: sample[k] for k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"] if k in sample},
        "phases": phases,
        "covariance": {
            k: project.data.get("Covariance", {}).get("data", {}).get(k)
            for k in ["Rvals", "varyList", "variables", "sig", "Lastshft"]
        },
    }
    project.save(str(outdir / f"{tag}.gpx"))
    (outdir / f"{tag}.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(f"{tag:24s} Rwp={hist.get_wR()!s}")
    return result


def refine(project: G2.G2Project, outdir: Path, tag: str) -> dict:
    project.refine(newfile=str(outdir / f"{tag}.gpx"), makeBack=False)
    return snapshot(project, outdir, tag)


def build(wo3_id: str, outdir: Path) -> dict:
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(outdir / "initial.gpx"))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "analysis" / "instrument.instprm"),
        fmthint="comma",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-550.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({"Limits": [float(hist.getdata("X")[0]), float(hist.getdata("X")[-1])]})

    # Initialize the slowly varying background from a robust rolling-minimum
    # baseline, then represent it with the same analytic polynomial saved in
    # the GPX. (The lean GSAS-II environment does not include pybaselines.)
    x = np.asarray(hist.getdata("X"), float)
    y = np.asarray(hist.getdata("Yobs"), float)
    baseline = gaussian_filter1d(minimum_filter1d(y, size=301, mode="nearest"), 80)
    stride = max(1, len(x) // 100)
    hist.data["Background"][1]["FixedPoints"] = [
        (float(a), float(b)) for a, b in zip(x[::stride], baseline[::stride])
    ]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "refine": True,
                "fit fixed points": True,
            }
        }
    )

    phase_specs = [
        ("MgWO4", "9013902"),
        ("WO3", wo3_id),
        ("MgO", "9000499"),
    ]
    for name, cod_id in phase_specs:
        phase = project.add_phase(
            str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2][0] = False
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    project.update_ids()
    # Physical bounds follow the broad laboratory envelope. They prevent
    # profile/cell correlations from producing a mathematically small but
    # nonphysical width, displacement or crystallite size.
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Shift": (-800.0, 800.0),
    }
    for phase in project.phases():
        pid = phase.id
        bounds[f"{pid}:0:Scale"] = (0.0, 1.0e6)
        bounds[f"{pid}:0:Size;i"] = (0.04, 1.5)
        bounds[f"{pid}:0:Mustrain;i"] = (0.0, 8000.0)
    for variable, (lower, upper) in bounds.items():
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    project.set_Controls("cycles", 12)
    snapshot(project, outdir, "00_initial")

    # First establish positive scales/background with a physically plausible
    # specimen displacement close to that indicated by all three peak families.
    refine(project, outdir, "01_scale_background")

    # Establish the specimen shift alone. Zero and shift are nearly collinear
    # over this angular range, so they are never varied in the same cycle.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, outdir, "02_shift_zero")
    hist.clear_refinements({"Sample Parameters": ["Shift"]})

    # Phase cells absorb only phase-specific peak displacement/splitting.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, outdir, "03_cells")
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})

    # Common angular zero/profile before phase-dependent broadening.
    common_profile = ["Zero", "U", "W", "X", "SH/L"]
    hist.set_refinements({"Instrument Parameters": common_profile})
    refine(project, outdir, "04_instrument")
    hist.clear_refinements({"Instrument Parameters": common_profile})

    # Revisit cells once with the common profile fixed.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, outdir, "05_cells_profile")
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})

    # One supported complexity at a time: isotropic size, then isotropic strain.
    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine(project, outdir, "06_size")
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True})

    for phase in project.phases():
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, outdir, "07_mustrain")
    for phase in project.phases():
        phase.clear_HAP_refinements({"Mustrain": True})

    # Width changes alter peak-centroid leverage. Close the alternating loop
    # with cells, specimen shift and zero varied separately, then cells once
    # more. This avoids the near-singular simultaneous calibration fit.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, outdir, "08_cells_final")
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, outdir, "09_shift_final")
    hist.clear_refinements({"Sample Parameters": ["Shift"]})

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, outdir, "10_zero_final")
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    final = refine(project, outdir, "11_cells_closed")
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    return final


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    out = args.out or ROOT / "analysis" / "candidates" / args.wo3_id
    result = build(args.wo3_id, out)
    print(json.dumps({"wo3_id": args.wo3_id, "rwp_percent": result["rwp_percent"]}, indent=2))


if __name__ == "__main__":
    main()
