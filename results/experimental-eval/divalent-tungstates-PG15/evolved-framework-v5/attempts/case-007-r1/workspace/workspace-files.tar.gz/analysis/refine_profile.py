#!/usr/bin/env python3
"""Refine supported instrument/specimen/profile terms after atomic parameters."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
START = ROOT / "analysis" / "atomic_refinement" / "05_phase_uiso.gpx"
OUT = ROOT / "analysis" / "profile_refinement"


def serial(value):
    if isinstance(value, dict):
        return {str(k): serial(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serial(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.clear_refinements(
        {
            "Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
            "Instrument Parameters": ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"],
        }
    )
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})


def set_bound(project: G2.G2Project, name: str, lower: float, upper: float) -> None:
    project.index_ids()
    controls = project.data["Controls"]["data"]
    var = project.make_var_obj(name, reloadIdx=False)
    controls.setdefault("parmMinDict", {})[var] = float(lower)
    controls.setdefault("parmMaxDict", {})[var] = float(upper)


def state(project: G2.G2Project, tag: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        masses.append(max(0.0, mass))
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass_scale": mass,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "uiso_A2": [float(a.uiso) for a in phase.atoms()],
            }
        )
    total = sum(masses)
    for row, mass in zip(phases, masses):
        row["weight_fraction"] = mass / total
    return {
        "tag": tag,
        "rwp_percent": hist.get_wR(),
        "residuals": hist.data["data"][0],
        "instrument": {k: inst[k] for k in ["Zero", "Polariz.", "U", "V", "W", "X", "SH/L"]},
        "sample": hist.SampleParameters,
        "phases": phases,
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
        "variables": project.data.get("Covariance", {}).get("data", {}).get("variables", []),
        "sig": project.data.get("Covariance", {}).get("data", {}).get("sig", []),
    }


def snapshot(project: G2.G2Project, tag: str) -> dict:
    project.save(str(OUT / f"{tag}.gpx"))
    report = state(project, tag)
    (OUT / f"{tag}.json").write_text(json.dumps(serial(report), indent=2) + "\n")
    print(f"{tag:24s} Rwp={report['rwp_percent']:.6f}")
    return report


def refine(project: G2.G2Project, tag: str) -> dict:
    project.save(str(OUT / f"{tag}.gpx"))
    project.refine(makeBack=False)
    return snapshot(project, tag)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(START))
    project.set_Controls("cycles", 18)
    project.data["Controls"]["data"]["min dM/M"] = 1e-4
    clear_flags(project)
    snapshot(project, "00_atomic_start")

    # Polarization is common to the instrument and affects relative intensity
    # smoothly across the full angular range.
    set_bound(project, ":0:Polariz.", 0.5, 1.0)
    project.histograms()[0].set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "01_polarization")
    clear_flags(project)

    # Test a physical Suortti low-angle deficit. Keep this branch only if the
    # full-pattern objective improves and both values remain in range.
    rough_start = OUT / "01_polarization.gpx"
    rough_seed = OUT / "02_surface_roughness_seed.gpx"
    shutil.copy2(rough_start, rough_seed)
    rough = G2.G2Project(gpxfile=str(rough_seed))
    clear_flags(rough)
    rough.histograms()[0].SampleParameters["SurfRoughA"] = [0.30, True]
    rough.histograms()[0].SampleParameters["SurfRoughB"] = [0.10, True]
    set_bound(rough, ":0:SurfRoughA", 0.05, 0.6)
    set_bound(rough, ":0:SurfRoughB", 0.02, 0.5)
    rough_report = refine(rough, "02_surface_roughness_test")
    pol_report = json.loads((OUT / "01_polarization.json").read_text())
    A = float(rough.histograms()[0].SampleParameters["SurfRoughA"][0])
    B = float(rough.histograms()[0].SampleParameters["SurfRoughB"][0])
    # A boundary-seeking, almost perfectly correlated pair is not evidence for
    # roughness. Require an interior physical solution as well as improvement.
    if (
        rough_report["rwp_percent"] < pol_report["rwp_percent"]
        and 0.0501 < A < 0.5999
        and 0.0201 < B < 0.4999
    ):
        project = rough
        snapshot(project, "02_surface_roughness_accepted")
    else:
        project = G2.G2Project(gpxfile=str(rough_start))
        clear_flags(project)
        snapshot(project, "02_surface_roughness_rejected")

    clear_flags(project)

    # Re-optimize isotropic phase broadening one supported family at a time.
    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine(project, "03_isotropic_size")
    clear_flags(project)

    for phase in project.phases():
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    strain_report = refine(project, "04_isotropic_strain_test")
    size_report = json.loads((OUT / "03_isotropic_size.json").read_text())
    if strain_report["rwp_percent"] < size_report["rwp_percent"]:
        snapshot(project, "04_isotropic_strain_accepted")
    else:
        project = G2.G2Project(gpxfile=str(OUT / "03_isotropic_size.gpx"))
        clear_flags(project)
        snapshot(project, "04_isotropic_strain_rejected")


if __name__ == "__main__":
    main()
