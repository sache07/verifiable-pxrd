#!/usr/bin/env python3
"""Write fit.csv from the independently regenerated GSAS-II profile."""

from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    replay = np.load(ROOT / "analysis" / "replay_check" / "prediction.npz")
    x = replay["x"]
    observed = replay["observed"]
    calculated = replay["predicted"]
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, observed - calculated]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        # Preserve the input grid exactly on a binary round trip and retain
        # enough profile precision to recompute the reported fit statistics.
        fmt=["%.17g", "%.17g", "%.17g", "%.17g"],
    )


if __name__ == "__main__":
    main()
