#!/usr/bin/env python3
"""Test bounded uniaxial microstrain after the accepted texture checkpoint."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "texture_tests" / "0_MgWO4_110.gpx"
OUT = ROOT / "analysis" / "anisotropy_tests"
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0)]


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.clear_refinements(
        {
            "Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
            "Instrument Parameters": ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"],
        }
    )
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})


def bound(project: G2.G2Project, name: str, lower: float, upper: float) -> None:
    project.index_ids()
    controls = project.data["Controls"]["data"]
    var = project.make_var_obj(name, reloadIdx=False)
    controls.setdefault("parmMinDict", {})[var] = lower
    controls.setdefault("parmMaxDict", {})[var] = upper


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, default=BASE)
    parser.add_argument("--out", type=Path, default=OUT)
    parser.add_argument("--phases", nargs="*")
    args = parser.parse_args()
    base_path = args.base if args.base.is_absolute() else ROOT / args.base
    out = args.out if args.out.is_absolute() else ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    base = G2.G2Project(gpxfile=str(base_path))
    base_rwp = float(base.histograms()[0].get_wR())
    rows = []
    for phase_index, phase_name in enumerate([p.name for p in base.phases()]):
        if args.phases and phase_name not in args.phases:
            continue
        axes = AXES if phase_name != "MgO" else [(0, 0, 1)]
        for axis in axes:
            axis_tag = "".join(str(v) for v in axis)
            tag = f"{phase_index}_{phase_name}_{axis_tag}"
            path = out / f"{tag}.gpx"
            shutil.copy2(base_path, path)
            project = G2.G2Project(gpxfile=str(path))
            project.set_Controls("cycles", 18)
            project.data["Controls"]["data"]["min dM/M"] = 1e-4
            clear_flags(project)
            phase = project.phase(phase_name)
            hap = phase.data["Histograms"][project.histograms()[0].name]
            strain = hap["Mustrain"]
            strain[0] = "uniaxial"
            strain[1][1] = strain[1][0]
            strain[2][0] = True
            strain[2][1] = True
            strain[3] = list(axis)
            bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
            bound(project, f"{phase.id}:0:Mustrain;a", 0.0, 8000.0)
            project.refine(makeBack=False)
            hist = project.histograms()[0]
            strain = phase.data["Histograms"][hist.name]["Mustrain"]
            equatorial, axial = map(float, strain[1][:2])
            row = {
                "tag": tag,
                "phase": phase_name,
                "axis": list(axis),
                "equatorial_ppm": equatorial,
                "axial_ppm": axial,
                "axial_ratio": axial / equatorial if equatorial else None,
                "rwp_percent": float(hist.get_wR()),
                "delta_rwp": float(hist.get_wR()) - base_rwp,
                "project": str(path.relative_to(ROOT)),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
    rows.sort(key=lambda r: r["rwp_percent"])
    (out / "summary.json").write_text(
        json.dumps({"base_rwp_percent": base_rwp, "tests": rows}, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
