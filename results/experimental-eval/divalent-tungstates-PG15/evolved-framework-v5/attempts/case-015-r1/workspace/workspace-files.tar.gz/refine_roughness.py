#!/usr/bin/env python3
"""Refine Suortti surface roughness from several starts, then replay fixed values."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def prepare(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("outdir")
    parser.add_argument("starts", nargs="+", type=float)
    args = parser.parse_args()
    if len(args.starts) % 2:
        raise ValueError("starts must be A,B pairs")
    source = Path(args.source).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    records = []
    for index, (a0, b0) in enumerate(zip(args.starts[0::2], args.starts[1::2])):
        output = outdir / f"start_{index}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
        prepare(project)
        hist = project.histogram(0)
        controls = project.data["Controls"]["data"]
        controls["max cyc"] = 30
        controls["min dM/M"] = 1e-8
        controls["shift factor"] = 0.2
        controls["parmFrozen"] = {"FrozenList": []}
        hist.SampleParameters["SurfRoughA"] = [a0, True]
        hist.SampleParameters["SurfRoughB"] = [b0, True]
        status = "ok"
        try:
            project.refine(makeBack=False)
            a = float(hist.SampleParameters["SurfRoughA"][0])
            b = float(hist.SampleParameters["SurfRoughB"][0])
            if not math.isfinite(a + b):
                raise ValueError("non-finite roughness")
            hist.SampleParameters["SurfRoughA"][1] = False
            hist.SampleParameters["SurfRoughB"][1] = False
            controls["parmFrozen"] = {"FrozenList": []}
            project.refine(makeBack=False)
            project.save()
            rec = {
                "start": [a0, b0],
                "refined": [a, b],
                "physical": 0.05 <= a <= 0.6 and 0.02 <= b <= 0.5,
                "Rwp": float(hist.residuals["wR"]),
                "Rp": float(hist.residuals["R"]),
                "gpx": str(output),
                "status": status,
            }
        except Exception as exc:
            status = "failed"
            rec = {"start": [a0, b0], "status": status, "error": repr(exc)}
        records.append(rec)
        print(json.dumps(rec), flush=True)
    valid = [r for r in records if r["status"] == "ok" and r["physical"]]
    if valid:
        print("BEST_PHYSICAL", json.dumps(min(valid, key=lambda r: r["Rwp"])), flush=True)


if __name__ == "__main__":
    main()
