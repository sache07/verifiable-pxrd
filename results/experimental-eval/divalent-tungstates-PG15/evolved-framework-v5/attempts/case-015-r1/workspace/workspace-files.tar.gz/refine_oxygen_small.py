#!/usr/bin/env python3
"""Test very small oxygen-coordinate moves after accepted heavy-site steps."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_atoms(project: G2.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def report(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    vals = [p.getHAPvalues(hist)["Scale"][0] * p.data["General"]["Mass"] for p in project.phases()]
    total = sum(vals)
    print(json.dumps({
        "label": label,
        "Rwp": hist.residuals.get("wR"),
        "weight_fractions": {p.name: v / total for p, v in zip(project.phases(), vals)},
        "coordinates": {p.name: {a.label: list(a.coordinates) for a in p.atoms()} for p in project.phases()},
    }, indent=2), flush=True)


def step(project: G2.G2Project, output: Path, phase_index: int, label: str) -> None:
    controls = project.data["Controls"]["data"]
    clear_atoms(project)
    for atom in project.phase(phase_index).atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    controls["max cyc"] = 1
    controls["shift factor"] = 0.005
    controls["parmFrozen"] = {"FrozenList": []}
    project.refine(makeBack=False)
    clear_atoms(project)
    controls["max cyc"] = 8
    controls["shift factor"] = 0.25
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(project.filename, output.with_name(f"{output.stem}_{label}.gpx"))
    report(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.source).resolve()), newgpx=str(output))
    hist = project.histogram(0)
    for key, val in hist.InstrumentParameters.items():
        if isinstance(val, list) and len(val) > 2: val[2] = False
    for val in hist.SampleParameters.values():
        if isinstance(val, list) and len(val) > 1 and isinstance(val[1], bool): val[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True})
    clear_atoms(project)
    step(project, output, 0, "znwo4_oxygen")
    step(project, output, 1, "wo3_oxygen")
    clear_atoms(project)
    project.save()


if __name__ == "__main__":
    main()
