#!/usr/bin/env python3
"""Take small symmetry-allowed coordinate steps, with settled checkpoints."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_atoms(project: G2.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def summarize(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    amount = [
        max(0.0, p.getHAPvalues(hist)["Scale"][0] * p.data["General"]["Mass"])
        for p in project.phases()
    ]
    total = sum(amount)
    print(
        json.dumps(
            {
                "label": label,
                "Rwp": hist.residuals.get("wR"),
                "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
                "phases": [
                    {
                        "name": p.name,
                        "weight_fraction": a / total,
                        "atoms": [
                            {
                                "label": at.label,
                                "element": at.element,
                                "xyz": list(at.coordinates),
                            }
                            for at in p.atoms()
                        ],
                    }
                    for p, a in zip(project.phases(), amount)
                ],
            },
            indent=2,
        ),
        flush=True,
    )


def small_step(
    project: G2.G2Project,
    output: Path,
    label: str,
    phase_index: int,
    elements: set[str],
) -> None:
    controls = project.data["Controls"]["data"]
    clear_atoms(project)
    for atom in project.phase(phase_index).atoms():
        if atom.element in elements:
            atom.refinement_flags = "X"
    controls["max cyc"] = 1
    controls["shift factor"] = 0.05
    controls["parmFrozen"] = {"FrozenList": []}
    project.refine(makeBack=False)

    # Settle the linear scale/background parameters after the deliberately
    # small coordinate move, without allowing coordinates to walk farther.
    clear_atoms(project)
    controls["max cyc"] = 8
    controls["shift factor"] = 0.25
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(project.filename, output.with_name(f"{output.stem}_{label}.gpx"))
    summarize(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.source).resolve()), newgpx=str(output))
    hist = project.histogram(0)
    controls = project.data["Controls"]["data"]
    controls["min dM/M"] = 1e-6
    controls["parmFrozen"] = {"FrozenList": []}

    for key, value in hist.InstrumentParameters.items():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
    clear_atoms(project)

    small_step(project, output, "znwo4_heavy", 0, {"W", "Zn"})
    small_step(project, output, "wo3_heavy", 1, {"W"})
    small_step(project, output, "znwo4_oxygen", 0, {"O"})
    small_step(project, output, "wo3_oxygen", 1, {"O"})
    clear_atoms(project)
    project.save()


if __name__ == "__main__":
    main()
