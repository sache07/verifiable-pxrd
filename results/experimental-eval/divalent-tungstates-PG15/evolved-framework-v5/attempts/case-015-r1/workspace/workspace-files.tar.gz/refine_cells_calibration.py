#!/usr/bin/env python3
"""Alternate phase-cell and bounded calibration refinements."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def summary(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    amounts = [
        max(0.0, p.getHAPvalues(hist)["Scale"][0] * p.data["General"]["Mass"])
        for p in project.phases()
    ]
    total = sum(amounts)
    print(
        json.dumps(
            {
                "label": label,
                "residuals": hist.residuals,
                "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
                "zero": hist.InstrumentParameters["Zero"],
                "shift": hist.SampleParameters["Shift"],
                "phases": [
                    {
                        "name": p.name,
                        "cell": p.get_cell(),
                        "weight_fraction": a / total,
                    }
                    for p, a in zip(project.phases(), amounts)
                ],
            },
            indent=2,
            default=str,
        ),
        flush=True,
    )


def save_checkpoint(project: G2.G2Project, output: Path, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, output.with_name(f"{output.stem}_{label}.gpx"))
    summary(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.source).resolve()), newgpx=str(output))
    hist = project.histogram(0)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1e-6
    controls["shift factor"] = 0.25
    controls["parmFrozen"] = {"FrozenList": []}

    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        hist.InstrumentParameters[key][2] = False
    hist.SampleParameters["Shift"][1] = False
    hist.InstrumentParameters["Zero"][2] = False
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_refinements({"Cell": True})

    project.refine(makeBack=False)
    save_checkpoint(project, output, "cells_1")

    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    hist.SampleParameters["Shift"][1] = True
    project.refine(makeBack=False)
    save_checkpoint(project, output, "shift")

    hist.SampleParameters["Shift"][1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine(makeBack=False)
    save_checkpoint(project, output, "cells_2")

    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    hist.InstrumentParameters["Zero"][2] = True
    project.refine(makeBack=False)
    save_checkpoint(project, output, "zero")

    hist.InstrumentParameters["Zero"][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine(makeBack=False)
    save_checkpoint(project, output, "cells_3")

    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    project.save()


if __name__ == "__main__":
    main()
