#!/usr/bin/env python3
"""Screen bounded March-Dollase preferred-orientation models.

Each branch starts from the same replay-consistent project. The MD coefficient
is first estimated as a single free parameter, then clipped to the stated
physical interval and frozen. Background and phase scales are subsequently
settled so the reported Rwp is evaluated at the parameters actually saved.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def prepare(project: G2.G2Project) -> None:
    """Leave only background and positive phase scales active."""
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histogram(0)
    values = [
        max(0.0, float(p.getHAPvalues(hist)["Scale"][0]))
        * float(p.data["General"]["Mass"])
        for p in project.phases()
    ]
    total = sum(values)
    return [v / total for v in values]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("outdir")
    parser.add_argument("--phase", type=int, action="append", dest="phases")
    parser.add_argument("--lower", type=float, default=0.7)
    parser.add_argument("--upper", type=float, default=1.4)
    args = parser.parse_args()

    source = Path(args.source).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    probe = G2.G2Project(str(source))
    phase_ids = args.phases if args.phases is not None else list(range(len(probe.phases())))
    records: list[dict] = []

    for phase_id in phase_ids:
        phase_name = probe.phase(phase_id).name
        for axis in AXES:
            axis_tag = "".join(str(i) for i in axis)
            tag = f"p{phase_id}_{axis_tag}"
            output = outdir / f"{tag}.gpx"
            project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
            prepare(project)
            hist = project.histogram(0)
            controls = project.data["Controls"]["data"]
            controls["max cyc"] = 10
            controls["min dM/M"] = 1e-7
            controls["shift factor"] = 0.25
            controls["parmFrozen"] = {"FrozenList": []}

            hap = project.phase(phase_id).getHAPvalues(hist)
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)

            status = "ok"
            try:
                project.refine(makeBack=False)
                raw_ratio = float(hap["Pref.Ori."][1])
                if not math.isfinite(raw_ratio):
                    raise ValueError("non-finite MD coefficient")
                bounded_ratio = min(args.upper, max(args.lower, raw_ratio))
                hap["Pref.Ori."][1] = bounded_ratio
                hap["Pref.Ori."][2] = False
                controls["parmFrozen"] = {"FrozenList": []}
                project.refine(makeBack=False)
                project.save()
                rec = {
                    "tag": tag,
                    "phase_id": phase_id,
                    "phase": phase_name,
                    "axis": axis,
                    "raw_ratio": raw_ratio,
                    "bounded_ratio": bounded_ratio,
                    "at_bound": bounded_ratio != raw_ratio,
                    "Rwp": float(hist.residuals["wR"]),
                    "Rp": float(hist.residuals["R"]),
                    "weight_fractions": fractions(project),
                    "gpx": str(output),
                    "status": status,
                }
            except Exception as exc:
                status = "failed"
                rec = {
                    "tag": tag,
                    "phase_id": phase_id,
                    "phase": phase_name,
                    "axis": axis,
                    "status": status,
                    "error": repr(exc),
                }
            records.append(rec)
            print(json.dumps(rec), flush=True)

    valid = [r for r in records if r["status"] == "ok"]
    if valid:
        print("BEST", json.dumps(min(valid, key=lambda r: r["Rwp"])), flush=True)


if __name__ == "__main__":
    main()
