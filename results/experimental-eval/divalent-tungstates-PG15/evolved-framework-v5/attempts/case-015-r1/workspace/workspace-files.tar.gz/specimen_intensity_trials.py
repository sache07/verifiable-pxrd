#!/usr/bin/env python3
"""Evaluate bounded polarization and surface-roughness intensity corrections."""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def prepare(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "


def evaluate(source: Path, output: Path, mode: str, values: tuple[float, ...]) -> dict:
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    prepare(project)
    hist = project.histogram(0)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 10
    controls["min dM/M"] = 1e-7
    controls["shift factor"] = 0.25
    controls["parmFrozen"] = {"FrozenList": []}
    if mode == "polarization":
        hist.InstrumentParameters["Polariz."][1] = values[0]
    elif mode == "roughness":
        hist.SampleParameters["SurfRoughA"][0] = values[0]
        hist.SampleParameters["SurfRoughB"][0] = values[1]
    else:
        raise ValueError(mode)
    project.refine(makeBack=False)
    project.save()
    amounts = [
        p.getHAPvalues(hist)["Scale"][0] * p.data["General"]["Mass"]
        for p in project.phases()
    ]
    total = sum(amounts)
    return {
        "mode": mode,
        "values": values,
        "Rwp": float(hist.residuals["wR"]),
        "Rp": float(hist.residuals["R"]),
        "weight_fractions": [v / total for v in amounts],
        "gpx": str(output),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("outdir")
    parser.add_argument("mode", choices=("polarization", "roughness"))
    parser.add_argument("values", nargs="+", type=float)
    args = parser.parse_args()
    source = Path(args.source).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    if args.mode == "polarization":
        points = [(v,) for v in args.values]
    else:
        if len(args.values) % 2:
            raise ValueError("roughness values must be A,B pairs")
        points = list(zip(args.values[0::2], args.values[1::2]))
    records = []
    for values in points:
        suffix = "_".join(f"{v:.4f}".replace(".", "p") for v in values)
        output = outdir / f"{args.mode}_{suffix}.gpx"
        rec = evaluate(source, output, args.mode, values)
        records.append(rec)
        print(json.dumps(rec), flush=True)
    print("BEST", json.dumps(min(records, key=lambda r: r["Rwp"])), flush=True)


if __name__ == "__main__":
    main()
