#!/usr/bin/env python3
"""Refine one isotropic crystallite size at a time with physical rollback."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def prepare(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("outdir")
    parser.add_argument("--phase", type=int, action="append", dest="phases")
    parser.add_argument("starts", nargs="+", type=float, default=[0.04])
    args = parser.parse_args()
    source = Path(args.source).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    probe = G2.G2Project(str(source))
    records = []
    phase_ids = args.phases if args.phases is not None else list(range(len(probe.phases())))
    for phase_id in phase_ids:
        probe_phase = probe.phase(phase_id)
        for start in args.starts:
            tag = f"p{phase_id}_s{start:.3f}".replace(".", "p")
            output = outdir / f"{tag}.gpx"
            project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
            prepare(project)
            hist = project.histogram(0)
            controls = project.data["Controls"]["data"]
            controls["max cyc"] = 25
            controls["min dM/M"] = 1e-8
            controls["shift factor"] = 0.2
            controls["parmFrozen"] = {"FrozenList": []}
            size = project.phase(phase_id).getHAPvalues(hist)["Size"]
            size[0] = "isotropic"
            size[1][0] = start
            size[2] = [True, False, False]
            status = "ok"
            try:
                project.refine(makeBack=False)
                raw = float(size[1][0])
                if not math.isfinite(raw):
                    raise ValueError("non-finite size")
                bounded = min(1.5, max(0.04, raw))
                size[1][0] = bounded
                size[2] = [False, False, False]
                controls["parmFrozen"] = {"FrozenList": []}
                project.refine(makeBack=False)
                project.save()
                rec = {
                    "phase_id": phase_id,
                    "phase": probe_phase.name,
                    "start_um": start,
                    "raw_um": raw,
                    "bounded_um": bounded,
                    "at_bound": bounded != raw,
                    "Rwp": float(hist.residuals["wR"]),
                    "Rp": float(hist.residuals["R"]),
                    "gpx": str(output),
                    "status": status,
                }
            except Exception as exc:
                status = "failed"
                rec = {
                    "phase_id": phase_id,
                    "phase": probe_phase.name,
                    "start_um": start,
                    "status": status,
                    "error": repr(exc),
                }
            records.append(rec)
            print(json.dumps(rec), flush=True)
    valid = [r for r in records if r["status"] == "ok"]
    if valid:
        print("BEST", json.dumps(min(valid, key=lambda r: r["Rwp"])), flush=True)


if __name__ == "__main__":
    main()
