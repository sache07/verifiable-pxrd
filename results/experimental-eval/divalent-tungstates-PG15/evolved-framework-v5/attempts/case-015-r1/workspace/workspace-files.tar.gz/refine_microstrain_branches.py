#!/usr/bin/env python3
"""Screen bounded uniaxial microstrain models along the supported axes."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def prepare(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("outdir")
    parser.add_argument("--phase", type=int, action="append", dest="phases")
    parser.add_argument("--equatorial", type=float, default=300.0)
    parser.add_argument("--axial", type=float, default=600.0)
    args = parser.parse_args()
    source = Path(args.source).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    probe = G2.G2Project(str(source))
    phase_ids = args.phases if args.phases is not None else list(range(len(probe.phases())))
    records = []
    for phase_id in phase_ids:
        for axis in AXES:
            axis_tag = "".join(str(v) for v in axis)
            output = outdir / f"p{phase_id}_{axis_tag}.gpx"
            project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
            prepare(project)
            hist = project.histogram(0)
            controls = project.data["Controls"]["data"]
            controls["max cyc"] = 30
            controls["min dM/M"] = 1e-8
            controls["shift factor"] = 0.2
            controls["parmFrozen"] = {"FrozenList": []}
            strain = project.phase(phase_id).getHAPvalues(hist)["Mustrain"]
            strain[0] = "uniaxial"
            strain[1][0] = args.equatorial
            strain[1][1] = args.axial
            strain[2] = [True, True, False]
            strain[3] = list(axis)
            status = "ok"
            try:
                project.refine(makeBack=False)
                raw = [float(strain[1][0]), float(strain[1][1])]
                if not all(math.isfinite(v) for v in raw):
                    raise ValueError("non-finite microstrain")
                bounded = [min(8000.0, max(0.0, v)) for v in raw]
                strain[1][0], strain[1][1] = bounded
                strain[2] = [False, False, False]
                controls["parmFrozen"] = {"FrozenList": []}
                project.refine(makeBack=False)
                project.save()
                rec = {
                    "phase_id": phase_id,
                    "phase": probe.phase(phase_id).name,
                    "axis": axis,
                    "raw_ppm": raw,
                    "bounded_ppm": bounded,
                    "at_bound": raw != bounded,
                    "Rwp": float(hist.residuals["wR"]),
                    "Rp": float(hist.residuals["R"]),
                    "gpx": str(output),
                    "status": status,
                }
            except Exception as exc:
                status = "failed"
                rec = {
                    "phase_id": phase_id,
                    "phase": probe.phase(phase_id).name,
                    "axis": axis,
                    "status": status,
                    "error": repr(exc),
                }
            records.append(rec)
            print(json.dumps(rec), flush=True)
    valid = [r for r in records if r["status"] == "ok"]
    if valid:
        print("BEST", json.dumps(min(valid, key=lambda r: r["Rwp"])), flush=True)


if __name__ == "__main__":
    main()
