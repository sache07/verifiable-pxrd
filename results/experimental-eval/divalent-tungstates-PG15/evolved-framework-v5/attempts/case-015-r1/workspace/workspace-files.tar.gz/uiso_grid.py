#!/usr/bin/env python3
"""Screen a common isotropic displacement parameter for one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def prepare(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("outdir")
    parser.add_argument("phase", type=int)
    parser.add_argument("values", nargs="+", type=float)
    args = parser.parse_args()
    source = Path(args.source).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    records = []
    for uiso in args.values:
        tag = f"p{args.phase}_u{uiso:.5f}".replace(".", "p")
        output = outdir / f"{tag}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
        prepare(project)
        hist = project.histogram(0)
        controls = project.data["Controls"]["data"]
        controls["max cyc"] = 15
        controls["min dM/M"] = 1e-8
        controls["shift factor"] = 0.5
        controls["parmFrozen"] = {"FrozenList": []}
        phase = project.phase(args.phase)
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = uiso
            atom.refinement_flags = " "
        project.refine(makeBack=False)
        project.save()
        amounts = [
            p.getHAPvalues(hist)["Scale"][0] * p.data["General"]["Mass"]
            for p in project.phases()
        ]
        total = sum(amounts)
        rec = {
            "phase_id": args.phase,
            "phase": phase.name,
            "uiso_A2": uiso,
            "Rwp": float(hist.residuals["wR"]),
            "Rp": float(hist.residuals["R"]),
            "weight_fractions": [v / total for v in amounts],
            "gpx": str(output),
        }
        records.append(rec)
        print(json.dumps(rec), flush=True)
    print("BEST", json.dumps(min(records, key=lambda r: r["Rwp"])), flush=True)


if __name__ == "__main__":
    main()
