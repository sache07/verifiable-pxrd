#!/usr/bin/env python3
"""Evaluate a fixed March-Dollase coefficient grid with settled scales/background."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def prepare(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("outdir")
    parser.add_argument("phase", type=int)
    parser.add_argument("h", type=int)
    parser.add_argument("k", type=int)
    parser.add_argument("l", type=int)
    parser.add_argument("ratios", nargs="+", type=float)
    args = parser.parse_args()
    source = Path(args.source).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    axis = [args.h, args.k, args.l]
    G2.SetPrintLevel("warn")
    records = []
    for ratio in args.ratios:
        tag = f"p{args.phase}_{args.h}{args.k}{args.l}_r{ratio:.3f}".replace(".", "p")
        output = outdir / f"{tag}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
        prepare(project)
        hist = project.histogram(0)
        controls = project.data["Controls"]["data"]
        controls["max cyc"] = 10
        controls["min dM/M"] = 1e-7
        controls["shift factor"] = 0.25
        controls["parmFrozen"] = {"FrozenList": []}
        po = project.phase(args.phase).getHAPvalues(hist)["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", ratio, False, axis
        project.refine(makeBack=False)
        project.save()
        amounts = [
            p.getHAPvalues(hist)["Scale"][0] * p.data["General"]["Mass"]
            for p in project.phases()
        ]
        total = sum(amounts)
        rec = {
            "tag": tag,
            "phase": project.phase(args.phase).name,
            "axis": axis,
            "ratio": ratio,
            "Rwp": float(hist.residuals["wR"]),
            "Rp": float(hist.residuals["R"]),
            "weight_fractions": [v / total for v in amounts],
            "gpx": str(output),
        }
        records.append(rec)
        print(json.dumps(rec), flush=True)
    print("BEST", json.dumps(min(records, key=lambda r: r["Rwp"])), flush=True)


if __name__ == "__main__":
    main()
