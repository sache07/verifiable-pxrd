#!/usr/bin/env python3
"""Run conservative GSAS-II phase-inventory trials on the supplied pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def phase_path(cod_id: str) -> Path:
    root = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
    return root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summarize(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phases = []
    raw = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        scale = float(hap["Scale"][0])
        mass = float(phase.data["General"]["Mass"])
        raw.append(max(0.0, scale * mass))
        phases.append(
            {
                "name": phase.name,
                "scale": scale,
                "mass": mass,
                "cell": phase.get_cell(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
            }
        )
    denom = sum(raw)
    for phase, value in zip(phases, raw):
        phase["weight_fraction"] = value / denom if denom else 0.0
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    result = {
        "label": label,
        "residuals": hist.residuals,
        "covariance": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
        "instrument": {k: v for k, v in inst.items() if k in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}},
        "sample": {k: v for k, v in sample.items() if k in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"}},
        "phases": phases,
    }
    print(json.dumps(result, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)))
    return result


def refine_step(
    project: G2.G2Project,
    label: str,
    set_dict: dict | None = None,
    clear_dict: dict | None = None,
) -> None:
    if clear_dict:
        project.set_refinement({"clear": clear_dict})
    if set_dict:
        project.set_refinement({"set": set_dict})
    project.refine(makeBack=False)
    project.save()
    summarize(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    parser.add_argument("ids", nargs="+")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(Path("pattern.xye").resolve()),
        str(Path("instrument.instprm").resolve()),
        fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    for cod_id in args.ids:
        project.add_phase(
            str(phase_path(cod_id)),
            phasename=f"COD_{cod_id}",
            histograms=[hist],
            fmthint="CIF",
        )

    # A smooth full-range background. Eight terms are enough to represent the
    # measured monotonic tail without tracking point noise.
    hist.set_refinements(
        {
            "Limits": [float(hist.getdata("X")[0]), float(hist.getdata("X")[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [600.0, -500.0, 350.0, -200.0, 100.0, -50.0, 20.0, -5.0],
                "refine": True,
            },
        }
    )
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.data["Controls"]["data"]["shift factor"] = 0.5
    project.save()

    # Keep uncertain instrumental/specimen terms inside the ranges described
    # for this laboratory. This also prevents cell/zero/height correlations
    # from finding numerically good but physically meaningless solutions.
    limits = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
    }
    for variable, (lower, upper) in limits.items():
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    for phase in project.phases():
        variable = f"{phase.id}:0:Scale"
        project.set_Controls("parmMin", 0.0, variable=variable)

    refine_step(project, "background_scales", {"Scale": True})
    refine_step(project, "cells_1", {"Cell": True})
    refine_step(project, "shift", {"Sample Parameters": ["Shift"]}, {"Cell": True})
    refine_step(project, "cells_2", {"Cell": True}, {"Sample Parameters": ["Shift"]})
    refine_step(project, "zero", {"Instrument Parameters": ["Zero"]}, {"Cell": True})
    refine_step(project, "cells_3", {"Cell": True}, {"Instrument Parameters": ["Zero"]})
    refine_step(
        project,
        "instrument_profile",
        {"Instrument Parameters": ["U", "W", "X", "SH/L"]},
        {"Cell": True},
    )
    summarize(project, "final")


if __name__ == "__main__":
    main()
