#!/usr/bin/env python3
"""Test a small grid of bounded oxygen moves along least-squares directions."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def wrapped_delta(target: float, source: float) -> float:
    return (target - source + 0.5) % 1.0 - 0.5


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("direction")
    parser.add_argument("outdir")
    args = parser.parse_args()
    source = Path(args.source).resolve()
    direction = G2.G2Project(str(Path(args.direction).resolve()))
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    records = []
    for zfrac in (0.0, 0.1, 0.2):
        for wfrac in (0.0, 0.02, 0.04):
            tag = f"z{int(round(100*zfrac)):02d}_w{int(round(100*wfrac)):02d}"
            output = outdir / f"{tag}.gpx"
            project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
            hist = project.histogram(0)
            controls = project.data["Controls"]["data"]
            controls["max cyc"] = 8
            controls["min dM/M"] = 1e-6
            controls["shift factor"] = 0.25
            controls["parmFrozen"] = {"FrozenList": []}

            for key, val in hist.InstrumentParameters.items():
                if isinstance(val, list) and len(val) > 2: val[2] = False
            for val in hist.SampleParameters.values():
                if isinstance(val, list) and len(val) > 1 and isinstance(val[1], bool): val[1] = False
            for phase in project.phases():
                phase.clear_refinements({"Cell": True})
                phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True})
                for atom in phase.atoms(): atom.refinement_flags = " "

            for phase_index, fraction in ((0, zfrac), (1, wfrac)):
                src_atoms = project.phase(phase_index).atoms()
                dst_atoms = direction.phase(phase_index).atoms()
                for src_atom, dst_atom in zip(src_atoms, dst_atoms):
                    if src_atom.element != "O": continue
                    xyz = [
                        (s + fraction * wrapped_delta(t, s)) % 1.0
                        for s, t in zip(src_atom.coordinates, dst_atom.coordinates)
                    ]
                    src_atom.coordinates = xyz

            project.refine(makeBack=False)
            project.save()
            amounts = [p.getHAPvalues(hist)["Scale"][0] * p.data["General"]["Mass"] for p in project.phases()]
            total = sum(amounts)
            rec = {
                "tag": tag,
                "znwo4_fraction_of_step": zfrac,
                "wo3_fraction_of_step": wfrac,
                "Rwp": hist.residuals.get("wR"),
                "weight_fractions": [a / total for a in amounts],
                "gpx": str(output),
            }
            records.append(rec)
            print(json.dumps(rec), flush=True)
    print("BEST", json.dumps(min(records, key=lambda x: x["Rwp"])), flush=True)


if __name__ == "__main__":
    main()
