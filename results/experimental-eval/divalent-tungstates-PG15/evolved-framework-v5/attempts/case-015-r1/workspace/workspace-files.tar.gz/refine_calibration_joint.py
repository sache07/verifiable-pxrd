#!/usr/bin/env python3
"""Jointly settle phase cells, zero, and specimen height, then replay fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(Path(args.source).resolve()), newgpx=str(output))
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    hist.InstrumentParameters["Zero"][2] = True
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 40
    controls["min dM/M"] = 1e-8
    controls["shift factor"] = 0.15
    controls["parmFrozen"] = {"FrozenList": []}
    project.refine(makeBack=False)
    refined = {
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "zero": hist.InstrumentParameters["Zero"][1],
        "shift_um": hist.SampleParameters["Shift"][0],
        "cells": [phase.get_cell() for phase in project.phases()],
        "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }
    print("REFINED", json.dumps(refined, default=str), flush=True)

    hist.InstrumentParameters["Zero"][2] = False
    hist.SampleParameters["Shift"][1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    controls["parmFrozen"] = {"FrozenList": []}
    project.refine(makeBack=False)
    project.save()
    replay = {
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "zero": hist.InstrumentParameters["Zero"][1],
        "shift_um": hist.SampleParameters["Shift"][0],
        "cells": [phase.get_cell() for phase in project.phases()],
        "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }
    print("REPLAY", json.dumps(replay, default=str), flush=True)


if __name__ == "__main__":
    main()
