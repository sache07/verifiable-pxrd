#!/usr/bin/env python3
"""Export the required deliverables directly from the frozen final GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PHASES = (
    {
        "name": "ZnWO4",
        "description": "zinc tungstate (wolframite)",
        "reference": "COD 1520641",
        "cif": "phase_ZnWO4.cif",
    },
    {
        "name": "WO3",
        "description": "monoclinic tungsten trioxide",
        "reference": "COD 2311041",
        "cif": "phase_WO3.cif",
    },
    {
        "name": "ZnO",
        "description": "zinc oxide (wurtzite)",
        "reference": "COD 9004178",
        "cif": "phase_ZnO.cif",
    },
)


def plain_cell(phase: G2.G2Phase) -> dict[str, float]:
    return {key: float(value) for key, value in phase.get_cell().items()}


def main() -> None:
    root = Path(__file__).resolve().parent
    project_path = root / "final.gpx"
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(project_path))
    hist = project.histogram(0)

    amounts = []
    for phase in project.phases():
        scale = float(phase.getHAPvalues(hist)["Scale"][0])
        amounts.append(scale * float(phase.data["General"]["Mass"]))
    total = sum(amounts)

    phase_results = []
    for phase, spec, amount in zip(project.phases(), PHASES, amounts):
        cif_path = root / spec["cif"]
        phase.export_CIF(str(cif_path))
        hap = phase.getHAPvalues(hist)
        phase_results.append(
            {
                "name": spec["name"],
                "description": spec["description"],
                "reference_structure": spec["reference"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": spec["cif"],
                "weight_fraction": amount / total,
                "weight_percent": 100.0 * amount / total,
                "unit_cell": plain_cell(phase),
                "phase_Rf_percent": float(hist.residuals[f"{phase.id}:0:Rf"]),
                "crystallite_size_um": float(hap["Size"][1][0]),
            }
        )

    arrays = hist.data["data"][1]
    x, observed, _weight, calculated, _background, _stored_difference = [
        np.ma.asarray(v).filled(np.nan) for v in arrays
    ]
    difference = observed - calculated
    with (root / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(("two_theta_deg", "observed", "calculated", "difference"))
        writer.writerows(
            (f"{xx:.8f}", f"{yo:.8f}", f"{yc:.8f}", f"{dy:.8f}")
            for xx, yo, yc, dy in zip(x, observed, calculated, difference)
        )

    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "fraction_basis": "normalized over the three modeled crystalline phases",
        "fraction_method": "GSAS-II phase scale multiplied by unit-cell mass, then normalized",
        "phases": phase_results,
        "fit_statistics": {
            "Rwp_percent": float(hist.residuals["wR"]),
            "Rp_percent": float(hist.residuals["R"]),
            "Rexp_percent": float(hist.residuals["wRmin"]),
            "GOF": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "N_observations": int(rvals["Nobs"]),
            "N_refined_variables_in_final_scale_background_settle": int(rvals["Nvars"]),
        },
        "difference_definition": "observed - calculated",
    }
    with (root / "result.json").open("w") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")

    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
