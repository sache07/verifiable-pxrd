#!/usr/bin/env python3
"""Refine phase cells with calibration fixed, then replay the fixed result."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(Path(args.source).resolve()), newgpx=str(output))
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 25
    controls["min dM/M"] = 1e-8
    controls["shift factor"] = 0.25
    controls["parmFrozen"] = {"FrozenList": []}
    project.refine(makeBack=False)
    print(
        "REFINED",
        json.dumps(
            {
                "Rwp": hist.residuals.get("wR"),
                "Rp": hist.residuals.get("R"),
                "cells": [p.get_cell() for p in project.phases()],
                "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
            },
            default=str,
        ),
        flush=True,
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    controls["parmFrozen"] = {"FrozenList": []}
    project.refine(makeBack=False)
    project.save()
    print(
        "REPLAY",
        json.dumps(
            {
                "Rwp": hist.residuals.get("wR"),
                "Rp": hist.residuals.get("R"),
                "cells": [p.get_cell() for p in project.phases()],
                "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
            },
            default=str,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
