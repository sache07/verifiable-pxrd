#!/usr/bin/env python3
"""Refine symmetry-allowed coordinates in scattering-power order."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def atom_state(phase: G2.G2Phase) -> list[dict]:
    out = []
    for atom in phase.atoms():
        try:
            u = atom.uiso
        except Exception:
            u = "anisotropic"
        out.append(
            {
                "label": atom.label,
                "element": atom.element,
                "xyz": list(atom.coordinates),
                "occupancy": atom.occupancy,
                "U": u,
                "flags": atom.refinement_flags,
            }
        )
    return out


def summary(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    amounts = [
        max(0.0, p.getHAPvalues(hist)["Scale"][0] * p.data["General"]["Mass"])
        for p in project.phases()
    ]
    total = sum(amounts)
    print(
        json.dumps(
            {
                "label": label,
                "residuals": hist.residuals,
                "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
                "phases": [
                    {
                        "name": p.name,
                        "cell": p.get_cell(),
                        "weight_fraction": a / total,
                        "atoms": atom_state(p),
                    }
                    for p, a in zip(project.phases(), amounts)
                ],
            },
            indent=2,
            default=str,
        ),
        flush=True,
    )


def clear_atom_flags(project: G2.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def refine_group(
    project: G2.G2Project,
    output: Path,
    label: str,
    phase_index: int,
    elements: set[str],
    exclude_labels: set[str] | None = None,
) -> None:
    clear_atom_flags(project)
    phase = project.phase(phase_index)
    exclude_labels = exclude_labels or set()
    for atom in phase.atoms():
        if atom.element in elements and atom.label not in exclude_labels:
            atom.refinement_flags = "X"
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(project.filename, output.with_name(f"{output.stem}_{label}.gpx"))
    summary(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.source).resolve()), newgpx=str(output))
    hist = project.histogram(0)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1e-6
    controls["shift factor"] = 0.12
    controls["parmFrozen"] = {"FrozenList": []}

    # Keep already selected cells/calibration/profile terms fixed while site
    # parameters are assessed one group at a time.
    for key in hist.InstrumentParameters:
        if len(hist.InstrumentParameters[key]) > 2:
            hist.InstrumentParameters[key][2] = False
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
    clear_atom_flags(project)

    refine_group(project, output, "znwo4_heavy", 0, {"W", "Zn"})
    refine_group(project, output, "wo3_heavy", 1, {"W"})
    # Zn is fixed by the origin choice in wurtzite; the oxygen z coordinate is
    # the only useful internal positional degree of freedom.
    refine_group(project, output, "zno_oxygen", 2, {"O"})
    refine_group(project, output, "znwo4_oxygen", 0, {"O"})
    refine_group(project, output, "wo3_oxygen", 1, {"O"})

    clear_atom_flags(project)
    project.save()


if __name__ == "__main__":
    main()
