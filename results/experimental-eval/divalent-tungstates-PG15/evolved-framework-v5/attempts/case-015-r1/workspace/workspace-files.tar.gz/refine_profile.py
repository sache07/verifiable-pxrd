#!/usr/bin/env python3
"""Refine common and phase-specific profile terms with physical bounds."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def result(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    raw = []
    phases = []
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        amount = max(0.0, float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
        raw.append(amount)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"][1:3],
                "mustrain": hap["Mustrain"][1:3],
            }
        )
    total = sum(raw)
    for phase, amount in zip(phases, raw):
        phase["weight_fraction"] = amount / total
    inst = hist.InstrumentParameters
    out = {
        "label": label,
        "residuals": hist.residuals,
        "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
        "instrument": {k: inst[k] for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "sample": {k: hist.SampleParameters[k] for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "phases": phases,
        "frozen": str(project.data["Controls"]["data"].get("parmFrozen", {})),
    }
    print(json.dumps(out, indent=2, default=str), flush=True)
    return out


def set_bound(project: G2.G2Project, variable: str, lower: float, upper: float) -> None:
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def checkpoint(project: G2.G2Project, path: Path, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, path.with_name(f"{path.stem}_{label}.gpx"))
    result(project, label)


def set_phase_profile_flags(project: G2.G2Project, refine: bool) -> None:
    for phase in project.phases():
        hap = phase.getHAPvalues(project.histogram(0))
        hap["Size"][0] = "isotropic"
        hap["Mustrain"][0] = "isotropic"
        hap["Size"][2] = [bool(refine), False, False]
        hap["Mustrain"][2] = [bool(refine), False, False]


def set_instrument_flags(hist: G2.G2PwdrData, refine: bool) -> None:
    for key in ("U", "W", "X", "SH/L"):
        hist.InstrumentParameters[key][2] = bool(refine)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    args = parser.parse_args()
    source = Path(args.source).resolve()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = project.histogram(0)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1e-6
    controls["shift factor"] = 0.35
    controls["parmFrozen"] = {"FrozenList": []}

    # Reset the common profile after the inventory screen, where it had tried
    # to absorb all phase broadening and reached its allowed limits.
    for key, value in {"U": 10.0, "W": 10.0, "X": 1.0, "SH/L": 0.02}.items():
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False

    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        set_bound(project, f"{phase.id}:0:Size;i", 0.04, 1.50)
        set_bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
    for variable, lower, upper in (
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
    ):
        set_bound(project, variable, lower, upper)

    # Alternate the largely correlated common and phase terms. Each checkpoint
    # is replayable and can be retained if a later stage becomes nonphysical.
    set_phase_profile_flags(project, True)
    project.refine(makeBack=False)
    checkpoint(project, output, "phase_profile_1")

    set_phase_profile_flags(project, False)
    set_instrument_flags(hist, True)
    controls["parmFrozen"] = {"FrozenList": []}
    project.refine(makeBack=False)
    checkpoint(project, output, "instrument")

    set_instrument_flags(hist, False)
    set_phase_profile_flags(project, True)
    controls["parmFrozen"] = {"FrozenList": []}
    project.refine(makeBack=False)
    checkpoint(project, output, "phase_profile_2")

    project.save()


if __name__ == "__main__":
    main()
