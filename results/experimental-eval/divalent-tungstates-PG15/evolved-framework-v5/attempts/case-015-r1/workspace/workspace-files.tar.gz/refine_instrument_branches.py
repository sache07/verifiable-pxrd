#!/usr/bin/env python3
"""Refine one bounded common profile coefficient at a time and replay it fixed."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2


BOUNDS = {"U": (0.0, 40.0), "W": (2.0, 40.0), "X": (0.1, 6.0), "SH/L": (0.005, 0.1)}


def prepare(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("outdir")
    parser.add_argument("keys", nargs="*", default=list(BOUNDS))
    args = parser.parse_args()
    source = Path(args.source).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    records = []
    for key in args.keys:
        if key not in BOUNDS:
            raise ValueError(key)
        output = outdir / f"{key.replace('/', '_')}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
        prepare(project)
        hist = project.histogram(0)
        controls = project.data["Controls"]["data"]
        controls["max cyc"] = 25
        controls["min dM/M"] = 1e-8
        controls["shift factor"] = 0.2
        controls["parmFrozen"] = {"FrozenList": []}
        parameter = hist.InstrumentParameters[key]
        parameter[2] = True
        status = "ok"
        try:
            project.refine(makeBack=False)
            raw = float(parameter[1])
            if not math.isfinite(raw):
                raise ValueError("non-finite coefficient")
            lower, upper = BOUNDS[key]
            bounded = min(upper, max(lower, raw))
            parameter[1] = bounded
            parameter[2] = False
            controls["parmFrozen"] = {"FrozenList": []}
            project.refine(makeBack=False)
            project.save()
            rec = {
                "key": key,
                "raw": raw,
                "bounded": bounded,
                "at_bound": raw != bounded,
                "Rwp": float(hist.residuals["wR"]),
                "Rp": float(hist.residuals["R"]),
                "gpx": str(output),
                "status": status,
            }
        except Exception as exc:
            status = "failed"
            rec = {"key": key, "status": status, "error": repr(exc)}
        records.append(rec)
        print(json.dumps(rec), flush=True)
    valid = [r for r in records if r["status"] == "ok"]
    if valid:
        print("BEST", json.dumps(min(valid, key=lambda r: r["Rwp"])), flush=True)


if __name__ == "__main__":
    main()
