#!/usr/bin/env python3
"""Freeze the selected GSAS-II model and export internally consistent outputs."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def json_dump(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def safe_name(name: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_.-]+", "_", name).strip("_.")
    return cleaned or "phase"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_gpx", type=Path)
    parser.add_argument("workspace", type=Path)
    parser.add_argument("replay_worker", type=Path)
    args = parser.parse_args()

    source = args.source_gpx.resolve()
    root = args.workspace.resolve()
    worker = args.replay_worker.resolve()
    project_path = root / "final.gpx"
    shutil.copy2(source, project_path)

    pattern = np.loadtxt(root / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if pattern.ndim != 2 or pattern.shape[1] != 2:
        raise ValueError("pattern.csv must have two columns")

    project = G2sc.G2Project(gpxfile=str(project_path))
    matches = []
    for hist in project.histograms():
        x, y = (np.asarray(a, dtype=float) for a in hist.data["data"][1][:2])
        if (
            x.shape == pattern[:, 0].shape
            and np.allclose(x, pattern[:, 0], rtol=0, atol=1e-7)
            and np.allclose(y, pattern[:, 1], rtol=0, atol=1e-5)
        ):
            matches.append(hist.name)
    if len(matches) != 1:
        raise ValueError(f"expected one matching histogram, found {matches}")
    histogram = matches[0]

    replay_dir = root / "analysis" / "replay_final"
    replay_dir.mkdir(parents=True, exist_ok=True)
    request_path = replay_dir / "request.json"
    json_dump(
        request_path,
        {
            "project": str(project_path),
            "observed": str(root / "inputs" / "pattern.csv"),
            "histogram": histogram,
        },
    )
    proc = subprocess.run(
        [sys.executable, str(worker), str(request_path)],
        cwd=replay_dir,
        text=True,
        capture_output=True,
    )
    replay = json.loads((replay_dir / "replay.json").read_text())
    if proc.returncode or replay.get("status") != "replayed":
        raise RuntimeError(
            "full-grid replay failed:\n"
            + proc.stdout
            + proc.stderr
            + "\n"
            + json.dumps(replay, indent=2)
        )

    curve = np.load(replay_dir / "prediction.npz")
    x = np.asarray(curve["x"], dtype=float)
    observed = np.asarray(curve["observed"], dtype=float)
    calculated = np.asarray(curve["predicted"], dtype=float)
    background = np.asarray(curve["background"], dtype=float)
    if not (
        np.allclose(x, pattern[:, 0], rtol=0, atol=1e-7)
        and np.allclose(observed, pattern[:, 1], rtol=0, atol=1e-5)
    ):
        raise ValueError("replayed profile does not match the submitted measurement grid")
    difference = observed - calculated
    np.savetxt(
        root / "fit.csv",
        np.column_stack([x, observed, calculated, difference, background]),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.10f", "%.10f", "%.10f", "%.10f", "%.10f"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    denominator = float(np.sum(weights * observed**2))
    chi_squared = float(np.sum(weights * difference**2))
    rwp = float(100.0 * np.sqrt(chi_squared / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    covariance = project.data.get("Covariance", {}).get("data", {})
    n_parameters = len(covariance.get("varyList", []))
    degrees_of_freedom = len(x) - n_parameters
    gof = float(np.sqrt(chi_squared / degrees_of_freedom))
    rexp = float(100.0 * np.sqrt(degrees_of_freedom / denominator))

    phase_details = {
        "WO3": {
            "name": "monoclinic gamma-WO3",
            "formula": "WO3",
            "space_group": "P 21/c",
            "weight_fraction_uncertainty": 0.02,
        },
        "Co3O4": {
            "name": "spinel Co3O4",
            "formula": "Co3O4",
            "space_group": "F d -3 m",
            "weight_fraction_uncertainty": 0.02,
        },
    }
    phases = []
    seen_names = set()
    for index, phase in enumerate(replay["phases"]):
        project_name = phase["name"]
        if project_name not in phase_details:
            raise ValueError(f"unexpected project phase {project_name!r}")
        details = phase_details[project_name]
        cif_name = "phase_" + safe_name(project_name) + ".cif"
        shutil.copy2(replay_dir / phase["cif"], root / cif_name)
        phases.append(
            {
                "name": details["name"],
                "project_phase_name": project_name,
                "formula": details["formula"],
                "space_group": details["space_group"],
                "cif_path": cif_name,
                "weight_fraction": float(phase["weight_fraction"]),
                "weight_fraction_uncertainty": details["weight_fraction_uncertainty"],
                "fraction_uncertainty_scope": "estimated absolute systematic uncertainty",
            }
        )
        seen_names.add(project_name)
    if seen_names != set(phase_details):
        raise ValueError(f"missing project phases: {set(phase_details) - seen_names}")

    hist = project.histogram(histogram)
    instrument = hist.data["Instrument Parameters"][0]
    zero = float(instrument["Zero"][1])
    result = {
        "schema_version": 1,
        "phases": phases,
        "unresolved_components": [],
        "fraction_normalization": "modeled crystalline phases sum to one",
        "refinement_histogram": histogram,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": rexp,
            "goodness_of_fit": gof,
            "chi_squared": chi_squared,
            "data_points": int(len(x)),
            "refined_parameters": int(n_parameters),
            "degrees_of_freedom": int(degrees_of_freedom),
            "grid_scope": "entire observed scan",
            "weighting": "1/max(observed_counts,1)",
        },
        "calibration": {"zero_deg": zero},
        "profile_file": "fit.csv",
        "project_file": "final.gpx",
        "project_sha256": hashlib.sha256(project_path.read_bytes()).hexdigest(),
        "replay": {
            "status": replay["status"],
            "parameters_optimized": replay["parameters_optimized"],
            "project_unchanged": replay["project_unchanged"],
            "profile_review_flags": replay["profile_review_flags"],
        },
    }
    json_dump(root / "result.json", result)
    json_dump(
        replay_dir / "finalization_summary.json",
        {
            "result": result,
            "max_profile_identity_error": float(
                np.max(np.abs((observed - calculated) - difference))
            ),
            "minimum_calculated_count": float(np.min(calculated)),
            "fraction_sum": float(sum(p["weight_fraction"] for p in phases)),
        },
    )


if __name__ == "__main__":
    main()
