#!/usr/bin/env python3
"""Test one bounded March-Dollase preferred-orientation branch."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("phase")
    parser.add_argument("axis", help="comma-separated h,k,l")
    parser.add_argument("output_gpx")
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]
    if len(axis) != 3:
        raise SystemExit("axis must contain three integers")

    G2.SetPrintLevel("warn")
    # GSAS-II writes its active project before refinement. Work on a private
    # copy so independent branches never mutate or contend for the checkpoint.
    output = Path(args.output_gpx).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.input_gpx, output)
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histograms()[0]
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""

    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis
    pidx = [p.name for p in project.phases()].index(args.phase)
    project.set_Controls("parmMin", 0.7, variable=f"{pidx}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{pidx}:0:MD")
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save(str(output))

    raw = []
    for item in project.phases():
        phap = item.data["Histograms"][hist.name]
        raw.append(float(item.data["General"]["Mass"]) * float(phap["Scale"][0]))
    total = sum(raw)
    print(
        json.dumps(
            {
                "phase": args.phase,
                "axis": axis,
                "ratio": float(hap["Pref.Ori."][1]),
                "Rwp_percent": hist.get_wR(),
                "GOF": project.data["Covariance"]["data"]["Rvals"]["GOF"],
                "fractions": {
                    item.name: value / total for item, value in zip(project.phases(), raw)
                },
                "varyList": project.data["Covariance"]["data"]["varyList"],
            }
        )
    )


if __name__ == "__main__":
    main()
