#!/usr/bin/env python3
"""Test one physically allowed uniaxial microstrain branch."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("phase")
    parser.add_argument("axis")
    parser.add_argument("output_gpx")
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]
    if len(axis) != 3:
        raise SystemExit("axis must contain three integers")

    output = Path(args.output_gpx).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.input_gpx, output)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histograms()[0]
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""

    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    initial = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = initial
    hap["Mustrain"][1][1] = initial
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = axis
    pidx = [p.name for p in project.phases()].index(args.phase)
    for suffix in ("i", "a"):
        project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;{suffix}")
        project.set_Controls("parmMax", 8000.0, variable=f"{pidx}:0:Mustrain;{suffix}")
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save(str(output))
    print(
        json.dumps(
            {
                "phase": args.phase,
                "axis": axis,
                "equatorial_ppm": float(hap["Mustrain"][1][0]),
                "axial_ppm": float(hap["Mustrain"][1][1]),
                "Rwp_percent": hist.get_wR(),
                "GOF": project.data["Covariance"]["data"]["Rvals"]["GOF"],
                "varyList": project.data["Covariance"]["data"]["varyList"],
            }
        )
    )


if __name__ == "__main__":
    main()
