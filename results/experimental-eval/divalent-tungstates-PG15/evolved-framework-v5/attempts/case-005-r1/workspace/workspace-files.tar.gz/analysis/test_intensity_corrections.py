#!/usr/bin/env python3
"""Test bounded Uiso, polarization and surface-roughness corrections."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("--wo3-uiso", type=float, default=0.005)
    parser.add_argument("--co-uiso", type=float, default=0.010)
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--polarization-start", type=float, default=0.70)
    parser.add_argument("--rough-a-start", type=float, default=0.30)
    parser.add_argument("--rough-b-start", type=float, default=0.10)
    args = parser.parse_args()
    if not (0.003 <= args.wo3_uiso <= 0.020 and 0.003 <= args.co_uiso <= 0.020):
        raise SystemExit("Uiso values must be in the specimen range 0.003--0.020 A^2")

    output = Path(args.output_gpx).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.input_gpx, output)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histograms()[0]
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        value = args.wo3_uiso if phase.name == "WO3" else args.co_uiso
        for atom in phase.atoms():
            atom.uiso = value
            atom.refinement_flags = ""

    if args.polarization:
        hist.data["Instrument Parameters"][0]["Polariz."][1] = args.polarization_start
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    if args.roughness:
        hist.SampleParameters["SurfRoughA"] = [args.rough_a_start, True]
        hist.SampleParameters["SurfRoughB"] = [args.rough_b_start, True]
        project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")

    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save(str(output))
    raw = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    total = sum(raw)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    print(
        json.dumps(
            {
                "wo3_Uiso_A2": args.wo3_uiso,
                "co_Uiso_A2": args.co_uiso,
                "polarization": float(inst["Polariz."][1]),
                "SurfRoughA": float(sample["SurfRoughA"][0]),
                "SurfRoughB": float(sample["SurfRoughB"][0]),
                "Rwp_percent": hist.get_wR(),
                "GOF": project.data["Covariance"]["data"]["Rvals"]["GOF"],
                "fractions": {
                    phase.name: value / total for phase, value in zip(project.phases(), raw)
                },
                "varyList": project.data["Covariance"]["data"]["varyList"],
            }
        )
    )


if __name__ == "__main__":
    main()
