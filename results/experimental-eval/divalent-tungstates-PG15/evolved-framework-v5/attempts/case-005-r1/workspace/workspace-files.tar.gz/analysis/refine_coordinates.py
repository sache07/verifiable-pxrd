#!/usr/bin/env python3
"""Refine accepted-phase coordinates and common per-phase Uiso values."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def phase_summary(project: G2.G2Project) -> list[dict]:
    out = []
    for pidx, phase in enumerate(project.phases()):
        out.append(
            {
                "phase": phase.name,
                "atoms": [
                    {
                        "index": aidx,
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": [float(v) for v in atom.coordinates],
                        "Uiso": float(atom.uiso),
                        "flags": atom.refinement_flags,
                    }
                    for aidx, atom in enumerate(phase.atoms())
                ],
            }
        )
    return out


def summarize(project: G2.G2Project, step: str) -> dict:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "step": step,
        "Rwp_percent": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "varyList": list(cov.get("varyList", [])),
        "phases": phase_summary(project),
    }
    print(json.dumps(result))
    return result


def refine(project: G2.G2Project, outdir: Path, step: str, results: list[dict]) -> None:
    project.refine(printFile=str(outdir / f"{step}.lst"), makeBack=False)
    # Keep the active filename fixed at working.gpx. GSAS-II writes the active
    # project before each refinement, so changing the filename here would let
    # the next stage overwrite the prior checkpoint.
    shutil.copy2(project.filename, outdir / f"{step}.gpx")
    results.append(summarize(project, step))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("outdir")
    parser.add_argument("--refine-wo3-oxygen", action="store_true")
    parser.add_argument("--common-uiso", action="store_true")
    args = parser.parse_args()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.input_gpx)
    project.save(str(outdir / "working.gpx"))
    hist = project.histograms()[0]
    # Freeze the bounded profile checkpoint while extracting structural signal.
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    project.set_Controls("cycles", 6)

    results = [summarize(project, "initial")]
    wo3 = project.phase("WO3")
    wo3.set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
    refine(project, outdir, "01_W_coordinates", results)
    wo3.clear_refinements({"Atoms": ["W1", "W2"]})

    if args.refine_wo3_oxygen:
        oxygen = {atom.label: "X" for atom in wo3.atoms() if atom.element == "O"}
        wo3.set_refinements({"Atoms": oxygen})
        refine(project, outdir, "02_WO3_O_coordinates", results)
        wo3.clear_refinements({"Atoms": list(oxygen)})

    co = project.phase("Co3O4")
    co_oxygen = {atom.label: "X" for atom in co.atoms() if atom.element == "O"}
    co.set_refinements({"Atoms": co_oxygen})
    refine(project, outdir, "03_Co3O4_O_coordinate", results)
    co.clear_refinements({"Atoms": list(co_oxygen)})

    # The specimen generator assigns one scalar isotropic displacement value to
    # every site in a phase. Enforce that physical model rather than refining an
    # independent Uiso for each atom.
    if args.common_uiso:
        for pidx, phase in enumerate(project.phases()):
            variables = []
            for aidx, atom in enumerate(phase.atoms()):
                atom.uiso = 0.005
                atom.refinement_flags = "U"
                var = f"{pidx}::AUiso:{aidx}"
                variables.append(var)
                project.set_Controls("parmMin", 0.003, variable=var)
                project.set_Controls("parmMax", 0.020, variable=var)
            project.add_EquivConstr(tuple(variables))
        refine(project, outdir, "04_common_Uiso", results)

        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = ""
    project.save(str(outdir / "structure_best.gpx"))
    (outdir / "summary.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
