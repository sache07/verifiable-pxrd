#!/usr/bin/env python3
"""Build and refine controlled GSAS-II trial models for the specimen."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
INPUT_CSV = ROOT / "inputs" / "pattern.csv"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

MODELS = {
    "wo3_1528915": ("WO3", "1528915"),
    "wo3_2311041": ("WO3", "2311041"),
    "wo3_2106293": ("WO3", "2106293"),
    "wo3_1010618": ("WO3", "1010618"),
    "co3o4_9005896": ("Co3O4", "9005896"),
    "co3o4_5910031": ("Co3O4", "5910031"),
}


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inputs(outdir: Path) -> tuple[Path, Path]:
    xye = outdir / "pattern.xye"
    with INPUT_CSV.open(newline="") as src, xye.open("w") as dst:
        for row in csv.DictReader(src):
            y = float(row["intensity"])
            dst.write(f"{float(row['two_theta_deg']):.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")

    inst = outdir / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha laboratory data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.30;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst


def summarize(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    phases = []
    raw = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"])
        scale = float(hap["Scale"][0])
        raw.append(max(0.0, mass * scale))
        phases.append(
            {
                "name": phase.name,
                "mass": mass,
                "scale": scale,
                "cell": phase.data["General"]["Cell"][1:8],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
            }
        )
    total = sum(raw)
    for phase, value in zip(phases, raw):
        phase["weight_fraction"] = value / total if total else None
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "step": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "instrument": {k: v for k, v in inst.items() if k in {"Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."}},
        "sample": {k: sample.get(k) for k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "background": hist.data["Background"][0],
        "phases": phases,
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }
    print(json.dumps(result, default=str))
    return result


def run_refinement(project: G2.G2Project, outdir: Path, step: str) -> dict:
    project.refine(printFile=str(outdir / f"{step}.lst"), makeBack=False)
    project.save(str(outdir / f"{step}.gpx"))
    return summarize(project, step)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("models", nargs="+")
    args = parser.parse_args()
    unknown = set(args.models) - set(MODELS)
    if unknown:
        raise SystemExit(f"Unknown models: {sorted(unknown)}")

    outdir = ROOT / "analysis" / "trials" / args.name
    outdir.mkdir(parents=True, exist_ok=True)
    xye, instfile = write_inputs(outdir)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(outdir / "trial.gpx"))
    hist = project.add_powder_histogram(str(xye), str(instfile), fmthint="xye")
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [3000.0] + [0.0] * 9,
                "refine": True,
            }
        }
    )

    for model in args.models:
        formula, cod_id = MODELS[model]
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=f"{formula}_{cod_id}",
            histograms=[hist],
            fmthint="CIF",
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    project.set_Controls("cycles", 8)
    results = [summarize(project, "initial")]

    results.append(run_refinement(project, outdir, "01_scale_background"))

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    results.append(run_refinement(project, outdir, "02_zero"))

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    results.append(run_refinement(project, outdir, "03_cells"))

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]})
    results.append(run_refinement(project, outdir, "04_instrument_profile"))

    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    results.append(run_refinement(project, outdir, "05_size"))

    for phase in project.phases():
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    results.append(run_refinement(project, outdir, "06_mustrain"))

    (outdir / "summary.json").write_text(json.dumps(results, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
