#!/usr/bin/env python3
"""Print structural and residual diagnostics from a GSAS-II project."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks, peak_widths
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx")
    parser.add_argument("--csv")
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=args.gpx)
    hist = project.histograms()[0]
    data = hist.data["data"][1]
    x, yobs, weight, ycalc, bkg, diff = (np.asarray(data[i], dtype=float) for i in range(6))
    mask = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    print(f"histogram={hist.name} n={mask.sum()} Rwp={hist.get_wR():.8f}")
    print(f"array_identity max|(obs-calc)-diff|={np.max(np.abs((yobs[mask]-ycalc[mask])-diff[mask])):.6g}")

    if args.csv:
        out = Path(args.csv)
        out.parent.mkdir(parents=True, exist_ok=True)
        with out.open("w", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
            writer.writerows(zip(x, yobs, ycalc, diff, bkg))

    # Smooth only enough to suppress counting noise; coherent residual maxima
    # should span several grid points.
    smooth = gaussian_filter1d(diff, 2.0)
    sigma = np.sqrt(np.maximum(yobs, 1.0))
    z = smooth / sigma
    peaks, props = find_peaks(z, prominence=1.5, distance=6, width=2)
    widths = peak_widths(z, peaks, rel_height=0.5)[0] * np.median(np.diff(x))
    order = np.argsort(z[peaks])[::-1]
    print("positive residual maxima: 2theta, z, counts, width_deg")
    for j in order[:40]:
        i = peaks[j]
        print(f"  {x[i]:10.5f} {z[i]:8.3f} {diff[i]:10.2f} {widths[j]:8.4f}")

    npeaks, _ = find_peaks(-z, prominence=1.5, distance=6, width=2)
    norder = np.argsort(z[npeaks])
    print("negative residual minima: 2theta, z, counts")
    for j in norder[:30]:
        i = npeaks[j]
        print(f"  {x[i]:10.5f} {z[i]:8.3f} {diff[i]:10.2f}")

    for lo, hi in [(10, 20), (20, 30), (30, 40), (40, 55), (55, 70), (70, 85), (85, 100)]:
        use = (x >= lo) & (x < hi)
        rwp = 100.0 * np.sqrt(np.sum(weight[use] * diff[use] ** 2) / np.sum(weight[use] * yobs[use] ** 2))
        print(f"segment {lo:02d}-{hi:03d}: Rwp={rwp:.5f}% mean_diff={np.mean(diff[use]):.3f}")

    for phase in project.phases():
        print(f"phase={phase.name} SG={phase.data['General']['SGData']['SpGrp']}")
        print("  atom label type mult x y z occ Uiso flags")
        for atom in phase.atoms():
            print(
                f"  {atom.label:8s} {atom.element:3s} {atom.mult:3d} "
                f"{atom.coordinates[0]: .7f} {atom.coordinates[1]: .7f} {atom.coordinates[2]: .7f} "
                f"{atom.occupancy: .5f} {atom.uiso: .6f} {atom.refinement_flags!r}"
            )


if __name__ == "__main__":
    main()
