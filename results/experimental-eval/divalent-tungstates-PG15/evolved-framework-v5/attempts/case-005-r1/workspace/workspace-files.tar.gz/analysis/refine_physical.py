#!/usr/bin/env python3
"""Controlled physical refinement of the accepted WO3 + Co3O4 inventory."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PHASES = (("WO3", "2311041"), ("Co3O4", "9005896"))


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_observed(outdir: Path) -> Path:
    path = outdir / "pattern.xye"
    with (ROOT / "inputs" / "pattern.csv").open(newline="") as src, path.open("w") as dst:
        for row in csv.DictReader(src):
            y = float(row["intensity"])
            dst.write(f"{float(row['two_theta_deg']):.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    return path


def make_instrument(outdir: Path, args: argparse.Namespace) -> Path:
    path = outdir / "instrument.instprm"
    path.write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha laboratory data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        f"Zero:{args.zero};Polariz.:{args.polarization};Azimuth:0.0\n"
        f"U:{args.U};V:0.0;W:{args.W};X:{args.X};Y:0.0;Z:0.0;SH/L:{args.shl}\n"
    )
    return path


def fraction_data(project: G2.G2Project) -> list[dict]:
    hist = project.histograms()[0]
    rows = []
    total = 0.0
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = max(0.0, float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
        total += mass_scale
        rows.append(
            {
                "name": phase.name,
                "mass_scale": mass_scale,
                "scale": float(hap["Scale"][0]),
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:8]],
                "size_um": float(hap["Size"][1][0]),
                "microstrain_ppm": float(hap["Mustrain"][1][0]),
                "MD_ratio": float(hap["Pref.Ori."][1]),
                "MD_axis": list(hap["Pref.Ori."][3]),
            }
        )
    for row in rows:
        row["weight_fraction"] = row.pop("mass_scale") / total if total else None
    return rows


def summarize(project: G2.G2Project, step: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "step": step,
        "Rwp_percent": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "Polariz.", "U", "V", "W", "X", "SH/L")},
        "sample": {k: float(sample[k][0]) for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "background": [float(v) if isinstance(v, (int, float)) else v for v in hist.data["Background"][0]],
        "phases": fraction_data(project),
        "varyList": list(cov.get("varyList", [])),
    }
    print(json.dumps(result))
    return result


def refine(project: G2.G2Project, outdir: Path, step: str, results: list[dict]) -> None:
    project.refine(printFile=str(outdir / f"{step}.lst"), makeBack=False)
    project.save(str(outdir / f"{step}.gpx"))
    results.append(summarize(project, step))


def set_bound(project: G2.G2Project, var: str, lo: float, hi: float) -> None:
    project.set_Controls("parmMin", lo, variable=var)
    project.set_Controls("parmMax", hi, variable=var)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("--U", type=float, default=20.0)
    parser.add_argument("--W", type=float, default=20.0)
    parser.add_argument("--X", type=float, default=2.0)
    parser.add_argument("--shl", type=float, default=0.03)
    parser.add_argument("--zero", type=float, default=0.0)
    parser.add_argument("--shift", type=float, default=-600.0)
    parser.add_argument("--polarization", type=float, default=0.70)
    parser.add_argument("--wo3-size", type=float, default=0.30)
    parser.add_argument("--wo3-strain", type=float, default=1800.0)
    parser.add_argument("--co-size", type=float, default=1.0)
    parser.add_argument("--co-strain", type=float, default=300.0)
    args = parser.parse_args()

    outdir = ROOT / "analysis" / "physical" / args.name
    outdir.mkdir(parents=True, exist_ok=True)
    xye = make_observed(outdir)
    instfile = make_instrument(outdir, args)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(outdir / "working.gpx"))
    hist = project.add_powder_histogram(str(xye), str(instfile), fmthint="xye")
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [args.shift, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [3000.0] + [0.0] * 11,
                "refine": True,
            }
        }
    )

    start_profiles = ((args.wo3_size, args.wo3_strain), (args.co_size, args.co_strain))
    for (formula, cod_id), (size, strain) in zip(PHASES, start_profiles):
        phase = project.add_phase(
            str(cod_path(cod_id)), phasename=formula, histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    project.set_Controls("cycles", 6)
    set_bound(project, ":0:Zero", -0.25, 0.25)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    set_bound(project, ":0:Polariz.", 0.5, 1.0)
    set_bound(project, ":0:U", 0.0, 40.0)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:X", 0.1, 6.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    set_bound(project, ":0:SurfRoughA", 0.0, 1.0)
    set_bound(project, ":0:SurfRoughB", 0.0, 0.5)
    for pidx in range(2):
        set_bound(project, f"{pidx}:0:Scale", 0.0, 1000.0)
        set_bound(project, f"{pidx}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{pidx}:0:Mustrain;i", 0.0, 8000.0)

    results = [summarize(project, "initial")]
    refine(project, outdir, "01_scale_background", results)

    hist.set_refinements({"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]})
    refine(project, outdir, "02_calibration", results)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, outdir, "03_cells", results)
    refine(project, outdir, "04_cells_calibration", results)

    # Establish phase-specific broadening before allowing the common instrument
    # profile to move; each addition is checked in its own replayable checkpoint.
    phase = project.phase("WO3")
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine(project, outdir, "05_wo3_size", results)
    phase.clear_HAP_refinements({"Size": True})

    phase = project.phase("Co3O4")
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine(project, outdir, "06_co_size", results)
    phase.clear_HAP_refinements({"Size": True})

    phase = project.phase("WO3")
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, outdir, "07_wo3_strain", results)
    phase.clear_HAP_refinements({"Mustrain": True})

    phase = project.phase("Co3O4")
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, outdir, "08_co_strain", results)
    phase.clear_HAP_refinements({"Mustrain": True})

    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    refine(project, outdir, "09_instrument_w_x_shl", results)
    hist.clear_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})

    hist.set_refinements({"Instrument Parameters": ["U"]})
    refine(project, outdir, "10_instrument_u", results)
    hist.clear_refinements({"Instrument Parameters": ["U"]})

    # One bounded joint polish after coordinate-descent starts.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in project.phases():
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    refine(project, outdir, "11_joint_profile", results)

    project.save(str(outdir / "profile_best.gpx"))
    (outdir / "summary.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
