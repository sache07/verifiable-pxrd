#!/usr/bin/env python3
"""Coordinate-descent polish of the selected complete physical model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def summary(project: G2.G2Project, step: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    raw = []
    phase_rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        value = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        raw.append(value)
        phase_rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:8]],
                "size": [float(v) for v in hap["Size"][1]],
                "size_type": hap["Size"][0],
                "strain": [float(v) for v in hap["Mustrain"][1]],
                "strain_type": hap["Mustrain"][0],
                "strain_axis": list(hap["Mustrain"][3]),
            }
        )
    total = sum(raw)
    for row, value in zip(phase_rows, raw):
        row["weight_fraction"] = value / total
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "step": step,
        "Rwp_percent": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "Polariz.", "U", "V", "W", "X", "SH/L")},
        "sample": {k: float(sample[k][0]) for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "phases": phase_rows,
        "varyList": list(cov.get("varyList", [])),
    }


def refine(project: G2.G2Project, outdir: Path, step: str, results: list[dict]) -> None:
    project.refine(printFile=str(outdir / f"{step}.lst"), makeBack=False)
    shutil.copy2(project.filename, outdir / f"{step}.gpx")
    row = summary(project, step)
    results.append(row)
    print(json.dumps(row))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("outdir")
    args = parser.parse_args()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    working = outdir / "working.gpx"
    shutil.copy2(args.input_gpx, working)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(working))
    hist = project.histograms()[0]
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""
    project.set_Controls("cycles", 8)
    results = [summary(project, "initial")]

    wo3 = project.phase("WO3")
    hap = wo3.data["Histograms"][hist.name]
    hap["Size"][2][0] = True
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    refine(project, outdir, "01_WO3_profile", results)
    wo3.clear_HAP_refinements({"Size": True, "Mustrain": True})

    co = project.phase("Co3O4")
    hap = co.data["Histograms"][hist.name]
    hap["Size"][2][0] = True
    hap["Mustrain"][2][0] = True
    refine(project, outdir, "02_Co3O4_profile", results)
    co.clear_HAP_refinements({"Size": True, "Mustrain": True})

    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    refine(project, outdir, "03_instrument_profile", results)
    hist.clear_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, outdir, "04_polarization", results)
    hist.clear_refinements({"Instrument Parameters": ["Polariz."]})

    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    refine(project, outdir, "05_roughness", results)
    hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})

    # Revisit the strongly scattering W sites only after profile and specimen
    # terms are stable. Oxygen coordinates remain fixed to preserve geometry.
    wo3.set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
    refine(project, outdir, "06_W_coordinates", results)
    wo3.clear_refinements({"Atoms": ["W1", "W2"]})

    shutil.copy2(project.filename, outdir / "polished.gpx")
    (outdir / "summary.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
