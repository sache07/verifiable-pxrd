#!/usr/bin/env python3
"""Test small, fixed WO3 oxygen-coordinate starts along the profile gradient."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


# Direction obtained from a diagnostic free-O refinement. Only small fractions
# of this direction are tested; the unconstrained endpoint is not physical.
TARGET = {
    "O6": [0.7268200947064404, 0.4925685205817502, 0.7389558269070956],
    "O2": [0.2010911538433074, 0.4955587698517087, -0.018022034761497035],
    "O5": [0.7302394942888489, 0.046701588013214335, 0.7338251517255364],
    "O3": [0.9885285711548021, 0.27782786073525867, 0.6706767294467758],
    "O1": [0.21455121844807437, 0.06390301613284076, 0.9756456786324971],
    "O4": [0.49475707535513347, 0.25542103032964103, 0.7598995424968926],
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("fraction", type=float)
    parser.add_argument("output_gpx")
    args = parser.parse_args()
    if abs(args.fraction) > 0.25:
        raise SystemExit("bounded oxygen test is limited to |fraction| <= 0.25")

    output = Path(args.output_gpx).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.input_gpx, output)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histograms()[0]
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""

    wo3 = project.phase("WO3")
    starts = {}
    for atom in wo3.atoms():
        if atom.label not in TARGET:
            continue
        start = np.asarray(atom.coordinates, dtype=float)
        target = np.asarray(TARGET[atom.label], dtype=float)
        delta = target - start
        delta -= np.rint(delta)
        atom.coordinates = ((start + args.fraction * delta) % 1.0).tolist()
        starts[atom.label] = {"start": start.tolist(), "delta_fractional": delta.tolist(), "final": list(atom.coordinates)}

    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save(str(output))
    print(
        json.dumps(
            {
                "fraction": args.fraction,
                "Rwp_percent": hist.get_wR(),
                "GOF": project.data["Covariance"]["data"]["Rvals"]["GOF"],
                "coordinates": starts,
            }
        )
    )


if __name__ == "__main__":
    main()
