from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "uiso_equal.gpx"


def run(axis):
    tag = "".join(map(str, axis))
    gpx = G2.G2Project(str(BASE), newgpx=str(ROOT / f"strain_fixed_{tag}_work.gpx"))
    h = gpx.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    inst["U"][2] = False
    inst["W"][2] = False
    gpx.set_Frozen()
    p = gpx.phase("NiWO4")
    m = p.data["Histograms"][h.name]["Mustrain"]
    m[0] = "uniaxial"
    m[1][0] = 500.0
    m[1][1] = 500.0
    m[2] = [True, True, False]
    m[3] = list(axis)
    for suffix in ("i", "a"):
        gpx.set_Controls("parmMin", 0.0, variable=f"0:0:Mustrain;{suffix}")
        gpx.set_Controls("parmMax", 32000.0, variable=f"0:0:Mustrain;{suffix}")
    gpx.set_Controls("cycles", 8)
    gpx.refine()
    gpx.save()
    shutil.copy2(gpx.filename, ROOT / f"strain_fixed_{tag}.gpx")
    print(axis, "Rwp", h.get_wR(), "strain", m[:4], "size", p.data["Histograms"][h.name]["Size"][:3], "frozen", gpx.get_Frozen())


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    for axis in ((0, 0, 1), (1, 0, 0), (0, 1, 0)):
        run(axis)
