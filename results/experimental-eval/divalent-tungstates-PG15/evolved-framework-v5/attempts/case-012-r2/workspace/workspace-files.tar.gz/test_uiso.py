from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "physical_wo3_03_light_0p005.gpx"


def main():
    G2.SetPrintLevel("warn")
    work = ROOT / "uiso_work.gpx"
    gpx = G2.G2Project(str(BASE), newgpx=str(work))
    for ip, phase in enumerate(gpx.phases()):
        vars_ = []
        for ia, atom in enumerate(phase.atoms()):
            atom.uiso = 0.01
            atom.refinement_flags = "".join(sorted(set(atom.refinement_flags + "U")))
            name = f"{ip}::AUiso:{ia}"
            vars_.append(name)
            gpx.set_Controls("parmMin", 0.003, variable=name)
            gpx.set_Controls("parmMax", 0.020, variable=name)
        gpx.add_EquivConstr(vars_)
    gpx.set_Controls("cycles", 8)
    gpx.refine()
    gpx.save()
    shutil.copy2(gpx.filename, ROOT / "uiso_equal.gpx")
    print("Rwp", gpx.histogram(0).get_wR(), "frozen", gpx.get_Frozen())
    print("constraints", gpx.data["Constraints"]["data"])
    for p in gpx.phases():
        print(p.name, [(a.label, a.uiso, a.refinement_flags) for a in p.atoms()])
    print([(str(v), x) for v, x in zip(gpx.data["Covariance"]["data"].get("varyList", []), gpx.data["Covariance"]["data"].get("variables", [])) if "AUiso" in str(v)])


if __name__ == "__main__":
    main()
