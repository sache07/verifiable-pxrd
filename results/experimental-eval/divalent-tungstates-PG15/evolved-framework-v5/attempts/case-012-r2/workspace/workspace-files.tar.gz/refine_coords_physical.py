from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def freeze_copy(gpx, filename):
    gpx.save()
    shutil.copy2(gpx.filename, ROOT / filename)
    print(filename, "Rwp", gpx.histogram(0).get_wR())
    for p in gpx.phases():
        print(p.name, [(a.label, tuple(round(v, 7) for v in a.coordinates), a.refinement_flags) for a in p.atoms()])


def main_branch():
    G2.SetPrintLevel("warn")
    work = ROOT / "coords_physical_work.gpx"
    gpx = G2.G2Project(str(ROOT / "checkpoint_05b_width_gaussian.gpx"), newgpx=str(work))
    gpx.set_Controls("cycles", 8)
    ni, wo = gpx.phases()

    ni.set_refinements({"Atoms": {"Ni0": "X", "W1": "X"}})
    wo.set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
    gpx.refine()
    freeze_copy(gpx, "physical_09_heavy.gpx")

    ni.set_refinements({"Atoms": {"O2": "X", "O3": "X"}})
    gpx.refine()
    freeze_copy(gpx, "physical_10_ni_light.gpx")
    for p in gpx.phases():
        p.export_CIF(str(ROOT / f"physical10_{p.name}.cif"), quickmode=True)


def bounded_wo3(bound):
    work = ROOT / f"wo3_bound_{bound:.3f}_work.gpx"
    gpx = G2.G2Project(str(ROOT / "physical_10_ni_light.gpx"), newgpx=str(work))
    ni, wo = gpx.phases()
    oxygen = [a for a in wo.atoms() if a.element == "O"]
    starts = {a.label: tuple(a.coordinates) for a in oxygen}
    wo.set_refinements({"Atoms": {a.label: "X" for a in oxygen}})
    # One light-atom step, then enforce the small symmetry-preserving
    # displacement range supported by the specimen model.
    gpx.set_Controls("cycles", 1)
    gpx.refine()
    for atom in oxygen:
        start = starts[atom.label]
        fitted = atom.coordinates
        clipped = []
        for s, f in zip(start, fitted):
            delta = (f - s + 0.5) % 1.0 - 0.5
            delta = min(bound, max(-bound, delta))
            clipped.append((s + delta) % 1.0)
        atom.coordinates = clipped
        atom.refinement_flags = " "
    gpx.set_Controls("cycles", 6)
    gpx.refine()
    tag = str(bound).replace(".", "p")
    freeze_copy(gpx, f"physical_11_wo3_bound_{tag}.gpx")
    for p in gpx.phases():
        p.export_CIF(str(ROOT / f"bound_{tag}_{p.name}.cif"), quickmode=True)


if __name__ == "__main__":
    main_branch()
    bounded_wo3(0.005)
    bounded_wo3(0.010)
