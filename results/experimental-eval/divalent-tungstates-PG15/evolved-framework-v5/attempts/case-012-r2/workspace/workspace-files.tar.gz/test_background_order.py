from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "uiso_equal.gpx"


def run(order):
    gpx = G2.G2Project(str(BASE), newgpx=str(ROOT / f"background_{order}_work.gpx"))
    h = gpx.histogram(0)
    bkg = h.data["Background"][0]
    coeffs = list(bkg[3:]) + [0.0] * max(0, order - len(bkg[3:]))
    h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": order, "coeffs": coeffs[:order], "refine": True}})
    gpx.set_Controls("cycles", 8)
    gpx.refine()
    gpx.save()
    shutil.copy2(gpx.filename, ROOT / f"background_{order}.gpx")
    print(order, "Rwp", h.get_wR(), "bkg", h.data["Background"][0], "frozen", gpx.get_Frozen())


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    for order in (18, 20):
        run(order)
