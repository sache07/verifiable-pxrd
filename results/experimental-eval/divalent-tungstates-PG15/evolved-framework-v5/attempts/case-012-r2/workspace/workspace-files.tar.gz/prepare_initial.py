from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_models() -> None:
    # Wolframite topology from the closest ordinary divalent analogue in the
    # frozen index. The Ni cell is initialized near literature-sized wolframite
    # metrics; all allowed cell terms are subsequently refined against the scan.
    niwo4 = Structure.from_file(cod_path("9013902"))
    niwo4.replace_species({"Mg": "Ni"})
    frac = niwo4.frac_coords
    niwo4 = Structure(
        Lattice.monoclinic(4.60, 5.66, 4.91, 90.1),
        niwo4.species,
        frac,
        site_properties=niwo4.site_properties,
    )
    CifWriter(niwo4, symprec=0.02, refine_struct=False).write_file(ROOT / "initial_NiWO4.cif")

    # Room-temperature monoclinic WO3, the exact-composition reference whose
    # characteristic low-angle triplets occur in the observed pattern.
    wo3 = Structure.from_file(cod_path("1528915"))
    CifWriter(wo3, symprec=0.02, refine_struct=False).write_file(ROOT / "initial_WO3.cif")


def write_data() -> None:
    pattern = pd.read_csv(ROOT / "inputs" / "pattern.csv")
    x = pattern["two_theta_deg"].to_numpy(float)
    y = pattern["intensity"].to_numpy(float)
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(ROOT / "pattern.xye", np.column_stack([x, y, sigma]), fmt="%.8f %.8f %.8f")


if __name__ == "__main__":
    write_models()
    write_data()
