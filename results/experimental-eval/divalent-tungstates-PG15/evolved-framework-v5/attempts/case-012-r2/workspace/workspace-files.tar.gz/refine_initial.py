from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def summary(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    print(f"{label}: wR={hist.get_wR()}")
    print("  instrument", {k: inst[k] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L") if k in inst})
    print("  sample", hist.data["Sample Parameters"])
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(" ", phase.name, "cell", phase.get_cell(), "scale", hap["Scale"], "size", hap["Size"], "strain", hap["Mustrain"], "PO", hap["Pref.Ori."])


def save_checkpoint(project, name):
    project.save(str(ROOT / name))
    summary(project, name)


def main():
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(newgpx=str(ROOT / "initial.gpx"))
    hist = gpx.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "initial.instprm"), fmthint="xye"
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    p1 = gpx.add_phase(str(ROOT / "initial_NiWO4.cif"), phasename="NiWO4", histograms=[hist], fmthint="CIF")
    p2 = gpx.add_phase(
        "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif",
        phasename="WO3",
        histograms=[hist],
        fmthint="CIF",
    )

    hist.set_refinements({
        "Limits": [10.01, 99.99],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 10,
            "coeffs": [650.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            "refine": True,
        },
    })
    for p, scale in ((p1, 0.02), (p2, 0.01)):
        hap = p.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0

    gpx.set_Controls("cycles", 8)
    save_checkpoint(gpx, "checkpoint_00_setup.gpx")

    # Establish stable positive phase scales and the low-frequency background.
    gpx.refine()
    save_checkpoint(gpx, "checkpoint_01_scale_background.gpx")

    # Peak positions: refine both monoclinic cells with one common angular zero.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    p1.set_refinements({"Cell": True})
    p2.set_refinements({"Cell": True})
    gpx.refine()
    save_checkpoint(gpx, "checkpoint_02_cells_zero.gpx")

    # Instrumental profile first; phase broadening is held fixed in this pass.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]})
    gpx.refine()
    save_checkpoint(gpx, "checkpoint_03_instrument.gpx")

    # Add one physically supported isotropic size and strain term per phase.
    for p in (p1, p2):
        p.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True, "value": 1.0},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    gpx.refine()
    save_checkpoint(gpx, "checkpoint_04_phase_profile.gpx")

    gpx.save(str(ROOT / "initial_refined.gpx"))


if __name__ == "__main__":
    main()
