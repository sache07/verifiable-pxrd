from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def main():
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(str(ROOT / "uiso_equal.gpx"), newgpx=str(ROOT / "roughness_work.gpx"))
    h = gpx.histogram(0)
    h.data["Sample Parameters"]["SurfRoughA"] = [0.20, True]
    h.data["Sample Parameters"]["SurfRoughB"] = [0.10, True]
    gpx.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    gpx.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
    gpx.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    gpx.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    gpx.set_Controls("cycles", 8)
    gpx.refine()
    gpx.save()
    shutil.copy2(gpx.filename, ROOT / "roughness.gpx")
    print("Rwp", h.get_wR(), "rough", h.data["Sample Parameters"]["SurfRoughA"], h.data["Sample Parameters"]["SurfRoughB"], "frozen", gpx.get_Frozen())
    print([(str(v), x) for v, x in zip(gpx.data["Covariance"]["data"].get("varyList", []), gpx.data["Covariance"]["data"].get("variables", [])) if "Surf" in str(v)])


if __name__ == "__main__":
    main()
