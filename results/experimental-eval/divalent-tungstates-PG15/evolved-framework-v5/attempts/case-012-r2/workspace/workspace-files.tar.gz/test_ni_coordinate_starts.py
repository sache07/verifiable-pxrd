from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "candidate_uniaxial.gpx"

STARTS = {
    "zn": {
        "Ni0": (0.5, 0.3160, 0.75),
        "W1": (0.0, 0.18258, 0.25),
        "O2": (0.2169, 0.1051, 0.9363),
        "O3": (0.2565, 0.3777, 0.3996),
    },
    "mn": {
        "Ni0": (0.5, 0.3154, 0.75),
        "W1": (0.0, 0.18116, 0.25),
        "O2": (0.2124, 0.1000, 0.9432),
        "O3": (0.2498, 0.3780, 0.3937),
    },
}


def run(tag, coords):
    gpx = G2.G2Project(str(BASE), newgpx=str(ROOT / f"ni_start_{tag}_work.gpx"))
    p = gpx.phase("NiWO4")
    for label, xyz in coords.items():
        atom = p.atom(label)
        atom.coordinates = xyz
        atom.refinement_flags = "UX"
    gpx.set_Controls("cycles", 10)
    gpx.refine()
    gpx.save()
    shutil.copy2(gpx.filename, ROOT / f"ni_start_{tag}.gpx")
    print(tag, "Rwp", gpx.histogram(0).get_wR())
    print([(a.label, tuple(round(v, 7) for v in a.coordinates), a.uiso) for a in p.atoms()])
    for phase in gpx.phases():
        phase.export_CIF(str(ROOT / f"ni_start_{tag}_{phase.name}.cif"), quickmode=True)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    for tag, coords in STARTS.items():
        run(tag, coords)
