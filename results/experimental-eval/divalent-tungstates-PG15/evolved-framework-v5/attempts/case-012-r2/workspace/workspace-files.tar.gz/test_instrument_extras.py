from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "uiso_equal.gpx"


def run(key, low, high, start, tag):
    gpx = G2.G2Project(str(BASE), newgpx=str(ROOT / f"{tag}_work.gpx"))
    h = gpx.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    inst[key][1] = start
    inst[key][2] = True
    gpx.set_Controls("parmMin", low, variable=f":0:{key}")
    gpx.set_Controls("parmMax", high, variable=f":0:{key}")
    gpx.set_Controls("cycles", 8)
    gpx.refine()
    gpx.save()
    shutil.copy2(gpx.filename, ROOT / f"{tag}.gpx")
    print(tag, "Rwp", h.get_wR(), key, inst[key], "frozen", gpx.get_Frozen())


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    run("Polariz.", 0.5, 1.0, 0.8, "polarization")
    run("SH/L", 0.005, 0.10, 0.02, "axial")
