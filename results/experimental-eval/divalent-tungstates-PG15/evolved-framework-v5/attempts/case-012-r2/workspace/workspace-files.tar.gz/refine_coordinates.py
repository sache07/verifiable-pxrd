from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def report(gpx, label):
    h = gpx.histogram(0)
    print(label, "Rwp", h.get_wR(), "frozen", gpx.get_Frozen())
    for p in gpx.phases():
        print(p.name, p.get_cell())
        for atom in p.atoms():
            print(" ", atom.label, atom.element, atom.coordinates, atom.refinement_flags, atom.uiso)


def checkpoint(gpx, filename):
    gpx.save(str(ROOT / filename))
    report(gpx, filename)


def main():
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(
        str(ROOT / "checkpoint_06b_width_lorentz.gpx"),
        newgpx=str(ROOT / "coordinates.gpx"),
    )
    gpx.set_Controls("cycles", 8)
    ni, wo = gpx.phases()

    ni.set_refinements({"Atoms": {"Ni0": "X", "W1": "X"}})
    wo.set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
    gpx.refine()
    checkpoint(gpx, "checkpoint_09_heavy_coordinates.gpx")

    ni.set_refinements({"Atoms": {"O2": "X", "O3": "X"}})
    wo.set_refinements({"Atoms": {
        "O1": "X", "O2": "X", "O3": "X", "O4": "X", "O5": "X", "O6": "X"
    }})
    gpx.refine()
    checkpoint(gpx, "checkpoint_10_all_coordinates.gpx")

    # Re-run after the first large coordinate step to assess convergence.
    gpx.refine()
    checkpoint(gpx, "checkpoint_11_coordinates_converged.gpx")

    for p in gpx.phases():
        p.export_CIF(str(ROOT / f"diagnostic_{p.name}.cif"), quickmode=True)


if __name__ == "__main__":
    main()
