from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def main():
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(str(ROOT / "ni_start_zn.gpx"), newgpx=str(ROOT / "best_converged_work.gpx"))
    gpx.set_Controls("cycles", 12)
    gpx.refine()
    gpx.save()
    shutil.copy2(gpx.filename, ROOT / "best_converged.gpx")
    h = gpx.histogram(0)
    print("Rwp", h.get_wR(), "frozen", gpx.get_Frozen())
    print("Rvals", gpx.data["Covariance"]["data"].get("Rvals"))
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        print(p.name, p.get_cell(), p.data["General"]["Mass"], hap["Scale"], hap["Size"][:3], hap["Mustrain"][:4])
        print([(a.label, tuple(round(v, 8) for v in a.coordinates), a.uiso, a.refinement_flags) for a in p.atoms()])
        p.export_CIF(str(ROOT / f"best_converged_{p.name}.cif"), quickmode=True)


if __name__ == "__main__":
    main()
