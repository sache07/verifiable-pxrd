from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def report(project, label):
    h = project.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    print(label, "Rwp", h.get_wR())
    print(" inst", {k: inst[k][1:] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")})
    print(" sample", {k: h.data["Sample Parameters"][k] for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")})
    for p in project.phases():
        hap = p.data["Histograms"][h.name]
        print(p.name, "cell", p.get_cell(), "scale", hap["Scale"], "size", hap["Size"][:3], "strain", hap["Mustrain"][:3])


def checkpoint(project, filename):
    project.save(str(ROOT / filename))
    report(project, filename)


def main():
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(str(ROOT / "checkpoint_04_phase_profile.gpx"), newgpx=str(ROOT / "physical.gpx"))
    h = gpx.histogram(0)
    inst = h.data["Instrument Parameters"][0]

    # Remove the redundant overall histogram scale while preserving the current
    # calculated intensity exactly through the two HAP scales.
    overall = float(h.data["Sample Parameters"]["Scale"][0])
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        hap["Scale"][0] *= overall
        hap["Scale"][1] = True
    h.data["Sample Parameters"]["Scale"] = [1.0, False]

    # Re-express width with the physical generator-supported terms. V and Y are
    # fixed at zero; phase size/strain absorb real phase-specific broadening.
    starts = {"U": 20.0, "V": 0.0, "W": 20.0, "X": 1.5, "Y": 0.0, "SH/L": 0.02}
    for key, value in starts.items():
        inst[key][1] = value
        inst[key][2] = key in ("U", "W", "X")
    inst["Zero"][2] = True

    for p, size, strain in zip(gpx.phases(), (0.7, 1.5), (900.0, 3000.0)):
        hap = p.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][2] = [True, False, False]

    gpx.set_Controls("cycles", 10)
    gpx.refine()
    checkpoint(gpx, "checkpoint_05_physical_width.gpx")

    # Separate a specimen-height term (cos(theta) dependence) from angular zero.
    h.data["Sample Parameters"]["Shift"] = [0.0, True]
    gpx.refine()
    checkpoint(gpx, "checkpoint_06_shift.gpx")

    # Axial divergence affects low-angle asymmetry and is now introduced after
    # stable cells/calibration.
    inst["SH/L"][2] = True
    gpx.refine()
    checkpoint(gpx, "checkpoint_07_axial.gpx")


if __name__ == "__main__":
    main()
