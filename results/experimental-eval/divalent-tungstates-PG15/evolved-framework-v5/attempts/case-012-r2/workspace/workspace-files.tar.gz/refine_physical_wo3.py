from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WO3_SOURCE = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif"


def limit(gpx, name, low, high):
    gpx.set_Controls("parmMin", low, variable=name)
    gpx.set_Controls("parmMax", high, variable=name)


def freeze_copy(gpx, filename):
    gpx.save()
    shutil.copy2(gpx.filename, ROOT / filename)
    h = gpx.histogram(0)
    print(filename, "Rwp", h.get_wR(), "frozen", gpx.get_Frozen())
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        print(p.name, p.get_cell(), "scale", hap["Scale"], "size", hap["Size"][:3], "strain", hap["Mustrain"][:3])
        print([(a.label, tuple(round(v, 6) for v in a.coordinates), a.refinement_flags) for a in p.atoms()])


def build_base():
    work = ROOT / "physical_wo3_work.gpx"
    gpx = G2.G2Project(newgpx=str(work))
    h = gpx.add_powder_histogram(str(ROOT / "pattern.xye"), str(ROOT / "initial.instprm"), fmthint="xye")
    h.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    h.data["Sample Parameters"]["Gonio. radius"] = 200.0
    h.data["Sample Parameters"]["Scale"] = [1.0, False]
    ni = gpx.add_phase(str(ROOT / "physical10_NiWO4.cif"), phasename="NiWO4", histograms=[h], fmthint="CIF")
    wo = gpx.add_phase(WO3_SOURCE, phasename="WO3", histograms=[h], fmthint="CIF")

    bkg = [753.8, -604.5, 433.0, -231.4, 128.9, -68.9, 49.0, -28.1, 22.1, -9.4]
    h.set_refinements({
        "Limits": [10.01, 99.99],
        "Background": {"type": "chebyschev-1", "no. coeffs": 10, "coeffs": bkg, "refine": True},
    })
    inst = h.data["Instrument Parameters"][0]
    for key, value, refine in (
        ("Zero", -0.0812, True), ("U", 13.8, True), ("V", 0.0, False),
        ("W", 36.0, True), ("X", 0.1, False), ("Y", 0.0, False), ("SH/L", 0.02, False),
    ):
        inst[key][1] = value
        inst[key][2] = refine

    for p, scale, size, strain, size_ref, strain_ref in (
        (ni, 22.16, 0.112, 0.0, True, False),
        (wo, 2.31, 1.5, 6050.0, False, True),
    ):
        p.set_refinements({"Cell": True})
        hap = p.data["Histograms"][h.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][2] = [size_ref, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][2] = [strain_ref, False, False]

    for name, low, high in (
        (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0), (":0:Zero", -0.25, 0.25),
        ("0:0:Size;i", 0.04, 1.5), ("1:0:Mustrain;i", 0.0, 8000.0),
        ("0:0:Scale", 0.0, 1000.0), ("1:0:Scale", 0.0, 1000.0),
    ):
        limit(gpx, name, low, high)

    gpx.set_Controls("cycles", 10)
    gpx.refine()
    freeze_copy(gpx, "physical_wo3_01_base.gpx")

    # Continue the already physical NiWO4 coordinates and refine only the W
    # sublattice of the replacement WO3 reference.
    ni.set_refinements({"Atoms": {a.label: "X" for a in ni.atoms()}})
    wo.set_refinements({"Atoms": {a.label: "X" for a in wo.atoms() if a.element == "W"}})
    gpx.set_Controls("cycles", 8)
    gpx.refine()
    freeze_copy(gpx, "physical_wo3_02_heavy.gpx")
    for p in gpx.phases():
        p.export_CIF(str(ROOT / f"physical_wo3_heavy_{p.name}.cif"), quickmode=True)


def bounded_light(bound):
    tag = str(bound).replace(".", "p")
    work = ROOT / f"physical_wo3_light_{tag}_work.gpx"
    gpx = G2.G2Project(str(ROOT / "physical_wo3_02_heavy.gpx"), newgpx=str(work))
    wo = gpx.phase("WO3")
    oxygen = [a for a in wo.atoms() if a.element == "O"]
    starts = {a.label: tuple(a.coordinates) for a in oxygen}
    wo.set_refinements({"Atoms": {a.label: "X" for a in oxygen}})
    gpx.set_Controls("cycles", 1)
    gpx.refine()
    for atom in oxygen:
        clipped = []
        for start, fitted in zip(starts[atom.label], atom.coordinates):
            delta = (fitted - start + 0.5) % 1.0 - 0.5
            clipped.append((start + min(bound, max(-bound, delta))) % 1.0)
        atom.coordinates = clipped
        atom.refinement_flags = " "
    gpx.set_Controls("cycles", 6)
    gpx.refine()
    freeze_copy(gpx, f"physical_wo3_03_light_{tag}.gpx")
    for p in gpx.phases():
        p.export_CIF(str(ROOT / f"physical_wo3_{tag}_{p.name}.cif"), quickmode=True)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    build_base()
    bounded_light(0.005)
    bounded_light(0.010)
