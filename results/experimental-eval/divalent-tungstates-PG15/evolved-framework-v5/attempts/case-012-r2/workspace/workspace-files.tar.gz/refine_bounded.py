from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def report(project, label):
    h = project.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    cov = project.data.get("Covariance", {}).get("data", {})
    print(label, "Rwp", h.get_wR(), "frozen", project.get_Frozen())
    print(" inst", {k: inst[k][1:] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")})
    print(" sample", {k: h.data["Sample Parameters"][k] for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")})
    for p in project.phases():
        hap = p.data["Histograms"][h.name]
        print(p.name, "cell", p.get_cell(), "scale", hap["Scale"], "size", hap["Size"][:3], "strain", hap["Mustrain"][:3])
    print(" vary", list(zip(map(str, cov.get("varyList", [])), cov.get("variables", []))))


def checkpoint(project, filename):
    project.save(str(ROOT / filename))
    report(project, filename)


def limit(project, name, low, high):
    project.set_Controls("parmMin", low, variable=name)
    project.set_Controls("parmMax", high, variable=name)


def main():
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(str(ROOT / "checkpoint_04_phase_profile.gpx"), newgpx=str(ROOT / "bounded.gpx"))
    h = gpx.histogram(0)
    inst = h.data["Instrument Parameters"][0]

    overall = float(h.data["Sample Parameters"]["Scale"][0])
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        hap["Scale"][0] *= overall
        hap["Scale"][1] = True
    h.data["Sample Parameters"]["Scale"] = [1.0, False]

    starts = {"U": 20.0, "V": 0.0, "W": 20.0, "X": 1.5, "Y": 0.0, "SH/L": 0.02}
    for key, value in starts.items():
        inst[key][1] = value
        inst[key][2] = key in ("U", "W")
    inst["Zero"][2] = True

    for i, (p, size, strain) in enumerate(zip(gpx.phases(), (0.30, 1.0), (1000.0, 3000.0))):
        hap = p.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][2] = [True, False, False]
        limit(gpx, f"{i}:0:Size;i", 0.04, 1.5)
        limit(gpx, f"{i}:0:Mustrain;i", 0.0, 8000.0)
        limit(gpx, f"{i}:0:Scale", 0.0, 1000.0)

    for name, low, high in (
        (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0), (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10), (":0:Zero", -0.25, 0.25), (":0:Shift", -800.0, 800.0),
    ):
        limit(gpx, name, low, high)

    gpx.set_Controls("cycles", 8)
    gpx.refine()
    checkpoint(gpx, "checkpoint_05b_width_gaussian.gpx")

    inst["X"][2] = True
    gpx.refine()
    checkpoint(gpx, "checkpoint_06b_width_lorentz.gpx")

    h.data["Sample Parameters"]["Shift"] = [0.0, True]
    gpx.refine()
    checkpoint(gpx, "checkpoint_07b_shift.gpx")

    inst["SH/L"][2] = True
    gpx.refine()
    checkpoint(gpx, "checkpoint_08b_axial.gpx")


if __name__ == "__main__":
    main()
