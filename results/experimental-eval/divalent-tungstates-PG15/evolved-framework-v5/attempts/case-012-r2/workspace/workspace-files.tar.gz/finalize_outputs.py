from pathlib import Path
import csv
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def main():
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(str(ROOT / "best_converged.gpx"), newgpx=str(ROOT / "final.gpx"))
    gpx.save()
    h = gpx.histogram(0)

    cif_names = {"NiWO4": "NiWO4.cif", "WO3": "WO3.cif"}
    phase_rows = []
    mass_scales = []
    for phase in gpx.phases():
        phase.export_CIF(str(ROOT / cif_names[phase.name]), quickmode=True)
        hap = phase.data["Histograms"][h.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        mass_scales.append(mass_scale)
        phase_rows.append({
            "name": phase.name,
            "formula": phase.name,
            "cif_path": cif_names[phase.name],
            "weight_fraction": None,
        })
    total = sum(mass_scales)
    for row, mass_scale in zip(phase_rows, mass_scales):
        row["weight_fraction"] = mass_scale / total

    x, obs, weights, calc, background, difference = [
        np.asarray(a, dtype=float) for a in h.data["data"][1][:6]
    ]
    # Write the complete original grid. Difference follows the GSAS-II
    # convention and is observed minus calculated.
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        writer.writerows(zip(x, obs, calc, obs - calc))

    denominator = float(np.sum(np.square(obs) / np.maximum(obs, 1.0)))
    rwp_export = 100.0 * np.sqrt(
        float(np.sum(np.square(obs - calc) / np.maximum(obs, 1.0))) / denominator
    )
    rvals = gpx.data["Covariance"]["data"]["Rvals"]
    hist_stats = h.data["data"][0]
    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent": float(h.get_wR()),
            "rwp_from_exported_profile_percent": float(rwp_export),
            "rp_percent": float(hist_stats["R"]),
            "rexp_percent": float(hist_stats["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "n_points": int(rvals["Nobs"]),
            "n_refined_variables": int(rvals["Nvars"]),
        },
        "refinement_histogram": h.name,
        "weight_fraction_basis": "Normalized over the modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    print("calculated intensity range", float(calc.min()), float(calc.max()))
    print("background range", float(background.min()), float(background.max()))


if __name__ == "__main__":
    main()
