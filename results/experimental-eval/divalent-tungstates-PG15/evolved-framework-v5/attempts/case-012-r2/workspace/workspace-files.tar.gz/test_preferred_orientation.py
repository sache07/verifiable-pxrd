from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "physical_wo3_03_light_0p005.gpx"
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def run(phase_index, axis):
    tag = "".join(map(str, axis))
    work = ROOT / f"po_p{phase_index}_{tag}_work.gpx"
    gpx = G2.G2Project(str(BASE), newgpx=str(work))
    phase = gpx.phases()[phase_index]
    h = gpx.histogram(0)
    hap = phase.data["Histograms"][h.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    gpx.set_Controls("parmMin", 0.7, variable=f"{phase_index}:0:MD")
    gpx.set_Controls("parmMax", 1.4, variable=f"{phase_index}:0:MD")
    gpx.set_Controls("cycles", 6)
    gpx.refine()
    gpx.save()
    out = ROOT / f"po_p{phase_index}_{tag}.gpx"
    shutil.copy2(gpx.filename, out)
    print(phase.name, axis, "Rwp", h.get_wR(), "PO", hap["Pref.Ori."], "frozen", gpx.get_Frozen())
    cov = gpx.data["Covariance"]["data"]
    print([(str(v), x) for v, x in zip(cov.get("varyList", []), cov.get("variables", [])) if "MD" in str(v)])


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    for p in (0, 1):
        for axis in AXES:
            run(p, axis)
