from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def copy_report(gpx, filename):
    gpx.save()
    shutil.copy2(gpx.filename, ROOT / filename)
    h = gpx.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    print(filename, "Rwp", h.get_wR(), "frozen", gpx.get_Frozen())
    print("instrument", {k: inst[k] for k in ("Zero", "Polariz.", "U", "V", "W", "X", "SH/L")})
    print("limits", h.data["Limits"])
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        print(p.name, "mass", p.data["General"]["Mass"], "scale", hap["Scale"], "size", hap["Size"][:3], "strain", hap["Mustrain"][:4])
        print("atoms", [(a.label, tuple(round(v, 7) for v in a.coordinates), a.uiso, a.refinement_flags) for a in p.atoms()])


def simple():
    gpx = G2.G2Project(str(ROOT / "background_20.gpx"), newgpx=str(ROOT / "candidate_simple_work.gpx"))
    h = gpx.histogram(0)
    h.data["Limits"][1] = list(h.data["Limits"][0])
    inst = h.data["Instrument Parameters"][0]
    inst["Polariz."][2] = True
    inst["SH/L"][2] = True
    gpx.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    gpx.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    gpx.set_Controls("parmMax", 0.10, variable=":0:SH/L")
    gpx.set_Controls("cycles", 8)
    gpx.refine()
    copy_report(gpx, "candidate_simple.gpx")
    for p in gpx.phases():
        p.export_CIF(str(ROOT / f"candidate_simple_{p.name}.cif"), quickmode=True)


def uniaxial():
    gpx = G2.G2Project(str(ROOT / "candidate_simple.gpx"), newgpx=str(ROOT / "candidate_uniaxial_work.gpx"))
    h = gpx.histogram(0)
    p = gpx.phase("WO3")
    m = p.data["Histograms"][h.name]["Mustrain"]
    start = float(m[1][0])
    m[0] = "uniaxial"
    m[1][0] = start
    m[1][1] = start
    m[2] = [True, True, False]
    m[3] = [0, 1, 0]
    for suffix in ("i", "a"):
        gpx.set_Controls("parmMin", 0.0, variable=f"1:0:Mustrain;{suffix}")
        gpx.set_Controls("parmMax", 32000.0, variable=f"1:0:Mustrain;{suffix}")
    gpx.set_Controls("cycles", 8)
    gpx.refine()
    copy_report(gpx, "candidate_uniaxial.gpx")
    for phase in gpx.phases():
        phase.export_CIF(str(ROOT / f"candidate_uniaxial_{phase.name}.cif"), quickmode=True)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    simple()
    uniaxial()
