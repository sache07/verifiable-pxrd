from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "physical_wo3_03_light_0p005.gpx"
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0)]


def run(phase_index, axis, start):
    tag = "".join(map(str, axis))
    work = ROOT / f"strain_p{phase_index}_{tag}_work.gpx"
    gpx = G2.G2Project(str(BASE), newgpx=str(work))
    phase = gpx.phases()[phase_index]
    h = gpx.histogram(0)
    m = phase.data["Histograms"][h.name]["Mustrain"]
    m[0] = "uniaxial"
    m[1][0] = start
    m[1][1] = start
    m[2] = [True, True, False]
    m[3] = list(axis)
    for suffix in ("i", "a"):
        gpx.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;{suffix}")
        gpx.set_Controls("parmMax", 32000.0, variable=f"{phase_index}:0:Mustrain;{suffix}")
    gpx.set_Controls("cycles", 8)
    gpx.refine()
    gpx.save()
    out = ROOT / f"strain_p{phase_index}_{tag}.gpx"
    shutil.copy2(gpx.filename, out)
    print(phase.name, axis, "Rwp", h.get_wR(), "strain", m[:4], "frozen", gpx.get_Frozen())


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    for axis in AXES:
        run(1, axis, 5700.0)
    for axis in AXES:
        run(0, axis, 500.0)
