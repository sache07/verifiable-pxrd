from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "inputs" / "pattern.csv"
XYE = ROOT / "pattern.xye"
INST = ROOT / "instrument.instprm"
CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)


x, y = np.loadtxt(DATA, delimiter=",", skiprows=1, unpack=True)
sigma = np.sqrt(np.maximum(y, 1.0))
np.savetxt(XYE, np.column_stack([x, y, sigma]), fmt="%.8f %.8f %.8f")

project = G2sc.G2Project(newgpx=str(ROOT / "initial.gpx"))
hist = project.add_powder_histogram(str(XYE), str(INST))
phase = project.add_phase(str(CIF), phasename="MnWO4", histograms=[hist])
hist.Limits("lower", float(x[0]))
hist.Limits("upper", float(x[-1]))

print("histogram", hist.name)
print("limits", hist.data["Limits"])
print("background", hist.data["Background"])
print("instrument", hist.data["Instrument Parameters"])
print("sample", hist.data["Sample Parameters"])
print("phase cell", phase.get_cell())
print("phase HAP", phase.data["Histograms"][hist.name])
project.save()
