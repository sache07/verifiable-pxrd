from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cid):
    return COD / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


for cid, label in (
    ("2311041", "WO3_monoclinic_2311041"),
    ("1563541", "WO3_monoclinic_1563541"),
    ("2106293", "WO3_triclinic_2106293"),
    ("2107312", "WO3_orthorhombic_2107312"),
):
    project = G2sc.G2Project(
        str(ROOT / "physical_p1p0_u0p014.gpx"),
        newgpx=str(ROOT / f"physical_wo3_{cid}.gpx"),
    )
    project.data["Controls"]["data"]["max cyc"] = 15
    hist = project.histogram(0)
    phase = project.add_phase(str(cod_path(cid)), phasename=label, histograms=[hist])
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.015
        atom.data[atom.cia + 2 : atom.cia + 8] = [0.0] * 6
        atom.refinement_flags = ""
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][0] = 0.4
    phase.set_HAP_refinements({"Scale": True}, [hist])
    project.refine()
    phase.set_refinements({"Cell": True})
    project.refine()
    project.save()
    print(
        "PHYSICAL_WO3",
        cid,
        hist.get_wR(),
        hist.ComputeMassFracs(),
        phase.get_cell(),
    )
