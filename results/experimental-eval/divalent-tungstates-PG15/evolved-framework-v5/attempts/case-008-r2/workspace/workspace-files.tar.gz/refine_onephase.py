from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
project = G2sc.G2Project(str(ROOT / "initial.gpx"), newgpx=str(ROOT / "onephase.gpx"))
hist = project.histogram(0)
phase = project.phase(0)

controls = project.data["Controls"]["data"]
controls["max cyc"] = 12
controls["min dM/M"] = 1e-5
hist.data["Sample Parameters"]["Scale"][1] = False


def report(label):
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    print("\nSTAGE", label)
    print("Rwp", hist.get_wR())
    print("cell", phase.get_cell())
    print(
        "inst",
        {k: inst[k][1] for k in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]},
    )
    print(
        "sample",
        {k: sample[k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
    )
    print("scale", phase.data["Histograms"][hist.name]["Scale"])
    print("background", hist.data["Background"][0])
    project.save()


hist.set_refinements(
    {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12}}
)
phase.set_HAP_refinements({"Scale": True}, [hist])
project.refine()
report("background_scale")

phase.set_refinements({"Cell": True})
hist.set_refinements({"Sample Parameters": ["Shift"]})
project.refine()
report("cell_shift")

hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]})
project.refine()
report("instrument_profile")
