from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
project = G2sc.G2Project(
    str(ROOT / "direct_texture_110.gpx"), newgpx=str(ROOT / "polarization.gpx")
)
project.data["Controls"]["data"]["max cyc"] = 15
hist = project.histogram(0)
hist.set_refinements({"Instrument Parameters": ["Polariz."]})
project.refine()
project.save()
print("Rwp", hist.get_wR())
print("polarization", hist.data["Instrument Parameters"][0]["Polariz."])
print("residuals", hist.data["data"][0])
