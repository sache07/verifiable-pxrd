from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def describe(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    print("\n", label, "Rwp", hist.get_wR())
    print("cell", phase.get_cell())
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.refinement_flags)
    project.save()


heavy = G2sc.G2Project(str(ROOT / "onephase.gpx"), newgpx=str(ROOT / "heavy_coords.gpx"))
heavy.data["Controls"]["data"]["max cyc"] = 12
heavy.phase(0).set_refinements({"Atoms": {"Mn1": "X", "W1": "X"}})
heavy.refine()
describe(heavy, "heavy")

light = G2sc.G2Project(str(ROOT / "heavy_coords.gpx"), newgpx=str(ROOT / "coords.gpx"))
light.data["Controls"]["data"]["max cyc"] = 12
light.phase(0).set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
light.refine()
describe(light, "light")
