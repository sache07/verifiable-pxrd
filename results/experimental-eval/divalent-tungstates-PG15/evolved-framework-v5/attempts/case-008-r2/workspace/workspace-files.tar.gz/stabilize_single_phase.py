from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
project = G2sc.G2Project(
    str(ROOT / "background_20.gpx"), newgpx=str(ROOT / "best_single.gpx")
)
project.data["Controls"]["data"]["max cyc"] = 18
hist = project.histogram(0)
inst = hist.data["Instrument Parameters"][0]
inst["Zero"][1] = 0.0
inst["Zero"][2] = False
project.refine()
project.save()
print("Rwp", hist.get_wR())
print("residuals", hist.data["data"][0])
print("cell", project.phase(0).get_cell())
print("instrument", {k: inst[k] for k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]})
print("sample", {k: hist.data["Sample Parameters"][k] for k in ["Shift", "SurfRoughA", "SurfRoughB"]})
print("HAP", project.phase(0).data["Histograms"][hist.name])
print("atoms", [(a.label, a.coordinates, a.adp_flag, a.ADP) for a in project.phase(0).atoms()])
