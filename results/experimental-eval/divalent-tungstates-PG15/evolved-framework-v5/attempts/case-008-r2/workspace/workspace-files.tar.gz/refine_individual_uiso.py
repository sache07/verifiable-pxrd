from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
starts = {
    "source": {"Mn1": 0.0078, "W1": 0.0070, "O1": 0.0066, "O2": 0.0090},
    "common015": {"Mn1": 0.015, "W1": 0.015, "O1": 0.015, "O2": 0.015},
}
for tag, values in starts.items():
    project = G2sc.G2Project(
        str(ROOT / "polarization.gpx"),
        newgpx=str(ROOT / f"individual_uiso_{tag}.gpx"),
    )
    project.data["Controls"]["data"]["max cyc"] = 18
    phase = project.phase(0)
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = values[atom.label]
        atom.data[atom.cia + 2 : atom.cia + 8] = [0.0] * 6
        atom.refinement_flags = "XU"
    project.refine()
    project.save()
    print("INDIVIDUAL_UISO", tag, project.histogram(0).get_wR())
    print("ATOMS", [(a.label, a.ADP, a.coordinates) for a in phase.atoms()])
