from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def show(project, label):
    hist = project.histogram(0)
    print("\nTWO_PHASE", label, "Rwp", hist.get_wR())
    print("fractions", hist.ComputeMassFracs())
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "cell", phase.get_cell(), "scale", hap["Scale"])
        print(phase.name, "size", hap["Size"], "mustrain", hap["Mustrain"])
    project.save()


cell = G2sc.G2Project(
    str(ROOT / "candidate_1528915.gpx"), newgpx=str(ROOT / "two_phase_cell.gpx")
)
cell.data["Controls"]["data"]["max cyc"] = 18
cell.phase("WO3_monoclinic_1528915").set_refinements({"Cell": True})
cell.refine()
show(cell, "cell")

size = G2sc.G2Project(
    str(ROOT / "two_phase_cell.gpx"), newgpx=str(ROOT / "two_phase_size.gpx")
)
size.data["Controls"]["data"]["max cyc"] = 18
hist = size.histogram(0)
wo3 = size.phase("WO3_monoclinic_1528915")
wo3.set_HAP_refinements(
    {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}, [hist]
)
size.refine()
show(size, "cell_size")
