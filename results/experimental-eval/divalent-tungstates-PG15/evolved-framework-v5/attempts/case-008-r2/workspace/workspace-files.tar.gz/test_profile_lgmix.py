from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
for mode in ("mustrain", "size", "both"):
    project = G2sc.G2Project(
        str(ROOT / "physical_p1p0_u0p014.gpx"),
        newgpx=str(ROOT / f"lgmix_{mode}.gpx"),
    )
    project.data["Controls"]["data"]["max cyc"] = 18
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["Y"][1] = 0.0
    inst["Y"][2] = False
    refs = {}
    if mode in ("mustrain", "both"):
        refs["Mustrain"] = {
            "type": "isotropic",
            "LGmix": {"value": 0.5, "refine": True},
        }
    if mode in ("size", "both"):
        refs["Size"] = {
            "type": "isotropic",
            "LGmix": {"value": 0.5, "refine": True},
        }
    phase.set_HAP_refinements(refs, [hist])
    project.refine()
    project.save()
    hap = phase.data["Histograms"][hist.name]
    print(
        "LGMIX",
        mode,
        hist.get_wR(),
        "Y",
        inst["Y"],
        "Mustrain",
        hap["Mustrain"],
        "Size",
        hap["Size"],
    )
