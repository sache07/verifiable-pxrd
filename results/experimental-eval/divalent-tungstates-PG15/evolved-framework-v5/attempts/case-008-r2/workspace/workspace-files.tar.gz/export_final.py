import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "physical_wo3_2311041.gpx"
FINAL = ROOT / "final.gpx"

project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
project.data["Controls"]["data"]["max cyc"] = 18
project.refine(makeBack=False)
project.save()

hist = project.histogram(0)
phase_specs = {
    "MnWO4": {
        "display_name": "MnWO4 (wolframite)",
        "formula": "MnWO4",
        "cif": "phase_1_MnWO4.cif",
        "source_reference": "COD 1520200",
    },
    "WO3_monoclinic_2311041": {
        "display_name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif": "phase_2_WO3.cif",
        "source_reference": "COD 2311041",
    },
}

fractions = hist.ComputeMassFracs()
phase_rows = []
for phase in project.phases():
    spec = phase_specs[phase.name]
    phase.export_CIF(str(ROOT / spec["cif"]))
    frac, frac_esd = fractions[phase.name]
    phase_rows.append(
        {
            "name": spec["display_name"],
            "formula": spec["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": spec["cif"],
            "weight_fraction": frac,
            "weight_fraction_esd": frac_esd,
            "source_reference": spec["source_reference"],
            "cell": phase.get_cell(),
        }
    )

x = np.asarray(hist.getdata("X"), dtype=float)
y_obs = np.asarray(hist.getdata("Yobs"), dtype=float)
y_calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
difference = np.asarray(hist.getdata("Residual"), dtype=float)
background = np.asarray(hist.getdata("Background"), dtype=float)
np.savetxt(
    ROOT / "fit.csv",
    np.column_stack([x, y_obs, y_calc, difference, background]),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference_observed_minus_calculated,background",
    comments="",
    fmt="%.10g",
)

hres = hist.data["data"][0]
rvals = project.data["Covariance"]["data"]["Rvals"]
per_phase = {}
for phase in project.phases():
    pid = phase.id
    per_phase[phase_specs[phase.name]["formula"]] = {
        "R_F_percent": hres.get(f"{pid}:0:Rf"),
        "R_F_squared_percent": hres.get(f"{pid}:0:Rf^2"),
        "number_of_reflections": hres.get(f"{pid}:0:Nref"),
    }

result = {
    "phases": phase_rows,
    "fit_statistics": {
        "Rwp_percent": hres["wR"],
        "Rp_percent": hres["R"],
        "Rexp_percent": hres["wRmin"],
        "goodness_of_fit": rvals["GOF"],
        "chi_squared": rvals["chisq"],
        "durbin_watson": hres["Durbin-Watson"],
        "number_of_observations": rvals["Nobs"],
        "number_of_variables": rvals["Nvars"],
        "converged": bool(rvals["converged"]),
        "per_phase": per_phase,
    },
    "refinement_histogram": hist.name,
    "weight_fraction_basis": "normalized over modeled crystalline phases",
    "profile_path": "fit.csv",
    "gsas_project_path": "final.gpx",
}

with open(ROOT / "result.json", "w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps(result, indent=2))
