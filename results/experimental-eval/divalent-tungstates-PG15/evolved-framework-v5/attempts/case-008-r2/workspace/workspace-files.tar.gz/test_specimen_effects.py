from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def refine_roughness():
    project = G2sc.G2Project(
        str(ROOT / "coords.gpx"), newgpx=str(ROOT / "roughness.gpx")
    )
    project.data["Controls"]["data"]["max cyc"] = 12
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"][0] = 0.1
    sample["SurfRoughB"][0] = 0.1
    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    project.refine()
    project.save()
    print(
        "ROUGHNESS",
        hist.get_wR(),
        sample["SurfRoughA"],
        sample["SurfRoughB"],
    )


def refine_texture(axis):
    tag = "".join(str(v).replace("-", "m") for v in axis)
    project = G2sc.G2Project(
        str(ROOT / "roughness.gpx"), newgpx=str(ROOT / f"texture_{tag}.gpx")
    )
    project.data["Controls"]["data"]["max cyc"] = 12
    hist = project.histogram(0)
    phase = project.phase(0)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)
    project.refine()
    project.save()
    print("TEXTURE", axis, hist.get_wR(), po)


refine_roughness()
for candidate_axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]):
    refine_texture(candidate_axis)
