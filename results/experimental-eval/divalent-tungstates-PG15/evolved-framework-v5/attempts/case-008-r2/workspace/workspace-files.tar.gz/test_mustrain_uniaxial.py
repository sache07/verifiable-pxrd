from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]):
    tag = "".join(str(v).replace("-", "m") for v in axis)
    project = G2sc.G2Project(
        str(ROOT / "direct_texture_110.gpx"),
        newgpx=str(ROOT / f"mustrain_uniaxial_{tag}.gpx"),
    )
    project.data["Controls"]["data"]["max cyc"] = 15
    hist = project.histogram(0)
    phase = project.phase(0)
    mustrain = phase.data["Histograms"][hist.name]["Mustrain"]
    mustrain[0] = "uniaxial"
    mustrain[1][0] = 1000.0
    mustrain[1][1] = 1000.0
    mustrain[3] = list(axis)
    phase.set_HAP_refinements(
        {
            "Mustrain": {
                "type": "uniaxial",
                "direction": list(axis),
                "refine": True,
            }
        },
        [hist],
    )
    project.refine()
    project.save()
    print("MUSTRAIN_UNIAXIAL", axis, hist.get_wR(), mustrain)
