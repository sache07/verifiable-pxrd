from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent

zero = G2sc.G2Project(
    str(ROOT / "uiso_0p022.gpx"), newgpx=str(ROOT / "zero_refined.gpx")
)
zero.data["Controls"]["data"]["max cyc"] = 18
hist = zero.histogram(0)
hist.set_refinements({"Instrument Parameters": ["Zero"]})
zero.refine()
zero.save()
print(
    "ZERO",
    hist.get_wR(),
    hist.data["Instrument Parameters"][0]["Zero"],
    hist.data["Sample Parameters"]["Shift"],
    zero.phase(0).get_cell(),
)

for ncoeff in (16, 20):
    project = G2sc.G2Project(
        str(ROOT / "zero_refined.gpx"),
        newgpx=str(ROOT / f"background_{ncoeff}.gpx"),
    )
    project.data["Controls"]["data"]["max cyc"] = 18
    hist = project.histogram(0)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": ncoeff,
            }
        }
    )
    project.refine()
    project.save()
    print("BACKGROUND", ncoeff, hist.get_wR(), hist.data["Background"][0])
