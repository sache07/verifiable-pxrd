from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
for uiso in (0.021, 0.022, 0.023):
    tag = str(uiso).replace(".", "p")
    project = G2sc.G2Project(
        str(ROOT / "polarization.gpx"), newgpx=str(ROOT / f"uiso_{tag}.gpx")
    )
    project.data["Controls"]["data"]["max cyc"] = 15
    phase = project.phase(0)
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = uiso
        atom.data[atom.cia + 2 : atom.cia + 8] = [0.0] * 6
        atom.refinement_flags = atom.refinement_flags.replace("U", "")
    project.refine()
    project.save()
    print("COMMON_UISO", uiso, project.histogram(0).get_wR())
    print("ATOMS", [(a.label, a.adp_flag, a.ADP, a.coordinates) for a in phase.atoms()])
