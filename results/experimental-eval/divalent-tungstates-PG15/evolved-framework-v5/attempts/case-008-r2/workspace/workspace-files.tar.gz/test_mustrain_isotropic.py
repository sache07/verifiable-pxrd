from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
for start in (100.0, 500.0, 1000.0):
    project = G2sc.G2Project(
        str(ROOT / "direct_texture_110.gpx"),
        newgpx=str(ROOT / f"mustrain_iso_{int(start)}.gpx"),
    )
    project.data["Controls"]["data"]["max cyc"] = 15
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["Y"][1] = 0.0
    inst["Y"][2] = False
    mustrain = phase.data["Histograms"][hist.name]["Mustrain"]
    mustrain[0] = "isotropic"
    mustrain[1][0] = start
    phase.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
    )
    project.refine()
    project.save()
    print(
        "MUSTRAIN_ISO",
        start,
        hist.get_wR(),
        mustrain,
        {k: inst[k] for k in ["U", "V", "W", "X", "Y", "SH/L"]},
    )
