from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]):
    tag = "".join(str(v).replace("-", "m") for v in axis)
    project = G2sc.G2Project(
        str(ROOT / "coords.gpx"), newgpx=str(ROOT / f"direct_texture_{tag}.gpx")
    )
    project.data["Controls"]["data"]["max cyc"] = 12
    hist = project.histogram(0)
    phase = project.phase(0)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)
    project.refine()
    project.save()
    print("DIRECT_TEXTURE", axis, hist.get_wR(), po)
