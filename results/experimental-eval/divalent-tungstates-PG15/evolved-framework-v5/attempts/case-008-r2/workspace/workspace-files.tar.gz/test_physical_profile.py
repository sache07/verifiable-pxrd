from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
source = ROOT / "direct_texture_110.gpx"


def summary(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    hap = phase.data["Histograms"][hist.name]
    print("\nPROFILE", label, "Rwp", hist.get_wR())
    print("INST", {k: inst[k] for k in ["U", "V", "W", "X", "Y", "SH/L"]})
    print("SIZE", hap["Size"])
    print("MUSTRAIN", hap["Mustrain"])
    project.save()


no_y = G2sc.G2Project(str(source), newgpx=str(ROOT / "profile_no_y.gpx"))
no_y.data["Controls"]["data"]["max cyc"] = 15
inst = no_y.histogram(0).data["Instrument Parameters"][0]
inst["Y"][1] = 0.0
inst["Y"][2] = False
no_y.refine()
summary(no_y, "Y_fixed_zero")

# The isotropic size term and instrumental X have the same angular dependence.
# Hold a small positive instrumental X while testing a physical crystallite size.
size = G2sc.G2Project(
    str(ROOT / "profile_no_y.gpx"), newgpx=str(ROOT / "profile_size.gpx")
)
size.data["Controls"]["data"]["max cyc"] = 15
inst = size.histogram(0).data["Instrument Parameters"][0]
inst["X"][1] = 1.0
inst["X"][2] = False
size.phase(0).set_HAP_refinements(
    {"Size": {"type": "isotropic", "value": 1.0, "refine": True}},
    [size.histogram(0)],
)
size.refine()
summary(size, "isotropic_size")
