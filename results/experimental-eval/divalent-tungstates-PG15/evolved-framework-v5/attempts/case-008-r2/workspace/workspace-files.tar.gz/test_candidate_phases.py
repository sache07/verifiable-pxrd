from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cid):
    return COD / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


candidates = {
    "Mn3WO6_2002703": "2002703",
    "MnO_1514231": "1514231",
    "Mn3O4_9001963": "9001963",
    "WO3_monoclinic_1528915": "1528915",
    "WO3_triclinic_2106293": "2106293",
}

for name, cid in candidates.items():
    project = G2sc.G2Project(
        str(ROOT / "physical_p1p0_u0p014.gpx"),
        newgpx=str(ROOT / f"candidate_{cid}.gpx"),
    )
    project.data["Controls"]["data"]["max cyc"] = 15
    hist = project.histogram(0)
    phase = project.add_phase(str(cod_path(cid)), phasename=name, histograms=[hist])
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][0] = 0.5
    phase.set_HAP_refinements({"Scale": True}, [hist])
    project.refine()
    project.save()
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:
        fractions = {"error": repr(exc)}
    print("CANDIDATE", name, "Rwp", hist.get_wR(), "scale", hap["Scale"], "fractions", fractions)
