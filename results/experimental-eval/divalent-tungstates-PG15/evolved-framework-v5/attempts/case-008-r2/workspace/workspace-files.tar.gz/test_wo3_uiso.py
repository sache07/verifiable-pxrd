from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
for uiso in (0.005, 0.010, 0.015, 0.020):
    tag = str(uiso).replace(".", "p")
    project = G2sc.G2Project(
        str(ROOT / "two_phase_cell.gpx"),
        newgpx=str(ROOT / f"two_phase_wo3_u{tag}.gpx"),
    )
    project.data["Controls"]["data"]["max cyc"] = 15
    hist = project.histogram(0)
    phase = project.phase("WO3_monoclinic_1528915")
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = uiso
        atom.data[atom.cia + 2 : atom.cia + 8] = [0.0] * 6
        atom.refinement_flags = ""
    project.refine()
    project.save()
    print("WO3_UISO", uiso, hist.get_wR(), hist.ComputeMassFracs())
