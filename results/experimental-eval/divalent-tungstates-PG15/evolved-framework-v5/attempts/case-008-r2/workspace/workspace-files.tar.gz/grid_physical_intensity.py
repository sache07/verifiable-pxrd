from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
for polarization in (0.7, 0.8, 0.9, 1.0):
    for uiso in (0.008, 0.014, 0.020):
        ptag = str(polarization).replace(".", "p")
        utag = str(uiso).replace(".", "p")
        project = G2sc.G2Project(
            str(ROOT / "best_single.gpx"),
            newgpx=str(ROOT / f"physical_p{ptag}_u{utag}.gpx"),
        )
        project.data["Controls"]["data"]["max cyc"] = 15
        hist = project.histogram(0)
        phase = project.phase(0)
        inst = hist.data["Instrument Parameters"][0]
        inst["Polariz."][1] = polarization
        inst["Polariz."][2] = False
        inst["Zero"][1] = 0.0
        inst["Zero"][2] = False
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = uiso
            atom.data[atom.cia + 2 : atom.cia + 8] = [0.0] * 6
            atom.refinement_flags = atom.refinement_flags.replace("U", "")
        project.refine()
        project.save()
        print("PHYSICAL_GRID", polarization, uiso, hist.get_wR())
