#!/usr/bin/env python3
"""Run guarded GSAS-II refinement branches from a complete checkpoint."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def bounds(project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable)
    project.set_Controls("parmMax", high, variable)


def summarize(project, label: str) -> dict:
    h = project.histogram(0)
    p = project.phase(0)
    hap = p.data["Histograms"][h.name]
    return {
        "label": label,
        "residuals": {k: float(v) for k, v in h.residuals.items()
                      if isinstance(v, (int, float, np.number))},
        "cell": p.get_cell(),
        "instrument": {k: float(v[1]) for k, v in h.InstrumentParameters.items()
                       if isinstance(v, list) and len(v) > 1
                       and isinstance(v[1], (int, float, np.number))},
        "sample": {k: v for k, v in h.SampleParameters.items()
                   if k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]},
        "profile": {k: hap[k] for k in ["Scale", "Size", "Mustrain", "Pref.Ori."]},
        "atoms": [
            {"label": a.label, "element": a.element,
             "xyz": [float(v) for v in a.coordinates],
             "uiso": float(a.uiso), "flags": a.refinement_flags}
            for a in p.atoms()
        ],
        "vary": list(project.get_VaryList() or []),
    }


def refine(project, label: str, records: list[dict]) -> None:
    project.refine(makeBack=False)
    rec = summarize(project, label)
    records.append(rec)
    print(label, "wR", rec["residuals"].get("wR"),
          "Rf2", rec["residuals"].get("0:0:Rf^2"))


def setup_common(project) -> None:
    project.set_Controls("cycles", 10)
    # Keep every fitted broadening and geometry term in the physical ranges
    # of this laboratory, while allowing a small numerical margin.
    for var, lo, hi in [
        (":0:U", 0.0, 60.0), (":0:W", 0.2, 60.0),
        (":0:X", 0.02, 10.0), (":0:SH/L", 0.002, 0.15),
        (":0:Zero", -0.35, 0.35), (":0:Shift", -850.0, 850.0),
        ("0:0:Size;i", 0.04, 2.0), ("0:0:Mustrain;i", 0.0, 9000.0),
        (":0:Polariz.", 0.45, 1.0),
    ]:
        bounds(project, var, lo, hi)


def mode_coords(project, records: list[dict]) -> None:
    p = project.phase(0)
    h = project.histogram(0)
    # For a single phase, isotropic size is exactly degenerate with the
    # Lorentzian instrument term and isotropic strain with the Gaussian U
    # term. Retain the reasonable fixed specimen start already in this
    # checkpoint and let the calibrated total profile carry those widths.
    p.clear_HAP_refinements({"Size": True, "Mustrain": True})
    for atom in p.atoms():
        atom.refinement_flags = "X" if atom.element in {"W", "Cu"} else " "
    refine(project, "heavy_coordinates", records)
    for atom in p.atoms():
        atom.refinement_flags = "X"
    refine(project, "all_coordinates", records)


def mode_texture(project, records: list[dict], axis: list[int]) -> None:
    p = project.phase(0)
    h = project.histogram(0)
    hap = p.data["Histograms"][h.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis
    bounds(project, "0:0:MD", 0.65, 1.5)
    refine(project, "texture_" + "".join(map(str, axis)), records)


def mode_polarization(project, records: list[dict]) -> None:
    project.histogram(0).set_refinements(
        {"Instrument Parameters": ["Polariz."]}
    )
    refine(project, "polarization", records)


def mode_roughness(project, records: list[dict]) -> None:
    h = project.histogram(0)
    h.SampleParameters["SurfRoughA"] = [0.15, False]
    h.SampleParameters["SurfRoughB"] = [0.08, False]
    h.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    bounds(project, ":0:SurfRoughA", 0.001, 0.8)
    bounds(project, ":0:SurfRoughB", 0.001, 0.7)
    refine(project, "surface_roughness", records)


def mode_uiso(project, records: list[dict]) -> None:
    p = project.phase(0)
    for atom in p.atoms():
        atom.refinement_flags = "XU" if "X" in atom.refinement_flags else "U"
    # One phase-level isotropic displacement is identifiable; independent
    # atom values are not warranted by this powder pattern.
    vars_ = tuple(f"0::AUiso:{i}" for i, _ in enumerate(p.atoms()))
    project.add_EquivConstr(vars_)
    bounds(project, "0::AUiso:0", 0.003, 0.02)
    bounds(project, ":0:Polariz.", 0.5, 1.0)
    refine(project, "common_uiso", records)


def mode_coord_start(project, records: list[dict], seed: int) -> None:
    p = project.phase(0)
    rng = np.random.default_rng(seed)
    for atom in p.atoms():
        sigma = 0.0025 if atom.element in {"W", "Cu"} else 0.006
        delta = np.clip(rng.normal(0.0, sigma, 3), -2 * sigma, 2 * sigma)
        atom.coordinates = (np.asarray(atom.coordinates) + delta) % 1.0
        atom.refinement_flags = "X"
    refine(project, f"coordinate_start_{seed}", records)


def mode_uniaxial_strain(project, records: list[dict], axis: list[int]) -> None:
    p = project.phase(0)
    h = project.histogram(0)
    hap = p.data["Histograms"][h.name]
    hap["Mustrain"][0] = "uniaxial"
    start = max(50.0, float(hap["Mustrain"][1][0]))
    hap["Mustrain"][1][0] = start
    hap["Mustrain"][1][1] = start
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = axis
    bounds(project, "0:0:Mustrain;i", 0.0, 9000.0)
    bounds(project, "0:0:Mustrain;a", 50.0, 12000.0)
    refine(project, "uniaxial_strain_" + "".join(map(str, axis)), records)


def mode_background(project, records: list[dict], ncoeff: int) -> None:
    project.histogram(0).set_refinements({
        "Background": {"type": "chebyschev-1", "no. coeffs": ncoeff,
                       "refine": True}
    })
    refine(project, f"background_{ncoeff}", records)


def mode_isotropic_strain(project, records: list[dict]) -> None:
    p = project.phase(0)
    h = project.histogram(0)
    hap = p.data["Histograms"][h.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = max(50.0, float(hap["Mustrain"][1][0]))
    hap["Mustrain"][2] = [True, False, False]
    bounds(project, "0:0:Mustrain;i", 0.0, 9000.0)
    refine(project, "isotropic_strain", records)


def mode_fixed_uiso(project, records: list[dict], value: float) -> None:
    p = project.phase(0)
    for atom in p.atoms():
        atom.uiso = value
        atom.refinement_flags = atom.refinement_flags.replace("U", "")
    bounds(project, ":0:Polariz.", 0.5, 1.0)
    refine(project, f"fixed_uiso_{value:.4f}", records)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mode", required=True,
                        choices=["coords", "texture", "polarization", "roughness", "uiso", "fixed-uiso", "coord-start", "uniaxial-strain", "isotropic-strain", "background"])
    parser.add_argument("--axis", default="001")
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--ncoeff", type=int, default=15)
    parser.add_argument("--uiso", type=float, default=0.01)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.input, args.output)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.output))
    setup_common(project)
    records: list[dict] = [summarize(project, "start")]

    if args.mode == "coords":
        mode_coords(project, records)
    elif args.mode == "texture":
        mode_texture(project, records, [int(v) for v in args.axis])
    elif args.mode == "polarization":
        mode_polarization(project, records)
    elif args.mode == "roughness":
        mode_roughness(project, records)
    elif args.mode == "uiso":
        mode_uiso(project, records)
    elif args.mode == "coord-start":
        mode_coord_start(project, records, args.seed)
    elif args.mode == "uniaxial-strain":
        mode_uniaxial_strain(project, records, [int(v) for v in args.axis])
    elif args.mode == "background":
        mode_background(project, records, args.ncoeff)
    elif args.mode == "isotropic-strain":
        mode_isotropic_strain(project, records)
    elif args.mode == "fixed-uiso":
        mode_fixed_uiso(project, records, args.uiso)

    project.save(str(args.output))
    args.output.with_suffix(".json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
