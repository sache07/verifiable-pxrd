#!/usr/bin/env python3
"""Create the replay-consistent final project, CIF, profile and reports."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "diagnostics" / "branches" / "selected_converged.gpx"
FINAL = ROOT / "final.gpx"
CIF = ROOT / "phase_1_CuWO4.cif"
FIT = ROOT / "fit.csv"
RESULT = ROOT / "result.json"
REPORT = ROOT / "report.md"


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return plain(value.tolist())
    if isinstance(value, np.generic):
        return value.item()
    return value


def main() -> None:
    shutil.copy2(SOURCE, FINAL)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(FINAL))
    hist = project.histogram(0)
    phase = project.phase(0)

    # Zero/sample displacement and the intensity-vs-angle nuisance terms are
    # strongly correlated with the metric/scale in a one-phase pattern. Their
    # fitted physical values are retained, but frozen for the final stable
    # coordinate/cell/profile refinement.
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "Polariz."],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    })
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    project.save(str(FINAL))

    hist = project.histogram(0)
    phase = project.phase(0)
    phase.export_CIF(str(CIF))

    public_x, public_y = np.loadtxt(
        ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1
    ).T
    x = np.asarray(hist.getdata("X"), float)
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    background = np.asarray(hist.getdata("Background"), float)
    if not (len(x) == len(public_x)
            and np.allclose(x, public_x, rtol=0, atol=1e-7)
            and np.allclose(obs, public_y, rtol=0, atol=1e-5)):
        raise RuntimeError("Final GPX does not contain the original observed grid")
    if not np.all(np.isfinite(calc)) or np.any(calc < 0):
        raise RuntimeError("Final calculated profile is nonfinite or negative")
    difference = public_y - calc
    np.savetxt(
        FIT,
        np.column_stack([public_x, public_y, calc, difference, background]),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt="%.17g",
    )

    weights = 1.0 / np.maximum(public_y, 1.0)
    weighted_chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * public_y**2))
    rwp = float(100.0 * np.sqrt(weighted_chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(public_y))
    vary = list(project.get_VaryList() or [])
    dof = max(1, len(public_y) - len(vary))
    reduced_chi_square = weighted_chi_square / dof
    residuals = {k: float(v) for k, v in hist.residuals.items()
                 if isinstance(v, (int, float, np.number))}

    hap = phase.data["Histograms"][hist.name]
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    cell = phase.get_cell()
    phase_mass = float(phase.data["General"]["Mass"])
    phase_scale = float(hap["Scale"][0])
    masses = [phase_mass * phase_scale]
    fraction = masses[0] / sum(masses)

    output = {
        "phases": [
            {
                "name": "triclinic CuWO4",
                "formula": "CuWO4",
                "space_group": "P -1",
                "cif_path": CIF.name,
                "weight_fraction": fraction,
            }
        ],
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "weighted_chi_square": weighted_chi_square,
            "reduced_chi_square": reduced_chi_square,
            "gsas_wRmin_percent": residuals.get("wRmin"),
            "bragg_Rf_percent": residuals.get("0:0:Rf"),
            "bragg_Rf2_percent": residuals.get("0:0:Rf^2"),
            "n_points": len(public_y),
            "n_refined_parameters_final_cycle": len(vary),
        },
        "refinement_histogram": hist.name,
        "calibration": {
            "zero_deg": float(inst["Zero"][1]),
            "sample_displacement_um": float(sample["Shift"][0]),
        },
        "model_details": {
            "cell": cell,
            "polarization": float(inst["Polariz."][1]),
            "surface_roughness_A": float(sample["SurfRoughA"][0]),
            "surface_roughness_B": float(sample["SurfRoughB"][0]),
            "crystallite_size_um_fixed": float(hap["Size"][1][0]),
            "microstrain_model": hap["Mustrain"][0],
            "microstrain_ppm_equatorial": float(hap["Mustrain"][1][0]),
            "microstrain_ppm_axial": float(hap["Mustrain"][1][1]),
            "microstrain_axis": list(hap["Mustrain"][3]),
        },
        "weight_fraction_basis": "normalized over modeled crystalline phases",
    }
    RESULT.write_text(json.dumps(plain(output), indent=2, allow_nan=False) + "\n")

    report = f"""# Powder XRD phase analysis

The crystalline pattern is modeled as single-phase triclinic CuWO₄ (space group P -1), with a normalized crystalline weight fraction of 1.0000. CuWO₄ is the chemically ordinary 1:1 product of CuO + WO₃ at 800 °C. Its diagnostic low-angle reflections and the dense high-angle multiplet sequence are all reproduced by one lattice; no coherent residual family remains that supports CuO, WO₃, or another crystalline phase.

The frozen COD exact-composition entries are high-pressure CuWO₄ determinations. COD 4000806 supplied the physically correct P -1 CuWO₄ topology and a close coordinate start; its compressed metric was adapted to the ambient CuWO₄ peak family, then the full cell and heavy- followed by light-atom coordinates were refined. The final cell is a = {cell['length_a']:.6f} Å, b = {cell['length_b']:.6f} Å, c = {cell['length_c']:.6f} Å, α = {cell['angle_alpha']:.5f}°, β = {cell['angle_beta']:.5f}°, γ = {cell['angle_gamma']:.5f}°. The refined structure has ordinary distorted CuO₆ and WO₆ coordination (shortest Cu–O about 1.94 Å, shortest W–O about 1.78 Å; no unphysical contacts).

The full-grid fit has Rwp = {rwp:.3f}%, Rp = {rp:.3f}%, and reduced χ² = {reduced_chi_square:.3f} using counting-statistical weights. A bounded Bragg–Brentano displacement/surface model and [001] uniaxial microstrain improve reflection shapes. Tests of all supported March–Dollase axes refined to within 1.4% of random orientation and were not retained. Multiple bounded coordinate starts returned the same structural minimum.

The 100 wt% value is normalized over modeled crystalline phases. It does not exclude amorphous material or trace crystalline impurities below the residual/noise detection level. Because this is a one-phase pattern, isotropic crystallite-size broadening is exactly correlated with the instrument Lorentzian term; the size was fixed at 1.0 µm, so that value is not independently determined. Zero/displacement and polarization/ADP/surface terms are also correlated, but this does not materially affect the phase identity or the single-phase normalized fraction. Oxygen coordinates are less precise than the W/Cu substructure and should not be interpreted as a single-crystal-quality determination.
"""
    REPORT.write_text(report)

    print(json.dumps({
        "rwp_percent": rwp,
        "rp_percent": rp,
        "reduced_chi_square": reduced_chi_square,
        "cell": cell,
        "project": str(FINAL),
    }, indent=2))


if __name__ == "__main__":
    main()
