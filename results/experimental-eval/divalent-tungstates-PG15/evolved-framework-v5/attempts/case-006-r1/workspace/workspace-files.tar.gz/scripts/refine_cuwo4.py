#!/usr/bin/env python3
"""Build and iteratively refine a physical CuWO4 GSAS-II model.

This script is intentionally specimen-specific. It keeps a checkpoint after
each refinement stage so that failed profile/coordinate branches do not
overwrite the last complete model.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
PATTERN = ROOT / "inputs" / "pattern.csv"
SOURCE_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/4/00/08/4000806.cif"
)
WORK = ROOT / "diagnostics" / "gsas"
XYE = WORK / "pattern.xye"
INST = WORK / "instrument.instprm"
LOG = WORK / "refinement_log.json"


def prepare_inputs() -> tuple[np.ndarray, np.ndarray]:
    WORK.mkdir(parents=True, exist_ok=True)
    x, y = np.loadtxt(PATTERN, delimiter=",", skiprows=1).T
    # Original uncertainties are absent; counting-statistical weights are the
    # most defensible choice and match the verification metric.
    np.savetxt(XYE, np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]),
               fmt=["%.8f", "%.8f", "%.8f"])
    INST.write_text(
        "#GSAS-II instrument parameter file; Cu K-alpha Bragg-Brentano start\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.25;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return x, y


def set_cell(phase, values: tuple[float, float, float, float, float, float]) -> None:
    a, b, c, alpha, beta, gamma = values
    avec = G2lat.cell2A([a, b, c, alpha, beta, gamma])
    volume = G2lat.calc_V(avec)
    phase.data["General"]["Cell"][1:] = [a, b, c, alpha, beta, gamma, volume]


def initialize(path: Path) -> None:
    x, y = prepare_inputs()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(path))
    phase = project.add_phase(str(SOURCE_CIF), phasename="CuWO4", fmthint="CIF")

    # Ambient triclinic CuWO4 metric. The frozen exact-composition COD source
    # is a compressed high-pressure determination, but supplies the correct
    # centrosymmetric CuWO4 topology and a close coordinate start.
    set_cell(phase, (4.7026, 5.8399, 4.8785, 91.677, 92.469, 82.805))
    for atom in phase.atoms():
        atom.uiso = 0.010
        atom.refinement_flags = " "

    hist = project.add_powder_histogram(
        str(XYE), str(INST), phases=[phase], fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]

    # Robust lower-envelope estimate only initializes the empirical
    # background. Coefficients are subsequently refined against all points.
    envelope = percentile_filter(y, percentile=12, size=401, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    coeffs = np.polynomial.chebyshev.chebfit(t, envelope, deg=9).tolist()
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1", "no. coeffs": len(coeffs),
            "coeffs": coeffs, "refine": False,
        }
    })

    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][1][1] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]

    project.set_Controls("cycles", 8)
    project.save()


def snapshot(project, label: str, log: list[dict]) -> None:
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    hap = phase.data["Histograms"][hist.name]
    record = {
        "stage": label,
        "residuals": {k: float(v) for k, v in hist.residuals.items()
                      if isinstance(v, (int, float, np.number))},
        "cell": phase.get_cell(),
        "instrument": {k: float(v[1]) for k, v in inst.items()
                       if isinstance(v, list) and len(v) > 1
                       and isinstance(v[1], (int, float, np.number))},
        "sample": {
            k: (float(v[0]) if isinstance(v, list) and v
                and isinstance(v[0], (int, float, np.number)) else v)
            for k, v in sample.items()
            if k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
        },
        "hap": {
            "Scale": float(hap["Scale"][0]),
            "Size": hap["Size"],
            "Mustrain": hap["Mustrain"],
            "Pref.Ori.": hap["Pref.Ori."],
        },
        "atoms": [
            {"label": a.label, "element": a.element,
             "xyz": [float(v) for v in a.coordinates],
             "uiso": float(a.uiso), "flags": a.refinement_flags}
            for a in phase.atoms()
        ],
        "vary": list(project.get_VaryList() or []),
    }
    log.append(record)
    project.save(str(WORK / f"{label}.gpx"))
    LOG.write_text(json.dumps(log, indent=2) + "\n")
    print(label, json.dumps(record["residuals"], sort_keys=True))


def refine_once(project, label: str, log: list[dict]) -> None:
    project.refine(makeBack=False)
    snapshot(project, label, log)


def run_stages(path: Path, stop_after: str | None = None) -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(path))
    hist = project.histogram(0)
    phase = project.phase(0)
    log: list[dict] = []
    snapshot(project, "s00_initial", log)

    def done(label: str) -> bool:
        if stop_after == label:
            shutil.copy2(project.filename, path)
            return True
        return False

    hist.set_refinements({"Background": True})
    phase.set_HAP_refinements({"Scale": True})
    refine_once(project, "s01_scale_background", log)
    if done("s01_scale_background"): return

    # First align the metric and constant angular term. The specimen-height
    # term is added only after this stable position solution.
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_once(project, "s02_cell_zero", log)
    if done("s02_cell_zero"): return

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_once(project, "s03_cell_zero_shift", log)
    if done("s03_cell_zero_shift"): return

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine_once(project, "s04_instrument_profile", log)
    if done("s04_instrument_profile"): return

    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 1.0, "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    refine_once(project, "s05_phase_profile", log)
    if done("s05_phase_profile"): return

    # Heavy-atom coordinates first, followed by oxygen only after the strong
    # scattering substructure is stable.
    for atom in phase.atoms():
        if atom.element in {"W", "Cu"}:
            atom.refinement_flags = "X"
    refine_once(project, "s06_heavy_coordinates", log)
    if done("s06_heavy_coordinates"): return

    for atom in phase.atoms():
        atom.refinement_flags = "X"
    refine_once(project, "s07_all_coordinates", log)
    if done("s07_all_coordinates"): return

    shutil.copy2(project.filename, path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, default=WORK / "working.gpx")
    parser.add_argument("--initialize", action="store_true")
    parser.add_argument("--stop-after")
    args = parser.parse_args()
    if args.initialize or not args.project.exists():
        initialize(args.project)
    run_stages(args.project, args.stop_after)


if __name__ == "__main__":
    main()
