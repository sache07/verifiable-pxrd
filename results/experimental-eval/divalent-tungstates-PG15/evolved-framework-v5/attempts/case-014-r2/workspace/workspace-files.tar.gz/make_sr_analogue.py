#!/usr/bin/env python3
"""Replace all non-W/O cations in a reference structure by Sr."""

from pathlib import Path
import sys

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser, CifWriter


def main(source, output, scale="1.0"):
    structure = CifParser(source, occupancy_tolerance=5.0).parse_structures(
        primitive=False
    )[0]
    species = []
    for site in structure:
        replacement = {}
        for specie, occupancy in site.species.items():
            symbol = getattr(getattr(specie, "element", None), "symbol", None)
            if symbol is None:
                symbol = specie.symbol
            # Normalize oxidation-state labels to neutral element symbols.
            # Fractional labels such as W5.4+ are valid CIF chemistry but are
            # not recognized as X-ray scattering types by GSAS-II.
            key = symbol if symbol in {"W", "O"} else "Sr"
            replacement[key] = replacement.get(key, 0.0) + occupancy
        species.append(replacement)
    factor = float(scale)
    old = structure.lattice
    lattice = Lattice.from_parameters(
        old.a * factor, old.b * factor, old.c * factor,
        old.alpha, old.beta, old.gamma,
    )
    analogue = Structure(
        lattice, species, [site.frac_coords for site in structure],
        site_properties=structure.site_properties,
    )
    CifWriter(analogue, symprec=None).write_file(output)
    print(analogue.composition, analogue.get_space_group_info(symprec=1e-3), analogue.lattice)


if __name__ == "__main__":
    if len(sys.argv) not in {3, 4}:
        raise SystemExit("usage: make_sr_analogue.py SOURCE OUTPUT [CELL_SCALE]")
    main(*sys.argv[1:])
