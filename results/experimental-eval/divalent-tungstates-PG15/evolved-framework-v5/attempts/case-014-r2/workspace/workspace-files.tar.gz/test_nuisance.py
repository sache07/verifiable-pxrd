#!/usr/bin/env python3
"""Screen supported specimen/intensity terms from a physical checkpoint."""

from __future__ import annotations

import argparse
from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2

from physical_refine import clear_all_flags, set_bound


ROOT = Path(__file__).resolve().parent
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def prepare(source, workpath):
    p = G2.G2Project(str(source))
    # Switch the project's working filename before any operation that may save
    # it; this keeps every branch independent and preserves the source.
    p.save(str(workpath))
    clear_all_flags(p)
    h = p.histograms()[0]
    h.set_refinements({"Background": {"refine": True}})
    for ph in p.phases():
        ph.set_HAP_refinements({"Scale": True})
    p.set_Frozen()
    p.set_Controls("cycles", 8)
    return p


def run_texture(source, outdir):
    rows = []
    for phase_index in range(2):
        for axis in AXES:
            name = f"texture_p{phase_index}_{''.join(map(str,axis))}.gpx"
            p = prepare(source, outdir / name)
            ph = p.phases()[phase_index]
            h = p.histograms()[0]
            hap = ph.data["Histograms"][h.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][3] = list(axis)
            ph.set_HAP_refinements({"Pref.Ori.": True})
            set_bound(p, f"{phase_index}:0:MD", 0.7, 1.4)
            try:
                p.refine()
                ratio = float(ph.data["Histograms"][h.name]["Pref.Ori."][1])
                val = float(h.get_wR())
                p.save(str(outdir / name))
                rows.append((val, phase_index, axis, ratio, name))
                print("TEXTURE", rows[-1], flush=True)
            except Exception as exc:
                print("TEXTURE_FAIL", phase_index, axis, repr(exc), flush=True)
    rows.sort()
    return rows


def run_uiso(source, outdir):
    # Coarse tied-by-construction Uiso scan. Each phase receives one common
    # isotropic value, matching the specimen generator's per-phase model.
    grid = [0.003, 0.005, 0.010, 0.020]
    rows = []
    for u0 in grid:
        for u1 in grid:
            name = f"uiso_{u0:.3f}_{u1:.3f}.gpx"
            p = prepare(source, outdir / name)
            for atom in p.phases()[0].atoms(): atom.uiso = u0
            for atom in p.phases()[1].atoms(): atom.uiso = u1
            p.set_Controls("cycles", 5)
            try:
                p.refine()
                val = float(p.histograms()[0].get_wR())
                p.save(str(outdir / name))
                rows.append((val, u0, u1, name))
                print("UISO", rows[-1], flush=True)
            except Exception as exc:
                print("UISO_FAIL", u0, u1, repr(exc), flush=True)
    rows.sort()
    return rows


def run_global(source, outdir):
    candidates = []
    # Polarization is an instrument term; refine it alone before roughness.
    name = "global_polarization.gpx"
    p = prepare(source, outdir / name)
    p.histograms()[0].set_refinements({"Instrument Parameters": ["Polariz."]})
    set_bound(p, ":0:Polariz.", 0.5, 1.0)
    p.refine()
    h = p.histograms()[0]
    p.save(str(outdir / name))
    candidates.append((float(h.get_wR()), name,
                       float(h.data["Instrument Parameters"][0]["Polariz."][1])))
    print("GLOBAL", candidates[-1], flush=True)

    # GSAS-II's Suortti roughness model requires positive starting A and B.
    name = "global_roughness.gpx"
    p = prepare(source, outdir / name)
    h = p.histograms()[0]
    h.data["Sample Parameters"]["SurfRoughA"][0] = 0.10
    h.data["Sample Parameters"]["SurfRoughB"][0] = 0.10
    h.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    set_bound(p, ":0:SurfRoughA", 0.0, 0.60)
    set_bound(p, ":0:SurfRoughB", 0.02, 0.50)
    p.refine()
    p.save(str(outdir / name))
    candidates.append((float(h.get_wR()), name,
                       float(h.data["Sample Parameters"]["SurfRoughA"][0]),
                       float(h.data["Sample Parameters"]["SurfRoughB"][0])))
    print("GLOBAL", candidates[-1], flush=True)
    return candidates


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source", nargs="?", default="checkpoints/physical_two_phase.gpx")
    ap.add_argument("--mode", choices=["texture", "uiso", "global", "all"], default="all")
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    source = (ROOT / args.source).resolve()
    outdir = ROOT / "checkpoints/nuisance"
    outdir.mkdir(parents=True, exist_ok=True)
    result = {}
    if args.mode in ("texture", "all"): result["texture"] = run_texture(source, outdir)
    if args.mode in ("uiso", "all"): result["uiso"] = run_uiso(source, outdir)
    if args.mode in ("global", "all"): result["global"] = run_global(source, outdir)
    (outdir / f"summary_{args.mode}.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
