#!/usr/bin/env python3
"""Refine scales/background for one fixed TTB Sr-site occupancy pair."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from physical_refine import clear_all_flags


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("occ0", type=float)
    ap.add_argument("occ1", type=float)
    ap.add_argument("output")
    ap.add_argument("--base", default="checkpoints/ttb_tex_001_bound.gpx")
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    p = G2.G2Project(args.base)
    p.save(args.output)
    clear_all_flags(p)
    controls = p.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    h = p.histograms()[0]
    bronze = p.phase("SrTTB")
    bronze.atom("Sr0").occupancy = args.occ0
    bronze.atom("Sr1").occupancy = args.occ1
    h.set_refinements({"Background": {"refine": True}})
    for phase in p.phases():
        phase.set_HAP_refinements({"Scale": True})
    p.set_Controls("cycles", 6)
    p.refine()
    p.save(args.output)
    print("FINAL", h.get_wR(), args.occ0, args.occ1,
          bronze.data["Histograms"][h.name]["Scale"],
          bronze.data["General"]["Mass"], flush=True)


if __name__ == "__main__":
    main()
