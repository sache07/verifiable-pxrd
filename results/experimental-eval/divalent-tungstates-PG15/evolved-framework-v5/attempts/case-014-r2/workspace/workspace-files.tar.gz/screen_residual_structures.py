#!/usr/bin/env python3
"""Rank frozen-COD A-W-O frameworks against a GSAS-II residual profile.

This is a diagnostic stick-family screen. It replaces the one non-W/O
element by Sr before calculating intensities, then searches only a modest
isotropic cell scale and the common Bragg-Brentano displacement shift.
"""

from __future__ import annotations

import gzip
import json
from pathlib import Path
import sys
import warnings

import numpy as np
from scipy.ndimage import gaussian_filter1d
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser


INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")
CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def sr_analogue(structure):
    mapping = {}
    for specie in structure.composition:
        symbol = getattr(getattr(specie, "element", None), "symbol", None) or specie.symbol
        if symbol not in {"W", "O"}:
            mapping[specie] = "Sr"
    if mapping:
        structure.replace_species(mapping)
    return structure


def main(profile_file: str):
    data = np.loadtxt(profile_file, delimiter=",", skiprows=1)
    x, yobs, ycalc, _background, residual = data.T
    step = float(np.median(np.diff(x)))
    # A peak-height-like standardized residual, smoothed to approximately one
    # observed FWHM. Positive values identify missing families; negative values
    # penalize candidates that predict intensity where the fit is already high.
    z = gaussian_filter1d(residual / np.sqrt(np.maximum(yobs, 1.0)), 8.0)

    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    records = []
    for key, entries in index.items():
        elements = key.split("-")
        if "W" not in elements or "O" not in elements:
            continue
        # Exact W-O and Sr-bearing records, plus one-cation A-W-O analogues.
        if not (set(elements) <= {"Sr", "W", "O", "C"} or len(elements) == 3):
            continue
        for formula, cod_id, sg, rfac in entries:
            records.append((key, formula, cod_id, sg, rfac))

    calculator = XRDCalculator(wavelength=1.540598)
    results = []
    warnings.filterwarnings("ignore")
    for number, (key, formula, cod_id, sg, rfac) in enumerate(records, 1):
        try:
            structure = CifParser(str(cif_path(cod_id)), occupancy_tolerance=5.0).parse_structures(
                primitive=False
            )[0]
            structure = sr_analogue(structure)
            pattern = calculator.get_pattern(structure, two_theta_range=(10.0, 100.0))
        except Exception:
            continue
        tt = np.asarray(pattern.x, float)
        inten = np.asarray(pattern.y, float)
        keep = inten >= 1.0
        tt, inten = tt[keep], inten[keep]
        if not len(tt):
            continue
        inten /= inten.sum()
        best = None
        # k is the analogue cell multiplier; A is the common displacement-like
        # 2theta correction in degrees, proportional to cos(theta).
        for k in np.linspace(0.97, 1.06, 37):
            moved = np.degrees(2.0 * np.arcsin(np.sin(np.radians(tt / 2.0)) / k))
            for amplitude in np.linspace(0.20, 0.45, 11):
                pos = moved + amplitude * np.cos(np.radians(moved / 2.0))
                valid = (pos >= x[0]) & (pos <= x[-1])
                if not np.any(valid):
                    continue
                sampled = np.interp(pos[valid], x, z)
                weights = inten[valid]
                weights /= weights.sum()
                mean = float(np.dot(weights, sampled))
                positive_coverage = float(np.sum(weights[sampled > 1.0]))
                strong_coverage = float(np.sum(weights[sampled > 3.0]))
                objective = mean + 2.0 * strong_coverage + positive_coverage
                candidate = (objective, mean, positive_coverage, strong_coverage, k, amplitude)
                if best is None or candidate > best:
                    best = candidate
        results.append((*best, key, formula, cod_id, sg, rfac, str(structure.composition)))

    results.sort(reverse=True)
    print("objective mean cov>1 cov>3 cell_scale shift key formula id sg R composition")
    for row in results[:80]:
        objective, mean, cov1, cov3, k, amplitude, key, formula, cod_id, sg, rfac, composition = row
        print(f"{objective:8.3f} {mean:8.3f} {cov1:6.3f} {cov3:6.3f} "
              f"{k:7.4f} {amplitude:6.3f} {key:16s} {formula:20s} {cod_id} {sg:3d} "
              f"{str(rfac):7s} {composition}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "checkpoint_sw_wo3_v2_fit.csv")
