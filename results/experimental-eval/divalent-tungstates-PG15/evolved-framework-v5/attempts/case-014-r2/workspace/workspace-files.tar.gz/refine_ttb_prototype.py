#!/usr/bin/env python3
"""Add and refine one Sr-substituted P4/mbm tungsten-bronze prototype."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from physical_refine import clear_all_flags, set_cell


ROOT = Path(__file__).resolve().parent


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("prototype")
    ap.add_argument("output")
    ap.add_argument("--base", default="checkpoints/physical_texture.gpx")
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    base = (ROOT / args.base).resolve()
    output = (ROOT / args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    p = G2.G2Project(str(base))
    p.save(str(output))
    h = p.histograms()[0]
    bronze = p.add_phase(
        str((ROOT / args.prototype).resolve()), phasename="SrTTB",
        histograms=[h], fmthint="CIF",
    )
    set_cell(bronze, [12.52, 12.52, 3.897, 90, 90, 90])
    hap = bronze.data["Histograms"][h.name]
    hap["Scale"] = [10000.0 * 0.03 / bronze.data["General"]["Mass"], False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.10
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    for atom in bronze.atoms():
        atom.uiso = 0.003

    clear_all_flags(p)
    controls = p.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    h.set_refinements({"Background": {"refine": True}})
    for phase in p.phases():
        phase.set_HAP_refinements({"Scale": True})
    p.set_Controls("cycles", 10)
    p.refine()
    print("SCALE", h.get_wR(), hap["Scale"], flush=True)
    if hap["Scale"][0] <= 0:
        p.save(str(output))
        raise SystemExit("nonpositive bronze scale")

    bronze.set_refinements({"Cell": True})
    p.set_Controls("cycles", 15)
    p.refine()
    p.save(str(output))
    print("FINAL", h.get_wR(), hap["Scale"], bronze.get_cell(), flush=True)


if __name__ == "__main__":
    main()
