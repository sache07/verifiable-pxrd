#!/usr/bin/env python3
"""Coarse bounded occupancy starts for the two Sr sites in the TTB model."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def run(source):
    G2.SetPrintLevel("error")
    root = Path(source).resolve().parent
    results = []
    for occ0 in (0.0, 0.2, 0.4, 0.6, 0.8, 1.0):
        for occ1 in (0.2, 0.4, 0.6, 0.8, 1.0):
            project = G2.G2Project(source)
            hist = project.histograms()[0]
            hist.clear_refinements({
                "Instrument Parameters": ["U", "V", "W", "X", "SH/L"],
                "Sample Parameters": ["Shift"],
            })
            for phase in project.phases():
                phase.clear_refinements({
                    "Cell": True, "Atoms": [atom.label for atom in phase.atoms()]
                })
            phase = project.phase("SrTTB")
            phase.atom("Sr0").occupancy = occ0
            phase.atom("Sr1").occupancy = occ1
            project.set_Controls("cycles", 8)
            project.do_refinements([{}])
            rwp = project.histograms()[0].get_wR()
            out = root / f"ttb_occ_{occ0:.1f}_{occ1:.1f}.gpx"
            project.save(str(out))
            results.append((rwp, occ0, occ1, str(out)))
            print(f"Rwp={rwp:.6f} Sr0={occ0:.2f} Sr1={occ1:.2f} {out}")
    print("BEST")
    for row in sorted(results)[:10]:
        print(row)


if __name__ == "__main__":
    run(sys.argv[1] if len(sys.argv) > 1 else "checkpoints/branch_ttb_s101.gpx")
