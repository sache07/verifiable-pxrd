#!/usr/bin/env python3
"""Build a physically bounded GSAS-II refinement for the accepted phases.

This is deliberately separate from the exploratory phase-screening script.  It
starts from clean reference structures, uses only ranges allowed by the lab
description and writes a checkpoint after every accepted refinement stage.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent


PHASES = [
    ("SrWO4", ROOT / "refs/SrWO4_1546036.cif", 0.88),
    ("WO3", ROOT / "refs/WO3_1528915.cif", 0.12),
]


def rwp(project: G2.G2Project) -> float:
    return float(project.histograms()[0].get_wR())


def set_bound(project, variable, lower, upper):
    project.set_Controls("parmMin", float(lower), variable=variable)
    project.set_Controls("parmMax", float(upper), variable=variable)


def set_cell(phase, values):
    cell = phase.data["General"]["Cell"]
    cell[1:7] = [float(v) for v in values]
    cell[7] = float(G2lat.calc_V(G2lat.cell2A(cell[1:7])))


def clear_all_flags(project):
    hist = project.histograms()[0]
    # GSAS-II's clear_refinements returns immediately after clearing a Boolean
    # Background entry, so clear it in a separate call.
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()], "LeBail": True})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "Pref.Ori.": True, "Extinction": True, "HStrain": True,
        })


def physical_state(project):
    hist = project.histograms()[0]
    ip = hist.data["Instrument Parameters"][0]
    sp = hist.data["Sample Parameters"]
    values = {
        "rwp": rwp(project),
        "zero_deg": float(ip["Zero"][1]),
        "shift_um": float(sp["Shift"][0]),
        "U": float(ip["U"][1]),
        "V": float(ip["V"][1]),
        "W": float(ip["W"][1]),
        "X": float(ip["X"][1]),
        "SH_L": float(ip["SH/L"][1]),
        "polarization": float(ip["Polariz."][1]),
        "surface_roughness_A": float(sp["SurfRoughA"][0]),
        "surface_roughness_B": float(sp["SurfRoughB"][0]),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        values["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size_um": float(hap["Size"][1][0]),
            "microstrain_ppm": float(hap["Mustrain"][1][0]),
            "md_ratio": float(hap["Pref.Ori."][1]),
            "md_axis": list(hap["Pref.Ori."][3]),
        }
    return values


def state_is_physical(project):
    s = physical_state(project)
    scalars = [s[k] for k in ("rwp", "zero_deg", "shift_um", "U", "V", "W", "X", "SH_L", "polarization")]
    if not np.all(np.isfinite(scalars)):
        return False, "nonfinite global parameter"
    if not (-0.25001 <= s["zero_deg"] <= 0.25001 and -800.01 <= s["shift_um"] <= 800.01):
        return False, "calibration outside lab range"
    if not (0 <= s["U"] <= 40.01 and 2 <= s["W"] <= 40.01 and 0.099 <= s["X"] <= 6.01):
        return False, "instrument profile outside lab range"
    if not (0.0049 <= s["SH_L"] <= 0.101 and 0.499 <= s["polarization"] <= 1.001):
        return False, "instrument asymmetry/polarization outside lab range"
    for name, p in s["phases"].items():
        if not (p["scale"] > 0 and 0.039 <= p["size_um"] <= 1.501 and 0 <= p["microstrain_ppm"] <= 8001):
            return False, f"nonphysical HAP term for {name}"
        cell = p["cell"]
        if not all(np.isfinite(float(v)) for v in cell.values()):
            return False, f"nonfinite cell for {name}"
    return True, "ok"


def refine_stage(project, output, label, configure, cycles=12, accept_worse=0.03):
    """Run one stage, rolling back numerical/nonphysical regressions."""
    before = rwp(project)
    backup = output.with_suffix(f".{label}.before.gpx")
    project.save(str(backup))
    configure(project)
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    try:
        project.refine()
        after = rwp(project)
        ok, reason = state_is_physical(project)
        if not ok or not np.isfinite(after) or after > before + accept_worse:
            print(f"REJECT {label}: {before:.5f} -> {after:.5f}; {reason}")
            return G2.G2Project(str(backup)), False
        project.save(str(output))
        print(f"ACCEPT {label}: {before:.5f} -> {after:.5f}")
        print(json.dumps(physical_state(project), indent=2, default=float))
        return project, True
    except Exception as exc:
        print(f"REJECT {label}: exception {exc!r}")
        return G2.G2Project(str(backup)), False


def build(output: Path):
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(output))
    phases = [project.add_phase(str(cif), phasename=name, fmthint="CIF")
              for name, cif, _ in PHASES]
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"),
        phases=phases, fmthint="xye",
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements({
        "Limits": [10.01, 99.99],
        "Background": {
            "type": "chebyschev-1", "no. coeffs": 12,
            "coeffs": [700.0] + [0.0] * 11, "refine": False,
        },
    })
    # Start near the stable peak-position solution from the exact-reference
    # screen. Zero and displacement are added below to separate calibration
    # from the small allowed reference-cell mismatch.
    set_cell(phases[0], [5.4191161, 5.4191161, 11.9618468, 90, 90, 90])
    set_cell(phases[1], [7.3014257, 7.5417404, 7.6933301, 90, 90.783006, 90])
    sp = hist.data["Sample Parameters"]
    sp["Shift"][0] = -606.0
    ip = hist.data["Instrument Parameters"][0]
    for name, value in {"Zero": 0.0, "U": 15.0, "V": 0.0, "W": 15.0,
                        "X": 2.0, "SH/L": 0.03, "Polariz.": 0.70}.items():
        ip[name][1] = value

    masses = np.array([p.data["General"]["Mass"] for p in phases], float)
    for phase, (_, _, fraction), mass in zip(phases, PHASES, masses):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 * fraction / mass, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.35
        hap["Size"][2][0] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 800.0
        hap["Mustrain"][2][0] = False
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.uiso = 0.005

    clear_all_flags(project)
    # Global bounds from LAB.md.
    for variable, lo, hi in [
        (":0:Zero", -0.25, 0.25), (":0:Shift", -800, 800),
        (":0:U", 0, 40), (":0:V", -40, 40), (":0:W", 2, 40),
        (":0:X", 0.1, 6), (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
        (":0:SurfRoughA", 0.0, 0.60), (":0:SurfRoughB", 0.0, 0.50),
    ]:
        set_bound(project, variable, lo, hi)
    for i in range(len(phases)):
        set_bound(project, f"{i}:0:Scale", 1e-8, 1000)
        set_bound(project, f"{i}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{i}:0:Mustrain;i", 0.0, 8000)
        set_bound(project, f"{i}:0:MD", 0.7, 1.4)
    # Conservative Marquardt damping and convergence tolerance.
    project.data["Controls"]["data"]["shift factor"] = 0.5
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(output))
    return project


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", nargs="?", default="checkpoints/physical_two_phase.gpx")
    args = parser.parse_args()
    output = (ROOT / args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = build(output)
    histname = project.histograms()[0].name

    def scales_background(p):
        h = p.histograms()[0]
        h.set_refinements({"Background": {"refine": True}})
        for ph in p.phases(): ph.set_HAP_refinements({"Scale": True})

    project, _ = refine_stage(project, output, "scale_bg", scales_background, 16, 0.1)

    def calibration_cells(p):
        h = p.histograms()[0]
        h.set_refinements({"Sample Parameters": ["Shift"],
                           "Instrument Parameters": ["Zero"]})
        for ph in p.phases(): ph.set_refinements({"Cell": True})

    project, _ = refine_stage(project, output, "calibration_cells", calibration_cells, 20, 0.1)

    def sizes(p):
        for ph in p.phases():
            ph.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.35, "refine": True}})

    project, _ = refine_stage(project, output, "size", sizes, 16, 0.1)

    def strains(p):
        for ph in p.phases():
            ph.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})

    project, _ = refine_stage(project, output, "strain", strains, 16, 0.1)

    def profile_wx(p):
        p.histograms()[0].set_refinements({"Instrument Parameters": ["W", "X"]})

    project, _ = refine_stage(project, output, "profile_wx", profile_wx, 16, 0.1)

    def profile_u(p):
        p.histograms()[0].set_refinements({"Instrument Parameters": ["U"]})

    project, _ = refine_stage(project, output, "profile_u", profile_u, 16, 0.1)

    def asymmetry(p):
        p.histograms()[0].set_refinements({"Instrument Parameters": ["SH/L"]})

    project, _ = refine_stage(project, output, "asymmetry", asymmetry, 16, 0.1)

    project.save(str(output))
    print("FINAL", json.dumps(physical_state(project), indent=2, default=float))


if __name__ == "__main__":
    main()
