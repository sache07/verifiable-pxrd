#!/usr/bin/env python3
"""Map preferred-orientation axes for physical monoclinic WO3."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from physical_refine import clear_all_flags, rwp, set_bound


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "checkpoints/wo3_mono_2311041.gpx"
AXES = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0),
        (1, 0, 1), (0, 1, 1), (1, 1, 1)]


def main():
    G2.SetPrintLevel("warn")
    rows = []
    for axis in AXES:
        tag = "".join(str(v) for v in axis)
        out = ROOT / f"checkpoints/wo3_texture_{tag}.gpx"
        project = G2.G2Project(str(SOURCE))
        clear_all_flags(project)
        hist = project.histograms()[0]
        hist.set_refinements({"Background": {"refine": True}})
        for phase in project.phases():
            phase.set_HAP_refinements({"Scale": True})
        wo3 = project.phase("WO3")
        hap = wo3.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        set_bound(project, "1:0:MD", 0.7, 1.4)
        project.set_Frozen()
        project.set_Controls("cycles", 18)
        project.refine()
        project.save(str(out))
        rows.append({"axis": list(axis), "rwp": rwp(project),
                     "ratio": float(hap["Pref.Ori."][1]),
                     "output": str(out.relative_to(ROOT))})
        print(json.dumps(rows[-1]))
    rows.sort(key=lambda row: row["rwp"])
    (ROOT / "checkpoints/wo3_texture_comparison.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )
    print("BEST", json.dumps(rows[0], indent=2))


if __name__ == "__main__":
    main()
