#!/usr/bin/env python3
"""Create Sr-substituted tetragonal-tungsten-bronze models from COD 4030741."""

from pathlib import Path
import sys

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser, CifWriter


def main(source, output, a_value, c_value):
    source = Path(source)
    structure = CifParser(str(source), occupancy_tolerance=2.0).parse_structures(
        primitive=False
    )[0]
    replaced_species = []
    for site in structure:
        species = {}
        for specie, occupancy in site.species.items():
            symbol = getattr(getattr(specie, "element", None), "symbol", None)
            if symbol is None:
                symbol = specie.symbol
            key = specie if symbol in {"W", "O"} else "Sr"
            species[key] = species.get(key, 0.0) + occupancy
        replaced_species.append(species)
    old = structure.lattice
    lattice = Lattice.from_parameters(
        float(a_value), float(a_value), float(c_value),
        old.alpha, old.beta, old.gamma,
    )
    analogue = Structure(
        lattice, replaced_species,
        [site.frac_coords for site in structure],
        site_properties=structure.site_properties,
    )
    CifWriter(analogue, symprec=1e-4, refine_struct=False).write_file(output)
    print(analogue.composition, analogue.get_space_group_info(symprec=1e-3), analogue.lattice)


if __name__ == "__main__":
    if len(sys.argv) != 5:
        raise SystemExit("usage: make_ttb_analogue.py SOURCE OUTPUT A_ANGSTROM C_ANGSTROM")
    main(*sys.argv[1:])
