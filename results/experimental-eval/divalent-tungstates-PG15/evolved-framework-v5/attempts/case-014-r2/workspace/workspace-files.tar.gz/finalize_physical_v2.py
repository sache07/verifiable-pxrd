#!/usr/bin/env python3
"""Robustly finalize the physical model with immutable GSAS-II checkpoints."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from physical_refine import clear_all_flags, physical_state, set_bound, state_is_physical


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "checkpoints/wo3_texture_110.bak0.gpx"
BASE = ROOT / "checkpoints/finalv2_00_base.gpx"
FINAL = ROOT / "checkpoints/final_physical_v2.gpx"


def set_bounds(project):
    for variable, lo, hi in [
        (":0:Zero", -0.25, 0.25), (":0:Shift", -800, 800),
        (":0:U", 0, 40), (":0:V", -40, 40), (":0:W", 2, 40),
        (":0:X", 0.1, 6), (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
    ]:
        set_bound(project, variable, lo, hi)
    for index in range(len(project.phases())):
        set_bound(project, f"{index}:0:Scale", 1e-8, 1000)
        set_bound(project, f"{index}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{index}:0:Mustrain;i", 0.0, 8000)
        set_bound(project, f"{index}:0:MD", 0.7, 1.4)


def common(project):
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    # Supported boundary texture terms are fixed for subsequent stages.
    for name in ("WO3", "SrTTB"):
        project.phase(name).data["Histograms"][hist.name]["Pref.Ori."][2] = False


def atoms(project):
    return {
        phase.name: {
            atom.label: tuple(float(v) for v in atom.coordinates)
            for atom in phase.atoms()
        }
        for phase in project.phases()
    }


def cells_close(before, after):
    for name in before["phases"]:
        c0 = before["phases"][name]["cell"]
        c1 = after["phases"][name]["cell"]
        for key in ("length_a", "length_b", "length_c"):
            if abs(c1[key] / c0[key] - 1.0) > 0.005:
                return False, f"{name} {key} moved by >0.5%"
        for key in ("angle_alpha", "angle_beta", "angle_gamma"):
            if abs(c1[key] - c0[key]) > 0.5:
                return False, f"{name} {key} moved by >0.5 degree"
    return True, "ok"


def trial(current, index, label, configure, cycles=18, allow_cell_change=False):
    output = ROOT / f"checkpoints/finalv2_{index:02d}_{label}.gpx"
    shutil.copy2(current, output)
    project = G2.G2Project(str(output))
    before = physical_state(project)
    before_atoms = atoms(project)
    set_bounds(project)
    configure(project)
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    try:
        project.refine()
        after = physical_state(project)
        ok, reason = state_is_physical(project)
        if ok and not np.isfinite(after["rwp"]):
            ok, reason = False, "nonfinite Rwp"
        if ok and after["rwp"] > before["rwp"] + 1e-4:
            ok, reason = False, "Rwp increased"
        if ok and atoms(project) != before_atoms:
            ok, reason = False, "atomic coordinates changed in a non-coordinate stage"
        if ok and allow_cell_change:
            ok, reason = cells_close(before, after)
        elif ok:
            for name in before["phases"]:
                if before["phases"][name]["cell"] != after["phases"][name]["cell"]:
                    ok, reason = False, "cell changed in a fixed-cell stage"
                    break
    except Exception as exc:
        after = None
        ok, reason = False, repr(exc)
    row = {
        "stage": label,
        "input": str(Path(current).relative_to(ROOT)),
        "trial": str(output.relative_to(ROOT)),
        "accepted": bool(ok),
        "reason": reason,
        "before_rwp": before["rwp"],
        "after_rwp": None if after is None else after["rwp"],
        "state": after,
    }
    print(json.dumps({k: row[k] for k in (
        "stage", "accepted", "reason", "before_rwp", "after_rwp")}, indent=2))
    return (output if ok else current), row


def main():
    G2.SetPrintLevel("warn")
    shutil.copy2(SOURCE, BASE)
    current = BASE
    history = []

    def cell_stage(p):
        common(p)
        for phase in p.phases():
            phase.set_refinements({"Cell": True})

    current, row = trial(current, 1, "cells", cell_stage, 20, True)
    history.append(row)

    def zero_stage(p):
        common(p)
        p.histograms()[0].set_refinements({"Instrument Parameters": ["Zero"]})

    current, row = trial(current, 2, "zero", zero_stage, 18)
    history.append(row)

    for index, (label, parameter) in enumerate(
        (("profile_w", "W"), ("profile_x", "X"), ("asymmetry", "SH/L")), start=3
    ):
        def profile_stage(p, name=parameter):
            common(p)
            p.histograms()[0].set_refinements({"Instrument Parameters": [name]})
        current, row = trial(current, index, label, profile_stage, 18)
        history.append(row)

    for index, phase_name in enumerate(("SrWO4", "WO3", "Sr3WO6", "SrTTB"), start=6):
        def size_stage(p, name=phase_name):
            common(p)
            p.phase(name).set_HAP_refinements({
                "Size": {"type": "isotropic", "refine": True}
            })
        current, row = trial(current, index, f"size_{phase_name}", size_stage, 18)
        history.append(row)

    def scales_background(p):
        common(p)

    current, row = trial(current, 10, "fullgrid", scales_background, 20)
    history.append(row)
    shutil.copy2(current, FINAL)
    final_project = G2.G2Project(str(FINAL))
    clear_all_flags(final_project)
    # Leave the submitted checkpoint with only scales/background selected for
    # an explicit replay; no structural or profile parameter is left floating.
    common(final_project)
    final_project.save(str(FINAL))
    summary = {
        "selected_checkpoint": str(Path(current).relative_to(ROOT)),
        "final_checkpoint": str(FINAL.relative_to(ROOT)),
        "state": physical_state(final_project),
        "history": history,
    }
    (ROOT / "checkpoints/final_physical_v2_history.json").write_text(
        json.dumps(summary, indent=2, default=float) + "\n"
    )
    print("FINAL", json.dumps(summary["state"], indent=2, default=float))


if __name__ == "__main__":
    main()
