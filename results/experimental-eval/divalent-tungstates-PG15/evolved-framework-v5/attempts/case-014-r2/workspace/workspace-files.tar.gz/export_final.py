#!/usr/bin/env python3
"""Export the selected replayable GSAS-II checkpoint and machine outputs."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "checkpoints/final_physical_v2.gpx"

PHASE_INFO = {
    "SrWO4": {
        "name": "scheelite SrWO4",
        "formula": "SrWO4",
        "space_group": "I 41/a (No. 88)",
        "cif_path": "SrWO4.cif",
        "reliability": "high",
    },
    "WO3": {
        "name": "monoclinic WO3 (physical neutron model)",
        "formula": "WO3",
        "space_group": "P 21/c (No. 14)",
        "cif_path": "WO3.cif",
        "reliability": "high phase assignment; COD 2311041 physical structure model",
    },
    "Sr3WO6": {
        "name": "ordered-double-perovskite Sr3WO6",
        "formula": "Sr3WO6",
        "space_group": "F m -3 m (No. 225)",
        "cif_path": "Sr3WO6.cif",
        "reliability": "moderate; prototype assignment",
    },
    "SrTTB": {
        "name": "Sr tungsten bronze (TTB)",
        "formula": "Sr6W10O30 model (Sr0.60WO3 basis)",
        "space_group": "P 4/m b m (No. 127)",
        "cif_path": "Sr_tungsten_bronze.cif",
        "reliability": "low; topology/cell supported, composition and structure factors uncertain",
    },
}


def fraction_esds(project, phases, q, fractions):
    covdata = project.data["Covariance"]["data"]
    vary = list(covdata.get("varyList", []))
    cov = np.asarray(covdata.get("covMatrix", []), float)
    scale_names = [f"{i}:0:Scale" for i in range(len(phases))]
    if cov.shape != (len(vary), len(vary)) or not all(v in vary for v in scale_names):
        return [None] * len(phases)
    idx = [vary.index(v) for v in scale_names]
    cs = cov[np.ix_(idx, idx)]
    masses = np.array([p.data["General"]["Mass"] for p in phases], float)
    total = float(np.sum(q))
    jac = np.empty((len(phases), len(phases)))
    for i in range(len(phases)):
        for j in range(len(phases)):
            jac[i, j] = ((masses[i] if i == j else 0.0) * total - q[i] * masses[j]) / total**2
    cf = jac @ cs @ jac.T
    return np.sqrt(np.maximum(np.diag(cf), 0.0)).tolist()


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE))
    project.save(str(ROOT / "final.gpx"))
    hist = project.histograms()[0]
    phases = project.phases()

    arrays = {key: np.asarray(hist.getdata(key), float)
              for key in ("X", "Yobs", "Ycalc")}
    difference = arrays["Yobs"] - arrays["Ycalc"]
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((arrays["X"], arrays["Yobs"], arrays["Ycalc"], difference)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt="%.15g",
    )

    q = []
    for phase in phases:
        phase.export_CIF(str(ROOT / PHASE_INFO[phase.name]["cif_path"]))
        hap = phase.data["Histograms"][hist.name]
        q.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
    q = np.asarray(q, float)
    fractions = q / np.sum(q)
    esds = fraction_esds(project, phases, q, fractions)

    hstats = hist.data["data"][0]
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    result_phases = []
    for phase, fraction, esd in zip(phases, fractions, esds):
        row = dict(PHASE_INFO[phase.name])
        row["project_phase_name"] = phase.name
        row["weight_fraction"] = float(fraction)
        row["weight_percent"] = float(100.0 * fraction)
        row["weight_fraction_formal_esd"] = None if esd is None else float(esd)
        row["cell"] = phase.get_cell()
        result_phases.append(row)

    result = {
        "schema": "pxrd-phase-analysis/1",
        "input_pattern": "inputs/pattern.csv",
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "weight_fraction_basis": "HAP scale multiplied by GSAS-II unit-cell mass, normalized over the four modeled crystalline phases",
        "phases": result_phases,
        "fit_statistics": {
            "Rwp_percent": float(hstats["wR"]),
            "Rp_percent": float(hstats["R"]),
            "Rexp_percent": float(hstats["wRmin"]),
            "goodness_of_fit": float(rvals.get("GOF", np.nan)),
            "chi_square": float(rvals.get("chisq", np.nan)),
            "durbin_watson": float(hstats.get("Durbin-Watson", np.nan)),
            "n_observations": int(hstats["Nobs"]),
            "n_refined_parameters_last_cycle": int(rvals.get("Nvars", 0)),
            "weighting": "1/max(Iobs,1), equivalent to sigma=sqrt(counts); input uncertainties were not supplied",
        },
        "model_notes": {
            "fractions_normalized": True,
            "formal_esds_exclude_phase-model/systematic uncertainty": True,
            "bronze_fraction_and_composition_are_not_reliably_determined": True,
            "wo3_legacy_reference_with_short_O_O_contact_was_rejected": True,
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
