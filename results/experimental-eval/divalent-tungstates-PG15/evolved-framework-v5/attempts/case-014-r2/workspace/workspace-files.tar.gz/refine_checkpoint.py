#!/usr/bin/env python3
"""Create and refine an initial GSAS-II multiphase checkpoint.

Run with the GSAS-II Python interpreter.  This intentionally starts with
only chemically ordinary exact-composition references; residual families
are assessed from the resulting full-pattern difference curve.
"""

from pathlib import Path
import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def summary(project, label):
    hist = project.histograms()[0]
    print(f"{label}: Rwp={hist.get_wR():.4f}")
    print("  instrument", {k: v for k, v in hist.data["Instrument Parameters"][0].items()
                            if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")})
    print("  sample", {k: hist.data["Sample Parameters"].get(k)
                        for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(" ", phase.name, phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"][:4], "mustrain", hap["Mustrain"][:4])


def main(outname, phase_specs):
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(ROOT / outname))
    phases = []
    for name, cif in phase_specs:
        phases.append(project.add_phase(str(ROOT / cif), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"),
        phases=phases, fmthint="xye",
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements({
        "Limits": [10.01, 99.99],
        "Background": {
            "type": "chebyschev-1", "no. coeffs": 12,
            "coeffs": [500.0] + [0.0] * 11, "refine": True,
        },
    })
    # Keep broadening finite at the first checkpoint and give all phases a
    # small, positive scale. Scale*cell-mass determines GSAS-II mass fraction.
    initial_fractions = np.full(len(phases), 0.15 / max(len(phases) - 1, 1))
    initial_fractions[0] = 0.85 if len(phases) > 1 else 1.0
    for phase, fraction in zip(phases, initial_fractions):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 * fraction / phase.data["General"]["Mass"], True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0

    project.set_Controls("cycles", 12)
    project.save()
    # Staged, stable refinement: scales/background, displacement and cells,
    # then the common instrument profile. A separate phase-profile branch is
    # evaluated only after inventory assignment.
    stages = [
        ("scale-background", {"set": {"Background": {"refine": True}, "Scale": True}}),
        ("shift", {"set": {"Sample Parameters": ["Shift"]}}),
        ("cells", {"set": {"Cell": True}}),
        ("profile-WX", {"set": {"Instrument Parameters": ["W", "X"]}}),
        ("profile-UV", {"set": {"Instrument Parameters": ["U", "V"]}}),
        ("asymmetry", {"set": {"Instrument Parameters": ["SH/L"]}}),
    ]
    for label, recipe in stages:
        try:
            project.do_refinements([recipe])
            summary(project, label)
            project.save(str(ROOT / outname))
        except Exception as exc:
            print(f"STAGE FAILED {label}: {exc!r}", file=sys.stderr)
            project = G2.G2Project(str(ROOT / outname))
    summary(project, "final-checkpoint")
    project.save(str(ROOT / outname))

    arrays = {key: np.asarray(hist.getdata(key), float)
              for key in ("X", "Yobs", "Ycalc", "Background", "Residual")}
    np.savetxt(ROOT / (Path(outname).stem + "_fit.csv"),
               np.column_stack([arrays[k] for k in arrays]), delimiter=",",
               header=",".join(arrays), comments="")


if __name__ == "__main__":
    if len(sys.argv) < 4 or (len(sys.argv) - 2) % 2:
        raise SystemExit("usage: refine_checkpoint.py OUT.gpx NAME CIF [NAME CIF ...]")
    specs = list(zip(sys.argv[2::2], sys.argv[3::2]))
    main(sys.argv[1], specs)
