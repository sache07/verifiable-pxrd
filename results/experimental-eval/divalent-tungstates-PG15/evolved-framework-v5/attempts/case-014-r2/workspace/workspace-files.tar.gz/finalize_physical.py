#!/usr/bin/env python3
"""Finalize the accepted four-phase model using physical monoclinic WO3."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from physical_refine import (
    clear_all_flags,
    physical_state,
    refine_stage,
    set_bound,
)


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "checkpoints/wo3_texture_110.gpx"
OUTPUT = ROOT / "checkpoints/final_physical.gpx"


def common(project):
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    # Boundary texture solutions are retained but not repeatedly optimized.
    project.phase("WO3").data["Histograms"][hist.name]["Pref.Ori."][2] = False
    project.phase("SrTTB").data["Histograms"][hist.name]["Pref.Ori."][2] = False


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE))
    clear_all_flags(project)
    # Reassert physical bounds after replacing the WO3 phase.
    for variable, lo, hi in [
        (":0:Zero", -0.25, 0.25), (":0:Shift", -800, 800),
        (":0:U", 0, 40), (":0:V", -40, 40), (":0:W", 2, 40),
        (":0:X", 0.1, 6), (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
    ]:
        set_bound(project, variable, lo, hi)
    for index in range(len(project.phases())):
        set_bound(project, f"{index}:0:Scale", 1e-8, 1000)
        set_bound(project, f"{index}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{index}:0:Mustrain;i", 0.0, 8000)
        set_bound(project, f"{index}:0:MD", 0.7, 1.4)
    project.save(str(OUTPUT))
    history = []

    def run(label, configure, cycles=18):
        nonlocal project
        project, accepted = refine_stage(
            project, OUTPUT, label, configure, cycles=cycles,
            accept_worse=0.02,
        )
        history.append({"stage": label, "accepted": accepted,
                        "state": physical_state(project)})

    def calibration_cells(p):
        common(p)
        hist = p.histograms()[0]
        hist.set_refinements({"Sample Parameters": ["Shift"],
                              "Instrument Parameters": ["Zero"]})
        for phase in p.phases():
            phase.set_refinements({"Cell": True})

    run("calibration_cells", calibration_cells, 22)

    def profile_w(p):
        common(p)
        p.histograms()[0].set_refinements({"Instrument Parameters": ["W"]})

    run("profile_w", profile_w, 18)

    def profile_x(p):
        common(p)
        p.histograms()[0].set_refinements({"Instrument Parameters": ["X"]})

    run("profile_x", profile_x, 18)

    def asymmetry(p):
        common(p)
        p.histograms()[0].set_refinements({"Instrument Parameters": ["SH/L"]})

    run("asymmetry", asymmetry, 18)

    for phase_name in ("SrWO4", "WO3", "Sr3WO6", "SrTTB"):
        def size_stage(p, name=phase_name):
            common(p)
            p.phase(name).set_HAP_refinements({
                "Size": {"type": "isotropic", "refine": True}
            })
        run(f"size_{phase_name}", size_stage, 18)

    def final_scales_background(p):
        common(p)

    run("fullgrid", final_scales_background, 20)
    project.save(str(OUTPUT))
    (ROOT / "checkpoints/final_physical_history.json").write_text(
        json.dumps(history, indent=2, default=float) + "\n"
    )
    print("FINAL", json.dumps(physical_state(project), indent=2, default=float))


if __name__ == "__main__":
    main()
