#!/usr/bin/env python3
"""Test bounded heavy- and light-atom refinement for physical WO3."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from physical_refine import clear_all_flags, rwp, set_bound


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "checkpoints/wo3_texture_110.gpx"


def configure_common(project):
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    # The mapped [110] texture is at the allowed physical boundary; keep it
    # fixed while testing structure factors.
    wo3 = project.phase("WO3")
    wo3.data["Histograms"][hist.name]["Pref.Ori."][2] = False
    return wo3


def set_coordinate_bounds(project, atom_indices, delta):
    for atom_index in atom_indices:
        for component in ("x", "y", "z"):
            set_bound(project, f"1::dA{component}:{atom_index}", -delta, delta)


def run_stage(source, output, labels, atom_indices, delta):
    project = G2.G2Project(str(source))
    wo3 = configure_common(project)
    wo3.set_refinements({"Atoms": {label: "X" for label in labels}})
    set_coordinate_bounds(project, atom_indices, delta)
    project.set_Frozen()
    project.set_Controls("cycles", 24)
    project.refine()
    project.save(str(output))
    cif = output.with_suffix(".cif")
    wo3.export_CIF(str(cif))
    row = {
        "source": str(Path(source).relative_to(ROOT)),
        "output": str(output.relative_to(ROOT)),
        "rwp": rwp(project),
        "labels": labels,
        "coordinate_bound_fractional": delta,
        "coordinates": {atom.label: list(atom.coordinates) for atom in wo3.atoms()},
    }
    print(json.dumps(row, indent=2))
    return row


def main():
    G2.SetPrintLevel("warn")
    heavy_out = ROOT / "checkpoints/wo3_physical_heavy.gpx"
    heavy = run_stage(SOURCE, heavy_out, ["W1", "W2"], [2, 6], 0.004)
    light_out = ROOT / "checkpoints/wo3_physical_light.gpx"
    light = run_stage(
        heavy_out, light_out,
        ["O1", "O2", "O3", "O4", "O5", "O6"],
        [0, 1, 3, 4, 5, 7], 0.006,
    )
    (ROOT / "checkpoints/wo3_coordinate_stages.json").write_text(
        json.dumps([heavy, light], indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
