#!/usr/bin/env python3
"""Compare physical exact-composition WO3 references in the accepted model."""

from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from physical_refine import clear_all_flags, physical_state, rwp, set_bound


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "checkpoints/final_fullgrid.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
MODELS = {
    "mono_2311041": COD / "2/31/10/2311041.cif",
    "triclinic_2106293": COD / "2/10/62/2106293.cif",
}


def load_phase_data(cif: Path):
    scratch = G2.G2Project(newgpx=str(ROOT / "checkpoints/wo3_import_scratch.gpx"))
    phase = scratch.add_phase(str(cif), phasename="WO3", fmthint="CIF")
    return copy.deepcopy(phase.data)


def replace_wo3(project: G2.G2Project, cif: Path):
    old = project.phase("WO3")
    hap = copy.deepcopy(old.data["Histograms"])
    new = load_phase_data(cif)
    new["General"]["Name"] = "WO3"
    new["Histograms"] = hap
    project.data["Phases"]["WO3"] = new
    project.update_ids()
    phase = project.phase("WO3")
    for atom in phase.atoms():
        atom.uiso = 0.003
    return phase


def refine(project: G2.G2Project, cycles=16):
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    project.refine()


def run(label: str, cif: Path):
    out = ROOT / f"checkpoints/wo3_{label}.gpx"
    project = G2.G2Project(str(SOURCE))
    phase = replace_wo3(project, cif)
    clear_all_flags(project)
    # Imported phases retain the accepted positive WO3 HAP scale/size. Use
    # neutral preferred orientation until its axis is tested explicitly.
    hap = phase.data["Histograms"][project.histograms()[0].name]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    set_bound(project, ":0:Shift", -800, 800)
    set_bound(project, ":0:Zero", -0.25, 0.25)
    project.set_Controls("cycles", 0)
    project.refine()
    initial = rwp(project)

    hist = project.histograms()[0]
    hist.set_refinements({"Background": {"refine": True}})
    for item in project.phases():
        item.set_HAP_refinements({"Scale": True})
    refine(project, 16)
    scaled = rwp(project)

    phase.set_refinements({"Cell": True})
    refine(project, 20)
    final = rwp(project)
    project.save(str(out))
    state = physical_state(project)
    row = {
        "label": label,
        "source": str(cif),
        "initial_rwp": initial,
        "scaled_rwp": scaled,
        "cell_rwp": final,
        "wo3_cell": phase.get_cell(),
        "wo3_scale": state["phases"]["WO3"]["scale"],
        "output": str(out.relative_to(ROOT)),
    }
    print(json.dumps(row, indent=2))
    return row


def main():
    G2.SetPrintLevel("warn")
    rows = [run(label, cif) for label, cif in MODELS.items()]
    (ROOT / "checkpoints/wo3_model_comparison.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
