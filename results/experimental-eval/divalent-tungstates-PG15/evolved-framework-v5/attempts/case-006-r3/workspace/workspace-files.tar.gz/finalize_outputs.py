#!/usr/bin/env python3
"""Freeze the selected full-grid GSAS-II checkpoint and write deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "pol080_checkpoint_1.gpx"


def main() -> None:
    project = G2.G2Project(gpxfile=str(SOURCE))
    histogram = project.histogram(0)
    phases = {phase.name: phase for phase in project.phases()}

    measured_limits, fitted_limits = histogram.data["Limits"]
    if not np.allclose(measured_limits, fitted_limits, rtol=0.0, atol=1e-10):
        raise RuntimeError("Selected checkpoint does not cover the full measured grid")
    if set(phases) != {"CuWO4", "WO3_2311041"}:
        raise RuntimeError(f"Unexpected phase inventory: {sorted(phases)}")

    rvals = project.data["Covariance"]["data"]["Rvals"]
    if not rvals.get("converged", False):
        raise RuntimeError("Selected checkpoint is not converged")

    # Save first, so this exact project is the parent of every submitted output.
    final_project = ROOT / "final.gpx"
    project.save(str(final_project))

    phase_specs = [
        ("CuWO4", "CuWO4", "P -1", ROOT / "phase_CuWO4.cif"),
        ("WO3_2311041", "WO3", "P 21/c", ROOT / "phase_WO3.cif"),
    ]
    for project_name, _, _, cif_path in phase_specs:
        phases[project_name].export_CIF(str(cif_path))

    x = np.asarray(histogram.getdata("x"), dtype=float)
    observed = np.asarray(histogram.getdata("yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("ycalc"), dtype=float)
    difference = np.asarray(histogram.getdata("residual"), dtype=float)
    if not (
        len(x) == len(observed) == len(calculated) == len(difference) == 8301
    ):
        raise RuntimeError("Unexpected profile length")
    if not np.allclose(difference, observed - calculated, atol=1e-8, rtol=0.0):
        raise RuntimeError("Stored residual is inconsistent with observed-calculated")

    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed",
                "calculated",
                "difference_observed_minus_calculated",
            ]
        )
        writer.writerows(
            (f"{xx:.10f}", f"{yo:.8f}", f"{yc:.8f}", f"{yd:.8f}")
            for xx, yo, yc, yd in zip(x, observed, calculated, difference)
        )

    mass_fractions = histogram.ComputeMassFracs()
    phase_results = []
    for project_name, formula, space_group, cif_path in phase_specs:
        fraction, esd = mass_fractions[project_name]
        phase_results.append(
            {
                "name": formula,
                "formula": formula,
                "space_group": space_group,
                "cif_path": cif_path.name,
                "weight_fraction": fraction,
                "weight_fraction_esd": esd,
                "weight_percent": 100.0 * fraction,
                "weight_percent_esd": 100.0 * esd,
            }
        )

    residuals = histogram.residuals
    result = {
        "phases": phase_results,
        "modeled_crystalline_weight_fraction_sum": sum(
            phase["weight_fraction"] for phase in phase_results
        ),
        "normalization": (
            "Fractions are normalized over the modeled crystalline phases; "
            "amorphous or undetected material is not quantified."
        ),
        "fit_statistics": {
            "Rwp_percent": residuals["wR"],
            "Rp_percent": residuals["R"],
            "Rexp_percent": residuals["wRmin"],
            "background_subtracted_Rwp_percent": residuals["wRb"],
            "background_subtracted_Rp_percent": residuals["Rb"],
            "goodness_of_fit": rvals["GOF"],
            "reduced_chi_square": rvals["GOF"] ** 2,
            "chi_square": rvals["chisq"],
            "n_observations": rvals["Nobs"],
            "n_refined_variables": rvals["Nvars"],
            "converged": rvals["converged"],
            "maximum_shift_over_esd": rvals["Max shft/sig"],
            "phase_Rf_percent": {
                "CuWO4": residuals["0:0:Rf"],
                "WO3": residuals["1:0:Rf"],
            },
        },
        "profile_path": "fit.csv",
        "project_path": "final.gpx",
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )

    cu_cell = phases["CuWO4"].data["General"]["Cell"]
    wo_cell = phases["WO3_2311041"].data["General"]["Cell"]
    cu_fraction, cu_esd = mass_fractions["CuWO4"]
    wo_fraction, wo_esd = mass_fractions["WO3_2311041"]
    report = f"""# Powder XRD phase analysis

## Result

The crystalline specimen is modeled as **triclinic CuWO4 (P -1), {100 * cu_fraction:.2f} wt%**, plus **monoclinic WO3 (P 21/c), {100 * wo_fraction:.2f} wt%**. Fractions are normalized to the modeled crystalline material. The GSAS-II covariance standard uncertainties are {100 * cu_esd:.2f} and {100 * wo_esd:.2f} wt percentage point, respectively.

The final full-range fit (9.9034-100.0949 degrees 2theta, 8,301 points, Cu Kalpha1/Kalpha2) has Rwp = {residuals['wR']:.3f}%, Rp = {residuals['R']:.3f}%, Rexp = {residuals['wRmin']:.3f}%, and goodness-of-fit = {rvals['GOF']:.3f}. The refined cells are:

- CuWO4: a = {cu_cell[1]:.5f}, b = {cu_cell[2]:.5f}, c = {cu_cell[3]:.5f} A; alpha = {cu_cell[4]:.4f}, beta = {cu_cell[5]:.4f}, gamma = {cu_cell[6]:.4f} degrees; V = {cu_cell[7]:.5f} A^3.
- WO3 (the reference P 21/c setting): a = {wo_cell[1]:.5f}, b = {wo_cell[2]:.5f}, c = {wo_cell[3]:.5f} A; beta = {wo_cell[5]:.4f} degrees; V = {wo_cell[7]:.5f} A^3.

## Evidence and model selection

The CuO + WO3 starting chemistry and 800 C treatment support CuWO4 formation. An ambient CuWO4 topology, initialized from COD 2101690 ((Cu0.9Zn0.1)WO4 with Zn replaced by Cu), indexes the dominant pattern. Refining its cell and coordinates gave a one-phase Rwp of 5.263%. Coherent residual peaks at approximately 23.45, 24.69, 33.59, and 34.49 degrees match multiple reflections of ambient monoclinic WO3 (COD 2311041); adding it lowered Rwp to 4.237% before supported profile terms and to {residuals['wR']:.3f}% in the final model. A physical CuO C2/c trial refined to the imposed near-zero scale boundary (about 5e-9 normalized fraction), so CuO was not retained. No remaining coherent reflection family supports a third crystalline phase.

The submitted CuWO4 geometry is physical: Cu-O distances span 1.90-2.41 A and W-O distances 1.81-2.26 A. Two bounded coordinate restarts converged to a slightly worse solution. WO3 coordinates were retained from the ambient reference because unconstrained coordinate refinement of this approximately 3 wt% phase was unstable and produced inferior local geometry; its phase identity, cell, and amount are supported, but its detailed atomic coordinates are not independently determined by this pattern.

Instrument zero and sample-height shift were nearly perfectly correlated. The insignificant zero offset was fixed at 0, while a specimen displacement of about -596 micrometres was retained. The polarization factor was fixed at the instrument value of 0.8 because refining it was strongly correlated with the common displacement parameter and changed Rwp by only about 0.003 percentage point. A weak CuWO4 [001] March-Dollase term and [001] uniaxial microstrain were retained because each gave reproducible improvements; unsupported WO3 texture/size/strain terms were omitted.

## Uncertainty

The formal phase-fraction standard uncertainty is about 0.06 wt percentage point, but model variants place WO3 between roughly 2.5 and 2.8 wt%. A practical uncertainty of about +/-0.3 wt percentage point is therefore more realistic. Trace CuO below the powder-XRD detection limit cannot be excluded, and no amorphous fraction can be determined without an internal standard. The files `phase_CuWO4.cif`, `phase_WO3.cif`, `fit.csv`, and `final.gpx` all come from the same selected full-grid checkpoint.
"""
    (ROOT / "report.md").write_text(report, encoding="utf-8")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
