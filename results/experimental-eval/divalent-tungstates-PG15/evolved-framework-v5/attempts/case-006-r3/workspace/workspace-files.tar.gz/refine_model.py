#!/usr/bin/env python3
"""Build and refine the ambient CuWO4 model against inputs/pattern.csv."""

from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"


def report(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    hap = phase.data["Histograms"][hist.name]
    result = {
        "label": label,
        "residuals": hist.residuals,
        "cell": phase.data["General"]["Cell"][1:],
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in sample.items()
            if k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "hap_scale": hap["Scale"][0],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "atoms": [
            {
                "label": atom.label,
                "xyz": list(atom.coordinates),
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
        "vary_list": project.get_VaryList(),
    }
    print(json.dumps(result, indent=2, default=float))
    return result


def refine(project, label, repeats=1):
    project.save(str(TMP / f"{label}.gpx"))
    project.set_Controls("cycles", 12)
    for _ in range(repeats):
        project.refine(makeBack=False)
    project.save()
    report(project, label)


def build():
    TMP.mkdir(exist_ok=True)
    project = G2.G2Project(newgpx=str(TMP / "stage00_build.gpx"))
    phase = project.add_phase(
        str(ROOT / "candidate_CuWO4.cif"), phasename="CuWO4", fmthint="CIF"
    )
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        phases=[phase],
        fmthint="comma",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.InstrumentParameters["Zero"][1] = 0.30
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1400.0, -500.0, 300.0, -180.0, 100.0, -50.0]
                + [0.0] * 6,
                "refine": True,
            }
        }
    )
    phase.set_HAP_refinements({"Scale": True})
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][1][0] = 1.0
    hap["Mustrain"][1][0] = 0.0
    project.save()
    return project


def main():
    G2.SetPrintLevel("warn")
    project = build()
    hist = project.histogram(0)
    phase = project.phase(0)

    refine(project, "stage01_scale_background", repeats=2)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    phase.set_refinements({"Cell": True})
    refine(project, "stage02_cell_zero", repeats=3)

    phase.set_refinements({"Atoms": {"Cu1": "X"}})
    refine(project, "stage03_heavy_coordinates", repeats=3)

    phase.set_refinements(
        {"Atoms": {"O1": "X", "O2": "X", "O3": "X", "O4": "X"}}
    )
    refine(project, "stage04_oxygen_coordinates", repeats=4)


if __name__ == "__main__":
    main()
