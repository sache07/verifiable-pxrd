#!/usr/bin/env python3
"""Build and refine trial GSAS-II models for the supplied powder pattern.

Run this script with the GSAS-II Python interpreter. It is intentionally
limited to the public specimen inputs and explicitly selected COD CIFs.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
import shutil
import sys

import numpy as np

from GSASII import GSASIIscriptable as G2


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    cod_id = str(cod_id)
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def read_pattern(path: Path) -> tuple[np.ndarray, np.ndarray]:
    arr = np.genfromtxt(path, delimiter=",", names=True)
    return (
        np.asarray(arr["two_theta_deg"], dtype=float),
        np.asarray(arr["intensity"], dtype=float),
    )


def write_xye(path: Path, x: np.ndarray, y: np.ndarray) -> None:
    # Counts are unprocessed and no pointwise uncertainties were supplied;
    # Poisson counting uncertainties are the least-assumptive working weights.
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(path, np.column_stack([x, y, sigma]), fmt="%.8f %.8f %.8f")


def write_instrument(path: Path) -> None:
    path.write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha Bragg-Brentano\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )


def phase_scale(phase, hist_name: str) -> float:
    return float(phase.data["Histograms"][hist_name]["Scale"][0])


def phase_profile(phase, hist_name: str) -> dict:
    hap = phase.data["Histograms"][hist_name]
    return {
        "scale": float(hap["Scale"][0]),
        "size": list(hap["Size"][1]),
        "mustrain": list(hap["Mustrain"][1]),
        "preferred_orientation": list(hap["Pref.Ori."][:4]),
    }


def snapshot(project, hist, label: str) -> dict:
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = {}
    for phase in project.phases():
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "profile": phase_profile(phase, hist.name),
        }
    out = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "gof": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "instrument": {
            k: (v[1] if isinstance(v, list) and len(v) > 1 else v)
            for k, v in inst.items()
            if k in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in sample.items()
            if k in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type"}
        },
        "phases": phases,
    }
    try:
        out["mass_fractions"] = {
            k: {"value": v[0], "sigma": v[1]}
            for k, v in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    return out


def all_finite_positive(project, hist) -> bool:
    rwp = hist.get_wR()
    if rwp is None or not np.isfinite(rwp):
        return False
    for phase in project.phases():
        if not np.isfinite(phase_scale(phase, hist.name)) or phase_scale(phase, hist.name) <= 0:
            return False
        cell = phase.get_cell()
        if not all(np.isfinite(v) for v in cell.values()) or cell["volume"] <= 0:
            return False
    return True


def run_refinement(project, hist, outdir: Path, label: str, set_dict: dict | None = None) -> dict:
    if set_dict:
        project.set_refinement({"set": set_dict})
    checkpoint = outdir / f"{label}.gpx"
    project.save(checkpoint)
    project.refine(makeBack=False)
    state = snapshot(project, hist, label)
    print(json.dumps(state, indent=2, default=float), flush=True)
    if not all_finite_positive(project, hist):
        raise RuntimeError(f"nonphysical refinement at {label}")
    project.save(checkpoint)
    return state


def make_project(
    pattern_path: Path,
    outdir: Path,
    phase_specs: list[tuple[str, str]],
    background_terms: int,
) -> tuple[object, object]:
    outdir.mkdir(parents=True, exist_ok=True)
    x, y = read_pattern(pattern_path)
    xye = outdir / "pattern.xye"
    inst = outdir / "instrument.instprm"
    write_xye(xye, x, y)
    write_instrument(inst)

    project = G2.G2Project(newgpx=str(outdir / "working.gpx"))
    hist = project.add_powder_histogram(
        str(xye), str(inst), fmthint="xye"
    )
    phases = []
    for name, cod_id in phase_specs:
        source = cod_path(cod_id)
        if not source.exists():
            raise FileNotFoundError(source)
        phases.append(
            project.add_phase(
                str(source), phasename=name, histograms=[hist], fmthint="CIF"
            )
        )

    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [-500.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]

    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": background_terms,
                "coeffs": [float(np.percentile(y, 20))] + [0.0] * (background_terms - 1),
                "refine": False,
            },
        }
    )

    # Broad physical starting values prevent a displaced narrow model from
    # giving the scale refinement no overlap with the observed reflections.
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.10
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    project.set_Controls("cycles", 8)
    project.save()
    return project, hist


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", default="inputs/pattern.csv")
    parser.add_argument("--outdir", required=True)
    parser.add_argument(
        "--phase",
        action="append",
        required=True,
        help="phase specification NAME:COD_ID; repeat for multiple phases",
    )
    parser.add_argument("--background-terms", type=int, default=12)
    parser.add_argument("--coordinates", action="store_true")
    args = parser.parse_args()

    phase_specs = []
    for item in args.phase:
        name, cod_id = item.split(":", 1)
        phase_specs.append((name, cod_id))
    outdir = Path(args.outdir).resolve()
    project, hist = make_project(
        Path(args.pattern).resolve(), outdir, phase_specs, args.background_terms
    )

    history = [snapshot(project, hist, "initial")]
    # Linear/background-dominated terms first.
    history.append(run_refinement(project, hist, outdir, "01_background", {"Background": True}))
    history.append(run_refinement(project, hist, outdir, "02_scales", {"Scale": True}))
    # Correct the common Bragg-Brentano displacement, then individual cells.
    history.append(
        run_refinement(
            project,
            hist,
            outdir,
            "03_shift",
            {"Sample Parameters": ["Shift"]},
        )
    )
    history.append(run_refinement(project, hist, outdir, "04_cells", {"Cell": True}))
    # Instrument width, then phase-specific broadening.
    history.append(
        run_refinement(
            project,
            hist,
            outdir,
            "05_instrument",
            {"Instrument Parameters": ["U", "W", "X", "SH/L"]},
        )
    )
    history.append(
        run_refinement(
            project,
            hist,
            outdir,
            "06_size",
            {"Size": {"type": "isotropic", "refine": True}},
        )
    )
    history.append(
        run_refinement(
            project,
            hist,
            outdir,
            "07_mustrain",
            {"Mustrain": {"type": "isotropic", "refine": True}},
        )
    )
    # A separately refined zero is supported only after displacement and cells
    # are stable; the two have distinguishable angular dependence on this range.
    history.append(
        run_refinement(
            project,
            hist,
            outdir,
            "08_zero",
            {"Instrument Parameters": ["Zero"]},
        )
    )

    if args.coordinates:
        atom_flags = {"Atoms": {"all": "XU"}}
        history.append(run_refinement(project, hist, outdir, "09_coordinates", atom_flags))

    project.save(outdir / "refined.gpx")
    arrays = hist.data["data"][1]
    np.savetxt(
        outdir / "fit.csv",
        np.column_stack([arrays[0], arrays[1], arrays[3], arrays[5]]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
    )
    for phase in project.phases():
        phase.export_CIF(str(outdir / f"{phase.name}.cif"))
    (outdir / "history.json").write_text(json.dumps(history, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
