#!/usr/bin/env python3
"""Continue a GSAS-II refinement from a physical checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2

from refine_model import snapshot


HEAVY = {"Ba", "W"}


def set_atom_flags(project, heavy: str = "", light: str = "") -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = heavy if atom.element in HEAVY else light


def set_coordinate_bounds(project, limit: float = 0.015) -> None:
    for phase in project.phases():
        for i, atom in enumerate(phase.atoms()):
            if "X" not in atom.refinement_flags:
                continue
            for axis, value in zip("xyz", atom.coordinates):
                var = f"{phase.id}::dA{axis}:{i}"
                # GSAS-II refines dA shifts, but applies dA limits to the
                # corresponding absolute coordinate (Ax/Ay/Az).
                project.set_Controls("parmMin", float(value) - limit, variable=var)
                project.set_Controls("parmMax", float(value) + limit, variable=var)


def set_uiso_bounds(project, low: float = 0.001, high: float = 0.05) -> None:
    for phase in project.phases():
        for i, atom in enumerate(phase.atoms()):
            if "U" not in atom.refinement_flags:
                continue
            var = f"{phase.id}::AUiso:{i}"
            project.set_Controls("parmMin", low, variable=var)
            project.set_Controls("parmMax", high, variable=var)


def run(project, hist, outdir: Path, index: int, name: str) -> dict:
    project.set_Controls("cycles", 12)
    output = outdir / f"{index:02d}_{name}.gpx"
    project.save(output)
    project.refine(makeBack=False)
    state = snapshot(project, hist, name)
    state["atoms"] = {
        phase.name: [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(atom.coordinates),
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ]
        for phase in project.phases()
    }
    print(json.dumps(state, indent=2, default=float), flush=True)
    project.save(output)
    return state


def apply_stage(project, hist, stage: str, args) -> None:
    if stage == "heavy_xyz":
        set_atom_flags(project, heavy="X", light="")
        set_coordinate_bounds(project, args.coordinate_limit)
    elif stage == "light_xyz":
        set_atom_flags(project, heavy="", light="X")
        set_coordinate_bounds(project, args.coordinate_limit)
    elif stage == "all_xyz":
        set_atom_flags(project, heavy="X", light="X")
        set_coordinate_bounds(project, args.coordinate_limit)
    elif stage == "common_uiso":
        set_atom_flags(project, heavy="U", light="U")
        for phase in project.phases():
            atoms = phase.atoms()
            start = float(np.clip(np.mean([a.uiso for a in atoms]), 0.003, 0.02))
            for atom in atoms:
                atom.uiso = start
            variables = tuple(f"{phase.id}::AUiso:{i}" for i in range(len(atoms)))
            if len(variables) > 1:
                project.add_EquivConstr(variables)
        set_uiso_bounds(project, 0.001, 0.05)
    elif stage == "individual_uiso":
        set_atom_flags(project, heavy="U", light="U")
        set_uiso_bounds(project, 0.001, 0.05)
    elif stage == "cap_uiso":
        for phase in project.phases():
            for atom in phase.atoms():
                atom.uiso = float(np.clip(atom.uiso, 0.003, 0.02))
                atom.refinement_flags = ""
    elif stage == "polarization":
        set_atom_flags(project)
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.45, variable=f":{hist.id}:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=f":{hist.id}:Polariz.")
    elif stage == "roughness":
        set_atom_flags(project)
        hist.SampleParameters["SurfRoughA"][0] = args.rough_a
        hist.SampleParameters["SurfRoughB"][0] = args.rough_b
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        for key, lo, hi in (("SurfRoughA", 0.001, 0.8), ("SurfRoughB", 0.001, 0.8)):
            project.set_Controls("parmMin", lo, variable=f":{hist.id}:{key}")
            project.set_Controls("parmMax", hi, variable=f":{hist.id}:{key}")
    elif stage == "rough_b":
        set_atom_flags(project)
        hist.SampleParameters["SurfRoughA"] = [args.rough_a, False]
        hist.SampleParameters["SurfRoughB"] = [args.rough_b, True]
        project.set_Controls("parmMin", 0.02, variable=f":{hist.id}:SurfRoughB")
        project.set_Controls("parmMax", 0.5, variable=f":{hist.id}:SurfRoughB")
    elif stage.startswith("texture_"):
        set_atom_flags(project)
        # syntax: texture_PHASEINDEX_h_k_l
        parts = stage.split("_")
        phase_index = int(parts[1])
        axis = [int(v) for v in parts[2:5]]
        for phase in project.phases():
            phase.data["Histograms"][hist.name]["Pref.Ori."][2] = False
        phase = project.phase(phase_index)
        pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
        pref[0] = "MD"
        pref[1] = 1.0
        pref[2] = True
        pref[3] = axis
        project.set_Controls("parmMin", 0.5, variable=f"{phase.id}:{hist.id}:MD")
        project.set_Controls("parmMax", 2.0, variable=f"{phase.id}:{hist.id}:MD")
    elif stage.startswith("mustrain_"):
        set_atom_flags(project)
        # syntax: mustrain_PHASEINDEX_h_k_l
        parts = stage.split("_")
        phase_index = int(parts[1])
        axis = [int(v) for v in parts[2:5]]
        phase = project.phase(phase_index)
        hap = phase.data["Histograms"][hist.name]
        strain = hap["Mustrain"]
        start = max(0.0, float(strain[1][0]))
        strain[0] = "uniaxial"
        strain[1][0] = start
        strain[1][1] = start
        strain[2][0] = True
        strain[2][1] = True
        strain[3] = axis
        for suffix in ("i", "a"):
            project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;{suffix}")
            project.set_Controls("parmMax", 12000.0, variable=f"{phase.id}:{hist.id}:Mustrain;{suffix}")
    elif stage == "freeze_degenerate":
        set_atom_flags(project)
        hist.clear_refinements({"Instrument Parameters": ["Zero", "X"]})
    elif stage == "clean_controls":
        # Coordinate and common-U refinements were completed in bounded trial
        # branches.  Remove their now-unused equivalences and the list of
        # variables GSAS-II froze at coordinate limits, so the final fixed-
        # coordinate model replays without stale warnings.
        set_atom_flags(project)
        constraints = project.data["Constraints"]["data"]
        for key in ("Hist", "HAP", "Phase", "Global"):
            constraints[key] = []
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    elif stage == "physical_polish":
        set_atom_flags(project)
        instrument = hist.data["Instrument Parameters"][0]
        # U is constrained to be nonnegative for a physical Caglioti profile.
        # Freeze it at the boundary if a prior unconstrained branch crossed it.
        if float(instrument["U"][1]) < 0.0:
            instrument["U"][1] = 0.0
        hist.clear_refinements({"Instrument Parameters": ["U", "Zero", "X"]})
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            if hap["Size"][1][0] < 0.04:
                hap["Size"][1][0] = 0.04
                hap["Size"][2][0] = False
            if hap["Mustrain"][1][0] < 0.0:
                hap["Mustrain"][1][0] = 0.0
                hap["Mustrain"][2][0] = False
    elif stage == "polish":
        set_atom_flags(project)
    else:
        raise ValueError(f"unknown stage {stage!r}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--stages", required=True, help="comma-separated stage names")
    parser.add_argument("--coordinate-limit", type=float, default=0.015)
    parser.add_argument("--rough-a", type=float, default=0.2)
    parser.add_argument("--rough-b", type=float, default=0.1)
    args = parser.parse_args()

    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(args.input, newgpx=str(outdir / "continued.gpx"))
    hist = project.histogram(0)
    history = []
    for index, stage in enumerate(args.stages.split(","), start=1):
        apply_stage(project, hist, stage, args)
        history.append(run(project, hist, outdir, index, stage))
    final = outdir / "refined.gpx"
    project.save(final)
    arrays = hist.data["data"][1]
    np.savetxt(
        outdir / "fit.csv",
        np.column_stack([arrays[0], arrays[1], arrays[3], arrays[5]]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
    )
    for phase in project.phases():
        phase.export_CIF(str(outdir / f"{phase.name}.cif"))
    (outdir / "history.json").write_text(json.dumps(history, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
