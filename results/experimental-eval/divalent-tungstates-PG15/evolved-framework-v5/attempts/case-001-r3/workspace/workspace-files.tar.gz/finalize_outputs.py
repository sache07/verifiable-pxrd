#!/usr/bin/env python3
"""Export the selected, converged GSAS-II checkpoint as final deliverables."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "trial_231_clean" / "refined.gpx"


def main() -> None:
    final_path = ROOT / "final.gpx"
    project = G2.G2Project(str(SOURCE), newgpx=str(final_path))
    project.save(final_path)

    # Reload exactly what will be submitted; all exports and reported values
    # below therefore come from final.gpx rather than an in-memory precursor.
    project = G2.G2Project(str(final_path))
    hist = project.histogram(0)
    phases = project.phases()
    if [p.name for p in phases] != ["BaCO3", "WO3"]:
        raise RuntimeError("unexpected final phase inventory")

    arrays = hist.data["data"][1]
    x, yobs, ycalc, ydiff = arrays[0], arrays[1], arrays[3], arrays[5]
    original = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    if len(x) != len(original):
        raise RuntimeError("final project does not contain the full observed grid")
    if not np.allclose(x, original["two_theta_deg"], rtol=0.0, atol=2e-8):
        raise RuntimeError("final project grid differs from pattern.csv")
    if not np.array_equal(yobs, original["intensity"]):
        raise RuntimeError("final project observations differ from pattern.csv")
    if not np.allclose(ydiff, yobs - ycalc, rtol=0.0, atol=1e-10):
        raise RuntimeError("stored difference profile is inconsistent")

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, yobs, ycalc, ydiff]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        # Twelve significant digits preserve the supplied angular grid to
        # well below the 1e-7 degree replay tolerance.
        fmt="%.12g",
    )

    cif_names = {"BaCO3": "BaCO3.cif", "WO3": "WO3.cif"}
    for phase in phases:
        phase.export_CIF(str(ROOT / cif_names[phase.name]))

    fractions = hist.ComputeMassFracs()
    total = sum(float(v[0]) for v in fractions.values())
    if not np.isclose(total, 1.0, rtol=0.0, atol=1e-10):
        raise RuntimeError(f"mass fractions do not sum to one: {total}")

    rvals = project.data["Covariance"]["data"]["Rvals"]
    hstats = hist.data["data"][0]
    gof = float(rvals["GOF"])
    result = {
        "schema_version": 1,
        "refinement_histogram": hist.name,
        "fraction_basis": "modeled crystalline phases; normalized to sum to 1",
        "phases": [
            {
                "name": "BaCO3 (witherite)",
                "formula": "BaCO3",
                "space_group": "Pmcn (No. 62; equivalent Pnma setting)",
                "cif_path": cif_names["BaCO3"],
                "weight_fraction": float(fractions["BaCO3"][0]),
                "weight_fraction_esd": float(fractions["BaCO3"][1]),
                "reference": "COD 9010928",
            },
            {
                "name": "WO3 (monoclinic)",
                "formula": "WO3",
                "space_group": "P21/c (No. 14)",
                "cif_path": cif_names["WO3"],
                "weight_fraction": float(fractions["WO3"][0]),
                "weight_fraction_esd": float(fractions["WO3"][1]),
                "reference": "COD 2311041",
            },
        ],
        "fit_statistics": {
            "Rwp_percent": float(rvals["Rwp"]),
            "Rp_percent": float(hstats["R"]),
            "Rexp_percent": float(hstats["wRmin"]),
            "goodness_of_fit": gof,
            "chi_square": float(rvals["chisq"]),
            "reduced_chi_square": gof * gof,
            "observations": int(rvals["Nobs"]),
            "refined_variables": int(rvals["Nvars"]),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    # Save once more after CIF export so the submitted project is the exact
    # object from which the reported files were generated.
    project.save(final_path)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
