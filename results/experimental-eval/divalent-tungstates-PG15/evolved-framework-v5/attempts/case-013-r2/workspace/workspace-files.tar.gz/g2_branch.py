#!/usr/bin/env python3
"""Create and refine a trial GSAS-II multiphase powder model.

This is an analysis helper. It is run with the GSAS-II Python interpreter.
Candidate phases are supplied as ``name=/absolute/path/to/model.cif`` pairs.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def prepare_data(pattern_csv: Path, work: Path) -> tuple[Path, Path]:
    work.mkdir(parents=True, exist_ok=True)
    xye = work / "pattern.xye"
    inst = work / "instrument.instprm"

    with pattern_csv.open(newline="") as src, xye.open("w") as dst:
        rows = csv.DictReader(src)
        dst.write("# two_theta_deg intensity poisson_sigma\n")
        for row in rows:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.10f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")

    inst.write_text(
        "#GSAS-II instrument parameter file for lab CuKa data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def fit_summary(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    weight = np.asarray(hist.getdata("Yweight"), dtype=float)
    lo, hi = hist.data["Limits"][1]
    x = np.asarray(hist.getdata("X"), dtype=float)
    use = (x >= lo) & (x <= hi)
    resid = yobs - ycalc
    denom = float(np.sum(weight[use] * yobs[use] ** 2))
    rwp = 100.0 * math.sqrt(float(np.sum(weight[use] * resid[use] ** 2)) / denom)
    rp = 100.0 * float(np.sum(np.abs(resid[use]))) / float(np.sum(np.abs(yobs[use])))
    out = {
        "Rwp_percent_recomputed": rwp,
        "Rp_percent_recomputed": rp,
        "Rwp_percent_GSASII": hist.get_wR(),
        "limits_deg": [float(lo), float(hi)],
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items()
                       if isinstance(v, list) and len(v) >= 2},
        "sample": {k: (v[0] if isinstance(v, list) else v)
                   for k, v in hist.SampleParameters.items()},
        "phases": [],
    }
    scales = []
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        scale = float(hap["Scale"][0])
        mass = float(phase.data["General"].get("Mass", 0.0))
        scales.append(max(0.0, scale * mass))
        out["phases"].append({
            "name": phase.name,
            "scale": scale,
            "mass": mass,
            "cell": phase.get_cell(),
            "size": hap.get("Size"),
            "microstrain": hap.get("Mustrain"),
        })
    total = sum(scales)
    for rec, val in zip(out["phases"], scales):
        rec["weight_fraction"] = val / total if total else 0.0
    return out


def run_refinement(project: G2sc.G2Project, label: str, log: list[dict]) -> None:
    project.refine(makeBack=False)
    project.save()
    summary = fit_summary(project)
    summary["stage"] = label
    log.append(summary)
    print(f"STAGE {label}: Rwp={summary['Rwp_percent_recomputed']:.4f}%")
    for phase in summary["phases"]:
        print(
            f"  {phase['name']}: scale={phase['scale']:.6g}, "
            f"wt={phase['weight_fraction']:.5f}"
        )


def build(args: argparse.Namespace) -> None:
    output = Path(args.output).resolve()
    work = output.parent / (output.stem + "_work")
    xye, inst = prepare_data(Path(args.pattern).resolve(), work)
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(xye), str(inst), fmthint="xye"
    )
    hist.Limits("lower", 10.05)
    hist.Limits("upper", 99.90)
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"][0] = -575.0
    hist.SampleParameters["Scale"][0] = 1.0
    hist.SampleParameters["Scale"][1] = False
    # A flexible but smooth whole-range background.
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": args.background_terms,
            "coeffs": [650.0] + [0.0] * (args.background_terms - 1),
        }
    })

    for item in args.phase:
        name, cif = item.split("=", 1)
        phase = project.add_phase(
            str(Path(cif).resolve()), phasename=name, histograms=[hist], fmthint="CIF"
        )
        # Keep initial displacement parameters physical and comparable.
        for atom in phase.atoms():
            try:
                uiso = atom.uiso
            except Exception:
                # Retain valid anisotropic displacement tensors from a source.
                continue
            if uiso is None or not np.isfinite(uiso) or uiso <= 0:
                atom.uiso = 0.01
        hap = phase.getHAPvalues(hist)
        hap["Scale"][0] = 1.0
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0

    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    # Broad physical limits prevent a missing phase from being represented by
    # negative strain, negative scale, or a collapsed crystallite size.
    for pid, _phase in enumerate(project.phases()):
        project.set_Controls("parmMin", 0.0, f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.005, f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 10.0, f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 100000.0, f"{pid}:0:Mustrain;i")
    for variable, low, high in [
        (":0:U", 0.0, 1000.0),
        (":0:W", 0.0, 1000.0),
        (":0:X", 0.0, 100.0),
        (":0:SH/L", 0.001, 1.0),
        (":0:Zero", -1.0, 1.0),
        (":0:Shift", -2000.0, 2000.0),
    ]:
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)
    project.save()
    log: list[dict] = []

    # Scales and the empirical background establish a complete model first.
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])
    run_refinement(project, "scales_background", log)

    # Cells are close to the specimen values after the displacement seed.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run_refinement(project, "cells", log)

    # Resolve specimen height and angular zero on the full angular range.
    hist.set_refinements({
        "Sample Parameters": ["Shift"],
        "Instrument Parameters": ["Zero"],
    })
    run_refinement(project, "calibration", log)

    # Shared instrument broadening before phase-specific broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]})
    run_refinement(project, "instrument_profile", log)

    if args.phase_profile:
        for phase in project.phases():
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "value": 0.5, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }, [hist])
        run_refinement(project, "phase_profile", log)

    project.save()
    summary = fit_summary(project)
    (output.with_suffix(".summary.json")).write_text(
        json.dumps({"stages": log, "final": summary}, indent=2, default=float) + "\n"
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", default="inputs/pattern.csv")
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", action="append", required=True)
    parser.add_argument("--background-terms", type=int, default=16)
    parser.add_argument("--cycles", type=int, default=6)
    parser.add_argument("--phase-profile", action="store_true")
    return parser.parse_args()


if __name__ == "__main__":
    G2sc.SetPrintLevel("warn")
    build(parse_args())
