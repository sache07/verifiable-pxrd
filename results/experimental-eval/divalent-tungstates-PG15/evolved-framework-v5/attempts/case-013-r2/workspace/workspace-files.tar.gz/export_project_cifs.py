#!/usr/bin/env python3
"""Export all phases from a GSAS-II project to a selected directory."""

from __future__ import annotations

import re
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(gpxfile=sys.argv[1])
outdir = Path(sys.argv[2])
outdir.mkdir(parents=True, exist_ok=True)
for index, phase in enumerate(project.phases(), start=1):
    stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", phase.name).strip("_")
    path = outdir / f"{index:02d}_{stem}.cif"
    phase.export_CIF(str(path))
    print(path)
