#!/usr/bin/env python3
"""Print calculated reflections nearest selected observed residual maxima."""

from __future__ import annotations

import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(gpxfile=sys.argv[1])
hist = project.histogram(0)
targets = [float(v) for v in sys.argv[2:]]
for phase in project.phases():
    block = hist.data["Reflection Lists"].get(phase.name, {})
    refs = np.asarray(block.get("RefList", []), dtype=float)
    print(f"\n{phase.name} shape={refs.shape} Super={block.get('Super')} Type={block.get('Type')}")
    if not refs.size:
        continue
    # For ordinary powder reflections GSAS-II stores calculated 2theta in col. 5.
    for target in targets:
        order = np.argsort(np.abs(refs[:, 5] - target))[:3]
        desc = []
        for idx in order:
            row = refs[idx]
            desc.append(
                f"hkl=({int(row[0])},{int(row[1])},{int(row[2])}) "
                f"2th={row[5]:.4f} mult={row[3]:.0f} F2={row[9]:.2f}"
            )
        print(f"  target {target:.4f}: " + " | ".join(desc))
