#!/usr/bin/env python3
"""Replace the origin-misread litharge phase with a standard P4/nmm model."""

from __future__ import annotations

import argparse
import copy
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--cif", required=True)
    args = ap.parse_args()

    output = Path(args.output).resolve()
    project = G2sc.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    target = project.phase("litharge_PbO")
    old_cell = copy.deepcopy(target.data["General"]["Cell"])

    clean_gpx = output.with_name(output.stem + "_clean_import.gpx")
    clean_project = G2sc.G2Project(newgpx=str(clean_gpx))
    clean = clean_project.add_phase(
        str(Path(args.cif).resolve()), phasename="litharge_clean", fmthint="CIF"
    )

    target.data["General"] = copy.deepcopy(clean.data["General"])
    target.data["General"]["Name"] = "litharge_PbO"
    target.data["General"]["Cell"] = old_cell
    target.data["General"]["Cell"][0] = False
    target.data["Atoms"] = copy.deepcopy(clean.data["Atoms"])
    target.data["Drawing"] = copy.deepcopy(clean.data["Drawing"])

    # Re-seed the corrected phase profile; its previous scale/size described
    # the origin-misread structure and must not be carried as evidence.
    hist = project.histogram(0)
    hap = target.getHAPvalues(hist)
    hap["Scale"][0] = max(float(hap["Scale"][0]), 0.1)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.1
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.save()

    g = target.data["General"]
    print(g["SGData"]["SpGrp"], g["NoAtoms"], g["Mass"], g["Cell"])


if __name__ == "__main__":
    G2sc.SetPrintLevel("warn")
    main()
