#!/usr/bin/env python3
"""Report simple interatomic-distance checks for exported CIFs."""

from __future__ import annotations

import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
from pymatgen.core import Structure


for filename in sys.argv[1:]:
    path = Path(filename)
    structure = Structure.from_file(path, primitive=False)
    print(f"\n{path}: formula={structure.composition.reduced_formula} sites={len(structure)}")
    matrix = structure.distance_matrix.copy()
    np.fill_diagonal(matrix, np.inf)
    idx = np.unravel_index(np.argmin(matrix), matrix.shape)
    print(
        f"  shortest={matrix[idx]:.4f} A "
        f"({structure[idx[0]].specie.symbol}-{structure[idx[1]].specie.symbol})"
    )
    bonds: dict[str, list[float]] = defaultdict(list)
    for i, site in enumerate(structure):
        el = site.specie.symbol
        if el not in {"Pb", "W", "Mo"}:
            continue
        distances = sorted(
            structure.get_distance(i, j)
            for j, other in enumerate(structure)
            if other.specie.symbol == "O"
        )
        near = [d for d in distances if d <= (2.35 if el in {"W", "Mo"} else 3.25)]
        bonds[el].extend(near)
    for element, distances in bonds.items():
        values = np.asarray(distances)
        print(
            f"  {element}-O selected: n={len(values)} "
            f"range={values.min():.4f}-{values.max():.4f} A "
            f"median={np.median(values):.4f} A"
        )
