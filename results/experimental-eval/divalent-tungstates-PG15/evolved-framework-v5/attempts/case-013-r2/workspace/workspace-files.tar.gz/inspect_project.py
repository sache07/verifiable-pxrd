#!/usr/bin/env python3
"""Compact inspection of a GSAS-II project used during refinement."""

from __future__ import annotations

import sys

from GSASII import GSASIIscriptable as G2sc


p = G2sc.G2Project(gpxfile=sys.argv[1])
h = p.histogram(0)
print("histogram", h.name, "Rwp", h.get_wR())
print("background", h.data["Background"][0])
print("instrument")
for key, val in h.InstrumentParameters.items():
    if isinstance(val, list) and len(val) >= 3:
        print(" ", key, val)
print("sample")
for key, val in h.SampleParameters.items():
    if isinstance(val, list):
        print(" ", key, val)
for phase in p.phases():
    print("\nPHASE", phase.name, phase.data["General"]["SGData"]["SpGrp"], phase.get_cell())
    print(" HAP", phase.getHAPvalues(h))
    for atom in phase.atoms():
        print(
            " ", atom.label, atom.element, atom.coordinates,
            "occ", atom.occupancy, "Uiso", atom.uiso,
            "flags", repr(atom.refinement_flags),
        )
