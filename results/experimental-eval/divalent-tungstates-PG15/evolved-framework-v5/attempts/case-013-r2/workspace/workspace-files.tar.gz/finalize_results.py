#!/usr/bin/env python3
"""Create the requested deliverables from the accepted GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PHASE_INFO = {
    "scheelite_PbWO4": {
        "name": "PbWO4 (scheelite)",
        "formula": "PbWO4",
        "cif": "phase_1_PbWO4_scheelite.cif",
        "provenance": "exact-composition COD 9009811",
    },
    "Pb2WO5": {
        "name": "Pb2WO5 (monoclinic prototype)",
        "formula": "Pb2WO5",
        "cif": "phase_2_Pb2WO5_monoclinic.cif",
        "provenance": "Pb2MoO5 COD 7220560 prototype with Mo replaced by W",
    },
    "Pb3WO6": {
        "name": "Pb3WO6 (monoclinic prototype)",
        "formula": "Pb3WO6",
        "cif": "phase_3_Pb3WO6_monoclinic.cif",
        "provenance": "Ca3WO6 COD 1563081 prototype with Ca replaced by Pb",
    },
    "massicot_PbO": {
        "name": "PbO (massicot)",
        "formula": "PbO",
        "cif": "phase_4_PbO_massicot.cif",
        "provenance": "exact-composition COD 2310433",
    },
    "litharge_PbO": {
        "name": "PbO (litharge)",
        "formula": "PbO",
        "cif": "phase_5_PbO_litharge.cif",
        "provenance": "exact-composition COD 9012700 transformed to standard P4/nmm origin",
    },
    "monoclinic_WO3": {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif": "phase_6_WO3_monoclinic.cif",
        "provenance": "exact-composition COD 2311041",
    },
}


def fraction_esds(project: G2sc.G2Project, scales: np.ndarray, masses: np.ndarray) -> np.ndarray:
    """Propagate the final scale covariance into normalized weight fractions."""
    covdata = project["Covariance"]["data"]
    vary = list(covdata.get("varyList", []))
    covariance = np.asarray(covdata.get("covMatrix"), dtype=float)
    if covariance.shape != (len(vary), len(vary)):
        return np.full(len(scales), np.nan)
    total = float(np.dot(scales, masses))
    jac = np.zeros((len(scales), len(vary)))
    for j in range(len(scales)):
        variable = f"{j}:0:Scale"
        if variable not in vary:
            continue
        k = vary.index(variable)
        for i in range(len(scales)):
            numerator = masses[i] * (total if i == j else 0.0)
            numerator -= scales[i] * masses[i] * masses[j]
            jac[i, k] = numerator / total**2
    variance = np.diag(jac @ covariance @ jac.T)
    return np.sqrt(np.maximum(variance, 0.0))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output-dir", default=".")
    args = ap.parse_args()

    outdir = Path(args.output_dir).resolve()
    final_gpx = outdir / "final.gpx"
    project = G2sc.G2Project(
        gpxfile=str(Path(args.input).resolve()), newgpx=str(final_gpx)
    )
    project.data["Controls"]["data"]["Author"] = "Powder XRD multiphase refinement"
    project.save()
    hist = project.histogram(0)

    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    weight = np.asarray(hist.getdata("Yweight"), dtype=float)
    difference = yobs - ycalc

    with (outdir / "fit.csv").open("w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        writer.writerows(
            zip(
                (f"{v:.8f}" for v in x),
                (f"{v:.8f}" for v in yobs),
                (f"{v:.8f}" for v in ycalc),
                (f"{v:.8f}" for v in difference),
                (f"{v:.8f}" for v in background),
            )
        )

    phases = project.phases()
    scales = np.asarray(
        [float(phase.getHAPvalues(hist)["Scale"][0]) for phase in phases]
    )
    masses = np.asarray([float(phase.data["General"]["Mass"]) for phase in phases])
    amounts = scales * masses
    fractions = amounts / amounts.sum()
    fraction_sigmas = fraction_esds(project, scales, masses)

    phase_results = []
    for i, (phase, fraction, sigma) in enumerate(
        zip(phases, fractions, fraction_sigmas)
    ):
        info = PHASE_INFO[phase.name]
        cif_path = outdir / info["cif"]
        phase.export_CIF(str(cif_path))
        cell, cell_esd = phase.get_cell_and_esd()
        hap = phase.getHAPvalues(hist)
        phase_results.append(
            {
                "name": info["name"],
                "phase_label_in_gpx": phase.name,
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": info["cif"],
                "weight_fraction": float(fraction),
                "weight_percent": float(100.0 * fraction),
                "weight_fraction_formal_esd": float(sigma),
                "cell": {k: float(v) for k, v in cell.items()},
                "cell_formal_esd": {k: float(v) for k, v in cell_esd.items()},
                "profile": {
                    "isotropic_size_micrometre": float(hap["Size"][1][0]),
                    "isotropic_microstrain": float(hap["Mustrain"][1][0]),
                },
                "model_provenance": info["provenance"],
            }
        )

    covstats = project["Covariance"]["data"].get("Rvals", {})
    nobs = int(covstats.get("Nobs", len(x)))
    nvars = int(covstats.get("Nvars", len(project["Covariance"]["data"].get("varyList", []))))
    dof = nobs - nvars
    chisq = float(np.sum(weight * difference**2))
    denominator = float(np.sum(weight * yobs**2))
    rwp = 100.0 * math.sqrt(chisq / denominator)
    rp = 100.0 * float(np.sum(np.abs(difference))) / float(np.sum(np.abs(yobs)))
    gof = math.sqrt(chisq / dof)
    rexp = 100.0 * math.sqrt(dof / denominator)
    result = {
        "phases": phase_results,
        "fraction_normalization": "Normalized over the six modeled crystalline phases; amorphous content was not quantified.",
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": rexp,
            "goodness_of_fit": gof,
            "chi_square": chisq,
            "n_observations": nobs,
            "n_refined_parameters": nvars,
            "degrees_of_freedom": dof,
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
            "weighting": "Poisson approximation: sigma=sqrt(max(observed_counts,1))",
        },
        "refinement_project": "final.gpx",
        "fit_profile": "fit.csv",
    }
    (outdir / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    G2sc.SetPrintLevel("warn")
    main()
