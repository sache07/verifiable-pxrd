#!/usr/bin/env python3
"""Fast whole-pattern screen of frozen-COD candidates against a GSAS residual."""

from __future__ import annotations

import gzip
import json
import os
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import differential_evolution


PROFILE = Path(os.environ.get(
    "PXRD_PROFILE", ".tmp/branches/ordinary_bounded_profile.csv"
))
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
COD_INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")
LAMBDA1 = 1.540598
LAMBDA2 = 1.544426


def cod_path(code: str) -> Path:
    return COD_ROOT / code[0] / code[1:3] / code[3:5] / f"{code}.cif"


def make_profile(x: np.ndarray, peaks: np.ndarray, intens: np.ndarray,
                 lattice_scale: float, zero: float, displacement: float,
                 fwhm: float) -> np.ndarray:
    # Convert reference Cu K-alpha1 angles to d, apply isotropic lattice scale,
    # then form the K-alpha1/K-alpha2 doublet and a physical angle correction.
    d0 = LAMBDA1 / (2.0 * np.sin(np.radians(peaks / 2.0)))
    d = d0 * lattice_scale
    profiles = np.zeros_like(x)
    for lam, ratio in ((LAMBDA1, 1.0), (LAMBDA2, 0.5)):
        valid = lam / (2.0 * d) < 1.0
        pos = np.degrees(2.0 * np.arcsin(lam / (2.0 * d[valid])))
        pos += zero + displacement * np.cos(np.radians(pos / 2.0))
        inten = ratio * intens[valid]
        q = (pos - x[0]) / (x[1] - x[0])
        i0 = np.floor(q).astype(int)
        frac = q - i0
        good = (i0 >= 0) & (i0 + 1 < len(x))
        np.add.at(profiles, i0[good], inten[good] * (1.0 - frac[good]))
        np.add.at(profiles, i0[good] + 1, inten[good] * frac[good])
    sigma_pts = fwhm / (2.0 * np.sqrt(2.0 * np.log(2.0))) / (x[1] - x[0])
    return gaussian_filter1d(profiles, sigma_pts, mode="constant")


def screen(code: str, formula: str, x: np.ndarray, residual: np.ndarray,
           weight: np.ndarray) -> dict | None:
    try:
        structure = CifParser(cod_path(code), occupancy_tolerance=10).parse_structures(
            primitive=False
        )[0]
        pattern = XRDCalculator(wavelength=LAMBDA1).get_pattern(
            structure, scaled=False, two_theta_range=(9.0, 101.0)
        )
    except Exception as exc:
        return {"code": code, "formula": formula, "error": f"{type(exc).__name__}: {exc}"}
    peaks = np.asarray(pattern.x, dtype=float)
    intens = np.asarray(pattern.y, dtype=float)
    if not len(peaks) or not np.all(np.isfinite(intens)):
        return None
    intens /= max(float(np.max(intens)), 1.0)
    base = float(np.sum(weight * residual**2))

    def objective(params: np.ndarray) -> float:
        g = make_profile(x, peaks, intens, *params)
        den = float(np.sum(weight * g * g))
        amp = max(0.0, float(np.sum(weight * g * residual)) / den) if den else 0.0
        return float(np.sum(weight * (residual - amp * g) ** 2))

    result = differential_evolution(
        objective,
        bounds=[(0.96, 1.04), (-0.5, 0.5), (-0.6, 0.6), (0.06, 0.5)],
        popsize=10,
        maxiter=50,
        polish=True,
        seed=int(code[-6:]),
        workers=1,
    )
    g = make_profile(x, peaks, intens, *result.x)
    den = float(np.sum(weight * g * g))
    amp = max(0.0, float(np.sum(weight * g * residual)) / den) if den else 0.0
    return {
        "code": code,
        "formula": formula,
        "space_group": structure.get_space_group_info(),
        "delta_chisq": base - float(result.fun),
        "fraction_residual_chisq_removed": (base - float(result.fun)) / base,
        "amplitude": amp,
        "lattice_scale": float(result.x[0]),
        "zero_deg": float(result.x[1]),
        "displacement_like_deg": float(result.x[2]),
        "fwhm_deg": float(result.x[3]),
    }


def main() -> None:
    a = np.genfromtxt(PROFILE, delimiter=",", names=True)
    x = np.asarray(a["x"])
    residual = np.asarray(a["residual"])
    weight = np.asarray(a["weight"])
    use = (x >= 10.05) & (x <= 99.9)
    x, residual, weight = x[use], residual[use], weight[use]
    with gzip.open(COD_INDEX, "rt") as stream:
        index = json.load(stream)
    records = []
    for key in ("O-Pb-W", "O-Pb", "O-W"):
        records.extend(index.get(key, []))
    out = []
    for formula, code, _sg, _r in records:
        rec = screen(code, formula, x, residual, weight)
        if rec:
            out.append(rec)
            print(json.dumps(rec, default=list), flush=True)
    out.sort(key=lambda item: item.get("delta_chisq", -1), reverse=True)
    Path(".tmp/branches/candidate_screen.json").write_text(
        json.dumps(out, indent=2, default=list) + "\n"
    )


if __name__ == "__main__":
    main()
