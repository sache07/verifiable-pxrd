#!/usr/bin/env python3
"""Screen a small chemistry-supported analogue set against the residual."""

from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser
from scipy.optimize import differential_evolution

from screen_candidates import COD_ROOT, LAMBDA1, make_profile


PROFILE = Path(os.environ.get(
    "PXRD_PROFILE", ".tmp/branches/ordinary_plus_litharge_profile.csv"
))

# Exact Pb-(Mo/Te/Cr)-O analogues and selected A-W-O intermediate frameworks.
CODES = [
    "7220560", "2007541", "9015570", "2002145", "8103050", "3500065",
    "1563081", "2311977", "1533878", "1534803", "1527404", "2002403",
    "5910316", "2002703", "2310464", "1528730", "1528731", "1567271",
    "2107328", "2108252", "7213033", "7230340",
]


def cod_path(code: str) -> Path:
    return COD_ROOT / code[0] / code[1:3] / code[3:5] / f"{code}.cif"


def adapted_structure(code: str):
    structure = CifParser(cod_path(code), occupancy_tolerance=10).parse_structures(
        primitive=False
    )[0]
    mapping = {}
    for specie in structure.composition.elements:
        symbol = specie.symbol
        if symbol in {"O", "Pb", "W"}:
            continue
        # Pb-X-O entries transfer X->W; A-W-O entries transfer A->Pb.
        mapping[symbol] = "W" if "Pb" in structure.composition else "Pb"
    if mapping:
        structure.replace_species(mapping)
    return structure, mapping


def main() -> None:
    data = np.genfromtxt(PROFILE, delimiter=",", names=True)
    use = (data["x"] >= 10.05) & (data["x"] <= 99.9)
    x = np.asarray(data["x"][use])
    residual = np.asarray(data["residual"][use])
    weight = np.asarray(data["weight"][use])
    base = float(np.sum(weight * residual**2))
    results = []
    for code in CODES:
        try:
            structure, mapping = adapted_structure(code)
            pattern = XRDCalculator(wavelength=LAMBDA1).get_pattern(
                structure, scaled=False, two_theta_range=(9.0, 101.0)
            )
            peaks = np.asarray(pattern.x)
            intens = np.asarray(pattern.y)
            intens /= max(float(np.max(intens)), 1.0)

            def objective(params):
                g = make_profile(x, peaks, intens, *params)
                den = float(np.sum(weight * g * g))
                amp = max(0.0, float(np.sum(weight * g * residual)) / den) if den else 0.0
                return float(np.sum(weight * (residual - amp * g) ** 2))

            fit = differential_evolution(
                objective,
                bounds=[(0.85, 1.15), (-0.5, 0.5), (-0.6, 0.6), (0.06, 0.5)],
                maxiter=70,
                popsize=12,
                polish=True,
                seed=int(code[-6:]),
            )
            g = make_profile(x, peaks, intens, *fit.x)
            den = float(np.sum(weight * g * g))
            amp = max(0.0, float(np.sum(weight * g * residual)) / den) if den else 0.0
            rec = {
                "code": code,
                "parent_formula": str(CifParser(cod_path(code), occupancy_tolerance=10)
                                      .parse_structures(primitive=False)[0].composition.reduced_formula),
                "target_formula": str(structure.composition.reduced_formula),
                "mapping": mapping,
                "space_group": structure.get_space_group_info(),
                "delta_chisq": base - float(fit.fun),
                "fraction_residual_chisq_removed": (base - float(fit.fun)) / base,
                "amplitude": amp,
                "lattice_scale": float(fit.x[0]),
                "zero_deg": float(fit.x[1]),
                "displacement_like_deg": float(fit.x[2]),
                "fwhm_deg": float(fit.x[3]),
            }
        except Exception as exc:
            rec = {"code": code, "error": f"{type(exc).__name__}: {exc}"}
        results.append(rec)
        print(json.dumps(rec, default=list), flush=True)
    results.sort(key=lambda item: item.get("delta_chisq", -1), reverse=True)
    Path(".tmp/branches/analogue_screen.json").write_text(
        json.dumps(results, indent=2, default=list) + "\n"
    )


if __name__ == "__main__":
    main()
