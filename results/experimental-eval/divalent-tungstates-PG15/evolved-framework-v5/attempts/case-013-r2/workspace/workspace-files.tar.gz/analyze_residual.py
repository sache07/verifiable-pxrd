#!/usr/bin/env python3
"""List the strongest signed residual features and nearby phase reflections."""

from __future__ import annotations

import sys

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks, peak_prominences
from GSASII import GSASIIscriptable as G2sc


p = G2sc.G2Project(gpxfile=sys.argv[1])
h = p.histogram(0)
x = np.asarray(h.getdata("X"), dtype=float)
r = np.asarray(h.getdata("Yobs"), dtype=float) - np.asarray(h.getdata("Ycalc"), dtype=float)
s = gaussian_filter1d(r, 1.2)

features = []
for sign in (1, -1):
    peaks, _ = find_peaks(sign * s, prominence=80, distance=4)
    prom = peak_prominences(sign * s, peaks)[0]
    features.extend((float(v), sign, int(i)) for i, v in zip(peaks, prom))

for prominence, sign, i in sorted(features, reverse=True)[:60]:
    matches = []
    for phase in p.phases():
        refs = np.asarray(h.data["Reflection Lists"][phase.name]["RefList"], dtype=float)
        close = np.where(np.abs(refs[:, 5] - x[i]) <= 0.12)[0]
        for j in close:
            row = refs[j]
            matches.append(
                (float(row[9]), phase.name, tuple(int(v) for v in row[:3]), float(row[5]))
            )
    desc = "; ".join(
        f"{name} {hkl}@{pos:.3f} F2={f2:.0f}"
        for f2, name, hkl, pos in sorted(matches, reverse=True)[:4]
    )
    print(
        f"{x[i]:8.4f} residual={r[i]:9.1f} smooth={s[i]:9.1f} "
        f"prom={prominence:8.1f} sign={'+' if sign > 0 else '-'} | {desc}"
    )
