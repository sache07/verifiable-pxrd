#!/usr/bin/env python3
"""Run one bounded GSAS-II refinement step from an accepted checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from g2_branch import fit_summary


def clear_all(project: G2sc.G2Project) -> None:
    """Clear vary flags while retaining all parameter values."""
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist.data["Background"][0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": False,
                "Size": False,
                "Mustrain": False,
                "Pref.Ori.": False,
                "HStrain": False,
            },
            [hist],
        )
        hap = phase.getHAPvalues(hist)
        hap["Extinction"][1] = False
        for value in hap["Babinet"].values():
            value[1] = False


def set_common(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for pid, phase in enumerate(project.phases()):
        phase.set_HAP_refinements({"Scale": True}, [hist])
        project.set_Controls("parmMin", 0.0, f"{pid}:0:Scale")


def set_coordinate_bounds(
    project: G2sc.G2Project, pid: int, atom_index: int, xyz: tuple[float, float, float], delta: float
) -> None:
    # GSAS-II varies symmetry-aware coordinate displacements (dAx/dAy/dAz),
    # which are zero at the start of each refinement step.
    if delta <= 0:
        return
    for axis in "xyz":
        project.set_Controls("parmMin", -delta, f"{pid}::dA{axis}:{atom_index}")
        project.set_Controls("parmMax", delta, f"{pid}::dA{axis}:{atom_index}")


def configure(project: G2sc.G2Project, args: argparse.Namespace) -> None:
    hist = project.histogram(0)
    selected = set(args.phase or [phase.name for phase in project.phases()])

    if args.mode in {"heavy", "oxygen"}:
        for pid, phase in enumerate(project.phases()):
            if phase.name not in selected:
                continue
            for atom_index, atom in enumerate(phase.atoms()):
                is_oxygen = atom.element == "O"
                if (args.mode == "oxygen") != is_oxygen:
                    continue
                set_coordinate_bounds(project, pid, atom_index, atom.coordinates, args.coordinate_delta)
                atom.refinement_flags = "X"
    elif args.mode == "size":
        for pid, phase in enumerate(project.phases()):
            if phase.name not in selected:
                continue
            hap = phase.getHAPvalues(hist)
            value = (
                float(args.start_value)
                if args.start_value is not None
                else float(hap["Size"][1][0])
            )
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": value, "refine": True}}, [hist]
            )
            project.set_Controls("parmMin", 0.005, f"{pid}:0:Size;i")
            project.set_Controls("parmMax", 10.0, f"{pid}:0:Size;i")
    elif args.mode == "mustrain":
        for pid, phase in enumerate(project.phases()):
            if phase.name not in selected:
                continue
            if args.start_value is not None:
                phase.getHAPvalues(hist)["Mustrain"][1][0] = float(args.start_value)
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
            )
            project.set_Controls("parmMin", 0.0, f"{pid}:0:Mustrain;i")
            project.set_Controls("parmMax", 100000.0, f"{pid}:0:Mustrain;i")
    elif args.mode == "orientation":
        if len(selected) != 1 or args.hkl is None:
            raise ValueError("orientation requires one --phase and --hkl h k l")
        for pid, phase in enumerate(project.phases()):
            if phase.name not in selected:
                continue
            pref = phase.getHAPvalues(hist)["Pref.Ori."]
            pref[0] = "MD"
            pref[1] = 1.0
            pref[3] = list(args.hkl)
            phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
            project.set_Controls("parmMin", 0.5, f"{pid}:0:MD")
            project.set_Controls("parmMax", 2.0, f"{pid}:0:MD")
    elif args.mode in {"cell_calibration", "cell_shift", "cell_zero"}:
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
        if args.mode == "cell_calibration":
            hist.set_refinements(
                {"Sample Parameters": ["Shift"], "Instrument Parameters": ["Zero"]}
            )
        elif args.mode == "cell_shift":
            hist.InstrumentParameters["Zero"][1] = 0.0
            hist.set_refinements({"Sample Parameters": ["Shift"]})
        else:
            hist.SampleParameters["Shift"][0] = 0.0
            hist.set_refinements({"Instrument Parameters": ["Zero"]})
        project.set_Controls("parmMin", -1.0, ":0:Zero")
        project.set_Controls("parmMax", 1.0, ":0:Zero")
        project.set_Controls("parmMin", -2000.0, ":0:Shift")
        project.set_Controls("parmMax", 2000.0, ":0:Shift")
    elif args.mode in {"instrument", "instrument_reset"}:
        if args.mode == "instrument_reset":
            for phase in project.phases():
                hap = phase.getHAPvalues(hist)
                hap["Size"][0] = "isotropic"
                hap["Size"][1][0] = 10.0
                hap["Mustrain"][0] = "isotropic"
                hap["Mustrain"][1][0] = 0.0
        hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]})
        for variable, low, high in [
            (":0:U", 0.0, 1000.0),
            (":0:W", 0.0, 1000.0),
            (":0:X", 0.0, 100.0),
            (":0:SH/L", 0.001, 1.0),
        ]:
            project.set_Controls("parmMin", low, variable)
            project.set_Controls("parmMax", high, variable)
    elif args.mode == "surface":
        hist.SampleParameters["SurfRoughA"][0] = 0.05
        hist.SampleParameters["SurfRoughB"][0] = 0.05
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        for name in ["SurfRoughA", "SurfRoughB"]:
            project.set_Controls("parmMin", 0.0, f":0:{name}")
            project.set_Controls("parmMax", 1.0, f":0:{name}")
    elif args.mode == "surface_b":
        hist.SampleParameters["SurfRoughA"][0] = 0.0
        hist.SampleParameters["SurfRoughB"][0] = (
            float(args.start_value) if args.start_value is not None else 0.01
        )
        hist.set_refinements({"Sample Parameters": ["SurfRoughB"]})
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
        project.set_Controls("parmMax", 1.0, ":0:SurfRoughB")
    elif args.mode == "transparency":
        hist.SampleParameters["Transparency"][0] = (
            float(args.start_value) if args.start_value is not None else 0.001
        )
        hist.set_refinements({"Sample Parameters": ["Transparency"]})
        project.set_Controls("parmMin", 0.0, ":0:Transparency")
        project.set_Controls("parmMax", 1.0, ":0:Transparency")
    elif args.mode == "profile_accepted":
        size_names = {"massicot_PbO", "litharge_PbO"}
        for pid, phase in enumerate(project.phases()):
            if phase.name in size_names:
                phase.set_HAP_refinements(
                    {"Size": {"type": "isotropic", "refine": True}}, [hist]
                )
                project.set_Controls("parmMin", 0.005, f"{pid}:0:Size;i")
                project.set_Controls("parmMax", 10.0, f"{pid}:0:Size;i")
            if phase.name == "Pb3WO6":
                phase.getHAPvalues(hist)["Size"][1][0] = 10.0
                phase.set_HAP_refinements(
                    {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
                )
                project.set_Controls("parmMin", 0.0, f"{pid}:0:Mustrain;i")
                project.set_Controls("parmMax", 100000.0, f"{pid}:0:Mustrain;i")
    elif args.mode == "global_final":
        # Submit a full-grid checkpoint, including the few edge points that
        # were omitted during exploratory stabilization.
        hist.data["Limits"][1][:] = hist.data["Limits"][0][:]
        hist.InstrumentParameters["Zero"][1] = 0.0
        hist.SampleParameters["SurfRoughA"][0] = 0.0
        hist.set_refinements(
            {
                "Sample Parameters": ["Shift", "SurfRoughB"],
                "Instrument Parameters": ["U", "V", "W", "X", "SH/L"],
            }
        )
        project.set_Controls("parmMin", -2000.0, ":0:Shift")
        project.set_Controls("parmMax", 2000.0, ":0:Shift")
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
        project.set_Controls("parmMax", 1.0, ":0:SurfRoughB")
        for variable, low, high in [
            (":0:U", 0.0, 1000.0),
            (":0:W", 0.0, 1000.0),
            (":0:X", 0.0, 100.0),
            (":0:SH/L", 0.001, 1.0),
        ]:
            project.set_Controls("parmMin", low, variable)
            project.set_Controls("parmMax", high, variable)
        size_names = {"massicot_PbO", "litharge_PbO"}
        for pid, phase in enumerate(project.phases()):
            phase.set_refinements({"Cell": True})
            if phase.name in size_names:
                phase.set_HAP_refinements(
                    {"Size": {"type": "isotropic", "refine": True}}, [hist]
                )
                project.set_Controls("parmMin", 0.005, f"{pid}:0:Size;i")
                project.set_Controls("parmMax", 10.0, f"{pid}:0:Size;i")
            if phase.name == "Pb3WO6":
                phase.getHAPvalues(hist)["Size"][1][0] = 10.0
                phase.set_HAP_refinements(
                    {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
                )
                project.set_Controls("parmMin", 0.0, f"{pid}:0:Mustrain;i")
                project.set_Controls("parmMax", 100000.0, f"{pid}:0:Mustrain;i")
    else:
        raise ValueError(args.mode)


def main(args: argparse.Namespace) -> None:
    output = Path(args.output).resolve()
    project = G2sc.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    before = fit_summary(project)
    clear_all(project)
    set_common(project)
    configure(project, args)
    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.save()
    project.refine(makeBack=False)
    project.save()
    after = fit_summary(project)
    report = {
        "mode": args.mode,
        "selected_phases": args.phase,
        "hkl": args.hkl,
        "before": before,
        "after": after,
        "atoms": {
            phase.name: [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": atom.coordinates,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ]
            for phase in project.phases()
        },
    }
    output.with_suffix(".step.json").write_text(json.dumps(report, indent=2, default=float) + "\n")
    print(
        f"{args.mode}: Rwp {before['Rwp_percent_recomputed']:.6f} -> "
        f"{after['Rwp_percent_recomputed']:.6f}"
    )
    for phase in after["phases"]:
        print(
            f"  {phase['name']}: wt={phase['weight_fraction']:.6f} "
            f"size={phase['size']} strain={phase['microstrain']}"
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument(
        "--mode",
        required=True,
        choices=[
            "heavy",
            "oxygen",
            "size",
            "mustrain",
            "orientation",
            "cell_calibration",
            "cell_shift",
            "cell_zero",
            "instrument",
            "instrument_reset",
            "surface",
            "surface_b",
            "transparency",
            "profile_accepted",
            "global_final",
        ],
    )
    parser.add_argument("--phase", action="append")
    parser.add_argument("--hkl", nargs=3, type=int)
    parser.add_argument("--coordinate-delta", type=float, default=0.03)
    parser.add_argument("--start-value", type=float)
    parser.add_argument("--cycles", type=int, default=8)
    return parser.parse_args()


if __name__ == "__main__":
    G2sc.SetPrintLevel("warn")
    main(parse_args())
