#!/usr/bin/env python3
"""Extend the accepted checkpoint to every measured grid point."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent


def main() -> None:
    project = G2sc.G2Project(str(WORK / "fullgrid_checkpoint.gpx"))
    project.index_ids()
    hist = project.histogram(0)
    x = hist.data["data"][1][0]
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]

    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["max cyc"] = 25
    controls["min dM/M"] = 1.0e-6

    project.save(str(WORK / "fullgrid_replay_start.gpx"))
    project.do_refinements(
        [{}], outputnames=[str(WORK / "fullgrid_replay.gpx")]
    )

    hist = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    data = hist.data["data"][1]
    print("limits", hist.data["Limits"])
    print("edge_ycalc", data[3, :3], data[3, -3:])
    print("Rwp", hist.get_wR())
    print("GOF", covariance["Rvals"].get("GOF"))
    print("Rvals", covariance["Rvals"])
    print("fractions", hist.ComputeMassFracs())
    print("frozen", controls.get("parmFrozen"))


if __name__ == "__main__":
    main()
