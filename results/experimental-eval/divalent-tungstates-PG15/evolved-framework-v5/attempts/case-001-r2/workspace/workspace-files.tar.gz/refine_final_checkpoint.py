#!/usr/bin/env python3
"""Replay the accepted physical model with weak structural terms fixed."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent


def main() -> None:
    project = G2sc.G2Project(str(WORK / "uiso_common.gpx"))
    project.index_ids()
    hist = project.histogram(0)

    # Preserve the physically screened coordinate/Uiso checkpoint, while
    # refining only parameters robustly determined by this powder profile.
    for phase in project.phases():
        for atom in phase.data["Atoms"]:
            atom[2] = ""

    constraints = project.data["Constraints"]["data"]
    for scope in ("Hist", "HAP", "Phase", "Global"):
        constraints[scope] = []

    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["max cyc"] = 25
    controls["min dM/M"] = 1.0e-6

    # Boundary/gauge parameters are constants in the submitted model.
    inst = hist.data["Instrument Parameters"][0]
    for name in ("Polariz.", "U", "X", "SH/L", "Zero"):
        inst[name][2] = False
    hist.data["Sample Parameters"]["SurfRoughA"][1] = False

    project.save(str(WORK / "final_checkpoint_start.gpx"))
    project.do_refinements(
        [{}], outputnames=[str(WORK / "final_checkpoint.gpx")]
    )

    hist = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    print("Rwp", hist.get_wR())
    print("GOF", covariance["Rvals"].get("GOF"))
    print("Rvals", covariance["Rvals"])
    print("fractions", hist.ComputeMassFracs())
    print("frozen", controls.get("parmFrozen"))
    print("vary", covariance.get("varyList"))
    for phase in project.phases():
        print(phase.name, phase.get_cell())
        print("atoms", [(a[0], a[3:6], a[10], a[2]) for a in phase.data["Atoms"]])
        print("HAP", phase.data["Histograms"][hist.name])


if __name__ == "__main__":
    main()
