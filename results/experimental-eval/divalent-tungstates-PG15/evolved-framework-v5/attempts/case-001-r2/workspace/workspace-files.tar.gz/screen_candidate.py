#!/usr/bin/env python3
"""Build the same conservative two-phase GSAS-II checkpoint for a WO3 candidate."""

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main(cod_id: str) -> None:
    stem = f"screen_wo3_{cod_id}"
    project = G2sc.G2Project(newgpx=str(WORK / f"{stem}_0.gpx"))
    hist = project.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"), str(WORK / "instrument.instprm")
    )
    project.add_phase(
        str(cod_cif("9010928")), phasename="BaCO3", histograms=[hist], fmthint="CIF"
    )
    project.add_phase(
        str(cod_cif(cod_id)), phasename="WO3", histograms=[hist], fmthint="CIF"
    )

    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [-550.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {
        "U": 20.0,
        "V": 0.0,
        "W": 20.0,
        "X": 2.0,
        "Y": 0.0,
        "SH/L": 0.03,
        "Polariz.": 0.70,
    }.items():
        inst[key][1] = value
        inst[key][2] = False
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [800.0] + [0.0] * 11,
                "refine": True,
            }
        }
    )
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][0] = 1.0
        phase.set_HAP_refinements({"Scale": True})
        phase.setSampleProfile(hist, "size", "isotropic", 0.20, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1500.0, LGmix=1.0)

    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.do_refinements([{}], outputnames=[str(WORK / f"{stem}_1.gpx")])
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.do_refinements([{}], outputnames=[str(WORK / f"{stem}_2.gpx")])
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.do_refinements([{}], outputnames=[str(WORK / f"{stem}_3.gpx")])
    for phase in project.phases():
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    project.do_refinements([{}], outputnames=[str(WORK / f"{stem}_4.gpx")])

    hist = project.histogram(0)
    summary = {
        "cod_id": cod_id,
        "project": f"{stem}_4.gpx",
        "Rwp_percent": hist.get_wR(),
        "GOF": project.data["Covariance"]["data"]["Rvals"].get("GOF"),
        "mass_fractions": {
            key: value[0] for key, value in hist.ComputeMassFracs().items()
        },
        "shift_um": hist.data["Sample Parameters"]["Shift"][0],
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        summary["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "size_um": hap["Size"][1][0],
            "microstrain_ppm": hap["Mustrain"][1][0],
        }
    print("SCREEN_RESULT=" + json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main(sys.argv[1])
