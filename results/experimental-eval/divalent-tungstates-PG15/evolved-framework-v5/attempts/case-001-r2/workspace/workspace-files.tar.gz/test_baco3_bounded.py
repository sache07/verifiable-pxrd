#!/usr/bin/env python3
"""One bounded light-atom test from the complete physical checkpoint."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent


def main() -> None:
    project = G2sc.G2Project(str(WORK / "final_checkpoint.gpx"))
    project.index_ids()
    phase = project.phase("BaCO3")
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-6
    controls["parmFrozen"] = {"FrozenList": []}

    # C and O coordinates may move by at most 0.01 fractional in this test.
    # This is a deliberately small, local branch rather than a topology search.
    for atom_index in (1, 2, 3):
        phase.data["Atoms"][atom_index][2] = "X"
        for component in ("dAx", "dAy", "dAz"):
            name = f"{phase.id}::{component}:{atom_index}"
            variable = project.make_var_obj(name, reloadIdx=False)
            controls.setdefault("parmMinDict", {})[variable] = -0.01
            controls.setdefault("parmMaxDict", {})[variable] = 0.01

    project.save(str(WORK / "baco3_bounded_start.gpx"))
    project.do_refinements(
        [{}], outputnames=[str(WORK / "baco3_bounded.gpx")]
    )

    hist = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    print("Rwp", hist.get_wR())
    print("GOF", covariance["Rvals"].get("GOF"))
    print("Rvals", covariance["Rvals"])
    print("fractions", hist.ComputeMassFracs())
    print("frozen", controls.get("parmFrozen"))
    print("atoms", [(a[0], a[3:6], a[2]) for a in phase.data["Atoms"]])


if __name__ == "__main__":
    main()
