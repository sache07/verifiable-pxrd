#!/usr/bin/env python3
"""Export all requested artifacts from the accepted full-grid GSAS-II model."""

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
SOURCE = WORK / "fullgrid_replay.gpx"


def main() -> None:
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(WORK / "final.gpx"))
    hist = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    histogram_rvals = hist.data["data"][0]

    cif_names = {"BaCO3": "BaCO3.cif", "WO3": "WO3.cif"}
    for phase in project.phases():
        phase.export_CIF(str(WORK / cif_names[phase.name]))

    profile = np.asarray(hist.data["data"][1], dtype=float)
    two_theta, observed, _weight, calculated, background, _stored_difference = profile
    difference = observed - calculated
    with (WORK / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference", "background"]
        )
        writer.writerows(
            zip(two_theta, observed, calculated, difference, background)
        )

    fractions = hist.ComputeMassFracs()
    phase_results = []
    formulas = {"BaCO3": "BaCO3", "WO3": "WO3"}
    for phase in project.phases():
        fraction, esd = fractions[phase.name]
        phase_results.append(
            {
                "name": phase.name,
                "formula": formulas[phase.name],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": cif_names[phase.name],
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(esd),
            }
        )

    result = {
        "phases": phase_results,
        "fit_statistics": {
            "Rwp_percent": float(rvals["Rwp"]),
            "Rp_percent": float(histogram_rvals["R"]),
            "R_background_percent": float(histogram_rvals["Rb"]),
            "Rwp_min_percent": float(histogram_rvals["wRmin"]),
            "GOF": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
        },
        "artifacts": {"project": "final.gpx", "profile": "fit.csv"},
        "weight_fraction_basis": "normalized over modeled crystalline phases",
    }
    (WORK / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=False) + "\n"
    )

    assert len(two_theta) == 8301
    assert np.all(np.isfinite(profile))
    assert abs(sum(item["weight_fraction"] for item in phase_results) - 1.0) < 1e-10
    assert rvals.get("SVD0", 1) == 0 and rvals.get("converged") is True
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
