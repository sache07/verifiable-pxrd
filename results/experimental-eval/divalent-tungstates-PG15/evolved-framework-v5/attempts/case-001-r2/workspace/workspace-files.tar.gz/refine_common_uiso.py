#!/usr/bin/env python3
"""Test one shared isotropic displacement parameter per accepted phase."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent


def main() -> None:
    project = G2sc.G2Project(str(WORK / "uiso_heavy_start.gpx"))
    hist = project.histogram(0)

    # Resolve all random phase/atom IDs before changing any model values. This
    # prevents constraint setup from saving a partially edited source project.
    project.index_ids()

    # Convert parameters that reached a physical boundary in earlier branches
    # to fixed constants and remove their stale entries from parmFrozen.
    inst = hist.data["Instrument Parameters"][0]
    inst["Polariz."][2] = False
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["max cyc"] = 20
    controls["min dM/M"] = 1.0e-6

    constraints = project.data["Constraints"]["data"]
    for scope in ("Hist", "HAP", "Phase", "Global"):
        constraints[scope] = []

    for phase in project.phases():
        atoms = phase.data["Atoms"]
        atom_vars = []
        for atom_index, atom in enumerate(atoms):
            atom[10] = 0.008
            atom[2] = "XU" if "X" in atom[2] else "U"
            atom_vars.append(f"{phase.id}::AUiso:{atom_index}")
        project.add_EquivConstr(atom_vars, reloadIdx=False)

    project.save(str(WORK / "uiso_common_start.gpx"))
    project.do_refinements(
        [{}], outputnames=[str(WORK / "uiso_common.gpx")]
    )

    hist = project.histogram(0)
    print("Rwp", hist.get_wR())
    print("GOF", project.data["Covariance"]["data"]["Rvals"].get("GOF"))
    print("fractions", hist.ComputeMassFracs())
    print("frozen", project.data["Controls"]["data"].get("parmFrozen"))
    print("constraints", project.data["Constraints"]["data"]["Phase"])
    for phase in project.phases():
        print(phase.name, [(atom[0], atom[10], atom[2]) for atom in phase.data["Atoms"]])


if __name__ == "__main__":
    main()
