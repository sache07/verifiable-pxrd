#!/usr/bin/env python3
"""Build the requested deliverables from the verified final-project replay."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / ".tmp" / "final_replay"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    replay = json.loads((REPLAY / "replay.json").read_text())
    if replay["status"] != "replayed":
        raise RuntimeError(f"Final project did not replay: {replay}")
    if replay["profile_review_flags"]:
        raise RuntimeError(f"Physical profile review failed: {replay['profile_review_flags']}")
    if sha256(ROOT / "final.gpx") != replay["project_sha256"]:
        raise RuntimeError("final.gpx changed after the verified replay")

    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as z:
        x = z["x"].copy()
        observed = z["observed"].copy()
        calculated = z["predicted"].copy()
    public = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if not np.array_equal(x, public[:, 0]) or not np.array_equal(observed, public[:, 1]):
        raise RuntimeError("Replay grid or observations differ from pattern.csv")
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=("%.8f", "%.8f", "%.10f", "%.10f"),
    )

    destinations = [
        ROOT / "phase_ZnWO4.cif",
        ROOT / "phase_WO3.cif",
        ROOT / "phase_ZnO.cif",
    ]
    for phase, destination in zip(replay["phases"], destinations, strict=True):
        shutil.copy2(REPLAY / phase["cif"], destination)

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    rwp = float(100.0 * np.sqrt(chi_square / np.sum(weights * observed**2)))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    n_parameters = 26
    reduced_chi_square = chi_square / (len(x) - n_parameters)

    # Formal fraction e.s.d.s propagated from the final scale covariance.
    refinement = json.loads((ROOT / "polish_cells.json").read_text())["covariance"]
    covariance = np.asarray(refinement["covMatrix"], dtype=float)
    scale_indices = [refinement["varyList"].index(f"{i}:0:Scale") for i in range(3)]
    scale_covariance = covariance[np.ix_(scale_indices, scale_indices)]
    scales = np.asarray([phase["scale"] for phase in replay["phases"]])
    cell_masses = np.asarray([phase["cell_mass"] for phase in replay["phases"]])
    total_mass_scale = float(cell_masses @ scales)
    fractions = cell_masses * scales / total_mass_scale
    jacobian = np.diag(cell_masses / total_mass_scale) - np.outer(
        fractions, cell_masses / total_mass_scale
    )
    fraction_covariance = jacobian @ scale_covariance @ jacobian.T
    fraction_esds = np.sqrt(np.maximum(np.diag(fraction_covariance), 0.0))

    phase_metadata = [
        {
            "name": "ZnWO4",
            "identification": "wolframite zinc tungstate",
            "formula": "ZnWO4",
            "space_group": "P 2/c",
            "structure_reference": "COD 1520641",
            "cif_path": destinations[0].name,
            "weight_fraction": float(fractions[0]),
            "weight_fraction_esd_formal": float(fraction_esds[0]),
            "crystallite_size_um": 0.08090873701313811,
        },
        {
            "name": "WO3",
            "identification": "monoclinic tungsten(VI) oxide",
            "formula": "WO3",
            "space_group": "P 21/c",
            "structure_reference": "COD 2311041",
            "cif_path": destinations[1].name,
            "weight_fraction": float(fractions[1]),
            "weight_fraction_esd_formal": float(fraction_esds[1]),
            "crystallite_size_um": 0.05599475833803953,
        },
        {
            "name": "ZnO",
            "identification": "wurtzite zinc oxide",
            "formula": "ZnO",
            "space_group": "P 63mc",
            "structure_reference": "COD 9004178",
            "cif_path": destinations[2].name,
            "weight_fraction": float(fractions[2]),
            "weight_fraction_esd_formal": float(fraction_esds[2]),
            "crystallite_size_um": 0.06613099061267694,
        },
    ]
    result = {
        "phases": phase_metadata,
        "unresolved_components": [],
        "refinement_histogram": replay["histogram"],
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "chi_square": chi_square,
            "reduced_chi_square": reduced_chi_square,
            "goodness_of_fit": float(np.sqrt(reduced_chi_square)),
            "n_points": int(len(x)),
            "n_refined_parameters": n_parameters,
            "evaluation_grid": replay["evaluation_grid"],
        },
        "measurement": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "kalpha1_angstrom": 1.540598,
            "kalpha2_angstrom": 1.544426,
            "kalpha2_to_kalpha1_ratio": 0.5,
            "zero_shift_deg": 0.14012915772154463,
        },
        "project_file": "final.gpx",
        "fit_file": "fit.csv",
        "fraction_basis": "normalized over modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result["fit_statistics"], indent=2))
    print("fraction sum", sum(phase["weight_fraction"] for phase in phase_metadata))


if __name__ == "__main__":
    main()
