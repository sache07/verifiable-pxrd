#!/usr/bin/env python3
"""Explore physically bounded refinement branches from a stable checkpoint."""

from pathlib import Path
import json
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

from trial_gsas import summarize


ROOT = Path(__file__).resolve().parent


def set_inst(hist, name, value=None, refine=None):
    row = hist.data["Instrument Parameters"][0][name]
    if value is not None:
        row[1] = float(value)
    if refine is not None:
        row[2] = bool(refine)


def base_project(output_name):
    project = G2.G2Project(gpxfile=str(ROOT / "trial_scale_background.gpx"))
    project.save(str(ROOT / output_name))
    hist = project.histograms()[0]
    phase = project.phases()[0]
    # Freeze the strongly correlated angular/cell solution while testing
    # structure and profile terms.
    phase.clear_refinements({"Cell": False})
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]
    project.set_Controls("cycles", 16)
    return project


def checkpoint(project, filename):
    project.save()
    shutil.copy2(project.filename, ROOT / filename)


def coordinate_limits(project, half_width=0.02):
    phase = project.phases()[0]
    for atom_index, atom in enumerate(phase.atoms()):
        for axis, value in zip("xyz", atom.coordinates):
            variable = f"0::dA{axis}:{atom_index}"
            project.set_Controls("parmMin", value - half_width, variable)
            project.set_Controls("parmMax", value + half_width, variable)
    project.set_Frozen()


def refine_coordinates():
    project = base_project("branch_coordinates.gpx")
    coordinate_limits(project)
    phase = project.phases()[0]
    phase.set_refinements({"Atoms": {"W": "X", "Zn": "X"}})
    project.refine()
    summarize(project, "coords_heavy")
    checkpoint(project, "branch_coords_heavy.gpx")

    phase = project.phases()[0]
    phase.set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
    project.refine()
    summarize(project, "coords_all")
    checkpoint(project, "branch_coords_all.gpx")


def profile_sequence():
    project = G2.G2Project(gpxfile=str(ROOT / "branch_coords_all.gpx"))
    project.save(str(ROOT / "branch_profile.gpx"))
    hist = project.histograms()[0]
    phase = project.phases()[0]
    hap = phase.data["Histograms"][hist.name]
    # Keep known instrument/profile terms inside the laboratory prior.
    for key, value in {"U": 10.0, "V": 0.0, "W": 15.0,
                       "X": 1.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.03}.items():
        set_inst(hist, key, value, False)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.5
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    # Atomic coordinates stay refined while profile terms are introduced.
    project.set_Controls("cycles", 20)

    hist.set_refinements({"Instrument Parameters": ["W"]})
    project.refine()
    summarize(project, "profile_W")
    checkpoint(project, "branch_profile_W.gpx")

    # Fix W to the physical laboratory upper limit if unconstrained LS exits it.
    hist = project.histograms()[0]
    w = hist.data["Instrument Parameters"][0]["W"][1]
    if not 2.0 <= w <= 40.0:
        set_inst(hist, "W", min(40.0, max(2.0, w)), False)
    phase = project.phases()[0]
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.refine()
    summarize(project, "profile_W_size")
    checkpoint(project, "branch_profile_W_size.gpx")

    # Fix X because it is exactly confounded with isotropic size for one phase.
    hist = project.histograms()[0]
    set_inst(hist, "X", 1.0, False)
    phase = project.phases()[0]
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project.refine()
    summarize(project, "profile_W_size_strain")
    checkpoint(project, "branch_profile_W_size_strain.gpx")

    # Refine axial divergence only after the symmetric widths are stable.
    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.refine()
    summarize(project, "profile_physical")
    checkpoint(project, "branch_profile_physical.gpx")


def main():
    G2.SetPrintLevel("warn")
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"
    if mode in ("coordinates", "all"):
        refine_coordinates()
    if mode in ("profile", "all"):
        profile_sequence()


if __name__ == "__main__":
    main()
