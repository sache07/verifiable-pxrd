#!/usr/bin/env python3
"""Write the selected GSAS-II checkpoint under the requested final filename."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(ROOT / "polish_cells.gpx"))
    project.save(str(ROOT / "final.gpx"))
    print(project.filename)
    print([phase.name for phase in project.phases()])
    print([hist.name for hist in project.histograms()])


if __name__ == "__main__":
    main()
