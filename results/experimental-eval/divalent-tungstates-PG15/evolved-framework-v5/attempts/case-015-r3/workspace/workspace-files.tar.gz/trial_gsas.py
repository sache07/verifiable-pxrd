#!/usr/bin/env python3
"""Build and inspect an initial GSAS-II ZnWO4 Rietveld project."""

from pathlib import Path
import csv
import json
import math
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
SOURCE_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/06/1520641.cif"
)


def make_auxiliary_files():
    rows = []
    with PATTERN.open(newline="") as stream:
        reader = csv.DictReader(stream)
        for row in reader:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            rows.append((x, y, math.sqrt(max(y, 1.0))))
    xye = ROOT / "observed.xye"
    with xye.open("w") as stream:
        stream.write("/* 2theta intensity sigma; Poisson counting weights */\n")
        for x, y, sigma in rows:
            stream.write(f"{x:.8f} {y:.8f} {sigma:.8f}\n")
    inst = ROOT / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha Bragg-Brentano\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def summarize(project, label):
    hist = project.histograms()[0]
    phase = project.phases()[0]
    hap = phase.data["Histograms"][hist.name]
    info = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "cell": phase.get_cell(),
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "hap": {
            "Scale": hap["Scale"],
            "Size": hap["Size"],
            "Mustrain": hap["Mustrain"],
            "Pref.Ori.": hap["Pref.Ori."],
        },
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "xyz": list(atom.coordinates),
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
        "covariance": {
            key: project.data.get("Covariance", {}).get("data", {}).get(key)
            for key in ("Rvals", "varyList", "sig", "variables")
        },
    }
    def plain(value):
        if isinstance(value, dict):
            return {str(k): plain(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [plain(v) for v in value]
        if isinstance(value, np.ndarray):
            return plain(value.tolist())
        if isinstance(value, np.generic):
            return value.item()
        return value
    (ROOT / f"trial_{label}.json").write_text(
        json.dumps(plain(info), indent=2, allow_nan=False) + "\n"
    )
    print(label, "wR", hist.get_wR(), "cell", phase.get_cell())


def main():
    G2.SetPrintLevel("all")
    xye, inst = make_auxiliary_files()
    gpx = ROOT / "trial.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    phase = project.add_phase(
        str(SOURCE_CIF), phasename="ZnWO4", fmthint="CIF"
    )
    hist = project.add_powder_histogram(
        str(xye), str(inst), phases=[phase], fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [9.90343322, 100.09488522],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [600.0] + [0.0] * 11,
                "refine": False,
            },
        }
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][0] = 0.1
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.3
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    project.set_Controls("cycles", 0)
    project.refine()
    summarize(project, "initial")

    # Establish background and scale before changing geometry.
    hist = project.histograms()[0]
    phase = project.phases()[0]
    hist.set_refinements({"Background": True})
    phase.set_HAP_refinements({"Scale": True})
    project.set_Controls("cycles", 12)
    project.refine()
    summarize(project, "scale_background")
    project.save(str(ROOT / "trial_scale_background.gpx"))

    # Refine lattice and angular zero against the complete reflection set.
    hist = project.histograms()[0]
    phase = project.phases()[0]
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("cycles", 16)
    project.refine()
    summarize(project, "cell_zero")
    project.save(str(ROOT / "trial_cell_zero.gpx"))

    # Separate specimen displacement from the constant angular zero.
    hist = project.histograms()[0]
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine()
    summarize(project, "cell_zero_shift")
    project.save(str(ROOT / "trial_cell_zero_shift.gpx"))

    # Instrument profile first, followed by specimen/phase broadening.
    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    project.refine()
    summarize(project, "instrument_profile")
    project.save(str(ROOT / "trial_instrument_profile.gpx"))

    phase = project.phases()[0]
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.3, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )
    project.refine()
    summarize(project, "phase_profile")
    project.save(str(ROOT / "trial_phase_profile.gpx"))


if __name__ == "__main__":
    main()
