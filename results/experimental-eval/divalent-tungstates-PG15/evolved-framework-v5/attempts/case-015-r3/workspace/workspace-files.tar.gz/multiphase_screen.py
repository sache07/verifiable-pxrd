#!/usr/bin/env python3
"""Screen exact-composition WO3 references in a ZnWO4 + WO3 model."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
WO3_IDS = ["1528915", "2311041", "2106293", "2107312"]


def cod_path(identifier):
    return COD / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def checkpoint(project, filename):
    project.save()
    shutil.copy2(project.filename, ROOT / filename)


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    try:
        return value.tolist()
    except AttributeError:
        pass
    try:
        return value.item()
    except (AttributeError, ValueError):
        return value


def report(project, identifier, stage):
    hist = project.histograms()[0]
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "mass_scale": mass_scale,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    total = sum(masses)
    for phase, value in zip(phases, masses):
        phase["weight_fraction"] = value / total
    row = {
        "wo3_cod_id": identifier,
        "stage": stage,
        "rwp_percent": hist.get_wR(),
        "phases": phases,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "covariance": project.data.get("Covariance", {}).get("data", {}),
        "frozen": project.get_Frozen(),
    }
    (ROOT / f"screen_{identifier}_{stage}.json").write_text(
        json.dumps(plain(row), indent=2, allow_nan=False) + "\n"
    )
    print(identifier, stage, "Rwp", hist.get_wR(), "fractions", [p["weight_fraction"] for p in phases])


def screen(identifier):
    work = ROOT / f"screen_{identifier}_work.gpx"
    project = G2.G2Project(gpxfile=str(ROOT / "trial.gpx"))
    project.save(str(work))
    hist = project.histograms()[0]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    wo3 = project.add_phase(
        str(cod_path(identifier)),
        phasename=f"WO3_{identifier}",
        histograms=[hist],
        fmthint="CIF",
    )
    znwo4 = project.phase("ZnWO4")
    for phase, scale in [(znwo4, 10.0), (wo3, 1.0)]:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
    project.set_Controls("parmMin", 0.0, "*:0:Scale")
    project.set_Controls("parmMin", -0.25, ":0:Zero")
    project.set_Controls("parmMax", 0.25, ":0:Zero")
    project.set_Controls("cycles", 16)
    project.refine()
    report(project, identifier, "scales")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    report(project, identifier, "cells")
    checkpoint(project, f"screen_{identifier}.gpx")


def main():
    G2.SetPrintLevel("warn")
    for identifier in WO3_IDS:
        screen(identifier)


if __name__ == "__main__":
    main()
