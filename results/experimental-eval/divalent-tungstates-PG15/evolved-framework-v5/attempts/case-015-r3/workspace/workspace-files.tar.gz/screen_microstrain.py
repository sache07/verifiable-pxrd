#!/usr/bin/env python3
"""Screen one physical isotropic/uniaxial microstrain term at a time."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
MODELS = [("isotropic", None)] + [
    ("uniaxial", axis) for axis in [(0, 0, 1), (1, 0, 0), (0, 1, 0)]
]


def run_branch(phase_index, kind, axis):
    suffix = "iso" if axis is None else f"u{axis[0]}{axis[1]}{axis[2]}"
    tag = f"p{phase_index}_{suffix}"
    project = G2.G2Project(gpxfile=str(ROOT / "coordinates_all.gpx"))
    project.save(str(ROOT / f"microstrain_{tag}_work.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 24)
    hist = project.histograms()[0]
    hist.SampleParameters["SurfRoughA"][1] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Size": False, "Mustrain": False, "Pref.Ori.": False})
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][0] = kind
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][1][1] = 500.0
    if axis is not None:
        hap["Mustrain"][3] = list(axis)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": list(axis), "refine": True}}
        )
    else:
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    project.set_Controls("parmMin", 0.0, f"{phase_index}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, f"{phase_index}:0:Mustrain;i")
    project.set_Controls("parmMin", 0.0, f"{phase_index}:0:Mustrain;a")
    project.set_Controls("parmMax", 8000.0, f"{phase_index}:0:Mustrain;a")
    project.refine()
    if project.get_Frozen():
        project.refine()
    hist = project.histograms()[0]
    hap = project.phases()[phase_index].data["Histograms"][hist.name]
    values = list(hap["Mustrain"][1][:2])
    project.save()
    shutil.copy2(project.filename, ROOT / f"microstrain_{tag}.gpx")
    return {
        "phase_index": phase_index,
        "phase": phase.name,
        "model": kind,
        "axis": list(axis) if axis is not None else None,
        "values_ppm": values,
        "rwp_percent": hist.get_wR(),
        "frozen": project.get_Frozen(),
        "vary_list": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
    }


def main():
    G2.SetPrintLevel("warn")
    rows = []
    for phase_index in range(3):
        for kind, axis in MODELS:
            row = run_branch(phase_index, kind, axis)
            rows.append(row)
            print(row)
    (ROOT / "microstrain_screen.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
