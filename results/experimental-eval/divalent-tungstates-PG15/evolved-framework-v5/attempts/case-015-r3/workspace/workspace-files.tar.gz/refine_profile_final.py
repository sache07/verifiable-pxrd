#!/usr/bin/env python3
"""Finalize supported physical profile and calibration terms."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def stage(project, name):
    project.save()
    shutil.copy2(project.filename, ROOT / f"profile_{name}.gpx")
    hist = project.histograms()[0]
    phases, masses = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / sum(masses)
    data = {
        "stage": name,
        "rwp_percent": hist.get_wR(),
        "phases": phases,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "frozen": project.get_Frozen(),
        "covariance": project.data.get("Covariance", {}).get("data", {}),
    }
    (ROOT / f"profile_{name}.json").write_text(
        json.dumps(plain(data), indent=2, allow_nan=False) + "\n"
    )
    print(name, "Rwp", hist.get_wR(), "fractions", [p["weight_fraction"] for p in phases], "frozen", project.get_Frozen())


def prepare(project):
    project.set_Frozen()
    project.set_Controls("cycles", 24)
    hist = project.histograms()[0]
    hist.SampleParameters["SurfRoughA"][1] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Size": False, "Mustrain": False, "Pref.Ori.": False})
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    for variable, lower, upper in [
        ("*:0:Size;i", 0.04, 1.5),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Zero", -0.25, 0.25),
        ("*:0:Scale", 1e-8, 1e5),
    ]:
        project.set_Controls("parmMin", lower, variable)
        project.set_Controls("parmMax", upper, variable)


def refine_consistently(project):
    before = set(project.get_Frozen())
    project.refine()
    if set(project.get_Frozen()) != before:
        project.refine()


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(ROOT / "coordinates_all.gpx"))
    project.save(str(ROOT / "profile_work.gpx"))
    prepare(project)

    # Refresh independent isotropic domain sizes after coordinate refinement.
    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine_consistently(project)
    stage(project, "size")

    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": False})
    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["U"]})
    refine_consistently(project)
    stage(project, "U")

    hist = project.histograms()[0]
    hist.clear_refinements({"Instrument Parameters": ["U"]})
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine_consistently(project)
    stage(project, "axial")

    # Final cells and constant zero with profile and coordinates fixed.
    hist = project.histograms()[0]
    hist.clear_refinements({"Instrument Parameters": ["SH/L"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_consistently(project)
    stage(project, "cells")


if __name__ == "__main__":
    main()
