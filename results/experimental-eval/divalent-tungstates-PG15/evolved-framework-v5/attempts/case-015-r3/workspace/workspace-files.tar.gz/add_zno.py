#!/usr/bin/env python3
"""Test the coherent residual ZnO family in the accepted ZnWO4 + WO3 model."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
ZNO = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/9/00/41/9004178.cif"
)


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def save_stage(project, stage):
    project.save()
    shutil.copy2(project.filename, ROOT / f"three_phase_{stage}.gpx")
    hist = project.histograms()[0]
    phases, mass_scales = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        value = phase.data["General"]["Mass"] * hap["Scale"][0]
        mass_scales.append(value)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    for phase, value in zip(phases, mass_scales):
        phase["weight_fraction"] = value / sum(mass_scales)
    data = {
        "stage": stage,
        "rwp_percent": hist.get_wR(),
        "phases": phases,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "frozen": project.get_Frozen(),
        "covariance": project.data.get("Covariance", {}).get("data", {}),
    }
    (ROOT / f"three_phase_{stage}.json").write_text(
        json.dumps(plain(data), indent=2, allow_nan=False) + "\n"
    )
    print(stage, "Rwp", hist.get_wR(), "fractions", [p["weight_fraction"] for p in phases], "frozen", project.get_Frozen())


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(ROOT / "two_phase_strain.gpx"))
    project.save(str(ROOT / "three_phase_work.gpx"))
    project.set_Frozen()
    hist = project.histograms()[0]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Size": False, "Mustrain": False})

    zno = project.add_phase(
        str(ZNO), phasename="ZnO", histograms=[hist], fmthint="CIF"
    )
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    hap = zno.data["Histograms"][hist.name]
    hap["Scale"] = [8.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.06
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]

    for variable, lower, upper in [
        ("*:0:Scale", 1e-8, 1e5),
        ("*:0:Size;i", 0.04, 1.5),
        (":0:Zero", -0.25, 0.25),
    ]:
        project.set_Controls("parmMin", lower, variable)
        project.set_Controls("parmMax", upper, variable)
    project.set_Controls("cycles", 20)
    project.refine()
    save_stage(project, "scale")

    # Refine all cells with the fixed physical profile and a bounded common zero.
    project.set_Frozen()
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    save_stage(project, "cells")

    # Re-optimize independent coherent-domain sizes after inventory completion.
    project.set_Frozen()
    for phase in project.phases():
        phase.clear_refinements({"Cell": False})
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    hist = project.histograms()[0]
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    save_stage(project, "size")


if __name__ == "__main__":
    main()
