#!/usr/bin/env python3
"""Screen one bounded March-Dollase texture term at a time."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def run_branch(phase_index, axis):
    tag = f"p{phase_index}_{axis[0]}{axis[1]}{axis[2]}"
    project = G2.G2Project(gpxfile=str(ROOT / "coordinates_all.gpx"))
    project.save(str(ROOT / f"texture_{tag}_work.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 20)
    hist = project.histograms()[0]
    hist.SampleParameters["SurfRoughA"][1] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Size": False, "Mustrain": False, "Pref.Ori.": False})
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    project.set_Controls("parmMin", 0.7, f"{phase_index}:0:MD")
    project.set_Controls("parmMax", 1.4, f"{phase_index}:0:MD")
    project.refine()
    if project.get_Frozen():
        project.refine()
    hist = project.histograms()[0]
    ratio = phase.data["Histograms"][hist.name]["Pref.Ori."][1]
    project.save()
    shutil.copy2(project.filename, ROOT / f"texture_{tag}.gpx")
    return {
        "phase_index": phase_index,
        "phase": phase.name,
        "axis": list(axis),
        "ratio": ratio,
        "rwp_percent": hist.get_wR(),
        "frozen": project.get_Frozen(),
    }


def main():
    G2.SetPrintLevel("warn")
    rows = []
    for phase_index in range(3):
        for axis in AXES:
            row = run_branch(phase_index, axis)
            rows.append(row)
            print(row)
    (ROOT / "texture_screen.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
