#!/usr/bin/env python3
"""Small final alternation of supported roughness, size and cell terms."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def save_stage(project, name):
    project.save()
    shutil.copy2(project.filename, ROOT / f"polish_{name}.gpx")
    hist = project.histograms()[0]
    phases, masses = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass)
        phases.append({"name": phase.name, "cell": phase.get_cell(), "scale": hap["Scale"], "size": hap["Size"]})
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / sum(masses)
    d = {
        "stage": name,
        "rwp_percent": hist.get_wR(),
        "phases": phases,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "frozen": project.get_Frozen(),
        "covariance": project.data.get("Covariance", {}).get("data", {}),
    }
    (ROOT / f"polish_{name}.json").write_text(json.dumps(plain(d), indent=2, allow_nan=False) + "\n")
    print(name, "Rwp", hist.get_wR(), "fractions", [p["weight_fraction"] for p in phases], "frozen", project.get_Frozen())


def fix_all(project):
    hist = project.histograms()[0]
    hist.SampleParameters["Scale"] = [1.0, False]
    for key in ["Shift", "SurfRoughA", "SurfRoughB"]:
        hist.SampleParameters[key][1] = False
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Size": False, "Mustrain": False, "Pref.Ori.": False})
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "


def main():
    G2.SetPrintLevel("warn")
    source = ROOT / "profile_cells_repeat.bak0.gpx"
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(ROOT / "polish_work.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 24)
    fix_all(project)
    for variable, lower, upper in [
        (":0:SurfRoughA", 0.0, 0.60),
        (":0:SurfRoughB", 0.0, 0.50),
        ("*:0:Size;i", 0.04, 1.5),
        (":0:Zero", -0.25, 0.25),
        ("*:0:Scale", 1e-8, 1e5),
    ]:
        project.set_Controls("parmMin", lower, variable)
        project.set_Controls("parmMax", upper, variable)

    hist = project.histograms()[0]
    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    project.refine()
    if project.get_Frozen(): project.refine()
    save_stage(project, "roughness")

    hist = project.histograms()[0]
    hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.refine()
    if project.get_Frozen(): project.refine()
    save_stage(project, "size")

    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": False})
        phase.set_refinements({"Cell": True})
    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    save_stage(project, "cells")


if __name__ == "__main__":
    main()
