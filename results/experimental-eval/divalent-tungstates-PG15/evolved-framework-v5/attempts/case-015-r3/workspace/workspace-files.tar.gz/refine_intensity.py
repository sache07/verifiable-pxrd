#!/usr/bin/env python3
"""Refine physical specimen and intensity terms for the three-phase model."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def stage(project, name):
    project.save()
    shutil.copy2(project.filename, ROOT / f"intensity_{name}.gpx")
    hist = project.histograms()[0]
    masses, phases = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / sum(masses)
    data = {
        "stage": name,
        "rwp_percent": hist.get_wR(),
        "phases": phases,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "frozen": project.get_Frozen(),
        "covariance": project.data.get("Covariance", {}).get("data", {}),
    }
    (ROOT / f"intensity_{name}.json").write_text(
        json.dumps(plain(data), indent=2, allow_nan=False) + "\n"
    )
    print(name, "Rwp", hist.get_wR(), "fractions", [p["weight_fraction"] for p in phases], "sample", hist.data["Sample Parameters"], "frozen", project.get_Frozen())


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(ROOT / "three_phase_size.gpx"))
    project.save(str(ROOT / "intensity_work.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 24)
    hist = project.histograms()[0]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Size": False, "Mustrain": False, "Pref.Ori.": False})
        phase.set_HAP_refinements({"Scale": True})

    # Bragg-Brentano roughness attenuates low-angle intensities.
    hist.SampleParameters["SurfRoughA"] = [0.20, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    for variable, lower, upper in [
        (":0:SurfRoughA", 0.0, 0.60),
        (":0:SurfRoughB", 0.0, 0.50),
        (":0:Polariz.", 0.50, 1.00),
        ("*:0:Scale", 1e-8, 1e5),
    ]:
        project.set_Controls("parmMin", lower, variable)
        project.set_Controls("parmMax", upper, variable)
    project.refine()
    stage(project, "roughness")

    # If a roughness bound was reached, rerun with it frozen so all remaining
    # terms are consistent with the bounded value.
    if project.get_Frozen():
        project.refine()
        stage(project, "roughness_consistent")

    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.refine()
    stage(project, "polarization")
    if project.get_Frozen():
        project.refine()
        stage(project, "polarization_consistent")


if __name__ == "__main__":
    main()
