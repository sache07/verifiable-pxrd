#!/usr/bin/env python3
"""Staged physical refinement of ZnWO4 + monoclinic WO3."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def checkpoint(project, stage):
    project.save()
    shutil.copy2(project.filename, ROOT / f"two_phase_{stage}.gpx")
    hist = project.histograms()[0]
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        value = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(value)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "xyz": atom.coordinates,
                        "uiso": atom.uiso,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    for phase, value in zip(phases, masses):
        phase["weight_fraction"] = value / sum(masses)
    row = {
        "stage": stage,
        "rwp_percent": hist.get_wR(),
        "phases": phases,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "frozen": project.get_Frozen(),
        "covariance": project.data.get("Covariance", {}).get("data", {}),
    }
    (ROOT / f"two_phase_{stage}.json").write_text(
        json.dumps(plain(row), indent=2, allow_nan=False) + "\n"
    )
    print(stage, "Rwp", hist.get_wR(), "fractions", [p["weight_fraction"] for p in phases], "frozen", project.get_Frozen())


def set_instrument(hist, name, value, refine=False):
    hist.data["Instrument Parameters"][0][name][1] = float(value)
    hist.data["Instrument Parameters"][0][name][2] = bool(refine)


def set_limits(project):
    bounds = {
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.1),
        ":0:Polariz.": (0.5, 1.0),
        ":0:Zero": (-0.25, 0.25),
        "*:0:Size;i": (0.04, 1.5),
        "*:0:Mustrain;i": (0.0, 8000.0),
        "*:0:Scale": (1e-8, 1e5),
    }
    for variable, (lower, upper) in bounds.items():
        project.set_Controls("parmMin", lower, variable)
        project.set_Controls("parmMax", upper, variable)


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(ROOT / "screen_2311041.gpx"))
    project.save(str(ROOT / "two_phase_work.gpx"))
    project.set_Frozen()
    set_limits(project)
    project.set_Controls("cycles", 24)
    hist = project.histograms()[0]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    for key, value in {
        "U": 10.0,
        "V": 0.0,
        "W": 20.0,
        "X": 1.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.03,
        "Polariz.": 0.70,
    }.items():
        set_instrument(hist, key, value, False)

    # First recover independent phase breadths with a common fixed instrument.
    for phase in project.phases():
        phase.clear_refinements({"Cell": False})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.08
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
    project.refine()
    checkpoint(project, "size")

    # Gaussian instrumental breadth is common to both phases.
    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["U", "W"]})
    project.refine()
    checkpoint(project, "instrument")

    # Permit physically nonnegative isotropic microstrain phase by phase.
    project.set_Frozen()
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 500.0
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project.refine()
    checkpoint(project, "strain")

    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.refine()
    checkpoint(project, "axial")

    # Re-optimize the phase cells and constant zero only after widths stabilize.
    project.set_Frozen()
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    checkpoint(project, "cells")


if __name__ == "__main__":
    main()
