#!/usr/bin/env python3
"""Bounded heavy-then-light coordinate refinement for the accepted inventory."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def save_stage(project, name):
    project.save()
    shutil.copy2(project.filename, ROOT / f"coordinates_{name}.gpx")
    hist = project.histograms()[0]
    phases, mass_scales = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        mass_scales.append(mass_scale)
        cif = ROOT / f"coordinates_{name}_{phase.name}.cif"
        phase.export_CIF(str(cif))
        phases.append(
            {
                "name": phase.name,
                "cif": cif.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": atom.coordinates,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    for phase, mass_scale in zip(phases, mass_scales):
        phase["weight_fraction"] = mass_scale / sum(mass_scales)
    data = {
        "stage": name,
        "rwp_percent": hist.get_wR(),
        "phases": phases,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "frozen": project.get_Frozen(),
        "covariance": project.data.get("Covariance", {}).get("data", {}),
    }
    (ROOT / f"coordinates_{name}.json").write_text(
        json.dumps(plain(data), indent=2, allow_nan=False) + "\n"
    )
    print(name, "Rwp", hist.get_wR(), "fractions", [p["weight_fraction"] for p in phases], "frozen", project.get_Frozen())


def set_coordinate_bounds(project):
    half_widths = {0: 0.012, 1: 0.008, 2: 0.012}
    for phase_index, phase in enumerate(project.phases()):
        half_width = half_widths[phase_index]
        for atom_index, atom in enumerate(phase.atoms()):
            for axis, value in zip("xyz", atom.coordinates):
                variable = f"{phase_index}::dA{axis}:{atom_index}"
                project.set_Controls("parmMin", value - half_width, variable)
                project.set_Controls("parmMax", value + half_width, variable)


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(ROOT / "intensity_roughness.gpx"))
    project.save(str(ROOT / "coordinates_work.gpx"))
    project.set_Frozen()
    set_coordinate_bounds(project)
    project.set_Controls("cycles", 24)
    hist = project.histograms()[0]
    hist.SampleParameters["SurfRoughA"][1] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Size": False, "Mustrain": False, "Pref.Ori.": False})
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "

    # Heavy-atom coordinates first.
    for phase in project.phases():
        heavy = {
            atom.label: "X"
            for atom in phase.atoms()
            if atom.element in {"W", "Zn"}
        }
        if heavy:
            phase.set_refinements({"Atoms": heavy})
    project.refine()
    if project.get_Frozen():
        project.refine()
    save_stage(project, "heavy")

    # Then oxygen coordinates, while retaining the bounded heavy solution.
    for phase in project.phases():
        oxygen = {
            atom.label: "X"
            for atom in phase.atoms()
            if atom.element == "O"
        }
        if oxygen:
            phase.set_refinements({"Atoms": oxygen})
    project.refine()
    if project.get_Frozen():
        project.refine()
    save_stage(project, "all")


if __name__ == "__main__":
    main()
