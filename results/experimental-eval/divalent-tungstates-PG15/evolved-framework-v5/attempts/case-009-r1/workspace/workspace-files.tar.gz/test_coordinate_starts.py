#!/usr/bin/env python3
"""Try a small set of symmetry-preserving coordinate starts."""

from pathlib import Path
import numpy as np
import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "stabilized_branches" / "rough_joint.gpx"
OUT = ROOT / "coordinate_starts"


def run(seed):
    rng = np.random.default_rng(seed)
    gpx = G2sc.G2Project(str(SOURCE))
    path = OUT / f"start_{seed}.gpx"
    gpx.save(str(path))
    gpx.set_Controls("cycles", 12)
    gpx["Controls"]["data"]["min dM/M"] = 0.00001
    phase = gpx.phase(0)
    cell = phase.get_cell()
    lengths = np.array([cell["length_a"], cell["length_b"], cell["length_c"]])
    for atom in phase.atoms():
        xyz = np.array(atom.coordinates)
        if atom.element in ("Mn", "W"):
            # P2/c special sites permit only y to vary.
            xyz[1] += rng.normal(scale=0.030 / lengths[1])
        else:
            xyz += rng.normal(size=3) * (0.030 / lengths)
        atom.coordinates = tuple(xyz)
        atom.refinement_flags = "X"
    for _ in range(3):
        gpx.do_refinements([{}])
    h = gpx.histogram(0)
    print("CSTART", seed, "RWP", h.residuals.get("wR"), "RF2", h.residuals.get("0:0:Rf^2"))
    for atom in phase.atoms():
        print("CSTART_ATOM", seed, atom.label, atom.coordinates)
    gpx.save()
    phase.export_CIF(str(path.with_suffix(".cif")))


def main():
    OUT.mkdir(exist_ok=True)
    for seed in (11, 22, 33, 44, 55):
        run(seed)


if __name__ == "__main__":
    main()
