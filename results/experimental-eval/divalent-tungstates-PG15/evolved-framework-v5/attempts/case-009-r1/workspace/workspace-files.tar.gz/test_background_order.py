#!/usr/bin/env python3
"""Check smooth background order without changing the phase inventory."""

from pathlib import Path
import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "coordinate_checkpoints" / "all_atoms.gpx"
OUT = ROOT / "background_branches"


def run(n):
    gpx = G2sc.G2Project(str(SOURCE))
    path = OUT / f"cheb_{n}.gpx"
    gpx.save(str(path))
    gpx.set_Controls("cycles", 10)
    gpx["Controls"]["data"]["min dM/M"] = 0.00001
    h = gpx.histogram(0)
    h.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": n, "refine": True}}
    )
    for i in range(2):
        gpx.do_refinements([{}])
    print("BACKGROUND", n, "RWP", h.residuals.get("wR"), "RF2", h.residuals.get("0:0:Rf^2"))
    gpx.save()


def main():
    OUT.mkdir(exist_ok=True)
    for n in (12, 16, 20, 24, 30, 40):
        run(n)


if __name__ == "__main__":
    main()
