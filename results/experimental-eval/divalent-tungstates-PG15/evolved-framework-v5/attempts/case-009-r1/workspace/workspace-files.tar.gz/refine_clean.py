#!/usr/bin/env python3
"""A conservative, physically bounded MnWO4 Rietveld refinement."""

from pathlib import Path
import shutil

import numpy as np
import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)
CHECKS = ROOT / "clean_checkpoints"


def report(gpx, label):
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    hap = phase.getHAPvalues(hist)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    print(f"\n===== {label} =====")
    print("residuals", hist.residuals)
    print("cell", phase.get_cell())
    print("instrument", {k: inst[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")})
    print("sample", {k: sample[k] for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")})
    print("phase scale", hap["Scale"])
    print("size", hap["Size"])
    print("mustrain", hap["Mustrain"])
    print("preferred orientation", hap["Pref.Ori."])
    print("atoms")
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.refinement_flags, atom.ADP)


def checkpoint(gpx, label):
    gpx.save()
    CHECKS.mkdir(exist_ok=True)
    shutil.copy2(gpx.filename, CHECKS / f"{label}.gpx")
    report(gpx, label)


def refine(gpx, label):
    gpx.do_refinements([{}])
    checkpoint(gpx, label)


def set_limit(gpx, variable, low, high):
    gpx.set_Controls("parmMin", low, variable=variable)
    gpx.set_Controls("parmMax", high, variable=variable)


def main():
    tmp = ROOT / ".tmp"
    tmp.mkdir(exist_ok=True)
    dat = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    xye = tmp / "pattern_clean.xye"
    np.savetxt(
        xye,
        np.column_stack(
            (dat["two_theta_deg"], dat["intensity"], np.sqrt(np.maximum(dat["intensity"], 1.0)))
        ),
        fmt=("%.8f", "%.8f", "%.8f"),
    )

    gpx = G2sc.G2Project(newgpx=str(ROOT / "clean_working.gpx"))
    hist = gpx.add_powder_histogram(
        str(xye), str(ROOT / "cu_ka.instprm"), fmthint="xye"
    )
    phase = gpx.add_phase(
        str(SOURCE_CIF),
        phasename="MnWO4_wolframite",
        histograms=[hist],
        fmthint="CIF",
    )
    hist.Limits("lower", float(dat["two_theta_deg"][0]))
    hist.Limits("upper", float(dat["two_theta_deg"][-1]))

    # Avoid the exact sample-scale/phase-scale degeneracy. Phase scales are the
    # quantities needed for quantitative phase analysis; the histogram scale is
    # fixed to unity.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["DisplaceX"][1] = False
    hist.SampleParameters["Shift"] = [0.0, False]
    phase.getHAPvalues(hist)["Scale"] = [15.0, True]

    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": 16, "refine": True}}
    )

    # Seed the specimen broadening within the laboratory's physical range. X
    # and isotropic size are collinear for this geometry, so X is held at a
    # physical value and the specimen size carries their observable sum.
    phase.setSampleProfile(hist, "size", "isotropic", 0.10)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 2500.0)
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": False},
            "Mustrain": {"type": "isotropic", "refine": False},
        },
        [hist],
    )

    gpx.set_Controls("cycles", 8)
    gpx["Controls"]["data"]["min dM/M"] = 0.0001
    set_limit(gpx, ":0:Shift", -800.0, 800.0)
    set_limit(gpx, ":0:W", 2.0, 40.0)
    set_limit(gpx, ":0:U", 0.0, 40.0)
    set_limit(gpx, ":0:SH/L", 0.005, 0.10)
    set_limit(gpx, ":0:Polariz.", 0.5, 1.0)
    set_limit(gpx, "0:0:Size;i", 0.04, 1.5)
    set_limit(gpx, "0:0:Mustrain;i", 1.0, 10000.0)

    checkpoint(gpx, "00_initial")
    refine(gpx, "01_scale_background")

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(gpx, "02_cell_shift")

    phase.set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True}}, [hist]
    )
    hist.set_refinements({"Instrument Parameters": ["W"]})
    refine(gpx, "03_width_low_angle")

    phase.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
    )
    refine(gpx, "04_width_strain")

    hist.set_refinements({"Instrument Parameters": ["U", "SH/L"]})
    refine(gpx, "05_profile_physical")

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(gpx, "06_polarization")


if __name__ == "__main__":
    main()
