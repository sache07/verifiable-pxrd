#!/usr/bin/env python3
"""Screen physically supported intensity modifiers without changing atoms."""

from pathlib import Path
import copy

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "clean_checkpoints" / "06_polarization.gpx"
OUT = ROOT / "modifier_branches"


def load_branch(name):
    gpx = G2sc.G2Project(str(BASE))
    gpx.save(str(OUT / f"{name}.gpx"))
    gpx.set_Controls("cycles", 8)
    gpx["Controls"]["data"]["min dM/M"] = 0.0001
    return gpx


def limit(gpx, var, lo, hi):
    gpx.set_Controls("parmMin", lo, variable=var)
    gpx.set_Controls("parmMax", hi, variable=var)


def run_texture(axis):
    name = "md_" + "".join(str(abs(i)) if i >= 0 else f"m{abs(i)}" for i in axis)
    gpx = load_branch(name)
    hist, phase = gpx.histogram(0), gpx.phase(0)
    po = phase.getHAPvalues(hist)["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 1.0, True, list(axis)
    limit(gpx, "0:0:MD", 0.7, 1.4)
    gpx.do_refinements([{}])
    gpx.save()
    print("RESULT", name, hist.residuals, "PO", po)


def run_rough(name="surface_roughness"):
    gpx = load_branch(name)
    hist = gpx.histogram(0)
    hist.SampleParameters["SurfRoughA"] = [0.2, True]
    hist.SampleParameters["SurfRoughB"] = [0.1, True]
    limit(gpx, ":0:SurfRoughA", 0.01, 0.8)
    limit(gpx, ":0:SurfRoughB", 0.005, 0.8)
    gpx.do_refinements([{}])
    gpx.save()
    print(
        "RESULT",
        name,
        hist.residuals,
        "rough",
        hist.SampleParameters["SurfRoughA"],
        hist.SampleParameters["SurfRoughB"],
    )


def main():
    OUT.mkdir(exist_ok=True)
    for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]):
        run_texture(axis)
    run_rough()


if __name__ == "__main__":
    main()
