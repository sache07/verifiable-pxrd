#!/usr/bin/env python3
"""Add the independently supported angular-zero calibration term."""

from pathlib import Path
import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "coordinate_checkpoints" / "all_atoms.gpx"
OUTPUT = ROOT / "profile_checkpoints" / "zero.gpx"


def main():
    OUTPUT.parent.mkdir(exist_ok=True)
    gpx = G2sc.G2Project(str(SOURCE))
    gpx.save(str(OUTPUT))
    gpx.set_Controls("cycles", 12)
    gpx["Controls"]["data"]["min dM/M"] = 0.00001
    h = gpx.histogram(0)
    h.InstrumentParameters["Zero"][2] = True
    gpx.set_Controls("parmMin", -0.25, variable=":0:Zero")
    gpx.set_Controls("parmMax", 0.25, variable=":0:Zero")
    for i in range(3):
        gpx.do_refinements([{}])
        print(
            "ZERO",
            i + 1,
            "RWP",
            h.residuals.get("wR"),
            "RF2",
            h.residuals.get("0:0:Rf^2"),
            "zero",
            h.InstrumentParameters["Zero"],
            "shift",
            h.SampleParameters["Shift"],
            "cell",
            gpx.phase(0).get_cell(),
        )
    gpx.save()
    gpx.phase(0).export_CIF(str(OUTPUT.with_suffix(".cif")))


if __name__ == "__main__":
    main()
