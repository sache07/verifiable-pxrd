#!/usr/bin/env python3
"""Test the laboratory model's phase-wide isotropic displacement parameter."""

from pathlib import Path

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "coordinate_checkpoints" / "all_atoms.gpx"
OUTPUT = ROOT / "coordinate_checkpoints" / "all_atoms_uiso.gpx"


def main():
    gpx = G2sc.G2Project(str(SOURCE))
    gpx.save(str(OUTPUT))
    gpx.set_Controls("cycles", 10)
    gpx["Controls"]["data"]["min dM/M"] = 0.00002
    phase = gpx.phase(0)
    uvars = []
    for i, atom in enumerate(phase.atoms()):
        # The source CIF mixes anisotropic heavy-atom and isotropic oxygen
        # ADPs, while the laboratory realization uses a phase Uiso. Convert
        # all unique sites to isotropic form and constrain them together.
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.010
        atom.refinement_flags = "XU"
        uvars.append(f"0::AUiso:{i}")
    # The project was indexed on load and no atoms were added, so reindexing is
    # unnecessary here (and can race the just-written project on fast storage).
    gpx.add_EquivConstr(uvars, reloadIdx=False)
    gpx.set_Controls("parmMin", 0.001, variable="0::AUiso:0")
    gpx.set_Controls("parmMax", 0.030, variable="0::AUiso:0")
    for i in range(3):
        gpx.do_refinements([{}])
        h = gpx.histogram(0)
        print("UISO", i + 1, "RWP", h.residuals.get("wR"), "RF2", h.residuals.get("0:0:Rf^2"))
        for atom in phase.atoms():
            print("UATOM", atom.label, atom.element, atom.adp_flag, atom.ADP, atom.coordinates)
    gpx.save()
    phase.export_CIF(str(OUTPUT.with_suffix(".cif")))


if __name__ == "__main__":
    main()
