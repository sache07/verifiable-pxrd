#!/usr/bin/env python3
"""Test the three laboratory-supported uniaxial microstrain axes."""

from pathlib import Path
import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "coordinate_checkpoints" / "all_atoms.gpx"
OUT = ROOT / "profile_branches"


def limit(gpx, var, lo, hi):
    gpx.set_Controls("parmMin", lo, variable=var)
    gpx.set_Controls("parmMax", hi, variable=var)


def run(axis):
    name = "strain_" + "".join(map(str, axis))
    gpx = G2sc.G2Project(str(SOURCE))
    gpx.save(str(OUT / f"{name}.gpx"))
    gpx.set_Controls("cycles", 12)
    gpx["Controls"]["data"]["min dM/M"] = 0.00002
    h, p = gpx.histogram(0), gpx.phase(0)
    # Restart the correlated Gaussian profile terms away from their old bounds.
    h.InstrumentParameters["U"][1:3] = [10.0, True]
    h.InstrumentParameters["W"][1:3] = [30.0, True]
    for var in (":0:U", ":0:W", "0:0:Mustrain;i", "0:0:Mustrain;a"):
        gpx.set_Frozen(var, mode="remove")
    p.setSampleProfile(h, "microstrain", "uniaxial", 300.0, 300.0, axis=axis)
    p.set_HAP_refinements(
        {"Mustrain": {"type": "uniaxial", "refine": True, "direction": axis}}, [h]
    )
    limit(gpx, ":0:U", 0.0, 40.0)
    limit(gpx, ":0:W", 2.0, 40.0)
    limit(gpx, "0:0:Mustrain;i", 1.0, 8000.0)
    limit(gpx, "0:0:Mustrain;a", 1.0, 8000.0)
    for i in range(3):
        gpx.do_refinements([{}])
        print(
            "STRAIN",
            name,
            i + 1,
            "RWP",
            h.residuals.get("wR"),
            "U",
            h.InstrumentParameters["U"][1],
            "W",
            h.InstrumentParameters["W"][1],
            "mustrain",
            p.getHAPvalues(h)["Mustrain"],
            "frozen",
            gpx.get_Frozen(),
        )
    gpx.save()


def main():
    OUT.mkdir(exist_ok=True)
    for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0]):
        run(axis)


if __name__ == "__main__":
    main()
