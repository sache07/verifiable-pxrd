#!/usr/bin/env python3
"""Create the final replayable project and exports from the accepted model."""

from pathlib import Path
import json

import numpy as np
import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "final_candidates" / "uiso003_cheb30.gpx"
FINAL_GPX = ROOT / "final.gpx"
FINAL_CIF = ROOT / "phase_1_MnWO4.cif"
FINAL_FIT = ROOT / "fit.csv"


def main():
    gpx = G2sc.G2Project(str(SOURCE))
    gpx.save(str(FINAL_GPX))
    gpx.set_Controls("cycles", 12)
    gpx["Controls"]["data"]["min dM/M"] = 0.00001

    # Clear bookkeeping from bounded exploratory branches. Terms that reached
    # a physical endpoint are retained at that value but are fixed below.
    controls = gpx["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}

    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    hap = phase.getHAPvalues(hist)

    # Exactly one overall intensity scale is varied.
    sample["Scale"] = [1.0, False]
    hap["Scale"][1] = True

    # Supported calibration/specimen corrections.
    for key in ("Absorption", "DisplaceX", "DisplaceY", "Transparency"):
        if isinstance(sample.get(key), list) and len(sample[key]) > 1:
            sample[key][1] = False
    sample["Shift"][1] = True
    sample["SurfRoughA"][1] = False
    sample["SurfRoughB"][1] = True

    # The broadening decomposition is not unique for one phase. Keep the
    # physically bounded instrument endpoints fixed and refine the observable
    # isotropic size plus axial-divergence term. Unsupported strain is off.
    for key in inst:
        if isinstance(inst[key], list) and len(inst[key]) > 2:
            inst[key][2] = False
    inst["Polariz."][2] = True
    inst["SH/L"][2] = True
    hap["Size"][2] = [True, False, False]
    hap["Mustrain"][1][0] = 1.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False

    # Refine the cell and symmetry-allowed coordinates. Uiso is fixed to the
    # physical lower end supported by these data and the laboratory model.
    phase.set_refinements({"Cell": True})
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.003
        atom.refinement_flags = "X"

    hist.Background[0][0] = "chebyschev-1"
    hist.Background[0][1] = True
    hist.Limits("lower", 9.90343322)
    hist.Limits("upper", 100.09488522)

    # Two passes guarantee that the saved arrays and scalar residuals are from
    # the retained, unclamped model rather than a discarded trial step.
    for _ in range(2):
        gpx.do_refinements([{}])
    gpx.save()

    phase.export_CIF(str(FINAL_CIF))
    x, yobs, weight, ycalc, ybkg, ydiff = hist.data["data"][1]
    # GSAS-II stores ydiff as observed-calculated; recompute explicitly so the
    # CSV convention is unambiguous and exactly consistent with its other rows.
    diff = np.asarray(yobs) - np.asarray(ycalc)
    np.savetxt(
        FINAL_FIT,
        np.column_stack((x, yobs, ycalc, diff)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=("%.8f", "%.8f", "%.8f", "%.8f"),
    )

    mass_fracs = hist.ComputeMassFracs()
    stats = dict(hist.residuals)
    cov = gpx["Covariance"]["data"]
    print("FINAL_STATS", json.dumps(stats, sort_keys=True))
    print("FINAL_MASS_FRACS", mass_fracs)
    print("FINAL_CELL", phase.get_cell_and_esd())
    print("FINAL_ATOMS")
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.ADP, atom.refinement_flags)
    print("FINAL_INSTRUMENT", {k: v for k, v in inst.items()})
    print("FINAL_SAMPLE", sample)
    print("FINAL_HAP", {k: hap[k] for k in ("Scale", "Size", "Mustrain", "Pref.Ori.")})
    print("FINAL_BACKGROUND", hist.Background[0])
    print("FINAL_COV_KEYS", sorted(cov))
    print("FINAL_VARY_COUNT", len(cov.get("varyList", [])))
    print("FINAL_FROZEN", gpx.get_Frozen())
    print("FINAL_DIFF_CHECK", float(np.max(np.abs(diff - np.asarray(ydiff)))))


if __name__ == "__main__":
    main()
