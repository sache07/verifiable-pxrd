#!/usr/bin/env python3
"""Refine MnWO4 coordinates in heavy-then-light order and keep checkpoints."""

from pathlib import Path
import shutil

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "coordinate_checkpoints"
BASE = ROOT / "stabilized_branches" / "rough_joint.gpx"


def summary(gpx, label):
    h, p = gpx.histogram(0), gpx.phase(0)
    print("COORD", label, "RWP", h.residuals.get("wR"), "RF2", h.residuals.get("0:0:Rf^2"))
    for atom in p.atoms():
        print("ATOM", label, atom.label, atom.element, atom.coordinates, atom.refinement_flags, atom.ADP)


def refine_stage(source, output, atom_elements, cycles=2):
    gpx = G2sc.G2Project(str(source))
    gpx.save(str(output))
    gpx.set_Controls("cycles", 10)
    gpx["Controls"]["data"]["min dM/M"] = 0.00002
    phase = gpx.phase(0)
    for atom in phase.atoms():
        atom.refinement_flags = "X" if atom.element in atom_elements else " "
    for i in range(cycles):
        gpx.do_refinements([{}])
        summary(gpx, f"{output.stem}_{i + 1}")
    gpx.save()
    phase.export_CIF(str(output.with_suffix(".cif")))
    return output


def main():
    OUT.mkdir(exist_ok=True)
    heavy = refine_stage(BASE, OUT / "heavy.gpx", {"Mn", "W"}, cycles=2)
    refine_stage(heavy, OUT / "all_atoms.gpx", {"Mn", "W", "O"}, cycles=3)


if __name__ == "__main__":
    main()
