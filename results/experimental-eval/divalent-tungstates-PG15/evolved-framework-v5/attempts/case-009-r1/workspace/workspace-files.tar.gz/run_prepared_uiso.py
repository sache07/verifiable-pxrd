#!/usr/bin/env python3
"""Refine the already prepared all-isotropic MnWO4 project."""

from pathlib import Path
import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "coordinate_checkpoints" / "all_atoms_uiso.gpx"


def main():
    gpx = G2sc.G2Project(str(PROJECT))
    gpx.set_Controls("cycles", 10)
    gpx["Controls"]["data"]["min dM/M"] = 0.00002
    uvars = [f"0::AUiso:{i}" for i, _ in enumerate(gpx.phase(0).atoms())]
    if not gpx.get_Constraints("Phase"):
        gpx.add_EquivConstr(uvars)
    gpx.set_Controls("parmMin", 0.001, variable="0::AUiso:0")
    gpx.set_Controls("parmMax", 0.030, variable="0::AUiso:0")
    for i in range(3):
        gpx.do_refinements([{}])
        h = gpx.histogram(0)
        print("UISO", i + 1, "RWP", h.residuals.get("wR"), "RF2", h.residuals.get("0:0:Rf^2"))
        for atom in gpx.phase(0).atoms():
            print("UATOM", atom.label, atom.element, atom.adp_flag, atom.ADP, atom.coordinates)
    gpx.save()
    gpx.phase(0).export_CIF(str(PROJECT.with_suffix(".cif")))


if __name__ == "__main__":
    main()
