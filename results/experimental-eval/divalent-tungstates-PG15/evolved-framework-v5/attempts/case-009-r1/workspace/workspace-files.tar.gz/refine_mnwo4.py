#!/usr/bin/env python3
"""Build and incrementally refine the chemically motivated MnWO4 model."""

from pathlib import Path
import json
import shutil

import numpy as np
import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
START_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)


def snapshot(gpx, label):
    """Save a replayable checkpoint and report key physical parameters."""
    out = ROOT / "checkpoints" / f"{label}.gpx"
    out.parent.mkdir(exist_ok=True)
    gpx.save(str(out))
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    hap = phase.getHAPvalues(hist)
    inst = hist.InstrumentParameters
    samp = hist.SampleParameters
    print("CHECKPOINT", label)
    print(" residuals", hist.residuals)
    print(" cell", phase.get_cell())
    print(" inst", {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")})
    print(" sample", {k: v[0] if isinstance(v, list) else v for k, v in samp.items() if k in ("DisplaceX", "DisplaceY", "Scale", "SurfRoughA", "SurfRoughB")})
    print(" scale", hap["Scale"], "size", hap["Size"], "mustrain", hap["Mustrain"], "prefori", hap["Pref.Ori."])


def main():
    work = ROOT / ".tmp"
    work.mkdir(exist_ok=True)
    xye = work / "pattern.xye"
    # The source gives raw counts but no uncertainties. Use Poisson counting
    # uncertainties, sigma=sqrt(max(I,1)), throughout the refinement.
    dat = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    np.savetxt(
        xye,
        np.column_stack((dat["two_theta_deg"], dat["intensity"], np.sqrt(np.maximum(dat["intensity"], 1.0)))),
        fmt=("%.8f", "%.8f", "%.8f"),
    )

    project = ROOT / "working.gpx"
    gpx = G2sc.G2Project(newgpx=str(project))
    hist = gpx.add_powder_histogram(str(xye), str(ROOT / "cu_ka.instprm"), fmthint="xye")
    phase = gpx.add_phase(str(START_CIF), phasename="MnWO4_wolframite", histograms=[hist], fmthint="CIF")
    hist.Limits("lower", float(dat["two_theta_deg"][0]))
    hist.Limits("upper", float(dat["two_theta_deg"][-1]))

    # An exponential-like low-angle tail is present. A 12-term Chebyshev
    # background is flexible enough to represent it over the full 10-100 deg
    # range without following individual Bragg peaks.
    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 12, "refine": True}})
    phase.set_HAP_refinements({"Scale": True}, [hist])
    gpx.save()

    # Conservative progression: background/scale; lattice and specimen shift;
    # then instrument profile. Each stage is kept as a physical checkpoint.
    gpx.do_refinements([{}])
    snapshot(gpx, "01_scale_background")

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["DisplaceX"]})
    gpx.do_refinements([{}])
    snapshot(gpx, "02_cell_displacement")

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X"]})
    gpx.do_refinements([{}])
    snapshot(gpx, "03_profile")

    # Refine heavy-atom coordinates before oxygen coordinates. Set all imported
    # anisotropic ADPs to modest isotropic values to avoid unsupported ADPs.
    for atom in phase.atoms():
        if atom.element in ("Mn", "W"):
            atom.refinement_flags = "X"
    gpx.do_refinements([{}])
    snapshot(gpx, "04_heavy_coordinates")

    for atom in phase.atoms():
        atom.refinement_flags = "X"
    gpx.do_refinements([{}])
    snapshot(gpx, "05_all_coordinates")

    # Add only isotropic specimen broadening at first. The values are seeded in
    # the physically allowed synthesis/measurement ranges.
    phase.setSampleProfile(hist, "size", "isotropic", 0.3)
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    gpx.do_refinements([{}])
    snapshot(gpx, "06_size")

    phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0)
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    gpx.do_refinements([{}])
    snapshot(gpx, "07_size_strain")

    gpx.save(str(ROOT / "working.gpx"))


if __name__ == "__main__":
    main()
