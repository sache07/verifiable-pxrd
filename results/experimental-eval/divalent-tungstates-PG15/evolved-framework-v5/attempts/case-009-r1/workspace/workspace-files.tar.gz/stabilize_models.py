#!/usr/bin/env python3
"""Recompute/refine branches after GSAS-II has clamped bounded variables."""

from pathlib import Path
import shutil

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "stabilized_branches"


def limit(gpx, var, lo, hi):
    gpx.set_Controls("parmMin", lo, variable=var)
    gpx.set_Controls("parmMax", hi, variable=var)


def summarize(gpx, label):
    h, p = gpx.histogram(0), gpx.phase(0)
    hap = p.getHAPvalues(h)
    print(
        "STABLE",
        label,
        "RWP",
        h.residuals.get("wR"),
        "RF2",
        h.residuals.get("0:0:Rf^2"),
        "pol",
        h.InstrumentParameters["Polariz."][1],
        "rough",
        h.SampleParameters["SurfRoughA"][0],
        h.SampleParameters["SurfRoughB"][0],
        "PO",
        hap["Pref.Ori."][:4],
        "frozen",
        gpx.get_Frozen(),
    )


def stabilize(source, label, setup=None, n=2):
    gpx = G2sc.G2Project(str(source))
    gpx.save(str(OUT / f"{label}.gpx"))
    gpx.set_Controls("cycles", 10)
    gpx["Controls"]["data"]["min dM/M"] = 0.00005
    if setup:
        setup(gpx)
    for i in range(n):
        gpx.do_refinements([{}])
        summarize(gpx, f"{label}_{i + 1}")
    gpx.save()
    return OUT / f"{label}.gpx"


def fixed_a05(gpx):
    h = gpx.histogram(0)
    h.SampleParameters["SurfRoughA"] = [0.05, False]
    h.SampleParameters["SurfRoughB"] = [0.05, True]
    limit(gpx, ":0:SurfRoughB", 0.001, 0.8)


def joint_rough(gpx):
    h = gpx.histogram(0)
    h.SampleParameters["SurfRoughA"] = [0.10, True]
    h.SampleParameters["SurfRoughB"] = [0.05, True]
    h.InstrumentParameters["Polariz."][1] = 0.90
    h.InstrumentParameters["Polariz."][2] = True
    for var in (":0:Polariz.", ":0:SurfRoughA", ":0:SurfRoughB"):
        gpx.set_Frozen(var, mode="remove")
    limit(gpx, ":0:Polariz.", 0.5, 1.0)
    limit(gpx, ":0:SurfRoughA", 0.05, 0.6)
    limit(gpx, ":0:SurfRoughB", 0.02, 0.5)


def texture_setup(axis):
    def setup(gpx):
        h, p = gpx.histogram(0), gpx.phase(0)
        po = p.getHAPvalues(h)["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", 1.0, True, list(axis)
        limit(gpx, "0:0:MD", 0.7, 1.4)
    return setup


def main():
    OUT.mkdir(exist_ok=True)
    base = ROOT / "clean_checkpoints" / "06_polarization.gpx"
    rough = ROOT / "modifier_branches" / "surface_roughness.gpx"
    stabilize(base, "base", n=2)
    stabilize(rough, "rough_clamped", n=3)
    stabilize(base, "rough_a05", setup=fixed_a05, n=3)
    joint = stabilize(base, "rough_joint", setup=joint_rough, n=3)
    # Texture is tested only on the best complete roughness branch.
    for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]):
        name = "rough_md_" + "".join(map(str, axis))
        stabilize(joint, name, setup=texture_setup(axis), n=2)


if __name__ == "__main__":
    main()
