#!/usr/bin/env python3
"""Test Bragg-Brentano surface roughness from one physical start."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from test_candidate_phase import freeze_project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("A", type=float)
    parser.add_argument("B", type=float)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.base))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(args.output))
    freeze_project(project)
    project.set_Frozen()
    project.data["Constraints"]["data"]["Phase"] = []
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    hist.SampleParameters["SurfRoughA"] = [args.A, True]
    hist.SampleParameters["SurfRoughB"] = [args.B, True]
    project.data["Controls"]["data"]["shift factor"] = 0.1
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save(str(args.output))
    result = {
        "A": float(hist.SampleParameters["SurfRoughA"][0]),
        "B": float(hist.SampleParameters["SurfRoughB"][0]),
        "wR": hist.residuals.get("wR"),
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
