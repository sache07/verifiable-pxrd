#!/usr/bin/env python3
"""Build comparable GSAS-II trial refinements for candidate phase models."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


WORK = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_observation() -> tuple[Path, Path]:
    src = WORK / "inputs" / "pattern.csv"
    arr = np.genfromtxt(src, delimiter=",", names=True)
    x = np.asarray(arr["two_theta_deg"], float)
    y = np.asarray(arr["intensity"], float)
    xye = WORK / ".tmp" / "pattern.xye"
    xye.parent.mkdir(exist_ok=True)
    np.savetxt(
        xye,
        np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))),
        fmt=("%.8f", "%.8f", "%.8f"),
        header="two_theta intensity sigma",
    )
    inst = WORK / ".tmp" / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha laboratory instrument; initial profile for refinement\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.28;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def phase_mass_fraction(phase, hist_name: str) -> float:
    scale = float(phase.data["Histograms"][hist_name]["Scale"][0])
    mass = float(phase.data["General"]["Mass"])
    return scale * mass


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    raw = [phase_mass_fraction(p, hist.name) for p in project.phases()]
    total = sum(raw)
    fractions = [v / total for v in raw] if total > 0 else [float("nan") for v in raw]
    return {
        "label": label,
        "residuals": dict(hist.residuals),
        "fractions": fractions,
        "instrument": {
            k: hist.InstrumentParameters[k][1]
            for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")
            if k in hist.InstrumentParameters
        },
        "sample": {
            k: hist.SampleParameters[k][0]
            for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if k in hist.SampleParameters and isinstance(hist.SampleParameters[k], list)
        },
        "cells": {p.name: {k: float(v) for k, v in p.get_cell().items()} for p in project.phases()},
    }


def run(wo3_id: str, mno2_id: str, outdir: Path) -> None:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    xye, inst = prepare_observation()
    gpx = outdir / f"trial_{wo3_id}_{mno2_id}.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    wo3 = project.add_phase(str(cod_cif(wo3_id)), phasename=f"WO3_{wo3_id}", fmthint="CIF")
    mno2 = project.add_phase(str(cod_cif(mno2_id)), phasename=f"MnO2_{mno2_id}", fmthint="CIF")
    hist = project.add_powder_histogram(str(xye), str(inst), phases="all", fmthint="xye")
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.05)
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1000.0] + [0.0] * 11,
                "refine": True,
            }
        }
    )
    # Scales are proportional to weight fraction / unit-cell mass.
    for phase, frac in ((wo3, 0.73), (mno2, 0.27)):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 * frac / phase.data["General"]["Mass"], True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0

    project.set_Controls("cycles", 8)
    history = []

    def refine(label: str) -> None:
        project.refine(makeBack=False)
        project.save(str(gpx))
        state = snapshot(project, label)
        history.append(state)
        print(label, "wR", state["residuals"].get("wR"), "fractions", state["fractions"])

    refine("background_scales")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine("zero")
    wo3.set_refinements({"Cell": True})
    mno2.set_refinements({"Cell": True})
    refine("cells")
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    refine("instrument_profile")
    for phase in (wo3, mno2):
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True, "value": 0.30},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    refine("phase_profiles")
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine("shift")
    project.save(str(gpx))
    (outdir / f"trial_{wo3_id}_{mno2_id}.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("mno2_id")
    parser.add_argument("--outdir", type=Path, default=WORK / ".tmp" / "trials")
    args = parser.parse_args()
    run(args.wo3_id, args.mno2_id, args.outdir)
