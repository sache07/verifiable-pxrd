#!/usr/bin/env python3
"""Refine one uniaxial microstrain trial against a fixed checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from test_candidate_phase import freeze_project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("phase", type=int)
    parser.add_argument("axis", help="comma-separated h,k,l")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.base))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(args.output))
    freeze_project(project)
    project.set_Frozen()
    project.data["Constraints"]["data"]["Phase"] = []
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    phase = project.phase(args.phase)
    strain = phase.data["Histograms"][hist.name]["Mustrain"]
    start = float(strain[1][0])
    strain[0] = "uniaxial"
    strain[1][0] = start
    strain[1][1] = start
    strain[2][0] = True
    strain[2][1] = True
    strain[2][2] = False
    strain[3] = axis
    project.data["Controls"]["data"]["shift factor"] = 0.15
    project.set_Controls("cycles", 6)
    project.refine(makeBack=False)
    project.save(str(args.output))
    result = {
        "phase": phase.name,
        "axis": axis,
        "equatorial_ppm": float(strain[1][0]),
        "axial_ppm": float(strain[1][1]),
        "axial_ratio": float(strain[1][1] / strain[1][0]) if strain[1][0] else None,
        "wR": hist.residuals.get("wR"),
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
