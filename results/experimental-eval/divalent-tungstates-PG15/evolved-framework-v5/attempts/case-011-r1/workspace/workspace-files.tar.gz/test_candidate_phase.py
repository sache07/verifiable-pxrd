#!/usr/bin/env python3
"""Test whether one candidate phase has a stable positive residual scale."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


WORK = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def freeze_project(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        for hap in phase.data["Histograms"].values():
            hap["Scale"][1] = False
            hap["Pref.Ori."][2] = False
            hap["Size"][2] = [False] * len(hap["Size"][2])
            hap["Size"][5] = [False] * len(hap["Size"][5])
            hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def run(base: Path, candidate_id: str, name: str) -> None:
    G2.SetPrintLevel("warn")
    outdir = WORK / ".tmp" / "phase_tests"
    outdir.mkdir(parents=True, exist_ok=True)
    outgpx = outdir / f"{name}_{candidate_id}.gpx"
    project = G2.G2Project(gpxfile=str(base))
    project.save(str(outgpx))
    freeze_project(project)
    phase = project.add_phase(
        str(cod_cif(candidate_id)),
        phasename=f"candidate_{name}_{candidate_id}",
        histograms=project.histograms(),
        fmthint="CIF",
    )
    hist = project.histogram(0)
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.30
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    scale_only = {
        "wR": hist.residuals.get("wR"),
        "scale": hap["Scale"][0],
        "mass_term": hap["Scale"][0] * phase.data["General"]["Mass"],
        "frozen": project.get_Frozen(),
    }
    # If positive, allow the candidate cell to adjust modestly and re-evaluate.
    if hap["Scale"][0] > 0:
        phase.set_refinements({"Cell": True})
        project.refine(makeBack=False)
    final = {
        "wR": hist.residuals.get("wR"),
        "scale": hap["Scale"][0],
        "mass_term": hap["Scale"][0] * phase.data["General"]["Mass"],
        "cell": phase.get_cell(),
        "frozen": project.get_Frozen(),
    }
    project.save(str(outgpx))
    result = {"candidate": name, "cod_id": candidate_id, "scale_only": scale_only, "cell_refined": final}
    (outdir / f"{name}_{candidate_id}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("candidate_id")
    parser.add_argument("name")
    args = parser.parse_args()
    run(args.base, args.candidate_id, args.name)
