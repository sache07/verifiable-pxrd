#!/usr/bin/env python3
"""Refine one bounded March-Dollase trial against a fixed physical checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from test_candidate_phase import freeze_project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("phase", type=int)
    parser.add_argument("axis", help="comma-separated h,k,l")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.base))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(args.output))
    freeze_project(project)
    project.set_Frozen()
    # Remove unused coordinate/Uiso equivalences inherited from exploratory branches.
    project.data["Constraints"]["data"]["Phase"] = []
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    phase = project.phase(args.phase)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = axis
    project.data["Controls"]["data"]["shift factor"] = 0.2
    project.set_Controls("cycles", 6)
    project.refine(makeBack=False)
    project.save(str(args.output))
    result = {
        "phase": phase.name,
        "axis": axis,
        "ratio": float(pref[1]),
        "wR": hist.residuals.get("wR"),
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
