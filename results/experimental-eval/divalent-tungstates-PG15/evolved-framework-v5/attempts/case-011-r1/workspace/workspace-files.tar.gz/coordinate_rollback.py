#!/usr/bin/env python3
"""Evaluate physically capped coordinate variants along the refined direction."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_physical import mass_fractions
from test_candidate_phase import freeze_project


WORK = Path(__file__).resolve().parent
BASE = WORK / ".tmp" / "profile_refresh" / "03_mno2_strain.gpx"
SOURCE = WORK / ".tmp" / "WO3_2311041_reduced.cif"
OUT = WORK / ".tmp" / "coordinate_rollback"


def lattice_matrix(cell: list[float]) -> np.ndarray:
    a, b, c, alpha, beta, gamma = map(float, cell)
    ar, br, gr = np.deg2rad([alpha, beta, gamma])
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * np.cos(gr), b * np.sin(gr), 0.0])
    cx = c * np.cos(br)
    cy = c * (np.cos(ar) - np.cos(br) * np.cos(gr)) / np.sin(gr)
    vc = np.array([cx, cy, np.sqrt(max(c * c - cx * cx - cy * cy, 0.0))])
    return np.array([va, vb, vc])


def source_coordinates() -> tuple[np.ndarray, list[str], np.ndarray]:
    scratch = G2.G2Project(newgpx=str(OUT / "source_scratch.gpx"))
    phase = scratch.add_phase(str(SOURCE), phasename="source", fmthint="CIF")
    xyz = np.array([atom.coordinates for atom in phase.atoms()], float)
    elements = [atom.element for atom in phase.atoms()]
    matrix = lattice_matrix(phase.data["General"]["Cell"][1:7])
    return xyz, elements, matrix


def set_wo3_rms(phase, source: np.ndarray, elements: list[str], matrix: np.ndarray,
                 target_w: float, target_o: float) -> dict[str, float]:
    refined = np.array([atom.coordinates for atom in phase.atoms()], float)
    delta = refined - source
    delta -= np.rint(delta)
    achieved = {}
    for element, target in (("W", target_w), ("O", target_o)):
        mask = np.array([e == element for e in elements])
        current = float(np.sqrt(np.mean(np.sum((delta[mask] @ matrix) ** 2, axis=1))))
        delta[mask] *= 0.0 if target == 0 else target / current
        achieved[element] = target
    xyz = (source + delta) % 1.0
    for atom, coords in zip(phase.atoms(), xyz):
        atom.coordinates = list(map(float, coords))
    return achieved


def run(target_w: float, target_o: float, mno2_o_rms: float = 0.0) -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    source, elements, matrix = source_coordinates()
    tag = f"w{target_w:.3f}_o{target_o:.3f}_mno{mno2_o_rms:.3f}".replace(".", "p")
    path = OUT / f"{tag}.gpx"
    project = G2.G2Project(gpxfile=str(BASE))
    # Change the active project filename before refinement so the immutable
    # accepted checkpoint cannot be updated by GSAS-II's normal autosave.
    project.save(str(path))
    hist = project.histogram(0)
    wo3, mno2 = project.phases()
    set_wo3_rms(wo3, source, elements, matrix, target_w, target_o)

    # Rutile O has x=y; a positive shift is selected by the observed intensities.
    a = float(mno2.data["General"]["Cell"][1])
    dx = mno2_o_rms / (np.sqrt(2.0) * a)
    oxygen = mno2.atoms()[1]
    oxygen.coordinates = [0.303 + dx, 0.303 + dx, 0.0]

    freeze_project(project)
    project.set_Frozen()
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.2
    project.refine(makeBack=False)

    project.save(str(path))
    result = {
        "target_rms_A": {"W_in_WO3": target_w, "O_in_WO3": target_o, "O_in_MnO2": mno2_o_rms},
        "rwp_percent": float(hist.residuals["wR"]),
        "rp_percent": float(hist.residuals["R"]),
        "weight_fractions": mass_fractions(project),
        "project": str(path),
    }
    path.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--w-rms", type=float)
    parser.add_argument("--o-rms", type=float)
    parser.add_argument("--mno2-o-rms", type=float, default=0.0)
    parser.add_argument("--grid", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    if args.grid:
        results = []
        for w in (0.0, 0.01, 0.02, 0.03, 0.04):
            for o in (0.0, 0.01, 0.02, 0.03, 0.04, 0.05):
                results.append(run(w, o, args.mno2_o_rms))
        (OUT / "grid.json").write_text(json.dumps(results, indent=2) + "\n")
    else:
        if args.w_rms is None or args.o_rms is None:
            parser.error("--w-rms and --o-rms are required without --grid")
        run(args.w_rms, args.o_rms, args.mno2_o_rms)


if __name__ == "__main__":
    main()
