#!/usr/bin/env python3
"""Refine the physical reduced-cell setting of COD 2311041."""

from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_physical import mass_fractions, prepare_observation, snapshot
from test_candidate_phase import cod_cif, freeze_project


WORK = Path(__file__).resolve().parent
OUT = WORK / ".tmp" / "reduced_branch"


def save_state(project: G2.G2Project, history: list[dict], label: str) -> None:
    path = OUT / f"{len(history):02d}_{label}.gpx"
    project.save(str(path))
    state = snapshot(project, label)
    history.append(state)
    print(label, "wR", state["residuals"].get("wR"), "fractions", state["weight_fractions"], "frozen", state["frozen"])


def main() -> None:
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    parent = G2.G2Project(gpxfile=str(WORK / ".tmp" / "controlled_cells_2311041.gpx"))
    parent_hist = parent.histogram(0)
    xye, inst = prepare_observation()
    project = G2.G2Project(newgpx=str(OUT / "working.gpx"))
    wo3 = project.add_phase(str(WORK / ".tmp" / "WO3_2311041_reduced.cif"), phasename="WO3_monoclinic", fmthint="CIF")
    mno2 = project.add_phase(str(cod_cif("1514110")), phasename="MnO2_rutile", fmthint="CIF")
    hist = project.add_powder_histogram(str(xye), str(inst), phases="all", fmthint="xye")
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.05)
    hist.Background[:] = copy.deepcopy(parent_hist.Background)
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key] = copy.deepcopy(parent_hist.SampleParameters[key])
        hist.SampleParameters[key][1] = False
    for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"):
        hist.InstrumentParameters[key][1] = float(parent_hist.InstrumentParameters[key][1])
        hist.InstrumentParameters[key][2] = False

    # Copy phase intensity/profile values from the equivalent parent setting.
    for phase, old_phase in zip((wo3, mno2), parent.phases()):
        hap = phase.data["Histograms"][hist.name]
        old_hap = old_phase.data["Histograms"][parent_hist.name]
        hap["Scale"] = copy.deepcopy(old_hap["Scale"])
        hap["Scale"][1] = False
        hap["Size"] = copy.deepcopy(old_hap["Size"])
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"] = copy.deepcopy(old_hap["Mustrain"])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."] = copy.deepcopy(old_hap["Pref.Ori."])
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
            atom.uiso = 0.008
    # The MnO2 setting is unchanged, so transfer its already-refined cell exactly.
    mno2.data["General"]["Cell"][1:8] = copy.deepcopy(parent.phase(1).data["General"]["Cell"][1:8])

    freeze_project(project)
    project.set_Frozen()
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.2
    history: list[dict] = []

    # Refit only quantities affected by the equivalent cell-setting change.
    hist.Background[0][1] = True
    for phase in (wo3, mno2):
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    wo3.set_refinements({"Cell": True})
    project.refine(makeBack=False)
    save_state(project, history, "reduced_cell")

    # Heavy coordinates; the orthogonalized cell makes shifts directly interpretable.
    freeze_project(project)
    hist.Background[0][1] = True
    for phase in (wo3, mno2):
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    heavy_start = {}
    for atom in wo3.atoms():
        if atom.element == "W":
            heavy_start[atom.label] = list(atom.coordinates)
            atom.refinement_flags = "X"
    project.data["Controls"]["data"]["shift factor"] = 0.1
    project.set_Controls("cycles", 5)
    project.refine(makeBack=False)
    save_state(project, history, "heavy_coordinates")

    # Oxygen coordinates are bounded to the supplied reference-mismatch scale.
    freeze_project(project)
    project.set_Frozen()
    hist.Background[0][1] = True
    for phase in (wo3, mno2):
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    oxygen_start = {}
    for i, atom in enumerate(wo3.atoms()):
        if atom.element != "O":
            continue
        xyz = list(atom.coordinates)
        oxygen_start[atom.label] = xyz
        atom.refinement_flags = "X"
        for j, axis in enumerate("xyz"):
            project.set_Controls("parmMin", xyz[j] - 0.008, variable=f"{wo3.id}::dA{axis}:{i}")
            project.set_Controls("parmMax", xyz[j] + 0.008, variable=f"{wo3.id}::dA{axis}:{i}")
    project.data["Controls"]["data"]["shift factor"] = 0.03
    project.set_Controls("cycles", 4)
    project.refine(makeBack=False)
    save_state(project, history, "oxygen_coordinates")

    # Per-phase Uiso: all sites in a generated phase share one value.
    freeze_project(project)
    project.set_Frozen()
    hist.Background[0][1] = True
    for phase in (wo3, mno2):
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        for atom in phase.atoms():
            atom.refinement_flags = "U"
        project.add_EquivConstr([f"{phase.id}::AUiso:{i}" for i in range(len(phase.atoms()))])
        project.set_Controls("parmMin", 0.003, variable=f"{phase.id}::AUiso:*")
        project.set_Controls("parmMax", 0.020, variable=f"{phase.id}::AUiso:*")
    project.data["Controls"]["data"]["shift factor"] = 0.2
    project.set_Controls("cycles", 5)
    project.refine(makeBack=False)
    save_state(project, history, "phase_uiso")

    project.save(str(OUT / "accepted.gpx"))
    (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
