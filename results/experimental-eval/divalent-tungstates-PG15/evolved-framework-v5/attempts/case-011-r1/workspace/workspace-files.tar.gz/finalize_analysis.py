#!/usr/bin/env python3
"""Create the final replayable GSAS-II project and machine-readable outputs."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_physical import mass_fractions
from test_candidate_phase import freeze_project


WORK = Path(__file__).resolve().parent
BASE = WORK / ".tmp" / "coordinate_rollback" / "w0p040_o0p050_mno0p010.gpx"
CHECKPOINTS = WORK / ".tmp" / "finalize"


def prepare(project: G2.G2Project) -> None:
    freeze_project(project)
    project.set_Frozen()
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    project.set_Controls("cycles", 15)
    project.data["Controls"]["data"]["shift factor"] = 0.25


def summary(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "label": label,
        "rwp_percent": float(hist.residuals["wR"]),
        "rp_percent": float(hist.residuals["R"]),
        "rexp_percent": float(hist.residuals["wRmin"]),
        "gof": float(cov.get("GOF", hist.residuals["wR"] / hist.residuals["wRmin"])),
        "fractions": mass_fractions(project),
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "surface_roughness": [
            float(hist.SampleParameters["SurfRoughA"][0]),
            float(hist.SampleParameters["SurfRoughB"][0]),
        ],
        "mno2_md_ratio": float(project.phase(1).data["Histograms"][hist.name]["Pref.Ori."][1]),
        "frozen": project.get_Frozen(),
    }


def refine(project: G2.G2Project, number: int, label: str) -> dict:
    project.refine(makeBack=False)
    path = CHECKPOINTS / f"{number:02d}_{label}.gpx"
    project.save(str(path))
    result = summary(project, label)
    print(json.dumps(result))
    return result


def fraction_esds(project: G2.G2Project) -> dict[str, float | None]:
    dep = project.data["Covariance"]["data"].get("depSigDict", {})
    hist = project.histogram(0)
    result = {}
    for phase in project.phases():
        key = f"{phase.id}:{hist.id}:WgtFrac"
        item = dep.get(key)
        result[phase.name] = None if item is None else float(item[1])
    return result


def main() -> None:
    G2.SetPrintLevel("warn")
    CHECKPOINTS.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(CHECKPOINTS / "start.gpx"))
    hist = project.histogram(0)
    x = np.asarray(hist.data["data"][1][0], float)
    hist.Limits("lower", float(x[0]))
    hist.Limits("upper", float(x[-1]))
    history = []

    # Refit the empirical background and phase scales on every measured bin.
    prepare(project)
    history.append(refine(project, 1, "full_grid_scales_background"))

    # Refresh only intensity corrections that were independently supported.
    prepare(project)
    hist.InstrumentParameters["Polariz."][2] = True
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    history.append(refine(project, 2, "polarization"))

    prepare(project)
    pref = project.phase(1).data["Histograms"][hist.name]["Pref.Ori."]
    pref[2] = True
    project.set_Controls("parmMin", 0.7, variable=f"{project.phase(1).id}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{project.phase(1).id}:0:MD")
    history.append(refine(project, 3, "mno2_preferred_orientation"))

    prepare(project)
    hist.SampleParameters["SurfRoughA"][1] = True
    hist.SampleParameters["SurfRoughB"][1] = True
    project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    history.append(refine(project, 4, "surface_roughness"))

    # End with the quantities that define the reported crystalline abundance.
    prepare(project)
    history.append(refine(project, 5, "final_scales_background"))
    project.save(str(WORK / "final.gpx"))

    fractions = mass_fractions(project)
    esds = fraction_esds(project)
    cif_names = ["phase_WO3.cif", "phase_MnO2.cif"]
    for phase, filename in zip(project.phases(), cif_names):
        phase.export_CIF(str(WORK / filename))

    arrays = np.asarray(hist.data["data"][1], float)
    x, observed, calculated = arrays[0], arrays[1], arrays[3]
    difference = observed - calculated
    np.savetxt(
        WORK / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    stats = summary(project, "submitted")
    phase_rows = []
    identities = [
        ("monoclinic WO3", "WO3", "P 1 21/n 1"),
        ("rutile beta-MnO2", "MnO2", "P 42/m n m"),
    ]
    for phase, filename, fraction, identity in zip(project.phases(), cif_names, fractions, identities):
        name, formula, space_group = identity
        phase_rows.append(
            {
                "name": name,
                "formula": formula,
                "space_group": space_group,
                "cif_path": filename,
                "weight_fraction": float(fraction),
                "weight_fraction_esd": esds.get(phase.name),
            }
        )
    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent": stats["rwp_percent"],
            "rp_percent": stats["rp_percent"],
            "rexp_percent": stats["rexp_percent"],
            "goodness_of_fit": stats["gof"],
            "n_points": int(len(x)),
        },
        "refinement_histogram": hist.name,
        "weight_fraction_basis": "normalized over the modeled crystalline phases; no amorphous fraction determined",
        "profile_file": "fit.csv",
        "project_file": "final.gpx",
    }
    (WORK / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    (CHECKPOINTS / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
