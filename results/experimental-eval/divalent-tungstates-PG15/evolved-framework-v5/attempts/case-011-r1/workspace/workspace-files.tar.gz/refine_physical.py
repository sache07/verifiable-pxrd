#!/usr/bin/env python3
"""Physically bounded full-grid GSAS-II refinement of WO3 + rutile MnO2."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


WORK = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_observation() -> tuple[Path, Path]:
    arr = np.genfromtxt(WORK / "inputs" / "pattern.csv", delimiter=",", names=True)
    x = np.asarray(arr["two_theta_deg"], float)
    y = np.asarray(arr["intensity"], float)
    xye = WORK / ".tmp" / "pattern.xye"
    xye.parent.mkdir(exist_ok=True)
    np.savetxt(
        xye,
        np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))),
        fmt=("%.8f", "%.8f", "%.8f"),
        header="two_theta intensity sigma",
    )
    inst = WORK / ".tmp" / "instrument_physical.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha laboratory instrument; physical initial profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:15.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def mass_fractions(project: G2.G2Project) -> list[float]:
    hist = project.histogram(0)
    terms = [
        float(p.data["Histograms"][hist.name]["Scale"][0]) * float(p.data["General"]["Mass"])
        for p in project.phases()
    ]
    total = sum(terms)
    return [v / total for v in terms]


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": {k: float(v) for k, v in phase.get_cell().items()},
                "scale": float(hap["Scale"][0]),
                "size": list(map(float, hap["Size"][1])),
                "mustrain": list(map(float, hap["Mustrain"][1])),
                "pref_ori": [hap["Pref.Ori."][0], float(hap["Pref.Ori."][1]), list(hap["Pref.Ori."][3])],
                "atoms": [
                    {
                        "label": a.label,
                        "element": a.element,
                        "xyz": list(map(float, a.coordinates)),
                        "uiso": float(a.uiso),
                        "flags": a.refinement_flags,
                    }
                    for a in phase.atoms()
                ],
            }
        )
    return {
        "label": label,
        "residuals": {k: v for k, v in hist.residuals.items() if isinstance(v, (int, float))},
        "weight_fractions": mass_fractions(project),
        "instrument": {
            k: float(hist.InstrumentParameters[k][1])
            for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")
            if k in hist.InstrumentParameters
        },
        "sample": {
            k: float(hist.SampleParameters[k][0])
            for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if k in hist.SampleParameters and isinstance(hist.SampleParameters[k], list)
        },
        "phases": phases,
        "frozen": project.get_Frozen(),
    }


def set_bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def run(wo3_id: str, mno2_id: str, outdir: Path) -> None:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    xye, inst = prepare_observation()
    work_gpx = outdir / "working.gpx"
    project = G2.G2Project(newgpx=str(work_gpx))
    wo3 = project.add_phase(str(cod_cif(wo3_id)), phasename=f"WO3_{wo3_id}", fmthint="CIF")
    mno2 = project.add_phase(str(cod_cif(mno2_id)), phasename=f"MnO2_{mno2_id}", fmthint="CIF")
    hist = project.add_powder_histogram(str(xye), str(inst), phases="all", fmthint="xye")
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.05)
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-600.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1000.0] + [0.0] * 11,
                "refine": True,
            }
        }
    )

    for phase, frac in ((wo3, 0.73), (mno2, 0.27)):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 * frac / phase.data["General"]["Mass"], True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        for atom in phase.atoms():
            atom.refinement_flags = " "
            atom.uiso = 0.008

    project.update_ids()
    project.save(str(work_gpx))
    # Bounds supplied by the measurement/specimen protocol.
    for var, lo, hi in (
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:Polariz.", 0.5, 1.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
    ):
        set_bound(project, var, lo, hi)
    for phase in (wo3, mno2):
        set_bound(project, f"{phase.id}:0:Scale", 0.0, 1.0e6)
        set_bound(project, f"{phase.id}:0:Size;i", 0.04, 1.50)
        set_bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{phase.id}::AUiso:*", 0.003, 0.020)
        for i, _atom in enumerate(phase.atoms()):
            for axis in "xyz":
                set_bound(project, f"{phase.id}::dA{axis}:{i}", -0.015, 0.015)

    # All atoms in each generated phase share one isotropic displacement parameter.
    if len(wo3.atoms()) > 1:
        project.add_EquivConstr([f"{wo3.id}::AUiso:{i}" for i in range(len(wo3.atoms()))])
    if len(mno2.atoms()) > 1:
        project.add_EquivConstr([f"{mno2.id}::AUiso:{i}" for i in range(len(mno2.atoms()))])

    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["shift factor"] = 0.7
    history = []

    def refine(label: str) -> None:
        project.refine(makeBack=False)
        checkpoint = outdir / f"{len(history):02d}_{label}.gpx"
        project.save(str(checkpoint))
        state = snapshot(project, label)
        history.append(state)
        print(label, "wR", state["residuals"].get("wR"), "fractions", state["weight_fractions"], "frozen", state["frozen"])

    refine("background_scales")
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine("sample_shift")
    wo3.set_refinements({"Cell": True})
    mno2.set_refinements({"Cell": True})
    refine("cells_shift")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine("zero_cells_shift")

    # Instrument calibration/profile, kept inside physically supplied ranges.
    hist.set_refinements({"Instrument Parameters": ["W"]})
    refine("instrument_W")
    hist.set_refinements({"Instrument Parameters": ["U"]})
    refine("instrument_UW")
    hist.set_refinements({"Instrument Parameters": ["X", "SH/L", "Polariz."]})
    refine("instrument_full")

    # Heavy-atom coordinates first.
    for atom in wo3.atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"
    refine("heavy_coordinates")
    # Then oxygen coordinates, retaining heavy-coordinate refinement.
    for phase in (wo3, mno2):
        for atom in phase.atoms():
            if atom.element == "O":
                atom.refinement_flags = "X"
    refine("light_coordinates")
    # Uniform phase Uiso terms are refined only after coordinates are stable.
    for phase in (wo3, mno2):
        for atom in phase.atoms():
            atom.refinement_flags = atom.refinement_flags.replace("U", "") + "U"
    refine("phase_uiso")

    # Phase profile terms are added one supported level at a time.
    for phase in (wo3, mno2):
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True, "value": 0.30}})
    refine("isotropic_size")
    for phase in (wo3, mno2):
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine("isotropic_microstrain")

    project.save(str(outdir / "physical.gpx"))
    (outdir / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("--mno2-id", default="1514110")
    parser.add_argument("--outdir", type=Path)
    args = parser.parse_args()
    output = args.outdir or (WORK / ".tmp" / f"physical_{args.wo3_id}")
    run(args.wo3_id, args.mno2_id, output)
