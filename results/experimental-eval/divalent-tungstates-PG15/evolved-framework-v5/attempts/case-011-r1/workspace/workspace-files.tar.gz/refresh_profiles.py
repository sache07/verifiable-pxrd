#!/usr/bin/env python3
"""Refresh only the accepted phase-profile terms from the physical checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_physical import mass_fractions
from test_candidate_phase import freeze_project


WORK = Path(__file__).resolve().parent
BASE = WORK / ".tmp" / "profile_pass_physical2" / "03_pol.gpx"
OUT = WORK / ".tmp" / "profile_refresh"


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "label": label,
        "rwp_percent": float(cov.get("Rwp", hist.residuals.get("wR"))),
        "gof": float(cov.get("GOF", float("nan"))),
        "weight_fractions": mass_fractions(project),
        "frozen": project.get_Frozen(),
        "profiles": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
    }


def prepare_step(project: G2.G2Project) -> None:
    freeze_project(project)
    project.set_Frozen()
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.12


def refine_step(project: G2.G2Project, number: int, label: str) -> dict:
    project.refine(makeBack=False)
    path = OUT / f"{number:02d}_{label}.gpx"
    project.save(str(path))
    result = state(project, label)
    print(json.dumps(result, default=str))
    return result


def main() -> None:
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(OUT / "start.gpx"))
    hist = project.histogram(0)
    wo3, mno2 = project.phases()
    history = [state(project, "start")]

    # The WO3 Lorentzian size term is supported and remains isotropic.
    prepare_step(project)
    whap = wo3.data["Histograms"][hist.name]
    whap["Size"][2][0] = True
    project.set_Controls("parmMin", 0.04, variable=f"{wo3.id}:0:Size;i")
    project.set_Controls("parmMax", 1.50, variable=f"{wo3.id}:0:Size;i")
    history.append(refine_step(project, 1, "wo3_size"))

    # Refresh both components of the accepted [001] uniaxial WO3 microstrain.
    prepare_step(project)
    whap["Mustrain"][2][0] = True
    whap["Mustrain"][2][1] = True
    for suffix in ("i", "a"):
        project.set_Controls("parmMin", 300.0, variable=f"{wo3.id}:0:Mustrain;{suffix}")
        project.set_Controls("parmMax", 8000.0, variable=f"{wo3.id}:0:Mustrain;{suffix}")
    history.append(refine_step(project, 2, "wo3_strain"))

    # Refresh the supported isotropic MnO2 microstrain. Its size was already
    # driven to the physical upper bound and is intentionally held fixed.
    prepare_step(project)
    mhap = mno2.data["Histograms"][hist.name]
    mhap["Mustrain"][2][0] = True
    project.set_Controls("parmMin", 300.0, variable=f"{mno2.id}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{mno2.id}:0:Mustrain;i")
    history.append(refine_step(project, 3, "mno2_strain"))

    project.save(str(OUT / "accepted.gpx"))
    (OUT / "history.json").write_text(json.dumps(history, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
