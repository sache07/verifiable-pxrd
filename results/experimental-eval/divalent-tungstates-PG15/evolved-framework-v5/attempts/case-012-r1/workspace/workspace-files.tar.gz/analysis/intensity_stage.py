#!/usr/bin/env python3
"""Test one bounded intensity-modifying specimen/instrument term."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument(
        "mode",
        choices=("polar", "rough", "rough-b", "po-ni", "po-wo"),
    )
    parser.add_argument("--axis", default="0,0,1")
    args = parser.parse_args()

    project = G2sc.G2Project(args.input, newgpx=str(Path(args.output).resolve()))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)

    if args.mode == "polar":
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif args.mode == "rough":
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")
        hist.SampleParameters["SurfRoughA"][0] = 0.3
        hist.SampleParameters["SurfRoughB"][0] = 0.05
        hist.set_refinements(
            {"Sample Parameters": ["SurfRoughA", "SurfRoughB"]}
        )
    elif args.mode == "rough-b":
        # Replay a boundary solution without leaving a stale, clipped profile:
        # A is held at its physical lower bound and only B is optimized.
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")
        hist.SampleParameters["SurfRoughA"] = [0.0, False]
        if hist.SampleParameters["SurfRoughB"][0] <= 0:
            hist.SampleParameters["SurfRoughB"][0] = 0.04
        hist.SampleParameters["SurfRoughB"][1] = True
    else:
        target = "NiWO4" if args.mode == "po-ni" else "WO3"
        phase = project.phase(target)
        axis = [int(value) for value in args.axis.split(",")]
        hap = phase.data["Histograms"][hist.name]["Pref.Ori."]
        hap[0] = "MD"
        hap[1] = 1.0
        hap[2] = True
        hap[3] = axis
        project.set_Controls(
            "parmMin", 0.7, variable=f"{phase.id}:0:MD"
        )
        project.set_Controls(
            "parmMax", 1.4, variable=f"{phase.id}:0:MD"
        )

    project.save()
    project.refine(makeBack=False)
    project.save()
    print("residuals", hist.residuals)
    print("frozen", project.get_Frozen())
    print("polarization", hist.InstrumentParameters["Polariz."])
    print(
        "roughness",
        hist.SampleParameters["SurfRoughA"],
        hist.SampleParameters["SurfRoughB"],
    )
    for phase in project.phases():
        print(
            phase.name,
            "preferred_orientation",
            phase.data["Histograms"][hist.name]["Pref.Ori."],
        )


if __name__ == "__main__":
    main()
