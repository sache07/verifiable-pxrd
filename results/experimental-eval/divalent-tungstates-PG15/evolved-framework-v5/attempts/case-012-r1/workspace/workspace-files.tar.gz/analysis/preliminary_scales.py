#!/usr/bin/env python3
"""Fit only global/background and phase scales to screen an inventory."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def summarize(project: G2sc.G2Project, label: str) -> None:
    histogram = project.histogram(0)
    print(f"\n=== {label} ===")
    print("residuals", histogram.residuals)
    print("sample scale", histogram.SampleParameters["Scale"])
    total = 0.0
    vals = []
    for phase in project.phases():
        scale = phase.data["Histograms"][histogram.name]["Scale"][0]
        mass = phase.data["General"]["Mass"]
        vals.append((phase.name, scale, mass))
        total += max(scale, 0.0) * mass
    for name, scale, mass in vals:
        fraction = max(scale, 0.0) * mass / total if total else float("nan")
        print(name, "scale", scale, "mass", mass, "fraction", fraction)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()

    project = G2sc.G2Project(args.input, newgpx=str(Path(args.output).resolve()))
    histogram = project.histogram(0)
    project.set_Controls("cycles", 12)

    guesses = {
        "NiWO4": 0.80,
        "WO3": 0.17,
        "NiO": 0.03,
    }
    # Initial HAP scales are proportional to weight fraction / unit-cell mass.
    # An arbitrary common multiplier keeps them near one.
    for phase in project.phases():
        mass = phase.data["General"]["Mass"]
        phase.HAPvalue("Scale", 1000.0 * guesses.get(phase.name, 0.01) / mass)
        phase.clear_HAP_refinements({"Scale": False})

    histogram.SampleParameters["Scale"][:] = [1.0, True]
    histogram.set_refinements({"Background": {"refine": True}})
    project.save()
    project.refine(makeBack=False)
    summarize(project, "common scale and background")

    common_scale = histogram.SampleParameters["Scale"][0]
    histogram.SampleParameters["Scale"][:] = [1.0, False]
    for phase in project.phases():
        phase.HAPvalue("Scale", phase.HAPvalue("Scale") * common_scale)
        phase.set_HAP_refinements({"Scale": True})
    project.save()
    project.refine(makeBack=False)
    summarize(project, "independent phase scales")
    project.save()


if __name__ == "__main__":
    main()
