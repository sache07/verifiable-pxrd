#!/usr/bin/env python3
"""Prepare traceable candidate CIFs from the frozen COD reference index."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
OUT = Path(__file__).resolve().parent / "models"


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_structure(structure: Structure, name: str, symprec: float = 1e-3) -> None:
    structure.add_site_property(
        "source_note",
        ["frozen COD analogue; see analysis/prepare_models.py"] * len(structure),
    )
    # refine_struct standardizes the setting; this is needed for GSAS-II's
    # conventional space-group implementation (notably for COD 1528915).
    CifWriter(structure, symprec=symprec, refine_struct=True).write_file(OUT / name)


def make_niwo4(parent_id: str, parent_element: str, name: str) -> None:
    structure = Structure.from_file(cod_path(parent_id), primitive=False)
    structure.replace_species({parent_element: "Ni"})
    # The malformed exact-composition COD 5910277 record still supplies a
    # chemically reasonable NiWO4 cell. Coordinates come only from the intact
    # wolframite analogue named by parent_id.
    structure.lattice = Lattice.monoclinic(4.600, 5.665, 4.912, 90.5)
    write_structure(structure, name)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    make_niwo4("1520641", "Zn", "niwo4_from_znwo4_1520641.cif")
    make_niwo4("9013902", "Mg", "niwo4_from_mgwo4_9013902.cif")
    make_niwo4("1520200", "Mn", "niwo4_from_mnwo4_1520200.cif")

    for cod_id, name in [
        ("1528915", "wo3_monoclinic_1528915.cif"),
        ("2311041", "wo3_monoclinic_neutron_2311041.cif"),
        ("2106293", "wo3_triclinic_2106293.cif"),
        ("1010093", "nio_1010093.cif"),
    ]:
        structure = Structure.from_file(cod_path(cod_id), primitive=False)
        write_structure(structure, name)


if __name__ == "__main__":
    main()
