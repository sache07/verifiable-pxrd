#!/usr/bin/env python3
"""Create a clean, full-grid, replayable final-refinement checkpoint."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()

    output = Path(args.output).resolve()
    project = G2sc.G2Project(args.input, newgpx=str(output))
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)

    # Use every supplied point and ensure clipped trial variables are now
    # ordinary fixed physical parameters, rather than stale frozen variables.
    x = hist.data["data"][1][0]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    for name in ("W", "X"):
        hist.InstrumentParameters[name][2] = False
    hist.SampleParameters["SurfRoughA"][1] = False
    project.set_Frozen()

    # Coordinates were accepted or rolled back in dedicated stages. Keep the
    # accepted structure fixed while replay-refining scales, cells and profile.
    for phase in project.phases():
        phase.clear_refinements(
            {"Atoms": [atom.label for atom in phase.atoms()]}
        )

    project.save()
    project.refine(makeBack=False)
    project.save()

    covariance = project.data["Covariance"]["data"]
    print("residuals", hist.residuals)
    print("Rvals", covariance.get("Rvals"))
    print("limits", hist.data["Limits"])
    print("frozen", project.get_Frozen())
    print("mass_fractions", hist.ComputeMassFracs())
    print(
        "profile_endpoints",
        tuple(float(a[0]) for a in hist.data["data"][1][:6]),
        tuple(float(a[-1]) for a in hist.data["data"][1][:6]),
    )
    for phase in project.phases():
        print(phase.name, phase.get_cell())


if __name__ == "__main__":
    main()
