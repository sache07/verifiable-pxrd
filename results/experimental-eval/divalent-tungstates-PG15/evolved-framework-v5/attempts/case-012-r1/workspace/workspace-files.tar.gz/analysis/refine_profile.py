#!/usr/bin/env python3
"""Refine supported instrument and phase line-profile terms in stages."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def summarize(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"\n=== {label} ===")
    print("residuals", hist.residuals)
    print(
        "instrument",
        {k: hist.InstrumentParameters[k] for k in ("U", "V", "W", "X", "Y", "SH/L")},
    )
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "Size", hap["Size"], "Mustrain", hap["Mustrain"])


def run(project: G2sc.G2Project, output: Path, label: str) -> None:
    project.save(str(output))
    project.refine(makeBack=False)
    project.save(str(output))
    summarize(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    output = Path(args.output).resolve()
    stem = output.with_suffix("")

    project = G2sc.G2Project(args.input, newgpx=str(output))
    hist = project.histogram(0)
    project.set_Controls("cycles", 12)
    # The zero+cell checkpoint is preferred: Shift and Zero were >99.9%
    # correlated and adding Shift did not improve Rwp.
    hist.SampleParameters["Shift"][:] = [0.0, False]

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    run(project, Path(f"{stem}_wx.gpx"), "instrument W + X")

    hist.set_refinements({"Instrument Parameters": ["U", "SH/L"]})
    run(project, Path(f"{stem}_inst.gpx"), "instrument U + W + X + SH/L")

    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
        )
    run(project, Path(f"{stem}_size.gpx"), "isotropic phase sizes")

    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    run(project, output, "isotropic sizes + microstrain")


if __name__ == "__main__":
    main()
