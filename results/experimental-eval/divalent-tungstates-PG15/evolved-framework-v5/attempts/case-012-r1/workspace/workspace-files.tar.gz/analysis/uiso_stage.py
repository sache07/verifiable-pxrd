#!/usr/bin/env python3
"""Refine one bounded isotropic displacement parameter per phase."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()

    project = G2sc.G2Project(
        args.input, newgpx=str(Path(args.output).resolve())
    )
    project.set_Controls("cycles", 12)

    for phase in project.phases():
        variables = []
        for index, atom in enumerate(phase.atoms()):
            flags = atom.refinement_flags.replace(" ", "")
            atom.refinement_flags = flags + ("" if "U" in flags else "U")
            variable = f"{phase.id}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.001, variable=variable)
            project.set_Controls("parmMax", 0.03, variable=variable)
        project.add_EquivConstr(variables)

    project.save()
    project.refine(makeBack=False)
    project.save()

    hist = project.histogram(0)
    print("residuals", hist.residuals)
    print("frozen", project.get_Frozen())
    for phase in project.phases():
        print(
            phase.name,
            [(atom.label, atom.uiso, atom.refinement_flags) for atom in phase.atoms()],
        )


if __name__ == "__main__":
    main()
