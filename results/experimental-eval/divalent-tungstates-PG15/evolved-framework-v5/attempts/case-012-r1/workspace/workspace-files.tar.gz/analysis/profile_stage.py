#!/usr/bin/env python3
"""Run one bounded, physically screened line-profile refinement stage."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def set_limits(project: G2sc.G2Project) -> None:
    limits = {
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
    }
    for phase in project.phases():
        limits[f"{phase.id}:0:Size;i"] = (0.04, 1.5)
        limits[f"{phase.id}:0:Mustrain;i"] = (0.0, 8000.0)
    for variable, (lower, upper) in limits.items():
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)


def summarize(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    print("residuals", hist.residuals)
    print("frozen", project.get_Frozen())
    print(
        "instrument",
        {k: hist.InstrumentParameters[k] for k in ("U", "V", "W", "X", "Y", "SH/L")},
    )
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "Size", hap["Size"], "Mustrain", hap["Mustrain"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument(
        "mode",
        choices=(
            "wx",
            "size",
            "size-fixed-inst",
            "ushl",
            "ushl-fixed-wx",
            "strain-ni",
            "strain-wo",
        ),
    )
    args = parser.parse_args()

    project = G2sc.G2Project(args.input, newgpx=str(Path(args.output).resolve()))
    hist = project.histogram(0)
    project.set_Controls("cycles", 12)
    set_limits(project)
    if args.mode not in ("size-fixed-inst", "ushl-fixed-wx"):
        project.set_Frozen()

    if args.mode == "wx":
        hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    elif args.mode in ("size", "size-fixed-inst"):
        if hist.InstrumentParameters["X"][1] > 6.0:
            hist.InstrumentParameters["X"][1] = 5.5
        for phase in project.phases():
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 0.8, "refine": True}}
            )
    elif args.mode in ("ushl", "ushl-fixed-wx"):
        hist.InstrumentParameters["U"][1] = min(
            40.0, max(0.0, hist.InstrumentParameters["U"][1])
        )
        hist.InstrumentParameters["SH/L"][1] = min(
            0.10, max(0.005, hist.InstrumentParameters["SH/L"][1])
        )
        hist.set_refinements({"Instrument Parameters": ["U", "SH/L"]})
    elif args.mode in ("strain-ni", "strain-wo"):
        target = "NiWO4" if args.mode == "strain-ni" else "WO3"
        other = "WO3" if target == "NiWO4" else "NiWO4"
        project.phase(other).clear_HAP_refinements({"Mustrain": False})
        project.phase(target).set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )

    project.save()
    project.refine(makeBack=False)
    project.save()
    summarize(project)


if __name__ == "__main__":
    main()
