#!/usr/bin/env python3
"""Run one symmetry-preserving coordinate-refinement stage."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def clear_atoms(phase) -> None:
    phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument(
        "mode", choices=("clean", "ni-heavy", "wo-heavy", "ni-oxygen", "wo-oxygen")
    )
    args = parser.parse_args()

    output = Path(args.output).resolve()
    project = G2sc.G2Project(args.input, newgpx=str(output))
    project.set_Controls("cycles", 12)

    # The bounded profile screen found no positive NiWO4 microstrain.
    # Keep strain out unless a later independent branch supports it.
    for phase in project.phases():
        phase.clear_HAP_refinements({"Mustrain": False})
    project.phase("NiWO4").data["Histograms"][project.histogram(0).name]["Mustrain"][1][0] = 0.0

    if args.mode == "clean":
        for phase in project.phases():
            clear_atoms(phase)
    elif args.mode == "ni-heavy":
        project.phase("NiWO4").set_refinements(
            {"Atoms": {"Ni0": "X", "W1": "X"}}
        )
    elif args.mode == "wo-heavy":
        project.phase("WO3").set_refinements(
            {
                "Atoms": {
                    atom.label: "X"
                    for atom in project.phase("WO3").atoms()
                    if atom.element == "W"
                }
            }
        )
    elif args.mode == "ni-oxygen":
        project.phase("NiWO4").set_refinements(
            {
                "Atoms": {
                    atom.label: "X"
                    for atom in project.phase("NiWO4").atoms()
                    if atom.element == "O"
                }
            }
        )
    elif args.mode == "wo-oxygen":
        project.phase("WO3").set_refinements(
            {
                "Atoms": {
                    atom.label: "X"
                    for atom in project.phase("WO3").atoms()
                    if atom.element == "O"
                }
            }
        )

    project.save()
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    print("residuals", hist.residuals)
    print("frozen", project.get_Frozen())
    for phase in project.phases():
        print("phase", phase.name, "cell", phase.get_cell())
        for atom in phase.atoms():
            print(atom.label, atom.element, atom.coordinates, atom.refinement_flags, atom.uiso)
        phase.export_CIF(str(output.with_suffix(f".{phase.name}.cif")))


if __name__ == "__main__":
    main()
