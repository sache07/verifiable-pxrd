#!/usr/bin/env python3
"""Create a complete three-phase starting GSAS-II project."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--niwo4", choices=("zn", "mg", "mn"), default="zn")
    parser.add_argument("--wo3", choices=("mono", "tri"), default="mono")
    parser.add_argument("--include-nio", action="store_true")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    ni_models = {
        "zn": "niwo4_from_znwo4_1520641.cif",
        "mg": "niwo4_from_mgwo4_9013902.cif",
        "mn": "niwo4_from_mnwo4_1520200.cif",
    }
    wo_models = {
        "mono": "wo3_monoclinic_neutron_2311041.cif",
        "tri": "wo3_triclinic_2106293.cif",
    }

    project = G2sc.G2Project(newgpx=str(Path(args.output).resolve()))
    histogram = project.add_powder_histogram(
        str(WORKSPACE / "inputs" / "pattern.csv"),
        str(HERE / "cu_ka.instprm"),
        fmthint="comma",
    )
    project.add_phase(
        str(HERE / "models" / ni_models[args.niwo4]),
        phasename="NiWO4",
        histograms=[histogram],
        fmthint="CIF",
    )
    project.add_phase(
        str(HERE / "models" / wo_models[args.wo3]),
        phasename="WO3",
        histograms=[histogram],
        fmthint="CIF",
    )
    if args.include_nio:
        project.add_phase(
            str(HERE / "models" / "nio_1010093.cif"),
            phasename="NiO",
            histograms=[histogram],
            fmthint="CIF",
        )

    histogram.set_refinements(
        {
            "Limits": [10.01, 99.99],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 15,
                "coeffs": [600.0] + [0.0] * 14,
                "refine": False,
            },
        }
    )
    project.set_Controls("cycles", 12)
    project.save()

    print("histogram", histogram.name)
    print("sample", histogram.SampleParameters)
    print("instrument", histogram.InstrumentParameters)
    for phase in project.phases():
        print(phase.name, phase.get_cell(), phase.data["Histograms"][histogram.name])


if __name__ == "__main__":
    main()
