#!/usr/bin/env python3
"""Refine calibration and phase cells from a stable scale/background fit."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def summarize(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"\n=== {label} ===")
    print("residuals", hist.residuals)
    print("Zero", hist.InstrumentParameters["Zero"])
    print("Shift", hist.SampleParameters["Shift"])
    denom = sum(
        ph.data["General"]["Mass"] * max(ph.HAPvalue("Scale"), 0.0)
        for ph in project.phases()
    )
    for ph in project.phases():
        frac = ph.data["General"]["Mass"] * max(ph.HAPvalue("Scale"), 0.0) / denom
        print(ph.name, "cell", ph.get_cell(), "weight_fraction", frac)


def run(project: G2sc.G2Project, output: Path, label: str) -> None:
    project.save(str(output))
    project.refine(makeBack=False)
    project.save(str(output))
    summarize(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    output = Path(args.output).resolve()
    stem = output.with_suffix("")

    project = G2sc.G2Project(args.input, newgpx=str(output))
    hist = project.histogram(0)
    project.set_Controls("cycles", 12)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run(project, Path(f"{stem}_zero.gpx"), "zero")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, Path(f"{stem}_cells.gpx"), "zero + cells")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run(project, output, "zero + shift + cells")


if __name__ == "__main__":
    main()
