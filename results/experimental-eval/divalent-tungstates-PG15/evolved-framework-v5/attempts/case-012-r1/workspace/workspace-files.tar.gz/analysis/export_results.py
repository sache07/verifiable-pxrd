#!/usr/bin/env python3
"""Export the accepted GSAS-II checkpoint and all requested result files."""

import argparse
import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


FORMULAS = {"NiWO4": "NiWO4", "WO3": "WO3"}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("checkpoint")
    parser.add_argument("workspace")
    args = parser.parse_args()

    workspace = Path(args.workspace).resolve()
    final_path = workspace / "final.gpx"
    project = G2sc.G2Project(
        args.checkpoint, newgpx=str(final_path)
    )
    project.save()
    hist = project.histogram(0)

    fractions = hist.ComputeMassFracs()
    phase_rows = []
    for phase in project.phases():
        cif_name = f"phase_{phase.name}.cif"
        phase.export_CIF(str(workspace / cif_name))
        fraction, esd = fractions[phase.name]
        cell = phase.get_cell()
        phase_rows.append(
            {
                "name": phase.name,
                "formula": FORMULAS[phase.name],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": cif_name,
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(esd),
                "cell": {key: float(value) for key, value in cell.items()},
            }
        )

    x, observed, _, calculated, _, _ = hist.data["data"][1]
    fit_path = workspace / "fit.csv"
    with fit_path.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta", "observed", "calculated", "difference"]
        )
        for angle, obs, calc in zip(x, observed, calculated):
            writer.writerow(
                [
                    repr(float(angle)),
                    repr(float(obs)),
                    repr(float(calc)),
                    repr(float(obs - calc)),
                ]
            )

    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    fit_statistics = {
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "Rexp_percent": float(hist.residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "reduced_chi_square": float(rvals["GOF"] ** 2),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_parameters": int(rvals["Nvars"]),
    }
    result = {
        "phases": phase_rows,
        "fit_statistics": fit_statistics,
        "refinement_histogram": hist.name,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "fraction_basis": "normalized over modeled crystalline phases",
        "calibration": {
            "zero_offset_deg": float(
                hist.InstrumentParameters["Zero"][1]
            )
        },
    }
    (workspace / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )

    print(json.dumps(result, indent=2))
    print("fit_rows", len(x), "calculated_min", float(min(calculated)))


if __name__ == "__main__":
    main()
