from __future__ import annotations

import copy
import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = ROOT / "analysis/candidates_physical/2106293/final_compare.gpx"
OUTDIR = ROOT / "analysis/structure_refinement"


def clear_flags(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
    hist.Background[0][1] = True
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"][1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.set_HAP_refinements({"Scale": True})
        phase.clear_HAP_refinements({
            "Size": True,
            "Mustrain": True,
            "HStrain": True,
            "Pref.Ori.": True,
            "Extinction": True,
        })


def set_grouped_uiso(project: G2sc.G2Project) -> None:
    project.save()
    for phase in project.phases():
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.uiso = 0.01
            atom.refinement_flags = "U"
            variables.append(f"{phase.id}::AUiso:{index}")
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=True)
        project.set_Controls("parmMin", 0.003, variable=variables[0])
        project.set_Controls("parmMax", 0.020, variable=variables[0])


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    result = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "R_percent": hist.residuals.get("R"),
        "mass_fractions": {
            key: [float(value[0]), float(value[1])]
            for key, value in hist.ComputeMassFracs().items()
        },
        "phases": {},
    }
    for phase in project.phases():
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "short_distances": phase.ShortDistances(useAll=True),
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": [float(v) for v in atom.coordinates],
                    "uiso": float(atom.uiso),
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    return result


def refine_and_save(project: G2sc.G2Project, stem: str) -> dict:
    project.refine()
    gpx = OUTDIR / f"{stem}.gpx"
    project.save(str(gpx))
    for phase in project.phases():
        phase.export_CIF(str(OUTDIR / f"{stem}_{phase.name}.cif"))
    result = snapshot(project, stem)
    with (OUTDIR / f"{stem}.json").open("w") as stream:
        json.dump(result, stream, indent=2)
    print(stem, "wR", result["wR_percent"], "mass", result["mass_fractions"])
    return result


def main() -> None:
    source = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_INPUT
    OUTDIR.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(source), newgpx=str(OUTDIR / "working.gpx"))
    project.set_Controls("cycles", 6)
    project.set_Frozen()
    clear_flags(project)
    set_grouped_uiso(project)
    project.save()
    refine_and_save(project, "01_grouped_uiso")

    # Heavy-atom coordinates first. Oxygen coordinates remain fixed.
    wo3 = project.phase("WO3_2106293")
    for atom in wo3.atoms():
        atom.refinement_flags = "XU" if atom.element == "W" else "U"
    project.set_Controls("cycles", 5)
    refine_and_save(project, "02_w_coordinates")


if __name__ == "__main__":
    main()
