from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/w_small_step.gpx"
FINAL = ROOT / "final.gpx"

project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
project.set_Frozen()
project.set_Controls("cycles", 10)
hist = project.histogram(0)

# Final physical full-grid refinement: linear terms, cells, and one identifiable
# specimen-displacement term. Profile and coordinates are held at the selected
# replay-checked checkpoint.
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
hist.Background[0][1] = True
for key, value in hist.SampleParameters.items():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
hist.SampleParameters["Scale"][1] = False
hist.SampleParameters["Shift"][1] = True

for phase in project.phases():
    phase.set_refinements({"Cell": True})
    phase.set_HAP_refinements({"Scale": True})
    phase.clear_HAP_refinements({
        "Size": True,
        "Mustrain": True,
        "HStrain": True,
        "Pref.Ori.": True,
        "Extinction": True,
    })
    for atom in phase.atoms():
        atom.refinement_flags = " "

project.refine()
project.save()

# CIFs are exported directly from the submitted GSAS-II project.
cif_names = {
    "BaO2": "phase_BaO2.cif",
    "WO3_2106293": "phase_WO3.cif",
}
for phase in project.phases():
    phase.export_CIF(str(ROOT / cif_names[phase.name]))

x = np.asarray(hist.getdata("x"), dtype=float)
observed = np.asarray(hist.getdata("yobs"), dtype=float)
calculated = np.asarray(hist.getdata("ycalc"), dtype=float)
difference = observed - calculated
np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x, observed, calculated, difference)),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference",
    comments="",
    fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
)

fractions = hist.ComputeMassFracs()
residuals = hist.residuals
phase_records = []
for phase in project.phases():
    fraction, uncertainty = fractions[phase.name]
    phase_records.append({
        "name": "BaO2" if phase.name == "BaO2" else "WO3",
        "formula": "BaO2" if phase.name == "BaO2" else "WO3",
        "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
        "cif_path": cif_names[phase.name],
        "weight_fraction": float(fraction),
        "weight_fraction_esd": float(uncertainty),
    })

rwp = float(residuals["wR"])
rexp = float(residuals["wRmin"])
result = {
    "refinement_histogram": hist.name,
    "phases": phase_records,
    "fit_statistics": {
        "Rwp_percent": rwp,
        "Rp_percent": float(residuals["R"]),
        "Rexp_percent": rexp,
        "goodness_of_fit": (rwp / rexp) ** 2,
        "n_points": int(x.size),
    },
}
with (ROOT / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2)

diagnostics = {
    "frozen": project.get_Frozen(),
    "instrument": hist.InstrumentParameters,
    "sample": {
        key: value for key, value in hist.SampleParameters.items()
        if key in ("Shift", "SurfRoughA", "SurfRoughB")
    },
    "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    "profile": {
        phase.name: {
            "size": phase.getHAPentryValue([hist.name, "Size"]),
            "mustrain": phase.getHAPentryValue([hist.name, "Mustrain"]),
            "preferred_orientation": phase.getHAPentryValue([hist.name, "Pref.Ori."]),
            "short_distances": phase.ShortDistances(useAll=True),
        }
        for phase in project.phases()
    },
    "result": result,
}
with (ROOT / "analysis/final_diagnostics.json").open("w") as stream:
    json.dump(diagnostics, stream, indent=2)

print(json.dumps(diagnostics, indent=2))
