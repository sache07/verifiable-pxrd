from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1, unpack=True)
sigma = np.sqrt(np.maximum(y, 1.0))
xye = ANALYSIS / "pattern.xye"
np.savetxt(xye, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")

gpx_path = ANALYSIS / "setup_test.gpx"
project = G2sc.G2Project(newgpx=str(gpx_path))
hist = project.add_powder_histogram(
    str(xye), str(ANALYSIS / "lab_cuka.instprm"), fmthint="xye"
)
bao2 = project.add_phase(
    str(cod_path("1010113")), phasename="BaO2", histograms=[hist], fmthint="CIF"
)
wo3 = project.add_phase(
    str(cod_path("2106293")), phasename="WO3", histograms=[hist], fmthint="CIF"
)
project.save()

print("histogram", hist.name)
print("limits", hist.Limits("lower"), hist.Limits("upper"))
print("data heads")
for key in ("X", "Yobs", "weight", "Ycalc", "background", "residual"):
    try:
        arr = hist.getdata(key)
        print(key, arr[:4], arr.shape)
    except Exception as exc:
        print(key, type(exc).__name__, exc)
print("background", hist.Background)
print("instrument", hist.InstrumentParameters)
print("sample", hist.SampleParameters)
print("BaO2 cell", bao2.get_cell())
print("WO3 cell", wo3.get_cell())
print("BaO2 HAP", bao2.getHAPentryList())
print("WO3 HAP", wo3.getHAPentryList())
print("controls", project.get_Controls())
