from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc


source = Path(sys.argv[1])
output = Path(sys.argv[2])
project = G2sc.G2Project(str(source), newgpx=str(output))
project.set_Frozen()
project.set_Controls("cycles", 5)
hist = project.histogram(0)
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
hist.Background[0][1] = True
for key, value in hist.SampleParameters.items():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
hist.SampleParameters["Scale"][1] = False
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.set_HAP_refinements({"Scale": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "HStrain": True, "Pref.Ori.": True})
    for atom in phase.atoms():
        atom.refinement_flags = " "
project.refine()
project.save()
result = {
    "wR_percent": hist.get_wR(),
    "R_percent": hist.residuals.get("R"),
    "mass_fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
    "frozen": project.get_Frozen(),
}
output.with_suffix(".json").write_text(json.dumps(result, indent=2))
print(result)
