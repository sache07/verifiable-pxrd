from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/structure_refinement/04_w_from_baseline.gpx"
OUTPUT = ROOT / "analysis/profile_refinement/05_robust_isotropic.gpx"

project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
project.set_Frozen()
project.set_Controls("cycles", 6)
hist = project.histogram(0)
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
for key, value in {"U": 20.0, "W": 20.0, "X": 2.0, "SH/L": 0.02}.items():
    hist.InstrumentParameters[key][1] = value
hist.Background[0][1] = True
for key, value in hist.SampleParameters.items():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
hist.SampleParameters["Scale"][1] = False

for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.set_HAP_refinements({"Scale": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "HStrain": True, "Pref.Ori.": True})
    for atom in phase.atoms():
        atom.refinement_flags = " "

bao2 = project.phase("BaO2")
wo3 = project.phase("WO3_2106293")
bao2_size = bao2.getHAPentryValue([hist.name, "Size"])
bao2_strain = bao2.getHAPentryValue([hist.name, "Mustrain"])
wo3_size = wo3.getHAPentryValue([hist.name, "Size"])
wo3_strain = wo3.getHAPentryValue([hist.name, "Mustrain"])
bao2_size[1][0] = 0.070
bao2_strain[1][0] = 7700.0
wo3_size[1][0] = 0.114
wo3_strain[1][0] = 8000.0

# The prior bounded step placed WO3 isotropic strain at the documented maximum.
# Hold it there and refine the remaining three phase-profile terms so no trial
# value outside a bound can contaminate the stored calculated profile.
bao2.set_HAP_refinements({
    "Size": {"type": "isotropic", "refine": True},
    "Mustrain": {"type": "isotropic", "refine": True},
})
wo3.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})

project.refine()
project.save()
result = {
    "wR_percent": hist.get_wR(),
    "R_percent": hist.residuals.get("R"),
    "mass_fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
    "frozen": project.get_Frozen(),
    "instrument": {k: v for k, v in hist.InstrumentParameters.items() if k in ("U", "W", "X", "SH/L")},
    "profile": {
        phase.name: {
            "size": phase.getHAPentryValue([hist.name, "Size"]),
            "mustrain": phase.getHAPentryValue([hist.name, "Mustrain"]),
        }
        for phase in project.phases()
    },
}
OUTPUT.with_suffix(".json").write_text(json.dumps(result, indent=2))
print(result)
