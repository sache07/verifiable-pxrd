from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/profile_refinement/05_robust_isotropic.gpx"
mode = sys.argv[1]
OUTPUT = ROOT / f"analysis/calibration_{mode}.gpx"

project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
project.set_Frozen()
project.set_Controls("cycles", 8)
hist = project.histogram(0)
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
hist.Background[0][1] = True
for key, value in hist.SampleParameters.items():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
hist.SampleParameters["Scale"][1] = False
for phase in project.phases():
    phase.set_refinements({"Cell": True})
    phase.set_HAP_refinements({"Scale": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "HStrain": True, "Pref.Ori.": True})
    for atom in phase.atoms():
        atom.refinement_flags = " "

if mode in ("shift", "both"):
    hist.SampleParameters["Shift"][1] = True
if mode in ("zero", "both"):
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})

project.refine()
project.save()
result = {
    "mode": mode,
    "wR_percent": hist.get_wR(),
    "R_percent": hist.residuals.get("R"),
    "mass_fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
    "zero": hist.InstrumentParameters["Zero"],
    "shift_um": hist.SampleParameters["Shift"],
    "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    "frozen": project.get_Frozen(),
}
OUTPUT.with_suffix(".json").write_text(json.dumps(result, indent=2))
print(result)
