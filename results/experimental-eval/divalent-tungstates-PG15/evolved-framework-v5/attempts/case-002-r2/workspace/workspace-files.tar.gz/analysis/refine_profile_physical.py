from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
OUTDIR = ROOT / "analysis/profile_refinement"
SOURCE = ROOT / "analysis/structure_refinement/04_w_from_baseline.gpx"


def clear_all_flags(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
    hist.Background[0][1] = True
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"][1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "HStrain": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "


def snap(project: G2sc.G2Project, stem: str) -> None:
    hist = project.histogram(0)
    data = {
        "wR_percent": hist.get_wR(),
        "R_percent": hist.residuals.get("R"),
        "mass_fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
        "instrument": {k: v for k, v in hist.InstrumentParameters.items() if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")},
        "sample": {k: v for k, v in hist.SampleParameters.items() if k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.getHAPentryValue([hist.name, "Scale"]),
                "size": phase.getHAPentryValue([hist.name, "Size"]),
                "mustrain": phase.getHAPentryValue([hist.name, "Mustrain"]),
            }
            for phase in project.phases()
        },
        "frozen": project.get_Frozen(),
    }
    with (OUTDIR / f"{stem}.json").open("w") as stream:
        json.dump(data, stream, indent=2)
    print(stem, data)


def run(project: G2sc.G2Project, stem: str) -> None:
    project.refine()
    project.save(str(OUTDIR / f"{stem}.gpx"))
    snap(project, stem)


OUTDIR.mkdir(parents=True, exist_ok=True)
project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTDIR / "working.gpx"))
project.set_Frozen()
project.set_Controls("cycles", 6)
clear_all_flags(project)
hist = project.histogram(0)

# Reset the highly correlated profile terms to the interior of the physically
# allowed laboratory ranges, then introduce one family at a time.
for key, value in {"U": 20.0, "W": 20.0, "X": 2.0, "SH/L": 0.02}.items():
    hist.InstrumentParameters[key][1] = value
for phase in project.phases():
    size = phase.getHAPentryValue([hist.name, "Size"])
    strain = phase.getHAPentryValue([hist.name, "Mustrain"])
    size[1][0] = 0.08
    strain[1][0] = 3000.0
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
project.save()
run(project, "01_size")

project.set_Frozen()
for phase in project.phases():
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
run(project, "02_size_strain")

project.set_Frozen()
hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
run(project, "03_size_strain_instrument")
