from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/source_w_coordinates.gpx"
OUTPUT = ROOT / "analysis/w_small_step.gpx"
PARENT = {
    "W3": (0.2438, 0.0313, 0.7817),
    "W1": (0.2566, 0.0259, 0.2850),
    "W2": (0.2502, 0.5280, 0.2158),
    "W4": (0.2499, 0.5338, 0.7190),
}

project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
project.set_Frozen()
project.set_Controls("cycles", 1)
hist = project.histogram(0)
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
hist.Background[0][1] = True
for key, value in hist.SampleParameters.items():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
hist.SampleParameters["Scale"][1] = False
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.set_HAP_refinements({"Scale": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "HStrain": True, "Pref.Ori.": True})
    for atom in phase.atoms():
        atom.refinement_flags = " "
wo3 = project.phase("WO3_2106293")
for atom in wo3.atoms():
    if atom.element == "W":
        atom.refinement_flags = "X"

project.refine()
project.save()
result = {
    "wR_percent": hist.get_wR(),
    "mass_fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
    "W_atoms": [
        {"label": atom.label, "xyz": [float(v) for v in atom.coordinates], "parent": PARENT[atom.label]}
        for atom in wo3.atoms() if atom.element == "W"
    ],
    "frozen": project.get_Frozen(),
}
OUTPUT.with_suffix(".json").write_text(json.dumps(result, indent=2))
print(result)
