from __future__ import annotations

import json
import shutil
import sys
import traceback
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
OUT = ANALYSIS / "candidates_physical"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
WO3_IDS = sys.argv[1:] or [
    "2106293",
    "1528915",
    "2311041",
    "1010618",
    "1563541",
    "1521532",
    "1521533",
    "1004057",
]


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prep_xye() -> tuple[Path, np.ndarray]:
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1, unpack=True)
    sigma = np.sqrt(np.maximum(y, 1.0))
    path = ANALYSIS / "pattern.xye"
    np.savetxt(path, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    return path, np.vstack((x, y))


def initial_background(x: np.ndarray, y: np.ndarray, ncoef: int = 18) -> list[float]:
    # A smooth lower envelope supplies stable starting values. All coefficients
    # remain refined by GSAS-II in the actual comparison.
    baseline = percentile_filter(y, percentile=12, size=401, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, baseline, ncoef - 1).tolist()


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phases = {}
    for phase in project.phases():
        hap = phase.getHAPentryValue([hist.name, "Scale"])
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap[0]),
            "size": phase.getHAPentryValue([hist.name, "Size"]),
            "mustrain": phase.getHAPentryValue([hist.name, "Mustrain"]),
            "short_distances": phase.ShortDistances(useAll=True),
        }
    try:
        mass = {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()}
    except Exception as exc:
        mass = {"error": repr(exc)}
    return {
        "label": label,
        "wR_percent": hist.get_wR(),
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if isinstance(v, (int, float, np.integer, np.floating))
        },
        "instrument": {k: list(v) if isinstance(v, list) else v for k, v in hist.InstrumentParameters.items()},
        "sample": {k: list(v) if isinstance(v, list) else v for k, v in hist.SampleParameters.items() if k in {"Scale", "Shift", "SurfRoughA", "SurfRoughB"}},
        "mass_fractions": mass,
        "phases": phases,
    }


def refine_step(project: G2sc.G2Project, label: str, outdir: Path, summary: list[dict]) -> None:
    project.refine()
    project.save(str(outdir / f"{label}.gpx"))
    summary.append(snapshot(project, label))
    print(label, "wR", summary[-1]["wR_percent"], "mass", summary[-1]["mass_fractions"])


def build_and_refine(wo3_id: str, xye: Path, xy: np.ndarray) -> dict:
    outdir = OUT / wo3_id
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(outdir / "working.gpx"))
    hist = project.add_powder_histogram(
        str(xye), str(ANALYSIS / "lab_cuka.instprm"), fmthint="xye"
    )
    bao2 = project.add_phase(
        str(cod_path("1010113")), phasename="BaO2", histograms=[hist], fmthint="CIF"
    )
    wo3 = project.add_phase(
        str(cod_path(wo3_id)), phasename=f"WO3_{wo3_id}", histograms=[hist], fmthint="CIF"
    )
    project.set_Controls("cycles", 6)
    hist.SampleParameters["Scale"][1] = False
    coeffs = initial_background(xy[0], xy[1])
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": len(coeffs),
            "coeffs": coeffs,
            "refine": True,
        }
    })
    bao2.set_HAP_refinements({"Scale": True})
    wo3.set_HAP_refinements({"Scale": True})
    # Start with plausible specimen broadening so cell/shift fitting does not
    # force instrumental terms outside the laboratory ranges.
    for phase in (bao2, wo3):
        phase.getHAPentryValue([hist.name, "Size"])[1][0] = 0.15
        phase.getHAPentryValue([hist.name, "Mustrain"])[1][0] = 1000.0
    # Physical bounds from the frozen laboratory description.
    bounds = {
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        "0:0:Scale": (0.0, None),
        "1:0:Scale": (0.0, None),
        "0:0:Size;i": (0.04, 1.5),
        "1:0:Size;i": (0.04, 1.5),
        "0:0:Mustrain;i": (300.0, 8000.0),
        "1:0:Mustrain;i": (300.0, 8000.0),
    }
    for variable, (low, high) in bounds.items():
        if low is not None:
            project.set_Controls("parmMin", low, variable=variable)
        if high is not None:
            project.set_Controls("parmMax", high, variable=variable)
    project.save()

    summary: list[dict] = []
    refine_step(project, "01_scale_background", outdir, summary)

    bao2.set_refinements({"Cell": True})
    wo3.set_refinements({"Cell": True})
    refine_step(project, "02_cells", outdir, summary)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_step(project, "03_calibration", outdir, summary)

    bao2.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.3, "refine": True}})
    wo3.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.3, "refine": True}})
    refine_step(project, "04_size", outdir, summary)

    bao2.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    wo3.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine_step(project, "05_mustrain", outdir, summary)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine_step(project, "06_instrument_profile", outdir, summary)

    final = outdir / "final_compare.gpx"
    project.save(str(final))
    return {"wo3_id": wo3_id, "ok": True, "steps": summary, "project": str(final.relative_to(ROOT))}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    xye, xy = prep_xye()
    results = []
    for wo3_id in WO3_IDS:
        print("\n===", wo3_id, "===")
        try:
            results.append(build_and_refine(wo3_id, xye, xy))
        except Exception as exc:
            traceback.print_exc()
            results.append({"wo3_id": wo3_id, "ok": False, "error": repr(exc)})
    with (OUT / "comparison.json").open("w") as stream:
        json.dump(results, stream, indent=2)
    print("\nSUMMARY")
    for result in results:
        if result["ok"]:
            last = result["steps"][-1]
            print(result["wo3_id"], last["wR_percent"], last["mass_fractions"])
        else:
            print(result["wo3_id"], result["error"])


if __name__ == "__main__":
    main()
