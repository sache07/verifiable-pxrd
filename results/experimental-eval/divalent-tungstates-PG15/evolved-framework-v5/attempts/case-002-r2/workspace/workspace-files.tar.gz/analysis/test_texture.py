from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/profile_refinement/05_robust_isotropic.gpx"
phase_name = sys.argv[1]
label = sys.argv[2]
axis = [int(v) for v in sys.argv[3:6]]
safe_phase = phase_name.replace("_2106293", "")
OUTPUT = ROOT / f"analysis/texture_{safe_phase}_{label}.gpx"

project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
project.set_Frozen()
project.set_Controls("cycles", 5)
hist = project.histogram(0)
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
hist.Background[0][1] = True
for key, value in hist.SampleParameters.items():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
hist.SampleParameters["Scale"][1] = False
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.set_HAP_refinements({"Scale": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "HStrain": True, "Pref.Ori.": True})
    for atom in phase.atoms():
        atom.refinement_flags = " "

phase = project.phase(phase_name)
po = phase.getHAPentryValue([hist.name, "Pref.Ori."])
po[1] = 1.0
po[2] = True
po[3] = axis
project.refine()
project.save()
result = {
    "phase": phase_name,
    "label": label,
    "axis": axis,
    "wR_percent": hist.get_wR(),
    "R_percent": hist.residuals.get("R"),
    "mass_fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
    "preferred_orientation": po,
    "frozen": project.get_Frozen(),
}
OUTPUT.with_suffix(".json").write_text(json.dumps(result, indent=2))
print(result)
