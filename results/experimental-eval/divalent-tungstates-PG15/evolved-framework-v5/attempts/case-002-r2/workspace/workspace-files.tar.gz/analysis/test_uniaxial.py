from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/profile_refinement/05_robust_isotropic.gpx"
label = sys.argv[1]
axis = [int(v) for v in sys.argv[2:5]]
OUTPUT = ROOT / f"analysis/uniaxial_{label}.gpx"

project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
project.set_Frozen()
project.set_Controls("cycles", 6)
hist = project.histogram(0)
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
hist.Background[0][1] = True
for key, value in hist.SampleParameters.items():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
hist.SampleParameters["Scale"][1] = False
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.set_HAP_refinements({"Scale": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "HStrain": True, "Pref.Ori.": True})
    for atom in phase.atoms():
        atom.refinement_flags = " "

wo3 = project.phase("WO3_2106293")
wo3.set_HAP_refinements({
    "Size": {"type": "isotropic", "refine": True},
    "Mustrain": {"type": "uniaxial", "direction": axis, "refine": True},
})
strain = wo3.getHAPentryValue([hist.name, "Mustrain"])
strain[1][0] = 6500.0
strain[1][1] = 6500.0
project.refine()
project.save()
result = {
    "label": label,
    "axis": axis,
    "wR_percent": hist.get_wR(),
    "R_percent": hist.residuals.get("R"),
    "mass_fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
    "frozen": project.get_Frozen(),
    "size": wo3.getHAPentryValue([hist.name, "Size"]),
    "mustrain": wo3.getHAPentryValue([hist.name, "Mustrain"]),
}
OUTPUT.with_suffix(".json").write_text(json.dumps(result, indent=2))
print(result)
