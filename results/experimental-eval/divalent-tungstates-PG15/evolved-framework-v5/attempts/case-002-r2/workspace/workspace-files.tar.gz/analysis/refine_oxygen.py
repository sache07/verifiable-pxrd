from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
INFILE = ROOT / "analysis/structure_refinement/02_w_coordinates.gpx"
OUTDIR = ROOT / "analysis/structure_refinement"


def snapshot(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    return {
        "wR_percent": hist.get_wR(),
        "R_percent": hist.residuals.get("R"),
        "mass_fractions": {
            key: [float(value[0]), float(value[1])]
            for key, value in hist.ComputeMassFracs().items()
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "short_distances": phase.ShortDistances(useAll=True),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": [float(v) for v in atom.coordinates],
                        "uiso": float(atom.uiso),
                    }
                    for atom in phase.atoms()
                ],
            }
            for phase in project.phases()
        },
    }


project = G2sc.G2Project(str(INFILE), newgpx=str(OUTDIR / "03_oxygen_coordinates.gpx"))
project.set_Frozen()
project.set_Controls("cycles", 3)

for phase in project.phases():
    for atom in phase.atoms():
        if atom.element == "O":
            atom.refinement_flags = "XU"
        elif atom.element == "W":
            atom.refinement_flags = "XU"
        else:
            atom.refinement_flags = "U"

project.refine()
project.save()
for phase in project.phases():
    phase.export_CIF(str(OUTDIR / f"03_oxygen_coordinates_{phase.name}.cif"))
result = snapshot(project)
with (OUTDIR / "03_oxygen_coordinates.json").open("w") as stream:
    json.dump(result, stream, indent=2)
print("03_oxygen_coordinates", result)
