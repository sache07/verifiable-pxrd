from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
source = ROOT / "analysis/candidates_physical/2106293/final_compare.gpx"
out = ROOT / "analysis/structure_refinement/04_w_from_baseline.gpx"
project = G2sc.G2Project(str(source), newgpx=str(out))
project.set_Frozen()
project.set_Controls("cycles", 4)
hist = project.histogram(0)
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
for key, value in hist.SampleParameters.items():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
hist.SampleParameters["Scale"][1] = False
hist.Background[0][1] = True
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.set_HAP_refinements({"Scale": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "HStrain": True, "Pref.Ori.": True})
    for atom in phase.atoms():
        atom.refinement_flags = " "
wo3 = project.phase("WO3_2106293")
for atom in wo3.atoms():
    if atom.element == "W":
        atom.refinement_flags = "X"
project.refine()
project.save()
for phase in project.phases():
    phase.export_CIF(str(out.with_name(f"04_w_from_baseline_{phase.name}.cif")))
result = {
    "wR_percent": hist.get_wR(),
    "mass_fractions": {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()},
    "W_atoms": [
        {"label": atom.label, "xyz": [float(v) for v in atom.coordinates]}
        for atom in wo3.atoms() if atom.element == "W"
    ],
}
out.with_suffix(".json").write_text(json.dumps(result, indent=2))
print(result)
