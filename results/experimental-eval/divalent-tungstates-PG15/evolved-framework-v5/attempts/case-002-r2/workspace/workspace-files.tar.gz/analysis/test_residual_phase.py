from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
SOURCE = ROOT / "analysis/calibration_shift.gpx"
cod_id = sys.argv[1]
phase_name = sys.argv[2]
OUTPUT = ROOT / f"analysis/residual_{phase_name}.gpx"


def cod_path(value: str) -> Path:
    return COD / value[0] / value[1:3] / value[3:5] / f"{value}.cif"


project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
project.set_Frozen()
project.set_Controls("cycles", 6)
hist = project.histogram(0)
candidate = project.add_phase(
    str(cod_path(cod_id)), phasename=phase_name, histograms=[hist], fmthint="CIF"
)

hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
hist.Background[0][1] = True
for key, value in hist.SampleParameters.items():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
hist.SampleParameters["Scale"][1] = False
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.set_HAP_refinements({"Scale": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "HStrain": True, "Pref.Ori.": True})
    for atom in phase.atoms():
        atom.refinement_flags = " "

candidate.getHAPentryValue([hist.name, "Scale"])[0] = 0.05
candidate.getHAPentryValue([hist.name, "Size"])[1][0] = 0.08
candidate.getHAPentryValue([hist.name, "Mustrain"])[1][0] = 3000.0

project.refine()
project.save()
try:
    fractions = {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()}
except Exception as exc:
    fractions = {"error": repr(exc)}
result = {
    "cod_id": cod_id,
    "phase": phase_name,
    "wR_percent": hist.get_wR(),
    "R_percent": hist.residuals.get("R"),
    "scale": candidate.getHAPentryValue([hist.name, "Scale"]),
    "mass_fractions": fractions,
    "short_distances": candidate.ShortDistances(useAll=True),
    "cell": candidate.get_cell(),
    "frozen": project.get_Frozen(),
}
OUTPUT.with_suffix(".json").write_text(json.dumps(result, indent=2))
print(result)
