#!/usr/bin/env python3
"""Controlled one-feature-at-a-time trials from a GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def reset_flags(project: G2.G2Project, scales: bool = True, background: bool = True) -> None:
    """Clear all nonlinear flags; optionally retain linear scales/background."""
    project.set_Frozen()
    for hist in project.histograms():
        hist.clear_refinements({"Sample Parameters": [
            k for k, v in hist.SampleParameters.items()
            if isinstance(v, list) and len(v) > 1
        ]})
        hist.clear_refinements({"Instrument Parameters": [
            k for k, v in hist.InstrumentParameters.items()
            if isinstance(v, list) and len(v) > 2
        ]})
        hist.set_refinements({"Background": bool(background)})
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        for hap in phase.data["Histograms"].values():
            hap["Scale"][1] = bool(scales)
            hap["Size"][2] = [False for _ in hap["Size"][2]]
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            if len(hap["Mustrain"]) > 5:
                hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
            hap["Pref.Ori."][2] = False
            hap["Extinction"][1] = False


def fractions(project: G2.G2Project) -> dict[str, float]:
    histname = project.histogram(0).name
    vals = {p.name: float(p.data["Histograms"][histname]["Scale"][0]) *
                    float(p.data["General"]["Mass"]) for p in project.phases()}
    den = sum(max(0.0, x) for x in vals.values())
    return {k: max(0.0, v) / den for k, v in vals.items()}


def summary(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    out = {
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions(project),
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items()
                       if k in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]},
        "sample": {k: v[0] for k, v in hist.SampleParameters.items()
                   if k in ["Shift", "SurfRoughA", "SurfRoughB", "Scale"]},
        "frozen": project.get_Frozen(),
        "varyList": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": list(map(float, phase.data["General"]["Cell"][1:])),
            "scale": float(hap["Scale"][0]),
            "MD": float(hap["Pref.Ori."][1]),
            "MD_axis": list(hap["Pref.Ori."][3]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "atoms": [{"label": a.label, "element": a.element,
                       "xyz": list(map(float, a.coordinates)),
                       "uiso": float(a.uiso) if a.adp_flag == "I" else None,
                       "flags": a.refinement_flags}
                      for a in phase.atoms()],
        }
    return out


def run_refine(project: G2.G2Project, cycles: int = 8) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    return summary(project)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--phase", type=int, default=0)
    ap.add_argument("--axis", nargs=3, type=int)
    ap.add_argument("--baseline", action="store_true")
    ap.add_argument("--elements", nargs="+")
    ap.add_argument("--coord-phase", type=int)
    ap.add_argument("--coord-delta", type=float)
    ap.add_argument("--keep-md", action="store_true")
    ap.add_argument("--uiso", action="store_true")
    ap.add_argument("--uiso-existing", action="store_true")
    ap.add_argument("--uiso-phase", type=int)
    ap.add_argument("--cells", action="store_true")
    ap.add_argument("--shift", action="store_true")
    ap.add_argument("--profile", nargs="+")
    ap.add_argument("--size", action="store_true")
    ap.add_argument("--mustrain", action="store_true")
    ap.add_argument("--roughness", nargs=2, type=float)
    ap.add_argument("--polarization", action="store_true")
    ap.add_argument("--add-phase")
    ap.add_argument("--set-W", type=float)
    ap.add_argument("--set-U", type=float)
    ap.add_argument("--set-X", type=float)
    ap.add_argument("--set-size", nargs=2, type=float)
    ap.add_argument("--set-strain", nargs=2, type=float)
    ap.add_argument("--set-uiso", nargs=2, type=float)
    ap.add_argument("--set-roughness", nargs=2, type=float)
    ap.add_argument("--refine-size", nargs="*", type=int)
    ap.add_argument("--refine-strain", nargs="*", type=int)
    args = ap.parse_args()

    args.out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.base), newgpx=str(args.out))
    if args.add_phase:
        added = project.add_phase(str(cod_path(args.add_phase)),
                                  phasename=f"test_{args.add_phase}",
                                  histograms=project.histograms(), fmthint="CIF")
        hap = added.data["Histograms"][project.histogram(0).name]
        hap["Scale"] = [10000.0 * 0.01 / float(added.data["General"]["Mass"]), True]
        project.set_Controls("parmMin", 0.0, f"{added.id}:0:Scale")
    reset_flags(project)
    label = "baseline"
    if args.add_phase:
        label = f"test_phase_{args.add_phase}"
    hist0 = project.histogram(0)
    for name, value in [("W", args.set_W), ("U", args.set_U), ("X", args.set_X)]:
        if value is not None:
            hist0.InstrumentParameters[name][1] = float(value)
            label += f"_{name}{value:g}"
    if args.set_size:
        for phase, value in zip(project.phases()[:2], args.set_size):
            phase.data["Histograms"][hist0.name]["Size"][1][0] = float(value)
        label += "_setsize"
    if args.set_strain:
        for phase, value in zip(project.phases()[:2], args.set_strain):
            phase.data["Histograms"][hist0.name]["Mustrain"][1][0] = float(value)
        label += "_setstrain"
    if args.set_uiso:
        for phase, value in zip(project.phases()[:2], args.set_uiso):
            for atom in phase.atoms():
                if atom.adp_flag == "I":
                    atom.uiso = float(value)
        label += "_setuiso"
    if args.set_roughness:
        hist0.SampleParameters["SurfRoughA"][0] = float(args.set_roughness[0])
        hist0.SampleParameters["SurfRoughB"][0] = float(args.set_roughness[1])
        label += "_setroughness"
    if args.refine_size is not None:
        chosen = set(args.refine_size) if args.refine_size else {p.id for p in project.phases()[:2]}
        for phase in project.phases()[:2]:
            if phase.id not in chosen:
                continue
            hap = phase.data["Histograms"][hist0.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][2][0] = True
            var = f"{phase.id}:0:Size;i"
            project.set_Controls("parmMin", 0.04, var)
            project.set_Controls("parmMax", 1.5, var)
        label += "_refinesize"
    if args.refine_strain is not None:
        chosen = set(args.refine_strain) if args.refine_strain else {p.id for p in project.phases()[:2]}
        for phase in project.phases()[:2]:
            if phase.id not in chosen:
                continue
            hap = phase.data["Histograms"][hist0.name]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2][0] = True
            var = f"{phase.id}:0:Mustrain;i"
            project.set_Controls("parmMin", 0.0, var)
            project.set_Controls("parmMax", 8000.0, var)
        label += "_refinestrain"
    if args.keep_md:
        for phase in project.phases():
            hap = phase.data["Histograms"][project.histogram(0).name]
            if abs(float(hap["Pref.Ori."][1]) - 1.0) > 1e-4:
                hap["Pref.Ori."][2] = True
                project.set_Controls("parmMin", 0.7, f"{phase.id}:0:MD")
                project.set_Controls("parmMax", 1.4, f"{phase.id}:0:MD")
    if args.elements:
        selected = set(args.elements)
        for phase in project.phases():
            if args.coord_phase is not None and phase.id != args.coord_phase:
                continue
            for atom_index, atom in enumerate(phase.atoms()):
                if atom.element in selected:
                    atom.refinement_flags = "X"
                    if args.coord_delta is not None:
                        for suffix, value in zip(("x", "y", "z"), atom.coordinates):
                            var = f"{phase.id}::dA{suffix}:{atom_index}"
                            project.set_Controls("parmMin", float(value) - args.coord_delta, var)
                            project.set_Controls("parmMax", float(value) + args.coord_delta, var)
        label = "coords_" + "_".join(args.elements)
    if args.uiso:
        for phase in project.phases():
            indices = []
            for i, atom in enumerate(phase.atoms()):
                if atom.adp_flag != "I":
                    continue
                if not (0.003 <= float(atom.uiso) <= 0.02):
                    atom.uiso = 0.01
                atom.refinement_flags = "U"
                var = f"{phase.id}::AUiso:{i}"
                indices.append(var)
                project.set_Controls("parmMin", 0.003, var)
                project.set_Controls("parmMax", 0.02, var)
            if len(indices) > 1:
                project.add_EquivConstr(indices, reloadIdx=True)
        label = "phase_uiso"
    if args.uiso_existing:
        for phase in project.phases():
            if args.uiso_phase is not None and phase.id != args.uiso_phase:
                continue
            for atom in phase.atoms():
                if atom.adp_flag == "I":
                    atom.refinement_flags = "U"
        label = "phase_uiso_existing"
    if args.cells:
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
        label = "cells"
    if args.shift:
        project.histogram(0).set_refinements({"Sample Parameters": ["Shift"]})
        label += "_shift"
    if args.profile:
        project.histogram(0).set_refinements({"Instrument Parameters": args.profile})
        label += "_profile_" + "_".join(args.profile)
    if args.size:
        for phase in project.phases():
            phase.set_HAP_refinements({"Size": {
                "type": "isotropic", "value": 0.3, "refine": True,
            }})
            var = f"{phase.id}:0:Size;i"
            project.set_Controls("parmMin", 0.04, var)
            project.set_Controls("parmMax", 1.5, var)
        label += "_size"
    if args.mustrain:
        for phase in project.phases():
            phase.set_HAP_refinements({"Mustrain": {
                "type": "isotropic", "refine": True,
            }})
            var = f"{phase.id}:0:Mustrain;i"
            project.set_Controls("parmMin", 0.0, var)
            project.set_Controls("parmMax", 8000.0, var)
        label += "_mustrain"
    if args.roughness:
        hist = project.histogram(0)
        hist.SampleParameters["SurfRoughA"][0] = float(args.roughness[0])
        hist.SampleParameters["SurfRoughB"][0] = float(args.roughness[1])
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughA")
        project.set_Controls("parmMax", 0.6, ":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
        project.set_Controls("parmMax", 0.5, ":0:SurfRoughB")
        label += "_roughness"
    if args.polarization:
        hist = project.histogram(0)
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.5, ":0:Polariz.")
        project.set_Controls("parmMax", 1.0, ":0:Polariz.")
        label += "_polarization"
    if args.axis is not None:
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][project.histogram(0).name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(args.axis)
        project.set_Controls("parmMin", 0.7, f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 1.4, f"{phase.id}:0:MD")
        label = f"phase{args.phase}_MD_{''.join(map(str, args.axis))}"
    project.save()
    G2.SetPrintLevel("warn")
    out = run_refine(project)
    out["label"] = label
    args.out.with_suffix(".json").write_text(json.dumps(out, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"label": label, "Rwp": out["Rwp_percent"],
                      "fractions": out["fractions"],
                      "MD": {k: (v["MD"], v["MD_axis"]) for k, v in out["phases"].items()}},
                     sort_keys=True))


if __name__ == "__main__":
    main()
