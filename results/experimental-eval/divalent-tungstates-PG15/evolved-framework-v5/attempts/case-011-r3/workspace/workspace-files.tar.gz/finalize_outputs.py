#!/usr/bin/env python3
"""Export the selected physical GSAS-II checkpoint as the requested deliverables."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "trials" / "final-supported-full.gpx"


def main() -> None:
    final_path = ROOT / "final.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(final_path))
    project.save()
    # Reload exactly what will be submitted, rather than exporting from the
    # in-memory source checkpoint.
    project = G2.G2Project(gpxfile=str(final_path))
    hist = project.histogram(0)
    phases = project.phases()
    if len(phases) != 2:
        raise RuntimeError(f"expected two accepted phases, found {len(phases)}")

    cif_paths = [ROOT / "phase_WO3_monoclinic.cif", ROOT / "phase_MnO2_pyrolusite.cif"]
    for phase, path in zip(phases, cif_paths):
        phase.export_CIF(str(path))

    x = np.asarray(hist.getdata("X"), dtype=float)
    observed = np.asarray(hist.getdata("Yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("Ycalc"), dtype=float)
    difference = observed - calculated
    if not (len(x) == len(observed) == len(calculated) == 8301):
        raise RuntimeError("final histogram does not cover the supplied full grid")
    if np.any(~np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("invalid final calculated profile")
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=("%.8f", "%.8f", "%.8f", "%.8f"),
    )

    histname = hist.name
    masses = np.asarray([float(p.data["General"]["Mass"]) for p in phases])
    scales = np.asarray([float(p.data["Histograms"][histname]["Scale"][0]) for p in phases])
    mass_terms = masses * scales
    fractions = mass_terms / mass_terms.sum()
    if not np.isclose(fractions.sum(), 1.0, atol=1e-12):
        raise RuntimeError("phase fractions did not normalize")

    scale_vars = [f"{p.id}:0:Scale" for p in phases]
    _, scale_cov = project.get_Covariance(scale_vars)
    jac = np.empty((len(phases), len(phases)))
    total = mass_terms.sum()
    for i in range(len(phases)):
        for j in range(len(phases)):
            jac[i, j] = masses[j] * ((1.0 if i == j else 0.0) * total - mass_terms[i]) / total**2
    fraction_cov = jac @ scale_cov @ jac.T
    fraction_esd = np.sqrt(np.maximum(np.diag(fraction_cov), 0.0))

    residuals = hist.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    phase_defs = [
        {
            "name": "monoclinic tungsten trioxide",
            "formula": "WO3",
            "phase_label_in_project": phases[0].name,
            "cif_path": cif_paths[0].name,
            "reference": {
                "database": "COD filtered 2024",
                "cod_id": "2311041",
                "basis": "published room-temperature neutron structure, refined",
            },
        },
        {
            "name": "pyrolusite (rutile-type manganese dioxide)",
            "formula": "MnO2",
            "phase_label_in_project": phases[1].name,
            "cif_path": cif_paths[1].name,
            "reference": {
                "database": "COD filtered 2024",
                "cod_id": "1514110",
                "basis": "published pyrolusite structure, refined",
            },
        },
    ]
    phase_rows = []
    for i, (phase, row) in enumerate(zip(phases, phase_defs)):
        cell = phase.data["General"]["Cell"]
        row.update({
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cell_angstrom_degree": {
                "a": float(cell[1]), "b": float(cell[2]), "c": float(cell[3]),
                "alpha": float(cell[4]), "beta": float(cell[5]), "gamma": float(cell[6]),
                "volume_angstrom3": float(cell[7]),
            },
            "weight_fraction": float(fractions[i]),
            "weight_fraction_formal_esd": float(fraction_esd[i]),
            "bragg_Rf_percent": float(residuals[f"{i}:0:Rf"]),
            "bragg_Rf2_percent": float(residuals[f"{i}:0:Rf^2"]),
        })
        phase_rows.append(row)

    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    result = {
        "schema_version": 1,
        "project_path": "final.gpx",
        "refinement_histogram": histname,
        "profile_path": "fit.csv",
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_points": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "background_weighted_R_percent": float(residuals["wRb"]),
            "converged": bool(rvals["converged"]),
        },
        "weighting": "Poisson counting weights, w = 1/max(observed_counts, 1)",
        "calibration": {
            "zero_deg": float(inst["Zero"][1]),
            "specimen_shift_um": float(sample["Shift"][0]),
            "goniometer_radius_mm": float(sample["Gonio. radius"]),
            "polarization": float(inst["Polariz."][1]),
            "wavelength_Kalpha1_angstrom": float(inst["Lam1"][1]),
            "wavelength_Kalpha2_angstrom": float(inst["Lam2"][1]),
            "Kalpha2_to_Kalpha1_ratio": float(inst["I(L2)/I(L1)"][1]),
        },
        "software": {"name": "GSAS-II", "revision": GSASIIpath.GetVersionNumber()},
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

    print(json.dumps({
        "project": str(final_path),
        "histogram": histname,
        "Rwp_percent": result["fit_statistics"]["Rwp_percent"],
        "fractions": {r["formula"]: r["weight_fraction"] for r in phase_rows},
    }, indent=2))


if __name__ == "__main__":
    main()
