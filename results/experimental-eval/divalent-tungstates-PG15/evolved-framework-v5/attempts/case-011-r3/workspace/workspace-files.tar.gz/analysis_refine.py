#!/usr/bin/env python3
"""GSAS-II branch refinements for the MnO2/WO3 powder pattern."""

from __future__ import annotations

import argparse
import json
import math
import os
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_inputs() -> tuple[Path, Path]:
    """Create GSAS-II input files from the supplied, unmodified CSV."""
    arr = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skip_header=1)
    xye = ROOT / ".tmp" / "pattern.xye"
    inst = ROOT / ".tmp" / "instrument.instprm"
    xye.parent.mkdir(parents=True, exist_ok=True)
    # Original point uncertainties were not supplied. Poisson count weights are
    # the physically natural choice for the raw count data.
    np.savetxt(xye, np.column_stack((arr[:, 0], arr[:, 1], np.sqrt(np.maximum(arr[:, 1], 1.0)))),
               fmt=("%.8f", "%.8f", "%.8f"))
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano instrument; initial profile values\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:20.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def frac_dict(project: G2.G2Project) -> dict[str, float]:
    vals = {}
    histname = project.histogram(0).name
    for phase in project.phases():
        hap = phase.data["Histograms"][histname]
        vals[phase.name] = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
    total = sum(max(v, 0.0) for v in vals.values())
    if total <= 0:
        return {k: float("nan") for k in vals}
    return {k: max(v, 0.0) / total for k, v in vals.items()}


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    result = {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "fractions": frac_dict(project),
        "instrument": {k: (v[1] if isinstance(v, list) and len(v) > 1 else v)
                       for k, v in inst.items() if k in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]},
        "sample": {k: (v[0] if isinstance(v, list) else v)
                   for k, v in sample.items() if k in ["Shift", "SurfRoughA", "SurfRoughB", "Scale"]},
        "phases": {},
        "varyList": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }
    for phase in project.phases():
        h = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": list(map(float, phase.data["General"]["Cell"][1:])),
            "mass": float(phase.data["General"]["Mass"]),
            "scale": float(h["Scale"][0]),
            "size": h["Size"],
            "mustrain": h["Mustrain"],
            "pref_ori": h["Pref.Ori."],
            "atoms": [{"label": a.label, "element": a.element,
                       "xyz": list(map(float, a.coordinates)),
                       "occ": float(a.occupancy), "flags": a.refinement_flags}
                      for a in phase.atoms()],
        }
    print(json.dumps({"step": label, "Rwp": result["Rwp_percent"],
                      "fractions": result["fractions"],
                      "zero": result["instrument"].get("Zero"),
                      "shift": result["sample"].get("Shift")}, sort_keys=True))
    return result


def refine_step(project: G2.G2Project, label: str, history: list[dict], cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    history.append(snapshot(project, label))
    project.save()


def create_project(wo_id: str, mn_id: str, outdir: Path, extra_id: str | None = None) -> G2.G2Project:
    xye, inst = prepare_inputs()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(outdir / "branch.gpx"))
    wo = project.add_phase(str(cod_path(wo_id)), phasename=f"WO3_{wo_id}", fmthint="CIF")
    mn = project.add_phase(str(cod_path(mn_id)), phasename=f"MnO2_{mn_id}", fmthint="CIF")
    phases = [wo, mn]
    if extra_id:
        extra = project.add_phase(str(cod_path(extra_id)), phasename=f"extra_{extra_id}", fmthint="CIF")
        phases.append(extra)
    hist = project.add_powder_histogram(str(xye), str(inst), phases=phases, fmthint="xye")
    hist.Limits("lower", 9.90343322)
    hist.Limits("upper", 100.09488522)
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    # The reference/observed peak displacement is about +0.30 degrees at low
    # angle, corresponding to a negative specimen-height shift in GSAS-II.
    hist.SampleParameters["Shift"] = [-520.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements({"Background": {
        "type": "chebyschev-1", "no. coeffs": 12,
        "coeffs": [1100.0] + [0.0] * 11, "refine": True,
    }})
    # Positive, chemically reasonable starting scales. GSAS-II quantitative
    # mass is proportional to HAP scale times unit-cell mass.
    starts = [0.72, 0.28] + ([0.01] if extra_id else [])
    starts = np.asarray(starts, dtype=float)
    starts /= starts.sum()
    for phase, wf in zip(phases, starts):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 * float(wf) / float(phase.data["General"]["Mass"]), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    # The measurement description supplies broad but finite physical ranges.
    # Applying them prevents profile/calibration correlations from wandering
    # into mathematically useful but impossible values.
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.1),
    }
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)
    for phase in phases:
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")
    project.save()
    return project


def run_branch(wo_id: str, mn_id: str, outdir: Path, extra_id: str | None = None,
               full: bool = False) -> dict:
    project = create_project(wo_id, mn_id, outdir, extra_id)
    hist = project.histogram(0)
    history: list[dict] = []

    # 1: scales/background at a physically estimated specimen displacement.
    refine_step(project, "scale_background", history)

    # 2: angular displacement and phase metrics. A small global zero term is
    # delayed until the cells are near their data values.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_step(project, "shift", history)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine_step(project, "cells", history)
    # Zero and specimen shift are almost perfectly correlated on this grid.
    # Keep zero at the stated nominal calibration for reference screening and
    # let the physically bounded height shift carry the common displacement.

    # 3: shared instrument profile, staged to avoid singular broadening steps.
    # V and Y are fixed because they were not sampled by the stated family.
    hist.set_refinements({"Instrument Parameters": ["W"]})
    refine_step(project, "profile_W", history)
    hist.set_refinements({"Instrument Parameters": ["X"]})
    refine_step(project, "profile_WX", history)
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine_step(project, "profile_WX_SHL", history)
    hist.set_refinements({"Instrument Parameters": ["U"]})
    refine_step(project, "instrument_profile", history)

    if full:
        # 4: phase broadening, introduced one supported family at a time.
        for phase in project.phases():
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.5, "refine": True}})
        refine_step(project, "phase_size", history)
        for phase in project.phases():
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        refine_step(project, "phase_mustrain", history)

    summary = {
        "GSAS_II_revision": GSASIIpath.GetVersionNumber(),
        "wo_id": wo_id,
        "mn_id": mn_id,
        "extra_id": extra_id,
        "history": history,
    }
    (outdir / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    project.save()
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo", required=True)
    parser.add_argument("--mn", default="1514110")
    parser.add_argument("--extra")
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--full", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run_branch(args.wo, args.mn, args.out, args.extra, args.full)


if __name__ == "__main__":
    main()
