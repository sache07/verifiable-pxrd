#!/usr/bin/env python3
"""Fast fixed-parameter GSAS-II profile grid around a physical checkpoint."""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--W", nargs="+", type=float, required=True)
    ap.add_argument("--U", nargs="+", type=float, default=[40.0])
    ap.add_argument("--X", nargs="+", type=float, default=[1.0, 3.0, 5.0, 6.0])
    ap.add_argument("--wo-size", nargs="+", type=float,
                    default=[0.2, 0.3, 0.5, 1.0, 1.5])
    ap.add_argument("--wo-strain", nargs="+", type=float, default=[1373.5])
    ap.add_argument("--mn-size", nargs="+", type=float, default=[1.5])
    ap.add_argument("--mn-strain", nargs="+", type=float, default=[0.0])
    args = ap.parse_args()

    args.out.parent.mkdir(parents=True, exist_ok=True)
    work = args.out.with_suffix(".gpx")
    project = G2.G2Project(gpxfile=str(args.base), newgpx=str(work))
    hist = project.histogram(0)
    # No parameters are varied; each zero-cycle call is a replay calculation.
    hist.data["Background"][0][1] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    G2.SetPrintLevel("error")

    rows = []
    values = itertools.product(args.W, args.U, args.X, args.wo_size,
                               args.wo_strain, args.mn_size, args.mn_strain)
    for W, U, X, wsz, wmu, msz, mmu in values:
        hist.InstrumentParameters["W"][1] = W
        hist.InstrumentParameters["U"][1] = U
        hist.InstrumentParameters["X"][1] = X
        wo, mn = project.phases()[:2]
        wh = wo.data["Histograms"][hist.name]
        mh = mn.data["Histograms"][hist.name]
        wh["Size"][1][0] = wsz
        wh["Mustrain"][1][0] = wmu
        mh["Size"][1][0] = msz
        mh["Mustrain"][1][0] = mmu
        project.refine()
        rows.append({"Rwp": float(project.histogram(0).get_wR()),
                     "W": W, "U": U, "X": X,
                     "wo_size": wsz, "wo_strain": wmu,
                     "mn_size": msz, "mn_strain": mmu})
    rows.sort(key=lambda x: x["Rwp"])
    args.out.write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows[:10], indent=2))


if __name__ == "__main__":
    main()
