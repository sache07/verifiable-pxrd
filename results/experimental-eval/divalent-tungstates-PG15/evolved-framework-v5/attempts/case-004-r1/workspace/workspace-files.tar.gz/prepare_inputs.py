#!/usr/bin/env python3
"""Prepare physical starting structures and GSAS-II input files."""

from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
WORK = ROOT / ".tmp" / "starting_models"


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    WORK.mkdir(parents=True, exist_ok=True)

    # Physical room-temperature gamma-WO3 model. The Niggli cell avoids the
    # very oblique source setting while preserving its P21/c topology.
    wo3 = Structure.from_file(cod_path("2311041")).get_reduced_structure("niggli")
    CifWriter(wo3, symprec=0.01, refine_struct=False).write_file(WORK / "WO3_start.cif")

    # The exact-composition COD CoWO4 entry is malformed. Start from the
    # physical room-temperature P2/c ZnWO4 topology (COD 1520641), replace Zn
    # by Co, and use the chemically specific CoWO4 checkpoint cell (COD
    # 5910316); fractional coordinates remain those of the physical analogue.
    znwo4 = Structure.from_file(cod_path("1520641"))
    znwo4.replace_species({"Zn": "Co"})
    cowo4 = Structure(
        Lattice.from_parameters(4.66, 5.69, 4.98, 90.0, 90.0, 90.0),
        znwo4.species,
        znwo4.frac_coords,
        site_properties=znwo4.site_properties,
    )
    CifWriter(cowo4, symprec=0.01, refine_struct=False).write_file(WORK / "CoWO4_start.cif")

    # Physical spinel model; the other exact-composition checkpoint has
    # 0.17-A Co-O contacts and is intentionally excluded.
    co3o4 = Structure.from_file(cod_path("9005896"))
    CifWriter(co3o4, symprec=0.01, refine_struct=False).write_file(WORK / "Co3O4_start.cif")

    raw = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    sigma = np.sqrt(np.maximum(raw[:, 1], 1.0))
    np.savetxt(
        WORK / "pattern.xye",
        np.column_stack((raw[:, 0], raw[:, 1], sigma)),
        fmt=("%.8f", "%.6f", "%.6f"),
        header="2theta intensity sigma",
        comments="# ",
    )


if __name__ == "__main__":
    main()
