#!/usr/bin/env python3
"""Refine the accepted WO3 + CoWO4 model in stable, inspectable stages."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"


def physical_summary(project, label):
    hist = project.histograms()[0]
    print(f"\n===== {label} =====")
    print("residuals", json.dumps(hist.residuals, sort_keys=True))
    print("shift", hist.SampleParameters.get("Shift"))
    for phase in project.phases():
        print("phase", phase.name, "cell", phase.get_cell(), "scale", phase.HAPvalue("Scale"),
              "use", phase.HAPvalue("Use"), "atoms")
        for atom in phase.atoms():
            print(" ", atom.label, atom.element, tuple(round(v, 7) for v in atom.coordinates),
                  "Uiso", atom.uiso, "flags", atom.refinement_flags)
    try:
        print("mass", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass unavailable", repr(exc))


def run_stage(source, output, setup, max_cycles=8):
    project = G2sc.G2Project(CHECK / source)
    project.data["Controls"]["data"]["max cyc"] = max_cycles
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    setup(project)
    out = CHECK / output
    project.save(out)
    project.refine(makeBack=False)
    project.save(out)
    physical_summary(project, output)


def base_cleanup(project):
    hist = project.histograms()[0]
    hist.SampleParameters["Shift"][1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    minor = project.phase("Co3O4")
    minor.HAPvalue("Scale", 1.0e-8)
    minor.HAPvalue("Use", False)
    minor.clear_HAP_refinements({"Scale": True})


def main():
    def wo_cell(project):
        base_cleanup(project)
        project.phase("gamma-WO3").set_refinements({"Cell": True})
    run_stage("40-co3o4-grid-0.gpx", "50-wo-cell.gpx", wo_cell)

    def co_cell(project):
        base_cleanup(project)
        project.phase("gamma-WO3").set_refinements({"Cell": True})
        project.phase("CoWO4").set_refinements({"Cell": True})
    run_stage("50-wo-cell.gpx", "51-co-cell.gpx", co_cell)

    def shift(project):
        base_cleanup(project)
        project.phase("gamma-WO3").set_refinements({"Cell": True})
        project.phase("CoWO4").set_refinements({"Cell": True})
        project.histograms()[0].set_refinements({"Sample Parameters": ["Shift"]})
    run_stage("51-co-cell.gpx", "52-shift.gpx", shift)


if __name__ == "__main__":
    main()
