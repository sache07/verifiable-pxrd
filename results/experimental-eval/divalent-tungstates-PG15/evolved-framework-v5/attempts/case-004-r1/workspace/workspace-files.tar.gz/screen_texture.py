#!/usr/bin/env python3
"""Screen single-parameter March-Dollase directions on the physical base."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"
SOURCE = CHECK / "71-bounded-w40.gpx"
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def freeze(project):
    hist = project.histograms()[0]
    hist.clear_refinements({"Background": True, "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for key in hist.InstrumentParameters:
        try:
            hist.InstrumentParameters[key][2] = False
        except (IndexError, TypeError):
            pass
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    minor = project.phase("Co3O4")
    minor.HAPvalue("Use", False)
    minor.HAPvalue("Scale", 1.0e-8)


def main():
    for phase_name in ("gamma-WO3", "CoWO4"):
        for idx, axis in enumerate(AXES):
            project = G2sc.G2Project(SOURCE)
            project.data["Controls"]["data"]["max cyc"] = 6
            freeze(project)
            phase = project.phase(phase_name)
            po = phase.getHAPvalues(project.histograms()[0].name)["Pref.Ori."]
            po[0] = "MD"
            po[1] = 1.0
            po[2] = True
            po[3] = list(axis)
            safe = phase_name.replace("gamma-", "")
            out = CHECK / f"73-texture-{safe}-{idx}.gpx"
            project.save(out)
            project.refine(makeBack=False)
            project.save(out)
            hist = project.histograms()[0]
            print(f"RESULT phase={phase_name} axis={axis} MD={po[1]:.8f} Rwp={hist.residuals.get('wR'):.8f}")


if __name__ == "__main__":
    main()
