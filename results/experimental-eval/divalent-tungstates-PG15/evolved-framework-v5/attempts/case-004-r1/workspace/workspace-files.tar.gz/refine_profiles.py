#!/usr/bin/env python3
"""Refine supported phase and instrument profile terms one block at a time."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"


def prepare(project):
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    minor = project.phase("Co3O4")
    minor.HAPvalue("Use", False)
    minor.HAPvalue("Scale", 1.0e-8)
    minor.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True})
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def report(project, label):
    hist = project.histograms()[0]
    print(f"\n===== {label} =====")
    print("residuals", json.dumps(hist.residuals, sort_keys=True))
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("U", "V", "W", "X", "Y", "SH/L")})
    print("shift", hist.SampleParameters["Shift"])
    for phase in project.phases()[:2]:
        hap = phase.getHAPvalues(hist.name)
        print("phase", phase.name, "cell", phase.get_cell(), "scale", phase.HAPvalue("Scale"),
              "size", hap["Size"], "mustrain", hap["Mustrain"])
    print("mass", hist.ComputeMassFracs())


def run(source, output, setup):
    project = G2sc.G2Project(CHECK / source)
    prepare(project)
    setup(project)
    out = CHECK / output
    project.save(out)
    project.refine(makeBack=False)
    project.save(out)
    report(project, output)


def main():
    run("54-co-heavy.gpx", "60-wo-size.gpx",
        lambda p: p.phase("gamma-WO3").set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True}}))

    run("60-wo-size.gpx", "61-co-size.gpx",
        lambda p: p.phase("CoWO4").set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True}}))

    run("61-co-size.gpx", "62-wo-strain.gpx",
        lambda p: p.phase("gamma-WO3").set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True}}))

    run("62-wo-strain.gpx", "63-co-strain.gpx",
        lambda p: p.phase("CoWO4").set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True}}))


if __name__ == "__main__":
    main()
