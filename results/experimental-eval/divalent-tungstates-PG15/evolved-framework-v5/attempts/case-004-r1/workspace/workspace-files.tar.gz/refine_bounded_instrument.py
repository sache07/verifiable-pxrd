#!/usr/bin/env python3
"""Test identifiable instrument terms without allowing negative U."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"


def prepare(project):
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histograms()[0]
    for key in ("U", "V", "W", "X", "Y", "SH/L", "Polariz."):
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False
    minor = project.phase("Co3O4")
    minor.HAPvalue("Use", False)
    minor.HAPvalue("Scale", 1.0e-8)
    minor.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True})
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({"Mustrain": True})


def report(project, label):
    hist = project.histograms()[0]
    print(f"\n===== {label} =====")
    print("residuals", json.dumps(hist.residuals, sort_keys=True))
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")})
    for phase in project.phases()[:2]:
        print(phase.name, "scale", phase.HAPvalue("Scale"),
              "size", phase.getHAPvalues(hist.name)["Size"], "cell", phase.get_cell())
    print("shift", hist.SampleParameters["Shift"], "mass", hist.ComputeMassFracs())


def run(source, output, params):
    project = G2sc.G2Project(CHECK / source)
    prepare(project)
    project.histograms()[0].set_refinements({"Instrument Parameters": params})
    out = CHECK / output
    project.save(out)
    project.refine(makeBack=False)
    project.save(out)
    report(project, output)


def main():
    run("61-co-size.gpx", "67-inst-w.gpx", ["W"])
    run("67-inst-w.gpx", "68-inst-u-test.gpx", ["U"])
    run("67-inst-w.gpx", "69-inst-shl.gpx", ["SH/L"])
    run("69-inst-shl.gpx", "70-polarization.gpx", ["Polariz."])


if __name__ == "__main__":
    main()
