#!/usr/bin/env python3
"""Evaluate bounded physical cell/displacement starts without freeing cells."""

from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"
SOURCE = CHECK / "11-wo3-cell.bak0.gpx"


def set_cell(phase: G2sc.G2Phase, values: list[float]) -> None:
    cell = phase.data["General"]["Cell"]
    cell[1:7] = values
    cell[7] = G2lat.calc_V(G2lat.cell2A(values))


def main() -> None:
    wo_stable = [7.6811449085, 7.5259287571, 10.5222138607, 90.0, 136.115594849, 90.0]
    wo_shifted = [7.6873959404, 7.5313936437, 10.5332440106, 90.0, 136.123134473, 90.0]
    co_initial = [4.66, 5.69, 4.98, 90.0, 90.0, 90.0]
    co_a = [4.6589872745, 5.6784720114, 4.9478961730, 90.0, 89.7168947755, 90.0]
    co_b = [4.6658609743, 5.6824731030, 4.9463256249, 90.0, 89.8002501780, 90.0]
    tests = [
        ("20-initial-shiftref", wo_stable, co_initial, 0.0, True),
        ("21-coa-noshift", wo_stable, co_a, 0.0, False),
        ("22-coa-shiftfixed", wo_shifted, co_a, -60.5, False),
        ("23-cob-shiftfixed", wo_shifted, co_b, -60.5, False),
        ("24-coa-shiftref", wo_shifted, co_a, -60.5, True),
    ]
    for label, wo_cell, co_cell, shift, refine_shift in tests:
        project = G2sc.G2Project(SOURCE)
        project.data["Controls"]["data"]["max cyc"] = 5
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
        hist = project.histograms()[0]
        for phase in project.phases():
            phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        set_cell(project.phase("gamma-WO3"), wo_cell)
        set_cell(project.phase("CoWO4"), co_cell)
        hist.SampleParameters["Shift"] = [shift, refine_shift]
        out = CHECK / f"{label}.gpx"
        project.save(out)
        project.refine(makeBack=False)
        project.save(out)
        print("\n", label, "R", hist.residuals)
        print("shift", hist.SampleParameters["Shift"])
        for phase in project.phases():
            print(phase.name, phase.get_cell(), phase.HAPvalue("Scale"))
        try:
            print("mass", hist.ComputeMassFracs())
        except Exception as exc:
            print("mass unavailable", repr(exc))


if __name__ == "__main__":
    main()
