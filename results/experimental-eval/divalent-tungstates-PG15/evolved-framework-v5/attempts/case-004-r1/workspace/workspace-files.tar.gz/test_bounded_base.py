#!/usr/bin/env python3
"""Reoptimize the major model at physical instrument-profile bounds."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"
SOURCE = CHECK / "61-co-size.gpx"


def main():
    for idx, wval in enumerate([20.0, 30.0, 40.0]):
        project = G2sc.G2Project(SOURCE)
        project.data["Controls"]["data"]["max cyc"] = 8
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
        hist = project.histograms()[0]
        inst = hist.InstrumentParameters
        fixed = {"U": 10.0, "V": 0.0, "W": wval, "X": 1.0,
                 "Y": 0.0, "SH/L": 0.02, "Polariz.": 1.0}
        for key, value in fixed.items():
            inst[key][1] = value
            inst[key][2] = False
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = " "
            phase.clear_HAP_refinements({"Mustrain": True})
        minor = project.phase("Co3O4")
        minor.HAPvalue("Use", False)
        minor.HAPvalue("Scale", 1.0e-8)
        minor.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True})
        out = CHECK / f"71-bounded-w{int(wval)}.gpx"
        project.save(out)
        project.refine(makeBack=False)
        project.save(out)
        print(f"\nRESULT W={wval} Rwp={hist.residuals.get('wR')} R={hist.residuals.get('R')}")
        print("instrument", {k: inst[k] for k in fixed})
        for phase in project.phases()[:2]:
            print(phase.name, phase.HAPvalue("Scale"), phase.getHAPvalues(hist.name)["Size"], phase.get_cell())
        print("shift", hist.SampleParameters["Shift"], "mass", hist.ComputeMassFracs())


if __name__ == "__main__":
    main()
