#!/usr/bin/env python3
"""Screen small, fixed oxygen-coordinate moves on the physical profile model.

The unconstrained oxygen refinements locate an intensity-gradient direction but
move too far for powder data of this quality.  Here only a small fraction of
that direction is applied, while the supported scale/background/cell/shift and
isotropic-size terms are re-optimized.
"""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"
BASE = CHECK / "71-bounded-w40.gpx"
WO_TARGET = CHECK / "55-wo-oxygen.gpx"
CO_TARGET = CHECK / "56-co-oxygen.gpx"


def oxygen_coordinates(project, phase_name):
    return {
        atom.label: tuple(atom.coordinates)
        for atom in project.phase(phase_name).atoms()
        if atom.element == "O"
    }


def apply_fraction(project, phase_name, base, target, fraction):
    for atom in project.phase(phase_name).atoms():
        atom.refinement_flags = " "
        if atom.label not in base:
            continue
        atom.coordinates = [
            x0 + fraction * (x1 - x0)
            for x0, x1 in zip(base[atom.label], target[atom.label])
        ]


def run(label, wo_fraction=0.0, co_fraction=0.0, source=BASE):
    project = G2sc.G2Project(source)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    apply_fraction(project, "gamma-WO3", WO_BASE, WO_END, wo_fraction)
    apply_fraction(project, "CoWO4", CO_BASE, CO_END, co_fraction)
    minor = project.phase("Co3O4")
    minor.HAPvalue("Use", False)
    minor.HAPvalue("Scale", 1.0e-8)
    minor.clear_HAP_refinements({"Scale": True})
    out = CHECK / f"74-oxygen-{label}.gpx"
    project.save(out)
    project.refine(makeBack=False)
    project.save(out)
    hist = project.histograms()[0]
    print(
        f"RESULT {label} wo_fraction={wo_fraction:.3f} "
        f"co_fraction={co_fraction:.3f} Rwp={hist.residuals.get('wR'):.8f} "
        f"mass={hist.ComputeMassFracs()}"
    )


_base_project = G2sc.G2Project(BASE)
_wo_target_project = G2sc.G2Project(WO_TARGET)
_co_target_project = G2sc.G2Project(CO_TARGET)
WO_BASE = oxygen_coordinates(_base_project, "gamma-WO3")
CO_BASE = oxygen_coordinates(_base_project, "CoWO4")
WO_END = oxygen_coordinates(_wo_target_project, "gamma-WO3")
CO_END = oxygen_coordinates(_co_target_project, "CoWO4")


def main():
    for fraction in (0.05, 0.10, 0.20):
        run(f"wo-{int(100 * fraction):02d}", wo_fraction=fraction)
    for fraction in (0.05, 0.10, 0.20):
        run(f"co-{int(100 * fraction):02d}", co_fraction=fraction)


if __name__ == "__main__":
    main()
