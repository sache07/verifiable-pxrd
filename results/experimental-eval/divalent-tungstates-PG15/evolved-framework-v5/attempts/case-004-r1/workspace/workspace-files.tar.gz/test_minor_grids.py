#!/usr/bin/env python3
"""Profile-test weak cobalt oxides on a stable WO3+CoWO4 checkpoint."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"
SOURCE = CHECK / "30-fixed-minor.gpx"
COO = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/54/16/1541662.cif")


def prepare(project):
    project.data["Controls"]["data"]["max cyc"] = 4
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histograms()[0]
    hist.set_refinements({"Background": True})
    hist.SampleParameters["Shift"][1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Scale": True})
    project.phase("gamma-WO3").set_HAP_refinements({"Scale": True})
    project.phase("CoWO4").set_HAP_refinements({"Scale": True})
    return hist


def report(project, family, scale):
    hist = project.histograms()[0]
    print(f"RESULT {family} fixed_scale={scale:.8g} Rwp={hist.residuals.get('wR')} R={hist.residuals.get('R')}")
    print("  mass", hist.ComputeMassFracs())


def main():
    for idx, scale in enumerate([1.0e-8, 0.03, 0.06, 0.1159105385, 0.18]):
        label = f"40-co3o4-grid-{idx}"
        project = G2sc.G2Project(SOURCE)
        prepare(project)
        minor = project.phase("Co3O4")
        minor.HAPvalue("Scale", scale)
        minor.clear_HAP_refinements({"Scale": True})
        out = CHECK / f"{label}.gpx"
        project.save(out)
        project.refine(makeBack=False)
        project.save(out)
        report(project, "Co3O4", scale)

    for idx, scale in enumerate([0.005, 0.02, 0.05, 0.10, 0.20]):
        label = f"41-coo-grid-{idx}"
        project = G2sc.G2Project(SOURCE)
        hist = prepare(project)
        project.phase("Co3O4").HAPvalue("Scale", 1.0e-8)
        out = CHECK / f"{label}.gpx"
        project.save(out)
        coo = project.add_phase(COO, phasename="CoO", histograms=[hist], fmthint="CIF")
        coo.HAPvalue("Scale", scale)
        coo.setSampleProfile(hist.name, "size", "isotropic", 0.10)
        coo.clear_HAP_refinements({"Scale": True})
        project.refine(makeBack=False)
        project.save(out)
        report(project, "CoO", scale)


if __name__ == "__main__":
    main()
