#!/usr/bin/env python3
"""Continue from the stable full-inventory checkpoint, one block at a time."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"


def summary(project: G2sc.G2Project, label: str) -> None:
    hist = project.histograms()[0]
    print(f"\n===== {label} =====")
    print("residuals", json.dumps(hist.residuals, sort_keys=True))
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)")})
    print("sample", {k: v for k, v in hist.SampleParameters.items()
                     if k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")})
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        print("phase", phase.name, "cell", phase.get_cell(), "scale", phase.HAPvalue("Scale"),
              "size", hap.get("Size"), "mustrain", hap.get("Mustrain"), "PO", hap.get("Pref.Ori."))
    try:
        print("mass_fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass_fractions unavailable", repr(exc))


def run(project: G2sc.G2Project, label: str) -> None:
    project.refine(makeBack=False)
    project.save(CHECK / f"{label}.gpx")
    summary(project, label)


def main() -> None:
    project = G2sc.G2Project(CHECK / "01-scales-background.gpx")
    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histograms()[0]
    wo3 = project.phase("gamma-WO3")
    cowo4 = project.phase("CoWO4")

    # The failed all-cell branch saved its flags into the source checkpoint;
    # explicitly restore the intended rollback state before branching again.
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    hist.clear_refinements({"Sample Parameters": ["Shift"]})

    wo3.set_refinements({"Cell": True})
    run(project, "11-wo3-cell")

    cowo4.set_refinements({"Cell": True})
    run(project, "12-cowo4-cell")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run(project, "13-shift")


if __name__ == "__main__":
    main()
