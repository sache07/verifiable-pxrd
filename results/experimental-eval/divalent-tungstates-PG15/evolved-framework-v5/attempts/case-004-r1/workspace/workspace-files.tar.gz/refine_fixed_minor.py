#!/usr/bin/env python3
"""Stabilize a bounded CoWO4 cell branch with the weak phase held positive."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"
SOURCE = CHECK / "11-wo3-cell.bak0.gpx"


def set_cell(phase, values):
    phase.data["General"]["Cell"][1:7] = values
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(values))


def report(project, label):
    hist = project.histograms()[0]
    print("\n", label, hist.residuals)
    print("shift", hist.SampleParameters["Shift"])
    for phase in project.phases():
        print(phase.name, phase.get_cell(), phase.HAPvalue("Scale"),
              phase.getHAPvalues(hist.name)["Scale"])
    print("mass", hist.ComputeMassFracs())


def main():
    project = G2sc.G2Project(SOURCE)
    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histograms()[0]
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    set_cell(project.phase("gamma-WO3"),
             [7.6873959404, 7.5313936437, 10.5332440106, 90.0, 136.123134473, 90.0])
    set_cell(project.phase("CoWO4"),
             [4.6658609743, 5.6824731030, 4.9463256249, 90.0, 89.8002501780, 90.0])
    hist.SampleParameters["Shift"] = [-60.5, False]
    minor = project.phase("Co3O4")
    minor.clear_HAP_refinements({"Scale": True})
    minor.HAPvalue("Scale", 0.1159105385)
    out = CHECK / "30-fixed-minor.gpx"
    project.save(out)
    project.refine(makeBack=False)
    project.save(out)
    report(project, "30-fixed-minor")

    # With the major intensities/background stabilized, test whether the minor
    # scale remains independently positive.
    hist.clear_refinements({"Background": True})
    project.phase("gamma-WO3").clear_HAP_refinements({"Scale": True})
    project.phase("CoWO4").clear_HAP_refinements({"Scale": True})
    minor.set_HAP_refinements({"Scale": True})
    project.data["Controls"]["data"]["max cyc"] = 5
    out2 = CHECK / "31-minor-scale-only.gpx"
    project.save(out2)
    project.refine(makeBack=False)
    project.save(out2)
    report(project, "31-minor-scale-only")


if __name__ == "__main__":
    main()
