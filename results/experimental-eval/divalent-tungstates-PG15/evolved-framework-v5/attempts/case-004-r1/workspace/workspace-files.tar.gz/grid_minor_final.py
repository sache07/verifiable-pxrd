#!/usr/bin/env python3
"""Fixed-positive minor-phase grids on the converged physical major model."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"
SOURCE = CHECK / "78-clean-base.gpx"
COO = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/54/16/1541662.cif"
)


def prepare(project):
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = project.histograms()[0]
    hist.SampleParameters["Shift"][1] = False
    hist.set_refinements({"Background": True})
    for values in hist.InstrumentParameters.values():
        if isinstance(values, list) and len(values) > 2:
            values[2] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        for atom in phase.atoms():
            atom.refinement_flags = " "
    for name in ("gamma-WO3", "CoWO4"):
        project.phase(name).set_HAP_refinements({"Scale": True})
    return hist


def report(project, label):
    hist = project.histograms()[0]
    print(
        f"RESULT {label} Rwp={hist.residuals.get('wR'):.8f} "
        f"R={hist.residuals.get('R'):.8f} mass={hist.ComputeMassFracs()}"
    )


def baseline():
    project = G2sc.G2Project(SOURCE)
    prepare(project)
    phase = project.phase("Co3O4")
    phase.HAPvalue("Use", False)
    phase.HAPvalue("Scale", 1.0e-8)
    out = CHECK / "79-grid-baseline.gpx"
    project.save(out)
    project.refine(makeBack=False)
    project.save(out)
    report(project, "baseline")


def co3o4_grid():
    for index, scale in enumerate((0.01, 0.03, 0.05, 0.10, 0.20)):
        project = G2sc.G2Project(SOURCE)
        prepare(project)
        phase = project.phase("Co3O4")
        phase.HAPvalue("Use", True)
        phase.HAPvalue("Scale", scale)
        phase.clear_HAP_refinements({"Scale": True})
        out = CHECK / f"79-grid-Co3O4-{index}.gpx"
        project.save(out)
        project.refine(makeBack=False)
        project.save(out)
        report(project, f"Co3O4 scale={scale}")


def coo_grid():
    for index, scale in enumerate((0.01, 0.025, 0.05, 0.10, 0.25, 0.50)):
        project = G2sc.G2Project(SOURCE)
        hist = prepare(project)
        # Change the autosave target before add_phase, preserving SOURCE.
        out = CHECK / f"79-grid-CoO-{index}.gpx"
        project.save(out)
        phase = project.add_phase(COO, phasename="CoO", histograms=[hist], fmthint="CIF")
        phase.HAPvalue("Scale", scale)
        phase.setSampleProfile(hist.name, "size", "isotropic", 0.10)
        phase.clear_HAP_refinements({"Scale": True, "Size": True})
        project.refine(makeBack=False)
        project.save(out)
        report(project, f"CoO scale={scale}")


def main():
    baseline()
    co3o4_grid()
    coo_grid()


if __name__ == "__main__":
    main()
