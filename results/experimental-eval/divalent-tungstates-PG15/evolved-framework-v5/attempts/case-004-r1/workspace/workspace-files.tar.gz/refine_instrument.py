#!/usr/bin/env python3
"""Refine shared instrument-profile terms from the physical size checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"


def prepare(project):
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    minor = project.phase("Co3O4")
    minor.HAPvalue("Use", False)
    minor.HAPvalue("Scale", 1.0e-8)
    minor.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True})
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    # Reject the nonphysical negative-microstrain branch explicitly.
    for phase in project.phases()[:2]:
        phase.clear_HAP_refinements({"Mustrain": True})


def report(project, label):
    hist = project.histograms()[0]
    print(f"\n===== {label} =====")
    print("residuals", json.dumps(hist.residuals, sort_keys=True))
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)")})
    for phase in project.phases()[:2]:
        hap = phase.getHAPvalues(hist.name)
        print(phase.name, "size", hap["Size"], "mustrain", hap["Mustrain"],
              "scale", phase.HAPvalue("Scale"), "cell", phase.get_cell())
    print("shift", hist.SampleParameters["Shift"], "mass", hist.ComputeMassFracs())


def run(source, output, parameters):
    project = G2sc.G2Project(CHECK / source)
    prepare(project)
    project.histograms()[0].set_refinements({"Instrument Parameters": parameters})
    out = CHECK / output
    project.save(out)
    project.refine(makeBack=False)
    project.save(out)
    report(project, output)


def main():
    run("61-co-size.gpx", "64-inst-uw.gpx", ["U", "W"])
    run("64-inst-uw.gpx", "65-inst-x.gpx", ["X"])
    run("65-inst-x.gpx", "66-inst-shl.gpx", ["SH/L"])


if __name__ == "__main__":
    main()
