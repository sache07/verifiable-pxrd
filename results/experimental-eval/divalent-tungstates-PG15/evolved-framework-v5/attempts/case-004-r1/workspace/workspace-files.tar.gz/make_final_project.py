#!/usr/bin/env python3
"""Create the clean, two-phase final GSAS-II project and matching CIFs."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "checkpoints" / "78-clean-base.gpx"
FINAL = ROOT / "final.gpx"


def remove_phase(project, name):
    phases = project.data["Phases"]
    if name in phases:
        del phases[name]
    for entry in project.names:
        if entry and entry[0] == "Phases" and name in entry:
            entry.remove(name)
    for hist in project.histograms():
        reflections = hist.data.get("Reflection Lists", {})
        reflections.pop(name, None)


def main():
    project = G2sc.G2Project(SOURCE)
    remove_phase(project, "Co3O4")
    project.data["Controls"]["data"]["max cyc"] = 15
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6

    hist = project.histograms()[0]
    hist.set_refinements({"Background": True, "Sample Parameters": ["Shift"]})
    for values in hist.InstrumentParameters.values():
        if isinstance(values, list) and len(values) > 2:
            values[2] = False

    for name in ("gamma-WO3", "CoWO4"):
        phase = project.phase(name)
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        size = phase.getHAPvalues(hist.name)["Size"]
        size[0] = "isotropic"
        size[2][0] = True
        po = phase.getHAPvalues(hist.name)["Pref.Ori."]
        po[0] = "MD"
        po[2] = True
        for atom in phase.atoms():
            atom.refinement_flags = " "

    project.save(FINAL)
    project.refine(makeBack=False)
    project.save(FINAL)

    print("FINAL phases", [phase.name for phase in project.phases()])
    print("FINAL histogram", hist.name)
    print("FINAL residuals", hist.residuals)
    print("FINAL mass fractions", hist.ComputeMassFracs())
    print("FINAL shift", hist.SampleParameters["Shift"])
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        print(
            "FINAL phase", phase.name,
            "cell", phase.get_cell(),
            "size", hap["Size"],
            "PO", hap["Pref.Ori."],
        )

    # Match the evaluator's atomic export convention: saved atoms, no cached
    # covariance-derived values. Do not save this in-memory covariance change.
    project.data["Covariance"]["data"] = {}
    project.phase("gamma-WO3").export_CIF(ROOT / "phase_wo3.cif")
    project.phase("CoWO4").export_CIF(ROOT / "phase_cowo4.cif")


if __name__ == "__main__":
    main()
