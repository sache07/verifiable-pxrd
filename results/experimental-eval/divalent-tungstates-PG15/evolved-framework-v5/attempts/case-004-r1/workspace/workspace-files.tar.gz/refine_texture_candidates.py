#!/usr/bin/env python3
"""Test the two supported March-Dollase axes after bounded O corrections."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"
SOURCE = CHECK / "74-oxygen-both-20.gpx"


def set_md(project, phase_name, axis):
    phase = project.phase(phase_name)
    po = phase.getHAPvalues(project.histograms()[0].name)["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)


def run(label, choices):
    project = G2sc.G2Project(SOURCE)
    project.data["Controls"]["data"]["max cyc"] = 10
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    for phase in project.phases():
        phase.clear_HAP_refinements({"Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    minor = project.phase("Co3O4")
    minor.HAPvalue("Use", False)
    minor.HAPvalue("Scale", 1.0e-8)
    minor.clear_HAP_refinements({"Scale": True})
    for phase_name, axis in choices:
        set_md(project, phase_name, axis)
    out = CHECK / f"75-texture-{label}.gpx"
    project.save(out)
    project.refine(makeBack=False)
    project.save(out)
    hist = project.histograms()[0]
    values = {
        phase_name: project.phase(phase_name).getHAPvalues(hist.name)["Pref.Ori."][1]
        for phase_name, _axis in choices
    }
    print(
        f"RESULT {label} Rwp={hist.residuals.get('wR'):.8f} "
        f"MD={values} mass={hist.ComputeMassFracs()}"
    )


def main():
    wo = ("gamma-WO3", [1, 1, 0])
    co = ("CoWO4", [0, 0, 1])
    run("wo110", [wo])
    run("co001", [co])
    run("both", [wo, co])


if __name__ == "__main__":
    main()
