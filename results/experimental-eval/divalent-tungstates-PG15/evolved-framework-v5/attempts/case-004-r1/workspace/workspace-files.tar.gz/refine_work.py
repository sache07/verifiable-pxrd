#!/usr/bin/env python3
"""Build and incrementally refine the complete three-phase GSAS-II model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
START = ROOT / ".tmp" / "starting_models"
CHECK = ROOT / ".tmp" / "checkpoints"


def summarize(project: G2sc.G2Project, label: str) -> None:
    hist = project.histograms()[0]
    print(f"\n===== {label} =====")
    print("residuals", json.dumps(hist.residuals, sort_keys=True))
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)")})
    print("sample", {k: v for k, v in hist.SampleParameters.items()
                     if k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB", "Gonio. radius")})
    for phase in project.phases():
        print("phase", phase.name, "cell", phase.get_cell(),
              "scale", phase.HAPvalue("Scale"),
              "size", phase.getHAPvalues(hist.name).get("Size"),
              "mustrain", phase.getHAPvalues(hist.name).get("Mustrain"))
    try:
        print("mass_fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass_fractions unavailable", repr(exc))


def checkpoint(project: G2sc.G2Project, name: str) -> None:
    path = CHECK / f"{name}.gpx"
    project.save(path)
    summarize(project, name)


def refine(project: G2sc.G2Project, name: str) -> None:
    project.refine(makeBack=False)
    checkpoint(project, name)


def main() -> None:
    CHECK.mkdir(parents=True, exist_ok=True)
    work_gpx = CHECK / "working.gpx"
    project = G2sc.G2Project(newgpx=work_gpx)
    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5

    hist = project.add_powder_histogram(
        START / "pattern.xye",
        START / "lab_cuka.instprm",
        fmthint="xye",
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 12,
            "coeffs": [1000.0, -500.0] + [0.0] * 10,
        }
    })

    phase_specs = [
        ("gamma-WO3", "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif", 8.0e-4, 0.10),
        ("CoWO4", "CoWO4_start.cif", 2.0e-4, 0.10),
        ("Co3O4", "Co3O4_start.cif", 5.0e-5, 0.10),
    ]
    phases = []
    for phase_name, filename, scale, size in phase_specs:
        phase = project.add_phase(
            Path(filename) if Path(filename).is_absolute() else START / filename,
            phasename=phase_name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.HAPvalue("Scale", scale)
        phase.set_HAP_refinements({
            "Scale": True,
            "Size": {"type": "isotropic", "value": size, "refine": False},
        })
        phases.append(phase)

    # The phase scales define relative amounts; keep the redundant histogram
    # scale fixed.
    hist.SampleParameters["Scale"] = [1.0, False]
    checkpoint(project, "00-built")

    # Start with only linear/near-linear intensity terms.
    refine(project, "01-scales-background")

    # Refine cells after all accepted phases are present.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "02-cells")

    # Bragg-Brentano specimen displacement is physically expected in this lab.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "03-shift")

    project.save(work_gpx)


if __name__ == "__main__":
    main()
