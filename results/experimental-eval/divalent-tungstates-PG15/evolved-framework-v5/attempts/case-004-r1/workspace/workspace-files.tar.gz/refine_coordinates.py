#!/usr/bin/env python3
"""Refine heavy and then oxygen coordinates with physical checkpoints."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"


def prepare(project):
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    minor = project.phase("Co3O4")
    minor.HAPvalue("Use", False)
    minor.HAPvalue("Scale", 1.0e-8)
    minor.clear_HAP_refinements({"Scale": True})
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def run(source, output, selector):
    project = G2sc.G2Project(CHECK / source)
    prepare(project)
    selector(project)
    out = CHECK / output
    project.save(out)
    project.refine(makeBack=False)
    project.save(out)
    hist = project.histograms()[0]
    print(f"\n===== {output} =====")
    print("residuals", json.dumps(hist.residuals, sort_keys=True))
    print("shift", hist.SampleParameters["Shift"])
    for phase in project.phases()[:2]:
        print("phase", phase.name, phase.get_cell(), phase.HAPvalue("Scale"))
        for atom in phase.atoms():
            print(" ", atom.label, atom.element, tuple(round(v, 8) for v in atom.coordinates),
                  "Uiso", atom.uiso, "flags", atom.refinement_flags)
        phase.export_CIF(CHECK / f"{output[:-4]}-{phase.name}.cif")
    try:
        print("mass", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass unavailable", repr(exc))


def main():
    def wo_heavy(project):
        for atom in project.phase("gamma-WO3").atoms():
            if atom.element == "W":
                atom.refinement_flags = "X"
    run("52-shift.gpx", "53-wo-heavy.gpx", wo_heavy)

    def co_heavy(project):
        for atom in project.phase("CoWO4").atoms():
            if atom.element in ("W", "Co"):
                atom.refinement_flags = "X"
    run("53-wo-heavy.gpx", "54-co-heavy.gpx", co_heavy)

    def wo_oxygen(project):
        for atom in project.phase("gamma-WO3").atoms():
            if atom.element == "O":
                atom.refinement_flags = "X"
    run("54-co-heavy.gpx", "55-wo-oxygen.gpx", wo_oxygen)

    def co_oxygen(project):
        for atom in project.phase("CoWO4").atoms():
            if atom.element == "O":
                atom.refinement_flags = "X"
    run("55-wo-oxygen.gpx", "56-co-oxygen.gpx", co_oxygen)


if __name__ == "__main__":
    main()
