#!/usr/bin/env python3
"""Test physically bounded Bragg-Brentano specimen-intensity terms."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"
SOURCE = CHECK / "71-bounded-w40.gpx"


def main():
    project = G2sc.G2Project(SOURCE)
    project.data["Controls"]["data"]["max cyc"] = 10
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histograms()[0]
    hist.SampleParameters["SurfRoughA"] = [0.20, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({"Mustrain": True, "Pref.Ori.": True})
    minor = project.phase("Co3O4")
    minor.HAPvalue("Use", False)
    minor.HAPvalue("Scale", 1.0e-8)
    minor.clear_HAP_refinements({"Scale": True, "Size": True})
    out = CHECK / "72-surface-roughness.gpx"
    project.save(out)
    project.refine(makeBack=False)
    project.save(out)
    print("residuals", hist.residuals)
    print("sample", {k: hist.SampleParameters[k] for k in ("Shift", "SurfRoughA", "SurfRoughB")})
    print("mass", hist.ComputeMassFracs())
    for phase in project.phases()[:2]:
        print(phase.name, phase.HAPvalue("Scale"), phase.getHAPvalues(hist.name)["Size"], phase.get_cell())


if __name__ == "__main__":
    main()
