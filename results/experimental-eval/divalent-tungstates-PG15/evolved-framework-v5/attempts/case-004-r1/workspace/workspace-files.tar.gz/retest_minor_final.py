#!/usr/bin/env python3
"""Final independent-scale tests for plausible residual cobalt oxides."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"
SOURCE = CHECK / "76-full-rerun.gpx"
COO = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/54/16/1541662.cif"
)


def freeze_major_model(project):
    hist = project.histograms()[0]
    hist.clear_refinements({"Background": True})
    hist.SampleParameters["Shift"][1] = False
    for values in hist.InstrumentParameters.values():
        if isinstance(values, list) and len(values) > 2:
            values[2] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        for atom in phase.atoms():
            atom.refinement_flags = " "


def run_co3o4():
    project = G2sc.G2Project(SOURCE)
    project.data["Controls"]["data"]["max cyc"] = 8
    freeze_major_model(project)
    phase = project.phase("Co3O4")
    phase.HAPvalue("Use", True)
    phase.HAPvalue("Scale", 0.10)
    phase.set_HAP_refinements({"Scale": True})
    out = CHECK / "77-test-Co3O4.gpx"
    project.save(out)
    project.refine(makeBack=False)
    project.save(out)
    hist = project.histograms()[0]
    print(
        "RESULT Co3O4",
        "scale", phase.HAPvalue("Scale"),
        "Rwp", hist.residuals.get("wR"),
        "mass", hist.ComputeMassFracs(),
    )


def run_coo(start):
    project = G2sc.G2Project(SOURCE)
    project.data["Controls"]["data"]["max cyc"] = 8
    freeze_major_model(project)
    hist = project.histograms()[0]
    phase = project.add_phase(COO, phasename="CoO", histograms=[hist], fmthint="CIF")
    phase.HAPvalue("Scale", start)
    phase.setSampleProfile(hist.name, "size", "isotropic", 0.10)
    phase.set_HAP_refinements({"Scale": True})
    out = CHECK / f"77-test-CoO-{str(start).replace('.', 'p')}.gpx"
    project.save(out)
    project.refine(makeBack=False)
    project.save(out)
    print(
        "RESULT CoO",
        "start", start,
        "scale", phase.HAPvalue("Scale"),
        "Rwp", hist.residuals.get("wR"),
        "mass", hist.ComputeMassFracs(),
    )


def main():
    run_co3o4()
    run_coo(0.10)
    run_coo(0.50)


if __name__ == "__main__":
    main()
