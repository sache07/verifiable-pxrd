#!/usr/bin/env python3
"""Extend the fixed-positive CoO scale profile test around its optimum."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CHECK = ROOT / ".tmp" / "checkpoints"
SOURCE = CHECK / "30-fixed-minor.gpx"
COO = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/54/16/1541662.cif")


def main():
    for idx, scale in enumerate([0.35, 0.50, 0.70, 0.90, 1.20, 1.60]):
        project = G2sc.G2Project(SOURCE)
        project.data["Controls"]["data"]["max cyc"] = 4
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
        hist = project.histograms()[0]
        hist.set_refinements({"Background": True})
        hist.SampleParameters["Shift"][1] = False
        for phase in project.phases():
            phase.clear_refinements({"Cell": True})
            phase.clear_HAP_refinements({"Scale": True})
        project.phase("gamma-WO3").set_HAP_refinements({"Scale": True})
        project.phase("CoWO4").set_HAP_refinements({"Scale": True})
        project.phase("Co3O4").HAPvalue("Scale", 1.0e-8)
        out = CHECK / f"42-coo-grid-{idx}.gpx"
        project.save(out)
        coo = project.add_phase(COO, phasename="CoO", histograms=[hist], fmthint="CIF")
        coo.HAPvalue("Scale", scale)
        coo.setSampleProfile(hist.name, "size", "isotropic", 0.10)
        coo.clear_HAP_refinements({"Scale": True})
        project.refine(makeBack=False)
        project.save(out)
        print(f"RESULT CoO fixed_scale={scale:.8g} Rwp={hist.residuals.get('wR')} R={hist.residuals.get('R')}")
        print("  mass", hist.ComputeMassFracs())


if __name__ == "__main__":
    main()
