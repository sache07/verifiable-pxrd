#!/usr/bin/env python3
"""Common-Uiso sensitivity for the minor monoclinic WO3 phase."""

from pathlib import Path
from shutil import copy2

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "branch_uiso_0p0160.gpx"


def main():
    for uiso in (0.003, 0.008, 0.012, 0.018, 0.020):
        tag = f"{uiso:.3f}".replace(".", "p")
        out = ROOT / f"physical_wo3_uiso_{tag}.gpx"
        copy2(BASE, out)
        gpx = G2sc.G2Project(str(out))
        h = gpx.histogram(0)
        p = gpx.phase("WO3_2311041_mon")
        for atom in p.atoms():
            atom.ADP = uiso
            atom.refinement_flags = atom.refinement_flags.replace("U", "")
        gpx.set_Controls("cycles", 12)
        try:
            gpx.refine()
            gpx.save(str(out))
            print("RESULT", uiso, "Rwp", h.get_wR(), "mass", h.ComputeMassFracs(),
                  "polarization", h.InstrumentParameters["Polariz."])
        except Exception as exc:
            print("FAIL", uiso, repr(exc))


if __name__ == "__main__":
    main()
