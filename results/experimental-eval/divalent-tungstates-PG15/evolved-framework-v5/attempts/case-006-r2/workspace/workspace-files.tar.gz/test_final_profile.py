#!/usr/bin/env python3
"""Final physical profile checks from the best accepted checkpoint."""

from pathlib import Path
from shutil import copy2

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "branch_wo3_uiso_0p018.gpx"


def run(tag, add_size=False):
    out = ROOT / f"branch_final_{tag}.gpx"
    copy2(BASE, out)
    gpx = G2sc.G2Project(str(out))
    h = gpx.histogram(0)
    p = gpx.phase("CuWO4")
    h.set_refinements({"Instrument Parameters": ["W", "X"]})
    if add_size:
        p.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True}})
    gpx.set_Controls("cycles", 12)
    try:
        gpx.refine()
        gpx.save(str(out))
        print("RESULT", tag, "Rwp", h.get_wR(), "mass", h.ComputeMassFracs())
        print(" instrument", {k: h.InstrumentParameters[k] for k in ("U", "W", "X", "SH/L")})
        print(" profile", {k: p.getHAPvalues(h.name)[k] for k in ("Size", "Mustrain")})
    except Exception as exc:
        print("FAIL", tag, repr(exc))


def main():
    run("wx")
    run("wx_size", add_size=True)


if __name__ == "__main__":
    main()
