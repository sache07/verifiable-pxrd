#!/usr/bin/env python3
"""Repeat a GSAS-II refinement from a saved checkpoint and report the result."""

import argparse
from pathlib import Path
from shutil import copy2

from GSASII import GSASIIscriptable as G2sc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    args = ap.parse_args()
    src = Path(args.input).resolve()
    dst = Path(args.output).resolve()
    copy2(src, dst)
    gpx = G2sc.G2Project(str(dst))
    h = gpx.histogram(0)
    print("BEFORE", h.residuals, h.ComputeMassFracs())
    gpx.set_Controls("cycles", 12)
    gpx.refine()
    gpx.save(str(dst))
    print("AFTER", h.residuals, h.ComputeMassFracs())
    for p in gpx.phases():
        print(p.name, p.get_cell(), p.getHAPvalues(h.name))
        p.export_CIF(str(dst.with_suffix("")) + "_" + p.name + ".cif")
        for a in p.atoms():
            print(" ", a.label, a.element, a.coordinates, a.ADP, a.refinement_flags)


if __name__ == "__main__":
    main()
