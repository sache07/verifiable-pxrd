#!/usr/bin/env python3
"""Small bounded CuWO4 coordinate restarts from the best physical checkpoint."""

from pathlib import Path
from random import Random
from shutil import copy2

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "branch_uniaxial_001.gpx"


def main():
    for seed in (17, 29, 43):
        out = ROOT / f"restart_coords_{seed}.gpx"
        copy2(BASE, out)
        gpx = G2sc.G2Project(str(out))
        h = gpx.histogram(0)
        p = gpx.phase("CuWO4")
        rng = Random(seed)
        for atom in p.atoms():
            if atom.label == "W1":
                continue
            atom.coordinates = tuple((v + rng.uniform(-0.004, 0.004)) % 1.0
                                     for v in atom.coordinates)
            atom.refinement_flags = "X"
        gpx.set_Controls("cycles", 12)
        try:
            gpx.refine()
            gpx.save(str(out))
            p.export_CIF(str(ROOT / f"restart_coords_{seed}.cif"))
            print("RESULT", seed, "Rwp", h.get_wR(), "mass", h.ComputeMassFracs())
            for atom in p.atoms():
                print(" ", atom.label, atom.coordinates)
        except Exception as exc:
            print("FAIL", seed, repr(exc))


if __name__ == "__main__":
    main()
