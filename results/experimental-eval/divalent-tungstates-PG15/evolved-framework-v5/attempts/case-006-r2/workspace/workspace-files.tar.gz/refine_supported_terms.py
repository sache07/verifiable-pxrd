#!/usr/bin/env python3
"""Add only supported physical profile/intensity terms, one checkpoint at a time."""

from pathlib import Path
from shutil import copy2

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def summary(gpx, label):
    h = gpx.histogram(0)
    p = gpx.phase("CuWO4")
    print("\n", label, h.residuals, "mass", h.ComputeMassFracs())
    print("instrument", {k: h.InstrumentParameters[k] for k in
                         ("Zero", "Polariz.", "U", "W", "X", "SH/L")})
    print("sample", {k: h.SampleParameters[k] for k in
                     ("Shift", "SurfRoughA", "SurfRoughB")})
    print("profile", {k: p.getHAPvalues(h.name)[k]
                      for k in ("Size", "Mustrain", "Pref.Ori.")})


def checkpoint(gpx, filename, label):
    gpx.set_Controls("cycles", 12)
    gpx.refine()
    gpx.save(str(ROOT / filename))
    summary(gpx, label)


def main():
    work = ROOT / "supported_terms_work.gpx"
    copy2(ROOT / "branch_mustrain.gpx", work)
    gpx = G2sc.G2Project(str(work))
    h = gpx.histogram(0)
    p = gpx.phase("CuWO4")
    gpx.save(str(ROOT / "checkpoint_10_isotropic_mustrain.gpx"))
    summary(gpx, "accepted isotropic microstrain")

    h.set_refinements({"Instrument Parameters": ["Polariz."]})
    checkpoint(gpx, "checkpoint_11_polarization.gpx", "polarization")

    # [100] gave the best of the five lab-supported March-Dollase axes.
    po = p.getHAPvalues(h.name)["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 1.0, True, [1, 0, 0]
    checkpoint(gpx, "checkpoint_12_texture.gpx", "[100] March-Dollase")

    h.set_refinements({"Instrument Parameters": ["SH/L"]})
    checkpoint(gpx, "checkpoint_13_asymmetry.gpx", "axial divergence")

    # One final cycle with the accepted flags active.
    checkpoint(gpx, "checkpoint_14_combined.gpx", "combined supported model")


if __name__ == "__main__":
    main()
