#!/usr/bin/env python3
"""Extend the best physical model to the complete measured grid and refine."""

from pathlib import Path
from shutil import copy2

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SRC = ROOT / "branch_uiso_0p0160.gpx"
DST = ROOT / "checkpoint_16_physical_full_grid.gpx"


def main():
    copy2(SRC, DST)
    gpx = G2sc.G2Project(str(DST))
    h = gpx.histogram(0)
    x = h.getdata("X")
    h.Limits("lower", float(x[0]))
    h.Limits("upper", float(x[-1]))
    gpx.set_Controls("cycles", 12)
    gpx.refine()
    gpx.save(str(DST))
    print("FULL_GRID", h.Limits("lower"), h.Limits("upper"), len(x), h.residuals,
          h.ComputeMassFracs())
    print("instrument", h.InstrumentParameters)
    print("sample", h.SampleParameters)
    for p in gpx.phases():
        print(p.name, p.get_cell(), p.getHAPvalues(h.name))


if __name__ == "__main__":
    main()
