#!/usr/bin/env python3
"""Write the submitted profile from the independent atomic GSAS-II replay."""

from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent


def main():
    replay = np.load(ROOT / ".tmp" / "replay_final" / "prediction.npz")
    x = replay["x"]
    observed = replay["observed"]
    calculated = replay["predicted"]
    background = replay["background"]
    difference = observed - calculated
    table = np.column_stack((x, observed, calculated, difference, background))
    np.savetxt(
        ROOT / "fit.csv",
        table,
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=("%.8f", "%.10g", "%.15g", "%.15g", "%.15g"),
    )


if __name__ == "__main__":
    main()
