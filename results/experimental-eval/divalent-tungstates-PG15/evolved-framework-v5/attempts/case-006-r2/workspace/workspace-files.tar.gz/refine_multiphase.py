#!/usr/bin/env python3
"""Staged refinement of the accepted CuWO4 + monoclinic WO3 inventory."""

from pathlib import Path
from shutil import copy2

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def summarize(gpx, label):
    h = gpx.histogram(0)
    print(f"\n{label}", h.residuals)
    print("mass fractions", h.ComputeMassFracs())
    print("instrument", {k: v[1:] for k, v in h.InstrumentParameters.items()
                         if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")})
    print("sample", {k: v for k, v in h.SampleParameters.items()
                     if k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")})
    for p in gpx.phases():
        print("phase", p.name, p.get_cell())
        print("HAP", {k: p.getHAPvalues(h.name)[k]
                      for k in ("Scale", "Size", "Mustrain", "Pref.Ori.")})
        for a in p.atoms():
            print(" ", a.label, a.element, a.coordinates, a.ADP, a.refinement_flags)


def checkpoint(gpx, filename, label):
    gpx.set_Controls("cycles", 12)
    gpx.refine()
    gpx.save(str(ROOT / filename))
    for p in gpx.phases():
        safe = p.name.replace("/", "_")
        p.export_CIF(str(ROOT / f"{filename[:-4]}_{safe}.cif"))
    summarize(gpx, label)


def main():
    work = ROOT / "multiphase_work.gpx"
    copy2(ROOT / "screen_WO3_2311041_mon.gpx", work)
    gpx = G2sc.G2Project(str(work))
    h = gpx.histogram(0)
    cuwo4 = gpx.phase("CuWO4")
    wo3 = gpx.phase("WO3_2311041_mon")

    # The published 1966 neutron model reports zero ADPs. A small, fixed,
    # physically ordinary room-temperature Uiso avoids a zero-displacement model.
    for atom in wo3.atoms():
        atom.ADP = 0.008

    # Scale/background, both cells, and the two physically distinct angular
    # calibration terms. Bounds follow the stated laboratory envelope.
    cuwo4.set_HAP_refinements({"Scale": True})
    wo3.set_HAP_refinements({"Scale": True})
    cuwo4.set_refinements({"Cell": True})
    wo3.set_refinements({"Cell": True})
    h.set_refinements({
        "Background": True,
        "Instrument Parameters": ["Zero"],
        "Sample Parameters": ["Shift"],
    })
    gpx.set_Controls("parmMin", -0.25, variable=":0:Zero")
    gpx.set_Controls("parmMax", 0.25, variable=":0:Zero")
    gpx.set_Controls("parmMin", -800.0, variable=":0:Shift")
    gpx.set_Controls("parmMax", 800.0, variable=":0:Shift")
    checkpoint(gpx, "checkpoint_07_cells_calibration.gpx", "cells + calibration")

    # W1 anchors the arbitrary origin of triclinic CuWO4. Cu is refined first,
    # then the four oxygen sites. WO3 coordinates stay at the neutron model
    # because a ~2 wt% phase cannot support independent coordinate refinement.
    cuwo4.set_refinements({"Atoms": {"Cu1": "X"}})
    checkpoint(gpx, "checkpoint_08_heavy_coords.gpx", "Cu relative to anchored W")

    cuwo4.set_refinements({"Atoms": {"O1": "X", "O2": "X", "O3": "X", "O4": "X"}})
    checkpoint(gpx, "checkpoint_09_light_coords.gpx", "oxygen coordinates")


if __name__ == "__main__":
    main()
