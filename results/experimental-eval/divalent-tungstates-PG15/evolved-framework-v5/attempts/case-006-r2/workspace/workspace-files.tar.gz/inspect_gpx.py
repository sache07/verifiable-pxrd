#!/usr/bin/env python3
"""Summarize a GSAS-II project and map coherent residual features."""

import argparse
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2sc


def peak_table(x, r, sign=1, n=40):
    smooth = gaussian_filter1d(sign * r, 1.2)
    peaks, props = find_peaks(smooth, prominence=35.0, distance=5, width=1)
    order = np.argsort(props["prominences"])[::-1]
    rows = []
    for j in order[:n]:
        i = peaks[j]
        rows.append((x[i], r[i], props["prominences"][j], props["widths"][j]))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("gpx")
    ap.add_argument("--plot")
    ap.add_argument("--csv")
    args = ap.parse_args()
    gpx = G2sc.G2Project(args.gpx)
    h = gpx.histogram(0)
    x = np.asarray(h.getdata("X"))
    yo = np.asarray(h.getdata("Yobs"))
    yc = np.asarray(h.getdata("Ycalc"))
    bg = np.asarray(h.getdata("Background"))
    r = yo - yc
    print("project", Path(args.gpx).resolve())
    print("histogram", h.name, h.residuals)
    print("instrument", {k: v for k, v in h.InstrumentParameters.items()})
    print("sample", h.SampleParameters)
    for p in gpx.phases():
        print("phase", p.name, "id", p.id, "cell", p.get_cell(), "composition", p.composition)
        print("HAP", p.getHAPvalues(h.name))
        print("atoms")
        for a in p.atoms():
            print(a.label, a.element, a.coordinates, a.occupancy, a.ADP, a.refinement_flags)
    use = (x >= h.Limits("lower")) & (x <= h.Limits("upper"))
    print("residual mean/rms/max/min", np.mean(r[use]), np.sqrt(np.mean(r[use]**2)), np.max(r[use]), np.min(r[use]))
    print("positive residual peaks: 2theta residual prominence width_points")
    for row in peak_table(x[use], r[use], 1):
        print("%9.4f %10.2f %10.2f %7.2f" % row)
    print("negative residual peaks: 2theta residual prominence width_points")
    for row in peak_table(x[use], r[use], -1):
        print("%9.4f %10.2f %10.2f %7.2f" % row)
    if args.csv:
        np.savetxt(args.csv, np.column_stack([x, yo, yc, bg, r]), delimiter=",",
                   header="two_theta_deg,observed,calculated,background,difference", comments="")
    if args.plot:
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
        except ModuleNotFoundError:
            print("matplotlib is not installed in this interpreter; skipping plot")
            return
        fig, axes = plt.subplots(2, 1, figsize=(16, 9), sharex=True,
                                 gridspec_kw={"height_ratios": [2, 1]})
        axes[0].plot(x, yo, lw=0.55, color="black", label="observed")
        axes[0].plot(x, yc, lw=0.55, color="red", label="calculated")
        axes[0].plot(x, bg, lw=0.45, color="royalblue", label="background")
        axes[0].legend(loc="upper right")
        axes[0].set_ylabel("counts")
        axes[1].plot(x, r, lw=0.55, color="black")
        axes[1].axhline(0, lw=0.4, color="red")
        axes[1].set_ylabel("obs - calc")
        axes[1].set_xlabel(r"2theta (deg)")
        axes[1].set_xlim(h.Limits("lower"), h.Limits("upper"))
        fig.tight_layout()
        fig.savefig(args.plot, dpi=160)


if __name__ == "__main__":
    main()
