#!/usr/bin/env python3
"""Physical common-Uiso grid for the principal CuWO4 phase."""

from pathlib import Path
from shutil import copy2

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "branch_uniaxial_001.gpx"


def main():
    for uiso in (0.015, 0.016, 0.0165, 0.017):
        tag = f"{uiso:.4f}".replace(".", "p")
        out = ROOT / f"branch_uiso_{tag}.gpx"
        copy2(BASE, out)
        gpx = G2sc.G2Project(str(out))
        h = gpx.histogram(0)
        p = gpx.phase("CuWO4")
        for atom in p.atoms():
            atom.ADP = uiso
            atom.refinement_flags = atom.refinement_flags.replace("U", "")
        gpx.set_Controls("cycles", 12)
        try:
            gpx.refine()
            gpx.save(str(out))
            print("RESULT", uiso, "Rwp", h.get_wR(), "mass", h.ComputeMassFracs())
        except Exception as exc:
            print("FAIL", uiso, repr(exc))


if __name__ == "__main__":
    main()
