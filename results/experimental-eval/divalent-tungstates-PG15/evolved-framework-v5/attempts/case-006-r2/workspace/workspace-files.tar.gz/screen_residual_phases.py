#!/usr/bin/env python3
"""Test chemically plausible residual CuO/WO3 phases against the CuWO4 residual."""

from pathlib import Path
from shutil import copy2

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

CANDIDATES = [
    ("CuO_1011194", "1/01/11/1011194.cif"),
    ("CuO_9016057", "9/01/60/9016057.cif"),
    ("WO3_1004057_hex", "1/00/40/1004057.cif"),
    ("WO3_1521532_tet", "1/52/15/1521532.cif"),
    ("WO3_1521533_tet", "1/52/15/1521533.cif"),
    ("WO3_1528915_mon", "1/52/89/1528915.cif"),
    ("WO3_1563541_mon", "1/56/35/1563541.cif"),
    ("WO3_2311041_mon", "2/31/10/2311041.cif"),
    ("WO3_2106293_tri", "2/10/62/2106293.cif"),
    ("WO3_2107312_ortho", "2/10/73/2107312.cif"),
]


def freeze_principal_and_nuisance(gpx):
    h = gpx.histogram(0)
    principal = gpx.phase("CuWO4")
    principal.clear_refinements({"Cell": True, "Atoms": [a.label for a in principal.atoms()]})
    h.clear_refinements({
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L", "Zero"],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    })
    # Retain smooth background and principal/candidate scales only.
    h.set_refinements({"Background": True})
    principal.set_HAP_refinements({"Scale": True})


def main():
    base_rwp = G2sc.G2Project(str(ROOT / "checkpoint_06_o_coords.gpx")).histogram(0).get_wR()
    print("base Rwp", base_rwp)
    for name, rel in CANDIDATES:
        branch = ROOT / f"screen_{name}.gpx"
        copy2(ROOT / "checkpoint_06_o_coords.gpx", branch)
        gpx = G2sc.G2Project(str(branch))
        freeze_principal_and_nuisance(gpx)
        h = gpx.histogram(0)
        cand = gpx.add_phase(str(COD / rel), phasename=name, histograms=[h])
        cand.getHAPvalues(h.name)["Scale"][0] = 0.5
        cand.set_HAP_refinements({"Scale": True})
        gpx.set_Controls("cycles", 8)
        try:
            gpx.refine()
            scale = cand.getHAPvalues(h.name)["Scale"][0]
            first_rwp = h.get_wR()
            print("SCALE", name, "scale", scale, "Rwp", first_rwp,
                  "delta", base_rwp - first_rwp, "mass", h.ComputeMassFracs())
            # Only a stable positive candidate earns a cell-refinement test.
            if scale > 0 and first_rwp < base_rwp - 0.01:
                cand.set_refinements({"Cell": True})
                gpx.refine()
                print("CELL ", name, "scale", cand.getHAPvalues(h.name)["Scale"][0],
                      "Rwp", h.get_wR(), "delta", base_rwp - h.get_wR(),
                      "mass", h.ComputeMassFracs(), "cell", cand.get_cell())
            gpx.save(str(branch))
        except Exception as exc:
            print("FAIL ", name, repr(exc))


if __name__ == "__main__":
    main()
