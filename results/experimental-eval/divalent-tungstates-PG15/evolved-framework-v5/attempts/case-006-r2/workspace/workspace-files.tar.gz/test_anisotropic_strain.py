#!/usr/bin/env python3
"""Test the three laboratory-supported uniaxial microstrain axes."""

from pathlib import Path
from shutil import copy2

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "checkpoint_13_asymmetry.gpx"


def main():
    for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0]):
        tag = "".join(map(str, axis))
        out = ROOT / f"branch_uniaxial_{tag}.gpx"
        copy2(BASE, out)
        gpx = G2sc.G2Project(str(out))
        h = gpx.histogram(0)
        p = gpx.phase("CuWO4")
        p.set_HAP_refinements({
            "Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}
        })
        gpx.set_Controls("cycles", 12)
        try:
            gpx.refine()
            gpx.save(str(out))
            print("RESULT", tag, "Rwp", h.get_wR(), "mass", h.ComputeMassFracs(),
                  "mustrain", p.getHAPvalues(h.name)["Mustrain"])
        except Exception as exc:
            print("FAIL", tag, repr(exc))


if __name__ == "__main__":
    main()
