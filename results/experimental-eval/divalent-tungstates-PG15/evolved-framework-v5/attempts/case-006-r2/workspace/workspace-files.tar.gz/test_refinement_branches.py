#!/usr/bin/env python3
"""One-at-a-time tests for supported specimen/profile complexity."""

from pathlib import Path
from shutil import copy2

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "checkpoint_09_light_coords.gpx"


def configure(gpx, kind, axis=None):
    h = gpx.histogram(0)
    p = gpx.phase("CuWO4")
    if kind == "shl":
        h.set_refinements({"Instrument Parameters": ["SH/L"]})
    elif kind == "calib":
        h.set_refinements({
            "Instrument Parameters": ["Zero"],
            "Sample Parameters": ["Shift"],
        })
    elif kind == "polar":
        h.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif kind == "rough":
        h.SampleParameters["SurfRoughA"][0] = 0.20
        h.SampleParameters["SurfRoughB"][0] = 0.10
        h.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    elif kind == "mustrain":
        p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    elif kind == "size":
        p.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True}})
    elif kind == "po":
        po = p.getHAPvalues(h.name)["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(axis)
    else:
        raise ValueError(kind)


def report(gpx, label):
    h = gpx.histogram(0)
    p = gpx.phase("CuWO4")
    print("RESULT", label, "Rwp", h.get_wR(), "mass", h.ComputeMassFracs())
    print(" instrument", {k: h.InstrumentParameters[k] for k in
          ("Zero", "Polariz.", "U", "W", "X", "SH/L")})
    print(" sample", {k: h.SampleParameters[k] for k in
          ("Shift", "SurfRoughA", "SurfRoughB")})
    print(" profile", {k: p.getHAPvalues(h.name)[k] for k in
          ("Size", "Mustrain", "Pref.Ori.")})


def run(kind, label, axis=None):
    out = ROOT / f"branch_{label}.gpx"
    copy2(BASE, out)
    gpx = G2sc.G2Project(str(out))
    configure(gpx, kind, axis)
    gpx.set_Controls("cycles", 10)
    try:
        gpx.refine()
        gpx.save(str(out))
        report(gpx, label)
    except Exception as exc:
        print("FAIL", label, repr(exc))


def main():
    for kind in ("shl", "calib", "polar", "rough", "mustrain", "size"):
        run(kind, kind)
    for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]):
        run("po", "po_" + "".join(map(str, axis)), axis)


if __name__ == "__main__":
    main()
