#!/usr/bin/env python3
"""Refine the accepted CuWO4 inventory in staged, physical checkpoints."""

from pathlib import Path
from shutil import copy2

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def summary(gpx, label):
    h = gpx.histogram(0)
    p = gpx.phase("CuWO4")
    print(f"\n{label}: {h.residuals}")
    print("cell", p.get_cell())
    print("instrument", {k: v[1:] for k, v in h.InstrumentParameters.items()
                         if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")})
    print("sample", {k: v for k, v in h.SampleParameters.items()
                     if k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")})
    print("HAP scale/profile", {k: p.getHAPvalues(h.name)[k]
                                for k in ("Scale", "Size", "Mustrain", "Pref.Ori.")})
    print("atoms")
    for atom in p.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.ADP, atom.refinement_flags)


def run_checkpoint(gpx, filename, label):
    gpx.set_Controls("cycles", 12)
    gpx.refine()
    gpx.save(str(ROOT / filename))
    gpx.phase("CuWO4").export_CIF(str(ROOT / filename.replace(".gpx", ".cif")))
    summary(gpx, label)


def main():
    work = ROOT / "principal_work.gpx"
    copy2(ROOT / "checkpoint_03_profile.gpx", work)
    gpx = G2sc.G2Project(str(work))
    h = gpx.histogram(0)
    p = gpx.phase("CuWO4")

    # Remove the exact sample/phase scale singularity while preserving intensity.
    sample_scale = h.SampleParameters["Scale"]
    hap_scale = p.getHAPvalues(h.name)["Scale"]
    hap_scale[0] *= sample_scale[0]
    sample_scale[:] = [1.0, False]

    # Roll back the unphysical negative Caglioti U; model any supported
    # high-angle broadening later with a positive specimen microstrain.
    h.InstrumentParameters["U"][1] = 0.0
    h.InstrumentParameters["U"][2] = False
    h.set_refinements({"Instrument Parameters": ["W", "X"]})
    p.set_HAP_refinements({"Scale": True})
    run_checkpoint(gpx, "checkpoint_04_physical_profile.gpx", "physical profile rollback")

    # Anchor W to remove the crystallographic origin null modes; refine Cu
    # relative to W, then oxygen positions as a separate checkpoint.
    p.set_refinements({"Atoms": {"Cu1": "X"}})
    run_checkpoint(gpx, "checkpoint_05_cu_coords.gpx", "Cu coordinates")

    p.set_refinements({"Atoms": {"O1": "X", "O2": "X", "O3": "X", "O4": "X"}})
    run_checkpoint(gpx, "checkpoint_06_o_coords.gpx", "oxygen coordinates")


if __name__ == "__main__":
    main()
