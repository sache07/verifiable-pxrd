#!/usr/bin/env python3
"""Build and refine the initial one-phase CuWO4 GSAS-II model."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CUWO4_PARENT = COD / "4/00/08/4000806.cif"


def summarize(gpx, label):
    hist = gpx.histogram(0)
    print(f"{label}: residuals={hist.residuals}")
    print("  instrument", {k: v[1] for k, v in hist.InstrumentParameters.items()
                            if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")})
    print("  sample", {k: v for k, v in hist.SampleParameters.items()
                        if k in ("Shift", "DisplaceX", "DisplaceY", "SurfRoughA", "SurfRoughB", "Scale", "Gonio. radius")})
    for phase in gpx.phases():
        print("  phase", phase.name, phase.get_cell(), phase.composition)
        print("    HAP", phase.getHAPvalues(hist.name))


def checkpoint(gpx, name, label):
    path = ROOT / name
    gpx.save(str(path))
    summarize(gpx, label)


def main():
    out = ROOT / "initial_cuwo4.gpx"
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    phase = gpx.add_phase(str(CUWO4_PARENT), phasename="CuWO4", histograms=[hist])

    # Ambient CuWO4 metric indexed directly from the observed reflection family.
    cell = [4.70625482, 5.84074946, 4.87893190, 91.65629436, 92.52395614, 82.75098797]
    phase.data["General"]["Cell"][1:7] = cell
    from GSASII import GSASIIlattice as G2lat
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))

    # Reflection geometry and physically expected goniometer radius.
    sample = hist.SampleParameters
    sample["Gonio. radius"] = 200.0
    print("initial sample keys", sample)
    print("initial background", hist.Background)
    print("initial instrument", hist.InstrumentParameters)

    hist.set_refinements({
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 8},
    })
    phase.set_HAP_refinements({"Scale": True})
    gpx.set_Controls("cycles", 8)
    gpx.refine()
    checkpoint(gpx, "checkpoint_01_scale_bg.gpx", "scale+background")

    # Cell and specimen position are introduced only after the scale/background settle.
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    gpx.refine()
    checkpoint(gpx, "checkpoint_02_cell_shift.gpx", "cell+shift")

    # Refine the least-correlated instrumental terms first.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    gpx.refine()
    checkpoint(gpx, "checkpoint_03_profile.gpx", "profile")

    gpx.save(str(out))


if __name__ == "__main__":
    main()
