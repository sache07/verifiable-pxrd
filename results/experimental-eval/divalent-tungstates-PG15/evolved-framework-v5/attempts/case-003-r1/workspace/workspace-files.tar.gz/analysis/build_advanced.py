#!/usr/bin/env python3
"""Converge supported profile terms and test cumulative texture/roughness."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path("analysis/anisotropy_tests/WO3_110.gpx")
OUT = Path("analysis/advanced")


def rwp(project):
    hist = project.histogram(0)
    x, y, w, yc, yb, yd = hist.data["data"][1]
    lo, hi = np.searchsorted(x, hist.data["Limits"][1])
    hi = min(hi, len(x))
    return float(100 * np.sqrt(np.sum(w[lo:hi] * (y[lo:hi] - yc[lo:hi]) ** 2) /
                               np.sum(w[lo:hi] * y[lo:hi] ** 2)))


def save(project, tag, rows, extra=None):
    project.save()
    shutil.copy2(project.filename, OUT / f"{tag}.gpx")
    row = {"stage": tag, "rwp": rwp(project), "extra": extra or {}}
    rows.append(row)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(row, flush=True)


def refine(project, tag, rows, cycles=12, extra=None):
    project.set_Controls("cycles", cycles)
    project.refine()
    save(project, tag, rows, extra)


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(OUT / "working.gpx"))
    hist = project.histogram(0)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""
        phase.data["Histograms"][hist.name]["Pref.Ori."][2] = False
    project.set_Frozen()
    rows = []
    refine(project, "00_WO3_anisotropy_converged", rows, cycles=20,
           extra={"mustrain": project.phase("WO3").data["Histograms"][hist.name]["Mustrain"]})
    wo3_hap = project.phase("WO3").data["Histograms"][hist.name]
    wo3_hap["Mustrain"][2][0] = False
    wo3_hap["Mustrain"][2][1] = False

    # The best symmetry-distinct texture tests are added cumulatively.
    cawo4 = project.phase("CaWO4")
    cawo4_hap = cawo4.data["Histograms"][hist.name]
    cawo4_hap["Pref.Ori."][0] = "MD"
    cawo4_hap["Pref.Ori."][1] = 1.0
    cawo4_hap["Pref.Ori."][2] = True
    cawo4_hap["Pref.Ori."][3] = [1, 1, 1]
    project.set_Controls("parmMin", 0.7, variable=f"{cawo4.id}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{cawo4.id}:0:MD")
    refine(project, "01_CaWO4_texture_111", rows, cycles=10)
    cawo4_hap["Pref.Ori."][2] = False
    project.set_Frozen()

    calcite = project.phase("CaCO3")
    calcite_hap = calcite.data["Histograms"][hist.name]
    calcite_hap["Pref.Ori."][0] = "MD"
    calcite_hap["Pref.Ori."][1] = 1.0
    calcite_hap["Pref.Ori."][2] = True
    calcite_hap["Pref.Ori."][3] = [0, 0, 1]
    project.set_Controls("parmMin", 0.7, variable=f"{calcite.id}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{calcite.id}:0:MD")
    refine(project, "02_CaCO3_texture_001", rows, cycles=10)
    calcite_hap["Pref.Ori."][2] = False
    project.set_Frozen()

    # Test the supported whole-specimen surface roughness model. This is a
    # branch; the no-roughness checkpoint above remains available.
    hist.SampleParameters["SurfRoughA"] = [0.20, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    refine(project, "03_surface_roughness_test", rows, cycles=12)


if __name__ == "__main__":
    main()
