#!/usr/bin/env python3
"""Test bounded uniaxial microstrain axes from a common physical checkpoint."""

from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


BASE = Path("analysis/final_work/17_recalibration.gpx")
OUT = Path("analysis/anisotropy_tests")


def rwp(project):
    hist = project.histogram(0)
    x, y, w, yc, yb, yd = hist.data["data"][1]
    lo, hi = np.searchsorted(x, hist.data["Limits"][1])
    hi = min(hi, len(x))
    return float(100 * np.sqrt(np.sum(w[lo:hi] * (y[lo:hi] - yc[lo:hi]) ** 2) /
                               np.sum(w[lo:hi] * y[lo:hi] ** 2)))


def clear_flags(project):
    hist = project.histogram(0)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][2] = False
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    project.set_Frozen()


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    tests = {
        "WO3": [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]],
        "CaWO4": [[0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]],
        "CaCO3": [[0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]],
    }
    base = G2.G2Project(gpxfile=str(BASE))
    rows = [{"phase": None, "axis": None, "rwp": rwp(base)}]
    for name, axes in tests.items():
        for axis in axes:
            tag = name + "_" + "".join(str(v) for v in axis)
            project = G2.G2Project(gpxfile=str(BASE))
            project.save(str(OUT / f"{tag}.gpx"))
            clear_flags(project)
            phase = project.phase(name)
            hap = phase.data["Histograms"][project.histogram(0).name]
            start = float(hap["Mustrain"][1][0])
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][0] = start
            hap["Mustrain"][1][1] = start
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][1] = True
            hap["Mustrain"][3] = axis
            project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
            project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;i")
            project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;a")
            project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;a")
            project.set_Controls("cycles", 8)
            project.refine()
            project.save()
            row = {
                "phase": name,
                "axis": axis,
                "equatorial_ppm": hap["Mustrain"][1][0],
                "axial_ppm": hap["Mustrain"][1][1],
                "rwp": rwp(project),
                "frozen": project.get_Frozen(),
            }
            rows.append(row)
            print(row, flush=True)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
