#!/usr/bin/env python3
"""Freeze and export the selected full-grid GSAS-II checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path("analysis/final_alternation/05_textures_converged.gpx")
FINAL_GPX = Path("final.gpx")


def freeze_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.data["General"]["doPawley"] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["LeBail"] = False
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 0
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    dep_sig = covariance.get("depSigDict", {})
    n_parameters = int(rvals.get("Nvars", len(covariance.get("varyList", []))))
    freeze_flags(project)
    project.save(str(FINAL_GPX.resolve()))

    # Reload exactly what will be submitted, and export all dependent products
    # from that serialized model.
    project = G2.G2Project(gpxfile=str(FINAL_GPX.resolve()))
    hist = project.histogram(0)
    x, observed, weights, calculated, background, difference_saved = hist.data["data"][1]
    difference = observed - calculated
    np.savetxt(
        "fit.csv",
        np.column_stack([x, observed, calculated, difference, background]),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
    )

    names = {
        "WO3": ("Monoclinic tungsten(VI) oxide", "WO3", "phase_WO3.cif", "COD 2311041"),
        "CaWO4": ("Scheelite calcium tungstate", "CaWO4", "phase_CaWO4.cif", "COD 7219229"),
        "CaCO3": ("Calcite", "CaCO3", "phase_CaCO3.cif", "COD 1547347"),
    }
    mass_scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scales.append(phase.data["General"]["Mass"] * hap["Scale"][0])
    total = float(sum(mass_scales))
    phase_rows = []
    for phase, mass_scale in zip(project.phases(), mass_scales):
        long_name, formula, cif_path, provenance = names[phase.name]
        phase.export_CIF(cif_path)
        esd_record = dep_sig.get(f"{phase.id}:0:WgtFrac")
        phase_rows.append(
            {
                "name": long_name,
                "formula": formula,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": cif_path,
                "weight_fraction": float(mass_scale / total),
                "weight_fraction_esd_statistical": (
                    float(esd_record[1]) if esd_record is not None else None
                ),
                "reference_provenance": provenance,
            }
        )

    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    n_observations = int(len(x))
    degrees_of_freedom = n_observations - n_parameters
    reduced = chi_square / degrees_of_freedom
    result = {
        "schema_version": 1,
        "refinement_histogram": hist.name,
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": float(hist.residuals.get("R", float("nan"))),
            "expected_rwp_percent": float(hist.residuals.get("wRmin", float("nan"))),
            "chi_square": chi_square,
            "reduced_chi_square": float(reduced),
            "goodness_of_fit_sqrt_reduced_chi_square": float(np.sqrt(reduced)),
            "number_of_observations": n_observations,
            "number_of_refined_parameters_last_cycle": n_parameters,
            "degrees_of_freedom": int(degrees_of_freedom),
        },
        "calibration": {
            "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
            "sample_shift_um_gsas_bragg_brentano": float(hist.SampleParameters["Shift"][0]),
        },
        "fraction_basis": "Normalized over the three modeled crystalline phases; amorphous content was not quantified.",
    }
    Path("result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
