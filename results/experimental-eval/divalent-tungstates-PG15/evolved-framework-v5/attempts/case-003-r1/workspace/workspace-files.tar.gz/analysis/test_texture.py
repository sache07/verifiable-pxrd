#!/usr/bin/env python3
"""Test one bounded March-Dollase term at a time from a common checkpoint."""

from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


BASE = Path("analysis/final_work/17_recalibration.gpx")
OUT = Path("analysis/texture_tests")


def rwp(project):
    hist = project.histogram(0)
    x, y, w, yc, yb, yd = hist.data["data"][1]
    lo, hi = np.searchsorted(x, hist.data["Limits"][1])
    hi = min(hi, len(x))
    return float(100 * np.sqrt(np.sum(w[lo:hi] * (y[lo:hi] - yc[lo:hi]) ** 2) /
                               np.sum(w[lo:hi] * y[lo:hi] ** 2)))


def clear_atom_and_texture_flags(project):
    hist = project.histogram(0)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""
        phase.data["Histograms"][hist.name]["Pref.Ori."][2] = False
    project.set_Frozen()


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    tests = {
        "WO3": [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]],
        "CaWO4": [[0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]],
        "CaCO3": [[0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]],
    }
    rows = []
    base = G2.G2Project(gpxfile=str(BASE))
    rows.append({"phase": None, "axis": None, "ratio": 1.0, "rwp": rwp(base)})
    for name, axes in tests.items():
        for axis in axes:
            tag = name + "_" + "".join(str(v) for v in axis)
            project = G2.G2Project(gpxfile=str(BASE))
            project.save(str(OUT / f"{tag}.gpx"))
            clear_atom_and_texture_flags(project)
            phase = project.phase(name)
            hap = phase.data["Histograms"][project.histogram(0).name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = axis
            project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")
            project.set_Controls("cycles", 8)
            project.refine()
            ratio = hap["Pref.Ori."][1]
            value = rwp(project)
            project.save()
            row = {"phase": name, "axis": axis, "ratio": ratio, "rwp": value,
                   "frozen": project.get_Frozen()}
            rows.append(row)
            print(row, flush=True)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
