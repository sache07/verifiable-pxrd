#!/usr/bin/env python3
"""Final one-term-at-a-time profile alternation from the best physical checkpoint."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path("analysis/background_tests/order_20_converged.gpx")
OUT = Path("analysis/final_alternation")


def rwp(project):
    hist = project.histogram(0)
    x, y, w, yc, yb, yd = hist.data["data"][1]
    lo, hi = np.searchsorted(x, hist.data["Limits"][1])
    hi = min(hi, len(x))
    return float(100 * np.sqrt(np.sum(w[lo:hi] * (y[lo:hi] - yc[lo:hi]) ** 2) /
                               np.sum(w[lo:hi] * y[lo:hi] ** 2)))


def save(project, tag, rows):
    project.save()
    shutil.copy2(project.filename, OUT / f"{tag}.gpx")
    row = {"stage": tag, "rwp": rwp(project), "frozen": project.get_Frozen()}
    rows.append(row)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(row, flush=True)


def run(project, tag, rows, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()
    save(project, tag, rows)


def fix_instrument(hist):
    for key in ["Zero", "Polariz.", "U", "W", "X", "SH/L"]:
        hist.InstrumentParameters[key][2] = False


def fix_profiles(project):
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = False


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(OUT / "working.gpx"))
    hist = project.histogram(0)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""
    fix_instrument(hist)
    fix_profiles(project)
    project.set_Frozen()
    rows = []
    save(project, "00_start", rows)

    # U and specimen height are at their supported boundaries and remain fixed.
    for key in ["Zero", "W", "X", "SH/L", "Polariz."]:
        hist.InstrumentParameters[key][2] = True
    run(project, "01_instrument", rows, 14)
    fix_instrument(hist)
    project.set_Frozen()

    wo3 = project.phase("WO3")
    hap = wo3.data["Histograms"][hist.name]
    hap["Size"][2][0] = True
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    run(project, "02_WO3_profile", rows, 14)
    fix_profiles(project)
    project.set_Frozen()

    cawo4 = project.phase("CaWO4")
    hap = cawo4.data["Histograms"][hist.name]
    hap["Mustrain"][2][0] = True
    run(project, "03_CaWO4_strain", rows, 10)
    fix_profiles(project)
    project.set_Frozen()

    calcite = project.phase("CaCO3")
    hap = calcite.data["Histograms"][hist.name]
    hap["Size"][2][0] = True
    hap["Mustrain"][2][0] = True
    run(project, "04_CaCO3_profile", rows, 10)
    fix_profiles(project)
    project.set_Frozen()

    cawo4.data["Histograms"][hist.name]["Pref.Ori."][2] = True
    calcite.data["Histograms"][hist.name]["Pref.Ori."][2] = True
    run(project, "05_textures", rows, 10)
    fix_profiles(project)
    project.set_Frozen()

    for key in ["Zero", "W", "X", "SH/L", "Polariz."]:
        hist.InstrumentParameters[key][2] = True
    run(project, "06_instrument_final", rows, 12)
    fix_instrument(hist)
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.refine()
    save(project, "07_final_zero_cycle", rows)


if __name__ == "__main__":
    main()
