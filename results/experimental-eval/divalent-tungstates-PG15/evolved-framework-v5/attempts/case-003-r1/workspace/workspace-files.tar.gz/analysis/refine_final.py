#!/usr/bin/env python3
"""Conservative bounded refinement of the accepted three-phase model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2


SOURCE = Path("analysis/candidates/2311041/08_phase_strain.gpx")
OUT = Path("analysis/final_work")


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}


def set_bound(project: G2.G2Project, variable: str, lower: float, upper: float) -> None:
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def phase_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    values = {
        phase.name: phase.data["General"]["Mass"]
        * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    }
    total = sum(values.values())
    return {key: value / total for key, value in values.items()}


def summary(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    x, y, w, yc, yb, yd = hist.data["data"][1]
    lo, hi = np.searchsorted(x, hist.data["Limits"][1])
    hi = min(hi, len(x))
    chi2 = float(np.sum(w[lo:hi] * (y[lo:hi] - yc[lo:hi]) ** 2))
    denominator = float(np.sum(w[lo:hi] * y[lo:hi] ** 2))
    phases = []
    fractions = phase_fractions(project)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "weight_fraction": fractions[phase.name],
                "cell": phase.data["General"]["Cell"][1:8],
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": list(atom.coordinates),
                        "flag": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    result = {
        "stage": stage,
        "rwp_percent": 100.0 * np.sqrt(chi2 / denominator),
        "chi_square": chi2,
        "gsas_residuals": hist.residuals,
        "background_min": float(np.min(yb)),
        "background_max": float(np.max(yb)),
        "sample": hist.SampleParameters,
        "instrument": hist.InstrumentParameters,
        "frozen": project.get_Frozen(),
        "phases": phases,
    }
    print(
        f"{stage:24s} Rwp={result['rwp_percent']:8.4f} "
        f"bkgmin={result['background_min']:8.2f} "
        f"fractions={fractions}",
        flush=True,
    )
    return result


def checkpoint(project: G2.G2Project, stage: str, history: list[dict]) -> None:
    project.save()
    shutil.copy2(project.filename, OUT / f"{stage}.gpx")
    history.append(summary(project, stage))
    (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")


def refine(
    project: G2.G2Project, stage: str, history: list[dict], cycles: int = 8
) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    checkpoint(project, stage, history)


def fix_instrument(hist) -> None:
    for key in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]:
        hist.InstrumentParameters[key][2] = False


def fix_profiles(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def main() -> None:
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(OUT / "physical.gpx"))
    clear_flags(project)
    hist = project.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [-750.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    initial_inst = {
        "Zero": -0.15,
        "Polariz.": 0.70,
        "U": 30.0,
        "V": 0.0,
        "W": 10.0,
        "X": 3.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.03,
    }
    for key, value in initial_inst.items():
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False

    profile_start = {
        "WO3": (0.30, 2500.0),
        "CaWO4": (0.08, 500.0),
        "CaCO3": (0.80, 500.0),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = profile_start[phase.name][0]
        hap["Size"][2][0] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = profile_start[phase.name][1]
        hap["Mustrain"][2][0] = False
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    hist.Background[0][1] = True

    # Limits are the explicit laboratory/specimen envelope in LAB.md.
    set_bound(project, ":0:Zero", -0.25, 0.25)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    set_bound(project, ":0:Polariz.", 0.5, 1.0)
    set_bound(project, ":0:U", 0.0, 40.0)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:X", 0.1, 6.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    for phase in project.phases():
        set_bound(project, f"{phase.id}:0:Scale", 0.0, 1.0e6)
        set_bound(project, f"{phase.id}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)

    history: list[dict] = []
    checkpoint(project, "00_reset", history)
    refine(project, "01_scale_background", history, 8)

    # Separate the highly correlated zero and sample-height terms.
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    hist.SampleParameters["Shift"][1] = True
    refine(project, "02_cells_shift", history, 10)
    hist.SampleParameters["Shift"][1] = False
    project.set_Frozen()
    hist.InstrumentParameters["Zero"][2] = True
    refine(project, "03_zero", history, 8)
    hist.InstrumentParameters["Zero"][2] = False
    project.set_Frozen()

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, "04_instrument_width", history, 10)
    fix_instrument(hist)
    project.set_Frozen()
    hist.set_refinements({"Instrument Parameters": ["SH/L", "Polariz."]})
    refine(project, "05_asymmetry_polarization", history, 8)
    fix_instrument(hist)
    project.set_Frozen()

    # Release one phase-width term at a time and freeze it before the next.
    for index, phase in enumerate(project.phases(), start=6):
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}
        )
        refine(project, f"{index:02d}_size_{phase.name}", history, 8)
        phase.data["Histograms"][hist.name]["Size"][2][0] = False
        project.set_Frozen()
    for index, phase in enumerate(project.phases(), start=9):
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
        refine(project, f"{index:02d}_strain_{phase.name}", history, 8)
        phase.data["Histograms"][hist.name]["Mustrain"][2][0] = False
        project.set_Frozen()

    # Re-estimate the common instrument width with phase widths fixed.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, "12_width_alternation", history, 8)
    fix_instrument(hist)
    project.set_Frozen()

    # Heavy coordinates first, then oxygen coordinates phase by phase.
    wo3 = project.phase("WO3")
    for label in ["W1", "W2"]:
        wo3.atom(label).refinement_flags = "X"
    refine(project, "13_WO3_W_coordinates", history, 10)
    for label in ["W1", "W2"]:
        wo3.atom(label).refinement_flags = ""
    for label in ["O1", "O2", "O3", "O4", "O5", "O6"]:
        wo3.atom(label).refinement_flags = "X"
    refine(project, "14_WO3_O_coordinates", history, 12)
    for label in ["O1", "O2", "O3", "O4", "O5", "O6"]:
        wo3.atom(label).refinement_flags = ""

    cawo4 = project.phase("CaWO4")
    cawo4.atom("O1").refinement_flags = "X"
    refine(project, "15_CaWO4_O_coordinates", history, 8)
    cawo4.atom("O1").refinement_flags = ""

    calcite = project.phase("CaCO3")
    calcite.atom("O1").refinement_flags = "X"
    refine(project, "16_CaCO3_O_coordinates", history, 8)
    calcite.atom("O1").refinement_flags = ""

    project.save()


if __name__ == "__main__":
    main()
