#!/usr/bin/env python3
"""Build comparable three-phase GSAS-II fits for candidate WO3 models."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def instrument_text() -> str:
    return (
        "# Synthetic laboratory instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.02;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:20.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def background_coefficients(pattern: Path, count: int = 10) -> list[float]:
    x, y = np.loadtxt(pattern, delimiter=",", skiprows=1).T
    # A broad lower-envelope estimate is only an initializer; all coefficients
    # are subsequently refined against the original Poisson-weighted profile.
    baseline = percentile_filter(y, percentile=12, size=501, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    coeffs = np.polynomial.chebyshev.chebfit(t, baseline, count - 1)
    return coeffs.tolist()


def snapshot(project: G2.G2Project, folder: Path, name: str) -> None:
    project.save()
    shutil.copy2(project.filename, folder / f"{name}.gpx")


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.data["General"]["Cell"][1:8],
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    total = sum(masses)
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / total
    result = {
        "stage": label,
        "residuals": hist.residuals,
        "sample": hist.SampleParameters,
        "instrument": hist.InstrumentParameters,
        "background": hist.Background,
        "phases": phases,
    }
    print(
        f"{label:18s} Rwp={hist.residuals.get('wR', float('nan')):9.4f} "
        f"GOF={project.data.get('Covariance', {}).get('data', {}).get('GOF', float('nan')):9.4f}"
    )
    return result


def refine(project: G2.G2Project, label: str, folder: Path, history: list[dict]) -> None:
    project.set_Controls("cycles", 12)
    project.refine()
    history.append(state(project, label))
    snapshot(project, folder, label)


def build_fit(pattern: Path, out: Path, wo3_id: str) -> None:
    out.mkdir(parents=True, exist_ok=True)
    inst = out / "instrument.instprm"
    inst.write_text(instrument_text())
    gpx = out / "candidate.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    phase_specs = [
        ("WO3", wo3_id),
        ("CaWO4", "7219229"),
        ("CaCO3", "1547347"),
    ]
    phases = [
        project.add_phase(
            str(cod_path(cod_id)), phasename=name, fmthint="CIF"
        )
        for name, cod_id in phase_specs
    ]
    hist = project.add_powder_histogram(
        str(pattern), str(inst), phases="all", fmthint="comma"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-500.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    coeffs = background_coefficients(pattern)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(coeffs),
                "coeffs": coeffs,
                "refine": True,
            }
        }
    )
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [5.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = False
        hap["Extinction"] = [0.0, False]

    history: list[dict] = [state(project, "initial")]
    refine(project, "01_scale_background", out, history)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "02_calibration", out, history)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "03_cells", out, history)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, "04_instrument_width", out, history)

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine(project, "05_asymmetry", out, history)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "06_polarization", out, history)

    for phase in phases:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
        )
    refine(project, "07_phase_size", out, history)

    for phase in phases:
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    refine(project, "08_phase_strain", out, history)

    (out / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3-id", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    build_fit(args.pattern.resolve(), args.out.resolve(), args.wo3_id)


if __name__ == "__main__":
    main()
