#!/usr/bin/env python3
"""Refine oxygen sites within the supplied reference-mismatch envelope."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path("analysis/uiso_tests/CaWO4_0.012.gpx")
OUT = Path("analysis/bounded_coordinates")


def rwp(project):
    hist = project.histogram(0)
    x, y, w, yc, yb, yd = hist.data["data"][1]
    lo, hi = np.searchsorted(x, hist.data["Limits"][1])
    hi = min(hi, len(x))
    return float(100 * np.sqrt(np.sum(w[lo:hi] * (y[lo:hi] - yc[lo:hi]) ** 2) /
                               np.sum(w[lo:hi] * y[lo:hi] ** 2)))


def save(project, tag, rows):
    project.save()
    shutil.copy2(project.filename, OUT / f"{tag}.gpx")
    row = {"stage": tag, "rwp": rwp(project), "frozen": project.get_Frozen()}
    rows.append(row)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(row, flush=True)


def bound_atom(project, phase, atom_index, widths):
    atom = phase.atoms()[atom_index]
    for axis, value, width in zip("xyz", atom.coordinates, widths):
        variable = f"{phase.id}::dA{axis}:{atom_index}"
        project.set_Controls("parmMin", value - width, variable=variable)
        project.set_Controls("parmMax", value + width, variable=variable)


def refine_group(project, phase_name, labels, widths, tag, rows, cycles=12):
    phase = project.phase(phase_name)
    for index, atom in enumerate(phase.atoms()):
        if atom.label not in labels:
            continue
        atom.refinement_flags = "X"
        bound_atom(project, phase, index, widths)
    project.set_Controls("cycles", cycles)
    project.refine()
    save(project, tag, rows)
    for atom in phase.atoms():
        atom.refinement_flags = ""
    project.set_Frozen()


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(OUT / "working.gpx"))
    hist = project.histogram(0)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""
        phase.data["Histograms"][hist.name]["Pref.Ori."][2] = False
        phase.data["Histograms"][hist.name]["Mustrain"][2] = [False, False, False]
    project.set_Frozen()
    rows = []
    save(project, "00_start", rows)
    refine_group(project, "WO3", {"O1", "O2", "O3", "O4", "O5", "O6"},
                 (0.0065, 0.0065, 0.0050), "01_WO3_O_bounded", rows, 14)
    refine_group(project, "CaWO4", {"O1"},
                 (0.0070, 0.0070, 0.0040), "02_CaWO4_O_bounded", rows, 10)
    refine_group(project, "CaCO3", {"O1"},
                 (0.0120, 0.0120, 0.0060), "03_CaCO3_O_bounded", rows, 10)
    project.save()


if __name__ == "__main__":
    main()
