#!/usr/bin/env python3
"""Profile test for a phase-common isotropic displacement parameter."""

from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


BASE = Path("analysis/advanced/02_CaCO3_texture_001.gpx")
OUT = Path("analysis/uiso_tests")


def rwp(project):
    hist = project.histogram(0)
    x, y, w, yc, yb, yd = hist.data["data"][1]
    lo, hi = np.searchsorted(x, hist.data["Limits"][1])
    hi = min(hi, len(x))
    return float(100 * np.sqrt(np.sum(w[lo:hi] * (y[lo:hi] - yc[lo:hi]) ** 2) /
                               np.sum(w[lo:hi] * y[lo:hi] ** 2)))


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for name in ["WO3", "CaWO4"]:
        for uiso in [0.0, 0.003, 0.007, 0.012, 0.020]:
            tag = f"{name}_{uiso:.3f}"
            project = G2.G2Project(gpxfile=str(BASE))
            project.save(str(OUT / f"{tag}.gpx"))
            hist = project.histogram(0)
            for phase in project.phases():
                for atom in phase.atoms():
                    atom.refinement_flags = ""
                phase.data["Histograms"][hist.name]["Pref.Ori."][2] = False
                phase.data["Histograms"][hist.name]["Mustrain"][2] = [False, False, False]
            phase = project.phase(name)
            cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
            for atom in phase.atoms():
                atom.data[cia] = "I"
                atom.data[cia + 1] = uiso
            project.set_Frozen()
            project.set_Controls("cycles", 6)
            project.refine()
            project.save()
            row = {"phase": name, "uiso_A2": uiso, "rwp": rwp(project)}
            rows.append(row)
            print(row, flush=True)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
