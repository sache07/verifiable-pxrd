#!/usr/bin/env python3
"""Test a small, replay-stable profile refinement from the stable model."""

from __future__ import annotations

import argparse
import contextlib
import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--name", required=True)
parser.add_argument(
    "--mode",
    choices=["uw", "xshl", "allinst", "strain", "size", "phaseprof", "geometry", "polarization"],
    required=True,
)
args = parser.parse_args()
out = ROOT / "analysis" / "profiles" / f"{args.name}.gpx"
out.parent.mkdir(parents=True, exist_ok=True)
project = G2sc.G2Project(
    str(ROOT / "analysis" / "stable" / "mono_stable.gpx"), newgpx=str(out)
)
hist = project.histogram(0)
project.set_Controls("cycles", 7)
project.data["Controls"]["data"]["parmMinDict"] = {}
project.data["Controls"]["data"]["parmMaxDict"] = {}
project.data["Controls"]["data"]["parmFrozen"] = {}

if args.mode == "uw":
    hist.set_refinements({"Instrument Parameters": ["U", "W"]})
elif args.mode == "xshl":
    hist.set_refinements({"Instrument Parameters": ["X", "SH/L"]})
elif args.mode == "allinst":
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
elif args.mode == "geometry":
    hist.set_refinements({"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]})
elif args.mode == "polarization":
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
elif args.mode in ("strain", "size", "phaseprof"):
    for phase in project.phases():
        refs = {}
        if args.mode in ("strain", "phaseprof"):
            refs["Mustrain"] = {"type": "isotropic", "refine": True}
        if args.mode in ("size", "phaseprof"):
            refs["Size"] = {"type": "isotropic", "refine": True}
        phase.set_HAP_refinements(refs, [hist])

with open(os.devnull, "w") as sink, contextlib.redirect_stdout(sink):
    project.refine(makeBack=False)
project.save()
result = {
    "name": args.name,
    "mode": args.mode,
    "residuals": dict(hist.residuals),
    "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
    "instrument": {k: v[1] for k, v in hist.data["Instrument Parameters"][0].items()},
    "sample": hist.data["Sample Parameters"],
    "profiles": {
        phase.name: {
            key: phase.getHAPvalues(hist)[key] for key in ("Size", "Mustrain")
        }
        for phase in project.phases()
    },
}
with out.with_suffix(".json").open("w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, default=lambda value: value.tolist())
    stream.write("\n")
print(args.name, result["residuals"].get("wR"), result["fractions"])
print("instrument", result["instrument"])
print("profiles", result["profiles"])
