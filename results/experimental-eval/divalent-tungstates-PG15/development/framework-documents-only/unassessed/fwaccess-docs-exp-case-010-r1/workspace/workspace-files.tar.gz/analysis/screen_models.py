#!/usr/bin/env python3
"""Screen chemically plausible COD models by staged GSAS-II refinements.

This is an exploratory model-selection script.  It keeps each project so that
poor fits can be inspected instead of selecting only on a scalar residual.
"""

from __future__ import annotations

import argparse
import contextlib
import json
import os
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = ROOT / "analysis" / "screen"


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


MODELS = {
    # tungsten oxides
    "wo3_old": "1010618",
    "wo3_mono": "1528915",
    "wo3_loopstra": "2311041",
    "wo3_triclinic": "2106293",
    "wo3_ortho": "2107312",
    "w10o29": "1538317",
    "w18o49": "1538315",
    # manganese oxides and tungstates
    "mn2o3_pbca": "1514103",
    "mn2o3_ia3": "1514230",
    "mn2o3_i213": "1010586",
    "mn3o4": "9001963",
    "mno": "1514108",
    "mnwo4": "1520200",
    "mn3wo6": "2002703",
}


DEFAULT_CASES = {
    "wo3_old": ["wo3_old"],
    "wo3_mono": ["wo3_mono"],
    "wo3_loopstra": ["wo3_loopstra"],
    "wo3_triclinic": ["wo3_triclinic"],
    "wo3_ortho": ["wo3_ortho"],
    "w10o29": ["w10o29"],
    "w18o49": ["w18o49"],
}


def background_coefficients(hist, degree: int = 15) -> list[float]:
    x = np.asarray(hist.data["data"][1][0], dtype=float)
    y = np.asarray(hist.data["data"][1][1], dtype=float)
    baseline = percentile_filter(y, percentile=12, size=401, mode="nearest")
    xn = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    return np.polynomial.chebyshev.chebfit(xn, baseline, degree - 1).tolist()


def quiet_refine(project: G2sc.G2Project) -> None:
    with open(os.devnull, "w") as sink, contextlib.redirect_stdout(sink):
        project.refine(makeBack=False)


def run_case(name: str, model_names: list[str]) -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    gpx_path = OUT / f"{name}.gpx"
    project = G2sc.G2Project(newgpx=str(gpx_path))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "analysis" / "cu_ka.instprm"),
        fmthint="comma",
    )
    phases = []
    for model_name in model_names:
        phase = project.add_phase(
            str(cod_path(MODELS[model_name])),
            phasename=model_name,
            histograms=[hist],
            fmthint="CIF",
        )
        phases.append(phase)

    project.set_Controls("cycles", 7)
    # Broad physical limits prevent cell/zero/displacement correlations from
    # producing numerically attractive but impossible geometry.
    for control, value, variable in [
        ("parmMin", -0.25, ":0:Zero"),
        ("parmMax", 0.25, ":0:Zero"),
        ("parmMin", -800.0, ":0:Shift"),
        ("parmMax", 800.0, ":0:Shift"),
        ("parmMin", 0.0, ":0:U"),
        ("parmMax", 40.0, ":0:U"),
        ("parmMin", 0.0, ":0:W"),
        ("parmMax", 40.0, ":0:W"),
        ("parmMin", 0.10, ":0:X"),
        ("parmMax", 6.0, ":0:X"),
        ("parmMin", 0.005, ":0:SH/L"),
        ("parmMax", 0.10, ":0:SH/L"),
    ]:
        project.set_Controls(control, value, variable)
    # Use HAP scales for phase quantities and hold the redundant histogram scale.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    for phase in phases:
        for control, value, variable in [
            ("parmMin", 0.0, f"{phase.id}:0:Scale"),
            ("parmMin", 0.03, f"{phase.id}:0:Size;i"),
            ("parmMax", 2.0, f"{phase.id}:0:Size;i"),
            ("parmMin", 100.0, f"{phase.id}:0:Mustrain;i"),
            ("parmMax", 12000.0, f"{phase.id}:0:Mustrain;i"),
        ]:
            project.set_Controls(control, value, variable)
        phase.HAPvalue("Scale", 1.0, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phase.setSampleProfile(hist, "size", "isotropic", 0.5, LGmix=1.0)
        phase.setSampleProfile(hist, "micro", "isotropic", 2000.0, LGmix=1.0)

    coeffs = background_coefficients(hist, degree=15)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": len(coeffs),
                "coeffs": coeffs,
            }
        }
    )

    stages = []
    try:
        quiet_refine(project)
        stages.append(("scale_background", dict(hist.residuals)))

        for phase in phases:
            phase.set_refinements({"Cell": True})
        hist.set_refinements(
            {
                "Sample Parameters": ["Shift"],
                "Instrument Parameters": ["Zero"],
            }
        )
        quiet_refine(project)
        stages.append(("cell_position", dict(hist.residuals)))

        hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        quiet_refine(project)
        stages.append(("instrument_profile", dict(hist.residuals)))

        for phase in phases:
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                },
                [hist],
            )
        quiet_refine(project)
        stages.append(("sample_profile", dict(hist.residuals)))
        project.save()
        fractions = hist.ComputeMassFracs() if len(phases) > 1 else {phases[0].name: (1.0, 0.0)}
        status = "ok"
        error = None
    except Exception as exc:  # retain the partially refined project for diagnosis
        project.save()
        fractions = {}
        status = "error"
        error = f"{type(exc).__name__}: {exc}"

    result = {
        "name": name,
        "models": [MODELS[m] for m in model_names],
        "model_names": model_names,
        "status": status,
        "error": error,
        "residuals": dict(hist.residuals),
        "stages": stages,
        "fractions": {k: list(v) for k, v in fractions.items()},
        "instrument": {k: v[1] for k, v in hist.data["Instrument Parameters"][0].items()},
        "sample": {
            k: v[0]
            for k, v in hist.data["Sample Parameters"].items()
            if isinstance(v, list) and len(v) == 2
        },
        "phases": {},
        "gpx": str(gpx_path.relative_to(ROOT)),
    }
    for phase in phases:
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "mass": phase.data["General"]["Mass"],
            "scale": phase.HAPvalue("Scale", targethistlist=[hist]),
            "hap": phase.getHAPvalues(hist),
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cases", nargs="*", help="case names from the built-in case table")
    args = parser.parse_args()
    cases = dict(DEFAULT_CASES)
    # Compact syntax permits an ad hoc combination: wo3_triclinic+mn2o3_pbca
    requested = args.cases or list(cases)
    results = []
    for case_name in requested:
        model_names = cases.get(case_name, case_name.split("+"))
        unknown = [m for m in model_names if m not in MODELS]
        if unknown:
            raise SystemExit(f"Unknown model name(s): {', '.join(unknown)}")
        result = run_case(case_name.replace("+", "__"), model_names)
        results.append(result)
        r = result["residuals"]
        print(
            f"{case_name:36s} {result['status']:5s} "
            f"Rwp={r.get('wR', float('nan')):9.4f} "
            f"Rexp={r.get('wRmin', float('nan')):9.4f} "
            f"fractions={result['fractions']}"
        )
        with (OUT / f"{result['name']}.json").open("w", encoding="utf-8") as stream:
            json.dump(result, stream, indent=2, default=lambda value: value.tolist())
            stream.write("\n")
    summary = OUT / ("summary_" + "__".join(c.replace("+", "_") for c in requested) + ".json")
    with summary.open("w", encoding="utf-8") as stream:
        json.dump(results, stream, indent=2, default=lambda value: value.tolist())
        stream.write("\n")


if __name__ == "__main__":
    main()
