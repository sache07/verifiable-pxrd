#!/usr/bin/env python3
"""Test triclinic WO3 as an incremental competitor to monoclinic WO3."""

import contextlib
import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
project = G2sc.G2Project(
    str(ROOT / "analysis" / "incremental_pbca.gpx"),
    newgpx=str(ROOT / "analysis" / "test_triclinic_add.gpx"),
)
hist = project.histogram(0)
mono, mn = project.phases()
tri = project.add_phase(
    str(COD / "2" / "10" / "62" / "2106293.cif"),
    phasename="wo3_triclinic",
    histograms=[hist],
    fmthint="CIF",
)
project.set_Controls("cycles", 7)
project.data["Controls"]["data"]["parmFrozen"] = {}


def refine():
    with open(os.devnull, "w") as sink, contextlib.redirect_stdout(sink):
        project.refine(makeBack=False)


# Freeze the established model and introduce only the new scale.
hist.clear_refinements(
    {
        "Background": True,
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    }
)
for phase in (mono, mn):
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True}, [hist])
tri.HAPvalue("Scale", 1.0, [hist])
tri.setSampleProfile(hist, "size", "isotropic", 0.5, LGmix=1.0)
tri.setSampleProfile(hist, "micro", "isotropic", 2000.0, LGmix=1.0)
tri.set_HAP_refinements({"Scale": True}, [hist])
refine()
stages = [("tri_scale", dict(hist.residuals), hist.ComputeMassFracs())]

# Let the triclinic cell find the unmatched peak positions.
tri.set_refinements({"Cell": True})
tri.set_HAP_refinements(
    {
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    },
    [hist],
)
hist.set_refinements({"Background": True})
refine()
stages.append(("tri_cell_profile", dict(hist.residuals), hist.ComputeMassFracs()))

# Finally let all phase scales and cells compete.
for phase in (mono, mn):
    phase.set_refinements({"Cell": True})
    phase.set_HAP_refinements({"Scale": True}, [hist])
refine()
stages.append(("all_cells_scales", dict(hist.residuals), hist.ComputeMassFracs()))
project.save()

result = {
    "stages": [
        [name, residuals, {key: list(value) for key, value in fractions.items()}]
        for name, residuals, fractions in stages
    ],
    "cells": {phase.name: phase.get_cell() for phase in project.phases()},
}
with (ROOT / "analysis" / "test_triclinic_add.json").open("w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, default=lambda value: value.tolist())
    stream.write("\n")
for stage in result["stages"]:
    print(stage[0], "Rwp", stage[1].get("wR"), "fractions", stage[2])
