#!/usr/bin/env python3
"""Create a minimal GSAS-II project and print the initialized data layout."""

from pathlib import Path
from pprint import pprint

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
project = G2sc.G2Project(newgpx=str(ROOT / "analysis" / "inspect.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "analysis" / "cu_ka.instprm"),
    fmthint="comma",
)
print("histogram", hist.name)
print("limits")
pprint(hist.data["Limits"])
print("instrument")
pprint(hist.data["Instrument Parameters"])
print("sample")
pprint(hist.data["Sample Parameters"])
print("background")
pprint(hist.data["Background"])
print("residuals")
pprint(hist.residuals)
project.save()
