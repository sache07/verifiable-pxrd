#!/usr/bin/env python3
"""Add a minority phase to a converged GSAS-II model without losing its fit."""

from __future__ import annotations

import contextlib
import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
BASE = ROOT / "analysis" / "screen" / "wo3_loopstra.gpx"
OUT = ROOT / "analysis" / "incremental_pbca.gpx"
MN_CIF = COD / "1" / "51" / "41" / "1514103.cif"


def refine(project):
    with open(os.devnull, "w") as sink, contextlib.redirect_stdout(sink):
        project.refine(makeBack=False)


project = G2sc.G2Project(str(BASE), newgpx=str(OUT))
hist = project.histogram(0)
wo3 = project.phase(0)
mn = project.add_phase(
    str(MN_CIF), phasename="mn2o3_pbca", histograms=[hist], fmthint="CIF"
)
project.set_Controls("cycles", 7)
project.data["Controls"]["data"]["parmFrozen"] = {}

# Freeze the converged parent model while the new scale is introduced.
hist.clear_refinements(
    {
        "Background": True,
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    }
)
wo3.clear_refinements({"Cell": True})
wo3.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True}, [hist])
mn.HAPvalue("Scale", 4.0, [hist])
mn.setSampleProfile(hist, "size", "isotropic", 0.5, LGmix=1.0)
mn.setSampleProfile(hist, "micro", "isotropic", 2000.0, LGmix=1.0)
mn.set_HAP_refinements({"Scale": True}, [hist])
refine(project)
stages = [("minority_scale", dict(hist.residuals), hist.ComputeMassFracs())]

# Re-equilibrate scales and smooth background, retaining the established positions.
wo3.set_HAP_refinements({"Scale": True}, [hist])
hist.set_refinements({"Background": True})
refine(project)
stages.append(("both_scales_background", dict(hist.residuals), hist.ComputeMassFracs()))

# Refine both cells and phase-specific broadening after the minority reflections
# have a stable nonzero scale.
for phase in (wo3, mn):
    phase.set_refinements({"Cell": True})
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [hist],
    )
refine(project)
stages.append(("cells_phase_profiles", dict(hist.residuals), hist.ComputeMassFracs()))

project.save()
result = {
    "stages": [
        [name, residuals, {key: list(value) for key, value in fractions.items()}]
        for name, residuals, fractions in stages
    ],
    "cells": {phase.name: phase.get_cell() for phase in (wo3, mn)},
    "scales": {phase.name: phase.HAPvalue("Scale", targethistlist=[hist]) for phase in (wo3, mn)},
}
with (ROOT / "analysis" / "incremental_pbca.json").open("w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, default=lambda value: value.tolist())
    stream.write("\n")
for stage in result["stages"]:
    print(stage[0], "Rwp", stage[1].get("wR"), "fractions", stage[2])
