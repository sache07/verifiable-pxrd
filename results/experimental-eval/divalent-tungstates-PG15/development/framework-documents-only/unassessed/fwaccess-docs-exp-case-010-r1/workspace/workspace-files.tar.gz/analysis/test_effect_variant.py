#!/usr/bin/env python3
"""Refine one specimen-effect variant from a common GSAS-II project."""

from __future__ import annotations

import argparse
import contextlib
import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


parser = argparse.ArgumentParser()
parser.add_argument("--base", default="analysis/triclinic_target.gpx")
parser.add_argument("--name", required=True)
parser.add_argument("--mode", choices=["po", "rough", "uniaxial"], required=True)
parser.add_argument("--phase", type=int, default=0)
parser.add_argument("--axis", default="0,0,1")
args = parser.parse_args()
axis = [int(x) for x in args.axis.split(",")]
out = ROOT / "analysis" / "effects" / f"{args.name}.gpx"
out.parent.mkdir(parents=True, exist_ok=True)
project = G2sc.G2Project(str(ROOT / args.base), newgpx=str(out))
hist = project.histogram(0)
project.set_Controls("cycles", 5)
project.data["Controls"]["data"]["parmFrozen"] = {}

# Hold the established profile; only scales/background and the tested effect vary.
hist.clear_refinements(
    {
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    }
)
hist.set_refinements({"Background": True})
for phase in project.phases():
    phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
    phase.clear_HAP_refinements(
        {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist]
    )
    phase.set_HAP_refinements({"Scale": True}, [hist])

target = project.phase(args.phase)
if args.mode == "po":
    po = target.getHAPvalues(hist)["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = axis
elif args.mode == "rough":
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.20, True]
    sample["SurfRoughB"] = [0.10, True]
elif args.mode == "uniaxial":
    current = target.getHAPvalues(hist)["Mustrain"][1][0]
    target.setSampleProfile(hist, "micro", "uniaxial", current, current, axis, LGmix=1.0)
    target.set_HAP_refinements(
        {"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}}, [hist]
    )

with open(os.devnull, "w") as sink, contextlib.redirect_stdout(sink):
    project.refine(makeBack=False)
project.save()
result = {
    "name": args.name,
    "mode": args.mode,
    "phase": args.phase,
    "axis": axis,
    "residuals": dict(hist.residuals),
    "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
    "effect": (
        hist.data["Sample Parameters"]
        if args.mode == "rough"
        else target.getHAPvalues(hist)["Pref.Ori." if args.mode == "po" else "Mustrain"]
    ),
}
with out.with_suffix(".json").open("w", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, default=lambda value: value.tolist())
    stream.write("\n")
print(args.name, result["residuals"].get("wR"), result["fractions"], result["effect"])
