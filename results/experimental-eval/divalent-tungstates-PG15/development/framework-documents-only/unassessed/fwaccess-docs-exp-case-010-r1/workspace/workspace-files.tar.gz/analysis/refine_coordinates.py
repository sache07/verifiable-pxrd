#!/usr/bin/env python3
"""Test symmetry-constrained coordinate refinements from the stable model."""

from __future__ import annotations

import argparse
import contextlib
import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "composite" / "composite_stable.gpx"
GROUPS = {
    "wo_w": {"monoclinic_WO3": ["W1", "W2"]},
    "wo_o": {"monoclinic_WO3": [f"O{i}" for i in range(1, 7)]},
    "wo_all": {"monoclinic_WO3": ["W1", "W2"] + [f"O{i}" for i in range(1, 7)]},
    "mn_mn": {"alpha_Mn2O3": ["Mn3", "Mn4", "Mn5"]},
    "mn_o": {"alpha_Mn2O3": [f"O{i}" for i in range(1, 7)]},
    "mn_all": {
        "alpha_Mn2O3": ["Mn3", "Mn4", "Mn5"] + [f"O{i}" for i in range(1, 7)]
    },
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("variant", choices=GROUPS)
    args = parser.parse_args()
    outdir = ROOT / "analysis" / "coordinates"
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(BASE), newgpx=str(outdir / f"{args.variant}.gpx"))
    hist = project.histogram(0)
    phases = {phase.name: phase for phase in project.phases()}
    controls = project.data["Controls"]["data"]
    project.set_Controls("cycles", 10)
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}

    for phase in phases.values():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
    for phase_name, labels in GROUPS[args.variant].items():
        phases[phase_name].set_refinements({"Atoms": {label: "X" for label in labels}})

    before = {
        phase.name: {atom.label: list(atom.coordinates) for atom in phase.atoms()}
        for phase in phases.values()
    }
    with open(os.devnull, "w") as sink, contextlib.redirect_stdout(sink):
        project.refine(makeBack=False)
    project.save()
    after = {
        phase.name: {atom.label: list(atom.coordinates) for atom in phase.atoms()}
        for phase in phases.values()
    }
    result = {
        "variant": args.variant,
        "residuals": dict(hist.residuals),
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "before": before,
        "after": after,
        "frozen": controls.get("parmFrozen", {}),
    }
    with (outdir / f"{args.variant}.json").open("w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(args.variant, hist.residuals.get("wR"), result["fractions"], result["frozen"])


if __name__ == "__main__":
    main()
