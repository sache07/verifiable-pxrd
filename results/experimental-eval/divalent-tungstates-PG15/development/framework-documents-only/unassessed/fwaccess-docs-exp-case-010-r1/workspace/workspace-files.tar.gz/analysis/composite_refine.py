#!/usr/bin/env python3
"""Combine independently supported profile effects into a stable final candidate."""

from __future__ import annotations

import contextlib
import json
import os
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
OUTDIR = ROOT / "analysis" / "composite"
OUTDIR.mkdir(parents=True, exist_ok=True)
project = G2sc.G2Project(
    str(ROOT / "analysis" / "effects" / "uni_w_100.gpx"),
    newgpx=str(OUTDIR / "work.gpx"),
)
hist = project.histogram(0)
wo3, mn = project.phases()
project.set_Controls("cycles", 7)
controls = project.data["Controls"]["data"]
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
controls["parmFrozen"] = {}

# Freeze all nonlinear terms, then insert values supported by independent
# one-effect refinements. Keep only phase scales and background active.
hist.clear_refinements(
    {
        "Instrument Parameters": ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    }
)
for phase in (wo3, mn):
    phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
    phase.clear_HAP_refinements(
        {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist]
    )
    phase.set_HAP_refinements({"Scale": True}, [hist])
hist.set_refinements({"Background": True})

inst = hist.data["Instrument Parameters"][0]
inst["Polariz."][1] = 0.82295
inst["X"][1] = 6.0923
inst["SH/L"][1] = 0.06057

# Retain the [100] uniaxial WO3 strain selected by the axis comparison.
wo_prof = wo3.getHAPvalues(hist)
wo_prof["Size"][1][0] = 0.3580
wo_prof["Mustrain"][0] = "uniaxial"
wo_prof["Mustrain"][1][0] = 2555.4
wo_prof["Mustrain"][1][1] = 9866.4
wo_prof["Mustrain"][2] = [False, False, False]
wo_prof["Mustrain"][3] = [1, 0, 0]
mn_prof = mn.getHAPvalues(hist)
mn_prof["Size"][1][0] = 0.5974
mn_prof["Mustrain"][0] = "isotropic"
mn_prof["Mustrain"][1][0] = 4615.0
mn_prof["Mustrain"][2] = [False, False, False]


def refine(name):
    controls["parmFrozen"] = {}
    with open(os.devnull, "w") as sink, contextlib.redirect_stdout(sink):
        project.refine(makeBack=False)
    project.save(str(OUTDIR / f"{name}.gpx"))
    return {
        "name": name,
        "residuals": dict(hist.residuals),
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "cells": {phase.name: phase.get_cell() for phase in (wo3, mn)},
    }


stages = [refine("composite_scales")]
for phase in (wo3, mn):
    phase.set_refinements({"Cell": True})
stages.append(refine("composite_cells"))
for phase in (wo3, mn):
    phase.clear_refinements({"Cell": True})
stages.append(refine("composite_stable"))

with (OUTDIR / "stages.json").open("w", encoding="utf-8") as stream:
    json.dump(stages, stream, indent=2, default=lambda value: value.tolist())
    stream.write("\n")
for stage in stages:
    print(stage["name"], stage["residuals"].get("wR"), stage["fractions"], stage["cells"])
