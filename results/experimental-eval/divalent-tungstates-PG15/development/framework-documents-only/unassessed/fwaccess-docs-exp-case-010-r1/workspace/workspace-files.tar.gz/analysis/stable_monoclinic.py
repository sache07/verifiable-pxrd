#!/usr/bin/env python3
"""Construct a replay-stable WO3 + alpha-Mn2O3 model without limit clipping."""

from __future__ import annotations

import contextlib
import json
import os
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUTDIR = ROOT / "analysis" / "stable"
OUTDIR.mkdir(parents=True, exist_ok=True)
project = G2sc.G2Project(newgpx=str(OUTDIR / "mono_work.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "analysis" / "cu_ka.instprm"),
    fmthint="comma",
)
wo3 = project.add_phase(
    str(COD / "2" / "31" / "10" / "2311041.cif"),
    phasename="monoclinic_WO3",
    histograms=[hist],
    fmthint="CIF",
)
mn = project.add_phase(
    str(COD / "1" / "51" / "41" / "1514103.cif"),
    phasename="alpha_Mn2O3",
    histograms=[hist],
    fmthint="CIF",
)
project.set_Controls("cycles", 7)


def set_cell(phase, cell):
    phase.data["General"]["Cell"][1:7] = list(cell)
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


# Peak-position fit derived independently from indexed strong reflections.
set_cell(wo3, [7.68717, 7.53559, 10.66553, 90.0, 136.82845, 90.0])
set_cell(mn, [9.39740, 9.42410, 9.40143, 90.0, 90.0, 90.0])

inst = hist.data["Instrument Parameters"][0]
for key, value in {
    "Zero": -0.1414,
    "Polariz.": 0.70,
    "U": 40.0,
    "V": 0.0,
    "W": 2.0,
    "X": 3.63,
    "Y": 0.0,
    "SH/L": 0.065,
}.items():
    inst[key][1] = value
sample = hist.data["Sample Parameters"]
sample["Scale"] = [1.0, False]
sample["Shift"] = [-800.0, False]

for atom in wo3.atoms():
    atom.uiso = 0.008
for phase, scale, size, strain in [
    (wo3, 16.1, 0.40, 2000.0),
    (mn, 4.7, 0.50, 4500.0),
]:
    phase.HAPvalue("Scale", scale, [hist])
    phase.setSampleProfile(hist, "size", "isotropic", size, LGmix=1.0)
    phase.setSampleProfile(hist, "micro", "isotropic", strain, LGmix=1.0)
    phase.set_HAP_refinements({"Scale": True}, [hist])

x = np.asarray(hist.data["data"][1][0], dtype=float)
y = np.asarray(hist.data["data"][1][1], dtype=float)
baseline = percentile_filter(y, percentile=12, size=401, mode="nearest")
xn = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
coeffs = np.polynomial.chebyshev.chebfit(xn, baseline, 14).tolist()
hist.set_refinements(
    {
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": len(coeffs),
            "coeffs": coeffs,
        }
    }
)


def refine(name):
    project.data["Controls"]["data"]["parmMinDict"] = {}
    project.data["Controls"]["data"]["parmMaxDict"] = {}
    project.data["Controls"]["data"]["parmFrozen"] = {}
    with open(os.devnull, "w") as sink, contextlib.redirect_stdout(sink):
        project.refine(makeBack=False)
    project.save(str(OUTDIR / f"{name}.gpx"))
    return {
        "name": name,
        "residuals": dict(hist.residuals),
        "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "cells": {phase.name: phase.get_cell() for phase in (wo3, mn)},
    }


stages = [refine("mono_scales")]
for phase in (wo3, mn):
    phase.set_refinements({"Cell": True})
stages.append(refine("mono_cells"))

# Freeze the determined cells and finish with a purely linear scale/background fit.
for phase in (wo3, mn):
    phase.clear_refinements({"Cell": True})
stages.append(refine("mono_stable"))

with (OUTDIR / "mono_stages.json").open("w", encoding="utf-8") as stream:
    json.dump(stages, stream, indent=2, default=lambda value: value.tolist())
    stream.write("\n")
for stage in stages:
    print(stage["name"], stage["residuals"].get("wR"), stage["fractions"], stage["cells"])
