#!/usr/bin/env python3
"""Purpose-built staged refinement for triclinic WO3 + alpha-Mn2O3."""

from __future__ import annotations

import contextlib
import json
import os
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = ROOT / "analysis" / "triclinic_target.gpx"


def refine(project):
    with open(os.devnull, "w") as sink, contextlib.redirect_stdout(sink):
        project.refine(makeBack=False)


project = G2sc.G2Project(newgpx=str(OUT))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "analysis" / "cu_ka.instprm"),
    fmthint="comma",
)
wo3 = project.add_phase(
    str(COD / "2" / "10" / "62" / "2106293.cif"),
    phasename="WO3_triclinic",
    histograms=[hist],
    fmthint="CIF",
)
mn = project.add_phase(
    str(COD / "1" / "51" / "41" / "1514103.cif"),
    phasename="alpha_Mn2O3",
    histograms=[hist],
    fmthint="CIF",
)
project.set_Controls("cycles", 5)

# Initial geometry is chosen to put the unperturbed reference peaks on the
# observed cluster before any cell parameters are released.
inst = hist.data["Instrument Parameters"][0]
inst["Zero"][1] = -0.10
inst["U"][1] = 15.0
inst["W"][1] = 15.0
inst["X"][1] = 1.5
inst["SH/L"][1] = 0.03
sample = hist.data["Sample Parameters"]
sample["Scale"] = [1.0, False]
sample["Shift"][0] = -800.0

for phase, scale, size, strain in [
    (wo3, 16.0, 0.4, 2500.0),
    (mn, 4.5, 0.5, 4500.0),
]:
    phase.HAPvalue("Scale", scale, [hist])
    phase.setSampleProfile(hist, "size", "isotropic", size, LGmix=1.0)
    phase.setSampleProfile(hist, "micro", "isotropic", strain, LGmix=1.0)
    phase.set_HAP_refinements({"Scale": True}, [hist])

# Initialize the smooth baseline with a robust local percentile estimate.
x = np.asarray(hist.data["data"][1][0], dtype=float)
y = np.asarray(hist.data["data"][1][1], dtype=float)
baseline = percentile_filter(y, percentile=12, size=401, mode="nearest")
xn = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
coeffs = np.polynomial.chebyshev.chebfit(xn, baseline, 14).tolist()
hist.set_refinements(
    {
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": len(coeffs),
            "coeffs": coeffs,
        }
    }
)

# Bounds reflect the broad but finite physically generated laboratory setup.
limits = [
    ("parmMin", -0.25, ":0:Zero"),
    ("parmMax", 0.25, ":0:Zero"),
    ("parmMin", -800.0, ":0:Shift"),
    ("parmMax", 800.0, ":0:Shift"),
    ("parmMin", 0.0, ":0:U"),
    ("parmMax", 40.0, ":0:U"),
    ("parmMin", 0.0, ":0:W"),
    ("parmMax", 40.0, ":0:W"),
    ("parmMin", 0.1, ":0:X"),
    ("parmMax", 6.0, ":0:X"),
    ("parmMin", 0.005, ":0:SH/L"),
    ("parmMax", 0.10, ":0:SH/L"),
]
for phase in (wo3, mn):
    limits.extend(
        [
            ("parmMin", 0.0, f"{phase.id}:0:Scale"),
            ("parmMin", 0.04, f"{phase.id}:0:Size;i"),
            ("parmMax", 1.5, f"{phase.id}:0:Size;i"),
            ("parmMin", 100.0, f"{phase.id}:0:Mustrain;i"),
            ("parmMax", 9000.0, f"{phase.id}:0:Mustrain;i"),
        ]
    )
for control, value, variable in limits:
    project.set_Controls(control, value, variable)

stages = []


def record(name):
    stages.append(
        {
            "name": name,
            "residuals": dict(hist.residuals),
            "fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
            "cells": {phase.name: phase.get_cell() for phase in (wo3, mn)},
        }
    )


# 1: establish intensities with peaks already near their measured locations.
refine(project)
record("scales_background")

# 2: fit lattice metrics while geometry stays anchored.
for phase in (wo3, mn):
    phase.set_refinements({"Cell": True})
refine(project)
record("cells")

# 3: separate common zero/displacement effects from cell metrics.
for phase in (wo3, mn):
    phase.clear_refinements({"Cell": True})
hist.set_refinements(
    {"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]}
)
project.data["Controls"]["data"]["parmFrozen"] = {}
refine(project)
record("geometry")

# 4: re-optimize cells at the fitted common geometry.
for phase in (wo3, mn):
    phase.set_refinements({"Cell": True})
refine(project)
record("cells_geometry")

# 5: common instrumental contribution.
hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
project.data["Controls"]["data"]["parmFrozen"] = {}
refine(project)
record("instrument_profile")

# 6: phase-specific size/strain contribution.
for phase in (wo3, mn):
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [hist],
    )
project.data["Controls"]["data"]["parmFrozen"] = {}
refine(project)
record("phase_profiles")

project.save()
with (ROOT / "analysis" / "triclinic_target.json").open("w", encoding="utf-8") as stream:
    json.dump(stages, stream, indent=2, default=lambda value: value.tolist())
    stream.write("\n")
for stage in stages:
    print(stage["name"], "Rwp", stage["residuals"].get("wR"), stage["fractions"])
