#!/usr/bin/env python3
"""Run comparable exploratory GSAS-II refinements for candidate WO3 models."""

from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_inputs() -> tuple[Path, Path, np.ndarray, np.ndarray]:
    work = ROOT / ".tmp"
    work.mkdir(exist_ok=True)
    xye = work / "pattern.xye"
    inst = work / "lab.instprm"
    rows = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    x = np.asarray(rows["two_theta_deg"], dtype=float)
    y = np.asarray(rows["intensity"], dtype=float)
    # Raw counts have Poisson counting uncertainty. No pointwise uncertainties
    # were supplied, so use sqrt(counts), as required for count-statistical Rwp.
    np.savetxt(xye, np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]), fmt="%.8f %.8f %.8f")
    inst.write_text(
        "#GSAS-II instrument parameter file for Bragg-Brentano lab Cu Ka data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.280;Polariz.:0.80;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:10.0;V:0.0;W:25.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.020\n"
    )
    return xye, inst, x, y


def report(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"SUMMARY {label}: Rwp={hist.get_wR()}")
    try:
        print("  mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("  mass fraction error", repr(exc))
    inst = hist.data["Instrument Parameters"][0]
    print("  instrument", {k: inst[k][1:] for k in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"]})
    print("  sample", {k: hist.data["Sample Parameters"].get(k) for k in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"]})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("  phase", phase.name, "cell", phase.get_cell(), "scale", hap["Scale"], "size", hap["Size"], "mustrain", hap["Mustrain"])


def refine(project: G2sc.G2Project, label: str) -> None:
    project.refine(makeBack=False)
    report(project, label)


def run(wo3_id: str, output: Path, cycles: int = 8) -> None:
    xye, instfile, x, y = prepare_inputs()
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(str(xye), str(instfile), fmthint="Topas xye")
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    # Do not refine the redundant histogram scale when all phase scales are
    # refined; otherwise GSAS-II reports the expected scale singularity.
    hist.data["Sample Parameters"]["Scale"][1] = False

    # Seed a smooth background from a lower-envelope estimate, then fit that
    # estimate with the same shifted-Chebyshev basis used in the refinement.
    low = percentile_filter(y, percentile=12, size=301, mode="nearest")
    baseline = gaussian_filter1d(low, 70)
    fixed = list(zip(x[::80], baseline[::80]))
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 18,
            "FixedPoints": fixed,
            "fit fixed points": True,
            "refine": True,
        }
    })

    sources = [
        (wo3_id, "WO3"),
        ("7219229", "CaWO4"),
        ("1547347", "CaCO3_calcite"),
    ]
    phases = []
    for source_id, name in sources:
        phase = project.add_phase(str(cod_path(source_id)), phasename=name, histograms=[hist], fmthint="CIF")
        phases.append(phase)

    # Keep initial widths broad enough for the offset peaks to overlap, while
    # using physically plausible phase-specific domain sizes.
    size0 = {"WO3": 0.35, "CaWO4": 0.10, "CaCO3_calcite": 0.50}
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size0[phase.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements({"Scale": True})

    project.set_Controls("cycles", cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.save()
    for variable, low, high in [
        (":0:U", 0.0, 200.0),
        (":0:W", 0.1, 200.0),
        (":0:X", 0.01, 20.0),
        (":0:SH/L", 0.001, 0.2),
    ]:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    for phase in phases:
        project.set_Controls("parmMin", 0.005, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, variable=f"{phase.id}:0:Mustrain;i")

    # Scale/background first, then lattice/position, then line profile.
    refine(project, "scale+bkg")
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "zero")

    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": size0[phase.name], "refine": True}})
    refine(project, "phase size")

    # The documented synthetic instrument varies U, W, X and SH/L; V and Y
    # are fixed at zero. Keeping that parameterization also avoids width
    # degeneracies with phase size/strain.
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(project, "instrument W+X")

    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, "phase strain")

    hist.set_refinements({"Instrument Parameters": ["U", "SH/L"]})
    refine(project, "instrument U+asymmetry")
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()
    output = args.output or ROOT / ".tmp" / f"trial_{args.wo3_id}.gpx"
    run(args.wo3_id, output, args.cycles)


if __name__ == "__main__":
    main()
