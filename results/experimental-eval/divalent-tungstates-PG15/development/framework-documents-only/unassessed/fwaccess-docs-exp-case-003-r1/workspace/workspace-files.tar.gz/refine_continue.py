#!/usr/bin/env python3
"""Targeted continuation refinements for the selected three-phase model."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def summary(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"RESULT {label} Rwp={hist.get_wR():.8f} mass={hist.ComputeMassFracs()}")
    inst = hist.data["Instrument Parameters"][0]
    print("INSTRUMENT", {k: inst[k][1] for k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]})
    print("SAMPLE", {k: hist.data["Sample Parameters"][k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("PHASE", phase.id, phase.name, "cell", phase.get_cell(), "PO", hap["Pref.Ori."], "size", hap["Size"], "strain", hap["Mustrain"])
        print("ATOMS", [(a.label, a.coordinates, a.ADP, a.refinement_flags) for a in phase.atoms()])


def do_refine(project: G2sc.G2Project, label: str) -> None:
    project.refine(makeBack=False)
    summary(project, label)


def fresh_project(source: Path, output: Path, cycles: int) -> G2sc.G2Project:
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(gpxfile=str(source), newgpx=str(output))
    project.set_Controls("cycles", cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.set_Frozen()
    hist = project.histogram(0)
    # The exploratory project drove U and X to their lower limits because
    # they are almost exactly correlated with phase strain and size. Keep the
    # physically valid boundary values fixed in continuation refinements.
    hist.data["Instrument Parameters"][0]["U"][2] = False
    hist.data["Instrument Parameters"][0]["X"][2] = False
    project.save()
    return project


def make_isotropic(atom, value: float) -> None:
    """Convert an anisotropic atom record to isotropic in the GSAS-II tree."""
    if atom.adp_flag == "A":
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = float(value)
        atom.data[atom.cia + 2 : atom.cia + 8] = [0.0] * 6
    else:
        atom.uiso = value


def atomic_refinement(source: Path, output: Path, cycles: int) -> None:
    project = fresh_project(source, output, cycles)
    # Use one common Uiso per phase, matching the specimen model, and refine
    # that common value before adjusting coordinates.
    for phase in project.phases():
        atoms = phase.atoms()
        for atom in atoms:
            make_isotropic(atom, 0.010)
            atom.refinement_flags = "U"
        if len(atoms) > 1:
            project.add_EquivConstr([f"{phase.id}::AUiso:{i}" for i in range(len(atoms))])
        for i in range(len(atoms)):
            project.set_Controls("parmMin", 0.0005, variable=f"{phase.id}::AUiso:{i}")
            project.set_Controls("parmMax", 0.08, variable=f"{phase.id}::AUiso:{i}")
    project.save()
    do_refine(project, "common Uiso")

    wo3, cawo4, calcite = project.phases()
    for atom in wo3.atoms():
        atom.refinement_flags = "XU" if atom.element == "W" else "U"
    # CaWO4 is a broad, minor phase. Its oxygen coordinates are not supported
    # independently by this pattern; unconstrained refinement lengthens W-O by
    # ~0.2 A and is therefore rejected as an overfit. Keep the published
    # scheelite geometry and refine only the well-determined WO3 W positions
    # plus the single calcite carbonate coordinate.
    calcite.atom("O1").refinement_flags = "XU"
    do_refine(project, "supported coordinates")
    project.save()


def po_scan(source: Path, output_dir: Path, cycles: int, phase_index: int) -> None:
    output_dir.mkdir(exist_ok=True)
    axes = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]
    for axis in axes:
        tag = "".join(str(i) for i in axis)
        out = output_dir / f"po_p{phase_index}_{tag}.gpx"
        project = fresh_project(source, out, cycles)
        phase = project.phase(phase_index)
        hist = project.histogram(0)
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", 1.0, True, list(axis)
        project.set_Controls("parmMin", 0.3, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 3.0, variable=f"{phase.id}:0:MD")
        do_refine(project, f"PO phase={phase.name} axis={axis}")
        project.save()


def strain_scan(source: Path, output_dir: Path, cycles: int, phase_index: int) -> None:
    output_dir.mkdir(exist_ok=True)
    axes = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]
    for axis in axes:
        tag = "".join(str(i) for i in axis)
        out = output_dir / f"strain_p{phase_index}_{tag}.gpx"
        project = fresh_project(source, out, cycles)
        phase = project.phase(phase_index)
        hist = project.histogram(0)
        m = phase.data["Histograms"][hist.name]["Mustrain"]
        m[1][1] = m[1][0]
        phase.set_HAP_refinements({
            "Mustrain": {
                "type": "uniaxial",
                "direction": list(axis),
                "refine": True,
            }
        })
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;a")
        project.set_Controls("parmMax", 30000.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 30000.0, variable=f"{phase.id}:0:Mustrain;a")
        do_refine(project, f"strain phase={phase.name} axis={axis}")
        project.save()


def combined_refinement(source: Path, output: Path, cycles: int) -> None:
    project = fresh_project(source, output, cycles)
    hist = project.histogram(0)
    wo3, cawo4, calcite = project.phases()

    # Parameters at an effectively infinite domain-size boundary or zero
    # strain are fixed instead of being carried as singular variables.
    calcite_hap = calcite.data["Histograms"][hist.name]
    calcite_hap["Size"][1][0] = 10.0
    calcite_hap["Size"][2][0] = False
    cawo4_hap = cawo4.data["Histograms"][hist.name]
    cawo4_hap["Mustrain"][1][0] = 0.0
    cawo4_hap["Mustrain"][2][0] = False

    # Axis scans support uniaxial broadening for WO3. The other candidate
    # axes give clearly worse fits; retain isotropic broadening elsewhere.
    wo3_hap = wo3.data["Histograms"][hist.name]
    wo3_hap["Mustrain"][1][0] = 6900.0
    wo3_hap["Mustrain"][1][1] = 3100.0
    wo3.set_HAP_refinements({
        "Mustrain": {"type": "uniaxial", "direction": [1, 1, 0], "refine": True}
    })
    for suffix in ["i", "a"]:
        project.set_Controls("parmMin", 0.0, variable=f"{wo3.id}:0:Mustrain;{suffix}")
        project.set_Controls("parmMax", 30000.0, variable=f"{wo3.id}:0:Mustrain;{suffix}")

    # Weak but reproducible March-Dollase terms are supported for the two Ca
    # phases. Both axes are among those used by the documented specimen model.
    for phase, axis, start in [
        (cawo4, [1, 1, 1], 1.12),
        (calcite, [1, 1, 1], 1.18),
    ]:
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", start, True, axis
        project.set_Controls("parmMin", 0.3, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 3.0, variable=f"{phase.id}:0:MD")
    do_refine(project, "combined specimen broadening+texture")

    # Separate the constant zero term from the cos(theta) specimen-height
    # shift and determine polarization from the full angular intensity trend.
    sample = hist.data["Sample Parameters"]
    sample["Shift"] = [0.0, True]
    project.set_Controls("parmMin", -1200.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1200.0, variable=":0:Shift")
    inst = hist.data["Instrument Parameters"][0]
    inst["Polariz."][2] = True
    project.set_Controls("parmMin", 0.3, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    do_refine(project, "specimen height+polarization")

    # Test the documented Suortti surface-roughness correction. If absent,
    # refinement naturally approaches its no-correction limit.
    sample["SurfRoughA"] = [0.30, True]
    sample["SurfRoughB"] = [0.10, True]
    project.set_Controls("parmMin", 0.001, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.0001, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 2.0, variable=":0:SurfRoughB")
    do_refine(project, "surface roughness")
    project.save()


def physical_bounds_refinement(source: Path, output: Path, cycles: int) -> None:
    """Reallocate correlated profile terms within the documented physical model."""
    project = fresh_project(source, output, cycles)
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    # The generating laboratory model uses finite nonnegative instrumental
    # broadening and phase domain sizes. Move boundary solutions back into
    # that physically meaningful parameterization before re-refining.
    inst["U"][1], inst["U"][2] = max(0.0, inst["U"][1]), True
    inst["X"][1], inst["X"][2] = max(0.10, inst["X"][1]), True
    for name, lo, hi in [("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.10, 6.0)]:
        project.set_Controls("parmMin", lo, variable=f":0:{name}")
        project.set_Controls("parmMax", hi, variable=f":0:{name}")

    sample["SurfRoughA"][0] = max(0.05, sample["SurfRoughA"][0])
    sample["SurfRoughB"][0] = max(0.02, sample["SurfRoughB"][0])
    for name, lo, hi in [("SurfRoughA", 0.05, 0.60), ("SurfRoughB", 0.02, 0.50)]:
        sample[name][1] = True
        project.set_Controls("parmMin", lo, variable=f":0:{name}")
        project.set_Controls("parmMax", hi, variable=f":0:{name}")

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][1][0] = min(1.5, max(0.04, hap["Size"][1][0]))
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:0:Size;i")
        for i, atom in enumerate(phase.atoms()):
            if atom.adp_flag == "I":
                atom.uiso = min(0.020, max(0.003, atom.uiso))
                project.set_Controls("parmMin", 0.003, variable=f"{phase.id}::AUiso:{i}")
                project.set_Controls("parmMax", 0.020, variable=f"{phase.id}::AUiso:{i}")
    project.save()
    do_refine(project, "documented physical bounds")
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["atomic", "po", "strain", "combined", "physical"])
    parser.add_argument("--source", type=Path, default=ROOT / ".tmp" / "trial_2311041.gpx")
    parser.add_argument("--output", type=Path, default=ROOT / ".tmp" / "atomic.gpx")
    parser.add_argument("--cycles", type=int, default=6)
    parser.add_argument("--phase", type=int, default=0)
    args = parser.parse_args()
    if args.mode == "atomic":
        atomic_refinement(args.source, args.output, args.cycles)
    elif args.mode == "po":
        po_scan(args.source, args.output, args.cycles, args.phase)
    elif args.mode == "strain":
        strain_scan(args.source, args.output, args.cycles, args.phase)
    elif args.mode == "combined":
        combined_refinement(args.source, args.output, args.cycles)
    else:
        physical_bounds_refinement(args.source, args.output, args.cycles)


if __name__ == "__main__":
    main()
