#!/usr/bin/env python3
"""Explore physically separated instrument and specimen broadening terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def summary(gpx: G2sc.G2Project, stage: str) -> None:
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    out = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "instrument": {
            k: inst[k][1]
            for k in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]
        },
        "sample": {
            k: hist.data["Sample Parameters"].get(k)
            for k in ["Shift", "SurfRoughA", "SurfRoughB"]
        },
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "texture": hap["Pref.Ori."],
            "cell": phase.get_cell(),
        }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    print("PROFILE_RESULT " + json.dumps(out, default=str, sort_keys=True))


def run(gpx: G2sc.G2Project, stage: str) -> None:
    gpx.refine(makeBack=False)
    gpx.save()
    summary(gpx, stage)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(gpxfile=str(args.base), newgpx=str(args.output.resolve()))
    gpx.data["Controls"]["data"]["max cyc"] = 10
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]

    # Reset the common profile to a plausible laboratory starting point and
    # first let phase size account for the obvious width difference between
    # BaCO3 and WO3.
    for key, value in {"U": 20.0, "V": 0.0, "W": 10.0, "X": 2.0, "Y": 0.0}.items():
        inst[key][1] = value
        inst[key][2] = False
    for i, phase in enumerate(gpx.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.2 if i == 0 else 0.6
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]

    # Carry the strongly supported BaCO3 [110] texture into both WO3 model
    # comparisons; leave WO3 texture disabled.
    po = gpx.phase(0).data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 0.90, True, [1, 1, 0]
    po2 = gpx.phase(1).data["Histograms"][hist.name]["Pref.Ori."]
    po2[1], po2[2] = 1.0, False
    gpx.save()
    run(gpx, "size_fixed_instrument")

    for phase in gpx.phases():
        phase.data["Histograms"][hist.name]["Mustrain"][2][0] = True
    run(gpx, "size_mustrain_fixed_instrument")

    # A negative isotropic strain is not physical. If a correlation drives it
    # through zero, remove that unresolved contribution and refit.
    reset = False
    for phase in gpx.phases():
        mu = phase.data["Histograms"][hist.name]["Mustrain"]
        if mu[1][0] <= 0:
            mu[1][0] = 0.01
            mu[2][0] = False
            reset = True
    if reset:
        run(gpx, "nonnegative_mustrain")

    for key in ["U", "W", "X"]:
        inst[key][2] = True
    run(gpx, "instrument_phase_profile")

    # Separate the constant angular zero from the Bragg-Brentano specimen
    # displacement (goniometer radius is in the imported sample parameters).
    sample = hist.data["Sample Parameters"]
    sample["Shift"] = [0.0, True]
    run(gpx, "sample_shift")

    inst["SH/L"][2] = True
    run(gpx, "axial_asymmetry")


if __name__ == "__main__":
    main()
