#!/usr/bin/env python3
"""Apply and assess one late-stage GSAS-II model effect."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def sanitize_atomic_bounds(gpx: G2sc.G2Project) -> None:
    """Keep accepted coordinates fixed and remove temporary bound state."""
    for phase in gpx.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    controls = gpx.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("effect", choices=["roughness", "polarization", "background16", "fullrange", "uiso"])
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--ba-uiso", type=float, default=0.0095)
    parser.add_argument("--w-uiso", type=float, default=0.003)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(gpxfile=str(args.base), newgpx=str(args.output.resolve()))
    sanitize_atomic_bounds(gpx)
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = gpx.histogram(0)

    if args.effect == "roughness":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.2, True]
        sample["SurfRoughB"] = [0.1, True]
    elif args.effect == "polarization":
        hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    elif args.effect == "background16":
        hist.set_refinements(
            {"Background": {"type": "chebyschev-1", "no. coeffs": 16, "refine": True}}
        )
    elif args.effect == "fullrange":
        hist.set_refinements({"Limits": list(hist.data["Limits"][0])})
    elif args.effect == "uiso":
        for atom in gpx.phase(0).atoms():
            atom.uiso = args.ba_uiso
        for atom in gpx.phase(1).atoms():
            atom.uiso = args.w_uiso

    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "effect": args.effect,
        "Rwp_percent": hist.get_wR(),
        "GOF": gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "mass_fractions": hist.ComputeMassFracs(),
        "limits": hist.data["Limits"],
        "background": hist.data["Background"][0],
        "instrument": {
            key: inst[key][1]
            for key in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]
        },
        "sample": {
            key: sample[key]
            for key in ["Shift", "SurfRoughA", "SurfRoughB"]
        },
        "uiso": {
            p.name: [a.uiso for a in p.atoms()]
            for p in gpx.phases()
        },
        "project": str(args.output.resolve()),
    }
    print("EFFECT_RESULT " + json.dumps(result, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
