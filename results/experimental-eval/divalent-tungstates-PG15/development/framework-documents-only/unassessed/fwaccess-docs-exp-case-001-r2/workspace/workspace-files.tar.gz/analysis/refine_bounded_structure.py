#!/usr/bin/env python3
"""Refine atomic positions inside physically small reference-mismatch bounds."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def lattice_matrix(cell: dict[str, float]) -> np.ndarray:
    a, b, c = (cell[f"length_{q}"] for q in "abc")
    alpha = math.radians(cell["angle_alpha"])
    beta = math.radians(cell["angle_beta"])
    gamma = math.radians(cell["angle_gamma"])
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * math.cos(gamma), b * math.sin(gamma), 0.0])
    cx = c * math.cos(beta)
    cy = c * (math.cos(alpha) - math.cos(beta) * math.cos(gamma)) / math.sin(gamma)
    cz = math.sqrt(max(c * c - cx * cx - cy * cy, 0.0))
    return np.array([va, vb, [cx, cy, cz]])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(gpxfile=str(args.base), newgpx=str(args.output.resolve()))
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    gpx.data["Controls"]["data"]["shift factor"] = 0.5
    gpx.data["Controls"]["data"]["parmMinDict"] = {}
    gpx.data["Controls"]["data"]["parmMaxDict"] = {}
    gpx.data["Controls"]["data"]["parmFrozen"] = {}

    starts: dict[tuple[int, int], tuple[float, float, float]] = {}
    for pidx, phase in enumerate(gpx.phases()):
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        for aidx, atom in enumerate(phase.atoms()):
            starts[(pidx, aidx)] = atom.coordinates
            atom.refinement_flags = "X"
            # Bound the total displacement to approximately 0.04 A for
            # cations/C and 0.05 A for oxygen. Component limits are the
            # spherical RMS limit divided by sqrt(3).
            radial = 0.05 if atom.element == "O" else 0.04
            for axis, letter in enumerate("xyz"):
                delta = radial / math.sqrt(3.0) / lengths[axis]
                var = f"{pidx}::dA{letter}:{aidx}"
                gpx.set_Controls(
                    "parmMin", starts[(pidx, aidx)][axis] - delta, variable=var
                )
                gpx.set_Controls(
                    "parmMax", starts[(pidx, aidx)][axis] + delta, variable=var
                )
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()

    hist = gpx.histogram(0)
    result = {
        "Rwp_percent": hist.get_wR(),
        "GOF": gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": gpx.get_Frozen(),
        "phases": {},
    }
    for pidx, phase in enumerate(gpx.phases()):
        mat = lattice_matrix(phase.get_cell())
        atoms = []
        for aidx, atom in enumerate(phase.atoms()):
            delta = np.array(atom.coordinates) - np.array(starts[(pidx, aidx)])
            delta -= np.round(delta)
            disp = float(np.linalg.norm(delta @ mat))
            atoms.append(
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": atom.coordinates,
                    "displacement_A": disp,
                }
            )
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "atoms": atoms,
            "short_distances": phase.ShortDistances(),
        }
    print("BOUNDED_STRUCTURE_RESULT " + json.dumps(result, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
