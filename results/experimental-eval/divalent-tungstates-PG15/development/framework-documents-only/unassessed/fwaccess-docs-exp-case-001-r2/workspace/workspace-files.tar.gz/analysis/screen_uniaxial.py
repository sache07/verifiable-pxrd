#!/usr/bin/env python3
"""Screen a physically allowed uniaxial microstrain direction."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_stable import freeze_all


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", type=int)
    parser.add_argument("axis", help="comma-separated h,k,l")
    parser.add_argument("--u", type=float)
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]
    if len(axis) != 3:
        raise ValueError("axis must have three components")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(gpxfile=str(args.base), newgpx=str(args.output.resolve()))
    freeze_all(gpx)
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = gpx.histogram(0)
    if args.u is not None:
        hist.data["Instrument Parameters"][0]["U"][1] = args.u
    phase = gpx.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    iso = hap["Mustrain"][1][0]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = iso
    hap["Mustrain"][1][1] = iso
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = axis
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    print(
        "UNIAXIAL_RESULT "
        + json.dumps(
            {
                "phase": phase.name,
                "axis": axis,
                "Rwp_percent": hist.get_wR(),
                "GOF": gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
                "mustrain": hap["Mustrain"],
                "U": hist.data["Instrument Parameters"][0]["U"][1],
                "mass_fractions": hist.ComputeMassFracs(),
                "project": str(args.output.resolve()),
            },
            default=str,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
