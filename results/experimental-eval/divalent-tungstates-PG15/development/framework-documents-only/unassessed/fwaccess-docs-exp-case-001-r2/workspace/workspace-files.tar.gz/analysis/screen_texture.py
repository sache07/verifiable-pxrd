#!/usr/bin/env python3
"""Screen March-Dollase axes for one phase in an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("phase", help="phase name or integer index")
    parser.add_argument("--outdir", required=True, type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    phase_ref = int(args.phase) if args.phase.isdigit() else args.phase

    for axis in AXES:
        tag = "".join(str(i) for i in axis)
        out = (args.outdir / f"texture_{tag}.gpx").resolve()
        gpx = G2sc.G2Project(gpxfile=str(args.project), newgpx=str(out))
        gpx.data["Controls"]["data"]["max cyc"] = 8
        phase = gpx.phase(phase_ref)
        hist = gpx.histogram(0)
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(axis)
        gpx.save()
        gpx.refine(makeBack=False)
        gpx.save()
        result = {
            "phase": phase.name,
            "axis": axis,
            "ratio": po[1],
            "Rwp_percent": hist.get_wR(),
            "GOF": gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
            "project": str(out),
        }
        print("TEXTURE_RESULT " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
