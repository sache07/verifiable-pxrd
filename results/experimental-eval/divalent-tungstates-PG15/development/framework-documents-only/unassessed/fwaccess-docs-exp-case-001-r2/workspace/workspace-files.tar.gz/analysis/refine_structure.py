#!/usr/bin/env python3
"""Refine coordinates and restrained-common isotropic displacement terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def report(gpx: G2sc.G2Project, stage: str) -> None:
    hist = gpx.histogram(0)
    result = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "mass_fractions": hist.ComputeMassFracs(),
        "short_distances": {p.name: p.ShortDistances() for p in gpx.phases()},
        "phases": {},
    }
    for p in gpx.phases():
        result["phases"][p.name] = {
            "cell": p.get_cell(),
            "atoms": [
                {
                    "label": a.label,
                    "element": a.element,
                    "xyz": a.coordinates,
                    "uiso": a.uiso,
                    "flags": a.refinement_flags,
                }
                for a in p.atoms()
            ],
        }
    print("STRUCTURE_RESULT " + json.dumps(result, default=str, sort_keys=True))


def refine(gpx: G2sc.G2Project, stage: str) -> None:
    gpx.refine(makeBack=False)
    gpx.save()
    report(gpx, stage)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--heavy-only", action="store_true")
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(gpxfile=str(args.base), newgpx=str(args.output.resolve()))
    gpx.data["Controls"]["data"]["max cyc"] = 12
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-5

    # First refine only the dominant scatterers.
    for phase in gpx.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    for atom in gpx.phase(0).atoms():
        if atom.element == "Ba":
            atom.refinement_flags = "X"
    for atom in gpx.phase(1).atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"
    gpx.save()
    refine(gpx, "heavy_atom_coordinates")
    if args.heavy_only:
        return

    # The carbonate coordinates are few enough to add as one block.
    for atom in gpx.phase(0).atoms():
        atom.refinement_flags = "X"
    refine(gpx, "barium_carbonate_coordinates")

    # Add the oxygen framework only after the W sublattice and profile have
    # stabilized.
    for atom in gpx.phase(1).atoms():
        atom.refinement_flags = "X"
    refine(gpx, "all_coordinates")

    # The generator assigns one physically small isotropic U value per phase.
    # Use GSAS-II equivalence constraints so this contributes only one thermal
    # parameter per phase rather than one poorly determined value per site.
    for pidx, phase in enumerate(gpx.phases()):
        for atom in phase.atoms():
            atom.uiso = 0.008
            atom.refinement_flags = "XU"
        variables = [f"{pidx}::AUiso:{i}" for i in range(len(phase.atoms()))]
        if len(variables) > 1:
            gpx.add_EquivConstr(variables, reloadIdx=True)
    refine(gpx, "coordinates_common_uiso")


if __name__ == "__main__":
    main()
