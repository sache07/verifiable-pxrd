#!/usr/bin/env python3
"""Refine a selected parameter block from a converged GSAS-II project.

This freezes every other block first, which makes late-stage model tests
reproducible and avoids correlated all-parameter steps that can move away
from an already better least-squares solution.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def freeze_all(gpx: G2sc.G2Project) -> None:
    controls = gpx.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for value in inst.values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Background"][0][1] = False
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "block",
        choices=[
            "background",
            "scales",
            "scales_background",
            "cells",
            "positions",
            "instrument",
            "instrument_fixed_u",
            "sizes",
            "mustrain",
            "phase_profile",
            "all_profile",
            "fullrange_background",
            "background16",
            "background20",
            "polarization",
            "zero_shift",
            "texture",
        ],
    )
    parser.add_argument("--set-u", type=float)
    parser.add_argument("--set-common-uiso", type=float)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(gpxfile=str(args.base), newgpx=str(args.output.resolve()))
    freeze_all(gpx)
    gpx.set_Controls("cycles", 10)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    phases = gpx.phases()
    if args.set_u is not None:
        inst["U"][1] = args.set_u
    if args.set_common_uiso is not None:
        for phase in phases:
            for atom in phase.atoms():
                atom.uiso = args.set_common_uiso

    if args.block in {"background", "scales_background", "fullrange_background", "background16", "background20"}:
        hist.data["Background"][0][1] = True
    if args.block == "scales_background":
        for phase in phases:
            phase.data["Histograms"][hist.name]["Scale"][1] = True
    elif args.block == "scales":
        for phase in phases:
            phase.data["Histograms"][hist.name]["Scale"][1] = True
    elif args.block == "cells":
        for phase in phases:
            phase.data["General"]["Cell"][0] = True
    elif args.block == "positions":
        for phase in phases:
            for atom in phase.atoms():
                atom.refinement_flags = "X"
    elif args.block == "instrument":
        for key in ["U", "W", "X", "SH/L"]:
            inst[key][2] = True
    elif args.block == "instrument_fixed_u":
        for key in ["W", "X", "SH/L"]:
            inst[key][2] = True
    elif args.block == "sizes":
        for phase in phases:
            phase.data["Histograms"][hist.name]["Size"][2][0] = True
    elif args.block == "mustrain":
        for phase in phases:
            mu = phase.data["Histograms"][hist.name]["Mustrain"]
            mu[2][0] = True
            if mu[0] == "uniaxial":
                mu[2][1] = True
    elif args.block == "phase_profile":
        for phase in phases:
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][2][0] = True
            hap["Mustrain"][2][0] = True
            if hap["Mustrain"][0] == "uniaxial":
                hap["Mustrain"][2][1] = True
    elif args.block == "all_profile":
        for key in ["U", "W", "X", "SH/L"]:
            inst[key][2] = True
        for phase in phases:
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][2][0] = True
            hap["Mustrain"][2][0] = True
            if hap["Mustrain"][0] == "uniaxial":
                hap["Mustrain"][2][1] = True
    elif args.block == "fullrange_background":
        hist.data["Limits"][1] = list(hist.data["Limits"][0])
    elif args.block in {"background16", "background20"}:
        ncoef = int(args.block.removeprefix("background"))
        old = hist.data["Background"][0]
        old[2] = ncoef
        old.extend([0.0] * (3 + ncoef - len(old)))
        del old[3 + ncoef :]
    elif args.block == "polarization":
        inst["Polariz."][2] = True
    elif args.block == "zero_shift":
        inst["Zero"][2] = True
        hist.data["Sample Parameters"]["Shift"][1] = True
    elif args.block == "texture":
        phases[0].data["Histograms"][hist.name]["Pref.Ori."][2] = True

    before = hist.get_wR()
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    cov = gpx.data.get("Covariance", {}).get("data", {})
    result = {
        "block": args.block,
        "before_Rwp": before,
        "after_Rwp": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "mass_fractions": hist.ComputeMassFracs(),
        "limits": hist.data["Limits"],
        "background": hist.data["Background"][0],
        "instrument": {key: inst[key][1] for key in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]},
        "sample": {key: hist.data["Sample Parameters"][key] for key in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "phases": {},
    }
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "scale": hap["Scale"],
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "texture": hap["Pref.Ori."],
        }
    print("STABLE_RESULT " + json.dumps(result, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
