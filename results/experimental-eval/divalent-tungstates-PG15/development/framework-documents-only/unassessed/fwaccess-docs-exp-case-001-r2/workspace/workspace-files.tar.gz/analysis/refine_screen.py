#!/usr/bin/env python3
"""Build a small GSAS-II Rietveld project for candidate phase screening.

This is an exploratory helper. It deliberately keeps atom coordinates fixed and
uses only conventional profile/cell/scale terms so reference models can be
compared on the same basis.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_inputs(work: Path) -> tuple[Path, Path]:
    work.mkdir(parents=True, exist_ok=True)
    xye = work / "pattern.xye"
    inst = work / "cu_ka.instprm"

    with (ROOT / "inputs" / "pattern.csv").open(newline="") as src, xye.open(
        "w"
    ) as dst:
        rows = csv.DictReader(src)
        for row in rows:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")

    inst.write_text(
        "#GSAS-II instrument parameter file; do not add/delete items!\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.28;Polariz.:0.7;Azimuth:0.0;"
        "I(L2)/I(L1):0.5\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst


def set_instrument_value(hist, key: str, value: float) -> None:
    hist.data["Instrument Parameters"][0][key][1] = float(value)


def summarize(gpx: G2sc.G2Project, stage: str) -> dict:
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    out = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "instrument": {
            k: inst[k][1]
            for k in [
                "Zero",
                "U",
                "V",
                "W",
                "X",
                "Y",
                "SH/L",
                "Polariz.",
            ]
            if k in inst
        },
        "sample": hist.data["Sample Parameters"],
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:  # screening should still report the project
        out["mass_fraction_error"] = repr(exc)
    print("SCREEN_SUMMARY " + json.dumps(out, default=str, sort_keys=True))
    return out


def refine_and_report(gpx: G2sc.G2Project, stage: str) -> None:
    gpx.refine(makeBack=False)
    gpx.save()
    summarize(gpx, stage)


def build_project(candidates: list[tuple[str, str]], output: Path) -> G2sc.G2Project:
    work = output.parent
    xye, inst = prepare_inputs(work)
    if output.exists():
        output.unlink()
    gpx = G2sc.G2Project(newgpx=str(output))
    hist = gpx.add_powder_histogram(
        str(xye), str(inst), fmthint="xye", phases=[]
    )
    for label, cod_id in candidates:
        source = cod_path(cod_id)
        if not source.exists():
            raise FileNotFoundError(source)
        gpx.add_phase(
            str(source), phasename=f"{label}_{cod_id}", histograms=[hist]
        )

    # Use nearly the entire observed range, trimming only the few endpoint bins.
    hist.set_refinements({"Limits": [10.0, 100.0]})
    # Only relative phase scales are needed. Refining the histogram scale as
    # well makes the scale block singular.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "refine": True,
            }
        }
    )
    # Reasonable starting profile for this broad laboratory pattern.
    for key, val in {
        "Zero": 0.28,
        "U": 10.0,
        "V": 0.0,
        "W": 10.0,
        "X": 1.0,
        "Y": 0.0,
        "SH/L": 0.02,
        "Polariz.": 0.7,
    }.items():
        set_instrument_value(hist, key, val)

    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = 8
    controls["min dM/M"] = 1.0e-5
    gpx.save()
    return gpx


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--phase",
        action="append",
        required=True,
        metavar="LABEL=CODID",
        help="Candidate phase and COD ID; repeat for each phase",
    )
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument(
        "--quick",
        action="store_true",
        help="Stop after the common-profile stage (for model ranking)",
    )
    args = parser.parse_args()
    candidates = []
    for item in args.phase:
        label, cod_id = item.split("=", 1)
        candidates.append((label, cod_id))

    gpx = build_project(candidates, args.output.resolve())
    hist = gpx.histogram(0)
    print("INITIAL_SAMPLE " + json.dumps(hist.data["Sample Parameters"], default=str))
    print(
        "INITIAL_INST "
        + json.dumps(hist.data["Instrument Parameters"][0], default=str)
    )

    # Stage 1: background and phase scales only.
    for phase in gpx.phases():
        phase.set_HAP_refinements({"Scale": True})
    refine_and_report(gpx, "scale_background")

    # Stage 2: cell metrics and common angular zero.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    refine_and_report(gpx, "cell_zero")

    # Stage 3: common instrumental broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine_and_report(gpx, "instrument_profile")

    if args.quick:
        return

    # Stage 4: isotropic phase broadening. Start conservatively in the middle
    # of the laboratory's expected domain-size range.
    for phase in gpx.phases():
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.3, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    refine_and_report(gpx, "phase_broadening")

    # Stage 5: refine the axial-divergence asymmetry after widths are stable.
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine_and_report(gpx, "asymmetry")


if __name__ == "__main__":
    main()
