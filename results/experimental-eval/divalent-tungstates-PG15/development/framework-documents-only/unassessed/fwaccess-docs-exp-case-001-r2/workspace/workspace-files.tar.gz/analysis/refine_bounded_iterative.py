#!/usr/bin/env python3
"""Iteratively refine physically bounded coordinates to a reloadable state.

GSAS-II computes the final profile before applying a coordinate clamp. When a
variable crosses a hard bound, another refinement pass is therefore required
with that variable frozen at the bound. Iteration continues until a complete
pass adds no frozen variables, making the saved structure and profile agree.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_stable import freeze_all


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("reference", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--passes", type=int, default=8)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    gpx = G2sc.G2Project(gpxfile=str(args.base), newgpx=str(args.output.resolve()))
    reference = G2sc.G2Project(gpxfile=str(args.reference))
    freeze_all(gpx)
    gpx.set_Controls("cycles", 10)
    controls = gpx.data["Controls"]["data"]
    controls["min dM/M"] = 1.0e-6
    controls["shift factor"] = 0.5

    starts = {}
    for pidx, (phase, ref_phase) in enumerate(zip(gpx.phases(), reference.phases())):
        lengths = [phase.get_cell()[f"length_{q}"] for q in "abc"]
        for aidx, (atom, ref_atom) in enumerate(zip(phase.atoms(), ref_phase.atoms())):
            atom.refinement_flags = "X"
            starts[(pidx, aidx)] = ref_atom.coordinates
            radial = 0.05 if atom.element == "O" else 0.04
            for axis, letter in enumerate("xyz"):
                delta = radial / math.sqrt(3.0) / lengths[axis]
                var = f"{pidx}::dA{letter}:{aidx}"
                gpx.set_Controls("parmMin", ref_atom.coordinates[axis] - delta, variable=var)
                gpx.set_Controls("parmMax", ref_atom.coordinates[axis] + delta, variable=var)

    passes = []
    for pass_index in range(args.passes):
        before = len(gpx.data["Controls"]["data"]["parmFrozen"].get("FrozenList", []))
        gpx.save()
        gpx.refine(makeBack=False)
        gpx.save()
        after = len(gpx.data["Controls"]["data"]["parmFrozen"].get("FrozenList", []))
        entry = {
            "pass": pass_index + 1,
            "Rwp_percent": gpx.histogram(0).get_wR(),
            "frozen_before": before,
            "frozen_after": after,
        }
        passes.append(entry)
        print("BOUND_PASS " + json.dumps(entry, sort_keys=True), flush=True)
        if after == before:
            break

    result = {
        "passes": passes,
        "Rwp_percent": gpx.histogram(0).get_wR(),
        "mass_fractions": gpx.histogram(0).ComputeMassFracs(),
        "frozen": len(gpx.data["Controls"]["data"]["parmFrozen"].get("FrozenList", [])),
        "phases": {},
    }
    for pidx, phase in enumerate(gpx.phases()):
        atoms = []
        lengths = [phase.get_cell()[f"length_{q}"] for q in "abc"]
        for aidx, atom in enumerate(phase.atoms()):
            delta = [
                (atom.coordinates[i] - starts[(pidx, aidx)][i]) * lengths[i]
                for i in range(3)
            ]
            atoms.append(
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": atom.coordinates,
                    "approx_displacement_A": math.sqrt(sum(v * v for v in delta)),
                }
            )
        result["phases"][phase.name] = {"cell": phase.get_cell(), "atoms": atoms}
    print("BOUND_ITER_RESULT " + json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
