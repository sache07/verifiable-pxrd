#!/usr/bin/env python3
"""Test chemically plausible added phases against an established project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--candidate", action="append", required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument(
        "--fixed-base",
        action="store_true",
        help="Refine only the added phase scale, keeping the accepted model fixed",
    )
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    for item in args.candidate:
        label, cod_id = item.split("=", 1)
        output = (args.outdir / f"added_{cod_id}.gpx").resolve()
        gpx = G2sc.G2Project(gpxfile=str(args.base), newgpx=str(output))
        hist = gpx.histogram(0)
        baseline = hist.get_wR()
        phase = gpx.add_phase(
            str(cod_path(cod_id)),
            phasename=f"{label}_{cod_id}",
            histograms=[hist],
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [0.05, True]
        hap["Size"][1][0] = 0.3
        hap["Size"][2][0] = False
        hap["Mustrain"][2][0] = False
        if args.fixed_base:
            # Disable every pre-existing flag. This makes the test a direct
            # projection of the candidate profile onto the established
            # residual and prevents a small positive scale from compensating
            # unrelated shifts in the accepted phases.
            hist.data["Background"][0][1] = False
            for value in hist.data["Instrument Parameters"][0].values():
                if isinstance(value, list) and len(value) > 2:
                    value[2] = False
            for value in hist.data["Sample Parameters"].values():
                if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
                    value[1] = False
            for old_phase in gpx.phases()[:-1]:
                old_phase.data["General"]["Cell"][0] = False
                for atom in old_phase.atoms():
                    atom.refinement_flags = " "
                old_hap = old_phase.data["Histograms"][hist.name]
                old_hap["Scale"][1] = False
                old_hap["Size"][2] = [False] * len(old_hap["Size"][2])
                old_hap["Mustrain"][2] = [False] * len(old_hap["Mustrain"][2])
                old_hap["Pref.Ori."][2] = False
                old_hap["HStrain"][1] = [False] * len(old_hap["HStrain"][1])
        gpx.data["Controls"]["data"]["max cyc"] = 8
        gpx.save()
        gpx.refine(makeBack=False)
        gpx.save()
        try:
            fractions = hist.ComputeMassFracs()
        except Exception as exc:
            fractions = {"error": repr(exc)}
        result = {
            "candidate": phase.name,
            "baseline_Rwp_percent": baseline,
            "Rwp_percent": hist.get_wR(),
            "candidate_scale": hap["Scale"][0],
            "mass_fractions": fractions,
            "project": str(output),
        }
        print("ADDED_PHASE_RESULT " + json.dumps(result, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
