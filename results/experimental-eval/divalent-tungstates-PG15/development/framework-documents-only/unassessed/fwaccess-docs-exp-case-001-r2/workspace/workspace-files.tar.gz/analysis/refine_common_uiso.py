#!/usr/bin/env python3
"""Refine one common isotropic displacement parameter per phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_stable import freeze_all


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--start", type=float, default=0.008)
    parser.add_argument("--scales", action="store_true")
    parser.add_argument("--phase", type=int, choices=[0, 1])
    parser.add_argument("--fixed-other", type=float, default=0.003)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(gpxfile=str(args.base), newgpx=str(args.output.resolve()))
    freeze_all(gpx)
    gpx.set_Controls("cycles", 10)
    gpx.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = gpx.histogram(0)
    for pidx, phase in enumerate(gpx.phases()):
        variables = []
        for aidx, atom in enumerate(phase.atoms()):
            refine_this = args.phase is None or pidx == args.phase
            atom.uiso = args.start if refine_this else args.fixed_other
            atom.refinement_flags = "U" if refine_this else " "
            variables.append(f"{pidx}::AUiso:{aidx}")
        if args.phase is None or pidx == args.phase:
            gpx.add_EquivConstr(variables, reloadIdx=True)
        if args.scales:
            phase.data["Histograms"][hist.name]["Scale"][1] = True
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    print(
        "UISO_RESULT "
        + json.dumps(
            {
                "Rwp_percent": hist.get_wR(),
                "GOF": gpx.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
                "mass_fractions": hist.ComputeMassFracs(),
                "uiso_A2": {phase.name: [atom.uiso for atom in phase.atoms()] for phase in gpx.phases()},
                "scales": {
                    phase.name: phase.data["Histograms"][hist.name]["Scale"]
                    for phase in gpx.phases()
                },
                "project": str(args.output.resolve()),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
