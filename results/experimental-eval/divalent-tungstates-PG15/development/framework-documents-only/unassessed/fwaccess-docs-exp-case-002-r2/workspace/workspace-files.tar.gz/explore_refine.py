#!/usr/bin/env python3
"""Run comparable preliminary GSAS-II refinements for WO3 reference models."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter, gaussian_filter1d

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def background_points() -> list[tuple[float, float]]:
    data = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    x, y = data.T
    # A broad low percentile suppresses the crystalline peaks while retaining
    # the smooth exponential/power-law background seen in this scan.
    envelope = percentile_filter(y, percentile=8, size=401, mode="nearest")
    envelope = gaussian_filter1d(envelope, 90)
    xp = np.arange(10.0, 100.01, 1.5)
    yp = np.interp(xp, x, envelope)
    return [(float(a), float(b)) for a, b in zip(xp, yp)]


def summarize(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    out = {
        "residuals": hist.residuals,
        "instrument": {
            k: v[1]
            for k, v in hist.InstrumentParameters.items()
            if isinstance(v, list) and len(v) >= 2
        },
        "sample": hist.SampleParameters,
        "phases": {},
    }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "mass": phase.data["General"]["Mass"],
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    return out


def set_bound(project: G2sc.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def apply_physical_bounds(
    project: G2sc.G2Project,
    hist: G2sc.G2PwdrData,
    phases: list[G2sc.G2Phase],
) -> None:
    project.index_ids()
    # Instrument/profile and specimen ranges are deliberately somewhat wider
    # than expected but exclude nonphysical trade-offs.
    for name, limits in {
        "U": (0.0, 50.0),
        "W": (1.0, 50.0),
        "X": (0.05, 8.0),
        "SH/L": (0.003, 0.12),
        "Zero": (-0.5, 0.5),
        "Polariz.": (0.4, 1.0),
        "Shift": (-1200.0, 1200.0),
    }.items():
        set_bound(project, f":{hist.id}:{name}", *limits)

    for phase in phases:
        pid = phase.id
        set_bound(project, f"{pid}:{hist.id}:Scale", 0.0, 1.0e4)
        set_bound(project, f"{pid}:{hist.id}:Size;i", 0.01, 10.0)
        set_bound(project, f"{pid}:{hist.id}:Size;mx", 0.0, 1.0)
        set_bound(project, f"{pid}:{hist.id}:Mustrain;i", 0.0, 15000.0)
        set_bound(project, f"{pid}:{hist.id}:Mustrain;mx", 0.0, 1.0)

        # Bound reciprocal-metric terms near the reference cell. This avoids
        # invalid trial cells while allowing much more change than the observed
        # reference mismatch requires.
        cell = phase.data["General"]["Cell"][1:7]
        avec = G2lat.cell2A(cell)
        metric_scale = max(abs(avec[0]), abs(avec[1]), abs(avec[2]))
        for index, value in enumerate(avec):
            if abs(value) > 1.0e-10:
                low, high = sorted((0.96 * value, 1.04 * value))
            else:
                low, high = -0.01 * metric_scale, 0.01 * metric_scale
            set_bound(project, f"{pid}::A{index}", low, high)


def refine(wo3_id: str, outdir: Path) -> dict:
    outdir.mkdir(parents=True, exist_ok=True)
    gpx_path = outdir / f"candidate-{wo3_id}.gpx"
    project = G2sc.G2Project(newgpx=str(gpx_path))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.SampleParameters["Gonio. radius"] = 200.0
    # The histogram scale and phase scales are exactly degenerate. Keep the
    # former fixed and refine the phase scales used for quantitative analysis.
    hist.SampleParameters["Scale"] = [1.0, False]
    # A small negative displacement places the reference peaks close enough
    # to the measured peaks for stable cell derivatives. It is refined below.
    hist.SampleParameters["Shift"] = [-200.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 18,
                "FixedPoints": background_points(),
                "fit fixed points": True,
                "refine": True,
            }
        }
    )

    phases = [
        project.add_phase(
            str(cod_path(wo3_id)),
            phasename=f"WO3_{wo3_id}",
            histograms=[hist],
            fmthint="CIF",
        ),
        project.add_phase(
            str(cod_path("1010113")),
            phasename="BaO2_1010113",
            histograms=[hist],
            fmthint="CIF",
        ),
    ]
    for phase in phases:
        phase.HAPvalue("Scale", 1.0)
        phase.set_HAP_refinements({"Scale": True})
        # Broad but fixed starting profiles keep displaced reference peaks in
        # derivative range during the early scale/cell refinements.
        phase.setSampleProfile(hist, "size", "isotropic", 0.10, LGmix=0.5)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 3000.0, LGmix=0.5)

    project.set_Controls("cycles", 12)
    apply_physical_bounds(project, hist, phases)
    project.save()

    # First establish scales/background at the reference cells.
    project.do_refinements([{}])
    # Refine the common specimen displacement, then each phase cell in turn.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.do_refinements([{}])
    phases[0].set_refinements({"Cell": True})
    project.do_refinements([{}])
    phases[1].set_refinements({"Cell": True})
    project.do_refinements([{}])
    # Separate zero and specimen displacement after the phase cells are close.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.do_refinements([{}])
    # Resolve phase-dependent broadening before releasing the common profile;
    # this prevents the instrument terms from absorbing all sample broadening.
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 0.5, "refine": False},
                },
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 0.5, "refine": False},
                },
            }
        )
    project.do_refinements([{}])
    # Establish the common instrument contribution after sample broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.do_refinements([{}])
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.do_refinements([{}])
    project.save()
    return summarize(project)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("--outdir", type=Path, default=ROOT / ".tmp" / "candidates")
    args = parser.parse_args()
    result = refine(args.wo3_id, args.outdir / args.wo3_id)
    print(json.dumps(result, indent=2, default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o)))


if __name__ == "__main__":
    main()
