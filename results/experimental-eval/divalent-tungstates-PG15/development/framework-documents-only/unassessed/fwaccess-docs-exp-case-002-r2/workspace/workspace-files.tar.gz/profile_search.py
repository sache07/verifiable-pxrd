#!/usr/bin/env python3
"""Compare isotropic/uniaxial sample-broadening models from a fitted base GPX."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from explore_refine import set_bound


def parse_axis(text: str):
    if text == "iso":
        return None
    if text not in {"001", "100", "010"}:
        raise ValueError(text)
    return [int(v) for v in text]


def reset_flags(project, hist, phases):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
            },
            [hist],
        )
        phase.set_HAP_refinements({"Scale": False}, [hist])
    hist.data["Background"][0][1] = False


def configure_profile(project, hist, phase, axis):
    old_hap = phase.getHAPvalues(hist)
    old_size = float(old_hap["Size"][1][0])
    old_strain = float(old_hap["Mustrain"][1][0])
    old_size_mix = float(old_hap["Size"][1][2])
    old_strain_mix = float(old_hap["Mustrain"][1][2])
    phase.setSampleProfile(hist, "size", "isotropic", old_size, LGmix=old_size_mix)
    phase.set_HAP_refinements(
        {
            "Size": {
                "type": "isotropic",
                "refine": False,
                "LGmix": {"value": old_size_mix, "refine": False},
            }
        },
        [hist],
    )
    if axis is None:
        phase.setSampleProfile(
            hist, "microstrain", "isotropic", old_strain, LGmix=old_strain_mix
        )
        strain_ref = {
            "type": "isotropic",
            "refine": False,
            "LGmix": {"value": old_strain_mix, "refine": False},
        }
    else:
        phase.setSampleProfile(
            hist,
            "microstrain",
            "uniaxial",
            old_strain,
            old_strain,
            axis,
            LGmix=old_strain_mix,
        )
        strain_ref = {
            "type": "uniaxial",
            "direction": axis,
            "refine": "axial",
            "LGmix": {"value": old_strain_mix, "refine": False},
        }
    phase.set_HAP_refinements({"Mustrain": strain_ref}, [hist])
    pid, hid = phase.id, hist.id
    set_bound(project, f"{pid}:{hid}:Size;i", 0.01, 10.0)
    set_bound(project, f"{pid}:{hid}:Mustrain;i", 0.0, 30000.0)
    if axis is not None:
        set_bound(project, f"{pid}:{hid}:Mustrain;a", 0.0, 30000.0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("wo3_axis")
    parser.add_argument("bao2_axis")
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(args.source), filename=str(args.output))
    hist = project.histogram(0)
    phases = project.phases()
    reset_flags(project, hist, phases)

    project.set_Controls("cycles", 5)
    configure_profile(project, hist, phases[0], parse_axis(args.wo3_axis))
    configure_profile(project, hist, phases[1], parse_axis(args.bao2_axis))
    project.save()
    project.do_refinements([{}])
    project.save()

    print(
        "PROFILE_RESULT",
        args.wo3_axis,
        args.bao2_axis,
        hist.get_wR(),
        hist.InstrumentParameters["U"][1],
        hist.InstrumentParameters["W"][1],
        hist.InstrumentParameters["X"][1],
        phases[0].getHAPvalues(hist)["Mustrain"][1][:2],
        phases[1].getHAPvalues(hist)["Mustrain"][1][:2],
    )


if __name__ == "__main__":
    main()
