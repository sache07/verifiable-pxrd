#!/usr/bin/env python3
"""Rebuild a consistent, physically parameterized refinement from a good cell fit."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def clear_all_flags(project, hist, phases):
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    for item in hist.InstrumentParameters.values():
        if isinstance(item, list) and len(item) >= 3:
            item[2] = False
    for item in hist.SampleParameters.values():
        if isinstance(item, list) and len(item) == 2 and isinstance(item[1], bool):
            item[1] = False
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.data["Background"][0][1] = False
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
                "Scale": True,
            },
            [hist],
        )


def report(tag, project, hist, phases):
    fields = [tag, f"Rwp={hist.get_wR():.6f}"]
    inst = hist.InstrumentParameters
    fields += [f"{k}={inst[k][1]:.7g}" for k in ("U", "W", "X", "SH/L", "Zero")]
    fields.append(f"Shift={hist.SampleParameters['Shift'][0]:.7g}")
    for phase in phases:
        hap = phase.getHAPvalues(hist)
        fields.append(
            f"{phase.name}:scale={hap['Scale'][0]:.7g},"
            f"size={hap['Size'][1][0]:.7g},strain={hap['Mustrain'][1][0]:.7g}"
        )
    print("STAGE", *fields, flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--u", type=float, default=20.0)
    parser.add_argument("--w", type=float, default=10.0)
    parser.add_argument("--x", type=float, default=1.0)
    parser.add_argument("--shl", type=float, default=0.017)
    parser.add_argument("--size", type=float, default=0.08)
    parser.add_argument("--strain", type=float, default=4000.0)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    project = G2sc.G2Project(str(args.source), filename=str(args.output))
    hist = project.histogram(0)
    phases = project.phases()
    clear_all_flags(project, hist, phases)
    project.set_Controls("cycles", args.cycles)

    # Keep the well-determined cells/peak-position solution from the source,
    # but replace the nonphysical trial profile with a laboratory-Cu starting
    # model inside the ranges supplied for this experiment family.
    for key, value in {
        "U": args.u,
        "W": args.w,
        "X": args.x,
        "SH/L": args.shl,
    }.items():
        hist.InstrumentParameters[key][1] = value
    for phase in phases:
        phase.setSampleProfile(hist, "size", "isotropic", args.size, LGmix=0.5)
        phase.setSampleProfile(
            hist, "microstrain", "isotropic", args.strain, LGmix=0.5
        )

    # Re-establish the linear intensity/background terms for the physical profile.
    hist.data["Background"][0][1] = True
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.save()
    project.do_refinements([{}])
    report("linear", project, hist, phases)

    # Fit low-angle size broadening first.
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 0.5, "refine": False},
                }
            },
            [hist],
        )
    project.do_refinements([{}])
    report("size", project, hist, phases)

    # Then fit the high-angle microstrain contribution.
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 0.5, "refine": False},
                }
            },
            [hist],
        )
    project.do_refinements([{}])
    report("strain", project, hist, phases)
    project.save()


if __name__ == "__main__":
    main()
