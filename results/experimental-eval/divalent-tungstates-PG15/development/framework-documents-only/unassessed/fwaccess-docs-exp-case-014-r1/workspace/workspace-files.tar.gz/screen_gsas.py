#!/usr/bin/env python3
"""Build and refine trial GSAS-II phase models for candidate screening."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def phase_path(spec: str) -> Path:
    path = Path(spec)
    return path if path.exists() else cod_path(spec)


def set_starting_values(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.Limits("lower", 10.02)
    hist.Limits("upper", 99.98)
    hist.Background[0][0] = "chebyschev-1"
    hist.Background[0][2] = 10
    hist.Background[0][3:] = [500.0] + [0.0] * 9
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"][0] = 1.0
    hist.SampleParameters["Scale"][1] = False
    hist.SampleParameters["Shift"][0] = -650.0
    inst = hist.InstrumentParameters
    inst["Polariz."][1] = 0.7
    inst["U"][1] = 10.0
    inst["V"][1] = 0.0
    inst["W"][1] = 10.0
    inst["X"][1] = 1.0
    inst["Y"][1] = 0.0
    inst["SH/L"][1] = 0.02
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        hap["Scale"][0] = 1.0
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.10
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0


def run_trial(cod_ids: list[str], output: Path) -> dict:
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    for cod_id in cod_ids:
        project.add_phase(
            str(phase_path(cod_id)),
            phasename=f"phase_{Path(cod_id).stem}",
            histograms=[hist],
            fmthint="CIF",
        )
    set_starting_values(project)
    project["Controls"]["data"]["max cyc"] = 12
    project.save()

    # Conservative staged refinement: background/scales, specimen shift and
    # cells, then peak widths and phase-dependent broadening.
    project.do_refinements([
        {"set": {"Background": {"refine": True, "no. coeffs": 10},
                  "PhaseFraction": True}},
        {"set": {"Sample Parameters": ["Shift"], "Cell": True}},
        {"set": {"Size": {"type": "isotropic", "refine": True}}},
        # Keep the common instrumental profile fixed during phase screening;
        # otherwise it is strongly correlated with specimen broadening.
    ])
    project.save()
    hist = project.histogram(0)
    result = {
        "ids": cod_ids,
        "wR": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items()
                       if isinstance(v, list) and len(v) > 1},
        "sample": hist.SampleParameters,
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cod_ids", nargs="+")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    result = run_trial(args.cod_ids, args.output)
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
