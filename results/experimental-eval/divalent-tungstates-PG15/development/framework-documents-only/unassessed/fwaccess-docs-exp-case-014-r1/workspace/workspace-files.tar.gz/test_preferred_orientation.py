#!/usr/bin/env python3
"""Test a single March-Dollase axis from a common GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json

import GSASIIscriptable as G2sc

from add_candidate import clear_flags


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", required=True, type=int)
    parser.add_argument("--axis", required=True)
    args = parser.parse_args()

    axis = [int(value) for value in args.axis.split(",")]
    project = G2sc.G2Project(args.base, newgpx=args.output)
    hist = project.histogram(0)
    clear_flags(project)
    hist.set_refinements({"Background": {"refine": True, "no. coeffs": 10}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    target = project.phase(args.phase)
    po = target.getHAPvalues(hist)["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = axis
    project.set_Controls("cycles", 12)
    project.save()
    project.refine()
    project.save()

    hist = project.histogram(0)
    target = project.phase(args.phase)
    print(json.dumps({
        "phase": target.name,
        "axis": axis,
        "wR": hist.get_wR(),
        "ratio": target.getHAPvalues(hist)["Pref.Ori."][1],
        "mass_fractions": hist.ComputeMassFracs(),
    }, default=str))


if __name__ == "__main__":
    main()
