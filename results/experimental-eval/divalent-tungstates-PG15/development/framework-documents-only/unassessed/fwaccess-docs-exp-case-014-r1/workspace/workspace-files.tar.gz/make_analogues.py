#!/usr/bin/env python3
"""Create chemically substituted analogue models for candidate screening."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = Path(".tmp/analogues")


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_scaled_substitution(
    cod_id: str, replacements: dict[str, str], scale: float, name: str
) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species(replacements)
    old = structure.lattice
    cell = (old.a * scale, old.b * scale, old.c * scale,
            old.alpha, old.beta, old.gamma)
    structure = Structure(
        Lattice.from_parameters(*cell),
        [site.species for site in structure],
        structure.frac_coords,
        site_properties=structure.site_properties,
    )
    CifWriter(structure, symprec=0.05, refine_struct=False).write_file(OUT / name)


def write_p21n_model(
    name: str,
    cell: tuple[float, float, float, float],
    sites: list[tuple[str, str, float, float, float, float]],
) -> None:
    a, b, c, beta = cell
    atom_rows = "\n".join(
        f"  {element:2s} {label:4s} {x:.8f} {y:.8f} {z:.8f} 1.0 Uiso {uiso:.5f}"
        for element, label, x, y, z, uiso in sites
    )
    text = f"""data_{Path(name).stem}
_chemical_formula_sum 'Sr3 W O6'
_space_group_IT_number 14
_space_group_name_Hall '-P 2yn'
_space_group_name_H-M_alt 'P 1 21/n 1'
_symmetry_cell_setting monoclinic
_symmetry_space_group_name_H-M 'P 1 21/n 1'
_cell_length_a {a:.8f}
_cell_length_b {b:.8f}
_cell_length_c {c:.8f}
_cell_angle_alpha 90
_cell_angle_beta {beta:.8f}
_cell_angle_gamma 90
_cell_formula_units_Z 2
loop_
_symmetry_equiv_pos_site_id
_symmetry_equiv_pos_as_xyz
1 +x,+y,+z
2 -x+1/2,+y+1/2,-z+1/2
3 -x,-y,-z
4 +x+1/2,-y+1/2,+z+1/2
loop_
_atom_site_type_symbol
_atom_site_label
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
_atom_site_occupancy
_atom_site_thermal_displace_type
_atom_site_U_iso_or_equiv
{atom_rows}
"""
    (OUT / name).write_text(text)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    # Ca3WO6 and Sr3UO6 share the same ordered P21/c A3BO6 framework.
    ca_sites = [
        ("Sr", "Sr1", .48520, .55687, .25576, .00803),
        ("Sr", "Sr2", 0., .5, 0., .00557),
        ("W", "W1", .5, 0., 0., .00477),
        ("O", "O1", .33351, .27515, .06938, .00855),
        ("O", "O2", .21705, .82446, .04950, .00847),
        ("O", "O3", .61240, -.05258, .22537, .00733),
    ]
    for scale in (1.04, 1.06, 1.08):
        write_p21n_model(
            f"Sr3WO6_from_Ca_scale_{scale:.2f}.cif",
            (5.55175 * scale, 5.81004 * scale, 8.0066 * scale, 90.1915),
            ca_sites,
        )
    u_sites = [
        ("Sr", "Sr1", .5128, .5490, .2440, .0100),
        ("Sr", "Sr2", .5, 0., 0., .0100),
        ("W", "W1", 0., .5, 0., .0080),
        ("O", "O1", .1731, .2242, .9283, .0120),
        ("O", "O2", .2823, .6759, .9484, .0120),
        ("O", "O3", .3857, .9415, .2728, .0120),
    ]
    for scale in (0.96, 0.98, 1.00):
        write_p21n_model(
            f"Sr3WO6_from_U_scale_{scale:.2f}.cif",
            (6.0126 * scale, 6.2138 * scale, 8.6139 * scale, 90.239),
            u_sites,
        )
    for scale in (0.96, 0.98, 1.00):
        write_scaled_substitution(
            "1534803", {"Ba": "Sr"}, scale,
            f"Sr3WO6_from_Ba_scale_{scale:.2f}.cif",
        )
    # Trigonal Ba3W2O9 provides a distinct A3B2O9 framework not represented
    # by the monoclinic Sr3W2O9 entry in the filtered library.
    for scale in (0.94, 0.96, 0.98):
        write_scaled_substitution(
            "1533878", {"Ba": "Sr"}, scale,
            f"Sr3W2O9_from_Ba_scale_{scale:.2f}.cif",
        )


if __name__ == "__main__":
    main()
