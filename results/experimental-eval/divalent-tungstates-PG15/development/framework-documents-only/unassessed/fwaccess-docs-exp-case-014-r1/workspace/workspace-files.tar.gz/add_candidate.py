#!/usr/bin/env python3
"""Add one trial phase to a converged two-phase GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import GSASIIscriptable as G2sc

from screen_gsas import phase_path


def clear_flags(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements({
        "Background": True,
        "Sample Parameters": ["Shift", "Scale", "SurfRoughA", "SurfRoughB"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "HStrain": True, "Pref.Ori.": True,
        })


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate")
    parser.add_argument("--base", default=".tmp/screen_1528915.gpx")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    project = G2sc.G2Project(args.base, newgpx=args.output)
    hist = project.histogram(0)
    candidate = project.add_phase(
        str(phase_path(args.candidate)),
        phasename=f"candidate_{Path(args.candidate).stem}",
        histograms=[hist],
        fmthint="CIF",
    )
    clear_flags(project)
    hap = candidate.getHAPvalues(hist)
    hap["Scale"][0] = 0.10
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.10
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    project.set_Controls("cycles", 12)
    project.save()

    # First assess intensities with all peak positions fixed. Then allow only
    # the candidate cell to move, followed by its specimen broadening. Finish
    # by readjusting all cells, the common displacement and background.
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    project.refine()
    candidate.set_refinements({"Cell": True})
    project.refine()
    candidate.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True}
    })
    project.refine()
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({
        "Sample Parameters": ["Shift"],
        "Background": {"refine": True, "no. coeffs": 10},
    })
    project.refine()
    project.save()

    result = {
        "wR": hist.get_wR(),
        "mass_fractions": hist.ComputeMassFracs(),
        "phases": {},
    }
    for phase in project.phases():
        phap = phase.getHAPvalues(hist)
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": phap["Scale"],
            "size": phap["Size"],
        }
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
