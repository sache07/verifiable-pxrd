#!/usr/bin/env python3
"""Staged physically constrained profile optimization for the selected model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import GSASIIscriptable as G2sc


def clear_flags(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements({
        "Background": True,
        "Sample Parameters": ["Scale", "Shift", "SurfRoughA", "SurfRoughB"],
        "Instrument Parameters": [
            "Polariz.", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"
        ],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "HStrain": True, "Pref.Ori.": True,
        })


def common_intensity_flags(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True, "no. coeffs": 10}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def summary(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    return {
        "stage": label,
        "wR": hist.get_wR(),
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: val[1] for key, val in hist.InstrumentParameters.items()
            if key in {"Polariz.", "U", "V", "W", "X", "Y", "SH/L"}
        },
        "sample": {
            key: hist.SampleParameters[key][0]
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.getHAPvalues(hist)["Scale"][0],
                "size": phase.getHAPvalues(hist)["Size"][1],
                "mustrain": phase.getHAPvalues(hist)["Mustrain"][1],
            }
            for phase in project.phases()
        },
    }


def refine_and_save(
    project: G2sc.G2Project, output_root: Path, number: int, label: str
) -> None:
    project.refine()
    project.save(str(output_root.with_name(f"{output_root.name}_stage{number}.gpx")))
    print(json.dumps(summary(project, label), default=str))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default=".tmp/add_sr3w2o9.gpx")
    parser.add_argument("--output-root", default=".tmp/profile")
    args = parser.parse_args()
    output_root = Path(args.output_root)

    project = G2sc.G2Project(
        args.base, newgpx=str(output_root.with_name(f"{output_root.name}_stage0.gpx"))
    )
    hist = project.histogram(0)
    project.set_Controls("cycles", 12)

    # 1. Correct the clear angle-dependent intensity bias before allowing
    # profile terms to compensate for it.
    clear_flags(project)
    common_intensity_flags(project)
    hist.SampleParameters["SurfRoughA"][0] = 0.20
    hist.SampleParameters["SurfRoughB"][0] = 0.10
    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    refine_and_save(project, output_root, 1, "surface roughness")

    # 2. Polarization also changes relative intensities with angle.
    clear_flags(project)
    common_intensity_flags(project)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine_and_save(project, output_root, 2, "polarization")

    # 3. Determine the common instrumental contribution with phase sizes held.
    clear_flags(project)
    common_intensity_flags(project)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine_and_save(project, output_root, 3, "instrument profile")

    # 4. Determine phase-dependent size and isotropic strain broadening with
    # the common instrument profile fixed.
    clear_flags(project)
    common_intensity_flags(project)
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        if hap["Mustrain"][1][0] <= 0:
            hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    refine_and_save(project, output_root, 4, "isotropic specimen broadening")

    # 5. Joint profile cleanup, retaining only physically motivated terms.
    clear_flags(project)
    common_intensity_flags(project)
    hist.set_refinements({
        "Instrument Parameters": ["Polariz.", "U", "W", "X", "SH/L"],
        "Sample Parameters": ["SurfRoughA", "SurfRoughB"],
    })
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    refine_and_save(project, output_root, 5, "joint profile")

    # 6. Reoptimize peak positions only after the profile is stable.
    clear_flags(project)
    common_intensity_flags(project)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine_and_save(project, output_root, 6, "cells and displacement")


if __name__ == "__main__":
    main()
