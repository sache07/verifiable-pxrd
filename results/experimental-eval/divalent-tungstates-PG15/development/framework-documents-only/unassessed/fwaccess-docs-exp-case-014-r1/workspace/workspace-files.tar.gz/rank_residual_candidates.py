#!/usr/bin/env python3
"""Rank local-library phases against positive residual intensity."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d


INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")
ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
LAMBDA1 = 1.540598
LAMBDA2 = 1.544426
SHIFT_UM = -600.0
RADIUS_MM = 200.0


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def add_profile(
    x: np.ndarray, positions: np.ndarray, intensities: np.ndarray
) -> np.ndarray:
    step = float(np.median(np.diff(x)))
    sticks = np.zeros_like(x)
    indices = np.rint((positions - x[0]) / step).astype(int)
    good = (indices >= 0) & (indices < len(x))
    np.add.at(sticks, indices[good], intensities[good])
    # About 0.28 degree FWHM, representative of the residual minor-phase peaks.
    return gaussian_filter1d(sticks, 0.28 / 2.35482 / step)


def profile_for_scale(
    x: np.ndarray, base_pos: np.ndarray, base_int: np.ndarray, scale: float
) -> np.ndarray:
    theta = np.deg2rad(base_pos / 2.0)
    arg = np.clip(np.sin(theta) / scale, -0.999999, 0.999999)
    pos1 = np.rad2deg(2.0 * np.arcsin(arg))
    correction = (
        -2.0 * SHIFT_UM / (RADIUS_MM * 1000.0)
        * 180.0 / np.pi * np.cos(np.deg2rad(pos1 / 2.0))
    )
    pos1 += correction
    pos2 = np.rad2deg(
        2.0 * np.arcsin(np.clip(LAMBDA2 / LAMBDA1 * np.sin(np.deg2rad(pos1 / 2.0)), -0.999999, 0.999999))
    )
    return add_profile(
        x,
        np.r_[pos1, pos2],
        np.r_[base_int, 0.5 * base_int],
    )


def score_profile(
    profile: np.ndarray,
    residual: np.ndarray,
    weight: np.ndarray,
    mask: np.ndarray,
) -> tuple[float, float]:
    use = mask & np.isfinite(profile) & np.isfinite(residual)
    p = profile[use]
    r = residual[use]
    w = weight[use]
    denom = np.sum(w * p * p)
    if denom <= 0:
        return 0.0, 0.0
    amplitude = max(0.0, float(np.sum(w * p * r) / denom))
    improvement = float(
        np.sum(w * r * r) - np.sum(w * (r - amplitude * p) ** 2)
    )
    return improvement, amplitude


def main() -> None:
    data = np.genfromtxt(".tmp/physical_fit.csv", delimiter=",", names=True)
    x = data["two_theta_deg"]
    residual = data["difference"]
    observed = data["observed"]
    crystalline = data["calculated"] - data["background"]
    weight = 1.0 / np.maximum(observed, 1.0)
    all_mask = np.ones_like(x, dtype=bool)
    residual_mask = crystalline < 150.0

    with gzip.open(INDEX, "rt") as handle:
        index = json.load(handle)
    keys = ["O-Sr-W", "C-O-Sr", "O-W", "O-Sr"]
    records: list[tuple[str, str, Path]] = []
    for key in keys:
        for formula, cod_id, _sg, _r in index.get(key, []):
            records.append((formula, cod_id, cod_path(cod_id)))
    for path in sorted(Path(".tmp/analogues").glob("*.cif")):
        records.append((path.stem, path.stem, path))

    calculator = XRDCalculator(wavelength=LAMBDA1, symprec=0.05)
    results = []
    for formula, identifier, path in records:
        try:
            structure = Structure.from_file(path)
            pattern = calculator.get_pattern(
                structure, two_theta_range=(8.0, 105.0), scaled=True
            )
            base_pos = np.asarray(pattern.x)
            base_int = np.asarray(pattern.y)
        except Exception as exc:
            print(f"SKIP {identifier}: {type(exc).__name__}: {exc}")
            continue
        best_full = (-np.inf, 0.0, 1.0)
        best_resid = (-np.inf, 0.0, 1.0)
        for scale in np.linspace(0.94, 1.06, 49):
            profile = profile_for_scale(x, base_pos, base_int, float(scale))
            full = score_profile(profile, residual, weight, all_mask)
            resid = score_profile(profile, residual, weight, residual_mask)
            if full[0] > best_full[0]:
                best_full = (full[0], full[1], float(scale))
            if resid[0] > best_resid[0]:
                best_resid = (resid[0], resid[1], float(scale))
        results.append((best_resid[0], best_full[0], formula, identifier,
                        best_resid[2], best_full[2]))

    print("\nTOP RESIDUAL-ONLY CANDIDATES")
    for row in sorted(results, reverse=True)[:30]:
        print(f"{row[2]:24s} {row[3]:32s} residual={row[0]:12.3f} full={row[1]:12.3f} scales={row[4]:.4f}/{row[5]:.4f}")
    print("\nTOP FULL-PATTERN RESIDUAL CANDIDATES")
    for row in sorted(results, key=lambda item: item[1], reverse=True)[:30]:
        print(f"{row[2]:24s} {row[3]:32s} residual={row[0]:12.3f} full={row[1]:12.3f} scales={row[4]:.4f}/{row[5]:.4f}")


if __name__ == "__main__":
    main()
