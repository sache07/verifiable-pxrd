#!/usr/bin/env python3
"""Run a controlled GSAS-II refinement from an existing checkpoint.

This helper explicitly clears every refinement flag first.  That is useful for
model-selection trials, where each output should differ from its common parent
only by the parameters requested on the command line.
"""

from __future__ import annotations

import argparse
import json

import GSASIIscriptable as G2sc


def clear_all(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    # Do these in separate calls: GSAS-II's Background clear path returns
    # immediately and otherwise skips later dictionary entries.
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({
        "Sample Parameters": [
            "Scale", "Absorption", "DisplaceX", "DisplaceY", "Shift",
            "Transparency", "SurfRoughA", "SurfRoughB",
        ]
    })
    hist.clear_refinements({
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""
        phase.clear_HAP_refinements({
            "Scale": True,
            "Size": True,
            "Mustrain": True,
            "HStrain": True,
            "Pref.Ori.": True,
        })


def parse_indices(text: str, count: int) -> list[int]:
    if not text:
        return []
    if text.lower() == "all":
        return list(range(count))
    return [int(item) for item in text.split(",")]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--cells", default="")
    parser.add_argument("--sizes", default="")
    parser.add_argument("--coords", default="")
    parser.add_argument("--uiso", default="")
    parser.add_argument("--po-phase", type=int)
    parser.add_argument("--po-axis", default="1,1,1")
    parser.add_argument("--sample", action="store_true")
    parser.add_argument("--shift", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--passes", type=int, default=2)
    parser.add_argument("--cycles", type=int, default=12)
    args = parser.parse_args()

    project = G2sc.G2Project(args.base, newgpx=args.output)
    hist = project.histogram(0)
    phases = project.phases()
    clear_all(project)

    hist.set_refinements({"Background": {"refine": True, "no. coeffs": 10}})
    sample_parameters = []
    if args.sample or args.shift:
        sample_parameters.append("Shift")
    if args.sample or args.roughness:
        sample_parameters.extend(["SurfRoughA", "SurfRoughB"])
    if sample_parameters:
        hist.set_refinements({"Sample Parameters": sample_parameters})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    for index in parse_indices(args.cells, len(phases)):
        phases[index].set_refinements({"Cell": True})
    for index in parse_indices(args.sizes, len(phases)):
        phases[index].set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True}
        })
    for index in parse_indices(args.coords, len(phases)):
        phases[index].set_refinements({"Atoms": {"all": "X"}})
    for index in parse_indices(args.uiso, len(phases)):
        for atom in phases[index].atoms():
            atom.refinement_flags += "U"
    if args.po_phase is not None:
        target = phases[args.po_phase]
        po = target.getHAPvalues(hist)["Pref.Ori."]
        po[0] = "MD"
        po[2] = True
        po[3] = [int(value) for value in args.po_axis.split(",")]

    project.set_Controls("cycles", args.cycles)
    project.save()
    for _ in range(args.passes):
        project.refine()
    project.save()

    result = {
        "wR": hist.get_wR(),
        "R": hist.data["data"][0].get("R"),
        "mass_fractions": hist.ComputeMassFracs(),
        "varyList": project["Covariance"]["data"].get("varyList", []),
        "phases": {},
    }
    for phase in phases:
        hap = phase.getHAPvalues(hist)
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "preferred_orientation": hap["Pref.Ori."],
            "atom_flags": [atom.refinement_flags for atom in phase.atoms()],
        }
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
