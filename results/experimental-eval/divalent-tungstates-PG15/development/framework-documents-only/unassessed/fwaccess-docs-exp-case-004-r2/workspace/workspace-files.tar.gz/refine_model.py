from pathlib import Path
import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summarize(tag, project, histogram, phases):
    print(f"\n===== {tag} =====")
    print("residuals", json.dumps(histogram.data["data"][0], default=str, sort_keys=True))
    print("instrument", {
        k: v[1] for k, v in histogram.data["Instrument Parameters"][0].items()
        if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "I(L2)/I(L1)")
    })
    print("sample", {
        k: v[0] for k, v in histogram.data["Sample Parameters"].items()
        if k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")
    })
    for phase in phases:
        hap = phase.getHAPvalues(histogram)
        print(phase.name, "cell", phase.get_cell())
        print(phase.name, "scale", hap["Scale"], "size", hap["Size"], "mustrain", hap["Mustrain"], "PO", hap["Pref.Ori."])
    try:
        print("mass_fractions", histogram.ComputeMassFracs())
    except Exception as exc:
        print("mass_fractions unavailable", repr(exc))


def run_refinement(project, histogram, phases, tag):
    project.refine()
    summarize(tag, project, histogram, phases)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--output", default="model.gpx")
    args = parser.parse_args()

    output = ROOT / args.output
    project = G2sc.G2Project(newgpx=str(output))
    project.set_Controls("cycles", 12)
    histogram = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "lab_cuka.instprm"),
    )
    histogram.set_refinements({
        "Limits": [9.95, 100.05],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 20,
        },
    })

    # Keep one phase scale fixed and vary the specimen scale plus the other
    # phase scale. This avoids the all-scales singularity while retaining the
    # relative scale needed for quantitative phase analysis.
    histogram.data["Sample Parameters"]["Scale"][1] = True
    cobalt_tungstate = project.add_phase(
        str(ROOT / "starting_cowo4.cif"),
        phasename="CoWO4",
        histograms=[histogram],
        fmthint="CIF",
    )
    tungsten_oxide = project.add_phase(
        str(cod_path(args.wo3)),
        phasename=f"WO3_{args.wo3}",
        histograms=[histogram],
        fmthint="CIF",
    )
    phases = [cobalt_tungstate, tungsten_oxide]
    for var, low, high in (
        (":0:Zero", -0.30, 0.30),
        (":0:U", 0.0, 50.0),
        (":0:W", 1.0, 50.0),
        (":0:X", 0.0, 8.0),
        (":0:SH/L", 0.002, 0.15),
        (":0:Shift", -800.0, 800.0),
    ):
        project.set_Controls("parmMin", low, var)
        project.set_Controls("parmMax", high, var)
    for phase in phases:
        pid = phase.data["pId"]
        for suffix, low, high in (
            ("Size;i", 0.02, 5.0),
            ("Mustrain;i", 0.0, 10000.0),
        ):
            var = f"{pid}:0:{suffix}"
            project.set_Controls("parmMin", low, var)
            project.set_Controls("parmMax", high, var)
    cobalt_tungstate.HAPvalue("Scale", 1.0)
    tungsten_oxide.HAPvalue("Scale", 0.25)
    cobalt_tungstate.clear_HAP_refinements({"Scale": True})
    tungsten_oxide.clear_HAP_refinements({"Scale": True})

    # Start with physically plausible specimen broadening, but do not vary it
    # until common instrumental terms have stabilized.
    for phase in phases:
        hap = phase.getHAPvalues(histogram)
        hap["Size"][1][0] = 0.20
        hap["Mustrain"][1][0] = 3000.0
        for atom in phase.atoms():
            atom.uiso = 0.01

    inst = histogram.data["Instrument Parameters"][0]
    inst["Zero"][1] = 0.04
    inst["U"][1] = 15.0
    inst["W"][1] = 25.0
    inst["X"][1] = 2.0

    run_refinement(project, histogram, phases, "scale/background")

    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_refinement(project, histogram, phases, "cells/zero")

    tungsten_oxide.set_HAP_refinements({"Scale": True})
    run_refinement(project, histogram, phases, "relative phase scale")

    histogram.set_refinements({
        "Instrument Parameters": ["U", "W", "X", "SH/L"],
    })
    run_refinement(project, histogram, phases, "common profile")

    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    run_refinement(project, histogram, phases, "phase broadening")

    # The source structures are close structural relatives of the expected
    # products. Refine symmetry-allowed coordinates after the profile and
    # lattice have converged.
    for phase in phases:
        phase.set_refinements({"Atoms": {"all": "X"}})
    run_refinement(project, histogram, phases, "atomic coordinates")

    # Separate the nearly collinear angular zero and specimen-displacement
    # corrections: hold the converged zero and then refine displacement.
    histogram.clear_refinements({"Instrument Parameters": ["Zero"]})
    histogram.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(project, histogram, phases, "specimen displacement")

    project.save(str(output))

    # Save a diagnostic profile without changing the project.
    x = np.asarray(histogram.getdata("x"))
    yobs = np.asarray(histogram.getdata("yobs"))
    ycalc = np.asarray(histogram.getdata("ycalc"))
    ybkg = np.asarray(histogram.getdata("background"))
    np.savetxt(
        ROOT / (output.stem + "_fit.csv"),
        np.column_stack((x, yobs, ycalc, yobs - ycalc, ybkg)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )


if __name__ == "__main__":
    main()
