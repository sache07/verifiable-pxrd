from pathlib import Path
import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def parse_axis(text):
    axis = tuple(int(v) for v in text.split(","))
    if len(axis) != 3:
        raise ValueError("axis must contain three comma-separated integers")
    return axis


def summary(project, histogram):
    print("wR", histogram.get_wR())
    print("residuals", json.dumps(histogram.data["data"][0], default=str, sort_keys=True))
    print("fractions", histogram.ComputeMassFracs())
    print("instrument", {
        k: v[1] for k, v in histogram.data["Instrument Parameters"][0].items()
        if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "I(L2)/I(L1)")
    })
    print("sample", {
        k: v[0] for k, v in histogram.data["Sample Parameters"].items()
        if k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")
    })
    for phase in project.phases():
        hap = phase.getHAPvalues(histogram)
        print(phase.name, "cell", phase.get_cell())
        print(phase.name, "size", hap["Size"], "mustrain", hap["Mustrain"], "PO", hap["Pref.Ori."])
        print(phase.name, "atoms", [
            (a.label, a.element, tuple(round(v, 6) for v in a.coordinates), round(a.uiso, 6), a.refinement_flags)
            for a in phase.atoms()
        ])


def save_profile(output, histogram):
    data = np.column_stack([
        histogram.getdata("x"),
        histogram.getdata("yobs"),
        histogram.getdata("ycalc"),
        histogram.getdata("residual"),
        histogram.getdata("background"),
    ])
    np.savetxt(
        output.with_name(output.stem + "_fit.csv"), data, delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background", comments="",
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("action", choices=(
        "physical", "heavy", "uiso", "roughness", "po", "size", "mustrain", "oxygen", "all_coords",
    ))
    parser.add_argument("--phase")
    parser.add_argument("--axis", default="0,0,1")
    args = parser.parse_args()

    output = ROOT / args.output
    project = G2sc.G2Project(str(ROOT / args.input))
    project.save(str(output))
    project.set_Controls("cycles", 10)
    histogram = project.histograms()[0]
    phases = project.phases()
    phase = project.phase(args.phase) if args.phase else None
    axis = parse_axis(args.axis)

    if args.action == "physical":
        inst = histogram.data["Instrument Parameters"][0]
        for name, low, high in (("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0), ("SH/L", 0.005, 0.10)):
            project.set_Controls("parmMin", low, f":0:{name}")
            project.set_Controls("parmMax", high, f":0:{name}")
            inst[name][1] = min(high, max(low, inst[name][1]))
        for ph in phases:
            pid = ph.data["pId"]
            for suffix, low, high in (("Size;i", 0.04, 2.0), ("Mustrain;i", 0.0, 8000.0)):
                project.set_Controls("parmMin", low, f"{pid}:0:{suffix}")
                project.set_Controls("parmMax", high, f"{pid}:0:{suffix}")
                hap = ph.getHAPvalues(histogram)
                key = "Size" if suffix.startswith("Size") else "Mustrain"
                hap[key][1][0] = min(high, max(low, hap[key][1][0]))
        project.refine()
        # Angular zero and specimen shift are almost collinear. Retain the
        # converged zero, then determine the displacement with zero held.
        histogram.clear_refinements({"Instrument Parameters": ["Zero"]})
        histogram.set_refinements({"Sample Parameters": ["Shift"]})
        project.refine()

    elif args.action == "heavy":
        for ph in phases:
            for atom in ph.atoms():
                atom.refinement_flags = "X" if atom.element in ("W", "Co") else " "
        project.refine()

    elif args.action == "uiso":
        for ph in phases:
            pid = ph.data["pId"]
            variables = []
            for i, atom in enumerate(ph.atoms()):
                atom.refinement_flags = "U"
                variable = f"{pid}::AUiso:{i}"
                variables.append(variable)
                project.set_Controls("parmMin", 0.001, variable)
                project.set_Controls("parmMax", 0.03, variable)
            project.add_EquivConstr(variables)
        project.refine()

    elif args.action == "roughness":
        sample = histogram.data["Sample Parameters"]
        sample["SurfRoughA"][0] = 0.2
        sample["SurfRoughB"][0] = 0.1
        histogram.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        project.refine()

    elif args.action == "po":
        if phase is None:
            raise ValueError("--phase is required")
        po = phase.getHAPvalues(histogram)["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[3] = list(axis)
        phase.set_HAP_refinements({"Pref.Ori.": True})
        project.set_Controls("parmMin", 0.5, f"{phase.data['pId']}:0:MD")
        project.set_Controls("parmMax", 2.0, f"{phase.data['pId']}:0:MD")
        project.refine()

    elif args.action in ("size", "mustrain"):
        if phase is None:
            raise ValueError("--phase is required")
        hap = phase.getHAPvalues(histogram)
        if args.action == "size":
            value = max(0.05, hap["Size"][1][0])
            phase.setSampleProfile(histogram, "size", "uniaxial", value, value, axis=axis)
            phase.set_HAP_refinements({"Size": {"type": "uniaxial", "refine": True, "direction": axis}})
        else:
            value = max(300.0, hap["Mustrain"][1][0])
            phase.setSampleProfile(histogram, "microstrain", "uniaxial", value, value, axis=axis)
            phase.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "refine": True, "direction": axis}})
        project.refine()

    elif args.action in ("oxygen", "all_coords"):
        if phase is None:
            raise ValueError("--phase is required")
        for atom in phase.atoms():
            if args.action == "all_coords" or atom.element == "O":
                atom.refinement_flags = "X"
        project.refine()

    project.save(str(output))
    save_profile(output, histogram)
    summary(project, histogram)


if __name__ == "__main__":
    main()
