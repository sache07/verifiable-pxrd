from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
WO3_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/89/1528915.cif"
)

gpx = G2sc.G2Project(newgpx=str(ROOT / "trial.gpx"))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs/pattern.csv"),
    str(ROOT / "lab_cuka.instprm"),
)
cowo4 = gpx.add_phase(
    str(ROOT / "starting_cowo4.cif"),
    phasename="CoWO4",
    histograms=[hist],
    fmthint="CIF",
)
wo3 = gpx.add_phase(
    str(WO3_CIF),
    phasename="WO3",
    histograms=[hist],
    fmthint="CIF",
)

print("histogram", hist.name)
print("range", hist.data["Limits"])
print("arrays", [len(v) for v in hist.data["data"][1]])
print("instrument", hist.data["Instrument Parameters"][0])
print("sample", hist.data["Sample Parameters"])
print("background", hist.data["Background"])
for phase in (cowo4, wo3):
    print("phase", phase.name, phase.get_cell())
    print("atoms")
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.occupancy, atom.uiso)
    print("HAP", json.dumps(phase.getHAPvalues(hist), default=str, indent=2))

gpx.save()
