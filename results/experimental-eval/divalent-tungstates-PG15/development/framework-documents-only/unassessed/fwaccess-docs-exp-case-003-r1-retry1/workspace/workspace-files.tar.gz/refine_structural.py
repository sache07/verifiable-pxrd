#!/usr/bin/env python3
"""Targeted structural continuation of the selected three-phase model."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", type=Path, default=Path(".tmp/combined.gpx"))
    ap.add_argument("--output", type=Path, default=Path(".tmp/structural.gpx"))
    ap.add_argument("--cycles", type=int, default=12)
    ap.add_argument("--wo-coordinates", choices=["fixed", "heavy", "all"], default="all")
    ap.add_argument("--fix-shl", action="store_true")
    ap.add_argument("--keep-surface", action="store_true")
    ap.add_argument("--convergence", type=float, default=1e-7)
    ap.add_argument("--refine-scheelite-o", action="store_true")
    ap.add_argument("--restrain-scheelite", action="store_true")
    ap.add_argument("--restraint-weight", type=float, default=20.0)
    ap.add_argument("--restraint-esd", type=float, default=0.04)
    args = ap.parse_args()

    if args.output.exists():
        args.output.unlink()
    gpx = G2sc.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    gpx.set_Controls("cycles", args.cycles)
    gpx.data["Controls"]["data"]["min dM/M"] = args.convergence
    gpx.set_Frozen()
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    # Remove the two statistically singular corrections that had approached
    # their no-correction limits. Keep specimen displacement fixed so that it
    # is not 99% correlated with the constant zero term.
    sample["Shift"][1] = False
    if args.keep_surface:
        sample["SurfRoughA"][1] = False
        sample["SurfRoughB"][1] = False
    else:
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.0, False]
    inst["Polariz."][1:3] = [1.0, False]
    inst["Zero"][2] = True
    if args.fix_shl:
        inst["SH/L"][2] = False

    wo3, cawo4, calcite = gpx.phases()
    # The major WO3 phase supports refinement of all symmetry-independent
    # coordinates. The scheelite oxygen coordinate is optional and can be
    # stabilized with a W-O restraint. The single carbonate coordinate is
    # well conditioned and remains refined.
    for atom in wo3.atoms():
        refine_xyz = args.wo_coordinates == "all" or (
            args.wo_coordinates == "heavy" and atom.element == "W"
        )
        atom.refinement_flags = "XU" if refine_xyz else "U"
    for atom in cawo4.atoms():
        atom.refinement_flags = "U"
    if args.refine_scheelite_o:
        cawo4.atom("O1").refinement_flags = "XU"
    for atom in calcite.atoms():
        atom.refinement_flags = "U"
    calcite.atom("O1").refinement_flags = "XU"

    if args.restrain_scheelite:
        restraints = gpx.data["Restraints"]["data"]
        restraints.setdefault(cawo4.name, {})
        restraints[cawo4.name].setdefault(
            "Bond", {"wtFactor": 1.0, "Range": 1.1, "Bonds": [], "Use": True}
        )
        cawo4.clearDistRestraint()
        count = cawo4.addDistRestraint(
            [a for a in cawo4.atoms() if a.element == "W"],
            [a for a in cawo4.atoms() if a.element == "O"],
            1.763,
            factor=1.25,
            ESD=args.restraint_esd,
        )
        cawo4.setDistRestraintWeight(args.restraint_weight)
        print("scheelite W-O restraints added", count)

    # Broad but positive ADP bounds guard against a coordinate/temperature
    # factor runaway without forcing the minor phases to a boundary.
    for phase in gpx.phases():
        for i, atom in enumerate(phase.atoms()):
            gpx.set_Controls("parmMin", 0.0005, variable=f"{phase.id}::AUiso:{i}")
            gpx.set_Controls("parmMax", 0.08, variable=f"{phase.id}::AUiso:{i}")
    gpx.save()

    for passno in range(2):
        gpx.refine(makeBack=False)
        h = gpx.histogram(0)
        rv = gpx.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        print(
            "PASS",
            passno + 1,
            "Rwp",
            h.get_wR(),
            "mass",
            h.ComputeMassFracs(),
            "converged",
            rv.get("converged"),
            "frozen",
            gpx.get_Frozen(),
        )
        # A second pass recomputes the profile after a parameter has been
        # clamped. Parameters reaching a bound are fixed explicitly.
        for var in list(gpx.get_Frozen()):
            if var == ":0:Polariz.":
                inst = gpx.histogram(0).data["Instrument Parameters"][0]
                inst["Polariz."][2] = False
            elif var == ":0:SurfRoughA":
                gpx.histogram(0).data["Sample Parameters"]["SurfRoughA"][1] = False
        gpx.set_Frozen()
        gpx.save()

    for phase in gpx.phases():
        phase.export_CIF(str(args.output.with_name(f"{args.output.stem}_{phase.name}.cif")))
    gpx.save()


if __name__ == "__main__":
    main()
