#!/usr/bin/env python3
"""Build and compare physically bounded GSAS-II profile-model variants.

This is an analysis helper.  Each output is a complete project cloned from
the selected three-phase refinement, with a discrete strain/texture model and
fixed instrumental U/X values.  Holding U/X during a scan removes the nearly
singular trade-off between instrumental and phase broadening.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def set_bounds(gpx: G2sc.G2Project, var: str, lo: float, hi: float) -> None:
    gpx.set_Controls("parmMin", lo, variable=var)
    gpx.set_Controls("parmMax", hi, variable=var)


def at_boundary(value: float, lo: float, hi: float) -> bool:
    tol = 1e-7 * max(1.0, abs(lo), abs(hi))
    return value <= lo + tol or value >= hi - tol


def freeze_profile_boundaries(gpx: G2sc.G2Project) -> list[str]:
    """Fix profile variables that have reached their stated physical bounds."""
    hist = gpx.histogram(0)
    fixed: list[str] = []
    inst = hist.data["Instrument Parameters"][0]
    for key, lo, hi in [
        ("W", 2.0, 40.0),
        ("SH/L", 0.005, 0.10),
        ("Polariz.", 0.5, 1.0),
    ]:
        if inst[key][2] and at_boundary(inst[key][1], lo, hi):
            inst[key][2] = False
            fixed.append(f":0:{key}")
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        if hap["Size"][2][0] and at_boundary(hap["Size"][1][0], 0.04, 1.5):
            hap["Size"][2][0] = False
            fixed.append(f"{phase.id}:0:Size;i")
        for i, suffix in enumerate(("i", "a")):
            if hap["Mustrain"][2][i] and at_boundary(hap["Mustrain"][1][i], 0.0, 8000.0):
                hap["Mustrain"][2][i] = False
                fixed.append(f"{phase.id}:0:Mustrain;{suffix}")
        po = hap["Pref.Ori."]
        if po[2] and at_boundary(po[1], 0.7, 1.4):
            po[2] = False
            fixed.append(f"{phase.id}:0:MD")
    gpx.set_Frozen()
    return fixed


def configure(
    source: Path,
    output: Path,
    u_value: float,
    x_value: float,
    wo_axis: tuple[int, int, int],
    ca_strain: str,
    cc_strain: str,
    ca_po: tuple[int, int, int] | None,
    cc_po: tuple[int, int, int] | None,
    cycles: int,
) -> G2sc.G2Project:
    if output.exists():
        output.unlink()
    gpx = G2sc.G2Project(gpxfile=str(source), newgpx=str(output))
    gpx.set_Controls("cycles", cycles)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    gpx.set_Frozen()
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    # A stable calibration parameterization: zero absorbs the common angular
    # shift while phase cells account for phase-specific reference mismatch.
    sample["Shift"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst["U"][1:3] = [float(u_value), False]
    inst["X"][1:3] = [float(x_value), False]
    for key in ("W", "SH/L", "Zero", "Polariz."):
        inst[key][2] = True
    for key in ("V", "Y", "Z"):
        inst[key][2] = False
    for var, lo, hi in [
        (":0:W", 2.0, 40.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Zero", -1.0, 1.0),
        (":0:Polariz.", 0.5, 1.0),
    ]:
        set_bounds(gpx, var, lo, hi)

    wo3, cawo4, calcite = gpx.phases()
    for phase in (wo3, cawo4, calcite):
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = min(1.5, max(0.04, hap["Size"][1][0]))
        hap["Size"][2][0] = True
        set_bounds(gpx, f"{phase.id}:0:Size;i", 0.04, 1.5)

    # Use the strongest allowed uniaxial-strain candidate for monoclinic WO3.
    wh = wo3.data["Histograms"][hist.name]
    wh["Mustrain"][1][0:2] = [5000.0, 3400.0]
    wo3.set_HAP_refinements({
        "Mustrain": {"type": "uniaxial", "direction": list(wo_axis), "refine": True}
    })

    def set_strain(phase, model: str) -> None:
        hap = phase.data["Histograms"][hist.name]
        if model == "none":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2][0] = False
        elif model == "iso":
            hap["Mustrain"][1][0] = min(8000.0, max(300.0, hap["Mustrain"][1][0]))
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        else:
            axis = tuple(int(v) for v in model)
            hap["Mustrain"][1][0:2] = [3000.0, 3000.0]
            phase.set_HAP_refinements({
                "Mustrain": {"type": "uniaxial", "direction": list(axis), "refine": True}
            })

    set_strain(cawo4, ca_strain)
    set_strain(calcite, cc_strain)
    for phase in (wo3, cawo4, calcite):
        for suffix in ("i", "a"):
            set_bounds(gpx, f"{phase.id}:0:Mustrain;{suffix}", 0.0, 8000.0)

    def set_po(phase, axis: tuple[int, int, int] | None) -> None:
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        if axis is None:
            po[0:4] = ["MD", 1.0, False, [0, 0, 1]]
        else:
            po[0:4] = ["MD", 1.05, True, list(axis)]
            set_bounds(gpx, f"{phase.id}:0:MD", 0.7, 1.4)

    set_po(cawo4, ca_po)
    set_po(calcite, cc_po)
    # WO3 texture was statistically negligible in the one-axis scans.
    set_po(wo3, None)

    # Hold common isotropic displacement factors at a conservative value while
    # selecting the line-profile model. Retain only supported coordinates.
    for phase in (wo3, cawo4, calcite):
        for atom in phase.atoms():
            if atom.adp_flag == "I":
                atom.uiso = 0.010
            atom.refinement_flags = ""
    for atom in wo3.atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"
    calcite.atom("O1").refinement_flags = "X"

    gpx.save()
    return gpx


def run_one(args, output: Path, u_value: float, x_value: float) -> tuple[float, dict]:
    parse_axis = lambda s: tuple(int(v) for v in s)
    parse_po = lambda s: None if s == "none" else parse_axis(s)
    gpx = configure(
        args.source,
        output,
        u_value,
        x_value,
        parse_axis(args.wo_axis),
        args.ca_strain,
        args.cc_strain,
        parse_po(args.ca_po),
        parse_po(args.cc_po),
        args.cycles,
    )
    # Two passes allow the cell/intensity and line-profile blocks to settle.
    gpx.refine(makeBack=False)
    fixed = freeze_profile_boundaries(gpx)
    gpx.save()
    gpx.refine(makeBack=False)
    fixed.extend(freeze_profile_boundaries(gpx))
    gpx.save()
    hist = gpx.histogram(0)
    return hist.get_wR(), {
        "mass": hist.ComputeMassFracs(),
        "fixed": sorted(set(fixed)),
        "converged": gpx.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("converged"),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=Path(".tmp/atomic_phys.gpx"))
    parser.add_argument("--outdir", type=Path, default=Path(".tmp/profile_grid"))
    parser.add_argument("--u", default="0,10,20,30,40")
    parser.add_argument("--x", default="0.1,1,3,6")
    parser.add_argument("--wo-axis", choices=["001", "010", "100", "110"], default="010")
    parser.add_argument("--ca-strain", choices=["none", "iso", "001", "010", "100"], default="none")
    parser.add_argument("--cc-strain", choices=["none", "iso", "001", "010", "100"], default="iso")
    parser.add_argument("--ca-po", choices=["none", "001", "010", "100", "110", "111"], default="111")
    parser.add_argument("--cc-po", choices=["none", "001", "010", "100", "110", "111"], default="111")
    parser.add_argument("--cycles", type=int, default=10)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    rows = []
    for u_value in [float(v) for v in args.u.split(",")]:
        for x_value in [float(v) for v in args.x.split(",")]:
            output = args.outdir / f"u{u_value:g}_x{x_value:g}.gpx"
            rwp, details = run_one(args, output, u_value, x_value)
            rows.append((rwp, u_value, x_value, output, details))
            print(f"SCAN Rwp={rwp:.8f} U={u_value:g} X={x_value:g} file={output} details={details}")
    print("RANKING")
    for row in sorted(rows):
        print(row)


if __name__ == "__main__":
    main()
