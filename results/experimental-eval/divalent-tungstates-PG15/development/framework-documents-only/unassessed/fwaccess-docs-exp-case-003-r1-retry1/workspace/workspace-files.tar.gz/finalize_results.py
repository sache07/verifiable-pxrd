#!/usr/bin/env python3
"""Export the required deliverables from one immutable GSAS-II model."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "scheelite_tight.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "WO3": {
        "name": "monoclinic tungsten(VI) oxide",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif": "phase_1_WO3_monoclinic.cif",
        "reference": "COD 2311041",
    },
    "CaWO4": {
        "name": "scheelite calcium tungstate",
        "formula": "CaWO4",
        "space_group": "I 41/a",
        "cif": "phase_2_CaWO4_scheelite.cif",
        "reference": "COD 7219229",
    },
    "CaCO3_calcite": {
        "name": "calcite calcium carbonate",
        "formula": "CaCO3",
        "space_group": "R -3 c",
        "cif": "phase_3_CaCO3_calcite.cif",
        "reference": "COD 1547347",
    },
}


def main() -> None:
    if not SOURCE.exists():
        raise FileNotFoundError(SOURCE)
    if FINAL.exists():
        FINAL.unlink()

    # Cloning through GSAS-II, rather than a byte copy, records final.gpx as
    # the active save target while preserving the exact refined tree/arrays.
    project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    project.save()
    hist = project.histogram(0)
    if len(project.histograms()) != 1:
        raise RuntimeError("Expected exactly one powder histogram")

    mass = hist.ComputeMassFracs()
    total = sum(v[0] for v in mass.values())
    if not math.isclose(total, 1.0, rel_tol=0, abs_tol=1e-10):
        raise RuntimeError(f"Mass fractions do not normalize: {total}")

    phases_json = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        cif_path = ROOT / info["cif"]
        phase.export_CIF(str(cif_path))
        wf, esd = mass[phase.name]
        cell = phase.get_cell()
        phases_json.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "space_group": info["space_group"],
                "cif_path": info["cif"],
                "weight_fraction": float(wf),
                "weight_percent": float(100.0 * wf),
                "weight_fraction_esd_formal": float(esd),
                "reference_structure": info["reference"],
                "unit_cell": {
                    "a_angstrom": float(cell["length_a"]),
                    "b_angstrom": float(cell["length_b"]),
                    "c_angstrom": float(cell["length_c"]),
                    "alpha_deg": float(cell["angle_alpha"]),
                    "beta_deg": float(cell["angle_beta"]),
                    "gamma_deg": float(cell["angle_gamma"]),
                    "volume_angstrom3": float(cell["volume"]),
                },
            }
        )

    x, obs, weights, calc, background, difference = (
        np.asarray(a, dtype=float) for a in hist.data["data"][1]
    )
    if not np.allclose(difference, obs - calc, rtol=0, atol=1e-8):
        raise RuntimeError("GSAS-II difference array is not observed-calculated")
    with (ROOT / "fit.csv").open("w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(
            ["two_theta_deg", "observed_counts", "calculated_counts", "difference_counts", "background_counts"]
        )
        for row in zip(x, obs, calc, difference, background):
            writer.writerow([f"{row[0]:.8f}", *(f"{v:.8f}" for v in row[1:])])

    data_chi2 = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * obs**2))
    rwp = 100.0 * math.sqrt(data_chi2 / denominator)
    rp = 100.0 * float(np.sum(np.abs(difference)) / np.sum(np.abs(obs)))
    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    nobs = int(rvals["Nobs"])
    nvars = int(rvals["Nvars"])
    dof = nobs - nvars
    reduced_chi2 = data_chi2 / dof
    gof = math.sqrt(reduced_chi2)
    rexp = rwp / gof

    result = {
        "schema_version": 1,
        "project_path": "final.gpx",
        "refinement_histogram": hist.name,
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over the three modeled crystalline phases; no amorphous fraction or external standard",
        "phases": phases_json,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": rexp,
            "goodness_of_fit": gof,
            "chi_square_data": data_chi2,
            "reduced_chi_square_data": reduced_chi2,
            "poisson_Rwp_min_percent": float(hist.residuals["wRmin"]),
            "n_profile_points": nobs,
            "n_refined_parameters": nvars,
            "n_distance_restraints": int(rvals.get("nRestraints", {}).get("Bond", 0)),
            "distance_restraint_penalty": float(rvals.get("RestraintSum", 0.0)),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_over_esd": float(rvals.get("Max shft/sig", float("nan"))),
        },
    }
    with (ROOT / "result.json").open("w") as fp:
        json.dump(result, fp, indent=2, allow_nan=False)
        fp.write("\n")

    project.save()
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
