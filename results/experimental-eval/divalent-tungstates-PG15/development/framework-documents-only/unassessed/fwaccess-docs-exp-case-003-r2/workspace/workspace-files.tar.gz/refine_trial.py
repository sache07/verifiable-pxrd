#!/usr/bin/env python3
"""Build and refine trial GSAS-II models for the CaCO3/WO3 pattern."""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_xye(path: Path) -> None:
    rows = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    x = rows["two_theta_deg"]
    y = rows["intensity"]
    # No point uncertainties were supplied. Counts are Poisson-distributed in
    # the measurement model, so sigma=sqrt(counts) is the defensible weighting.
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(path, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")


def rwp(project: G2sc.G2Project) -> float:
    return float(project.histogram(0).get_wR())


def refine(project: G2sc.G2Project, label: str) -> None:
    project.save()
    project.do_refinements([{}])
    print(f"STAGE {label:24s} Rwp={rwp(project):.6f}")


def set_atom_uiso(phase, value: float) -> None:
    for atom in phase.atoms():
        if atom.adp_flag == "I":
            atom.uiso = value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tag", required=True)
    parser.add_argument("--wo3", required=True)
    parser.add_argument("--cawo4", default="7219229")
    parser.add_argument("--calcite", default="1547347")
    parser.add_argument("--coordinates", action="store_true")
    parser.add_argument("--uiso", action="store_true")
    parser.add_argument("--shift", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--background-terms", type=int, default=18)
    args = parser.parse_args()

    outdir = ROOT / ".tmp" / "trials"
    outdir.mkdir(parents=True, exist_ok=True)
    xye = outdir / "pattern.xye"
    if not xye.exists():
        write_xye(xye)

    gpx_path = outdir / f"{args.tag}.gpx"
    if gpx_path.exists():
        gpx_path.unlink()
    project = G2sc.G2Project(newgpx=str(gpx_path))
    hist = project.add_powder_histogram(
        str(xye), str(ROOT / "instrument.instprm"), fmthint="xye"
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    # Keep the histogram scale fixed; phase scales carry all quantitative
    # information and refining both creates an exact scale singularity.
    hist.SampleParameters["Scale"][1] = False
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "refine": True,
            }
        }
    )

    phase_specs = [
        ("CaWO4_scheelite", args.cawo4),
        ("WO3_monoclinic", args.wo3),
        ("CaCO3_calcite", args.calcite),
    ]
    phases = []
    for name, cod_id in phase_specs:
        path = cod_path(cod_id)
        if not path.exists():
            raise FileNotFoundError(path)
        phase = project.add_phase(
            str(path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        phases.append(phase)
        set_atom_uiso(phase, 0.01)

    # Stable starting values for phase scale and broadening.
    for phase, initial_scale, initial_size in zip(phases, (0.3, 0.3, 0.3), (0.15, 0.15, 1.0)):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][0] = initial_scale
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = initial_size

    project.save()
    project.set_Controls("cycles", 6)

    # Bring the background, abundances and common position correction into range.
    project.set_refinement(
        {"set": {"Background": True, "Scale": True, "Instrument Parameters": ["Zero"]}}
    )
    refine(project, "background scales zero")

    # Reference cells differ slightly from the measured crystallites.
    project.set_refinement({"set": {"Cell": True}})
    refine(project, "cells")
    refine(project, "cells repeat")

    # The narrow calcite reflections constrain instrumental width; broadening
    # beyond this is then assigned to each phase.
    project.set_refinement(
        {"set": {"Instrument Parameters": ["U", "W", "X", "SH/L"]}}
    )
    refine(project, "instrument profile")
    for phase in phases[:2]:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
    refine(project, "isotropic size")
    for phase in phases[:2]:
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    refine(project, "isotropic strain")
    refine(project, "profile repeat")

    if args.shift:
        # Shift is in micrometres for a 200 mm Bragg-Brentano radius.
        hist.SampleParameters["Shift"][0] = 0.0
        project.set_refinement({"set": {"Sample Parameters": ["Shift"]}})
        refine(project, "specimen shift")
        refine(project, "shift repeat")

    if args.coordinates:
        for phase in phases:
            phase.set_refinements({"Atoms": {"all": "X"}})
            refine(project, f"coordinates {phase.name}")

    if args.uiso:
        # A single isotropic displacement parameter per phase mirrors the
        # measurement model and avoids poorly determined atom-by-atom ADPs.
        project.save()
        for phase in phases:
            pid = phase.id
            atom_vars = [
                f"{pid}::AUiso:{i}"
                for i, atom in enumerate(phase.atoms())
                if atom.adp_flag == "I"
            ]
            if len(atom_vars) > 1:
                project.add_EquivConstr(atom_vars, reloadIdx=False)
            for atom in phase.atoms():
                if atom.adp_flag == "I":
                    atom.refinement_flags = "U"
        refine(project, "phase Uiso")

    if args.roughness:
        sample = hist.SampleParameters
        print("SAMPLE_PARAMETERS", sample)
        for key in ("SurfRoughA", "SurfRoughB"):
            if key in sample:
                project.set_refinement({"set": {"Sample Parameters": [key]}})
        refine(project, "surface roughness")

    refine(project, "final repeat")
    project.save()

    summary = {
        "tag": args.tag,
        "ids": {name: cod_id for name, cod_id in phase_specs},
        "rwp": rwp(project),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list) and len(value) > 1
        },
        "sample": hist.SampleParameters,
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "hap": {
            phase.name: {
                key: phase.data["Histograms"][hist.name][key]
                for key in ("Scale", "Size", "Mustrain", "Pref.Ori.")
            }
            for phase in phases
        },
    }
    with open(outdir / f"{args.tag}.json", "w", encoding="utf-8") as stream:
        json.dump(summary, stream, indent=2, default=float)
    print(json.dumps(summary, indent=2, default=float))


if __name__ == "__main__":
    main()
