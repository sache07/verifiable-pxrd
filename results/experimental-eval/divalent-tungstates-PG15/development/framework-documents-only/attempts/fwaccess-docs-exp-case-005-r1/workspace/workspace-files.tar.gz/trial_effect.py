#!/usr/bin/env python3
"""Test one physically motivated profile/intensity correction on a project copy."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("effect", choices=("po", "strain", "rough", "polar"))
    parser.add_argument("target", nargs="?", default="wo3", choices=("wo3", "co3o4"))
    parser.add_argument("axis", nargs="?", default="001")
    args = parser.parse_args()

    out = Path(args.output).resolve()
    if out.exists():
        out.unlink()
    project = G2sc.G2Project(args.input, newgpx=str(out))
    project.set_Controls("cycles", 18)
    hist = project.histogram(0)
    phase = project.phase("WO3_monoclinic" if args.target == "wo3" else "Co3O4_spinel")
    axis = [int(char) for char in args.axis]

    if args.effect == "po":
        po = phase.getHAPvalues(hist.name)["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = axis
    elif args.effect == "strain":
        strain = phase.getHAPvalues(hist.name)["Mustrain"]
        strain[1][1] = strain[1][0]
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}},
            [hist],
        )
    elif args.effect == "rough":
        hist.SampleParameters["SurfRoughA"] = [0.2, True]
        hist.SampleParameters["SurfRoughB"] = [0.1, True]
    elif args.effect == "polar":
        hist.InstrumentParameters["Polariz."][2] = True

    for idx in range(2):
        project.refine(makeBack=False)
        print(f"cycle_{idx + 1}", hist.residuals)
        print("fractions", hist.ComputeMassFracs())
        print("sample", {k: hist.SampleParameters[k] for k in ("Shift", "SurfRoughA", "SurfRoughB")})
        print("instrument", {k: hist.InstrumentParameters[k] for k in ("Zero", "Polariz.", "W", "SH/L")})
        for item in project.phases():
            hap = item.getHAPvalues(hist.name)
            print(item.name, "PO", hap["Pref.Ori."], "strain", hap["Mustrain"], "size", hap["Size"])
    project.save()


if __name__ == "__main__":
    main()
