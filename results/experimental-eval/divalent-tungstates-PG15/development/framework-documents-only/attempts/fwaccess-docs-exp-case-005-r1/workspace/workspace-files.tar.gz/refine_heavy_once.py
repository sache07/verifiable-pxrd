#!/usr/bin/env python3
"""One restrained-by-judgment coordinate step, followed by a held-coordinate settle."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc


out = Path("candidate_heavy.gpx").resolve()
if out.exists():
    out.unlink()
project = G2sc.G2Project("combined_strain_polar.gpx", newgpx=str(out))
project.set_Controls("cycles", 18)
hist = project.histogram(0)
wo3 = project.phase("WO3_monoclinic")
co3o4 = project.phase("Co3O4_spinel")
wo3.set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
co3o4.set_refinements({"Atoms": {"O": "X"}})
project.refine(makeBack=False)
print("coordinates", hist.residuals, hist.ComputeMassFracs())
for phase in project.phases():
    for atom in phase.atoms():
        print(phase.name, atom.label, atom.coordinates, atom.refinement_flags)

wo3.clear_refinements({"Atoms": ["W1", "W2"]})
co3o4.clear_refinements({"Atoms": ["O"]})
project.refine(makeBack=False)
print("settled", hist.residuals, hist.ComputeMassFracs())
for phase in project.phases():
    hap = phase.getHAPvalues(hist.name)
    print(phase.name, phase.get_cell(), hap["Scale"], hap["Size"], hap["Mustrain"])
project.save()
