#!/usr/bin/env python3
"""Apply controlled refinement experiments to a GSAS-II project copy."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


def set_cell(phase, cell):
    phase.data["General"]["Cell"][1:7] = list(cell)
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def print_summary(project, tag):
    hist = project.histogram(0)
    print(tag, hist.residuals)
    print("fractions", hist.ComputeMassFracs())
    print("sample", {k: hist.SampleParameters[k] for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")})
    print("instrument", {k: hist.InstrumentParameters[k] for k in ("Zero", "Polariz.", "U", "W", "X", "SH/L")})
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        print(phase.name, phase.get_cell(), "scale", hap["Scale"], "size", hap["Size"], "mustrain", hap["Mustrain"], "PO", hap["Pref.Ori."])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("mode", choices=("zero_fixed", "shift_fixed", "geometry_fixed"))
    args = parser.parse_args()

    out = Path(args.output).resolve()
    if out.exists():
        out.unlink()
    project = G2sc.G2Project(args.input, newgpx=str(out))
    project.set_Controls("cycles", 16)
    hist = project.histogram(0)
    wo3 = project.phase("WO3_monoclinic")
    co3o4 = project.phase("Co3O4_spinel")

    set_cell(wo3, (7.69673, 7.53955, 10.54956, 90.0, 136.15472, 90.0))
    set_cell(co3o4, (8.08717, 8.08717, 8.08717, 90.0, 90.0, 90.0))
    wo3.data["General"]["Cell"][0] = True
    co3o4.data["General"]["Cell"][0] = True
    hist.SampleParameters["Shift"] = [-551.4, args.mode != "shift_fixed" and args.mode != "geometry_fixed"]
    hist.InstrumentParameters["Zero"][1:] = [0.0693, args.mode != "zero_fixed" and args.mode != "geometry_fixed"]

    for idx in range(3):
        project.refine(makeBack=False)
        print_summary(project, f"cycle_{idx + 1}")
    project.save()


if __name__ == "__main__":
    main()
