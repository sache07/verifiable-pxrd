#!/usr/bin/env python3
"""Evaluate fixed common isotropic displacement values for each phase."""

import argparse
from pathlib import Path
from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("wo3", type=float)
parser.add_argument("co3o4", type=float)
args = parser.parse_args()

out = Path(args.output).resolve()
if out.exists():
    out.unlink()
project = G2sc.G2Project(args.input, newgpx=str(out))
project.set_Controls("cycles", 18)
hist = project.histogram(0)
for phase, value in ((project.phase("WO3_monoclinic"), args.wo3), (project.phase("Co3O4_spinel"), args.co3o4)):
    for atom in phase.atoms():
        atom.uiso = value
        atom.refinement_flags = atom.refinement_flags.replace("U", "")
for idx in range(2):
    project.refine(makeBack=False)
    print(f"cycle_{idx + 1}", hist.residuals, hist.ComputeMassFracs())
project.save()
