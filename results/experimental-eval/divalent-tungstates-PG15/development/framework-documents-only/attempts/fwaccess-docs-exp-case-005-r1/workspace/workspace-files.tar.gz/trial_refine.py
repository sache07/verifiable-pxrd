#!/usr/bin/env python3
"""Build comparable two-phase GSAS-II trial refinements for WO3 candidates."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summarize(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    out = {
        "stage": label,
        "residuals": hist.residuals,
        "sample": hist.SampleParameters,
        "instrument": hist.InstrumentParameters,
        "phases": {},
    }
    for phase in project.phases():
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "mass": phase.data["General"]["Mass"],
            "hap": phase.getHAPvalues(hist.name),
        }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    print(json.dumps(out, indent=2, default=lambda obj: obj.tolist() if hasattr(obj, "tolist") else str(obj)))
    return out


def refine_once(project: G2sc.G2Project, label: str) -> None:
    project.refine(makeBack=False)
    summarize(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("output")
    parser.add_argument("--co3o4-id", default="9005896")
    args = parser.parse_args()

    output = Path(args.output).resolve()
    if output.exists():
        output.unlink()

    project = G2sc.G2Project(newgpx=str(output))
    project.set_Controls("cycles", 8)
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)

    wo3 = project.add_phase(
        str(cod_path(args.wo3_id)),
        phasename=f"WO3_{args.wo3_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    co3o4 = project.add_phase(
        str(cod_path(args.co3o4_id)),
        phasename=f"Co3O4_{args.co3o4_id}",
        histograms=[hist],
        fmthint="CIF",
    )

    # A negative specimen height shift moves Bragg peaks to larger 2theta.
    hist.SampleParameters["Shift"] = [-600.0, False]
    hist.Background[0] = ["chebyschev-1", False, 15, 3000.0] + [0.0] * 14
    wo3.getHAPvalues(hist.name)["Scale"] = [1.0, False]
    co3o4.getHAPvalues(hist.name)["Scale"] = [0.15, False]

    # Establish background and intensity scales before varying metric/profile terms.
    hist.set_refinements({"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 15}})
    wo3.set_HAP_refinements({"Scale": True}, [hist])
    co3o4.set_HAP_refinements({"Scale": True}, [hist])
    refine_once(project, "background_scales")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    wo3.set_refinements({"Cell": True})
    co3o4.set_refinements({"Cell": True})
    refine_once(project, "cells_shift")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_once(project, "zero_cells_shift")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine_once(project, "instrument_profile")

    wo3.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True}}, [hist])
    co3o4.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True}}, [hist])
    refine_once(project, "phase_size")

    wo3.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    co3o4.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    refine_once(project, "phase_size_strain")

    project.save()


if __name__ == "__main__":
    main()
