#!/usr/bin/env python3
"""Refine selected symmetry-allowed coordinates in an existing GSAS-II project."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def report(project, label):
    hist = project.histogram(0)
    print(label, hist.residuals)
    print("fractions", hist.ComputeMassFracs())
    for phase in project.phases():
        print("phase", phase.name, "cell", phase.get_cell())
        for atom in phase.atoms():
            print("atom", atom.label, atom.element, atom.coordinates, atom.occupancy, atom.ADP, atom.refinement_flags)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("group", choices=("heavy", "oxygen", "all"))
    args = parser.parse_args()

    out = Path(args.output).resolve()
    if out.exists():
        out.unlink()
    project = G2sc.G2Project(args.input, newgpx=str(out))
    project.set_Controls("cycles", 18)
    wo3 = project.phase("WO3_monoclinic")
    co3o4 = project.phase("Co3O4_spinel")

    if args.group in ("heavy", "all"):
        wo3.set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
        co3o4.set_refinements({"Atoms": {"O": "X"}})
    if args.group in ("oxygen", "all"):
        wo3.set_refinements({"Atoms": {name: "X" for name in ("O1", "O2", "O3", "O4", "O5", "O6")}})

    for idx in range(3):
        project.refine(makeBack=False)
        report(project, f"cycle_{idx + 1}")
    project.save()


if __name__ == "__main__":
    main()
