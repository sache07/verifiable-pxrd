#!/usr/bin/env python3
"""Refine only the robust heavy-atom coordinates, then settle the profile."""

from __future__ import annotations

import argparse
from copy import deepcopy
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
args = parser.parse_args()

out = Path(args.output).resolve()
if out.exists():
    out.unlink()
project = G2sc.G2Project(args.input, newgpx=str(out))
project.set_Controls("cycles", 30)
hist = project.histogram(0)
wo3 = project.phase("WO3_monoclinic")
co3o4 = project.phase("Co3O4_spinel")

# Isolate coordinate information from strongly correlated profile and metric terms.
hist.Background[0][1] = False
saved_instrument_flags = {}
for key in hist.InstrumentParameters:
    item = hist.InstrumentParameters[key]
    if isinstance(item, list) and len(item) > 2:
        saved_instrument_flags[key] = item[2]
        item[2] = False
wo3.data["General"]["Cell"][0] = False
co3o4.data["General"]["Cell"][0] = False
saved_hap_flags = {}
for phase in (wo3, co3o4):
    hap = phase.getHAPvalues(hist.name)
    saved_hap_flags[phase.name] = (deepcopy(hap["Size"][2]), deepcopy(hap["Mustrain"][2]))
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]

saved_atom_flags = {
    atom.ranId: atom.refinement_flags
    for phase in (wo3, co3o4)
    for atom in phase.atoms()
}
for phase in (wo3, co3o4):
    for atom in phase.atoms():
        atom.refinement_flags = atom.refinement_flags.replace("U", "")

wo3.set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
co3o4.set_refinements({"Atoms": {"O": "X"}})
project.refine(makeBack=False)
print("coordinate_only", hist.residuals, hist.ComputeMassFracs())
for phase in project.phases():
    for atom in phase.atoms():
        print(phase.name, atom.label, atom.coordinates, atom.refinement_flags)

# Preserve the structural result and settle the complete profile model.
wo3.clear_refinements({"Atoms": ["W1", "W2"]})
co3o4.clear_refinements({"Atoms": ["O"]})
for phase in (wo3, co3o4):
    for atom in phase.atoms():
        atom.refinement_flags = saved_atom_flags[atom.ranId]
hist.Background[0][1] = True
for key, flag in saved_instrument_flags.items():
    hist.InstrumentParameters[key][2] = flag
for phase in (wo3, co3o4):
    phase.data["General"]["Cell"][0] = True
    hap = phase.getHAPvalues(hist.name)
    hap["Size"][2], hap["Mustrain"][2] = saved_hap_flags[phase.name]
for idx in range(2):
    project.refine(makeBack=False)
    print(f"settle_{idx + 1}", hist.residuals, hist.ComputeMassFracs())
project.save()
