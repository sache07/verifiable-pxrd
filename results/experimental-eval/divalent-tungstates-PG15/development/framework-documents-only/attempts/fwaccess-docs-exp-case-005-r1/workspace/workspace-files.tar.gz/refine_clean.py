#!/usr/bin/env python3
"""Build a numerically identifiable two-phase refinement for the selected models."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def set_cell(phase, cell):
    phase.data["General"]["Cell"][1:7] = list(cell)
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def compact(project, stage):
    hist = project.histogram(0)
    data = {
        "stage": stage,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "sample": {k: hist.SampleParameters[k] for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")},
        "instrument": {k: hist.InstrumentParameters[k] for k in ("Zero", "Polariz.", "U", "W", "X", "SH/L")},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        data["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    print(json.dumps(data, indent=2, default=str))


def run(project, stage):
    project.refine(makeBack=False)
    compact(project, stage)


def main():
    out = Path("clean_base.gpx").resolve()
    if out.exists():
        out.unlink()
    project = G2sc.G2Project(newgpx=str(out))
    project.set_Controls("cycles", 12)
    hist = project.add_powder_histogram("inputs/pattern.csv", "instrument.instprm", fmthint="comma")
    hist.Limits("lower", 9.90343322)
    hist.Limits("upper", 100.09455322)

    wo3 = project.add_phase(str(cod_path("2311041")), phasename="WO3_monoclinic", histograms=[hist], fmthint="CIF")
    co3o4 = project.add_phase(str(cod_path("9005896")), phasename="Co3O4_spinel", histograms=[hist], fmthint="CIF")

    # Starts taken from the stable metric/profile portion of the screening fit.
    set_cell(wo3, (7.69673, 7.53955, 10.54956, 90.0, 136.15472, 90.0))
    set_cell(co3o4, (8.08717, 8.08717, 8.08717, 90.0, 90.0, 90.0))
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-551.4, False]
    hist.InstrumentParameters["Zero"][1:] = [0.0693, False]
    hist.InstrumentParameters["U"][1:] = [0.0, False]
    hist.InstrumentParameters["W"][1:] = [12.0, False]
    hist.InstrumentParameters["X"][1:] = [0.1, False]
    hist.InstrumentParameters["SH/L"][1:] = [0.036, False]

    hist.Background[0] = ["chebyschev-1", False, 15, 3000.0] + [0.0] * 14
    wo3.getHAPvalues(hist.name)["Scale"] = [17.0, False]
    co3o4.getHAPvalues(hist.name)["Scale"] = [5.6, False]
    for phase in (wo3, co3o4):
        hap = phase.getHAPvalues(hist.name)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.15
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1200.0
        hap["Mustrain"][2] = [False, False, False]

    hist.set_refinements({"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 15}})
    wo3.set_HAP_refinements({"Scale": True}, [hist])
    co3o4.set_HAP_refinements({"Scale": True}, [hist])
    run(project, "background_scales")

    hist.set_refinements({"Sample Parameters": ["Shift"], "Instrument Parameters": ["Zero"]})
    wo3.set_refinements({"Cell": True})
    co3o4.set_refinements({"Cell": True})
    run(project, "metric")

    hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
    wo3.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}, "Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    co3o4.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}, "Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    run(project, "identifiable_profile")
    run(project, "repeat")
    project.save()


if __name__ == "__main__":
    main()
