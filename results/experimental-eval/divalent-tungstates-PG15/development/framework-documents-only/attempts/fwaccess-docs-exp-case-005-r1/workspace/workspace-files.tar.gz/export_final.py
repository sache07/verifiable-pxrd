#!/usr/bin/env python3
"""Freeze the selected GSAS-II model and export all requested deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE = Path("candidate_010_physfinal.gpx")
FINAL = Path("final.gpx")
WO3_CIF = Path("phase_WO3.cif")
CO3O4_CIF = Path("phase_Co3O4.cif")
FIT = Path("fit.csv")
RESULT = Path("result.json")

for target in (FINAL, WO3_CIF, CO3O4_CIF, FIT, RESULT):
    if target.exists():
        target.unlink()

project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL.resolve()))
project.save()
hist = project.histogram(0)

project.phase("WO3_monoclinic").export_CIF(str(WO3_CIF))
project.phase("Co3O4_spinel").export_CIF(str(CO3O4_CIF))

columns = [
    np.asarray(hist.getdata("X"), dtype=float),
    np.asarray(hist.getdata("Yobs"), dtype=float),
    np.asarray(hist.getdata("Ycalc"), dtype=float),
    np.asarray(hist.getdata("Residual"), dtype=float),
    np.asarray(hist.getdata("Background"), dtype=float),
]
with FIT.open("w", newline="") as stream:
    writer = csv.writer(stream, lineterminator="\n")
    writer.writerow(
        (
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "difference_intensity_obs_minus_calc",
            "background_intensity",
        )
    )
    writer.writerows(zip(*columns))

fractions = hist.ComputeMassFracs()
residuals = hist.residuals
rvals = project.data["Covariance"]["data"]["Rvals"]
phase_rows = (
    ("monoclinic tungsten trioxide", "WO3", "P 1 21/c 1", WO3_CIF, "WO3_monoclinic"),
    ("spinel cobalt oxide", "Co3O4", "F d -3 m", CO3O4_CIF, "Co3O4_spinel"),
)
result = {
    "phases": [
        {
            "name": name,
            "formula": formula,
            "space_group": space_group,
            "cif": str(cif),
            "weight_fraction": fractions[key][0],
            "weight_fraction_standard_uncertainty": fractions[key][1],
        }
        for name, formula, space_group, cif, key in phase_rows
    ],
    "weight_fraction_basis": "normalized over the modeled crystalline phases",
    "fit_statistics": {
        "Rwp_percent": residuals["wR"],
        "Rp_percent": residuals["R"],
        "Rexp_percent": residuals["wRmin"],
        "goodness_of_fit": rvals["GOF"],
        "chi_squared": rvals["chisq"],
        "n_observations": rvals["Nobs"],
        "n_refined_parameters": rvals["Nvars"],
    },
    "profile": str(FIT),
    "gsasii_project": str(FINAL),
}
with RESULT.open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps(result, indent=2))
