#!/usr/bin/env python3
"""Refine heavy-atom coordinates with profile/metric terms temporarily held."""

from copy import deepcopy
from pathlib import Path
from GSASII import GSASIIscriptable as G2sc


out = Path("candidate_heavy_stable.gpx").resolve()
if out.exists():
    out.unlink()
project = G2sc.G2Project("combined_strain_polar.gpx", newgpx=str(out))
project.set_Controls("cycles", 30)
hist = project.histogram(0)
wo3 = project.phase("WO3_monoclinic")
co3o4 = project.phase("Co3O4_spinel")

# Hold terms that otherwise correlate strongly with intensity/position changes.
hist.Background[0][1] = False
for key in hist.InstrumentParameters:
    if isinstance(hist.InstrumentParameters[key], list) and len(hist.InstrumentParameters[key]) > 2:
        hist.InstrumentParameters[key][2] = False
wo3.data["General"]["Cell"][0] = False
co3o4.data["General"]["Cell"][0] = False
saved_hap_flags = {}
for phase in (wo3, co3o4):
    hap = phase.getHAPvalues(hist.name)
    saved_hap_flags[phase.name] = (deepcopy(hap["Size"][2]), deepcopy(hap["Mustrain"][2]))
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]

wo3.set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
co3o4.set_refinements({"Atoms": {"O": "X"}})
project.refine(makeBack=False)
print("coordinate_only", hist.residuals, hist.ComputeMassFracs())
for phase in project.phases():
    for atom in phase.atoms():
        print(phase.name, atom.label, atom.coordinates, atom.refinement_flags)

# Hold the structural result and settle the complete profile model.
wo3.clear_refinements({"Atoms": ["W1", "W2"]})
co3o4.clear_refinements({"Atoms": ["O"]})
hist.Background[0][1] = True
for key in ("Zero", "Polariz.", "W", "SH/L"):
    hist.InstrumentParameters[key][2] = True
for phase in (wo3, co3o4):
    phase.data["General"]["Cell"][0] = True
    hap = phase.getHAPvalues(hist.name)
    hap["Size"][2], hap["Mustrain"][2] = saved_hap_flags[phase.name]
for idx in range(2):
    project.refine(makeBack=False)
    print(f"settle_{idx + 1}", hist.residuals, hist.ComputeMassFracs())
project.save()
