#!/usr/bin/env python3
"""Refine one common isotropic displacement parameter for each phase."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("initial", type=float, nargs="?", default=0.01)
parser.add_argument("--polarization", type=float)
args = parser.parse_args()

out = Path(args.output).resolve()
if out.exists():
    out.unlink()
project = G2sc.G2Project(args.input, newgpx=str(out))
project.set_Controls("cycles", 30)
project.index_ids()
if args.polarization is not None:
    polar = project.histogram(0).InstrumentParameters["Polariz."]
    polar[1] = args.polarization
    polar[2] = False

for phase in project.phases():
    variables = []
    for atom_index, atom in enumerate(phase.atoms()):
        atom.uiso = args.initial
        if "U" not in atom.refinement_flags:
            atom.refinement_flags += "U"
        variables.append(f"{phase.id}::AUiso:{atom_index}")
    project.add_EquivConstr(variables)

hist = project.histogram(0)
for idx in range(3):
    project.refine(makeBack=False)
    print(f"cycle_{idx + 1}", hist.residuals, hist.ComputeMassFracs())
    for phase in project.phases():
        print(phase.name, [atom.uiso for atom in phase.atoms()])
project.save()
