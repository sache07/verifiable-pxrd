#!/usr/bin/env python3
"""Refine coordinates within the modest displacement supported by the source model."""

from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def bound_atom(project, phase_id, atom_id, delta=0.006):
    for axis in "xyz":
        variable = f"{phase_id}::dA{axis}:{atom_id}"
        project.set_Controls("parmMin", -delta, variable=variable)
        project.set_Controls("parmMax", delta, variable=variable)


def report(project, label):
    hist = project.histogram(0)
    print(label, hist.residuals)
    print("fractions", hist.ComputeMassFracs())
    for phase in project.phases():
        print("phase", phase.name, phase.get_cell())
        for atom in phase.atoms():
            print("atom", atom.label, atom.element, atom.coordinates, atom.ADP, atom.refinement_flags)
    print("frozen", project.data["Controls"]["data"].get("parmFrozen"))


def main():
    out = Path("atoms_bounded.gpx").resolve()
    if out.exists():
        out.unlink()
    project = G2sc.G2Project("geom_shift_fixed.gpx", newgpx=str(out))
    project.set_Controls("cycles", 30)
    wo3 = project.phase("WO3_monoclinic")
    co3o4 = project.phase("Co3O4_spinel")

    # W sites dominate the WO3 structure factors; spinel oxygen is its sole
    # symmetry-variable positional degree of freedom.
    wo3.set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
    co3o4.set_refinements({"Atoms": {"O": "X"}})
    for atom_id in (2, 6):
        bound_atom(project, 0, atom_id)
    bound_atom(project, 1, 2)
    project.refine(makeBack=False)
    report(project, "bounded_heavy")

    wo3.clear_refinements({"Atoms": ["W1", "W2"]})
    co3o4.clear_refinements({"Atoms": ["O"]})
    oxygen = ("O6", "O2", "O5", "O3", "O1", "O4")
    wo3.set_refinements({"Atoms": {name: "X" for name in oxygen}})
    for atom_id in (0, 1, 3, 4, 5, 7):
        bound_atom(project, 0, atom_id)
    project.refine(makeBack=False)
    report(project, "bounded_oxygen")

    wo3.clear_refinements({"Atoms": list(oxygen)})
    project.refine(makeBack=False)
    report(project, "settled")
    project.save()


if __name__ == "__main__":
    main()
