#!/usr/bin/env python3
"""Refine only heavy-atom coordinates, leaving weakly determined O/C fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(
        gpxfile=str(args.base), newgpx=str(args.outdir / "candidate.gpx")
    )
    hist = gpx.histogram(0)
    gpx.save()
    mass0 = hist.ComputeMassFracs()
    refined = {}
    for phase in gpx.phases():
        # A sub-percent phase cannot support coordinate refinement.
        frac = mass0.get(phase.name, (0.0, 0.0))[0]
        refs = {
            atom.label: "X"
            for atom in phase.atoms()
            if frac >= 0.01 and atom.element not in ("O", "C", "H")
        }
        if refs:
            phase.set_refinements({"Atoms": refs})
            refined[phase.name] = list(refs)
    gpx.set_Controls("cycles", 16)
    gpx.save()
    gpx.do_refinements([{}], makeBack=False)
    gpx.do_refinements([{}], makeBack=False)
    gpx.save()
    r = gpx.data["Covariance"]["data"]["Rvals"]
    result = {
        "Rwp": r.get("Rwp"),
        "GOF": r.get("GOF"),
        "chisq": r.get("chisq"),
        "mass_fractions": hist.ComputeMassFracs(),
        "refined_atoms": refined,
        "coordinates": {
            phase.name: {
                atom.label: atom.coordinates for atom in phase.atoms()
            }
            for phase in gpx.phases()
        },
    }
    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, default=float) + "\n"
    )
    print("RESULT", json.dumps(result, default=float))


if __name__ == "__main__":
    main()
