#!/usr/bin/env python3
"""Refine Lorentzian/Gaussian mixing terms for active sample broadening."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--kind", choices=("size", "mustrain", "both"), default="both")
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(
        gpxfile=str(args.base), newgpx=str(args.outdir / "candidate.gpx")
    )
    hist = gpx.histogram(0)
    gpx.save()
    mass0 = hist.ComputeMassFracs()
    for phase in gpx.phases():
        # Do not attempt profile extraction for a sub-percent trace phase.
        if mass0.get(phase.name, (0.0, 0.0))[0] < 0.01:
            continue
        refs = {}
        if args.kind in ("size", "both"):
            refs["Size"] = {"type": phase.getHAPvalues(hist)["Size"][0],
                            "LGmix": {"refine": True}}
        if args.kind in ("mustrain", "both"):
            refs["Mustrain"] = {"type": phase.getHAPvalues(hist)["Mustrain"][0],
                                "LGmix": {"refine": True}}
        phase.set_HAP_refinements(refs, [hist])
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.do_refinements([{}], makeBack=False)
    gpx.save()
    r = gpx.data["Covariance"]["data"]["Rvals"]
    result = {
        "Rwp": r.get("Rwp"),
        "GOF": r.get("GOF"),
        "chisq": r.get("chisq"),
        "mass_fractions": hist.ComputeMassFracs(),
        "profiles": {
            phase.name: {
                "size": phase.getHAPvalues(hist)["Size"],
                "mustrain": phase.getHAPvalues(hist)["Mustrain"],
            }
            for phase in gpx.phases()
        },
    }
    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, default=float) + "\n"
    )
    print("RESULT", json.dumps(result, default=float))


if __name__ == "__main__":
    main()
