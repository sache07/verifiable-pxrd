#!/usr/bin/env python3
"""Create the internally consistent final GSAS-II and text deliverables."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PHASE_INFO = {
    "WO3": {
        "display_name": "monoclinic tungsten trioxide",
        "formula": "WO3",
        "cif": "phase_WO3.cif",
        "source": "COD 2311041 (Loopstra & Boldrini, 1966 model)",
        "structure_status": "major phase; cell and W coordinates refined",
        "fraction_status": "quantified",
    },
    "BaCO3": {
        "display_name": "orthorhombic barium carbonate (witherite)",
        "formula": "BaCO3",
        "cif": "phase_BaCO3.cif",
        "source": "COD 9010928",
        "structure_status": "major phase; cell and Ba coordinates refined",
        "fraction_status": "quantified",
    },
    "BaWO4": {
        "display_name": "tetragonal barium tungstate (scheelite)",
        "formula": "BaWO4",
        "cif": "phase_BaWO4.cif",
        "source": (
            "Ba/W cell and sites from COD 1527204; full-occupancy scheelite "
            "oxygen framework from BaMoO4 COD 2300459 with Mo-to-W substitution"
        ),
        "structure_status": "trace phase; fixed analogue-repaired scheelite model",
        "fraction_status": "tentative trace estimate",
    },
}


def plain(value):
    """Recursively convert NumPy scalar values for JSON serialization."""
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.generic):
        return value.item()
    return value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("."))
    args = parser.parse_args()
    outdir = args.output_dir.resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    final_path = outdir / "final.gpx"
    project = G2sc.G2Project(
        gpxfile=str(args.candidate.resolve()), newgpx=str(final_path)
    )
    hist = project.histogram(0)

    # COD 1527204 is an old average model with two half-occupied oxygen sites
    # that are too close to be occupied together. For a physical trace-phase
    # model, retain its BaWO4 cell and Ba/W sites but use the full-occupancy
    # 16f oxygen framework of modern scheelite BaMoO4 (COD 2300459), Mo -> W.
    trace = project.phase("BaWO4")
    trace.data["Atoms"] = [
        row for row in trace.data["Atoms"] if not str(row[1]).startswith("O")
    ]
    oxygen = trace.add_atom(
        0.22831, 0.13536, 0.04996, "O-2", "O1", occ=1.0, uiso=0.01
    )
    oxygen.refinement_flags = ""

    # Use every supplied observation and remove obsolete frozen-variable records.
    hist.set_refinements({"Limits": list(hist.data["Limits"][0])})
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["Author"] = "Codex PXRD analysis"
    controls["max cyc"] = 12

    # Keep calibrated/profile boundary values fixed; the specimen displacement,
    # surface B term and physically identifiable phase parameters remain active.
    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"):
        inst[key][2] = False
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"][1] = False
    hist.data["Comments"].extend(
        [
            "Cu Kalpha1/Kalpha2 Rietveld refinement; Poisson counting weights.",
            "Sources: WO3 COD 2311041; BaCO3 COD 9010928.",
            "BaWO4 cell/Ba/W: COD 1527204; O framework: BaMoO4 COD 2300459, Mo->W.",
            "BaWO4 is tentative; its analogue-repaired structure was fixed.",
        ]
    )

    project.save()
    project.do_refinements([{}], makeBack=False)
    project.do_refinements([{}], makeBack=False)
    project.save()

    # Reload the exact serialized project before every export.
    project = G2sc.G2Project(gpxfile=str(final_path))
    hist = project.histogram(0)
    phases = project.phases()
    if {p.name for p in phases} != set(PHASE_INFO):
        raise RuntimeError(f"unexpected phase inventory: {[p.name for p in phases]}")

    mass = hist.ComputeMassFracs()
    total = sum(float(v[0]) for v in mass.values())
    phase_records = []
    for phase in phases:
        info = PHASE_INFO[phase.name]
        cif_path = outdir / info["cif"]
        phase.export_CIF(str(cif_path))
        cell = phase.get_cell()
        phase_records.append(
            {
                "name": info["display_name"],
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": info["cif"],
                "weight_fraction": float(mass[phase.name][0]) / total,
                "weight_fraction_formal_su": float(mass[phase.name][1]) / total,
                "fraction_status": info["fraction_status"],
                "structure_status": info["structure_status"],
                "reference_source": info["source"],
                "cell": plain(cell),
            }
        )

    data = np.ma.filled(hist.data["data"][1], np.nan)
    x, yobs, weights, ycalc, background, stored_diff = data
    diff = yobs - ycalc
    finite = np.isfinite(x + yobs + weights + ycalc)
    if not np.all(finite):
        raise RuntimeError("non-finite values in final calculated profile")
    if np.any(ycalc <= 0):
        raise RuntimeError("final profile was not calculated over the complete scan")
    if not np.allclose(diff, stored_diff, rtol=0.0, atol=1e-7):
        raise RuntimeError("stored GSAS-II difference curve is inconsistent")

    with (outdir / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_intensity",
                "background_intensity",
            ]
        )
        writer.writerows(
            zip(
                (f"{v:.8f}" for v in x),
                (f"{v:.8f}" for v in yobs),
                (f"{v:.8f}" for v in ycalc),
                (f"{v:.8f}" for v in diff),
                (f"{v:.8f}" for v in background),
            )
        )

    rvals = project.data["Covariance"]["data"]["Rvals"]
    nobs = int(rvals["Nobs"])
    nvars = int(rvals["Nvars"])
    chisq = float(np.sum(weights * diff**2))
    denom = float(np.sum(weights * yobs**2))
    rwp = 100.0 * math.sqrt(chisq / denom)
    rp = 100.0 * float(np.sum(np.abs(diff))) / float(np.sum(yobs))
    gof = math.sqrt(chisq / (nobs - nvars))
    rexp = rwp / gof
    if not math.isclose(rwp, float(rvals["Rwp"]), rel_tol=0.0, abs_tol=2e-6):
        raise RuntimeError("reported and recomputed Rwp differ")

    result = {
        "schema_version": 1,
        "refinement_histogram": hist.name,
        "phase_fraction_basis": (
            "weight fractions normalized to unity over the modeled crystalline phases"
        ),
        "phases": phase_records,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": rexp,
            "goodness_of_fit": gof,
            "chi_square": chisq,
            "n_observations": nobs,
            "n_refined_variables": nvars,
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
            "converged": bool(rvals.get("converged", False)),
        },
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "radiation": {
            "Kalpha1_angstrom": 1.540598,
            "Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
        },
        "uncertainty_note": (
            "Listed standard uncertainties are least-squares values only. "
            "The BaWO4 trace fraction and structure are not reliable against "
            "model-selection and profile-systematic uncertainty."
        ),
    }
    (outdir / "result.json").write_text(
        json.dumps(plain(result), indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(plain(result), indent=2))


if __name__ == "__main__":
    main()
