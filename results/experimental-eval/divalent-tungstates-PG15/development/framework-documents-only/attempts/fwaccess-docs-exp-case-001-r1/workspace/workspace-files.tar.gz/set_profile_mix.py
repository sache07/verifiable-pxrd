#!/usr/bin/env python3
"""Set fixed sample broadening mixing coefficients and re-refine."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--size-mix", type=float, default=1.0)
    ap.add_argument("--strain-mix", type=float, default=1.0)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(
        gpxfile=str(args.base), newgpx=str(args.outdir / "candidate.gpx")
    )
    hist = gpx.histogram(0)
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        hap["Size"][1][2] = args.size_mix
        hap["Size"][2][2] = False
        hap["Mustrain"][1][2] = args.strain_mix
        hap["Mustrain"][2][2] = False
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.do_refinements([{}], makeBack=False)
    gpx.save()
    r = gpx.data["Covariance"]["data"]["Rvals"]
    result = {
        "Rwp": r.get("Rwp"),
        "GOF": r.get("GOF"),
        "chisq": r.get("chisq"),
        "mass_fractions": hist.ComputeMassFracs(),
    }
    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, default=float) + "\n"
    )
    print("RESULT", json.dumps(result, default=float))


if __name__ == "__main__":
    main()
