#!/usr/bin/env python3
"""Set/fix surface-roughness parameters and re-refine."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("a", type=float)
    ap.add_argument("b", type=float, nargs="?", default=None)
    ap.add_argument("--refine-b", action="store_true")
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(
        gpxfile=str(args.base), newgpx=str(args.outdir / "candidate.gpx")
    )
    hist = gpx.histogram(0)
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [args.a, False]
    if args.b is not None:
        sample["SurfRoughB"] = [args.b, args.refine_b]
    elif args.refine_b:
        sample["SurfRoughB"][1] = True
    gpx.set_Controls("cycles", 16)
    gpx.save()
    gpx.do_refinements([{}], makeBack=False)
    gpx.save()
    r = gpx.data["Covariance"]["data"]["Rvals"]
    result = {
        "Rwp": r.get("Rwp"),
        "GOF": r.get("GOF"),
        "chisq": r.get("chisq"),
        "mass_fractions": hist.ComputeMassFracs(),
        "surface": {k: sample[k] for k in ("SurfRoughA", "SurfRoughB")},
    }
    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, default=float) + "\n"
    )
    print("RESULT", json.dumps(result, default=float))


if __name__ == "__main__":
    main()
