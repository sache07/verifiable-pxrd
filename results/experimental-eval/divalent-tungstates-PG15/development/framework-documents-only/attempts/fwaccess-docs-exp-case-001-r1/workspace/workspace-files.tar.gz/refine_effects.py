#!/usr/bin/env python3
"""Refine physically motivated profile/specimen effects in stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def snapshot(gpx: G2sc.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    r = gpx.data["Covariance"]["data"]["Rvals"]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    out = {
        "label": label,
        "Rwp": r.get("Rwp"),
        "GOF": r.get("GOF"),
        "chisq": r.get("chisq"),
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {k: inst[k][1] for k in ("Zero", "Polariz.", "U", "W", "X", "SH/L")},
        "sample": {k: sample[k][0] for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        out["phases"][phase.name] = {
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    print("STATE", json.dumps(out, default=float))
    return out


def run(gpx: G2sc.G2Project, label: str, states: list[dict]) -> None:
    print(f"\n===== {label} =====")
    gpx.do_refinements([{}], makeBack=False)
    gpx.save()
    states.append(snapshot(gpx, label))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--no-surface", action="store_true")
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    out = args.outdir / "candidate.gpx"
    gpx = G2sc.G2Project(gpxfile=str(args.base), newgpx=str(out))
    hist = gpx.histogram(0)
    hist.data["Sample Parameters"]["Scale"][1] = False
    gpx.set_Controls("cycles", 12)

    # Instrumental X and specimen size have nearly identical Lorentzian
    # dependences; similarly, U and isotropic microstrain are strongly linked.
    # Keep the already fitted instrumental U/W fixed and use a plausible X so
    # phase-specific broadening is estimable without singularities.
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    hist.data["Instrument Parameters"][0]["X"][1] = 2.0
    gpx.save()
    states = [snapshot(gpx, "initial")]

    for phase in gpx.phases():
        phase.setSampleProfile(hist, "size", "isotropic", 0.3, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
        var = f"{phase.id}:{hist.id}:Size;i"
        gpx.set_Controls("parmMin", 0.02, variable=var)
        gpx.set_Controls("parmMax", 5.0, variable=var)
    run(gpx, "isotropic_size", states)

    for phase in gpx.phases():
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=0.5)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
        var = f"{phase.id}:{hist.id}:Mustrain;i"
        gpx.set_Controls("parmMin", 0.0, variable=var)
        gpx.set_Controls("parmMax", 10000.0, variable=var)
    run(gpx, "isotropic_mustrain", states)

    hist.data["Instrument Parameters"][0]["Polariz."][1] = 0.7
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    gpx.set_Controls("parmMin", 0.5, variable=f":{hist.id}:Polariz.")
    gpx.set_Controls("parmMax", 1.0, variable=f":{hist.id}:Polariz.")
    run(gpx, "polarization", states)

    if not args.no_surface:
        hist.data["Sample Parameters"]["SurfRoughA"][0] = 0.1
        hist.data["Sample Parameters"]["SurfRoughB"][0] = 0.1
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        for key in ("SurfRoughA", "SurfRoughB"):
            gpx.set_Controls("parmMin", 0.001, variable=f":{hist.id}:{key}")
            gpx.set_Controls("parmMax", 1.0, variable=f":{hist.id}:{key}")
        run(gpx, "surface_roughness", states)

    run(gpx, "settle", states)
    (args.outdir / "states.json").write_text(
        json.dumps(states, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
