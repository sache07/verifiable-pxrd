#!/usr/bin/env python3
"""Refine one common isotropic displacement parameter per selected phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("phase", nargs="+")
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(
        gpxfile=str(args.base), newgpx=str(args.outdir / "candidate.gpx")
    )
    gpx.save()
    selected = []
    for phase_name in args.phase:
        phase = gpx.phase(phase_name)
        variables = []
        for i, atom in enumerate(phase.atoms()):
            if atom.adp_flag != "I":
                continue
            atom.uiso = 0.01
            if "X" in atom.refinement_flags:
                atom.refinement_flags = "XU"
            else:
                atom.refinement_flags = "U"
            variables.append(f"{phase.id}::AUiso:{i}")
        if len(variables) > 1:
            gpx.add_EquivConstr(variables, reloadIdx=True)
        selected.append(phase.name)
    gpx.set_Controls("cycles", 16)
    gpx.save()
    gpx.do_refinements([{}], makeBack=False)
    gpx.do_refinements([{}], makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    r = gpx.data["Covariance"]["data"]["Rvals"]
    result = {
        "Rwp": r.get("Rwp"),
        "GOF": r.get("GOF"),
        "chisq": r.get("chisq"),
        "mass_fractions": hist.ComputeMassFracs(),
        "uiso": {
            phase.name: [atom.uiso for atom in phase.atoms()]
            for phase in gpx.phases()
        },
        "selected": selected,
    }
    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, default=float) + "\n"
    )
    print("RESULT", json.dumps(result, default=float))


if __name__ == "__main__":
    main()
