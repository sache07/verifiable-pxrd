#!/usr/bin/env python3
"""Build and refine a GSAS-II candidate model for the supplied PXRD scan.

This is an exploratory helper. The final artifact export is handled separately
once the phase inventory and refinement strategy have been selected.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inputs(outdir: Path) -> tuple[Path, Path]:
    rows = []
    with Path("inputs/pattern.csv").open(newline="") as fp:
        reader = csv.DictReader(fp)
        for row in reader:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            rows.append((x, y, math.sqrt(max(y, 1.0))))
    xye = outdir / "pattern.xye"
    np.savetxt(xye, np.asarray(rows), fmt=("%.8f", "%.8f", "%.8f"))

    inst = outdir / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for Cu Ka Bragg-Brentano data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.25;Polariz.:0.7;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def state(gpx: G2sc.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    rvals = gpx.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    try:
        mass = hist.ComputeMassFracs()
    except Exception as exc:
        mass = {"error": repr(exc)}
    ans = {
        "label": label,
        "Rwp": rvals.get("Rwp"),
        "GOF": rvals.get("GOF"),
        "chisq": rvals.get("chisq"),
        "Nobs": rvals.get("Nobs"),
        "instrument": {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")},
        "sample": {k: sample[k][0] if isinstance(sample.get(k), list) else sample.get(k)
                   for k in ("Shift", "SurfRoughA", "SurfRoughB") if k in sample},
        "mass_fractions": mass,
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        ans["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    print("STATE", json.dumps(ans, default=float))
    return ans


def refine_step(gpx: G2sc.G2Project, label: str, spec: dict, states: list[dict]) -> None:
    print(f"\n===== {label} =====")
    gpx.do_refinements([spec], makeBack=False)
    gpx.save()
    states.append(state(gpx, label))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("outdir", type=Path)
    parser.add_argument(
        "phase", nargs="+", help="COD_ID:phase_name (for example 1528915:WO3)"
    )
    parser.add_argument("--background", type=int, default=18)
    parser.add_argument("--no-shift", action="store_true")
    parser.add_argument("--no-broadening", action="store_true")
    args = parser.parse_args()

    args.outdir.mkdir(parents=True, exist_ok=True)
    xye, instfile = write_inputs(args.outdir)
    gpx_path = args.outdir / "candidate.gpx"
    gpx = G2sc.G2Project(newgpx=str(gpx_path))
    hist = gpx.add_powder_histogram(str(xye), str(instfile), fmthint="xye")
    hist.set_refinements({"Limits": [10.0, 100.0]})
    # Histogram scale and phase scales are exactly redundant. Keep the former
    # fixed so phase-scale uncertainties and candidate comparisons are valid.
    hist.data["Sample Parameters"]["Scale"][1] = False

    phases = []
    for item in args.phase:
        cod_id, name = item.split(":", 1)
        phase = gpx.add_phase(
            str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )
        # The synthetic lab uses a single modest isotropic displacement value
        # for each phase; start all sites at a physically neutral value.
        for atom in phase.atoms():
            if atom.adp_flag == "I":
                atom.uiso = 0.01
        phase.HAPvalue("Scale", 1.0, [hist])
        phases.append(phase)

    gpx.set_Controls("cycles", 8)
    gpx.save()
    states = [state(gpx, "initial")]

    refine_step(
        gpx,
        "background_scales_zero",
        {
            "set": {
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": args.background,
                    "refine": True,
                },
                "PhaseFraction": True,
                "Instrument Parameters": ["Zero"],
            }
        },
        states,
    )
    refine_step(
        gpx,
        "cells",
        {"set": {"Cell": True}},
        states,
    )
    refine_step(
        gpx,
        "instrument_profile",
        {"set": {"Instrument Parameters": ["U", "W", "X", "SH/L"]}},
        states,
    )

    if not args.no_shift:
        refine_step(
            gpx,
            "sample_shift",
            {"set": {"Sample Parameters": ["Shift"]}},
            states,
        )

    if not args.no_broadening:
        for phase in phases:
            phase.setSampleProfile(hist, "size", "isotropic", 0.5, LGmix=1.0)
            phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=0.5)
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                },
                [hist],
            )
        refine_step(gpx, "phase_broadening", {}, states)

    refine_step(gpx, "settle", {}, states)
    (args.outdir / "states.json").write_text(json.dumps(states, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
