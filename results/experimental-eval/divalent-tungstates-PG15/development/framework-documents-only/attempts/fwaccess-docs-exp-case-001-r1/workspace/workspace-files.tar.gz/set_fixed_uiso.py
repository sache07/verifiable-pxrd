#!/usr/bin/env python3
"""Set fixed isotropic displacement values and re-refine other parameters."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument(
        "setting", nargs="+", help="phase=value or phase:atom=value in A^2"
    )
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(
        gpxfile=str(args.base), newgpx=str(args.outdir / "candidate.gpx")
    )
    chosen = {}
    for item in args.setting:
        target, value = item.split("=", 1)
        value = float(value)
        chosen[target] = value
        if ":" in target:
            name, atom_label = target.split(":", 1)
        else:
            name, atom_label = target, None
        phase = gpx.phase(name)
        for atom in phase.atoms():
            if atom.adp_flag == "I" and (atom_label is None or atom.label == atom_label):
                atom.uiso = value
                atom.refinement_flags = atom.refinement_flags.replace("U", "")
    gpx.set_Controls("cycles", 16)
    gpx.save()
    gpx.do_refinements([{}], makeBack=False)
    gpx.do_refinements([{}], makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    r = gpx.data["Covariance"]["data"]["Rvals"]
    result = {
        "Rwp": r.get("Rwp"),
        "GOF": r.get("GOF"),
        "chisq": r.get("chisq"),
        "mass_fractions": hist.ComputeMassFracs(),
        "fixed_uiso": chosen,
    }
    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, default=float) + "\n"
    )
    print("RESULT", json.dumps(result, default=float))


if __name__ == "__main__":
    main()
