#!/usr/bin/env python3
"""Fix instrumental zero and refine a physical Bragg-Brentano sample shift."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("zero", type=float)
    ap.add_argument("shift", type=float)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(
        gpxfile=str(args.base), newgpx=str(args.outdir / "candidate.gpx")
    )
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"] = [inst["Zero"][0], args.zero, False]
    # GSAS-II stores Bragg-Brentano specimen displacement in micrometres.
    hist.data["Sample Parameters"]["Shift"] = [args.shift, True]
    gpx.set_Controls("parmMin", -800.0, variable=f":{hist.id}:Shift")
    gpx.set_Controls("parmMax", 800.0, variable=f":{hist.id}:Shift")
    # These two profile terms have already converged in the parent model.
    # Fixing them avoids ill-conditioning against specimen displacement.
    inst["Polariz."][2] = False
    inst["SH/L"][2] = False
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.do_refinements([{}], makeBack=False)
    gpx.do_refinements([{}], makeBack=False)
    gpx.save()
    r = gpx.data["Covariance"]["data"]["Rvals"]
    result = {
        "Rwp": r.get("Rwp"),
        "GOF": r.get("GOF"),
        "chisq": r.get("chisq"),
        "mass_fractions": hist.ComputeMassFracs(),
        "zero": inst["Zero"],
        "shift": hist.data["Sample Parameters"]["Shift"],
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
    }
    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, default=float) + "\n"
    )
    print("RESULT", json.dumps(result, default=float))


if __name__ == "__main__":
    main()
