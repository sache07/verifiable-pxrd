#!/usr/bin/env python3
"""Staged coordinate and displacement refinement for a GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def snapshot(gpx: G2sc.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    r = gpx.data["Covariance"]["data"]["Rvals"]
    out = {
        "label": label,
        "Rwp": r.get("Rwp"),
        "GOF": r.get("GOF"),
        "chisq": r.get("chisq"),
        "mass_fractions": hist.ComputeMassFracs(),
        "atoms": {},
    }
    for phase in gpx.phases():
        out["atoms"][phase.name] = [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": atom.coordinates,
                "uiso": atom.uiso if atom.adp_flag == "I" else atom.ADP,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ]
    print("STATE", json.dumps(out, default=float))
    return out


def run(gpx: G2sc.G2Project, label: str, states: list[dict]) -> None:
    print(f"\n===== {label} =====")
    gpx.do_refinements([{}], makeBack=False)
    gpx.save()
    states.append(snapshot(gpx, label))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--no-uiso", action="store_true")
    ap.add_argument(
        "--coord-bound",
        type=float,
        default=None,
        help="symmetric bound on fractional coordinate shifts from the input model",
    )
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    out = args.outdir / "candidate.gpx"
    gpx = G2sc.G2Project(gpxfile=str(args.base), newgpx=str(out))
    hist = gpx.histogram(0)
    hist.data["Sample Parameters"]["Scale"][1] = False
    gpx.set_Controls("cycles", 12)
    gpx.save()
    if args.coord_bound is not None:
        for phase in gpx.phases():
            for i, _atom in enumerate(phase.atoms()):
                for axis in ("x", "y", "z"):
                    var = f"{phase.id}::dA{axis}:{i}"
                    gpx.set_Controls("parmMin", -args.coord_bound, variable=var)
                    gpx.set_Controls("parmMax", args.coord_bound, variable=var)
    states = [snapshot(gpx, "initial")]

    # Heavy-atom shifts are the most strongly determined and help avoid oxygen
    # coordinates absorbing scale/profile errors in the first coordinate step.
    for phase in gpx.phases():
        refs = {
            atom.label: "X"
            for atom in phase.atoms()
            if atom.element not in ("O", "C", "H")
        }
        if refs:
            phase.set_refinements({"Atoms": refs})
    run(gpx, "heavy_coordinates", states)

    for phase in gpx.phases():
        phase.set_refinements({"Atoms": {"all": "X"}})
    run(gpx, "all_coordinates", states)

    if not args.no_uiso:
        gpx.save()
        for phase in gpx.phases():
            vars_ = []
            for i, atom in enumerate(phase.atoms()):
                if atom.adp_flag != "I":
                    continue
                atom.refinement_flags = "XU"
                vars_.append(f"{phase.id}::AUiso:{i}")
                gpx.set_Controls("parmMin", 0.001, variable=vars_[-1])
                gpx.set_Controls("parmMax", 0.05, variable=vars_[-1])
            if len(vars_) > 1:
                gpx.add_EquivConstr(vars_, reloadIdx=True)
        run(gpx, "common_uiso", states)

    run(gpx, "settle", states)
    (args.outdir / "states.json").write_text(
        json.dumps(states, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
