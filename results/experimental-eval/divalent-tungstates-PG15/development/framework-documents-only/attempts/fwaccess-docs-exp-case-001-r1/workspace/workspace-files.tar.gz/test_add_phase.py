#!/usr/bin/env python3
"""Add one low-level candidate phase to an existing GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("cod_id")
    ap.add_argument("name")
    ap.add_argument("--scale", type=float, default=0.05)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    out = args.outdir / "candidate.gpx"
    gpx = G2sc.G2Project(gpxfile=str(args.base), newgpx=str(out))
    hist = gpx.histogram(0)
    hist.data["Sample Parameters"]["Scale"][1] = False
    phase = gpx.add_phase(
        str(cod_path(args.cod_id)),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    for atom in phase.atoms():
        if atom.adp_flag == "I":
            atom.uiso = 0.01
    phase.HAPvalue("Scale", args.scale, [hist])
    phase.set_HAP_refinements({"Scale": True}, [hist])
    gpx.set_Controls("cycles", 10)
    gpx.save()
    gpx.set_Controls(
        "parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale"
    )
    gpx.do_refinements([{}], makeBack=False)
    gpx.save()
    rvals = gpx.data["Covariance"]["data"]["Rvals"]
    result = {
        "Rwp": rvals.get("Rwp"),
        "GOF": rvals.get("GOF"),
        "chisq": rvals.get("chisq"),
        "mass_fractions": hist.ComputeMassFracs(),
        "candidate_scale": phase.HAPvalue("Scale", targethistlist=[hist]),
    }
    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, default=float) + "\n"
    )
    print("RESULT", json.dumps(result, default=float))


if __name__ == "__main__":
    main()
