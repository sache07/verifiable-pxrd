#!/usr/bin/env python3
"""Test one March-Dollase preferred-orientation axis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("phase")
    ap.add_argument("axis", help="comma-separated h,k,l")
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(
        gpxfile=str(args.base), newgpx=str(args.outdir / "candidate.gpx")
    )
    hist = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    axis = [int(v) for v in args.axis.split(",")]
    po = phase.getHAPvalues(hist)["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = axis
    gpx.set_Controls("cycles", 12)
    gpx.save()
    var = f"{phase.id}:{hist.id}:MD"
    gpx.set_Controls("parmMin", 0.5, variable=var)
    gpx.set_Controls("parmMax", 2.0, variable=var)
    gpx.do_refinements([{}], makeBack=False)
    gpx.save()
    r = gpx.data["Covariance"]["data"]["Rvals"]
    result = {
        "phase": phase.name,
        "axis": axis,
        "ratio": po[1],
        "Rwp": r.get("Rwp"),
        "GOF": r.get("GOF"),
        "chisq": r.get("chisq"),
        "mass_fractions": hist.ComputeMassFracs(),
    }
    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, default=float) + "\n"
    )
    print("RESULT", json.dumps(result, default=float))


if __name__ == "__main__":
    main()
