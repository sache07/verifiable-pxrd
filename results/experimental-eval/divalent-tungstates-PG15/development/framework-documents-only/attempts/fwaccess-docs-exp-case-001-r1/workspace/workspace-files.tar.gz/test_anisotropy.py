#!/usr/bin/env python3
"""Test one uniaxial crystallite-size or microstrain axis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("phase")
    ap.add_argument("kind", choices=("size", "microstrain"))
    ap.add_argument("axis", help="comma-separated h,k,l")
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    gpx = G2sc.G2Project(
        gpxfile=str(args.base), newgpx=str(args.outdir / "candidate.gpx")
    )
    hist = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    axis = [int(v) for v in args.axis.split(",")]
    hap = phase.getHAPvalues(hist)
    if args.kind == "size":
        current = hap["Size"][1][0]
        phase.setSampleProfile(hist, "size", "uniaxial", current, current, axis, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Size": {"type": "uniaxial", "refine": True, "direction": axis}}, [hist]
        )
        key = "Size"
    else:
        current = hap["Mustrain"][1][0]
        phase.setSampleProfile(hist, "microstrain", "uniaxial", current, current, axis, LGmix=0.5)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "refine": True, "direction": axis}}, [hist]
        )
        key = "Mustrain"
    gpx.set_Controls("cycles", 12)
    gpx.save()
    gpx.do_refinements([{}], makeBack=False)
    gpx.save()
    r = gpx.data["Covariance"]["data"]["Rvals"]
    profile = phase.getHAPvalues(hist)[key]
    result = {
        "phase": phase.name,
        "kind": args.kind,
        "axis": axis,
        "values": profile[1],
        "Rwp": r.get("Rwp"),
        "GOF": r.get("GOF"),
        "chisq": r.get("chisq"),
        "mass_fractions": hist.ComputeMassFracs(),
    }
    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, default=float) + "\n"
    )
    print("RESULT", json.dumps(result, default=float))


if __name__ == "__main__":
    main()
