#!/usr/bin/env python
"""Produce a self-consistent physically bounded two-phase refinement."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / 'analysis' / 'screen_2311041.gpx'
target = ROOT / 'analysis' / 'bounded_2311041.gpx'


def refine_until_stable(project, label, maximum=5):
    """Repeat after bound freezing so profile arrays match stored parameters."""
    previous = None
    for iteration in range(maximum):
        project.do_refinements([{}])
        frozen = tuple(sorted(project.get_Frozen()))
        hist = project.histogram(0)
        print('ITER', label, iteration + 1, hist.residuals.get('wR'), frozen,
              flush=True)
        if frozen == previous:
            return
        previous = frozen
    raise RuntimeError(f'Frozen parameter set did not stabilize in {maximum} fits')


project = G2sc.G2Project(str(source), newgpx=str(target))
project.set_Controls('cycles', 10)
project.data['Controls']['data']['min dM/M'] = 1e-5
project.data['Controls']['data']['SVDtol'] = 1e-7
hist = project.histogram(0)
niwo4, wo3 = project.phases()

# Reinitialize all strongly correlated breadth terms.
for key, value in {'U': 20.0, 'W': 20.0, 'X': 1.0, 'SH/L': 0.02}.items():
    hist.InstrumentParameters[key][1] = value
hist.SampleParameters['Shift'] = [0.0, False]
for phase, size, strain in ((niwo4, 0.08, 500.0),
                            (wo3, 0.20, 2800.0)):
    hap = phase.getHAPvalues(hist)
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][0] = size
    hap['Size'][2][0] = True
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][0] = strain
    hap['Mustrain'][2][0] = True

# Conservative physical bounds. Instrument ranges encompass ordinary lab data;
# size and strain bounds prevent nonphysical cancellation among profile terms.
limits = {
    ':0:U': (0.0, 40.0),
    ':0:W': (0.0, 40.0),
    ':0:X': (0.1, 6.0),
    ':0:SH/L': (0.005, 0.10),
    '0:0:Size;i': (0.025, 3.0),
    '1:0:Size;i': (0.025, 3.0),
    '0:0:Mustrain;i': (0.0, 12000.0),
    '1:0:Mustrain;i': (0.0, 12000.0),
}
for variable, (lower, upper) in limits.items():
    project.set_Controls('parmMin', lower, variable=variable)
    project.set_Controls('parmMax', upper, variable=variable)

# Fit specimen broadening first with a common fixed instrument profile.
project.set_Frozen()
hist.clear_refinements({'Instrument Parameters': ['U', 'W', 'X', 'SH/L']})
project.save()
refine_until_stable(project, 'phase_profile')

# Release common instrumental breadth and repeat through any bound freezes.
project.set_Frozen()
hist.set_refinements({'Instrument Parameters': ['U', 'W', 'X', 'SH/L']})
refine_until_stable(project, 'joint_profile')
project.save()

print('FINAL', hist.residuals, hist.ComputeMassFracs(), flush=True)
print('INST', {k: v[1] for k, v in hist.InstrumentParameters.items()
               if k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L')}, flush=True)
for phase in project.phases():
    hap = phase.getHAPvalues(hist)
    print('PHASE', phase.name, phase.get_cell(), hap['Scale'][0],
          hap['Size'], hap['Mustrain'], hap['Pref.Ori.'], flush=True)
print('FROZEN', project.get_Frozen(), flush=True)
