#!/usr/bin/env python
"""Screen the lab's allowed uniaxial microstrain directions."""

from pathlib import Path
import sys
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
phase_index = int(sys.argv[1])
axis = [int(v) for v in sys.argv[2].split(',')]
tag = ''.join(str(v) for v in axis)
source = ROOT / 'analysis' / 'effect_effect_roughpolar_heavy.gpx'
target = ROOT / 'analysis' / f'strain_p{phase_index}_{tag}.gpx'
project = G2sc.G2Project(str(source), newgpx=str(target))
project.set_Controls('cycles', 10)
phase = project.phase(phase_index)
hist = project.histogram(0)
strain = phase.getHAPvalues(hist)['Mustrain']
start = max(100.0, strain[1][0])
strain[0] = 'uniaxial'
strain[1][0] = start
strain[1][1] = start
strain[2][0] = True
strain[2][1] = True
strain[3] = axis
project.set_Frozen(variable=f'{phase_index}:0:Mustrain;i', mode='remove')
for suffix in ('i', 'a'):
    project.set_Controls('parmMin', 0.0,
                         variable=f'{phase_index}:0:Mustrain;{suffix}')
    project.set_Controls('parmMax', 12000.0,
                         variable=f'{phase_index}:0:Mustrain;{suffix}')
project.save()
previous = tuple(sorted(project.get_Frozen()))
for iteration in range(4):
    project.do_refinements([{}])
    frozen = tuple(sorted(project.get_Frozen()))
    if frozen == previous:
        break
    previous = frozen
project.save()
print('RESULT', phase_index, axis, hist.residuals.get('wR'),
      strain, hist.ComputeMassFracs(), project.get_Frozen(), flush=True)
