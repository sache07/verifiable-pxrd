#!/usr/bin/env python
"""Compare physically motivated intensity corrections from a common base."""

from pathlib import Path
import sys
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
mode = sys.argv[1]
source_name = sys.argv[2] if len(sys.argv) > 2 else 'uiso_2311041.gpx'
source = ROOT / 'analysis' / source_name
target = ROOT / 'analysis' / f'effect_{Path(source_name).stem}_{mode}.gpx'
project = G2sc.G2Project(str(source), newgpx=str(target))
project.set_Controls('cycles', 12)
hist = project.histogram(0)

if 'rough' in mode:
    hist.SampleParameters['SurfRoughA'] = [0.25, True]
    hist.SampleParameters['SurfRoughB'] = [0.10, True]
    for variable in (':0:SurfRoughA', ':0:SurfRoughB'):
        project.set_Controls('parmMin', 0.0, variable=variable)
        project.set_Controls('parmMax', 1.0, variable=variable)

if 'polar' in mode:
    hist.InstrumentParameters['Polariz.'][1] = 0.7
    hist.InstrumentParameters['Polariz.'][2] = True
    project.set_Controls('parmMin', 0.3, variable=':0:Polariz.')
    project.set_Controls('parmMax', 1.0, variable=':0:Polariz.')

if 'heavy' in mode:
    for phase in project.phases():
        for atom in phase.atoms():
            element = atom.element.split('+')[0]
            if element in ('Ni', 'W'):
                atom.refinement_flags = ''.join(
                    sorted(set(atom.refinement_flags + 'X')))

project.save()
previous = tuple(sorted(project.get_Frozen()))
for iteration in range(4):
    project.do_refinements([{}])
    frozen = tuple(sorted(project.get_Frozen()))
    if frozen == previous:
        break
    previous = frozen
project.save()
print('RESULT', mode, hist.residuals, hist.ComputeMassFracs(), flush=True)
print('SAMPLE', mode,
      {k: v for k, v in hist.SampleParameters.items()
       if k in ('SurfRoughA', 'SurfRoughB')}, flush=True)
print('POLAR', mode, hist.InstrumentParameters['Polariz.'], flush=True)
for phase in project.phases():
    print('ATOMS', mode, phase.name,
          [(a.label, tuple(a.coordinates)) for a in phase.atoms()], flush=True)
print('FROZEN', mode, project.get_Frozen(), flush=True)
