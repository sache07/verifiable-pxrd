#!/usr/bin/env python
"""Screen plausible WO3 models with a common conservative GSAS-II recipe."""

from pathlib import Path
import json
import sys
import traceback

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / 'analysis'
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def brief(project, label):
    hist = project.histogram(0)
    phases = project.phases()
    out = {
        'step': label,
        'residuals': hist.residuals,
        'instrument': {k: v[1] for k, v in hist.InstrumentParameters.items()
                       if k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L',
                                'Polariz.', 'I(L2)/I(L1)')},
        'sample': {k: v[0] for k, v in hist.SampleParameters.items()
                   if k in ('Shift', 'SurfRoughA', 'SurfRoughB')},
        'phases': {},
    }
    for phase in phases:
        hap = phase.getHAPvalues(hist)
        out['phases'][phase.name] = {
            'cell': phase.get_cell(),
            'scale': hap['Scale'][0],
            'size': hap['Size'],
            'mustrain': hap['Mustrain'],
            'pref_ori': hap['Pref.Ori.'],
        }
    try:
        project.save()
        out['mass_fractions'] = hist.ComputeMassFracs()
    except Exception as err:
        out['mass_fraction_error'] = repr(err)
    print(json.dumps(out, indent=2, default=str), flush=True)
    return out


def make_project(cod_id):
    out = ANALYSIS / f'screen_{cod_id}.gpx'
    if out.exists():
        out.unlink()
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ANALYSIS / 'pattern.xye'), str(ANALYSIS / 'cu_ka.instprm'),
        fmthint='xye')
    niwo4 = project.add_phase(
        str(ANALYSIS / 'niwo4_repaired.cif'), phasename='NiWO4',
        histograms=[hist], fmthint='CIF')
    wo3 = project.add_phase(
        str(cod_path(cod_id)), phasename=f'WO3_{cod_id}',
        histograms=[hist], fmthint='CIF')

    controls = project.data['Controls']['data']
    controls['max cyc'] = 12
    controls['min dM/M'] = 1e-5
    controls['SVDtol'] = 1e-8
    hist.SampleParameters['Scale'][1] = False
    hist.SampleParameters['Shift'][0] = 0.0
    hist.Background[0] = ['chebyschev-1', True, 15, 900.0] + [0.0] * 14
    niwo4.HAPvalue('Scale', 1.0)
    wo3.HAPvalue('Scale', 0.2)
    for phase in (niwo4, wo3):
        hap = phase.getHAPvalues(hist)
        hap['Size'][0] = 'isotropic'
        hap['Size'][1][0] = 0.10
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = 1000.0
    project.save()
    return project


def run(cod_id):
    project = make_project(cod_id)
    hist = project.histogram(0)
    phases = project.phases()
    history = []

    # Scale and smooth background first.
    project.do_refinements([{'set': {'Background': {'refine': True,
                                                     'no. coeffs': 15},
                                     'Scale': True}}])
    history.append(brief(project, 'background_scales'))

    # Align phase cells and the common angular origin.
    project.do_refinements([{'set': {'Cell': True,
                                     'Instrument Parameters': ['Zero']}}])
    history.append(brief(project, 'cells_zero'))

    # Recover the shared instrumental width before phase-specific broadening.
    project.do_refinements([{'set': {'Instrument Parameters': ['U', 'W', 'X']}}])
    history.append(brief(project, 'instrument_profile'))

    # Add phase-specific crystallite size and isotropic microstrain.
    for phase in phases:
        phase.set_HAP_refinements({
            'Size': {'type': 'isotropic', 'refine': True, 'value': 0.10},
            'Mustrain': {'type': 'isotropic', 'refine': True},
        })
    project.do_refinements([{}])
    history.append(brief(project, 'phase_broadening'))

    # Separate zero error from specimen displacement and allow axial asymmetry.
    project.do_refinements([{'set': {
        'Sample Parameters': ['Shift'],
        'Instrument Parameters': ['SH/L'],
    }}])
    history.append(brief(project, 'shift_asymmetry'))
    project.save()
    return {'cod_id': cod_id, 'history': history}


def main():
    ids = sys.argv[1:] or ['1528915', '2311041', '2106293', '1010618',
                           '1563541', '2107312', '1521532', '1521533']
    summary = {}
    for cod_id in ids:
        print(f'\n===== {cod_id} =====', flush=True)
        try:
            summary[cod_id] = run(cod_id)
        except Exception as err:
            traceback.print_exc()
            summary[cod_id] = {'error': repr(err)}
    with open(ANALYSIS / 'candidate_summary.json', 'w') as stream:
        json.dump(summary, stream, indent=2, default=str)


if __name__ == '__main__':
    main()
