#!/usr/bin/env python
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def main():
    cod_id = sys.argv[1] if len(sys.argv) > 1 else '1528915'
    out = ROOT / 'analysis' / f'inspect_{cod_id}.gpx'
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / 'analysis' / 'pattern.xye'),
        str(ROOT / 'analysis' / 'cu_ka.instprm'),
        fmthint='xye',
    )
    niwo4 = project.add_phase(
        str(ROOT / 'analysis' / 'niwo4_repaired.cif'),
        phasename='NiWO4', histograms=[hist], fmthint='CIF',
    )
    wo3 = project.add_phase(
        str(cod_path(cod_id)), phasename=f'WO3_{cod_id}',
        histograms=[hist], fmthint='CIF',
    )
    print('histogram', hist.name)
    print('limits', hist.data['Limits'])
    print('instrument', hist.data['Instrument Parameters'][0])
    print('sample', hist.data['Sample Parameters'])
    print('background', hist.data['Background'])
    print('controls', project.data['Controls']['data'])
    for phase in (niwo4, wo3):
        print('phase', phase.name, phase.composition, phase.get_cell())
        print('HAP', phase.getHAPvalues(hist))
        print('atoms')
        for atom in phase.atoms():
            print(vars(atom))
    project.save()


if __name__ == '__main__':
    main()
