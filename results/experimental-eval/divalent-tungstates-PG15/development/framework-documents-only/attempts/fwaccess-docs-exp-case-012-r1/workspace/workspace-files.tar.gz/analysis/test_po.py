#!/usr/bin/env python
"""Test one March-Dollase direction from a common refined project."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
phase_index = int(sys.argv[1])
axis = [int(v) for v in sys.argv[2].split(',')]
tag = ''.join(str(v) for v in axis)
base_name = sys.argv[3] if len(sys.argv) > 3 else 'screen_1528915.gpx'
base = ROOT / 'analysis' / base_name
stem = Path(base_name).stem
out = ROOT / 'analysis' / f'po_{stem}_p{phase_index}_{tag}.gpx'

project = G2sc.G2Project(str(base), newgpx=str(out))
project.set_Controls('cycles', 6)
phase = project.phase(phase_index)
hist = project.histogram(0)
po = phase.getHAPvalues(hist)['Pref.Ori.']
po[0] = 'MD'
po[1] = 1.0
po[2] = True
po[3] = axis
project.save()
project.do_refinements([{}])
project.save()
print('RESULT', phase_index, axis, hist.residuals.get('wR'), po[1],
      hist.ComputeMassFracs(), flush=True)
