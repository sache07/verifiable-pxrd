#!/usr/bin/env python
"""Adopt the supported NiWO4 [100] strain model with physical limits."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / 'analysis' / 'effect_effect_roughpolar_heavy.gpx'
target = ROOT / 'analysis' / 'adopted_2311041.gpx'
project = G2sc.G2Project(str(source), newgpx=str(target))
project.set_Controls('cycles', 12)
hist = project.histogram(0)
niwo4 = project.phase(0)

# The axis screen selected [100]. Keep both components in the physically
# plausible microstrain regime rather than accepting cancellation at zero.
strain = niwo4.getHAPvalues(hist)['Mustrain']
strain[0] = 'uniaxial'
strain[1][0] = 300.0
strain[1][1] = 1000.0
strain[2][0] = True
strain[2][1] = True
strain[3] = [1, 0, 0]
project.set_Frozen(variable='0:0:Mustrain;i', mode='remove')
for suffix in ('i', 'a'):
    project.set_Controls('parmMin', 300.0,
                         variable=f'0:0:Mustrain;{suffix}')
    project.set_Controls('parmMax', 8000.0,
                         variable=f'0:0:Mustrain;{suffix}')

# Metadata leaves polarization unknown, while the lab context gives 0.5 as
# the physical lower edge. The unconstrained optimum is 0.498, so constrain it.
project.set_Controls('parmMin', 0.5, variable=':0:Polariz.')
project.set_Controls('parmMax', 1.0, variable=':0:Polariz.')
project.save()

previous = tuple(sorted(project.get_Frozen()))
for iteration in range(5):
    project.do_refinements([{}])
    frozen = tuple(sorted(project.get_Frozen()))
    print('ITER', iteration + 1, hist.residuals.get('wR'), frozen, flush=True)
    if frozen == previous:
        break
    previous = frozen
project.save()
print('FINAL', hist.residuals, hist.ComputeMassFracs(), flush=True)
print('STRAIN', strain, flush=True)
print('POLAR', hist.InstrumentParameters['Polariz.'], flush=True)
print('SURFACE', hist.SampleParameters['SurfRoughA'],
      hist.SampleParameters['SurfRoughB'], flush=True)
print('FROZEN', project.get_Frozen(), flush=True)
