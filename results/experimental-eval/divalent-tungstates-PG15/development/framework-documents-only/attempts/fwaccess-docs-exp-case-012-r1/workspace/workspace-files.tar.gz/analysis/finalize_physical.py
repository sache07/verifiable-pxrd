#!/usr/bin/env python
"""Apply final physical bounds without introducing unsupported effects."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / 'analysis' / 'effect_effect_roughpolar_heavy.gpx'
target = ROOT / 'analysis' / 'selected_model.gpx'
project = G2sc.G2Project(str(source), newgpx=str(target))
project.set_Controls('cycles', 12)
hist = project.histogram(0)
project.set_Controls('parmMin', 0.5, variable=':0:Polariz.')
project.set_Controls('parmMax', 1.0, variable=':0:Polariz.')
project.save()

previous = tuple(sorted(project.get_Frozen()))
for iteration in range(4):
    project.do_refinements([{}])
    frozen = tuple(sorted(project.get_Frozen()))
    print('ITER', iteration + 1, hist.residuals.get('wR'), frozen, flush=True)
    if frozen == previous:
        break
    previous = frozen
project.save()
print('FINAL', hist.residuals, hist.ComputeMassFracs(), flush=True)
print('POLAR', hist.InstrumentParameters['Polariz.'], flush=True)
print('SURFACE', hist.SampleParameters['SurfRoughA'],
      hist.SampleParameters['SurfRoughB'], flush=True)
print('FROZEN', project.get_Frozen(), flush=True)
