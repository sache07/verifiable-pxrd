#!/usr/bin/env python
"""Refine symmetry-allowed NiWO4 coordinates, then heavy-atom WO3 coordinates."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / 'analysis' / 'uiso_2311041.gpx'
target = ROOT / 'analysis' / 'coords_2311041.gpx'
project = G2sc.G2Project(str(source), newgpx=str(target))
project.set_Controls('cycles', 12)
hist = project.histogram(0)
niwo4, wo3 = project.phases()


def report(label):
    project.save()
    print('STAGE', label, hist.residuals, hist.ComputeMassFracs(), flush=True)
    for phase in project.phases():
        print('ATOMS', phase.name,
              [(a.label, a.element, tuple(a.coordinates), a.uiso,
                a.refinement_flags) for a in phase.atoms()], flush=True)


# The dominant phase has only eight independent positional parameters.
for atom in niwo4.atoms():
    atom.refinement_flags = ''.join(sorted(set(atom.refinement_flags + 'X')))
project.save()
project.do_refinements([{}])
report('NiWO4_all_coordinates')

# For the minor WO3 phase, refine W sites first; oxygen contributes weakly to Cu XRD.
for atom in wo3.atoms():
    if atom.element.split('+')[0] == 'W':
        atom.refinement_flags = ''.join(sorted(set(atom.refinement_flags + 'X')))
project.do_refinements([{}])
report('WO3_W_coordinates')
print('FROZEN', project.get_Frozen(), flush=True)
