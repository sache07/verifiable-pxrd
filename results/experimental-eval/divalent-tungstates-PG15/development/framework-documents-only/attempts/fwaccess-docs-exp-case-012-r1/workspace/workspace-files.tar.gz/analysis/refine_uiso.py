#!/usr/bin/env python
"""Refine one common isotropic displacement parameter per phase."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / 'analysis' / 'bounded_2311041.gpx'
target = ROOT / 'analysis' / 'uiso_2311041.gpx'
project = G2sc.G2Project(str(source), newgpx=str(target))
project.set_Controls('cycles', 12)

for phase, start in zip(project.phases(), (0.005, 0.008)):
    atoms = phase.atoms()
    for atom in atoms:
        atom.uiso = start
        atom.refinement_flags = atom.refinement_flags.replace('U', '') + 'U'
    variables = [f'{phase.id}::AUiso:{i}' for i in range(len(atoms))]
    project.add_EquivConstr(variables)
    project.set_Controls('parmMin', 0.0,
                         variable=f'{phase.id}::AUiso:*')
    project.set_Controls('parmMax', 0.05,
                         variable=f'{phase.id}::AUiso:*')

project.set_Frozen()
project.save()
previous = None
for iteration in range(4):
    project.do_refinements([{}])
    frozen = tuple(sorted(project.get_Frozen()))
    print('ITER', iteration + 1, project.histogram(0).residuals.get('wR'),
          frozen, flush=True)
    if frozen == previous:
        break
    previous = frozen
project.save()
hist = project.histogram(0)
print('FINAL', hist.residuals, hist.ComputeMassFracs(), flush=True)
for phase in project.phases():
    print('UISOS', phase.name, [a.uiso for a in phase.atoms()], flush=True)
print('FROZEN', project.get_Frozen(), flush=True)
