#!/usr/bin/env python
"""Export all submission artifacts from the selected GSAS-II project."""

from pathlib import Path
import csv
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'analysis' / 'polished_model.gpx'
FINAL = ROOT / 'final.gpx'

project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
project.save()

# Reload the final file so all values below come from the submitted project.
project = G2sc.G2Project(str(FINAL))
hist = project.histogram(0)
phases = project.phases()
cif_names = ['phase_1_NiWO4.cif', 'phase_2_WO3.cif']
for phase, cif_name in zip(phases, cif_names):
    phase.export_CIF(str(ROOT / cif_name))

x = np.asarray(hist.getdata('x'), dtype=float)
yobs = np.asarray(hist.getdata('yobs'), dtype=float)
ycalc = np.asarray(hist.getdata('ycalc'), dtype=float)
residual = np.asarray(hist.getdata('residual'), dtype=float)
if not np.allclose(residual, yobs - ycalc, rtol=0.0, atol=1e-8):
    raise RuntimeError('GSAS-II residual array does not equal observed-calculated')

with open(ROOT / 'fit.csv', 'w', newline='') as stream:
    writer = csv.writer(stream)
    writer.writerow(['two_theta_deg', 'observed_intensity',
                     'calculated_intensity', 'difference_observed_minus_calculated'])
    for row in zip(x, yobs, ycalc, residual):
        writer.writerow([f'{row[0]:.8f}', f'{row[1]:.8f}',
                         f'{row[2]:.8f}', f'{row[3]:.8f}'])

mass_fractions = hist.ComputeMassFracs()
res = hist.residuals
rwp = float(res['wR'])
rexp = float(res['wRmin'])
phase_records = []
labels = [
    ('NiWO4', 'NiWO4', 'P 1 2/c 1'),
    ('WO3', 'WO3', 'P 1 21/c 1'),
]
for phase, cif_name, (name, formula, space_group) in zip(
        phases, cif_names, labels):
    fraction, esd = mass_fractions[phase.name]
    phase_records.append({
        'name': name,
        'formula': formula,
        'space_group': space_group,
        'cif_path': cif_name,
        'weight_fraction': float(fraction),
        'weight_fraction_esd': float(esd),
    })

result = {
    'phases': phase_records,
    'fit_statistics': {
        'Rwp_percent': rwp,
        'Rp_percent': float(res['R']),
        'Rexp_percent': rexp,
        'goodness_of_fit': rwp / rexp,
        'reduced_chi_squared': (rwp / rexp) ** 2,
        'Rwp_background_subtracted_percent': float(res['wRb']),
        'Rp_background_subtracted_percent': float(res['Rb']),
        'NiWO4_Rf_percent': float(res['0:0:Rf']),
        'NiWO4_Rf2_percent': float(res['0:0:Rf^2']),
        'WO3_Rf_percent': float(res['1:0:Rf']),
        'WO3_Rf2_percent': float(res['1:0:Rf^2']),
        'n_profile_points': int(len(x)),
        'weighting': 'Poisson counting weights, w = 1/max(Iobs,1)',
    },
}
with open(ROOT / 'result.json', 'w') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')

print(json.dumps(result, indent=2))
