#!/usr/bin/env python
"""Reset correlated profile terms to physical values and re-refine COD 2311041."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / 'analysis' / 'screen_2311041.gpx'
target = ROOT / 'analysis' / 'physical_2311041.gpx'

project = G2sc.G2Project(str(source), newgpx=str(target))
project.set_Controls('cycles', 12)
project.data['Controls']['data']['min dM/M'] = 1e-5
project.data['Controls']['data']['SVDtol'] = 1e-8
hist = project.histogram(0)
niwo4, wo3 = project.phases()

# Reset the ill-conditioned profile solution to values inside physical ranges.
for key, value in {'U': 25.0, 'W': 25.0, 'X': 1.0, 'SH/L': 0.02}.items():
    hist.InstrumentParameters[key][1] = value
hist.SampleParameters['Shift'] = [0.0, False]
ni_hap = niwo4.getHAPvalues(hist)
w_hap = wo3.getHAPvalues(hist)
ni_hap['Size'][1][0] = 0.070
ni_hap['Mustrain'][1][0] = 500.0
w_hap['Size'][1][0] = 0.140
w_hap['Mustrain'][1][0] = 2800.0

# GSAS-II parameter limits freeze a parameter if it attempts to leave its range.
limits = {
    ':0:U': (0.0, 60.0),
    ':0:W': (0.0, 60.0),
    ':0:X': (0.0, 8.0),
    ':0:SH/L': (0.002, 0.15),
    '0:0:Size;i': (0.025, 3.0),
    '1:0:Size;i': (0.025, 3.0),
    '0:0:Mustrain;i': (0.0, 12000.0),
    '1:0:Mustrain;i': (0.0, 12000.0),
}
for variable, (lower, upper) in limits.items():
    project.set_Controls('parmMin', lower, variable=variable)
    project.set_Controls('parmMax', upper, variable=variable)
project.set_Frozen()

# First fit phase broadening with the instrument held at a plausible common profile.
hist.clear_refinements({'Instrument Parameters': ['U', 'W', 'X', 'SH/L']})
project.save()
project.do_refinements([{}])
print('STAGE phase', hist.residuals, hist.ComputeMassFracs(), flush=True)

# Then release the common instrumental profile under bounds.
hist.set_refinements({'Instrument Parameters': ['U', 'W', 'X', 'SH/L']})
project.set_Frozen()
project.do_refinements([{}])
project.save()
print('STAGE instrument', hist.residuals, hist.ComputeMassFracs(), flush=True)
print('INST', {k: v[1] for k, v in hist.InstrumentParameters.items()
               if k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L')}, flush=True)
for phase in project.phases():
    hap = phase.getHAPvalues(hist)
    print('PHASE', phase.name, phase.get_cell(), hap['Size'], hap['Mustrain'],
          hap['Pref.Ori.'], flush=True)
print('FROZEN', project.get_Frozen(), flush=True)
