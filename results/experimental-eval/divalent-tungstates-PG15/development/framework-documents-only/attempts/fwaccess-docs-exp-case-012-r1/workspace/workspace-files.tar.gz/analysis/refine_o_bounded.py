#!/usr/bin/env python
"""Test oxygen-coordinate refinement inside the documented mismatch scale."""

from pathlib import Path
import sys
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
include_wo3 = len(sys.argv) > 1 and sys.argv[1] == 'both'
source = ROOT / 'analysis' / 'selected_model.gpx'
suffix = 'both' if include_wo3 else 'niwo4'
target = ROOT / 'analysis' / f'oxygen_bounded_{suffix}.gpx'
project = G2sc.G2Project(str(source), newgpx=str(target))
project.set_Controls('cycles', 12)
hist = project.histogram(0)

# Parent coordinates are retained explicitly so bounds represent about 0.05 A
# along each cell direction rather than accumulating across cycles.
parents = {
    0: {
        2: (0.22000, 0.11000, 0.96000),
        3: (0.26000, 0.38000, 0.39000),
    },
}
if include_wo3:
    parents[1] = {
        0: (0.714, 0.487, 0.721),
        1: (0.225, 0.474, 0.007),
        3: (0.716, 0.043, 0.708),
        4: (0.998, 0.262, 0.712),
        5: (0.206, 0.042, 0.995),
        7: (0.519, 0.259, 0.789),
    }

for phase_id, atom_parents in parents.items():
    phase = project.phase(phase_id)
    cell = phase.get_cell()
    frac_halfwidth = (0.05 / cell['length_a'],
                      0.05 / cell['length_b'],
                      0.05 / cell['length_c'])
    atoms = phase.atoms()
    for atom_index, parent in atom_parents.items():
        atom = atoms[atom_index]
        atom.refinement_flags = ''.join(sorted(set(atom.refinement_flags + 'X')))
        for axis, letter in enumerate('xyz'):
            variable = f'{phase_id}::dA{letter}:{atom_index}'
            project.set_Controls('parmMin', parent[axis] - frac_halfwidth[axis],
                                 variable=variable)
            project.set_Controls('parmMax', parent[axis] + frac_halfwidth[axis],
                                 variable=variable)

project.save()
previous = tuple(sorted(project.get_Frozen()))
for iteration in range(6):
    project.do_refinements([{}])
    frozen = tuple(sorted(project.get_Frozen()))
    print('ITER', iteration + 1, hist.residuals.get('wR'), frozen, flush=True)
    if frozen == previous:
        break
    previous = frozen
project.save()
print('FINAL', hist.residuals, hist.ComputeMassFracs(), flush=True)
for phase in project.phases():
    print('ATOMS', phase.name,
          [(a.label, tuple(a.coordinates), a.refinement_flags)
           for a in phase.atoms()], flush=True)
print('FROZEN', project.get_Frozen(), flush=True)
