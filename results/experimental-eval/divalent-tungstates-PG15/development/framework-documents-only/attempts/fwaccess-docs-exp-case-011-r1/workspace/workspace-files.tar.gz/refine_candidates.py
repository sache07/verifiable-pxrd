#!/usr/bin/env python3
"""Build and refine a two-phase GSAS-II project for candidate screening."""

import argparse
import os
import sys

import GSASIIscriptable as G2sc


COD_ROOT = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"


def cod_path(cod_id):
    return os.path.join(COD_ROOT, cod_id[0], cod_id[1:3], cod_id[3:5], cod_id + ".cif")


def report(gpx, label):
    hist = gpx.histogram(0)
    print("\n===", label, "===")
    print("residuals", hist.residuals)
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("U", "V", "W", "X", "Y", "SH/L", "Zero", "Polariz.", "I(L2)/I(L1)")})
    print("sample", hist.SampleParameters)
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        print("phase", phase.name, "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "mustrain", hap["Mustrain"], "PO", hap["Pref.Ori."])
    try:
        print("mass_fracs", hist.ComputeMassFracs())
    except Exception as err:
        print("mass_fracs error", repr(err))


def refine_once(gpx, label):
    try:
        gpx.do_refinements([{}])
    except Exception:
        report(gpx, label + " FAILED")
        raise
    report(gpx, label)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--mno2", default="1514110")
    parser.add_argument("--output", default="candidate.gpx")
    parser.add_argument("--full", action="store_true")
    args = parser.parse_args()

    gpx = G2sc.G2Project(newgpx=args.output)
    hist = gpx.add_powder_histogram("inputs/pattern.csv", "instrument.instprm",
                                    fmthint="comma")
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.SampleParameters["Gonio. radius"] = 200.0
    # The shared +~0.28 degree shift indicates a specimen-height correction
    # close to -500 micrometres for a 200 mm goniometer.
    hist.SampleParameters["Shift"][0] = -500.0

    wo3 = gpx.add_phase(cod_path(args.wo3), phasename="gamma-WO3", histograms=[hist])
    mno2 = gpx.add_phase(cod_path(args.mno2), phasename="pyrolusite-MnO2", histograms=[hist])

    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = 8
    controls["deriv type"] = "analytic Hessian"
    controls["min dM/M"] = 0.0001

    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 12,
                                                  "refine": True}})
    for phase in (wo3, mno2):
        phase.set_HAP_refinements({"Scale": True})
    refine_once(gpx, "background + phase scales")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_once(gpx, "sample displacement")

    wo3.set_refinements({"Cell": True})
    mno2.set_refinements({"Cell": True})
    refine_once(gpx, "unit cells")

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X"]})
    refine_once(gpx, "instrument profile")

    for phase, initial in ((wo3, 1.0), (mno2, 0.15)):
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": initial,
                                                     "refine": True}})
    refine_once(gpx, "phase sizes")

    for phase in (wo3, mno2):
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine_once(gpx, "isotropic microstrain")

    if args.full:
        # Test the generator's allowed [110] texture axis for pyrolusite.
        po = mno2.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[3] = [1, 1, 0]
        mno2.set_HAP_refinements({"Pref.Ori.": True})
        refine_once(gpx, "pyrolusite [110] March-Dollase")

    gpx.save(args.output)
    report(gpx, "final")


if __name__ == "__main__":
    main()
