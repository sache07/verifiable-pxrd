#!/usr/bin/env python3
"""Refine selected coordinates from an established profile model."""

import argparse

from GSASII import GSASIIscriptable as G2sc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("selection", choices=("wo3_w", "wo3_o", "mno2_o", "all"))
    ap.add_argument("--delta", type=float,
                    help="bound each newly selected fractional coordinate around its starting value")
    args = ap.parse_args()
    gpx = G2sc.G2Project(args.input, newgpx=args.output)
    gpx.index_ids()
    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = 15
    controls["parmFrozen"] = {}
    for pnum, phase in enumerate(gpx.phases()):
        for anum, atom in enumerate(phase.atoms()):
            select = args.selection == "all"
            select |= args.selection == "wo3_w" and pnum == 0 and atom.element == "W"
            select |= args.selection == "wo3_o" and pnum == 0 and atom.element == "O"
            select |= args.selection == "mno2_o" and pnum == 1 and atom.element == "O"
            if select:
                atom.refinement_flags = "X"
                if args.delta is not None:
                    for key, value in zip(("dAx", "dAy", "dAz"), atom.coordinates):
                        var = gpx.make_var_obj(f"{pnum}::{key}:{anum}", reloadIdx=False)
                        controls.setdefault("parmMinDict", {})[var] = value - args.delta
                        controls.setdefault("parmMaxDict", {})[var] = value + args.delta
    gpx.do_refinements([{}])
    # A parameter that crosses a GSAS-II limit is clamped/frozen only after
    # the least-squares cycle. Recalculate once from that bounded model so the
    # saved profile and residuals are consistent with the saved coordinates.
    if controls.get("parmFrozen"):
        gpx.do_refinements([{}])
    gpx.save(args.output)
    h = gpx.histogram(0)
    print("COORD", args.selection, "wR", h.get_wR(), "mass", h.ComputeMassFracs())
    for phase in gpx.phases():
        print("PHASE", phase.name, [(a.label, a.element, tuple(a.coordinates),
                                     a.refinement_flags) for a in phase.atoms()])


if __name__ == "__main__":
    main()
