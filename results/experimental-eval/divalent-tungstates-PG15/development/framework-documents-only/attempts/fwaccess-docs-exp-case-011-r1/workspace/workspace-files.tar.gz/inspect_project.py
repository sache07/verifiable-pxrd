#!/usr/bin/env python3
"""Summarize a GSAS-II project and optionally export/plot its profile."""

import argparse
import csv

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("--csv")
    parser.add_argument("--plot")
    args = parser.parse_args()
    gpx = G2sc.G2Project(args.project)
    hist = gpx.histogram(0)
    x = np.asarray(hist.getdata("X"))
    yo = np.asarray(hist.getdata("Yobs"))
    yc = np.asarray(hist.getdata("Ycalc"))
    bg = np.asarray(hist.getdata("Background"))
    dy = np.asarray(hist.getdata("Residual"))
    wt = np.asarray(hist.getdata("Yweight"))
    print("histogram", hist.name)
    print("residuals", hist.residuals)
    print("mass_fractions", hist.ComputeMassFracs())
    print("limits", hist.Limits("lower"), hist.Limits("upper"))
    print("weighted_rss", float(np.sum(wt * dy * dy)))
    # Rank 0.25-degree windows by their contribution to weighted residual.
    edges = np.arange(np.floor(x.min() * 4) / 4, np.ceil(x.max() * 4) / 4 + 0.25, 0.25)
    bins = np.digitize(x, edges) - 1
    rows = []
    for i in range(len(edges) - 1):
        sel = bins == i
        if not np.any(sel):
            continue
        rows.append((float(np.sum(wt[sel] * dy[sel] ** 2)), edges[i], edges[i + 1],
                     float(np.max(np.abs(dy[sel]))), float(np.mean(dy[sel]))))
    print("top weighted-residual windows: wrss low high max_abs mean_resid")
    for row in sorted(rows, reverse=True)[:40]:
        print("%.3f %.2f %.2f %.1f %.2f" % row)
    if args.csv:
        with open(args.csv, "w", newline="") as stream:
            out = csv.writer(stream)
            out.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
            out.writerows(zip(x, yo, yc, dy, bg))
    if args.plot:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(2, 1, figsize=(16, 8), sharex=True,
                                 gridspec_kw={"height_ratios": [3, 1]})
        axes[0].plot(x, yo, color="black", lw=0.6, label="observed")
        axes[0].plot(x, yc, color="red", lw=0.7, label="calculated")
        axes[0].plot(x, bg, color="blue", lw=0.5, label="background")
        axes[0].legend(loc="upper right")
        axes[1].plot(x, dy, color="black", lw=0.5)
        axes[1].axhline(0, color="red", lw=0.5)
        axes[1].set_xlabel(r"2theta (degrees)")
        axes[0].set_ylabel("counts")
        axes[1].set_ylabel("obs-calc")
        fig.tight_layout()
        fig.savefig(args.plot, dpi=160)


if __name__ == "__main__":
    main()
