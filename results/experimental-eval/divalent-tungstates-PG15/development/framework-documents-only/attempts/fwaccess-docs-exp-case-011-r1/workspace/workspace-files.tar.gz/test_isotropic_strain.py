#!/usr/bin/env python3
"""Replace one phase's strain model by isotropic and refine."""

import argparse
from GSASII import GSASIIscriptable as G2sc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("phase", type=int)
    args = ap.parse_args()
    gpx = G2sc.G2Project(args.input, newgpx=args.output)
    h = gpx.histogram(0)
    mu = gpx.phase(args.phase).data["Histograms"][h.name]["Mustrain"]
    mu[1][0] = 0.5 * (mu[1][0] + mu[1][1])
    mu[0] = "isotropic"
    mu[2][0] = True
    mu[2][1] = False
    gpx.index_ids()
    gpx.data["Controls"]["data"]["max cyc"] = 15
    gpx.data["Controls"]["data"]["parmFrozen"] = {}
    h.InstrumentParameters["U"][2] = False
    gpx.do_refinements([{}])
    gpx.save(args.output)
    print("ISOSTRAIN", args.phase, mu, "wR", h.get_wR(), "mass", h.ComputeMassFracs())


if __name__ == "__main__":
    main()
