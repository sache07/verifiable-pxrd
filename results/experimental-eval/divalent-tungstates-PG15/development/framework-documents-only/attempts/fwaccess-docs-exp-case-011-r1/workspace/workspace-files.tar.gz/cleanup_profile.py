#!/usr/bin/env python3
"""Joint physical profile cleanup after structure/intensity refinement."""

import argparse

from GSASII import GSASIIscriptable as G2sc


def limit(gpx, name, low, high):
    c = gpx.data["Controls"]["data"]
    v = gpx.make_var_obj(name, reloadIdx=False)
    c.setdefault("parmMinDict", {})[v] = low
    c.setdefault("parmMaxDict", {})[v] = high


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--refine-u", action="store_true")
    args = ap.parse_args()
    gpx = G2sc.G2Project(args.input, newgpx=args.output)
    gpx.index_ids()
    h = gpx.histogram(0)
    c = gpx.data["Controls"]["data"]
    c["max cyc"] = 18
    c["parmFrozen"] = {}
    # Keep U at its physically selected zero boundary and the MnO2 size at
    # its effectively size-unbroadened upper boundary. Refine the remaining
    # common and phase-specific width terms.
    for key in ("U", "V", "Y", "Polariz.", "I(L2)/I(L1)"):
        h.InstrumentParameters[key][2] = False
    for key in ("W", "X", "SH/L"):
        h.InstrumentParameters[key][2] = True
    h.InstrumentParameters["U"][2] = args.refine_u
    for pnum, p in enumerate(gpx.phases()):
        hap = p.data["Histograms"][h.name]
        hap["Size"][2][0] = pnum == 0
        if hap["Mustrain"][0] == "uniaxial":
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][1] = True
        else:
            hap["Mustrain"][2][0] = True
    for name, lo, hi in ((":0:U", 0, 40), (":0:W", 2, 40), (":0:X", 0.1, 6),
                         (":0:SH/L", 0.005, 0.1), ("0:0:Size;i", 0.04, 1.5),
                         ("0:0:Mustrain;i", 0, 10000), ("0:0:Mustrain;a", 0, 10000),
                         ("1:0:Mustrain;i", 0, 10000), ("1:0:Mustrain;a", 0, 10000)):
        limit(gpx, name, lo, hi)
    gpx.do_refinements([{}])
    if c.get("parmFrozen"):
        gpx.do_refinements([{}])
    gpx.save(args.output)
    print("CLEAN wR", h.get_wR(), "mass", h.ComputeMassFracs())
    print("INST", {k: h.InstrumentParameters[k] for k in ("U", "W", "X", "SH/L")})
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        print("PHASE", p.name, "size", hap["Size"], "strain", hap["Mustrain"])


if __name__ == "__main__":
    main()
