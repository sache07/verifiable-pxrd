#!/usr/bin/env python3
"""Refine polarization and/or Bragg-Brentano surface roughness."""

import argparse

from GSASII import GSASIIscriptable as G2sc


def add_bound(gpx, name, low, high):
    c = gpx.data["Controls"]["data"]
    v = gpx.make_var_obj(name, reloadIdx=False)
    c.setdefault("parmMinDict", {})[v] = low
    c.setdefault("parmMaxDict", {})[v] = high


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--polarization", action="store_true")
    ap.add_argument("--roughness", action="store_true")
    args = ap.parse_args()
    gpx = G2sc.G2Project(args.input, newgpx=args.output)
    gpx.index_ids()
    h = gpx.histogram(0)
    c = gpx.data["Controls"]["data"]
    c["max cyc"] = 15
    c["parmFrozen"] = {}
    h.InstrumentParameters["Polariz."][2] = args.polarization
    if args.polarization:
        add_bound(gpx, ":0:Polariz.", 0.5, 1.0)
    if args.roughness:
        h.SampleParameters["SurfRoughA"][:] = [0.20, True]
        h.SampleParameters["SurfRoughB"][:] = [0.10, True]
        add_bound(gpx, ":0:SurfRoughA", 0.01, 0.8)
        add_bound(gpx, ":0:SurfRoughB", 0.005, 0.8)
    gpx.do_refinements([{}])
    # Ensure the calculated profile corresponds to any bounded/frozen values.
    if c.get("parmFrozen"):
        gpx.do_refinements([{}])
    gpx.save(args.output)
    print("TERMS pol", h.InstrumentParameters["Polariz."],
          "rough", h.SampleParameters["SurfRoughA"], h.SampleParameters["SurfRoughB"],
          "wR", h.get_wR(), "mass", h.ComputeMassFracs())


if __name__ == "__main__":
    main()
