#!/usr/bin/env python3
"""Extend refinement/calculation limits to the complete measured grid."""

import argparse
from GSASII import GSASIIscriptable as G2sc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    args = ap.parse_args()
    gpx = G2sc.G2Project(args.input, newgpx=args.output)
    h = gpx.histogram(0)
    h.data["Limits"][1][:] = h.data["Limits"][0]
    h.InstrumentParameters["U"][2] = False
    gpx.index_ids()
    gpx.data["Controls"]["data"]["max cyc"] = 18
    gpx.data["Controls"]["data"]["parmFrozen"] = {}
    gpx.do_refinements([{}])
    gpx.save(args.output)
    print("FULLRANGE", h.data["Limits"], "wR", h.get_wR(), "mass", h.ComputeMassFracs())


if __name__ == "__main__":
    main()
