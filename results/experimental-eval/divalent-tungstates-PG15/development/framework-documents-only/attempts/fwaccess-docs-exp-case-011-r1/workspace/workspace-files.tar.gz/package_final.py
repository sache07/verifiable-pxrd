#!/usr/bin/env python3
"""Package the selected GSAS-II refinement into the requested deliverables."""

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_PROJECT = ROOT / "fullrange.gpx"
FINAL_PROJECT = ROOT / "final.gpx"
PROFILE_FILE = ROOT / "fit.csv"
CIF_FILES = (
    ROOT / "phase_1_gamma_WO3.cif",
    ROOT / "phase_2_pyrolusite_MnO2.cif",
)


def main():
    # Save under the requested final name, then reload that exact file before
    # producing every derived output.
    source = G2sc.G2Project(str(SOURCE_PROJECT), newgpx=str(FINAL_PROJECT))
    source.save(str(FINAL_PROJECT))
    project = G2sc.G2Project(str(FINAL_PROJECT))
    project.index_ids()

    phases = project.phases()
    if len(phases) != len(CIF_FILES):
        raise RuntimeError(f"Expected {len(CIF_FILES)} phases, found {len(phases)}")
    for phase, filename in zip(phases, CIF_FILES):
        phase.export_CIF(str(filename))

    histogram = project.histogram(0)
    x = np.asarray(histogram.getdata("X"), dtype=float)
    observed = np.asarray(histogram.getdata("Yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    difference = np.asarray(histogram.getdata("Residual"), dtype=float)
    background = np.asarray(histogram.getdata("Background"), dtype=float)
    if not np.allclose(difference, observed - calculated, rtol=0, atol=1e-8):
        raise RuntimeError("GSAS-II residual is inconsistent with observed-calculated")

    with PROFILE_FILE.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity_counts",
                "calculated_intensity_counts",
                "difference_observed_minus_calculated_counts",
                "calculated_background_counts",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    fractions = histogram.ComputeMassFracs()
    summary = {
        "histogram": histogram.name,
        "limits_deg_2theta": [float(histogram.Limits("lower")), float(histogram.Limits("upper"))],
        "n_profile_rows": int(x.size),
        "phases": [],
        "fit": {
            "Rwp_percent": float(rvals["Rwp"]),
            "Rp_percent": float(histogram.residuals["R"]),
            "Rexp_percent": float(histogram.residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "reduced_chi_square": float(rvals["chisq"] / (rvals["Nobs"] - rvals["Nvars"])),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "converged": bool(rvals["converged"]),
            "max_shift_over_sigma": float(rvals["Max shft/sig"]),
        },
    }
    for phase, cif_file in zip(phases, CIF_FILES):
        fraction, fraction_esd = fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        summary["phases"].append(
            {
                "name": phase.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif": cif_file.name,
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(fraction_esd),
                "cell": {key: float(value) for key, value in cell.items()},
                "cell_esd": {key: float(value) for key, value in cell_esd.items()},
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": [float(value) for value in atom.coordinates],
                        "uiso_A2": float(atom.uiso),
                        "refinement_flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
