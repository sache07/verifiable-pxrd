#!/usr/bin/env python3
"""Stable staged profile refinement with physically bounded nuisance terms."""

import argparse

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2sc


def bound(gpx, name, low, high):
    controls = gpx.data["Controls"]["data"]
    var = gpx.make_var_obj(name, reloadIdx=False)
    controls.setdefault("parmMinDict", {})[var] = float(low)
    controls.setdefault("parmMaxDict", {})[var] = float(high)


def clear_frozen(gpx):
    gpx.data["Controls"]["data"]["parmFrozen"] = {}


def run(gpx, label, ncyc=12):
    gpx.data["Controls"]["data"]["max cyc"] = ncyc
    gpx.do_refinements([{}])
    h = gpx.histogram(0)
    print("\nRESULT", label, "wR", h.get_wR(), "R", h.residuals.get("R"),
          "mass", h.ComputeMassFracs())
    print("INST", {k: h.InstrumentParameters[k][1:] for k in
                   ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")})
    print("SAMPLE", {k: h.SampleParameters[k] for k in
                     ("Scale", "Shift", "SurfRoughA", "SurfRoughB")})
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        print("PHASE", p.name, p.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "strain", hap["Mustrain"],
              "PO", hap["Pref.Ori."])


def set_profile_flags(hist, names):
    names = set(names)
    for key in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.", "I(L2)/I(L1)"):
        hist.InstrumentParameters[key][2] = key in names


def set_broadening_flags(gpx, enabled):
    h = gpx.histogram(0)
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        hap["Size"][2][0] = bool(enabled)
        hap["Mustrain"][2][0] = bool(enabled)


def configure(gpx):
    gpx.index_ids()
    h = gpx.histogram(0)
    controls = gpx.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    controls["deriv type"] = "analytic Hessian"
    controls["min dM/M"] = 0.00005

    # Eliminate redundant overall/phase scaling.
    hs = float(h.SampleParameters["Scale"][0])
    h.SampleParameters["Scale"][:] = [1.0, False]
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        hap["Scale"][0] *= hs
        hap["Scale"][1] = True
        p.data["General"]["Cell"][0] = True
        # Generator uses one physical Uiso per phase. Fix at a central value
        # until the intensity/texture model is stable.
        for atom in p.atoms():
            atom.uiso = 0.010
            atom.refinement_flags = ""

    inst = h.InstrumentParameters
    for key, val in (("U", 20.0), ("V", 0.0), ("W", 20.0),
                     ("X", 2.0), ("Y", 0.0), ("SH/L", 0.02),
                     ("Polariz.", 0.70), ("I(L2)/I(L1)", 0.50)):
        inst[key][1] = val
        inst[key][2] = False

    for p, size, strain in ((gpx.phase(0), 0.35, 4500.0),
                            (gpx.phase(1), 0.60, 3000.0)):
        hap = p.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][2][0] = True
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][2][0] = True

    # Recreate bounds after project IDs have been indexed.
    for name, lo, hi in ((":0:U", 0, 40), (":0:W", 2, 40),
                         (":0:X", 0.1, 6), (":0:SH/L", 0.005, 0.10),
                         (":0:Polariz.", 0.5, 1.0), (":0:Shift", -800, 800),
                         ("0:0:Size;i", 0.04, 1.5), ("1:0:Size;i", 0.04, 1.5),
                         ("0:0:Mustrain;i", 0, 10000),
                         ("1:0:Mustrain;i", 0, 10000)):
        bound(gpx, name, lo, hi)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    args = ap.parse_args()
    gpx = G2sc.G2Project(args.input, newgpx=args.output)
    configure(gpx)
    h = gpx.histogram(0)

    # First let only specimen broadening adapt to a central instrument model.
    set_profile_flags(h, [])
    set_broadening_flags(gpx, True)
    clear_frozen(gpx)
    run(gpx, "phase broadening", 15)

    # Then determine the common instrumental width with phase terms fixed.
    set_broadening_flags(gpx, False)
    set_profile_flags(h, ["U", "W", "X"])
    clear_frozen(gpx)
    run(gpx, "instrument width", 12)

    # Joint cleanup from the already physical basin.
    set_broadening_flags(gpx, True)
    set_profile_flags(h, ["U", "W", "X"])
    clear_frozen(gpx)
    run(gpx, "joint isotropic width", 12)

    # Axial divergence is fitted with displacement held to avoid a false
    # asymmetry/position tradeoff, then displacement is released again.
    h.SampleParameters["Shift"][1] = False
    set_broadening_flags(gpx, False)
    set_profile_flags(h, ["SH/L"])
    clear_frozen(gpx)
    run(gpx, "axial divergence", 10)

    set_profile_flags(h, [])
    h.SampleParameters["Shift"][1] = True
    clear_frozen(gpx)
    run(gpx, "position cleanup", 8)

    gpx.save(args.output)


if __name__ == "__main__":
    main()
