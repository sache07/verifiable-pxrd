#!/usr/bin/env python3
"""Regularization path for WO3 oxygen displacements using a target RMS in A."""

import argparse
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def lattice_matrix(cell):
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    al, be, ga = [math.radians(cell[k]) for k in
                  ("angle_alpha", "angle_beta", "angle_gamma")]
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * math.cos(ga), b * math.sin(ga), 0.0])
    cx = c * math.cos(be)
    cy = c * (math.cos(al) - math.cos(be) * math.cos(ga)) / math.sin(ga)
    cz = math.sqrt(max(0.0, c * c - cx * cx - cy * cy))
    return np.array([va, vb, [cx, cy, cz]])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("parent_project")
    ap.add_argument("refined_project")
    ap.add_argument("output")
    ap.add_argument("rms", type=float)
    args = ap.parse_args()
    parent = G2sc.G2Project(args.parent_project)
    gpx = G2sc.G2Project(args.refined_project, newgpx=args.output)
    p0 = parent.phase(0)
    phase = gpx.phase(0)
    ref = {a.label: np.array(a.coordinates, float) for a in p0.atoms() if a.element == "O"}
    mat = lattice_matrix(phase.get_cell())
    deltas = []
    for atom in phase.atoms():
        if atom.element != "O":
            continue
        d = np.array(atom.coordinates, float) - ref[atom.label]
        d -= np.round(d)
        deltas.append(d)
    current = math.sqrt(np.mean([np.dot(d @ mat, d @ mat) for d in deltas]))
    factor = args.rms / current if current else 0.0
    for atom in phase.atoms():
        if atom.element != "O":
            continue
        d = np.array(atom.coordinates, float) - ref[atom.label]
        d -= np.round(d)
        atom.coordinates = tuple(ref[atom.label] + factor * d)
        atom.refinement_flags = ""
    gpx.index_ids()
    c = gpx.data["Controls"]["data"]
    c["max cyc"] = 15
    c["parmFrozen"] = {}
    gpx.do_refinements([{}])
    gpx.save(args.output)
    h = gpx.histogram(0)
    print("OXYRMS requested", args.rms, "unconstrained", current, "factor", factor,
          "wR", h.get_wR(), "mass", h.ComputeMassFracs())
    print("OXYGEN", [(a.label, tuple(a.coordinates)) for a in phase.atoms() if a.element == "O"])


if __name__ == "__main__":
    main()
