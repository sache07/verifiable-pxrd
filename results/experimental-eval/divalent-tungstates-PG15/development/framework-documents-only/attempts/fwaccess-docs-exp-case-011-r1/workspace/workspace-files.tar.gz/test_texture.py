#!/usr/bin/env python3
"""Refine one March-Dollase axis from a common project for screening."""

import argparse

from GSASII import GSASIIscriptable as G2sc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("phase", type=int)
    ap.add_argument("h", type=int)
    ap.add_argument("k", type=int)
    ap.add_argument("l", type=int)
    args = ap.parse_args()

    gpx = G2sc.G2Project(args.input, newgpx=args.output)
    gpx.index_ids()
    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = 10
    controls["parmFrozen"] = {}
    phase = gpx.phase(args.phase)
    hist = gpx.histogram(0)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = [args.h, args.k, args.l]
    var = gpx.make_var_obj(f"{args.phase}:0:MD", reloadIdx=False)
    controls.setdefault("parmMinDict", {})[var] = 0.5
    controls.setdefault("parmMaxDict", {})[var] = 2.0
    gpx.do_refinements([{}])
    gpx.save(args.output)
    print("TEXTURE", phase.name, po[3], "MD", po[1], "wR", hist.get_wR(),
          "mass", hist.ComputeMassFracs())


if __name__ == "__main__":
    main()
