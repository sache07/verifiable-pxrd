#!/usr/bin/env python3
"""Refine a selected Chebyshev background order."""

import argparse
from GSASII import GSASIIscriptable as G2sc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("n", type=int)
    args = ap.parse_args()
    gpx = G2sc.G2Project(args.input, newgpx=args.output)
    h = gpx.histogram(0)
    h.set_refinements({"Background": {"type": "chebyschev-1",
                                               "no. coeffs": args.n,
                                               "refine": True}})
    gpx.index_ids()
    gpx.data["Controls"]["data"]["max cyc"] = 15
    gpx.data["Controls"]["data"]["parmFrozen"] = {}
    h.InstrumentParameters["U"][2] = False
    gpx.do_refinements([{}])
    gpx.save(args.output)
    print("BACKGROUND", args.n, "wR", h.get_wR(), "mass", h.ComputeMassFracs(),
          "coeffs", h.data["Background"][0][3:])


if __name__ == "__main__":
    main()
