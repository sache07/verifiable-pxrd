#!/usr/bin/env python3
"""Refine one isotropic displacement parameter per phase."""

import argparse

from GSASII import GSASIIscriptable as G2sc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    args = ap.parse_args()
    gpx = G2sc.G2Project(args.input, newgpx=args.output)
    gpx.index_ids()
    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = 15
    controls["parmFrozen"] = {}
    for phase in gpx.phases():
        names = []
        for i, atom in enumerate(phase.atoms()):
            atom.uiso = 0.010
            atom.refinement_flags = "XU" if "X" in atom.refinement_flags else "U"
            names.append(f"{phase.id}::AUiso:{i}")
        if len(names) > 1:
            gpx.add_EquivConstr(names, reloadIdx=True)
    gpx.do_refinements([{}])
    gpx.save(args.output)
    hist = gpx.histogram(0)
    print("UISO wR", hist.get_wR(), "mass", hist.ComputeMassFracs())
    for p in gpx.phases():
        print("PHASE", p.name, [(a.label, a.uiso, a.refinement_flags) for a in p.atoms()])


if __name__ == "__main__":
    main()
