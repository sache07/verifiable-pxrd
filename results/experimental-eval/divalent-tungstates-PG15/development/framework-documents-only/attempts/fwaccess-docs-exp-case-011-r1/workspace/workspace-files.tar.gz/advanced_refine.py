#!/usr/bin/env python3
"""Physically constrained refinement for the MnO2/WO3 model."""

import argparse
import copy

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2sc


def set_bound(controls, name, low=None, high=None):
    var = G2obj.G2VarObj(name)
    if low is not None:
        controls.setdefault("parmMinDict", {})[var] = float(low)
    if high is not None:
        controls.setdefault("parmMaxDict", {})[var] = float(high)


def summary(gpx, label):
    hist = gpx.histogram(0)
    print("\nSUMMARY", label)
    print("RESIDUALS", hist.residuals)
    print("MASS", hist.ComputeMassFracs())
    print("INST", {key: hist.InstrumentParameters[key] for key in
                   ("U", "V", "W", "X", "Y", "SH/L", "Polariz.", "I(L2)/I(L1)")})
    print("SAMPLE", {key: hist.SampleParameters[key] for key in
                     ("Scale", "Shift", "SurfRoughA", "SurfRoughB", "Gonio. radius")})
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        print("PHASE", phase.name, phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "strain", hap["Mustrain"], "PO", hap["Pref.Ori."])
        print("ATOMS", [(a.label, a.element, tuple(a.coordinates), a.uiso,
                         a.refinement_flags) for a in phase.atoms()])


def run(gpx, label, cycles=12):
    gpx.data["Controls"]["data"]["max cyc"] = cycles
    gpx.do_refinements([{}])
    summary(gpx, label)


def configure_physical_profile(gpx):
    hist = gpx.histogram(0)
    controls = gpx.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["deriv type"] = "analytic Hessian"
    controls["min dM/M"] = 0.00005

    # Remove the redundant histogram/phase scale product. Preserve the
    # calculated intensity by folding the histogram scale into every phase.
    hscale = float(hist.SampleParameters["Scale"][0])
    hist.SampleParameters["Scale"][:] = [1.0, False]
    for phase in gpx.phases():
        phase.data["Histograms"][hist.name]["Scale"][0] *= hscale
        phase.set_HAP_refinements({"Scale": True})

    inst = hist.InstrumentParameters
    for key, value in (("U", 20.0), ("V", 0.0), ("W", 20.0),
                       ("X", 2.0), ("Y", 0.0), ("SH/L", 0.02)):
        inst[key][1] = value
        inst[key][2] = key in ("U", "W", "X", "SH/L")
    # These are fixed by metadata/generator and should not absorb specimen terms.
    inst["I(L2)/I(L1)"][1] = 0.5
    inst["I(L2)/I(L1)"][2] = False
    inst["Polariz."][2] = False

    # Start phase broadening from the middle of the physically allowed regime.
    starts = ((gpx.phase(0), 0.40, 4000.0),
              (gpx.phase(1), 0.40, 3000.0))
    for phase, size, strain in starts:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": size, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = strain

    # Instrument ranges come from the measurement family; broadening outside
    # these ranges belongs in the phase-specific size/strain terms.
    for name, low, high in ((":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0),
                            (":0:X", 0.1, 6.0), (":0:SH/L", 0.005, 0.10),
                            (":0:Polariz.", 0.5, 1.0), (":0:Shift", -800.0, 800.0),
                            ("0:0:Size;i", 0.04, 1.5), ("1:0:Size;i", 0.04, 1.5),
                            ("0:0:Mustrain;i", 0.0, 10000.0),
                            ("1:0:Mustrain;i", 0.0, 10000.0)):
        set_bound(controls, name, low, high)


def add_common_uiso(gpx):
    controls = gpx.data["Controls"]["data"]
    for phase in gpx.phases():
        vars_ = []
        for i, atom in enumerate(phase.atoms()):
            atom.uiso = 0.010
            atom.refinement_flags = "U"
            vars_.append(f"{phase.id}::AUiso:{i}")
            set_bound(controls, vars_[-1], 0.001, 0.03)
        if len(vars_) > 1:
            gpx.add_EquivConstr(vars_, reloadIdx=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--coordinates", choices=("none", "w", "all"), default="none")
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.input, newgpx=args.output)
    configure_physical_profile(gpx)
    run(gpx, "physical isotropic profile", 15)

    add_common_uiso(gpx)
    run(gpx, "common phase Uiso", 12)

    hist = gpx.histogram(0)
    if args.polarization:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        run(gpx, "polarization", 10)

    if args.roughness:
        hist.SampleParameters["SurfRoughA"][0] = 0.10
        hist.SampleParameters["SurfRoughB"][0] = 0.05
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        set_bound(gpx.data["Controls"]["data"], ":0:SurfRoughA", 0.001, 1.0)
        set_bound(gpx.data["Controls"]["data"], ":0:SurfRoughB", 0.001, 1.0)
        run(gpx, "surface roughness", 10)

    if args.coordinates != "none":
        for phase in gpx.phases():
            for atom in phase.atoms():
                if args.coordinates == "all" or atom.element == "W":
                    atom.refinement_flags = "XU"
        run(gpx, args.coordinates + " coordinates", 15)

    gpx.save(args.output)
    summary(gpx, "final")


if __name__ == "__main__":
    main()
