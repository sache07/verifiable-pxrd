#!/usr/bin/env python3
"""Set fixed phase Uiso values and recalculate/refine remaining parameters."""

import argparse

from GSASII import GSASIIscriptable as G2sc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("wo3", type=float)
    ap.add_argument("mno2", type=float)
    args = ap.parse_args()
    gpx = G2sc.G2Project(args.input, newgpx=args.output)
    gpx.index_ids()
    gpx.data["Controls"]["data"]["max cyc"] = 12
    gpx.data["Controls"]["data"]["parmFrozen"] = {}
    for phase, value in zip(gpx.phases(), (args.wo3, args.mno2)):
        for atom in phase.atoms():
            atom.uiso = value
            atom.refinement_flags = "X" if "X" in atom.refinement_flags else ""
    gpx.do_refinements([{}])
    gpx.save(args.output)
    h = gpx.histogram(0)
    print("FIXU", args.wo3, args.mno2, "wR", h.get_wR(), "mass", h.ComputeMassFracs())


if __name__ == "__main__":
    main()
