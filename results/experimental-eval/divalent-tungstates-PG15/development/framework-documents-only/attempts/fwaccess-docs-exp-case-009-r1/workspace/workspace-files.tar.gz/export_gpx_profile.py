import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("project")
parser.add_argument("output")
args = parser.parse_args()

gpx = G2sc.G2Project(args.project)
hist = gpx.histogram(0)
arrays = np.column_stack([
    hist.getdata("X"), hist.getdata("Yobs"), hist.getdata("Ycalc"),
    hist.getdata("Background"), hist.getdata("Residual"),
])
np.savetxt(
    args.output, arrays, delimiter=",",
    header="two_theta_deg,observed,calculated,background,difference", comments="",
)
print("Rwp", hist.get_wR())
