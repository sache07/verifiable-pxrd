from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
SOURCE = WORK / "finaltest_bg42.gpx"


def configure_zero_fixed(histogram):
    histogram.InstrumentParameters["Zero"][1] = 0.0
    histogram.InstrumentParameters["Zero"][2] = False


def configure_shift_fixed(histogram):
    histogram.SampleParameters["Shift"][0] = 0.0
    histogram.SampleParameters["Shift"][1] = False


def configure_both_fixed(histogram):
    configure_zero_fixed(histogram)
    configure_shift_fixed(histogram)


for name, configure in {
    "zero_fixed": configure_zero_fixed,
    "shift_fixed": configure_shift_fixed,
    "both_fixed": configure_both_fixed,
}.items():
    output = WORK / f"conditioned_{name}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    histogram = project.histogram(0)
    configure(histogram)
    project.set_Controls("cycles", 12)
    for pass_number in (1, 2):
        project.do_refinements([{}])
        print(name, pass_number, histogram.get_wR())
    project.save()
    print(
        "RESULT", name,
        histogram.residuals,
        project["Covariance"]["data"]["Rvals"],
        "zero", histogram.InstrumentParameters["Zero"],
        "shift", histogram.SampleParameters["Shift"],
    )
