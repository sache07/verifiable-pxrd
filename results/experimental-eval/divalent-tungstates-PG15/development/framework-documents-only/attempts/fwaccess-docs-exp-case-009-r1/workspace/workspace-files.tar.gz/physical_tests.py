from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / "trial_mnwo4.gpx"


def run_branch(name, modifier, passes=2):
    output = WORK / f"physical_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(output))
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    gpx.set_Controls("cycles", 12)
    modifier(gpx, hist, phase)
    for _ in range(passes):
        gpx.do_refinements([{}])
    gpx.save()
    print(f"RESULT {name} Rwp={hist.get_wR():.8f}")
    print("  roughness", hist.SampleParameters["SurfRoughA"], hist.SampleParameters["SurfRoughB"])
    print("  instrument", {k: v[1] for k, v in hist.InstrumentParameters.items()
                           if k in ("U", "W", "X", "SH/L", "Polariz.")})
    print("  background terms", hist.Background[0][2])
    print("  atoms", [(a.label, a.adp_flag, a.ADP) for a in phase.atoms()])


def fixed_surface(a_value):
    def modify(gpx, hist, phase):
        hist.SampleParameters["SurfRoughA"][:] = [a_value, False]
        hist.SampleParameters["SurfRoughB"][:] = [0.15, True]
    return modify


def isotropic_adps(common):
    def modify(gpx, hist, phase):
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = 0.007
            atom.refinement_flags = "XU"
        if common:
            gpx.add_EquivConstr(
                tuple(f"0::AUiso:{i}" for i, _ in enumerate(phase.atoms())),
                reloadIdx=True,
            )
    return modify


def background_terms(number):
    def modify(gpx, hist, phase):
        hist.set_refinements({"Background": {"no. coeffs": number, "refine": True}})
    return modify


tests = {
    "surface_005": fixed_surface(0.05),
    "surface_010": fixed_surface(0.10),
    "surface_020": fixed_surface(0.20),
    "surface_030": fixed_surface(0.30),
    "surface_050": fixed_surface(0.50),
    "iso_adps_independent": isotropic_adps(False),
    "iso_adps_common": isotropic_adps(True),
    "background_24": background_terms(24),
    "background_30": background_terms(30),
}

for test_name, test_modifier in tests.items():
    try:
        run_branch(test_name, test_modifier)
    except Exception as exc:
        print(f"FAILED {test_name}: {type(exc).__name__}: {exc}")
