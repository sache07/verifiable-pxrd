from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / "physical_surface_005.gpx"


def configure(hist, phase, background=30, micro_axis=None, po_axis=None):
    hist.set_refinements({"Background": {"no. coeffs": background, "refine": True}})
    if micro_axis is not None:
        phase.setSampleProfile(
            hist, "microstrain", "uniaxial", 300.0, 500.0,
            list(micro_axis), LGmix=1.0,
        )
        phase.set_HAP_refinements({
            "Mustrain": {
                "type": "uniaxial", "refine": True,
                "direction": list(micro_axis),
                "LGmix": {"value": 1.0, "refine": False},
            }
        })
    if po_axis is not None:
        pref = phase.getHAPvalues(hist)["Pref.Ori."]
        pref[0] = "MD"
        pref[1] = 1.01
        pref[2] = True
        pref[3] = list(po_axis)


tests = {
    "bg30": dict(background=30),
    "bg36": dict(background=36),
    "bg42": dict(background=42),
    "bg30_micro001": dict(background=30, micro_axis=(0, 0, 1)),
    "bg30_micro100": dict(background=30, micro_axis=(1, 0, 0)),
    "bg30_po100": dict(background=30, po_axis=(1, 0, 0)),
    "bg30_micro001_po100": dict(
        background=30, micro_axis=(0, 0, 1), po_axis=(1, 0, 0)
    ),
    "bg36_micro001_po100": dict(
        background=36, micro_axis=(0, 0, 1), po_axis=(1, 0, 0)
    ),
}

for name, options in tests.items():
    try:
        output = WORK / f"combo_{name}.gpx"
        gpx = G2sc.G2Project(str(BASE), newgpx=str(output))
        hist = gpx.histogram(0)
        phase = gpx.phase(0)
        gpx.set_Controls("cycles", 12)
        configure(hist, phase, **options)
        for pass_number in (1, 2):
            gpx.do_refinements([{}])
            print(f"PASS {name} {pass_number} Rwp={hist.get_wR():.8f}")
        gpx.save()
        hap = phase.getHAPvalues(hist)
        print(f"RESULT {name} Rwp={hist.get_wR():.8f}")
        print("  roughness", hist.SampleParameters["SurfRoughA"], hist.SampleParameters["SurfRoughB"])
        print("  instrument", {k: v[1] for k, v in hist.InstrumentParameters.items()
                               if k in ("U", "W", "X", "SH/L", "Polariz.")})
        print("  Mustrain", hap["Mustrain"])
        print("  PO", hap["Pref.Ori."])
    except Exception as exc:
        print(f"FAILED {name}: {type(exc).__name__}: {exc}")
