from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
PATTERN = WORK / "inputs" / "pattern.csv"
INSTRUMENT = WORK / "instrument.instprm"
REFERENCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)
PROJECT = WORK / "trial_mnwo4.gpx"


def snapshot(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    hap = phase.getHAPvalues(hist)
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print("cell", phase.get_cell())
    print(
        "instrument",
        {key: inst[key][1] for key in inst if key in {
            "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L",
            "I(L2)/I(L1)",
        }},
    )
    print(
        "sample",
        {key: sample[key][0] for key in sample if key in {
            "Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"
        }},
    )
    print(
        "hap",
        {key: hap[key] for key in ("Scale", "Size", "Mustrain", "HStrain", "Pref.Ori.")},
    )
    print("background", hist.Background[0])


gpx = G2sc.G2Project(newgpx=str(PROJECT))
hist = gpx.add_powder_histogram(
    str(PATTERN), str(INSTRUMENT), fmthint="comma/tab/semicolon separated"
)
phase = gpx.add_phase(
    str(REFERENCE), phasename="MnWO4", histograms=[hist], fmthint="CIF"
)

hist.set_refinements({
    "Limits": [10.0, 100.0],
    "Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": 12,
    },
})
phase.set_HAP_refinements({"Scale": True})
gpx.set_Controls("cycles", 5)
gpx.save()

steps = [
    ("scale_background", None),
    ("zero", {"Instrument Parameters": ["Zero"]}),
    ("cell", {"Cell": True}),
    ("profile_gaussian", {"Instrument Parameters": ["U", "W"]}),
    ("profile_lorentz_asym", {"Instrument Parameters": ["X", "SH/L"]}),
    ("sample_shift", {"Sample Parameters": ["Shift"]}),
]

for label, settings in steps:
    if settings:
        gpx.set_refinement({"set": settings})
    gpx.do_refinements([{}])
    snapshot(gpx, label)

gpx.save()

hist = gpx.histogram(0)
arrays = np.column_stack([
    hist.getdata("X"),
    hist.getdata("Yobs"),
    hist.getdata("Ycalc"),
    hist.getdata("Background"),
    hist.getdata("Residual"),
])
np.savetxt(
    WORK / "trial_fit.csv",
    arrays,
    delimiter=",",
    header="two_theta_deg,observed,calculated,background,difference",
    comments="",
)
