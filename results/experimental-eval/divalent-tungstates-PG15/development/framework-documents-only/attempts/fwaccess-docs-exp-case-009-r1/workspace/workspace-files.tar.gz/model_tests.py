from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / "trial_mnwo4.gpx"


def refine_branch(name, modifier):
    output = WORK / f"test_{name}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(output))
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    gpx.set_Controls("cycles", 12)
    modifier(hist, phase)
    gpx.do_refinements([{}])
    # A second pass is useful when position/profile correlations are strong.
    gpx.do_refinements([{}])
    gpx.save()
    hap = phase.getHAPvalues(hist)
    print(f"RESULT {name} Rwp={hist.get_wR():.8f}")
    print("  instrument", {k: v[1] for k, v in hist.InstrumentParameters.items()
                           if k in ("U", "W", "X", "SH/L", "Polariz.")})
    print("  roughness", hist.SampleParameters["SurfRoughA"], hist.SampleParameters["SurfRoughB"])
    print("  Mustrain", hap["Mustrain"])
    print("  Size", hap["Size"])
    print("  PO", hap["Pref.Ori."])
    print("  atoms", [(a.label, a.coordinates, a.ADP) for a in phase.atoms()])


def unchanged(hist, phase):
    pass


def oxygen_adp(hist, phase):
    for atom in phase.atoms():
        atom.refinement_flags = "XU" if atom.element == "O" else "X"


def all_adp(hist, phase):
    for atom in phase.atoms():
        atom.refinement_flags = "XU"


def po(axis):
    def modify(hist, phase):
        pref = phase.getHAPvalues(hist)["Pref.Ori."]
        pref[0] = "MD"
        pref[1] = 1.02
        pref[2] = True
        pref[3] = list(axis)
    return modify


def microstrain(mode, axis=None):
    def modify(hist, phase):
        if mode == "isotropic":
            phase.setSampleProfile(hist, "microstrain", "isotropic", 300.0, LGmix=1.0)
            phase.set_HAP_refinements({
                "Mustrain": {"type": "isotropic", "refine": True,
                              "LGmix": {"value": 1.0, "refine": False}}
            })
        else:
            phase.setSampleProfile(
                hist, "microstrain", "uniaxial", 300.0, 500.0, list(axis), LGmix=1.0
            )
            phase.set_HAP_refinements({
                "Mustrain": {"type": "uniaxial", "refine": True,
                              "direction": list(axis),
                              "LGmix": {"value": 1.0, "refine": False}}
            })
    return modify


tests = {
    "control": unchanged,
    "oxygen_adp": oxygen_adp,
    "all_adp": all_adp,
    "po_001": po((0, 0, 1)),
    "po_100": po((1, 0, 0)),
    "po_010": po((0, 1, 0)),
    "po_110": po((1, 1, 0)),
    "po_111": po((1, 1, 1)),
    "micro_iso": microstrain("isotropic"),
    "micro_001": microstrain("uniaxial", (0, 0, 1)),
    "micro_100": microstrain("uniaxial", (1, 0, 0)),
    "micro_010": microstrain("uniaxial", (0, 1, 0)),
}

for test_name, test_modifier in tests.items():
    try:
        refine_branch(test_name, test_modifier)
    except Exception as exc:
        print(f"FAILED {test_name}: {type(exc).__name__}: {exc}")
