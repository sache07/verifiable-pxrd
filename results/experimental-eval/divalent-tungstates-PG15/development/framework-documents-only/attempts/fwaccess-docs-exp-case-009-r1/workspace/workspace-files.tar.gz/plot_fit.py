from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


work = Path(__file__).resolve().parent
a = np.loadtxt(work / "trial_fit.csv", delimiter=",", skiprows=1)
x, yobs, ycalc, background, difference = a.T

fig, axes = plt.subplots(4, 1, figsize=(16, 12), constrained_layout=True)
windows = [(10, 35), (35, 60), (60, 82), (82, 100)]
for ax, (lo, hi) in zip(axes, windows):
    use = (x >= lo) & (x <= hi)
    ax.plot(x[use], yobs[use], color="black", lw=0.65, label="observed")
    ax.plot(x[use], ycalc[use], color="tab:red", lw=0.7, label="calculated")
    ax.plot(x[use], difference[use] + 100, color="tab:blue", lw=0.6, label="difference + 100")
    ax.plot(x[use], background[use], color="tab:green", lw=0.5, alpha=0.8, label="background")
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
axes[0].legend(ncol=4, loc="upper right")
axes[-1].set_xlabel(r"$2\theta$ (degrees)")
fig.savefig(work / "trial_fit.png", dpi=150)
