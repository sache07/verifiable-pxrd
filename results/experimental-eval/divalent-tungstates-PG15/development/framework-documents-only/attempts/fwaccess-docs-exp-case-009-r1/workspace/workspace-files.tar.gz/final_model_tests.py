from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / "grid_uiso_0p0030.gpx"


def modify_model(hist, phase, background=30, po_axis=(1, 0, 0), uiso=0.003):
    hist.set_refinements({"Background": {"no. coeffs": background, "refine": True}})
    pref = phase.getHAPvalues(hist)["Pref.Ori."]
    if po_axis is None:
        pref[0] = "MD"
        pref[1] = 1.0
        pref[2] = False
    else:
        pref[0] = "MD"
        pref[1] = 1.004
        pref[2] = True
        pref[3] = list(po_axis)
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = uiso
        atom.refinement_flags = "X"


tests = {
    "control": {},
    "no_po": {"po_axis": None},
    "bg42": {"background": 42},
    "bg42_no_po": {"background": 42, "po_axis": None},
    "bg42_po001": {"background": 42, "po_axis": (0, 0, 1)},
    "bg42_po010": {"background": 42, "po_axis": (0, 1, 0)},
    "bg42_po110": {"background": 42, "po_axis": (1, 1, 0)},
    "bg42_po111": {"background": 42, "po_axis": (1, 1, 1)},
    "bg42_u002": {"background": 42, "uiso": 0.002},
    "bg42_u004": {"background": 42, "uiso": 0.004},
    "bg54": {"background": 54},
}

for name, options in tests.items():
    try:
        output = WORK / f"finaltest_{name}.gpx"
        gpx = G2sc.G2Project(str(BASE), newgpx=str(output))
        hist = gpx.histogram(0)
        phase = gpx.phase(0)
        modify_model(hist, phase, **options)
        gpx.set_Controls("cycles", 12)
        for pass_number in (1, 2):
            gpx.do_refinements([{}])
            print(f"PASS {name} {pass_number} Rwp={hist.get_wR():.8f}")
        gpx.save()
        hap = phase.getHAPvalues(hist)
        print(
            f"RESULT {name} Rwp={hist.get_wR():.8f} "
            f"PO={hap['Pref.Ori.']} BG={hist.Background[0][2]}"
        )
    except Exception as exc:
        print(f"FAILED {name}: {type(exc).__name__}: {exc}")
