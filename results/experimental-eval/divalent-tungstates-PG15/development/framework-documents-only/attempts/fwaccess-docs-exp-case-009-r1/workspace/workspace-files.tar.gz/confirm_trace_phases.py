from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
SOURCE = WORK / "finaltest_bg42.gpx"
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
CANDIDATES = {
    "Mn3O4": COD / "9/00/19/9001963.cif",
    "MnO": COD / "1/51/41/1514108.cif",
    "Mn2O3": COD / "1/01/05/1010586.cif",
    "Mn3WO6": COD / "2/00/27/2002703.cif",
    "WO3_monoclinic": COD / "1/52/89/1528915.cif",
    "WO3_triclinic": COD / "2/10/62/2106293.cif",
}


def freeze_final_model(hist, phase):
    # Background clearing returns immediately in the GSAS-II scripting API, so
    # clear it separately before fixing the remaining histogram parameters.
    hist.clear_refinements({"Background": True})
    sample_flags = [
        key
        for key, value in hist.SampleParameters.items()
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)
    ]
    instrument_flags = [
        key
        for key, value in hist.InstrumentParameters.items()
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool)
    ]
    hist.clear_refinements(
        {
            "Sample Parameters": sample_flags,
            "Instrument Parameters": instrument_flags,
        }
    )
    phase.clear_refinements(
        {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
    )
    phase.clear_HAP_refinements(
        {
            "Scale": True,
            "Mustrain": True,
            "Size": True,
            "Pref.Ori.": True,
            "HStrain": True,
            "Extinction": True,
            "Babinet": ["BabA", "BabU"],
        },
        [hist],
    )


for name, cif_path in CANDIDATES.items():
    output = WORK / f"confirm_trace_{name}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    histogram = project.histogram(0)
    freeze_final_model(histogram, project.phase(0))
    candidate = project.add_phase(
        str(cif_path), phasename=name, histograms=[histogram], fmthint="CIF"
    )
    candidate.HAPvalue("Scale", 0.01)
    candidate.set_HAP_refinements({"Scale": True}, [histogram])
    project.set_Controls("cycles", 12)
    project.do_refinements([{}])
    project.save()
    print(
        name,
        "Rwp", histogram.get_wR(),
        "residuals", histogram.residuals,
        "scale", candidate.HAPvalue("Scale"),
        "mass_fractions", histogram.ComputeMassFracs(),
    )
