from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
SOURCE = WORK / "finaltest_bg42.gpx"
FINAL = WORK / "final.gpx"
CIF = WORK / "phase_MnWO4.cif"
FIT = WORK / "fit.csv"


# Preserve the selected, refined model under the requested final project name.
project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
project.save()
histogram = project.histogram(0)
phase = project.phase(0)
phase.export_CIF(str(CIF))

# GSAS-II evaluates one grid point just beyond the nominal upper limit. Use the
# same index convention so the profile and statistics cover all 8,284 refined
# observations recorded in the project.
x = np.asarray(histogram.getdata("x"), dtype=float)
observed = np.asarray(histogram.getdata("yobs"), dtype=float)
calculated = np.asarray(histogram.getdata("ycalc"), dtype=float)
background = np.asarray(histogram.getdata("background"), dtype=float)
weights = np.asarray(histogram.getdata("yweight"), dtype=float)
low_limit, high_limit = histogram.data["Limits"][1]
first, last = np.searchsorted(x, [low_limit, high_limit])
used = slice(first, last + 1)
difference = observed[used] - calculated[used]

profile = np.column_stack(
    [
        x[used],
        observed[used],
        calculated[used],
        difference,
        background[used],
    ]
)
np.savetxt(
    FIT,
    profile,
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference,background",
    comments="",
    fmt=["%.8f", "%.6f", "%.6f", "%.6f", "%.6f"],
)

covariance = project["Covariance"]["data"]
rvals = covariance["Rvals"]
chi_squared = float(np.sum(weights[used] * difference**2))
assert profile.shape[0] == rvals["Nobs"]
assert np.isclose(chi_squared, rvals["chisq"], rtol=0, atol=1e-6)
assert np.allclose(
    difference,
    np.asarray(histogram.getdata("residual"), dtype=float)[used],
    rtol=0,
    atol=1e-10,
)

print("final_project", FINAL.name)
print("phase_cif", CIF.name)
print("profile", FIT.name, profile.shape)
print("cell", phase.get_cell())
print("residuals", histogram.residuals)
print("refinement", rvals)
