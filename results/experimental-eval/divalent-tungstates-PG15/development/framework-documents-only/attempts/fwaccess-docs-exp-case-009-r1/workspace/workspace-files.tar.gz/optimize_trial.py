from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(WORK / "trial_mnwo4.gpx"))
hist = gpx.histogram(0)
phase = gpx.phase(0)
gpx.set_Controls("cycles", 12)


def run(label):
    gpx.do_refinements([{}])
    print(f"\n--- {label}: Rwp={hist.get_wR():.6f} ---")
    print("residuals", hist.residuals)
    print("cell", phase.get_cell())
    print("instrument", {k: v[1] for k, v in hist.InstrumentParameters.items() if k in (
        "Zero", "Polariz.", "I(L2)/I(L1)", "U", "V", "W", "X", "Y", "Z", "SH/L"
    )})
    print("sample", {k: v for k, v in hist.SampleParameters.items() if k in (
        "Scale", "Shift", "SurfRoughA", "SurfRoughB"
    )})
    print("background", hist.Background[0])
    print("hap", {k: phase.getHAPvalues(hist)[k] for k in (
        "Scale", "Size", "Mustrain", "Pref.Ori."
    )})
    for atom in phase.atoms():
        print("atom", atom.label, atom.coordinates, atom.adp_flag, atom.ADP, atom.refinement_flags)


# Remove the exact sample-scale/phase-scale degeneracy.
hist.SampleParameters["Scale"][:] = [1.0, False]
run("fixed sample scale")

# Suortti roughness needs a nonzero starting point for both derivatives.
hist.SampleParameters["SurfRoughA"][:] = [0.25, False]
hist.SampleParameters["SurfRoughB"][:] = [0.10, False]
hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
run("surface roughness")

hist.set_refinements({"Instrument Parameters": ["Polariz."]})
run("polarization")

# Give the smooth, strongly decaying background more flexibility.
hist.set_refinements({"Background": {"no. coeffs": 18, "refine": True}})
run("18-term background")

gpx.save()
arrays = np.column_stack([
    hist.getdata("X"), hist.getdata("Yobs"), hist.getdata("Ycalc"),
    hist.getdata("Background"), hist.getdata("Residual"),
])
np.savetxt(
    WORK / "trial_fit.csv", arrays, delimiter=",",
    header="two_theta_deg,observed,calculated,background,difference", comments="",
)
