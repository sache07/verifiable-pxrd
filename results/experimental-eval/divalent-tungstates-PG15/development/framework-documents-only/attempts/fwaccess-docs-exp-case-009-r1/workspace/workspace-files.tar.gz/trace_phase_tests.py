from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / "combo_bg30_micro001_po100.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = {
    "Mn3WO6": COD / "2/00/27/2002703.cif",
    "Mn3O4": COD / "9/00/19/9001963.cif",
    "WO3": COD / "2/10/62/2106293.cif",
}

for name, cif_path in CANDIDATES.items():
    try:
        output = WORK / f"trace_{name}.gpx"
        gpx = G2sc.G2Project(str(BASE), newgpx=str(output))
        hist = gpx.histogram(0)
        phase = gpx.add_phase(
            str(cif_path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        phase.HAPvalue("Scale", 0.20)
        phase.set_HAP_refinements({"Scale": True})
        gpx.set_Controls("cycles", 12)
        for pass_number in (1, 2):
            gpx.do_refinements([{}])
            print(
                f"PASS {name} {pass_number} Rwp={hist.get_wR():.8f} "
                f"secondary_scale={phase.HAPvalue('Scale'):.10g}"
            )
        gpx.save()
        print("RESULT", name, hist.ComputeMassFracs())
    except Exception as exc:
        print(f"FAILED {name}: {type(exc).__name__}: {exc}")
