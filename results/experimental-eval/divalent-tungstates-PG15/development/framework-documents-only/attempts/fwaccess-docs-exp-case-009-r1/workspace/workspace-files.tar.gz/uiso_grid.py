from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
BASE = WORK / "combo_bg30_micro001_po100.gpx"

for uiso in (0.0005, 0.003, 0.005, 0.007, 0.010, 0.015):
    name = f"uiso_{uiso:.4f}".replace(".", "p")
    try:
        output = WORK / f"grid_{name}.gpx"
        gpx = G2sc.G2Project(str(BASE), newgpx=str(output))
        hist = gpx.histogram(0)
        phase = gpx.phase(0)
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = uiso
            atom.refinement_flags = "X"
        gpx.set_Controls("cycles", 12)
        for pass_number in (1, 2):
            gpx.do_refinements([{}])
            print(f"PASS {name} {pass_number} Rwp={hist.get_wR():.8f}")
        gpx.save()
        print("RESULT", name, hist.get_wR(), [(a.label, a.ADP) for a in phase.atoms()])
    except Exception as exc:
        print(f"FAILED {name}: {type(exc).__name__}: {exc}")
