from pathlib import Path

from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
FILES = {
    "MnWO4": "1/52/02/1520200.cif",
    "Mn3WO6": "2/00/27/2002703.cif",
    "Mn3O4": "9/00/19/9001963.cif",
    "WO3": "2/10/62/2106293.cif",
}

for name, relative_path in FILES.items():
    structure = Structure.from_file(ROOT / relative_path)
    pattern = XRDCalculator(wavelength=1.540598).get_pattern(
        structure, two_theta_range=(9.8, 100.2)
    )
    print(f"\n{name}: {structure.composition.reduced_formula}")
    print(structure.lattice)
    print(f"Reflections: {len(pattern.x)}")
    strongest = sorted(
        zip(pattern.x, pattern.y, pattern.hkls), key=lambda row: row[1], reverse=True
    )[:30]
    for two_theta, intensity, hkl_group in strongest:
        hkl = hkl_group[0]["hkl"]
        print(f"{two_theta:8.3f} {intensity:7.2f} {hkl}")
