#!/usr/bin/env python3
"""Make one controlled GSAS-II branch from a stable powder project."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from screen_refine import (
    MGO,
    WO3_CANDIDATES,
    covariance_status,
    project_summary,
    stable_refine,
)


PROFILE_STARTS = {"U": 10.0, "V": 0.0, "X": 2.0, "Y": 2.0, "Z": 2.0}

# Audited COD 9013902 starting model, used only for matched omission tests.
MGWO4_SOURCE_ATOMS = {
    "Mg": ((0.50000, 0.67420, 0.25000), 0.00790),
    "W": ((0.00000, 0.18190, 0.25000), 0.00520),
    "O1": ((0.21600, 0.10700, 0.93700), 0.00840),
    "O2": ((0.25600, 0.37660, 0.39700), 0.00700),
}


def phase_by_token(project: G2sc.G2Project, token: str):
    exact = [phase for phase in project.phases() if phase.name == token]
    if exact:
        return exact[0]
    matches = [phase for phase in project.phases() if token.lower() in phase.name.lower()]
    if len(matches) != 1:
        raise ValueError(
            f"phase token {token!r} matched {[phase.name for phase in matches]}"
        )
    return matches[0]


def remove_phase(project: G2sc.G2Project, token: str) -> str:
    phase = phase_by_token(project, token)
    name = phase.name
    removed_ran_id = phase.ranId
    constraints = project.data.get("Constraints", {}).get("data", {})
    for scope, rows in list(constraints.items()):
        if not isinstance(rows, list):
            continue
        constraints[scope] = [
            constraint
            for constraint in rows
            if not any(
                isinstance(term, list)
                and len(term) == 2
                and getattr(term[1], "phase", None) == removed_ran_id
                for term in constraint
            )
        ]
    del project.data["Phases"][name]
    for item in project.names:
        if item and item[0] == "Phases" and name in item:
            item.remove(name)
    for histogram in project.histograms():
        histogram.data.get("Reflection Lists", {}).pop(name, None)
    project.update_ids()
    return name


def add_phase(project: G2sc.G2Project, path: Path, name: str) -> None:
    project.add_phase(
        str(path), phasename=name, histograms=project.histograms(), fmthint="CIF"
    )
    histogram = project.histograms()[0]
    project.phase(name).data["Histograms"][histogram.name]["Scale"][1] = True


def max_correlations(project: G2sc.G2Project, threshold: float = 0.8) -> list[dict]:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    diagonal = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    results = []
    for first in range(len(names)):
        for second in range(first + 1, len(names)):
            denominator = diagonal[first] * diagonal[second]
            if denominator <= 0:
                continue
            correlation = float(matrix[first, second] / denominator)
            if abs(correlation) >= threshold:
                results.append(
                    {
                        "first": names[first],
                        "second": names[second],
                        "correlation": correlation,
                    }
                )
    return sorted(results, key=lambda item: abs(item["correlation"]), reverse=True)


def extended_summary(project: G2sc.G2Project, path: Path) -> dict:
    project.save(str(path))
    summary = project_summary(path)
    histogram = project.histograms()[0]
    summary["sample_parameters"] = histogram.SampleParameters
    summary["instrument_parameters"] = histogram.InstrumentParameters
    summary["max_correlations"] = max_correlations(project)
    summary["hap"] = {
        phase.name: {
            key: phase.data["Histograms"][histogram.name].get(key)
            for key in ("Size", "Mustrain", "Pref.Ori.", "HStrain")
        }
        for phase in project.phases()
    }
    return summary


def configure(project: G2sc.G2Project, args) -> list[str]:
    histogram = project.histograms()[0]
    notes = []
    if args.operation == "minimal-profile":
        for key in ("U", "V", "X", "Y", "Z"):
            histogram.InstrumentParameters[key][1] = 0.0
            histogram.InstrumentParameters[key][2] = False
        histogram.InstrumentParameters["W"][2] = True
        notes.append("set U,V,X,Y,Z to zero and retained refined W")
    elif args.operation == "zero-microstructure":
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1000.0
            hap["Size"][2] = [False] * len(hap["Size"][2])
            hap["Size"][5] = [False] * len(hap["Size"][5])
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        notes.append("set all phase size to 1000 um and microstrain to zero")
    elif args.operation == "profile":
        for key in args.parameters.split(","):
            key = key.strip()
            if key not in histogram.InstrumentParameters:
                raise ValueError(f"unknown instrument parameter {key}")
            if key in PROFILE_STARTS and abs(float(histogram.InstrumentParameters[key][1])) < 1e-12:
                histogram.InstrumentParameters[key][1] = PROFILE_STARTS[key]
            histogram.InstrumentParameters[key][2] = True
            notes.append(f"refine instrument {key}")
    elif args.operation == "clear-profile":
        for key in args.parameters.split(","):
            key = key.strip()
            if key not in histogram.InstrumentParameters:
                raise ValueError(f"unknown instrument parameter {key}")
            histogram.InstrumentParameters[key][1] = 0.0
            histogram.InstrumentParameters[key][2] = False
            notes.append(f"removed instrument {key}")
    elif args.operation in ("size", "strain"):
        phase = phase_by_token(project, args.phase)
        if args.operation == "size":
            phase.setSampleProfile(histogram, "size", "isotropic", args.start)
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "refine": True}}, [histogram]
            )
        else:
            phase.setSampleProfile(histogram, "microstrain", "isotropic", args.start)
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}, [histogram]
            )
        notes.append(f"refine isotropic {args.operation} for {phase.name}")
    elif args.operation == "texture":
        phase = phase_by_token(project, args.phase)
        axis = [int(value) for value in args.axis.split(",")]
        if len(axis) != 3 or axis == [0, 0, 0]:
            raise ValueError("axis must be nonzero h,k,l")
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        notes.append(f"refine March-Dollase {axis} for {phase.name}")
    elif args.operation == "clear-texture":
        phase = phase_by_token(project, args.phase)
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        notes.append(f"removed March-Dollase correction for {phase.name}")
    elif args.operation == "coordinates":
        phase = phase_by_token(project, args.phase)
        phase.set_refinements({"Atoms": {"all": "X"}})
        notes.append(f"refine coordinates for {phase.name}")
    elif args.operation == "adp":
        phase = phase_by_token(project, args.phase)
        phase.set_refinements({"Atoms": {"all": "U"}})
        notes.append(f"refine isotropic ADPs for {phase.name}")
    elif args.operation == "coordinates-adp":
        phase = phase_by_token(project, args.phase)
        phase.set_refinements({"Atoms": {"all": "XU"}})
        notes.append(f"refine coordinates and isotropic ADPs for {phase.name}")
    elif args.operation == "grouped-adp":
        phase = phase_by_token(project, args.phase)
        _, ct, _, cia = phase.data["General"]["AtomPtrs"]
        groups = {}
        for index, atom in enumerate(phase.data["Atoms"]):
            element = atom[ct]
            atom[cia + 1] = 0.005 if element == "W" else 0.010
            groups.setdefault(element, []).append(index)
        phase.set_refinements({"Atoms": {"all": "U"}})
        project.index_ids()
        phase_id = phase.data["pId"]
        for indices in groups.values():
            if len(indices) > 1:
                project.add_EquivConstr(
                    tuple(f"{phase_id}::AUiso:{index}" for index in indices),
                    reloadIdx=False,
                )
        notes.append(f"refine element-grouped isotropic ADPs for {phase.name}")
    elif args.operation == "common-adp":
        phase = phase_by_token(project, args.phase)
        _, _, _, cia = phase.data["General"]["AtomPtrs"]
        for atom in phase.data["Atoms"]:
            atom[cia + 1] = 0.005
        phase.set_refinements({"Atoms": {"all": "U"}})
        project.index_ids()
        phase_id = phase.data["pId"]
        project.add_EquivConstr(
            tuple(
                f"{phase_id}::AUiso:{index}"
                for index in range(len(phase.data["Atoms"]))
            ),
            reloadIdx=False,
        )
        notes.append(f"refine one common isotropic ADP for {phase.name}")
    elif args.operation in (
        "reset-coordinates",
        "reset-adp",
        "reset-coordinates-adp",
    ):
        phase = phase_by_token(project, args.phase)
        if "mgwo4" not in phase.name.lower():
            raise ValueError("source reset is defined only for MgWO4")
        cx, _, _, cia = phase.data["General"]["AtomPtrs"]
        reset_x = args.operation in ("reset-coordinates", "reset-coordinates-adp")
        reset_u = args.operation in ("reset-adp", "reset-coordinates-adp")
        for atom in phase.data["Atoms"]:
            coordinates, uiso = MGWO4_SOURCE_ATOMS[atom[0]]
            if reset_x:
                atom[cx : cx + 3] = coordinates
                atom[2] = atom[2].replace("X", "")
            if reset_u:
                atom[cia + 1] = uiso
                atom[2] = atom[2].replace("U", "")
        notes.append(f"restored {args.operation.removeprefix('reset-')} from COD 9013902")
    elif args.operation == "polarization":
        histogram.InstrumentParameters["Polariz."][2] = True
        notes.append("refine polarization")
    elif args.operation == "surface-roughness":
        histogram.SampleParameters["SurfRoughA"][:] = [args.start, True]
        if args.second is not None:
            histogram.SampleParameters["SurfRoughB"][:] = [args.second, True]
        notes.append("refine surface roughness")
    elif args.operation == "asymmetry":
        histogram.InstrumentParameters["SH/L"][2] = True
        notes.append("refine axial divergence SH/L")
    elif args.operation == "drop-phase":
        removed = remove_phase(project, args.phase)
        notes.append(f"removed {removed}")
    elif args.operation == "replace-wo3":
        removed = remove_phase(project, "wo3")
        add_phase(project, WO3_CANDIDATES[args.candidate], args.candidate)
        replacement = phase_by_token(project, args.candidate)
        # Match the retained WO3 nuisance model: negligible fixed size
        # broadening and one independently supported isotropic strain term.
        replacement.setSampleProfile(histogram, "size", "isotropic", 10.0)
        replacement.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": False}}, [histogram]
        )
        replacement.setSampleProfile(
            histogram, "microstrain", "isotropic", 1250.0
        )
        replacement.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [histogram]
        )
        notes.append(
            f"replaced {removed} by {args.candidate} with matched WO3 strain model"
        )
    else:
        raise ValueError(args.operation)
    return notes


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument(
        "operation",
        choices=(
            "minimal-profile",
            "zero-microstructure",
            "profile",
            "clear-profile",
            "size",
            "strain",
            "texture",
            "clear-texture",
            "coordinates",
            "adp",
            "coordinates-adp",
            "grouped-adp",
            "common-adp",
            "reset-coordinates",
            "reset-adp",
            "reset-coordinates-adp",
            "polarization",
            "surface-roughness",
            "asymmetry",
            "drop-phase",
            "replace-wo3",
        ),
    )
    parser.add_argument("--parameters")
    parser.add_argument("--phase")
    parser.add_argument("--axis")
    parser.add_argument("--start", type=float, default=1.0)
    parser.add_argument("--second", type=float)
    parser.add_argument("--candidate", choices=sorted(WO3_CANDIDATES))
    parser.add_argument("--attempts", type=int, default=4)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source), newgpx=str(args.destination))
    project.set_Controls("cycles", 8)
    notes = configure(project, args)
    project.save(str(args.destination))
    stages = []
    # A newly imported replacement first gets a scale/background pass with its
    # cell fixed, then joins the common cell refinement.
    if args.operation == "replace-wo3":
        new_phase = phase_by_token(project, args.candidate)
        existing_cell_flags = {
            phase.name: phase.data["General"]["Cell"][0]
            for phase in project.phases()
        }
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = False
        stages.append(stable_refine(project, "replacement_scale", args.attempts))
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = existing_cell_flags.get(
                phase.name, phase is new_phase
            )
        new_phase.data["General"]["Cell"][0] = True
    stages.append(stable_refine(project, args.operation, args.attempts))
    summary = extended_summary(project, args.destination)
    summary["notes"] = notes
    summary["stages"] = stages
    print("BRANCH_RESULT=" + json.dumps(summary, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
