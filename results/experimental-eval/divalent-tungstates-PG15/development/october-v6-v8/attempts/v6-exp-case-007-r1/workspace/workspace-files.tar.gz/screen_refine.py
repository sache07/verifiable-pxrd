#!/usr/bin/env python3
"""Build matched GSAS-II screening branches for the MgO--WO3 pattern."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "instrument.instprm"
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)

MGWO4 = COD / "9/01/39/9013902.cif"
MGO = COD / "9/00/04/9000499.cif"
WO3_CANDIDATES = {
    "wo3_monoclinic_2311041": COD / "2/31/10/2311041.cif",
    "wo3_triclinic_2106293": COD / "2/10/62/2106293.cif",
    "wo3_orthorhombic_2107312": COD / "2/10/73/2107312.cif",
    "wo3_monoclinic_1563541": COD / "1/56/35/1563541.cif",
    "wo3_tetragonal_1521532": COD / "1/52/15/1521532.cif",
    "wo3_tetragonal_1521533": COD / "1/52/15/1521533.cif",
}


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, label: str, attempts: int = 4) -> dict:
    """Refine repeatedly, stopping on a clean small-shift convergence."""
    history = []
    for attempt in range(attempts):
        project.refine()
        status = covariance_status(project)
        entry = {
            "attempt": attempt + 1,
            "rwp": float(project.histograms()[0].get_wR()),
            "converged": bool(status.get("converged", False)),
            "svd0": int(status.get("SVD0", 0) or 0),
            "max_shift_over_sigma": status.get("Max shft/sig"),
            "message": str(status.get("msg", "") or ""),
        }
        history.append(entry)
        bad_message = any(
            word in entry["message"].lower() for word in ("dropped", "error")
        )
        shift = entry["max_shift_over_sigma"]
        if (
            entry["converged"]
            and not entry["svd0"]
            and not bad_message
            and (shift is None or float(shift) < 0.05)
        ):
            break
    print("STAGE", label, json.dumps(history[-1], sort_keys=True))
    return {"label": label, "history": history}


def initial_background(histogram, coefficients: int = 12) -> list[float]:
    x = np.asarray(histogram.data["data"][1][0], dtype=float)
    y = np.asarray(histogram.data["data"][1][1], dtype=float)
    baseline = percentile_filter(y, percentile=15, size=401, mode="nearest")
    transformed = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(
        transformed, baseline, coefficients - 1
    ).tolist()


def freeze_profile_and_cells(project: G2sc.G2Project) -> None:
    hist = project.histograms()[0]
    for parameter in hist.InstrumentParameters.values():
        if isinstance(parameter, list) and len(parameter) >= 3:
            parameter[2] = False
    for parameter in hist.SampleParameters.values():
        if isinstance(parameter, list) and len(parameter) == 2:
            parameter[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False


def set_scales_background(project: G2sc.G2Project) -> None:
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True


def enable_cells(project: G2sc.G2Project) -> None:
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True


def enable_zero(project: G2sc.G2Project) -> None:
    project.histograms()[0].InstrumentParameters["Zero"][2] = True


def enable_w(project: G2sc.G2Project) -> None:
    project.histograms()[0].InstrumentParameters["W"][2] = True


def add_phase(
    project: G2sc.G2Project, path: Path, name: str
) -> None:
    project.add_phase(
        str(path), phasename=name, histograms=project.histograms(), fmthint="CIF"
    )


def make_core(destination: Path) -> list[dict]:
    project = G2sc.G2Project(newgpx=str(destination))
    histogram = project.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma"
    )
    histogram.set_refinements({"Limits": [10.0, 100.0]})
    coefficients = initial_background(histogram)
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(coefficients),
                "coeffs": coefficients,
                "refine": True,
            }
        }
    )
    add_phase(project, MGWO4, "MgWO4_P2c")
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    freeze_profile_and_cells(project)
    # Preserve the data-supplied doublet and seed the clear common offset.
    histogram.InstrumentParameters["Zero"][1] = 0.35
    set_scales_background(project)
    project.save(str(destination))
    stages = [stable_refine(project, "core_scales_background")]
    project.save(str(destination.with_name(destination.stem + "_stable_scale.gpx")))
    enable_cells(project)
    stages.append(stable_refine(project, "core_cell"))
    enable_zero(project)
    stages.append(stable_refine(project, "core_zero"))
    enable_w(project)
    stages.append(stable_refine(project, "core_W"))
    project.save(str(destination))
    return stages


def add_and_refine(
    source: Path, destination: Path, phase_path: Path, phase_name: str
) -> list[dict]:
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    freeze_profile_and_cells(project)
    set_scales_background(project)
    add_phase(project, phase_path, phase_name)
    set_scales_background(project)
    project.save(str(destination))
    stages = [stable_refine(project, phase_name + "_scales_background")]
    project.save(str(destination.with_name(destination.stem + "_stable_scale.gpx")))
    enable_cells(project)
    stages.append(stable_refine(project, phase_name + "_cells"))
    enable_zero(project)
    stages.append(stable_refine(project, phase_name + "_zero"))
    enable_w(project)
    stages.append(stable_refine(project, phase_name + "_W"))
    project.save(str(destination))
    return stages


def project_summary(path: Path) -> dict:
    project = G2sc.G2Project(str(path))
    histogram = project.histograms()[0]
    arrays = histogram.data["data"][1]
    x, observed, weights, calculated = [np.asarray(v) for v in arrays[:4]]
    limits = histogram.data["Limits"][1]

    def local_rwp(low: float, high: float) -> float:
        use = (
            (x >= low)
            & (x <= high)
            & np.isfinite(observed)
            & np.isfinite(calculated)
            & np.isfinite(weights)
            & (weights > 0)
        )
        den = float(np.sum(weights[use] * observed[use] ** 2))
        num = float(np.sum(weights[use] * (observed[use] - calculated[use]) ** 2))
        return 100.0 * math.sqrt(num / den)

    try:
        fractions = histogram.ComputeMassFracs()
    except Exception as error:
        fractions = {"error": repr(error)}
    status = covariance_status(project)
    result = {
        "path": str(path),
        "rwp_percent": float(histogram.get_wR()),
        "residuals": dict(histogram.data["data"][0]),
        "regional_rwp_percent": {
            "10_35": local_rwp(10.0, 35.0),
            "35_65": local_rwp(35.0, 65.0),
            "65_100": local_rwp(65.0, 100.0),
        },
        "limits": [float(v) for v in limits],
        "zero": list(histogram.InstrumentParameters["Zero"]),
        "profile": {
            key: list(histogram.InstrumentParameters[key])
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "fractions": fractions,
        "phases": [],
        "convergence": {
            key: status.get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp")
        },
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": list(hap["Scale"]),
            }
        )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "mode", choices=("core", "wo3", "mgo"), help="screening operation"
    )
    parser.add_argument("source", nargs="?", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--candidate", choices=sorted(WO3_CANDIDATES))
    args = parser.parse_args()

    if args.mode == "core":
        stages = make_core(args.destination)
    elif args.mode == "wo3":
        if args.source is None or args.candidate is None:
            raise SystemExit("wo3 mode needs source and --candidate")
        stages = add_and_refine(
            args.source,
            args.destination,
            WO3_CANDIDATES[args.candidate],
            args.candidate,
        )
    else:
        if args.source is None:
            raise SystemExit("mgo mode needs source")
        stages = add_and_refine(args.source, args.destination, MGO, "MgO_Fm3m")

    summary = project_summary(args.destination)
    summary["stages"] = stages
    print("SCREEN_RESULT=" + json.dumps(summary, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
