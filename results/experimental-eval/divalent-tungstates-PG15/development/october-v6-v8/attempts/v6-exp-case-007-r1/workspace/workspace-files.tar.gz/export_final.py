#!/usr/bin/env python3
"""Export the audited final GSAS-II model and machine-readable fit products."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"

PHASE_EXPORTS = {
    "MgWO4_P2c": {
        "name": "magnesium tungstate",
        "formula": "MgWO4",
        "cif_path": "phase_mgwo4.cif",
    },
    "wo3_monoclinic_2311041": {
        "name": "tungsten trioxide",
        "formula": "WO3",
        "cif_path": "phase_wo3.cif",
    },
    "wo3_triclinic_2106293": {
        "name": "tungsten trioxide",
        "formula": "WO3",
        "cif_path": "phase_wo3.cif",
    },
    "MgO_Fm3m": {
        "name": "magnesium oxide",
        "formula": "MgO",
        "cif_path": "phase_mgo.cif",
    },
}


def main() -> None:
    project = G2sc.G2Project(str(PROJECT))
    histogram = project.histograms()[0]
    arrays = histogram.data["data"][1]
    two_theta, observed, weights, calculated, background = (
        np.asarray(array, dtype=float) for array in arrays[:5]
    )
    difference = observed - calculated
    if not all(
        np.all(np.isfinite(array))
        for array in (two_theta, observed, weights, calculated, difference, background)
    ):
        raise ValueError("nonfinite value in final profile")

    with (ROOT / "fit.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "difference", "background"]
        )
        writer.writerows(
            zip(two_theta, observed, calculated, difference, background, strict=True)
        )

    fractions = histogram.ComputeMassFracs()
    fraction_total = sum(float(value[0]) for value in fractions.values())
    if not math.isfinite(fraction_total) or fraction_total <= 0:
        raise ValueError("invalid crystalline fraction sum")

    phase_rows = []
    for phase in project.phases():
        specification = PHASE_EXPORTS[phase.name]
        phase.export_CIF(str(ROOT / specification["cif_path"]))
        value, esd = fractions[phase.name]
        cell = phase.get_cell()
        phase_rows.append(
            {
                "name": specification["name"],
                "formula": specification["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": specification["cif_path"],
                "weight_fraction": float(value) / fraction_total,
                "weight_fraction_esd": float(esd) / fraction_total,
                "weight_percent": 100.0 * float(value) / fraction_total,
                "cell": {
                    "a_angstrom": float(cell["length_a"]),
                    "b_angstrom": float(cell["length_b"]),
                    "c_angstrom": float(cell["length_c"]),
                    "alpha_deg": float(cell["angle_alpha"]),
                    "beta_deg": float(cell["angle_beta"]),
                    "gamma_deg": float(cell["angle_gamma"]),
                    "volume_angstrom3": float(cell["volume"]),
                },
            }
        )

    residuals = histogram.data["data"][0]
    covariance_rvals = project.data["Covariance"]["data"]["Rvals"]
    full_grid_denominator = float(np.sum(weights * observed**2))
    full_grid_numerator = float(np.sum(weights * difference**2))
    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(covariance_rvals["GOF"]),
            "chi_squared": float(covariance_rvals["chisq"]),
            "refined_observations": int(covariance_rvals["Nobs"]),
            "refined_variables": int(covariance_rvals["Nvars"]),
            "full_grid_Rwp_percent": 100.0
            * math.sqrt(full_grid_numerator / full_grid_denominator),
            "full_grid_points": int(two_theta.size),
            "refinement_range_two_theta_deg": [10.0, 100.0],
        },
        "fraction_basis": "normalized over the modeled crystalline phases",
        "difference_definition": "observed minus calculated",
        "project_path": "final.gpx",
        "fit_path": "fit.csv",
        "unresolved_components": [],
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=False) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
