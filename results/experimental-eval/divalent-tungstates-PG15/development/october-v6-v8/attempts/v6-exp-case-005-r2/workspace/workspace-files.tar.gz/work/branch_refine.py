#!/usr/bin/env python3
"""Create matched refinement branches from an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from refine_workflow import covariance_status, phase_fraction_summary, stable_refine, summary


PROFILE_KEYS = ("U", "V", "W", "X", "Y", "Z", "SH/L")


def region_metrics(project: G2sc.G2Project) -> list[dict]:
    arrays = [np.asarray(item, dtype=float) for item in project.histograms()[0].data["data"][1]]
    x, observed, weights, calculated = arrays[:4]
    rows = []
    for lower, upper in ((10, 30), (30, 50), (50, 70), (70, 100)):
        selected = (
            (x >= lower)
            & (x < upper)
            & np.isfinite(observed)
            & np.isfinite(calculated)
            & np.isfinite(weights)
            & (weights > 0)
        )
        difference = observed[selected] - calculated[selected]
        numerator = float(np.sum(weights[selected] * difference**2))
        denominator = float(np.sum(weights[selected] * observed[selected] ** 2))
        rows.append(
            {
                "range_2theta_deg": [lower, upper],
                "rwp_percent": 100.0 * math.sqrt(numerator / denominator),
                "mean_difference_counts": float(np.mean(difference)),
                "rms_difference_counts": float(np.sqrt(np.mean(difference**2))),
            }
        )
    return rows


def set_instrument_profile(project: G2sc.G2Project, selected: set[str]) -> None:
    instrument = project.histograms()[0].InstrumentParameters
    for key in PROFILE_KEYS:
        instrument[key][2] = key in selected
    for key in selected:
        if key in {"X", "Y", "Z"} and abs(float(instrument[key][1])) < 1.0e-9:
            instrument[key][1] = 1.0


def configure(project: G2sc.G2Project, args: argparse.Namespace) -> None:
    histogram = project.histograms()[0]
    instrument = histogram.InstrumentParameters
    sample = histogram.SampleParameters
    if args.profile is not None:
        selected = {item for item in args.profile.split(",") if item}
        unknown = selected.difference(PROFILE_KEYS)
        if unknown:
            raise ValueError(f"unknown profile keys: {sorted(unknown)}")
        set_instrument_profile(project, selected)
    if args.remove_x:
        instrument["X"][1] = 0.0
        instrument["X"][2] = False
    if args.polarization:
        instrument["Polariz."][2] = True
    if args.roughness:
        sample["SurfRoughA"][:] = [0.5, True]
        sample["SurfRoughB"][:] = [0.01, True]
    if args.roughness_b:
        sample["SurfRoughA"][:] = [args.roughness_fixed_a, False]
        sample["SurfRoughB"][:] = [0.01, True]
    if args.remove_roughness:
        sample["SurfRoughA"][:] = [0.0, False]
        sample["SurfRoughB"][:] = [0.0, False]
    if args.phase_size:
        phase = project.phase(args.phase_size)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True, "value": args.size_start}}
        )
    if args.phase_strain:
        phase = project.phase(args.phase_strain)
        hap = phase.data["Histograms"][histogram.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = args.strain_start
        hap["Mustrain"][2][0] = True
    if args.remove_phase_size:
        phase = project.phase(args.remove_phase_size)
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "refine": False,
                    "value": args.removed_size_value,
                }
            }
        )
    if args.texture:
        phase_name, axis_text = args.texture.split(":", 1)
        axis = [int(item) for item in axis_text.split(",")]
        if len(axis) != 3:
            raise ValueError("texture axis must have three integers")
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
    if args.atoms:
        phase_name, flags = args.atoms.split(":", 1)
        phase = project.phase(phase_name)
        phase.set_refinements({"Atoms": {"all": flags}})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("destination")
    parser.add_argument("--label", default="branch")
    parser.add_argument("--profile", help="comma-separated instrument profile keys")
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--roughness-b", action="store_true")
    parser.add_argument(
        "--roughness-fixed-a",
        type=float,
        default=0.0,
        help="fixed SurfRoughA used with --roughness-b",
    )
    parser.add_argument("--remove-x", action="store_true")
    parser.add_argument("--remove-roughness", action="store_true")
    parser.add_argument("--phase-size")
    parser.add_argument("--size-start", type=float, default=1.0)
    parser.add_argument("--phase-strain")
    parser.add_argument("--strain-start", type=float, default=1000.0)
    parser.add_argument("--remove-phase-size")
    parser.add_argument("--removed-size-value", type=float, default=1.0)
    parser.add_argument("--texture", help="phase:h,k,l")
    parser.add_argument("--atoms", help="phase:refinement flags, e.g. WO3_tri:X")
    parser.add_argument("--runs", type=int, default=8)
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    source = Path(args.source).resolve()
    destination = Path(args.destination).resolve()
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    project.set_Controls("cycles", args.cycles)
    configure(project, args)
    project.save()
    stable_refine(project, args.label, maximum_runs=args.runs)
    project.save()
    result = summary(project)
    result["regions"] = region_metrics(project)
    result["vary_list"] = project.data.get("Covariance", {}).get("data", {}).get(
        "varyList", []
    )
    print("BRANCH_RESULT=" + json.dumps(result, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
