#!/usr/bin/env python3
"""Export the replayed final GSAS-II model into the requested submission files."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PROJECT_PATH = ROOT / "final.gpx"

PHASE_METADATA = {
    "Co3O4": {
        "display_name": "Cobalt(II,III) oxide (spinel)",
        "formula": "Co3O4",
        "cif_path": "Co3O4.cif",
        "source_database": "Crystallography Open Database",
        "source_entry": "COD 9005896",
    },
    "WO3_tri": {
        "display_name": "Tungsten(VI) oxide (triclinic)",
        "formula": "WO3",
        "cif_path": "WO3_triclinic.cif",
        "source_database": "Crystallography Open Database",
        "source_entry": "COD 2106293",
    },
}


def rwp_percent(observed: np.ndarray, calculated: np.ndarray, weights: np.ndarray) -> float:
    valid = (
        np.isfinite(observed)
        & np.isfinite(calculated)
        & np.isfinite(weights)
        & (weights > 0.0)
    )
    numerator = float(np.sum(weights[valid] * (observed[valid] - calculated[valid]) ** 2))
    denominator = float(np.sum(weights[valid] * observed[valid] ** 2))
    return 100.0 * math.sqrt(numerator / denominator)


def fraction_esds(
    project: G2sc.G2Project, phase_rows: list[dict], total_mass_scale: float
) -> list[float | None]:
    covariance = project.data.get("Covariance", {}).get("data", {})
    vary_list = list(covariance.get("varyList", []))
    matrix = covariance.get("covMatrix")
    if matrix is None:
        return [None] * len(phase_rows)
    matrix = np.asarray(matrix, dtype=float)
    histogram_id = project.histograms()[0].id
    scale_names = [f"{row['phase_id']}:{histogram_id}:Scale" for row in phase_rows]
    if any(name not in vary_list for name in scale_names):
        return [None] * len(phase_rows)
    indices = [vary_list.index(name) for name in scale_names]
    scale_covariance = matrix[np.ix_(indices, indices)]
    masses = np.asarray([row["mass_per_cell"] for row in phase_rows], dtype=float)
    mass_scales = np.asarray([row["mass_scale"] for row in phase_rows], dtype=float)
    esds: list[float | None] = []
    for phase_index in range(len(phase_rows)):
        gradient = -mass_scales[phase_index] * masses / total_mass_scale**2
        gradient[phase_index] += masses[phase_index] / total_mass_scale
        variance = float(gradient @ scale_covariance @ gradient)
        esds.append(math.sqrt(max(variance, 0.0)) if math.isfinite(variance) else None)
    return esds


def main() -> None:
    project = G2sc.G2Project(str(PROJECT_PATH))
    histograms = project.histograms()
    if len(histograms) != 1:
        raise ValueError(f"expected one histogram, found {len(histograms)}")
    histogram = histograms[0]
    arrays = [np.asarray(item, dtype=float) for item in histogram.data["data"][1]]
    two_theta, observed, weights, calculated, background, difference = arrays[:6]
    if not np.allclose(difference, observed - calculated, atol=1.0e-8, rtol=1.0e-10):
        raise ValueError("saved difference profile is inconsistent with observed-calculated")

    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        writer.writerows(
            zip(two_theta, observed, calculated, difference, background, strict=True)
        )

    phase_rows: list[dict] = []
    for phase in project.phases():
        metadata = PHASE_METADATA[phase.name]
        hap = phase.data["Histograms"][histogram.name]
        scale = float(hap["Scale"][0])
        mass = float(phase.data["General"]["Mass"])
        cell, cell_esd = phase.get_cell_and_esd()
        output_cif = ROOT / metadata["cif_path"]
        phase.export_CIF(str(output_cif))
        phase_rows.append(
            {
                "phase_id": phase.id,
                "name": metadata["display_name"],
                "formula": metadata["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": metadata["cif_path"],
                "source_database": metadata["source_database"],
                "source_entry": metadata["source_entry"],
                "scale": scale,
                "mass_per_cell": mass,
                "mass_scale": scale * mass,
                "cell": {key: float(value) for key, value in cell.items()},
                "cell_esd": {key: float(value) for key, value in cell_esd.items()},
                "bragg_rf_percent": float(
                    histogram.residuals[f"{phase.id}:{histogram.id}:Rf"]
                ),
                "model_details": {
                    "preferred_orientation": "none refined",
                    "atomic_coordinates": "fixed to audited source structure",
                    "isotropic_displacement_parameters": "fixed to source values",
                    "isotropic_size_micrometre": (
                        float(hap["Size"][1][0]) if hap["Size"][2][0] else None
                    ),
                },
            }
        )

    total_mass_scale = sum(row["mass_scale"] for row in phase_rows)
    esds = fraction_esds(project, phase_rows, total_mass_scale)
    for row, esd in zip(phase_rows, esds, strict=True):
        row["weight_fraction"] = row["mass_scale"] / total_mass_scale
        row["weight_fraction_esd_formal"] = esd
        row["weight_percent"] = 100.0 * row["weight_fraction"]
        for internal_key in ("phase_id", "scale", "mass_per_cell", "mass_scale"):
            row.pop(internal_key)

    rvalues = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    residuals = histogram.residuals
    fit_limits = [float(item) for item in histogram.data["Limits"][1]]
    result = {
        "method": "two-phase Rietveld refinement in GSAS-II",
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "fraction_basis": "normalized over the modeled crystalline phases only",
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent": float(residuals["wR"]),
            "rp_percent": float(residuals["R"]),
            "rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvalues["GOF"]),
            "reduced_chi_squared": float(rvalues["GOF"]) ** 2,
            "full_exported_profile_rwp_percent": rwp_percent(
                observed, calculated, weights
            ),
            "refinement_range_two_theta_deg": fit_limits,
            "exported_range_two_theta_deg": [float(two_theta[0]), float(two_theta[-1])],
            "refined_observation_count": int(rvalues["Nobs"]),
            "refined_variable_count": int(rvalues["Nvars"]),
            "converged": bool(rvalues.get("converged")),
            "svd_dropped_variables": int(rvalues.get("SVD0", 0)),
            "maximum_shift_over_esd": float(rvalues["Max shft/sig"]),
        },
        "formal_uncertainty_note": (
            "Weight-fraction ESDs are covariance-only and exclude phase-model, "
            "instrument-profile and specimen-preparation systematics."
        ),
        "unresolved_components": [],
    }
    with (ROOT / "result.json").open("w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, sort_keys=False, allow_nan=False)
        stream.write("\n")

    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
