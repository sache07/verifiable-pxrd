#!/usr/bin/env python3
"""Build and inspect matched GSAS-II screening refinements for this dataset."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "work" / "cu_ka.instprm"
CO3O4 = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/9/00/58/9005896.cif"
)
WO3_MODELS = {
    "mono": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/2/31/10/2311041.cif"
    ),
    "tri": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/2/10/62/2106293.cif"
    ),
}
COWO4 = ROOT / "work" / "candidates" / "cowo4_repaired.cif"


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, label: str, maximum_runs: int = 8) -> None:
    for run in range(1, maximum_runs + 1):
        project.refine(makeBack=False)
        status = covariance_status(project)
        rwp = float(project.histograms()[0].get_wR())
        shift = float(status.get("Max shft/sig") or math.inf)
        print(
            "STAGE",
            json.dumps(
                {
                    "label": label,
                    "run": run,
                    "rwp_percent": rwp,
                    "converged": status.get("converged"),
                    "max_shift_over_esd": shift,
                    "svd0": status.get("SVD0"),
                    "message": status.get("msg", ""),
                },
                sort_keys=True,
            ),
        )
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in message:
            raise RuntimeError(f"unstable refinement in {label}: {status}")
        if status.get("converged") and shift < 0.05:
            return
    raise RuntimeError(f"refinement did not stabilize in {label}: {covariance_status(project)}")


def phase_fraction_summary(project: G2sc.G2Project) -> list[dict]:
    histogram = project.histograms()[0]
    rows = []
    denominator = 0.0
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        term = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        denominator += term
        rows.append(
            {
                "phase": phase.name,
                "scale": float(hap["Scale"][0]),
                "mass_per_cell": float(phase.data["General"]["Mass"]),
                "mass_scale": term,
                "cell": phase.get_cell(),
            }
        )
    for row in rows:
        row["weight_fraction"] = row["mass_scale"] / denominator
    return rows


def summary(project: G2sc.G2Project) -> dict:
    histogram = project.histograms()[0]
    status = covariance_status(project)
    return {
        "project": project.filename,
        "rwp_percent": float(histogram.get_wR()),
        "residuals": histogram.residuals,
        "convergence": {
            key: status.get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp", "GOF")
        },
        "instrument": histogram.InstrumentParameters,
        "sample": histogram.SampleParameters,
        "background": histogram.Background,
        "phases": phase_fraction_summary(project),
    }


def configure_histogram(histogram: G2sc.G2PwdrData) -> None:
    histogram.data["Limits"][1] = [10.0, 100.0]
    histogram.data["Background"][0] = [
        "chebyschev-1",
        True,
        12,
        3150.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
    ]
    sample = histogram.SampleParameters
    sample["Scale"][:] = [1.0, False]
    sample["Shift"][:] = [0.0, False]
    instrument = histogram.InstrumentParameters
    starts = {
        "Zero": 0.335,
        "Polariz.": 0.5,
        "U": 10.0,
        "V": -10.0,
        "W": 50.0,
        "X": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }
    for key, value in starts.items():
        instrument[key][1] = value
        instrument[key][2] = False


def build(args: argparse.Namespace) -> None:
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(output))
    project.set_Controls("cycles", 6)
    histogram = project.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma"
    )
    configure_histogram(histogram)
    phases = [
        project.add_phase(
            str(CO3O4), phasename="Co3O4", histograms=[histogram], fmthint="CIF"
        ),
        project.add_phase(
            str(WO3_MODELS[args.wo3]),
            phasename=f"WO3_{args.wo3}",
            histograms=[histogram],
            fmthint="CIF",
        ),
    ]
    if args.cowo4:
        phases.append(
            project.add_phase(
                str(COWO4), phasename="CoWO4", histograms=[histogram], fmthint="CIF"
            )
        )

    initial_scales = {"Co3O4": 8.0, f"WO3_{args.wo3}": 24.0, "CoWO4": 1.0}
    for phase in phases:
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][:] = [initial_scales[phase.name], True]
        phase.data["General"]["Cell"][0] = False
        for atom in phase.data["Atoms"]:
            atom[2] = ""

    project.save()
    stable_refine(project, "background_scales")
    project.save(str(output.with_name(output.stem + "-scales.gpx")))

    for phase in phases:
        phase.data["General"]["Cell"][0] = True
    stable_refine(project, "cells_background_scales")
    project.save(str(output))
    print("MODEL_RESULT=" + json.dumps(summary(project), sort_keys=True, default=str))


def inspect(args: argparse.Namespace) -> None:
    project = G2sc.G2Project(str(Path(args.project).resolve()))
    print(json.dumps(summary(project), indent=2, sort_keys=True, default=str))


def copy_project(args: argparse.Namespace) -> None:
    shutil.copy2(args.source, args.destination)


def continue_refinement(args: argparse.Namespace) -> None:
    source = Path(args.source).resolve()
    destination = Path(args.destination).resolve()
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    project.set_Controls("cycles", args.cycles)
    project.save()
    stable_refine(project, args.label, maximum_runs=args.runs)
    project.save()
    print("MODEL_RESULT=" + json.dumps(summary(project), sort_keys=True, default=str))


def main() -> None:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    build_parser = subparsers.add_parser("build")
    build_parser.add_argument("--wo3", choices=sorted(WO3_MODELS), required=True)
    build_parser.add_argument("--cowo4", action="store_true")
    build_parser.add_argument("output")
    build_parser.set_defaults(function=build)
    inspect_parser = subparsers.add_parser("inspect")
    inspect_parser.add_argument("project")
    inspect_parser.set_defaults(function=inspect)
    copy_parser = subparsers.add_parser("copy")
    copy_parser.add_argument("source")
    copy_parser.add_argument("destination")
    copy_parser.set_defaults(function=copy_project)
    continue_parser = subparsers.add_parser("continue")
    continue_parser.add_argument("source")
    continue_parser.add_argument("destination")
    continue_parser.add_argument("--label", default="continued")
    continue_parser.add_argument("--runs", type=int, default=8)
    continue_parser.add_argument("--cycles", type=int, default=8)
    continue_parser.set_defaults(function=continue_refinement)
    args = parser.parse_args()
    args.function(args)


if __name__ == "__main__":
    main()
