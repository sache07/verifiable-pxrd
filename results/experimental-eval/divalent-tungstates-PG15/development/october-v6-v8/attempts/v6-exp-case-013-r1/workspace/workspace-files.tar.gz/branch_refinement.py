#!/usr/bin/env python3
"""Create matched GSAS-II nuisance-parameter branches and report diagnostics."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, maximum_cycles: int = 10) -> bool:
    for _ in range(maximum_cycles):
        try:
            project.refine()
        except Exception as error:
            print("REFINEMENT_ERROR=" + repr(error))
            return False
        values = status(project)
        message = str(values.get("msg", "") or "").lower()
        if (
            values.get("Aborted")
            or values.get("SVD0", 0)
            or "dropped" in message
            or "error" in message
        ):
            return False
        shift = abs(float(values.get("Max shft/sig") or 0.0))
        if values.get("converged") and shift < 0.05:
            return True
    return False


def regional_sse(project: G2sc.G2Project) -> dict[str, float]:
    arrays = project.histograms()[0].data["data"][1]
    x, weight, difference = arrays[0], arrays[2], arrays[5]
    limits = project.histograms()[0].data["Limits"][1]
    edges = np.linspace(float(limits[0]), float(limits[1]), 7)
    output = {}
    for lower, upper in zip(edges[:-1], edges[1:]):
        selected = (x >= lower) & (x < upper)
        output[f"{lower:.1f}-{upper:.1f}"] = float(
            np.sum(weight[selected] * difference[selected] ** 2)
        )
    return output


def positive_widths(project: G2sc.G2Project) -> dict[str, object]:
    instrument = project.histograms()[0].InstrumentParameters
    angles = np.linspace(10.0, 100.0, 181)
    theta = np.radians(angles / 2.0)
    u, v, w = (float(instrument[key][1]) for key in ("U", "V", "W"))
    x, y = (float(instrument[key][1]) for key in ("X", "Y"))
    gaussian = u * np.tan(theta) ** 2 + v * np.tan(theta) + w
    lorentzian = x / np.cos(theta) + y * np.tan(theta)
    return {
        "gaussian_min": float(np.min(gaussian)),
        "gaussian_max": float(np.max(gaussian)),
        "lorentzian_min": float(np.min(lorentzian)),
        "lorentzian_max": float(np.max(lorentzian)),
        "gaussian_positive": bool(np.all(gaussian > 0)),
        "lorentzian_nonnegative": bool(np.all(lorentzian >= 0)),
    }


def phase_by_name(project: G2sc.G2Project, name: str):
    matches = [phase for phase in project.phases() if phase.name == name]
    if len(matches) != 1:
        raise ValueError(f"expected one phase named {name!r}; found {len(matches)}")
    return matches[0]


def configure(project: G2sc.G2Project, kind: str, phase_name: str | None, axis: list[int] | None) -> None:
    histogram = project.histograms()[0]
    instrument = histogram.InstrumentParameters
    if kind == "continue":
        return
    if kind == "reset-microstructure":
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1.0e6
            hap["Size"][2] = [False] * len(hap["Size"][2])
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        return
    if kind.startswith("global-"):
        key = kind.split("-", 1)[1]
        if key.endswith("-off"):
            key = key[:-4]
            # Restore the instrument-file value as well as freezing the flag;
            # otherwise an "off" branch still applies the refined term.
            instrument[key][1] = instrument[key][0]
            instrument[key][2] = False
        else:
            instrument[key][2] = True
        return
    if kind == "polarization":
        instrument["Polariz."][2] = True
        return
    if kind == "polarization-off":
        instrument["Polariz."][1] = instrument["Polariz."][0]
        instrument["Polariz."][2] = False
        return
    if kind == "roughness":
        histogram.SampleParameters["SurfRoughA"][:] = [0.05, True]
        histogram.SampleParameters["SurfRoughB"][:] = [0.05, True]
        return
    if phase_name is None:
        raise ValueError(f"{kind} requires --phase")
    phase = phase_by_name(project, phase_name)
    hap = phase.data["Histograms"][histogram.name]
    if kind == "cell-off":
        phase.data["General"]["Cell"][0] = False
    elif kind == "size":
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.5, "refine": True}}
        )
    elif kind == "strain":
        hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    elif kind == "size-off":
        hap["Size"][2] = [False] * len(hap["Size"][2])
        # A very large coherent domain makes the Scherrer contribution vanish.
        hap["Size"][1][0] = 1.0e6
    elif kind == "strain-off":
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Mustrain"][1][0] = 0.0
    elif kind == "md":
        if axis is None or len(axis) != 3:
            raise ValueError("md requires --axis h k l")
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [int(value) for value in axis]
    elif kind == "md-off":
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][1] = 1.0
    else:
        raise ValueError(kind)


def summarize(project: G2sc.G2Project, valid: bool, kind: str) -> dict:
    histogram = project.histograms()[0]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases[phase.name] = {
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    values = status(project)
    return {
        "kind": kind,
        "valid": valid,
        "rwp_percent": float(histogram.get_wR()),
        "convergence": {
            key: values.get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp")
        },
        "instrument": {
            key: histogram.InstrumentParameters[key]
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
        },
        "sample": {
            key: histogram.SampleParameters[key]
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "width_diagnostics": positive_widths(project),
        "regional_weighted_sse": regional_sse(project),
        "phases": phases,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "kind",
        choices=(
            "global-U", "global-V", "global-W", "global-X", "global-Y",
            "global-SH/L",
            "global-U-off", "global-V-off", "global-W-off", "global-X-off",
            "global-Y-off", "global-SH/L-off", "polarization", "polarization-off", "roughness", "continue",
            "reset-microstructure", "cell-off", "size", "strain",
            "size-off", "strain-off", "md", "md-off",
        ),
    )
    parser.add_argument("--phase")
    parser.add_argument("--axis", nargs=3, type=int)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    configure(project, args.kind, args.phase, args.axis)
    project.save()
    valid = stable_refine(project)
    project.save()
    summary = summarize(project, valid, args.kind)
    print("BRANCH_RESULT=" + json.dumps(summary, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
