#!/usr/bin/env python3
"""Build and stage trial GSAS-II Rietveld models for the supplied pattern."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)

PHASES = {
    "scheelite": ("9009811", "PbWO4_scheelite"),
    "wo3": ("1528915", "WO3_monoclinic"),
    "massicot": ("2310433", "PbO_massicot"),
    "litharge": ("9012700", "PbO_litharge"),
    "raspite": ("9007617", "PbWO4_raspite"),
    "pb7w8": ("9016035", "Pb7W8O28.8_defect"),
    "wo2": ("1548686", "WO2_monoclinic"),
    "pb3o4": ("9012124", "Pb3O4"),
    "pb2wo5": ("candidates/Pb2WO5_C2m.cif", "Pb2WO5_monoclinic"),
    "pb3wo6": ("candidates/Pb3WO6_Pmcn.cif", "Pb3WO6_orthorhombic_trial"),
}


def cif_path(cod_id: str) -> Path:
    if "/" in cod_id:
        return ROOT / cod_id
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refinement_summary(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    status = covariance_status(project)
    out = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "convergence": {
            key: status.get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp")
        },
        "zero": hist.InstrumentParameters.get("Zero"),
        "profile": {
            key: hist.InstrumentParameters.get(key)
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap.get("Scale"),
            "size": hap.get("Size"),
            "mustrain": hap.get("Mustrain"),
            "pref_ori": hap.get("Pref.Ori."),
        }
    return out


def refine_until_stable(project: G2sc.G2Project, label: str, cycles: int = 8) -> dict:
    attempts = []
    for _ in range(cycles):
        error = None
        try:
            project.refine()
        except Exception as exc:  # retained in branch diagnostics
            error = repr(exc)
        status = covariance_status(project)
        attempts.append(
            {
                "error": error,
                "rwp_percent": project.histograms()[0].get_wR(),
                "converged": status.get("converged"),
                "SVD0": status.get("SVD0"),
                "max_shift_over_sigma": status.get("Max shft/sig"),
                "message": status.get("msg"),
            }
        )
        if error or status.get("SVD0", 0):
            break
        shift = status.get("Max shft/sig")
        if status.get("converged") and shift is not None and abs(float(shift)) < 0.05:
            break
    project.save()
    summary = refinement_summary(project, label)
    summary["attempts"] = attempts
    print("REFINEMENT_STAGE=" + json.dumps(summary, default=str, sort_keys=True))
    return summary


def set_background(hist, ncoeff: int = 12) -> None:
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": ncoeff,
                "coeffs": [800.0] + [0.0] * (ncoeff - 1),
            }
        }
    )


def set_all_scales(project: G2sc.G2Project, refine: bool = True) -> None:
    hist = project.histograms()[0]
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = refine


def build(output: Path, phase_keys: list[str]) -> G2sc.G2Project:
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma/tab/semicolon separated",
    )
    hist.Limits("lower", 10.02)
    hist.Limits("upper", 99.98)
    # Overall histogram scale and phase scales are exactly redundant. Keep the
    # former fixed so that phase scales and derived weight fractions are stable.
    hist.SampleParameters["Scale"][1] = False
    for key in phase_keys:
        cod_id, name = PHASES[key]
        project.add_phase(
            str(cif_path(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
    set_background(hist)
    set_all_scales(project, True)
    project.set_Controls("cycles", 12)
    project.save()
    refine_until_stable(project, "background_scales")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine_until_stable(project, "cells")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_until_stable(project, "zero_cells")

    # W is the smallest global Gaussian-width branch. Angle-dependent terms
    # are tested only from this converged baseline in separate branches.
    hist.set_refinements({"Instrument Parameters": ["W"]})
    refine_until_stable(project, "constant_gaussian_profile")

    return project


def add_phase(source: Path, output: Path, phase_key: str) -> G2sc.G2Project:
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = project.histograms()[0]
    cod_id, name = PHASES[phase_key]
    phase = project.add_phase(
        str(cif_path(cod_id)),
        phasename=name,
        histograms=[hist],
        fmthint="CIF",
    )
    # Start an add-phase branch with a small scale and fixed candidate cell.
    # Simultaneous scale/cell release can send an unsupported candidate's
    # metric tensor to a nonphysical value before its scale settles.
    phase.data["Histograms"][hist.name]["Scale"][:] = [0.05, True]
    phase.set_refinements({"Cell": False})
    project.save()
    scale_result = refine_until_stable(project, f"add_{phase_key}_scale_only")
    candidate_scale = phase.data["Histograms"][hist.name]["Scale"][0]
    if math.isfinite(candidate_scale) and candidate_scale > 1.0e-6:
        phase.set_refinements({"Cell": True})
        refine_until_stable(project, f"add_{phase_key}_cell")
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("build")
    make.add_argument("output", type=Path)
    make.add_argument("phases", nargs="+")
    add = sub.add_parser("add")
    add.add_argument("source", type=Path)
    add.add_argument("output", type=Path)
    add.add_argument("phase", choices=sorted(PHASES))
    args = parser.parse_args()
    if args.command == "build":
        build(args.output.resolve(), args.phases)
    else:
        add_phase(args.source.resolve(), args.output.resolve(), args.phase)


if __name__ == "__main__":
    main()
