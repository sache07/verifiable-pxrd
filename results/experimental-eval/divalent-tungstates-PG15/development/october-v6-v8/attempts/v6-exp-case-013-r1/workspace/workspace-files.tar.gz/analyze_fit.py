#!/usr/bin/env python3
"""Plot a saved GSAS-II profile and list coherent positive residual peaks."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--npz", type=Path)
    args = parser.parse_args()
    project = G2sc.G2Project(str(args.project.resolve()))
    histogram = project.histograms()[0]
    x, observed, weight, calculated, background, difference = histogram.data["data"][1]
    smooth = gaussian_filter1d(difference, 2.0)
    peaks, properties = find_peaks(smooth, prominence=80.0, distance=8)
    order = np.argsort(properties["prominences"])[::-1]
    reflections = histogram.reflections()
    print("Residual peaks (position, positive height, prominence, nearest phase reflections):")
    for index in order[:40]:
        point = peaks[index]
        if smooth[point] <= 50.0:
            continue
        nearby = []
        for phase_name, reflection_data in reflections.items():
            rows = reflection_data["RefList"]
            nearest = rows[np.argmin(np.abs(rows[:, 5] - x[point]))]
            distance = abs(float(nearest[5] - x[point]))
            if distance < 0.22:
                hkl = tuple(int(value) for value in nearest[:3])
                # multiplicity times calculated F^2 is a useful stick-strength proxy.
                strength = float(nearest[3] * nearest[9])
                nearby.append((distance, phase_name, hkl, float(nearest[5]), strength))
        nearby.sort()
        print(
            f"{x[point]:8.4f} {smooth[point]:9.1f} "
            f"prom={properties['prominences'][index]:8.1f} {nearby[:4]}"
        )

    if args.npz:
        args.npz.parent.mkdir(parents=True, exist_ok=True)
        np.savez(
            args.npz,
            two_theta=x,
            observed=observed,
            calculated=calculated,
            background=background,
            difference=difference,
        )


if __name__ == "__main__":
    main()
