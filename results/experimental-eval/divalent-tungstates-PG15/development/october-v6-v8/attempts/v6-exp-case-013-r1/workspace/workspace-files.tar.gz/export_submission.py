#!/usr/bin/env python3
"""Export the final GSAS-II project into the required submission files."""

from __future__ import annotations

import csv
import json
import re
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"
LISTING = ROOT / "final.lst"

PHASE_INFO = {
    "PbWO4_scheelite": {
        "name": "PbWO4 (scheelite)",
        "formula": "PbWO4",
        "space_group": "I 41/a",
        "cif_path": "phase_PbWO4_scheelite.cif",
        "model_source": "COD 9009811",
    },
    "WO3_monoclinic": {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif_path": "phase_WO3_monoclinic.cif",
        "model_source": "COD 2311041",
    },
    "PbO_massicot": {
        "name": "PbO (massicot)",
        "formula": "PbO",
        "space_group": "P b c m",
        "cif_path": "phase_PbO_massicot.cif",
        "model_source": "COD 2310433",
    },
    "PbO_litharge": {
        "name": "PbO (litharge)",
        "formula": "PbO",
        "space_group": "P 4/n m m",
        "cif_path": "phase_PbO_litharge.cif",
        "model_source": (
            "COD 9012700 with an equivalent origin-setting repair for GSAS-II"
        ),
    },
    "Pb2WO5_monoclinic": {
        "name": "Pb2WO5 (monoclinic)",
        "formula": "Pb2WO5",
        "space_group": "C 2/m",
        "cif_path": "phase_Pb2WO5_monoclinic.cif",
        "model_source": (
            "isovalent W6+ substitution in the Pb2MoO5 topology of COD 7220560"
        ),
    },
}


def listing_fractions(text: str, phase_names: list[str]) -> dict[str, tuple[float, float]]:
    output = {}
    for phase_name in phase_names:
        starts = [
            match.start()
            for match in re.finditer(
                rf"^ Phase: {re.escape(phase_name)} in histogram:", text, re.MULTILINE
            )
        ]
        if not starts:
            raise ValueError(f"phase missing from final listing: {phase_name}")
        block = text[starts[-1] :]
        match = re.search(
            r"Weight fraction\s*:\s*([0-9.eE+-]+),\s*sig\s*([0-9.eE+-]+)",
            block,
        )
        if not match:
            raise ValueError(f"weight fraction missing from final listing: {phase_name}")
        output[phase_name] = (float(match.group(1)), float(match.group(2)))
    return output


def main() -> None:
    project = G2sc.G2Project(str(PROJECT))
    histogram = project.histograms()[0]
    phases = project.phases()
    phase_names = [phase.name for phase in phases]
    if set(phase_names) != set(PHASE_INFO):
        raise ValueError(f"unexpected final phase inventory: {phase_names}")

    fractions = listing_fractions(LISTING.read_text(encoding="utf-8"), phase_names)
    fraction_sum = sum(value for value, _ in fractions.values())
    if fraction_sum <= 0:
        raise ValueError("nonpositive crystalline weight-fraction sum")
    fractions = {
        name: (value / fraction_sum, esd / fraction_sum)
        for name, (value, esd) in fractions.items()
    }
    records = []
    for phase in phases:
        metadata = dict(PHASE_INFO[phase.name])
        phase.export_CIF(str(ROOT / metadata["cif_path"]))
        fraction, esd = fractions[phase.name]
        metadata.update(
            {
                "weight_fraction": fraction,
                "weight_fraction_esd": esd,
                "cell": phase.get_cell(),
            }
        )
        records.append(metadata)

    arrays = histogram.data["data"][1]
    with (ROOT / "fit.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        for two_theta, observed, calculated, background, difference in zip(
            arrays[0], arrays[1], arrays[3], arrays[4], arrays[5]
        ):
            writer.writerow(
                [
                    f"{float(two_theta):.8f}",
                    f"{float(observed):.8f}",
                    f"{float(calculated):.8f}",
                    f"{float(difference):.8f}",
                    f"{float(background):.8f}",
                ]
            )

    covariance = project.data["Covariance"]["data"]
    rvalues = covariance["Rvals"]
    residuals = histogram.residuals
    result = {
        "phases": records,
        "fraction_basis": (
            "weight fractions normalized over the five modeled crystalline phases"
        ),
        "fit_statistics": {
            "rwp_percent": float(residuals["wR"]),
            "rp_percent": float(residuals["R"]),
            "r_background_percent": float(residuals["Rb"]),
            "weighted_r_background_percent": float(residuals["wRb"]),
            "rwp_minimum_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvalues["GOF"]),
            "chi_square": float(rvalues["chisq"]),
            "n_observations": int(rvalues["Nobs"]),
            "n_variables": int(rvalues["Nvars"]),
            "converged": bool(rvalues["converged"]),
            "svd_dropped_variables": int(rvalues["SVD0"]),
            "max_shift_over_esd": float(rvalues["Max shft/sig"]),
        },
        "unresolved_components": [
            {
                "description": (
                    "coherent residual intensity centered near 30.16 degrees 2theta, "
                    "with a weaker feature near 31.39 degrees"
                ),
                "status": (
                    "no chemically plausible atomistic candidate passed the "
                    "complete-pattern test"
                ),
                "weight_fraction": None,
                "normalization_note": (
                    "excluded from the reported crystalline-phase normalization"
                ),
            }
        ],
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=False) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
