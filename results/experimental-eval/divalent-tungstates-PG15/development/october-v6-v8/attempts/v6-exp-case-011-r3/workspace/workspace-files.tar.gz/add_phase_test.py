#!/usr/bin/env python3
"""Retest a candidate phase one-at-a-time from the mature baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from branch_refine import project_summary
from refinement_driver import cod_cif, stable_refine


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("name")
    parser.add_argument("cod_id")
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()))
    project.save(str(args.output.resolve()))
    hist = project.histograms()[0]
    phase = project.add_phase(
        str(cod_cif(args.cod_id)), phasename=args.name, histograms=[hist]
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][:] = [1.0, True]
    project.data["Controls"]["data"]["max cyc"] = 12
    project.save()
    ok = stable_refine(project, "add-" + args.name, attempts=8)
    result = project_summary(project, ok)
    result["candidate_scale"] = hap["Scale"]
    result["candidate_cell"] = phase.get_cell()
    print("ADD_PHASE_RESULT=" + json.dumps(result))


if __name__ == "__main__":
    main()
