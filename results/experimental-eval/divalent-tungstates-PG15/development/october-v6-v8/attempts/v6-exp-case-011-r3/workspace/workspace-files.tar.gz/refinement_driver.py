#!/usr/bin/env python3
"""Utilities used to build and compare GSAS-II phase-model branches."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from scipy.ndimage import percentile_filter, uniform_filter1d


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "instrument.instprm"
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_cif(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def concise_state(project: G2sc.G2Project) -> dict:
    hist = project.histograms()[0]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "scale": hap["Scale"],
            "cell": phase.get_cell(),
            "size": hap.get("Size"),
            "mustrain": hap.get("Mustrain"),
        }
    return {
        "file": project.filename,
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background[0],
        "phases": phases,
        "covariance": covariance_status(project),
    }


def save_state(project: G2sc.G2Project, label: str) -> None:
    project.save()
    print(f"STATE {label} " + json.dumps(concise_state(project), default=str))


def stable_refine(
    project: G2sc.G2Project,
    label: str,
    attempts: int = 5,
    shift_limit: float = 0.10,
) -> bool:
    for cycle in range(1, attempts + 1):
        try:
            project.refine()
        except Exception as error:
            print(f"REFINE_ERROR {label} cycle={cycle}: {error!r}")
            save_state(project, label + "-error")
            return False
        status = covariance_status(project)
        msg = str(status.get("msg", "") or "").lower()
        print(
            f"REFINE {label} cycle={cycle} rwp={project.histograms()[0].get_wR()} "
            f"converged={status.get('converged')} shift={status.get('Max shft/sig')} "
            f"svd={status.get('SVD0')} msg={status.get('msg')!r}"
        )
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in msg:
            save_state(project, label + "-unstable")
            return False
        max_shift = status.get("Max shft/sig")
        if status.get("converged") and (
            max_shift is None or abs(float(max_shift)) < shift_limit
        ):
            save_state(project, label)
            return True
    save_state(project, label + "-maxcycles")
    return False


def initial_background() -> list[float]:
    x, y = np.loadtxt(PATTERN, delimiter=",", skiprows=1, unpack=True)
    # A wide rolling lower quantile avoids seeding Bragg intensity into the
    # empirical background while following the low-angle air-scatter tail.
    baseline = uniform_filter1d(
        percentile_filter(y, percentile=8.0, size=501, mode="nearest"),
        size=151,
        mode="nearest",
    )
    domain = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(domain, baseline, 11).tolist()


def set_controls(project: G2sc.G2Project) -> None:
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 0.0001
    controls["deriv type"] = "analytic Hessian"


def build_project(output: Path, phase_specs: list[tuple[str, str]]) -> G2sc.G2Project:
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma"
    )
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": initial_background(),
                "refine": True,
            },
        }
    )
    # Use a known starting correction only to put reflections inside their
    # profiles; angular alternatives are compared later with the supplied
    # branch helper.
    hist.InstrumentParameters["Zero"][1:] = [0.300, False]
    hist.InstrumentParameters["Polariz."][1:] = [0.5, False]
    hist.InstrumentParameters["I(L2)/I(L1)"][1:] = [0.5, False]
    hist.SampleParameters["Gonio. radius"] = 240.0
    # The histogram scale is redundant with all HAP scales; keep it fixed.
    hist.SampleParameters["Scale"][:] = [1.0, False]
    for name, cod_id in phase_specs:
        project.add_phase(
            str(cod_cif(cod_id)), phasename=name, histograms=[hist]
        )
    set_controls(project)
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    project.save()
    return project


def minimal_screen(output: Path, phase_specs: list[tuple[str, str]]) -> dict:
    project = build_project(output, phase_specs)
    save_state(project, "created")
    ok_scale = stable_refine(project, "background-scales", attempts=6)
    if not ok_scale:
        return {"ok": False, **concise_state(project)}
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    ok_cell = stable_refine(project, "cells", attempts=6)
    return {"ok": bool(ok_cell), **concise_state(project)}


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    screen = sub.add_parser("screen")
    screen.add_argument("output", type=Path)
    screen.add_argument(
        "phase", nargs="+", help="phase specification NAME=COD_ID"
    )
    inspect = sub.add_parser("inspect")
    inspect.add_argument("project", type=Path)
    args = parser.parse_args()
    if args.command == "screen":
        specs = []
        for item in args.phase:
            name, cod_id = item.split("=", 1)
            specs.append((name, cod_id))
        summary = minimal_screen(args.output.resolve(), specs)
        print("SCREEN_RESULT=" + json.dumps(summary, default=str))
    elif args.command == "inspect":
        project = G2sc.G2Project(str(args.project.resolve()))
        print(json.dumps(concise_state(project), indent=2, default=str))


if __name__ == "__main__":
    main()
