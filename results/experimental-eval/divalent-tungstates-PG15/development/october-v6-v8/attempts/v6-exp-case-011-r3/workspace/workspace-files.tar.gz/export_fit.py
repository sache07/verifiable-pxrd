#!/usr/bin/env python3
"""Export the regenerated full-grid observed/calculated/difference profile."""

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
project = G2sc.G2Project(str(ROOT / "final.gpx"))
hist = project.histograms()[0]
x, observed, _, calculated, _, difference = hist.data["data"][1][:6]
table = np.column_stack((x, observed, calculated, difference))
np.savetxt(
    ROOT / "fit.csv",
    table,
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference",
    comments="",
    fmt="%.10g",
)
print(f"FIT_EXPORT rows={len(table)} max_abs_closure={np.max(np.abs(observed-calculated-difference))}")
