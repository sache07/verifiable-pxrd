#!/usr/bin/env python3
"""Apply the selected nuisance model to an alternative phase model."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from branch_refine import project_summary
from refinement_driver import stable_refine


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("reference", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("target_wo3")
    args = parser.parse_args()

    reference = G2sc.G2Project(str(args.reference.resolve()))
    project = G2sc.G2Project(str(args.target.resolve()))
    project.save(str(args.output.resolve()))
    ref_hist = reference.histograms()[0]
    hist = project.histograms()[0]

    # Use exactly the selected instrumental/envelope parameterization and
    # values as the starting point for the alternative structure.
    for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"):
        hist.InstrumentParameters[key][1:] = copy.deepcopy(
            ref_hist.InstrumentParameters[key][1:]
        )
    for key in (
        "Shift",
        "Transparency",
        "SurfRoughA",
        "SurfRoughB",
        "DisplaceX",
        "DisplaceY",
    ):
        hist.SampleParameters[key] = copy.deepcopy(ref_hist.SampleParameters[key])

    ref_wo3 = reference.phase("WO3_triclinic")
    wo3 = project.phase(args.target_wo3)
    ref_wo3_hap = ref_wo3.data["Histograms"][ref_hist.name]
    wo3_hap = wo3.data["Histograms"][hist.name]
    wo3_hap["Size"] = copy.deepcopy(ref_wo3_hap["Size"])
    wo3_hap["Mustrain"] = copy.deepcopy(ref_wo3_hap["Mustrain"])

    ref_mno2 = reference.phase("MnO2_pyrolusite")
    mno2 = project.phase("MnO2_pyrolusite")
    mno2.data["Histograms"][hist.name]["Pref.Ori."] = copy.deepcopy(
        ref_mno2.data["Histograms"][ref_hist.name]["Pref.Ori."]
    )

    project.data["Controls"]["data"]["max cyc"] = 12
    ok = stable_refine(project, "matched-mature-model", attempts=10)
    print("MATURE_COMPARE_RESULT=" + json.dumps(project_summary(project, ok)))


if __name__ == "__main__":
    main()
