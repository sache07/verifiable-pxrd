#!/usr/bin/env python3
"""Create matched GSAS-II nuisance-model branches from a stable project."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from refinement_driver import covariance_status, stable_refine


PROFILE_KEYS = ("U", "V", "W", "X", "Y", "Z", "SH/L")


def correlation_summary(project: G2sc.G2Project) -> dict:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)) or not names:
        return {"max_abs": None, "pair": None}
    diagonal = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denominator = np.outer(diagonal, diagonal)
    corr = np.divide(
        matrix,
        denominator,
        out=np.zeros_like(matrix),
        where=denominator > 0,
    )
    np.fill_diagonal(corr, 0.0)
    flat = int(np.argmax(np.abs(corr)))
    row, col = np.unravel_index(flat, corr.shape)
    return {
        "max_abs": float(abs(corr[row, col])),
        "signed": float(corr[row, col]),
        "pair": [names[row], names[col]],
    }


def width_summary(hist: G2sc.G2PwdrData) -> dict:
    inst = hist.InstrumentParameters
    values = {key: float(inst[key][1]) for key in PROFILE_KEYS}
    two_theta = np.linspace(float(hist.Limits("lower")), float(hist.Limits("upper")), 1000)
    theta = np.radians(two_theta / 2.0)
    tangent = np.tan(theta)
    gaussian = values["U"] * tangent**2 + values["V"] * tangent + values["W"]
    lorentzian = values["X"] / np.cos(theta) + values["Y"] * tangent + values["Z"]
    return {
        "parameters": values,
        "gaussian_sigma2_min": float(np.min(gaussian)),
        "gaussian_sigma2_max": float(np.max(gaussian)),
        "lorentzian_gamma_min": float(np.min(lorentzian)),
        "lorentzian_gamma_max": float(np.max(lorentzian)),
    }


def project_summary(project: G2sc.G2Project, ok: bool) -> dict:
    hist = project.histograms()[0]
    return {
        "ok": ok,
        "project": project.filename,
        "rwp": float(hist.get_wR()),
        "widths": width_summary(hist),
        "correlation": correlation_summary(project),
        "convergence": {
            key: covariance_status(project).get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp")
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "scales": {
            phase.name: phase.data["Histograms"][hist.name]["Scale"]
            for phase in project.phases()
        },
    }


def parse_assignments(items: list[str]) -> dict[str, float]:
    result = {}
    for item in items:
        key, value = item.split("=", 1)
        result[key] = float(value)
    return result


def instrument_branch(source: Path, output: Path, assignments: dict[str, float]) -> dict:
    project = G2sc.G2Project(str(source.resolve()))
    project.save(str(output.resolve()))
    hist = project.histograms()[0]
    for key, value in assignments.items():
        if key not in PROFILE_KEYS and key not in (
            "Zero",
            "Polariz.",
            "I(L2)/I(L1)",
        ):
            raise ValueError(f"unsupported instrument parameter {key}")
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = True
    project.data["Controls"]["data"]["max cyc"] = 10
    ok = stable_refine(project, "instrument-" + "-".join(assignments), attempts=7)
    return project_summary(project, ok)


def sample_branch(source: Path, output: Path, assignments: dict[str, float]) -> dict:
    project = G2sc.G2Project(str(source.resolve()))
    project.save(str(output.resolve()))
    hist = project.histograms()[0]
    for key, value in assignments.items():
        parameter = hist.SampleParameters[key]
        parameter[0] = value
        parameter[1] = True
    project.data["Controls"]["data"]["max cyc"] = 10
    ok = stable_refine(project, "sample-" + "-".join(assignments), attempts=7)
    return project_summary(project, ok)


def hap_branch(
    source: Path,
    output: Path,
    phase_name: str,
    term: str,
    value: float,
) -> dict:
    project = G2sc.G2Project(str(source.resolve()))
    project.save(str(output.resolve()))
    phase = project.phase(phase_name)
    if term == "Size":
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": value, "refine": True}}
        )
    elif term == "Mustrain":
        hap = phase.data["Histograms"][project.histograms()[0].name]
        hap["Mustrain"][1][0] = value
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    else:
        raise ValueError(term)
    project.data["Controls"]["data"]["max cyc"] = 10
    ok = stable_refine(project, f"{phase_name}-{term}", attempts=7)
    result = project_summary(project, ok)
    hist_name = project.histograms()[0].name
    result["hap"] = {
        phase.name: {
            "Size": phase.data["Histograms"][hist_name]["Size"],
            "Mustrain": phase.data["Histograms"][hist_name]["Mustrain"],
        }
        for phase in project.phases()
    }
    return result


def texture_branch(
    source: Path,
    output: Path,
    phase_name: str,
    direction: list[int],
) -> dict:
    project = G2sc.G2Project(str(source.resolve()))
    project.save(str(output.resolve()))
    hist = project.histograms()[0]
    phase = project.phase(phase_name)
    preferred = phase.data["Histograms"][hist.name]["Pref.Ori."]
    preferred[0] = "MD"
    preferred[1] = 1.0
    preferred[2] = True
    preferred[3] = [int(value) for value in direction]
    project.data["Controls"]["data"]["max cyc"] = 10
    ok = stable_refine(
        project,
        f"{phase_name}-MD-{'-'.join(str(value) for value in direction)}",
        attempts=7,
    )
    result = project_summary(project, ok)
    result["preferred_orientation"] = {
        item.name: item.data["Histograms"][hist.name]["Pref.Ori."]
        for item in project.phases()
    }
    return result


def coordinate_branch(
    source: Path,
    output: Path,
    phase_name: str,
    atom_labels: list[str],
) -> dict:
    project = G2sc.G2Project(str(source.resolve()))
    project.save(str(output.resolve()))
    phase = project.phase(phase_name)
    phase.set_refinements(
        {"Atoms": {label: "X" for label in atom_labels}}
    )
    project.data["Controls"]["data"]["max cyc"] = 10
    ok = stable_refine(
        project,
        f"{phase_name}-coordinates-{'-'.join(atom_labels)}",
        attempts=7,
    )
    result = project_summary(project, ok)
    result["atoms"] = {
        item.name: [
            {
                "label": atom.label,
                "coordinates": atom.coordinates,
                "refinement_flags": atom.refinement_flags,
                "uiso": atom.uiso if atom.adp_flag == "I" else None,
            }
            for atom in item.atoms()
        ]
        for item in project.phases()
    }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    instrument = sub.add_parser("instrument")
    instrument.add_argument("source", type=Path)
    instrument.add_argument("output", type=Path)
    instrument.add_argument("assignment", nargs="+")
    sample = sub.add_parser("sample")
    sample.add_argument("source", type=Path)
    sample.add_argument("output", type=Path)
    sample.add_argument("assignment", nargs="+")
    hap = sub.add_parser("hap")
    hap.add_argument("source", type=Path)
    hap.add_argument("output", type=Path)
    hap.add_argument("phase")
    hap.add_argument("term", choices=("Size", "Mustrain"))
    hap.add_argument("value", type=float)
    texture = sub.add_parser("texture")
    texture.add_argument("source", type=Path)
    texture.add_argument("output", type=Path)
    texture.add_argument("phase")
    texture.add_argument("direction", nargs=3, type=int)
    coordinates = sub.add_parser("coordinates")
    coordinates.add_argument("source", type=Path)
    coordinates.add_argument("output", type=Path)
    coordinates.add_argument("phase")
    coordinates.add_argument("atom", nargs="+")
    args = parser.parse_args()
    if args.command == "instrument":
        result = instrument_branch(
            args.source, args.output, parse_assignments(args.assignment)
        )
    elif args.command == "sample":
        result = sample_branch(
            args.source, args.output, parse_assignments(args.assignment)
        )
    elif args.command == "hap":
        result = hap_branch(args.source, args.output, args.phase, args.term, args.value)
    elif args.command == "texture":
        result = texture_branch(
            args.source, args.output, args.phase, args.direction
        )
    else:
        result = coordinate_branch(
            args.source, args.output, args.phase, args.atom
        )
    print("BRANCH_RESULT=" + json.dumps(result, default=str))


if __name__ == "__main__":
    main()
