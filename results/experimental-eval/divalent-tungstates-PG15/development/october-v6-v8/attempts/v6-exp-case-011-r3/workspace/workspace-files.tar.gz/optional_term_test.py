#!/usr/bin/env python3
"""Matched leave-one-out checks for retained optional Rietveld terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from branch_refine import project_summary
from refinement_driver import stable_refine


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "term", choices=("W", "X", "polarization", "size", "strain", "texture")
    )
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()))
    project.save(str(args.output.resolve()))
    hist = project.histograms()[0]
    wo3_hap = project.phase("WO3_triclinic").data["Histograms"][hist.name]
    mno2_hap = project.phase("MnO2_pyrolusite").data["Histograms"][hist.name]

    if args.term == "W":
        hist.InstrumentParameters["W"][1:] = [50.0, False]
    elif args.term == "X":
        hist.InstrumentParameters["X"][1:] = [0.0, False]
    elif args.term == "polarization":
        hist.InstrumentParameters["Polariz."][1:] = [0.5, False]
    elif args.term == "size":
        wo3_hap["Size"][1][0] = 10.0
        wo3_hap["Size"][2][0] = False
    elif args.term == "strain":
        wo3_hap["Mustrain"][1][0] = 0.0
        wo3_hap["Mustrain"][2][0] = False
    elif args.term == "texture":
        mno2_hap["Pref.Ori."][1] = 1.0
        mno2_hap["Pref.Ori."][2] = False

    project.data["Controls"]["data"]["max cyc"] = 12
    project.save()
    ok = stable_refine(project, "remove-" + args.term, attempts=8)
    result = project_summary(project, ok)
    result["removed_term"] = args.term
    print("OPTIONAL_TERM_RESULT=" + json.dumps(result))


if __name__ == "__main__":
    main()
