#!/usr/bin/env python3
"""Converge the selected project and export final phase structures."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from branch_refine import correlation_summary, width_summary
from refinement_driver import covariance_status, stable_refine


ROOT = Path(__file__).resolve().parent


def main() -> None:
    source = ROOT / "branches" / "final-angular.gpx"
    output = ROOT / "final.gpx"
    project = G2sc.G2Project(str(source))
    project.save(str(output))
    project.data["Controls"]["data"]["max cyc"] = 12
    ok = stable_refine(project, "final-replay", attempts=8)
    if not ok:
        raise RuntimeError("final project did not reach the replay convergence criterion")

    cif_paths = {
        "WO3_triclinic": ROOT / "phase_wo3_triclinic.cif",
        "MnO2_pyrolusite": ROOT / "phase_mno2_pyrolusite.cif",
    }
    for phase_name, cif_path in cif_paths.items():
        project.phase(phase_name).export_CIF(str(cif_path), quickmode=True)
    project.save(str(output))

    hist = project.histograms()[0]
    fractions = hist.ComputeMassFracs()
    hist_name = hist.name
    result = {
        "project": str(output),
        "converged": ok,
        "residuals": hist.residuals,
        "covariance": covariance_status(project),
        "correlation": correlation_summary(project),
        "widths": width_summary(hist),
        "fractions": {
            name: {"value": float(value), "esd": float(esd)}
            for name, (value, esd) in fractions.items()
        },
        "phases": {
            phase.name: {
                "cif": str(cif_paths[phase.name]),
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist_name]["Scale"],
                "size": phase.data["Histograms"][hist_name]["Size"],
                "mustrain": phase.data["Histograms"][hist_name]["Mustrain"],
                "preferred_orientation": phase.data["Histograms"][hist_name][
                    "Pref.Ori."
                ],
            }
            for phase in project.phases()
        },
        "instrument": hist.InstrumentParameters,
    }
    print("FINAL_PROJECT_RESULT=" + json.dumps(result, default=str))


if __name__ == "__main__":
    main()
