#!/usr/bin/env python3
"""Test isotropic size and microstrain independently for each phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from profile_branch_tests import covariance_correlations, residual_bins, stable


def run_branch(
    source: Path,
    destination: Path,
    phase_name: str,
    term: str,
    preserve_existing: bool = False,
) -> dict:
    project = G2sc.G2Project(str(source.resolve()))
    histogram = project.histograms()[0]
    target = None
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        if preserve_existing:
            phase.clear_HAP_refinements({"Pref.Ori.": True})
        else:
            phase.clear_HAP_refinements(
                {"Size": True, "Mustrain": True, "Pref.Ori.": True}
            )
            # A true no-broadening control: GSAS-II phase links otherwise start
            # with finite 1 micron size and 1000 microstrain even when fixed.
            phase_hap = phase.data["Histograms"][histogram.name]
            phase_hap["Size"][0] = "isotropic"
            phase_hap["Size"][1][0] = 1000.0
            phase_hap["Mustrain"][0] = "isotropic"
            phase_hap["Mustrain"][1][0] = 0.0
        if phase.name == phase_name:
            target = phase
    if target is None:
        raise ValueError(f"phase not found: {phase_name}")
    histogram.clear_refinements(
        {
            "Instrument Parameters": ["Polariz."],
            "Sample Parameters": [
                "Shift",
                "Transparency",
                "SurfRoughA",
                "SurfRoughB",
            ],
        }
    )
    key = "Size" if term == "size" else "Mustrain"
    target_hap = target.data["Histograms"][histogram.name]
    if term == "size":
        target_hap["Size"][1][0] = 1.0
    else:
        target_hap["Mustrain"][1][0] = 500.0
    target.set_HAP_refinements(
        {key: {"type": "isotropic", "refine": True}}
    )
    project.set_Controls("cycles", 12)
    destination.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(destination.resolve()))
    variable = f"{target.id}:0:{key};i"
    if term == "size":
        project.set_Controls("parmMin", 0.001, variable=variable)
        project.set_Controls("parmMax", 1000.0, variable=variable)
    else:
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 100000.0, variable=variable)
    project.save(str(destination.resolve()))

    error = None
    rounds = 0
    for rounds in range(1, 13):
        try:
            project.refine()
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            break
        project.save(str(destination.resolve()))
        if stable(project, 0.05):
            break

    histogram = project.histograms()[0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    hap = target.data["Histograms"][histogram.name]
    try:
        fractions = {
            name: {"value": float(value), "esd": float(esd)}
            for name, (value, esd) in histogram.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": str(exc)}
    result = {
        "path": str(destination),
        "phase": phase_name,
        "term": term,
        "rounds": rounds,
        "error": error,
        "stable": stable(project, 0.05) if error is None else False,
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "svd_zero_count": rvals.get("SVD0"),
        "message": rvals.get("msg"),
        "rwp_percent": float(histogram.get_wR()),
        "gof": rvals.get("GOF"),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "mass_fractions": fractions,
        "residual_bins": residual_bins(histogram),
        "largest_correlations": covariance_correlations(project)[:15],
    }
    project.save(str(destination.resolve()))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_directory", type=Path)
    parser.add_argument("--phase", action="append", dest="phases")
    parser.add_argument("--terms", nargs="+", default=["size", "mustrain"])
    parser.add_argument("--preserve-existing", action="store_true")
    args = parser.parse_args()
    probe = G2sc.G2Project(str(args.source.resolve()))
    phases = args.phases or [phase.name for phase in probe.phases()]
    results = {}
    for phase_name in phases:
        for term in args.terms:
            token = f"{phase_name}-{term}"
            destination = args.output_directory / f"hap-{token}.gpx"
            result = run_branch(
                args.source,
                destination,
                phase_name,
                term,
                preserve_existing=args.preserve_existing,
            )
            results[token] = result
            print("HAP_BRANCH_RESULT=" + json.dumps({token: result}, sort_keys=True))
    (args.output_directory / "hap-branches.json").write_text(
        json.dumps(results, indent=2, sort_keys=True) + "\n"
    )


if __name__ == "__main__":
    main()
