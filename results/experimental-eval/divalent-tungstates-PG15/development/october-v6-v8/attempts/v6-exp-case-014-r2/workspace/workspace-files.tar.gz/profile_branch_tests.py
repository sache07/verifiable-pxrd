#!/usr/bin/env python3
"""Run isolated, matched GSAS-II profile branches from one stable project."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PROFILE_NAMES = ("U", "V", "W", "X", "Y", "Z")


def covariance_correlations(project: G2sc.G2Project) -> list[dict]:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    answer = []
    if matrix.shape != (len(names), len(names)):
        return answer
    sigmas = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    for i in range(len(names)):
        for j in range(i):
            denominator = sigmas[i] * sigmas[j]
            if denominator <= 0:
                continue
            value = float(matrix[i, j] / denominator)
            answer.append(
                {
                    "absolute": abs(value),
                    "value": value,
                    "parameters": [names[j], names[i]],
                }
            )
    return sorted(answer, key=lambda item: item["absolute"], reverse=True)


def residual_bins(histogram) -> list[dict]:
    x, observed, weights, calculated = [
        np.asarray(item, dtype=float) for item in histogram.data["data"][1][:4]
    ]
    answer = []
    for lower in np.arange(10.0, 100.0, 10.0):
        selected = (
            (x >= lower)
            & (x < lower + 10.0)
            & np.isfinite(observed)
            & np.isfinite(calculated)
            & np.isfinite(weights)
            & (weights > 0.0)
        )
        numerator = float(
            np.sum(weights[selected] * (observed[selected] - calculated[selected]) ** 2)
        )
        denominator = float(np.sum(weights[selected] * observed[selected] ** 2))
        answer.append(
            {
                "range_deg": [lower, lower + 10.0],
                "rwp_percent": 100.0 * math.sqrt(numerator / denominator),
            }
        )
    return answer


def width_extrema(histogram) -> dict:
    instrument = histogram.InstrumentParameters
    values = {name: float(instrument[name][1]) for name in PROFILE_NAMES}
    positions = np.linspace(
        float(histogram.data["Limits"][1][0]),
        float(histogram.data["Limits"][1][1]),
        1001,
    )
    tangent = np.tan(np.radians(positions / 2.0))
    cosine = np.cos(np.radians(positions / 2.0))
    sigma = values["U"] * tangent**2 + values["V"] * tangent + values["W"]
    gamma = values["X"] / cosine + values["Y"] * tangent + values["Z"]
    return {
        "minimum_gaussian_sigma": float(np.min(sigma)),
        "minimum_lorentzian_gamma": float(np.min(gamma)),
        "maximum_gaussian_sigma": float(np.max(sigma)),
        "maximum_lorentzian_gamma": float(np.max(gamma)),
    }


def stable(project: G2sc.G2Project, target: float) -> bool:
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    message = str(rvals.get("msg", "") or "").lower()
    shift = float(rvals.get("Max shft/sig") or math.inf)
    return bool(
        rvals.get("converged")
        and not rvals.get("SVD0", 0)
        and "dropped" not in message
        and "error" not in message
        and math.isfinite(shift)
        and shift < target
    )


def run_branch(
    source: Path,
    destination: Path,
    varied_profile: list[str],
    maximum_rounds: int,
    target_shift: float,
) -> dict:
    project = G2sc.G2Project(str(source.resolve()))
    histogram = project.histograms()[0]

    # Matched nuisance model: phase scales, background and only the requested
    # global profile terms vary. Geometry, cells, atoms and all HAP terms stay fixed.
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    histogram.clear_refinements(
        {
            "Instrument Parameters": list(PROFILE_NAMES),
            "Sample Parameters": [
                "Shift",
                "Transparency",
                "SurfRoughA",
                "SurfRoughB",
            ],
        }
    )
    # GSAS-II's Background=True convenience path returns immediately, so set
    # profile flags in a separate call before enabling the background.
    histogram.set_refinements({"Instrument Parameters": varied_profile})
    histogram.set_refinements({"Background": True})
    project.set_Controls("cycles", 12)
    destination.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(destination.resolve()))

    rounds = 0
    error = None
    for rounds in range(1, maximum_rounds + 1):
        try:
            project.refine()
        except Exception as exc:  # preserve failed branch for inspection
            error = f"{type(exc).__name__}: {exc}"
            break
        project.save(str(destination.resolve()))
        if stable(project, target_shift):
            break

    histogram = project.histograms()[0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    try:
        fractions = {
            name: {"value": float(value), "esd": float(esd)}
            for name, (value, esd) in histogram.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": str(exc)}
    result = {
        "path": str(destination),
        "varied_profile": varied_profile,
        "rounds": rounds,
        "error": error,
        "stable": stable(project, target_shift) if error is None else False,
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "svd_zero_count": rvals.get("SVD0"),
        "message": rvals.get("msg"),
        "rwp_percent": float(histogram.get_wR()),
        "gof": rvals.get("GOF"),
        "instrument": {
            name: {
                "value": float(histogram.InstrumentParameters[name][1]),
                "refine": bool(histogram.InstrumentParameters[name][2]),
            }
            for name in PROFILE_NAMES
        },
        "width_extrema": width_extrema(histogram),
        "mass_fractions": fractions,
        "residual_bins": residual_bins(histogram),
        "largest_correlations": covariance_correlations(project)[:15],
    }
    project.save(str(destination.resolve()))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_directory", type=Path)
    parser.add_argument(
        "--branches",
        nargs="+",
        default=["W", "UW", "VW", "WX", "WY"],
        help="Each token is the concatenation of profile terms to refine.",
    )
    parser.add_argument("--maximum-rounds", type=int, default=12)
    parser.add_argument("--target-shift", type=float, default=0.05)
    args = parser.parse_args()

    results = {}
    for token in args.branches:
        terms = [name for name in PROFILE_NAMES if name in token]
        if not terms:
            raise ValueError(f"no recognized profile terms in {token!r}")
        destination = args.output_directory / f"profile-{token.lower()}.gpx"
        result = run_branch(
            args.source,
            destination,
            terms,
            args.maximum_rounds,
            args.target_shift,
        )
        results[token] = result
        print("PROFILE_BRANCH_RESULT=" + json.dumps({token: result}, sort_keys=True))
    summary = args.output_directory / "profile-branches.json"
    summary.write_text(json.dumps(results, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
