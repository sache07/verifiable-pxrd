#!/usr/bin/env python3
"""Build comparable minimal GSAS-II phase-screening refinements."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def status(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
        }
    row = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "converged": covariance.get("Rvals", {}).get("converged"),
        "max_shift_over_esd": covariance.get("Rvals", {}).get("Max shft/sig"),
        "message": covariance.get("Rvals", {}).get("msg"),
        "vary_count": len(covariance.get("varyList", [])),
        "phases": phases,
        "instrument": {
            key: value
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
    }
    try:
        row["mass_fractions"] = {
            name: [float(value), float(esd)]
            for name, (value, esd) in hist.ComputeMassFracs().items()
        }
    except Exception as error:
        row["mass_fraction_error"] = str(error)
    print("SCREEN_STAGE=" + json.dumps(row, sort_keys=True))
    return row


def refine(project: G2sc.G2Project, output_dir: Path, label: str) -> dict:
    project.save(str(output_dir / f"pre-{label}.gpx"))
    project.refine(makeBack=False)
    project.save(str(output_dir / f"post-{label}.gpx"))
    return status(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "phase",
        nargs="+",
        help="phase specification NAME=COD_ID or NAME=@LOCAL_CIF",
    )
    args = parser.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)
    pattern = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
    x, y = pattern.T

    project = G2sc.G2Project(newgpx=str(args.output / "screen.gpx"))
    hist = project.add_simulated_powder_histogram(
        "observed pattern.csv",
        "instrument.instprm",
        float(x[0]),
        float(x[-1]),
        Npoints=len(x),
        wavelength=(1.540598, 1.544426),
    )
    arrays = hist.data["data"][1]
    arrays[0][:] = x
    arrays[1][:] = y
    arrays[2][:] = 1.0 / np.maximum(y, 1.0)
    arrays[3][:] = 0.0
    arrays[4][:] = 0.0
    arrays[5][:] = 0.0
    hist.data["data"][0].pop("Dummy", None)
    hist.data["Sample Parameters"]["Scale"][1] = False
    hist.data["Limits"][0] = [float(x[0]), float(x[-1])]
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]

    # Start the empirical background close to a robust lower envelope.
    baseline = percentile_filter(y, percentile=15, size=501, mode="nearest")
    coordinate = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    coefficients = np.polynomial.chebyshev.chebfit(coordinate, baseline, 11)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(coefficients),
                "coeffs": coefficients.tolist(),
                "refine": True,
            }
        }
    )

    for specification in args.phase:
        name, source = specification.split("=", 1)
        cif_path = Path(source[1:]) if source.startswith("@") else cod_path(source)
        phase = project.add_phase(
            str(cif_path),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.set_HAP_refinements({"Scale": True})

    project.set_Controls("cycles", 8)
    project.save()
    rows = []
    rows.append(refine(project, args.output, "background-scales"))

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    rows.append(refine(project, args.output, "cells"))

    hist.set_refinements({"Instrument Parameters": ["W"]})
    rows.append(refine(project, args.output, "global-W"))

    project.save(str(args.output / "screen.gpx"))
    (args.output / "summary.json").write_text(
        json.dumps(rows, indent=2, sort_keys=True), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
