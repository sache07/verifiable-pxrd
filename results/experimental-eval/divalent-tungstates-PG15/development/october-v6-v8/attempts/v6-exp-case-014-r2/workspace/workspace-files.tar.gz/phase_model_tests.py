#!/usr/bin/env python3
"""Matched phase leave-out, replacement, and source-candidate tests."""

from __future__ import annotations

import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
SOURCE = Path("screen4/p21c/angular-round3-shift-only.gpx")
BASE = Path("model_tests/baseline.gpx")
OUT = Path("model_tests")


def cod(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def converge(project: G2sc.G2Project, maximum_rounds: int = 12) -> bool:
    project.set_Controls("cycles", 12)
    for _ in range(maximum_rounds):
        project.refine()
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        message = str(rvals.get("msg", "") or "").lower()
        shift = float(rvals.get("Max shft/sig") or 0.0)
        if (
            rvals.get("converged")
            and not rvals.get("SVD0", 0)
            and "dropped" not in message
            and "error" not in message
            and math.isfinite(shift)
            and shift < 0.05
        ):
            return True
    return False


def summary(project: G2sc.G2Project, label: str, stable: bool) -> dict:
    histogram = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(histogram.name)
        phases[phase.name] = {
            "use": hap.get("Use") if hap else None,
            "scale": hap.get("Scale") if hap else None,
            "cell": phase.get_cell(),
        }
    try:
        fractions = {
            key: [float(value), float(esd)]
            for key, (value, esd) in histogram.ComputeMassFracs().items()
        }
    except Exception as error:
        fractions = {"error": str(error)}
    return {
        "label": label,
        "stable": stable,
        "rwp_percent": float(histogram.get_wR()),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "svd_zero_count": rvals.get("SVD0"),
        "message": rvals.get("msg"),
        "mass_fractions": fractions,
        "phases": phases,
    }


def save_and_run(project: G2sc.G2Project, stem: str) -> tuple[G2sc.G2Project, dict]:
    destination = OUT / f"{stem}.gpx"
    project.save(str(destination.resolve()))
    stable = converge(project)
    project.save(str(destination.resolve()))
    row = summary(project, stem, stable)
    print("MODEL_TEST=" + json.dumps(row, sort_keys=True))
    return project, row


def leave_out(name: str) -> dict:
    project = G2sc.G2Project(str(BASE.resolve()))
    histogram = project.histograms()[0]
    phase = project.phase(name)
    hap = phase.data["Histograms"][histogram.name]
    hap["Use"] = False
    hap["Scale"][1] = False
    _, row = save_and_run(project, "leave-out-" + name)
    return row


def add_test(name: str, path: Path, starting_scale: float) -> list[dict]:
    project = G2sc.G2Project(str(BASE.resolve()))
    project.save(str((OUT / ("working-add-" + name + ".gpx")).resolve()))
    histogram = project.histograms()[0]
    phase = project.add_phase(
        str(path.resolve()), phasename=name, histograms=[histogram], fmthint="CIF"
    )
    phase.data["Histograms"][histogram.name]["Scale"] = [starting_scale, True]
    project, fixed = save_and_run(project, "add-" + name + "-fixed-cell")
    rows = [fixed]
    scale = float(phase.data["Histograms"][histogram.name]["Scale"][0])
    if fixed["stable"] and scale > 1.0e-5:
        phase.data["General"]["Cell"][0] = True
        project, free = save_and_run(project, "add-" + name + "-free-cell")
        rows.append(free)
    return rows


def replace_wo3() -> list[dict]:
    project = G2sc.G2Project(str(BASE.resolve()))
    project.save(str((OUT / "working-replace-WO3-Pminus1.gpx").resolve()))
    histogram = project.histograms()[0]
    old = project.phase("WO3_P21c")
    old_hap = old.data["Histograms"][histogram.name]
    starting_scale = float(old_hap["Scale"][0])
    old_hap["Use"] = False
    old_hap["Scale"][1] = False
    phase = project.add_phase(
        str(cod("2106293")),
        phasename="WO3_Pminus1_replacement",
        histograms=[histogram],
        fmthint="CIF",
    )
    phase.data["Histograms"][histogram.name]["Scale"] = [starting_scale, True]
    project, fixed = save_and_run(project, "replace-WO3-Pminus1-fixed-cell")
    rows = [fixed]
    if fixed["stable"]:
        phase.data["General"]["Cell"][0] = True
        project, free = save_and_run(project, "replace-WO3-Pminus1-free-cell")
        rows.append(free)
    return rows


def main() -> None:
    OUT.mkdir(exist_ok=True)
    restored = G2sc.G2Project(str(SOURCE.resolve()))
    restored.save(str(BASE.resolve()))
    baseline = G2sc.G2Project(str(BASE.resolve()))
    rows: list[dict] = [summary(baseline, "baseline", True)]
    for name in ("SrWO4", "WO3_P21c", "Sr3WO6"):
        rows.append(leave_out(name))
    rows.extend(replace_wo3())
    rows.extend(add_test("SrWO4_monoclinic", cod("1546037"), 0.03))
    rows.extend(add_test("Sr3W2O9", cod("2311977"), 0.03))
    rows.extend(add_test("SrCO3", cod("9008198"), 0.03))
    (OUT / "summary.json").write_text(
        json.dumps(rows, indent=2, sort_keys=True), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
