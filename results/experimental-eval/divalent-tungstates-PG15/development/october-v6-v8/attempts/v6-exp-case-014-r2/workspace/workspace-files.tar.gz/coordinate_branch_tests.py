#!/usr/bin/env python3
"""Test small, chemically interpretable coordinate subsets in isolation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from profile_branch_tests import covariance_correlations, residual_bins, stable


DEFAULT_BRANCHES = [
    ("SrWO4", ["O"]),
    ("WO3_P21c", ["W1", "W2"]),
    ("Sr3WO6", ["O1"]),
]


def atom_table(phase) -> list[dict]:
    cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
    answer = []
    for atom in phase.data["Atoms"]:
        answer.append(
            {
                "label": atom[ct - 1],
                "type": atom[ct],
                "flags": atom[cx - 1],
                "xyz": [float(value) for value in atom[cx : cx + 3]],
                "occupancy": float(atom[cx + 3]),
                "uiso": float(atom[cia + 1]),
            }
        )
    return answer


def run_branch(
    source: Path, destination: Path, phase_name: str, atom_labels: list[str]
) -> dict:
    project = G2sc.G2Project(str(source.resolve()))
    histogram = project.histograms()[0]
    target = None
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Pref.Ori.": True})
        if phase.name == phase_name:
            target = phase
    if target is None:
        raise ValueError(phase_name)
    initial_atoms = atom_table(target)
    target.set_refinements(
        {"Atoms": {label: "X" for label in atom_labels}}
    )
    histogram.clear_refinements(
        {
            "Instrument Parameters": ["Polariz."],
            "Sample Parameters": [
                "Shift",
                "Transparency",
                "SurfRoughA",
                "SurfRoughB",
            ],
        }
    )
    project.set_Controls("cycles", 12)
    destination.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(destination.resolve()))

    error = None
    rounds = 0
    for rounds in range(1, 13):
        try:
            project.refine()
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            break
        project.save(str(destination.resolve()))
        if stable(project, 0.05):
            break

    histogram = project.histograms()[0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    try:
        fractions = {
            name: {"value": float(value), "esd": float(esd)}
            for name, (value, esd) in histogram.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": str(exc)}
    result = {
        "path": str(destination),
        "phase": phase_name,
        "atom_labels": atom_labels,
        "rounds": rounds,
        "error": error,
        "stable": stable(project, 0.05) if error is None else False,
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "svd_zero_count": rvals.get("SVD0"),
        "message": rvals.get("msg"),
        "rwp_percent": float(histogram.get_wR()),
        "gof": rvals.get("GOF"),
        "initial_atoms": initial_atoms,
        "final_atoms": atom_table(target),
        "mass_fractions": fractions,
        "residual_bins": residual_bins(histogram),
        "largest_correlations": covariance_correlations(project)[:20],
    }
    project.save(str(destination.resolve()))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_directory", type=Path)
    parser.add_argument(
        "--branch",
        action="append",
        help="PHASE:atom1,atom2; may be repeated.",
    )
    args = parser.parse_args()
    branches = DEFAULT_BRANCHES
    if args.branch:
        branches = []
        for specification in args.branch:
            phase, raw_atoms = specification.split(":", 1)
            branches.append((phase, raw_atoms.split(",")))
    results = {}
    for phase_name, labels in branches:
        name = f"{phase_name}-{'_'.join(labels)}"
        destination = args.output_directory / f"coordinates-{name}.gpx"
        result = run_branch(args.source, destination, phase_name, labels)
        results[name] = result
        print("COORDINATE_BRANCH_RESULT=" + json.dumps({name: result}, sort_keys=True))
    (args.output_directory / "coordinate-branches.json").write_text(
        json.dumps(results, indent=2, sort_keys=True) + "\n"
    )


if __name__ == "__main__":
    main()
