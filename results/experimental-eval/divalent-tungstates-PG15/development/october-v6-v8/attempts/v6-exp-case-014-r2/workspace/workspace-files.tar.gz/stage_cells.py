#!/usr/bin/env python3
"""Refine phase cells sequentially after selecting an angular correction."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def stable(project: G2sc.G2Project, maximum_rounds: int = 24) -> tuple[bool, dict]:
    result = {}
    for round_index in range(1, maximum_rounds + 1):
        project.refine()
        result = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        message = str(result.get("msg", "") or "").lower()
        shift = float(result.get("Max shft/sig") or 0.0)
        print(
            "CELL_STAGE_ROUND="
            + json.dumps(
                {
                    "round": round_index,
                    "rwp_percent": float(project.histograms()[0].get_wR()),
                    "max_shift_over_esd": shift,
                    "converged": result.get("converged"),
                    "svd_zero_count": result.get("SVD0"),
                    "message": result.get("msg"),
                },
                sort_keys=True,
            )
        )
        if (
            result.get("converged")
            and not result.get("SVD0", 0)
            and "dropped" not in message
            and "error" not in message
            and math.isfinite(shift)
            and shift < 0.05
        ):
            return True, result
    return False, result


def report(project: G2sc.G2Project, label: str, ok: bool) -> None:
    histogram = project.histograms()[0]
    print(
        "CELL_STAGE_RESULT="
        + json.dumps(
            {
                "label": label,
                "stable": ok,
                "rwp_percent": float(histogram.get_wR()),
                "cells": {phase.name: phase.get_cell() for phase in project.phases()},
                "mass_fractions": {
                    name: [float(value), float(esd)]
                    for name, (value, esd) in histogram.ComputeMassFracs().items()
                },
                "shift": histogram.SampleParameters["Shift"],
            },
            sort_keys=True,
        )
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()))
    project.set_Controls("cycles", 12)
    histogram = project.histograms()[0]
    histogram.SampleParameters["Shift"][1] = False
    histogram.InstrumentParameters["Zero"][2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
    args.destination.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(args.destination.resolve()))

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        project.save(str(args.destination.with_name(args.destination.stem + f"-pre-{phase.name}.gpx")))
        ok, _ = stable(project)
        report(project, phase.name, ok)
        if not ok:
            raise RuntimeError(f"cell stage did not stabilize for {phase.name}")
        phase.data["General"]["Cell"][0] = False
        project.save(str(args.destination.resolve()))

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    project.save(str(args.destination.with_name(args.destination.stem + "-pre-joint.gpx")))
    ok, _ = stable(project)
    report(project, "all-cells", ok)
    if not ok:
        raise RuntimeError("joint cell stage did not stabilize")
    project.save(str(args.destination.resolve()))


if __name__ == "__main__":
    main()
