#!/usr/bin/env python3
"""Retest phase inventory from a mature GSAS-II baseline, one branch at a time."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def stable(project: G2sc.G2Project, limit: float = 0.05) -> bool:
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    message = str(rvals.get("msg", "") or "").lower()
    shift = float(rvals.get("Max shft/sig") or math.inf)
    return bool(
        rvals.get("converged")
        and not rvals.get("SVD0", 0)
        and "dropped" not in message
        and "error" not in message
        and math.isfinite(shift)
        and shift < limit
    )


def converge(project: G2sc.G2Project, rounds: int = 14) -> tuple[bool, int, str | None]:
    error = None
    for round_index in range(1, rounds + 1):
        try:
            project.refine()
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            return False, round_index, error
        if stable(project):
            return True, round_index, None
    return False, rounds, error


def result(project: G2sc.G2Project, label: str, ok: bool, rounds: int, error) -> dict:
    histogram = project.histograms()[0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    fractions = {}
    try:
        fractions = {
            name: {"value": float(value), "esd": float(esd)}
            for name, (value, esd) in histogram.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": str(exc)}
    return {
        "label": label,
        "stable": ok,
        "rounds": rounds,
        "error": error,
        "rwp_percent": float(histogram.get_wR()),
        "gof": rvals.get("GOF"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "svd_zero_count": rvals.get("SVD0"),
        "message": rvals.get("msg"),
        "mass_fractions": fractions,
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }


def save_run(project: G2sc.G2Project, output: Path, stem: str) -> tuple[G2sc.G2Project, dict]:
    path = output / f"{stem}.gpx"
    project.set_Controls("cycles", 12)
    project.save(str(path.resolve()))
    ok, rounds, error = converge(project)
    project.save(str(path.resolve()))
    row = result(project, stem, ok, rounds, error)
    print("MATURE_PHASE_TEST=" + json.dumps(row, sort_keys=True))
    return project, row


def reset_new_phase_hap(phase, histogram) -> None:
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    hap = phase.data["Histograms"][histogram.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1000.0
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0


def leave_out(source: Path, output: Path, phase_name: str) -> dict:
    project = G2sc.G2Project(str(source.resolve()))
    histogram = project.histograms()[0]
    hap = project.phase(phase_name).data["Histograms"][histogram.name]
    hap["Use"] = False
    hap["Scale"][1] = False
    _, row = save_run(project, output, f"leave-out-{phase_name}")
    return row


def add_phase(
    source: Path,
    output: Path,
    phase_name: str,
    cif_path: Path,
    start_scale: float,
) -> list[dict]:
    project = G2sc.G2Project(str(source.resolve()))
    # G2Project.add_phase() auto-saves to the project's current filename.
    # Move the branch to its own file before importing anything.
    project.save(str((output / f"working-add-{phase_name}.gpx").resolve()))
    histogram = project.histograms()[0]
    phase = project.add_phase(
        str(cif_path.resolve()),
        phasename=phase_name,
        histograms=[histogram],
        fmthint="CIF",
    )
    reset_new_phase_hap(phase, histogram)
    phase.data["Histograms"][histogram.name]["Scale"] = [start_scale, True]
    phase.data["General"]["Cell"][0] = False
    project, fixed = save_run(project, output, f"add-{phase_name}-fixed-cell")
    return [fixed]


def replace_wo3(source: Path, output: Path) -> list[dict]:
    project = G2sc.G2Project(str(source.resolve()))
    # Protect the stable source from add_phase()'s implicit save.
    project.save(str((output / "working-replace-WO3-Pminus1.gpx").resolve()))
    histogram = project.histograms()[0]
    old_hap = project.phase("WO3_P21c").data["Histograms"][histogram.name]
    start_scale = float(old_hap["Scale"][0])
    old_hap["Use"] = False
    old_hap["Scale"][1] = False
    phase = project.add_phase(
        str(cod("2106293").resolve()),
        phasename="WO3_Pminus1_replacement",
        histograms=[histogram],
        fmthint="CIF",
    )
    reset_new_phase_hap(phase, histogram)
    phase.data["Histograms"][histogram.name]["Scale"] = [start_scale, True]
    phase.data["General"]["Cell"][0] = False
    project, fixed = save_run(project, output, "replace-WO3-Pminus1-fixed-cell")
    rows = [fixed]
    fraction = fixed["mass_fractions"].get("WO3_Pminus1_replacement", {})
    if fixed["stable"] and float(fraction.get("value", 0.0)) > 0.01:
        phase.data["General"]["Cell"][0] = True
        _, free = save_run(project, output, "replace-WO3-Pminus1-free-cell")
        rows.append(free)
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_directory", type=Path)
    args = parser.parse_args()
    args.output_directory.mkdir(parents=True, exist_ok=True)
    baseline = G2sc.G2Project(str(args.source.resolve()))
    rows = [result(baseline, "baseline", stable(baseline), 0, None)]
    for phase_name in ("SrWO4", "WO3_P21c", "Sr3WO6"):
        rows.append(leave_out(args.source, args.output_directory, phase_name))
    rows.extend(replace_wo3(args.source, args.output_directory))
    rows.extend(
        add_phase(
            args.source,
            args.output_directory,
            "SrWO4_monoclinic",
            cod("1546037"),
            0.03,
        )
    )
    rows.extend(
        add_phase(
            args.source,
            args.output_directory,
            "Sr3W2O9",
            cod("2311977"),
            0.03,
        )
    )
    rows.extend(
        add_phase(
            args.source,
            args.output_directory,
            "SrCO3",
            cod("9008198"),
            0.03,
        )
    )
    (args.output_directory / "summary.json").write_text(
        json.dumps(rows, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
