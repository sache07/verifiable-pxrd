#!/usr/bin/env python3
"""Compare polarization and Suortti surface-roughness envelope branches."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from profile_branch_tests import covariance_correlations, residual_bins, stable


def run_branch(source: Path, destination: Path, mode: str) -> dict:
    project = G2sc.G2Project(str(source.resolve()))
    histogram = project.histograms()[0]
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    histogram.clear_refinements(
        {
            "Instrument Parameters": ["Polariz."],
            "Sample Parameters": [
                "Shift",
                "Transparency",
                "SurfRoughA",
                "SurfRoughB",
            ],
        }
    )
    project.set_Controls("cycles", 12)
    destination.parent.mkdir(parents=True, exist_ok=True)
    # Save before setting parameter limits because that API can auto-save.
    project.save(str(destination.resolve()))

    if mode == "polarization":
        histogram.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif mode == "rough-b":
        histogram.SampleParameters["SurfRoughA"][0] = 0.5
        histogram.SampleParameters["SurfRoughB"][0] = 0.1
        histogram.set_refinements({"Sample Parameters": ["SurfRoughB"]})
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")
    elif mode == "rough-ab":
        histogram.SampleParameters["SurfRoughA"][0] = 0.5
        histogram.SampleParameters["SurfRoughB"][0] = 0.1
        histogram.set_refinements(
            {"Sample Parameters": ["SurfRoughA", "SurfRoughB"]}
        )
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")
    elif mode != "baseline":
        raise ValueError(mode)

    project.save(str(destination.resolve()))
    error = None
    rounds = 0
    for rounds in range(1, 13):
        try:
            project.refine()
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            break
        project.save(str(destination.resolve()))
        if stable(project, 0.05):
            break

    histogram = project.histograms()[0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    sample = histogram.SampleParameters
    instrument = histogram.InstrumentParameters
    try:
        fractions = {
            name: {"value": float(value), "esd": float(esd)}
            for name, (value, esd) in histogram.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": str(exc)}
    result = {
        "path": str(destination),
        "mode": mode,
        "rounds": rounds,
        "error": error,
        "stable": stable(project, 0.05) if error is None else False,
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "svd_zero_count": rvals.get("SVD0"),
        "message": rvals.get("msg"),
        "rwp_percent": float(histogram.get_wR()),
        "gof": rvals.get("GOF"),
        "parameters": {
            "Polariz.": list(instrument["Polariz."]),
            "SurfRoughA": list(sample["SurfRoughA"]),
            "SurfRoughB": list(sample["SurfRoughB"]),
        },
        "mass_fractions": fractions,
        "residual_bins": residual_bins(histogram),
        "largest_correlations": covariance_correlations(project)[:15],
    }
    project.save(str(destination.resolve()))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_directory", type=Path)
    parser.add_argument(
        "--modes",
        nargs="+",
        default=["baseline", "polarization", "rough-b", "rough-ab"],
    )
    args = parser.parse_args()
    results = {}
    for mode in args.modes:
        destination = args.output_directory / f"envelope-{mode}.gpx"
        result = run_branch(args.source, destination, mode)
        results[mode] = result
        print("ENVELOPE_BRANCH_RESULT=" + json.dumps({mode: result}, sort_keys=True))
    (args.output_directory / "envelope-branches.json").write_text(
        json.dumps(results, indent=2, sort_keys=True) + "\n"
    )


if __name__ == "__main__":
    main()
