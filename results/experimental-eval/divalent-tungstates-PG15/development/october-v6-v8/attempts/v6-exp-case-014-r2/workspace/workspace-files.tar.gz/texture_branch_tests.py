#!/usr/bin/env python3
"""Screen simple March-Dollase axes one phase at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from profile_branch_tests import covariance_correlations, residual_bins, stable


DEFAULT_BRANCHES = [
    ("SrWO4", [0, 0, 1]),
    ("SrWO4", [1, 0, 0]),
    ("SrWO4", [1, 1, 2]),
    ("WO3_P21c", [0, 1, 0]),
    ("WO3_P21c", [0, 0, 1]),
    ("Sr3WO6", [1, 1, 1]),
    ("Sr3WO6", [1, 0, 0]),
]


def token(phase: str, axis: list[int]) -> str:
    return f"{phase}-{'_'.join(str(value) for value in axis)}"


def run_branch(
    source: Path, destination: Path, phase_name: str, axis: list[int]
) -> dict:
    project = G2sc.G2Project(str(source.resolve()))
    histogram = project.histograms()[0]
    target = None
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Pref.Ori.": True})
        if phase.name == phase_name:
            target = phase
    if target is None:
        raise ValueError(phase_name)
    histogram.clear_refinements(
        {
            "Instrument Parameters": ["Polariz."],
            "Sample Parameters": [
                "Shift",
                "Transparency",
                "SurfRoughA",
                "SurfRoughB",
            ],
        }
    )
    preferred = target.data["Histograms"][histogram.name]["Pref.Ori."]
    preferred[0] = "MD"
    preferred[1] = 1.0
    preferred[2] = True
    preferred[3] = list(axis)
    project.set_Controls("cycles", 12)
    destination.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(destination.resolve()))
    variable = f"{target.id}:0:MD"
    project.set_Controls("parmMin", 0.2, variable=variable)
    project.set_Controls("parmMax", 5.0, variable=variable)
    project.save(str(destination.resolve()))

    error = None
    rounds = 0
    for rounds in range(1, 13):
        try:
            project.refine()
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            break
        project.save(str(destination.resolve()))
        if stable(project, 0.05):
            break

    histogram = project.histograms()[0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    preferred = target.data["Histograms"][histogram.name]["Pref.Ori."]
    try:
        fractions = {
            name: {"value": float(value), "esd": float(esd)}
            for name, (value, esd) in histogram.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": str(exc)}
    result = {
        "path": str(destination),
        "phase": phase_name,
        "axis": axis,
        "rounds": rounds,
        "error": error,
        "stable": stable(project, 0.05) if error is None else False,
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "svd_zero_count": rvals.get("SVD0"),
        "message": rvals.get("msg"),
        "rwp_percent": float(histogram.get_wR()),
        "gof": rvals.get("GOF"),
        "march_dollase": preferred,
        "mass_fractions": fractions,
        "residual_bins": residual_bins(histogram),
        "largest_correlations": covariance_correlations(project)[:15],
    }
    project.save(str(destination.resolve()))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_directory", type=Path)
    parser.add_argument(
        "--branch",
        action="append",
        help="PHASE:h,k,l; may be repeated. Defaults to a compact axis screen.",
    )
    args = parser.parse_args()
    branches = DEFAULT_BRANCHES
    if args.branch:
        branches = []
        for specification in args.branch:
            phase, raw_axis = specification.split(":", 1)
            axis = [int(value) for value in raw_axis.split(",")]
            if len(axis) != 3:
                raise ValueError(specification)
            branches.append((phase, axis))
    results = {}
    for phase_name, axis in branches:
        name = token(phase_name, axis)
        destination = args.output_directory / f"texture-{name}.gpx"
        result = run_branch(args.source, destination, phase_name, axis)
        results[name] = result
        print("TEXTURE_BRANCH_RESULT=" + json.dumps({name: result}, sort_keys=True))
    (args.output_directory / "texture-branches.json").write_text(
        json.dumps(results, indent=2, sort_keys=True) + "\n"
    )


if __name__ == "__main__":
    main()
