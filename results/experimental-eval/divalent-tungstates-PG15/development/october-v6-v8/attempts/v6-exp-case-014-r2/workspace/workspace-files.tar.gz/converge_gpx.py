#!/usr/bin/env python3
"""Copy and repeatedly refine a GSAS-II project to a stable stopping point."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def summary(project: G2sc.G2Project, rounds: int) -> dict:
    histogram = project.histograms()[0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    correlations = []
    if matrix.shape == (len(names), len(names)):
        sigmas = np.sqrt(np.maximum(np.diag(matrix), 0.0))
        for i in range(len(names)):
            for j in range(i):
                denominator = sigmas[i] * sigmas[j]
                if denominator > 0:
                    value = float(matrix[i, j] / denominator)
                    correlations.append((abs(value), value, names[j], names[i]))
    correlations.sort(reverse=True)
    try:
        fractions = {
            name: {"value": float(value), "esd": float(esd)}
            for name, (value, esd) in histogram.ComputeMassFracs().items()
        }
    except Exception as error:
        fractions = {"error": str(error)}
    return {
        "rounds": rounds,
        "rwp_percent": float(histogram.get_wR()),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "svd_zero_count": rvals.get("SVD0"),
        "message": rvals.get("msg"),
        "vary_count": len(names),
        "mass_fractions": fractions,
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "instrument": {
            key: value
            for key, value in histogram.InstrumentParameters.items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "sample": {
            key: value
            for key, value in histogram.SampleParameters.items()
            if key in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
        },
        "largest_correlations": [
            {"absolute": absolute, "value": value, "parameters": [one, two]}
            for absolute, value, one, two in correlations[:12]
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--maximum-rounds", type=int, default=12)
    parser.add_argument("--target-shift", type=float, default=0.05)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()))
    project.set_Controls("cycles", 12)
    args.destination.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(args.destination.resolve()))
    rounds = 0
    for rounds in range(1, args.maximum_rounds + 1):
        project.refine()
        covariance = project.data.get("Covariance", {}).get("data", {})
        rvals = covariance.get("Rvals", {})
        message = str(rvals.get("msg", "") or "").lower()
        stable = (
            rvals.get("converged")
            and not rvals.get("SVD0", 0)
            and "dropped" not in message
            and "error" not in message
            and math.isfinite(float(rvals.get("Max shft/sig") or 0.0))
            and float(rvals.get("Max shft/sig") or 0.0) < args.target_shift
        )
        print(
            "CONVERGENCE_ROUND="
            + json.dumps(
                {
                    "round": rounds,
                    "rwp_percent": float(project.histograms()[0].get_wR()),
                    "converged": rvals.get("converged"),
                    "max_shift_over_esd": rvals.get("Max shft/sig"),
                    "svd_zero_count": rvals.get("SVD0"),
                    "message": rvals.get("msg"),
                },
                sort_keys=True,
            )
        )
        project.save(str(args.destination.resolve()))
        if stable:
            break
    print("CONVERGENCE_RESULT=" + json.dumps(summary(project, rounds), sort_keys=True))


if __name__ == "__main__":
    main()
