#!/usr/bin/env python3
"""Summarize full-pattern residuals for already-regenerated GSAS-II projects."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def load(path: Path) -> dict:
    project = G2sc.G2Project(str(path))
    histogram = project.histograms()[0]
    x, observed, weight, calculated, background, difference = (
        np.asarray(values, dtype=float) for values in histogram.data["data"][1][:6]
    )
    lower, upper = map(float, histogram.data["Limits"][1])
    used = (x >= lower) & (x <= upper) & np.isfinite(weight) & (weight > 0)
    return {
        "path": str(path),
        "x": x,
        "observed": observed,
        "weight": weight,
        "calculated": calculated,
        "background": background,
        "difference": difference,
        "used": used,
    }


def metrics(data: dict, mask: np.ndarray) -> dict:
    mask = mask & data["used"]
    residual = data["observed"][mask] - data["calculated"][mask]
    weight = data["weight"][mask]
    numerator = float(np.sum(weight * residual**2))
    denominator = float(np.sum(weight * data["observed"][mask] ** 2))
    return {
        "points": int(mask.sum()),
        "weighted_ssr": numerator,
        "rwp_percent": 100.0 * np.sqrt(numerator / denominator),
        "rms_counts": float(np.sqrt(np.mean(residual**2))),
    }


def main() -> None:
    if len(sys.argv) < 3:
        raise SystemExit("usage: compare_profiles.py BASE.gpx CANDIDATE.gpx [...]")
    datasets = [load(Path(name).resolve()) for name in sys.argv[1:]]
    base = datasets[0]
    edges = [10, 25, 40, 55, 70, 85, 100.1]
    output = []
    for data in datasets:
        if not np.allclose(data["x"], base["x"]):
            raise ValueError("projects have different grids")
        whole = metrics(data, np.ones_like(data["used"], dtype=bool))
        regions = []
        for lower, upper in zip(edges[:-1], edges[1:]):
            mask = (data["x"] >= lower) & (data["x"] < upper)
            item = {"range_deg": [lower, upper], **metrics(data, mask)}
            if data is not base:
                base_item = metrics(base, mask)
                item["weighted_ssr_change_from_base"] = (
                    item["weighted_ssr"] - base_item["weighted_ssr"]
                )
            regions.append(item)
        output.append({"project": data["path"], "whole": whole, "regions": regions})
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
