#!/usr/bin/env python3
"""Run matched leave-one-out or retained-term removal GSAS-II branches."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine_stably(project: G2sc.G2Project, attempts: int = 8) -> bool:
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as error:
            print("REFINEMENT_ERROR=" + repr(error))
            return False
        current = status(project)
        message = str(current.get("msg") or "").lower()
        if current.get("Aborted") or current.get("SVD0", 0) or "dropped" in message:
            return False
        if current.get("converged") and float(current.get("Max shft/sig") or math.inf) < 0.05:
            return True
    return False


def freeze_phase(phase, histogram_name: str) -> None:
    phase.data["General"]["Cell"][0] = False
    for atom in phase.data["Atoms"]:
        atom[2] = ""
    hap = phase.data["Histograms"][histogram_name]
    hap["Scale"][:] = [0.0, False]
    if "Pref.Ori." in hap:
        hap["Pref.Ori."][2] = False
    for key in ("Size", "Mustrain"):
        if key in hap:
            hap[key][2] = [False] * len(hap[key][2])
    if "HStrain" in hap:
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])


def configure(project: G2sc.G2Project, mode: str, phase_name: str | None) -> None:
    histogram = project.histograms()[0]
    if mode == "leave-phase":
        phase = project.phase(phase_name)
        if phase is None:
            raise ValueError(f"phase not found: {phase_name}")
        freeze_phase(phase, histogram.name)
        return
    if mode == "remove-polarization":
        histogram.InstrumentParameters["Polariz."][1:] = [0.7, False]
        return
    if mode == "remove-Y":
        histogram.InstrumentParameters["Y"][1:] = [0.0, False]
        return
    if mode == "remove-shift":
        histogram.SampleParameters["Shift"][:] = [0.0, False]
        histogram.InstrumentParameters["Zero"][1:] = [0.0, False]
        return
    phase = project.phase(phase_name)
    if phase is None:
        raise ValueError(f"phase not found: {phase_name}")
    hap = phase.data["Histograms"][histogram.name]
    if mode == "remove-size":
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = False
    elif mode == "remove-texture":
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    else:
        raise ValueError(mode)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "mode",
        choices=(
            "leave-phase",
            "remove-polarization",
            "remove-Y",
            "remove-shift",
            "remove-size",
            "remove-texture",
        ),
    )
    parser.add_argument("--phase")
    args = parser.parse_args()
    source = G2sc.G2Project(str(args.source.resolve()))
    source_rwp = float(source.histograms()[0].get_wR())
    project = G2sc.G2Project(
        str(args.source.resolve()), newgpx=str(args.output.resolve())
    )
    project.set_Controls("cycles", 8)
    configure(project, args.mode, args.phase)
    project.save()
    valid = refine_stably(project)
    project.save()
    histogram = project.histograms()[0]
    print(
        "VALIDATION_BRANCH_RESULT="
        + json.dumps(
            {
                "source": str(args.source.resolve()),
                "output": str(args.output.resolve()),
                "mode": args.mode,
                "phase": args.phase,
                "valid": valid,
                "source_rwp_percent": source_rwp,
                "branch_rwp_percent": float(histogram.get_wR()),
                "rwp_change_percent": float(histogram.get_wR()) - source_rwp,
                "convergence": status(project),
            },
            default=str,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
