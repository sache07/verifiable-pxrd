#!/usr/bin/env python3
"""Inspect local residual support for the BaWO4 screening branch."""

from __future__ import annotations

import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def arrays(path):
    project = G2sc.G2Project(path)
    histogram = project.histograms()[0]
    values = [np.asarray(item, dtype=float) for item in histogram.data["data"][1][:6]]
    return project, histogram, values


def main():
    _, _, base = arrays("final.gpx")
    project, histogram, branch = arrays("screen-bawo4-final.gpx")
    x, observed, weight, base_calc = base[:4]
    branch_calc = branch[3]
    candidate = np.asarray(
        histogram.data["Reflection Lists"]["BaWO4_scheelite_test"]["RefList"],
        dtype=float,
    )
    candidate = candidate[np.argsort(candidate[:, 9])[::-1]]

    strong_existing = []
    for name in ("BaCO3_witherite", "WO3"):
        reflections = np.asarray(
            histogram.data["Reflection Lists"][name]["RefList"], dtype=float
        )
        threshold = 0.02 * float(np.max(reflections[:, 9]))
        strong_existing.extend(reflections[reflections[:, 9] >= threshold, 5])
    strong_existing = np.asarray(strong_existing)

    rows = []
    used_positions = []
    for reflection in candidate:
        position = float(reflection[5])
        if any(abs(position - old) < 0.12 for old in used_positions):
            continue
        used_positions.append(position)
        mask = np.abs(x - position) <= 0.18
        before = float(np.sum(weight[mask] * (observed[mask] - base_calc[mask]) ** 2))
        after = float(np.sum(weight[mask] * (observed[mask] - branch_calc[mask]) ** 2))
        delta_profile = branch_calc[mask] - base_calc[mask]
        rows.append(
            {
                "hkl": [int(value) for value in reflection[:3]],
                "two_theta_deg": position,
                "relative_structure_intensity": float(
                    reflection[9] / candidate[0, 9]
                ),
                "nearest_strong_existing_reflection_deg": float(
                    np.min(np.abs(strong_existing - position))
                ),
                "local_weighted_ssr_change": after - before,
                "maximum_added_calculated_counts": float(np.max(delta_profile)),
            }
        )
        if len(rows) >= 20:
            break
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
