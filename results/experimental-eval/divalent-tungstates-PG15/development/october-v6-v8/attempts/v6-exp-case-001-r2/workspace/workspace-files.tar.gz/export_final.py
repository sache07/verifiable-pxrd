#!/usr/bin/env python3
"""Create the required submission files from the selected GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from learned.profile_regeneration import regenerate_profile


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "p21c-angular-final.gpx"
FINAL = ROOT / "final.gpx"
CIF_NAMES = {
    "BaCO3_witherite": "BaCO3_witherite.cif",
    "WO3": "WO3_monoclinic.cif",
}
FORMULAE = {"BaCO3_witherite": "BaCO3", "WO3": "WO3"}
DISPLAY_NAMES = {
    "BaCO3_witherite": "Barium carbonate (witherite)",
    "WO3": "Tungsten trioxide (monoclinic)",
}
COD_IDS = {"BaCO3_witherite": "9010928", "WO3": "2311041"}


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    project.save()
    regenerate_profile(FINAL)
    project = G2sc.G2Project(str(FINAL))
    histogram = project.histograms()[0]
    fractions = histogram.ComputeMassFracs()

    phases = []
    for phase in project.phases():
        cif_name = CIF_NAMES[phase.name]
        phase.export_CIF(str(ROOT / cif_name))
        value, esd = fractions[phase.name]
        phases.append(
            {
                "name": DISPLAY_NAMES[phase.name],
                "formula": FORMULAE[phase.name],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cell": {key: float(number) for key, number in phase.get_cell().items()},
                "cif_path": cif_name,
                "weight_fraction": float(value),
                "weight_fraction_esd_formal": float(esd),
                "structure_source": {"database": "COD", "entry": COD_IDS[phase.name]},
            }
        )

    x, observed, weight, calculated, background, difference = (
        np.asarray(values, dtype=float) for values in histogram.data["data"][1][:6]
    )
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    lower, upper = map(float, histogram.data["Limits"][1])
    used = (x >= lower) & (x <= upper) & np.isfinite(weight) & (weight > 0)
    profile_rwp = 100.0 * np.sqrt(
        np.sum(weight[used] * difference[used] ** 2)
        / np.sum(weight[used] * observed[used] ** 2)
    )
    rvalues = project.data["Covariance"]["data"]["Rvals"]
    histogram_stats = histogram.data["data"][0]
    result = {
        "phases": phases,
        "fraction_basis": "Normalized over the modeled crystalline phases; amorphous material, if present, is not quantified.",
        "fit_statistics": {
            "Rwp_percent": float(rvalues["Rwp"]),
            "Rp_percent": float(histogram_stats["R"]),
            "GOF": float(rvalues["GOF"]),
            "reduced_chi_squared": float(rvalues["GOF"]) ** 2,
            "weighted_residual_sum_squares": float(rvalues["chisq"]),
            "Durbin_Watson": float(histogram_stats["Durbin-Watson"]),
            "observations": int(rvalues["Nobs"]),
            "refined_variables": int(rvalues["Nvars"]),
            "maximum_shift_over_esd": float(rvalues["Max shft/sig"]),
            "Rwp_percent_recomputed_from_exported_profile": float(profile_rwp),
            "refined_two_theta_range_deg": [lower, upper],
        },
        "unresolved_components": [],
        "model_selection_note": (
            "A triclinic P-1 WO3 model was a near-tied alternative "
            "(Rwp 6.9891% versus 6.9804% for the selected monoclinic model)."
        ),
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
