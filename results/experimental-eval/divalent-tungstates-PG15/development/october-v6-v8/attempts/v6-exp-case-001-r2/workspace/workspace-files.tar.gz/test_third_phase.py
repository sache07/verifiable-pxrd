#!/usr/bin/env python3
"""Matched mature-baseline test for the audited scheelite BaWO4 candidate."""

from __future__ import annotations

import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "final.gpx"
OUTPUT = ROOT / "screen-bawo4-final.gpx"
CANDIDATE = ROOT / "candidate_BaWO4_scheelite.cif"


def state(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine_stably(project, attempts=8):
    for _ in range(attempts):
        project.refine()
        current = state(project)
        message = str(current.get("msg") or "").lower()
        if current.get("Aborted") or current.get("SVD0", 0) or "dropped" in message:
            return False
        if current.get("converged") and abs(
            float(current.get("Max shft/sig") or math.inf)
        ) < 0.05:
            return True
    return False


def freeze_all(project):
    histogram = project.histograms()[0]
    histogram.Background[0][1] = False
    for parameter in histogram.InstrumentParameters.values():
        if isinstance(parameter, list) and len(parameter) >= 3:
            parameter[2] = False
    for parameter in histogram.SampleParameters.values():
        if isinstance(parameter, list) and len(parameter) == 2:
            parameter[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.data["Atoms"]:
            atom[2] = ""
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        for key in ("Size", "Mustrain"):
            hap[key][2] = [False] * len(hap[key][2])


def restore_baseline_flags(project, template):
    histogram = project.histograms()[0]
    source_histogram = template.histograms()[0]
    histogram.Background[0][1] = source_histogram.Background[0][1]
    for key, source in source_histogram.InstrumentParameters.items():
        if isinstance(source, list) and len(source) >= 3:
            histogram.InstrumentParameters[key][2] = source[2]
    for key, source in source_histogram.SampleParameters.items():
        if isinstance(source, list) and len(source) == 2:
            histogram.SampleParameters[key][1] = source[1]
    for phase, source_phase in zip(project.phases()[:2], template.phases()):
        phase.data["General"]["Cell"][0] = source_phase.data["General"]["Cell"][0]
        hap = phase.data["Histograms"][histogram.name]
        source_hap = source_phase.data["Histograms"][source_histogram.name]
        hap["Scale"][1] = source_hap["Scale"][1]
        hap["Pref.Ori."][2] = source_hap["Pref.Ori."][2]
        for key in ("Size", "Mustrain"):
            hap[key][2] = list(source_hap[key][2])


def scale_and_esd(project, phase):
    histogram = project.histograms()[0]
    value = float(phase.data["Histograms"][histogram.name]["Scale"][0])
    covariance = project.data.get("Covariance", {}).get("data", {})
    histogram_id = histogram.data["data"][0]["hId"]
    name = f"{phase.data['pId']}:{histogram_id}:Scale"
    lookup = dict(zip(covariance.get("varyList", []), covariance.get("sig", [])))
    return value, float(lookup.get(name, math.nan))


def main():
    template = G2sc.G2Project(str(SOURCE))
    baseline_rwp = float(template.histograms()[0].get_wR())
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    histogram = project.histograms()[0]
    candidate = project.add_phase(
        str(CANDIDATE),
        phasename="BaWO4_scheelite_test",
        histograms=[histogram],
        fmthint="CIF",
    )
    freeze_all(project)
    candidate.data["Histograms"][histogram.name]["Scale"][:] = [0.1, True]
    project.set_Controls("cycles", 8)
    project.save()
    scale_only_valid = refine_stably(project)
    scale_only = scale_and_esd(project, candidate)

    complete_valid = False
    if scale_only_valid and scale_only[0] > 0.0:
        restore_baseline_flags(project, template)
        complete_valid = refine_stably(project)
    project.save()
    complete_scale = scale_and_esd(project, candidate)
    print(
        "THIRD_PHASE_RESULT="
        + json.dumps(
            {
                "baseline_rwp_percent": baseline_rwp,
                "branch_rwp_percent": float(histogram.get_wR()),
                "rwp_change_percent": float(histogram.get_wR()) - baseline_rwp,
                "scale_only_valid": scale_only_valid,
                "scale_only_scale_esd": scale_only,
                "complete_valid": complete_valid,
                "complete_scale_esd": complete_scale,
                "mass_fractions": histogram.ComputeMassFracs(),
                "convergence": state(project),
            },
            default=str,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
