#!/usr/bin/env python3
"""Create a matched GSAS-II refinement branch for profile/model testing."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, attempts: int = 8) -> bool:
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as error:
            print("REFINEMENT_ERROR=" + repr(error))
            return False
        state = covariance_status(project)
        message = str(state.get("msg") or "").lower()
        if state.get("Aborted") or state.get("SVD0", 0) or "dropped" in message:
            return False
        if state.get("converged") and float(state.get("Max shft/sig") or math.inf) < 0.05:
            return True
    return False


def configure(project: G2sc.G2Project, mode: str, phase_name: str | None) -> None:
    histogram = project.histograms()[0]
    if mode.startswith("instrument-"):
        parameter = mode.removeprefix("instrument-")
        if parameter not in histogram.InstrumentParameters:
            raise ValueError(f"unknown instrument parameter {parameter}")
        histogram.InstrumentParameters[parameter][2] = True
        return
    if mode == "polarization":
        histogram.InstrumentParameters["Polariz."][2] = True
        return
    if mode == "roughness":
        histogram.SampleParameters["SurfRoughA"][:] = [0.5, True]
        histogram.SampleParameters["SurfRoughB"][:] = [0.01, True]
        return
    if phase_name is None:
        raise ValueError(f"{mode} requires --phase")
    phase = project.phase(phase_name)
    if phase is None:
        raise ValueError(f"phase not found: {phase_name}")
    hap = phase.data["Histograms"][histogram.name]
    if mode == "size":
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 1.0, "refine": True}},
            [histogram],
        )
    elif mode == "mustrain":
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}},
            [histogram],
        )
    elif mode == "texture":
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
    else:
        raise ValueError(mode)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "mode",
        help="instrument-U, instrument-V, instrument-Y, polarization, roughness, size, mustrain or texture",
    )
    parser.add_argument("--phase")
    parser.add_argument("--axis", nargs=3, type=int)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    project.set_Controls("cycles", 8)
    configure(project, args.mode, args.phase)
    if args.mode == "texture" and args.axis:
        histogram = project.histograms()[0]
        project.phase(args.phase).data["Histograms"][histogram.name]["Pref.Ori."][3] = list(args.axis)
    project.save()
    valid = stable_refine(project)
    project.save()

    histogram = project.histograms()[0]
    summary = {
        "source": str(args.source.resolve()),
        "output": str(args.output.resolve()),
        "mode": args.mode,
        "phase": args.phase,
        "axis": args.axis,
        "valid": valid,
        "rwp_percent": histogram.get_wR(),
        "convergence": covariance_status(project),
        "instrument": histogram.InstrumentParameters,
        "sample": histogram.SampleParameters,
        "mass_fractions": histogram.ComputeMassFracs(),
        "hap": {
            phase.name: {
                key: phase.data["Histograms"][histogram.name].get(key)
                for key in ("Size", "Mustrain", "Pref.Ori.")
            }
            for phase in project.phases()
        },
    }
    print("BRANCH_RESULT=" + json.dumps(summary, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
