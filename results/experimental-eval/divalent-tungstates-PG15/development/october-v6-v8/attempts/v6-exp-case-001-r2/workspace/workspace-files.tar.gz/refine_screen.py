#!/usr/bin/env python3
"""Build matched two-phase GSAS-II screening refinements."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "instrument.instprm"
BACARBONATE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/9/01/09/9010928.cif"
)


def status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine_to_stability(project: G2sc.G2Project, label: str, attempts: int = 12) -> None:
    for attempt in range(1, attempts + 1):
        project.refine()
        state = status(project)
        print(
            json.dumps(
                {
                    "stage": label,
                    "attempt": attempt,
                    "rwp_percent": project.histograms()[0].get_wR(),
                    "converged": state.get("converged"),
                    "max_shift_over_esd": state.get("Max shft/sig"),
                    "svd": state.get("SVD0"),
                    "message": state.get("msg"),
                },
                default=str,
            )
        )
        message = str(state.get("msg") or "").lower()
        if state.get("Aborted") or state.get("SVD0", 0) or "dropped" in message:
            raise RuntimeError(f"unstable refinement in {label}: {state}")
        shift = float(state.get("Max shft/sig") or math.inf)
        if state.get("converged") and shift < 0.05:
            return
    raise RuntimeError(f"refinement did not stabilize in {label}: {status(project)}")


def initial_background(histogram) -> None:
    frame = np.genfromtxt(PATTERN, delimiter=",", names=True)
    x = np.asarray(frame[frame.dtype.names[0]], dtype=float)
    y = np.asarray(frame[frame.dtype.names[1]], dtype=float)
    step = float(np.median(np.diff(x)))
    window = max(31, int(round(2.0 / step)) | 1)
    lower_envelope = percentile_filter(y, percentile=12, size=window, mode="nearest")
    transformed = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    coefficients = np.polynomial.chebyshev.chebfit(transformed, lower_envelope, 9)
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": len(coefficients),
                "coeffs": coefficients.tolist(),
            }
        }
    )


def set_reasonable_uiso(phase) -> None:
    for atom in phase.atoms():
        if atom.adp_flag == "I" and atom.uiso <= 0.0:
            atom.uiso = 0.005 if atom.element in {"Ba", "W"} else 0.010


def build(wo3_cif: Path, output: Path) -> G2sc.G2Project:
    project = G2sc.G2Project(newgpx=str(output))
    project.set_Controls("cycles", 8)
    histogram = project.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma"
    )
    histogram.Limits("lower", 10.0)
    histogram.Limits("upper", 100.0)
    # The histogram scale is redundant with freely refined phase scales.
    histogram.SampleParameters["Scale"][:] = [1.0, False]
    initial_background(histogram)

    carbonate = project.add_phase(
        str(BACARBONATE),
        phasename="BaCO3_witherite",
        histograms=[histogram],
        fmthint="CIF",
    )
    oxide = project.add_phase(
        str(wo3_cif),
        phasename="WO3",
        histograms=[histogram],
        fmthint="CIF",
    )
    for phase in (carbonate, oxide):
        set_reasonable_uiso(phase)
        phase.set_HAP_refinements({"Scale": True})

    project.save(str(output))
    refine_to_stability(project, "background_scales")
    project.save(str(output.with_name(output.stem + "-stable-scales.gpx")))
    project.save(str(output))

    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_to_stability(project, "zero")
    project.save(str(output.with_name(output.stem + "-stable-zero.gpx")))
    project.save(str(output))

    histogram.InstrumentParameters["Zero"][2] = False
    histogram.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine_to_stability(project, "minimal_profile")
    project.save(str(output.with_name(output.stem + "-stable-profile.gpx")))
    project.save(str(output))

    carbonate.set_refinements({"Cell": True})
    oxide.set_refinements({"Cell": True})
    refine_to_stability(project, "cells")
    project.save(str(output.with_name(output.stem + "-stable-cells.gpx")))
    project.save(str(output))

    refine_to_stability(project, "full_reconvergence")
    project.save(str(output))
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_cif", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    project = build(args.wo3_cif.resolve(), args.output.resolve())
    histogram = project.histograms()[0]
    summary = {
        "project": str(args.output.resolve()),
        "rwp_percent": histogram.get_wR(),
        "residuals": histogram.residuals,
        "mass_fractions": histogram.ComputeMassFracs(),
        "instrument": histogram.InstrumentParameters,
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "convergence": status(project),
    }
    print("SCREEN_RESULT=" + json.dumps(summary, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
