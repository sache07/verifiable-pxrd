#!/usr/bin/env python3
"""Add one phase and test only its scale from a stable project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("destination", type=Path)
parser.add_argument("cif", type=Path)
parser.add_argument("phase")
parser.add_argument("--scale", type=float, default=0.2)
parser.add_argument("--calls", type=int, default=12)
args = parser.parse_args()
G2sc.SetPrintLevel("none")
project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.destination.resolve()))
histogram = project.histograms()[0]
phase = project.add_phase(
    str(args.cif.resolve()),
    phasename=args.phase,
    histograms=[histogram],
    fmthint="CIF",
)
phase.HAPvalue("Scale", newValue=args.scale)
phase.set_HAP_refinements({"Scale": True})
phase.set_refinements({"Cell": False})
project.save()
history = []
for call in range(1, args.calls + 1):
    project.refine(makeBack=False)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {
        "call": call,
        "rwp": float(project.histograms()[0].get_wR()),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig") or 999.0),
        "converged": bool(rvals.get("converged")),
        "svd_zero": int(rvals.get("SVD0") or 0),
        "message": rvals.get("msg"),
    }
    history.append(row)
    if row["converged"] and row["max_shift_over_sigma"] < 0.1:
        break
project.save()
print(
    json.dumps(
        {
            "phase": args.phase,
            "history": history,
            "fractions": {
                key: [float(value), float(esd)]
                for key, (value, esd) in histogram.ComputeMassFracs().items()
                if value > 0
            },
        },
        sort_keys=True,
    )
)
