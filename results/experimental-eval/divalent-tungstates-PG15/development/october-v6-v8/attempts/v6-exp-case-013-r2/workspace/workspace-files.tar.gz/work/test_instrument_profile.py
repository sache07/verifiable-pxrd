#!/usr/bin/env python3
"""Run a matched global powder-profile branch from a stable project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("destination", type=Path)
parser.add_argument("terms", help="comma-separated subset of U,V,W,X,Y,Z")
parser.add_argument("--calls", type=int, default=12)
args = parser.parse_args()
terms = {item.strip() for item in args.terms.split(",") if item.strip()}
if not terms <= {"U", "V", "W", "X", "Y", "Z"}:
    raise SystemExit("unsupported profile term")

G2sc.SetPrintLevel("none")
project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.destination.resolve()))
histogram = project.histograms()[0]
instrument = histogram.data["Instrument Parameters"][0]
defaults = {"U": 2.0, "V": -2.0, "W": 5.0, "X": 0.5, "Y": 0.5, "Z": 0.0}
for key, value in defaults.items():
    instrument[key][1] = value
    instrument[key][2] = key in terms
project.save()

history = []
for call in range(1, args.calls + 1):
    project.refine(makeBack=False)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {
        "call": call,
        "rwp": float(project.histograms()[0].get_wR()),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig") or 999.0),
        "converged": bool(rvals.get("converged")),
        "svd_zero": int(rvals.get("SVD0") or 0),
        "message": rvals.get("msg"),
    }
    history.append(row)
    if row["converged"] and row["max_shift_over_sigma"] < 0.1:
        break
project.save()
print(
    json.dumps(
        {
            "terms": sorted(terms),
            "history": history,
            "parameters": {key: instrument[key] for key in defaults},
        },
        sort_keys=True,
    )
)
