#!/usr/bin/env python3
"""Export CIFs and the combined profile from final.gpx."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parents[1]
project = G2sc.G2Project(str(root / "final.gpx"))
histogram = project.histograms()[0]

filenames = {
    "scheelite_PbWO4": "phase_01_scheelite_PbWO4.cif",
    "massicot_PbO": "phase_02_massicot_PbO.cif",
    "litharge_PbO_corrected": "phase_03_litharge_PbO.cif",
    "fluorite_Pb2WO5": "phase_04_fluorite_type_Pb2WO5.cif",
    "Pb3O4": "phase_05_minium_Pb3O4.cif",
    "monoclinic_WO3_final": "phase_06_monoclinic_WO3.cif",
    "W3O8_mature": "phase_07_W3O8.cif",
}
if set(filenames) != {phase.name for phase in project.phases()}:
    raise SystemExit("final project phase inventory differs from export map")

for phase in project.phases():
    phase.export_CIF(str(root / filenames[phase.name]))

x, observed, weights, calculated, background, difference = [
    np.asarray(values, dtype=float) for values in histogram.data["data"][1][:6]
]
profile = np.column_stack((x, observed, calculated, difference, background))
np.savetxt(
    root / "fit.csv",
    profile,
    delimiter=",",
    header="two_theta_deg,observed_counts,calculated_counts,difference_counts,background_counts",
    comments="",
    fmt="%.8g",
)

valid = np.isfinite(profile).all(axis=1) & np.isfinite(weights) & (weights > 0.0)
rp = 100.0 * np.sum(np.abs(difference[valid])) / np.sum(np.abs(observed[valid]))
rvals = project.data["Covariance"]["data"]["Rvals"]
fractions = histogram.ComputeMassFracs()
print(json.dumps({
    "rwp_percent": float(rvals["Rwp"]),
    "rp_percent": float(rp),
    "rexp_percent": float(rvals["Rwp"] / rvals["GOF"]),
    "goodness_of_fit": float(rvals["GOF"]),
    "chi_square": float(rvals["chisq"]),
    "n_observations": int(rvals["Nobs"]),
    "n_variables": int(rvals["Nvars"]),
    "max_shift_over_esd": float(rvals["Max shft/sig"]),
    "fractions": {
        name: {"value": float(value), "esd": float(esd)}
        for name, (value, esd) in fractions.items()
    },
    "files": filenames,
}, indent=2, sort_keys=True))
