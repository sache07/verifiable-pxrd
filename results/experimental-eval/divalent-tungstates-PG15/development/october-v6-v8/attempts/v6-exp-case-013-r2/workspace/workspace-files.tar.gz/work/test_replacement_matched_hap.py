#!/usr/bin/env python3
"""Replace a same-symmetry phase while copying its matched HAP nuisance model."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("destination", type=Path)
parser.add_argument("old_phase")
parser.add_argument("cif", type=Path)
parser.add_argument("new_phase")
parser.add_argument("--calls", type=int, default=12)
args = parser.parse_args()

G2sc.SetPrintLevel("none")
project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.destination.resolve()))
histogram = project.histograms()[0]
old = project.phase(args.old_phase)
old_hap = old.data["Histograms"][histogram.name]
old_cell = copy.deepcopy(old.data["General"]["Cell"])
old_scale = float(old_hap["Scale"][0])
old.HAPvalue("Scale", newValue=0.0)
old.set_HAP_refinements({"Scale": False})
old_hap["Use"] = False

new = project.add_phase(str(args.cif.resolve()), phasename=args.new_phase,
                        histograms=[histogram], fmthint="CIF")
new_hap = new.data["Histograms"][histogram.name]
for key in ("Size", "Mustrain", "Pref.Ori.", "HStrain", "Extinction", "Babinet"):
    if key in old_hap and key in new_hap:
        new_hap[key] = copy.deepcopy(old_hap[key])
new.data["General"]["Cell"] = old_cell
new.HAPvalue("Scale", newValue=old_scale)
new.set_HAP_refinements({"Scale": True})
new.set_refinements({"Cell": True})
project.save()

history = []
for call in range(1, args.calls + 1):
    project.refine(makeBack=False)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {
        "call": call,
        "rwp": float(histogram.get_wR()),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig") or 999.0),
        "converged": bool(rvals.get("converged")),
        "svd_zero": int(rvals.get("SVD0") or 0),
        "message": rvals.get("msg"),
    }
    history.append(row)
    if row["converged"] and row["max_shift_over_sigma"] < 0.1:
        break
project.save()
print(json.dumps({
    "old_phase": args.old_phase,
    "new_phase": args.new_phase,
    "history": history,
    "cell": new.get_cell(),
    "mustrain": new_hap["Mustrain"],
    "fractions": {name: [float(value), float(esd)]
                  for name, (value, esd) in histogram.ComputeMassFracs().items()
                  if value > 0.0},
}, sort_keys=True))
