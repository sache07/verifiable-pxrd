#!/usr/bin/env python3
from pathlib import Path

import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parents[1]
project = G2sc.G2Project(gpxfile=str(root / "work/test-indexed-PbO2.gpx"))
phase = next(p for p in project.phases() if p.name == "indexed_tetragonal_PbO2")
phase.export_CIF(str(root / "work/indexed_tetragonal_PbO2_refined.cif"))
