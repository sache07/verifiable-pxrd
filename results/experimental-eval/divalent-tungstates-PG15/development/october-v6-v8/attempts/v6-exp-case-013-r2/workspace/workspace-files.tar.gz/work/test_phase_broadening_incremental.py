#!/usr/bin/env python3
"""Add one phase broadening term while preserving already accepted terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("destination", type=Path)
parser.add_argument("phase")
parser.add_argument("mode", choices=("size", "strain"))
parser.add_argument("--calls", type=int, default=12)
args = parser.parse_args()

G2sc.SetPrintLevel("none")
project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.destination.resolve()))
histogram = project.histograms()[0]
target = project.phase(args.phase)
hap = target.data["Histograms"][histogram.name]
if args.mode == "size":
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2][0] = True
else:
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2][0] = True
project.save()

history = []
for call in range(1, args.calls + 1):
    project.refine(makeBack=False)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {
        "call": call,
        "rwp": float(histogram.get_wR()),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig") or 999.0),
        "converged": bool(rvals.get("converged")),
        "svd_zero": int(rvals.get("SVD0") or 0),
        "message": rvals.get("msg"),
    }
    history.append(row)
    if row["converged"] and row["max_shift_over_sigma"] < 0.1:
        break
project.save()
retained = {}
for phase in project.phases():
    if histogram.name not in phase.data.get("Histograms", {}):
        continue
    phase_hap = phase.data["Histograms"][histogram.name]
    if phase_hap["Size"][2][0] or phase_hap["Mustrain"][2][0]:
        retained[phase.name] = {
            "size": phase_hap["Size"],
            "mustrain": phase_hap["Mustrain"],
        }
print(json.dumps({"phase": args.phase, "mode": args.mode, "history": history,
                  "retained": retained}, sort_keys=True))
