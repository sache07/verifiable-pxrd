#!/usr/bin/env python3
"""Concise weighted residual comparison by ten-degree region."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def summarize(path: Path) -> dict:
    project = G2sc.G2Project(str(path.resolve()))
    histogram = project.histograms()[0]
    x, y, w, yc = (np.asarray(v, dtype=float) for v in histogram.data["data"][1][:4])
    lo, hi = histogram.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & np.isfinite(w) & (w > 0.0)
    regions = {}
    for lower in np.arange(10.0, 100.0, 10.0):
        mask = use & (x >= lower) & (x < lower + 10.0)
        regions[f"{lower:.0f}-{lower + 10.0:.0f}"] = float(
            np.sum(w[mask] * (y[mask] - yc[mask]) ** 2)
        )
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "path": str(path),
        "rwp": float(histogram.get_wR()),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig") or 999.0),
        "message": rvals.get("msg"),
        "regions": regions,
    }


baseline = summarize(Path(sys.argv[1]))
for item in sys.argv[2:]:
    branch = summarize(Path(item))
    branch["delta_weighted_sse_vs_baseline"] = {
        key: branch["regions"][key] - baseline["regions"][key]
        for key in baseline["regions"]
    }
    print(json.dumps({"baseline_rwp": baseline["rwp"], "branch": branch}, sort_keys=True))
