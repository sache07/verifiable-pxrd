#!/usr/bin/env python3
"""Add one candidate to a stable GSAS-II project and refine in two stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def stable_refine(project: G2sc.G2Project, maximum_calls: int = 10) -> dict:
    last = {}
    for call in range(1, maximum_calls + 1):
        project.refine(makeBack=False)
        last = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        shift = float(last.get("Max shft/sig") or 999.0)
        if last.get("converged") and shift < 0.1:
            break
    return {
        "calls": call,
        "max_shift_over_sigma": float(last.get("Max shft/sig") or 999.0),
        "converged": bool(last.get("converged")),
        "svd_zero": int(last.get("SVD0") or 0),
        "message": last.get("msg"),
        "rwp_percent": float(project.histograms()[0].get_wR()),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("phase_name")
    parser.add_argument("--scale", type=float, default=0.2)
    args = parser.parse_args()

    G2sc.SetPrintLevel("none")
    source = args.source.resolve()
    destination = args.destination.resolve()
    scale_checkpoint = destination.with_name(destination.stem + "-scale.gpx")

    project = G2sc.G2Project(str(source), newgpx=str(destination))
    histogram = project.histograms()[0]
    phase = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.phase_name,
        histograms=[histogram],
        fmthint="CIF",
    )
    phase.HAPvalue("Scale", newValue=args.scale)
    phase.set_HAP_refinements({"Scale": True})
    phase.set_refinements({"Cell": False})
    project.save()
    scale_stage = stable_refine(project)
    project.save(str(scale_checkpoint))

    project = G2sc.G2Project(str(scale_checkpoint), newgpx=str(destination))
    phase = project.phase(args.phase_name)
    phase.set_refinements({"Cell": True})
    project.save()
    cell_stage = stable_refine(project)
    project.save()

    histogram = project.histograms()[0]
    try:
        fractions = {
            key: {"value": float(value), "esd": float(esd)}
            for key, (value, esd) in histogram.ComputeMassFracs().items()
        }
    except Exception as error:
        fractions = {"error": str(error)}
    summary = {
        "source": str(source),
        "destination": str(destination),
        "candidate": args.phase_name,
        "scale_stage": scale_stage,
        "cell_stage": cell_stage,
        "fractions": fractions,
        "phases": [
            {
                "name": item.name,
                "scale": float(item.HAPvalue("Scale")),
                "cell": item.get_cell(),
            }
            for item in project.phases()
        ],
    }
    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
