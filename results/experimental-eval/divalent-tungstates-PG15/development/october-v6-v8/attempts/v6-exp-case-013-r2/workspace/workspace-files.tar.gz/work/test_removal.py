#!/usr/bin/env python3
"""Matched removal test for an active phase or retained nuisance term."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("destination", type=Path)
parser.add_argument(
    "kind",
    choices=("phase", "rough-b", "profile-W", "profile-X", "strain", "size", "texture"),
)
parser.add_argument("target", nargs="?", default="")
parser.add_argument("--calls", type=int, default=12)
args = parser.parse_args()

G2sc.SetPrintLevel("none")
project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.destination.resolve()))
histogram = project.histograms()[0]

if args.kind == "phase":
    phase = project.phase(args.target)
    phase.HAPvalue("Scale", newValue=0.0)
    phase.set_HAP_refinements({"Scale": False})
    phase.data["Histograms"][histogram.name]["Use"] = False
elif args.kind == "rough-b":
    histogram.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
elif args.kind.startswith("profile-"):
    term = args.kind.split("-", 1)[1]
    histogram.data["Instrument Parameters"][0][term][1] = 0.0
    histogram.data["Instrument Parameters"][0][term][2] = False
elif args.kind in {"strain", "size", "texture"}:
    phase = project.phase(args.target)
    hap = phase.data["Histograms"][histogram.name]
    if args.kind == "strain":
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = False
    elif args.kind == "size":
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = False
    else:
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

project.save()
history = []
for call in range(1, args.calls + 1):
    project.refine(makeBack=False)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {
        "call": call,
        "rwp": float(histogram.get_wR()),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig") or 999.0),
        "converged": bool(rvals.get("converged")),
        "svd_zero": int(rvals.get("SVD0") or 0),
        "message": rvals.get("msg"),
    }
    history.append(row)
    if row["converged"] and row["max_shift_over_sigma"] < 0.1:
        break
project.save()
print(json.dumps({"kind": args.kind, "target": args.target, "history": history}, sort_keys=True))
