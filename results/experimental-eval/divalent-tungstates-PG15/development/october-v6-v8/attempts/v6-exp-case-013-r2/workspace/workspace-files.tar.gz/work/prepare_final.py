#!/usr/bin/env python3
"""Remove inactive screening phases and reconverge a replay-safe final GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("destination", type=Path)
parser.add_argument("--remove", action="append", default=[])
parser.add_argument("--calls", type=int, default=12)
args = parser.parse_args()

G2sc.SetPrintLevel("none")
project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.destination.resolve()))

for phase_name in args.remove:
    phase = project.phase(phase_name)
    if phase is None:
        raise SystemExit(f"phase not found: {phase_name}")
    active = any(hap.get("Use", True) and hap.get("Scale", [0.0])[0] != 0.0
                 for hap in phase.data.get("Histograms", {}).values())
    if active:
        raise SystemExit(f"refusing to remove active phase: {phase_name}")
    project.data["Phases"].pop(phase_name)
    for item in project.names:
        if item and item[0] == "Phases" and phase_name in item:
            item.remove(phase_name)
    for histogram in project.histograms():
        histogram.data.get("Reflection Lists", {}).pop(phase_name, None)

project.update_ids()
project.save()

history = []
for call in range(1, args.calls + 1):
    project.refine(makeBack=False)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {
        "call": call,
        "rwp": float(project.histograms()[0].get_wR()),
        "rp": float(rvals.get("R") or rvals.get("Rp") or 0.0),
        "gof": float(rvals.get("GOF") or 0.0),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig") or 999.0),
        "converged": bool(rvals.get("converged")),
        "svd_zero": int(rvals.get("SVD0") or 0),
        "message": rvals.get("msg"),
    }
    history.append(row)
    if row["converged"] and row["max_shift_over_sigma"] < 0.1:
        break

project.save()
histogram = project.histograms()[0]
fractions = {
    key: {"value": float(value), "esd": float(esd)}
    for key, (value, esd) in histogram.ComputeMassFracs().items()
    if value > 0.0
}
print(json.dumps({
    "history": history,
    "phases": [phase.name for phase in project.phases()],
    "fractions": fractions,
}, sort_keys=True))
