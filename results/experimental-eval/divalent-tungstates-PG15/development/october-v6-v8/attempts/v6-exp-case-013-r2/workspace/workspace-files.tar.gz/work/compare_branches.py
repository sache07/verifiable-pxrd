#!/usr/bin/env python3
"""Summarize complete-pattern residuals and candidate reflection support."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def summarize(path: Path) -> dict:
    project = G2sc.G2Project(str(path))
    histogram = project.histograms()[0]
    x, y, w, yc, yb, yd = (np.asarray(v, dtype=float) for v in histogram.data["data"][1][:6])
    limits = histogram.data["Limits"][1]
    use = (x >= limits[0]) & (x <= limits[1]) & np.isfinite(w) & (w > 0)
    denominator = np.sum(w[use] * y[use] ** 2)
    regions = []
    for lower in np.arange(10.0, 100.0, 10.0):
        mask = use & (x >= lower) & (x < lower + 10.0)
        regions.append(
            {
                "range": [lower, lower + 10.0],
                "weighted_sse": float(np.sum(w[mask] * (y[mask] - yc[mask]) ** 2)),
                "rwp_contribution_squared": float(
                    np.sum(w[mask] * (y[mask] - yc[mask]) ** 2) / denominator * 10000.0
                ),
                "mean_residual": float(np.mean(y[mask] - yc[mask])),
            }
        )
    reflections = {}
    for phase in project.phases():
        if phase.name in {
            "scheelite_PbWO4",
            "massicot_PbO",
            "monoclinic_WO3",
            "triclinic_WO3",
            "litharge_PbO",
            "fluorite_Pb2WO5",
            "Pb3O4",
        }:
            continue
        block = histogram.data.get("Reflection Lists", {}).get(phase.name, {})
        rows = np.asarray(block.get("RefList", []), dtype=float)
        if not len(rows):
            continue
        # Columns 8 and 9 are the observed and calculated intensity-like entries.
        order = np.argsort(np.abs(rows[:, 9]))[::-1][:30] if rows.shape[1] > 9 else np.arange(min(30, len(rows)))
        compact = []
        for index in order:
            row = rows[index]
            compact.append(
                {
                    "hkl": [int(row[0]), int(row[1]), int(row[2])],
                    "multiplicity": int(row[3]),
                    "d_A": float(row[4]),
                    "position_deg": float(row[5]),
                    "Fobs2": float(row[8]) if rows.shape[1] > 8 else None,
                    "Fcalc2": float(row[9]) if rows.shape[1] > 9 else None,
                }
            )
        reflections[phase.name] = {
            "shape": list(rows.shape),
            "top": compact,
        }
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "path": str(path),
        "rwp": float(histogram.get_wR()),
        "rvals": {
            key: rvals.get(key)
            for key in ("Rwp", "GOF", "Max shft/sig", "SVD0", "converged", "msg")
        },
        "regions": regions,
        "reflections": reflections,
    }


for argument in sys.argv[1:]:
    print(json.dumps(summarize(Path(argument).resolve()), default=str))
