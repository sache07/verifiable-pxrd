#!/usr/bin/env python3
"""Replace one active phase with a candidate under matched GSAS-II settings."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def stable_refine(project: G2sc.G2Project, maximum_calls: int = 10) -> dict:
    last = {}
    for call in range(1, maximum_calls + 1):
        project.refine(makeBack=False)
        last = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        shift = float(last.get("Max shft/sig") or 999.0)
        if last.get("converged") and shift < 0.1:
            break
    return {
        "calls": call,
        "max_shift_over_sigma": float(last.get("Max shft/sig") or 999.0),
        "converged": bool(last.get("converged")),
        "svd_zero": int(last.get("SVD0") or 0),
        "message": last.get("msg"),
        "rwp_percent": float(project.histograms()[0].get_wR()),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("old_phase")
    parser.add_argument("cif", type=Path)
    parser.add_argument("new_phase")
    parser.add_argument("--scale", type=float, default=1.0)
    args = parser.parse_args()

    G2sc.SetPrintLevel("none")
    destination = args.destination.resolve()
    scale_checkpoint = destination.with_name(destination.stem + "-scale.gpx")
    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(destination))
    histogram = project.histograms()[0]
    old = project.phase(args.old_phase)
    old.HAPvalue("Scale", newValue=0.0)
    old.set_HAP_refinements({"Scale": False})
    old.data["Histograms"][histogram.name]["Use"] = False
    new = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.new_phase,
        histograms=[histogram],
        fmthint="CIF",
    )
    new.HAPvalue("Scale", newValue=args.scale)
    new.set_HAP_refinements({"Scale": True})
    new.set_refinements({"Cell": False})
    project.save()
    scale_stage = stable_refine(project)
    project.save(str(scale_checkpoint))

    project = G2sc.G2Project(str(scale_checkpoint), newgpx=str(destination))
    project.phase(args.new_phase).set_refinements({"Cell": True})
    project.save()
    cell_stage = stable_refine(project)
    project.save()
    histogram = project.histograms()[0]
    fractions = {
        key: {"value": float(value), "esd": float(esd)}
        for key, (value, esd) in histogram.ComputeMassFracs().items()
        if value > 0
    }
    print(
        json.dumps(
            {
                "old_phase": args.old_phase,
                "new_phase": args.new_phase,
                "scale_stage": scale_stage,
                "cell_stage": cell_stage,
                "fractions": fractions,
                "cell": project.phase(args.new_phase).get_cell(),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
