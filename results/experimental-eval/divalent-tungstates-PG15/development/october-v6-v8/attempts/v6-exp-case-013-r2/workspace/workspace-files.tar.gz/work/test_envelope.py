#!/usr/bin/env python3
"""Test one simple intensity-envelope correction from a stable project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("destination", type=Path)
parser.add_argument("mode", choices=("polarization", "rough-b", "rough-ab"))
parser.add_argument("--calls", type=int, default=12)
args = parser.parse_args()
G2sc.SetPrintLevel("none")
project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.destination.resolve()))
histogram = project.histograms()[0]
instrument = histogram.data["Instrument Parameters"][0]
sample = histogram.data["Sample Parameters"]
instrument["Polariz."][1:] = [0.7, args.mode == "polarization"]
sample["SurfRoughA"] = [0.5 if args.mode == "rough-ab" else 0.0, args.mode == "rough-ab"]
sample["SurfRoughB"] = [0.1 if args.mode.startswith("rough") else 0.0, args.mode.startswith("rough")]
project.save()
history = []
for call in range(1, args.calls + 1):
    project.refine(makeBack=False)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {
        "call": call,
        "rwp": float(project.histograms()[0].get_wR()),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig") or 999.0),
        "converged": bool(rvals.get("converged")),
        "svd_zero": int(rvals.get("SVD0") or 0),
        "message": rvals.get("msg"),
    }
    history.append(row)
    if row["converged"] and row["max_shift_over_sigma"] < 0.1:
        break
project.save()
print(
    json.dumps(
        {
            "mode": args.mode,
            "history": history,
            "polarization": instrument["Polariz."],
            "surface_roughness_a": sample["SurfRoughA"],
            "surface_roughness_b": sample["SurfRoughB"],
        },
        sort_keys=True,
    )
)
