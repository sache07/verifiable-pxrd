#!/usr/bin/env python3
"""Test one simple March-Dollase axis on one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("destination", type=Path)
parser.add_argument("phase")
parser.add_argument("h", type=int)
parser.add_argument("k", type=int)
parser.add_argument("l", type=int)
parser.add_argument("--calls", type=int, default=12)
args = parser.parse_args()
G2sc.SetPrintLevel("none")
project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.destination.resolve()))
histogram = project.histograms()[0]
for phase in project.phases():
    if histogram.name not in phase.data.get("Histograms", {}):
        continue
    po = phase.data["Histograms"][histogram.name]["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 1.0, False, [0, 0, 1]
target = project.phase(args.phase)
po = target.data["Histograms"][histogram.name]["Pref.Ori."]
po[2] = True
po[3] = [args.h, args.k, args.l]
project.save()
history = []
for call in range(1, args.calls + 1):
    project.refine(makeBack=False)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {
        "call": call,
        "rwp": float(project.histograms()[0].get_wR()),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig") or 999.0),
        "converged": bool(rvals.get("converged")),
        "svd_zero": int(rvals.get("SVD0") or 0),
        "message": rvals.get("msg"),
    }
    history.append(row)
    if row["converged"] and row["max_shift_over_sigma"] < 0.1:
        break
project.save()
print(json.dumps({"phase": args.phase, "axis": po[3], "ratio": po[1], "history": history}, sort_keys=True))
