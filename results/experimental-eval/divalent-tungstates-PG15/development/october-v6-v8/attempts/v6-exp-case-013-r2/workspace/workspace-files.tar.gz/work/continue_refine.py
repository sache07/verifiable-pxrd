#!/usr/bin/env python3
"""Continue a saved refinement to a strict shift/esd threshold."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("destination", type=Path)
parser.add_argument("--calls", type=int, default=20)
args = parser.parse_args()
G2sc.SetPrintLevel("none")
project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.destination.resolve()))
history = []
for call in range(1, args.calls + 1):
    project.refine(makeBack=False)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {
        "call": call,
        "rwp": float(project.histograms()[0].get_wR()),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig") or 999.0),
        "converged": bool(rvals.get("converged")),
        "svd_zero": int(rvals.get("SVD0") or 0),
        "message": rvals.get("msg"),
    }
    history.append(row)
    if row["converged"] and row["max_shift_over_sigma"] < 0.1:
        break
project.save()
histogram = project.histograms()[0]
print(
    json.dumps(
        {
            "history": history,
            "fractions": {
                key: [float(value), float(esd)]
                for key, (value, esd) in histogram.ComputeMassFracs().items()
                if value > 0
            },
            "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        },
        sort_keys=True,
    )
)
