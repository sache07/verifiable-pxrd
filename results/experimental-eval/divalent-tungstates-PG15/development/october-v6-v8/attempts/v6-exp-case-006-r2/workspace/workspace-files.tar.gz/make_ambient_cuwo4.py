#!/usr/bin/env python3
"""Prepare an ambient-cell P-1 CuWO4 screening model from COD 4000806.

The source provides a chemically complete, ordered P-1 topology measured
under pressure. Only the lattice is reset to a literature-scale ambient
wolframite cell; fractional coordinates are preserved for subsequent
full-pattern testing and refinement.
"""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/4/00/08/4000806.cif"
)
OUTPUT = Path("branches/candidates/CuWO4_ambient_P-1.cif")


source = Structure.from_file(SOURCE)
lattice = Lattice.from_parameters(
    4.7026, 5.8389, 4.8786, 91.677, 92.469, 82.805
)
candidate = Structure(
    lattice,
    source.species,
    source.frac_coords,
    site_properties=source.site_properties,
)
OUTPUT.parent.mkdir(parents=True, exist_ok=True)
CifWriter(candidate, symprec=0.01, refine_struct=False).write_file(OUTPUT)
print(OUTPUT.resolve())
