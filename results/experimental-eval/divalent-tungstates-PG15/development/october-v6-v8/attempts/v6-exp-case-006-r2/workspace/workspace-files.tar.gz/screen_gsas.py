#!/usr/bin/env python3
"""Build and minimally refine one or more atomistic GSAS-II phase models."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, cycles: int = 20) -> bool:
    for _ in range(cycles):
        try:
            project.refine(makeBack=False)
        except Exception as exc:
            print("REFINEMENT_ERROR", repr(exc))
            return False
        status = covariance_status(project)
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in message:
            return False
        if status.get("converged") and float(status.get("Max shft/sig") or 0.0) < 0.10:
            return True
    return False


def summary(project: G2sc.G2Project, stage: str, stable: bool) -> dict:
    histogram = project.histograms()[0]
    row = {
        "stage": stage,
        "stable": stable,
        "rwp_percent": histogram.get_wR(),
        "residuals": histogram.residuals,
        "instrument": {
            key: value for key, value in histogram.InstrumentParameters.items()
            if key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
        },
        "sample": {
            key: value for key, value in histogram.SampleParameters.items()
            if key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": [],
        "convergence": covariance_status(project),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        row["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "size": hap.get("Size"),
                "mustrain": hap.get("Mustrain"),
            }
        )
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("cifs", nargs="+", type=Path)
    parser.add_argument("--names", nargs="*")
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--coordinates", action="store_true")
    parser.add_argument("--initial-zero", type=float, default=0.0)
    args = parser.parse_args()

    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(output))
    histogram = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()),
        str(Path("instrument.instprm").resolve()),
        fmthint="comma",
    )
    names = args.names or [path.stem for path in args.cifs]
    if len(names) != len(args.cifs):
        raise ValueError("--names must match CIF count")
    phases = [
        project.add_phase(str(path.resolve()), phasename=name, histograms=[histogram])
        for path, name in zip(args.cifs, names)
    ]
    histogram.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [1200.0] + [0.0] * 9,
                "refine": True,
            },
        }
    )
    # A single powder histogram has an arbitrary overall scale. Keep the
    # histogram scale fixed and refine only phase scales to avoid an exact
    # scale/phase-scale singularity.
    if "Scale" in histogram.SampleParameters:
        histogram.SampleParameters["Scale"][1] = False
    # The measured peaks are about 0.15 degree FWHM. A deliberately realistic
    # starting width gives cell derivatives support before profile refinement.
    histogram.InstrumentParameters["W"][1] = 200.0
    histogram.InstrumentParameters["Zero"][1] = args.initial_zero
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [histogram])
    project.data["Controls"]["data"]["max cyc"] = 12
    project.save()

    records = []
    for stage, configure in (
        ("background_scales", lambda: None),
        ("cells", lambda: [phase.set_refinements({"Cell": True}) for phase in phases]),
        ("zero", lambda: histogram.set_refinements({"Instrument Parameters": ["Zero"]})),
    ):
        configure()
        stable = stable_refine(project)
        records.append(summary(project, stage, stable))
        project.save(output.with_name(output.stem + f"-{stage}.gpx"))
        if not stable:
            break

    if args.profile and records[-1]["stable"]:
        histogram.set_refinements({"Instrument Parameters": ["W", "X"]})
        stable = stable_refine(project)
        records.append(summary(project, "profile_WX", stable))
        project.save(output.with_name(output.stem + "-profile_WX.gpx"))

    if args.coordinates and records[-1]["stable"]:
        for phase in phases:
            phase.set_refinements({"Atoms": {"all": "X"}})
        stable = stable_refine(project)
        records.append(summary(project, "coordinates", stable))
        project.save(output.with_name(output.stem + "-coordinates.gpx"))

    project.save(output)
    print("SCREEN_RESULT=" + json.dumps(records, default=str))


if __name__ == "__main__":
    main()
