#!/usr/bin/env python3
"""Reproducible GSAS-II branching helpers for this Cu-W-O powder pattern."""

from __future__ import annotations

import argparse
import copy
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "instrument.instprm"


def covariance(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {})


def rvals(project: G2sc.G2Project) -> dict:
    return covariance(project).get("Rvals", {})


def stable_refine(
    project: G2sc.G2Project,
    max_calls: int = 12,
    shift_limit: float = 0.10,
) -> bool:
    previous = math.inf
    stagnant = 0
    for _ in range(max_calls):
        try:
            project.refine(makeBack=False)
        except Exception as exc:
            print("REFINEMENT_ERROR", repr(exc))
            return False
        status = rvals(project)
        message = str(status.get("msg", "") or "").lower()
        current = float(project.histograms()[0].get_wR())
        if (
            status.get("Aborted")
            or int(status.get("SVD0", 0) or 0) > 0
            or "dropped" in message
            or not math.isfinite(current)
        ):
            return False
        max_shift = float(status.get("Max shft/sig") or 0.0)
        if status.get("converged") and max_shift < shift_limit:
            return True
        if abs(previous - current) < 1.0e-5:
            stagnant += 1
        else:
            stagnant = 0
        # A persistent large shift/esd with no objective movement is not a
        # replay-safe convergence, so stop and let the caller reject it.
        if stagnant >= 3:
            return False
        previous = current
    return False


def freeze_all(project: G2sc.G2Project) -> None:
    histogram = project.histograms()[0]
    histogram.Background[0][1] = False
    for parameter in histogram.InstrumentParameters.values():
        if isinstance(parameter, list) and len(parameter) >= 3:
            parameter[2] = False
    for parameter in histogram.SampleParameters.values():
        if isinstance(parameter, list) and len(parameter) == 2:
            parameter[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.data["Atoms"]:
            atom[2] = ""
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = False
        if "Pref.Ori." in hap:
            hap["Pref.Ori."][2] = False
        for key in ("Size", "Mustrain"):
            if key in hap:
                hap[key][2] = [False] * len(hap[key][2])
                if len(hap[key]) > 5 and isinstance(hap[key][5], list):
                    hap[key][5] = [False] * len(hap[key][5])
        if "HStrain" in hap:
            hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        if "Extinction" in hap:
            hap["Extinction"][1] = False


def branch(source: Path, destination: Path) -> G2sc.G2Project:
    destination.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(source.resolve()), newgpx=str(destination.resolve()))
    project.save()
    return project


def state(project: G2sc.G2Project) -> dict:
    histogram = project.histograms()[0]
    cov = covariance(project)
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    maximum_correlation = None
    maximum_pair = None
    if matrix.shape == (len(names), len(names)) and len(names) > 1:
        sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
        denom = np.outer(sigma, sigma)
        with np.errstate(divide="ignore", invalid="ignore"):
            corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
        np.fill_diagonal(corr, 0.0)
        idx = np.unravel_index(np.argmax(np.abs(corr)), corr.shape)
        maximum_correlation = float(corr[idx])
        maximum_pair = [names[idx[0]], names[idx[1]]]
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases.append(
            {
                "name": phase.name,
                "composition": phase.composition,
                "cell": phase.get_cell(),
                "scale": copy.deepcopy(hap["Scale"]),
                "size": copy.deepcopy(hap.get("Size")),
                "mustrain": copy.deepcopy(hap.get("Mustrain")),
                "preferred_orientation": copy.deepcopy(hap.get("Pref.Ori.")),
            }
        )
    return {
        "project": project.filename,
        "rwp_percent": histogram.get_wR(),
        "residuals": histogram.residuals,
        "instrument": copy.deepcopy(histogram.InstrumentParameters),
        "sample": copy.deepcopy(histogram.SampleParameters),
        "background": copy.deepcopy(histogram.Background),
        "phases": phases,
        "convergence": copy.deepcopy(rvals(project)),
        "maximum_parameter_correlation": maximum_correlation,
        "maximum_correlation_pair": maximum_pair,
    }


def configure_common(project: G2sc.G2Project) -> None:
    histogram = project.histograms()[0]
    freeze_all(project)
    histogram.Background[0][1] = True
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        if hap.get("Use", True):
            phase.data["General"]["Cell"][0] = True
            hap["Scale"][1] = True


def build(args: argparse.Namespace) -> None:
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(output))
    histogram = project.add_powder_histogram(
        str(DATA), str(INSTRUMENT), fmthint="comma"
    )
    phase = project.add_phase(
        str(args.cif.resolve()), phasename=args.name, histograms=[histogram]
    )
    histogram.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": [1200.0] + [0.0] * (args.background_terms - 1),
                "refine": True,
            },
        }
    )
    histogram.SampleParameters["Scale"][1] = False
    histogram.SampleParameters["Shift"][:] = [args.shift, False]
    for key, value in (("Zero", args.zero), ("W", args.w), ("X", args.x)):
        histogram.InstrumentParameters[key][1] = value
        histogram.InstrumentParameters[key][2] = False
    phase.data["Histograms"][histogram.name]["Scale"][1] = True
    project.data["Controls"]["data"]["max cyc"] = 12
    project.save()
    stable = stable_refine(project)
    project.save()
    print("WORKFLOW_RESULT=" + json.dumps({"stable": stable, **state(project)}, default=str))


def refine_common(args: argparse.Namespace) -> None:
    project = branch(args.source, args.output)
    configure_common(project)
    if args.background_terms is not None:
        histogram = project.histograms()[0]
        histogram.set_refinements(
            {"Background": {"no. coeffs": args.background_terms, "refine": True}}
        )
    stable = stable_refine(project, max_calls=args.max_calls)
    project.save()
    print("WORKFLOW_RESULT=" + json.dumps({"stable": stable, **state(project)}, default=str))


def add_phase(args: argparse.Namespace) -> None:
    project = branch(args.source, args.output)
    histogram = project.histograms()[0]
    freeze_all(project)
    new_phase = project.add_phase(
        str(args.cif.resolve()), phasename=args.name, histograms=[histogram]
    )
    if args.neutralize_microstructure:
        new_hap = new_phase.data["Histograms"][histogram.name]
        new_hap["Size"][1][0] = 10.0
        new_hap["Mustrain"][1][0] = 0.0
    histogram.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][histogram.name]["Scale"][1] = True
    if args.refine_cells:
        new_phase.data["General"]["Cell"][0] = True
    project.save()
    stable = stable_refine(project, max_calls=args.max_calls)
    project.save()
    print("WORKFLOW_RESULT=" + json.dumps({"stable": stable, **state(project)}, default=str))


def replace_phase(args: argparse.Namespace) -> None:
    """Screen a replacement while retaining the old phase as an inactive record."""
    project = branch(args.source, args.output)
    histogram = project.histograms()[0]
    freeze_all(project)
    old_hap = project.phase(args.old).data["Histograms"][histogram.name]
    old_hap["Use"] = False
    old_hap["Scale"][:] = [0.0, False]
    new_phase = project.add_phase(
        str(args.cif.resolve()), phasename=args.name, histograms=[histogram]
    )
    if args.neutralize_microstructure:
        new_hap = new_phase.data["Histograms"][histogram.name]
        new_hap["Size"][1][0] = 10.0
        new_hap["Mustrain"][1][0] = 0.0
    histogram.Background[0][1] = True
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        if hap.get("Use", True):
            hap["Scale"][1] = True
    if args.refine_cells:
        new_phase.data["General"]["Cell"][0] = True
    project.save()
    stable = stable_refine(project, max_calls=args.max_calls)
    project.save()
    print("WORKFLOW_RESULT=" + json.dumps({"stable": stable, **state(project)}, default=str))


def set_profile(args: argparse.Namespace) -> None:
    project = branch(args.source, args.output)
    configure_common(project)
    histogram = project.histograms()[0]
    for key in ("U", "V", "W", "X", "Y", "Z", "Polariz.", "SH/L"):
        histogram.InstrumentParameters[key][2] = key in args.parameters
    stable = stable_refine(project, max_calls=args.max_calls)
    project.save()
    print("WORKFLOW_RESULT=" + json.dumps({"stable": stable, **state(project)}, default=str))


def set_microstructure(args: argparse.Namespace) -> None:
    project = branch(args.source, args.output)
    configure_common(project)
    histogram = project.histograms()[0]
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][histogram.name]
    if args.kind == "size":
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": args.start, "refine": True}},
            [histogram],
        )
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = args.start
        hap["Mustrain"][2][0] = True
    if args.retain_other:
        other = "Mustrain" if args.kind == "size" else "Size"
        hap[other][2][0] = True
    stable = stable_refine(project, max_calls=args.max_calls)
    project.save()
    print("WORKFLOW_RESULT=" + json.dumps({"stable": stable, **state(project)}, default=str))


def coordinates(args: argparse.Namespace) -> None:
    project = branch(args.source, args.output)
    configure_common(project)
    selected = project.phase(args.phase)
    atom_type_index = selected.data["General"]["AtomPtrs"][1]
    wanted = set(args.elements or [])
    for atom in selected.data["Atoms"]:
        if not wanted or atom[atom_type_index] in wanted:
            atom[2] = args.flags
    stable = stable_refine(project, max_calls=args.max_calls)
    project.save()
    print("WORKFLOW_RESULT=" + json.dumps({"stable": stable, **state(project)}, default=str))


def preferred_orientation(args: argparse.Namespace) -> None:
    project = branch(args.source, args.output)
    configure_common(project)
    histogram = project.histograms()[0]
    phase = project.phase(args.phase)
    po = phase.data["Histograms"][histogram.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = args.start
    po[2] = True
    po[3] = list(args.axis)
    stable = stable_refine(project, max_calls=args.max_calls)
    project.save()
    print("WORKFLOW_RESULT=" + json.dumps({"stable": stable, **state(project)}, default=str))


def surface_roughness(args: argparse.Namespace) -> None:
    project = branch(args.source, args.output)
    configure_common(project)
    sample = project.histograms()[0].SampleParameters
    sample["SurfRoughA"][:] = [args.a, True]
    sample["SurfRoughB"][:] = [args.b, args.refine_b]
    stable = stable_refine(project, max_calls=args.max_calls)
    project.save()
    print("WORKFLOW_RESULT=" + json.dumps({"stable": stable, **state(project)}, default=str))


def activate_model(args: argparse.Namespace) -> None:
    """Refine a selected mature model with all retained terms active together."""
    project = branch(args.source, args.output)
    freeze_all(project)
    histogram = project.histograms()[0]
    for assignment in args.reset_profile or []:
        key, raw_value = assignment.rsplit("=", 1)
        histogram.InstrumentParameters[key][1] = float(raw_value)
    for phase_name in args.disable_phases or []:
        hap = project.phase(phase_name).data["Histograms"][histogram.name]
        hap["Use"] = False
        hap["Scale"][:] = [0.0, False]
    if args.neutralize_texture:
        for phase in project.phases():
            po = phase.data["Histograms"][histogram.name].get("Pref.Ori.")
            if po and po[0] == "MD":
                po[1] = 1.0
    if args.neutralize_microstructure:
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 10.0
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
    histogram.Background[0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.data["Histograms"][histogram.name]["Scale"][1] = True
    for key in args.profile or []:
        histogram.InstrumentParameters[key][2] = True
    if args.surface:
        histogram.SampleParameters["SurfRoughA"][1] = True
        histogram.SampleParameters["SurfRoughB"][1] = True
    if args.coordinates:
        phase = project.phase(args.coordinates)
        atom_type_index = phase.data["General"]["AtomPtrs"][1]
        wanted = set(args.elements or [])
        for atom in phase.data["Atoms"]:
            if not wanted or atom[atom_type_index] in wanted:
                atom[2] = "X"
    for phase_name in args.size_phases or []:
        project.phase(phase_name).data["Histograms"][histogram.name]["Size"][2][0] = True
    for phase_name in args.strain_phases or []:
        project.phase(phase_name).data["Histograms"][histogram.name]["Mustrain"][2][0] = True
    if args.texture_phase:
        project.phase(args.texture_phase).data["Histograms"][histogram.name]["Pref.Ori."][2] = True
    stable = stable_refine(project, max_calls=args.max_calls)
    project.save()
    print("WORKFLOW_RESULT=" + json.dumps({"stable": stable, **state(project)}, default=str))


def show(args: argparse.Namespace) -> None:
    project = G2sc.G2Project(str(args.source.resolve()))
    print("WORKFLOW_RESULT=" + json.dumps(state(project), default=str))


def continue_existing(args: argparse.Namespace) -> None:
    project = branch(args.source, args.output)
    stable = stable_refine(project, max_calls=args.max_calls)
    project.save()
    print("WORKFLOW_RESULT=" + json.dumps({"stable": stable, **state(project)}, default=str))


def parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="command", required=True)

    p = sub.add_parser("build")
    p.add_argument("output", type=Path)
    p.add_argument("cif", type=Path)
    p.add_argument("--name", default="CuWO4_P-1")
    p.add_argument("--background-terms", type=int, default=10)
    p.add_argument("--zero", type=float, default=0.0)
    p.add_argument("--shift", type=float, default=-600.0)
    p.add_argument("--w", type=float, default=25.0)
    p.add_argument("--x", type=float, default=10.0)
    p.set_defaults(func=build)

    p = sub.add_parser("common")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("--background-terms", type=int)
    p.add_argument("--max-calls", type=int, default=12)
    p.set_defaults(func=refine_common)

    p = sub.add_parser("add-phase")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("cif", type=Path)
    p.add_argument("--name", required=True)
    p.add_argument("--refine-cells", action="store_true")
    p.add_argument("--neutralize-microstructure", action="store_true")
    p.add_argument("--max-calls", type=int, default=12)
    p.set_defaults(func=add_phase)

    p = sub.add_parser("profile")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("parameters", nargs="+")
    p.add_argument("--max-calls", type=int, default=12)
    p.set_defaults(func=set_profile)

    p = sub.add_parser("replace-phase")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("cif", type=Path)
    p.add_argument("--old", required=True)
    p.add_argument("--name", required=True)
    p.add_argument("--refine-cells", action="store_true")
    p.add_argument("--neutralize-microstructure", action="store_true")
    p.add_argument("--max-calls", type=int, default=20)
    p.set_defaults(func=replace_phase)

    p = sub.add_parser("microstructure")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("kind", choices=("size", "strain"))
    p.add_argument("--phase", default="CuWO4_P-1")
    p.add_argument("--start", type=float, default=1.0)
    p.add_argument("--retain-other", action="store_true")
    p.add_argument("--max-calls", type=int, default=12)
    p.set_defaults(func=set_microstructure)

    p = sub.add_parser("coordinates")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("--phase", default="CuWO4_P-1")
    p.add_argument("--elements", nargs="+")
    p.add_argument("--flags", default="X")
    p.add_argument("--max-calls", type=int, default=12)
    p.set_defaults(func=coordinates)

    p = sub.add_parser("texture")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("--phase", default="CuWO4_P-1")
    p.add_argument("--axis", nargs=3, type=int, required=True)
    p.add_argument("--start", type=float, default=1.0)
    p.add_argument("--max-calls", type=int, default=12)
    p.set_defaults(func=preferred_orientation)

    p = sub.add_parser("surface")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("--a", type=float, default=0.5)
    p.add_argument("--b", type=float, default=0.1)
    p.add_argument("--refine-b", action="store_true")
    p.add_argument("--max-calls", type=int, default=12)
    p.set_defaults(func=surface_roughness)

    p = sub.add_parser("activate")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("--profile", nargs="+", default=[])
    p.add_argument("--reset-profile", nargs="+", default=[])
    p.add_argument("--disable-phases", nargs="+", default=[])
    p.add_argument("--surface", action="store_true")
    p.add_argument("--neutralize-microstructure", action="store_true")
    p.add_argument("--neutralize-texture", action="store_true")
    p.add_argument("--coordinates")
    p.add_argument("--elements", nargs="+")
    p.add_argument("--size-phases", nargs="+", default=[])
    p.add_argument("--strain-phases", nargs="+", default=[])
    p.add_argument("--texture-phase")
    p.add_argument("--max-calls", type=int, default=30)
    p.set_defaults(func=activate_model)

    p = sub.add_parser("show")
    p.add_argument("source", type=Path)
    p.set_defaults(func=show)

    p = sub.add_parser("continue")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("--max-calls", type=int, default=20)
    p.set_defaults(func=continue_existing)
    return ap


if __name__ == "__main__":
    arguments = parser().parse_args()
    arguments.func(arguments)
