#!/usr/bin/env python3
"""Workspace-local helpers for the staged Mn/W/O PXRD analysis."""

from __future__ import annotations

import argparse
import copy
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIfiles as G2fil
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
MNWO4_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"
)


def cod_cif(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def instrument_parameters() -> tuple[dict, dict]:
    names = [
        "Type",
        "Lam1",
        "Lam2",
        "Zero",
        "I(L2)/I(L1)",
        "Polariz.",
        "U",
        "V",
        "W",
        "X",
        "Y",
        "Z",
        "SH/L",
        "Azimuth",
    ]
    values = [
        "PXC",
        1.540598,
        1.544426,
        0.0,
        0.5,
        0.5,
        2.0,
        -2.0,
        5.0,
        0.0,
        0.0,
        0.0,
        0.002,
        0.0,
    ]
    inst = G2fil.makeInstDict(names, values, [False] * len(names))
    inst["Source"] = ["CuKa", "CuKa", 0]
    inst["Bank"] = [1, 1, 0]
    return inst, {}


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, attempts: int = 8) -> bool:
    project.set_Controls("cycles", 8)
    for _ in range(attempts):
        project.refine(makeBack=False)
        status = covariance_status(project)
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in message:
            return False
        max_shift = float(status.get("Max shft/sig") or math.inf)
        if status.get("converged") and max_shift < 0.05:
            return True
    return False


def summary(project: G2sc.G2Project) -> dict:
    hist = project.histograms()[0]
    status = covariance_status(project)
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "size": hap.get("Size"),
                "mustrain": hap.get("Mustrain"),
                "preferred_orientation": hap.get("Pref.Ori."),
            }
        )
    return {
        "file": project.filename,
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "background": hist.Background,
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "phases": phases,
        "convergence": {
            key: status.get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg", "GOF", "Rwp")
        },
        "vary_list": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }


def initialize(output: Path) -> None:
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(PATTERN), instrument_parameters(), fmthint="comma"
    )
    phase = project.add_phase(
        str(MNWO4_CIF), phasename="MnWO4_wolframite", histograms=[hist], fmthint="CIF"
    )
    sample = hist.SampleParameters
    sample.update(
        {
            "Type": "Bragg-Brentano",
            "Shift": [0.0, False],
            "Transparency": [0.0, False],
            "SurfRoughA": [0.0, False],
            "SurfRoughB": [0.0, False],
        }
    )
    for key in ("Absorption", "DisplaceX", "DisplaceY"):
        sample.pop(key, None)
    # Fix the redundant histogram multiplier and use HAP scales for phase amounts.
    sample["Scale"][:] = [1.0, False]
    # A smooth, low-order background is adequate for the slowly falling baseline.
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [1200.0, -500.0, 250.0, -100.0, 40.0, -15.0],
                "refine": False,
            },
        }
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][:] = [0.01, False]
    project.set_Controls("cycles", 8)
    project.save(str(output))
    print(json.dumps(summary(project), indent=2, default=str))


def inspect(path: Path) -> None:
    project = G2sc.G2Project(str(path))
    print(json.dumps(summary(project), indent=2, default=str))


def converge(source: Path, output: Path) -> None:
    project = G2sc.G2Project(str(source), newgpx=str(output))
    valid = stable_refine(project, attempts=30)
    project.save(str(output))
    print("CONVERGED", valid, json.dumps(summary(project), indent=2, default=str))


def instrument_branch(source: Path, output: Path, parameters: list[str]) -> None:
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = project.histograms()[0]
    for name in parameters:
        if name not in hist.InstrumentParameters:
            raise KeyError(name)
        hist.InstrumentParameters[name][2] = True
    valid = stable_refine(project, attempts=30)
    project.save(str(output))
    print(
        "INSTRUMENT_BRANCH",
        ",".join(parameters),
        "valid=", valid,
        json.dumps(summary(project), indent=2, default=str),
    )


def candidate_branch(source: Path, output: Path, cod_id: str) -> None:
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = project.histograms()[0]
    candidate_file = cod_cif(cod_id) if cod_id.isdigit() else Path(cod_id).resolve()
    candidate_label = cod_id if cod_id.isdigit() else candidate_file.stem
    phase = project.add_phase(
        str(candidate_file),
        phasename=f"candidate_{candidate_label}",
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][:] = [0.5, True]
    phase.data["General"]["Cell"][0] = False
    project.save(str(output))
    valid = stable_refine(project, attempts=30)
    project.save(str(output))
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as error:
        fractions = {"error": repr(error)}
    print(
        "CANDIDATE_BRANCH",
        cod_id,
        "valid=", valid,
        "fractions=", fractions,
        json.dumps(summary(project), indent=2, default=str),
    )


def phase_cell_branch(source: Path, output: Path, phase_index: int) -> None:
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = project.histograms()[0]
    phase = project.phases()[phase_index]
    phase.data["General"]["Cell"][0] = True
    valid = stable_refine(project, attempts=30)
    project.save(str(output))
    cell, esd = phase.get_cell_and_esd()
    print(
        "PHASE_CELL_BRANCH",
        phase.name,
        "valid=", valid,
        "cell_esd=", esd,
        json.dumps(summary(project), indent=2, default=str),
    )


def replacement_branch(
    source: Path, output: Path, phase_index: int, cod_id: str
) -> None:
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = project.histograms()[0]
    old_phase = project.phases()[phase_index]
    old_hap = old_phase.data["Histograms"][hist.name]
    old_hap["Use"] = False
    old_hap["Scale"][1] = False

    candidate_file = cod_cif(cod_id)
    phase = project.add_phase(
        str(candidate_file),
        phasename=f"replacement_{cod_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][:] = [0.5, True]
    phase.data["General"]["Cell"][0] = False
    phase.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.1, "refine": True}}
    )
    project.save(str(output))
    valid = stable_refine(project, attempts=30)
    project.save(str(output))
    print(
        "REPLACEMENT_BRANCH",
        cod_id,
        "valid=", valid,
        "fractions=", hist.ComputeMassFracs(),
        json.dumps(summary(project), indent=2, default=str),
    )


def initial_refinement(source: Path, output: Path) -> None:
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = project.histograms()[0]
    phase = project.phases()[0]

    # Stage 1: background and scale only.
    hist.Background[0][1] = True
    phase.data["Histograms"][hist.name]["Scale"][1] = True
    stable_refine(project)
    project.save(str(output))
    print("STAGE background-scale", json.dumps(summary(project), default=str))

    # Stage 2: add the unit cell after intensity scale/background have settled.
    phase.data["General"]["Cell"][0] = True
    stable_refine(project)
    project.save(str(output))
    print("STAGE cell", json.dumps(summary(project), default=str))


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("init")
    p.add_argument("output", type=Path)
    p = sub.add_parser("initial")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p = sub.add_parser("inspect")
    p.add_argument("project", type=Path)
    p = sub.add_parser("converge")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p = sub.add_parser("instrument")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("parameters", nargs="+")
    p = sub.add_parser("candidate")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("cod_id")
    p = sub.add_parser("phase-cell")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("phase_index", type=int)
    p = sub.add_parser("replacement")
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("phase_index", type=int)
    p.add_argument("cod_id")
    args = parser.parse_args()
    if args.command == "init":
        initialize(args.output.resolve())
    elif args.command == "initial":
        initial_refinement(args.source.resolve(), args.output.resolve())
    elif args.command == "inspect":
        inspect(args.project.resolve())
    elif args.command == "converge":
        converge(args.source.resolve(), args.output.resolve())
    elif args.command == "instrument":
        instrument_branch(
            args.source.resolve(), args.output.resolve(), args.parameters
        )
    elif args.command == "candidate":
        candidate_branch(
            args.source.resolve(), args.output.resolve(), args.cod_id
        )
    elif args.command == "phase-cell":
        phase_cell_branch(
            args.source.resolve(), args.output.resolve(), args.phase_index
        )
    elif args.command == "replacement":
        replacement_branch(
            args.source.resolve(), args.output.resolve(), args.phase_index, args.cod_id
        )


if __name__ == "__main__":
    main()
