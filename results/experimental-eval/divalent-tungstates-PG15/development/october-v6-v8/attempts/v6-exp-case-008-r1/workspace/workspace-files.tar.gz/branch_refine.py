#!/usr/bin/env python3
"""Small, reproducible GSAS-II branch operations for this analysis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from analysis_work import stable_refine


def report(project: G2sc.G2Project, valid: bool) -> None:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    names = cov.get("varyList", [])
    values = cov.get("variables", [])
    sigmas = cov.get("sig", [])
    params = {
        name: {"value": float(value), "esd": float(sigma)}
        for name, value, sigma in zip(names, values, sigmas)
    }
    corr = []
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.shape == (len(names), len(names)) and len(names):
        sd = np.sqrt(np.clip(np.diag(matrix), 0.0, None))
        den = np.outer(sd, sd)
        with np.errstate(divide="ignore", invalid="ignore"):
            cm = np.divide(matrix, den, out=np.zeros_like(matrix), where=den > 0)
        for i in range(len(names)):
            for j in range(i):
                if abs(cm[i, j]) >= 0.95:
                    corr.append([names[j], names[i], float(cm[i, j])])
    status = cov.get("Rvals", {})
    result = {
        "file": str(project.filename),
        "valid": valid,
        "rwp_percent": float(hist.get_wR()),
        "rp_percent": float(hist.residuals.get("R", np.nan)),
        "gof": float(status.get("GOF", np.nan)),
        "converged": bool(status.get("converged", False)),
        "max_shift_over_esd": status.get("Max shft/sig"),
        "message": status.get("msg"),
        "mass_fractions": hist.ComputeMassFracs(),
        "high_correlations": corr,
        "parameters": params,
        "instrument": {
            key: hist.InstrumentParameters[key]
            for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
            if key in hist.InstrumentParameters
        },
        "sample": {
            key: hist.SampleParameters[key]
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if key in hist.SampleParameters
        },
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "size": hap["Size"][:3],
                "mustrain": hap["Mustrain"][:3],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "xyz": list(atom.coordinates),
                        "refinement_flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    print("BRANCH_RESULT=" + json.dumps(result, default=str, sort_keys=True))


def load(source: Path, output: Path) -> G2sc.G2Project:
    return G2sc.G2Project(str(source), newgpx=str(output))


def finish(project: G2sc.G2Project, output: Path, attempts: int = 16) -> None:
    project.save(str(output))
    valid = stable_refine(project, attempts=attempts)
    project.save(str(output))
    report(project, valid)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    sub = parser.add_subparsers(dest="operation", required=True)

    sub.add_parser("full-range")
    bg = sub.add_parser("background")
    bg.add_argument("count", type=int)
    inst = sub.add_parser("instrument")
    inst.add_argument("parameters", nargs="+")
    inst_off = sub.add_parser("instrument-off")
    inst_off.add_argument("parameters", nargs="+")
    inst_fixed = sub.add_parser("instrument-fixed")
    inst_fixed.add_argument("parameter")
    inst_fixed.add_argument("value", type=float)
    sample = sub.add_parser("sample")
    sample.add_argument("parameters", nargs="+")
    hap = sub.add_parser("hap")
    hap.add_argument("phase_index", type=int)
    hap.add_argument("kind", choices=("size", "strain"))
    hap_off = sub.add_parser("hap-off")
    hap_off.add_argument("phase_index", type=int)
    hap_off.add_argument("kind", choices=("size", "strain"))
    texture = sub.add_parser("texture")
    texture.add_argument("phase_index", type=int)
    texture.add_argument("axis", nargs=3, type=int)
    texture_off = sub.add_parser("texture-off")
    texture_off.add_argument("phase_index", type=int)
    atoms = sub.add_parser("atoms")
    atoms.add_argument("phase_index", type=int)
    atoms.add_argument("labels", nargs="+")
    adp = sub.add_parser("adp")
    adp.add_argument("phase_index", type=int)
    adp.add_argument("labels", nargs="+")
    atom_reset = sub.add_parser("atom-reset")
    atom_reset.add_argument("phase_index", type=int)
    atom_reset.add_argument("label")
    atom_reset.add_argument("xyz", nargs=3, type=float)

    args = parser.parse_args()
    project = load(args.source.resolve(), args.output.resolve())
    hist = project.histograms()[0]

    if args.operation == "full-range":
        x = np.asarray(hist.data["data"][1][0], dtype=float)
        hist.Limits("lower", float(x.min()))
        hist.Limits("upper", float(x.max()))
    elif args.operation == "background":
        old = list(hist.Background[0][3:])
        if args.count > len(old):
            old.extend([0.0] * (args.count - len(old)))
        hist.Background[0][2] = args.count
        hist.Background[0][3:] = old[: args.count]
        hist.Background[0][1] = True
    elif args.operation == "instrument":
        for name in args.parameters:
            hist.InstrumentParameters[name][2] = True
    elif args.operation == "instrument-off":
        for name in args.parameters:
            hist.InstrumentParameters[name][2] = False
    elif args.operation == "instrument-fixed":
        hist.InstrumentParameters[args.parameter][1] = args.value
        hist.InstrumentParameters[args.parameter][2] = False
    elif args.operation == "sample":
        for name in args.parameters:
            if name == "SurfRoughA" and hist.SampleParameters[name][0] == 0:
                hist.SampleParameters[name][0] = 0.5
            if name == "SurfRoughB" and hist.SampleParameters[name][0] == 0:
                hist.SampleParameters[name][0] = 0.01
            hist.SampleParameters[name][1] = True
    elif args.operation == "hap":
        phase = project.phases()[args.phase_index]
        if args.kind == "size":
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
            )
        else:
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
    elif args.operation == "hap-off":
        phase = project.phases()[args.phase_index]
        hap_values = phase.data["Histograms"][hist.name]
        if args.kind == "size":
            hap_values["Size"][0] = "isotropic"
            hap_values["Size"][1][0] = 1.0
            hap_values["Size"][2] = [False for _ in hap_values["Size"][2]]
            hap_values["Size"][5] = [False for _ in hap_values["Size"][5]]
        else:
            hap_values["Mustrain"][0] = "isotropic"
            hap_values["Mustrain"][1][0] = 1000.0
            hap_values["Mustrain"][2] = [False for _ in hap_values["Mustrain"][2]]
            hap_values["Mustrain"][5] = [False for _ in hap_values["Mustrain"][5]]
    elif args.operation == "texture":
        phase = project.phases()[args.phase_index]
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(args.axis)
    elif args.operation == "texture-off":
        phase = project.phases()[args.phase_index]
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[1] = 1.0
        po[2] = False
    elif args.operation == "atoms":
        phase = project.phases()[args.phase_index]
        refs = {label: "X" for label in args.labels}
        phase.set_refinements({"Atoms": refs})
    elif args.operation == "adp":
        phase = project.phases()[args.phase_index]
        refs = {label: "XU" for label in args.labels}
        phase.set_refinements({"Atoms": refs})
    elif args.operation == "atom-reset":
        phase = project.phases()[args.phase_index]
        atom = phase.atom(args.label)
        atom.coordinates = tuple(args.xyz)
        atom.refinement_flags = ""
    finish(project, args.output.resolve())


if __name__ == "__main__":
    main()
