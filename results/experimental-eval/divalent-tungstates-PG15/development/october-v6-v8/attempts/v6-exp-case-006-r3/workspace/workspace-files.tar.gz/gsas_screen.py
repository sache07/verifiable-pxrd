#!/usr/bin/env python3
"""Build and minimally refine a GSAS-II project for candidate phase screening."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def stable_refine(project: G2sc.G2Project, cycles: int = 8) -> dict:
    """Refine until converged (or the cycle cap) and return covariance status."""
    last = {}
    for _ in range(cycles):
        project.refine()
        last = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        msg = str(last.get("msg", "") or "").lower()
        if last.get("Aborted") or last.get("SVD0", 0) or "dropped" in msg or "error" in msg:
            raise RuntimeError(f"unstable refinement: {last}")
        if last.get("converged") and float(last.get("Max shft/sig") or 0.0) < 0.05:
            break
    return last


def make_inputs(csv_path: Path, stem: Path) -> tuple[Path, Path]:
    data = np.genfromtxt(csv_path, delimiter=",", names=True)
    x = np.asarray(data[data.dtype.names[0]], dtype=float)
    y = np.asarray(data[data.dtype.names[1]], dtype=float)
    # Point uncertainties were not supplied. Counts are used with Poisson weights.
    sig = np.sqrt(np.maximum(y, 1.0))
    xye = stem.with_suffix(".xye")
    np.savetxt(xye, np.column_stack((x, y, sig)), fmt="%.8f %.8f %.8f")
    inst = stem.with_suffix(".instprm")
    inst.write_text(
        "#GSAS-II instrument parameter file for reflection Cu Ka1/Ka2 data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:2.0;V:-2.0;W:5.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    rval = cov.get("Rvals", {})
    return {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "gof": rval.get("GOF"),
        "converged": rval.get("converged"),
        "max_shift_esd": rval.get("Max shft/sig"),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "scales": {
            phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("cifs", nargs="+", type=Path)
    parser.add_argument("--names", nargs="*")
    parser.add_argument("--background", type=int, default=12)
    parser.add_argument("--initial-w", type=float)
    parser.add_argument("--profile", action="store_true")
    args = parser.parse_args()

    output = args.output.resolve()
    stem = output.with_name(output.stem + "-input")
    xye, inst = make_inputs(Path("inputs/pattern.csv"), stem)
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    # Keep the histogram normalization fixed; phase scales carry the intensity model.
    hist.SampleParameters["Scale"][1] = False
    if args.initial_w is not None:
        hist.InstrumentParameters["W"][1] = args.initial_w
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "no. coeffs": args.background, "refine": True},
    })
    names = args.names or [p.stem for p in args.cifs]
    if len(names) != len(args.cifs):
        raise ValueError("--names must match number of CIFs")
    for cif, name in zip(args.cifs, names):
        project.add_phase(str(cif.resolve()), phasename=name, histograms=[hist])
    project.set_Controls("cycles", 8)
    project.save()

    stages = []
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    stable_refine(project)
    stages.append(snapshot(project, "scale_background"))
    project.save(str(output))
    shutil.copy2(output, output.with_name(output.stem + "-scale-background.gpx"))

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    stable_refine(project)
    stages.append(snapshot(project, "cells"))
    project.save(str(output))
    shutil.copy2(output, output.with_name(output.stem + "-cells.gpx"))

    if args.profile:
        # Add the minimal global Gaussian/Lorentzian terms after cells settle.
        hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
        stable_refine(project)
        stages.append(snapshot(project, "global_profile"))

    project.save(str(output))
    print("SCREEN_RESULT=" + json.dumps(stages, default=float))


if __name__ == "__main__":
    main()
