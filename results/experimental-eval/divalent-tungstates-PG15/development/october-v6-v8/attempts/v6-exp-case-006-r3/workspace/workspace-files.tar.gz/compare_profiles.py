#!/usr/bin/env python3
"""Compare saved GSAS-II profiles over fixed two-theta intervals."""

from __future__ import annotations

import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def profile(path: str):
    project = G2sc.G2Project(path)
    histogram = project.histograms()[0]
    x, observed, weights, calculated = [
        np.asarray(values, dtype=float) for values in histogram.data["data"][1][:4]
    ]
    limits = histogram.data["Limits"][1]
    used = (x >= limits[0]) & (x <= limits[1]) & np.isfinite(calculated)
    return x, observed, weights, calculated, used


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("reference")
    parser.add_argument("candidate")
    parser.add_argument("--width", type=float, default=10.0)
    args = parser.parse_args()
    x0, y0, w0, c0, used0 = profile(args.reference)
    x1, y1, w1, c1, used1 = profile(args.candidate)
    if not (np.array_equal(x0, x1) and np.array_equal(y0, y1)):
        raise ValueError("projects do not share the same observed profile")
    used = used0 & used1 & (w0 > 0) & (w1 > 0)
    rows = []
    lo = np.floor(x0[used].min() / args.width) * args.width
    hi = x0[used].max()
    while lo < hi:
        mask = used & (x0 >= lo) & (x0 < lo + args.width)
        if np.any(mask):
            old = float(np.sum(w0[mask] * (y0[mask] - c0[mask]) ** 2))
            new = float(np.sum(w1[mask] * (y1[mask] - c1[mask]) ** 2))
            rows.append({
                "range_deg": [float(lo), float(min(lo + args.width, hi))],
                "reference_chi2": old,
                "candidate_chi2": new,
                "improvement": old - new,
            })
        lo += args.width
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
