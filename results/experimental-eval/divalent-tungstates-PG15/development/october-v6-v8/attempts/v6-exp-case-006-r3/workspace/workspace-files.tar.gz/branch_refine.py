#!/usr/bin/env python3
"""Create a matched GSAS-II refinement branch and report stability diagnostics."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def covariance(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {})


def stable_refine(project: G2sc.G2Project, outer: int = 8) -> bool:
    for _ in range(outer):
        try:
            project.refine()
        except Exception as error:
            print("refinement error:", repr(error))
            return False
        stat = covariance(project).get("Rvals", {})
        msg = str(stat.get("msg", "") or "").lower()
        if stat.get("Aborted") or stat.get("SVD0", 0) or "dropped" in msg or "error" in msg:
            return False
        if stat.get("converged") and abs(float(stat.get("Max shft/sig") or 0.0)) < 0.05:
            return True
    return False


def correlation_summary(project: G2sc.G2Project) -> dict:
    cov = covariance(project)
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)) or not len(names):
        return {"maximum_abs": None, "pair": None}
    diag = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    corr = matrix / np.outer(diag, diag)
    np.fill_diagonal(corr, 0.0)
    if not np.all(np.isfinite(corr)):
        return {"maximum_abs": None, "pair": None}
    i, j = np.unravel_index(np.argmax(np.abs(corr)), corr.shape)
    return {"maximum_abs": abs(float(corr[i, j])), "pair": [names[i], names[j]]}


def atom_summary(atom) -> dict:
    try:
        uiso = atom.uiso
    except Exception:
        uiso = None
    return {"label": atom.label, "element": atom.element,
            "xyz": list(atom.coordinates), "uiso": uiso}


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--instrument", action="append", default=[])
    ap.add_argument("--instrument-start", action="append", default=[])
    ap.add_argument("--fix-instrument", action="append", default=[])
    ap.add_argument("--sample", action="append", default=[])
    ap.add_argument("--sample-start", action="append", default=[])
    ap.add_argument("--size", type=int, action="append", default=[])
    ap.add_argument("--size-start", type=float, default=1.0)
    ap.add_argument("--mustrain", type=int, action="append", default=[])
    ap.add_argument("--mustrain-start", type=float, default=1000.0)
    ap.add_argument("--texture", nargs=4, type=int, metavar=("PHASE", "H", "K", "L"))
    ap.add_argument("--remove-texture", type=int, action="append", default=[])
    ap.add_argument("--atoms", nargs=2, metavar=("PHASE", "SELECTOR"))
    ap.add_argument("--adps", nargs=2, metavar=("PHASE", "SELECTOR"))
    ap.add_argument(
        "--set-uiso",
        nargs=3,
        action="append",
        default=[],
        metavar=("PHASE", "SELECTOR", "VALUE"),
        help="set a fixed isotropic ADP for selected atoms",
    )
    ap.add_argument("--freeze-cells", action="store_true")
    ap.add_argument("--freeze-angular", action="store_true")
    ap.add_argument("--add-phase", nargs=2, action="append", default=[], metavar=("CIF", "NAME"))
    ap.add_argument("--disable-phase", type=int, action="append", default=[])
    ap.add_argument("--refine-added-cell", action="store_true")
    ap.add_argument("--refine-cell", type=int, action="append", default=[])
    return ap.parse_args()


def main() -> None:
    args = parse_args()
    output = args.output.resolve()
    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(output))
    project.set_Controls("cycles", 8)
    hist = project.histograms()[0]

    for phase_index in args.disable_phase:
        phase = project.phases()[phase_index]
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = False
        hap["Scale"] = [0.0, False]
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = ""

    for cif, name in args.add_phase:
        phase = project.add_phase(str(Path(cif).resolve()), phasename=name, histograms=[hist])
        phase.data["Histograms"][hist.name]["Scale"][0] = 1.0
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": args.refine_added_cell})
    for phase_index in args.refine_cell:
        project.phases()[phase_index].set_refinements({"Cell": True})

    starts = {}
    for item in args.instrument_start:
        key, value = item.split("=", 1)
        starts[key] = float(value)
    for key in args.instrument:
        if key not in hist.InstrumentParameters:
            raise ValueError(f"unknown instrument parameter {key}")
        if key in starts:
            hist.InstrumentParameters[key][1] = starts[key]
        hist.InstrumentParameters[key][2] = True
    for item in args.fix_instrument:
        key, value = item.split("=", 1)
        if key not in hist.InstrumentParameters:
            raise ValueError(f"unknown instrument parameter {key}")
        hist.InstrumentParameters[key][1] = float(value)
        hist.InstrumentParameters[key][2] = False

    sample_starts = {}
    for item in args.sample_start:
        key, value = item.split("=", 1)
        sample_starts[key] = float(value)
    for key in args.sample:
        if key not in hist.SampleParameters:
            raise ValueError(f"unknown sample parameter {key}")
        if key in sample_starts:
            hist.SampleParameters[key][0] = sample_starts[key]
        hist.SampleParameters[key][1] = True

    if args.freeze_angular:
        hist.InstrumentParameters["Zero"][2] = False
        hist.SampleParameters["Shift"][1] = False

    for phase_index in args.size:
        phase = project.phases()[phase_index]
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": args.size_start, "refine": True}
        })
    for phase_index in args.mustrain:
        phase = project.phases()[phase_index]
        hap = phase.data["Histograms"][hist.name]["Mustrain"]
        hap[1][0] = args.mustrain_start
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    if args.texture:
        phase_index, h, k, l = args.texture
        hap = project.phases()[phase_index].data["Histograms"][hist.name]["Pref.Ori."]
        hap[0] = "MD"
        hap[1] = 1.0
        hap[2] = True
        hap[3] = [h, k, l]
    for phase_index in args.remove_texture:
        hap = project.phases()[phase_index].data["Histograms"][hist.name]["Pref.Ori."]
        hap[1] = 1.0
        hap[2] = False
    if args.atoms:
        phase_index = int(args.atoms[0])
        selector = args.atoms[1]
        phase = project.phases()[phase_index]
        for atom in phase.atoms():
            if selector == "all" or atom.element.rstrip("+-0123456789") == selector:
                atom.refinement_flags = "X"
    if args.adps:
        phase_index = int(args.adps[0])
        selector = args.adps[1]
        phase = project.phases()[phase_index]
        for atom in phase.atoms():
            if selector == "all" or atom.element.rstrip("+-0123456789") == selector:
                flags = atom.refinement_flags
                atom.refinement_flags = ("X" if "X" in flags else "") + "U"
    for phase_text, selector, value_text in args.set_uiso:
        phase = project.phases()[int(phase_text)]
        value = float(value_text)
        for atom in phase.atoms():
            if selector == "all" or atom.element.rstrip("+-0123456789") == selector:
                atom.uiso = value
                atom.refinement_flags = atom.refinement_flags.replace("U", "")
    if args.freeze_cells:
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = False

    project.save(str(output))
    valid = stable_refine(project)
    project.save(str(output))
    stat = covariance(project).get("Rvals", {})
    result = {
        "valid": valid,
        "rwp_percent": project.histograms()[0].get_wR(),
        "gof": stat.get("GOF"),
        "converged": stat.get("converged"),
        "max_shift_esd": stat.get("Max shft/sig"),
        "message": stat.get("msg"),
        "correlation": correlation_summary(project),
        "instrument": hist.InstrumentParameters,
        "sample": {key: hist.SampleParameters.get(key) for key in ("Shift", "SurfRoughA", "SurfRoughB")},
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "haps": {
            p.name: {
                key: p.data["Histograms"][hist.name].get(key)
                for key in ("Scale", "Size", "Mustrain", "Pref.Ori.")
            }
            for p in project.phases()
        },
        "mass_fractions": hist.ComputeMassFracs(),
        "atoms": {
            p.name: [atom_summary(a) for a in p.atoms()]
            for p in project.phases()
        },
    }
    print("BRANCH_RESULT=" + json.dumps(result, default=float))


if __name__ == "__main__":
    main()
