#!/usr/bin/env python3
"""Export the final GSAS-II project into the required submission files."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT_PATH = ROOT / "final.gpx"


def weighted_rwp(observed: np.ndarray, calculated: np.ndarray, weights: np.ndarray) -> float:
    valid = (
        np.isfinite(observed)
        & np.isfinite(calculated)
        & np.isfinite(weights)
        & (weights > 0.0)
    )
    numerator = np.sum(weights[valid] * (observed[valid] - calculated[valid]) ** 2)
    denominator = np.sum(weights[valid] * observed[valid] ** 2)
    return 100.0 * math.sqrt(float(numerator / denominator))


def unweighted_rp(observed: np.ndarray, calculated: np.ndarray) -> float:
    valid = np.isfinite(observed) & np.isfinite(calculated)
    return 100.0 * float(
        np.sum(np.abs(observed[valid] - calculated[valid]))
        / np.sum(np.abs(observed[valid]))
    )


def main() -> None:
    project = G2sc.G2Project(str(PROJECT_PATH))
    histograms = project.histograms()
    phases = project.phases()
    if len(histograms) != 1:
        raise ValueError(f"expected one powder histogram, found {len(histograms)}")
    if [phase.name for phase in phases] != ["CuWO4-triclinic", "WO3-P21c"]:
        raise ValueError(f"unexpected phase inventory: {[phase.name for phase in phases]}")

    histogram = histograms[0]
    arrays = histogram.data["data"][1]
    two_theta = np.asarray(arrays[0], dtype=float)
    observed = np.asarray(arrays[1], dtype=float)
    weights = np.asarray(arrays[2], dtype=float)
    calculated = np.asarray(arrays[3], dtype=float)
    difference = np.asarray(arrays[5], dtype=float)
    if not all(len(array) == len(two_theta) for array in (observed, calculated, difference)):
        raise ValueError("profile arrays have inconsistent lengths")
    if not np.allclose(difference, observed - calculated, rtol=0.0, atol=1e-8):
        raise ValueError("saved difference profile is inconsistent with observed-calculated")

    with (ROOT / "fit.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        writer.writerows(
            zip(
                (f"{value:.8f}" for value in two_theta),
                (f"{value:.17g}" for value in observed),
                (f"{value:.17g}" for value in calculated),
                (f"{value:.17g}" for value in difference),
            )
        )

    phase_metadata = [
        {
            "name": "CuWO4 (triclinic)",
            "formula": "CuWO4",
            "cif_path": "phase_CuWO4.cif",
            "source_model": "COD 4000806 topology",
        },
        {
            "name": "WO3 (monoclinic)",
            "formula": "WO3",
            "cif_path": "phase_WO3.cif",
            "source_model": "COD 2311041 topology",
        },
    ]
    mass_fractions = histogram.ComputeMassFracs()
    fraction_total = sum(float(mass_fractions[phase.name][0]) for phase in phases)
    if not math.isfinite(fraction_total) or fraction_total <= 0.0:
        raise ValueError("invalid mass-fraction normalization")

    phase_rows = []
    for phase, metadata in zip(phases, phase_metadata):
        cif_path = ROOT / metadata["cif_path"]
        phase.export_CIF(str(cif_path))
        fraction, fraction_esd = mass_fractions[phase.name]
        normalized_fraction = float(fraction) / fraction_total
        phase_rows.append(
            {
                **metadata,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "weight_fraction": normalized_fraction,
                "weight_percent": 100.0 * normalized_fraction,
                "formal_weight_fraction_esd": float(fraction_esd) / fraction_total,
                "cell": {key: float(value) for key, value in phase.get_cell().items()},
            }
        )

    covariance = project.data["Covariance"]["data"]
    rvalues = covariance["Rvals"]
    histogram_stats = histogram.data["data"][0]
    result = {
        "phases": phase_rows,
        "fraction_basis": "normalized over modeled crystalline phases",
        "fit_statistics": {
            "rwp_percent": float(rvalues["Rwp"]),
            "rp_percent": float(histogram_stats["R"]),
            "gof": float(rvalues["GOF"]),
            "chi_squared": float(rvalues["chisq"]),
            "n_observations": int(rvalues["Nobs"]),
            "n_variables": int(rvalues["Nvars"]),
            "fit_range_two_theta_deg": [
                float(histogram.data["Limits"][1][0]),
                float(histogram.data["Limits"][1][1]),
            ],
            "full_profile_rwp_percent": weighted_rwp(observed, calculated, weights),
            "full_profile_rp_percent": unweighted_rp(observed, calculated),
            "full_profile_point_count": int(len(two_theta)),
            "converged": bool(rvalues["converged"]),
            "svd_dropped_variables": int(rvalues.get("SVD0", 0) or 0),
            "maximum_shift_over_esd": float(rvalues["Max shft/sig"]),
        },
        "uncertainty_note": (
            "Fraction esds are formal least-squares values. Model, profile, preferred-"
            "orientation, counting-statistics, and possible trace-phase systematics are larger."
        ),
        "unresolved_components": [],
    }
    if abs(sum(row["weight_fraction"] for row in phase_rows) - 1.0) > 1e-12:
        raise ValueError("exported fractions do not sum to one")
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
