#!/usr/bin/env python3
"""Stage a narrow-profile refinement from a broad centroid solution."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, outer: int = 8) -> None:
    previous = math.inf
    for _ in range(outer):
        project.refine()
        current = float(project.histograms()[0].get_wR())
        stat = status(project)
        msg = str(stat.get("msg", "") or "").lower()
        if stat.get("Aborted") or stat.get("SVD0", 0) or "dropped" in msg or "error" in msg:
            raise RuntimeError(f"unstable refinement: {stat}")
        if current > previous + 1e-5:
            raise RuntimeError(f"Rwp increased from {previous:.6f} to {current:.6f}")
        previous = current
        if stat.get("converged") and abs(float(stat.get("Max shft/sig") or 0.0)) < 0.05:
            return


def summary(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    cov = status(project)
    names = project.data.get("Covariance", {}).get("data", {}).get("varyList", [])
    return {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("GOF"),
        "converged": cov.get("converged"),
        "max_shift_esd": cov.get("Max shft/sig"),
        "variables": names,
        "instrument": hist.InstrumentParameters,
        "sample_shift": hist.SampleParameters.get("Shift"),
        "cells": {p.name: p.get_cell() for p in project.phases()},
    }


def checkpoint(project: G2sc.G2Project, output: Path, label: str) -> None:
    project.save(str(output))
    shutil.copy2(output, output.with_name(output.stem + f"-{label}.gpx"))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--w-start", type=float, default=15.0)
    args = ap.parse_args()
    output = args.output.resolve()
    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(output))
    hist = project.histograms()[0]
    project.set_Controls("cycles", 8)

    # Replace the deliberately broad centroid-search profile by a realistic
    # lab profile while preserving the selected angular branch and cell.
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = False
    hist.InstrumentParameters["U"][1] = 2.0
    hist.InstrumentParameters["V"][1] = -2.0
    hist.InstrumentParameters["W"][1] = args.w_start
    hist.InstrumentParameters["X"][1] = 0.0
    hist.InstrumentParameters["Y"][1] = 0.0
    checkpoint(project, output, "narrow-start")

    stages = []
    stable_refine(project)
    stages.append(summary(project, "narrow_fixed_profile"))
    checkpoint(project, output, "narrow-fixed")

    # First test the minimal global Gaussian constant term alone.
    hist.InstrumentParameters["W"][2] = True
    stable_refine(project)
    stages.append(summary(project, "refine_W"))
    checkpoint(project, output, "W")

    print("MATURE_RESULT=" + json.dumps(stages, default=float))


if __name__ == "__main__":
    main()
