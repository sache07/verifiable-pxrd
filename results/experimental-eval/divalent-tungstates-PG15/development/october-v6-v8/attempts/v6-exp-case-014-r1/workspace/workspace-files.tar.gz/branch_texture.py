#!/usr/bin/env python3
"""Matched one-phase March-Dollase preferred-orientation tests."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from branch_profile import freeze


def run(source: Path, phase_index: int, axis: tuple[int, int, int]) -> dict:
    axis_tag = "".join(str(value).replace("-", "m") for value in axis)
    destination = source.with_name(
        f"{source.stem}_plus_p{phase_index}_MD_{axis_tag}.gpx"
    )
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    freeze(project)
    histogram = project.histograms()[0]
    phase = project.phases()[phase_index]
    preferred = phase.data["Histograms"][histogram.name]["Pref.Ori."]
    preferred[0] = "MD"
    preferred[1] = 1.0
    preferred[2] = True
    preferred[3] = list(axis)
    project.data["Controls"]["data"]["max cyc"] = 20
    project.save()
    history = []
    for iteration in range(6):
        project.refine(printFile=str(destination.with_suffix(".lst")))
        status = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        history.append(
            {
                "iteration": iteration,
                "rwp_percent": histogram.get_wR(),
                "converged": status.get("converged"),
                "svd": status.get("SVD0"),
                "max_shift_esd": status.get("Max shft/sig"),
                "message": status.get("msg"),
            }
        )
        if (
            status.get("converged")
            and not status.get("SVD0")
            and abs(float(status.get("Max shft/sig") or 0.0)) < 0.05
        ):
            break
    project.save()
    return {
        "phase_index": phase_index,
        "phase": phase.name,
        "axis": axis,
        "ratio": preferred[1],
        "project": destination.name,
        "rwp_percent": histogram.get_wR(),
        "history": history,
    }


def main() -> None:
    if len(sys.argv) < 3:
        raise SystemExit(
            "usage: branch_texture.py SOURCE.gpx PHASE:H,K,L [PHASE:H,K,L ...]"
        )
    source = Path(sys.argv[1]).resolve()
    requests = []
    for item in sys.argv[2:]:
        phase, values = item.split(":", 1)
        axis = tuple(int(value) for value in values.split(","))
        if len(axis) != 3:
            raise ValueError(axis)
        requests.append((int(phase), axis))
    results = [run(source, phase, axis) for phase, axis in requests]
    print("TEXTURE_BRANCH_RESULT=" + json.dumps(results, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
