#!/usr/bin/env python3
"""Matched, phase-local coordinate refinement branches.

Usage: branch_coordinates.py SOURCE.gpx PHASE:MODE [...]
MODE is ``oxygen``, ``heavy`` or ``all``. All nuisance and other structural
parameters are frozen so that each branch measures coordinate support alone.
"""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from branch_profile import freeze


def max_correlation(project: G2sc.G2Project) -> dict | None:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)) or len(names) < 2:
        return None
    diagonal = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denominator = np.outer(diagonal, diagonal)
    correlation = np.divide(
        matrix,
        denominator,
        out=np.zeros_like(matrix),
        where=denominator > 0,
    )
    np.fill_diagonal(correlation, 0.0)
    row, column = np.unravel_index(np.nanargmax(np.abs(correlation)), correlation.shape)
    return {
        "absolute": abs(float(correlation[row, column])),
        "signed": float(correlation[row, column]),
        "parameters": [names[row], names[column]],
    }


def select_atoms(phase, mode: str) -> list[int]:
    atom_type_index = phase.data["General"]["AtomPtrs"][1]
    selected = []
    for index, atom in enumerate(phase.data["Atoms"]):
        element = str(atom[atom_type_index]).strip().capitalize()
        if mode == "all" or (mode == "oxygen" and element == "O") or (
            mode == "heavy" and element != "O"
        ):
            selected.append(index)
    if not selected:
        raise ValueError(f"no atoms selected for {phase.name!r} mode {mode!r}")
    return selected


def stable_clone(source: Path, destination: Path) -> None:
    clone = G2sc.G2Project(str(source), newgpx=str(destination))
    clone.save()


def run(source: Path, phase_index: int, mode: str) -> dict:
    destination = source.with_name(f"{source.stem}_plus_p{phase_index}_{mode}_coords.gpx")
    stable = destination.with_name(destination.stem + "_stable.gpx")
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    freeze(project)
    phase = project.phases()[phase_index]
    selected = select_atoms(phase, mode)
    for index in selected:
        phase.data["Atoms"][index][2] = "X"
    project.data["Controls"]["data"]["max cyc"] = 30
    project.save()
    stable_clone(destination, stable)
    histogram = project.histograms()[0]
    best = float(histogram.get_wR())
    history = []
    valid = True
    for iteration in range(8):
        try:
            project.refine(printFile=str(destination.with_suffix(".lst")))
        except Exception as error:
            history.append({"iteration": iteration, "error": repr(error)})
            valid = False
            break
        current = float(histogram.get_wR())
        status = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        message = str(status.get("msg", "") or "").lower()
        accepted = (
            math.isfinite(current)
            and not status.get("SVD0", 0)
            and "dropped" not in message
            and "error" not in message
            and current <= best + 0.001
        )
        history.append(
            {
                "iteration": iteration,
                "rwp_percent": current,
                "accepted": accepted,
                **{
                    key: status.get(key)
                    for key in ("converged", "SVD0", "Max shft/sig", "msg")
                },
            }
        )
        if not accepted:
            project = G2sc.G2Project(str(stable), newgpx=str(destination))
            project.save()
            histogram = project.histograms()[0]
            break
        best = current
        project.save()
        stable_clone(destination, stable)
        if status.get("converged") and abs(float(status.get("Max shft/sig") or 0.0)) < 0.05:
            break
    status = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    valid = valid and not status.get("SVD0", 0) and "dropped" not in str(
        status.get("msg", "") or ""
    ).lower()
    project.save()
    return {
        "phase_index": phase_index,
        "phase": phase.name,
        "mode": mode,
        "selected_atom_indices": selected,
        "selected_atom_labels": [phase.data["Atoms"][index][0] for index in selected],
        "project": destination.name,
        "valid": valid,
        "rwp_percent": float(histogram.get_wR()),
        "maximum_correlation": max_correlation(project),
        "history": history,
    }


def main() -> None:
    if len(sys.argv) < 3:
        raise SystemExit(
            "usage: branch_coordinates.py SOURCE.gpx PHASE:MODE [PHASE:MODE ...]"
        )
    source = Path(sys.argv[1]).resolve()
    requests = []
    for item in sys.argv[2:]:
        phase, mode = item.split(":", 1)
        if mode not in {"oxygen", "heavy", "all"}:
            raise ValueError(mode)
        requests.append((int(phase), mode))
    results = [run(source, phase, mode) for phase, mode in requests]
    print("COORDINATE_BRANCH_RESULT=" + json.dumps(results, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
