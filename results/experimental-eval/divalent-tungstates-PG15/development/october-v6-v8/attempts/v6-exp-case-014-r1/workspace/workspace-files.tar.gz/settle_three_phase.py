#!/usr/bin/env python3
"""Stage a stable three-phase inventory baseline for angular/profile branches."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from branch_profile import freeze


def covariance(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def valid_status(project: G2sc.G2Project) -> bool:
    values = covariance(project)
    message = str(values.get("msg", "") or "").lower()
    return not (
        values.get("Aborted")
        or values.get("SVD0", 0)
        or "dropped" in message
        or "error" in message
    )


def refine_until(project: G2sc.G2Project, listing: Path, maximum: int = 10) -> list[dict]:
    histogram = project.histograms()[0]
    history = []
    for iteration in range(maximum):
        project.refine(printFile=str(listing))
        values = covariance(project)
        row = {
            "iteration": iteration,
            "rwp_percent": histogram.get_wR(),
            **{
                key: values.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
        }
        history.append(row)
        if not valid_status(project):
            raise RuntimeError(f"unstable refinement: {row}")
        if (
            values.get("converged")
            and abs(float(values.get("Max shft/sig") or 0.0)) < 0.05
        ):
            break
    return history


def enable_scales_background(project: G2sc.G2Project) -> None:
    histogram = project.histograms()[0]
    histogram.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][histogram.name]["Scale"][1] = True


def enable_cells(project: G2sc.G2Project) -> None:
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True


def snapshot(path: Path, output: Path) -> None:
    copy = G2sc.G2Project(str(path), newgpx=str(output))
    copy.save()


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: settle_three_phase.py SOURCE.gpx DESTINATION.gpx")
    source = Path(sys.argv[1]).resolve()
    destination = Path(sys.argv[2]).resolve()
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    histogram = project.histograms()[0]
    freeze(project)

    # Re-establish an orientation-neutral, effectively neutral broadening state
    # before nuisance branches are reconsidered for the complete inventory.
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
    project.data["Controls"]["data"]["max cyc"] = 30
    project.save()
    snapshot(destination, destination.with_name(destination.stem + "_stable_start.gpx"))

    stages = []
    for stage in ("scale_background_1", "cells_1", "scale_background_2", "cells_2"):
        freeze(project)
        if stage.startswith("scale_background"):
            enable_scales_background(project)
        else:
            enable_cells(project)
        project.save()
        stages.append(
            {
                "stage": stage,
                "history": refine_until(project, destination.with_suffix(".lst")),
            }
        )
        project.save()

    # Preserve the converged core flags so the angular helper can restore and
    # reconverge the complete core model identically in every branch.
    freeze(project)
    enable_scales_background(project)
    enable_cells(project)
    project.save()
    snapshot(destination, destination.with_name(destination.stem + "_stable.gpx"))

    fractions = histogram.ComputeMassFracs()
    result = {
        "project": destination.name,
        "rwp_percent": histogram.get_wR(),
        "stages": stages,
        "convergence": covariance(project),
        "fractions": fractions,
        "phases": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][histogram.name]["Scale"][0],
            }
            for phase in project.phases()
        ],
    }
    print("THREE_PHASE_SETTLE_RESULT=" + json.dumps(result, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
