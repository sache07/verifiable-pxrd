#!/usr/bin/env python3
"""Matched phase-specific isotropic size and microstrain branch tests."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from branch_profile import freeze


def run(source: Path, phase_index: int, term: str) -> dict:
    tag = f"p{phase_index}_{term}"
    destination = source.with_name(source.stem + "_plus_" + tag + ".gpx")
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    freeze(project)
    histogram = project.histograms()[0]
    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][histogram.name]
    if term == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][2][0] = True
    elif term == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2][0] = True
    else:
        raise ValueError(term)
    project.data["Controls"]["data"]["max cyc"] = 20
    project.save()
    history = []
    for iteration in range(6):
        project.refine(printFile=str(destination.with_suffix(".lst")))
        status = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        history.append(
            {
                "iteration": iteration,
                "rwp_percent": histogram.get_wR(),
                "converged": status.get("converged"),
                "svd": status.get("SVD0"),
                "max_shift_esd": status.get("Max shft/sig"),
                "message": status.get("msg"),
            }
        )
        if (
            status.get("converged")
            and not status.get("SVD0")
            and abs(float(status.get("Max shft/sig") or 0.0)) < 0.05
        ):
            break
    project.save()
    return {
        "phase_index": phase_index,
        "phase": phase.name,
        "term": term,
        "project": destination.name,
        "rwp_percent": histogram.get_wR(),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "history": history,
    }


def main() -> None:
    if len(sys.argv) < 3:
        raise SystemExit(
            "usage: branch_microstructure.py SOURCE.gpx PHASE:TERM [PHASE:TERM ...]"
        )
    source = Path(sys.argv[1]).resolve()
    requests = []
    for item in sys.argv[2:]:
        phase, term = item.split(":", 1)
        requests.append((int(phase), term))
    results = [run(source, phase, term) for phase, term in requests]
    print("MICROSTRUCTURE_BRANCH_RESULT=" + json.dumps(results, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
