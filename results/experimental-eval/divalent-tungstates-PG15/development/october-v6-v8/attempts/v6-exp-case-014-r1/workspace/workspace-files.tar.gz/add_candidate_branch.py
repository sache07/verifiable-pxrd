#!/usr/bin/env python3
"""Add one candidate to a fixed mature GSAS-II baseline and test scale/cell."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from branch_profile import freeze


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
HERE = Path(__file__).resolve().parent

CANDIDATES = {
    "sro": ("7200689", "SrO_Fm3m"),
    "srco3_r": ("1539128", "SrCO3_R3m"),
    "srco3_o": ("9008198", "SrCO3_Pnma"),
    "sro2_t": ("1010114", "SrO2_I4mmm"),
    "sro2_o": ("9008161", "SrO2_Pnma"),
    "sr3w2o9": ("2311977", "Sr3W2O9_C2c"),
    "srwo4_m": ("1546037", "SrWO4_C2c"),
}


def cif_path(cod_id: str) -> Path:
    path = ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def status(project: G2sc.G2Project) -> dict:
    values = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        key: values.get(key)
        for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp")
    }


def refine(project: G2sc.G2Project, listing: Path, count: int = 4) -> list[dict]:
    histogram = project.histograms()[0]
    history = []
    for iteration in range(count):
        project.refine(printFile=str(listing))
        current = status(project)
        current.update(iteration=iteration, rwp_percent=histogram.get_wR())
        history.append(current)
        if (
            current.get("converged")
            and not current.get("SVD0")
            and abs(float(current.get("Max shft/sig") or 0.0)) < 0.05
        ):
            break
    return history


def run(source: Path, label: str) -> dict:
    cod_id, phase_name = CANDIDATES[label]
    destination = HERE / f"inventory_add_{label}.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    histogram = project.histograms()[0]
    phase = project.add_phase(
        str(cif_path(cod_id)),
        phasename=phase_name,
        histograms=[histogram],
        fmthint="CIF",
    )
    freeze(project)

    # Match the selected baseline's effectively neutral phase broadening.
    hap = phase.data["Histograms"][histogram.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Scale"][:] = [0.25, True]
    phase.data["General"]["Cell"][0] = False
    project.data["Controls"]["data"]["max cyc"] = 30
    project.save()

    listing = destination.with_suffix(".lst")
    scale_history = refine(project, listing)
    project.save(str(HERE / f"inventory_add_{label}_scale.gpx"))
    scale_only = {
        "rwp_percent": histogram.get_wR(),
        "scale": hap["Scale"][0],
        "history": scale_history,
    }

    # Cell refinement has no useful meaning after a non-positive scale solution.
    cell_history = []
    if float(hap["Scale"][0]) > 1e-8:
        phase.data["General"]["Cell"][0] = True
        cell_history = refine(project, listing, count=6)
    project.save()

    try:
        fractions = histogram.ComputeMassFracs()
    except Exception as error:
        fractions = {"error": repr(error)}
    return {
        "label": label,
        "cod_id": cod_id,
        "phase": phase_name,
        "project": destination.name,
        "baseline": source.name,
        "scale_only": scale_only,
        "final_rwp_percent": histogram.get_wR(),
        "final_scale": hap["Scale"][0],
        "cell": phase.get_cell(),
        "cell_history": cell_history,
        "mass_fractions": fractions,
        "final_status": status(project),
    }


def main() -> None:
    if len(sys.argv) < 3:
        raise SystemExit(
            "usage: add_candidate_branch.py BASE.gpx CANDIDATE [CANDIDATE ...]"
        )
    source = Path(sys.argv[1]).resolve()
    unknown = [item for item in sys.argv[2:] if item not in CANDIDATES]
    if unknown:
        raise SystemExit(f"unknown candidates: {unknown}; choices: {list(CANDIDATES)}")
    results = [run(source, label) for label in sys.argv[2:]]
    print("ADD_CANDIDATE_RESULT=" + json.dumps(results, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
