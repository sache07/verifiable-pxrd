#!/usr/bin/env python3
"""Reconverge background/scales and cells around a selected fixed profile model."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from branch_profile import freeze


def covariance(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine_until(project: G2sc.G2Project, listing: Path, maximum: int = 8) -> list[dict]:
    histogram = project.histograms()[0]
    history = []
    for iteration in range(maximum):
        project.refine(printFile=str(listing))
        status = covariance(project)
        row = {
            "iteration": iteration,
            "rwp_percent": histogram.get_wR(),
            **{
                key: status.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
        }
        history.append(row)
        message = str(status.get("msg", "") or "").lower()
        if status.get("SVD0", 0) or "dropped" in message or "error" in message:
            raise RuntimeError(row)
        if (
            status.get("converged")
            and abs(float(status.get("Max shft/sig") or 0.0)) < 0.05
        ):
            break
    return history


def enable(project: G2sc.G2Project, stage: str) -> None:
    histogram = project.histograms()[0]
    if stage == "scales_background":
        histogram.Background[0][1] = True
        for phase in project.phases():
            phase.data["Histograms"][histogram.name]["Scale"][1] = True
    elif stage == "cells":
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
    else:
        raise ValueError(stage)


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: core_reconverge.py SOURCE.gpx DESTINATION.gpx")
    source = Path(sys.argv[1]).resolve()
    destination = Path(sys.argv[2]).resolve()
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    project.data["Controls"]["data"]["max cyc"] = 30
    project.save()
    history = []
    for stage in ("scales_background", "cells", "scales_background", "cells"):
        freeze(project)
        enable(project, stage)
        project.save()
        history.append(
            {
                "stage": stage,
                "history": refine_until(project, destination.with_suffix(".lst")),
            }
        )
    freeze(project)
    project.save()
    histogram = project.histograms()[0]
    print(
        "CORE_RECONVERGE_RESULT="
        + json.dumps(
            {
                "project": destination.name,
                "rwp_percent": histogram.get_wR(),
                "history": history,
                "fractions": histogram.ComputeMassFracs(),
            },
            sort_keys=True,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
