#!/usr/bin/env python3
"""Matched optional-term removals and phase leave-one-out tests."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from branch_profile import freeze
from learned.profile_regeneration import regenerate_profile


TESTS = {
    "U": "Reset the added Caglioti U term to its supplied value",
    "WU_nominal": "Reset the refined Gaussian W/U shape to supplied values",
    "polarization": "Reset polarization to the supplied value",
    "X": "Remove the Lorentzian X term",
    "shift": "Remove specimen displacement",
    "strain": "Remove Sr3W2O9 isotropic microstrain",
    "texture": "Remove Sr3W2O9 March-Dollase texture",
    "srwo4_O": "Restore source SrWO4 oxygen coordinates",
    "sr3_heavy": "Restore source Sr3W2O9 Sr/W coordinates",
    "leave_SrWO4": "Disable SrWO4",
    "leave_WO3": "Disable WO3",
    "leave_Sr3W2O9": "Disable Sr3W2O9",
}


def profile_rwp(project: G2sc.G2Project) -> float:
    histogram = project.histograms()[0]
    x, observed, weight, calculated = histogram.data["data"][1][:4]
    lower, upper = np.searchsorted(x, histogram.data["Limits"][1])
    numerator = np.sum(
        weight[lower:upper] * (observed[lower:upper] - calculated[lower:upper]) ** 2
    )
    denominator = np.sum(weight[lower:upper] * observed[lower:upper] ** 2)
    return float(100.0 * np.sqrt(numerator / denominator))


def clone(source: Path, destination: Path) -> None:
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    project.save()


def apply_test(project: G2sc.G2Project, label: str) -> None:
    histogram = project.histograms()[0]
    instrument = histogram.InstrumentParameters
    if label == "U":
        instrument["U"][1] = instrument["U"][0]
    elif label == "WU_nominal":
        instrument["W"][1] = instrument["W"][0]
        instrument["U"][1] = instrument["U"][0]
    elif label == "polarization":
        instrument["Polariz."][1] = instrument["Polariz."][0]
    elif label == "X":
        instrument["X"][1] = 0.0
    elif label == "shift":
        histogram.SampleParameters["Shift"][0] = 0.0
    elif label == "strain":
        project.phase("Sr3W2O9_C2c").data["Histograms"][histogram.name][
            "Mustrain"
        ][1][0] = 0.0
    elif label == "texture":
        project.phase("Sr3W2O9_C2c").data["Histograms"][histogram.name][
            "Pref.Ori."
        ][1] = 1.0
    elif label == "srwo4_O":
        atoms = project.phase("SrWO4_scheelite").data["Atoms"]
        next(atom for atom in atoms if atom[0] == "O")[3:6] = [0.2497, 0.0925, 0.0421]
    elif label == "sr3_heavy":
        source = {
            "Sr1": [0.0, 0.24688, 0.25],
            "Sr2": [0.1044, 0.25091, 0.5653],
            "W1": [0.3011, 0.24703, 0.155199],
        }
        for atom in project.phase("Sr3W2O9_C2c").data["Atoms"]:
            if atom[0] in source:
                atom[3:6] = source[atom[0]]
    elif label.startswith("leave_"):
        phase_name = {
            "leave_SrWO4": "SrWO4_scheelite",
            "leave_WO3": "WO3_monoclinic",
            "leave_Sr3W2O9": "Sr3W2O9_C2c",
        }[label]
        hap = project.phase(phase_name).data["Histograms"][histogram.name]
        hap["Use"] = False
        hap["Scale"][:] = [0.0, False]
    else:
        raise ValueError(label)


def enable_core(project: G2sc.G2Project, stage: str) -> None:
    histogram = project.histograms()[0]
    if stage == "scales_background":
        histogram.Background[0][1] = True
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            if hap.get("Use", True):
                hap["Scale"][1] = True
    elif stage == "cells":
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            if hap.get("Use", True):
                phase.data["General"]["Cell"][0] = True
    else:
        raise ValueError(stage)


def refine_stage(project: G2sc.G2Project, destination: Path, stage: str, index: int):
    freeze(project)
    enable_core(project, stage)
    project.data["Controls"]["data"]["max cyc"] = 25
    project.save()
    stable = destination.with_name(f"{destination.stem}_{index}_stable.gpx")
    clone(destination, stable)
    best = profile_rwp(project)
    history = []
    for iteration in range(3):
        project.refine(printFile=str(destination.with_suffix(".lst")))
        current = float(project.histograms()[0].get_wR())
        status = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        message = str(status.get("msg", "") or "").lower()
        valid = (
            math.isfinite(current)
            and not status.get("SVD0", 0)
            and "dropped" not in message
            and "error" not in message
        )
        accepted = valid and current <= best + 0.002
        history.append(
            {
                "iteration": iteration,
                "rwp_percent": current,
                "accepted": accepted,
                "converged": status.get("converged"),
                "max_shift_esd": status.get("Max shft/sig"),
                "message": status.get("msg"),
            }
        )
        if not accepted:
            project = G2sc.G2Project(str(stable), newgpx=str(destination))
            project.save()
            break
        best = current
        project.save()
        clone(destination, stable)
        if status.get("converged") and abs(float(status.get("Max shft/sig") or 0)) < 0.05:
            break
    return project, history


def run(source: Path, label: str) -> dict:
    destination = source.with_name(f"matched_{label}.gpx")
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    freeze(project)
    apply_test(project, label)
    project.save()
    regenerate_profile(destination)
    project = G2sc.G2Project(str(destination))
    initial = profile_rwp(project)
    histories = []
    for index, stage in enumerate(
        ("scales_background", "cells", "scales_background", "cells"), start=1
    ):
        project, history = refine_stage(project, destination, stage, index)
        histories.append({"stage": stage, "history": history})
    freeze(project)
    project.save()
    histogram = project.histograms()[0]
    return {
        "label": label,
        "description": TESTS[label],
        "project": destination.name,
        "initial_rwp_percent": initial,
        "final_rwp_percent": profile_rwp(project),
        "fractions": histogram.ComputeMassFracs(),
        "histories": histories,
    }


def main() -> None:
    if len(sys.argv) < 3:
        raise SystemExit("usage: matched_model_tests.py SOURCE.gpx TEST [TEST ...]")
    source = Path(sys.argv[1]).resolve()
    labels = sys.argv[2:]
    unknown = [label for label in labels if label not in TESTS]
    if unknown:
        raise SystemExit(f"unknown tests: {unknown}")
    results = [run(source, label) for label in labels]
    print("MATCHED_MODEL_TEST_RESULT=" + json.dumps(results, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
