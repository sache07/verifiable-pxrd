#!/usr/bin/env python3
"""Reset inherited instrument profile/envelope terms to supplied nominal values."""

from __future__ import annotations

import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from branch_profile import freeze


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: reset_profile_baseline.py SOURCE.gpx DESTINATION.gpx")
    source = Path(sys.argv[1]).resolve()
    destination = Path(sys.argv[2]).resolve()
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    freeze(project)
    histogram = project.histograms()[0]
    for key in ("Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"):
        parameter = histogram.InstrumentParameters[key]
        parameter[1] = parameter[0]
        parameter[2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][1][0] = 10.0
        hap["Mustrain"][1][0] = 0.0
    project.save()
    print(destination)


if __name__ == "__main__":
    main()
