#!/usr/bin/env python3
"""Run one-parameter matched nuisance branches from a supplied GSAS-II project."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def freeze(project: G2sc.G2Project) -> None:
    histogram = project.histograms()[0]
    histogram.Background[0][1] = False
    for value in histogram.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in histogram.SampleParameters.values():
        if isinstance(value, list) and len(value) == 2:
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.data["Atoms"]:
            atom[2] = ""
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])


def configure(project: G2sc.G2Project, branch: str) -> None:
    histogram = project.histograms()[0]
    if branch in {"U", "V", "W", "X", "Y", "SH_L", "Polariz"}:
        key = {"SH_L": "SH/L", "Polariz": "Polariz."}.get(branch, branch)
        histogram.InstrumentParameters[key][2] = True
    elif branch == "UV":
        histogram.InstrumentParameters["U"][2] = True
        histogram.InstrumentParameters["V"][2] = True
    elif branch == "WU":
        histogram.InstrumentParameters["W"][2] = True
        histogram.InstrumentParameters["U"][2] = True
    elif branch == "WUPX":
        for key in ("W", "U", "Polariz.", "X"):
            histogram.InstrumentParameters[key][2] = True
    elif branch == "XY":
        histogram.InstrumentParameters["X"][2] = True
        histogram.InstrumentParameters["Y"][2] = True
    elif branch == "XY_neutral_micro":
        histogram.InstrumentParameters["X"][2] = True
        histogram.InstrumentParameters["Y"][2] = True
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1000.0
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
    elif branch == "roughness":
        histogram.SampleParameters["SurfRoughA"][:] = [0.5, True]
        histogram.SampleParameters["SurfRoughB"][:] = [0.1, True]
    else:
        raise ValueError(branch)


def run(source: Path, branch: str) -> dict:
    if source.stem == "angular_selected":
        stem = f"profile_{branch}"
    else:
        stem = f"{source.stem}_plus_{branch}"
    destination = source.with_name(stem + ".gpx")
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    freeze(project)
    configure(project, branch)
    project.data["Controls"]["data"]["max cyc"] = 20
    project.save()
    histogram = project.histograms()[0]
    history = []
    for iteration in range(6):
        project.refine(printFile=str(destination.with_suffix(".lst")))
        status = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        history.append(
            {
                "iteration": iteration,
                "rwp_percent": histogram.get_wR(),
                "converged": status.get("converged"),
                "svd": status.get("SVD0"),
                "max_shift_esd": status.get("Max shft/sig"),
                "message": status.get("msg"),
            }
        )
        if (
            status.get("converged")
            and not status.get("SVD0")
            and abs(float(status.get("Max shft/sig") or 0.0)) < 0.05
        ):
            break
    project.save()
    return {
        "branch": branch,
        "project": destination.name,
        "rwp_percent": histogram.get_wR(),
        "instrument": {
            key: value[1:]
            for key, value in histogram.InstrumentParameters.items()
            if isinstance(value, list) and len(value) >= 3 and value[2]
        },
        "sample": {
            key: value
            for key, value in histogram.SampleParameters.items()
            if isinstance(value, list) and len(value) == 2 and value[1]
        },
        "history": history,
    }


def main() -> None:
    if len(sys.argv) < 3:
        raise SystemExit("usage: branch_profile.py SOURCE.gpx BRANCH [BRANCH ...]")
    source = Path(sys.argv[1]).resolve()
    results = [run(source, branch) for branch in sys.argv[2:]]
    print("PROFILE_BRANCH_RESULT=" + json.dumps(results, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
