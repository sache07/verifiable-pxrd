#!/usr/bin/env python3
"""Build matched minimal GSAS-II branches for candidate phase inventories."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
HERE = Path(__file__).resolve().parent

MODELS = {
    "scheelite_only": [("1546036", "SrWO4_scheelite")],
    "wo3_clean": [("1546036", "SrWO4_scheelite"), ("2311041", "WO3_P21c")],
    "wo3_triclinic": [("1546036", "SrWO4_scheelite"), ("2106293", "WO3_P-1")],
    "wo3_tetragonal": [("1546036", "SrWO4_scheelite"), ("1521532", "WO3_P4ncc")],
    "srco3": [("1546036", "SrWO4_scheelite"), ("9008198", "SrCO3_Pnma")],
    "sr3w2o9": [("1546036", "SrWO4_scheelite"), ("2311977", "Sr3W2O9_C2c")],
    "srwo4_mono_wo3": [("1546037", "SrWO4_C2c"), ("2311041", "WO3_P21c")],
}


def cif_path(cod_id: str) -> Path:
    parts = [cod_id[0], cod_id[1:3], cod_id[3:5]]
    path = ROOT.joinpath(*parts, cod_id + ".cif")
    if not path.is_file():
        matches = list(ROOT.rglob(cod_id + ".cif"))
        if len(matches) != 1:
            raise FileNotFoundError(cod_id)
        return matches[0]
    return path


def covariance(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine(project: G2sc.G2Project, label: str, repeats: int = 2) -> None:
    for index in range(repeats):
        project.refine(printFile=str(HERE / f"screen_{label}.lst"))
        status = covariance(project)
        print(
            label,
            index,
            "Rwp",
            project.histograms()[0].get_wR(),
            "max_shift_esd",
            status.get("Max shft/sig"),
            "SVD",
            status.get("SVD0"),
        )


def build(label: str) -> dict:
    project_path = HERE / f"screen_{label}.gpx"
    project = G2sc.G2Project(newgpx=str(project_path))
    histogram = project.add_powder_histogram(
        str(HERE / "inputs" / "pattern.csv"),
        str(HERE / "cu_ka.instprm"),
        fmthint="comma",
    )
    for cod_id, name in MODELS[label]:
        project.add_phase(
            str(cif_path(cod_id)),
            phasename=name,
            histograms=[histogram],
            fmthint="CIF",
        )

    histogram.set_refinements(
        {
            "Limits": [10.05, 99.95],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [700, -500, 300, -180, 80, -60, 35, -30, 10, 10, -40, 40],
                "refine": True,
            },
        }
    )
    histogram.SampleParameters["Scale"][:] = [1.0, False]
    histogram.SampleParameters["Shift"][:] = [-580.0, False]
    histogram.InstrumentParameters["W"][1:] = [90.0, False]
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][:] = [7.0 if index == 0 else 0.6, True]
    project.data["Controls"]["data"]["max cyc"] = 30
    project.save()

    # Scales/background first at common fixed centroid and width settings.
    refine(project, label, repeats=1)
    project.save(str(HERE / f"screen_{label}_stable_scales.gpx"))

    # Then common displacement and all symmetry-allowed cell terms.
    histogram.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    refine(project, label, repeats=2)
    project.save(str(HERE / f"screen_{label}_stable_cells.gpx"))

    # Finally the same one-term global Gaussian-width nuisance model.
    histogram.InstrumentParameters["W"][2] = True
    refine(project, label, repeats=2)
    project.save(str(project_path))

    status = covariance(project)
    try:
        fractions = histogram.ComputeMassFracs()
    except Exception as error:
        fractions = {"error": repr(error)}
    return {
        "label": label,
        "project": project_path.name,
        "rwp_percent": histogram.get_wR(),
        "convergence": {
            key: status.get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp")
        },
        "shift_um": histogram.SampleParameters["Shift"][0],
        "W": histogram.InstrumentParameters["W"][1],
        "fractions": fractions,
        "phases": [
            {
                "name": phase.name,
                "scale": phase.data["Histograms"][histogram.name]["Scale"][0],
                "cell": phase.get_cell(),
            }
            for phase in project.phases()
        ],
    }


def main() -> None:
    labels = sys.argv[1:] or list(MODELS)
    summaries = []
    for label in labels:
        if label not in MODELS:
            raise SystemExit(f"unknown model {label!r}")
        summaries.append(build(label))
    print("SCREEN_RESULT=" + json.dumps(summaries, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
