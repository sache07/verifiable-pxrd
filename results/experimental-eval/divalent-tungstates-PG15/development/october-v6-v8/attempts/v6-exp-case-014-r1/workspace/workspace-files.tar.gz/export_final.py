#!/usr/bin/env python3
"""Freeze the selected GSAS-II model and export the required deliverables."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from branch_profile import freeze
from learned.profile_regeneration import regenerate_profile


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "final_angular.gpx"
FINAL = HERE / "final.gpx"

PHASE_INFO = {
    "SrWO4_scheelite": {
        "name": "strontium tungstate (scheelite)",
        "formula": "SrWO4",
        "cif_path": "SrWO4_scheelite.cif",
        "source_cod_id": "1546036",
    },
    "WO3_monoclinic": {
        "name": "tungsten trioxide (monoclinic)",
        "formula": "WO3",
        "cif_path": "WO3_monoclinic.cif",
        "source_cod_id": "2311041",
    },
    "Sr3W2O9_C2c": {
        "name": "tristrontium ditungstate",
        "formula": "Sr3W2O9",
        "cif_path": "Sr3W2O9_C2c.cif",
        "source_cod_id": "2311977",
    },
}


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    freeze(project)
    project.save()
    regenerate_profile(FINAL)
    project = G2sc.G2Project(str(FINAL))
    histogram = project.histograms()[0]

    for phase in project.phases():
        phase.export_CIF(str(HERE / PHASE_INFO[phase.name]["cif_path"]))

    x, observed, weights, calculated, background, difference = (
        np.asarray(values, dtype=float) for values in histogram.data["data"][1][:6]
    )
    lower_limit, upper_limit = map(float, histogram.data["Limits"][1])
    lower, upper = np.searchsorted(x, [lower_limit, upper_limit])
    fit_slice = slice(lower, upper)
    valid = (
        np.isfinite(observed[fit_slice])
        & np.isfinite(calculated[fit_slice])
        & np.isfinite(weights[fit_slice])
        & (weights[fit_slice] > 0.0)
    )
    obs = observed[fit_slice][valid]
    calc = calculated[fit_slice][valid]
    wt = weights[fit_slice][valid]
    residual = obs - calc
    chi_square = float(np.sum(wt * residual**2))
    rwp = float(100.0 * math.sqrt(chi_square / np.sum(wt * obs**2)))
    rp = float(100.0 * np.sum(np.abs(residual)) / np.sum(np.abs(obs)))
    covariance = project.data.get("Covariance", {}).get("data", {})
    nvars = int(covariance.get("Rvals", {}).get("Nvars", 0) or 0)
    nobs = int(valid.sum())
    dof = max(1, nobs - nvars)
    gof = float(math.sqrt(chi_square / dof))
    rexp = float(rwp / gof)

    with (HERE / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
                "weight",
                "in_refinement_range",
            ]
        )
        for index in range(len(x)):
            writer.writerow(
                [
                    f"{x[index]:.8f}",
                    f"{observed[index]:.10g}",
                    f"{calculated[index]:.10g}",
                    f"{observed[index] - calculated[index]:.10g}",
                    f"{background[index]:.10g}",
                    f"{weights[index]:.10g}",
                    "true" if lower <= index < upper else "false",
                ]
            )

    raw_fractions = {
        name: float(value[0]) for name, value in histogram.ComputeMassFracs().items()
    }
    total = sum(raw_fractions.values())
    phase_rows = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        cell = phase.get_cell()
        hap = phase.data["Histograms"][histogram.name]
        phase_rows.append(
            {
                "name": info["name"],
                "model_id": phase.name,
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": info["cif_path"],
                "weight_fraction": raw_fractions[phase.name] / total,
                "source_cod_id": info["source_cod_id"],
                "unit_cell": {
                    "a_angstrom": float(cell["length_a"]),
                    "b_angstrom": float(cell["length_b"]),
                    "c_angstrom": float(cell["length_c"]),
                    "alpha_deg": float(cell["angle_alpha"]),
                    "beta_deg": float(cell["angle_beta"]),
                    "gamma_deg": float(cell["angle_gamma"]),
                    "volume_angstrom3": float(cell["volume"]),
                },
                "rietveld_scale": float(hap["Scale"][0]),
            }
        )

    result = {
        "phases": phase_rows,
        "fraction_basis": "normalized over the three modeled crystalline phases; no amorphous correction or internal standard",
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "rexp_percent": rexp,
            "goodness_of_fit": gof,
            "weighted_chi_square": chi_square,
            "n_observations": nobs,
            "n_variables_in_last_refinement_stage": nvars,
            "two_theta_range_deg": [lower_limit, upper_limit],
        },
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "unresolved_components": [
            {
                "description": "Weak residual intensity compatible with several trace Sr-O candidates",
                "status": "not modeled or quantified",
                "reason": "No tested atomistic candidate reproduced its strongest reflections without strong absent predictions or instability.",
            }
        ],
        "model_uncertainty": {
            "WO3_polymorph": "Monoclinic P21/c is weakly preferred, but a triclinic WO3 model is near-tied and the polymorph assignment is not unique from this powder pattern alone.",
            "fractions": "Statistical scale uncertainties understate model/systematic uncertainty because no pointwise standard uncertainties, internal standard, or amorphous model were supplied.",
        },
    }
    (HERE / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=False) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
