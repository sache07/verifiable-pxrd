#!/usr/bin/env python3
"""Prepare matched phase-replacement projects from a mature GSAS-II model."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from branch_profile import freeze


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

REPLACEMENTS = {
    "wo3_triclinic": ("WO3_monoclinic", "2106293", "WO3_triclinic"),
    "wo3_tetragonal": ("WO3_monoclinic", "1521532", "WO3_tetragonal"),
    "srwo4_monoclinic": ("SrWO4_scheelite", "1546037", "SrWO4_monoclinic"),
}


def cif_path(cod_id: str) -> Path:
    path = ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def prepare(source: Path, label: str) -> dict:
    old_name, cod_id, new_name = REPLACEMENTS[label]
    destination = source.with_name(f"replacement_{label}_start.gpx")
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    histogram = project.histograms()[0]
    old_phase = project.phase(old_name)
    old_scale = float(old_phase.data["Histograms"][histogram.name]["Scale"][0])

    del project.data["Phases"][old_name]
    histogram.data.get("Reflection Lists", {}).pop(old_name, None)
    for item in project.names:
        if item and item[0] == "Phases" and old_name in item:
            item.remove(old_name)
            break
    project.save()

    # Reload after deletion so GSAS-II rebuilds wrapper/index bookkeeping.
    project = G2sc.G2Project(str(destination))
    histogram = project.histograms()[0]
    phase = project.add_phase(
        str(cif_path(cod_id)),
        phasename=new_name,
        histograms=[histogram],
        fmthint="CIF",
    )
    freeze(project)
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"][:] = [old_scale, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    project.save()
    return {
        "label": label,
        "source": source.name,
        "project": destination.name,
        "removed": old_name,
        "added": new_name,
        "cod_id": cod_id,
        "initial_scale": old_scale,
        "phases": [item.name for item in project.phases()],
    }


def main() -> None:
    if len(sys.argv) < 3:
        raise SystemExit(
            "usage: prepare_replacement.py SOURCE.gpx REPLACEMENT [REPLACEMENT ...]"
        )
    source = Path(sys.argv[1]).resolve()
    unknown = [item for item in sys.argv[2:] if item not in REPLACEMENTS]
    if unknown:
        raise SystemExit(f"unknown replacements: {unknown}")
    print(
        "REPLACEMENT_PREP_RESULT="
        + json.dumps([prepare(source, item) for item in sys.argv[2:]], sort_keys=True)
    )


if __name__ == "__main__":
    main()
