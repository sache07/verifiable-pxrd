#!/usr/bin/env python3
"""Reconverge core Rietveld terms with stable snapshots and rollback on regressions."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from branch_profile import freeze


def covariance(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_copy(source: Path, destination: Path) -> None:
    clone = G2sc.G2Project(str(source), newgpx=str(destination))
    clone.save()


def profile_rwp(project: G2sc.G2Project) -> float:
    """Compute Rwp from the saved profile, avoiding a stale cached R value."""
    histogram = project.histograms()[0]
    x, observed, weight, calculated = histogram.data["data"][1][:4]
    lower, upper = np.searchsorted(x, histogram.data["Limits"][1])
    numerator = np.sum(weight[lower:upper] * (observed[lower:upper] - calculated[lower:upper]) ** 2)
    denominator = np.sum(weight[lower:upper] * observed[lower:upper] ** 2)
    return float(100.0 * np.sqrt(numerator / denominator))


def enable(project: G2sc.G2Project, stage: str) -> None:
    histogram = project.histograms()[0]
    if stage == "scales_background":
        histogram.Background[0][1] = True
        for phase in project.phases():
            phase.data["Histograms"][histogram.name]["Scale"][1] = True
    elif stage == "cells":
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
    else:
        raise ValueError(stage)


def run_stage(
    project: G2sc.G2Project,
    destination: Path,
    stage: str,
    index: int,
    maximum: int = 10,
) -> tuple[G2sc.G2Project, dict]:
    freeze(project)
    enable(project, stage)
    project.save()
    stable = destination.with_name(f"{destination.stem}_{index}_{stage}_stable.gpx")
    stable_copy(destination, stable)
    best = profile_rwp(project)
    history = []
    for iteration in range(maximum):
        project.refine(printFile=str(destination.with_suffix(".lst")))
        current = float(project.histograms()[0].get_wR())
        status = covariance(project)
        message = str(status.get("msg", "") or "").lower()
        valid = (
            math.isfinite(current)
            and not status.get("SVD0", 0)
            and "dropped" not in message
            and "error" not in message
        )
        accepted = valid and current <= best + 0.001
        history.append(
            {
                "iteration": iteration,
                "rwp_percent": current,
                "accepted": accepted,
                **{
                    key: status.get(key)
                    for key in ("converged", "SVD0", "Max shft/sig", "msg")
                },
            }
        )
        if not accepted:
            project = G2sc.G2Project(str(stable), newgpx=str(destination))
            project.save()
            break
        best = current
        project.save()
        stable_copy(destination, stable)
        if (
            status.get("converged")
            and abs(float(status.get("Max shft/sig") or 0.0)) < 0.05
        ):
            break
    return project, {"stage": stage, "history": history, "best_rwp_percent": best}


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: core_reconverge_safe.py SOURCE.gpx DESTINATION.gpx")
    source = Path(sys.argv[1]).resolve()
    destination = Path(sys.argv[2]).resolve()
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    project.data["Controls"]["data"]["max cyc"] = 30
    project.save()
    records = []
    for index, stage in enumerate(
        ("scales_background", "cells", "scales_background", "cells"), start=1
    ):
        project, record = run_stage(project, destination, stage, index)
        records.append(record)
    freeze(project)
    project.save()
    histogram = project.histograms()[0]
    print(
        "SAFE_CORE_RESULT="
        + json.dumps(
            {
                "project": destination.name,
                "rwp_percent": profile_rwp(project),
                "fractions": histogram.ComputeMassFracs(),
                "stages": records,
            },
            sort_keys=True,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
