#!/usr/bin/env python3
"""Matched tests of minimal global peak-width terms."""

from __future__ import annotations

from GSASII import GSASIIscriptable as G2sc


def status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def converge(project: G2sc.G2Project, maximum_blocks: int = 8) -> None:
    project.set_Controls("cycles", 12)
    for _ in range(maximum_blocks):
        project.refine()
        result = status(project)
        if (
            result.get("converged")
            and not result.get("SVD0")
            and abs(float(result.get("Max shft/sig") or 999.0)) < 0.05
        ):
            return


def summarize(project: G2sc.G2Project, label: str) -> dict:
    histogram = project.histograms()[0]
    result = status(project)
    return {
        "label": label,
        "rwp": histogram.get_wR(),
        "instrument": {
            key: list(histogram.InstrumentParameters[key])
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "status": {
            key: result.get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg")
        },
    }


def make_baseline() -> G2sc.G2Project:
    project = G2sc.G2Project("stages/triclinic_inventory_stable.gpx")
    histogram = project.histograms()[0]
    for phase in project.phases():
        phase.setSampleProfile(histogram, "size", "isotropic", 10.0, LGmix=1.0)
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    for parameter in histogram.InstrumentParameters.values():
        if isinstance(parameter, list) and len(parameter) >= 3:
            parameter[2] = False
    project.save("stages/profile_nosample_pre.gpx")
    converge(project)
    project.save("stages/profile_nosample_baseline.gpx")
    return project


def branch(baseline: G2sc.G2Project, label: str, terms: dict[str, float]) -> dict:
    path = f"stages/profile_{label}.gpx"
    prepath = f"stages/profile_{label}_pre.gpx"
    baseline.save(prepath)
    project = G2sc.G2Project(prepath)
    histogram = project.histograms()[0]
    for key, value in terms.items():
        histogram.InstrumentParameters[key][1] = float(value)
        histogram.InstrumentParameters[key][2] = True
    converge(project)
    project.save(path)
    return summarize(project, label)


def main() -> None:
    baseline = make_baseline()
    print("PROFILE_RESULT", summarize(baseline, "no_sample_baseline"), flush=True)
    independent = {
        "W": {"W": 100.0},
        "U": {"U": 20.0},
        "X": {"X": 10.0},
        "Y": {"Y": 10.0},
    }
    results = {}
    for label, terms in independent.items():
        try:
            results[label] = branch(baseline, label, terms)
            print("PROFILE_RESULT", results[label], flush=True)
        except Exception as error:
            print("PROFILE_ERROR", label, repr(error), flush=True)
    joint_terms = {
        "WX": {
            "W": results.get("W", {}).get("instrument", {}).get("W", [0, 100])[1],
            "X": results.get("X", {}).get("instrument", {}).get("X", [0, 10])[1],
        },
        "WY": {
            "W": results.get("W", {}).get("instrument", {}).get("W", [0, 100])[1],
            "Y": results.get("Y", {}).get("instrument", {}).get("Y", [0, 10])[1],
        },
        "WU": {
            "W": results.get("W", {}).get("instrument", {}).get("W", [0, 100])[1],
            "U": results.get("U", {}).get("instrument", {}).get("U", [0, 20])[1],
        },
    }
    for label, terms in joint_terms.items():
        try:
            print("PROFILE_RESULT", branch(baseline, label, terms), flush=True)
        except Exception as error:
            print("PROFILE_ERROR", label, repr(error), flush=True)


if __name__ == "__main__":
    main()
