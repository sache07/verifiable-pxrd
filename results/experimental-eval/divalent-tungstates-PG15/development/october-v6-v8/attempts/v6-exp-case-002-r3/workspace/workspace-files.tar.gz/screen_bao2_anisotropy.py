#!/usr/bin/env python3
"""Matched uniaxial BaO2 broadening branches along the tetragonal c axis."""

from GSASII import GSASIIscriptable as G2sc


def run(term: str) -> None:
    source = G2sc.G2Project("stages/envelope_polarization.gpx")
    prepath = f"stages/broad_bao2_uniaxial_{term}_pre.gpx"
    source.save(prepath)
    project = G2sc.G2Project(prepath)
    histogram = project.histograms()[0]
    phase = project.phase("BaO2")
    if term == "size":
        phase.setSampleProfile(
            histogram, "size", "uniaxial", 0.1, 1.0, [0, 0, 1], LGmix=1.0
        )
        phase.set_HAP_refinements(
            {"Size": {"type": "uniaxial", "refine": True, "direction": [0, 0, 1]}}
        )
    else:
        phase.setSampleProfile(
            histogram,
            "microstrain",
            "uniaxial",
            500.0,
            500.0,
            [0, 0, 1],
            LGmix=1.0,
        )
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "refine": True,
                    "direction": [0, 0, 1],
                }
            }
        )
    project.set_Controls("cycles", 12)
    for _ in range(8):
        project.refine()
        result = project.data["Covariance"]["data"].get("Rvals", {})
        if (
            result.get("converged")
            and not result.get("SVD0")
            and abs(float(result.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(f"stages/broad_bao2_uniaxial_{term}.gpx")
    result = project.data["Covariance"]["data"].get("Rvals", {})
    hap = phase.data["Histograms"][histogram.name]
    print(
        "UNIAXIAL_RESULT",
        {
            "term": term,
            "rwp": histogram.get_wR(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "mass_fractions": histogram.ComputeMassFracs(),
            "status": {
                key: result.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
        },
        flush=True,
    )


if __name__ == "__main__":
    run("size")
    run("strain")
