#!/usr/bin/env python3
"""Matched polarization and surface-roughness envelope branches."""

from GSASII import GSASIIscriptable as G2sc


def refine_branch(label: str, configure) -> None:
    source = G2sc.G2Project("stages/profile_XY.gpx")
    prepath = f"stages/envelope_{label}_pre.gpx"
    source.save(prepath)
    project = G2sc.G2Project(prepath)
    histogram = project.histograms()[0]
    configure(histogram)
    project.set_Controls("cycles", 12)
    for _ in range(8):
        project.refine()
        status = project.data["Covariance"]["data"].get("Rvals", {})
        if (
            status.get("converged")
            and not status.get("SVD0")
            and abs(float(status.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(f"stages/envelope_{label}.gpx")
    status = project.data["Covariance"]["data"].get("Rvals", {})
    print(
        "ENVELOPE_RESULT",
        {
            "label": label,
            "rwp": histogram.get_wR(),
            "polarization": list(histogram.InstrumentParameters["Polariz."]),
            "surface_roughness_A": list(histogram.SampleParameters["SurfRoughA"]),
            "surface_roughness_B": list(histogram.SampleParameters["SurfRoughB"]),
            "status": {
                key: status.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
        },
        flush=True,
    )


def main() -> None:
    def polarization(histogram):
        histogram.InstrumentParameters["Polariz."][2] = True

    def roughness(histogram):
        histogram.SampleParameters["SurfRoughA"][:] = [0.9, True]
        histogram.SampleParameters["SurfRoughB"][:] = [0.1, True]

    refine_branch("polarization", polarization)
    refine_branch("roughness", roughness)


if __name__ == "__main__":
    main()
