#!/usr/bin/env python3
"""Matched minimal-nuisance GSAS-II screen of valid WO3 models."""

from __future__ import annotations

import copy
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
BAO2 = ROOT / "1/01/01/1010113.cif"
WO3_MODELS = {
    "2311041_monoclinic": ROOT / "2/31/10/2311041.cif",
    "2106293_triclinic": ROOT / "2/10/62/2106293.cif",
    "2107312_orthorhombic": ROOT / "2/10/73/2107312.cif",
    "1563541_monoclinic_alt": ROOT / "1/56/35/1563541.cif",
    "1521532_tetragonal": ROOT / "1/52/15/1521532.cif",
    "1521533_tetragonal": ROOT / "1/52/15/1521533.cif",
    "1004057_hexagonal": ROOT / "1/00/40/1004057.cif",
}


def fit_model(label: str, cif: Path, template: G2sc.G2Project) -> dict:
    project = G2sc.G2Project(newgpx=f"stages/model_{label}.gpx")
    histogram = project.add_powder_histogram(
        "pattern.xye", "instrument.instprm", fmthint="Topas"
    )
    bao2 = project.add_phase(
        str(BAO2), phasename="BaO2", histograms=[histogram], fmthint="CIF"
    )
    wo3 = project.add_phase(
        str(cif), phasename="WO3", histograms=[histogram], fmthint="CIF"
    )

    source_histogram = template.histograms()[0]
    histogram.data["Background"] = copy.deepcopy(source_histogram.data["Background"])
    histogram.data["Background"][0][1] = True
    histogram.SampleParameters["Scale"][:] = [1.0, False]
    histogram.SampleParameters["Shift"][:] = list(
        source_histogram.SampleParameters["Shift"]
    )
    histogram.SampleParameters["Shift"][1] = True

    source_bao2 = template.phase("BaO2")
    bao2.data["General"]["Cell"][1:8] = copy.deepcopy(
        source_bao2.data["General"]["Cell"][1:8]
    )
    for phase, scale in ((bao2, 24.0), (wo3, 8.0)):
        phase.setSampleProfile(histogram, "size", "isotropic", 0.03, LGmix=1.0)
        phase.set_HAP_refinements({"Scale": True})
        phase.data["Histograms"][histogram.name]["Scale"][0] = scale
        phase.set_refinements({"Cell": True})

    project.set_Controls("cycles", 12)
    project.save(f"stages/model_{label}_pre.gpx")
    for _ in range(5):
        project.refine()
        status = project.data["Covariance"]["data"].get("Rvals", {})
        if (
            status.get("converged")
            and not status.get("SVD0")
            and abs(float(status.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(f"stages/model_{label}.gpx")
    status = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "label": label,
        "rwp": histogram.get_wR(),
        "mass_fractions": histogram.ComputeMassFracs(),
        "status": {
            key: status.get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg")
        },
        "shift": list(histogram.SampleParameters["Shift"]),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "scales": {
            phase.name: list(phase.data["Histograms"][histogram.name]["Scale"])
            for phase in project.phases()
        },
    }


def main() -> None:
    template = G2sc.G2Project("stages/angular_selected.gpx")
    for label, cif in WO3_MODELS.items():
        try:
            print("MODEL_RESULT", fit_model(label, cif, template), flush=True)
        except Exception as error:
            print("MODEL_ERROR", label, repr(error), flush=True)


if __name__ == "__main__":
    main()
