#!/usr/bin/env python3
"""Conservative coordinate branches for the selected two-phase model."""

from GSASII import GSASIIscriptable as G2sc


SOURCE = "stages/texture_joint_bao2_001.gpx"


def run(label: str, phase_name: str, element: str) -> None:
    source = G2sc.G2Project(SOURCE)
    prepath = f"stages/coords_{label}_pre.gpx"
    source.save(prepath)
    project = G2sc.G2Project(prepath)
    histogram = project.histograms()[0]
    phase = project.phase(phase_name)
    for atom in phase.data["Atoms"]:
        atom[2] = "X" if atom[1].startswith(element) else ""
    project.set_Controls("cycles", 12)
    for _ in range(8):
        project.refine()
        result = project.data["Covariance"]["data"].get("Rvals", {})
        if (
            result.get("converged")
            and not result.get("SVD0")
            and abs(float(result.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(f"stages/coords_{label}.gpx")
    result = project.data["Covariance"]["data"].get("Rvals", {})
    print(
        "COORD_RESULT",
        {
            "label": label,
            "rwp": histogram.get_wR(),
            "mass_fractions": histogram.ComputeMassFracs(),
            "atoms": [
                {
                    "label": atom[0],
                    "type": atom[1],
                    "flags": atom[2],
                    "xyz": atom[3:6],
                }
                for atom in phase.data["Atoms"]
            ],
            "status": {
                key: result.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
        },
        flush=True,
    )


if __name__ == "__main__":
    run("bao2_oxygen", "BaO2", "O")
    run("wo3_tungsten", "WO3", "W")
