#!/usr/bin/env python3
"""Independent phase-by-phase isotropic size and microstrain branches."""

from __future__ import annotations

from GSASII import GSASIIscriptable as G2sc


SOURCE = "stages/envelope_polarization.gpx"


def run(phase_name: str, term: str) -> None:
    label = f"{phase_name}_{term}".replace("O", "o").lower()
    source = G2sc.G2Project(SOURCE)
    prepath = f"stages/broad_{label}_pre.gpx"
    source.save(prepath)
    project = G2sc.G2Project(prepath)
    histogram = project.histograms()[0]
    phase = project.phase(phase_name)
    if term == "size":
        phase.setSampleProfile(histogram, "size", "isotropic", 0.1, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}
        )
    elif term == "strain":
        phase.setSampleProfile(
            histogram, "microstrain", "isotropic", 500.0, LGmix=1.0
        )
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    else:
        raise ValueError(term)

    project.set_Controls("cycles", 12)
    for _ in range(8):
        project.refine()
        status = project.data["Covariance"]["data"].get("Rvals", {})
        if (
            status.get("converged")
            and not status.get("SVD0")
            and abs(float(status.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(f"stages/broad_{label}.gpx")
    status = project.data["Covariance"]["data"].get("Rvals", {})
    print(
        "BROADENING_RESULT",
        {
            "phase": phase_name,
            "term": term,
            "rwp": histogram.get_wR(),
            "size": phase.data["Histograms"][histogram.name]["Size"],
            "mustrain": phase.data["Histograms"][histogram.name]["Mustrain"],
            "mass_fractions": histogram.ComputeMassFracs(),
            "status": {
                key: status.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
        },
        flush=True,
    )


def main() -> None:
    for phase_name in ("BaO2", "WO3"):
        for term in ("size", "strain"):
            try:
                run(phase_name, term)
            except Exception as error:
                print("BROADENING_ERROR", phase_name, term, repr(error), flush=True)


if __name__ == "__main__":
    main()
