#!/usr/bin/env python3
"""Downstream recheck of unretained global and phase broadening terms."""

from __future__ import annotations

import sys

from GSASII import GSASIIscriptable as G2sc


SOURCE = "stages/mature_u.gpx"


def apply_branch(project: G2sc.G2Project, label: str) -> None:
    histogram = project.histograms()[0]
    if label == "global_u":
        histogram.InstrumentParameters["U"][2] = True
    elif label == "global_w":
        histogram.InstrumentParameters["W"][2] = True
    elif label == "bao2_strain":
        phase = project.phase("BaO2")
        phase.setSampleProfile(histogram, "microstrain", "isotropic", 500.0, LGmix=1.0)
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    elif label == "wo3_size":
        phase = project.phase("WO3")
        phase.setSampleProfile(histogram, "size", "isotropic", 0.1, LGmix=1.0)
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    elif label == "wo3_strain":
        phase = project.phase("WO3")
        phase.setSampleProfile(histogram, "microstrain", "isotropic", 500.0, LGmix=1.0)
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    elif label == "bao2_uniaxial_size":
        phase = project.phase("BaO2")
        current = phase.data["Histograms"][histogram.name]["Size"][1][0]
        phase.setSampleProfile(
            histogram, "size", "uniaxial", current, current, [0, 0, 1], LGmix=1.0
        )
        phase.set_HAP_refinements(
            {"Size": {"type": "uniaxial", "refine": True, "direction": [0, 0, 1]}}
        )
    else:
        raise KeyError(label)


def run(label: str) -> None:
    source = G2sc.G2Project(SOURCE)
    baseline_path = f"stages/recheck_{label}_baseline.gpx"
    source.save(baseline_path)
    project = G2sc.G2Project(baseline_path)
    apply_branch(project, label)
    project.save(f"stages/recheck_{label}_pre.gpx")
    project.set_Controls("cycles", 12)
    for _ in range(8):
        project.refine()
        status = project.data["Covariance"]["data"].get("Rvals", {})
        if (
            status.get("converged")
            and not status.get("SVD0")
            and abs(float(status.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(f"stages/recheck_{label}.gpx")
    histogram = project.histograms()[0]
    status = project.data["Covariance"]["data"].get("Rvals", {})
    print(
        "PROFILE_RECHECK_RESULT",
        {
            "branch": label,
            "rwp": histogram.get_wR(),
            "instrument": {
                key: histogram.InstrumentParameters[key]
                for key in ("U", "V", "W", "X", "Y")
            },
            "phase_profiles": {
                phase.name: {
                    "size": phase.data["Histograms"][histogram.name]["Size"],
                    "mustrain": phase.data["Histograms"][histogram.name]["Mustrain"],
                }
                for phase in project.phases()
            },
            "mass_fractions": histogram.ComputeMassFracs(),
            "status": {
                key: status.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
        },
        flush=True,
    )


if __name__ == "__main__":
    branches = tuple(sys.argv[1:]) or (
        "global_u",
        "global_w",
        "bao2_strain",
        "wo3_size",
        "wo3_strain",
        "bao2_uniaxial_size",
    )
    for name in branches:
        try:
            run(name)
        except Exception as error:
            print("PROFILE_RECHECK_ERROR", name, repr(error), flush=True)
