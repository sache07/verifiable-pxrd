#!/usr/bin/env python3
"""One-axis-at-a-time March-Dollase preferred-orientation screen."""

from GSASII import GSASIIscriptable as G2sc


SOURCE = "stages/broad_bao2_size.gpx"
BRANCHES = (
    ("BaO2", (0, 0, 1)),
    ("BaO2", (1, 0, 0)),
    ("WO3", (1, 0, 0)),
    ("WO3", (0, 1, 0)),
    ("WO3", (0, 0, 1)),
)


def run(phase_name: str, axis: tuple[int, int, int]) -> None:
    tag = "".join(str(value) for value in axis)
    label = f"{phase_name.lower()}_{tag}"
    source = G2sc.G2Project(SOURCE)
    prepath = f"stages/texture_{label}_pre.gpx"
    source.save(prepath)
    project = G2sc.G2Project(prepath)
    histogram = project.histograms()[0]
    phase = project.phase(phase_name)
    orientation = phase.data["Histograms"][histogram.name]["Pref.Ori."]
    orientation[0] = "MD"
    orientation[1] = 1.0
    orientation[2] = True
    orientation[3] = list(axis)
    project.set_Controls("cycles", 12)
    for _ in range(8):
        project.refine()
        result = project.data["Covariance"]["data"].get("Rvals", {})
        if (
            result.get("converged")
            and not result.get("SVD0")
            and abs(float(result.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(f"stages/texture_{label}.gpx")
    result = project.data["Covariance"]["data"].get("Rvals", {})
    print(
        "TEXTURE_RESULT",
        {
            "phase": phase_name,
            "axis": axis,
            "rwp": histogram.get_wR(),
            "orientation": orientation,
            "mass_fractions": histogram.ComputeMassFracs(),
            "status": {
                key: result.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
        },
        flush=True,
    )


if __name__ == "__main__":
    for phase_name, axis in BRANCHES:
        try:
            run(phase_name, axis)
        except Exception as error:
            print("TEXTURE_ERROR", phase_name, axis, repr(error), flush=True)
