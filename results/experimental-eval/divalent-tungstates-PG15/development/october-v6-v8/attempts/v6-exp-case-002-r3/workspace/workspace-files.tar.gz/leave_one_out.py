#!/usr/bin/env python3
"""Matched leave-one-term-out tests from the mature two-phase model."""

from __future__ import annotations

import math
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE = "stages/angular_final_u.gpx"


def remove_term(project: G2sc.G2Project, label: str) -> None:
    histogram = project.histograms()[0]
    instrument = histogram.InstrumentParameters
    if label == "x_profile":
        instrument["X"][1:] = [0.0, False]
    elif label == "y_profile":
        instrument["Y"][1:] = [0.0, False]
    elif label == "u_profile":
        instrument["U"][1:] = [2.0, False]
    elif label == "fixed_adp_baseline":
        for atom in project.phase("WO3").data["Atoms"]:
            atom[2] = ""
    elif label == "y_profile_fixed_adp":
        instrument["Y"][1:] = [0.0, False]
        for atom in project.phase("WO3").data["Atoms"]:
            atom[2] = ""
    elif label == "polarization":
        instrument["Polariz."][1:] = [0.7, False]
    elif label == "specimen_shift":
        histogram.SampleParameters["Shift"] = [0.0, False]
    elif label == "bao2_size":
        size = project.phase("BaO2").data["Histograms"][histogram.name]["Size"]
        size[1][0] = 10.0
        size[2][0] = False
    elif label == "bao2_texture":
        pref = project.phase("BaO2").data["Histograms"][histogram.name]["Pref.Ori."]
        pref[1] = 1.0
        pref[2] = False
    elif label == "wo3_texture":
        pref = project.phase("WO3").data["Histograms"][histogram.name]["Pref.Ori."]
        pref[1] = 1.0
        pref[2] = False
    elif label == "bao2_oxygen_coordinate":
        oxygen = project.phase("BaO2").data["Atoms"][1]
        oxygen[5] = 0.404
        oxygen[2] = ""
    elif label == "wo3_common_adps":
        for atom in project.phase("WO3").data["Atoms"]:
            atom[10] = 0.004 if atom[1].startswith("W") else 0.008
            atom[2] = ""
    else:
        raise KeyError(label)


def maximum_correlation(project: G2sc.G2Project) -> tuple[float | None, tuple[str, str] | None]:
    covariance = project.data["Covariance"]["data"]
    matrix = covariance.get("covMatrix")
    variables = covariance.get("varyList")
    if matrix is None or not variables:
        return None, None
    sigma = np.sqrt(np.diag(matrix))
    correlation = matrix / np.outer(sigma, sigma)
    best = (0.0, None)
    for row in range(len(variables)):
        for column in range(row):
            value = float(abs(correlation[row, column]))
            if math.isfinite(value) and value > best[0]:
                best = (value, (variables[column], variables[row]))
    return best


def run(label: str) -> None:
    baseline = G2sc.G2Project(SOURCE)
    baseline.save(f"stages/loo_{label}_baseline.gpx")
    project = G2sc.G2Project(f"stages/loo_{label}_baseline.gpx")
    remove_term(project, label)
    project.save(f"stages/loo_{label}_pre.gpx")
    project.set_Controls("cycles", 12)
    for _ in range(8):
        project.refine()
        result = project.data["Covariance"]["data"].get("Rvals", {})
        if (
            result.get("converged")
            and not result.get("SVD0")
            and abs(float(result.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(f"stages/loo_{label}.gpx")
    histogram = project.histograms()[0]
    result = project.data["Covariance"]["data"].get("Rvals", {})
    print(
        "LEAVE_ONE_OUT_RESULT",
        {
            "term": label,
            "rwp": histogram.get_wR(),
            "mass_fractions": histogram.ComputeMassFracs(),
            "maximum_correlation": maximum_correlation(project),
            "status": {
                key: result.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
        },
        flush=True,
    )


if __name__ == "__main__":
    default_names = (
        "x_profile",
        "y_profile",
        "polarization",
        "specimen_shift",
        "bao2_size",
        "bao2_texture",
        "wo3_texture",
        "bao2_oxygen_coordinate",
        "wo3_common_adps",
    )
    for name in (tuple(sys.argv[1:]) or default_names):
        try:
            run(name)
        except Exception as error:
            print("LEAVE_ONE_OUT_ERROR", name, repr(error), flush=True)
