#!/usr/bin/env python3
"""Refine chemically grouped isotropic ADPs for the selected WO3 model."""

from GSASII import GSASIIscriptable as G2sc


SOURCE = "stages/coords_bao2_oxygen.gpx"
PRE = "stages/adp_common_pre.gpx"
OUTPUT = "stages/adp_common.gpx"


def main() -> None:
    source = G2sc.G2Project(SOURCE)
    wo3 = source.phase("WO3")
    tungsten = []
    oxygen = []
    for index, atom in enumerate(wo3.data["Atoms"]):
        atom[2] = "U"
        if atom[1].startswith("W"):
            atom[10] = 0.004
            tungsten.append(index)
        elif atom[1].startswith("O"):
            atom[10] = 0.008
            oxygen.append(index)
        else:
            raise ValueError(f"Unexpected WO3 atom type: {atom[1]}")
    source.save(PRE)

    project = G2sc.G2Project(PRE)
    pid = project.phase("WO3").data["pId"]
    project.add_EquivConstr(tuple(f"{pid}::AUiso:{i}" for i in tungsten))
    project.add_EquivConstr(tuple(f"{pid}::AUiso:{i}" for i in oxygen))
    project.set_Controls("cycles", 12)
    for _ in range(10):
        project.refine()
        result = project.data["Covariance"]["data"].get("Rvals", {})
        if (
            result.get("converged")
            and not result.get("SVD0")
            and abs(float(result.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(OUTPUT)

    histogram = project.histograms()[0]
    phase = project.phase("WO3")
    result = project.data["Covariance"]["data"].get("Rvals", {})
    print(
        "COMMON_ADP_RESULT",
        {
            "rwp": histogram.get_wR(),
            "mass_fractions": histogram.ComputeMassFracs(),
            "adps": [(a[0], a[1], a[2], a[10]) for a in phase.data["Atoms"]],
            "status": {
                key: result.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
        },
        flush=True,
    )


if __name__ == "__main__":
    main()
