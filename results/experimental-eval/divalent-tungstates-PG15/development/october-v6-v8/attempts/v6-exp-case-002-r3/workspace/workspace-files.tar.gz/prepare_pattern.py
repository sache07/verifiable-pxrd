#!/usr/bin/env python3
"""Convert the supplied two-column count data to GSAS-II XYE format."""

import csv
import math
from pathlib import Path


source = Path("inputs/pattern.csv")
destination = Path("pattern.xye")

with source.open(newline="") as source_handle, destination.open("w") as output:
    reader = csv.DictReader(source_handle)
    for row in reader:
        angle = float(row["two_theta_deg"])
        counts = float(row["intensity"])
        # No pointwise uncertainties were supplied. Counting-statistical
        # sigma=sqrt(counts) is the explicit weighting convention used here.
        sigma = math.sqrt(max(counts, 1.0))
        output.write(f"{angle:.8f} {counts:.8f} {sigma:.8f}\n")
