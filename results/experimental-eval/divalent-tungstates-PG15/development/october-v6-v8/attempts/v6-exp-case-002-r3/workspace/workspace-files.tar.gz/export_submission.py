#!/usr/bin/env python3
"""Export the frozen GSAS-II model into the requested submission files."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PROJECT = Path("final.gpx")
FORMULAS = {"BaO2": "BaO2", "WO3": "WO3"}
CIF_PATHS = {"BaO2": Path("BaO2.cif"), "WO3": Path("WO3.cif")}


def main() -> None:
    project = G2sc.G2Project(str(PROJECT))
    histogram = project.histograms()[0]
    fractions = histogram.ComputeMassFracs()
    total = sum(value[0] for value in fractions.values())
    if not np.isfinite(total) or total <= 0:
        raise ValueError(f"Invalid crystalline fraction total: {total}")

    phase_rows = []
    for phase in project.phases():
        if phase.name not in CIF_PATHS:
            raise ValueError(f"Unexpected phase in final project: {phase.name}")
        cif_path = CIF_PATHS[phase.name]
        phase.export_CIF(str(cif_path))
        fraction, fraction_esd = fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phase_rows.append(
            {
                "name": phase.name,
                "formula": FORMULAS[phase.name],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": str(cif_path),
                "weight_fraction": float(fraction / total),
                "weight_fraction_esd": float(fraction_esd / total),
                "cell": {key: float(value) for key, value in cell.items()},
                "cell_esd": {key: float(value) for key, value in cell_esd.items()},
            }
        )

    arrays = histogram.data["data"][1]
    x, observed, weights, calculated, background, difference = (
        np.asarray(values, dtype=float) for values in arrays[:6]
    )
    if not np.allclose(difference, observed - calculated, rtol=0.0, atol=1e-8):
        raise ValueError("Saved difference profile is not observed minus calculated")
    with Path("fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_intensity",
                "background_intensity",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    covariance = project.data["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    n_observations = int(rvals["Nobs"])
    n_variables = int(rvals["Nvars"])
    chi_square = float(np.sum(weights * difference**2))
    rwp = float(
        100.0
        * np.sqrt(chi_square / np.sum(weights * observed**2))
    )
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    gof = float(np.sqrt(chi_square / (n_observations - n_variables)))
    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "expected_rwp_percent": rwp / gof,
            "goodness_of_fit": gof,
            "chi_square": chi_square,
            "n_observations": n_observations,
            "n_refined_variables": n_variables,
            "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
            "converged": bool(rvals.get("converged")),
            "svd_dropped_variables": int(rvals.get("SVD0", 0)),
        },
        "fraction_basis": "Normalized over the modeled crystalline phases only",
        "unresolved_components": [],
    }
    with Path("result.json").open("w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, sort_keys=False)
        stream.write("\n")

    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
