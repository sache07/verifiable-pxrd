#!/usr/bin/env python3
"""Retest the leading WO3 structure families with the mature nuisance model."""

from __future__ import annotations

import copy
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc


MATURE = "stages/angular_final_u.gpx"
MODELS = {
    "triclinic_2106293": "stages/model_2106293_triclinic.gpx",
    "monoclinic_2311041": "stages/model_2311041_monoclinic.gpx",
    "orthorhombic_2107312": "stages/model_2107312_orthorhombic.gpx",
}


def maximum_correlation(project: G2sc.G2Project) -> tuple[float, tuple[str, str] | None]:
    covariance = project.data["Covariance"]["data"]
    matrix = covariance.get("covMatrix")
    variables = covariance.get("varyList")
    if matrix is None or not variables:
        return 0.0, None
    sigma = np.sqrt(np.diag(matrix))
    correlation = matrix / np.outer(sigma, sigma)
    best = (0.0, None)
    for row in range(len(variables)):
        for column in range(row):
            value = float(abs(correlation[row, column]))
            if np.isfinite(value) and value > best[0]:
                best = (value, (variables[column], variables[row]))
    return best


def prepare(label: str, model_path: str) -> G2sc.G2Project:
    mature = G2sc.G2Project(MATURE)
    source = G2sc.G2Project(model_path)
    stable_path = f"stages/retest_{label}_stable.gpx"
    source.save(stable_path)
    project = G2sc.G2Project(stable_path)

    mature_hist = mature.histograms()[0]
    histogram = project.histograms()[0]
    histogram.data["Background"] = copy.deepcopy(mature_hist.data["Background"])
    histogram.data["Instrument Parameters"] = copy.deepcopy(
        mature_hist.data["Instrument Parameters"]
    )
    histogram.data["Sample Parameters"] = copy.deepcopy(
        mature_hist.data["Sample Parameters"]
    )
    histogram.SampleParameters["Scale"] = [1.0, False]

    mature_ba = mature.phase("BaO2")
    bao2 = project.phase("BaO2")
    bao2.data["Atoms"] = copy.deepcopy(mature_ba.data["Atoms"])
    bao2.data["General"]["Cell"] = copy.deepcopy(mature_ba.data["General"]["Cell"])
    bao2_hap = bao2.data["Histograms"][histogram.name]
    mature_ba_hap = mature_ba.data["Histograms"][mature_hist.name]
    for key in ("Scale", "Pref.Ori.", "Size", "Mustrain", "Extinction", "Babinet"):
        bao2_hap[key] = copy.deepcopy(mature_ba_hap[key])
    bao2.set_refinements({"Cell": True})

    wo3 = project.phase("WO3")
    wo3.set_refinements({"Cell": True})
    wo3_hap = wo3.data["Histograms"][histogram.name]
    wo3_hap["Scale"][1] = True
    wo3_hap["Size"] = copy.deepcopy(
        mature.phase("WO3").data["Histograms"][mature_hist.name]["Size"]
    )
    wo3_hap["Mustrain"] = copy.deepcopy(
        mature.phase("WO3").data["Histograms"][mature_hist.name]["Mustrain"]
    )
    wo3_hap["Pref.Ori."][0] = "MD"
    wo3_hap["Pref.Ori."][1] = 1.0
    wo3_hap["Pref.Ori."][2] = True
    wo3_hap["Pref.Ori."][3] = [0, 1, 0]

    tungsten = []
    oxygen = []
    for index, atom in enumerate(wo3.data["Atoms"]):
        atom[2] = "U"
        if atom[1].startswith("W"):
            atom[10] = 0.010
            tungsten.append(index)
        elif atom[1].startswith("O"):
            atom[10] = 0.012
            oxygen.append(index)
        else:
            raise ValueError(f"Unexpected atom type in {label}: {atom[1]}")

    pre_path = f"stages/retest_{label}_pre.gpx"
    project.save(pre_path)
    project = G2sc.G2Project(pre_path)
    pid = project.phase("WO3").data["pId"]
    if len(tungsten) > 1:
        project.add_EquivConstr(tuple(f"{pid}::AUiso:{i}" for i in tungsten))
    if len(oxygen) > 1:
        project.add_EquivConstr(tuple(f"{pid}::AUiso:{i}" for i in oxygen))
    return project


def run(label: str, model_path: str) -> None:
    project = prepare(label, model_path)
    project.set_Controls("cycles", 12)
    for _ in range(8):
        project.refine()
        result = project.data["Covariance"]["data"].get("Rvals", {})
        if (
            result.get("converged")
            and not result.get("SVD0")
            and abs(float(result.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    output = f"stages/retest_{label}.gpx"
    project.save(output)
    histogram = project.histograms()[0]
    result = project.data["Covariance"]["data"].get("Rvals", {})
    print(
        "RETEST_MODEL_RESULT",
        {
            "model": label,
            "rwp": histogram.get_wR(),
            "mass_fractions": histogram.ComputeMassFracs(),
            "cells": {phase.name: phase.get_cell() for phase in project.phases()},
            "wo3_adps": sorted(
                {(atom[1], round(float(atom[10]), 8)) for atom in project.phase("WO3").data["Atoms"]}
            ),
            "maximum_correlation": maximum_correlation(project),
            "status": {
                key: result.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
        },
        flush=True,
    )


if __name__ == "__main__":
    requested = tuple(sys.argv[1:])
    selected = (
        ((name, MODELS[name]) for name in requested)
        if requested
        else MODELS.items()
    )
    for model_label, path in selected:
        try:
            run(model_label, path)
        except Exception as error:
            print("RETEST_MODEL_ERROR", model_label, repr(error), flush=True)
