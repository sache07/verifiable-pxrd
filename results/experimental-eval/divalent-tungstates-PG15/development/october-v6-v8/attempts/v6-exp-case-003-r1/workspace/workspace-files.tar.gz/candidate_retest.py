#!/usr/bin/env python3
"""Retest screened structural candidates from the mature refinement state."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from profile_branches import covariance_correlations
from pxrd_refine import CANDIDATES, metrics, stable_refine


ROLES = {
    "wo3_p1": "WO3_P21c",
    "wo3_pnma": "WO3_P21c",
    "wo3_small_p21c": "WO3_P21c",
    "wo3_small_p21c_fixed": "WO3_P21c",
    "cawo4_monoclinic": "CaWO4_scheelite",
    "ca3wo6": "CaWO4_scheelite",
    "aragonite": "CaCO3_calcite",
}

LOCAL_CANDIDATES = {
    "wo3_small_p21c_fixed": (
        "WO3_small_P21c_fixed",
        Path(__file__).resolve().parent / "candidates" / "wo3_small_p21c_fixed.cif",
    ),
}


def configure_candidate(
    project: G2sc.G2Project,
    candidate_key: str,
    mode: str,
) -> tuple[str, str]:
    histogram = project.histograms()[0]
    old_name = ROLES[candidate_key]
    old_phase = project.phase(old_name)
    old_hap = old_phase.data["Histograms"][histogram.name]
    candidate_name, candidate_path = LOCAL_CANDIDATES.get(candidate_key, CANDIDATES.get(candidate_key, (None, None)))
    if candidate_path is None:
        raise ValueError(candidate_key)
    candidate = project.add_phase(
        str(candidate_path),
        phasename=candidate_name,
        histograms=[histogram],
        fmthint="CIF",
    )
    candidate_hap = candidate.data["Histograms"][histogram.name]
    candidate.set_refinements({"Cell": mode == "replace"})
    for atom in candidate.data["Atoms"]:
        atom[2] = ""
        if old_name == "WO3_P21c" and atom[9] == "I" and float(atom[10]) <= 0.0:
            atom[10] = 0.005 if atom[1] == "W" else 0.010

    old_term = float(old_phase.data["General"]["Mass"]) * float(old_hap["Scale"][0])
    new_mass = float(candidate.data["General"]["Mass"])
    if mode == "replace":
        candidate_hap["Scale"][:] = [old_term / new_mass, True]
        old_hap["Scale"][:] = [0.0, False]
        old_hap["Use"] = False
    else:
        candidate_hap["Scale"][:] = [0.02 * old_term / new_mass, True]

    # Transfer only the interpretable isotropic broadening family associated
    # with the role, avoiding symmetry-dependent array copies.
    if old_name == "CaWO4_scheelite":
        candidate.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": float(old_hap["Size"][1][0]), "refine": mode == "replace"},
            "Mustrain": {"type": "isotropic", "value": float(old_hap["Mustrain"][1][0]), "refine": mode == "replace"},
        })
    elif old_name == "WO3_P21c":
        candidate.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 10.0, "refine": False},
            "Mustrain": {"type": "isotropic", "value": float(old_hap["Mustrain"][1][0]), "refine": mode == "replace"},
        })
    else:
        candidate.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 10.0, "refine": False},
            "Mustrain": {"type": "isotropic", "value": 1.0, "refine": False},
        })
    return old_name, candidate_name


def compact(report: dict, old_name: str, candidate_name: str, mode: str) -> dict:
    candidate = report["phases"][candidate_name]
    return {
        "mode": mode,
        "replaced_phase": old_name if mode == "replace" else None,
        "candidate_phase": candidate_name,
        "valid": report["valid"],
        "rwp_percent": report["rwp_percent"],
        "max_shift_over_esd": report["convergence"].get("Max shft/sig"),
        "svd_zeros": report["convergence"].get("SVD0"),
        "message": report["convergence"].get("msg"),
        "candidate_scale": candidate["scale"],
        "candidate_fraction": candidate["fraction"],
        "candidate_cell": candidate["cell"],
        "regions": report["regions"],
        "residual_peaks": report["residual_peaks"][:10],
        "high_correlations": report["high_correlations"],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("replace", "add"))
    parser.add_argument("source", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("candidates", nargs="+")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    summary = {}
    for key in args.candidates:
        if key not in ROLES:
            raise ValueError(key)
        print(f"CANDIDATE_RETEST_START={args.mode}:{key}", flush=True)
        destination = (args.output_dir / f"{args.mode}__{key}.gpx").resolve()
        project = G2sc.G2Project(str(args.source.resolve()))
        project.save(str(destination.with_name(destination.stem + "-pre.gpx")))
        old_name, candidate_name = configure_candidate(project, key, args.mode)
        valid, history = stable_refine(project)
        project.save(str(destination))
        project.phase(candidate_name).export_CIF(str(destination.with_suffix(".cif")))
        report = metrics(project)
        report.update(valid=valid, history=history, high_correlations=covariance_correlations(project))
        destination.with_suffix(".json").write_text(json.dumps(report, indent=2, default=str) + "\n")
        summary[key] = compact(report, old_name, candidate_name, args.mode)
        print("CANDIDATE_RETEST_RESULT=" + json.dumps({key: summary[key]}, default=str), flush=True)
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
