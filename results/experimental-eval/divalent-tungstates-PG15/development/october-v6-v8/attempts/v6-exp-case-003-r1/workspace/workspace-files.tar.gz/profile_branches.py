#!/usr/bin/env python3
"""Matched profile/envelope/microstructure branches for the PXRD project."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from pxrd_refine import metrics, stable_refine


ROOT = Path(__file__).resolve().parent


def covariance_correlations(project: G2sc.G2Project, threshold: float = 0.90) -> list[dict]:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    diagonal = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    rows = []
    for i in range(len(names)):
        for j in range(i):
            denominator = diagonal[i] * diagonal[j]
            if denominator <= 0.0:
                continue
            value = float(matrix[i, j] / denominator)
            if abs(value) >= threshold:
                rows.append({"first": names[j], "second": names[i], "correlation": value})
    return sorted(rows, key=lambda row: abs(row["correlation"]), reverse=True)


def configure_global(project: G2sc.G2Project, branch: str) -> None:
    hist = project.histograms()[0]
    instrument = hist.InstrumentParameters
    if branch in {"U", "V", "X", "Y", "Z", "SH_L", "polarization"}:
        key = {
            "SH_L": "SH/L",
            "polarization": "Polariz.",
        }.get(branch, branch)
        instrument[key][2] = True
    elif branch == "roughness_B":
        hist.SampleParameters["SurfRoughB"][:] = [0.0, True]
    elif branch == "roughness_AB":
        hist.SampleParameters["SurfRoughA"][:] = [0.5, True]
        hist.SampleParameters["SurfRoughB"][:] = [0.05, True]
    else:
        raise ValueError(branch)


def configure_microstructure(project: G2sc.G2Project, branch: str) -> None:
    kind, phase_name = branch.split("__", 1)
    phase = project.phase(phase_name)
    if kind == "size":
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 1.0, "refine": True}
        })
    elif kind == "strain":
        phase.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "value": 1000.0, "refine": True}
        })
    else:
        raise ValueError(branch)


def configure_texture(project: G2sc.G2Project, branch: str) -> None:
    # syntax: md__phase_name__h_k_l
    _, phase_name, axis_text = branch.split("__", 2)
    axis = [int(item) for item in axis_text.split("_")]
    phase = project.phase(phase_name)
    hist = project.histograms()[0]
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis


def run_branch(source: Path, destination: Path, family: str, branch: str) -> dict:
    destination.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(source))
    project.save(str(destination.with_name(destination.stem + "-pre.gpx")))
    if family == "global":
        configure_global(project, branch)
    elif family == "microstructure":
        configure_microstructure(project, branch)
    elif family == "texture":
        configure_texture(project, branch)
    else:
        raise ValueError(family)
    valid, history = stable_refine(project)
    project.save(str(destination))
    report = metrics(project)
    report.update(
        family=family,
        branch=branch,
        valid=valid,
        history=history,
        high_correlations=covariance_correlations(project),
    )
    destination.with_suffix(".json").write_text(json.dumps(report, indent=2, default=str) + "\n")
    return report


def compact(report: dict) -> dict:
    return {
        "valid": report["valid"],
        "rwp_percent": report["rwp_percent"],
        "max_shift_over_esd": report["convergence"].get("Max shft/sig"),
        "svd_zeros": report["convergence"].get("SVD0"),
        "message": report["convergence"].get("msg"),
        "instrument": {
            key: report["instrument"].get(key)
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
        },
        "sample": {
            key: report["sample"].get(key)
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "fractions": {
            name: phase["fraction"] for name, phase in report["phases"].items()
        },
        "phase_profile": {
            name: {"size": phase["size"], "mustrain": phase["mustrain"], "po": phase["preferred_orientation"]}
            for name, phase in report["phases"].items()
        },
        "regions": report["regions"],
        "high_correlations": report["high_correlations"],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("family", choices=("global", "microstructure", "texture"))
    parser.add_argument("source", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("branches", nargs="+")
    args = parser.parse_args()
    summary = {}
    for branch in args.branches:
        print(f"BRANCH_START={args.family}:{branch}", flush=True)
        destination = args.output_dir / f"{branch}.gpx"
        report = run_branch(args.source.resolve(), destination.resolve(), args.family, branch)
        summary[branch] = compact(report)
        print("BRANCH_RESULT=" + json.dumps({branch: summary[branch]}, default=str), flush=True)
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
