#!/usr/bin/env python3
"""Run matched atomic-coordinate and displacement-parameter branches."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from profile_branches import covariance_correlations
from pxrd_refine import metrics, stable_refine


def _append_flag(atom: list, flag: str) -> None:
    atom[2] = "".join(dict.fromkeys(str(atom[2]) + flag))


def configure_coordinates(project: G2sc.G2Project, phase_name: str, elements: set[str]) -> None:
    phase = project.phase(phase_name)
    matched = 0
    for atom in phase.data["Atoms"]:
        if atom[1] in elements:
            _append_flag(atom, "X")
            matched += 1
    if not matched:
        raise ValueError(f"No atoms in {phase_name} matched {sorted(elements)}")


def configure_coordinates_antiy(project: G2sc.G2Project, phase_name: str, elements: set[str]) -> None:
    """Refine coordinates with a two-site antisymmetric y-displacement mode."""
    phase = project.phase(phase_name)
    indices = []
    for atom_index, atom in enumerate(phase.data["Atoms"]):
        if atom[1] in elements:
            _append_flag(atom, "X")
            indices.append(atom_index)
    if len(indices) != 2:
        raise ValueError(f"Expected exactly two matched atoms in {phase_name}; got {indices}")
    project.save()
    project.index_ids()
    project.add_EquivConstr(
        [f"{phase.id}::dAy:{atom_index}" for atom_index in indices],
        [1.0, -1.0],
        reloadIdx=False,
    )


def configure_grouped_uiso(project: G2sc.G2Project, phase_name: str, elements: set[str]) -> None:
    """Refine one common Uiso for each requested element.

    This is deliberately much more conservative than refining one thermal
    parameter per atom from a laboratory powder pattern.
    """
    phase = project.phase(phase_name)
    phase_id = phase.id
    groups: dict[str, list[int]] = {}
    for atom_index, atom in enumerate(phase.data["Atoms"]):
        if atom[1] not in elements:
            continue
        if atom[9] != "I":
            raise ValueError(f"{phase_name} atom {atom[0]} is not isotropic")
        # CIFs without reported displacement parameters import as zero. Use a
        # small positive starting value before refinement.
        if float(atom[10]) <= 0.0:
            atom[10] = 0.01
        _append_flag(atom, "U")
        groups.setdefault(atom[1], []).append(atom_index)
    if not groups:
        raise ValueError(f"No atoms in {phase_name} matched {sorted(elements)}")

    project.save()
    project.index_ids()
    for element, indices in groups.items():
        if len(indices) > 1:
            project.add_EquivConstr(
                [f"{phase_id}::AUiso:{atom_index}" for atom_index in indices],
                reloadIdx=False,
            )


def atom_report(project: G2sc.G2Project) -> dict:
    report = {}
    for phase in project.phases():
        atoms = []
        for atom in phase.data["Atoms"]:
            atoms.append(
                {
                    "label": atom[0],
                    "element": atom[1],
                    "refinement_flags": atom[2],
                    "xyz": [float(value) for value in atom[3:6]],
                    "occupancy": float(atom[6]),
                    "adp_type": atom[9],
                    "uiso_or_u11": float(atom[10]),
                }
            )
        report[phase.name] = atoms
    return report


def run_branch(source: Path, destination: Path, branch: str) -> dict:
    destination.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(source))
    pre = destination.with_name(destination.stem + "-pre.gpx")
    project.save(str(pre))

    kind, phase_name, element_text = branch.split("__", 2)
    elements = set(element_text.split("_"))
    if kind == "coords":
        configure_coordinates(project, phase_name, elements)
    elif kind == "coords_antiy":
        configure_coordinates_antiy(project, phase_name, elements)
    elif kind == "uiso":
        configure_grouped_uiso(project, phase_name, elements)
    else:
        raise ValueError(kind)

    valid, history = stable_refine(project)
    project.save(str(destination))
    for phase in project.phases():
        phase.export_CIF(str(destination.with_name(f"{destination.stem}-{phase.name}.cif")))

    report = metrics(project)
    report.update(
        branch=branch,
        valid=valid,
        history=history,
        atoms=atom_report(project),
        high_correlations=covariance_correlations(project),
    )
    destination.with_suffix(".json").write_text(json.dumps(report, indent=2, default=str) + "\n")
    return report


def compact(report: dict) -> dict:
    return {
        "valid": report["valid"],
        "rwp_percent": report["rwp_percent"],
        "max_shift_over_esd": report["convergence"].get("Max shft/sig"),
        "svd_zeros": report["convergence"].get("SVD0"),
        "message": report["convergence"].get("msg"),
        "fractions": {name: item["fraction"] for name, item in report["phases"].items()},
        "regions": report["regions"],
        "residual_peaks": report["residual_peaks"][:10],
        "atoms": report["atoms"],
        "high_correlations": report["high_correlations"],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("branches", nargs="+")
    args = parser.parse_args()

    summary = {}
    for branch in args.branches:
        print(f"STRUCTURE_BRANCH_START={branch}", flush=True)
        destination = args.output_dir / f"{branch}.gpx"
        report = run_branch(args.source.resolve(), destination.resolve(), branch)
        summary[branch] = compact(report)
        print("STRUCTURE_BRANCH_RESULT=" + json.dumps({branch: summary[branch]}, default=str), flush=True)
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
