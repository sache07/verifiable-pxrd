#!/usr/bin/env python3
"""Scripted GSAS-II screening and refinement for the supplied PXRD pattern."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = {
    "scheelite": ("CaWO4_scheelite", cod_path("7219229")),
    "cawo4_monoclinic": ("CaWO4_monoclinic", cod_path("1546035")),
    "ca3wo6": ("Ca3WO6", cod_path("1563081")),
    "wo3_p21c": ("WO3_P21c", cod_path("2311041")),
    "wo3_p1": ("WO3_P-1", cod_path("2106293")),
    "wo3_pnma": ("WO3_Pnma", cod_path("2107312")),
    "wo3_small_p21c": ("WO3_small_P21c", cod_path("1563541")),
    "calcite": ("CaCO3_calcite", cod_path("1547347")),
    "aragonite": ("CaCO3_aragonite", cod_path("2103119")),
}


SCREEN_MODELS = {
    "preferred": ["scheelite", "wo3_p21c", "calcite"],
    "wo3_p1": ["scheelite", "wo3_p1", "calcite"],
    "wo3_pnma": ["scheelite", "wo3_pnma", "calcite"],
    "wo3_small_p21c": ["scheelite", "wo3_small_p21c", "calcite"],
    "cawo4_monoclinic": ["cawo4_monoclinic", "wo3_p21c", "calcite"],
    "ca3wo6": ["ca3wo6", "wo3_p21c", "calcite"],
    "aragonite": ["scheelite", "wo3_p21c", "aragonite"],
    "no_scheelite": ["wo3_p21c", "calcite"],
    "no_wo3": ["scheelite", "calcite"],
    "no_calcite": ["scheelite", "wo3_p21c"],
}


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, maximum_runs: int = 12) -> tuple[bool, list[dict]]:
    history = []
    for _ in range(maximum_runs):
        try:
            project.refine()
        except Exception as error:
            history.append({"error": repr(error)})
            return False, history
        status = covariance_status(project)
        entry = {
            key: status.get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp", "GOF")
        }
        history.append(entry)
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in message or "error" in message:
            return False, history
        shift = float(status.get("Max shft/sig") or math.inf)
        if status.get("converged") and shift < 0.05:
            return True, history
    return False, history


def weighted_rwp(yobs: np.ndarray, ycalc: np.ndarray, weight: np.ndarray, mask: np.ndarray) -> float:
    den = float(np.sum(weight[mask] * yobs[mask] ** 2))
    if den <= 0.0:
        return math.nan
    num = float(np.sum(weight[mask] * (yobs[mask] - ycalc[mask]) ** 2))
    return 100.0 * math.sqrt(num / den)


def fractions(project: G2sc.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    terms = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        terms[phase.name] = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
    total = sum(value for value in terms.values() if value > 0.0)
    return {name: value / total for name, value in terms.items()} if total > 0 else terms


def metrics(project: G2sc.G2Project) -> dict:
    hist = project.histograms()[0]
    x, yobs, weight, ycalc, background, difference = [
        np.asarray(v, dtype=float) for v in hist.data["data"][1][:6]
    ]
    lo, hi = hist.data["Limits"][1]
    active = (x >= lo) & (x <= hi) & np.isfinite(ycalc)
    regions = {}
    for lower, upper in ((10, 25), (25, 40), (40, 60), (60, 80), (80, 100.1)):
        mask = active & (x >= lower) & (x < upper)
        regions[f"{lower:g}-{upper:g}"] = {
            "rwp_percent": weighted_rwp(yobs, ycalc, weight, mask),
            "rms_counts": float(np.sqrt(np.mean((yobs[mask] - ycalc[mask]) ** 2))),
            "mean_difference_counts": float(np.mean(yobs[mask] - ycalc[mask])),
        }
    residual = yobs - ycalc
    peaks, properties = find_peaks(residual, prominence=max(100.0, 0.004 * float(np.max(yobs))), distance=8)
    order = np.argsort(properties.get("prominences", np.array([])))[::-1]
    residual_peaks = [
        {
            "two_theta_deg": float(x[peaks[index]]),
            "difference_counts": float(residual[peaks[index]]),
            "prominence_counts": float(properties["prominences"][index]),
        }
        for index in order[:20]
    ]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": list(hap["Scale"]),
            "mass": float(phase.data["General"]["Mass"]),
            "fraction": fractions(project).get(phase.name),
            "size": hap.get("Size"),
            "mustrain": hap.get("Mustrain"),
            "preferred_orientation": hap.get("Pref.Ori."),
        }
    return {
        "rwp_percent": float(hist.get_wR()),
        "residuals": hist.residuals,
        "convergence": covariance_status(project),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "regions": regions,
        "residual_peaks": residual_peaks,
        "phases": phases,
    }


def configure_initial(project: G2sc.G2Project) -> None:
    hist = project.histograms()[0]
    project.set_Controls("cycles", 12)
    hist.set_refinements({
        "Limits": [10.0, 100.09],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 15,
            "coeffs": [1400.0] + [0.0] * 14,
        },
    })
    inst = hist.InstrumentParameters
    inst["Zero"][1] = 0.28
    inst["Zero"][2] = False
    inst["U"][1] = 10.0
    inst["V"][1] = 0.0
    inst["W"][1] = 50.0
    inst["X"][1] = 0.0
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002
    # Keep the histogram scale fixed; otherwise it is exactly degenerate with
    # the independently refined phase scales in a single-pattern refinement.
    if "Scale" in hist.SampleParameters:
        hist.SampleParameters["Scale"][0] = 1.0
        hist.SampleParameters["Scale"][1] = False
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": False})
        for atom in phase.data["Atoms"]:
            atom[2] = ""


def build_project(output: Path, model: list[str]) -> G2sc.G2Project:
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        fmthint="xye",
    )
    for key in model:
        name, path = CANDIDATES[key]
        project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
    configure_initial(project)
    project.save()
    return project


def run_minimal_model(output: Path, model: list[str]) -> tuple[G2sc.G2Project, dict]:
    output.parent.mkdir(parents=True, exist_ok=True)
    project = build_project(output, model)
    stage_log = []

    stages = [
        ("background_scales", None),
        ("zero", {"Instrument Parameters": ["Zero"]}),
        ("cells", {"Cell": True}),
        ("global_W", {"Instrument Parameters": ["W"]}),
    ]
    for stage, settings in stages:
        stable = output.with_name(f"{output.stem}-{stage}-pre.gpx")
        project.save(str(stable))
        if settings:
            if "Instrument Parameters" in settings:
                project.histograms()[0].set_refinements(settings)
            if "Cell" in settings:
                for phase in project.phases():
                    phase.set_refinements({"Cell": settings["Cell"]})
        valid, history = stable_refine(project)
        stage_log.append({"stage": stage, "valid": valid, "history": history})
        project.save(str(output))
        if not valid:
            break
    report = metrics(project)
    report["model"] = model
    report["stages"] = stage_log
    output.with_suffix(".json").write_text(json.dumps(report, indent=2, default=str) + "\n")
    return project, report


def command_screen(selected: list[str] | None = None) -> None:
    branch_dir = ROOT / "branches" / "screen"
    branch_dir.mkdir(parents=True, exist_ok=True)
    summaries = {}
    names = selected or list(SCREEN_MODELS)
    for name in names:
        print(f"SCREEN_START={name}", flush=True)
        project, report = run_minimal_model(branch_dir / f"{name}.gpx", SCREEN_MODELS[name])
        summaries[name] = {
            "rwp_percent": report["rwp_percent"],
            "fractions": {key: value["fraction"] for key, value in report["phases"].items()},
            "regions": report["regions"],
            "convergence": report["convergence"],
            "cells": {key: value["cell"] for key, value in report["phases"].items()},
            "residual_peaks": report["residual_peaks"][:10],
        }
        print("SCREEN_RESULT=" + json.dumps({name: summaries[name]}, default=str), flush=True)
    (branch_dir / "summary.json").write_text(json.dumps(summaries, indent=2, default=str) + "\n")


def command_metrics(project_path: Path) -> None:
    project = G2sc.G2Project(str(project_path))
    print(json.dumps(metrics(project), indent=2, default=str))


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    screen = sub.add_parser("screen")
    screen.add_argument("branches", nargs="*")
    show = sub.add_parser("metrics")
    show.add_argument("project", type=Path)
    args = parser.parse_args()
    if args.command == "screen":
        unknown = sorted(set(args.branches) - set(SCREEN_MODELS))
        if unknown:
            parser.error(f"unknown screen branch(es): {', '.join(unknown)}")
        command_screen(args.branches or None)
    elif args.command == "metrics":
        command_metrics(args.project)


if __name__ == "__main__":
    main()
