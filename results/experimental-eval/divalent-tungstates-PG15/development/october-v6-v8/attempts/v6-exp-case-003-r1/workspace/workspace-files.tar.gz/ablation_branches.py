#!/usr/bin/env python3
"""Matched removal and replacement tests for retained optional terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from profile_branches import covariance_correlations
from pxrd_refine import metrics, stable_refine


def _hap(project: G2sc.G2Project, phase_name: str) -> dict:
    phase = project.phase(phase_name)
    return phase.data["Histograms"][project.histograms()[0].name]


def configure(project: G2sc.G2Project, branch: str) -> None:
    if "__" in branch:
        operation, phase_name = branch.split("__", 1)
    else:
        operation, phase_name = branch, None

    if operation == "clear_all_microstructure":
        for phase in project.phases():
            hap = phase.data["Histograms"][project.histograms()[0].name]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 10.0
            hap["Size"][2][0] = False
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 1.0
            hap["Mustrain"][2][0] = False
        return

    if operation in {"remove_size", "remove_strain", "only_size", "only_strain"}:
        hap = _hap(project, phase_name)
        if operation in {"remove_size", "only_strain"}:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 10.0
            hap["Size"][2][0] = False
        if operation in {"remove_strain", "only_size"}:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 1.0
            hap["Mustrain"][2][0] = False
        if operation == "only_size":
            hap["Size"][1][0] = 1.0
            hap["Size"][2][0] = True
        if operation == "only_strain":
            hap["Mustrain"][1][0] = 1000.0
            hap["Mustrain"][2][0] = True
        return

    hist = project.histograms()[0]
    if operation == "remove_X":
        hist.InstrumentParameters["X"][1] = 0.0
        hist.InstrumentParameters["X"][2] = False
    elif operation == "remove_Y":
        hist.InstrumentParameters["Y"][1] = 0.0
        hist.InstrumentParameters["Y"][2] = False
    elif operation == "remove_roughness_B":
        hist.SampleParameters["SurfRoughB"][:] = [0.0, False]
    elif operation == "remove_MD":
        hap = _hap(project, phase_name)
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    else:
        raise ValueError(branch)


def compact(report: dict) -> dict:
    return {
        "valid": report["valid"],
        "rwp_percent": report["rwp_percent"],
        "max_shift_over_esd": report["convergence"].get("Max shft/sig"),
        "svd_zeros": report["convergence"].get("SVD0"),
        "message": report["convergence"].get("msg"),
        "regions": report["regions"],
        "fractions": {name: phase["fraction"] for name, phase in report["phases"].items()},
        "instrument": report["instrument"],
        "sample": report["sample"],
        "phase_profile": {
            name: {
                "size": phase["size"],
                "mustrain": phase["mustrain"],
                "po": phase["preferred_orientation"],
            }
            for name, phase in report["phases"].items()
        },
        "high_correlations": report["high_correlations"],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("branches", nargs="+")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    summary = {}
    for branch in args.branches:
        print(f"ABLATION_BRANCH_START={branch}", flush=True)
        project = G2sc.G2Project(str(args.source.resolve()))
        destination = (args.output_dir / f"{branch}.gpx").resolve()
        project.save(str(destination.with_name(destination.stem + "-pre.gpx")))
        configure(project, branch)
        valid, history = stable_refine(project)
        project.save(str(destination))
        report = metrics(project)
        report.update(valid=valid, history=history, high_correlations=covariance_correlations(project))
        destination.with_suffix(".json").write_text(json.dumps(report, indent=2, default=str) + "\n")
        summary[branch] = compact(report)
        print("ABLATION_BRANCH_RESULT=" + json.dumps({branch: summary[branch]}, default=str), flush=True)
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
