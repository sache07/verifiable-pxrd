#!/usr/bin/env python3
"""Freeze and export the selected GSAS-II refinement and submission files."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from learned.profile_regeneration import regenerate_profile
from pxrd_refine import fractions, stable_refine


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "branches" / "final_model" / "angular_final.gpx"
FINAL = ROOT / "final.gpx"

CIF_NAMES = {
    "CaWO4_scheelite": "phase_CaWO4_scheelite.cif",
    "WO3_P21c": "phase_WO3_monoclinic.cif",
    "CaCO3_calcite": "phase_CaCO3_calcite.cif",
}

DISPLAY_NAMES = {
    "CaWO4_scheelite": ("scheelite calcium tungstate", "CaWO4"),
    "WO3_P21c": ("monoclinic tungsten trioxide (gamma-WO3)", "WO3"),
    "CaCO3_calcite": ("calcite", "CaCO3"),
}


def fraction_esds(project: G2sc.G2Project) -> dict[str, float | None]:
    histogram = project.histograms()[0]
    phases = project.phases()
    terms = np.asarray(
        [
            float(phase.data["General"]["Mass"])
            * float(phase.data["Histograms"][histogram.name]["Scale"][0])
            for phase in phases
        ],
        dtype=float,
    )
    total = float(np.sum(terms))
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    scale_names = [f"{phase.id}:{histogram.id}:Scale" for phase in phases]
    try:
        indices = [names.index(name) for name in scale_names]
    except ValueError:
        return {phase.name: None for phase in phases}
    if matrix.shape != (len(names), len(names)) or total <= 0.0:
        return {phase.name: None for phase in phases}
    scale_covariance = matrix[np.ix_(indices, indices)]
    masses = np.asarray([float(phase.data["General"]["Mass"]) for phase in phases])
    jacobian = np.empty((len(phases), len(phases)), dtype=float)
    for i in range(len(phases)):
        for j in range(len(phases)):
            jacobian[i, j] = masses[j] * (
                (total if i == j else 0.0) - terms[i]
            ) / total**2
    fraction_covariance = jacobian @ scale_covariance @ jacobian.T
    return {
        phase.name: math.sqrt(max(float(fraction_covariance[i, i]), 0.0))
        for i, phase in enumerate(phases)
    }


def main() -> None:
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(ROOT / "branches" / "final_model" / "final_export_pre.gpx"))
    valid, history = stable_refine(project)
    if not valid:
        raise RuntimeError(f"final refinement did not converge: {history[-1] if history else history}")
    project.save(str(FINAL))
    regenerate_profile(FINAL)
    project = G2sc.G2Project(str(FINAL))
    histogram = project.histograms()[0]

    for phase in project.phases():
        phase.export_CIF(str(ROOT / CIF_NAMES[phase.name]))

    x, observed, weight, calculated, background, difference = [
        np.asarray(values, dtype=float) for values in histogram.data["data"][1][:6]
    ]
    # Recompute the submitted difference explicitly to guard against stale
    # saved arrays and make its sign convention unambiguous.
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_obs_minus_calc_counts",
                "background_counts",
                "weight_inverse_variance",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background, weight))

    phase_fractions = fractions(project)
    esds = fraction_esds(project)
    phase_rows = []
    for phase in project.phases():
        display_name, formula = DISPLAY_NAMES[phase.name]
        cell = phase.get_cell()
        phase_rows.append(
            {
                "name": display_name,
                "project_phase_name": phase.name,
                "formula": formula,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": CIF_NAMES[phase.name],
                "weight_fraction": phase_fractions[phase.name],
                "weight_fraction_esd_statistical": esds[phase.name],
                "weight_percent": 100.0 * phase_fractions[phase.name],
                "cell": {key: float(value) for key, value in cell.items()},
            }
        )

    residuals = histogram.residuals
    rvalues = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "phases": phase_rows,
        "normalization_basis": (
            "Weight fractions are normalized over the three modeled crystalline phases only; "
            "no amorphous/internal-standard correction is possible from this pattern."
        ),
        "fit_statistics": {
            "Rwp_percent": float(histogram.get_wR()),
            "Rp_percent": float(residuals.get("R", math.nan)),
            "Rexp_percent": float(residuals.get("wRmin", math.nan)),
            "goodness_of_fit": float(rvalues.get("GOF", math.nan)),
            "chi_square": float(rvalues.get("chisq", math.nan)),
            "observations": int(rvalues.get("Nobs", 0)),
            "refined_variables": int(rvalues.get("Nvars", 0)),
            "maximum_shift_over_esd": float(rvalues.get("Max shft/sig", math.nan)),
            "fit_range_two_theta_deg": [
                float(histogram.data["Limits"][1][0]),
                float(histogram.data["Limits"][1][1]),
            ],
        },
        "unresolved_components": [
            {
                "candidate": "trace aragonite",
                "status": "not_reported_as_a_phase",
                "reason": (
                    "A four-phase test gave about 0.7 wt% and a very small Rwp decrease, "
                    "but its strongest reflections overlap the accepted phases and did not "
                    "provide multiple unique-peak support; its presence and fraction are unreliable."
                ),
            }
        ],
        "files": {
            "project": "final.gpx",
            "profile": "fit.csv",
            "report": "report.md",
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
