#!/usr/bin/env python3
"""Small replayable transformations used to stabilize selected GSAS-II branches."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from profile_branches import covariance_correlations
from pxrd_refine import metrics, stable_refine


def freeze_coordinates(project: G2sc.G2Project, phase_name: str, elements: set[str]) -> None:
    phase = project.phase(phase_name)
    for atom in phase.data["Atoms"]:
        if atom[1] in elements:
            atom[2] = str(atom[2]).replace("X", "")
    # Coordinate-mode constraints are no longer needed after their refined
    # values have been frozen. No other phase constraints are used here.
    project.data["Constraints"]["data"]["Phase"] = []


def freeze_adps(project: G2sc.G2Project, phase_name: str, elements: set[str]) -> None:
    phase = project.phase(phase_name)
    for atom in phase.data["Atoms"]:
        if atom[1] in elements:
            atom[2] = str(atom[2]).replace("U", "")
    project.data["Constraints"]["data"]["Phase"] = []


def set_fixed_uiso(project: G2sc.G2Project, phase_name: str, assignments: dict[str, float]) -> None:
    phase = project.phase(phase_name)
    found = set()
    for atom in phase.data["Atoms"]:
        element = atom[1]
        if element not in assignments:
            continue
        if atom[9] != "I":
            raise ValueError(f"{phase_name} atom {atom[0]} is not isotropic")
        atom[10] = float(assignments[element])
        atom[2] = str(atom[2]).replace("U", "")
        found.add(element)
    missing = set(assignments) - found
    if missing:
        raise ValueError(f"Elements not found in {phase_name}: {sorted(missing)}")
    project.data["Constraints"]["data"]["Phase"] = []


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=("freeze-coords", "freeze-adps", "set-fixed-uiso", "reconverge"))
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("phase")
    parser.add_argument("elements", nargs="+")
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()))
    args.destination.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(args.destination.with_name(args.destination.stem + "-pre.gpx")))
    if args.operation == "freeze-coords":
        freeze_coordinates(project, args.phase, set(args.elements))
    elif args.operation == "freeze-adps":
        freeze_adps(project, args.phase, set(args.elements))
    elif args.operation == "set-fixed-uiso":
        assignments = {}
        for item in args.elements:
            element, value = item.split("=", 1)
            assignments[element] = float(value)
        set_fixed_uiso(project, args.phase, assignments)
    else:
        pass
    valid, history = stable_refine(project)
    project.save(str(args.destination.resolve()))
    report = metrics(project)
    report.update(valid=valid, history=history, high_correlations=covariance_correlations(project))
    args.destination.with_suffix(".json").write_text(json.dumps(report, indent=2, default=str) + "\n")
    print(json.dumps({
        "valid": valid,
        "rwp_percent": report["rwp_percent"],
        "convergence": report["convergence"],
        "high_correlations": report["high_correlations"],
    }, indent=2, default=str))


if __name__ == "__main__":
    main()
