#!/usr/bin/env python3
"""Retest one phase broadening term while preserving a mature baseline."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

sys.path.insert(0, str(Path(__file__).resolve().parent))
import envelope_screen as es  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output")
    parser.add_argument("phase_index", type=int)
    parser.add_argument("kind", choices=("size", "mustrain"))
    args = parser.parse_args()

    Path(args.output).resolve().parent.mkdir(parents=True, exist_ok=True)
    baseline = G2sc.G2Project(args.base)
    project = G2sc.G2Project(args.base, newgpx=args.output)
    es.freeze(project)
    phase = project.phases()[args.phase_index]
    hist = project.histograms()[0]
    hap = phase.data["Histograms"][hist.name]
    if args.kind == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
        variable = f"{args.phase_index}:0:Size;i"
        project.set_Controls("parmMin", 0.005, variable=variable)
        project.set_Controls("parmMax", 10.0, variable=variable)
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
        variable = f"{args.phase_index}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=variable)
    stage = es.refine(project, 3)
    phase = project.phases()[args.phase_index]
    hap = phase.data["Histograms"][hist.name]
    staged_value = (hap["Size"][1][0] if args.kind == "size"
                    else hap["Mustrain"][1][0])

    es.restore(project, baseline)
    hist = project.histograms()[0]
    phase = project.phases()[args.phase_index]
    hap = phase.data["Histograms"][hist.name]
    if args.kind == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = staged_value
        hap["Size"][2][0] = True
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = staged_value
        hap["Mustrain"][2][0] = True
    full = es.refine(project, 8)
    project.save()

    hist = project.histograms()[0]
    phase = project.phases()[args.phase_index]
    hap = phase.data["Histograms"][hist.name]
    cov = project.data.get("Covariance", {}).get("data", {})
    result = cov.get("Rvals", {})
    branch = {
        "phase": phase.name,
        "phase_index": args.phase_index,
        "kind": args.kind,
        "file": str(Path(args.output).resolve()),
        "rwp_percent": hist.get_wR(),
        "regional_rwp_percent": es.regional(hist),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "target_variable": variable,
        "target_sigma": {
            str(v): float(s) for v, s in zip(cov.get("varyList", []), cov.get("sig", []))
            if str(v) == variable
        },
        "convergence": {k: result.get(k) for k in
                        ("GOF", "Max shft/sig", "SVD0", "converged",
                         "DelChi2", "lamMax", "msg")},
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}).get("FrozenList", [])],
        "stage_trace": stage,
        "full_trace": full,
    }
    Path(args.output).with_suffix(".json").write_text(json.dumps(branch, indent=2) + "\n")
    print("MATURE_BROADENING_RESULT=" + json.dumps(branch, sort_keys=True))


if __name__ == "__main__":
    main()
