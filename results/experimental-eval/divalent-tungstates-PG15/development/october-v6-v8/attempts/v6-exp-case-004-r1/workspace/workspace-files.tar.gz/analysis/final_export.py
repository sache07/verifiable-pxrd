#!/usr/bin/env python3
"""Freeze, replay, and export the selected GSAS-II model."""

from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "learned"))
from profile_regeneration import regenerate_profile  # noqa: E402


def cell_record(phase):
    cell = phase.get_cell()
    return {
        "a_angstrom": float(cell["length_a"]),
        "b_angstrom": float(cell["length_b"]),
        "c_angstrom": float(cell["length_c"]),
        "alpha_deg": float(cell["angle_alpha"]),
        "beta_deg": float(cell["angle_beta"]),
        "gamma_deg": float(cell["angle_gamma"]),
        "volume_angstrom3": float(cell["volume"]),
    }


def main():
    source = ROOT / "projects/final_chemistry/angular.gpx"
    final = ROOT / "final.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(final))
    controls = project.data["Controls"]["data"]
    controls["min dM/M"] = 1e-5
    controls["max cyc"] = 10

    trace = []
    for _ in range(4):
        controls["Marquardt"] = 0
        project.save()
        project.refine()
        values = dict(project.data.get("Covariance", {}).get("data", {}).get(
            "Rvals", {}))
        trace.append({k: values.get(k) for k in
                      ("Rwp", "GOF", "Max shft/sig", "SVD0", "converged",
                       "DelChi2", "lamMax", "msg")})
        shift = values.get("Max shft/sig")
        if (values.get("converged") and values.get("SVD0", 0) == 0
                and shift is not None and abs(shift) < 0.08):
            break
    project.save()

    frozen = [str(v) for v in controls.get("parmFrozen", {}).get(
        "FrozenList", [])]
    values = project.data["Covariance"]["data"]["Rvals"]
    if frozen:
        raise RuntimeError(f"final project has frozen variables: {frozen}")
    if not values.get("converged") or values.get("SVD0", 0):
        raise RuntimeError(f"final refinement is not clean: {values}")
    if abs(float(values.get("Max shft/sig", math.inf))) >= 0.08:
        raise RuntimeError(f"final refinement not converged tightly: {values}")

    # Ensure all exported arrays and reflection lists are regenerated from the
    # exact project that supplies the CIFs and phase fractions.
    regenerate_profile(final)
    project = G2sc.G2Project(str(final))
    hist = project.histograms()[0]
    phases = project.phases()
    if [phase.name for phase in phases] != ["CoWO4", "WO3"]:
        raise RuntimeError(f"unexpected final phases: {[p.name for p in phases]}")

    cif_names = ["phase_CoWO4.cif", "phase_WO3.cif"]
    for phase, name in zip(phases, cif_names):
        phase.export_CIF(str(ROOT / name), quickmode=True)

    x = np.asarray(hist.getdata("X"), dtype=float)
    observed = np.asarray(hist.getdata("Yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("Ycalc"), dtype=float)
    difference = np.asarray(hist.getdata("Residual"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated",
                         "difference_obs_minus_calc", "background"])
        writer.writerows(zip(x, observed, calculated, difference, background))

    fractions = hist.ComputeMassFracs()
    fraction_values = [float(fractions[p.name][0]) for p in phases]
    total = sum(fraction_values)
    fraction_values = [value / total for value in fraction_values]
    fraction_esds = [float(fractions[p.name][1]) / total for p in phases]

    covariance = project.data["Covariance"]["data"]
    values = covariance["Rvals"]
    rwp = float(hist.get_wR())
    rp = 100.0 * float(np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    gof = float(values["GOF"])
    fit_stats = {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "Rexp_percent": rwp / gof,
        "goodness_of_fit": gof,
        "chi_squared": float(values["chisq"]),
        "number_of_observations": int(values["Nobs"]),
        "number_of_refined_variables": int(values["Nvars"]),
        "maximum_shift_over_esd": float(values["Max shft/sig"]),
    }
    formulas = ["CoWO4", "WO3"]
    labels = ["Cobalt tungstate (wolframite)",
              "Tungsten trioxide (monoclinic gamma-WO3)"]
    records = []
    for phase, cif_name, formula, label, fraction, esd in zip(
            phases, cif_names, formulas, labels, fraction_values,
            fraction_esds):
        records.append({
            "name": label,
            "phase_id": phase.name,
            "chemical_formula": formula,
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cif_path": cif_name,
            "weight_fraction": fraction,
            "weight_fraction_esd_formal": esd,
            "unit_cell": cell_record(phase),
        })

    result = {
        "phases": records,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "fit_statistics": fit_stats,
        "profile_path": "fit.csv",
        "difference_definition": "observed - calculated",
        "gsasii_project": "final.gpx",
        "refinement_trace": trace,
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
