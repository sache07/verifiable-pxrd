#!/usr/bin/env python3
"""Matched GSAS-II nuisance/profile branch screen for this data set."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


REGIONS = ((10.0, 30.0), (30.0, 50.0), (50.0, 70.0),
           (70.0, 85.0), (85.0, 100.0))
INST_PROFILE = ("U", "V", "W", "X", "Y", "Z", "SH/L")


def convergence(project: G2sc.G2Project) -> dict:
    return dict(project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}))


def regional_rwp(hist) -> dict[str, float]:
    x = np.asarray(hist.getdata("X"), dtype=float)
    yo = np.asarray(hist.getdata("Yobs"), dtype=float)
    yc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    wt = np.asarray(hist.getdata("Yweight"), dtype=float)
    out = {}
    for lo, hi in REGIONS:
        sel = (x >= lo) & (x < hi)
        numerator = np.sum(wt[sel] * (yo[sel] - yc[sel]) ** 2)
        denominator = np.sum(wt[sel] * yo[sel] ** 2)
        out[f"{lo:g}-{hi:g}"] = 100.0 * math.sqrt(numerator / denominator)
    return out


def set_baseline_flags(project: G2sc.G2Project, enabled: bool) -> None:
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = enabled
    inst = hist.data["Instrument Parameters"][0]
    for key in INST_PROFILE:
        inst[key][2] = False
    inst["W"][2] = enabled
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = enabled
        phase.data["Histograms"][hist.name]["Scale"][1] = enabled


def refine_until_stable(project: G2sc.G2Project, calls: int = 5,
                        shift_limit: float = 0.08) -> list[dict]:
    trace = []
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.data["Controls"]["data"]["max cyc"] = 10
    for _ in range(calls):
        project.data["Controls"]["data"]["Marquardt"] = 0
        project.save()
        project.refine()
        rv = convergence(project)
        trace.append({k: rv.get(k) for k in
                      ("Rwp", "GOF", "Max shft/sig", "SVD0", "converged",
                       "DelChi2", "lamMax", "msg")})
        shift = rv.get("Max shft/sig")
        if rv.get("converged") and shift is not None and abs(shift) < shift_limit:
            break
    return trace


def gaussian_widths(inst: dict, x: np.ndarray) -> np.ndarray:
    theta = np.radians(x / 2.0)
    return (inst["U"][1] * np.tan(theta) ** 2
            + inst["V"][1] * np.tan(theta) + inst["W"][1])


def lorentz_widths(inst: dict, x: np.ndarray) -> np.ndarray:
    # GSAS-II CW Lorentzian profile is gamma = X/cos(theta) + Y tan(theta) + Z.
    theta = np.radians(x / 2.0)
    return (inst["X"][1] / np.cos(theta)
            + inst["Y"][1] * np.tan(theta) + inst["Z"][1])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("outdir")
    parser.add_argument("terms", nargs="+", choices=("U", "V", "X", "Y", "Z", "SH/L"))
    args = parser.parse_args()

    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    baseline = G2sc.G2Project(args.base)
    base_hist = baseline.histograms()[0]
    results = {
        "baseline": {
            "file": str(Path(args.base).resolve()),
            "rwp_percent": base_hist.get_wR(),
            "regional_rwp_percent": regional_rwp(base_hist),
        },
        "branches": [],
    }

    starts = {"U": 2.0, "V": -2.0, "X": 1.0, "Y": 1.0,
              "Z": 1.0, "SH/L": 0.002}
    for term in args.terms:
        destination = outdir / f"profile_{term.replace('/', '_')}.gpx"
        project = G2sc.G2Project(args.base, newgpx=str(destination))
        hist = project.histograms()[0]
        inst = hist.data["Instrument Parameters"][0]

        # Stage only the added term first against a settled baseline.
        set_baseline_flags(project, False)
        inst[term][1] = starts[term]
        inst[term][2] = True
        if term in ("X", "Y", "Z"):
            project.set_Controls("parmMin", 0.0, variable=f":0:{term}")
        if term == "SH/L":
            project.set_Controls("parmMin", 0.0005, variable=":0:SH/L")
        stage_trace = refine_until_stable(project, calls=3)

        # Restore identical nuisance terms and reconverge the complete pattern.
        set_baseline_flags(project, True)
        inst[term][2] = True
        full_trace = refine_until_stable(project, calls=6)
        project.save()
        hist = project.histograms()[0]
        inst = hist.data["Instrument Parameters"][0]
        x = np.asarray(hist.getdata("X"), dtype=float)
        rv = convergence(project)
        results["branches"].append({
            "term": term,
            "file": str(destination),
            "value": inst[term][1],
            "esd": project.data.get("Covariance", {}).get("data", {}).get("sigDict", {}).get(f":0:{term}"),
            "rwp_percent": hist.get_wR(),
            "regional_rwp_percent": regional_rwp(hist),
            "gaussian_width_sq_min": float(np.min(gaussian_widths(inst, x))),
            "lorentz_width_min": float(np.min(lorentz_widths(inst, x))),
            "convergence": {k: rv.get(k) for k in
                            ("GOF", "Max shft/sig", "SVD0", "converged",
                             "DelChi2", "lamMax", "msg")},
            "stage_trace": stage_trace,
            "full_trace": full_trace,
        })
        print("PROFILE_BRANCH_RESULT=" + json.dumps(results["branches"][-1], sort_keys=True))

    result_path = outdir / "profile_screen.json"
    result_path.write_text(json.dumps(results, indent=2) + "\n")
    print("PROFILE_SCREEN_RESULT=" + json.dumps(results, sort_keys=True))


if __name__ == "__main__":
    main()
