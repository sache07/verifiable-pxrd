#!/usr/bin/env python3
"""Remove one retained model term and reconverge all remaining variables."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

sys.path.insert(0, str(Path(__file__).resolve().parent))
import envelope_screen as es  # noqa: E402


KINDS = (
    "V", "W", "Z", "roughness_A", "roughness_B",
    "CoWO4_size", "WO3_mustrain", "CoWO4_MD", "WO3_MD",
    "WO3_W_ADP", "shift",
)


def remove(project, kind):
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = project.phases()
    if kind == "V":
        inst["V"][1], inst["V"][2] = inst["V"][0], False
    elif kind == "W":
        # Return to the calibrated starting value from the instrument file.
        inst["W"][1], inst["W"][2] = inst["W"][0], False
    elif kind == "Z":
        inst["Z"][1], inst["Z"][2] = 0.0, False
    elif kind == "roughness_A":
        sample["SurfRoughA"] = [0.0, False]
    elif kind == "roughness_B":
        sample["SurfRoughB"] = [0.0, False]
    elif kind == "CoWO4_size":
        hap = phases[0].data["Histograms"][hist.name]
        hap["Size"][1][0] = 10.0
        hap["Size"][2][0] = False
    elif kind == "WO3_mustrain":
        hap = phases[1].data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2][0] = False
    elif kind == "CoWO4_MD":
        po = phases[0].data["Histograms"][hist.name]["Pref.Ori."]
        po[1], po[2] = 1.0, False
    elif kind == "WO3_MD":
        po = phases[1].data["Histograms"][hist.name]["Pref.Ori."]
        po[1], po[2] = 1.0, False
    elif kind == "WO3_W_ADP":
        for atom in phases[1].atoms():
            if atom.element == "W":
                atom.uiso = 0.005
                atom.refinement_flags = atom.refinement_flags.replace("U", "")
        # This project has one phase constraint: equivalence of the two W
        # isotropic displacement parameters. It is no longer applicable.
        project.data["Constraints"]["data"]["Phase"] = []
    elif kind == "shift":
        sample["Shift"] = [0.0, False]
    else:  # pragma: no cover
        raise ValueError(kind)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output")
    parser.add_argument("kind", choices=KINDS)
    args = parser.parse_args()
    Path(args.output).resolve().parent.mkdir(parents=True, exist_ok=True)

    project = G2sc.G2Project(args.base, newgpx=args.output)
    remove(project, args.kind)
    trace = es.refine(project, 10)
    project.save()

    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = project.phases()
    cov = project.data.get("Covariance", {}).get("data", {})
    vals = cov.get("Rvals", {})
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:  # pragma: no cover
        fractions = {"error": str(exc)}
    result = {
        "removed": args.kind,
        "file": str(Path(args.output).resolve()),
        "rwp_percent": hist.get_wR(),
        "regional_rwp_percent": es.regional(hist),
        "convergence": {k: vals.get(k) for k in
                        ("GOF", "Max shft/sig", "SVD0", "converged",
                         "DelChi2", "lamMax", "msg")},
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}).get("FrozenList", [])],
        "trace": trace,
        "instrument": {k: inst[k] for k in ("V", "W", "Z")},
        "surface_roughness_a": sample["SurfRoughA"],
        "surface_roughness_b": sample["SurfRoughB"],
        "shift": sample["Shift"],
        "phase_terms": {
            phases[0].name: {
                "size": phases[0].data["Histograms"][hist.name]["Size"],
                "mustrain": phases[0].data["Histograms"][hist.name]["Mustrain"],
                "preferred_orientation": phases[0].data["Histograms"][hist.name]["Pref.Ori."],
            },
            phases[1].name: {
                "size": phases[1].data["Histograms"][hist.name]["Size"],
                "mustrain": phases[1].data["Histograms"][hist.name]["Mustrain"],
                "preferred_orientation": phases[1].data["Histograms"][hist.name]["Pref.Ori."],
                "w_adps": [a.uiso for a in phases[1].atoms()
                           if a.element == "W"],
            },
        },
        "mass_fractions": fractions,
    }
    Path(args.output).with_suffix(".json").write_text(
        json.dumps(result, indent=2, default=str) + "\n")
    print("LEAVE_ONE_OUT_RESULT=" + json.dumps(result, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
