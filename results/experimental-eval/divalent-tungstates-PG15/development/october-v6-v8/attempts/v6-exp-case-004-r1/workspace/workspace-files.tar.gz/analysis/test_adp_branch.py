#!/usr/bin/env python3
"""Test selected isotropic atomic displacement parameters in a matched branch."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

sys.path.insert(0, str(Path(__file__).resolve().parent))
import envelope_screen as es  # noqa: E402


def corr_pairs(project):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = [str(v) for v in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.size == 0:
        return []
    sig = np.sqrt(np.diag(matrix))
    corr = matrix / np.outer(sig, sig)
    pairs = [(abs(corr[i, j]), corr[i, j], names[i], names[j])
             for i in range(len(names)) for j in range(i)]
    return [{"absolute": float(a), "value": float(v), "first": x, "second": y}
            for a, v, x, y in sorted(pairs, reverse=True)[:15]]


def set_u_flags(project, phase_index, labels, preserve):
    phase = project.phases()[phase_index]
    selected = []
    selected_indices = []
    for index, atom in enumerate(phase.atoms()):
        if atom.label not in labels:
            continue
        flags = atom.refinement_flags if preserve else ""
        atom.refinement_flags = flags if "U" in flags else flags + "U"
        project.set_Controls("parmMin", 0.0,
                             variable=f"{phase_index}::AUiso:{index}")
        project.set_Controls("parmMax", 0.1,
                             variable=f"{phase_index}::AUiso:{index}")
        selected.append(atom.label)
        selected_indices.append(index)
    missing = sorted(labels - set(selected))
    if missing:
        raise ValueError(f"Missing labels: {missing}")
    return selected_indices


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output")
    parser.add_argument("phase_index", type=int)
    parser.add_argument("labels", help="Comma-separated atom labels")
    parser.add_argument("--equiv", action="store_true",
                        help="Constrain all selected Uiso values equal")
    args = parser.parse_args()
    labels = set(args.labels.split(","))
    Path(args.output).resolve().parent.mkdir(parents=True, exist_ok=True)

    baseline = G2sc.G2Project(args.base)
    project = G2sc.G2Project(args.base, newgpx=args.output)
    es.freeze(project)
    indices = set_u_flags(project, args.phase_index, labels, preserve=False)
    if args.equiv:
        if len(indices) < 2:
            raise ValueError("--equiv requires at least two atoms")
        project.add_EquivConstr(
            [f"{args.phase_index}::AUiso:{index}" for index in indices])
    stage = es.refine(project, 4)

    es.restore(project, baseline)
    set_u_flags(project, args.phase_index, labels, preserve=True)
    full = es.refine(project, 10)
    project.save()

    hist = project.histograms()[0]
    phase = project.phases()[args.phase_index]
    cov = project.data.get("Covariance", {}).get("data", {})
    vals = cov.get("Rvals", {})
    result = {
        "phase": phase.name,
        "labels": sorted(labels),
        "equivalent_uiso_constraint": args.equiv,
        "file": str(Path(args.output).resolve()),
        "rwp_percent": hist.get_wR(),
        "regional_rwp_percent": es.regional(hist),
        "atoms": [{"label": atom.label, "element": atom.element,
                   "uiso": atom.uiso, "refinement_flags": atom.refinement_flags}
                  for atom in phase.atoms()],
        "convergence": {k: vals.get(k) for k in
                        ("GOF", "Max shft/sig", "SVD0", "converged",
                         "DelChi2", "lamMax", "msg")},
        "top_correlations": corr_pairs(project),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}).get("FrozenList", [])],
        "stage_trace": stage,
        "full_trace": full,
    }
    Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print("ADP_BRANCH_RESULT=" + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
