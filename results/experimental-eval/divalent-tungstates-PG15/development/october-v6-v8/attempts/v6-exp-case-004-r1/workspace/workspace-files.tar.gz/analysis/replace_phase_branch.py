#!/usr/bin/env python3
"""Matched replacement of phase 1 in a mature two-phase powder model."""

from __future__ import annotations

import argparse
import copy
import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

sys.path.insert(0, str(Path(__file__).resolve().parent))
import envelope_screen as es  # noqa: E402


def top_correlations(project):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = [str(v) for v in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.size == 0:
        return []
    sig = np.sqrt(np.diag(matrix))
    corr = matrix / np.outer(sig, sig)
    pairs = [(abs(corr[i, j]), corr[i, j], names[i], names[j])
             for i in range(len(names)) for j in range(i)]
    return [{"absolute": float(a), "value": float(v), "first": x, "second": y}
            for a, v, x, y in sorted(pairs, reverse=True)[:15]]


def remove_phase(project, index):
    phase = project.phases()[index]
    name = phase.name
    hist = project.histograms()[0]
    old_hap = copy.deepcopy(phase.data["Histograms"][hist.name])
    del project.data["Phases"][name]
    for node in project.names:
        if node and node[0] == "Phases" and name in node:
            node.remove(name)
    hist.data.get("Reflection Lists", {}).pop(name, None)
    # Existing phase constraints reference the removed phase/atom IDs.
    project.data["Constraints"]["data"]["Phase"] = []
    return name, old_hap


def configure_candidate(project, phase, old_hap, scale, full):
    hist = project.histograms()[0]
    pid = phase.data["pId"]
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [max(scale, 1e-6), True]
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
    phase.data["General"]["Cell"][0] = bool(full)
    phase.set_refinements({"Atoms": {"all": ""}})

    hap["Size"] = copy.deepcopy(old_hap["Size"])
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2][0] = False
    hap["Mustrain"] = copy.deepcopy(old_hap["Mustrain"])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = max(old_hap["Mustrain"][1][0], 100.0)
    hap["Mustrain"][2][0] = bool(full)
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")

    hap["Pref.Ori."] = copy.deepcopy(old_hap["Pref.Ori."])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = bool(full)
    hap["Pref.Ori."][3] = [0, 1, 0]
    project.set_Controls("parmMin", 0.2, variable=f"{pid}:0:MD")
    project.set_Controls("parmMax", 5.0, variable=f"{pid}:0:MD")


def add_shared_w_adp(project, phase):
    pid = phase.data["pId"]
    indices = []
    for index, atom in enumerate(phase.atoms()):
        atom.refinement_flags = ""
        if atom.element == "W":
            atom.uiso = 0.010
            atom.refinement_flags = "U"
            indices.append(index)
            project.set_Controls("parmMin", 0.0,
                                 variable=f"{pid}::AUiso:{index}")
            project.set_Controls("parmMax", 0.1,
                                 variable=f"{pid}::AUiso:{index}")
    if len(indices) > 1:
        project.add_EquivConstr(
            [f"{pid}::AUiso:{index}" for index in indices])
    return indices


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output")
    parser.add_argument("candidate_cif")
    parser.add_argument("phase_name")
    args = parser.parse_args()
    Path(args.output).resolve().parent.mkdir(parents=True, exist_ok=True)

    baseline = G2sc.G2Project(args.base)
    project = G2sc.G2Project(args.base, newgpx=args.output)
    es.freeze(project)
    removed, old_hap = remove_phase(project, 1)
    hist = project.histograms()[0]
    project.save()
    phase = project.add_phase(args.candidate_cif, phasename=args.phase_name,
                              histograms=[hist])
    initial_cell = list(phase.data["General"]["Cell"][1:8])
    # The number of HStrain terms is symmetry-dependent. Preserve the new
    # phase's correctly-sized default before restore() copies the old phase's
    # histogram settings onto it.
    candidate_hstrain = copy.deepcopy(
        phase.data["Histograms"][hist.name]["HStrain"])
    configure_candidate(project, phase, old_hap, old_hap["Scale"][0], False)
    scale_trace = es.refine(project, 4)
    staged_scale = phase.data["Histograms"][hist.name]["Scale"][0]

    # Restore every mature global/CoWO4 refinement, then give the replacement
    # the same minimal cell/strain/texture/ADP flexibility as the selected WO3.
    es.restore(project, baseline)
    configure_candidate(project, phase, old_hap, staged_scale, True)
    phase.data["Histograms"][hist.name]["HStrain"] = candidate_hstrain
    w_indices = add_shared_w_adp(project, phase)
    full_trace = es.refine(project, 12)
    project.save()

    hist = project.histograms()[0]
    phase = project.phase(args.phase_name)
    cov = project.data.get("Covariance", {}).get("data", {})
    vals = cov.get("Rvals", {})
    result = {
        "removed_phase": removed,
        "candidate_phase": phase.name,
        "candidate_cif": str(Path(args.candidate_cif).resolve()),
        "file": str(Path(args.output).resolve()),
        "rwp_percent": hist.get_wR(),
        "regional_rwp_percent": es.regional(hist),
        "mass_fractions": hist.ComputeMassFracs(),
        "initial_cell": initial_cell,
        "final_cell": list(phase.data["General"]["Cell"][1:8]),
        "hap": phase.data["Histograms"][hist.name],
        "w_atom_indices": w_indices,
        "atoms": [{"label": a.label, "element": a.element,
                   "uiso": a.uiso, "flags": a.refinement_flags}
                  for a in phase.atoms()],
        "convergence": {k: vals.get(k) for k in
                        ("GOF", "Max shft/sig", "SVD0", "converged",
                         "DelChi2", "lamMax", "msg")},
        "top_correlations": top_correlations(project),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}).get("FrozenList", [])],
        "scale_trace": scale_trace,
        "full_trace": full_trace,
    }
    Path(args.output).with_suffix(".json").write_text(
        json.dumps(result, indent=2, default=str) + "\n")
    print("REPLACEMENT_RESULT=" + json.dumps(result, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
