#!/usr/bin/env python3
"""Matched atomic-coordinate refinement branch for selected atoms."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

sys.path.insert(0, str(Path(__file__).resolve().parent))
import envelope_screen as es  # noqa: E402


def atom_summary(phase):
    out = []
    for atom in phase.atoms():
        out.append({
            "label": atom.label,
            "element": atom.element,
            "coordinates": [float(x) for x in atom.coordinates],
            "occupancy": float(atom.occupancy),
            "uiso": float(atom.uiso),
            "refinement_flags": atom.refinement_flags,
        })
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output")
    parser.add_argument("phase_index", type=int)
    parser.add_argument("labels", help="comma-separated atom labels")
    args = parser.parse_args()
    labels = [x.strip() for x in args.labels.split(",") if x.strip()]
    Path(args.output).resolve().parent.mkdir(parents=True, exist_ok=True)

    baseline = G2sc.G2Project(args.base)
    project = G2sc.G2Project(args.base, newgpx=args.output)
    es.freeze(project)
    phase = project.phases()[args.phase_index]
    phase.set_refinements({"Atoms": {label: "X" for label in labels}})
    stage = es.refine(project, 3)

    # restore baseline nuisance flags; coordinates from the staged branch remain
    es.restore(project, baseline)
    phase = project.phases()[args.phase_index]
    phase.set_refinements({"Atoms": {label: "X" for label in labels}})
    full = es.refine(project, 8)
    project.save()

    hist = project.histograms()[0]
    phase = project.phases()[args.phase_index]
    cov = project.data.get("Covariance", {}).get("data", {})
    result = cov.get("Rvals", {})
    coordinate_sigmas = {
        str(v): float(s) for v, s in zip(cov.get("varyList", []), cov.get("sig", []))
        if str(v).split(":")[-1].startswith("dA")
    }
    cif_path = str(Path(args.output).with_suffix(".cif"))
    phase.export_CIF(cif_path, quickmode=True)
    branch = {
        "phase": phase.name,
        "phase_index": args.phase_index,
        "labels": labels,
        "file": str(Path(args.output).resolve()),
        "cif": str(Path(cif_path).resolve()),
        "rwp_percent": hist.get_wR(),
        "regional_rwp_percent": es.regional(hist),
        "atoms": atom_summary(phase),
        "coordinate_sigmas": coordinate_sigmas,
        "convergence": {k: result.get(k) for k in
                        ("GOF", "Max shft/sig", "SVD0", "converged",
                         "DelChi2", "lamMax", "msg")},
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}).get("FrozenList", [])],
        "stage_trace": stage,
        "full_trace": full,
    }
    Path(args.output).with_suffix(".json").write_text(json.dumps(branch, indent=2) + "\n")
    print("COORDINATE_BRANCH_RESULT=" + json.dumps(branch, sort_keys=True))


if __name__ == "__main__":
    main()
