#!/usr/bin/env python3
"""Retest one global CW profile term while preserving a mature baseline."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

sys.path.insert(0, str(Path(__file__).resolve().parent))
import envelope_screen as es  # noqa: E402


STARTS = {"U": 2.0, "V": -2.0, "X": 1.0, "Y": 1.0, "SH/L": 0.002}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output")
    parser.add_argument("term", choices=tuple(STARTS))
    args = parser.parse_args()
    Path(args.output).resolve().parent.mkdir(parents=True, exist_ok=True)

    baseline = G2sc.G2Project(args.base)
    project = G2sc.G2Project(args.base, newgpx=args.output)
    es.freeze(project)
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    inst[args.term][1] = STARTS[args.term]
    inst[args.term][2] = True
    variable = f":0:{args.term}"
    if args.term in ("X", "Y"):
        project.set_Controls("parmMin", 0.0, variable=variable)
    if args.term == "SH/L":
        project.set_Controls("parmMin", 0.0005, variable=variable)
    stage = es.refine(project, 3)
    staged_value = project.histograms()[0].data["Instrument Parameters"][0][args.term][1]

    es.restore(project, baseline)
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    inst[args.term][1] = staged_value
    inst[args.term][2] = True
    full = es.refine(project, 8)
    project.save()

    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    x = np.asarray(hist.getdata("X"), dtype=float)
    theta = np.radians(x / 2.0)
    gaussian = (inst["U"][1] * np.tan(theta) ** 2
                + inst["V"][1] * np.tan(theta) + inst["W"][1])
    lorentz = (inst["X"][1] / np.cos(theta)
               + inst["Y"][1] * np.tan(theta) + inst["Z"][1])
    cov = project.data.get("Covariance", {}).get("data", {})
    result = cov.get("Rvals", {})
    branch = {
        "term": args.term,
        "file": str(Path(args.output).resolve()),
        "rwp_percent": hist.get_wR(),
        "regional_rwp_percent": es.regional(hist),
        "value": inst[args.term][1],
        "target_sigma": {
            str(v): float(s) for v, s in zip(cov.get("varyList", []), cov.get("sig", []))
            if str(v) == variable
        },
        "gaussian_width_sq_min": float(np.min(gaussian)),
        "lorentz_width_min": float(np.min(lorentz)),
        "convergence": {k: result.get(k) for k in
                        ("GOF", "Max shft/sig", "SVD0", "converged",
                         "DelChi2", "lamMax", "msg")},
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}).get("FrozenList", [])],
        "stage_trace": stage,
        "full_trace": full,
    }
    Path(args.output).with_suffix(".json").write_text(json.dumps(branch, indent=2) + "\n")
    print("MATURE_PROFILE_RESULT=" + json.dumps(branch, sort_keys=True))


if __name__ == "__main__":
    main()
