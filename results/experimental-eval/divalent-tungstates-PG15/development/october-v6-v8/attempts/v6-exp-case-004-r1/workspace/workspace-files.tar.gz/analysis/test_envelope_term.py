#!/usr/bin/env python3
"""Matched test for one added envelope parameter on a mature model."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

sys.path.insert(0, str(Path(__file__).resolve().parent))
import envelope_screen as es  # noqa: E402


def correlations(project):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = [str(x) for x in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.size == 0:
        return []
    sigma = np.sqrt(np.diag(matrix))
    corr = matrix / np.outer(sigma, sigma)
    pairs = [(abs(corr[i, j]), corr[i, j], names[i], names[j])
             for i in range(len(names)) for j in range(i)]
    return [{"absolute": float(a), "value": float(v), "first": x, "second": y}
            for a, v, x, y in sorted(pairs, reverse=True)[:15]]


def enable(project, kind, value):
    hist = project.histograms()[0]
    if kind == "roughness_A":
        hist.data["Sample Parameters"]["SurfRoughA"] = [value, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
    else:
        inst = hist.data["Instrument Parameters"][0]
        inst["Polariz."][1], inst["Polariz."][2] = value, True
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output")
    parser.add_argument("kind", choices=("roughness_A", "polarization"))
    args = parser.parse_args()
    Path(args.output).resolve().parent.mkdir(parents=True, exist_ok=True)

    baseline = G2sc.G2Project(args.base)
    project = G2sc.G2Project(args.base, newgpx=args.output)
    es.freeze(project)
    enable(project, args.kind, 0.1 if args.kind == "roughness_A" else 0.7)
    stage = es.refine(project, 4)
    hist = project.histograms()[0]
    if args.kind == "roughness_A":
        value = hist.data["Sample Parameters"]["SurfRoughA"][0]
    else:
        value = hist.data["Instrument Parameters"][0]["Polariz."][1]

    es.restore(project, baseline)
    enable(project, args.kind, value)
    full = es.refine(project, 10)
    project.save()

    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    vals = cov.get("Rvals", {})
    result = {
        "kind": args.kind,
        "file": str(Path(args.output).resolve()),
        "rwp_percent": hist.get_wR(),
        "regional_rwp_percent": es.regional(hist),
        "polarization": hist.data["Instrument Parameters"][0]["Polariz."],
        "surface_roughness_a": hist.data["Sample Parameters"]["SurfRoughA"],
        "surface_roughness_b": hist.data["Sample Parameters"]["SurfRoughB"],
        "convergence": {k: vals.get(k) for k in
                        ("GOF", "Max shft/sig", "SVD0", "converged",
                         "DelChi2", "lamMax", "msg")},
        "top_correlations": correlations(project),
        "stage_trace": stage,
        "full_trace": full,
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}).get("FrozenList", [])],
    }
    Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print("ENVELOPE_TERM_RESULT=" + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
