#!/usr/bin/env python3
"""Compare polarization and Suortti surface-roughness envelope branches."""

from __future__ import annotations

import argparse
import copy
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


REGIONS = ((10.0, 30.0), (30.0, 50.0), (50.0, 70.0),
           (70.0, 85.0), (85.0, 100.0))


def rv(project):
    return dict(project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}))


def regional(hist):
    x = np.asarray(hist.getdata("X"), dtype=float)
    yo = np.asarray(hist.getdata("Yobs"), dtype=float)
    yc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    wt = np.asarray(hist.getdata("Yweight"), dtype=float)
    out = {}
    for lo, hi in REGIONS:
        use = (x >= lo) & (x < hi)
        out[f"{lo:g}-{hi:g}"] = 100.0 * math.sqrt(
            np.sum(wt[use] * (yo[use] - yc[use]) ** 2)
            / np.sum(wt[use] * yo[use] ** 2))
    return out


def freeze(project):
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = False
    for table in (hist.data["Instrument Parameters"][0],
                  hist.data["Sample Parameters"]):
        for value in table.values():
            if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
                value[1] = False
            elif isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
                value[2] = False
    # Instrument parameter flags are stored at index 2.
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.set_refinements({"Atoms": {"all": ""}})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "Pref.Ori.": True, "HStrain": True, "Extinction": True,
        })


def restore(project, baseline):
    hist = project.histograms()[0]
    bhist = baseline.histograms()[0]
    hist.data["Background"][0][1] = bhist.data["Background"][0][1]
    inst = hist.data["Instrument Parameters"][0]
    binst = bhist.data["Instrument Parameters"][0]
    for key, value in inst.items():
        if key in binst and isinstance(value, list) and len(value) > 2:
            value[2] = binst[key][2]
    sample = hist.data["Sample Parameters"]
    bsample = bhist.data["Sample Parameters"]
    for key, value in sample.items():
        if (key in bsample and isinstance(value, list) and len(value) > 1
                and isinstance(value[1], bool)):
            value[1] = bsample[key][1]
    for phase, bphase in zip(project.phases(), baseline.phases()):
        phase.data["General"]["Cell"][0] = bphase.data["General"]["Cell"][0]
        for atom, batom in zip(phase.atoms(), bphase.atoms()):
            atom.refinement_flags = batom.refinement_flags
        hap = phase.data["Histograms"][hist.name]
        bhap = bphase.data["Histograms"][bhist.name]
        for key in ("Scale", "Size", "Mustrain", "Pref.Ori.", "HStrain",
                    "Extinction", "Babinet"):
            if key in bhap:
                hap[key] = copy.deepcopy(bhap[key])


def refine(project, calls, limit=0.08):
    trace = []
    ctrl = project.data["Controls"]["data"]
    ctrl["min dM/M"] = 1e-5
    ctrl["max cyc"] = 10
    for _ in range(calls):
        ctrl["Marquardt"] = 0
        project.save()
        project.refine()
        result = rv(project)
        trace.append({k: result.get(k) for k in
                      ("Rwp", "GOF", "Max shft/sig", "SVD0", "converged",
                       "DelChi2", "lamMax", "msg")})
        if (result.get("converged") and result.get("Max shft/sig") is not None
                and abs(result["Max shft/sig"]) < limit):
            break
    return trace


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("outdir")
    args = parser.parse_args()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    baseline = G2sc.G2Project(args.base)
    bhist = baseline.histograms()[0]
    results = {
        "baseline": {"file": str(Path(args.base).resolve()),
                     "rwp_percent": bhist.get_wR(),
                     "regional_rwp_percent": regional(bhist)},
        "branches": [],
    }

    for kind in ("polarization", "surface_roughness"):
        dest = outdir / f"{kind}.gpx"
        project = G2sc.G2Project(args.base, newgpx=str(dest))
        freeze(project)
        hist = project.histograms()[0]
        if kind == "polarization":
            hist.data["Instrument Parameters"][0]["Polariz."][2] = True
            project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
            project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
        else:
            hist.data["Sample Parameters"]["SurfRoughA"] = [0.1, True]
            hist.data["Sample Parameters"]["SurfRoughB"] = [0.1, True]
            project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
            project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
            project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        stage = refine(project, 3)

        restore(project, baseline)
        hist = project.histograms()[0]
        if kind == "polarization":
            hist.data["Instrument Parameters"][0]["Polariz."][2] = True
        else:
            hist.data["Sample Parameters"]["SurfRoughA"][1] = True
            hist.data["Sample Parameters"]["SurfRoughB"][1] = True
        full = refine(project, 6)
        project.save()
        hist = project.histograms()[0]
        cov = project.data.get("Covariance", {}).get("data", {})
        vary = cov.get("varyList", [])
        sig = cov.get("sig", [])
        param_sigmas = {str(v): float(s) for v, s in zip(vary, sig)
                        if ("Polariz" in str(v) or "SurfRough" in str(v))}
        result = rv(project)
        branch = {
            "kind": kind,
            "file": str(dest),
            "rwp_percent": hist.get_wR(),
            "regional_rwp_percent": regional(hist),
            "polarization": hist.data["Instrument Parameters"][0]["Polariz."],
            "surface_roughness_a": hist.data["Sample Parameters"]["SurfRoughA"],
            "surface_roughness_b": hist.data["Sample Parameters"]["SurfRoughB"],
            "parameter_sigmas": param_sigmas,
            "convergence": {k: result.get(k) for k in
                            ("GOF", "Max shft/sig", "SVD0", "converged",
                             "DelChi2", "lamMax", "msg")},
            "stage_trace": stage,
            "full_trace": full,
        }
        results["branches"].append(branch)
        print("ENVELOPE_BRANCH=" + json.dumps(branch, sort_keys=True))

    (outdir / "envelope_screen.json").write_text(json.dumps(results, indent=2) + "\n")
    print("ENVELOPE_RESULT=" + json.dumps(results, sort_keys=True))


if __name__ == "__main__":
    main()
