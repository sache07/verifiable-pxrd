#!/usr/bin/env python3
"""Restore an audited coordinate set and reconverge all nuisance terms."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

sys.path.insert(0, str(Path(__file__).resolve().parent))
import envelope_screen as es  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("reference")
    parser.add_argument("output")
    parser.add_argument("phase_name")
    args = parser.parse_args()
    Path(args.output).resolve().parent.mkdir(parents=True, exist_ok=True)

    project = G2sc.G2Project(args.base, newgpx=args.output)
    reference = G2sc.G2Project(args.reference)
    phase = project.phase(args.phase_name)
    ref_phase = reference.phase(args.phase_name)
    ref_atoms = {atom.label: atom for atom in ref_phase.atoms()}
    restored = []
    for atom in phase.atoms():
        source = ref_atoms[atom.label]
        atom.coordinates = list(source.coordinates)
        atom.refinement_flags = atom.refinement_flags.replace("X", "")
        restored.append({"label": atom.label,
                         "coordinates": list(atom.coordinates)})

    trace = es.refine(project, 12)
    project.save()
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    values = cov.get("Rvals", {})
    cif = str(Path(args.output).with_suffix(".cif"))
    project.phase(args.phase_name).export_CIF(cif, quickmode=True)
    result = {
        "file": str(Path(args.output).resolve()),
        "reference": str(Path(args.reference).resolve()),
        "phase": args.phase_name,
        "cif": str(Path(cif).resolve()),
        "restored_atoms": restored,
        "rwp_percent": hist.get_wR(),
        "regional_rwp_percent": es.regional(hist),
        "mass_fractions": hist.ComputeMassFracs(),
        "convergence": {k: values.get(k) for k in
                        ("GOF", "Max shft/sig", "SVD0", "converged",
                         "DelChi2", "lamMax", "msg")},
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}).get("FrozenList", [])],
        "trace": trace,
    }
    Path(args.output).with_suffix(".json").write_text(
        json.dumps(result, indent=2, default=str) + "\n")
    print("FIXED_COORDINATE_RESULT=" + json.dumps(
        result, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
