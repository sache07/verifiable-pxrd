#!/usr/bin/env python3
"""Matched one-axis March-Dollase preferred-orientation branch."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

sys.path.insert(0, str(Path(__file__).resolve().parent))
import envelope_screen as es  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output")
    parser.add_argument("phase_index", type=int)
    parser.add_argument("h", type=int)
    parser.add_argument("k", type=int)
    parser.add_argument("l", type=int)
    args = parser.parse_args()
    Path(args.output).resolve().parent.mkdir(parents=True, exist_ok=True)
    axis = [args.h, args.k, args.l]

    baseline = G2sc.G2Project(args.base)
    project = G2sc.G2Project(args.base, newgpx=args.output)
    es.freeze(project)
    hist = project.histograms()[0]
    phase = project.phases()[args.phase_index]
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 1.0, True, axis
    variable = f"{args.phase_index}:0:MD"
    project.set_Controls("parmMin", 0.2, variable=variable)
    project.set_Controls("parmMax", 5.0, variable=variable)
    stage = es.refine(project, 3)
    staged_value = project.phases()[args.phase_index].data[
        "Histograms"][hist.name]["Pref.Ori."][1]

    es.restore(project, baseline)
    hist = project.histograms()[0]
    phase = project.phases()[args.phase_index]
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", staged_value, True, axis
    full = es.refine(project, 8)
    project.save()

    hist = project.histograms()[0]
    phase = project.phases()[args.phase_index]
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    cov = project.data.get("Covariance", {}).get("data", {})
    result = cov.get("Rvals", {})
    branch = {
        "phase": phase.name,
        "phase_index": args.phase_index,
        "axis": axis,
        "file": str(Path(args.output).resolve()),
        "rwp_percent": hist.get_wR(),
        "regional_rwp_percent": es.regional(hist),
        "march_dollase": po,
        "target_sigma": {
            str(v): float(s) for v, s in zip(cov.get("varyList", []), cov.get("sig", []))
            if str(v) == variable
        },
        "convergence": {k: result.get(k) for k in
                        ("GOF", "Max shft/sig", "SVD0", "converged",
                         "DelChi2", "lamMax", "msg")},
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}).get("FrozenList", [])],
        "stage_trace": stage,
        "full_trace": full,
    }
    Path(args.output).with_suffix(".json").write_text(json.dumps(branch, indent=2) + "\n")
    print("TEXTURE_BRANCH_RESULT=" + json.dumps(branch, sort_keys=True))


if __name__ == "__main__":
    main()
