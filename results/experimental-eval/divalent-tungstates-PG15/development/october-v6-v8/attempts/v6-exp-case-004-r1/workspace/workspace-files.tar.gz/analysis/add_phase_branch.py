#!/usr/bin/env python3
"""Retest one fixed atomistic phase against a mature powder model."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

sys.path.insert(0, str(Path(__file__).resolve().parent))
import envelope_screen as es  # noqa: E402


def configure_candidate(project, phase, scale):
    hist = project.histograms()[0]
    pid = phase.data["pId"]
    hap = phase.data["Histograms"][hist.name]
    phase.data["General"]["Cell"][0] = False
    phase.set_refinements({"Atoms": {"all": ""}})
    hap["Scale"] = [max(float(scale), 1e-8), True]
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][1:4] = [1.0, False, [0, 0, 1]]
    if "HStrain" in hap:
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    return f"{pid}:0:Scale"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output")
    parser.add_argument("candidate_cif")
    parser.add_argument("phase_name")
    args = parser.parse_args()
    Path(args.output).resolve().parent.mkdir(parents=True, exist_ok=True)

    baseline = G2sc.G2Project(args.base)
    base_hist = baseline.histograms()[0]
    project = G2sc.G2Project(args.base, newgpx=args.output)
    es.freeze(project)
    hist = project.histograms()[0]
    phase = project.add_phase(args.candidate_cif, phasename=args.phase_name,
                              histograms=[hist])
    variable = configure_candidate(project, phase, 0.1)
    stage = es.refine(project, 4)
    phase = project.phase(args.phase_name)
    staged_scale = phase.data["Histograms"][hist.name]["Scale"][0]

    # Re-enable all refinements in the mature two-phase model, retaining only
    # a scale degree of freedom for the tested phase. Its structure and cell
    # remain fixed so overlap cannot be converted into a spurious cell match.
    es.restore(project, baseline)
    phase = project.phase(args.phase_name)
    configure_candidate(project, phase, max(staged_scale, 1e-8))
    full = es.refine(project, 8)
    project.save()

    hist = project.histograms()[0]
    phase = project.phase(args.phase_name)
    cov = project.data.get("Covariance", {}).get("data", {})
    vals = cov.get("Rvals", {})
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:  # pragma: no cover
        fractions = {"error": str(exc)}
    result = {
        "candidate": phase.name,
        "candidate_cif": str(Path(args.candidate_cif).resolve()),
        "file": str(Path(args.output).resolve()),
        "baseline_rwp_percent": base_hist.get_wR(),
        "rwp_percent": hist.get_wR(),
        "regional_rwp_percent": es.regional(hist),
        "staged_scale": staged_scale,
        "final_scale": phase.data["Histograms"][hist.name]["Scale"],
        "scale_sigma": {
            str(v): float(s) for v, s in zip(cov.get("varyList", []),
                                             cov.get("sig", []))
            if str(v) == variable
        },
        "mass_fractions": fractions,
        "convergence": {k: vals.get(k) for k in
                        ("GOF", "Max shft/sig", "SVD0", "converged",
                         "DelChi2", "lamMax", "msg")},
        "frozen": [str(v) for v in project.data["Controls"]["data"].get(
            "parmFrozen", {}).get("FrozenList", [])],
        "stage_trace": stage,
        "full_trace": full,
    }
    Path(args.output).with_suffix(".json").write_text(
        json.dumps(result, indent=2, default=str) + "\n")
    print("ADD_PHASE_RESULT=" + json.dumps(result, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
