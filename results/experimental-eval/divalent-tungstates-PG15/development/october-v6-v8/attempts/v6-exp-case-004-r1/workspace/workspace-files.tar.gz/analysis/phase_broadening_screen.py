#!/usr/bin/env python3
"""Matched isotropic crystallite-size and microstrain branch screen."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


REGIONS = ((10.0, 30.0), (30.0, 50.0), (50.0, 70.0),
           (70.0, 85.0), (85.0, 100.0))


def rvals(project):
    return dict(project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}))


def regional_rwp(hist):
    x = np.asarray(hist.getdata("X"), dtype=float)
    yo = np.asarray(hist.getdata("Yobs"), dtype=float)
    yc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    wt = np.asarray(hist.getdata("Yweight"), dtype=float)
    out = {}
    for lo, hi in REGIONS:
        use = (x >= lo) & (x < hi)
        out[f"{lo:g}-{hi:g}"] = 100.0 * math.sqrt(
            np.sum(wt[use] * (yo[use] - yc[use]) ** 2)
            / np.sum(wt[use] * yo[use] ** 2))
    return out


def freeze_nuisance(project):
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = False
    for entry in hist.data["Instrument Parameters"][0].values():
        if isinstance(entry, list) and len(entry) > 2:
            entry[2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})


def restore_nuisance(project, instrument_flags):
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    inst = hist.data["Instrument Parameters"][0]
    for key, flag in instrument_flags.items():
        if key in inst and len(inst[key]) > 2:
            inst[key][2] = flag
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def refine(project, calls, shift_limit=0.08):
    trace = []
    ctrl = project.data["Controls"]["data"]
    ctrl["min dM/M"] = 1e-5
    ctrl["max cyc"] = 10
    for _ in range(calls):
        ctrl["Marquardt"] = 0
        project.save()
        project.refine()
        rv = rvals(project)
        trace.append({k: rv.get(k) for k in
                      ("Rwp", "GOF", "Max shft/sig", "SVD0", "converged",
                       "DelChi2", "lamMax", "msg")})
        if (rv.get("converged") and rv.get("Max shft/sig") is not None
                and abs(rv["Max shft/sig"]) < shift_limit):
            break
    return trace


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("outdir")
    args = parser.parse_args()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    baseline = G2sc.G2Project(args.base)
    base_hist = baseline.histograms()[0]
    base_inst = base_hist.data["Instrument Parameters"][0]
    instrument_flags = {
        key: bool(value[2]) for key, value in base_inst.items()
        if isinstance(value, list) and len(value) > 2
    }
    results = {
        "baseline": {
            "file": str(Path(args.base).resolve()),
            "rwp_percent": base_hist.get_wR(),
            "regional_rwp_percent": regional_rwp(base_hist),
        },
        "branches": [],
    }

    for phase_index, base_phase in enumerate(baseline.phases()):
        for kind in ("Size", "Mustrain"):
            slug = base_phase.name.replace(" ", "_")
            destination = outdir / f"{slug}_{kind.lower()}.gpx"
            project = G2sc.G2Project(args.base, newgpx=str(destination))
            freeze_nuisance(project)
            phase = project.phases()[phase_index]
            if kind == "Size":
                phase.set_HAP_refinements({
                    "Size": {"type": "isotropic", "value": 1.0,
                             "refine": True}
                })
            else:
                hap = phase.data["Histograms"][project.histograms()[0].name]
                hap["Mustrain"][0] = "isotropic"
                hap["Mustrain"][1][0] = 1000.0
                hap["Mustrain"][2][0] = True
            stage_trace = refine(project, 3)

            restore_nuisance(project, instrument_flags)
            phase = project.phases()[phase_index]
            hap = phase.data["Histograms"][project.histograms()[0].name]
            if kind == "Size":
                hap["Size"][2][0] = True
            else:
                hap["Mustrain"][2][0] = True
            full_trace = refine(project, 6)
            project.save()

            hist = project.histograms()[0]
            phase = project.phases()[phase_index]
            hap = phase.data["Histograms"][hist.name]
            cov = project.data.get("Covariance", {}).get("data", {})
            vary = cov.get("varyList", [])
            sig = cov.get("sig", [])
            broadening_sigmas = {
                str(name): float(sigma) for name, sigma in zip(vary, sig)
                if kind.lower() in str(name).lower()
            }
            rv = rvals(project)
            branch = {
                "phase": phase.name,
                "phase_index": phase_index,
                "kind": kind,
                "file": str(destination),
                "rwp_percent": hist.get_wR(),
                "regional_rwp_percent": regional_rwp(hist),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "broadening_sigmas": broadening_sigmas,
                "convergence": {k: rv.get(k) for k in
                                ("GOF", "Max shft/sig", "SVD0", "converged",
                                 "DelChi2", "lamMax", "msg")},
                "stage_trace": stage_trace,
                "full_trace": full_trace,
                "frozen": [str(v) for v in project.data["Controls"]["data"].get(
                    "parmFrozen", {}).get("FrozenList", [])],
            }
            results["branches"].append(branch)
            print("PHASE_BROADENING_BRANCH=" + json.dumps(branch, sort_keys=True))

    result_path = outdir / "phase_broadening_screen.json"
    result_path.write_text(json.dumps(results, indent=2) + "\n")
    print("PHASE_BROADENING_RESULT=" + json.dumps(results, sort_keys=True))


if __name__ == "__main__":
    main()
