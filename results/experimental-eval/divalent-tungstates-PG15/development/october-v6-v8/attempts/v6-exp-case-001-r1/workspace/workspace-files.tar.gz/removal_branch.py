#!/usr/bin/env python3
"""Run a matched leave-one-term-out refinement from a stable GSAS-II project."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def remove_term(project: G2sc.G2Project, target: str) -> None:
    histogram = project.histograms()[0]
    kind, value = target.split(":", 1)
    if kind == "instrument":
        parameter = histogram.InstrumentParameters[value]
        parameter[1] = float(parameter[0])
        parameter[2] = False
        return
    if kind == "sample":
        parameter = histogram.SampleParameters[value]
        parameter[0] = 0.0 if value == "Shift" else float(parameter[0])
        parameter[1] = False
        return
    phase = project.phase(value)
    if phase is None:
        raise ValueError(f"unknown phase {value!r}")
    hap = phase.data["Histograms"][histogram.name]
    if kind == "mustrain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        return
    if kind == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False] * len(hap["Size"][2])
        return
    if kind == "texture":
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        return
    raise ValueError(target)


def stable_refine(project: G2sc.G2Project, attempts: int = 2) -> bool:
    project.set_Controls("cycles", 10)
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as error:
            print("REFINEMENT_ERROR", repr(error))
            return False
        status = covariance_status(project)
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in message:
            return False
        if status.get("converged") and abs(float(status.get("Max shft/sig") or 0.0)) < 0.08:
            return True
    return False


def region_rwps(histogram) -> dict[str, float]:
    x, observed, weight, calculated = (
        np.asarray(row, dtype=float) for row in histogram.data["data"][1][:4]
    )
    result = {}
    for lower, upper in ((9.9, 30.0), (30.0, 50.0), (50.0, 70.0), (70.0, 100.1)):
        mask = (x >= lower) & (x < upper) & (weight > 0.0)
        numerator = np.sum(weight[mask] * (observed[mask] - calculated[mask]) ** 2)
        denominator = np.sum(weight[mask] * observed[mask] ** 2)
        result[f"{lower:.1f}-{upper:.1f}"] = 100.0 * math.sqrt(numerator / denominator)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("target")
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()))
    remove_term(project, args.target)
    project.save(str(args.output.resolve()))
    valid = stable_refine(project)
    project.save(str(args.output.resolve()))
    histogram = project.histograms()[0]
    status = covariance_status(project)
    print(
        "REMOVAL_BRANCH_RESULT="
        + json.dumps(
            {
                "removed": args.target,
                "valid": valid,
                "rwp_percent": histogram.get_wR(),
                "region_rwp_percent": region_rwps(histogram),
                "convergence": {
                    key: status.get(key)
                    for key in ("converged", "SVD0", "Max shft/sig", "msg")
                },
            }
        )
    )


if __name__ == "__main__":
    main()
