#!/usr/bin/env python3
"""Create and minimally refine matched GSAS-II screening branches."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2sc


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, attempts: int = 5) -> bool:
    """Refine repeatedly until converged or a numerical warning is encountered."""
    project.set_Controls("cycles", 12)
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as error:
            print("REFINEMENT_ERROR", repr(error))
            return False
        status = covariance_status(project)
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in message:
            return False
        if status.get("converged") and float(status.get("Max shft/sig") or 0.0) < 0.1:
            return True
    return bool(covariance_status(project).get("converged"))


def set_initial_background(histogram) -> None:
    arrays = histogram.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    y = np.asarray(arrays[1], dtype=float)
    step = float(np.median(np.diff(x)))
    window = max(5, int(round(2.5 / step)) | 1)
    baseline = percentile_filter(y, percentile=12, size=window, mode="nearest")
    transformed = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    coefficients = np.polynomial.chebyshev.chebfit(transformed, baseline, deg=9)
    histogram.data["Background"][0] = [
        "chebyschev-1",
        False,
        len(coefficients),
        *map(float, coefficients),
    ]


def set_profile(histogram) -> None:
    values = {
        "U": 1200.0,
        "V": 0.0,
        "W": 80.0,
        "X": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Zero": 0.0,
        "Polariz.": 0.7,
        "I(L2)/I(L1)": 0.5,
    }
    for name, value in values.items():
        parameter = histogram.InstrumentParameters[name]
        parameter[1] = value
        parameter[2] = False


def profile_is_physical(project: G2sc.G2Project) -> bool:
    inst = project.histograms()[0].InstrumentParameters
    # Require positive Caglioti variance over the full half-angle range and
    # nonnegative Lorentzian width terms retained in this screening model.
    u, v, w = (float(inst[key][1]) for key in ("U", "V", "W"))
    x, y, z = (float(inst[key][1]) for key in ("X", "Y", "Z"))
    for two_theta in np.linspace(9.9, 100.1, 181):
        tangent = math.tan(math.radians(two_theta / 2.0))
        if u * tangent * tangent + v * tangent + w <= 0.0:
            return False
        if x / math.cos(math.radians(two_theta / 2.0)) + y * tangent + z < 0.0:
            return False
    return True


def branch_summary(project: G2sc.G2Project, valid: bool, stages: list[dict]) -> dict:
    histogram = project.histograms()[0]
    try:
        fractions = {
            name: {"value": value, "esd": esd}
            for name, (value, esd) in histogram.ComputeMassFracs().items()
        }
    except Exception as error:
        fractions = {"error": repr(error)}
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "size": hap.get("Size"),
                "mustrain": hap.get("Mustrain"),
            }
        )
    return {
        "project": project.filename,
        "valid": valid,
        "rwp_percent": histogram.get_wR(),
        "fractions": fractions,
        "instrument": histogram.InstrumentParameters,
        "convergence": covariance_status(project),
        "phases": phases,
        "stages": stages,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--no-profile", action="store_true")
    parser.add_argument(
        "phase", nargs="+", help="phase specification as NAME=/absolute/path/model.cif"
    )
    args = parser.parse_args()
    output = args.output.resolve()
    start = output.with_name(output.stem + "-start.gpx")

    project = G2sc.G2Project(newgpx=str(start))
    histogram = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    histogram.SampleParameters["Scale"][1] = False
    set_initial_background(histogram)
    set_profile(histogram)
    for specification in args.phase:
        name, path = specification.split("=", 1)
        phase = project.add_phase(
            path, phasename=name, histograms=project.histograms(), fmthint="CIF"
        )
        phase.set_HAP_refinements({"Scale": True})
    project.save(str(start))

    # Repoint all refinement byproducts away from the immutable branch start.
    project = G2sc.G2Project(str(start))
    project.save(str(output))
    histogram = project.histograms()[0]
    stages: list[dict] = []

    histogram.set_refinements({"Background": {"refine": True}})
    valid = stable_refine(project)
    stages.append({"stage": "background_scales", "valid": valid, "rwp": histogram.get_wR()})
    if not valid:
        project.save(str(output))
        print("BRANCH_RESULT=" + json.dumps(branch_summary(project, False, stages)))
        return

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    valid = stable_refine(project)
    stages.append({"stage": "cells", "valid": valid, "rwp": histogram.get_wR()})
    project.save(str(output.with_name(output.stem + "-cells.gpx")))
    if not valid:
        project.save(str(output))
        print("BRANCH_RESULT=" + json.dumps(branch_summary(project, False, stages)))
        return

    if args.no_profile:
        project.save(str(output))
        print("BRANCH_RESULT=" + json.dumps(branch_summary(project, True, stages)))
        return

    # Matched minimal global profile branch. Keep only a physically positive
    # result that improves the complete-pattern fit.
    cell_rwp = float(histogram.get_wR())
    profile_path = output.with_name(output.stem + "-profile.gpx")
    candidate = G2sc.G2Project(str(output.with_name(output.stem + "-cells.gpx")))
    candidate.save(str(profile_path))
    candidate_histogram = candidate.histograms()[0]
    candidate_histogram.set_refinements(
        {"Instrument Parameters": ["U", "W", "Y"]}
    )
    profile_valid = stable_refine(candidate) and profile_is_physical(candidate)
    profile_rwp = float(candidate_histogram.get_wR())
    stages.append(
        {
            "stage": "global_profile_U_W_Y",
            "valid": profile_valid,
            "rwp": profile_rwp,
        }
    )
    if profile_valid and profile_rwp < cell_rwp - 0.005:
        project = candidate
        project.save(str(output))
        valid = True
    else:
        project = G2sc.G2Project(str(output.with_name(output.stem + "-cells.gpx")))
        project.save(str(output))
        valid = True

    print("BRANCH_RESULT=" + json.dumps(branch_summary(project, valid, stages)))


if __name__ == "__main__":
    main()
