#!/usr/bin/env python3
"""Test one optional GSAS-II profile, microstructure, or envelope term."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, attempts: int = 8) -> bool:
    project.set_Controls("cycles", 10)
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as error:
            print("REFINEMENT_ERROR", repr(error))
            return False
        result = status(project)
        message = str(result.get("msg", "") or "").lower()
        if result.get("Aborted") or result.get("SVD0", 0) or "dropped" in message:
            return False
        if result.get("converged") and float(result.get("Max shft/sig") or 0.0) < 0.08:
            return True
    result = status(project)
    return bool(
        result.get("converged")
        and float(result.get("Max shft/sig") or math.inf) < 0.15
    )


def freeze_all(project: G2sc.G2Project) -> None:
    histogram = project.histograms()[0]
    histogram.Background[0][1] = False
    for parameter in histogram.InstrumentParameters.values():
        if isinstance(parameter, list) and len(parameter) >= 3:
            parameter[2] = False
    for parameter in histogram.SampleParameters.values():
        if isinstance(parameter, list) and len(parameter) == 2:
            parameter[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.data["Atoms"]:
            atom[2] = ""
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
        for parameter in hap.get("Babinet", {}).values():
            parameter[1] = False


def restore_flags(project: G2sc.G2Project, template: G2sc.G2Project) -> None:
    histogram = project.histograms()[0]
    source_histogram = template.histograms()[0]
    histogram.Background[0][1] = source_histogram.Background[0][1]
    for key, source in source_histogram.InstrumentParameters.items():
        parameter = histogram.InstrumentParameters.get(key)
        if isinstance(parameter, list) and len(parameter) >= 3:
            parameter[2] = source[2]
    for key, source in source_histogram.SampleParameters.items():
        parameter = histogram.SampleParameters.get(key)
        if isinstance(parameter, list) and len(parameter) == 2:
            parameter[1] = source[1]
    for phase in project.phases():
        source_phase = template.phase(phase.name)
        phase.data["General"]["Cell"][0] = source_phase.data["General"]["Cell"][0]
        for atom, source_atom in zip(phase.data["Atoms"], source_phase.data["Atoms"]):
            atom[2] = source_atom[2]
        hap = phase.data["Histograms"][histogram.name]
        source_hap = source_phase.data["Histograms"][source_histogram.name]
        hap["Scale"][1] = source_hap["Scale"][1]
        hap["Pref.Ori."][2] = source_hap["Pref.Ori."][2]
        hap["Size"][2] = list(source_hap["Size"][2])
        hap["Mustrain"][2] = list(source_hap["Mustrain"][2])
        hap["HStrain"][1] = list(source_hap["HStrain"][1])
        hap["Extinction"][1] = source_hap["Extinction"][1]
        for key, source_parameter in source_hap.get("Babinet", {}).items():
            hap["Babinet"][key][1] = source_parameter[1]


def set_target(project: G2sc.G2Project, target: str) -> None:
    histogram = project.histograms()[0]
    kind, value = target.split(":", 1)
    if kind == "instrument":
        for name in value.split(","):
            histogram.InstrumentParameters[name][2] = True
        return
    if kind == "sample":
        names = value.split(",")
        if any(name.startswith("SurfRough") for name in names):
            if (
                float(histogram.SampleParameters["SurfRoughA"][0]) == 0.0
                and float(histogram.SampleParameters["SurfRoughB"][0]) == 0.0
            ):
                histogram.SampleParameters["SurfRoughA"][0] = 0.5
                histogram.SampleParameters["SurfRoughB"][0] = 0.01
        for name in names:
            histogram.SampleParameters[name][1] = True
        return
    if kind in {"mustrain", "size"}:
        phase = project.phase(value)
        if phase is None:
            raise ValueError(f"unknown phase {value!r}")
        if kind == "mustrain":
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
        else:
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "refine": True}}
            )
        return
    if kind == "texture":
        name, axis_text = value.rsplit(":", 1)
        phase = project.phase(name)
        if phase is None:
            raise ValueError(f"unknown phase {name!r}")
        axis = [int(item) for item in axis_text.split(",")]
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        return
    if kind in {"coordinates", "uiso"}:
        phase = project.phase(value)
        if phase is None:
            raise ValueError(f"unknown phase {value!r}")
        flag = "X" if kind == "coordinates" else "U"
        phase.set_refinements({"Atoms": {"all": flag}})
        return
    raise ValueError(target)


def physical(project: G2sc.G2Project, target: str) -> tuple[bool, str]:
    histogram = project.histograms()[0]
    instrument = histogram.InstrumentParameters
    u, v, w = (float(instrument[key][1]) for key in ("U", "V", "W"))
    x, y, z = (float(instrument[key][1]) for key in ("X", "Y", "Z"))
    for two_theta in np.linspace(9.9, 100.1, 181):
        tangent = math.tan(math.radians(two_theta / 2.0))
        sigma = u * tangent * tangent + v * tangent + w
        gamma = x / math.cos(math.radians(two_theta / 2.0)) + y * tangent + z
        if not math.isfinite(sigma) or sigma <= 0.0:
            return False, f"nonpositive global Gaussian variance at {two_theta}"
        if not math.isfinite(gamma) or gamma < 0.0:
            return False, f"negative global Lorentzian width at {two_theta}"
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        if float(hap["Size"][1][0]) <= 0.0:
            return False, f"nonpositive size in {phase.name}"
        if float(hap["Mustrain"][1][0]) < 0.0:
            return False, f"negative microstrain in {phase.name}"
        ratio = float(hap["Pref.Ori."][1])
        if not math.isfinite(ratio) or ratio <= 0.0:
            return False, f"invalid March-Dollase ratio in {phase.name}"
        for atom in phase.atoms():
            if not (0.0 < float(atom.occupancy) <= 1.0001):
                return False, f"invalid occupancy for {phase.name}:{atom.label}"
            if atom.adp_flag == "I" and float(atom.uiso) < 0.0:
                return False, f"negative Uiso for {phase.name}:{atom.label}"
    rough_a = float(histogram.SampleParameters.get("SurfRoughA", [0.0])[0])
    rough_b = float(histogram.SampleParameters.get("SurfRoughB", [0.0])[0])
    if rough_a < 0.0 or rough_a > 1.0 or rough_b < 0.0:
        return False, "invalid surface roughness parameters"
    return True, "pass"


def summarize(project: G2sc.G2Project, target: str, valid: bool, reason: str) -> dict:
    histogram = project.histograms()[0]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases[phase.name] = {
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return {
        "target": target,
        "valid": valid,
        "reason": reason,
        "rwp_percent": histogram.get_wR(),
        "instrument": histogram.InstrumentParameters,
        "sample": histogram.SampleParameters,
        "phases": phases,
        "convergence": {
            key: status(project).get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp")
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("target")
    args = parser.parse_args()
    source = args.source.resolve()
    output = args.output.resolve()

    project = G2sc.G2Project(str(source))
    template = G2sc.G2Project(str(source))
    freeze_all(project)
    set_target(project, args.target)
    project.save(str(output))
    valid = stable_refine(project)
    if valid:
        restore_flags(project, template)
        set_target(project, args.target)
        valid = stable_refine(project)
    physical_status, reason = physical(project, args.target)
    valid = valid and physical_status
    project.save(str(output))
    print("TERM_BRANCH_RESULT=" + json.dumps(summarize(project, args.target, valid, reason)))


if __name__ == "__main__":
    main()
