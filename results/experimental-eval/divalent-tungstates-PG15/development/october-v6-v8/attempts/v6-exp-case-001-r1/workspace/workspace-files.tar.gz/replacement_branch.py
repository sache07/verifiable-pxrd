#!/usr/bin/env python3
"""Retest a candidate structure as a one-for-one phase replacement."""

from __future__ import annotations

import argparse
import copy
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, attempts: int = 10) -> bool:
    project.set_Controls("cycles", 10)
    for _ in range(attempts):
        project.data.setdefault("Covariance", {}).setdefault("data", {})["Rvals"] = {}
        try:
            project.refine()
        except Exception as error:
            print("REFINEMENT_ERROR", repr(error))
            return False
        result = covariance_status(project)
        if not result:
            return False
        message = str(result.get("msg", "") or "").lower()
        if result.get("Aborted") or result.get("SVD0", 0) or "dropped" in message:
            return False
        if result.get("converged") and float(result.get("Max shft/sig") or 0.0) < 0.08:
            return True
    result = covariance_status(project)
    return bool(
        result.get("converged")
        and float(result.get("Max shft/sig") or math.inf) < 0.15
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("old_phase")
    parser.add_argument("new_phase")
    parser.add_argument("candidate", type=Path)
    args = parser.parse_args()

    output = args.output.resolve()
    project = G2sc.G2Project(str(args.source.resolve()))
    template = G2sc.G2Project(str(args.source.resolve()))
    project.save(str(output))
    histogram = project.histograms()[0]
    old = project.phase(args.old_phase)
    old_hap = old.data["Histograms"][histogram.name]
    old_mustrain_refine = list(old_hap["Mustrain"][2])
    old_preferred_orientation_refine = bool(old_hap["Pref.Ori."][2])
    old_hap["Use"] = False
    old_scale = float(old_hap["Scale"][0])
    old_hap["Scale"][0] = 0.0
    old_hap["Scale"][1] = False

    new = project.add_phase(
        str(args.candidate.resolve()),
        phasename=args.new_phase,
        histograms=project.histograms(),
        fmthint="CIF",
    )
    new_hap = new.data["Histograms"][histogram.name]
    new_hap["Use"] = True
    new_hap["Scale"] = [old_scale, True]
    new.data["General"]["Cell"][0] = True
    new_hap["Size"][1] = list(old_hap["Size"][1])
    new_hap["Mustrain"][1] = list(old_hap["Mustrain"][1])
    if old_mustrain_refine[0]:
        new_hap["Mustrain"][0] = "isotropic"
        new_hap["Mustrain"][2][0] = True
    if old_preferred_orientation_refine:
        new_hap["Pref.Ori."][:4] = [
            old_hap["Pref.Ori."][0],
            old_hap["Pref.Ori."][1],
            True,
            list(old_hap["Pref.Ori."][3]),
        ]

    # First fit only active phase scales and background with all peak-position,
    # profile and microstructure terms fixed. This avoids cell collapse when a
    # replacement uses a substantially different setting.
    histogram.Background[0][1] = True
    for parameter in histogram.InstrumentParameters.values():
        if isinstance(parameter, list) and len(parameter) >= 3:
            parameter[2] = False
    for parameter in histogram.SampleParameters.values():
        if isinstance(parameter, list) and len(parameter) == 2:
            parameter[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = bool(hap.get("Use", True) and hap["Scale"][0] != 0.0)
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    project.save(str(output))
    valid = stable_refine(project)
    if valid:
        new.data["General"]["Cell"][0] = True
        valid = stable_refine(project)
    if valid:
        source_histogram = template.histograms()[0]
        histogram.Background[0][1] = source_histogram.Background[0][1]
        for key, source_parameter in source_histogram.InstrumentParameters.items():
            if key in histogram.InstrumentParameters:
                histogram.InstrumentParameters[key][2] = source_parameter[2]
        for key, source_parameter in source_histogram.SampleParameters.items():
            parameter = histogram.SampleParameters.get(key)
            if isinstance(parameter, list) and len(parameter) == 2:
                parameter[1] = source_parameter[1]
        for phase in project.phases():
            if phase.name in (args.old_phase, args.new_phase):
                continue
            source_phase = template.phase(phase.name)
            phase.data["General"]["Cell"][0] = source_phase.data["General"]["Cell"][0]
            hap = phase.data["Histograms"][histogram.name]
            source_hap = source_phase.data["Histograms"][source_histogram.name]
            for key in ("Scale", "Pref.Ori.", "Size", "Mustrain"):
                if key == "Scale":
                    hap[key][1] = source_hap[key][1]
                elif key == "Pref.Ori.":
                    hap[key][2] = source_hap[key][2]
                else:
                    hap[key][2] = list(source_hap[key][2])
        new.data["General"]["Cell"][0] = True
        new_hap["Scale"][1] = True
        new_hap["Mustrain"][2] = list(old_mustrain_refine)
        new_hap["Pref.Ori."][2] = old_preferred_orientation_refine
        valid = stable_refine(project)
    project.save(str(output))
    result = {
        "valid": valid,
        "rwp_percent": histogram.get_wR(),
        "candidate": str(args.candidate),
        "old_phase": args.old_phase,
        "new_phase": args.new_phase,
        "cell": new.get_cell(),
        "scale": new_hap["Scale"],
        "mustrain": new_hap["Mustrain"],
        "preferred_orientation": new_hap["Pref.Ori."],
        "convergence": {
            key: covariance_status(project).get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp")
        },
    }
    print("REPLACEMENT_BRANCH_RESULT=" + json.dumps(result))


if __name__ == "__main__":
    main()
