#!/usr/bin/env python3
"""Converge the selected GSAS-II model and export all requested deliverables."""

from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "learned"))
from profile_regeneration import regenerate_profile  # noqa: E402


SOURCE = ROOT / "models" / "p21c_noW_angular.gpx"
FINAL = ROOT / "final.gpx"


def status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def converge_final() -> None:
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(FINAL))
    project.set_Controls("cycles", 10)
    stable = False
    for _ in range(6):
        project.refine()
        result = status(project)
        message = str(result.get("msg", "") or "").lower()
        if result.get("Aborted") or result.get("SVD0", 0) or "dropped" in message:
            raise RuntimeError(f"final refinement failed integrity checks: {result}")
        if result.get("converged") and abs(float(result.get("Max shft/sig") or 0.0)) < 0.05:
            stable = True
            break
    if not stable:
        raise RuntimeError(f"final refinement did not stabilize: {status(project)}")
    project.save(str(FINAL))
    regenerate_profile(FINAL)


def export_outputs() -> dict:
    project = G2sc.G2Project(str(FINAL))
    histogram = project.histograms()[0]
    fractions = histogram.ComputeMassFracs()
    phase_metadata = {
        "BaCO3": {
            "display_name": "BaCO3 (witherite)",
            "formula": "BaCO3",
            "space_group": "Pmcn (No. 62; setting-equivalent to Pnma)",
            "cif_path": "phase_BaCO3.cif",
            "source_structure": "COD 9010928",
        },
        "WO3": {
            "display_name": "WO3 (monoclinic)",
            "formula": "WO3",
            "space_group": "P21/c (No. 14)",
            "cif_path": "phase_WO3.cif",
            "source_structure": "COD 2311041",
        },
    }

    phase_rows = []
    for phase in project.phases():
        if phase.name not in phase_metadata:
            continue
        metadata = phase_metadata[phase.name]
        cif_path = ROOT / metadata["cif_path"]
        phase.export_CIF(str(cif_path))
        fraction, fraction_esd = fractions[phase.name]
        cell = phase.get_cell()
        phase_rows.append(
            {
                "name": metadata["display_name"],
                "formula": metadata["formula"],
                "space_group": metadata["space_group"],
                "cif_path": metadata["cif_path"],
                "weight_fraction": float(fraction),
                "weight_fraction_formal_esd": float(fraction_esd),
                "source_structure": metadata["source_structure"],
                "refined_cell": {key: float(value) for key, value in cell.items()},
            }
        )

    arrays = np.asarray(histogram.data["data"][1], dtype=float)
    two_theta, observed, weight, calculated, background, difference = arrays[:6]
    with (ROOT / "fit.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        for row in zip(two_theta, observed, calculated, difference, background):
            writer.writerow([f"{row[0]:.8f}", *[f"{value:.8f}" for value in row[1:]]])

    refinement = status(project)
    histogram_stats = histogram.data["data"][0]
    independent_rwp = 100.0 * math.sqrt(
        float(np.sum(weight * (observed - calculated) ** 2))
        / float(np.sum(weight * observed**2))
    )
    result = {
        "analysis": "Rietveld refinement against the complete Cu K-alpha powder pattern",
        "fractions_basis": "normalized over the modeled crystalline phases only",
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": float(histogram.get_wR()),
            "Rwp_recomputed_percent": independent_rwp,
            "Rp_percent": float(histogram_stats["R"]),
            "R_expected_percent": float(histogram_stats["wRmin"]),
            "goodness_of_fit": float(refinement["GOF"]),
            "chi_square": float(refinement["chisq"]),
            "n_observations": int(refinement["Nobs"]),
            "n_refined_variables": int(refinement["Nvars"]),
            "converged": bool(refinement["converged"]),
            "svd_dropped_variables": int(refinement.get("SVD0", 0)),
            "maximum_shift_over_esd": float(refinement["Max shft/sig"]),
        },
        "unresolved_components": [],
        "model_uncertainty": {
            "note": (
                "A triclinic P-1 WO3 model is near-tied but slightly worse; the "
                "reported fractions are conditional on the selected P21/c model and "
                "do not quantify amorphous material."
            )
        },
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=False) + "\n", encoding="utf-8"
    )
    return result


def write_report(result: dict) -> None:
    phase_by_formula = {row["formula"]: row for row in result["phases"]}
    barium = phase_by_formula["BaCO3"]
    tungsten = phase_by_formula["WO3"]
    stats = result["fit_statistics"]
    report = f"""# Quantitative crystalline-phase analysis

The selected two-phase Rietveld model is **witherite BaCO3** in Pmcn (space-group No. 62, a setting of Pnma) at **{100*barium['weight_fraction']:.2f} wt%**, and **monoclinic WO3** in P21/c (No. 14) at **{100*tungsten['weight_fraction']:.2f} wt%**. Fractions sum to 100% over the modeled crystalline material. The formal covariance esd is {100*barium['weight_fraction_formal_esd']:.2f} wt% for each complementary fraction.

The complete-pattern fit converged with Rwp = {stats['Rwp_percent']:.4f}%, Rp = {stats['Rp_percent']:.4f}%, and goodness-of-fit = {stats['goodness_of_fit']:.4f}, using all {stats['n_observations']} points. Removing either precursor phase gave poor single-phase fits (Rwp about 31.4% for BaCO3 alone and 29.5% for WO3 alone), whereas both accepted structures account for many unique reflections. A BaWO4 candidate was rejected because its strong predicted peaks near 26.45 and 31.85 degrees 2theta are absent. Other oxide and carbonate candidates either predicted unsupported peaks, failed geometry audits, or collapsed to negligible/unstable scale.

For WO3, a fully reconverged triclinic P-1 alternative is close but worse (Rwp 7.0174% versus {stats['Rwp_percent']:.4f}%) and uses three additional lattice parameters; it changes the phase split to 52.57/47.43 wt% (BaCO3/WO3). Thus WO3 is securely present, but the monoclinic-versus-pseudotriclinic symmetry assignment remains the main structural uncertainty. The orthorhombic WO3 alternative is clearly worse (Rwp 11.73%). Atomic coordinates and displacement parameters were retained from audited literature structures because free coordinate/ADP refinements were non-unique or chemically implausible.

The final profile uses a single specimen-displacement correction, global U and X widths, polarization, WO3 isotropic microstrain, and a mild BaCO3 [110] March-Dollase term. Matched removals materially degrade the complete pattern; competing zero/shift, size/strain, extra V/Y/W, roughness, and WO3 texture branches were rejected for correlation, instability, boundary behavior, or region-inconsistent gains. The fitted displacement is substantial, so absolute cell parameters inherit calibration uncertainty.

No internal standard was supplied, and the measurement has no reported pointwise uncertainties. Consequently, the fractions are conditional crystalline-phase fractions: amorphous content cannot be measured, the formal esds understate model/systematic uncertainty, and a practical fraction uncertainty of roughly +/-1 wt% is more realistic than the covariance esd.
"""
    (ROOT / "report.md").write_text(report, encoding="utf-8")


def main() -> None:
    converge_final()
    result = export_outputs()
    write_report(result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
