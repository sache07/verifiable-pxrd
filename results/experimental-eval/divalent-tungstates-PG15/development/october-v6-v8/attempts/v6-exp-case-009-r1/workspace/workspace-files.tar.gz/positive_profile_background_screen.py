#!/usr/bin/env python3
"""Screen background order with sample microstrain fixed at its physical floor."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from mature_model_validation import regional_rwp
from pxrd_workflow import covariance_status, stable_refine


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "mature_refine_U.gpx"


def main() -> None:
    results = []
    for count in (10, 12, 14, 16, 18, 20, 22, 24):
        output = ROOT / f"positive_profile_background_{count}.gpx"
        project = G2sc.G2Project(str(BASE))
        project.save(str(output))
        project = G2sc.G2Project(str(output))
        histogram = project.histograms()[0]
        hap = project.phases()[0].data["Histograms"][histogram.name]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        histogram.set_refinements(
            {"Background": {"refine": True, "no. coeffs": count}}
        )
        project.save()
        stable = stable_refine(project, f"positive-profile-bg-{count}", 8)
        project = G2sc.G2Project(str(output))
        histogram = project.histograms()[0]
        hap = project.phases()[0].data["Histograms"][histogram.name]
        status = covariance_status(project)
        item = {
            "coefficients": count,
            "project": output.name,
            "stable": stable,
            "rwp_percent": float(histogram.get_wR()),
            "regional_rwp_percent": regional_rwp(project),
            "U": float(histogram.InstrumentParameters["U"][1]),
            "W": float(histogram.InstrumentParameters["W"][1]),
            "X": float(histogram.InstrumentParameters["X"][1]),
            "microstrain": float(hap["Mustrain"][1][0]),
            "converged": status.get("converged"),
            "svd_dropped": status.get("SVD0"),
            "max_shift_over_esd": status.get("Max shft/sig"),
            "message": status.get("msg"),
        }
        results.append(item)
        print("POSITIVE_PROFILE_RESULT=" + json.dumps(item, sort_keys=True), flush=True)
    (ROOT / "positive_profile_background_results.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
