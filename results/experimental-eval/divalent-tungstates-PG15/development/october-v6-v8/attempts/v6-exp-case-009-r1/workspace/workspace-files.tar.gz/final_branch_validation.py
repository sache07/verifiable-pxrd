#!/usr/bin/env python3
"""Final matched optional-term and texture tests from the positive profile model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from mature_model_validation import regional_rwp
from pxrd_workflow import covariance_status, stable_refine


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "positive_profile_background_20.gpx"


def clone(name: str) -> G2sc.G2Project:
    output = ROOT / f"finaltest_{name}.gpx"
    project = G2sc.G2Project(str(BASE))
    project.save(str(output))
    return G2sc.G2Project(str(output))


def summarize(project, stable, name):
    histogram = project.histograms()[0]
    phase = project.phases()[0]
    hap = phase.data["Histograms"][histogram.name]
    status = covariance_status(project)
    return {
        "test": name,
        "project": Path(project.filename).name,
        "stable": stable,
        "rwp_percent": float(histogram.get_wR()),
        "regional_rwp_percent": regional_rwp(project),
        "profile": {
            key: float(histogram.InstrumentParameters[key][1])
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "surface_roughness_B": float(histogram.SampleParameters["SurfRoughB"][0]),
        "size_micrometre": float(hap["Size"][1][0]),
        "microstrain": float(hap["Mustrain"][1][0]),
        "march_dollase_ratio": float(hap["Pref.Ori."][1]),
        "converged": status.get("converged"),
        "svd_dropped": status.get("SVD0"),
        "max_shift_over_esd": status.get("Max shft/sig"),
        "message": status.get("msg"),
    }


def run(name, modifier):
    project = clone(name)
    modifier(project)
    project.save()
    stable = stable_refine(project, name, 8)
    project = G2sc.G2Project(project.filename)
    item = summarize(project, stable, name)
    print("FINAL_BRANCH_RESULT=" + json.dumps(item, sort_keys=True), flush=True)
    return item


def instrument_refine(key):
    def modify(project):
        project.histograms()[0].InstrumentParameters[key][2] = True
    return modify


def instrument_remove(key, value):
    def modify(project):
        parameter = project.histograms()[0].InstrumentParameters[key]
        parameter[1] = value
        parameter[2] = False
    return modify


def surface_remove(project):
    project.histograms()[0].SampleParameters["SurfRoughB"] = [0.0, False]


def size_add(project):
    histogram = project.histograms()[0]
    hap = project.phases()[0].data["Histograms"][histogram.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2][0] = True


def strain_add(start):
    def modify(project):
        histogram = project.histograms()[0]
        hap = project.phases()[0].data["Histograms"][histogram.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = float(start)
        hap["Mustrain"][2][0] = True
    return modify


def polarization_competitor(project):
    surface_remove(project)
    parameter = project.histograms()[0].InstrumentParameters["Polariz."]
    parameter[1] = 0.5
    parameter[2] = True


def march_dollase(axis):
    def modify(project):
        histogram = project.histograms()[0]
        hap = project.phases()[0].data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
    return modify


def main():
    base = G2sc.G2Project(str(BASE))
    results = [summarize(base, True, "baseline")]
    tests = {
        "without_U_refinement": instrument_remove("U", 20.0),
        "without_SHL": instrument_remove("SH/L", 0.002),
        "without_X": instrument_remove("X", 0.0),
        "without_surfaceB": surface_remove,
        "add_V": instrument_refine("V"),
        "add_Y": instrument_refine("Y"),
        "add_Z": instrument_refine("Z"),
        "add_size": size_add,
        "add_strain_100": strain_add(100.0),
        "add_strain_500": strain_add(500.0),
        "add_strain_1000": strain_add(1000.0),
        "polarization_instead_surface": polarization_competitor,
    }
    for name, modifier in tests.items():
        print(f"START_FINAL_BRANCH={name}", flush=True)
        results.append(run(name, modifier))
    for axis in ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 0, 1), (1, 1, 0), (1, 1, 1)):
        label = "MD_" + "".join(str(i) for i in axis)
        print(f"START_FINAL_BRANCH={label}", flush=True)
        results.append(run(label, march_dollase(axis)))
    (ROOT / "final_branch_results.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
