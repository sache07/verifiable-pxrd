#!/usr/bin/env python3
"""Replay-safe matched checks from the angular-selected final baseline."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from mature_model_validation import regional_rwp
from pxrd_workflow import covariance_status, stable_refine


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "angular_final.gpx"


def run(name, modifier):
    output = ROOT / f"freezecheck_{name}.gpx"
    project = G2sc.G2Project(str(BASE))
    project.save(str(output))
    project = G2sc.G2Project(str(output))
    modifier(project)
    project.save()
    stable = stable_refine(project, f"freeze-{name}", 8)
    project = G2sc.G2Project(str(output))
    histogram = project.histograms()[0]
    hap = project.phases()[0].data["Histograms"][histogram.name]
    status = covariance_status(project)
    item = {
        "test": name,
        "project": output.name,
        "stable": stable,
        "rwp_percent": float(histogram.get_wR()),
        "regional_rwp_percent": regional_rwp(project),
        "instrument": {
            key: float(histogram.InstrumentParameters[key][1])
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "shift_micrometre": float(histogram.SampleParameters["Shift"][0]),
        "surface_roughness_B": float(histogram.SampleParameters["SurfRoughB"][0]),
        "size_micrometre": float(hap["Size"][1][0]),
        "microstrain": float(hap["Mustrain"][1][0]),
        "march_dollase_ratio": float(hap["Pref.Ori."][1]),
        "background_coefficients": int(histogram.data["Background"][0][2]),
        "converged": status.get("converged"),
        "svd_dropped": status.get("SVD0"),
        "max_shift_over_esd": status.get("Max shft/sig"),
        "message": status.get("msg"),
    }
    print("FREEZE_RESULT=" + json.dumps(item, sort_keys=True), flush=True)
    return item


def remove_instrument(key, value):
    def modify(project):
        parameter = project.histograms()[0].InstrumentParameters[key]
        parameter[1] = value
        parameter[2] = False
    return modify


def add_instrument(key):
    def modify(project):
        project.histograms()[0].InstrumentParameters[key][2] = True
    return modify


def remove_surface(project):
    project.histograms()[0].SampleParameters["SurfRoughB"] = [0.0, False]


def add_size(project):
    histogram = project.histograms()[0]
    hap = project.phases()[0].data["Histograms"][histogram.name]
    hap["Size"][1][0] = 1.0
    hap["Size"][2][0] = True


def add_strain(project):
    histogram = project.histograms()[0]
    hap = project.phases()[0].data["Histograms"][histogram.name]
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][2][0] = True


def add_texture(project):
    histogram = project.histograms()[0]
    hap = project.phases()[0].data["Histograms"][histogram.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = [1, 0, 1]


def background(count):
    def modify(project):
        project.histograms()[0].set_refinements(
            {"Background": {"refine": True, "no. coeffs": count}}
        )
    return modify


def main():
    tests = {
        "without_surfaceB": remove_surface,
        "add_V": add_instrument("V"),
        "add_Y": add_instrument("Y"),
        "add_Z": add_instrument("Z"),
        "add_size": add_size,
        "add_strain": add_strain,
        "add_MD_101": add_texture,
        "background_18": background(18),
        "background_22": background(22),
    }
    results = []
    for name, modifier in tests.items():
        print(f"START_FREEZE_CHECK={name}", flush=True)
        results.append(run(name, modifier))
    (ROOT / "freeze_validation_results.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
