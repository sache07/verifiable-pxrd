#!/usr/bin/env python3
"""Compare matched smooth-background orders after accepting Gaussian U."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from mature_model_validation import regional_rwp
from pxrd_workflow import covariance_status, stable_refine


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "mature_refine_U.gpx"


def main() -> None:
    results = []
    for count in (20, 22, 24, 26, 28, 30):
        output = ROOT / f"screen_u_background_{count}.gpx"
        project = G2sc.G2Project(str(BASE))
        project.save(str(output))
        project = G2sc.G2Project(str(output))
        project.histograms()[0].set_refinements(
            {"Background": {"refine": True, "no. coeffs": count}}
        )
        project.save()
        stable = stable_refine(project, f"U-background-{count}", maximum_calls=8)
        project = G2sc.G2Project(str(output))
        status = covariance_status(project)
        item = {
            "coefficients": count,
            "project": output.name,
            "stable": stable,
            "rwp_percent": float(project.histograms()[0].get_wR()),
            "regional_rwp_percent": regional_rwp(project),
            "converged": status.get("converged"),
            "svd_dropped": status.get("SVD0"),
            "max_shift_over_esd": status.get("Max shft/sig"),
            "message": status.get("msg"),
        }
        results.append(item)
        print("BACKGROUND_RESULT=" + json.dumps(item, sort_keys=True), flush=True)
    (ROOT / "background_order_results.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
