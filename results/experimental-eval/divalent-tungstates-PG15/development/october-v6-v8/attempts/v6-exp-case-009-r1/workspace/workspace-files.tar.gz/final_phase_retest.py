#!/usr/bin/env python3
"""One-at-a-time source-supported phase tests from the selected mature model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from mature_model_validation import regional_rwp
from pxrd_workflow import covariance_status, stable_refine


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "angular_final.gpx"
CANDIDATES = {
    "Mn3O4": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/12/1011262.cif",
    "Mn3WO6": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/00/27/2002703.cif",
    "Mn2O3": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/51/42/1514230.cif",
    "WO3": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif",
}


def main():
    results = []
    for name, cif in CANDIDATES.items():
        output = ROOT / f"angular_phase_test_{name}.gpx"
        project = G2sc.G2Project(str(BASE))
        project.save(str(output))
        project = G2sc.G2Project(str(output))
        histogram = project.histograms()[0]
        phase = project.add_phase(
            cif, phasename=name, histograms=[histogram], fmthint="CIF"
        )
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"] = [0.01, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False
        project.save()

        project.refine()
        phase = project.phase(name)
        scale = float(phase.data["Histograms"][histogram.name]["Scale"][0])
        floor = scale <= 1.0e-10
        stable = False if floor else stable_refine(project, f"final-add-{name}", 8)
        project.save()
        project = G2sc.G2Project(str(output))
        histogram = project.histograms()[0]
        phase = project.phase(name)
        scale = float(phase.data["Histograms"][histogram.name]["Scale"][0])
        status = covariance_status(project)
        try:
            mass_fractions = {
                key: {"value": value[0], "sigma": value[1]}
                for key, value in histogram.ComputeMassFracs().items()
            }
        except Exception as error:
            mass_fractions = {"error": f"{type(error).__name__}: {error}"}
        item = {
            "candidate": name,
            "project": output.name,
            "scale": scale,
            "scale_at_floor": floor,
            "stable": stable,
            "rwp_percent": float(histogram.get_wR()),
            "regional_rwp_percent": regional_rwp(project),
            "mass_fractions": mass_fractions,
            "converged": status.get("converged"),
            "svd_dropped": status.get("SVD0"),
            "max_shift_over_esd": status.get("Max shft/sig"),
            "message": status.get("msg"),
        }
        results.append(item)
        print("FINAL_PHASE_RESULT=" + json.dumps(item, sort_keys=True), flush=True)
    (ROOT / "final_phase_retest_results.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
