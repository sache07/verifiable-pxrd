#!/usr/bin/env python3
"""Matched branch tests around the mature MnWO4 Rietveld model."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from pxrd_workflow import covariance_status, stable_refine


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "branch_coords.gpx"


def clone(output: str) -> G2sc.G2Project:
    target = ROOT / output
    project = G2sc.G2Project(str(BASE))
    project.save(str(target))
    return G2sc.G2Project(str(target))


def regional_rwp(project: G2sc.G2Project) -> dict[str, float]:
    arrays = project.histograms()[0].data["data"][1]
    x, obs, weights, calc = (np.asarray(arrays[i], dtype=float) for i in range(4))
    regions = {
        "full": (float(x.min()), float(x.max()) + 1.0),
        "low": (float(x.min()), 35.0),
        "middle": (35.0, 65.0),
        "high": (65.0, float(x.max()) + 1.0),
    }
    result = {}
    for name, (lower, upper) in regions.items():
        mask = (
            (x >= lower)
            & (x < upper)
            & np.isfinite(obs)
            & np.isfinite(calc)
            & np.isfinite(weights)
            & (weights > 0)
        )
        denominator = float(np.sum(weights[mask] * obs[mask] ** 2))
        numerator = float(np.sum(weights[mask] * (obs[mask] - calc[mask]) ** 2))
        result[name] = 100.0 * math.sqrt(numerator / denominator)
    return result


def summarize(project: G2sc.G2Project, stable: bool, extra: dict | None = None) -> dict:
    histogram = project.histograms()[0]
    status = covariance_status(project)
    item = {
        "project": Path(project.filename).name,
        "stable": stable,
        "rwp_percent": float(histogram.get_wR()),
        "regional_rwp_percent": regional_rwp(project),
        "converged": status.get("converged"),
        "svd_dropped": status.get("SVD0"),
        "max_shift_over_esd": status.get("Max shft/sig"),
        "message": status.get("msg"),
    }
    if extra:
        item.update(extra)
    return item


def run_modified(name: str, modifier) -> dict:
    project = clone(f"mature_{name}.gpx")
    modifier(project)
    project.save()
    stable = stable_refine(project, name, maximum_calls=8)
    project = G2sc.G2Project(project.filename)
    return summarize(project, stable)


def instrument_term(key: str):
    def modify(project):
        project.histograms()[0].InstrumentParameters[key][2] = True
    return modify


def remove_instrument_term(key: str, neutral: float):
    def modify(project):
        parameter = project.histograms()[0].InstrumentParameters[key]
        parameter[1] = neutral
        parameter[2] = False
    return modify


def remove_surface(project):
    project.histograms()[0].SampleParameters["SurfRoughB"] = [0.0, False]


def remove_strain(project):
    phase = project.phases()[0]
    hap = phase.data["Histograms"][project.histograms()[0].name]
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def add_size(project):
    phase = project.phases()[0]
    hap = phase.data["Histograms"][project.histograms()[0].name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2][0] = True


def polarization_competitor(project):
    remove_surface(project)
    parameter = project.histograms()[0].InstrumentParameters["Polariz."]
    parameter[1] = 0.5
    parameter[2] = True


def background_coefficients(count: int):
    def modify(project):
        project.histograms()[0].set_refinements(
            {"Background": {"refine": True, "no. coeffs": count}}
        )
    return modify


def add_candidate(name: str, cif: str) -> dict:
    project = clone(f"mature_add_{name}.gpx")
    histogram = project.histograms()[0]
    phase = project.add_phase(
        cif, phasename=name, histograms=[histogram], fmthint="CIF"
    )
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"] = [0.1, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][2] = False
    project.save()
    stable = stable_refine(project, f"add-{name}", maximum_calls=8)
    project = G2sc.G2Project(project.filename)
    added = project.phase(name)
    added_hap = added.data["Histograms"][project.histograms()[0].name]
    return summarize(
        project,
        stable,
        {
            "candidate": name,
            "candidate_scale": float(added_hap["Scale"][0]),
            "candidate_scale_refined": bool(added_hap["Scale"][1]),
        },
    )


def main() -> None:
    base_project = G2sc.G2Project(str(BASE))
    results = [summarize(base_project, True, {"test": "baseline"})]

    tests = {
        "without_SHL": remove_instrument_term("SH/L", 0.002),
        "without_X": remove_instrument_term("X", 0.0),
        "without_strain": remove_strain,
        "without_surfaceB": remove_surface,
        "refine_U": instrument_term("U"),
        "refine_V": instrument_term("V"),
        "refine_Y": instrument_term("Y"),
        "refine_Z": instrument_term("Z"),
        "add_size_with_X": add_size,
        "polarization_instead_surface": polarization_competitor,
        "background_8": background_coefficients(8),
        "background_12": background_coefficients(12),
    }
    for name, modifier in tests.items():
        print(f"START_BRANCH={name}", flush=True)
        item = run_modified(name, modifier)
        item["test"] = name
        results.append(item)
        print("BRANCH_RESULT=" + json.dumps(item, sort_keys=True), flush=True)

    candidates = {
        "Mn3O4": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/12/1011262.cif",
        "Mn3WO6": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/00/27/2002703.cif",
        "Mn2O3": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/51/42/1514230.cif",
        "WO3": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif",
    }
    for name, cif in candidates.items():
        print(f"START_CANDIDATE={name}", flush=True)
        item = add_candidate(name, cif)
        item["test"] = f"add_{name}"
        results.append(item)
        print("CANDIDATE_RESULT=" + json.dumps(item, sort_keys=True), flush=True)

    output = ROOT / "mature_validation_results.json"
    output.write_text(json.dumps(results, indent=2) + "\n")
    print(f"VALIDATION_RESULTS={output}")


if __name__ == "__main__":
    main()
