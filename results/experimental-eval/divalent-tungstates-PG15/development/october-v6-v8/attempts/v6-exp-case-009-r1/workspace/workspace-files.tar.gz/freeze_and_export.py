#!/usr/bin/env python3
"""Create the final replay-safe project, CIF and full-grid profile table."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from learned.profile_regeneration import regenerate_profile
from pxrd_workflow import covariance_status, stable_refine


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "angular_final.gpx"
FINAL = ROOT / "final.gpx"
CIF = ROOT / "MnWO4.cif"
FIT = ROOT / "fit.csv"


def main() -> None:
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(FINAL))
    project = G2sc.G2Project(str(FINAL))
    if not stable_refine(project, "final-reconvergence", 8):
        raise RuntimeError("final model did not reconverge cleanly")
    project = G2sc.G2Project(str(FINAL))
    phase = project.phases()[0]
    phase.export_CIF(str(CIF))

    regenerate_profile(FINAL)
    project = G2sc.G2Project(str(FINAL))
    histogram = project.histograms()[0]
    arrays = [np.asarray(value, dtype=float) for value in histogram.data["data"][1]]
    x, observed, weights, calculated, background, difference = arrays[:6]
    with FIT.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        writer.writerows(
            zip(x, observed, calculated, difference, background, strict=True)
        )

    phase = project.phases()[0]
    hap = phase.data["Histograms"][histogram.name]
    status = covariance_status(project)
    summary = {
        "rwp_percent": float(histogram.residuals["wR"]),
        "rp_percent": float(histogram.residuals["R"]),
        "rexp_percent": float(histogram.residuals["wRmin"]),
        "gof": float(status["GOF"]),
        "r_bragg_percent": float(histogram.residuals["Rb"]),
        "rf_percent": float(histogram.residuals["0:0:Rf"]),
        "rf2_percent": float(histogram.residuals["0:0:Rf^2"]),
        "n_observations": int(status["Nobs"]),
        "n_variables": int(status["Nvars"]),
        "converged": bool(status["converged"]),
        "svd_dropped": int(status["SVD0"]),
        "max_shift_over_esd": float(status["Max shft/sig"]),
        "cell": phase.get_cell(),
        "sample_shift_micrometre": float(histogram.SampleParameters["Shift"][0]),
        "surface_roughness_B": float(histogram.SampleParameters["SurfRoughB"][0]),
        "profile": {
            key: float(histogram.InstrumentParameters[key][1])
            for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "size_micrometre_fixed": float(hap["Size"][1][0]),
        "microstrain_fixed": float(hap["Mustrain"][1][0]),
        "fit_rows": int(len(x)),
        "difference_identity_max_abs": float(
            np.max(np.abs(difference - (observed - calculated)))
        ),
    }
    print("FINAL_EXPORT=" + json.dumps(summary, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
