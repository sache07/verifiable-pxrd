#!/usr/bin/env python3
"""Small reproducible helpers for the staged GSAS-II refinements in this run."""

from __future__ import annotations

import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(
    project: G2sc.G2Project,
    label: str,
    maximum_calls: int = 8,
    shift_tolerance: float = 0.05,
) -> bool:
    """Repeat refinements until a fresh call is converged with small shifts."""
    for call in range(1, maximum_calls + 1):
        project.refine()
        status = covariance_status(project)
        message = str(status.get("msg", "") or "").lower()
        summary = {
            "label": label,
            "call": call,
            "rwp_percent": project.histograms()[0].get_wR(),
            "converged": status.get("converged"),
            "svd_dropped": status.get("SVD0"),
            "max_shift_over_esd": status.get("Max shft/sig"),
            "message": status.get("msg"),
        }
        print("REFINE_STATUS=" + json.dumps(summary, sort_keys=True, default=str))
        bad = (
            status.get("Aborted")
            or status.get("SVD0", 0)
            or "dropped" in message
            or "error" in message
        )
        if bad:
            return False
        shift = float(status.get("Max shft/sig") or math.inf)
        if status.get("converged") and shift < shift_tolerance:
            project.save()
            return True
    project.save()
    return False


def project_summary(project: G2sc.G2Project) -> dict:
    histogram = project.histograms()[0]
    return {
        "file": project.filename,
        "rwp_percent": histogram.get_wR(),
        "residuals": histogram.residuals,
        "instrument": {
            key: histogram.InstrumentParameters.get(key)
            for key in (
                "Lam1",
                "Lam2",
                "I(L2)/I(L1)",
                "Zero",
                "Polariz.",
                "U",
                "V",
                "W",
                "X",
                "Y",
                "Z",
                "SH/L",
            )
        },
        "sample": histogram.SampleParameters,
        "phases": [
            {
                "name": phase.name,
                "composition": phase.composition,
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][histogram.name]["Scale"],
                "size": phase.data["Histograms"][histogram.name]["Size"],
                "mustrain": phase.data["Histograms"][histogram.name]["Mustrain"],
                "preferred_orientation": phase.data["Histograms"][histogram.name][
                    "Pref.Ori."
                ],
            }
            for phase in project.phases()
        ],
        "convergence": covariance_status(project),
    }


def build_minimal_project(cif: str | Path, output: str | Path, phase_name: str):
    """Build the common screening model and save each stable refinement stage."""
    output = Path(output).resolve()
    project = G2sc.G2Project(newgpx=str(output))
    histogram = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm"
    )
    phase = project.add_phase(
        str(cif), phasename=phase_name, histograms=[histogram], fmthint="CIF"
    )
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    histogram.SampleParameters["Scale"] = [1.0, False]
    for key, value in {
        "U": 20.0,
        "V": 0.0,
        "W": 70.0,
        "X": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }.items():
        histogram.InstrumentParameters[key][1] = value
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 10,
            }
        }
    )
    phase.set_HAP_refinements({"Scale": True})
    project.save()
    stable_refine(project, f"{phase_name}:background-scale")
    project.save(str(output.with_name(output.stem + "-stage1.gpx")))

    phase.set_refinements({"Cell": True})
    stable_refine(project, f"{phase_name}:cell")
    project.save(str(output.with_name(output.stem + "-stage2.gpx")))

    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    stable_refine(project, f"{phase_name}:zero")
    project.save(str(output.with_name(output.stem + "-stage3.gpx")))

    histogram.set_refinements({"Instrument Parameters": ["W"]})
    stable_refine(project, f"{phase_name}:W")
    project.save(str(output))
    print("PROJECT_SUMMARY=" + json.dumps(project_summary(project), default=str))
    return project
