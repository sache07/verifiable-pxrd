#!/usr/bin/env python3
"""Coordinate-stage a stable two-phase inventory project."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refinement_utils import checked_refine, enable_scales, freeze_all


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "stable_inventory.gpx"
DESTINATION = ROOT / "analysis" / "profile_baseline.gpx"


def configure(project: G2sc.G2Project, group: str) -> None:
    freeze_all(project)
    histogram = project.histograms()[0]
    if group == "background-scales":
        histogram.Background[0][1] = True
        enable_scales(project)
    elif group == "cells":
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
    elif group in {"Zero", "W", "X"}:
        histogram.InstrumentParameters[group][2] = True
    elif group == "scales":
        enable_scales(project)
    else:
        raise ValueError(group)


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(DESTINATION))
    project.set_Controls("cycles", 10)
    project.save()
    history = []
    for _pass in range(2):
        for group in ("background-scales", "Zero", "cells", "W", "X"):
            configure(project, group)
            result = checked_refine(project, attempts=4)
            history.append({"pass": _pass + 1, "group": group, **result})
    configure(project, "scales")
    final = checked_refine(project, attempts=4)
    history.append({"pass": 3, "group": "scales-final", **final})
    project.save()
    summary = {
        "rwp_percent": float(project.histograms()[0].get_wR()),
        "fractions": project.histograms()[0].ComputeMassFracs(),
        "history": history,
    }
    (ROOT / "analysis" / "profile_baseline.json").write_text(
        json.dumps(summary, indent=2, default=str) + "\n", encoding="utf-8"
    )
    print("STABILIZED=" + json.dumps(summary, default=str))


if __name__ == "__main__":
    main()
