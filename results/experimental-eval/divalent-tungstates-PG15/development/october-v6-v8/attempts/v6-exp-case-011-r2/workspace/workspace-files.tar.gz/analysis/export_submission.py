#!/usr/bin/env python3
"""Export the final GSAS-II model into the requested submission files."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "final.gpx"
CIF_NAMES = (
    "phase_1_WO3_triclinic.cif",
    "phase_2_MnO2_pyrolusite.cif",
)
DISPLAY_NAMES = (
    "WO3 (triclinic, P-1)",
    "MnO2 (pyrolusite, P42/mnm)",
)
COD_IDS = ("2106293", "1514232")


def main() -> None:
    project = G2sc.G2Project(str(PROJECT))
    histogram = project.histograms()[0]
    phases = project.phases()
    if len(phases) != 2:
        raise RuntimeError(f"expected two final phases, found {len(phases)}")

    for phase, filename in zip(phases, CIF_NAMES, strict=True):
        phase.export_CIF(str(ROOT / filename))

    mass_fractions = histogram.ComputeMassFracs()
    fraction_rows = []
    for phase, filename, display_name, cod_id in zip(
        phases, CIF_NAMES, DISPLAY_NAMES, COD_IDS, strict=True
    ):
        value, esd = mass_fractions[phase.name]
        fraction_rows.append(
            {
                "name": display_name,
                "formula": "WO3" if "WO3" in phase.name else "MnO2",
                "space_group": "P -1" if "WO3" in phase.name else "P 42/m n m",
                "cif_path": filename,
                "weight_fraction": float(value),
                "weight_fraction_esd": float(esd),
                "structure_reference": f"COD {cod_id}",
            }
        )

    arrays = np.asarray(histogram.data["data"][1], dtype=float)
    two_theta, observed, weights, calculated = arrays[:4]
    difference = observed - calculated
    limits = histogram.data["Limits"][1]
    included = (
        (two_theta >= float(limits[0]))
        & (two_theta <= float(limits[1]))
        & np.isfinite(observed)
        & np.isfinite(calculated)
        & np.isfinite(weights)
        & (weights > 0.0)
    )
    numerator = float(np.sum(weights[included] * difference[included] ** 2))
    denominator = float(np.sum(weights[included] * observed[included] ** 2))
    rwp = 100.0 * math.sqrt(numerator / denominator)
    rp = 100.0 * float(np.sum(np.abs(difference[included]))) / float(
        np.sum(np.abs(observed[included]))
    )
    covariance = project.data.get("Covariance", {}).get("data", {})
    n_parameters = len(covariance.get("varyList", []))
    n_observations = int(np.count_nonzero(included))
    degrees_of_freedom = n_observations - n_parameters
    gof = math.sqrt(numerator / degrees_of_freedom)
    rexp = rwp / gof

    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed_counts", "calculated_counts", "difference_counts"]
        )
        writer.writerows(zip(two_theta, observed, calculated, difference, strict=True))

    result = {
        "phases": fraction_rows,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": rexp,
            "goodness_of_fit": gof,
            "chi_squared": numerator,
            "n_observations": n_observations,
            "n_refined_parameters": n_parameters,
            "two_theta_fit_range_deg": [float(limits[0]), float(limits[1])],
            "weighting": "Poisson approximation, w = 1 / observed counts",
        },
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "fraction_basis": "normalized over modeled crystalline phases",
        "unresolved_components": [],
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
