#!/usr/bin/env python3
"""Run a matched leave-one-term-out refinement without objective rollback."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refinement_utils import checked_refine, enable_scales, freeze_all, repair_project_metadata
from test_profile_branch import collect, configure


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("label")
    parser.add_argument("specification")
    args = parser.parse_args()

    outdir = ROOT / "analysis" / "removal_branches"
    outdir.mkdir(parents=True, exist_ok=True)
    destination = outdir / f"{args.label}.gpx"
    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(destination))
    repair_project_metadata(project)
    freeze_all(project)
    enable_scales(project)
    for specification in args.specification.split("+"):
        configure(project, specification)
    project.set_Controls("cycles", 12)
    project.save()

    # Establish a calculated profile for the reduced model even though it is
    # expected to fit worse than the source project.
    project.refine()
    project.save()
    status = checked_refine(project, attempts=5)
    result = collect(project, args.label, args.specification, status)
    (outdir / f"{args.label}.json").write_text(
        json.dumps(result, indent=2, default=str) + "\n", encoding="utf-8"
    )
    print("REMOVAL_BRANCH_RESULT=" + json.dumps(result, default=str))


if __name__ == "__main__":
    main()
