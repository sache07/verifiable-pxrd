#!/usr/bin/env python3
"""Add one candidate to a mature GSAS-II baseline and test its scale."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_screen import MODELS, ROOT, cod_path, covariance, stable_refine, summarize


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("label")
    parser.add_argument("model", choices=sorted(MODELS))
    args = parser.parse_args()

    outdir = ROOT / "analysis" / "add_phase"
    outdir.mkdir(parents=True, exist_ok=True)
    destination = outdir / f"{args.label}.gpx"
    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(destination))
    histogram = project.histograms()[0]
    identifier, name = MODELS[args.model]
    phase = project.add_phase(
        str(cod_path(identifier)), phasename=name, histograms=[histogram], fmthint="CIF"
    )
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"][:] = [0.1, True]
    phase.set_refinements({"Cell": False})
    project.set_Controls("cycles", 8)
    project.save()
    ok = stable_refine(project, attempts=2)
    # Only allow cell adjustment after a positive first-pass scale.
    first_scale = float(hap["Scale"][0])
    if first_scale > 0:
        phase.set_refinements({"Cell": True})
        ok = stable_refine(project, attempts=2) and ok
    project.save()
    result = summarize(project, args.label, ok)
    result["candidate"] = {
        "model": args.model,
        "first_pass_scale": first_scale,
        "final_scale": float(hap["Scale"][0]),
    }
    (outdir / f"{args.label}.json").write_text(
        json.dumps(result, indent=2, default=str) + "\n", encoding="utf-8"
    )
    print("ADD_PHASE_RESULT=" + json.dumps(result, default=str))


if __name__ == "__main__":
    main()
