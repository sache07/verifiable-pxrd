#!/usr/bin/env python3
"""Create and refine matched minimal GSAS-II screening branches."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "analysis" / "lab_cu.instprm"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

MODELS = {
    "wo3_mono": ("2311041", "WO3_monoclinic_P21c"),
    "wo3_tri": ("2106293", "WO3_triclinic_P-1"),
    "wo3_half": ("1010618", "WO3_reduced_P-1"),
    "mno2_rutile": ("1514232", "MnO2_pyrolusite"),
    "mno2_rutile_charged": ("1514110", "MnO2_pyrolusite_charged"),
    "mno2_tunnel": ("9016667", "MnO2_hollandite"),
    "mnwo4": ("1520200", "MnWO4_wolframite"),
    "mn2o3": ("1514230", "Mn2O3_bixbyite"),
    "mn3o4": ("1011262", "Mn3O4_hausmannite"),
    "mn3wo6": ("2002703", "Mn3WO6_ilmenite_related"),
    "w18o49": ("1538315", "W18O49_magneli"),
    "w3o8": ("2101049", "W3O8_orthorhombic"),
}


def cod_path(identifier: str) -> Path:
    return COD / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def covariance(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, attempts: int = 2) -> bool:
    for _ in range(attempts):
        project.refine()
        state = covariance(project)
        message = str(state.get("msg", "") or "").lower()
        if state.get("Aborted") or state.get("SVD0", 0) or "error" in message or "dropped" in message:
            return False
        if state.get("converged") and float(state.get("Max shft/sig") or 0.0) < 0.1:
            return True
    return bool(covariance(project).get("converged"))


def summarize(project: G2sc.G2Project, label: str, ok: bool) -> dict:
    histogram = project.histograms()[0]
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": phase.get_cell(),
            }
        )
    return {
        "branch": label,
        "stable": ok,
        "rwp_percent": float(histogram.get_wR()),
        "residuals": histogram.residuals,
        "zero": histogram.InstrumentParameters["Zero"],
        "instrument": {
            key: histogram.InstrumentParameters[key]
            for key in ("U", "V", "W", "X", "Y", "Z")
        },
        "phases": phases,
        "convergence": {
            key: covariance(project).get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp")
        },
    }


def build(label: str, model_keys: list[str], destination: Path) -> dict:
    project = G2sc.G2Project(newgpx=str(destination))
    histogram = project.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma/tab/semicolon separated"
    )
    # Keep the histogram scale fixed; phase HAP scales carry quantitative
    # information. Refining both produces an exact scale degeneracy.
    histogram.SampleParameters["Scale"][1] = False
    histogram.set_refinements(
        {
            "Limits": [10.0, 100.05],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 10,
                "coeffs": [1100.0] + [0.0] * 9,
            },
        }
    )
    for key in model_keys:
        identifier, name = MODELS[key]
        project.add_phase(
            str(cod_path(identifier)),
            phasename=name,
            histograms=[histogram],
            fmthint="CIF",
        )
    project.set_Controls("cycles", 8)
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    project.save()

    # Matched minimal nuisance sequence for all structural branches.
    ok = stable_refine(project)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    ok = stable_refine(project) and ok
    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    ok = stable_refine(project) and ok
    # One global Gaussian and Lorentzian width term, kept identical in screening.
    histogram.set_refinements({"Instrument Parameters": ["W"]})
    ok = stable_refine(project) and ok
    histogram.set_refinements({"Instrument Parameters": ["X"]})
    ok = stable_refine(project) and ok
    project.save()
    return summarize(project, label, ok)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("models", nargs="+")
    args = parser.parse_args()
    unknown = sorted(set(args.models) - MODELS.keys())
    if unknown:
        raise SystemExit(f"unknown model keys: {unknown}")
    outdir = ROOT / "analysis" / "screen"
    outdir.mkdir(parents=True, exist_ok=True)
    destination = outdir / f"{args.label}.gpx"
    result = build(args.label, args.models, destination)
    (outdir / f"{args.label}.json").write_text(
        json.dumps(result, indent=2, default=str) + "\n", encoding="utf-8"
    )
    print("SCREEN_RESULT=" + json.dumps(result, default=str))


if __name__ == "__main__":
    main()
