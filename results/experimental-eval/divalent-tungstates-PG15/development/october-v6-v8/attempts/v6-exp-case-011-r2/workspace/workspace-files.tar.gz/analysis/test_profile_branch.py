#!/usr/bin/env python3
"""Run one matched optional profile/structure branch from a stable project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refinement_utils import (
    checked_refine,
    enable_scales,
    freeze_all,
    repair_project_metadata,
)


ROOT = Path(__file__).resolve().parents[1]


def configure(project: G2sc.G2Project, specification: str) -> None:
    histogram = project.histograms()[0]
    fields = specification.split(":")
    kind = fields[0]
    if kind == "background":
        histogram.Background[0][1] = True
    elif kind == "fixedinstrument":
        histogram.InstrumentParameters[fields[1]][1] = float(fields[2])
        histogram.InstrumentParameters[fields[1]][2] = False
    elif kind == "fixedstrain":
        phase = project.phases()[int(fields[1])]
        hap = phase.data["Histograms"][histogram.name]
        hap["Mustrain"][1][0] = float(fields[2])
        hap["Mustrain"][2][0] = False
    elif kind == "fixedpo":
        phase = project.phases()[int(fields[1])]
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][1] = float(fields[2])
        hap["Pref.Ori."][2] = False
    elif kind == "cell":
        selector = fields[1]
        phases = project.phases()
        if selector == "all":
            for phase in phases:
                phase.data["General"]["Cell"][0] = True
        else:
            phases[int(selector)].data["General"]["Cell"][0] = True
    elif kind == "instrument":
        histogram.InstrumentParameters[fields[1]][2] = True
    elif kind == "roughness":
        histogram.SampleParameters["SurfRoughA"][:] = [0.5, True]
        histogram.SampleParameters["SurfRoughB"][:] = [0.1, True]
    elif kind == "size":
        phase = project.phases()[int(fields[1])]
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    elif kind == "strain":
        phase = project.phases()[int(fields[1])]
        hap = phase.data["Histograms"][histogram.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
    elif kind == "po":
        phase = project.phases()[int(fields[1])]
        axis = [int(value) for value in fields[2].split(",")]
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
    elif kind == "coords":
        phase = project.phases()[int(fields[1])]
        selector = fields[2]
        for atom in phase.atoms():
            if selector == "all" or atom.element == selector:
                atom.refinement_flags = "X"
    elif kind == "uiso":
        phase = project.phases()[int(fields[1])]
        selector = fields[2]
        for atom in phase.atoms():
            if selector == "all" or atom.element == selector:
                atom.refinement_flags = "U"
    else:
        raise ValueError(f"unknown specification {specification!r}")


def collect(project: G2sc.G2Project, label: str, specification: str, status: dict) -> dict:
    histogram = project.histograms()[0]
    phase_rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phase_rows.append(
            {
                "name": phase.name,
                "scale": hap["Scale"],
                "cell": phase.get_cell(),
                "size": hap.get("Size"),
                "microstrain": hap.get("Mustrain"),
                "preferred_orientation": hap.get("Pref.Ori."),
            }
        )
    return {
        "label": label,
        "specification": specification,
        "rwp_percent": float(histogram.get_wR()),
        "fractions": histogram.ComputeMassFracs(),
        "instrument": histogram.InstrumentParameters,
        "sample": histogram.SampleParameters,
        "phases": phase_rows,
        "refinement": status,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("label")
    parser.add_argument("specification")
    args = parser.parse_args()
    outdir = ROOT / "analysis" / "profile_branches"
    outdir.mkdir(parents=True, exist_ok=True)
    destination = outdir / f"{args.label}.gpx"
    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(destination))
    repair_project_metadata(project)
    freeze_all(project)
    enable_scales(project)
    for specification in args.specification.split("+"):
        configure(project, specification)
    project.set_Controls("cycles", 12)
    project.save()
    status = checked_refine(project, attempts=5)
    result = collect(project, args.label, args.specification, status)
    (outdir / f"{args.label}.json").write_text(
        json.dumps(result, indent=2, default=str) + "\n", encoding="utf-8"
    )
    print("PROFILE_BRANCH_RESULT=" + json.dumps(result, default=str))


if __name__ == "__main__":
    main()
