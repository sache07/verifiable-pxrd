"""Small GSAS-II refinement helpers used for matched branch tests."""

from __future__ import annotations

import copy
import math

from GSASII import GSASIIscriptable as G2sc


def covariance(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def freeze_all(project: G2sc.G2Project) -> None:
    histogram = project.histograms()[0]
    histogram.Background[0][1] = False
    for parameter in histogram.InstrumentParameters.values():
        if isinstance(parameter, list) and len(parameter) >= 3:
            parameter[2] = False
    for parameter in histogram.SampleParameters.values():
        if (
            isinstance(parameter, list)
            and len(parameter) == 2
            and isinstance(parameter[1], bool)
        ):
            parameter[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.data["Atoms"]:
            atom[2] = ""
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = False
        if "Pref.Ori." in hap:
            hap["Pref.Ori."][2] = False
        for key in ("Size", "Mustrain"):
            if key in hap:
                hap[key][2] = [False] * len(hap[key][2])
                if len(hap[key]) > 5:
                    hap[key][5] = [False] * len(hap[key][5])
        if "HStrain" in hap:
            hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        if "Extinction" in hap:
            hap["Extinction"][1] = False
        for parameter in hap.get("Babinet", {}).values():
            parameter[1] = False


def enable_scales(project: G2sc.G2Project) -> None:
    histogram = project.histograms()[0]
    for phase in project.phases():
        phase.data["Histograms"][histogram.name]["Scale"][1] = True


def repair_project_metadata(project: G2sc.G2Project) -> None:
    """Restore non-refinable sample metadata damaged by early branch scripts."""
    histogram = project.histograms()[0]
    materials = histogram.SampleParameters.get("Materials")
    if not (
        isinstance(materials, list)
        and len(materials) == 2
        and all(isinstance(item, dict) for item in materials)
    ):
        histogram.SampleParameters["Materials"] = [
            {"Name": "vacuum", "VolFrac": 1.0},
            {"Name": "vacuum", "VolFrac": 0.0},
        ]


def checked_refine(
    project: G2sc.G2Project,
    attempts: int = 5,
    max_shift: float = 0.1,
    worsening_margin: float = 0.003,
) -> dict:
    """Refine repeatedly, rolling back any materially worse iterate."""
    best_rwp = float(project.histograms()[0].get_wR())
    best_data = copy.deepcopy(project.data)
    best_names = copy.deepcopy(project.names)
    accepted = 0
    for _ in range(attempts):
        project.refine()
        state = covariance(project)
        rwp = float(project.histograms()[0].get_wR())
        message = str(state.get("msg", "") or "").lower()
        invalid = (
            not math.isfinite(rwp)
            or state.get("Aborted")
            or int(state.get("SVD0", 0) or 0) > 0
            or "dropped" in message
            or "error" in message
        )
        if invalid or rwp > best_rwp + worsening_margin:
            project.data = copy.deepcopy(best_data)
            project.names = copy.deepcopy(best_names)
            project.update_ids()
            project.save()
            break
        accepted += 1
        stable = bool(state.get("converged")) and abs(
            float(state.get("Max shft/sig") or 0.0)
        ) < max_shift
        if rwp <= best_rwp or (stable and rwp <= best_rwp + worsening_margin):
            best_rwp = rwp
            best_data = copy.deepcopy(project.data)
            best_names = copy.deepcopy(project.names)
        if stable:
            break
    project.data = copy.deepcopy(best_data)
    project.names = copy.deepcopy(best_names)
    project.update_ids()
    project.save()
    state = covariance(project)
    return {
        "accepted_iterations": accepted,
        "rwp_percent": best_rwp,
        "converged": state.get("converged"),
        "max_shift_over_esd": state.get("Max shft/sig"),
        "svd": state.get("SVD0"),
        "message": state.get("msg"),
    }
