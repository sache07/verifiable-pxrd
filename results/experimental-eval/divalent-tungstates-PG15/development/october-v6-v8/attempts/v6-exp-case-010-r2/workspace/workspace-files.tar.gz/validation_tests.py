"""Matched leave-one-term-out checks for the selected GSAS-II model."""

from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "simplified_profile.gpx"


def objects(project):
    hist = project.histograms()[0]
    phases = {phase.name: phase for phase in project.phases()}
    return hist, phases


def set_block(project, block, omitted):
    """Set exactly one refinement block, leaving the omitted term fixed off."""
    hist, phases = objects(project)
    background = hist.data["Background"][0]
    background[1] = block == "background_scale"
    for phase in phases.values():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = block == "background_scale"
        hap["Size"][2][0] = False
        hap["Mustrain"][2][0] = False
    instrument = hist.data["Instrument Parameters"][0]
    for key, value in instrument.items():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    sample = hist.data["Sample Parameters"]
    for value in sample.values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False

    if block == "profile":
        instrument["W"][2] = True
        if omitted != "wo3_size":
            phases["WO3"].data["Histograms"][hist.name]["Size"][2][0] = True
        if omitted != "wo3_strain":
            phases["WO3"].data["Histograms"][hist.name]["Mustrain"][2][0] = True
        if omitted != "mn2o3_size":
            phases["Mn2O3"].data["Histograms"][hist.name]["Size"][2][0] = True
    elif block == "roughness" and omitted != "roughness":
        sample["SurfRoughB"][1] = True


def region_rwp(project):
    hist = project.histograms()[0]
    x, obs, weight, calc, _, diff = hist.data["data"][1]
    ans = {}
    for lo in range(10, 100, 10):
        hi = lo + 10
        use = (x >= lo) & (x < hi)
        ans[f"{lo}-{hi}"] = float(
            100.0 * np.sqrt(np.sum(weight[use] * diff[use] ** 2) /
                            np.sum(weight[use] * obs[use] ** 2))
        )
    return ans


def values(project):
    hist, phases = objects(project)
    hap_w = phases["WO3"].data["Histograms"][hist.name]
    hap_mn = phases["Mn2O3"].data["Histograms"][hist.name]
    return {
        "Rwp": float(hist.get_wR()),
        "GOF": float(project.data["Covariance"]["data"]["Rvals"]["GOF"]),
        "W": float(hist.data["Instrument Parameters"][0]["W"][1]),
        "rough_B": float(hist.data["Sample Parameters"]["SurfRoughB"][0]),
        "WO3_size_um": float(hap_w["Size"][1][0]),
        "WO3_strain_microstrain": float(hap_w["Mustrain"][1][0]),
        "Mn2O3_size_um": float(hap_mn["Size"][1][0]),
        "regions": region_rwp(project),
    }


def run_branch(label, omitted):
    project = G2sc.G2Project(gpxfile=str(BASE))
    hist, phases = objects(project)
    if omitted == "roughness":
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    elif omitted == "wo3_size":
        phases["WO3"].data["Histograms"][hist.name]["Size"][1][0] = 1000.0
    elif omitted == "wo3_strain":
        phases["WO3"].data["Histograms"][hist.name]["Mustrain"][1][0] = 0.0
    elif omitted == "mn2o3_size":
        phases["Mn2O3"].data["Histograms"][hist.name]["Size"][1][0] = 1000.0
    output = ROOT / f"remove_{label}.gpx"
    project.save(str(output))

    # Reoptimize all retained nuisance terms in matched coordinate blocks.
    for _ in range(3):
        for block in ("profile", "roughness", "background_scale"):
            if block == "roughness" and omitted == "roughness":
                continue
            set_block(project, block, omitted)
            project.save()
            project.do_refinements([{}])
    set_block(project, "background_scale", omitted)
    project.save()
    project.do_refinements([{}])
    return values(project)


results = {"baseline": values(G2sc.G2Project(gpxfile=str(BASE)))}
for label in ("roughness", "wo3_size", "wo3_strain", "mn2o3_size"):
    results[f"without_{label}"] = run_branch(label, label)
print("TERM_REMOVAL_RESULT=" + json.dumps(results, sort_keys=True))
