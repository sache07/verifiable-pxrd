"""Scale-only additions of chemically plausible reaction products."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "simplified_profile.gpx"
CANDIDATES = {
    "MnWO4": Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif"),
    "Mn3WO6": Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/00/27/2002703.cif"),
}


def test_candidate(label, cif):
    project = G2sc.G2Project(gpxfile=str(BASE))
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = False
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = False
        phase.data["General"]["Cell"][0] = False
    added = project.add_phase(
        phasefile=str(cif), phasename=label + "_test", histograms=[hist]
    )
    added.data["General"]["Cell"][0] = False
    hap = added.data["Histograms"][hist.name]
    hap["Scale"] = [0.1, True]
    hap["Size"][1][0] = 0.1
    hap["Size"][2][0] = False
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2][0] = False
    output = ROOT / f"retest_add_{label}.gpx"
    project.save(str(output))
    project.do_refinements([{}])
    hist = project.histograms()[0]
    scale_only = float(hap["Scale"][0])
    scale_key = f"{added.id}:0:Scale"
    dep = project.data["Covariance"]["data"].get("depSigDict", {})
    sig = dep.get(scale_key, (scale_only, None))[1]
    first = {
        "Rwp": float(hist.get_wR()),
        "scale": scale_only,
        "scale_esd": None if sig is None else float(sig),
    }
    # If scale-only support is positive, permit the same background/scale block
    # used for the accepted model and verify that the signal survives.
    joint = None
    if scale_only > 0:
        hist.data["Background"][0][1] = True
        for phase in project.phases():
            phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.save()
        project.do_refinements([{}])
        joint = {
            "Rwp": float(hist.get_wR()),
            "scale": float(hap["Scale"][0]),
        }
    return {"scale_only": first, "joint_scales_background": joint}


results = {label: test_candidate(label, cif) for label, cif in CANDIDATES.items()}
print("CANDIDATE_RETEST_RESULT=" + json.dumps(results, sort_keys=True))
