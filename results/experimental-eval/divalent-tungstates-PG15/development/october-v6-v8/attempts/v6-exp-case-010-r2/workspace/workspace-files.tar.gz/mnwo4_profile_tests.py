"""Independent profile-term tests for the provisional trace MnWO4 phase."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "retest_add_MnWO4.gpx"


def get(project):
    hist = project.histograms()[0]
    phases = {phase.name: phase for phase in project.phases()}
    return hist, phases, phases["MnWO4_test"]


def clear(project):
    hist, phases, _ = get(project)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in phases.values():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2][0] = False
        hap["Mustrain"][2][0] = False


def set_block(project, kind):
    clear(project)
    hist, phases, candidate = get(project)
    if kind == "background_scale":
        hist.data["Background"][0][1] = True
        for phase in phases.values():
            phase.data["Histograms"][hist.name]["Scale"][1] = True
    elif kind == "size":
        hap = candidate.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2][0] = True
    elif kind == "strain":
        hap = candidate.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Mustrain"][2][0] = True


def refine(project, kind):
    set_block(project, kind)
    project.save()
    project.do_refinements([{}])


def result(project):
    hist, _, candidate = get(project)
    hap = candidate.data["Histograms"][hist.name]
    cov = project.data["Covariance"]["data"]
    p_id = candidate.id
    return {
        "Rwp": float(hist.get_wR()),
        "GOF": float(cov["Rvals"]["GOF"]),
        "converged": bool(cov["Rvals"].get("converged", False)),
        "SVD0": int(cov["Rvals"].get("SVD0", 0)),
        "scale": float(hap["Scale"][0]),
        "size_um": float(hap["Size"][1][0]),
        "strain_microstrain": float(hap["Mustrain"][1][0]),
        "weight_fraction": cov.get("depSigDict", {}).get(f"{p_id}:0:WgtFrac"),
    }


# First construct a matched baseline with no phase-specific MnWO4 broadening.
base = G2sc.G2Project(gpxfile=str(SOURCE))
hist, _, candidate = get(base)
hap = candidate.data["Histograms"][hist.name]
hap["Size"][1][0] = 10.0
hap["Mustrain"][1][0] = 0.0
base.save(str(ROOT / "mnwo4_no_broadening.gpx"))
for _ in range(2):
    refine(base, "background_scale")
baseline_result = result(base)


def branch(kind):
    project = G2sc.G2Project(gpxfile=str(ROOT / "mnwo4_no_broadening.gpx"))
    hist, _, candidate = get(project)
    hap = candidate.data["Histograms"][hist.name]
    if kind == "size":
        hap["Size"][1][0] = 0.1
        hap["Mustrain"][1][0] = 0.0
    else:
        hap["Size"][1][0] = 10.0
        hap["Mustrain"][1][0] = 1000.0
    project.save(str(ROOT / f"mnwo4_{kind}_branch.gpx"))
    for _ in range(3):
        refine(project, kind)
        refine(project, "background_scale")
    return result(project)


results = {
    "no_broadening": baseline_result,
    "size_only": branch("size"),
    "strain_only": branch("strain"),
}
print("MNWO4_PROFILE_RESULT=" + json.dumps(results, sort_keys=True))
