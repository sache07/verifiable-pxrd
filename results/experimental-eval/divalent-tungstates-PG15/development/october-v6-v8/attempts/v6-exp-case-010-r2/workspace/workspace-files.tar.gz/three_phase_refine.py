"""Block-coordinate reconvergence of the selected three-phase model."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
project = G2sc.G2Project(gpxfile=str(root / "mnwo4_strain_branch.gpx"))
hist = project.histograms()[0]
phases = {phase.name: phase for phase in project.phases()}


def clear():
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in phases.values():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2][0] = False
        hap["Mustrain"][2][0] = False


def select(block):
    clear()
    if block == "major_profile":
        hist.data["Instrument Parameters"][0]["W"][2] = True
        phases["WO3"].data["Histograms"][hist.name]["Size"][2][0] = True
        phases["WO3"].data["Histograms"][hist.name]["Mustrain"][2][0] = True
        phases["Mn2O3"].data["Histograms"][hist.name]["Size"][2][0] = True
    elif block == "mnwo4_profile":
        hap = phases["MnWO4_test"].data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Mustrain"][2][0] = True
    elif block == "roughness":
        hist.data["Sample Parameters"]["SurfRoughB"][1] = True
    elif block == "background_scale":
        hist.data["Background"][0][1] = True
        for phase in phases.values():
            phase.data["Histograms"][hist.name]["Scale"][1] = True


def refine(block):
    select(block)
    project.save()
    project.do_refinements([{}])


# Preserve the fixed reference MnWO4 cell and all selected profile terms.
project.save(str(root / "stable_before_three_phase_reconvergence.gpx"))
project.save(str(root / "three_phase_stable.gpx"))
history = []
for cycle in range(3):
    for block in ("major_profile", "mnwo4_profile", "roughness", "background_scale"):
        refine(block)
        history.append([cycle + 1, block, float(hist.get_wR())])
select("background_scale")
project.save()
project.do_refinements([{}])

cov = project.data["Covariance"]["data"]
dep = cov.get("depSigDict", {})
fractions = {}
for phase in phases.values():
    fractions[phase.name] = dep.get(f"{phase.id}:0:WgtFrac")
result = {
    "Rwp": float(hist.get_wR()),
    "Rp": float(hist.data["data"][0].get("R", float("nan"))),
    "GOF": float(cov["Rvals"]["GOF"]),
    "chisq": float(cov["Rvals"]["chisq"]),
    "converged": bool(cov["Rvals"].get("converged", False)),
    "SVD0": int(cov["Rvals"].get("SVD0", 0)),
    "max_shift_over_sigma": float(cov["Rvals"].get("Max shft/sig", float("nan"))),
    "fractions": fractions,
    "history": history,
}
print("THREE_PHASE_RESULT=" + json.dumps(result, sort_keys=True))
