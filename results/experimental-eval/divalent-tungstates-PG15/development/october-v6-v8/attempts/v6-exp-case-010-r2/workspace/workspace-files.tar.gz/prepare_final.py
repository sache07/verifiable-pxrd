"""Create the final replay-safe project and normalize the trace phase name."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
project = G2sc.G2Project(gpxfile=str(root / "three_phase_stable.gpx"))
project.save(str(root / "final.gpx"))

old = "MnWO4_test"
new = "MnWO4"
if old in project.data["Phases"]:
    phase_data = project.data["Phases"].pop(old)
    phase_data["General"]["Name"] = new
    project.data["Phases"][new] = phase_data
    for tree_names in project.names:
        for index, name in enumerate(tree_names):
            if name == old:
                tree_names[index] = new
    histogram = project.histograms()[0]
    reflections = histogram.data["Reflection Lists"]
    if old in reflections:
        reflections[new] = reflections.pop(old)
    histogram.data["data"][0]["2::Name"] = new

project.save()
check = G2sc.G2Project(gpxfile=str(root / "final.gpx"))
print("FINAL_PHASE_NAMES=" + repr([phase.name for phase in check.phases()]))
