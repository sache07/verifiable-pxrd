"""Matched final leave-one-out check for the accepted Mn2O3 phase."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
p = G2sc.G2Project(gpxfile=str(root / "three_phase_stable.gpx"))
h = p.histograms()[0]
ph = {item.name: item for item in p.phases()}
ph["Mn2O3"].data["Histograms"][h.name]["Use"] = False
ph["Mn2O3"].data["Histograms"][h.name]["Scale"] = [1.0e-12, False]
p.save(str(root / "final_remove_Mn2O3_phase.gpx"))


def clear():
    h.data["Background"][0][1] = False
    for value in h.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in ph.values():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2][0] = False
        hap["Mustrain"][2][0] = False


for _ in range(2):
    clear()
    h.data["Instrument Parameters"][0]["W"][2] = True
    ph["WO3"].data["Histograms"][h.name]["Size"][2][0] = True
    ph["WO3"].data["Histograms"][h.name]["Mustrain"][2][0] = True
    mnw = ph["MnWO4_test"].data["Histograms"][h.name]
    mnw["Scale"][1] = True
    mnw["Mustrain"][2][0] = True
    p.save(); p.do_refinements([{}])

    clear()
    h.data["Sample Parameters"]["SurfRoughB"][1] = True
    p.save(); p.do_refinements([{}])

    clear()
    h.data["Background"][0][1] = True
    ph["WO3"].data["Histograms"][h.name]["Scale"][1] = True
    ph["MnWO4_test"].data["Histograms"][h.name]["Scale"][1] = True
    p.save(); p.do_refinements([{}])

clear()
h.data["Background"][0][1] = True
ph["WO3"].data["Histograms"][h.name]["Scale"][1] = True
ph["MnWO4_test"].data["Histograms"][h.name]["Scale"][1] = True
p.save(); p.do_refinements([{}])
r = p.data["Covariance"]["data"]["Rvals"]
print("MN2O3_LEAVEOUT=" + json.dumps({"Rwp": h.get_wR(), "GOF": r["GOF"], "converged": r.get("converged"), "SVD0": r.get("SVD0")}))
