"""Repeat principal structure replacements after accepting trace MnWO4."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
mnwo4_cif = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif")
cases = {
    "WO3_P21c_plus_MnWO4": root / "retest_WO3_P21c.gpx",
    "WO3_Pnma_plus_MnWO4": root / "retest_WO3_Pnma.gpx",
    "Mn2O3_Pbca_plus_MnWO4": root / "retest_Mn2O3_Pbca.gpx",
}


def clear(project):
    hist = project.histograms()[0]
    phases = {phase.name: phase for phase in project.phases()}
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in phases.values():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2][0] = False
        hap["Mustrain"][2][0] = False


def select(project, block):
    clear(project)
    hist = project.histograms()[0]
    phases = {phase.name: phase for phase in project.phases()}
    if block == "major_profile":
        hist.data["Instrument Parameters"][0]["W"][2] = True
        phases["WO3"].data["Histograms"][hist.name]["Size"][2][0] = True
        phases["WO3"].data["Histograms"][hist.name]["Mustrain"][2][0] = True
        phases["Mn2O3"].data["Histograms"][hist.name]["Size"][2][0] = True
    elif block == "candidate":
        hap = phases["MnWO4_test"].data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Mustrain"][2][0] = True
    elif block == "roughness":
        hist.data["Sample Parameters"]["SurfRoughB"][1] = True
    elif block == "background_scale":
        hist.data["Background"][0][1] = True
        for phase in phases.values():
            phase.data["Histograms"][hist.name]["Scale"][1] = True


def run(label, source):
    project = G2sc.G2Project(gpxfile=str(source))
    output = root / f"final_retest_{label}.gpx"
    # Move to the branch file before add_phase, which saves immediately.
    project.save(str(output))
    hist = project.histograms()[0]
    candidate = project.add_phase(
        phasefile=str(mnwo4_cif), phasename="MnWO4_test", histograms=[hist]
    )
    candidate.data["General"]["Cell"][0] = False
    hap = candidate.data["Histograms"][hist.name]
    hap["Scale"] = [1.6, False]
    hap["Size"][1][0] = 10.0
    hap["Size"][2][0] = False
    hap["Mustrain"][1][0] = 38500.0
    hap["Mustrain"][2][0] = False
    project.save()
    for _ in range(2):
        for block in ("major_profile", "candidate", "roughness", "background_scale"):
            select(project, block)
            project.save()
            project.do_refinements([{}])
    select(project, "background_scale")
    project.save()
    project.do_refinements([{}])
    cov = project.data["Covariance"]["data"]
    return {
        "Rwp": float(hist.get_wR()),
        "GOF": float(cov["Rvals"]["GOF"]),
        "converged": bool(cov["Rvals"].get("converged", False)),
        "SVD0": int(cov["Rvals"].get("SVD0", 0)),
        "MnWO4_scale": float(hap["Scale"][0]),
    }


results = {label: run(label, source) for label, source in cases.items()}
print("FINAL_STRUCTURE_RETEST=" + json.dumps(results, sort_keys=True))
