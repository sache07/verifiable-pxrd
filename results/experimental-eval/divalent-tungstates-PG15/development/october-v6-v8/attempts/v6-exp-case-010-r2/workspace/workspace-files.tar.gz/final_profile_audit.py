"""Matched final-model removals and one unretained-term retest."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
source = root / "three_phase_stable.gpx"


def objects(project):
    hist = project.histograms()[0]
    phases = {phase.name: phase for phase in project.phases()}
    return hist, phases


def clear(project):
    hist, phases = objects(project)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in phases.values():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2][0] = False
        hap["Mustrain"][2][0] = False


def select(project, block, omitted):
    clear(project)
    hist, phases = objects(project)
    active_candidate = omitted != "mnwo4_phase"
    if block == "profile":
        hist.data["Instrument Parameters"][0]["W"][2] = True
        if omitted != "wo3_size":
            phases["WO3"].data["Histograms"][hist.name]["Size"][2][0] = True
        if omitted != "wo3_strain":
            phases["WO3"].data["Histograms"][hist.name]["Mustrain"][2][0] = True
        if omitted != "mn2o3_size":
            phases["Mn2O3"].data["Histograms"][hist.name]["Size"][2][0] = True
        if active_candidate:
            candidate_hap = phases["MnWO4_test"].data["Histograms"][hist.name]
            candidate_hap["Scale"][1] = True
            if omitted != "mnwo4_strain":
                candidate_hap["Mustrain"][2][0] = True
    elif block == "roughness" and omitted != "roughness":
        hist.data["Sample Parameters"]["SurfRoughB"][1] = True
    elif block == "background_scale":
        hist.data["Background"][0][1] = True
        for name, phase in phases.items():
            if name != "MnWO4_test" or active_candidate:
                phase.data["Histograms"][hist.name]["Scale"][1] = True


def refine(project, block, omitted):
    select(project, block, omitted)
    project.save()
    project.do_refinements([{}])


def remove(label):
    project = G2sc.G2Project(gpxfile=str(source))
    hist, phases = objects(project)
    if label == "roughness":
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    elif label == "wo3_size":
        phases["WO3"].data["Histograms"][hist.name]["Size"][1][0] = 10.0
    elif label == "wo3_strain":
        phases["WO3"].data["Histograms"][hist.name]["Mustrain"][1][0] = 0.0
    elif label == "mn2o3_size":
        phases["Mn2O3"].data["Histograms"][hist.name]["Size"][1][0] = 10.0
    elif label == "mnwo4_strain":
        phases["MnWO4_test"].data["Histograms"][hist.name]["Mustrain"][1][0] = 0.0
    elif label == "mnwo4_phase":
        hap = phases["MnWO4_test"].data["Histograms"][hist.name]
        hap["Use"] = False
        hap["Scale"] = [1.0e-12, False]
    project.save(str(root / f"final_remove_{label}.gpx"))
    for _ in range(2):
        for block in ("profile", "roughness", "background_scale"):
            if block == "roughness" and label == "roughness":
                continue
            refine(project, block, label)
    refine(project, "background_scale", label)
    cov = project.data["Covariance"]["data"]["Rvals"]
    return {
        "Rwp": float(hist.get_wR()),
        "GOF": float(cov["GOF"]),
        "converged": bool(cov.get("converged", False)),
        "SVD0": int(cov.get("SVD0", 0)),
    }


def test_mn2o3_strain():
    project = G2sc.G2Project(gpxfile=str(source))
    hist, phases = objects(project)
    hap = phases["Mn2O3"].data["Histograms"][hist.name]
    hap["Mustrain"][1][0] = 1000.0
    project.save(str(root / "final_retest_mn2o3_strain.gpx"))
    for _ in range(2):
        clear(project)
        hap["Scale"][1] = True
        hap["Mustrain"][2][0] = True
        project.save()
        project.do_refinements([{}])
        select(project, "background_scale", "none")
        project.save()
        project.do_refinements([{}])
    cov = project.data["Covariance"]["data"]["Rvals"]
    return {
        "Rwp": float(hist.get_wR()),
        "strain_microstrain": float(hap["Mustrain"][1][0]),
        "converged": bool(cov.get("converged", False)),
        "SVD0": int(cov.get("SVD0", 0)),
        "message": cov.get("msg"),
    }


labels = ("roughness", "wo3_size", "wo3_strain", "mn2o3_size", "mnwo4_strain", "mnwo4_phase")
results = {"baseline_Rwp": float(G2sc.G2Project(gpxfile=str(source)).histograms()[0].get_wR())}
results.update({f"without_{label}": remove(label) for label in labels})
results["mn2o3_strain_retest"] = test_mn2o3_strain()
print("FINAL_PROFILE_AUDIT=" + json.dumps(results, sort_keys=True))
