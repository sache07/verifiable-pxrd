"""Export phase CIFs and the saved observed/calculated/difference profile."""

from pathlib import Path
import csv
import json

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
project = G2sc.G2Project(gpxfile=str(root / "final.gpx"))
hist = project.histograms()[0]
phases = {phase.name: phase for phase in project.phases()}
outputs = {
    "WO3": root / "phase_1_WO3.cif",
    "Mn2O3": root / "phase_2_Mn2O3.cif",
    "MnWO4": root / "phase_3_MnWO4.cif",
}
for name, output in outputs.items():
    phases[name].export_CIF(str(output))

x, observed, weight, calculated, background, difference = hist.data["data"][1]
with (root / "fit.csv").open("w", encoding="utf-8", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow([
        "two_theta_deg",
        "observed_counts",
        "calculated_counts",
        "difference_counts",
        "background_counts",
    ])
    for row in zip(x, observed, calculated, difference, background):
        writer.writerow([f"{float(row[0]):.8f}"] + [f"{float(value):.6f}" for value in row[1:]])

covariance = project.data["Covariance"]["data"]
dependent = covariance.get("depSigDict", {})
summary = {
    "fit_statistics": {
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(hist.data["data"][0]["R"]),
        "Rexp_percent": float(hist.data["data"][0]["wRmin"]),
        "GOF": float(covariance["Rvals"]["GOF"]),
        "chi_square": float(covariance["Rvals"]["chisq"]),
        "Nobs": int(covariance["Rvals"]["Nobs"]),
        "Nvars": int(covariance["Rvals"]["Nvars"]),
    },
    "phases": {},
}
for phase in project.phases():
    summary["phases"][phase.name] = {
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "cell": phase.data["General"]["Cell"][1:8],
        "weight_fraction": dependent.get(f"{phase.id}:0:WgtFrac"),
    }
print("FINAL_EXPORT_RESULT=" + json.dumps(summary, sort_keys=True))
