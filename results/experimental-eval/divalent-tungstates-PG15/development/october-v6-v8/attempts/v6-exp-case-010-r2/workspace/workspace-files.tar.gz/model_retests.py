"""Mature-profile replacement tests for the principal phase assignments."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CASES = {
    "WO3_P21c": ROOT / "mature_mono_profile.gpx",
    "WO3_Pnma": ROOT / "screen_orth2107312_cub1514230_stable00.gpx",
    "Mn2O3_Pbca": ROOT / "screen_tri2106293_orth1514103_stable00.gpx",
}


def setup(project):
    hist = project.histograms()[0]
    phases = {phase.name: phase for phase in project.phases()}
    hist.data["Instrument Parameters"][0]["U"][1:] = [0.0, False]
    hist.data["Instrument Parameters"][0]["V"][1:] = [0.0, False]
    hist.data["Instrument Parameters"][0]["W"][1:] = [15.0, False]
    hist.data["Instrument Parameters"][0]["Zero"][2] = False
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.093, False]
    for phase in phases.values():
        phase.data["General"]["Cell"][0] = False
    wo = phases["WO3"].data["Histograms"][hist.name]
    mn = phases["Mn2O3"].data["Histograms"][hist.name]
    wo["Size"][1][0] = 0.16
    wo["Mustrain"][1][0] = 4683.0
    mn["Size"][1][0] = 0.061
    mn["Mustrain"][1][0] = 0.0


def set_block(project, block):
    hist = project.histograms()[0]
    phases = {phase.name: phase for phase in project.phases()}
    hist.data["Background"][0][1] = block == "background_scale"
    for phase in phases.values():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = block == "background_scale"
        hap["Size"][2][0] = False
        hap["Mustrain"][2][0] = False
        phase.data["General"]["Cell"][0] = False
    instrument = hist.data["Instrument Parameters"][0]
    for value in instrument.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    if block == "profile":
        instrument["W"][2] = True
        phases["WO3"].data["Histograms"][hist.name]["Size"][2][0] = True
        phases["WO3"].data["Histograms"][hist.name]["Mustrain"][2][0] = True
        phases["Mn2O3"].data["Histograms"][hist.name]["Size"][2][0] = True
    elif block == "roughness":
        hist.data["Sample Parameters"]["SurfRoughB"][1] = True


def refine_case(label, source):
    project = G2sc.G2Project(gpxfile=str(source))
    setup(project)
    output = ROOT / f"retest_{label}.gpx"
    project.save(str(output))
    for _ in range(3):
        for block in ("background_scale", "profile", "roughness"):
            set_block(project, block)
            project.save()
            project.do_refinements([{}])
    set_block(project, "background_scale")
    project.save()
    project.do_refinements([{}])
    hist = project.histograms()[0]
    cov = project.data["Covariance"]["data"]
    phases = {phase.name: phase for phase in project.phases()}
    return {
        "Rwp": float(hist.get_wR()),
        "GOF": float(cov["Rvals"]["GOF"]),
        "converged": bool(cov["Rvals"].get("converged", False)),
        "SVD0": int(cov["Rvals"].get("SVD0", 0)),
        "space_groups": {name: phase.data["General"]["SGData"]["SpGrp"]
                         for name, phase in phases.items()},
        "cells": {name: phase.data["General"]["Cell"][1:8]
                  for name, phase in phases.items()},
    }


results = {label: refine_case(label, source) for label, source in CASES.items()}
print("STRUCTURE_RETEST_RESULT=" + json.dumps(results, sort_keys=True))
