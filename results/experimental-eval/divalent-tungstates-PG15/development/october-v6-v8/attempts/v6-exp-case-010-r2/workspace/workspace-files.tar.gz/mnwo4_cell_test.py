"""Test whether the trace MnWO4 lattice is identifiable from this pattern."""

from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
project = G2sc.G2Project(gpxfile=str(root / "mnwo4_strain_branch.gpx"))
hist = project.histograms()[0]
phases = {phase.name: phase for phase in project.phases()}
candidate = phases["MnWO4_test"]

hist.data["Background"][0][1] = False
for value in hist.data["Instrument Parameters"][0].values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for value in hist.data["Sample Parameters"].values():
    if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
        value[1] = False
for phase in phases.values():
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = False
    hap["Size"][2][0] = False
    hap["Mustrain"][2][0] = False

candidate.data["General"]["Cell"][0] = True
candidate.data["Histograms"][hist.name]["Scale"][1] = True
project.save(str(root / "mnwo4_cell_branch.gpx"))
project.do_refinements([{}])

covdata = project.data["Covariance"]["data"]
vary = covdata.get("varyList", [])
cov = np.asarray(covdata.get("covMatrix", []))
sig = np.asarray(covdata.get("sig", []))
maxcorr = None
if len(vary):
    corr = cov / np.outer(sig, sig)
    np.fill_diagonal(corr, 0.0)
    i, j = np.unravel_index(np.nanargmax(np.abs(corr)), corr.shape)
    maxcorr = [str(vary[i]), str(vary[j]), float(corr[i, j])]
result = {
    "Rwp": float(hist.get_wR()),
    "cell": candidate.data["General"]["Cell"][1:8],
    "Rvals": covdata["Rvals"],
    "vary": [str(item) for item in vary],
    "sigmas": sig.tolist(),
    "max_correlation": maxcorr,
}
print("MNWO4_CELL_RESULT=" + json.dumps(result, sort_keys=True))
