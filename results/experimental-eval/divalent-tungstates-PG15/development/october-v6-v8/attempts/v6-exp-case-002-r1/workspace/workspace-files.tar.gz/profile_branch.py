#!/usr/bin/env python3
"""Run matched global constant-wavelength profile branches."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PRESETS = {
    # value, refine flag. All widths are GSAS-II centidegree units.
    "u0_wy": {"U": (0.0, False), "V": (0.0, False), "W": (26.3, True), "X": (0.0, False), "Y": (88.2, True), "Z": (0.0, False)},
    "u0_wxy": {"U": (0.0, False), "V": (0.0, False), "W": (26.3, True), "X": (0.0, True), "Y": (88.2, True), "Z": (0.0, False)},
    "u0_wyz": {"U": (0.0, False), "V": (0.0, False), "W": (26.3, True), "X": (0.0, False), "Y": (88.2, True), "Z": (0.0, True)},
    "u0_w": {"U": (0.0, False), "V": (0.0, False), "W": (26.3, True), "X": (0.0, False), "Y": (0.0, False), "Z": (0.0, False)},
    "uwy": {"U": (20.0, True), "V": (0.0, False), "W": (26.3, True), "X": (0.0, False), "Y": (88.2, True), "Z": (0.0, False)},
    "uvwy": {"U": (20.0, True), "V": (0.0, True), "W": (26.3, True), "X": (0.0, False), "Y": (88.2, True), "Z": (0.0, False)},
    "uwxy": {"U": (20.0, True), "V": (0.0, False), "W": (26.3, True), "X": (0.0, True), "Y": (88.2, True), "Z": (0.0, False)},
    "uwyz": {"U": (20.0, True), "V": (0.0, False), "W": (26.3, True), "X": (0.0, False), "Y": (88.2, True), "Z": (0.0, True)},
    "uwx": {"U": (20.0, True), "V": (0.0, False), "W": (26.3, True), "X": (30.0, True), "Y": (0.0, False), "Z": (0.0, False)},
    "wx": {"U": (0.0, False), "V": (0.0, False), "W": (26.3, True), "X": (30.0, True), "Y": (0.0, False), "Z": (0.0, False)},
    "uw": {"U": (20.0, True), "V": (0.0, False), "W": (26.3, True), "X": (0.0, False), "Y": (0.0, False), "Z": (0.0, False)},
    # Minimal one-at-a-time additions to a W=0, Y-only mature baseline.
    "w0_uy": {"U": (5.0, True), "V": (0.0, False), "W": (0.0, False), "X": (0.0, False), "Y": (90.0, True), "Z": (0.0, False)},
    "w0_vy": {"U": (0.0, False), "V": (0.0, True), "W": (0.0, False), "X": (0.0, False), "Y": (90.0, True), "Z": (0.0, False)},
    "w0_xy": {"U": (0.0, False), "V": (0.0, False), "W": (0.0, False), "X": (5.0, True), "Y": (90.0, True), "Z": (0.0, False)},
    "w0_yz": {"U": (0.0, False), "V": (0.0, False), "W": (0.0, False), "X": (0.0, False), "Y": (90.0, True), "Z": (5.0, True)},
}


def refine_stable(project, calls=8):
    for _ in range(calls):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        vals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        msg = str(vals.get("msg", "") or "").lower()
        if vals.get("Aborted") or int(vals.get("SVD0", 0) or 0) or "dropped" in msg or "error" in msg:
            return False, str(vals.get("msg"))
        if vals.get("converged") and float(vals.get("Max shft/sig") or 0.0) < 0.05:
            return True, None
    return False, "did_not_reach_shift_threshold"


def correlations(project):
    data = project.data.get("Covariance", {}).get("data", {})
    names = list(data.get("varyList", []))
    matrix = np.asarray(data.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denom = np.outer(sigma, sigma)
    with np.errstate(invalid="ignore", divide="ignore"):
        corr = matrix / denom
    rows = []
    for i in range(len(names)):
        for j in range(i):
            if not np.isfinite(corr[i, j]):
                continue
            if any(token in names[i] or token in names[j] for token in (":U", ":V", ":W", ":X", ":Y", ":Z")):
                rows.append((abs(float(corr[i, j])), float(corr[i, j]), names[i], names[j]))
    rows.sort(reverse=True)
    return [{"correlation": row[1], "first": row[2], "second": row[3]} for row in rows[:10]]


def diagnostics(project):
    hist = project.histograms()[0]
    inst = hist.InstrumentParameters
    x = np.linspace(float(hist.data["Limits"][1][0]), float(hist.data["Limits"][1][1]), 2001)
    theta = np.radians(x / 2.0)
    tan = np.tan(theta)
    cos = np.cos(theta)
    value = lambda key: float(inst[key][1])
    sig = value("U") * tan**2 + value("V") * tan + value("W")
    gam = value("X") / cos + value("Y") * tan + value("Z")
    obs = np.asarray(hist.getdata("Yobs"), dtype=float)
    calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    wt = np.asarray(hist.getdata("Yweight"), dtype=float)
    xx = np.asarray(hist.getdata("X"), dtype=float)
    regions = []
    for lo, hi in [(9.9, 20), (20, 30), (30, 40), (40, 55), (55, 70), (70, 85), (85, 100.1)]:
        use = (xx >= lo) & (xx < hi) & (wt > 0)
        rwp = 100 * math.sqrt(np.sum(wt[use] * (obs[use] - calc[use]) ** 2) / np.sum(wt[use] * obs[use] ** 2))
        regions.append([lo, hi, rwp])
    vals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "rwp": float(hist.get_wR()),
        "parameters": {key: inst[key] for key in ("U", "V", "W", "X", "Y", "Z")},
        "minimum_gaussian_variance": float(np.min(sig)),
        "minimum_lorentzian_width": float(np.min(gam)),
        "regions": regions,
        "profile_correlations": correlations(project),
        "convergence": {key: vals.get(key) for key in ("converged", "SVD0", "Max shft/sig", "msg")},
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("preset", choices=sorted(PRESETS))
    args = parser.parse_args()
    project = G2sc.G2Project(str(args.baseline.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histograms()[0]
    for key, (value, refine) in PRESETS[args.preset].items():
        hist.InstrumentParameters[key][1] = float(value)
        hist.InstrumentParameters[key][2] = bool(refine)
    project.data["Controls"]["data"]["max cyc"] = 20
    project.save(str(args.output.with_name(args.output.stem + "-start.gpx").resolve()))
    valid, error = refine_stable(project)
    project.save(str(args.output.resolve()))
    print("PROFILE_BRANCH_RESULT=" + json.dumps({"preset": args.preset, "valid": valid, "error": error, **diagnostics(project)}, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
