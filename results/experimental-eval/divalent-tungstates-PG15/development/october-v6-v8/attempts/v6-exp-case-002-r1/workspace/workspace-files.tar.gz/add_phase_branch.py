#!/usr/bin/env python3
"""Add one candidate to a mature GSAS-II baseline and test its support."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def covariance(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine_to_stable(project, calls=8, threshold=0.2):
    for _ in range(calls):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        vals = covariance(project)
        msg = str(vals.get("msg", "") or "").lower()
        if vals.get("Aborted") or int(vals.get("SVD0", 0) or 0) or "dropped" in msg or "error" in msg:
            return False, str(vals.get("msg"))
        if vals.get("converged") and float(vals.get("Max shft/sig") or 0.0) < threshold:
            return True, None
    return False, "did_not_reach_shift_threshold"


def freeze_all(project):
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for item in hist.InstrumentParameters.values():
        if isinstance(item, list) and len(item) >= 3:
            item[2] = False
    for item in hist.SampleParameters.values():
        if isinstance(item, list) and len(item) == 2:
            item[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.data["Atoms"]:
            atom[2] = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])


def restore_baseline_flags(project, template, candidate_name):
    hist = project.histograms()[0]
    source_hist = template.histograms()[0]
    hist.Background[0][1] = source_hist.Background[0][1]
    for key, item in hist.InstrumentParameters.items():
        source = source_hist.InstrumentParameters.get(key)
        if isinstance(item, list) and len(item) >= 3 and isinstance(source, list) and len(source) >= 3:
            item[2] = source[2]
    for key, item in hist.SampleParameters.items():
        source = source_hist.SampleParameters.get(key)
        if isinstance(item, list) and len(item) == 2 and isinstance(source, list) and len(source) == 2:
            item[1] = source[1]
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if phase.name == candidate_name:
            phase.data["General"]["Cell"][0] = False
            hap["Scale"][1] = True
            continue
        source = template.phase(phase.name)
        phase.data["General"]["Cell"][0] = source.data["General"]["Cell"][0]
        for atom, source_atom in zip(phase.data["Atoms"], source.data["Atoms"]):
            atom[2] = source_atom[2]
        source_hap = source.data["Histograms"][source_hist.name]
        hap["Scale"][1] = source_hap["Scale"][1]
        hap["Pref.Ori."][2] = source_hap["Pref.Ori."][2]
        hap["Size"][2] = list(source_hap["Size"][2])
        hap["Mustrain"][2] = list(source_hap["Mustrain"][2])
        hap["HStrain"][1] = list(source_hap["HStrain"][1])


def region_rwp(hist, intervals):
    x = np.asarray(hist.getdata("X"), dtype=float)
    obs = np.asarray(hist.getdata("Yobs"), dtype=float)
    calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    weights = np.asarray(hist.getdata("Yweight"), dtype=float)
    rows = []
    for lower, upper in intervals:
        use = (x >= lower) & (x < upper) & (weights > 0)
        value = 100 * math.sqrt(np.sum(weights[use] * (obs[use] - calc[use]) ** 2) / np.sum(weights[use] * obs[use] ** 2))
        rows.append([lower, upper, value])
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--name", required=True)
    args = parser.parse_args()

    baseline = G2sc.G2Project(str(args.baseline.resolve()))
    baseline_rwp = float(baseline.histograms()[0].get_wR())
    project = G2sc.G2Project(str(args.baseline.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histograms()[0]
    candidate = project.add_phase(str(args.candidate.resolve()), phasename=args.name, histograms=[hist], fmthint="CIF")
    freeze_all(project)
    candidate.data["Histograms"][hist.name]["Scale"] = [0.01, True]
    project.save(str(args.output.with_name(args.output.stem + "-start.gpx").resolve()))
    scale_only_valid, scale_only_error = refine_to_stable(project, calls=5)
    scale_only = {
        "valid": scale_only_valid,
        "error": scale_only_error,
        "rwp": float(hist.get_wR()),
        "scale": float(candidate.data["Histograms"][hist.name]["Scale"][0]),
    }
    project.save(str(args.output.with_name(args.output.stem + "-scale-only.gpx").resolve()))

    restore_baseline_flags(project, baseline, args.name)
    full_valid, full_error = refine_to_stable(project, calls=8)
    project.save(str(args.output.resolve()))
    result = {
        "baseline_rwp": baseline_rwp,
        "scale_only": scale_only,
        "full": {
            "valid": full_valid,
            "error": full_error,
            "rwp": float(hist.get_wR()),
            "candidate_scale": float(candidate.data["Histograms"][hist.name]["Scale"][0]),
            "candidate_cell": candidate.get_cell(),
            "mass_fractions": hist.ComputeMassFracs() if full_valid else None,
            "regions": region_rwp(hist, [(9.9, 20), (20, 30), (30, 40), (40, 55), (55, 70), (70, 85), (85, 100.1)]),
            "convergence": {key: covariance(project).get(key) for key in ("converged", "SVD0", "Max shft/sig", "msg")},
        },
    }
    print("ADD_PHASE_RESULT=" + json.dumps(result, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
