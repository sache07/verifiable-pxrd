#!/usr/bin/env python3
"""Test one phase-specific isotropic size or microstrain term."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def refine_stable(project, calls=8):
    for _ in range(calls):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        vals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        msg = str(vals.get("msg", "") or "").lower()
        if vals.get("Aborted") or int(vals.get("SVD0", 0) or 0) or "dropped" in msg or "error" in msg:
            return False, str(vals.get("msg"))
        if vals.get("converged") and float(vals.get("Max shft/sig") or 0.0) < 0.05:
            return True, None
    return False, "did_not_reach_shift_threshold"


def correlations(project, token):
    data = project.data.get("Covariance", {}).get("data", {})
    names = list(data.get("varyList", []))
    matrix = np.asarray(data.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sig = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    with np.errstate(invalid="ignore", divide="ignore"):
        corr = matrix / np.outer(sig, sig)
    rows = []
    selected = [i for i, name in enumerate(names) if token in name]
    for i in selected:
        for j in range(len(names)):
            if i == j or not np.isfinite(corr[i, j]):
                continue
            rows.append((abs(float(corr[i, j])), float(corr[i, j]), names[i], names[j]))
    rows.sort(reverse=True)
    return [{"correlation": row[1], "first": row[2], "second": row[3]} for row in rows[:8]]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("kind", choices=("size", "strain"))
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histograms()[0]
    phase = project.phase(args.phase)
    if args.kind == "size":
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True}}, [hist])
        token = "Size;i"
    else:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
        phase.data["Histograms"][hist.name]["Mustrain"][1][0] = 1000.0
        token = "Mustrain;i"
    project.data["Controls"]["data"]["max cyc"] = 20
    project.save(str(args.output.with_name(args.output.stem + "-start.gpx").resolve()))
    valid, error = refine_stable(project)
    project.save(str(args.output.resolve()))

    hap = phase.data["Histograms"][hist.name]
    obs = np.asarray(hist.getdata("Yobs"), dtype=float)
    calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    wt = np.asarray(hist.getdata("Yweight"), dtype=float)
    x = np.asarray(hist.getdata("X"), dtype=float)
    regions = []
    for lo, hi in [(9.9, 20), (20, 30), (30, 40), (40, 55), (55, 70), (70, 85), (85, 100.1)]:
        use = (x >= lo) & (x < hi) & (wt > 0)
        rwp = 100 * math.sqrt(np.sum(wt[use] * (obs[use] - calc[use]) ** 2) / np.sum(wt[use] * obs[use] ** 2))
        regions.append([lo, hi, rwp])
    vals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "phase": args.phase,
        "kind": args.kind,
        "valid": valid,
        "error": error,
        "rwp": float(hist.get_wR()),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "regions": regions,
        "correlations": correlations(project, token),
        "convergence": {key: vals.get(key) for key in ("converged", "SVD0", "Max shft/sig", "msg")},
    }
    print("MICROSTRUCTURE_BRANCH_RESULT=" + json.dumps(result, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
