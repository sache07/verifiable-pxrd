#!/usr/bin/env python3
"""Test a staged set of atomic-coordinate refinements."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def refine_stable(project, calls=10):
    for _ in range(calls):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        vals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        msg = str(vals.get("msg", "") or "").lower()
        if vals.get("Aborted") or int(vals.get("SVD0", 0) or 0) or "dropped" in msg or "error" in msg:
            return False, str(vals.get("msg"))
        if vals.get("converged") and float(vals.get("Max shft/sig") or 0.0) < 0.05:
            return True, None
    return False, "did_not_reach_shift_threshold"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("labels", help="Comma-separated atom labels")
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histograms()[0]
    phase = project.phase(args.phase)
    labels = [label.strip() for label in args.labels.split(",") if label.strip()]
    before = {label: list(phase.atom(label).coordinates) for label in labels}
    phase.set_refinements({"Atoms": {label: "X" for label in labels}})
    project.data["Controls"]["data"]["max cyc"] = 20
    project.save(str(args.output.with_name(args.output.stem + "-start.gpx").resolve()))
    valid, error = refine_stable(project)
    project.save(str(args.output.resolve()))
    phase.export_CIF(str(args.output.with_suffix(".cif").resolve()))

    data = project.data.get("Covariance", {}).get("data", {})
    names = list(data.get("varyList", []))
    cov = np.asarray(data.get("covMatrix", []), dtype=float)
    correlations = []
    if cov.shape == (len(names), len(names)):
        sig = np.sqrt(np.maximum(np.diag(cov), 0.0))
        with np.errstate(invalid="ignore", divide="ignore"):
            corr = cov / np.outer(sig, sig)
        coord_indices = [i for i, name in enumerate(names) if "::dA" in name]
        for i in coord_indices:
            for j in range(len(names)):
                if i == j or not np.isfinite(corr[i, j]):
                    continue
                correlations.append((abs(float(corr[i, j])), float(corr[i, j]), names[i], names[j]))
    correlations.sort(reverse=True)
    vals = data.get("Rvals", {})
    result = {
        "phase": args.phase,
        "labels": labels,
        "valid": valid,
        "error": error,
        "rwp": float(hist.get_wR()),
        "mass_fractions": hist.ComputeMassFracs(),
        "coordinates_before": before,
        "coordinates_after": {label: list(phase.atom(label).coordinates) for label in labels},
        "correlations": [
            {"correlation": row[1], "first": row[2], "second": row[3]}
            for row in correlations[:12]
        ],
        "convergence": {key: vals.get(key) for key in ("converged", "SVD0", "Max shft/sig", "msg")},
    }
    print("ATOM_BRANCH_RESULT=" + json.dumps(result, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
