#!/usr/bin/env python3
"""Test one simple March-Dollase preferred-orientation axis."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def refine_stable(project, calls=8):
    for _ in range(calls):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        vals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        msg = str(vals.get("msg", "") or "").lower()
        if vals.get("Aborted") or int(vals.get("SVD0", 0) or 0) or "dropped" in msg or "error" in msg:
            return False, str(vals.get("msg"))
        if vals.get("converged") and float(vals.get("Max shft/sig") or 0.0) < 0.05:
            return True, None
    return False, "did_not_reach_shift_threshold"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("h", type=int)
    parser.add_argument("k", type=int)
    parser.add_argument("l", type=int)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histograms()[0]
    phase = project.phase(args.phase)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = [args.h, args.k, args.l]
    project.data["Controls"]["data"]["max cyc"] = 20
    project.save(str(args.output.with_name(args.output.stem + "-start.gpx").resolve()))
    valid, error = refine_stable(project)
    project.save(str(args.output.resolve()))

    obs = np.asarray(hist.getdata("Yobs"), dtype=float)
    calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    wt = np.asarray(hist.getdata("Yweight"), dtype=float)
    x = np.asarray(hist.getdata("X"), dtype=float)
    regions = []
    for lo, hi in [(9.9, 20), (20, 30), (30, 40), (40, 55), (55, 70), (70, 85), (85, 100.1)]:
        use = (x >= lo) & (x < hi) & (wt > 0)
        rwp = 100 * math.sqrt(np.sum(wt[use] * (obs[use] - calc[use]) ** 2) / np.sum(wt[use] * obs[use] ** 2))
        regions.append([lo, hi, rwp])

    data = project.data.get("Covariance", {}).get("data", {})
    names = list(data.get("varyList", []))
    cov = np.asarray(data.get("covMatrix", []), dtype=float)
    correlations = []
    if cov.shape == (len(names), len(names)):
        sig = np.sqrt(np.maximum(np.diag(cov), 0.0))
        with np.errstate(invalid="ignore", divide="ignore"):
            corr = cov / np.outer(sig, sig)
        for i, name in enumerate(names):
            if not name.endswith(":MD"):
                continue
            for j, other in enumerate(names):
                if i == j or not np.isfinite(corr[i, j]):
                    continue
                correlations.append((abs(float(corr[i, j])), float(corr[i, j]), name, other))
    correlations.sort(reverse=True)
    vals = data.get("Rvals", {})
    result = {
        "phase": args.phase,
        "axis": [args.h, args.k, args.l],
        "valid": valid,
        "error": error,
        "rwp": float(hist.get_wR()),
        "march_dollase": po,
        "mass_fractions": hist.ComputeMassFracs(),
        "regions": regions,
        "correlations": [
            {"correlation": row[1], "first": row[2], "second": row[3]}
            for row in correlations[:8]
        ],
        "convergence": {key: vals.get(key) for key in ("converged", "SVD0", "Max shft/sig", "msg")},
    }
    print("TEXTURE_BRANCH_RESULT=" + json.dumps(result, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
