#!/usr/bin/env python3
"""Build matched, conservative GSAS-II screening refinements."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter, gaussian_filter1d
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

CANDIDATES = {
    "wo3_p21c": COD / "2/31/10/2311041.cif",
    "wo3_p21c_conv": ROOT / "screening/wo3_p21c_conventional.cif",
    "wo3_p1": COD / "2/10/62/2106293.cif",
    "wo3_pnma": COD / "2/10/73/2107312.cif",
    "wo3_p21c_alt": COD / "1/52/89/1528915.cif",
    "wo3_p21c_small": COD / "1/56/35/1563541.cif",
    "wo3_p4ncc": COD / "1/52/15/1521532.cif",
    "bao2": COD / "1/01/01/1010113.cif",
    "bawo4_split": COD / "1/52/72/1527204.cif",
    "bawo4_scheelite": ROOT / "screening/bawo4_scheelite_analog.cif",
    "ba_o_def_3766": COD / "1/52/14/1521428.cif",
    "ba_o_def_3446": COD / "1/52/14/1521429.cif",
    "ba_o_def_3363": COD / "1/52/14/1521430.cif",
}


def stable_refine(project: G2sc.G2Project, attempts: int = 8) -> bool:
    """Refine repeatedly until converged and reject numerical failures."""
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as exc:
            print("REFINE_ERROR", repr(exc))
            return False
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        msg = str(rvals.get("msg", "") or "").lower()
        if rvals.get("Aborted") or int(rvals.get("SVD0", 0) or 0) or "dropped" in msg or "error" in msg:
            return False
        # Screening projects are only used to rank complete-pattern models;
        # final branches are converged more tightly after inventory selection.
        if rvals.get("converged") and float(rvals.get("Max shft/sig") or 0.0) < 0.2:
            return True
    return False


def initial_background(hist, degree: int = 12) -> None:
    x = np.asarray(hist.getdata("X"), dtype=float)
    y = np.asarray(hist.getdata("Yobs"), dtype=float)
    baseline = percentile_filter(y, percentile=18, size=401, mode="nearest")
    baseline = gaussian_filter1d(baseline.astype(float), sigma=80)
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    coeffs = np.polynomial.chebyshev.chebfit(t, baseline, degree - 1).tolist()
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "refine": False,
                "no. coeffs": degree,
                "coeffs": coeffs,
            },
        }
    )


def status(project: G2sc.G2Project, label: str, valid: bool = True) -> dict:
    hist = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": phase.get_cell(),
                "composition": phase.composition,
            }
        )
    return {
        "label": label,
        "valid": bool(valid),
        "rwp": float(hist.get_wR()),
        "gof": float(hist.residuals.get("GOF", math.nan)),
        "rp": float(hist.residuals.get("Rp", math.nan)),
        "zero": hist.InstrumentParameters.get("Zero"),
        "profile": {k: hist.InstrumentParameters.get(k) for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "phases": phases,
        "convergence": {k: rvals.get(k) for k in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp")},
    }


def build(label: str, phase_keys: list[str], instrument: Path, outdir: Path) -> dict:
    outdir.mkdir(parents=True, exist_ok=True)
    initial_path = outdir / f"{label}-initial.gpx"
    project = G2sc.G2Project(newgpx=str(initial_path))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(instrument),
        fmthint="comma/tab/semicolon separated",
    )
    # Absolute intensity is represented by phase scales; keep the redundant
    # histogram/sample scale fixed to avoid an exact scale correlation.
    if isinstance(hist.SampleParameters.get("Scale"), list):
        hist.SampleParameters["Scale"][0] = 1.0
        hist.SampleParameters["Scale"][1] = False
    for key in phase_keys:
        project.add_phase(str(CANDIDATES[key]), phasename=key, histograms=[hist], fmthint="CIF")
    initial_background(hist)
    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    # Keep initial phases on comparable scales.
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][0] = 1.0
    project.save()

    # Stage 1: background and positive phase scales.
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    valid = stable_refine(project)
    project.save(str(outdir / f"{label}-scales.gpx"))
    if not valid:
        return status(project, label, False)

    # Stage 2: unit cells, retaining a common zero correction.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    valid = stable_refine(project)
    project.save(str(outdir / f"{label}-cell.gpx"))
    if not valid:
        return status(project, label, False)

    # Stage 3: a minimal common Gaussian/Lorentzian profile.
    hist.set_refinements({"Instrument Parameters": ["W", "Y"]})
    valid = stable_refine(project)
    project.save(str(outdir / f"{label}-minimal.gpx"))
    return status(project, label, valid)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--label", required=True)
    parser.add_argument("--phases", required=True, help="comma-separated candidate keys")
    parser.add_argument("--instrument", choices=("single", "dual"), default="single")
    parser.add_argument("--outdir", type=Path, default=ROOT / "screening")
    args = parser.parse_args()
    instrument = ROOT / f"instrument_{args.instrument}.instprm"
    result = build(args.label, args.phases.split(","), instrument, args.outdir)
    print("SCREEN_RESULT=" + json.dumps(result, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
