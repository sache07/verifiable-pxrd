#!/usr/bin/env python3
"""Remove one retained optional term from a mature model and reconverge."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def refine_stable(project, calls=10):
    for _ in range(calls):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        vals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        msg = str(vals.get("msg", "") or "").lower()
        if vals.get("Aborted") or int(vals.get("SVD0", 0) or 0) or "dropped" in msg or "error" in msg:
            return False, str(vals.get("msg"))
        if vals.get("converged") and float(vals.get("Max shft/sig") or 0.0) < 0.05:
            return True, None
    return False, "did_not_reach_shift_threshold"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "term",
        choices=("wo3_size", "bao2_size", "polarization", "wo3_texture", "wo3_coords", "bao2_coord", "global_y"),
    )
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histograms()[0]
    wo3 = project.phase("wo3_p21c_conv")
    bao2 = project.phase("bao2")
    if args.term == "wo3_size":
        size = wo3.data["Histograms"][hist.name]["Size"]
        size[1][0], size[2][0] = 10.0, False
    elif args.term == "bao2_size":
        size = bao2.data["Histograms"][hist.name]["Size"]
        size[1][0], size[2][0] = 10.0, False
    elif args.term == "polarization":
        hist.InstrumentParameters["Polariz."][1:] = [0.7, False]
    elif args.term == "wo3_texture":
        po = wo3.data["Histograms"][hist.name]["Pref.Ori."]
        po[1], po[2] = 1.0, False
    elif args.term == "wo3_coords":
        reference = {
            "W1": (0.246, 0.463, 0.218),
            "W2": (0.250, 0.477, 0.716),
        }
        for label, xyz in reference.items():
            atom = wo3.atom(label)
            atom.coordinates = xyz
            atom.refinement_flags = ""
    elif args.term == "bao2_coord":
        atom = bao2.atom("O1")
        atom.coordinates = (0.0, 0.0, 0.404)
        atom.refinement_flags = ""
    elif args.term == "global_y":
        hist.InstrumentParameters["Y"][1:] = [0.0, False]

    project.data["Controls"]["data"]["max cyc"] = 20
    project.save(str(args.output.with_name(args.output.stem + "-start.gpx").resolve()))
    valid, error = refine_stable(project)
    project.save(str(args.output.resolve()))

    x = np.asarray(hist.getdata("X"), dtype=float)
    obs = np.asarray(hist.getdata("Yobs"), dtype=float)
    calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    wt = np.asarray(hist.getdata("Yweight"), dtype=float)
    regions = []
    for lo, hi in [(9.9, 20), (20, 30), (30, 40), (40, 55), (55, 70), (70, 85), (85, 100.1)]:
        use = (x >= lo) & (x < hi) & (wt > 0)
        rwp = 100 * math.sqrt(np.sum(wt[use] * (obs[use] - calc[use]) ** 2) / np.sum(wt[use] * obs[use] ** 2))
        regions.append([lo, hi, rwp])
    vals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "term_removed": args.term,
        "valid": valid,
        "error": error,
        "rwp": float(hist.get_wR()),
        "mass_fractions": hist.ComputeMassFracs(),
        "regions": regions,
        "convergence": {key: vals.get(key) for key in ("converged", "SVD0", "Max shft/sig", "msg")},
    }
    print("ABLATION_BRANCH_RESULT=" + json.dumps(result, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
