#!/usr/bin/env python3
"""Replace one phase with an alternative structure in a matched GSAS-II branch."""

import argparse
import contextlib
import io
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source")
parser.add_argument("old_phase")
parser.add_argument("new_phase")
parser.add_argument("cif")
parser.add_argument("output")
parser.add_argument("--attempts", type=int, default=2)
args = parser.parse_args()

log = io.StringIO()
with contextlib.redirect_stdout(log):
    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    histogram = project.histogram(0)
    old = project.phase(args.old_phase)
    old_hap = old.data["Histograms"][histogram.name]
    old_hap["Use"] = False
    old_hap["Scale"][1] = False
    phase = project.add_phase(
        args.cif,
        phasename=args.new_phase,
        histograms=[histogram],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"][:] = [0.006, True]
    phase.data["General"]["Cell"][0] = False
    project.save(args.output.replace(".gpx", "_pre_scale.gpx"))
    project.refine()
    scale_stage = {
        "rwp_percent": histogram.get_wR(),
        "scale": list(hap["Scale"]),
        "status": project.data["Covariance"]["data"]["Rvals"],
    }
    if math.isfinite(float(hap["Scale"][0])) and hap["Scale"][0] > 1.0e-10:
        phase.data["General"]["Cell"][0] = True
        project.save(args.output.replace(".gpx", "_pre_cell.gpx"))
        project.refine()
        phase.data["General"]["Cell"][0] = False
        for _ in range(args.attempts):
            project.refine()
            status = project.data["Covariance"]["data"]["Rvals"]
            if (
                status.get("converged")
                and not status.get("SVD0")
                and abs(float(status.get("Max shft/sig") or 999.0)) < 0.05
            ):
                break
    project.save(args.output)

status = project.data["Covariance"]["data"]["Rvals"]
cov = project.data["Covariance"]["data"]
vary = cov.get("varyList", [])
matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
correlations = []
if matrix.size and matrix.shape == (len(vary), len(vary)):
    sd = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    for i in range(len(vary)):
        for j in range(i):
            if sd[i] > 0 and sd[j] > 0:
                corr = matrix[i, j] / (sd[i] * sd[j])
                if abs(corr) >= 0.65:
                    correlations.append([vary[j], vary[i], float(corr)])

x, y, weight, calc = histogram.data["data"][1][:4]
lo, hi = histogram.data["Limits"][1]
valid = (x >= lo) & (x <= hi) & (weight > 0)
regions = []
for left, right in ((lo, 30.0), (30.0, 50.0), (50.0, 70.0), (70.0, hi + 1e-6)):
    selected = valid & (x >= left) & (x < right)
    rwp = 100.0 * np.sqrt(
        np.sum(weight[selected] * (y[selected] - calc[selected]) ** 2)
        / np.sum(weight[selected] * y[selected] ** 2)
    )
    regions.append([float(left), float(right), float(rwp)])

print(
    "REPLACEMENT_RESULT="
    + json.dumps(
        {
            "old_phase": args.old_phase,
            "new_phase": args.new_phase,
            "scale_stage": scale_stage,
            "final_rwp_percent": histogram.get_wR(),
            "regional_rwp_percent": regions,
            "new_scale": hap["Scale"],
            "new_cell": phase.get_cell(),
            "convergence": {
                key: status.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg", "Nvars")
            },
            "large_correlations": correlations,
            "log_tail": log.getvalue()[-1200:],
        },
        default=str,
    ),
    flush=True,
)
