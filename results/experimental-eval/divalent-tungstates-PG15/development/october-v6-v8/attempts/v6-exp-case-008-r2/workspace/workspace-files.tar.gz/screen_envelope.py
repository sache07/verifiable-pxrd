#!/usr/bin/env python3
"""Run a matched sample-envelope branch from an existing GSAS-II project."""

import argparse
import contextlib
import io
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII.GSASIIpwd import SurfaceRough


parser = argparse.ArgumentParser()
parser.add_argument("source")
parser.add_argument("mode", choices=("rough-b", "rough-ab"))
parser.add_argument("output")
parser.add_argument("--a", type=float, default=0.0)
parser.add_argument("--b", type=float, default=0.01)
parser.add_argument("--disable-polarization", action="store_true")
parser.add_argument("--attempts", type=int, default=2)
args = parser.parse_args()

log = io.StringIO()
with contextlib.redirect_stdout(log):
    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    histogram = project.histogram(0)
    if args.disable_polarization:
        histogram.InstrumentParameters["Polariz."][1] = 0.5
        histogram.InstrumentParameters["Polariz."][2] = False
    sample = histogram.SampleParameters
    sample["SurfRoughA"] = [args.a, args.mode == "rough-ab"]
    sample["SurfRoughB"] = [args.b, True]
    project.save(args.output.replace(".gpx", "_pre.gpx"))
    for _ in range(args.attempts):
        project.refine()
        status = project.data["Covariance"]["data"]["Rvals"]
        if (
            status.get("converged")
            and not status.get("SVD0")
            and abs(float(status.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(args.output)

status = project.data["Covariance"]["data"]["Rvals"]
cov = project.data["Covariance"]["data"]
vary = cov.get("varyList", [])
matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
correlations = []
if matrix.size and matrix.shape == (len(vary), len(vary)):
    sd = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    for i in range(len(vary)):
        for j in range(i):
            if sd[i] > 0 and sd[j] > 0:
                corr = matrix[i, j] / (sd[i] * sd[j])
                if abs(corr) >= 0.65:
                    correlations.append([vary[j], vary[i], float(corr)])

sample = histogram.SampleParameters
x = np.linspace(*histogram.data["Limits"][1], 2001)
correction = SurfaceRough(sample["SurfRoughA"][0], sample["SurfRoughB"][0], x)
print(
    "ENVELOPE_RESULT="
    + json.dumps(
        {
            "mode": args.mode,
            "rwp_percent": histogram.get_wR(),
            "surface_roughness": {
                "A": sample["SurfRoughA"],
                "B": sample["SurfRoughB"],
                "correction_min": float(np.min(correction)),
                "correction_max": float(np.max(correction)),
            },
            "polarization": histogram.InstrumentParameters["Polariz."],
            "mass_fractions": histogram.ComputeMassFracs(),
            "convergence": {
                key: status.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
            "large_correlations": correlations,
            "log_tail": log.getvalue()[-1000:],
        },
        default=str,
    ),
    flush=True,
)
