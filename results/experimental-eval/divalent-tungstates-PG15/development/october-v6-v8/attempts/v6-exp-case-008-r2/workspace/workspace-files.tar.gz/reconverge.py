#!/usr/bin/env python3
"""Continue a GSAS-II refinement without changing its parameter flags."""

import argparse
import contextlib
import io
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source")
parser.add_argument("output")
parser.add_argument("--attempts", type=int, default=3)
args = parser.parse_args()

log = io.StringIO()
with contextlib.redirect_stdout(log):
    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.save(args.output.replace(".gpx", "_pre.gpx"))
    for _ in range(args.attempts):
        project.refine()
        status = project.data["Covariance"]["data"]["Rvals"]
        if (
            status.get("converged")
            and not status.get("SVD0")
            and abs(float(status.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(args.output)

histogram = project.histogram(0)
status = project.data["Covariance"]["data"]["Rvals"]
cov = project.data["Covariance"]["data"]
vary = cov.get("varyList", [])
matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
correlations = []
if matrix.size and matrix.shape == (len(vary), len(vary)):
    sd = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    for i in range(len(vary)):
        for j in range(i):
            if sd[i] > 0 and sd[j] > 0:
                corr = matrix[i, j] / (sd[i] * sd[j])
                if abs(corr) >= 0.65:
                    correlations.append([vary[j], vary[i], float(corr)])

x, y, weight, calc = histogram.data["data"][1][:4]
lo, hi = histogram.data["Limits"][1]
valid = (x >= lo) & (x <= hi) & (weight > 0)
regions = []
for left, right in ((lo, 30.0), (30.0, 50.0), (50.0, 70.0), (70.0, hi + 1e-6)):
    selected = valid & (x >= left) & (x < right)
    rwp = 100.0 * np.sqrt(
        np.sum(weight[selected] * (y[selected] - calc[selected]) ** 2)
        / np.sum(weight[selected] * y[selected] ** 2)
    )
    regions.append([float(left), float(right), float(rwp)])

phases = {}
for phase in project.phases():
    hap = phase.data["Histograms"][histogram.name]
    phases[phase.name] = {
        "cell": phase.data["General"]["Cell"],
        "scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "atom_flags": {atom.label: atom.refinement_flags for atom in phase.atoms()},
    }

print(
    "RECONVERGE_RESULT="
    + json.dumps(
        {
            "rwp_percent": histogram.get_wR(),
            "mass_fractions": histogram.ComputeMassFracs(),
            "regional_rwp_percent": regions,
            "instrument": {
                key: histogram.InstrumentParameters[key]
                for key in ("Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
            },
            "sample": {
                key: histogram.SampleParameters[key]
                for key in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")
            },
            "phases": phases,
            "convergence": {
                key: status.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg", "chisq", "Nobs", "Nvars", "GOF")
            },
            "large_correlations": correlations,
            "log_tail": log.getvalue()[-1200:],
        },
        default=str,
    ),
    flush=True,
)
