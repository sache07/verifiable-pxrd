#!/usr/bin/env python3
"""Run one matched global profile-parameter branch."""

import argparse
import contextlib
import io
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source")
parser.add_argument("parameter")
parser.add_argument("output")
args = parser.parse_args()

log = io.StringIO()
with contextlib.redirect_stdout(log):
    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    histogram = project.histogram(0)
    histogram.InstrumentParameters[args.parameter][2] = True
    project.save(args.output.replace(".gpx", "_pre.gpx"))
    for _ in range(4):
        project.refine()
        status = project.data["Covariance"]["data"]["Rvals"]
        if (
            status.get("converged")
            and not status.get("SVD0")
            and abs(float(status.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(args.output)

instrument = histogram.InstrumentParameters
x = np.linspace(*histogram.data["Limits"][1], 2001)
tangent = np.tan(np.radians(x / 2.0))
cosine = np.cos(np.radians(x / 2.0))
sigma = (
    instrument["U"][1] * tangent**2
    + instrument["V"][1] * tangent
    + instrument["W"][1]
)
gamma = (
    instrument["Z"][1]
    + instrument["X"][1] / cosine
    + instrument["Y"][1] * tangent
)
status = project.data["Covariance"]["data"]["Rvals"]
print(
    "PROFILE_RESULT="
    + json.dumps(
        {
            "parameter": args.parameter,
            "rwp_percent": histogram.get_wR(),
            "instrument": {
                key: instrument[key]
                for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
            },
            "minimum_sigma": float(sigma.min()),
            "minimum_gamma": float(gamma.min()),
            "mass_fractions": histogram.ComputeMassFracs(),
            "convergence": {
                key: status.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
            "log_tail": log.getvalue()[-1000:],
        },
        default=str,
    ),
    flush=True,
)
