#!/usr/bin/env python3
"""Run a staged atomic-coordinate refinement branch."""

import argparse
import contextlib
import io
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source")
parser.add_argument("phase")
parser.add_argument("atoms", help="comma-separated labels, or all")
parser.add_argument("output")
parser.add_argument("--attempts", type=int, default=2)
args = parser.parse_args()

log = io.StringIO()
with contextlib.redirect_stdout(log):
    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    histogram = project.histogram(0)
    phase = project.phase(args.phase)
    selected = [atom.label for atom in phase.atoms()] if args.atoms == "all" else args.atoms.split(",")
    phase.set_refinements({"Atoms": {label: "X" for label in selected}})
    project.save(args.output.replace(".gpx", "_pre.gpx"))
    for _ in range(args.attempts):
        project.refine()
        status = project.data["Covariance"]["data"]["Rvals"]
        if (
            status.get("converged")
            and not status.get("SVD0")
            and abs(float(status.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(args.output)
    phase.export_CIF(args.output.replace(".gpx", ".cif"))

status = project.data["Covariance"]["data"]["Rvals"]
cov = project.data["Covariance"]["data"]
vary = cov.get("varyList", [])
matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
correlations = []
if matrix.size and matrix.shape == (len(vary), len(vary)):
    sd = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    for i in range(len(vary)):
        for j in range(i):
            if sd[i] > 0 and sd[j] > 0:
                corr = matrix[i, j] / (sd[i] * sd[j])
                if abs(corr) >= 0.65:
                    correlations.append([vary[j], vary[i], float(corr)])

cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
atoms = []
for atom in phase.data["Atoms"]:
    atoms.append(
        {
            "label": atom[ct - 1],
            "type": atom[ct],
            "flags": atom[ct + 1],
            "xyz": [float(value) for value in atom[cx : cx + 3]],
            "occupancy": float(atom[cx + 3]),
        }
    )

print(
    "ATOM_RESULT="
    + json.dumps(
        {
            "phase": phase.name,
            "selected": selected,
            "rwp_percent": histogram.get_wR(),
            "mass_fractions": histogram.ComputeMassFracs(),
            "atoms": atoms,
            "convergence": {
                key: status.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
            "large_correlations": correlations,
            "log_tail": log.getvalue()[-1200:],
        },
        default=str,
    ),
    flush=True,
)
