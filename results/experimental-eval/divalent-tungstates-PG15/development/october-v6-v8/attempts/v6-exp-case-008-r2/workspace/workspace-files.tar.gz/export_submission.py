#!/usr/bin/env python3
"""Export CIFs, profile CSV, and machine-readable results from final.gpx."""

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
project_path = root / "final.gpx"
project = G2sc.G2Project(str(project_path))
histogram = project.histogram(0)

phase_specs = [
    ("MnWO4", "MnWO4", "phase_MnWO4.cif", "1520200"),
    ("wo3_mono", "WO3 (monoclinic)", "phase_WO3.cif", "2311041"),
]

raw_fractions = histogram.ComputeMassFracs()
fraction_values = {name: float(raw_fractions[name][0]) for name, *_ in phase_specs}
fraction_sum = sum(fraction_values.values())
if not math.isfinite(fraction_sum) or fraction_sum <= 0.0:
    raise ValueError("invalid crystalline phase-fraction sum")

phase_rows = []
for internal_name, display_name, cif_name, cod_id in phase_specs:
    phase = project.phase(internal_name)
    phase.export_CIF(str(root / cif_name))
    value, esd = raw_fractions[internal_name]
    cell = phase.get_cell()
    phase_rows.append(
        {
            "name": display_name,
            "formula": "MnWO4" if internal_name == "MnWO4" else "WO3",
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": cif_name,
            "weight_fraction": float(value) / fraction_sum,
            "weight_fraction_esd": float(esd) / fraction_sum,
            "reference_cod_id": cod_id,
            "cell": {
                "a_A": float(cell["length_a"]),
                "b_A": float(cell["length_b"]),
                "c_A": float(cell["length_c"]),
                "alpha_deg": float(cell["angle_alpha"]),
                "beta_deg": float(cell["angle_beta"]),
                "gamma_deg": float(cell["angle_gamma"]),
                "volume_A3": float(cell["volume"]),
            },
        }
    )

x, observed, weights, calculated, background, saved_difference = [
    np.asarray(values, dtype=float) for values in histogram.data["data"][1][:6]
]
lower, upper = [float(value) for value in histogram.data["Limits"][1]]
selected = (
    (x >= lower)
    & (x <= upper)
    & np.isfinite(observed)
    & np.isfinite(calculated)
    & np.isfinite(weights)
    & (weights > 0.0)
)
difference = observed - calculated

with (root / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
    writer = csv.writer(stream)
    writer.writerow(("two_theta_deg", "observed", "calculated", "difference"))
    for values in zip(x, observed, calculated, difference):
        writer.writerow((f"{values[0]:.8f}", *(f"{value:.10g}" for value in values[1:])))

rwp = 100.0 * math.sqrt(
    float(np.sum(weights[selected] * difference[selected] ** 2))
    / float(np.sum(weights[selected] * observed[selected] ** 2))
)
rp = 100.0 * float(np.sum(np.abs(difference[selected]))) / float(
    np.sum(np.abs(observed[selected]))
)
rvals = project.data["Covariance"]["data"]["Rvals"]
gof = float(rvals["GOF"])
result = {
    "phases": phase_rows,
    "fraction_basis": "normalized over modeled crystalline phases",
    "fit_statistics": {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "rexp_percent": rwp / gof,
        "goodness_of_fit": gof,
        "chi_square": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_variables": int(rvals["Nvars"]),
        "two_theta_range_deg": [lower, upper],
        "profile_points": int(np.count_nonzero(selected)),
    },
    "project_path": "final.gpx",
    "fit_profile_path": "fit.csv",
    "unresolved_components": [],
}
(root / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")

print(json.dumps(result, indent=2))
