#!/usr/bin/env python3
"""Run one matched phase-specific broadening or March-Dollase branch."""

import argparse
import contextlib
import io
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source")
parser.add_argument("phase")
parser.add_argument("term", choices=("size", "mustrain", "md"))
parser.add_argument("output")
parser.add_argument("--axis", default="0,0,1")
parser.add_argument("--size", type=float, default=1.0)
parser.add_argument("--mustrain", type=float, default=1000.0)
parser.add_argument("--attempts", type=int, default=2)
args = parser.parse_args()

log = io.StringIO()
with contextlib.redirect_stdout(log):
    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    histogram = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][histogram.name]
    if args.term == "size":
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True, "value": args.size}}
        )
    elif args.term == "mustrain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = args.mustrain
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    else:
        axis = [int(value) for value in args.axis.split(",")]
        if len(axis) != 3 or axis == [0, 0, 0]:
            raise ValueError("--axis must contain three integers and be nonzero")
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
    project.save(args.output.replace(".gpx", "_pre.gpx"))
    for _ in range(args.attempts):
        project.refine()
        status = project.data["Covariance"]["data"]["Rvals"]
        if (
            status.get("converged")
            and not status.get("SVD0")
            and abs(float(status.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(args.output)

status = project.data["Covariance"]["data"]["Rvals"]
cov = project.data["Covariance"]["data"]
vary = cov.get("varyList", [])
matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
correlations = []
if matrix.size and matrix.shape == (len(vary), len(vary)):
    sd = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    for i in range(len(vary)):
        for j in range(i):
            if sd[i] > 0 and sd[j] > 0:
                corr = matrix[i, j] / (sd[i] * sd[j])
                if abs(corr) >= 0.65:
                    correlations.append([vary[j], vary[i], float(corr)])

hap = phase.data["Histograms"][histogram.name]
x, y, weight, calc = histogram.data["data"][1][:4]
lo, hi = histogram.data["Limits"][1]
valid = (x >= lo) & (x <= hi) & (weight > 0)
regions = []
for left, right in ((lo, 30.0), (30.0, 50.0), (50.0, 70.0), (70.0, hi + 1e-6)):
    selected = valid & (x >= left) & (x < right)
    rwp = 100.0 * np.sqrt(
        np.sum(weight[selected] * (y[selected] - calc[selected]) ** 2)
        / np.sum(weight[selected] * y[selected] ** 2)
    )
    regions.append([float(left), float(right), float(rwp)])

print(
    "HAP_RESULT="
    + json.dumps(
        {
            "phase": phase.name,
            "term": args.term,
            "rwp_percent": histogram.get_wR(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "mass_fractions": histogram.ComputeMassFracs(),
            "regional_rwp_percent": regions,
            "convergence": {
                key: status.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
            "large_correlations": correlations,
            "log_tail": log.getvalue()[-1000:],
        },
        default=str,
    ),
    flush=True,
)
