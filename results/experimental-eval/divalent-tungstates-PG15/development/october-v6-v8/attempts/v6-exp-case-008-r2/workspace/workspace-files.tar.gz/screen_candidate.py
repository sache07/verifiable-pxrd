#!/usr/bin/env python3
"""Run a matched, minimally parameterized GSAS-II phase-screening branch."""

from __future__ import annotations

import argparse
import contextlib
import io
import json
import math

from GSASII import GSASIIscriptable as G2sc


def rvals(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def compact_status(project):
    status = rvals(project)
    return {
        key: status.get(key)
        for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp")
    }


def stable(status):
    return bool(
        status.get("converged")
        and not status.get("SVD0")
        and abs(float(status.get("Max shft/sig") or 999.0)) < 0.05
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("name")
    parser.add_argument("cif")
    parser.add_argument("output")
    args = parser.parse_args()

    log = io.StringIO()
    report = {"name": args.name, "source": args.source, "cif": args.cif}
    try:
        with contextlib.redirect_stdout(log):
            project = G2sc.G2Project(args.source, newgpx=args.output)
            project.data["Controls"]["data"]["max cyc"] = 8
            project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
            histogram = project.histogram(0)
            phase = project.add_phase(
                args.cif,
                phasename=args.name,
                histograms=[histogram],
                fmthint="CIF",
            )
            hap = phase.data["Histograms"][histogram.name]
            hap["Scale"][:] = [0.03, True]
            project.save(args.output.replace(".gpx", "_pre_scale.gpx"))
            project.refine()
        report["scale_stage"] = {
            "rwp_percent": histogram.get_wR(),
            "phase_scale": list(hap["Scale"]),
            "convergence": compact_status(project),
        }

        if math.isfinite(float(hap["Scale"][0])) and hap["Scale"][0] > 0.0:
            phase.data["General"]["Cell"][0] = True
            project.save(args.output.replace(".gpx", "_pre_cell.gpx"))
            with contextlib.redirect_stdout(log):
                project.refine()
            report["cell_stage"] = {
                "rwp_percent": histogram.get_wR(),
                "phase_scale": list(hap["Scale"]),
                "cell": phase.get_cell(),
                "convergence": compact_status(project),
            }
            for _ in range(3):
                if stable(rvals(project)):
                    break
                with contextlib.redirect_stdout(log):
                    project.refine()
        project.save(args.output)
        report.update(
            final_rwp_percent=histogram.get_wR(),
            phase_scale=list(hap["Scale"]),
            cell=phase.get_cell(),
            convergence=compact_status(project),
        )
        try:
            report["mass_fractions"] = histogram.ComputeMassFracs()
        except Exception as error:
            report["mass_fraction_error"] = repr(error)
    except Exception as error:
        report["fatal_error"] = repr(error)
    report["log_tail"] = log.getvalue()[-1200:]
    print("CANDIDATE_RESULT=" + json.dumps(report, sort_keys=True, default=str), flush=True)


if __name__ == "__main__":
    main()
