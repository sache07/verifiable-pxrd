#!/usr/bin/env python3
"""Remove one retained optional refinement term and reconverge."""

import argparse
import contextlib
import io
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source")
parser.add_argument("term", choices=("polarization", "U", "W", "X", "SHL", "MD"))
parser.add_argument("output")
parser.add_argument("--phase", default="MnWO4")
parser.add_argument("--attempts", type=int, default=2)
args = parser.parse_args()

defaults = {"polarization": ("Polariz.", 0.5), "U": ("U", 2.0), "W": ("W", 5.0), "X": ("X", 0.0), "SHL": ("SH/L", 0.002)}

log = io.StringIO()
with contextlib.redirect_stdout(log):
    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    histogram = project.histogram(0)
    if args.term == "MD":
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    else:
        key, value = defaults[args.term]
        histogram.InstrumentParameters[key][1] = value
        histogram.InstrumentParameters[key][2] = False
    project.save(args.output.replace(".gpx", "_pre.gpx"))
    for _ in range(args.attempts):
        project.refine()
        status = project.data["Covariance"]["data"]["Rvals"]
        if (
            status.get("converged")
            and not status.get("SVD0")
            and abs(float(status.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(args.output)

status = project.data["Covariance"]["data"]["Rvals"]
x, y, weight, calc = histogram.data["data"][1][:4]
lo, hi = histogram.data["Limits"][1]
valid = (x >= lo) & (x <= hi) & (weight > 0)
regions = []
for left, right in ((lo, 30.0), (30.0, 50.0), (50.0, 70.0), (70.0, hi + 1e-6)):
    selected = valid & (x >= left) & (x < right)
    rwp = 100.0 * np.sqrt(
        np.sum(weight[selected] * (y[selected] - calc[selected]) ** 2)
        / np.sum(weight[selected] * y[selected] ** 2)
    )
    regions.append([float(left), float(right), float(rwp)])

print(
    "REMOVAL_RESULT="
    + json.dumps(
        {
            "term": args.term,
            "rwp_percent": histogram.get_wR(),
            "regional_rwp_percent": regions,
            "instrument": {
                key: histogram.InstrumentParameters[key]
                for key in ("Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
            },
            "mass_fractions": histogram.ComputeMassFracs(),
            "convergence": {
                key: status.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg", "Nvars")
            },
            "log_tail": log.getvalue()[-1200:],
        },
        default=str,
    ),
    flush=True,
)
