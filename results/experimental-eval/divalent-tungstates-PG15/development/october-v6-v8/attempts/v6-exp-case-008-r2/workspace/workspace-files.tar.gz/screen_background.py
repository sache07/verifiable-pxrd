#!/usr/bin/env python3
"""Compare a matched empirical-background complexity branch."""

import argparse
import contextlib
import io
import json

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("source")
parser.add_argument("coefficients", type=int)
parser.add_argument("output")
args = parser.parse_args()

log = io.StringIO()
with contextlib.redirect_stdout(log):
    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    histogram = project.histogram(0)
    histogram.set_refinements(
        {"Background": {"refine": True, "no. coeffs": args.coefficients}}
    )
    project.save(args.output.replace(".gpx", "_pre.gpx"))
    for _ in range(4):
        project.refine()
        status = project.data["Covariance"]["data"]["Rvals"]
        if (
            status.get("converged")
            and not status.get("SVD0")
            and abs(float(status.get("Max shft/sig") or 999.0)) < 0.05
        ):
            break
    project.save(args.output)

status = project.data["Covariance"]["data"]["Rvals"]
print(
    "BACKGROUND_RESULT="
    + json.dumps(
        {
            "coefficients": args.coefficients,
            "rwp_percent": histogram.get_wR(),
            "background": histogram.Background[0],
            "convergence": {
                key: status.get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg")
            },
            "mass_fractions": histogram.ComputeMassFracs(),
            "log_tail": log.getvalue()[-1000:],
        },
        default=str,
    ),
    flush=True,
)
