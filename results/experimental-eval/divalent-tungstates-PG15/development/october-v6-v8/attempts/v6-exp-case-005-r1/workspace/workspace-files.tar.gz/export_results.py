#!/usr/bin/env python3
"""Export the final GSAS-II project into the requested submission files."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"
PHASE_METADATA = {
    "WO3": {
        "phase_name": "monoclinic tungsten(VI) oxide",
        "formula": "WO3",
        "cif_path": "WO3_monoclinic.cif",
    },
    "Co3O4": {
        "phase_name": "cubic cobalt(II,III) oxide spinel",
        "formula": "Co3O4",
        "cif_path": "Co3O4_spinel.cif",
    },
}


def weighted_rwp(observed: np.ndarray, calculated: np.ndarray,
                 weights: np.ndarray, mask: np.ndarray) -> float:
    valid = (
        mask
        & np.isfinite(observed)
        & np.isfinite(calculated)
        & np.isfinite(weights)
        & (weights > 0.0)
    )
    numerator = float(np.sum(weights[valid] * (observed[valid] - calculated[valid]) ** 2))
    denominator = float(np.sum(weights[valid] * observed[valid] ** 2))
    return 100.0 * math.sqrt(numerator / denominator)


def main() -> None:
    project = G2sc.G2Project(str(PROJECT))
    histogram = project.histograms()[0]
    arrays = np.asarray(histogram.data["data"][1], dtype=float)
    two_theta, observed, weights, calculated, background, difference = arrays

    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg",
            "observed_counts",
            "calculated_counts",
            "difference_counts_observed_minus_calculated",
            "background_counts",
        ])
        writer.writerows(zip(two_theta, observed, calculated, difference, background))

    raw_fractions = histogram.ComputeMassFracs()
    total_fraction = sum(float(raw_fractions[name][0]) for name in PHASE_METADATA)
    phase_rows = []
    for phase in project.phases():
        if phase.name not in PHASE_METADATA:
            continue
        metadata = PHASE_METADATA[phase.name]
        output = ROOT / metadata["cif_path"]
        phase.export_CIF(str(output))
        fraction, esd = raw_fractions[phase.name]
        cell = phase.get_cell()
        phase_rows.append({
            "name": metadata["phase_name"],
            "project_phase_name": phase.name,
            "formula": metadata["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": metadata["cif_path"],
            "weight_fraction": float(fraction) / total_fraction,
            "weight_fraction_esd": float(esd),
            "weight_fraction_formal_esd": float(esd),
            "estimated_absolute_weight_fraction_uncertainty": 0.01,
            "cell": {
                "a_angstrom": float(cell["length_a"]),
                "b_angstrom": float(cell["length_b"]),
                "c_angstrom": float(cell["length_c"]),
                "alpha_deg": float(cell["angle_alpha"]),
                "beta_deg": float(cell["angle_beta"]),
                "gamma_deg": float(cell["angle_gamma"]),
                "volume_angstrom3": float(cell["volume"]),
            },
        })

    refinement_limits = [float(v) for v in histogram.data["Limits"][1]]
    fit_mask = (two_theta >= refinement_limits[0]) & (two_theta <= refinement_limits[1])
    full_mask = np.ones_like(two_theta, dtype=bool)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    residuals = histogram.residuals
    result = {
        "phases": phase_rows,
        "fraction_basis": "normalized over the modeled crystalline phases only",
        "fraction_uncertainty_note": (
            "Formal covariance e.s.d.s are reported per phase; an absolute "
            "uncertainty of about 0.01 (one weight-percent point) is more "
            "realistic because no calibrated instrument profile or measured "
            "ADPs were supplied."
        ),
        "unresolved_components": [],
        "fit_statistics": {
            "rwp_percent_refinement": float(rvals["Rwp"]),
            "rwp_percent_recomputed_refinement_range": weighted_rwp(
                observed, calculated, weights, fit_mask
            ),
            "rwp_percent_exported_full_grid": weighted_rwp(
                observed, calculated, weights, full_mask
            ),
            "rp_percent": float(residuals["R"]),
            "rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "observations": int(rvals["Nobs"]),
            "refined_variables": int(rvals["Nvars"]),
            "refinement_range_two_theta_deg": refinement_limits,
            "exported_range_two_theta_deg": [float(two_theta[0]), float(two_theta[-1])],
            "exported_points": int(two_theta.size),
            "converged": bool(rvals["converged"]),
            "svd_dropped_variables": int(rvals["SVD0"]),
            "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
            "weighting": "Poisson weights derived from raw counts (1/I)",
        },
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
