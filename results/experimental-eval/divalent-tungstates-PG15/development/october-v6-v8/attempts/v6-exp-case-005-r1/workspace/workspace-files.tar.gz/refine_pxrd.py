#!/usr/bin/env python3
"""Build and inspect staged GSAS-II refinements for the supplied PXRD data."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
IPARAMS = ROOT / "lab_cuka.instprm"
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
CIFS = {
    "wo3_mono": COD_ROOT / "2/31/10/2311041.cif",
    "wo3_tri": COD_ROOT / "2/10/62/2106293.cif",
    "co3o4": COD_ROOT / "9/00/58/9005896.cif",
    "cowo4": ROOT / "candidates" / "CoWO4_wolframite_from_FeWO4.cif",
}


def convergence(project: G2sc.G2Project) -> dict:
    values = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        key: values.get(key)
        for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp", "GOF")
    }


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    result = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "convergence": convergence(project),
        "instrument": {
            key: value
            for key, value in hist.InstrumentParameters.items()
            if key in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.",
                       "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            key: value
            for key, value in hist.SampleParameters.items()
            if key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB",
                       "Gonio. radius")
        },
        "phases": [],
    }
    try:
        result["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap.get("Scale"),
                "size": hap.get("Size"),
                "mustrain": hap.get("Mustrain"),
                "pref_ori": hap.get("Pref.Ori."),
            }
        )
    return result


def print_snapshot(project: G2sc.G2Project, label: str) -> None:
    print("SNAPSHOT=" + json.dumps(snapshot(project, label), default=str, sort_keys=True))


def stable_refine(project: G2sc.G2Project, label: str, cycles: int = 8) -> bool:
    project.set_Controls("cycles", 8)
    valid = False
    for attempt in range(cycles):
        try:
            project.refine()
        except Exception as exc:
            print(f"REFINE_ERROR label={label} attempt={attempt + 1} error={exc!r}")
            break
        state = convergence(project)
        print_snapshot(project, f"{label}-{attempt + 1}")
        message = str(state.get("msg") or "").lower()
        if state.get("SVD0", 0) or state.get("Aborted") or "dropped" in message:
            break
        if state.get("converged") and float(state.get("Max shft/sig") or 0.0) < 0.05:
            valid = True
            break
    return valid


def freeze_all(project: G2sc.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) == 2:
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.data["Atoms"]:
            atom[2] = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        if "Pref.Ori." in hap:
            hap["Pref.Ori."][2] = False
        for key in ("Size", "Mustrain"):
            if key in hap:
                hap[key][2] = [False] * len(hap[key][2])
        if "HStrain" in hap:
            hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        if "Extinction" in hap:
            hap["Extinction"][1] = False
        for value in hap.get("Babinet", {}).values():
            value[1] = False


def configure_start(project: G2sc.G2Project) -> None:
    hist = project.histograms()[0]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [3100.0] + [0.0] * 9,
                "refine": False,
            },
        }
    )
    # The peak list shows a large cos(theta)-dependent positive displacement.
    # Seed it but hold it fixed until the requested angular branch comparison.
    hist.SampleParameters["Shift"][:] = [-620.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"][1] = False
    # Use neutral starting scales; both are refined in the first stage.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][:] = [1.0, False]
        phase.data["General"]["Cell"][0] = False


def build(path: Path, wo3_key: str, include_co3o4: bool = True) -> G2sc.G2Project:
    path.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(path))
    hist = project.add_powder_histogram(
        str(PATTERN), str(IPARAMS), fmthint="comma"
    )
    project.add_phase(
        str(CIFS[wo3_key]), phasename="WO3", histograms=[hist], fmthint="CIF"
    )
    if include_co3o4:
        project.add_phase(
            str(CIFS["co3o4"]), phasename="Co3O4", histograms=[hist], fmthint="CIF"
        )
    configure_start(project)
    project.save()
    return project


def initial_refinement(path: Path, wo3_key: str, include_co3o4: bool = True) -> None:
    project = build(path, wo3_key, include_co3o4)
    hist = project.histograms()[0]
    print_snapshot(project, "built")

    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    stable_refine(project, "background-scales")
    project.save()

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    stable_refine(project, "cells")
    project.save()
    print_snapshot(project, "initial-final")


def run_branch(source: Path, destination: Path, mode: str, phase_name: str | None) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    hist = project.histograms()[0]
    project.save()

    refined_in_branch = False
    if mode.startswith("inst-"):
        name = mode.removeprefix("inst-")
        if name not in hist.InstrumentParameters:
            raise ValueError(f"unknown instrument parameter {name}")
        hist.InstrumentParameters[name][2] = True
    elif mode == "polarization":
        hist.InstrumentParameters["Polariz."][2] = True
    elif mode == "surface-roughness":
        hist.SampleParameters["SurfRoughA"][:] = [0.1, True]
        hist.SampleParameters["SurfRoughB"][:] = [0.1, True]
    elif mode in ("size", "mustrain"):
        if phase_name is None:
            raise ValueError("--phase is required for size/mustrain")
        phase = project.phase(phase_name)
        if mode == "size":
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 1.0, "refine": True}},
                [hist],
            )
        else:
            hap = phase.data["Histograms"][hist.name]["Mustrain"]
            hap[0] = "isotropic"
            hap[1][0] = 1000.0
            hap[2][0] = True
    elif mode.startswith("texture-"):
        if phase_name is None:
            raise ValueError("--phase is required for texture")
        axis = [int(v) for v in mode.removeprefix("texture-").split(",")]
        if len(axis) != 3:
            raise ValueError("texture axis must be h,k,l")
        hap = project.phase(phase_name).data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
    elif mode in ("coordinates", "coordinates-uiso"):
        if phase_name is None:
            raise ValueError("--phase is required for coordinate refinement")
        project.phase(phase_name).set_refinements(
            {"Atoms": {"all": "XU" if mode.endswith("uiso") else "X"}}
        )
    elif mode == "add-cowo4":
        phase = project.add_phase(
            str(CIFS["cowo4"]), phasename="CoWO4", histograms=[hist],
            fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][:] = [0.1, True]
        phase.data["General"]["Cell"][0] = False
        stable_refine(project, "add-cowo4-scale")
        if hap["Scale"][0] > 0:
            phase.data["General"]["Cell"][0] = True
            stable_refine(project, "add-cowo4-cell")
        refined_in_branch = True
    elif mode == "disable-phase":
        if phase_name is None:
            raise ValueError("--phase is required for disable-phase")
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = False
        hap["Scale"][1] = False
        phase.data["General"]["Cell"][0] = False
    elif mode.startswith("ablate-"):
        term = mode.removeprefix("ablate-")
        if term in ("X", "W", "polarization"):
            name = "Polariz." if term == "polarization" else term
            defaults = {"X": 0.0, "W": 25.0, "Polariz.": 0.5}
            hist.InstrumentParameters[name][1] = defaults[name]
            hist.InstrumentParameters[name][2] = False
        elif term == "mustrain":
            if phase_name is None:
                raise ValueError("--phase is required for ablate-mustrain")
            hap = project.phase(phase_name).data["Histograms"][hist.name]
            hap["Mustrain"][1][0] = 1000.0
            hap["Mustrain"][2][0] = False
        else:
            raise ValueError(f"unknown ablation term {term}")
    elif mode == "reconverge":
        pass
    elif mode.startswith("set-uiso-"):
        if phase_name is None:
            raise ValueError("--phase is required for set-uiso")
        value = float(mode.removeprefix("set-uiso-"))
        if value <= 0:
            raise ValueError("Uiso must be positive")
        phase = project.phase(phase_name)
        for atom in phase.data["Atoms"]:
            atom[9] = "I"
            atom[10] = value
            atom[2] = atom[2].replace("U", "")
    elif mode == "set-wo3-adps":
        if phase_name is None:
            raise ValueError("--phase is required for set-wo3-adps")
        phase = project.phase(phase_name)
        fixed_values = {"W": 0.003, "O": 0.008}
        for atom in phase.data["Atoms"]:
            atom[9] = "I"
            atom[10] = fixed_values[atom[1].split("+")[0].split("-")[0]]
            atom[2] = atom[2].replace("U", "")
    else:
        raise ValueError(f"unknown branch mode {mode}")

    if not refined_in_branch:
        stable_refine(project, mode)
    project.save()
    print_snapshot(project, "branch-final")


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    build_parser = sub.add_parser("initial")
    build_parser.add_argument("output", type=Path)
    build_parser.add_argument("--wo3", choices=("wo3_mono", "wo3_tri"), default="wo3_mono")
    build_parser.add_argument("--without-co3o4", action="store_true")
    branch_parser = sub.add_parser("branch")
    branch_parser.add_argument("source", type=Path)
    branch_parser.add_argument("output", type=Path)
    branch_parser.add_argument("mode")
    branch_parser.add_argument("--phase")
    inspect_parser = sub.add_parser("inspect")
    inspect_parser.add_argument("project", type=Path)
    args = parser.parse_args()
    if args.command == "initial":
        initial_refinement(
            args.output.resolve(), args.wo3, include_co3o4=not args.without_co3o4
        )
    elif args.command == "branch":
        run_branch(
            args.source.resolve(), args.output.resolve(), args.mode, args.phase
        )
    elif args.command == "inspect":
        print_snapshot(G2sc.G2Project(str(args.project.resolve())), "inspect")


if __name__ == "__main__":
    main()
