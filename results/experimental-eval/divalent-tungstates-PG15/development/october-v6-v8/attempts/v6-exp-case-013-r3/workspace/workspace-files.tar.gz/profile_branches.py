#!/usr/bin/env python3
"""Matched minimal global-profile branches for a GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def freeze_nuisance(project: G2sc.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.data["Histograms"][hist.name]["Scale"][1] = False
    for item in hist.InstrumentParameters.values():
        if isinstance(item, list) and len(item) >= 3:
            item[2] = False


def restore_nuisance(project: G2sc.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def state(project: G2sc.G2Project, branch: str) -> dict:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "branch": branch,
        "rwp": hist.get_wR(),
        "profile": {
            key: hist.InstrumentParameters[key]
            for key in ("U", "V", "W", "X", "Y", "Z")
        },
        "covariance": {
            key: cov.get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp", "GOF")
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("terms", nargs="*", choices=["U", "V", "W", "X", "Y", "Z"])
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source), filename=str(args.output))
    hist = project.histograms()[0]
    freeze_nuisance(project)
    for term in args.terms:
        hist.InstrumentParameters[term][2] = True
    project.set_Controls("cycles", 8)
    project.save()
    project.refine()
    isolated = state(project, "isolated")

    restore_nuisance(project)
    for term in args.terms:
        hist.InstrumentParameters[term][2] = True
    project.set_Controls("cycles", 4)
    project.refine()
    project.save(str(args.output))
    print("PROFILE_BRANCH_RESULT=" + json.dumps({"isolated": isolated, "full": state(project, "full")}, default=str))


if __name__ == "__main__":
    main()
