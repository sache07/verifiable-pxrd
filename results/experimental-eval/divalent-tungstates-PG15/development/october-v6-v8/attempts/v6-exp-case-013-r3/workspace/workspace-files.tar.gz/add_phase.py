#!/usr/bin/env python3
"""Matched atomistic phase-addition branch for a GSAS-II project."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


def freeze_all(project: G2sc.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]


def refine(project: G2sc.G2Project, label: str) -> dict:
    project.save()
    project.refine()
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "label": label,
        "rwp": project.histograms()[0].get_wR(),
        "converged": cov.get("converged"),
        "max_shift_over_esd": cov.get("Max shft/sig"),
        "svd_dropped": cov.get("SVD0"),
        "message": cov.get("msg"),
    }
    print("ADDITION_STAGE=" + json.dumps(result))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("phase_name")
    parser.add_argument("--scale", type=float, default=0.2)
    parser.add_argument("--cell-scale", type=float, default=1.0)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    hist = project.histograms()[0]
    freeze_all(project)
    phase = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.phase_name,
        histograms=[hist],
        fmthint="CIF",
    )
    if not math.isclose(args.cell_scale, 1.0):
        cell = phase.data["General"]["Cell"]
        cell[1:4] = [float(value) * args.cell_scale for value in cell[1:4]]
        cell[7] = G2lat.calc_V(G2lat.cell2A(cell[1:7]))
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][0] = args.scale
    hap["Scale"][1] = True
    phase.data["General"]["Cell"][0] = False

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1e-8
    controls["shift factor"] = 0.5
    refine(project, "new-scale")

    phase.data["General"]["Cell"][0] = True
    refine(project, "new-cell-scale")

    for item in project.phases():
        item.data["Histograms"][hist.name]["Scale"][1] = True
    refine(project, "all-scales-new-cell")
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:
        fractions = {"error": repr(exc)}
    print(
        "ADDITION_RESULT="
        + json.dumps(
            {
                "rwp": hist.get_wR(),
                "fractions": fractions,
                "new_scale": hap["Scale"],
                "cell": phase.get_cell(),
                "composition": phase.composition,
            },
            default=str,
        )
    )


if __name__ == "__main__":
    main()
