#!/usr/bin/env python3
"""Matched removal test for retained W or massicot microstrain."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("term", choices=["W", "massicot-strain"])
    args = parser.parse_args()
    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for key, value in hist.InstrumentParameters.items():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = key == "W"
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        if phase.name == "PbO_massicot":
            hap["Mustrain"][2][0] = True
    if args.term == "W":
        hist.InstrumentParameters["W"][1] = hist.InstrumentParameters["W"][0]
        hist.InstrumentParameters["W"][2] = False
    else:
        hap = project.phase("PbO_massicot").data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2][0] = False
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1e-8
    controls["shift factor"] = 0.5
    project.save()
    history = []
    for attempt in range(1, 8):
        project.refine()
        project.save()
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        history.append(
            {
                "attempt": attempt,
                "rwp": hist.get_wR(),
                "converged": rvals.get("converged"),
                "max_shift_over_esd": rvals.get("Max shft/sig"),
                "svd_dropped": rvals.get("SVD0"),
                "message": rvals.get("msg"),
            }
        )
        if (
            rvals.get("converged")
            and abs(float(rvals.get("Max shft/sig") or 999.0)) < 0.05
            and not rvals.get("SVD0")
            and not rvals.get("msg")
        ):
            break
    print(
        "LEAVEOUT_RESULT="
        + json.dumps(
            {
                "removed": args.term,
                "history": history,
                "W": hist.InstrumentParameters["W"],
                "massicot_strain": project.phase("PbO_massicot")
                .data["Histograms"][hist.name]["Mustrain"],
                "fractions": hist.ComputeMassFracs(),
            },
            default=str,
        )
    )


if __name__ == "__main__":
    main()
