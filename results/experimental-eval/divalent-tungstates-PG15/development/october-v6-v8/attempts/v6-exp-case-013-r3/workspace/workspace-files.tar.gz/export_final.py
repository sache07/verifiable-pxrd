#!/usr/bin/env python3
"""Freeze the selected project and create the machine-readable deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from learned.profile_regeneration import regenerate_profile


SOURCE = Path("angular-fourphase-final.gpx")
FINAL = Path("final.gpx")

PHASE_INFO = {
    "PbWO4_scheelite": {
        "display_name": "PbWO4 (scheelite)",
        "formula": "PbWO4",
        "space_group": "I41/a",
        "space_group_number": 88,
        "cif_path": "phase_1_PbWO4_scheelite.cif",
    },
    "WO3_gamma": {
        "display_name": "gamma-WO3",
        "formula": "WO3",
        "space_group": "P-1",
        "space_group_number": 2,
        "cif_path": "phase_2_WO3_gamma.cif",
    },
    "PbO_massicot": {
        "display_name": "PbO (massicot)",
        "formula": "PbO",
        "space_group": "Pbcm",
        "space_group_number": 57,
        "cif_path": "phase_3_PbO_massicot.cif",
    },
    "PbO_litharge": {
        "display_name": "PbO (litharge)",
        "formula": "PbO",
        "space_group": "P4/nmm",
        "space_group_number": 129,
        "cif_path": "phase_4_PbO_litharge.cif",
    },
}


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    project.save()
    regenerate_profile(FINAL.resolve())
    project = G2sc.G2Project(str(FINAL))
    histogram = project.histograms()[0]

    fractions = histogram.ComputeMassFracs()
    phase_rows = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(info["cif_path"])
        fraction, esd = fractions[phase.name]
        cell = phase.get_cell()
        phase_rows.append(
            {
                "name": info["display_name"],
                "project_phase_name": phase.name,
                "formula": info["formula"],
                "space_group": info["space_group"],
                "space_group_number": info["space_group_number"],
                "cif_path": info["cif_path"],
                "weight_fraction": float(fraction),
                "weight_fraction_formal_esd": float(esd),
                "cell": {key: float(value) for key, value in cell.items()},
            }
        )

    arrays = histogram.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    observed = np.asarray(arrays[1], dtype=float)
    weights = np.asarray(arrays[2], dtype=float)
    calculated = np.asarray(arrays[3], dtype=float)
    background = np.asarray(arrays[4], dtype=float)
    difference = observed - calculated
    lower, upper = histogram.data["Limits"][1]
    fit_mask = (x >= lower) & (x <= upper)
    rp = 100.0 * np.sum(np.abs(difference[fit_mask])) / np.sum(
        np.abs(observed[fit_mask])
    )
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    rwp = float(histogram.get_wR())
    gof = float(rvals.get("GOF"))
    rexp = rwp / gof

    with Path("fit.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        writer.writerows(
            zip(x, observed, calculated, difference, background, strict=True)
        )

    result = {
        "phases": phase_rows,
        "fraction_basis": (
            "Normalized over the four atomistically modeled crystalline phases; "
            "the unresolved crystalline residual and any amorphous content are excluded."
        ),
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": float(rp),
            "rexp_percent": float(rexp),
            "goodness_of_fit": gof,
            "chi_square": float(rvals.get("chisq")),
            "n_observations": int(rvals.get("Nobs")),
            "n_refined_variables": int(rvals.get("Nvars")),
            "converged": bool(rvals.get("converged")),
            "svd_dropped_variables": int(rvals.get("SVD0") or 0),
            "maximum_shift_over_esd": float(rvals.get("Max shft/sig")),
            "two_theta_range_deg": [float(lower), float(upper)],
        },
        "profile_file": "fit.csv",
        "gsasii_project": "final.gpx",
        "unresolved_components": [
            {
                "description": "Coherent weak crystalline residual family",
                "representative_two_theta_deg": [
                    25.907,
                    26.776,
                    27.950,
                    30.178,
                    31.036,
                    33.524,
                    46.369,
                    48.444,
                    54.747,
                ],
                "status": (
                    "No tested atomistic model passed simultaneous geometry, "
                    "multi-region, and absent-peak checks; no fraction is assigned."
                ),
            }
        ],
    }
    Path("result.json").write_text(
        json.dumps(result, indent=2, sort_keys=False) + "\n", encoding="utf-8"
    )
    print(json.dumps(result["fit_statistics"], indent=2))
    print("fraction_sum", sum(row["weight_fraction"] for row in phase_rows))


if __name__ == "__main__":
    main()
