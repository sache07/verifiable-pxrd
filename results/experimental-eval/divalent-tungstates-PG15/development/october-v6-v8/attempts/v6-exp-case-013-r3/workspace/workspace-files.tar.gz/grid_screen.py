#!/usr/bin/env python3
"""Screen a CIF addition over an isotropic lattice-scale grid without LS steps."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat

from learned.profile_regeneration import regenerate_profile


def arrays(path: Path):
    project = G2sc.G2Project(str(path))
    histogram = project.histograms()[0]
    data = histogram.data["data"][1]
    return (
        np.asarray(data[0], dtype=float),
        np.asarray(data[1], dtype=float),
        np.asarray(data[2], dtype=float),
        np.asarray(data[3], dtype=float),
        list(histogram.data["Limits"][1]),
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("phase_name")
    parser.add_argument("--minimum", type=float, default=0.97)
    parser.add_argument("--maximum", type=float, default=1.06)
    parser.add_argument("--steps", type=int, default=37)
    parser.add_argument("--work", type=Path, default=Path(".tmp/grid-screen.gpx"))
    args = parser.parse_args()

    base_path = args.work.with_name(args.work.stem + "-base.gpx")
    base = G2sc.G2Project(str(args.source), newgpx=str(base_path))
    base.save()
    regenerate_profile(base_path)
    x, observed, weight, base_calc, limits = arrays(base_path)
    mask = (x >= limits[0]) & (x <= limits[1])
    residual = observed - base_calc
    denominator_observed = np.sum(weight[mask] * observed[mask] ** 2)
    base_ss = np.sum(weight[mask] * residual[mask] ** 2)

    rows = []
    for cell_scale in np.linspace(args.minimum, args.maximum, args.steps):
        project = G2sc.G2Project(str(base_path), newgpx=str(args.work))
        histogram = project.histograms()[0]
        phase = project.add_phase(
            str(args.cif.resolve()),
            phasename=args.phase_name,
            histograms=[histogram],
            fmthint="CIF",
        )
        cell = phase.data["General"]["Cell"]
        cell[1:4] = [float(value) * cell_scale for value in cell[1:4]]
        cell[7] = G2lat.calc_V(G2lat.cell2A(cell[1:7]))
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][0] = 1.0
        hap["Scale"][1] = False
        project.save()
        regenerate_profile(args.work)
        _, _, _, trial_calc, _ = arrays(args.work)
        contribution = trial_calc - base_calc
        normal = np.sum(weight[mask] * contribution[mask] ** 2)
        cross = np.sum(weight[mask] * residual[mask] * contribution[mask])
        optimum_scale = max(0.0, float(cross / normal)) if normal > 0 else 0.0
        trial_residual = residual - optimum_scale * contribution
        trial_ss = np.sum(weight[mask] * trial_residual[mask] ** 2)
        rows.append(
            {
                "cell_scale": float(cell_scale),
                "phase_scale": optimum_scale,
                "estimated_rwp": float(100.0 * np.sqrt(trial_ss / denominator_observed)),
                "weighted_ss_improvement_fraction": float((base_ss - trial_ss) / base_ss),
            }
        )
    rows.sort(key=lambda row: row["estimated_rwp"])
    print(
        "GRID_SCREEN_RESULT="
        + json.dumps(
            {
                "source": str(args.source),
                "candidate": str(args.cif),
                "base_rwp_recomputed": float(
                    100.0 * np.sqrt(base_ss / denominator_observed)
                ),
                "best": rows[0],
                "top": rows[:10],
            }
        )
    )


if __name__ == "__main__":
    main()
