#!/usr/bin/env python3
"""Index a conservative list of residual-peak centroids with GSAS-II."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIindex as G2index


# Peaks with sizeable positive residuals and no strong calculated reflection
# within approximately one fitted FWHM. Positions are from the selected mature
# three-phase model, not from the raw-pattern peak list.
POSITIONS = [
    25.918,
    27.428,
    29.341,
    30.156,
    30.623,
    31.036,
    33.524,
    34.839,
    38.121,
    39.544,
    39.957,
    41.913,
    43.413,
    46.369,
    50.998,
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("bravais", type=int, help="GSAS-II Bravais index (0--17)")
    parser.add_argument(
        "--positions",
        type=float,
        nargs="+",
        default=POSITIONS,
        help="residual-peak positions in degrees 2theta",
    )
    parser.add_argument("--volume", type=float, default=100.0)
    parser.add_argument("--timeout", type=float, default=60.0)
    args = parser.parse_args()

    project = G2sc.G2Project(args.project)
    hist = project.histograms()[0]
    inst = hist.InstrumentParameters
    arrays = hist.data["data"][1]
    x, y, _, calc = arrays[:4]
    peaks = []
    for position in args.positions:
        index = min(range(len(x)), key=lambda i: abs(x[i] - position))
        intensity = max(1.0, float(y[index] - calc[index]))
        dspace = float(G2lat.Pos2dsp(inst, position))
        peaks.append([position, intensity, True, False, 0, 0, 0, dspace, 0.0])

    controls = [False, 0.0, 4, args.volume, 0, "P1", 1.0, 1.0, 1.0, 90.0, 90.0, 90.0, 1.0, "P 1"]
    bravais = [False] * 18
    bravais[args.bravais] = True
    ok, dmin, cells = G2index.DoIndexPeaks(
        peaks,
        controls,
        bravais,
        None,
        ifX20=True,
        timeout=args.timeout,
        M20_min=2.0,
        return_Nc=True,
    )
    print("RESIDUAL_INDEX_RESULT=" + json.dumps({"ok": ok, "dmin": dmin, "cells": cells}))


if __name__ == "__main__":
    main()
