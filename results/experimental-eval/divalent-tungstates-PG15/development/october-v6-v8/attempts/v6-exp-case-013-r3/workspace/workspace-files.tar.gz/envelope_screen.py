#!/usr/bin/env python3
"""One-parameter polarization or surface-roughness screen."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("term", choices=["polarization", "surface-roughness"])
    args = parser.parse_args()
    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    if args.term == "polarization":
        hist.InstrumentParameters["Polariz."][2] = True
    else:
        hist.SampleParameters["SurfRoughA"] = [0.001, True]
        hist.SampleParameters["SurfRoughB"] = [0.0, False]
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1e-8
    controls["shift factor"] = 0.5
    project.save()
    project.refine()
    project.save()
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(
        "ENVELOPE_SCREEN_RESULT="
        + json.dumps(
            {
                "term": args.term,
                "rwp": hist.get_wR(),
                "polarization": hist.InstrumentParameters.get("Polariz."),
                "surface_roughness_a": hist.SampleParameters.get("SurfRoughA"),
                "surface_roughness_b": hist.SampleParameters.get("SurfRoughB"),
                "converged": rvals.get("converged"),
                "max_shift_over_esd": rvals.get("Max shft/sig"),
                "svd_dropped": rvals.get("SVD0"),
                "message": rvals.get("msg"),
            },
            default=str,
        )
    )


if __name__ == "__main__":
    main()
