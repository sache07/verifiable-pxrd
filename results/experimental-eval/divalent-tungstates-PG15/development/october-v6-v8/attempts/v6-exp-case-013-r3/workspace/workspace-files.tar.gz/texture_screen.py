#!/usr/bin/env python3
"""Screen simple March--Dollase axes with all other terms fixed.

The script deliberately performs the one-parameter screen only. Promising
axes are subsequently reconverged with the common nuisance model in a
separate project.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def freeze(project: G2sc.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("axis", nargs=3, type=int)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    freeze(project)
    hist = project.histograms()[0]
    phase = project.phase(args.phase)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = list(args.axis)
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1e-8
    controls["shift factor"] = 0.5
    project.save()
    project.refine()
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "phase": phase.name,
        "axis": args.axis,
        "ratio": pref[1],
        "rwp": hist.get_wR(),
        "converged": cov.get("converged"),
        "max_shift_over_esd": cov.get("Max shft/sig"),
        "svd_dropped": cov.get("SVD0"),
        "message": cov.get("msg"),
    }
    print("TEXTURE_SCREEN_RESULT=" + json.dumps(result))


if __name__ == "__main__":
    main()
