#!/usr/bin/env python3
"""Reconverge an added phase cell/scale, then all scales with nuisance fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def status(project: G2sc.G2Project, label: str) -> dict:
    values = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "label": label,
        "rwp": project.histograms()[0].get_wR(),
        "converged": values.get("converged"),
        "max_shift_over_esd": values.get("Max shft/sig"),
        "svd_dropped": values.get("SVD0"),
        "message": values.get("msg"),
    }


def acceptable(row: dict) -> bool:
    return (
        row["converged"]
        and abs(float(row["max_shift_over_esd"] or 999.0)) < 0.05
        and not row["svd_dropped"]
        and not row["message"]
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    args = parser.parse_args()
    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = phase.name == args.phase
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = phase.name == args.phase
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1e-8
    controls["shift factor"] = 0.2
    project.save()
    history = []
    for attempt in range(1, 6):
        project.refine()
        project.save()
        row = status(project, f"cell-scale-{attempt}")
        history.append(row)
        if acceptable(row):
            break
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    for attempt in range(1, 6):
        project.refine()
        project.save()
        row = status(project, f"all-scales-{attempt}")
        history.append(row)
        if acceptable(row):
            break
    phase = project.phase(args.phase)
    print(
        "STABILIZED_ADDITION_RESULT="
        + json.dumps(
            {
                "history": history,
                "fractions": hist.ComputeMassFracs(),
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"],
            },
            default=str,
        )
    )


if __name__ == "__main__":
    main()
