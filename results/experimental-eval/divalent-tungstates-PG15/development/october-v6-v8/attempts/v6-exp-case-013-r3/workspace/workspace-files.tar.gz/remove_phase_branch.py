#!/usr/bin/env python3
"""Matched leave-one-phase-out branch for a GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from replace_phase import freeze_all, remove_phase


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    args = parser.parse_args()
    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    freeze_all(project)
    remove_phase(project, args.phase)
    hist = project.histograms()[0]
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1e-8
    controls["shift factor"] = 0.5
    project.save()
    history = []
    for attempt in range(1, 8):
        project.refine()
        project.save()
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        history.append(
            {
                "attempt": attempt,
                "rwp": hist.get_wR(),
                "converged": rvals.get("converged"),
                "max_shift_over_esd": rvals.get("Max shft/sig"),
                "svd_dropped": rvals.get("SVD0"),
                "message": rvals.get("msg"),
            }
        )
        if (
            rvals.get("converged")
            and abs(float(rvals.get("Max shft/sig") or 999.0)) < 0.05
            and not rvals.get("SVD0")
            and not rvals.get("msg")
        ):
            break
    print(
        "PHASE_LEAVEOUT_RESULT="
        + json.dumps(
            {
                "removed": args.phase,
                "history": history,
                "fractions": hist.ComputeMassFracs(),
            },
            default=str,
        )
    )


if __name__ == "__main__":
    main()
