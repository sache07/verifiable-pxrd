#!/usr/bin/env python3
"""Matched atomistic phase-replacement branch for a GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def remove_phase(project: G2sc.G2Project, name: str) -> None:
    for hist in project.histograms():
        hist.data.get("Reflection Lists", {}).pop(name, None)
    project.data["Phases"].pop(name)
    for entry in project.names:
        if entry and entry[0] == "Phases" and name in entry:
            entry.remove(name)
    project.update_ids()


def freeze_all(project: G2sc.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]


def refine(project: G2sc.G2Project, label: str) -> dict:
    project.save()
    project.refine()
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "label": label,
        "rwp": project.histograms()[0].get_wR(),
        "converged": cov.get("converged"),
        "max_shift_over_esd": cov.get("Max shft/sig"),
        "svd_dropped": cov.get("SVD0"),
        "message": cov.get("msg"),
    }
    print("REPLACEMENT_STAGE=" + json.dumps(result))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("old_phase")
    parser.add_argument("cif", type=Path)
    parser.add_argument("new_phase")
    parser.add_argument("--scale", type=float, default=1.0)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    hist = project.histograms()[0]
    freeze_all(project)
    remove_phase(project, args.old_phase)
    phase = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.new_phase,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][0] = args.scale
    hap["Scale"][1] = True
    phase.data["General"]["Cell"][0] = False

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1e-8
    controls["shift factor"] = 0.5
    refine(project, "new-scale")

    phase.data["General"]["Cell"][0] = True
    refine(project, "new-cell-scale")

    for item in project.phases():
        item.data["Histograms"][hist.name]["Scale"][1] = True
    refine(project, "all-scales-new-cell")
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:
        fractions = {"error": repr(exc)}
    print(
        "REPLACEMENT_RESULT="
        + json.dumps(
            {
                "rwp": hist.get_wR(),
                "fractions": fractions,
                "new_scale": hap["Scale"],
                "cell": phase.get_cell(),
                "composition": phase.composition,
            },
            default=str,
        )
    )


if __name__ == "__main__":
    main()
