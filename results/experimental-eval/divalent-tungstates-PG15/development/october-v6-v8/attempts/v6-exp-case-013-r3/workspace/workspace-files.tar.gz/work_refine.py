#!/usr/bin/env python3
"""Working GSAS-II refinement driver for the supplied Pb-W-O powder pattern.

This is an analysis helper, not a submission artifact. It creates reproducible
screening branches with identical nuisance models so phase inventories can be
compared on a matched basis.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

CANDIDATES = {
    "scheelite": ("9009811", "PbWO4_scheelite"),
    "defect": ("9016035", "Pb7W8O28p8_defect_scheelite"),
    "raspite": ("9007617", "PbWO4_raspite"),
    "pbo": ("local-pbo", "PbO_litharge"),
    "wo3": ("2106293", "WO3_gamma"),
    "wo3mono": ("local-wo3mono", "WO3_monoclinic_smallcell"),
    "massicot": ("2310433", "PbO_massicot"),
}


def cif_path(cod_id: str) -> Path:
    if cod_id == "local-pbo":
        return Path("candidates/PbO_litharge_standard.cif").resolve()
    if cod_id == "local-wo3mono":
        return Path("candidates/WO3_monoclinic_1563541_standard.cif").resolve()
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def covariance(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, label: str, attempts: int = 5) -> bool:
    """Refine repeatedly until converged or a numerical warning is encountered."""
    for attempt in range(1, attempts + 1):
        try:
            project.refine()
        except Exception as exc:
            print(f"STAGE {label} attempt={attempt} error={exc!r}")
            return False
        status = covariance(project)
        rwp = project.histograms()[0].get_wR()
        rwp_text = "None" if rwp is None else f"{rwp:.6f}"
        print(
            f"STAGE {label} attempt={attempt} Rwp={rwp_text} "
            f"converged={status.get('converged')} shift={status.get('Max shft/sig')} "
            f"SVD0={status.get('SVD0')} msg={status.get('msg')!r}"
        )
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in message or "error" in message:
            return False
        shift = float(status.get("Max shft/sig") or math.inf)
        if status.get("converged") and shift < 0.05:
            return True
    return False


def set_cell(phase, cell: list[float]) -> None:
    phase.data["General"]["Cell"][1:7] = list(cell)
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def apply_starting_cells(project: G2sc.G2Project) -> None:
    starts = {
        "PbWO4_scheelite": [5.414, 5.414, 12.165, 90.0, 90.0, 90.0],
        "Pb7W8O28p8_defect_scheelite": [7.656, 7.656, 12.165, 90.0, 90.0, 90.0],
        "WO3_gamma": [7.236, 7.447, 7.600, 88.81, 90.92, 90.93],
        "WO3_monoclinic_smallcell": [5.21, 5.08, 7.58, 90.0, 92.05, 90.0],
        "PbO_litharge": [3.94, 3.94, 4.98, 90.0, 90.0, 90.0],
        "PbO_massicot": [5.82, 5.42, 4.70, 90.0, 90.0, 90.0],
    }
    for phase in project.phases():
        if phase.name in starts:
            set_cell(phase, starts[phase.name])


def initialize_background(histogram, terms: int = 15) -> None:
    arrays = histogram.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    y = np.asarray(arrays[1], dtype=float)
    step = float(np.median(np.diff(x)))
    window = max(5, int(round(2.5 / step)))
    if window % 2 == 0:
        window += 1
    baseline = percentile_filter(y, percentile=15, size=window, mode="nearest")
    baseline = gaussian_filter1d(baseline, sigma=max(2.0, 0.20 / step))
    transformed = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    coefficients = np.polynomial.chebyshev.chebfit(transformed, baseline, terms - 1)
    histogram.data["Background"][0] = [
        "chebyschev-1",
        False,
        terms,
        *[float(value) for value in coefficients],
    ]


def summarize(project: G2sc.G2Project, tag: str) -> dict:
    hist = project.histograms()[0]
    result = {
        "tag": tag,
        "rwp": float(hist.get_wR()) if hist.get_wR() is not None else None,
        "covariance": {
            key: covariance(project).get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp", "GOF")
        },
        "instrument": {
            key: value
            for key, value in hist.InstrumentParameters.items()
            if key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "I(L2)/I(L1)")
        },
        "sample": {
            key: value
            for key, value in hist.SampleParameters.items()
            if key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius")
        },
        "phases": [],
    }
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:
        fractions = {"error": repr(exc)}
    result["mass_fractions"] = fractions
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "composition": phase.composition,
                "density": phase.density,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "size": hap.get("Size"),
                "mustrain": hap.get("Mustrain"),
                "preferred_orientation": hap.get("Pref.Ori."),
            }
        )
    print("MODEL_SUMMARY=" + json.dumps(result, default=str, sort_keys=True))
    return result


def build_project(output: Path, keys: list[str]) -> G2sc.G2Project:
    project = G2sc.G2Project(newgpx=str(output))
    histogram = project.add_powder_histogram(
        "inputs/pattern.csv",
        "instrument.instprm",
        fmthint="comma/tab/semicolon separated",
    )
    histogram.SampleParameters["Scale"][1] = False
    initialize_background(histogram)
    for key in keys:
        cod_id, name = CANDIDATES[key]
        project.add_phase(
            str(cif_path(cod_id)),
            phasename=name,
            histograms=[histogram],
            fmthint="CIF",
        )
    apply_starting_cells(project)
    # One least-squares cycle per save/reload makes broad, initially
    # mismatched phase models much less prone to a destructive second step.
    project.set_Controls("cycles", 1)

    # Use a broad positive starting profile so slightly displaced candidate
    # peaks overlap the observations in the first cell/scale refinement.
    instrument = histogram.InstrumentParameters
    instrument["U"][1] = 2.0
    instrument["V"][1] = -2.0
    instrument["W"][1] = 100.0
    instrument["X"][1] = 0.0
    instrument["Y"][1] = 5.0
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][0] = 1.0 / max(1, len(project.phases()))
        hap["Scale"][1] = True
        phase.data["General"]["Cell"][0] = False
    histogram.Background[0][1] = True
    project.save(str(output))
    return project


def matched_minimal_refinement(project: G2sc.G2Project, output: Path) -> bool:
    hist = project.histograms()[0]
    ok = stable_refine(project, "broad-background-scale", attempts=12)
    project.save(str(output.with_name(output.stem + "-stage1.gpx")))
    if not ok:
        return False

    # Refine each candidate cell against its own supported peaks before a
    # joint cell step. This prevents an unsupported trial phase from taking a
    # singular metric step in the first least-squares cycle.
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        ok = stable_refine(project, f"cell-{phase.name}", attempts=10)
        if not ok:
            return False
        phase.data["General"]["Cell"][0] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    ok = stable_refine(project, "joint-cells", attempts=10)
    if not ok:
        return False
    project.save(str(output.with_name(output.stem + "-stage1b.gpx")))

    # Let the global Gaussian and Lorentzian widths settle from positive starts.
    inst = hist.InstrumentParameters
    inst["W"][2] = True
    inst["Y"][2] = True
    ok = stable_refine(project, "W-Y", attempts=10)
    project.save(str(output.with_name(output.stem + "-stage2.gpx")))
    if not ok:
        return False

    # Add the minimum angle dependence needed for the complete range.
    inst["U"][2] = True
    inst["V"][2] = True
    inst["X"][2] = True
    ok = stable_refine(project, "U-V-W-X-Y", attempts=12)
    project.save(str(output.with_name(output.stem + "-stage3.gpx")))
    project.save(str(output))
    return ok


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+", choices=sorted(CANDIDATES))
    args = parser.parse_args()
    project = build_project(args.output, args.phases)
    ok = matched_minimal_refinement(project, args.output)
    summarize(project, "final" if ok else "failed")
    project.save(str(args.output))


if __name__ == "__main__":
    main()
