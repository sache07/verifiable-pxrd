#!/usr/bin/env python3
"""One-parameter phase broadening screen for a GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def freeze(project: G2sc.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("term", choices=["size", "strain"])
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    freeze(project)
    hist = project.histograms()[0]
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    if args.term == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
        variable = f"{phase.id}:{hist.id}:Size;i"
        project.set_Controls("parmMin", 0.001, variable=variable)
        project.set_Controls("parmMax", 1000.0, variable=variable)
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
        variable = f"{phase.id}:{hist.id}:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 100000.0, variable=variable)

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1e-8
    controls["shift factor"] = 0.5
    project.save()
    project.refine()
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    value = hap["Size"][1][0] if args.term == "size" else hap["Mustrain"][1][0]
    result = {
        "phase": phase.name,
        "term": args.term,
        "value": value,
        "rwp": hist.get_wR(),
        "converged": cov.get("converged"),
        "max_shift_over_esd": cov.get("Max shft/sig"),
        "svd_dropped": cov.get("SVD0"),
        "message": cov.get("msg"),
    }
    print("BROADENING_SCREEN_RESULT=" + json.dumps(result))


if __name__ == "__main__":
    main()
