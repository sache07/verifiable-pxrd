#!/usr/bin/env python3
"""Repeat the refinement flags already stored in a GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--attempts", type=int, default=8)
    parser.add_argument("--shift-factor", type=float, default=0.5)
    args = parser.parse_args()
    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1e-8
    controls["shift factor"] = args.shift_factor
    project.save()
    history = []
    for attempt in range(1, args.attempts + 1):
        project.refine()
        project.save()
        values = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        state = {
            "attempt": attempt,
            "rwp": project.histograms()[0].get_wR(),
            "converged": values.get("converged"),
            "max_shift_over_esd": values.get("Max shft/sig"),
            "svd_dropped": values.get("SVD0"),
            "message": values.get("msg"),
        }
        history.append(state)
        shift = abs(float(values.get("Max shft/sig") or 999.0))
        if (
            values.get("converged")
            and shift < 0.05
            and not values.get("SVD0")
            and not values.get("msg")
        ):
            break
    print(
        "RECONVERGE_RESULT="
        + json.dumps(
            {
                "history": history,
                "fractions": project.histograms()[0].ComputeMassFracs(),
            },
            default=str,
        )
    )


if __name__ == "__main__":
    main()
