"""Small GSAS-II refinement helpers used for matched branch tests."""

from __future__ import annotations

import contextlib
import io
import math


def covariance_status(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project, maximum_calls=20, target_shift=0.03, maximum_cycles=12):
    """Refine repeatedly until GSAS-II reports a small final shift/esd."""
    project.data["Controls"]["data"]["max cyc"] = maximum_cycles
    history = []
    for call in range(1, maximum_calls + 1):
        capture = io.StringIO()
        try:
            with contextlib.redirect_stdout(capture):
                project.refine()
        except Exception as error:
            return False, history, f"{type(error).__name__}: {error}\n{capture.getvalue()}"
        status = covariance_status(project)
        item = {
            "call": call,
            "rwp_percent": float(project.histograms()[0].get_wR()),
            "converged": bool(status.get("converged")),
            "svd_dropped": int(status.get("SVD0", 0) or 0),
            "max_shift_over_esd": float(status.get("Max shft/sig") or math.inf),
            "message": str(status.get("msg", "") or ""),
        }
        history.append(item)
        if (
            item["converged"]
            and item["svd_dropped"] == 0
            and abs(item["max_shift_over_esd"]) < target_shift
        ):
            return True, history, ""
    return False, history, "did not reach the requested shift/esd threshold"


def maximum_correlations(project, limit=10):
    """Return the largest absolute off-diagonal covariance correlations."""
    import numpy as np

    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    rows = []
    for i in range(len(names)):
        for j in range(i):
            denominator = sigma[i] * sigma[j]
            if denominator > 0:
                rows.append((abs(float(matrix[i, j] / denominator)), names[j], names[i]))
    rows.sort(reverse=True)
    return rows[:limit]


def cw_width_diagnostics(histogram, points=181):
    """Evaluate the GSAS-II CW Gaussian and Lorentzian width polynomials."""
    import numpy as np

    lower, upper = histogram.data["Limits"][1]
    two_theta = np.linspace(float(lower), float(upper), points)
    theta = np.radians(two_theta / 2.0)
    inst = histogram.InstrumentParameters
    value = lambda key: float(inst[key][1]) if key in inst else 0.0
    tangent = np.tan(theta)
    gaussian = value("U") * tangent**2 + value("V") * tangent + value("W")
    lorentzian = value("X") / np.cos(theta) + value("Y") * tangent + value("Z")
    return {
        "gaussian_variance_min": float(np.min(gaussian)),
        "gaussian_variance_max": float(np.max(gaussian)),
        "lorentzian_width_min": float(np.min(lorentzian)),
        "lorentzian_width_max": float(np.max(lorentzian)),
    }
