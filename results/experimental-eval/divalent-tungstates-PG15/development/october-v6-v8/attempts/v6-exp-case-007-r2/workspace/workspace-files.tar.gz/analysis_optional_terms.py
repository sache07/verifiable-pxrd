#!/usr/bin/env python3
"""Matched removal/replacement tests for retained optional nuisance terms."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


BASE = Path("mature_angular_retest.gpx")


def converge(project, maximum_passes=4):
    for _ in range(maximum_passes):
        project.refine()
        project.save()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        if rvals.get("converged", False) and abs(rvals.get("Max shft/sig", 99.0)) < 1.0:
            break


def metrics(project):
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    names = covariance["varyList"]
    matrix = np.asarray(covariance["covMatrix"], dtype=float)
    sigmas = np.sqrt(np.diag(matrix))
    correlations = []
    if len(names):
        corr = np.divide(
            matrix,
            np.outer(sigmas, sigmas),
            out=np.zeros_like(matrix),
            where=np.outer(sigmas, sigmas) > 0,
        )
        for i in range(len(names)):
            for j in range(i):
                if abs(corr[i, j]) >= 0.90:
                    correlations.append([names[i], names[j], float(corr[i, j])])
    return {
        "Rwp_percent": float(rvals.get("Rwp", math.nan)),
        "GOF": float(rvals.get("GOF", math.nan)),
        "converged": bool(rvals.get("converged", False)),
        "SVD0": int(rvals.get("SVD0", -1)),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", math.nan)),
        "high_correlations": correlations,
    }


def branch(label, mutator):
    project = G2sc.G2Project(gpxfile=str(BASE))
    output = Path(f"optional_{label}.gpx")
    project.save(str(output))
    mutator(project)
    project.save()
    try:
        converge(project)
        return {"branch": label, **metrics(project)}
    except Exception as exc:
        return {"branch": label, "error": repr(exc)}


def profile_zero(term):
    def mutate(project):
        parameter = project.histograms()[0].data["Instrument Parameters"][0][term]
        parameter[1] = 0.0
        parameter[2] = False

    return mutate


def no_roughness(project):
    sample = project.histograms()[0].data["Sample Parameters"]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]


def polarization(project):
    no_roughness(project)
    polar = project.histograms()[0].data["Instrument Parameters"][0]["Polariz."]
    polar[1], polar[2] = 0.7, True


def no_texture(project):
    hist = project.histograms()[0]
    po = project.phases()[0].data["Histograms"][hist.name]["Pref.Ori."]
    po[1], po[2] = 1.0, False


def texture_110(project):
    hist = project.histograms()[0]
    po = project.phases()[0].data["Histograms"][hist.name]["Pref.Ori."]
    po[1], po[2], po[3] = 1.0, True, [1, 1, 0]


def source_coordinates(project):
    source = {
        "Mg": [0.5, 0.6742, 0.25],
        "W": [0.0, 0.1819, 0.25],
        "O1": [0.216, 0.107, 0.937],
        "O2": [0.256, 0.3766, 0.397],
    }
    phase = project.phases()[0]
    cx = phase.data["General"]["AtomPtrs"][0]
    for atom in phase.data["Atoms"]:
        atom[cx - 1] = ""
        atom[cx : cx + 3] = source[atom[0]]


def background_terms(count):
    def mutate(project):
        background = project.histograms()[0].data["Background"][0]
        coefficients = list(background[3 : 3 + count])
        project.histograms()[0].data["Background"][0] = [
            background[0],
            True,
            count,
            *coefficients,
        ]

    return mutate


base = G2sc.G2Project(gpxfile=str(BASE))
results = [{"branch": "selected", **metrics(base)}]
tests = (
    ("without_U", profile_zero("U")),
    ("without_W", profile_zero("W")),
    ("without_X", profile_zero("X")),
    ("without_roughness", no_roughness),
    ("polarization_instead_of_roughness", polarization),
    ("without_texture", no_texture),
    ("texture_110_instead_of_001", texture_110),
    ("source_coordinates", source_coordinates),
    ("background_8_terms", background_terms(8)),
    ("background_10_terms", background_terms(10)),
)
for label, mutator in tests:
    results.append(branch(label, mutator))

print("OPTIONAL_TERM_RESULT")
print(json.dumps(results, indent=2))
