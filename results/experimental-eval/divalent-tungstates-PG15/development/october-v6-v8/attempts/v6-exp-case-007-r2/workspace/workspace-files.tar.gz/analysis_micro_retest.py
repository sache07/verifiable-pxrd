#!/usr/bin/env python3
"""Matched one-term phase-broadening tests from the mature no-strain model."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc


BASE = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("mature_micro_remove_wo3_strain.gpx")
PREFIX = sys.argv[2] if len(sys.argv) > 2 else "mature_retest"
TESTS = (
    ("mgwo4_strain", 0, "Mustrain", 600.0),
    ("wo3_size", 1, "Size", 1.0),
    ("wo3_strain", 1, "Mustrain", 1000.0),
    ("mgo_size", 2, "Size", 1.0),
    ("mgo_strain", 2, "Mustrain", 600.0),
)


def correlations(covariance, needle):
    names = covariance["varyList"]
    matrix = np.asarray(covariance["covMatrix"], dtype=float)
    sigmas = np.sqrt(np.diag(matrix))
    indices = [index for index, name in enumerate(names) if needle in name]
    result = []
    for index in indices:
        denom = sigmas[index] * sigmas
        corr = np.divide(
            matrix[index], denom, out=np.zeros_like(denom), where=denom > 0
        )
        for other, value in enumerate(corr):
            if other != index and abs(value) >= 0.90:
                result.append([names[index], names[other], float(value)])
    return result


summaries = []
for label, phase_index, term, initial in TESTS:
    project = G2sc.G2Project(gpxfile=str(BASE))
    histogram = project.histograms()[0]
    phases = project.phases()
    # Ensure every phase-broadening term is off before activating this branch.
    for phase in phases:
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
    hap = phases[phase_index].data["Histograms"][histogram.name]
    hap[term][0] = "isotropic"
    hap[term][1][0] = initial
    hap[term][2][0] = True
    output = Path(f"{PREFIX}_{label}.gpx")
    project.save(str(output))
    try:
        project.refine()
        project.save()
        cov = project.data["Covariance"]["data"]
        rvals = cov["Rvals"]
        final_hap = project.phases()[phase_index].data["Histograms"][histogram.name]
        value = float(final_hap[term][1][0])
        prefix = f"{phase_index}:0:"
        needle = "Size;i" if term == "Size" else "Mustrain;i"
        summaries.append(
            {
                "branch": label,
                "phase": project.phases()[phase_index].name,
                "term": term,
                "value": value,
                "Rwp_percent": float(rvals.get("Rwp", np.nan)),
                "GOF": float(rvals.get("GOF", np.nan)),
                "converged": bool(rvals.get("converged", False)),
                "SVD0": int(rvals.get("SVD0", -1)),
                "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
                "high_correlations": correlations(cov, prefix + needle),
            }
        )
    except Exception as exc:
        summaries.append({"branch": label, "error": repr(exc)})

print("MICRO_RETEST_RESULT")
print(json.dumps(summaries, indent=2))
