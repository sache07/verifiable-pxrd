#!/usr/bin/env python3
"""Freeze the selected model as final.gpx and export its phase CIFs."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE = Path("mature_angular_retest.gpx")
FINAL = Path("final.gpx")
CIF_PATHS = (
    Path("phase_mgwo4.cif"),
    Path("phase_wo3.cif"),
    Path("phase_mgo.cif"),
)


project = G2sc.G2Project(gpxfile=str(SOURCE))
project.save(str(FINAL))
for _ in range(4):
    project.refine()
    project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    if (
        rvals.get("converged", False)
        and rvals.get("SVD0", -1) == 0
        and abs(rvals.get("Max shft/sig", math.inf)) < 1.0
    ):
        break

histogram = project.histograms()[0]
phases = project.phases()
for phase, output in zip(phases, CIF_PATHS, strict=True):
    phase.export_CIF(str(output))

scales = np.asarray(
    [phase.data["Histograms"][histogram.name]["Scale"][0] for phase in phases],
    dtype=float,
)
masses = np.asarray([phase.data["General"]["Mass"] for phase in phases], dtype=float)
products = scales * masses
fractions = products / products.sum()

covariance = project.data["Covariance"]["data"]
names = covariance["varyList"]
scale_indices = [names.index(f"{index}:0:Scale") for index in range(len(phases))]
scale_covariance = np.asarray(covariance["covMatrix"])[
    np.ix_(scale_indices, scale_indices)
]
jacobian = np.zeros((len(phases), len(phases)))
total = products.sum()
for i in range(len(phases)):
    for j in range(len(phases)):
        jacobian[i, j] = (
            masses[i] * (1.0 if i == j else 0.0) * total
            - products[i] * masses[j]
        ) / total**2
fraction_esds = np.sqrt(np.diag(jacobian @ scale_covariance @ jacobian.T))

summary = {
    "phases": [phase.name for phase in phases],
    "cifs": [str(path) for path in CIF_PATHS],
    "weight_fractions": fractions.tolist(),
    "weight_fraction_esds": fraction_esds.tolist(),
    "Rvals": {
        key: value
        for key, value in project.data["Covariance"]["data"]["Rvals"].items()
        if isinstance(value, (str, int, float, bool)) or value is None
    },
}
print("FINAL_GSAS_RESULT")
print(json.dumps(summary, indent=2))
