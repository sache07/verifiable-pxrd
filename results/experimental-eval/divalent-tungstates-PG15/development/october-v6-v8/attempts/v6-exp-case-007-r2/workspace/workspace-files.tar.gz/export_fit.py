#!/usr/bin/env python3
"""Export the regenerated full-grid observed/calculated/difference profile."""

from __future__ import annotations

import numpy as np
from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(gpxfile="final.gpx")
arrays = np.asarray(project.histograms()[0].data["data"][1], dtype=float)
x, observed, _weights, calculated, _background, difference = arrays
output = np.column_stack((x, observed, calculated, difference))
np.savetxt(
    "fit.csv",
    output,
    delimiter=",",
    header="two_theta_deg,observed_counts,calculated_counts,difference_counts",
    comments="",
    fmt=("%.8f", "%.8f", "%.8f", "%.8f"),
)
print(f"wrote fit.csv with {len(output)} rows")
