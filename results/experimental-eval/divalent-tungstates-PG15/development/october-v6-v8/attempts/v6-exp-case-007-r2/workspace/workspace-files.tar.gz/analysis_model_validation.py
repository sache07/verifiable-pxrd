#!/usr/bin/env python3
"""Matched leave-one-out and WO3 structural-alternative tests."""

from __future__ import annotations

import json
import math
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc


BASE = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("mature_micro_remove_wo3_strain.gpx")
PREFIX = sys.argv[2] if len(sys.argv) > 2 else ""
ALT_CIFS = {
    "wo3_triclinic_2106293": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/2/10/62/2106293.cif"
    ),
    "wo3_orthorhombic_2107312": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/2/10/73/2107312.cif"
    ),
}


def profile_metrics(project):
    hist = project.histograms()[0]
    x, obs, weights, calc = [np.asarray(row, dtype=float) for row in hist.data["data"][1][:4]]
    low, high = hist.data["Limits"][1]
    regions = ((low, 30.0), (30.0, 50.0), (50.0, 70.0), (70.0, high))
    regional = {}
    for lo, hi in regions:
        mask = (x >= lo) & (x < hi) & np.isfinite(obs) & np.isfinite(calc) & (weights > 0)
        den = np.sum(weights[mask] * obs[mask] ** 2)
        num = np.sum(weights[mask] * (obs[mask] - calc[mask]) ** 2)
        regional[f"{lo:.1f}-{hi:.1f}"] = 100.0 * math.sqrt(num / den) if den > 0 else None
    rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "Rwp_percent": float(rvals.get("Rwp", np.nan)),
        "GOF": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "SVD0": int(rvals.get("SVD0", -1)),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", np.nan)),
        "regional_Rwp_percent": regional,
    }


def remove_phase(project, name):
    del project.data["Phases"][name]
    for row in project.names:
        if row and row[0] == "Phases" and name in row:
            row.remove(name)
    for hist in project.histograms():
        hist.data["Reflection Lists"].pop(name, None)
    project.index_ids()
    project.update_ids()


def converge(project, maximum_passes=4):
    """Continue matched refinements until both convergence tests are quiet."""
    for _ in range(maximum_passes):
        project.refine()
        project.save()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        if rvals.get("converged", False) and rvals.get("Max shft/sig", 99.0) < 1.0:
            break


results = []
base = G2sc.G2Project(gpxfile=str(BASE))
results.append({"branch": "complete_model", **profile_metrics(base)})

for phase_name in [phase.name for phase in base.phases()]:
    project = G2sc.G2Project(gpxfile=str(BASE))
    hist = project.histograms()[0]
    project.phase(phase_name).data["Histograms"][hist.name]["Use"] = False
    output = Path(f"{PREFIX}leaveout_{phase_name}.gpx")
    project.save(str(output))
    try:
        converge(project)
        results.append(
            {"branch": f"leave_out_{phase_name}", **profile_metrics(project)}
        )
    except Exception as exc:
        results.append({"branch": f"leave_out_{phase_name}", "error": repr(exc)})

for label, cif_path in ALT_CIFS.items():
    project = G2sc.G2Project(gpxfile=str(BASE))
    hist = project.histograms()[0]
    output = Path(f"{PREFIX}replacement_{label}.gpx")
    # Change the project's save target before phase import, since importers may
    # autosave bookkeeping changes.
    project.save(str(output))
    remove_phase(project, "wo3_2311041")
    alt = project.add_phase(
        str(cif_path), phasename=label, histograms=[hist], fmthint="CIF"
    )
    alt.data["General"]["Cell"][0] = False
    hap = alt.data["Histograms"][hist.name]
    hap["Scale"] = [4.0, True]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    project.save()
    try:
        # Settle scale and nuisance terms first, then release the candidate cell.
        converge(project)
        project.phase(label).data["General"]["Cell"][0] = True
        project.save()
        converge(project)
        result = {
            "branch": f"replace_selected_with_{label}",
            "scale": float(
                project.phase(label).data["Histograms"][hist.name]["Scale"][0]
            ),
            "cell": [float(value) for value in project.phase(label).data["General"]["Cell"][1:8]],
            **profile_metrics(project),
        }
        results.append(result)
    except Exception as exc:
        results.append(
            {"branch": f"replace_selected_with_{label}", "error": repr(exc)}
        )

print("MODEL_VALIDATION_RESULT")
print(json.dumps(results, indent=2))
