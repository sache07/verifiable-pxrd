#!/usr/bin/env python3
"""Export final-fit arrays and list the largest standardized residuals."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("data", type=Path)
    args = parser.parse_args()
    project = G2sc.G2Project(str(args.project.resolve()))
    hist = project.histograms()[0]
    x, observed, weights, calculated, background, difference = [
        np.asarray(value) for value in hist.data["data"][1][:6]
    ]
    sigma = np.where(weights > 0, 1.0 / np.sqrt(weights), np.inf)
    standardized = difference / sigma
    smoothed = gaussian_filter1d(standardized, sigma=2.0)
    peaks, properties = find_peaks(np.abs(smoothed), prominence=0.8, distance=8)
    order = peaks[np.argsort(np.abs(smoothed[peaks]))[::-1]]
    residual_peaks = [
        {
            "two_theta_deg": float(x[index]),
            "smoothed_standardized_residual": float(smoothed[index]),
            "observed_counts": float(observed[index]),
            "calculated_counts": float(calculated[index]),
        }
        for index in order[:30]
    ]

    args.data.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        args.data,
        two_theta=x,
        observed=observed,
        calculated=calculated,
        background=background,
        difference=difference,
        standardized_residual=standardized,
    )

    print(json.dumps({
        "project": str(args.project.resolve()),
        "data": str(args.data.resolve()),
        "largest_smoothed_standardized_residuals": residual_peaks,
    }, indent=2))


if __name__ == "__main__":
    main()
