#!/usr/bin/env python3
"""Matched GSAS-II branches for global Gaussian/Lorentzian profile terms."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PROFILE_TERMS = ("U", "V", "W", "X", "Y", "Z")


def status(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project, rounds=8):
    history = []
    valid = True
    for index in range(rounds):
        try:
            project.refine(makeBack=False)
        except Exception as error:
            history.append({"error": repr(error)})
            valid = False
            break
        state = status(project)
        row = {
            "round": index + 1,
            "rwp": float(project.histograms()[0].get_wR()),
            "converged": bool(state.get("converged")),
            "max_shift_esd": state.get("Max shft/sig"),
            "svd": state.get("SVD0", 0),
            "message": state.get("msg"),
        }
        history.append(row)
        print("PROFILE_ROUND=" + json.dumps(row, default=str, sort_keys=True))
        message = str(state.get("msg", "") or "").lower()
        if state.get("SVD0", 0) or "dropped" in message or "error" in message:
            valid = False
            break
        shift = abs(float(state.get("Max shft/sig") or math.inf))
        if state.get("converged") and shift < 0.05:
            break
    if not history or not history[-1].get("converged"):
        valid = False
    elif abs(float(history[-1].get("max_shift_esd") or math.inf)) >= 0.05:
        valid = False
    return valid, history


def profile_positive(hist):
    inst = hist.InstrumentParameters
    two_theta = np.linspace(hist.data["Limits"][1][0], hist.data["Limits"][1][1], 2001)
    theta = np.radians(two_theta / 2.0)
    values = {key: float(inst[key][1]) for key in PROFILE_TERMS}
    gaussian = values["U"] * np.tan(theta) ** 2 + values["V"] * np.tan(theta) + values["W"]
    lorentzian = values["X"] / np.cos(theta) + values["Y"] * np.tan(theta) + values["Z"]
    # The FCJ term supplies a small positive Lorentzian contribution even
    # when X/Y/Z are zero. Report the explicit global component separately.
    return {
        "gaussian_min_centideg2": float(np.min(gaussian)),
        "gaussian_max_centideg2": float(np.max(gaussian)),
        "lorentzian_global_min_centideg": float(np.min(lorentzian)),
        "lorentzian_global_max_centideg": float(np.max(lorentzian)),
    }


def binned_rwp(hist):
    x, y, weights, calculated = hist.data["data"][1][:4]
    rows = []
    for lower in range(10, 100, 10):
        use = (x >= lower) & (x < lower + 10)
        denominator = float(np.sum(weights[use] * y[use] ** 2))
        numerator = float(np.sum(weights[use] * (y[use] - calculated[use]) ** 2))
        rows.append({
            "range": f"{lower}-{lower + 10}",
            "rwp": 100.0 * math.sqrt(numerator / denominator),
        })
    return rows


def run_branch(source, destination, terms):
    project = G2sc.G2Project(str(source))
    hist = project.histograms()[0]
    for key in PROFILE_TERMS:
        if key in hist.InstrumentParameters:
            hist.InstrumentParameters[key][2] = key in terms
    project.set_Controls("cycles", 12)
    project.save(str(destination.with_name(destination.stem + "_start.gpx")))
    valid, history = stable_refine(project)
    project.save(str(destination))
    values = {key: hist.InstrumentParameters[key] for key in PROFILE_TERMS}
    widths = profile_positive(hist)
    if widths["gaussian_min_centideg2"] <= 0.0:
        valid = False
    if any(key in terms for key in ("X", "Y", "Z")) and widths["lorentzian_global_min_centideg"] < 0.0:
        valid = False
    result = {
        "source": str(source),
        "project": str(destination),
        "terms": list(terms),
        "valid": valid,
        "rwp": float(hist.get_wR()),
        "residuals": hist.residuals,
        "instrument": values,
        "widths": widths,
        "binned_rwp": binned_rwp(hist),
        "history": history,
    }
    print("PROFILE_BRANCH=" + json.dumps(result, default=str, sort_keys=True))
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("stage", choices=("gaussian", "lorentzian"))
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if args.stage == "gaussian":
        branches = [("w", ("W",)), ("uw", ("U", "W")), ("uvw", ("U", "V", "W"))]
    else:
        branches = [("x", ("X",)), ("y", ("Y",)), ("xy", ("X", "Y"))]
    results = []
    for name, terms in branches:
        destination = args.output_dir / f"{args.stage}_{name}.gpx"
        results.append(run_branch(args.source.resolve(), destination.resolve(), terms))
    output = args.output_dir / f"{args.stage}_results.json"
    output.write_text(json.dumps(results, indent=2, default=str, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
