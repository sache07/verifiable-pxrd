#!/usr/bin/env python3
"""Plot final-fit arrays exported from GSAS-II."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("data", type=Path)
    parser.add_argument("plot", type=Path)
    args = parser.parse_args()
    data = np.load(args.data)
    x = data["two_theta"]
    observed = data["observed"]
    calculated = data["calculated"]
    difference = data["difference"]

    args.plot.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(3, 1, figsize=(14, 10), constrained_layout=True)
    ranges = ((10, 40), (40, 70), (70, 100))
    for ax, (lower, upper) in zip(axes, ranges):
        use = (x >= lower) & (x <= upper)
        offset = -0.12 * float(np.max(observed[use]))
        ax.plot(x[use], observed[use], color="black", linewidth=0.7, label="Observed")
        ax.plot(x[use], calculated[use], color="#d62728", linewidth=0.8, label="Calculated")
        ax.plot(
            x[use], difference[use] + offset, color="#1f77b4", linewidth=0.6,
            label="Difference (offset)",
        )
        ax.axhline(offset, color="0.6", linewidth=0.5)
        ax.set_xlim(lower, upper)
        ax.set_ylabel("Counts")
    axes[0].legend(loc="upper right", ncol=3, fontsize=8)
    axes[-1].set_xlabel(r"2$\theta$ (degrees)")
    fig.suptitle("Final GSAS-II Rietveld fit")
    fig.savefig(args.plot, dpi=180)
    plt.close(fig)


if __name__ == "__main__":
    main()
