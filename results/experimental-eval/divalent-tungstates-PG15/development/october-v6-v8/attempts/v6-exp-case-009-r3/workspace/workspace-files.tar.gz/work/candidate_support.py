#!/usr/bin/env python3
"""Summarize where a trial phase improves or worsens a matched powder fit."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def reflection_groups(reflections, minimum_relative=0.005, merge_width=0.18):
    # Powder RefList columns for non-modulated phases: h k l mult d pos
    # sig gam Fobs2 Fcalc2 phase Icorr ... preferred-orientation factor.
    rows = []
    for ref in reflections:
        intensity = max(0.0, float(ref[3] * ref[9] * ref[11] * ref[-1]))
        rows.append((float(ref[5]), intensity, tuple(int(v) for v in ref[:3])))
    strongest = max((row[1] for row in rows), default=0.0)
    rows = sorted(row for row in rows if row[1] >= minimum_relative * strongest)
    groups = []
    for position, intensity, hkl in rows:
        if groups and position - groups[-1]["last_position"] <= merge_width:
            group = groups[-1]
            total = group["intensity"] + intensity
            group["position"] = (
                group["position"] * group["intensity"] + position * intensity
            ) / total
            group["intensity"] = total
            group["last_position"] = position
            group["hkls"].append(hkl)
        else:
            groups.append({
                "position": position,
                "last_position": position,
                "intensity": intensity,
                "hkls": [hkl],
            })
    return groups


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("branch", type=Path)
    parser.add_argument("candidate")
    parser.add_argument("--window", type=float, default=0.18)
    parser.add_argument("--top", type=int, default=24)
    args = parser.parse_args()

    baseline = G2sc.G2Project(str(args.baseline.resolve()))
    branch = G2sc.G2Project(str(args.branch.resolve()))
    hist0 = baseline.histograms()[0]
    hist1 = branch.histograms()[0]
    x0, y0, w0, calc0 = [np.asarray(v) for v in hist0.data["data"][1][:4]]
    x1, y1, w1, calc1 = [np.asarray(v) for v in hist1.data["data"][1][:4]]
    if not (np.allclose(x0, x1) and np.allclose(y0, y1) and np.allclose(w0, w1)):
        raise ValueError("baseline and branch observations/weights differ")

    refl = hist1.reflections()
    groups = reflection_groups(np.asarray(refl[args.candidate]["RefList"]))
    primary_name = next(name for name in refl if name != args.candidate)
    primary_groups = reflection_groups(np.asarray(refl[primary_name]["RefList"]), 0.002)
    primary_positions = np.array([g["position"] for g in primary_groups])

    rows = []
    for group in groups:
        center = group["position"]
        use = np.abs(x0 - center) <= args.window
        if not np.any(use):
            continue
        chi0 = float(np.sum(w0[use] * (y0[use] - calc0[use]) ** 2))
        chi1 = float(np.sum(w0[use] * (y0[use] - calc1[use]) ** 2))
        rows.append({
            "position_deg": center,
            "relative_intensity": group["intensity"],
            "nearest_primary_deg": float(np.min(np.abs(primary_positions - center))),
            "baseline_residual_sum_counts": float(np.sum(y0[use] - calc0[use])),
            "branch_minus_baseline_calc_sum_counts": float(np.sum(calc1[use] - calc0[use])),
            "delta_chi2_positive_is_better": chi0 - chi1,
            "hkls": group["hkls"],
        })
    maximum = max((row["relative_intensity"] for row in rows), default=1.0)
    for row in rows:
        row["relative_intensity"] = 100.0 * row["relative_intensity"] / maximum
    rows.sort(key=lambda row: row["relative_intensity"], reverse=True)

    overall0 = float(np.sum(w0 * (y0 - calc0) ** 2))
    overall1 = float(np.sum(w0 * (y0 - calc1) ** 2))
    print(json.dumps({
        "candidate": args.candidate,
        "overall_delta_chi2_positive_is_better": overall0 - overall1,
        "top_reflection_groups": rows[: args.top],
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
