#!/usr/bin/env python3
"""Copy a GPX, then refine all enabled parameters to a stable endpoint."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def state(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--rounds", type=int, default=8)
    args = parser.parse_args()
    args.destination.parent.mkdir(parents=True, exist_ok=True)

    project = G2sc.G2Project(str(args.source.resolve()))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.save(str(args.destination.resolve()))
    history = []
    valid = True
    for number in range(1, args.rounds + 1):
        try:
            project.refine(makeBack=False)
        except Exception as error:
            history.append({"round": number, "error": repr(error)})
            valid = False
            break
        current = state(project)
        row = {
            "round": number,
            "rwp": float(project.histograms()[0].get_wR()),
            "converged": bool(current.get("converged")),
            "max_shift_esd": current.get("Max shft/sig"),
            "svd": current.get("SVD0", 0),
            "message": current.get("msg"),
        }
        history.append(row)
        print("CONVERGE_ROUND=" + json.dumps(row, default=str, sort_keys=True))
        message = str(current.get("msg", "") or "").lower()
        if current.get("SVD0", 0) or "dropped" in message or "error" in message:
            valid = False
            break
        shift = abs(float(current.get("Max shft/sig") or math.inf))
        if current.get("converged") and shift < 0.05:
            break
    current = state(project)
    if not history or not current.get("converged"):
        valid = False
    elif abs(float(current.get("Max shft/sig") or math.inf)) >= 0.05:
        valid = False
    project.save(str(args.destination.resolve()))

    hist = project.histograms()[0]
    fractions = {
        key: {"value": value[0], "esd": value[1]}
        for key, value in hist.ComputeMassFracs().items()
    }
    print("CONVERGE_RESULT=" + json.dumps({
        "valid": valid,
        "project": str(args.destination.resolve()),
        "rwp": float(hist.get_wR()),
        "residuals": hist.residuals,
        "history": history,
        "mass_fractions": fractions,
        "cells": {phase.name: phase.get_cell_and_esd() for phase in project.phases()},
    }, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
