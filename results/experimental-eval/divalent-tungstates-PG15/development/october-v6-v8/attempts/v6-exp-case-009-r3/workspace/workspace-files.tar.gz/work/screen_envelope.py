#!/usr/bin/env python3
"""Compare polarization and simple Suortti surface-roughness envelopes."""

from pathlib import Path
import argparse
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE = ROOT / "work/profile_branches/gaussian_w.gpx"
DEFAULT_OUT = ROOT / "work/envelope_branches"


def state(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine(project, rounds=6):
    history = []
    for index in range(rounds):
        project.refine(makeBack=False)
        current = state(project)
        row = {
            "round": index + 1,
            "rwp": float(project.histograms()[0].get_wR()),
            "converged": bool(current.get("converged")),
            "max_shift_esd": current.get("Max shft/sig"),
            "svd": current.get("SVD0", 0),
            "message": current.get("msg"),
        }
        history.append(row)
        print("ENVELOPE_ROUND=" + json.dumps(row, default=str, sort_keys=True))
        message = str(current.get("msg", "") or "").lower()
        if current.get("SVD0", 0) or "dropped" in message or "error" in message:
            return False, history
        if current.get("converged") and abs(float(current.get("Max shft/sig") or math.inf)) < 0.05:
            return True, history
    return False, history


def bins(hist):
    x, y, weights, calc = hist.data["data"][1][:4]
    answer = []
    for low in range(10, 100, 10):
        use = (x >= low) & (x < low + 10)
        answer.append({
            "range": f"{low}-{low+10}",
            "rwp": 100 * math.sqrt(
                float(np.sum(weights[use] * (y[use] - calc[use]) ** 2))
                / float(np.sum(weights[use] * y[use] ** 2))
            ),
        })
    return answer


def branch(name, source, out):
    destination = out / f"{name}.gpx"
    project = G2sc.G2Project(str(source))
    hist = project.histograms()[0]
    hist.InstrumentParameters["Polariz."][2] = name == "polarization"
    hist.SampleParameters["SurfRoughA"][:] = [0.0, False]
    hist.SampleParameters["SurfRoughB"][:] = [0.01 if name == "roughness" else 0.0, name == "roughness"]
    project.set_Controls("cycles", 12)
    project.save(str(out / f"{name}_start.gpx"))
    valid, history = refine(project)
    project.save(str(destination))
    polarization = float(hist.InstrumentParameters["Polariz."][1])
    rough_a = float(hist.SampleParameters["SurfRoughA"][0])
    rough_b = float(hist.SampleParameters["SurfRoughB"][0])
    if not (0.0 <= polarization <= 1.0) or rough_a < 0.0 or rough_a > 1.0 or rough_b < 0.0:
        valid = False
    result = {
        "branch": name,
        "project": str(destination),
        "valid": valid,
        "rwp": float(hist.get_wR()),
        "polarization": hist.InstrumentParameters["Polariz."],
        "surface_roughness_a": hist.SampleParameters["SurfRoughA"],
        "surface_roughness_b": hist.SampleParameters["SurfRoughB"],
        "binned_rwp": bins(hist),
        "history": history,
    }
    print("ENVELOPE_BRANCH=" + json.dumps(result, default=str, sort_keys=True))
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", nargs="?", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("output_dir", nargs="?", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    results = [
        branch("polarization", args.source.resolve(), args.output_dir.resolve()),
        branch("roughness", args.source.resolve(), args.output_dir.resolve()),
    ]
    (args.output_dir / "results.json").write_text(
        json.dumps(results, indent=2, sort_keys=True) + "\n"
    )


if __name__ == "__main__":
    main()
