#!/usr/bin/env python3
"""Freeze the selected GPX and export CIF/profile deliverables from it."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("project", type=Path)
    parser.add_argument("fit", type=Path)
    parser.add_argument("cifs", nargs="+", type=Path)
    args = parser.parse_args()

    source = G2sc.G2Project(str(args.source.resolve()))
    source.save(str(args.project.resolve()))
    project = G2sc.G2Project(str(args.project.resolve()))
    phases = project.phases()
    if len(args.cifs) != len(phases):
        raise ValueError(f"received {len(args.cifs)} CIF paths for {len(phases)} phases")
    for phase, path in zip(phases, args.cifs):
        phase.export_CIF(str(path.resolve()))

    hist = project.histograms()[0]
    x, observed, weights, calculated, background, difference = [
        np.asarray(value) for value in hist.data["data"][1][:6]
    ]
    with args.fit.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "two_theta_deg",
            "observed_counts",
            "calculated_counts",
            "difference_counts",
            "background_counts",
            "weight_inverse_counts",
        ])
        writer.writerows(zip(x, observed, calculated, difference, background, weights))

    full_grid_rwp = 100.0 * math.sqrt(
        float(np.sum(weights * (observed - calculated) ** 2))
        / float(np.sum(weights * observed ** 2))
    )
    fractions = {
        key: {"value": value[0], "esd": value[1]}
        for key, value in hist.ComputeMassFracs().items()
    }
    covariance = project.data["Covariance"]["data"]["Rvals"]
    print("EXPORT_RESULT=" + json.dumps({
        "project": str(args.project.resolve()),
        "fit": str(args.fit.resolve()),
        "cifs": {
            phase.name: str(path.resolve()) for phase, path in zip(phases, args.cifs)
        },
        "fractions": fractions,
        "residuals": hist.residuals,
        "full_grid_rwp_percent": full_grid_rwp,
        "gof": covariance.get("GOF"),
        "chi_square": covariance.get("chisq"),
        "n_observations": covariance.get("Nobs"),
        "n_variables": covariance.get("Nvars"),
        "converged": covariance.get("converged"),
        "max_shift_esd": covariance.get("Max shft/sig"),
        "cells": {phase.name: phase.get_cell_and_esd() for phase in phases},
    }, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
