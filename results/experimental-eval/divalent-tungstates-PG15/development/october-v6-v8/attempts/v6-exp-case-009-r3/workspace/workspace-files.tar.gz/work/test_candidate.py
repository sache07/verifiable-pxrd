#!/usr/bin/env python3
"""Add one candidate phase to a mature GPX and refine its scale reproducibly."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def covariance_state(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def binned_rwp(hist):
    x, y, weights, calc = hist.data["data"][1][:4]
    rows = []
    for low in range(10, 100, 10):
        use = (x >= low) & (x < low + 10)
        rows.append({
            "range": f"{low}-{low + 10}",
            "rwp": 100.0 * math.sqrt(
                float(np.sum(weights[use] * (y[use] - calc[use]) ** 2))
                / float(np.sum(weights[use] * y[use] ** 2))
            ),
        })
    return rows


def refine_to_stable(project, rounds=8):
    history = []
    valid = True
    for number in range(1, rounds + 1):
        try:
            project.refine(makeBack=False)
        except Exception as error:
            history.append({"round": number, "error": repr(error)})
            valid = False
            break
        state = covariance_state(project)
        row = {
            "round": number,
            "rwp": float(project.histograms()[0].get_wR()),
            "converged": bool(state.get("converged")),
            "max_shift_esd": state.get("Max shft/sig"),
            "svd": state.get("SVD0", 0),
            "message": state.get("msg"),
        }
        history.append(row)
        print("CANDIDATE_ROUND=" + json.dumps(row, default=str, sort_keys=True))
        message = str(state.get("msg", "") or "").lower()
        if state.get("SVD0", 0) or "dropped" in message or "error" in message:
            valid = False
            break
        shift = abs(float(state.get("Max shft/sig") or math.inf))
        if state.get("converged") and shift < 0.05:
            break
    if not history or not history[-1].get("converged"):
        valid = False
    elif abs(float(history[-1].get("max_shift_esd") or math.inf)) >= 0.05:
        valid = False
    return valid, history


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("name")
    parser.add_argument("--refine-cell", action="store_true")
    args = parser.parse_args()

    args.destination.parent.mkdir(parents=True, exist_ok=True)
    # add_phase() saves the currently loaded GPX as a side effect. Work from a
    # private copy so the stable source checkpoint can never be modified.
    working = args.destination.with_name(args.destination.stem + "_working.gpx")
    shutil.copy2(args.source.resolve(), working.resolve())
    project = G2sc.G2Project(str(working.resolve()))
    hist = project.histograms()[0]
    phase = project.add_phase(
        str(args.candidate.resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    # Start small but do not constrain the sign: an unsupported candidate is
    # expected to refine through zero and should be rejected rather than clipped.
    hap["Scale"][:] = [0.1, True]
    if args.refine_cell:
        phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6

    start = args.destination.with_name(args.destination.stem + "_start.gpx")
    project.save(str(start.resolve()))
    valid, history = refine_to_stable(project)
    project.save(str(args.destination.resolve()))

    try:
        mass_fractions = {
            key: {"value": value[0], "esd": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as error:
        mass_fractions = {"error": repr(error)}

    result = {
        "source": str(args.source.resolve()),
        "candidate": str(args.candidate.resolve()),
        "project": str(args.destination.resolve()),
        "candidate_name": phase.name,
        "valid_refinement": valid,
        "candidate_scale": list(hap["Scale"]),
        "mass_fractions": mass_fractions,
        "rwp": float(hist.get_wR()),
        "residuals": hist.residuals,
        "binned_rwp": binned_rwp(hist),
        "history": history,
    }
    print("CANDIDATE_RESULT=" + json.dumps(result, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
