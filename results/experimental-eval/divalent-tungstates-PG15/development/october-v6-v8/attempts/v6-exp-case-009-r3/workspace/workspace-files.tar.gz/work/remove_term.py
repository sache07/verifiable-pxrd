#!/usr/bin/env python3
"""Create a matched branch with one retained optional term removed."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


REFERENCE_MNWO4_COORDS = {
    "Mn1": (0.5, 0.6846, 0.25),
    "W1": (0.0, 0.18116, 0.25),
    "O1": (0.2124, 0.1000, 0.9432),
    "O2": (0.2498, 0.3780, 0.3937),
}


def state(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine_to_stable(project, rounds=8):
    history = []
    valid = True
    for number in range(1, rounds + 1):
        try:
            project.refine(makeBack=False)
        except Exception as error:
            history.append({"round": number, "error": repr(error)})
            valid = False
            break
        current = state(project)
        row = {
            "round": number,
            "rwp": float(project.histograms()[0].get_wR()),
            "converged": bool(current.get("converged")),
            "max_shift_esd": current.get("Max shft/sig"),
            "svd": current.get("SVD0", 0),
            "message": current.get("msg"),
        }
        history.append(row)
        print("REMOVAL_ROUND=" + json.dumps(row, default=str, sort_keys=True))
        message = str(current.get("msg", "") or "").lower()
        if current.get("SVD0", 0) or "dropped" in message or "error" in message:
            valid = False
            break
        shift = abs(float(current.get("Max shft/sig") or math.inf))
        if current.get("converged") and shift < 0.05:
            break
    if not history or not history[-1].get("converged"):
        valid = False
    elif abs(float(history[-1].get("max_shift_esd") or math.inf)) >= 0.05:
        valid = False
    return valid, history


def binned_rwp(hist):
    x, y, weights, calc = hist.data["data"][1][:4]
    answer = []
    for low in range(10, 100, 10):
        use = (x >= low) & (x < low + 10)
        answer.append({
            "range": f"{low}-{low + 10}",
            "rwp": 100.0 * math.sqrt(
                float(np.sum(weights[use] * (y[use] - calc[use]) ** 2))
                / float(np.sum(weights[use] * y[use] ** 2))
            ),
        })
    return answer


def modify(project, mode):
    hist = project.histograms()[0]
    phases = project.phases()
    primary = phases[0]
    primary_hap = primary.data["Histograms"][hist.name]
    if mode == "minor_cell_reference":
        if len(phases) < 2:
            raise ValueError("minor-cell branch requires a second phase")
        phases[1].data["General"]["Cell"][:] = [
            False, 9.41, 9.41, 9.41, 90.0, 90.0, 90.0, 9.41 ** 3
        ]
    elif mode == "roughness":
        hist.SampleParameters["SurfRoughA"][:] = [0.0, False]
        hist.SampleParameters["SurfRoughB"][:] = [0.0, False]
    elif mode == "primary_size":
        primary_hap["Size"][1][0] = 1000.0
        primary_hap["Size"][2][0] = False
    elif mode == "profile_v":
        hist.InstrumentParameters["V"][1] = -2.0
        hist.InstrumentParameters["V"][2] = False
    elif mode == "primary_coordinates":
        for atom in primary.atoms():
            atom.coordinates = REFERENCE_MNWO4_COORDS[atom.label]
            atom.refinement_flags = atom.refinement_flags.replace("X", "") or " "
    elif mode == "sample_shift":
        hist.SampleParameters["Shift"][:] = [0.0, False]
    elif mode == "minor_scale":
        if len(phases) < 2:
            raise ValueError("minor-scale branch requires a second phase")
        minor_hap = phases[1].data["Histograms"][hist.name]
        minor_hap["Scale"][:] = [1.0e-12, False]
    else:
        raise ValueError(mode)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument(
        "mode",
        choices=(
            "minor_cell_reference",
            "roughness",
            "primary_size",
            "profile_v",
            "primary_coordinates",
            "sample_shift",
            "minor_scale",
        ),
    )
    args = parser.parse_args()
    args.destination.parent.mkdir(parents=True, exist_ok=True)

    project = G2sc.G2Project(str(args.source.resolve()))
    modify(project, args.mode)
    project.set_Controls("cycles", 12)
    start = args.destination.with_name(args.destination.stem + "_start.gpx")
    project.save(str(start.resolve()))
    valid, history = refine_to_stable(project)
    project.save(str(args.destination.resolve()))
    hist = project.histograms()[0]
    try:
        fractions = {
            key: {"value": val[0], "esd": val[1]}
            for key, val in hist.ComputeMassFracs().items()
        }
    except Exception as error:
        fractions = {"error": repr(error)}
    result = {
        "mode": args.mode,
        "valid": valid,
        "project": str(args.destination.resolve()),
        "rwp": float(hist.get_wR()),
        "binned_rwp": binned_rwp(hist),
        "history": history,
        "mass_fractions": fractions,
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "cells": {phase.name: phase.get_cell_and_esd() for phase in project.phases()},
    }
    print("REMOVAL_RESULT=" + json.dumps(result, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
