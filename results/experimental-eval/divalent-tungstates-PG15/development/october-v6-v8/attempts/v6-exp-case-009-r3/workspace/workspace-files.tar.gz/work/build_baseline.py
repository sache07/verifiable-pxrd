#!/usr/bin/env python3
"""Build the single-phase MnWO4 inventory baseline and refine background/scale/cell."""

from pathlib import Path
import json
import shutil

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
BRANCH = WORK / "branches"
BRANCH.mkdir(parents=True, exist_ok=True)


def covariance(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def run_to_stable(project, label, max_rounds=8, require_stable=True):
    """Refine repeatedly until GSAS-II reports a small maximum shift/esd."""
    history = []
    for cycle in range(max_rounds):
        project.refine(makeBack=False)
        status = covariance(project)
        row = {
            "round": cycle + 1,
            "rwp": float(project.histograms()[0].get_wR()),
            "converged": status.get("converged"),
            "max_shift_esd": status.get("Max shft/sig"),
            "svd": status.get("SVD0"),
            "message": status.get("msg"),
        }
        history.append(row)
        print(label, json.dumps(row, default=str))
        msg = str(status.get("msg", "") or "").lower()
        if status.get("SVD0", 0) or "dropped" in msg or "error" in msg:
            raise RuntimeError(f"unstable refinement in {label}: {row}")
        if status.get("converged") and float(status.get("Max shft/sig") or 0.0) < 0.05:
            break
    project.save(str(BRANCH / f"{label}.gpx"))
    if require_stable:
        status = covariance(project)
        if not status.get("converged") or float(status.get("Max shft/sig") or 1e9) >= 0.05:
            raise RuntimeError(f"did not converge in {label}: {history[-1]}")
    return history


def main():
    candidate = WORK / "candidate_MnWO4.cif"
    project = G2sc.G2Project(newgpx=str(BRANCH / "00_import.gpx"))
    hist = project.add_powder_histogram(
        str(WORK / "pattern.xye"),
        str(WORK / "cu_ka1ka2.instprm"),
        fmthint="xye",
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    phase = project.add_phase(
        str(candidate), phasename="MnWO4", histograms=[hist], fmthint="CIF"
    )
    # For a one-pattern Rietveld fit the phase HAP scales carry composition;
    # keep the redundant histogram-wide scale fixed to avoid exact correlation.
    hist.SampleParameters["Scale"][:] = [1.0, False]

    # A smooth, positive starting background sampled at evenly spaced knots.
    x, y = hist.data["data"][1][0], hist.data["data"][1][1]
    robust = percentile_filter(y, percentile=8, size=501, mode="nearest")
    robust = gaussian_filter1d(robust, sigma=120)
    n_background = 20
    knots = np.linspace(10.0, 100.0, n_background)
    coeffs = np.interp(knots, x, robust).tolist()
    hist.set_refinements(
        {
            "Background": {
                "type": "lin interpolate",
                "refine": True,
                "no. coeffs": n_background,
                "coeffs": coeffs,
            }
        }
    )
    phase.set_HAP_refinements({"Scale": True})
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.save()

    # This short linear-parameter pass is only an initialization checkpoint;
    # centroid mismatch prevents it from being a scientifically stable model.
    project.set_Controls("cycles", 3)
    histories = {"01_background_scale": run_to_stable(
        project, "01_background_scale", max_rounds=1, require_stable=False
    )}

    phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 12)
    histories["02_inventory_baseline"] = run_to_stable(project, "02_inventory_baseline")
    project.save(str(WORK / "inventory_baseline.gpx"))

    print("BASELINE_SUMMARY=" + json.dumps({
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "cell": phase.get_cell_and_esd(),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "histories": histories,
    }, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
