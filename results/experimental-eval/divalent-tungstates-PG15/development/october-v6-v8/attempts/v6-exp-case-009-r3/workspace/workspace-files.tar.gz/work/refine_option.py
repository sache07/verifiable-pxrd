#!/usr/bin/env python3
"""Refine one optional GSAS-II term in a matched project branch."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def covariance_state(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine_to_stable(project, rounds=8):
    history = []
    valid = True
    for number in range(1, rounds + 1):
        try:
            project.refine(makeBack=False)
        except Exception as error:
            history.append({"round": number, "error": repr(error)})
            valid = False
            break
        state = covariance_state(project)
        row = {
            "round": number,
            "rwp": float(project.histograms()[0].get_wR()),
            "converged": bool(state.get("converged")),
            "max_shift_esd": state.get("Max shft/sig"),
            "svd": state.get("SVD0", 0),
            "message": state.get("msg"),
        }
        history.append(row)
        print("OPTION_ROUND=" + json.dumps(row, default=str, sort_keys=True))
        message = str(state.get("msg", "") or "").lower()
        if state.get("SVD0", 0) or "dropped" in message or "error" in message:
            valid = False
            break
        shift = abs(float(state.get("Max shft/sig") or math.inf))
        if state.get("converged") and shift < 0.05:
            break
    if not history or not history[-1].get("converged"):
        valid = False
    elif abs(float(history[-1].get("max_shift_esd") or math.inf)) >= 0.05:
        valid = False
    return valid, history


def binned_rwp(hist):
    x, y, weights, calc = hist.data["data"][1][:4]
    answer = []
    for low in range(10, 100, 10):
        use = (x >= low) & (x < low + 10)
        answer.append({
            "range": f"{low}-{low + 10}",
            "rwp": 100.0 * math.sqrt(
                float(np.sum(weights[use] * (y[use] - calc[use]) ** 2))
                / float(np.sum(weights[use] * y[use] ** 2))
            ),
        })
    return answer


def configure(project, option, axis=None, phase_index=0):
    hist = project.histograms()[0]
    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][hist.name]
    if option == "axial":
        hist.InstrumentParameters["SH/L"][2] = True
    elif option == "size":
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True}})
    elif option == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    elif option == "coordinates":
        phase.set_refinements({"Atoms": {"all": "X"}})
    elif option == "adp":
        phase.set_refinements({"Atoms": {"all": "U"}})
    elif option == "coordinates_adp":
        phase.set_refinements({"Atoms": {"all": "XU"}})
    elif option == "texture":
        if axis is None:
            raise ValueError("texture requires --axis h k l")
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = [int(value) for value in axis]
        phase.set_HAP_refinements({"Pref.Ori.": True})
    else:
        raise ValueError(option)


def parameter_summary(project):
    hist = project.histograms()[0]
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append({
            "name": phase.name,
            "cell": phase.get_cell_and_esd(),
            "scale": hap["Scale"],
            "size": hap.get("Size"),
            "mustrain": hap.get("Mustrain"),
            "preferred_orientation": hap.get("Pref.Ori."),
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": atom.coordinates,
                    "uiso": atom.uiso if atom.adp_flag == "I" else None,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        })
    return {
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "phases": phases,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument(
        "option",
        choices=("axial", "size", "strain", "coordinates", "adp", "coordinates_adp", "texture"),
    )
    parser.add_argument("--axis", nargs=3, type=int)
    parser.add_argument("--phase", type=int, default=0)
    args = parser.parse_args()
    args.destination.parent.mkdir(parents=True, exist_ok=True)

    project = G2sc.G2Project(str(args.source.resolve()))
    if args.phase < 0 or args.phase >= len(project.phases()):
        raise IndexError(f"phase index {args.phase} is out of range")
    configure(project, args.option, args.axis, args.phase)
    project.set_Controls("cycles", 12)
    start = args.destination.with_name(args.destination.stem + "_start.gpx")
    project.save(str(start.resolve()))
    valid, history = refine_to_stable(project)
    project.save(str(args.destination.resolve()))

    hist = project.histograms()[0]
    summary = parameter_summary(project)
    if args.option == "axial" and float(hist.InstrumentParameters["SH/L"][1]) <= 0.0005:
        valid = False
    if args.option == "size":
        size = float(summary["phases"][args.phase]["size"][1][0])
        valid = valid and math.isfinite(size) and size > 0.0
    if args.option == "strain":
        strain = float(summary["phases"][args.phase]["mustrain"][1][0])
        valid = valid and math.isfinite(strain) and strain > 0.0
    if args.option == "texture":
        ratio = float(summary["phases"][args.phase]["preferred_orientation"][1])
        valid = valid and math.isfinite(ratio) and ratio > 0.0

    result = {
        "option": args.option,
        "phase_index": args.phase,
        "source": str(args.source.resolve()),
        "project": str(args.destination.resolve()),
        "valid": valid,
        "rwp": float(hist.get_wR()),
        "residuals": hist.residuals,
        "binned_rwp": binned_rwp(hist),
        "history": history,
        "parameters": summary,
    }
    print("OPTION_RESULT=" + json.dumps(result, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
