#!/usr/bin/env python3
"""Screen one-parameter March-Dollase axes one phase at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import refinement_work as rw


AXES = {
    "MgWO4": ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1)),
    "MgO": ((1, 0, 0), (1, 1, 0), (1, 1, 1)),
    "WO3-monoclinic": ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 0, 1)),
    "WO3-triclinic": ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 0, 1)),
}


def clear_texture(project: G2sc.G2Project) -> None:
    histogram = project.histograms()[0]
    for phase in project.phases():
        po = phase.data["Histograms"][histogram.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--phases", nargs="+")
    parser.add_argument("--preserve-existing", action="store_true")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    source = G2sc.G2Project(str(args.source.resolve()))
    phase_names = [phase.name for phase in source.phases()]
    selected = args.phases or phase_names
    reports = []
    for phase_name in selected:
        if phase_name not in phase_names:
            raise SystemExit(f"unknown phase: {phase_name}")
        for axis in AXES.get(phase_name, ((1, 0, 0), (0, 1, 0), (0, 0, 1))):
            axis_name = "".join(str(value).replace("-", "m") for value in axis)
            safe_name = phase_name.replace(" ", "_")
            destination = args.output_dir / f"{safe_name}-MD-{axis_name}.gpx"
            project = G2sc.G2Project(
                str(args.source.resolve()), newgpx=str(destination.resolve())
            )
            if not args.preserve_existing:
                clear_texture(project)
            histogram = project.histograms()[0]
            phase = project.phase(phase_name)
            po = phase.data["Histograms"][histogram.name]["Pref.Ori."]
            po[3] = list(axis)
            po[2] = True
            project.save(str(destination))
            result = rw.stable_refine(
                project, f"{phase_name}-MD-{axis_name}", repeats=5
            )
            project.save(str(destination))
            report = {
                "phase": phase_name,
                "axis": axis,
                "march_dollase": po,
                "result": result,
                "rwp_percent": float(histogram.get_wR()),
                "fractions": histogram.ComputeMassFracs(),
                "output": str(destination),
            }
            reports.append(report)
            print("TEXTURE_BRANCH", json.dumps(rw.json_safe(report), sort_keys=True))
    (args.output_dir / "texture-branches.json").write_text(
        json.dumps(rw.json_safe(reports), indent=2, sort_keys=True), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
