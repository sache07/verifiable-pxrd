#!/usr/bin/env python3
"""Run matched minimal global profile branches from one stable GPX."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

import refinement_work as rw


BRANCHES = {
    "W": ("W",),
    "UW": ("U", "W"),
    "WX": ("W", "X"),
    "WY": ("W", "Y"),
    "UWX": ("U", "W", "X"),
    "UWY": ("U", "W", "Y"),
    "UVW": ("U", "V", "W"),
    "UVWXY": ("U", "V", "W", "X", "Y"),
}


def profile_correlations(project: G2sc.G2Project) -> list[dict]:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    profile_names = {":0:" + key for key in ("U", "V", "W", "X", "Y", "Z")}
    selected = [i for i, name in enumerate(names) if name in profile_names]
    output = []
    for offset, left in enumerate(selected):
        for right in selected[offset + 1 :]:
            denominator = math.sqrt(max(matrix[left, left], 0.0)) * math.sqrt(
                max(matrix[right, right], 0.0)
            )
            correlation = matrix[left, right] / denominator if denominator else math.nan
            output.append(
                {
                    "left": names[left],
                    "right": names[right],
                    "correlation": float(correlation),
                }
            )
    return output


def width_range(histogram: G2sc.G2PwdrData) -> dict:
    instrument = histogram.InstrumentParameters
    lower, upper = histogram.data["Limits"][1]
    two_theta = np.linspace(lower, upper, 1000)
    theta = np.radians(two_theta / 2.0)
    tangent = np.tan(theta)
    value = lambda key: float(instrument[key][1])
    sigma = value("U") * tangent**2 + value("V") * tangent + value("W")
    gamma = value("X") / np.cos(theta) + value("Y") * tangent + value("Z")
    return {
        "minimum_sigma_centideg2": float(np.min(sigma)),
        "maximum_sigma_centideg2": float(np.max(sigma)),
        "minimum_gamma_centideg": float(np.min(gamma)),
        "maximum_gamma_centideg": float(np.max(gamma)),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("branches", nargs="+", choices=sorted(BRANCHES))
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    reports = []
    for branch in args.branches:
        destination = args.output_dir / f"profile-{branch}.gpx"
        project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(destination.resolve()))
        histogram = project.histograms()[0]
        starts = {"U": 10.0, "V": 0.0, "W": 25.0, "X": 0.0, "Y": 0.0, "Z": 0.0}
        for key, start in starts.items():
            histogram.InstrumentParameters[key][1] = start
            histogram.InstrumentParameters[key][2] = key in BRANCHES[branch]
        project.save(str(destination))
        result = rw.stable_refine(project, f"profile-{branch}", repeats=10)
        project.save(str(destination))
        correlations = profile_correlations(project)
        report = {
            "branch": branch,
            "terms": BRANCHES[branch],
            "result": result,
            "rwp_percent": float(histogram.get_wR()),
            "profile": {
                key: histogram.InstrumentParameters[key]
                for key in ("U", "V", "W", "X", "Y", "Z")
            },
            "width_range": width_range(histogram),
            "profile_correlations": correlations,
            "maximum_absolute_profile_correlation": max(
                (abs(item["correlation"]) for item in correlations), default=None
            ),
            "fractions": histogram.ComputeMassFracs(),
            "output": str(destination),
        }
        reports.append(report)
        print("PROFILE_BRANCH", json.dumps(rw.json_safe(report), sort_keys=True))
    summary = args.output_dir / "profile-branches.json"
    summary.write_text(
        json.dumps(rw.json_safe(reports), indent=2, sort_keys=True), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
