#!/usr/bin/env python3
"""Build and refine matched GSAS-II screening models for this dataset."""

from __future__ import annotations

import argparse
import json
import math
import pickle
import shutil
import time
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)

CANDIDATES = {
    "MgWO4": COD_ROOT / "9/01/39/9013902.cif",
    "MgO": COD_ROOT / "9/00/04/9000499.cif",
    "WO3-triclinic": COD_ROOT / "2/10/62/2106293.cif",
    "WO3-monoclinic": COD_ROOT / "2/31/10/2311041.cif",
    "WO3-HP-monoclinic": COD_ROOT / "1/56/35/1563541.cif",
    "WO3-orthorhombic": COD_ROOT / "2/10/73/2107312.cif",
    "WO3-hexagonal": COD_ROOT / "1/00/40/1004057.cif",
}


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, label: str, repeats: int = 10) -> dict:
    """Run enough short refinements to converge and fail on bad LSQ states."""
    result = {"label": label, "valid": False, "iterations": 0}
    for iteration in range(1, repeats + 1):
        try:
            project.refine()
        except (pickle.UnpicklingError, EOFError):
            # On the managed overlay filesystem a just-replaced GPX can very
            # occasionally be observed before all pickle records are visible.
            # Rewrite and retry once; this does not alter the model.
            time.sleep(0.25)
            project.save()
            time.sleep(0.25)
            project.refine()
        status = covariance_status(project)
        result["iterations"] = iteration
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "error" in message:
            result["status"] = status
            return result
        maximum = float(status.get("Max shft/sig") or math.inf)
        if status.get("converged") and maximum < 0.10:
            result["valid"] = True
            break
    status = covariance_status(project)
    result["status"] = {
        key: status.get(key)
        for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp", "GOF")
    }
    result["rwp_percent"] = float(project.histograms()[0].get_wR())
    return result


def initial_background(histogram: G2sc.G2PwdrData, terms: int = 8) -> list[float]:
    """Robust low-envelope Chebyshev starting coefficients."""
    x = np.asarray(histogram.getdata("X"), dtype=float)
    y = np.asarray(histogram.getdata("Yobs"), dtype=float)
    width = 2.0
    centers = np.arange(x[0] + width / 2.0, x[-1], width)
    anchors = []
    kept = []
    for center in centers:
        subset = y[(x >= center - width / 2.0) & (x < center + width / 2.0)]
        if subset.size:
            kept.append(center)
            anchors.append(float(np.percentile(subset, 5.0)))
    transformed = 2.0 * (np.asarray(kept) - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(
        transformed, np.asarray(anchors), terms - 1
    ).tolist()


def save_checkpoint(project: G2sc.G2Project, output: Path, label: str) -> Path:
    project.save(str(output))
    checkpoint = output.with_name(f"{output.stem}-{label}.gpx")
    shutil.copy2(output, checkpoint)
    return checkpoint


def project_summary(project: G2sc.G2Project, history: list[dict]) -> dict:
    histogram = project.histograms()[0]
    try:
        mass_fractions = histogram.ComputeMassFracs()
    except Exception as error:
        mass_fractions = {"error": repr(error)}
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "composition": phase.composition,
            "density": phase.density,
            "scale": hap["Scale"],
            "size": hap.get("Size"),
            "mustrain": hap.get("Mustrain"),
        }
    return {
        "rwp_percent": float(histogram.get_wR()),
        "residuals": histogram.residuals,
        "mass_fractions": mass_fractions,
        "instrument": histogram.InstrumentParameters,
        "sample": histogram.SampleParameters,
        "background": histogram.Background,
        "phases": phases,
        "convergence": covariance_status(project),
        "history": history,
    }


def build(output: Path, phase_names: list[str]) -> G2sc.G2Project:
    project = G2sc.G2Project(newgpx=str(output))
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    histogram = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    histogram.SampleParameters["Scale"][:] = [1.0, False]
    histogram.SampleParameters["Shift"][:] = [-600.0, False]
    histogram.SampleParameters["Gonio. radius"] = 200.0
    instrument = histogram.InstrumentParameters
    instrument["U"][1:] = [10.0, False]
    instrument["V"][1:] = [0.0, False]
    instrument["W"][1:] = [25.0, False]
    instrument["X"][1:] = [2.0, False]
    instrument["Y"][1:] = [2.0, False]
    instrument["Z"][1:] = [0.0, False]
    coefficients = initial_background(histogram, terms=8)
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(coefficients),
                "coeffs": coefficients,
                "refine": True,
            }
        }
    )
    starts = {"MgWO4": 1.0, "MgO": 0.1}
    for phase_name in phase_names:
        phase = project.add_phase(
            str(CANDIDATES[phase_name]),
            phasename=phase_name,
            histograms=[histogram],
            fmthint="CIF",
        )
        phase.HAPvalue("Scale", starts.get(phase_name, 0.2))
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": False})
        phase.set_refinements({"Atoms": {"all": ""}})
    project.save(str(output))
    return project


def run(output: Path, phase_names: list[str]) -> dict:
    output.parent.mkdir(parents=True, exist_ok=True)
    project = build(output, phase_names)
    history: list[dict] = []

    save_checkpoint(project, output, "stable-import")
    history.append(stable_refine(project, "background-scales"))
    if not history[-1]["valid"]:
        project.save(str(output))
        return project_summary(project, history)

    save_checkpoint(project, output, "stable-scales")
    histogram = project.histograms()[0]
    histogram.SampleParameters["Shift"][1] = True
    history.append(stable_refine(project, "sample-shift"))
    if not history[-1]["valid"]:
        project.save(str(output))
        return project_summary(project, history)

    save_checkpoint(project, output, "stable-angular")
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    history.append(stable_refine(project, "cells"))
    if not history[-1]["valid"]:
        project.save(str(output))
        return project_summary(project, history)

    save_checkpoint(project, output, "stable-cells")
    for parameter in ("U", "V", "W", "X", "Y"):
        histogram.InstrumentParameters[parameter][2] = True
    history.append(stable_refine(project, "global-profile"))
    project.save(str(output))
    return project_summary(project, history)


def json_safe(value):
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    return value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+", choices=sorted(CANDIDATES))
    args = parser.parse_args()
    summary = run(args.output.resolve(), args.phases)
    summary_path = args.output.with_suffix(".json")
    summary_path.write_text(
        json.dumps(json_safe(summary), indent=2, sort_keys=True), encoding="utf-8"
    )
    print("SCREEN_RESULT", json.dumps(json_safe(summary), sort_keys=True))


if __name__ == "__main__":
    main()
