#!/usr/bin/env python3
"""Freeze the selected GSAS-II state and export the submission artifacts."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2sc

from learned.profile_regeneration import regenerate_profile
import refinement_work as rw


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/final-checks/coordinates-angular.gpx"
PROJECT = ROOT / "final.gpx"
CIF_PATHS = {
    "MgWO4": ROOT / "phase_MgWO4.cif",
    "MgO": ROOT / "phase_MgO.cif",
    "WO3-monoclinic": ROOT / "phase_WO3_monoclinic.cif",
}


def high_correlations(project: G2sc.G2Project, threshold: float = 0.90) -> list[dict]:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    output = []
    for left in range(len(names)):
        for right in range(left):
            denominator = np.sqrt(max(matrix[left, left], 0.0)) * np.sqrt(
                max(matrix[right, right], 0.0)
            )
            if not denominator:
                continue
            value = float(matrix[left, right] / denominator)
            if abs(value) >= threshold:
                output.append(
                    {"left": names[left], "right": names[right], "correlation": value}
                )
    return sorted(output, key=lambda item: abs(item["correlation"]), reverse=True)


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(PROJECT))
    project.save(str(PROJECT))
    regenerate_profile(PROJECT)
    project = G2sc.G2Project(str(PROJECT))
    histogram = project.histograms()[0]

    for phase in project.phases():
        phase.export_CIF(str(CIF_PATHS[phase.name]), quickmode=True)

    arrays = {
        key: np.asarray(histogram.getdata(key), dtype=float)
        for key in ("X", "Yobs", "Ycalc", "Residual", "Background", "Yweight")
    }
    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        for row in zip(
            arrays["X"],
            arrays["Yobs"],
            arrays["Ycalc"],
            arrays["Residual"],
            arrays["Background"],
        ):
            writer.writerow([f"{value:.12g}" for value in row])

    covariance = project.data["Covariance"]["data"]
    rvalues = covariance["Rvals"]
    fractions = histogram.ComputeMassFracs()
    residual = arrays["Residual"]
    # List separated, prominent positive residual maxima for the scientific
    # report; these are diagnostic, not extra modeled phases.
    noise = float(np.median(np.abs(residual - np.median(residual))) / 0.67448975)
    indices, properties = find_peaks(
        residual, prominence=max(5.0 * noise, 1.0), distance=5
    )
    order = indices[np.argsort(residual[indices])[::-1]][:15]

    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        space_group = phase.data["General"]["SGData"]["SpGrp"].strip()
        phases[phase.name] = {
            "cif_path": CIF_PATHS[phase.name].name,
            "composition": phase.composition,
            "space_group": space_group,
            "cell": phase.get_cell(),
            "density_g_cm3": phase.density,
            "weight_fraction": fractions[phase.name][0],
            "weight_fraction_esd": fractions[phase.name][1],
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": atom.coordinates,
                    "occupancy": atom.occupancy,
                    "uiso_A2": atom.uiso,
                    "refinement_flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }

    summary = {
        "source_project": str(SOURCE.relative_to(ROOT)),
        "final_project": PROJECT.name,
        "profile": "fit.csv",
        "point_count": int(arrays["X"].size),
        "fit_statistics": {
            "Rwp_percent": float(histogram.residuals["wR"]),
            "Rp_percent": float(histogram.residuals["R"]),
            "Rexp_percent": float(histogram.residuals["wRmin"]),
            "GOF": float(rvalues["GOF"]),
            "chi_squared": float(rvalues["chisq"]),
            "observations": int(rvalues["Nobs"]),
            "variables": int(rvalues["Nvars"]),
            "max_shift_over_esd": float(rvalues["Max shft/sig"]),
            "svd_dropped_variables": int(rvalues.get("SVD0", 0)),
            "converged": bool(rvalues.get("converged", False)),
        },
        "phases": phases,
        "instrument": histogram.InstrumentParameters,
        "sample": histogram.SampleParameters,
        "high_correlations_abs_ge_0.90": high_correlations(project),
        "residual_noise_estimate_counts": noise,
        "largest_positive_residual_maxima": [
            {
                "two_theta_deg": float(arrays["X"][index]),
                "difference_counts": float(residual[index]),
            }
            for index in order
        ],
    }
    (ROOT / ".tmp/final_export_summary.json").write_text(
        json.dumps(rw.json_safe(summary), indent=2, sort_keys=True), encoding="utf-8"
    )
    print("FINAL_EXPORT", json.dumps(rw.json_safe(summary), sort_keys=True))


if __name__ == "__main__":
    main()
