#!/usr/bin/env python3
"""Matched late-stage branches for the final PXRD model.

This script keeps every accepted nuisance term fixed in scope while changing
only the hypothesis named by each branch. It is intentionally specific to the
three-phase MgO/WO3 data set in this workspace.
"""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

import refinement_work as rw


def correlations(project: G2sc.G2Project, threshold: float = 0.90) -> list[dict]:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = covariance.get("covMatrix")
    if matrix is None:
        return []
    matrix = np.asarray(matrix, dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    output = []
    for left in range(len(names)):
        for right in range(left):
            denominator = np.sqrt(max(matrix[left, left], 0.0)) * np.sqrt(
                max(matrix[right, right], 0.0)
            )
            if denominator:
                value = float(matrix[left, right] / denominator)
                if abs(value) >= threshold:
                    output.append(
                        {"left": names[left], "right": names[right], "correlation": value}
                    )
    return sorted(output, key=lambda item: abs(item["correlation"]), reverse=True)


def residual_bins(project: G2sc.G2Project) -> list[dict]:
    histogram = project.histograms()[0]
    x = np.asarray(histogram.getdata("X"), dtype=float)
    observed = np.asarray(histogram.getdata("Yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    weights = np.asarray(histogram.getdata("Yweight"), dtype=float)
    output = []
    for lower in (10.0, 25.0, 40.0, 55.0, 70.0, 85.0):
        upper = min(lower + 15.0, 100.1)
        mask = (x >= lower) & (x < upper)
        numerator = np.sum(weights[mask] * (observed[mask] - calculated[mask]) ** 2)
        denominator = np.sum(weights[mask] * observed[mask] ** 2)
        output.append(
            {
                "lower_deg": lower,
                "upper_deg": upper,
                "rwp_percent": float(100.0 * np.sqrt(numerator / denominator)),
                "mean_difference_counts": float(np.mean(observed[mask] - calculated[mask])),
            }
        )
    return output


def report(project: G2sc.G2Project, result: dict, output: Path) -> dict:
    histogram = project.histograms()[0]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return {
        "output": str(output),
        "result": result,
        "rwp_percent": float(histogram.get_wR()),
        "residuals": histogram.residuals,
        "fractions": histogram.ComputeMassFracs(),
        "instrument": histogram.InstrumentParameters,
        "sample": histogram.SampleParameters,
        "phases": phases,
        "correlations_abs_ge_0.90": correlations(project),
        "residual_bins": residual_bins(project),
    }


def copy_mature_settings(
    reference: G2sc.G2Project, target: G2sc.G2Project, wo3_name: str
) -> None:
    source_histogram = reference.histograms()[0]
    histogram = target.histograms()[0]
    histogram.Background[:] = copy.deepcopy(source_histogram.Background)
    histogram.SampleParameters["Shift"] = copy.deepcopy(
        source_histogram.SampleParameters["Shift"]
    )
    for key in ("U", "V", "W", "X", "Y", "Z", "Polariz.", "SH/L", "Zero"):
        histogram.InstrumentParameters[key][:] = copy.deepcopy(
            source_histogram.InstrumentParameters[key]
        )
    for phase in target.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Atoms": {"all": ""}})
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        po = hap["Pref.Ori."]
        po[0:4] = ["MD", 1.0, False, [0, 0, 1]]

    for phase_name in ("MgWO4", "MgO"):
        source_phase = reference.phase(phase_name)
        target_phase = target.phase(phase_name)
        source_hap = source_phase.data["Histograms"][source_histogram.name]
        target_hap = target_phase.data["Histograms"][histogram.name]
        target_hap["Scale"][0] = source_hap["Scale"][0]

    mgwo4_hap = target.phase("MgWO4").data["Histograms"][histogram.name]
    mgwo4_hap["Mustrain"][0] = "isotropic"
    mgwo4_hap["Mustrain"][1][0] = 1368.75
    mgwo4_hap["Mustrain"][2][0] = True
    mgwo4_hap["Pref.Ori."][0:4] = ["MD", 1.08368, True, [1, 1, 0]]

    wo3_hap = target.phase(wo3_name).data["Histograms"][histogram.name]
    wo3_hap["Mustrain"][0] = "isotropic"
    wo3_hap["Mustrain"][1][0] = 2610.52
    wo3_hap["Mustrain"][2][0] = True
    wo3_hap["Scale"][0] = 4.23


def run_triclinic(reference_path: Path, source_path: Path, output: Path) -> dict:
    reference = G2sc.G2Project(str(reference_path.resolve()))
    project = G2sc.G2Project(str(source_path.resolve()), newgpx=str(output.resolve()))
    copy_mature_settings(reference, project, "WO3-triclinic")
    project.save(str(output))
    result = rw.stable_refine(project, "mature-triclinic", repeats=12)
    project.save(str(output))
    return report(project, result, output)


def run_triclinic_after_coordinates(
    reference_path: Path, triclinic_path: Path, output: Path
) -> dict:
    """Retest triclinic WO3 after accepting MgWO4 coordinate refinement."""
    reference = G2sc.G2Project(str(reference_path.resolve()))
    project = G2sc.G2Project(str(triclinic_path.resolve()), newgpx=str(output.resolve()))
    source_phase = reference.phase("MgWO4")
    target_phase = project.phase("MgWO4")
    for source_atom in source_phase.atoms():
        target_atom = target_phase.atom(source_atom.label)
        target_atom.coordinates = source_atom.coordinates
        target_atom.refinement_flags = "X"
    project.save(str(output))
    result = rw.stable_refine(project, "mature-triclinic-after-coordinates", repeats=12)
    project.save(str(output))
    return report(project, result, output)


def run_coordinate_branch(source_path: Path, output: Path) -> dict:
    project = G2sc.G2Project(str(source_path.resolve()), newgpx=str(output.resolve()))
    project.phase("MgWO4").set_refinements({"Atoms": {"all": "X"}})
    project.save(str(output))
    result = rw.stable_refine(project, "MgWO4-coordinates", repeats=12)
    project.save(str(output))
    return report(project, result, output)


def run_removal(source_path: Path, output: Path, term: str) -> dict:
    project = G2sc.G2Project(str(source_path.resolve()), newgpx=str(output.resolve()))
    histogram = project.histograms()[0]
    if term == "polarization":
        histogram.InstrumentParameters["Polariz."][1:] = [0.5, False]
    elif term == "MgWO4-strain":
        hap = project.phase("MgWO4").data["Histograms"][histogram.name]
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = False
    elif term == "WO3-strain":
        wo3 = next(phase for phase in project.phases() if phase.name.startswith("WO3"))
        hap = wo3.data["Histograms"][histogram.name]
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = False
    elif term == "MgWO4-texture":
        hap = project.phase("MgWO4").data["Histograms"][histogram.name]
        hap["Pref.Ori."][1:3] = [1.0, False]
    elif term == "X":
        histogram.InstrumentParameters["X"][1:] = [0.0, False]
    else:
        raise ValueError(term)
    project.save(str(output))
    result = rw.stable_refine(project, f"remove-{term}", repeats=10)
    project.save(str(output))
    return report(project, result, output)


def run_leave_one_out(source_path: Path, output: Path, phase_name: str) -> dict:
    project = G2sc.G2Project(str(source_path.resolve()), newgpx=str(output.resolve()))
    histogram = project.histograms()[0]
    # Keep the mature nuisance model numerically identical and re-optimize only
    # background and surviving phase scales. This is the least ambiguous
    # leave-one-out comparison and avoids letting the wrong phases distort their
    # cells/profile in an attempt to absorb the omitted pattern.
    for key, value in histogram.InstrumentParameters.items():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    histogram.SampleParameters["Shift"][1] = False
    for candidate in project.phases():
        candidate.set_refinements({"Cell": False, "Atoms": {"all": ""}})
        candidate_hap = candidate.data["Histograms"][histogram.name]
        candidate_hap["Size"][2] = [False] * len(candidate_hap["Size"][2])
        candidate_hap["Mustrain"][2] = [False] * len(candidate_hap["Mustrain"][2])
        candidate_hap["Pref.Ori."][2] = False
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"][:] = [0.0, False]
    project.save(str(output))
    result = rw.stable_refine(project, f"leave-out-{phase_name}", repeats=10)
    project.save(str(output))
    return report(project, result, output)


def run_target_microstructure(
    source_path: Path, output: Path, phase_name: str, term: str
) -> dict:
    """Replace the target phase's microstructure with one independent term."""
    project = G2sc.G2Project(str(source_path.resolve()), newgpx=str(output.resolve()))
    histogram = project.histograms()[0]
    hap = project.phase(phase_name).data["Histograms"][histogram.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    if term == "size":
        hap["Size"][2][0] = True
    elif term == "strain":
        hap["Mustrain"][2][0] = True
    else:
        raise ValueError(term)
    project.save(str(output))
    result = rw.stable_refine(project, f"{phase_name}-{term}-after-coordinates", repeats=10)
    project.save(str(output))
    return report(project, result, output)


def run_single_wavelength(source_path: Path, output: Path) -> dict:
    """Test the metadata's intended Cu K-alpha1-only interpretation."""
    project = G2sc.G2Project(str(source_path.resolve()), newgpx=str(output.resolve()))
    instrument = project.histograms()[0].InstrumentParameters
    wavelength = float(instrument["Lam1"][1])
    for key in ("Lam1", "Lam2", "I(L2)/I(L1)"):
        del instrument[key]
    instrument["Lam"] = [wavelength, wavelength, False]
    project.save(str(output))
    result = rw.stable_refine(project, "single-Cu-Kalpha1", repeats=12)
    project.save(str(output))
    return report(project, result, output)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--triclinic-source", type=Path)
    parser.add_argument(
        "--mode",
        choices=(
            "triclinic",
            "triclinic-after-coordinates",
            "coordinates",
            "microstructure",
            "wavelength",
            "removals",
            "leave-one-out",
            "all",
        ),
        default="all",
    )
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    reports = []
    if args.mode in ("triclinic", "all"):
        if args.triclinic_source is None:
            raise SystemExit("--triclinic-source is required")
        reports.append(
            run_triclinic(
                args.source,
                args.triclinic_source,
                args.output_dir / "mature-triclinic.gpx",
            )
        )
    if args.mode == "triclinic-after-coordinates":
        if args.triclinic_source is None:
            raise SystemExit("--triclinic-source is required")
        reports.append(
            run_triclinic_after_coordinates(
                args.source,
                args.triclinic_source,
                args.output_dir / "mature-triclinic-after-coordinates.gpx",
            )
        )
    if args.mode in ("coordinates", "all"):
        reports.append(
            run_coordinate_branch(args.source, args.output_dir / "MgWO4-coordinates.gpx")
        )
    if args.mode == "microstructure":
        for phase_name in ("MgWO4", "MgO", "WO3-monoclinic"):
            for term in ("size", "strain"):
                safe_name = phase_name.replace(" ", "_")
                reports.append(
                    run_target_microstructure(
                        args.source,
                        args.output_dir / f"{safe_name}-{term}.gpx",
                        phase_name,
                        term,
                    )
                )
    if args.mode == "wavelength":
        reports.append(
            run_single_wavelength(args.source, args.output_dir / "single-Kalpha1.gpx")
        )
    if args.mode in ("removals", "all"):
        for term in ("polarization", "MgWO4-strain", "WO3-strain", "MgWO4-texture", "X"):
            reports.append(
                run_removal(args.source, args.output_dir / f"remove-{term}.gpx", term)
            )
    if args.mode in ("leave-one-out", "all"):
        for phase_name in ("MgWO4", "MgO", "WO3-monoclinic"):
            reports.append(
                run_leave_one_out(
                    args.source,
                    args.output_dir / f"leave-out-{phase_name}.gpx",
                    phase_name,
                )
            )
    output_json = args.output_dir / "final-branch-checks.json"
    output_json.write_text(
        json.dumps(rw.json_safe(reports), indent=2, sort_keys=True), encoding="utf-8"
    )
    for item in reports:
        print("FINAL_BRANCH", json.dumps(rw.json_safe(item), sort_keys=True))


if __name__ == "__main__":
    main()
