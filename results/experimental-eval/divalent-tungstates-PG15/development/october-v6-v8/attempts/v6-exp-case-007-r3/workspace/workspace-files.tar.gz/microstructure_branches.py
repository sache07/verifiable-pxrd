#!/usr/bin/env python3
"""Screen isotropic size and microstrain one phase at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import refinement_work as rw


def clear_microstructure(project: G2sc.G2Project) -> None:
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})


def configure(
    project: G2sc.G2Project, phase_name: str, term: str, preserve_existing: bool
) -> None:
    if not preserve_existing:
        clear_microstructure(project)
    phase = project.phase(phase_name)
    histogram = project.histograms()[0]
    hap = phase.data["Histograms"][histogram.name]
    if term == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    elif term == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
    else:
        raise ValueError(term)


def parameter_correlations(project: G2sc.G2Project, suffix: str) -> list[dict]:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = covariance.get("covMatrix")
    if matrix is None:
        return []
    import numpy as np

    matrix = np.asarray(matrix, dtype=float)
    target = next((i for i, name in enumerate(names) if name.endswith(suffix)), None)
    if target is None or matrix.shape != (len(names), len(names)):
        return []
    output = []
    for index, name in enumerate(names):
        if index == target:
            continue
        denominator = np.sqrt(max(matrix[target, target], 0.0)) * np.sqrt(
            max(matrix[index, index], 0.0)
        )
        if denominator:
            correlation = float(matrix[target, index] / denominator)
            if abs(correlation) >= 0.8:
                output.append({"other": name, "correlation": correlation})
    return sorted(output, key=lambda item: abs(item["correlation"]), reverse=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--phases", nargs="+")
    parser.add_argument("--terms", nargs="+", choices=("size", "strain"), default=("size", "strain"))
    parser.add_argument("--preserve-existing", action="store_true")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    source = G2sc.G2Project(str(args.source.resolve()))
    phase_names = [phase.name for phase in source.phases()]
    if args.phases:
        missing = sorted(set(args.phases) - set(phase_names))
        if missing:
            raise SystemExit(f"unknown phase name(s): {missing}")
        phase_names = args.phases
    reports = []
    for phase_name in phase_names:
        for term in args.terms:
            safe_name = phase_name.replace(" ", "_")
            destination = args.output_dir / f"{safe_name}-{term}.gpx"
            project = G2sc.G2Project(
                str(args.source.resolve()), newgpx=str(destination.resolve())
            )
            configure(project, phase_name, term, args.preserve_existing)
            project.save(str(destination))
            result = rw.stable_refine(
                project, f"{phase_name}-{term}", repeats=5
            )
            project.save(str(destination))
            histogram = project.histograms()[0]
            phase = project.phase(phase_name)
            hap = phase.data["Histograms"][histogram.name]
            suffix = ":Size;i" if term == "size" else ":Mustrain;i"
            report = {
                "phase": phase_name,
                "term": term,
                "result": result,
                "rwp_percent": float(histogram.get_wR()),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "correlations_abs_ge_0.8": parameter_correlations(project, suffix),
                "fractions": histogram.ComputeMassFracs(),
                "output": str(destination),
            }
            reports.append(report)
            print("MICROSTRUCTURE_BRANCH", json.dumps(rw.json_safe(report), sort_keys=True))
    (args.output_dir / "microstructure-branches.json").write_text(
        json.dumps(rw.json_safe(reports), indent=2, sort_keys=True), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
