#!/usr/bin/env python3
"""Compare axial-divergence and intensity-envelope nuisance branches."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import refinement_work as rw


def configure(project: G2sc.G2Project, branch: str) -> None:
    histogram = project.histograms()[0]
    instrument = histogram.InstrumentParameters
    sample = histogram.SampleParameters
    instrument["SH/L"][2] = False
    instrument["Polariz."][2] = False
    sample["SurfRoughA"][1] = False
    sample["SurfRoughB"][1] = False
    if branch == "axial":
        instrument["SH/L"][1:] = [0.02, True]
    elif branch == "polarization":
        instrument["Polariz."][1:] = [0.5, True]
    elif branch == "roughness":
        sample["SurfRoughA"][:] = [0.5, True]
        sample["SurfRoughB"][:] = [0.1, True]
    elif branch == "none":
        pass
    else:
        raise ValueError(branch)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument(
        "branches", nargs="+", choices=("none", "axial", "polarization", "roughness")
    )
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    reports = []
    for branch in args.branches:
        destination = args.output_dir / f"nuisance-{branch}.gpx"
        project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(destination.resolve()))
        configure(project, branch)
        project.save(str(destination))
        result = rw.stable_refine(project, f"nuisance-{branch}", repeats=10)
        project.save(str(destination))
        histogram = project.histograms()[0]
        report = {
            "branch": branch,
            "result": result,
            "rwp_percent": float(histogram.get_wR()),
            "sh_over_l": histogram.InstrumentParameters["SH/L"],
            "polarization": histogram.InstrumentParameters["Polariz."],
            "surface_roughness_a": histogram.SampleParameters["SurfRoughA"],
            "surface_roughness_b": histogram.SampleParameters["SurfRoughB"],
            "fractions": histogram.ComputeMassFracs(),
            "output": str(destination),
        }
        reports.append(report)
        print("NUISANCE_BRANCH", json.dumps(rw.json_safe(report), sort_keys=True))
    (args.output_dir / "nuisance-branches.json").write_text(
        json.dumps(rw.json_safe(reports), indent=2, sort_keys=True), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
