#!/usr/bin/env python3
"""Run a matched atom, cell or displacement-parameter refinement branch."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    if len(sys.argv) != 5:
        raise SystemExit(
            "usage: structure_branch.py BASE.gpx OUTPUT.gpx PHASE_INDEX "
            "cell|x:LABEL[,LABEL]|u:LABEL[,LABEL]|xu:LABEL[,LABEL]|x:all|u:all|xu:all"
        )
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    phase_index = int(sys.argv[3])
    mode = sys.argv[4]
    stable = output.with_name(output.stem + "_stable_before.gpx")

    project = G2sc.G2Project(str(source), filename=str(stable))
    project.save(str(stable))
    project.save(str(output))
    phase = project.phases()[phase_index]
    if mode.lower() == "cell":
        phase.set_refinements({"Cell": True})
    else:
        kind, labels_text = mode.split(":", 1)
        kind = kind.lower()
        flags = {"x": "X", "u": "U", "xu": "XU"}[kind]
        if labels_text == "all":
            selections = {"all": flags}
        else:
            selections = {label: flags for label in labels_text.split(",")}
        phase.set_refinements({"Atoms": selections})

    project.set_Controls("cycles", 6)
    summaries = []
    for attempt in range(1, 7):
        project.refine()
        rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        item = {
            "attempt": attempt,
            "rwp_percent": float(project.histograms()[0].get_wR()),
            "converged": bool(rv.get("converged")),
            "max_shift_over_esd": rv.get("Max shft/sig"),
            "svd_dropped": rv.get("SVD0"),
            "message": rv.get("msg", ""),
        }
        summaries.append(item)
        print("STRUCTURE_STAGE=" + json.dumps(item, default=str), flush=True)
        if (
            rv.get("converged")
            and not rv.get("SVD0")
            and not rv.get("msg")
            and float(rv.get("Max shft/sig") or 0.0) < 0.05
        ):
            break
    project.save(str(output))
    histogram = project.histograms()[0]
    rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(
        "STRUCTURE_RESULT="
        + json.dumps(
            {
                "mode": mode,
                "phase": phase.name,
                "project": str(output),
                "rwp_percent": float(histogram.get_wR()),
                "mass_fractions": histogram.ComputeMassFracs(),
                "cell": phase.get_cell(),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": atom.coordinates,
                        "occupancy": atom.occupancy,
                        "uiso": atom.uiso,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
                "convergence": {
                    key: rv.get(key)
                    for key in ("converged", "SVD0", "Max shft/sig", "msg")
                },
                "attempts": summaries,
            },
            default=str,
            sort_keys=True,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
