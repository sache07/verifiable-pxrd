#!/usr/bin/env python3
"""Run one matched optional profile/envelope/microstructure branch in GSAS-II."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def configure(project: G2sc.G2Project, mode: str) -> None:
    histogram = project.histograms()[0]
    instrument = histogram.InstrumentParameters
    if mode.startswith("inst-"):
        name = mode.split("-", 1)[1]
        if name not in instrument:
            raise ValueError(name)
        instrument[name][2] = True
        return
    if mode == "polarization":
        instrument["Polariz."][2] = True
        return
    if mode == "roughness":
        histogram.SampleParameters["SurfRoughA"][:] = [0.5, True]
        histogram.SampleParameters["SurfRoughB"][:] = [0.1, True]
        return
    if mode == "axial":
        instrument["SH/L"][2] = True
        return

    parts = mode.split(":")
    if len(parts) < 2:
        raise ValueError(mode)
    kind, phase_index = parts[0], int(parts[1])
    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][histogram.name]
    if kind == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [True, False, False]
    elif kind == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [True, False, False]
    elif kind == "texture":
        if len(parts) != 3:
            raise ValueError(mode)
        axis = [int(value) for value in parts[2].split(",")]
        if len(axis) != 3:
            raise ValueError(axis)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
    else:
        raise ValueError(mode)


def main() -> None:
    if len(sys.argv) not in (4, 5):
        raise SystemExit("usage: profile_branch.py BASE.gpx OUTPUT.gpx MODE [MAX_ATTEMPTS]")
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    mode = sys.argv[3]
    max_attempts = int(sys.argv[4]) if len(sys.argv) == 5 else 6
    stable = output.with_name(output.stem + "_stable_before.gpx")

    project = G2sc.G2Project(str(source), filename=str(stable))
    project.save(str(stable))
    project.save(str(output))
    configure(project, mode)
    project.set_Controls("cycles", 6)
    summaries = []
    for attempt in range(1, max_attempts + 1):
        project.refine()
        rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        item = {
            "attempt": attempt,
            "rwp_percent": float(project.histograms()[0].get_wR()),
            "converged": bool(rv.get("converged")),
            "max_shift_over_esd": rv.get("Max shft/sig"),
            "svd_dropped": rv.get("SVD0"),
            "message": rv.get("msg", ""),
        }
        summaries.append(item)
        print("PROFILE_STAGE=" + json.dumps(item, default=str), flush=True)
        if (
            rv.get("converged")
            and not rv.get("SVD0")
            and not rv.get("msg")
            and float(rv.get("Max shft/sig") or 0.0) < 0.05
        ):
            break
    project.save(str(output))
    histogram = project.histograms()[0]
    rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(
        "PROFILE_RESULT="
        + json.dumps(
            {
                "mode": mode,
                "project": str(output),
                "rwp_percent": float(histogram.get_wR()),
                "mass_fractions": histogram.ComputeMassFracs(),
                "instrument": histogram.InstrumentParameters,
                "sample": histogram.SampleParameters,
                "phases": {
                    phase.name: phase.data["Histograms"][histogram.name]
                    for phase in project.phases()
                },
                "convergence": {
                    key: rv.get(key)
                    for key in ("converged", "SVD0", "Max shft/sig", "msg")
                },
                "attempts": summaries,
            },
            default=str,
            sort_keys=True,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
