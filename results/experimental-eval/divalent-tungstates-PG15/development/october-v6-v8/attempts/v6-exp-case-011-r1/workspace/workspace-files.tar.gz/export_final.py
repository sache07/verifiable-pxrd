#!/usr/bin/env python3
"""Export final CIFs and the observed/calculated/difference profile."""

from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: export_final.py final.gpx")
    project_path = Path(sys.argv[1]).resolve()
    root = project_path.parent
    project = G2sc.G2Project(str(project_path))
    phases = project.phases()
    if len(phases) != 2:
        raise ValueError(f"expected two phases, found {len(phases)}")
    histogram = project.histograms()[0]

    cif_names = ["phase_1_WO3_gamma.cif", "phase_2_MnO2_beta.cif"]
    for phase, name in zip(phases, cif_names, strict=True):
        phase.export_CIF(str(root / name))

    arrays = np.asarray(histogram.data["data"][1], dtype=float)
    x, observed, calculated, background, difference = (
        arrays[0],
        arrays[1],
        arrays[3],
        arrays[4],
        arrays[5],
    )
    if not all(np.all(np.isfinite(values)) for values in (x, observed, calculated, difference)):
        raise ValueError("nonfinite value in exported profile")
    with (root / "fit.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["two_theta_deg", "observed_counts", "calculated_counts", "difference_counts", "background_counts"]
        )
        writer.writerows(zip(x, observed, calculated, difference, background, strict=True))

    lower, upper = histogram.data["Limits"][1]
    selected = (x >= lower) & (x <= upper)
    rp = 100.0 * float(np.sum(np.abs(difference[selected]))) / float(
        np.sum(np.abs(observed[selected]))
    )
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvalues = covariance.get("Rvals", {})
    rwp = float(histogram.get_wR())
    gof = float(rvalues.get("GOF"))
    fractions = histogram.ComputeMassFracs()
    result = {
        "project": str(project_path),
        "profile_rows": int(len(x)),
        "cifs": cif_names,
        "phases": [
            {
                "name": phase.name,
                "composition": phase.composition,
                "cell": phase.get_cell(),
                "weight_fraction": fractions[phase.name][0],
                "weight_fraction_esd": fractions[phase.name][1],
            }
            for phase in phases
        ],
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "GOF": gof,
            "Rexp_percent": rwp / gof,
            "chi_squared": rvalues.get("chisq"),
            "n_observations": rvalues.get("Nobs"),
            "n_variables": rvalues.get("Nvars"),
            "max_shift_over_esd": rvalues.get("Max shft/sig"),
        },
        "fraction_sum": sum(value[0] for value in fractions.values()),
    }
    if not math.isclose(result["fraction_sum"], 1.0, abs_tol=1e-10):
        raise ValueError(f"fractions do not sum to one: {result['fraction_sum']}")
    print("FINAL_EXPORT=" + json.dumps(result, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
