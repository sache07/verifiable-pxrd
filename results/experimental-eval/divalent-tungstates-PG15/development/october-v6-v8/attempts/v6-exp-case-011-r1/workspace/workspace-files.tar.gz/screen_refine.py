#!/usr/bin/env python3
"""Run matched, minimal GSAS-II screening refinements for one candidate CIF."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def run_to_stability(project: G2sc.G2Project, stage: str, attempts: int = 3) -> dict:
    summary = {}
    for attempt in range(1, attempts + 1):
        project.refine()
        rv = status(project)
        summary = {
            "stage": stage,
            "attempt": attempt,
            "rwp_percent": float(project.histograms()[0].get_wR()),
            "converged": bool(rv.get("converged")),
            "max_shift_over_esd": rv.get("Max shft/sig"),
            "svd_dropped": rv.get("SVD0"),
            "message": rv.get("msg", ""),
        }
        print("SCREEN_STAGE=" + json.dumps(summary, default=str), flush=True)
        max_shift = float(rv.get("Max shft/sig") or 0.0)
        if rv.get("converged") and not rv.get("SVD0") and not rv.get("msg") and max_shift < 0.1:
            break
    return summary


def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit("usage: screen_refine.py CANDIDATE.cif TAG PHASE_NAME")
    candidate = Path(sys.argv[1]).resolve()
    tag = sys.argv[2]
    phase_name = sys.argv[3]
    branch_dir = Path("branches").resolve()
    branch_dir.mkdir(exist_ok=True)
    pre = branch_dir / f"{tag}_stable_before_minimal.gpx"
    work = branch_dir / f"{tag}_minimal.gpx"

    project = G2sc.G2Project(newgpx=str(pre))
    histogram = project.add_powder_histogram(
        "inputs/pattern.csv", "cu_ka.instprm", fmthint="comma"
    )
    phase = project.add_phase(
        str(candidate), phasename=phase_name, histograms=[histogram], fmthint="CIF"
    )
    project.set_Controls("cycles", 6)
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 10,
                "coeffs": [1000.0] + [0.0] * 9,
            }
        }
    )
    histogram.SampleParameters["Scale"][:] = [8.0, True]
    histogram.InstrumentParameters["Zero"][1:] = [0.30, False]
    histogram.InstrumentParameters["W"][1:] = [25.0, False]
    phase.data["Histograms"][histogram.name]["Scale"][:] = [1.0, False]
    project.save(str(pre))
    project.save(str(work))

    summaries = []
    summaries.append(run_to_stability(project, "background_scale"))

    histogram.InstrumentParameters["Zero"][2] = True
    summaries.append(run_to_stability(project, "zero"))

    phase.data["General"]["Cell"][0] = True
    summaries.append(run_to_stability(project, "cell"))

    histogram.InstrumentParameters["W"][2] = True
    summaries.append(run_to_stability(project, "global_W"))
    project.save(str(work))

    rv = status(project)
    print(
        "SCREEN_RESULT="
        + json.dumps(
            {
                "tag": tag,
                "candidate": str(candidate),
                "project": str(work),
                "rwp_percent": float(histogram.get_wR()),
                "cell": phase.get_cell(),
                "instrument": histogram.InstrumentParameters,
                "sample_scale": histogram.SampleParameters["Scale"],
                "phase_scale": phase.data["Histograms"][histogram.name]["Scale"],
                "convergence": {
                    key: rv.get(key)
                    for key in ("converged", "SVD0", "Max shft/sig", "msg")
                },
                "stages": summaries,
            },
            default=str,
            sort_keys=True,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
