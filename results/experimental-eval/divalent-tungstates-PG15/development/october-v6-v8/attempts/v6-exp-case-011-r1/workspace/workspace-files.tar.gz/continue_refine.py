#!/usr/bin/env python3
"""Continue a GSAS-II refinement until its saved shift criterion is small."""

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("project")
parser.add_argument("--freeze-cells", action="store_true")
parser.add_argument("--freeze-background", action="store_true")
parser.add_argument("--attempts", type=int, default=6)
args = parser.parse_args()

project = G2sc.G2Project(args.project)
if args.freeze_cells:
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
if args.freeze_background:
    project.histograms()[0].Background[0][1] = False
project.set_Controls("cycles", 6)
for attempt in range(1, args.attempts + 1):
    project.refine()
    status = project.data["Covariance"]["data"].get("Rvals", {})
    print(
        "CONTINUE="
        + json.dumps(
            {
                "attempt": attempt,
                "rwp_percent": project.histograms()[0].get_wR(),
                "converged": status.get("converged"),
                "max_shift_over_esd": status.get("Max shft/sig"),
                "svd_dropped": status.get("SVD0"),
                "message": status.get("msg"),
            }
        ),
        flush=True,
    )
    if (
        status.get("converged")
        and not status.get("SVD0")
        and not status.get("msg")
        and float(status.get("Max shft/sig") or 0.0) < 0.05
    ):
        break
project.save()
