#!/usr/bin/env python3
"""Matched mature-model replacement test for the alternative WO3 structure."""

from __future__ import annotations

import copy
import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def refine_to_stability(project: G2sc.G2Project, stage: str, attempts: int = 6) -> dict:
    result = {}
    for attempt in range(1, attempts + 1):
        project.refine()
        rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        result = {
            "stage": stage,
            "attempt": attempt,
            "rwp_percent": float(project.histograms()[0].get_wR()),
            "converged": bool(rv.get("converged")),
            "max_shift_over_esd": rv.get("Max shft/sig"),
            "svd_dropped": rv.get("SVD0"),
            "message": rv.get("msg", ""),
        }
        print("REPLACEMENT_STAGE=" + json.dumps(result, default=str), flush=True)
        if (
            rv.get("converged")
            and not rv.get("SVD0")
            and not rv.get("msg")
            and float(rv.get("Max shft/sig") or 0.0) < 0.05
        ):
            break
    return result


def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit("usage: replace_wo3_test.py BASE.gpx ALTERNATIVE.cif OUTPUT.gpx")
    source = Path(sys.argv[1]).resolve()
    candidate = Path(sys.argv[2]).resolve()
    output = Path(sys.argv[3]).resolve()
    stable = output.with_name(output.stem + "_stable_before.gpx")

    project = G2sc.G2Project(str(source), filename=str(stable))
    project.save(str(stable))
    project.save(str(output))
    histogram = project.histograms()[0]
    old_phase = project.phases()[0]
    old_hap = old_phase.data["Histograms"][histogram.name]
    old_hap["Use"] = False
    old_phase.data["General"]["Cell"][0] = False
    for atom in old_phase.atoms():
        atom.refinement_flags = ""

    new_phase = project.add_phase(
        str(candidate),
        phasename="WO3_triclinic_P-1",
        histograms=[histogram],
        fmthint="CIF",
    )
    new_hap = new_phase.data["Histograms"][histogram.name]
    new_hap["Scale"][:] = [1.0, False]
    new_hap["Size"] = copy.deepcopy(old_hap["Size"])
    new_hap["Mustrain"] = copy.deepcopy(old_hap["Mustrain"])
    new_hap["Pref.Ori."] = copy.deepcopy(old_hap["Pref.Ori."])
    new_phase.data["General"]["Cell"][0] = False
    project.set_Controls("cycles", 6)
    project.save(str(output))

    stages = [refine_to_stability(project, "fixed_source_cell")]
    new_phase.data["General"]["Cell"][0] = True
    stages.append(refine_to_stability(project, "refined_cell"))
    new_phase.data["General"]["Cell"][0] = False
    stages.append(refine_to_stability(project, "frozen_cell_replay", 3))
    project.save(str(output))

    rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(
        "REPLACEMENT_RESULT="
        + json.dumps(
            {
                "project": str(output),
                "candidate": str(candidate),
                "rwp_percent": float(histogram.get_wR()),
                "mass_fractions": histogram.ComputeMassFracs(),
                "cell": new_phase.get_cell(),
                "scale": new_hap["Scale"],
                "size": new_hap["Size"],
                "convergence": {
                    key: rv.get(key)
                    for key in ("converged", "SVD0", "Max shft/sig", "msg")
                },
                "stages": stages,
            },
            default=str,
            sort_keys=True,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
