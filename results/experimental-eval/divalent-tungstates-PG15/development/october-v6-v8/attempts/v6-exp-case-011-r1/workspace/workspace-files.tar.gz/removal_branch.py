#!/usr/bin/env python3
"""Run a matched leave-one-term-out refinement from a mature GSAS-II model."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit(
            "usage: removal_branch.py BASE.gpx OUTPUT.gpx "
            "polarization|global-Y|wo3-size|mno2-texture|mno2-phase|wo3-W1"
        )
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    mode = sys.argv[3]
    stable = output.with_name(output.stem + "_stable_before.gpx")

    project = G2sc.G2Project(str(source), filename=str(stable))
    project.save(str(stable))
    project.save(str(output))
    histogram = project.histograms()[0]

    if mode == "polarization":
        histogram.InstrumentParameters["Polariz."][1:] = [0.7, False]
    elif mode == "global-Y":
        histogram.InstrumentParameters["Y"][1:] = [0.0, False]
    elif mode == "wo3-size":
        size = project.phases()[0].data["Histograms"][histogram.name]["Size"]
        size[1][0] = 1.0
        size[2][0] = False
    elif mode == "mno2-texture":
        texture = project.phases()[1].data["Histograms"][histogram.name]["Pref.Ori."]
        texture[1] = 1.0
        texture[2] = False
    elif mode == "mno2-phase":
        hap = project.phases()[1].data["Histograms"][histogram.name]
        hap["Use"] = False
        hap["Scale"][1] = False
    elif mode == "wo3-W1":
        atom = project.phases()[0].atom("W1")
        atom.coordinates = [0.028, 0.037, 0.746]
        atom.refinement_flags = ""
    else:
        raise ValueError(mode)

    project.set_Controls("cycles", 6)
    attempts = []
    for attempt in range(1, 7):
        project.refine()
        rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        item = {
            "attempt": attempt,
            "rwp_percent": float(project.histograms()[0].get_wR()),
            "converged": bool(rv.get("converged")),
            "max_shift_over_esd": rv.get("Max shft/sig"),
            "svd_dropped": rv.get("SVD0"),
            "message": rv.get("msg", ""),
        }
        attempts.append(item)
        print("REMOVAL_STAGE=" + json.dumps(item, default=str), flush=True)
        if (
            rv.get("converged")
            and not rv.get("SVD0")
            and not rv.get("msg")
            and float(rv.get("Max shft/sig") or 0.0) < 0.05
        ):
            break
    project.save(str(output))
    print(
        "REMOVAL_RESULT="
        + json.dumps(
            {
                "mode": mode,
                "project": str(output),
                "rwp_percent": float(project.histograms()[0].get_wR()),
                "mass_fractions": project.histograms()[0].ComputeMassFracs(),
                "attempts": attempts,
            },
            default=str,
            sort_keys=True,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
