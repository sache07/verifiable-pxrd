#!/usr/bin/env python3
"""Retest one candidate phase from a mature GSAS-II baseline."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def refine_stage(project: G2sc.G2Project, label: str, attempts: int = 5) -> dict:
    summary = {}
    for attempt in range(1, attempts + 1):
        project.refine()
        rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        summary = {
            "stage": label,
            "attempt": attempt,
            "rwp_percent": float(project.histograms()[0].get_wR()),
            "converged": bool(rv.get("converged")),
            "max_shift_over_esd": rv.get("Max shft/sig"),
            "svd_dropped": rv.get("SVD0"),
            "message": rv.get("msg", ""),
        }
        print("ADD_PHASE_STAGE=" + json.dumps(summary, default=str), flush=True)
        if (
            rv.get("converged")
            and not rv.get("SVD0")
            and not rv.get("msg")
            and float(rv.get("Max shft/sig") or 0.0) < 0.05
        ):
            break
    return summary


def main() -> None:
    if len(sys.argv) not in (6, 7):
        raise SystemExit(
            "usage: add_phase_screen.py BASE.gpx CANDIDATE.cif TAG PHASE_NAME START_SCALE [--scale-only]"
        )
    baseline = Path(sys.argv[1]).resolve()
    candidate = Path(sys.argv[2]).resolve()
    tag, phase_name, start_scale = sys.argv[3], sys.argv[4], float(sys.argv[5])
    scale_only = len(sys.argv) == 7 and sys.argv[6] == "--scale-only"
    if len(sys.argv) == 7 and not scale_only:
        raise SystemExit("only optional argument is --scale-only")
    branch_dir = Path("branches").resolve()
    stable = branch_dir / f"{tag}_stable_before_add.gpx"
    work = branch_dir / f"{tag}_added.gpx"

    project = G2sc.G2Project(str(baseline), filename=str(stable))
    project.save(str(stable))
    project.save(str(work))
    histogram = project.histograms()[0]
    phase = project.add_phase(
        str(candidate), phasename=phase_name, histograms=[histogram], fmthint="CIF"
    )
    project.set_Controls("cycles", 6)
    phase.data["Histograms"][histogram.name]["Scale"][:] = [start_scale, True]
    phase.data["General"]["Cell"][0] = False
    project.save(str(work))

    summaries = [refine_stage(project, "scale_from_mature_baseline")]
    if not scale_only:
        phase.data["General"]["Cell"][0] = True
        summaries.append(refine_stage(project, "candidate_cell"))
    project.save(str(work))

    rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(
        "ADD_PHASE_RESULT="
        + json.dumps(
            {
                "tag": tag,
                "candidate": str(candidate),
                "project": str(work),
                "rwp_percent": float(histogram.get_wR()),
                "mass_fractions": histogram.ComputeMassFracs(),
                "new_phase_scale": phase.data["Histograms"][histogram.name]["Scale"],
                "new_phase_cell": phase.get_cell(),
                "convergence": {
                    key: rv.get(key)
                    for key in ("converged", "SVD0", "Max shft/sig", "msg")
                },
                "stages": summaries,
            },
            default=str,
            sort_keys=True,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
