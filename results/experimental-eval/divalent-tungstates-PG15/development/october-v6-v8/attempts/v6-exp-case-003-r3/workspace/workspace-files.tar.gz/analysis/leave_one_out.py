#!/usr/bin/env python3
"""Matched leave-one-phase-out tests from the mature selected model."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refinement_utils import clone, project_summary, stable_refine


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "checkpoints" / "angular_after_microtexture.gpx"
OUTPUT = BASE / "leave_one_out.json"
PHASES = ("WO3_alternative", "CaWO4", "CaCO3")


def main() -> None:
    results = {
        "baseline": project_summary(G2sc.G2Project(str(SOURCE))),
        "branches": {},
    }
    for phase_name in PHASES:
        project = clone(SOURCE, BASE / "branches" / f"leave_out_{phase_name}.gpx")
        histogram = project.histograms()[0]
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][histogram.name]
        hap["Use"] = False
        hap["Scale"][:] = [0.0, False]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        phase.data["General"]["Cell"][0] = False
        project.save()
        refinement = stable_refine(project, maximum_passes=6, cycles_per_pass=6)
        summary = project_summary(project)
        results["branches"][phase_name] = {
            "refinement": refinement,
            "summary": summary,
        }
        print(phase_name, refinement["valid"], summary["rwp_by_region_percent"], file=sys.stderr)
    OUTPUT.write_text(json.dumps(results, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
