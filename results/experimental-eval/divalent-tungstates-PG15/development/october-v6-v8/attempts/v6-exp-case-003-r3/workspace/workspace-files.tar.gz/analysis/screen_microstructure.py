#!/usr/bin/env python3
"""Screen isotropic size and microstrain independently for every active phase."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from refinement_utils import clone, project_summary, stable_refine


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "branches" / "envelope_roughness_B_only.gpx"
OUTPUT = BASE / "microstructure_screen.json"
PHASES = ("WO3_alternative", "CaWO4", "CaCO3")


def term_correlations(project: G2sc.G2Project, token: str) -> list[dict]:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    indexes = [index for index, name in enumerate(names) if token in name]
    rows = []
    for first in indexes:
        for second, other in enumerate(names):
            if first == second:
                continue
            denominator = math.sqrt(max(matrix[first, first], 0.0)) * math.sqrt(
                max(matrix[second, second], 0.0)
            )
            if denominator > 0.0:
                rows.append(
                    {
                        "first": names[first],
                        "second": other,
                        "absolute_correlation": abs(
                            float(matrix[first, second]) / denominator
                        ),
                    }
                )
    return sorted(rows, key=lambda row: row["absolute_correlation"], reverse=True)[:8]


def configure(project: G2sc.G2Project, phase_name: str, term: str) -> None:
    histogram = project.histograms()[0]
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][histogram.name]
    if term == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    elif term == "microstrain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
    else:
        raise ValueError(term)


def main() -> None:
    results = {
        "baseline": project_summary(G2sc.G2Project(str(SOURCE))),
        "branches": {},
    }
    for phase_name in PHASES:
        for term in ("size", "microstrain"):
            key = f"{phase_name}_{term}"
            destination = BASE / "branches" / f"micro_{key}.gpx"
            project = clone(SOURCE, destination)
            configure(project, phase_name, term)
            project.save()
            refinement = stable_refine(project, maximum_passes=8, cycles_per_pass=6)
            summary = project_summary(project)
            results["branches"][key] = {
                "phase": phase_name,
                "term": term,
                "refinement": refinement,
                "summary": summary,
                "correlations": term_correlations(
                    project, "Size" if term == "size" else "Mustrain"
                ),
            }
            print(key, refinement["valid"], summary["rwp_by_region_percent"], file=sys.stderr)
    OUTPUT.write_text(json.dumps(results, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
