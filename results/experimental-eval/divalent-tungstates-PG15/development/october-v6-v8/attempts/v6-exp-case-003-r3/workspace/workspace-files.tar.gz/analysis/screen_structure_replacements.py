#!/usr/bin/env python3
"""Compare complete-pattern replacements for each accepted phase topology."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refinement_utils import clone, project_summary, stable_refine


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "checkpoints" / "angular_selected.gpx"
OUTPUT = BASE / "structure_replacement_screen.json"


def replace_phase(
    source_name: str, candidate_file: str, destination: Path
) -> tuple[G2sc.G2Project, dict]:
    project = clone(SOURCE, destination)
    histogram = project.histograms()[0]
    original = project.phase(source_name)
    original_hap = original.data["Histograms"][histogram.name]
    starting_scale = float(original_hap["Scale"][0])
    original_hap["Use"] = False
    original_hap["Scale"][:] = [0.0, False]
    alternative = project.add_phase(
        str(BASE / "candidates" / candidate_file),
        phasename=f"{source_name}_alternative",
        histograms=[histogram],
        fmthint="CIF",
    )
    alternative.data["General"]["Cell"][0] = True
    alternative_hap = alternative.data["Histograms"][histogram.name]
    alternative_hap["Scale"][:] = [starting_scale, True]
    alternative_hap["Use"] = True
    project.update_ids()
    project.index_ids()
    # A replacement scale is linear, but its cell is not. First establish
    # positive full-pattern support at the measured reference cell while all
    # cell metrics are held fixed, then release the active cells together.
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
    project.save()
    scale_refinement = stable_refine(project, maximum_passes=8, cycles_per_pass=6)
    scale_value = float(alternative_hap["Scale"][0])
    result = {
        "scale_stage": scale_refinement,
        "scale_after_fixed_cell_stage": scale_value,
    }
    if not scale_refinement["valid"] or scale_value <= 0.0:
        result["cell_stage"] = {"valid": False, "reason": "no_positive_scale_support"}
        return project, result
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phase.data["General"]["Cell"][0] = bool(
            hap.get("Use", True) and float(hap["Scale"][0]) != 0.0
        )
    project.save()
    result["cell_stage"] = stable_refine(
        project, maximum_passes=10, cycles_per_pass=6
    )
    result["valid"] = bool(
        scale_refinement["valid"] and result["cell_stage"]["valid"]
    )
    return project, result


def main() -> None:
    branches = {
        "wo3_triclinic": (
            "WO3",
            "wo3_triclinic_cod2106293.cif",
        ),
        "wo3_orthorhombic": (
            "WO3",
            "wo3_orthorhombic_cod2107312.cif",
        ),
        "cawo4_fergusonite": (
            "CaWO4",
            "cawo4_fergusonite_cod1546035.cif",
        ),
        "caco3_aragonite": (
            "CaCO3",
            "caco3_aragonite_cod2103119.cif",
        ),
    }
    results = {
        "baseline": project_summary(G2sc.G2Project(str(SOURCE))),
        "branches": {},
    }
    for name, (source_name, candidate_file) in branches.items():
        destination = BASE / "branches" / f"replacement_{name}.gpx"
        project, refinement = replace_phase(source_name, candidate_file, destination)
        results["branches"][name] = {
            "replaces": source_name,
            "candidate_file": candidate_file,
            "refinement": refinement,
            "summary": project_summary(project),
        }
        print(
            name,
            refinement.get("valid", False),
            results["branches"][name]["summary"]["rwp_by_region_percent"],
            file=sys.stderr,
        )
    OUTPUT.write_text(json.dumps(results, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
