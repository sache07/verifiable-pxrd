#!/usr/bin/env python3
"""Retest remaining broadening terms from the accepted two-size state."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refinement_utils import clone, project_summary, stable_refine


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "branches" / "retest_WO3_alternative_size.gpx"
OUTPUT = BASE / "microstructure_two_size_retest.json"


def configure(project: G2sc.G2Project, phase_name: str, term: str) -> None:
    histogram = project.histograms()[0]
    hap = project.phase(phase_name).data["Histograms"][histogram.name]
    if term == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True


def main() -> None:
    tests = (
        ("WO3_alternative", "microstrain"),
        ("CaWO4", "microstrain"),
        ("CaCO3", "size"),
        ("CaCO3", "microstrain"),
    )
    results = {
        "baseline": project_summary(G2sc.G2Project(str(SOURCE))),
        "branches": {},
    }
    for phase_name, term in tests:
        key = f"{phase_name}_{term}"
        project = clone(SOURCE, BASE / "branches" / f"two_size_retest_{key}.gpx")
        configure(project, phase_name, term)
        project.save()
        refinement = stable_refine(project, maximum_passes=6, cycles_per_pass=6)
        summary = project_summary(project)
        results["branches"][key] = {
            "phase": phase_name,
            "term": term,
            "refinement": refinement,
            "summary": summary,
        }
        print(key, refinement["valid"], summary["rwp_by_region_percent"], file=sys.stderr)
    OUTPUT.write_text(json.dumps(results, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
