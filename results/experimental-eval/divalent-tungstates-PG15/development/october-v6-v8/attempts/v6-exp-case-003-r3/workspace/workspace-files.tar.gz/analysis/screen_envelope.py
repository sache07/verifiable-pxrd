#!/usr/bin/env python3
"""Compare minimal polarization and surface-roughness envelope models."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from refinement_utils import clone, project_summary, stable_refine


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "branches" / "replacement_wo3_triclinic.gpx"
OUTPUT = BASE / "envelope_screen.json"


def max_pair_correlation(project: G2sc.G2Project, suffixes: tuple[str, ...]) -> float | None:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    indexes = [i for i, name in enumerate(names) if name.endswith(suffixes)]
    if matrix.shape != (len(names), len(names)) or len(indexes) < 2:
        return None
    values = []
    for pos, first in enumerate(indexes):
        for second in indexes[pos + 1 :]:
            denominator = math.sqrt(max(matrix[first, first], 0.0)) * math.sqrt(
                max(matrix[second, second], 0.0)
            )
            if denominator > 0.0:
                values.append(abs(float(matrix[first, second]) / denominator))
    return max(values) if values else None


def configure(project: G2sc.G2Project, branch: str) -> None:
    histogram = project.histograms()[0]
    instrument = histogram.InstrumentParameters
    sample = histogram.SampleParameters
    instrument["Polariz."][2] = False
    sample["SurfRoughA"][1] = False
    sample["SurfRoughB"][1] = False
    if branch == "polarization":
        instrument["Polariz."][1:] = [0.7, True]
    elif branch == "roughness_B_only":
        sample["SurfRoughA"][:] = [0.0, False]
        sample["SurfRoughB"][:] = [0.05, True]
    elif branch == "roughness_joint":
        sample["SurfRoughA"][:] = [0.5, True]
        sample["SurfRoughB"][:] = [0.05, True]
    else:
        raise ValueError(branch)


def main() -> None:
    results = {
        "baseline": project_summary(G2sc.G2Project(str(SOURCE))),
        "branches": {},
    }
    for branch in ("polarization", "roughness_B_only", "roughness_joint"):
        destination = BASE / "branches" / f"envelope_{branch}.gpx"
        project = clone(SOURCE, destination)
        configure(project, branch)
        project.save()
        refinement = stable_refine(project, maximum_passes=8, cycles_per_pass=6)
        summary = project_summary(project)
        results["branches"][branch] = {
            "refinement": refinement,
            "summary": summary,
            "envelope_pair_correlation": max_pair_correlation(
                project, (":Polariz.", ":SurfRoughA", ":SurfRoughB")
            ),
        }
        print(branch, refinement["valid"], summary["rwp_by_region_percent"], file=sys.stderr)
    OUTPUT.write_text(json.dumps(results, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
