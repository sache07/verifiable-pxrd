#!/usr/bin/env python3
"""Prepare symmetry-clean local CIFs from the masked COD references."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = Path(__file__).resolve().parent / "candidates"


def cod_path(cod_id: str) -> Path:
    matches = list(ROOT.rglob(f"{cod_id}.cif"))
    if len(matches) != 1:
        raise RuntimeError(f"expected one CIF for COD {cod_id}, found {matches}")
    return matches[0]


def write_standardized(cod_id: str, output: str) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    CifWriter(structure, symprec=0.01, angle_tolerance=5).write_file(OUT / output)


def write_conventional_monoclinic_wo3() -> None:
    """Transform COD 2311041 to its near-orthogonal conventional metric.

    The source uses an equivalent P21/c cell with beta=136.06 degrees.  The
    unimodular transform below preserves Cartesian coordinates and topology,
    but gives the familiar a~7.30, b~7.54, c~7.69 A, beta~90.91 degree cell.
    """

    structure = Structure.from_file(cod_path("2311041"))
    old = structure.lattice.matrix
    new_lattice = Lattice([-old[0] - old[2], old[1], old[0]])
    transformed = Structure(
        new_lattice,
        structure.species,
        structure.cart_coords,
        coords_are_cartesian=True,
        to_unit_cell=True,
    )
    analyzer = SpacegroupAnalyzer(transformed, symprec=0.01, angle_tolerance=5)
    symmetrized = analyzer.get_symmetrized_structure()
    operations = analyzer.get_symmetry_operations(cartesian=False)
    cell = transformed.lattice
    lines = [
        "data_wo3_monoclinic_cod2311041_conventional",
        "_audit_creation_method 'Unimodular cell transform of COD 2311041'",
        "_chemical_formula_sum 'O3 W'",
        "_cell_formula_units_Z 8",
        f"_cell_length_a {cell.a:.8f}",
        f"_cell_length_b {cell.b:.8f}",
        f"_cell_length_c {cell.c:.8f}",
        f"_cell_angle_alpha {cell.alpha:.8f}",
        f"_cell_angle_beta {cell.beta:.8f}",
        f"_cell_angle_gamma {cell.gamma:.8f}",
        "_space_group_IT_number 14",
        "_symmetry_space_group_name_H-M 'P 1 21/n 1'",
        "_symmetry_space_group_name_Hall '-P 2yn'",
        "loop_",
        "_space_group_symop_id",
        "_space_group_symop_operation_xyz",
    ]
    for index, operation in enumerate(operations, start=1):
        lines.append(f"{index} '{operation.as_xyz_str()}'")
    lines.extend(
        [
            "loop_",
            "_atom_site_label",
            "_atom_site_type_symbol",
            "_atom_site_fract_x",
            "_atom_site_fract_y",
            "_atom_site_fract_z",
            "_atom_site_occupancy",
            "_atom_site_U_iso_or_equiv",
        ]
    )
    element_counts: dict[str, int] = {}
    for equivalent_group in symmetrized.equivalent_indices:
        site = transformed[equivalent_group[0]]
        element = site.specie.symbol
        count = element_counts.get(element, 0) + 1
        element_counts[element] = count
        x, y, z = site.frac_coords % 1.0
        lines.append(
            f"{element}{count} {element} {x:.8f} {y:.8f} {z:.8f} 1.0 0.0100"
        )
    (OUT / "wo3_monoclinic_cod2311041.cif").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    write_conventional_monoclinic_wo3()
    write_standardized("2106293", "wo3_triclinic_cod2106293.cif")
    write_standardized("2107312", "wo3_orthorhombic_cod2107312.cif")
    write_standardized("7219229", "cawo4_scheelite_cod7219229.cif")
    write_standardized("1546035", "cawo4_fergusonite_cod1546035.cif")
    write_standardized("1547347", "caco3_calcite_cod1547347.cif")
    write_standardized("2103119", "caco3_aragonite_cod2103119.cif")


if __name__ == "__main__":
    main()
