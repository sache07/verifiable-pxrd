#!/usr/bin/env python3
"""Retest WO3 symmetry alternatives from the mature nuisance model."""

from __future__ import annotations

import copy
import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refinement_utils import clone, project_summary, stable_refine


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "checkpoints" / "angular_after_microtexture.gpx"
OUTPUT = BASE / "mature_wo3_retest.json"


def transfer_hap(source: dict, target: dict) -> None:
    for key in ("Size", "Mustrain", "HStrain", "Extinction", "Babinet"):
        if key in source:
            target[key] = copy.deepcopy(source[key])
    target["Pref.Ori."] = copy.deepcopy(source["Pref.Ori."])
    target["Pref.Ori."][2] = False


def prepare(branch: str, destination: Path) -> G2sc.G2Project:
    project = clone(SOURCE, destination)
    histogram = project.histograms()[0]
    triclinic = project.phase("WO3_alternative")
    triclinic_hap = triclinic.data["Histograms"][histogram.name]
    scale = float(triclinic_hap["Scale"][0])
    triclinic_hap["Use"] = False
    triclinic_hap["Scale"][:] = [0.0, False]
    if branch == "monoclinic":
        alternative = project.phase("WO3")
        alternative_hap = alternative.data["Histograms"][histogram.name]
    elif branch == "orthorhombic":
        alternative = project.add_phase(
            str(BASE / "candidates" / "wo3_orthorhombic_cod2107312.cif"),
            phasename="WO3_orthorhombic_retest",
            histograms=[histogram],
            fmthint="CIF",
        )
        alternative_hap = alternative.data["Histograms"][histogram.name]
    else:
        raise ValueError(branch)
    alternative_hap["Use"] = True
    alternative_hap["Scale"][:] = [scale, True]
    transfer_hap(triclinic_hap, alternative_hap)
    alternative.data["General"]["Cell"][0] = False
    project.update_ids()
    project.index_ids()
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
    project.save()
    return project


def main() -> None:
    results = {
        "baseline": project_summary(G2sc.G2Project(str(SOURCE))),
        "branches": {},
    }
    for branch in ("monoclinic", "orthorhombic"):
        project = prepare(branch, BASE / "branches" / f"mature_wo3_{branch}.gpx")
        histogram = project.histograms()[0]
        scale_stage = stable_refine(project, maximum_passes=6, cycles_per_pass=6)
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            phase.data["General"]["Cell"][0] = bool(
                hap.get("Use", True) and float(hap["Scale"][0]) != 0.0
            )
        project.save()
        cell_stage = stable_refine(project, maximum_passes=8, cycles_per_pass=6)
        summary = project_summary(project)
        results["branches"][branch] = {
            "scale_stage": scale_stage,
            "cell_stage": cell_stage,
            "summary": summary,
        }
        print(branch, cell_stage["valid"], summary["rwp_by_region_percent"], file=sys.stderr)
    OUTPUT.write_text(json.dumps(results, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
