#!/usr/bin/env python3
"""Retest unretained phase broadening after accepting CaWO4 size."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refinement_utils import clone, project_summary, stable_refine


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "branches" / "micro_CaWO4_size.gpx"
OUTPUT = BASE / "microstructure_retest.json"


def configure(project: G2sc.G2Project, phase_name: str, term: str) -> None:
    histogram = project.histograms()[0]
    hap = project.phase(phase_name).data["Histograms"][histogram.name]
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    if term == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = True
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True


def main() -> None:
    results = {
        "baseline": project_summary(G2sc.G2Project(str(SOURCE))),
        "branches": {},
    }
    for phase_name in ("WO3_alternative", "CaCO3"):
        for term in ("size", "microstrain"):
            key = f"{phase_name}_{term}"
            project = clone(SOURCE, BASE / "branches" / f"retest_{key}.gpx")
            configure(project, phase_name, term)
            project.save()
            refinement = stable_refine(project, maximum_passes=6, cycles_per_pass=6)
            summary = project_summary(project)
            results["branches"][key] = {
                "phase": phase_name,
                "term": term,
                "refinement": refinement,
                "summary": summary,
            }
            print(key, refinement["valid"], summary["rwp_by_region_percent"], file=sys.stderr)
    OUTPUT.write_text(json.dumps(results, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
