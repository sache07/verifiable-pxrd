#!/usr/bin/env python3
"""Final downstream re-screen of unretained optional terms."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from refinement_utils import clone, project_summary, stable_refine


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "checkpoints" / "selected_clean.gpx"
OUTPUT = BASE / "final_addition_screen.json"


def maximum_new_correlation(project: G2sc.G2Project, token: str) -> float | None:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return None
    indexes = [i for i, name in enumerate(names) if token in name]
    values = []
    for first in indexes:
        for second in range(len(names)):
            if first == second:
                continue
            denominator = math.sqrt(max(matrix[first, first], 0.0)) * math.sqrt(
                max(matrix[second, second], 0.0)
            )
            if denominator > 0.0:
                values.append(abs(float(matrix[first, second]) / denominator))
    return max(values) if values else None


def configure(project: G2sc.G2Project, term: str) -> str:
    histogram = project.histograms()[0]
    if term == "global_W":
        histogram.InstrumentParameters["W"][1:] = [5.0, True]
        return ":W"
    if term == "global_Y":
        histogram.InstrumentParameters["Y"][1:] = [1.0, True]
        return ":Y"
    if term == "polarization":
        histogram.InstrumentParameters["Polariz."][1:] = [0.7, True]
        return "Polariz."
    if term == "cawo4_texture":
        preferred = project.phase("CaWO4").data["Histograms"][histogram.name][
            "Pref.Ori."
        ]
        preferred[0:4] = ["MD", 1.0, True, [1, 1, 2]]
        return "MD"
    if term == "wo3_texture":
        preferred = project.phase("WO3_triclinic").data["Histograms"][histogram.name][
            "Pref.Ori."
        ]
        preferred[0:4] = ["MD", 1.0, True, [0, 0, 1]]
        return "MD"
    raise ValueError(term)


def main() -> None:
    terms = ("global_W", "global_Y", "polarization", "cawo4_texture", "wo3_texture")
    results = {
        "baseline": project_summary(G2sc.G2Project(str(SOURCE))),
        "branches": {},
    }
    for term in terms:
        project = clone(SOURCE, BASE / "branches" / f"final_add_{term}.gpx")
        token = configure(project, term)
        project.save()
        refinement = stable_refine(project, maximum_passes=5, cycles_per_pass=6)
        summary = project_summary(project)
        results["branches"][term] = {
            "refinement": refinement,
            "summary": summary,
            "maximum_added_term_correlation": maximum_new_correlation(project, token),
        }
        print(term, refinement["valid"], summary["rwp_by_region_percent"], file=sys.stderr)
    OUTPUT.write_text(json.dumps(results, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
