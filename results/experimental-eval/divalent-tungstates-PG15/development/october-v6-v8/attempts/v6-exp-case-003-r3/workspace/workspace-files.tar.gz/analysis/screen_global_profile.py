#!/usr/bin/env python3
"""Run matched one-term global profile branches from a stable inventory."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refinement_utils import clone, project_summary, stable_refine


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "checkpoints" / "inventory_mature.gpx"
OUTPUT = BASE / "profile_screen.json"


def configure(project: G2sc.G2Project, parameters: dict[str, float]) -> None:
    instrument = project.histograms()[0].InstrumentParameters
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        instrument[key][2] = False
    for key, start in parameters.items():
        instrument[key][1] = float(start)
        instrument[key][2] = True


def main() -> None:
    branches = {
        "gaussian_W": {"W": 5.0},
        "gaussian_U": {"U": 2.0},
        "lorentzian_X": {"X": 1.0},
        "lorentzian_Y": {"Y": 1.0},
    }
    results = {
        "baseline": project_summary(G2sc.G2Project(str(SOURCE))),
        "branches": {},
    }
    for name, parameters in branches.items():
        destination = BASE / "branches" / f"global_{name}.gpx"
        project = clone(SOURCE, destination)
        configure(project, parameters)
        project.save()
        refinement = stable_refine(project, maximum_passes=8, cycles_per_pass=6)
        results["branches"][name] = {
            "requested_parameters": parameters,
            "refinement": refinement,
            "summary": project_summary(project),
        }
        print(
            name,
            refinement["valid"],
            results["branches"][name]["summary"]["rwp_by_region_percent"],
            file=sys.stderr,
        )
    OUTPUT.write_text(json.dumps(results, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
