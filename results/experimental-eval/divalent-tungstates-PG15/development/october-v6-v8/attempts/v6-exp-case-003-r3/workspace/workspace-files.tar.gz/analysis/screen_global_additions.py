#!/usr/bin/env python3
"""Test one additional global width term from the selected X baseline."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from refinement_utils import clone, project_summary, stable_refine


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "branches" / "global_lorentzian_X.gpx"
OUTPUT = BASE / "global_additions_screen.json"


def correlations(project: G2sc.G2Project, needle: str) -> list[dict]:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    matches = [i for i, name in enumerate(names) if name.endswith(needle)]
    rows = []
    for first in matches:
        for second, other in enumerate(names):
            if first == second:
                continue
            denominator = math.sqrt(max(matrix[first, first], 0.0)) * math.sqrt(
                max(matrix[second, second], 0.0)
            )
            if denominator <= 0.0:
                continue
            rows.append(
                {
                    "first": names[first],
                    "second": other,
                    "absolute_correlation": abs(
                        float(matrix[first, second]) / denominator
                    ),
                }
            )
    return sorted(rows, key=lambda row: row["absolute_correlation"], reverse=True)[:8]


def main() -> None:
    additions = {"W": 5.0, "U": 2.0, "Y": 1.0}
    results = {
        "baseline": project_summary(G2sc.G2Project(str(SOURCE))),
        "branches": {},
    }
    for parameter, start in additions.items():
        destination = BASE / "branches" / f"global_X_plus_{parameter}.gpx"
        project = clone(SOURCE, destination)
        instrument = project.histograms()[0].InstrumentParameters
        parameter_data = instrument[parameter]
        parameter_data[1] = start
        parameter_data[2] = True
        project.save()
        refinement = stable_refine(project, maximum_passes=8, cycles_per_pass=6)
        results["branches"][parameter] = {
            "refinement": refinement,
            "summary": project_summary(project),
            "correlations": correlations(project, f":{parameter}"),
        }
        print(
            parameter,
            refinement["valid"],
            results["branches"][parameter]["summary"]["rwp_by_region_percent"],
            file=sys.stderr,
        )
    OUTPUT.write_text(json.dumps(results, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
