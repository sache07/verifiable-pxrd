#!/usr/bin/env python3
"""Screen one simple March-Dollase axis for each active phase."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refinement_utils import clone, project_summary, stable_refine


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "branches" / "retest_WO3_alternative_size.gpx"
OUTPUT = BASE / "texture_screen.json"
AXES = {
    "WO3_alternative": [0, 0, 1],
    "CaWO4": [1, 1, 2],
    "CaCO3": [1, 0, 4],
}


def main() -> None:
    results = {
        "baseline": project_summary(G2sc.G2Project(str(SOURCE))),
        "branches": {},
    }
    for phase_name, axis in AXES.items():
        key = f"{phase_name}_{'_'.join(map(str, axis))}"
        project = clone(SOURCE, BASE / "branches" / f"texture_{key}.gpx")
        histogram = project.histograms()[0]
        for phase in project.phases():
            phase.data["Histograms"][histogram.name]["Pref.Ori."][2] = False
        preferred = project.phase(phase_name).data["Histograms"][histogram.name][
            "Pref.Ori."
        ]
        preferred[0] = "MD"
        preferred[1] = 1.0
        preferred[2] = True
        preferred[3] = axis
        project.save()
        refinement = stable_refine(project, maximum_passes=6, cycles_per_pass=6)
        summary = project_summary(project)
        results["branches"][key] = {
            "phase": phase_name,
            "axis": axis,
            "refinement": refinement,
            "summary": summary,
        }
        print(key, refinement["valid"], summary["rwp_by_region_percent"], file=sys.stderr)
    OUTPUT.write_text(json.dumps(results, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
