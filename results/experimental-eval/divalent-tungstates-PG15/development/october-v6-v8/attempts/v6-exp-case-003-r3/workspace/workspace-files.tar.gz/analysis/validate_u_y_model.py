#!/usr/bin/env python3
"""Matched removals after selecting the final U+Y profile form."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refinement_utils import clone, project_summary, stable_refine


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "branches" / "profile_U_plus_Y_from_settled.gpx"
OUTPUT = BASE / "u_y_model_removals.json"


def remove(project: G2sc.G2Project, term: str) -> None:
    histogram = project.histograms()[0]
    if term == "global_U":
        histogram.InstrumentParameters["U"][1:] = [2.0, False]
    elif term == "global_Y":
        histogram.InstrumentParameters["Y"][1:] = [0.0, False]
    elif term == "surface_roughness":
        histogram.SampleParameters["SurfRoughA"][:] = [0.0, False]
        histogram.SampleParameters["SurfRoughB"][:] = [0.0, False]
    elif term in {"cawo4_size", "wo3_size"}:
        name = "CaWO4" if term == "cawo4_size" else "WO3_triclinic"
        size = project.phase(name).data["Histograms"][histogram.name]["Size"]
        size[1][0] = 1000.0
        size[2][0] = False
    elif term == "calcite_texture":
        preferred = project.phase("CaCO3").data["Histograms"][histogram.name][
            "Pref.Ori."
        ]
        preferred[1] = 1.0
        preferred[2] = False
    else:
        raise ValueError(term)


def main() -> None:
    terms = (
        "global_U",
        "global_Y",
        "surface_roughness",
        "cawo4_size",
        "wo3_size",
        "calcite_texture",
    )
    results = {
        "baseline": project_summary(G2sc.G2Project(str(SOURCE))),
        "branches": {},
    }
    for term in terms:
        project = clone(SOURCE, BASE / "branches" / f"uy_remove_{term}.gpx")
        remove(project, term)
        project.save()
        refinement = stable_refine(project, maximum_passes=5, cycles_per_pass=6)
        summary = project_summary(project)
        results["branches"][term] = {
            "refinement": refinement,
            "summary": summary,
        }
        print(term, refinement["valid"], summary["rwp_by_region_percent"], file=sys.stderr)
    OUTPUT.write_text(json.dumps(results, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
