#!/usr/bin/env python3
"""Matched removal tests for every retained optional nuisance term."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refinement_utils import clone, project_summary, stable_refine


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "checkpoints" / "selected_clean.gpx"
OUTPUT = BASE / "optional_term_removals.json"


def remove(project: G2sc.G2Project, term: str) -> None:
    histogram = project.histograms()[0]
    instrument = histogram.InstrumentParameters
    sample = histogram.SampleParameters
    if term == "global_U":
        instrument["U"][1:] = [2.0, False]
    elif term == "global_X":
        instrument["X"][1:] = [0.0, False]
    elif term == "surface_roughness":
        sample["SurfRoughA"][:] = [0.0, False]
        sample["SurfRoughB"][:] = [0.0, False]
    elif term == "cawo4_size":
        size = project.phase("CaWO4").data["Histograms"][histogram.name]["Size"]
        size[1][0] = 1000.0
        size[2][0] = False
    elif term == "wo3_size":
        size = project.phase("WO3_triclinic").data["Histograms"][histogram.name][
            "Size"
        ]
        size[1][0] = 1000.0
        size[2][0] = False
    elif term == "calcite_texture":
        preferred = project.phase("CaCO3").data["Histograms"][histogram.name][
            "Pref.Ori."
        ]
        preferred[1] = 1.0
        preferred[2] = False
    elif term == "specimen_displacement":
        sample["Shift"][:] = [0.0, False]
        instrument["Zero"][1:] = [0.0, False]
    else:
        raise ValueError(term)


def main() -> None:
    terms = (
        "global_U",
        "global_X",
        "surface_roughness",
        "cawo4_size",
        "wo3_size",
        "calcite_texture",
        "specimen_displacement",
    )
    results = {
        "baseline": project_summary(G2sc.G2Project(str(SOURCE))),
        "branches": {},
    }
    for term in terms:
        project = clone(SOURCE, BASE / "branches" / f"remove_{term}.gpx")
        remove(project, term)
        project.save()
        refinement = stable_refine(project, maximum_passes=6, cycles_per_pass=6)
        summary = project_summary(project)
        results["branches"][term] = {
            "refinement": refinement,
            "summary": summary,
        }
        print(term, refinement["valid"], summary["rwp_by_region_percent"], file=sys.stderr)
    OUTPUT.write_text(json.dumps(results, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
