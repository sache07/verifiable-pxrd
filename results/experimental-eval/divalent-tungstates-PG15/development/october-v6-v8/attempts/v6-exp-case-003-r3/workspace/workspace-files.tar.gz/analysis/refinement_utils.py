"""Small helpers for reproducible GSAS-II branch refinements."""

from __future__ import annotations

import contextlib
import io
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(
    project: G2sc.G2Project,
    *,
    maximum_passes: int = 8,
    cycles_per_pass: int = 8,
    shift_limit: float = 0.10,
    quiet: bool = True,
) -> dict:
    """Refine repeatedly until both GSAS-II convergence tests are satisfied."""

    project.set_Controls("cycles", cycles_per_pass)
    history = []
    valid = True
    reason = "maximum_passes"
    for _ in range(maximum_passes):
        try:
            if quiet:
                sink = io.StringIO()
                with contextlib.redirect_stdout(sink):
                    project.refine()
                transcript = sink.getvalue().lower()
            else:
                project.refine()
                transcript = ""
        except Exception as error:  # GSAS-II raises a range of exception types
            valid = False
            reason = f"exception: {error!r}"
            break
        if any(
            marker in transcript
            for marker in (
                "refinement failed",
                "unable to evaluate objective function",
                "invalid metric tensor",
                "***** error",
            )
        ):
            valid = False
            reason = "refinement_failed"
            break
        status = covariance_status(project)
        message = str(status.get("msg", "") or "").lower()
        rwp = float(project.histograms()[0].get_wR())
        shift = float(status.get("Max shft/sig") or math.inf)
        history.append(
            {
                "rwp_percent": rwp,
                "max_shift_over_esd": shift,
                "converged": bool(status.get("converged")),
                "svd_zero": int(status.get("SVD0", 0) or 0),
                "message": status.get("msg"),
            }
        )
        if (
            status.get("Aborted")
            or status.get("SVD0", 0)
            or "dropped" in message
            or "singular" in message
            or "error" in message
            or not math.isfinite(rwp)
        ):
            valid = False
            reason = "covariance_failure"
            break
        if status.get("converged") and abs(shift) < shift_limit:
            reason = "converged"
            break
    else:
        valid = False
    project.save()
    return {"valid": valid and reason == "converged", "reason": reason, "history": history}


def rwp_regions(project: G2sc.G2Project) -> dict[str, float]:
    histogram = project.histograms()[0]
    x = np.asarray(histogram.getdata("X"), dtype=float)
    observed = np.asarray(histogram.getdata("Yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    weights = np.asarray(histogram.getdata("Yweight"), dtype=float)
    limits = histogram.data["Limits"][1]
    ranges = {
        "full": (float(limits[0]), float(limits[1])),
        "low_10_30": (10.0, 30.0),
        "mid_30_60": (30.0, 60.0),
        "high_60_100": (60.0, 100.0),
    }
    values: dict[str, float] = {}
    for name, (lower, upper) in ranges.items():
        mask = (
            (x >= lower)
            & (x <= upper)
            & np.isfinite(observed)
            & np.isfinite(calculated)
            & np.isfinite(weights)
            & (weights > 0.0)
        )
        denominator = float(np.sum(weights[mask] * observed[mask] ** 2))
        numerator = float(
            np.sum(weights[mask] * (observed[mask] - calculated[mask]) ** 2)
        )
        values[name] = 100.0 * math.sqrt(numerator / denominator)
    return values


def project_summary(project: G2sc.G2Project) -> dict:
    histogram = project.histograms()[0]
    status = covariance_status(project)
    try:
        fractions = {
            name: {"value": value, "esd": esd}
            for name, (value, esd) in histogram.ComputeMassFracs().items()
        }
    except Exception as error:
        fractions = {"error": repr(error)}
    return {
        "path": str(Path(project.filename).resolve()),
        "rwp_by_region_percent": rwp_regions(project),
        "gof": status.get("GOF"),
        "converged": status.get("converged"),
        "max_shift_over_esd": status.get("Max shft/sig"),
        "svd_zero": status.get("SVD0"),
        "instrument": {
            key: list(value)
            for key, value in histogram.InstrumentParameters.items()
            if key
            in {
                "Lam1",
                "Lam2",
                "I(L2)/I(L1)",
                "Zero",
                "Polariz.",
                "U",
                "V",
                "W",
                "X",
                "Y",
                "Z",
                "SH/L",
            }
        },
        "sample": {
            key: value
            for key, value in histogram.SampleParameters.items()
            if key in {"Shift", "SurfRoughA", "SurfRoughB", "Transparency"}
        },
        "phases": {
            phase.name: {
                "cell": list(phase.data["General"]["Cell"]),
                "scale": list(phase.data["Histograms"][histogram.name]["Scale"]),
                "size": phase.data["Histograms"][histogram.name].get("Size"),
                "microstrain": phase.data["Histograms"][histogram.name].get(
                    "Mustrain"
                ),
                "preferred_orientation": phase.data["Histograms"][histogram.name].get(
                    "Pref.Ori."
                ),
            }
            for phase in project.phases()
        },
        "mass_fractions": fractions,
    }


def clone(source: str | Path, destination: str | Path) -> G2sc.G2Project:
    project = G2sc.G2Project(str(source), newgpx=str(destination))
    project.save()
    return project
