#!/usr/bin/env python3
"""Freeze the selected GSAS-II project and export all submission artifacts."""

from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORKSPACE = Path(__file__).resolve().parents[1]
LEARNED = WORKSPACE / "learned"
sys.path.insert(0, str(LEARNED))
from profile_regeneration import regenerate_profile  # noqa: E402


SOURCE = WORKSPACE / "analysis" / "checkpoints" / "angular_final_uy.gpx"
FINAL = WORKSPACE / "final.gpx"

PHASE_INFO = {
    "WO3_triclinic": {
        "name": "triclinic tungsten(VI) oxide",
        "formula": "WO3",
        "space_group": "P -1",
        "cif_path": "wo3_triclinic.cif",
        "source": "COD 2106293",
    },
    "CaCO3": {
        "name": "calcite",
        "formula": "CaCO3",
        "space_group": "R -3 c (hexagonal setting)",
        "cif_path": "calcite.cif",
        "source": "COD 1547347",
    },
    "CaWO4": {
        "name": "scheelite calcium tungstate",
        "formula": "CaWO4",
        "space_group": "I 41/a",
        "cif_path": "cawo4_scheelite.cif",
        "source": "COD 7219229",
    },
}


def profile_statistics(histogram: G2sc.G2PwdrData, covariance: dict) -> dict:
    observed = np.asarray(histogram.getdata("Yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    weights = np.asarray(histogram.getdata("Yweight"), dtype=float)
    valid = (
        np.isfinite(observed)
        & np.isfinite(calculated)
        & np.isfinite(weights)
        & (weights > 0.0)
    )
    residual = observed[valid] - calculated[valid]
    rwp = 100.0 * math.sqrt(
        float(np.sum(weights[valid] * residual**2))
        / float(np.sum(weights[valid] * observed[valid] ** 2))
    )
    rp = 100.0 * float(np.sum(np.abs(residual))) / float(
        np.sum(np.abs(observed[valid]))
    )
    gof = float(covariance.get("GOF"))
    nobs = int(covariance.get("Nobs"))
    nvars = int(covariance.get("Nvars"))
    return {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "rexp_percent": rwp / gof,
        "goodness_of_fit": gof,
        "reduced_chi_squared": gof**2,
        "chi_squared": float(covariance.get("chisq")),
        "n_observations": nobs,
        "n_refined_variables": nvars,
        "degrees_of_freedom": nobs - nvars,
        "converged": bool(covariance.get("converged")),
        "max_shift_over_esd": float(covariance.get("Max shft/sig")),
        "svd_dropped_variables": int(covariance.get("SVD0", 0) or 0),
        "weighting": "Poisson weights 1/I assigned by GSAS-II; pointwise uncertainties were not supplied",
    }


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    project.save()
    regenerate_profile(FINAL)
    project = G2sc.G2Project(str(FINAL))
    histogram = project.histograms()[0]

    for phase_name, info in PHASE_INFO.items():
        project.phase(phase_name).export_CIF(str(WORKSPACE / info["cif_path"]))

    x = np.asarray(histogram.getdata("X"), dtype=float)
    observed = np.asarray(histogram.getdata("Yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    background = np.asarray(histogram.getdata("Background"), dtype=float)
    difference = observed - calculated
    with (WORKSPACE / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_observed_minus_calculated",
                "calculated_background",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    fractions = histogram.ComputeMassFracs()
    phase_rows = []
    for phase_name in ("WO3_triclinic", "CaCO3", "CaWO4"):
        info = PHASE_INFO[phase_name]
        value, esd = fractions[phase_name]
        phase = project.phase(phase_name)
        phase_rows.append(
            {
                **info,
                "weight_fraction": float(value),
                "weight_fraction_esd_formal": float(esd),
                "refined_cell": {
                    key: float(number)
                    for key, number in zip(
                        ("a_A", "b_A", "c_A", "alpha_deg", "beta_deg", "gamma_deg", "volume_A3"),
                        phase.data["General"]["Cell"][1:8],
                    )
                },
            }
        )

    covariance = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "phases": phase_rows,
        "fit_statistics": profile_statistics(histogram, covariance),
        "fraction_basis": "normalized over the three modeled crystalline phases; amorphous content not determined",
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "unresolved_components": [],
    }
    (WORKSPACE / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (WORKSPACE / "analysis" / "final_export_summary.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
