#!/usr/bin/env python3
"""Export the selected GSAS-II result into the requested submission files."""

from __future__ import annotations

import csv
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PROJECT = "final.gpx"


def main():
    project = G2sc.G2Project(PROJECT)
    histogram = project.histograms()[0]
    phases = project.phases()
    if len(phases) != 2:
        raise ValueError(f"expected two selected phases, found {len(phases)}")

    cif_paths = ["NiWO4.cif", "WO3.cif"]
    for phase, path in zip(phases, cif_paths):
        phase.export_CIF(path)

    arrays = np.asarray(histogram.data["data"][1], dtype=float)
    two_theta, observed, weights, calculated = arrays[:4]
    difference = observed - calculated
    with open("fit.csv", "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["two_theta_deg", "observed_counts", "calculated_counts", "difference_counts"]
        )
        writer.writerows(zip(two_theta, observed, calculated, difference))

    lower, upper = histogram.data["Limits"][1]
    selected = (two_theta >= lower) & (two_theta <= upper)
    covariance = project.data["Covariance"]["data"]["Rvals"]
    # Use the statistics reported by the converged GSAS-II fit. The regenerated
    # profile extends to the two points just outside the refinement limits, so a
    # direct CSV recomputation is not exactly the refinement's point selection.
    rwp = float(covariance["Rwp"])
    rp = float(histogram.residuals["R"])
    fractions = histogram.ComputeMassFracs()

    records = []
    specifications = [
        ("NiWO4 (wolframite)", "NiWO4", "P2/c", cif_paths[0], phases[0].name),
        ("WO3 (monoclinic)", "WO3", "P21/c", cif_paths[1], phases[1].name),
    ]
    for name, formula, space_group, path, project_name in specifications:
        fraction, esd = fractions[project_name]
        records.append(
            {
                "name": name,
                "formula": formula,
                "space_group": space_group,
                "cif_path": path,
                "weight_fraction": float(fraction),
                "weight_fraction_formal_esd": float(esd),
            }
        )

    result = {
        "phases": records,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": float(histogram.residuals["wRmin"]),
            "GOF": float(covariance["GOF"]),
            "chi_square": float(covariance["chisq"]),
            "observations": int(covariance["Nobs"]),
            "refined_variables_in_final_scale_cycle": int(covariance["Nvars"]),
            "fit_range_two_theta_deg": [float(lower), float(upper)],
        },
        "measurement": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelengths_angstrom": [1.540598, 1.544426],
            "Kalpha2_to_Kalpha1_ratio": 0.5,
        },
    }
    with open("result.json", "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")


if __name__ == "__main__":
    main()
