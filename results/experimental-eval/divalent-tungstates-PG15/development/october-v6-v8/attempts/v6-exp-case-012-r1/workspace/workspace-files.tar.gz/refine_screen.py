#!/usr/bin/env python3
"""Build matched two-phase GSAS-II screening projects for NiWO4 + WO3."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2sc


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine_to_stability(project: G2sc.G2Project, label: str, attempts: int = 6) -> dict:
    history = []
    for _ in range(attempts):
        project.refine()
        status = dict(covariance_status(project))
        history.append(
            {
                "rwp": float(project.histograms()[0].get_wR()),
                "converged": bool(status.get("converged")),
                "max_shift_over_esd": status.get("Max shft/sig"),
                "svd": int(status.get("SVD0", 0) or 0),
                "message": status.get("msg", ""),
            }
        )
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "error" in message:
            break
        if status.get("converged") and float(status.get("Max shft/sig") or 0.0) < 0.05:
            break
    project.save()
    print("STAGE", label, json.dumps(history[-1], default=str), flush=True)
    return {"label": label, "history": history}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("wo3", type=Path)
    parser.add_argument("--wo3-name", default="WO3")
    parser.add_argument("--nio", action="store_true")
    parser.add_argument("--sizes", action="store_true")
    args = parser.parse_args()

    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(output))
    project.set_Controls("cycles", 8)
    histogram = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    histogram.set_refinements({"Limits": [10.02, 99.98]})
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": False,
                "no. coeffs": 12,
            }
        }
    )
    # Seed the empirical background from a broad lower-percentile envelope.
    # This is used only as a start; all coefficients are refined with the phases.
    x = np.asarray(histogram.data["data"][1][0], dtype=float)
    y = np.asarray(histogram.data["data"][1][1], dtype=float)
    envelope = percentile_filter(y, size=401, percentile=20, mode="nearest")
    transformed = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    coefficients = np.polynomial.chebyshev.chebfit(transformed, envelope, 11)
    histogram.Background[0][3:] = coefficients.tolist()
    # GSAS-II initializes the global histogram scale as refinable. Keep it
    # fixed so independent phase scales remain identifiable.
    histogram.SampleParameters["Scale"][1] = False

    niwo4 = project.add_phase(
        "candidates/NiWO4_wolframite_start.cif",
        phasename="NiWO4_wolframite",
        histograms=[histogram],
        fmthint="CIF",
    )
    wo3 = project.add_phase(
        str(args.wo3.resolve()),
        phasename=args.wo3_name,
        histograms=[histogram],
        fmthint="CIF",
    )
    if args.nio:
        project.add_phase(
            "candidates/NiO_rocksalt_start.cif",
            phasename="NiO_rocksalt",
            histograms=[histogram],
            fmthint="CIF",
        )

    # Conservative starts avoid enormous calculated intensities on the first cycle.
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][0] = 0.0001
        phase.set_HAP_refinements({"Scale": True})

    project.save()
    stages = []
    stages.append(refine_to_stability(project, "scales"))
    histogram.set_refinements({"Background": True})
    stages.append(refine_to_stability(project, "background-scales"))

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    stages.append(refine_to_stability(project, "cells"))

    # Same minimal global profile nuisance model for every structural branch.
    histogram.set_refinements({"Instrument Parameters": ["W", "X"]})
    stages.append(refine_to_stability(project, "global-W-X"))

    if args.sizes:
        # Optional diagnostic only. Production acceptance/rollback is handled
        # from saved baselines in the later model-selection workflow.
        for phase in project.phases():
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
            )
            stages.append(refine_to_stability(project, f"size-{phase.name}"))

    project.save()
    status = covariance_status(project)
    try:
        fractions = histogram.ComputeMassFracs()
    except Exception as error:
        fractions = {"error": repr(error)}
    summary = {
        "project": str(output),
        "wo3": str(args.wo3),
        "rwp": float(histogram.get_wR()),
        "residuals": histogram.residuals,
        "fractions": fractions,
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "scales": {
            phase.name: phase.data["Histograms"][histogram.name]["Scale"]
            for phase in project.phases()
        },
        "sizes": {
            phase.name: phase.data["Histograms"][histogram.name]["Size"]
            for phase in project.phases()
        },
        "instrument": histogram.InstrumentParameters,
        "convergence": status,
        "stages": stages,
    }
    print("SCREEN_RESULT=" + json.dumps(summary, default=str), flush=True)


if __name__ == "__main__":
    main()
