#!/usr/bin/env python3
"""Replace one active phase in a mature project under matched nuisance terms."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc

from stabilize_project import freeze_all
from test_branch import correlations, covariance_status, refine_stable


def activate_scales(project):
    histogram = project.histograms()[0]
    for phase in project.phases():
        hap = phase.data["Histograms"].get(histogram.name)
        if hap and hap.get("Use", True):
            hap["Scale"][1] = True


def run_stage(project, name, configure=None):
    freeze_all(project)
    activate_scales(project)
    if configure:
        configure()
    history = refine_stable(project)
    project.save()
    print("REPLACE_STAGE=" + json.dumps({"name": name, "history": history}), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("replace_index", type=int)
    parser.add_argument("cif")
    parser.add_argument("name")
    parser.add_argument("--heavy", action="store_true")
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.set_Controls("cycles", 8)
    freeze_all(project)
    histogram = project.histograms()[0]
    old = project.phases()[args.replace_index]
    old_hap = old.data["Histograms"][histogram.name]
    old_hap["Use"] = False
    old_hap["Scale"][1] = False
    candidate = project.add_phase(
        args.cif,
        phasename=args.name,
        histograms=[histogram],
        fmthint="CIF",
    )
    hap = candidate.data["Histograms"][histogram.name]
    hap["Scale"][:] = [float(old_hap["Scale"][0]), True]
    hap["Size"][1][0] = float(old_hap["Size"][1][0])
    hap["Mustrain"][1][0] = float(old_hap["Mustrain"][1][0])
    project.save()

    run_stage(project, "scales")
    run_stage(
        project,
        "candidate-cell",
        lambda: candidate.data["General"]["Cell"].__setitem__(0, True),
    )
    if args.heavy:
        labels = {atom.label: "X" for atom in candidate.atoms() if atom.element == "W"}
        run_stage(
            project,
            "candidate-heavy-coordinates",
            lambda: candidate.set_refinements({"Atoms": labels}),
        )

    print(
        "REPLACE_RESULT="
        + json.dumps(
            {
                "project": args.output,
                "rwp": float(histogram.get_wR()),
                "fractions": histogram.ComputeMassFracs(),
                "scales": {
                    phase.name: phase.data["Histograms"][histogram.name]["Scale"]
                    for phase in project.phases()
                },
                "cells": {phase.name: phase.get_cell() for phase in project.phases()},
                "correlations": correlations(project),
                "status": covariance_status(project),
            },
            default=str,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
