#!/usr/bin/env python3
"""Add one candidate phase to a frozen mature project and refine phase scales."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc

from stabilize_project import freeze_all
from test_branch import correlations, covariance_status, refine_stable


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("cif")
    parser.add_argument("name")
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.set_Controls("cycles", 8)
    freeze_all(project)
    histogram = project.histograms()[0]
    candidate = project.add_phase(
        args.cif,
        phasename=args.name,
        histograms=[histogram],
        fmthint="CIF",
    )
    hap = candidate.data["Histograms"][histogram.name]
    hap["Scale"][:] = [0.01, True]
    hap["Size"][1][0] = 10.0
    hap["Mustrain"][1][0] = 0.0
    for phase in project.phases()[:-1]:
        phase.data["Histograms"][histogram.name]["Scale"][1] = True
    project.save()
    history = refine_stable(project)
    project.save()
    print(
        "ADD_CANDIDATE_RESULT="
        + json.dumps(
            {
                "project": args.output,
                "rwp": float(histogram.get_wR()),
                "history": history,
                "scales": {
                    phase.name: phase.data["Histograms"][histogram.name]["Scale"]
                    for phase in project.phases()
                },
                "fractions": histogram.ComputeMassFracs(),
                "correlations": correlations(project),
                "status": covariance_status(project),
            },
            default=str,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
