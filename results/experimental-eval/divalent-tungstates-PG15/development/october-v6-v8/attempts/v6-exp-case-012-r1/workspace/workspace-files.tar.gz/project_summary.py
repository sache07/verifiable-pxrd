#!/usr/bin/env python3
"""Print compact diagnostics for one or more GSAS-II projects."""

from __future__ import annotations

import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def correlations(project, threshold=0.9):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    output = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            denominator = sigma[i] * sigma[j]
            if denominator:
                value = float(matrix[i, j] / denominator)
                if abs(value) >= threshold:
                    output.append([names[i], names[j], value])
    return sorted(output, key=lambda row: abs(row[2]), reverse=True)


def summarize(path):
    project = G2sc.G2Project(path)
    histogram = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "path": path,
        "rwp": float(histogram.get_wR()),
        "gof": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "svd": rvals.get("SVD0", 0),
        "shift_esd": rvals.get("Max shft/sig"),
        "fractions": histogram.ComputeMassFracs(),
        "instrument": {
            key: histogram.InstrumentParameters[key][1:]
            for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            key: histogram.SampleParameters.get(key)
            for key in ("Shift", "DisplaceX", "DisplaceY", "SurfRoughA", "SurfRoughB")
        },
        "hap": {
            phase.name: {
                key: phase.data["Histograms"][histogram.name].get(key)
                for key in ("Scale", "Pref.Ori.", "Size", "Mustrain")
            }
            for phase in project.phases()
        },
        "correlations": correlations(project),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("projects", nargs="+")
    args = parser.parse_args()
    for project in args.projects:
        print(json.dumps(summarize(project), default=str))


if __name__ == "__main__":
    main()
