#!/usr/bin/env python3
"""Run a matched optional-model branch from a frozen GSAS-II baseline."""

from __future__ import annotations

import argparse
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from stabilize_project import freeze_all


def covariance_status(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def correlations(project, threshold=0.90):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sigmas = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    rows = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            denominator = sigmas[i] * sigmas[j]
            if denominator <= 0:
                continue
            value = float(matrix[i, j] / denominator)
            if abs(value) >= threshold:
                rows.append([names[i], names[j], value])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)


def refine_stable(project, attempts=8):
    history = []
    for _ in range(attempts):
        project.refine()
        rv = covariance_status(project)
        item = {
            "rwp": float(project.histograms()[0].get_wR()),
            "converged": bool(rv.get("converged")),
            "svd": int(rv.get("SVD0", 0) or 0),
            "max_shift_over_esd": float(rv.get("Max shft/sig") or 0.0),
            "message": str(rv.get("msg", "") or ""),
        }
        history.append(item)
        message = item["message"].lower()
        if item["svd"] or "error" in message or rv.get("Aborted"):
            break
        if item["converged"] and abs(item["max_shift_over_esd"]) < 0.05:
            break
    return history


def activate_scales(project):
    histogram = project.histograms()[0]
    for phase in project.phases():
        phase.data["Histograms"][histogram.name]["Scale"][1] = True


def configure(project, mode, axis=None):
    histogram = project.histograms()[0]
    activate_scales(project)
    if mode == "scales":
        pass
    elif mode == "omit-roughness":
        histogram.SampleParameters["SurfRoughB"][:] = [0.0, False]
    elif mode == "omit-wo3-strain":
        project.phases()[1].data["Histograms"][histogram.name]["Mustrain"][1][0] = 0.0
    elif mode == "omit-zero":
        histogram.InstrumentParameters["Zero"][1] = 0.0
    elif mode == "omit-wo3":
        hap = project.phases()[1].data["Histograms"][histogram.name]
        hap["Use"] = False
        hap["Scale"][1] = False
    elif mode == "reset-U":
        histogram.InstrumentParameters["U"][1] = 2.0
    elif mode == "background":
        histogram.Background[0][1] = True
    elif mode == "clear-phase-broadening":
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            hap["Size"][1][0] = 1.0e6
            hap["Mustrain"][1][0] = 0.0
    elif mode == "zero":
        histogram.InstrumentParameters["Zero"][2] = True
    elif mode == "cells":
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
    elif mode in {"cell-niwo4", "cell-wo3"}:
        phase = project.phases()[0 if mode.endswith("niwo4") else 1]
        phase.data["General"]["Cell"][0] = True
    elif mode == "roughness-continue":
        histogram.SampleParameters["SurfRoughB"][1] = True
    elif mode == "roughness-polarization":
        histogram.SampleParameters["SurfRoughB"][1] = True
        histogram.InstrumentParameters["Polariz."][2] = True
    elif mode == "inst-XY":
        histogram.InstrumentParameters["X"][2] = True
        histogram.InstrumentParameters["Y"][2] = True
    elif mode == "polarization":
        histogram.InstrumentParameters["Polariz."][2] = True
    elif mode == "roughness":
        histogram.SampleParameters["SurfRoughA"][:] = [0.0, False]
        histogram.SampleParameters["SurfRoughB"][:] = [0.01, True]
    elif mode in {
        "inst-U",
        "inst-V",
        "inst-W",
        "inst-X",
        "inst-Y",
        "inst-Z",
        "inst-SH/L",
    }:
        key = mode.split("-", 1)[1]
        histogram.InstrumentParameters[key][2] = True
    elif mode in {"size-niwo4", "size-wo3"}:
        phase = project.phases()[0 if mode.endswith("niwo4") else 1]
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
        )
    elif mode in {"strain-niwo4", "strain-wo3"}:
        phase = project.phases()[0 if mode.endswith("niwo4") else 1]
        phase.data["Histograms"][histogram.name]["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    elif mode == "coords-niwo4-all":
        project.phases()[0].set_refinements({"Atoms": {"all": "X"}})
    elif mode == "coords-niwo4-heavy":
        project.phases()[0].set_refinements(
            {"Atoms": {"Ni1": "X", "W1": "X"}}
        )
    elif mode == "coords-wo3-heavy":
        phase = project.phases()[1]
        labels = {atom.label: "X" for atom in phase.atoms() if atom.element == "W"}
        phase.set_refinements({"Atoms": labels})
    elif mode == "coords-wo3-oxygen":
        phase = project.phases()[1]
        labels = {atom.label: "X" for atom in phase.atoms() if atom.element == "O"}
        phase.set_refinements({"Atoms": labels})
    elif mode == "coords-wo3-all":
        project.phases()[1].set_refinements({"Atoms": {"all": "X"}})
    elif mode in {"uiso-niwo4", "uiso-wo3"}:
        phase = project.phases()[0 if mode.endswith("niwo4") else 1]
        phase.set_refinements({"Atoms": {"all": "U"}})
    elif mode in {"texture-niwo4", "texture-wo3"}:
        if axis is None:
            raise ValueError("texture mode requires --axis")
        phase = project.phases()[0 if mode.endswith("niwo4") else 1]
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
    else:
        raise ValueError(mode)


def snapshot(project):
    histogram = project.histograms()[0]
    return {
        "rwp": float(histogram.get_wR()),
        "fractions": histogram.ComputeMassFracs(),
        "instrument": histogram.InstrumentParameters,
        "sample": histogram.SampleParameters,
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "atoms": {
            phase.name: [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": atom.coordinates,
                    "uiso": atom.uiso,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ]
            for phase in project.phases()
        },
        "hap": {
            phase.name: {
                key: phase.data["Histograms"][histogram.name].get(key)
                for key in ("Scale", "Pref.Ori.", "Size", "Mustrain")
            }
            for phase in project.phases()
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("mode")
    parser.add_argument("--axis", nargs=3, type=int)
    args = parser.parse_args()

    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.set_Controls("cycles", 8)
    freeze_all(project)
    configure(project, args.mode, args.axis)
    project.save()
    history = refine_stable(project)
    project.save()
    result = {
        "mode": args.mode,
        "axis": args.axis,
        "project": args.output,
        "history": history,
        "stable": bool(
            history
            and history[-1]["converged"]
            and history[-1]["svd"] == 0
            and abs(history[-1]["max_shift_over_esd"]) < 0.05
        ),
        "correlations_over_0.90": correlations(project),
        **snapshot(project),
    }
    print("BRANCH_RESULT=" + json.dumps(result, default=str), flush=True)


if __name__ == "__main__":
    main()
