#!/usr/bin/env python3
"""Stabilize a selected GSAS-II model by alternating weakly correlated groups."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def status(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def freeze_all(project):
    histogram = project.histograms()[0]
    histogram.Background[0][1] = False
    for parameter in histogram.InstrumentParameters.values():
        if isinstance(parameter, list) and len(parameter) >= 3:
            parameter[2] = False
    for parameter in histogram.SampleParameters.values():
        if isinstance(parameter, list) and len(parameter) == 2:
            parameter[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.data["Atoms"]:
            atom[2] = ""
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = False
        if "Pref.Ori." in hap:
            hap["Pref.Ori."][2] = False
        for key in ("Size", "Mustrain"):
            if key in hap:
                hap[key][2] = [False] * len(hap[key][2])
                if len(hap[key]) > 5:
                    hap[key][5] = [False] * len(hap[key][5])
        if "HStrain" in hap:
            hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        if "Extinction" in hap:
            hap["Extinction"][1] = False


def activate(project, group):
    histogram = project.histograms()[0]
    if group == "scale":
        for phase in project.phases():
            phase.data["Histograms"][histogram.name]["Scale"][1] = True
    elif group == "background-scale":
        histogram.Background[0][1] = True
        activate(project, "scale")
    elif group == "zero-scale":
        histogram.InstrumentParameters["Zero"][2] = True
        activate(project, "scale")
    elif group == "cells-scale":
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
        activate(project, "scale")
    elif group == "W-scale":
        histogram.InstrumentParameters["W"][2] = True
        activate(project, "scale")
    elif group == "X-scale":
        histogram.InstrumentParameters["X"][2] = True
        activate(project, "scale")
    else:
        raise ValueError(group)


def run_group(project, group, attempts=8):
    freeze_all(project)
    activate(project, group)
    history = []
    for _ in range(attempts):
        project.refine()
        rv = status(project)
        item = {
            "rwp": float(project.histograms()[0].get_wR()),
            "converged": bool(rv.get("converged")),
            "svd": int(rv.get("SVD0", 0) or 0),
            "max_shift_over_esd": float(rv.get("Max shft/sig") or 0.0),
            "message": str(rv.get("msg", "") or ""),
        }
        history.append(item)
        if item["svd"] or "error" in item["message"].lower():
            break
        if item["converged"] and abs(item["max_shift_over_esd"]) < 0.05:
            break
    print("STABILIZE_STAGE=" + json.dumps({"group": group, "history": history}), flush=True)
    return history[-1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    args = parser.parse_args()
    project = G2sc.G2Project(args.source, newgpx=args.output)
    project.set_Controls("cycles", 8)
    project.save()
    for group in (
        "scale",
        "background-scale",
        "zero-scale",
        "cells-scale",
        "W-scale",
        "X-scale",
        "zero-scale",
        "cells-scale",
        "background-scale",
    ):
        run_group(project, group)
    # Leave a minimal, stable covariance model for phase-fraction uncertainties.
    freeze_all(project)
    activate(project, "scale")
    final = run_group(project, "scale")
    project.save()
    histogram = project.histograms()[0]
    print(
        "STABILIZE_RESULT="
        + json.dumps(
            {
                "project": args.output,
                "rwp": float(histogram.get_wR()),
                "fractions": histogram.ComputeMassFracs(),
                "zero": histogram.InstrumentParameters["Zero"],
                "instrument": {
                    key: histogram.InstrumentParameters[key]
                    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L")
                },
                "cells": {phase.name: phase.get_cell() for phase in project.phases()},
                "convergence": final,
            },
            default=str,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
