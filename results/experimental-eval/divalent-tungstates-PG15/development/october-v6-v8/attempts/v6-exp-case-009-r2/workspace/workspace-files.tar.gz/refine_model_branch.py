#!/usr/bin/env python3
"""Create matched GSAS-II refinement branches used for the final model audit."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def covariance(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {})


def refine_to_stability(project: G2sc.G2Project, cycles: int = 10) -> bool:
    for _ in range(cycles):
        try:
            project.refine()
        except Exception as error:
            print(f"REFINEMENT_ERROR={error!r}")
            return False
        status = covariance(project).get("Rvals", {})
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0):
            return False
        if "dropped" in message or "error" in message:
            return False
        if status.get("converged") and abs(float(status.get("Max shft/sig") or 0)) < 0.05:
            return True
    return False


def correlation_summary(project: G2sc.G2Project) -> dict:
    cov = covariance(project)
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return {"maximum": None, "pair": None, "changed_parameter_pairs": []}
    pairs = []
    for i in range(len(names)):
        for j in range(i):
            denom = math.sqrt(max(matrix[i, i], 0.0) * max(matrix[j, j], 0.0))
            if denom <= 0:
                continue
            value = abs(float(matrix[i, j]) / denom)
            pairs.append((value, names[j], names[i]))
    pairs.sort(reverse=True)
    relevant = [
        {"correlation": v, "parameters": [a, b]}
        for v, a, b in pairs
        if any(key in a or key in b for key in ("Size", "Mustrain", "Polariz", "Pref.Ori."))
    ][:10]
    if not pairs:
        return {"maximum": None, "pair": None, "changed_parameter_pairs": relevant}
    return {
        "maximum": pairs[0][0],
        "pair": list(pairs[0][1:]),
        "changed_parameter_pairs": relevant,
    }


def local_rwp(project: G2sc.G2Project) -> list[dict]:
    data = project.histograms()[0].data["data"][1]
    x, obs, weights, calc = (np.asarray(data[i], dtype=float) for i in range(4))
    result = []
    for lower in range(10, 100, 10):
        upper = lower + 10
        mask = (x >= lower) & (x < upper)
        denominator = np.sum(weights[mask] * obs[mask] ** 2)
        numerator = np.sum(weights[mask] * (obs[mask] - calc[mask]) ** 2)
        result.append(
            {
                "range_deg": [lower, upper],
                "rwp_percent": 100 * math.sqrt(numerator / denominator),
            }
        )
    return result


def configure(project: G2sc.G2Project, mode: str, value: float | None) -> None:
    histogram = project.histograms()[0]
    phase = project.phases()[0]
    hap = phase.data["Histograms"][histogram.name]
    instrument = histogram.InstrumentParameters
    sample = histogram.SampleParameters

    if mode == "noop":
        return
    if mode == "neutral":
        # Size is in micrometres and contributes inversely. GSAS-II's upper
        # bound is 10 um, where its contribution is negligible relative to
        # the observed widths here. Zero microstrain is exactly neutral.
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2][0] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2][0] = False
    elif mode == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 2.0 if value is None else value
        hap["Size"][2][0] = True
    elif mode == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0 if value is None else value
        hap["Mustrain"][2][0] = True
    elif mode == "strain_off":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2][0] = False
    elif mode in {"U", "V", "X", "Y", "Z", "SH/L"}:
        default = {"U": 10.0, "V": 5.0, "X": 1.0, "Y": 1.0, "Z": 1.0, "SH/L": 0.01}[mode]
        instrument[mode][1] = default if value is None else value
        instrument[mode][2] = True
    elif mode == "Z_off":
        instrument["Z"][1] = 0.0
        instrument["Z"][2] = False
    elif mode == "shift_off":
        instrument["Zero"][1:] = [0.0, False]
        sample["Shift"][:] = [0.0, False]
    elif mode == "surface_off":
        sample["SurfRoughA"][:] = [0.0, False]
        sample["SurfRoughB"][:] = [0.0, False]
    elif mode == "surface_A_add":
        sample["SurfRoughA"][:] = [0.01 if value is None else value, True]
    elif mode == "polarization_only":
        sample["SurfRoughA"][:] = [0.0, False]
        sample["SurfRoughB"][:] = [0.0, False]
        instrument["Polariz."][1] = 0.7 if value is None else value
        instrument["Polariz."][2] = True
    elif mode == "polarization_add":
        instrument["Polariz."][1] = 0.7 if value is None else value
        instrument["Polariz."][2] = True
    elif mode == "adp_source_fixed":
        for atom, uiso in zip(phase.data["Atoms"][:2], (0.0078, 0.0070)):
            atom[2] = atom[2].replace("U", "")
            atom[10] = uiso
    elif mode == "coords_source_fixed":
        source_xyz = (
            (0.5, 0.6846, 0.25),
            (0.0, 0.18116, 0.25),
            (0.2124, 0.1000, 0.9432),
            (0.2498, 0.3780, 0.3937),
        )
        for atom, xyz in zip(phase.data["Atoms"], source_xyz):
            atom[2] = atom[2].replace("X", "")
            atom[3:6] = xyz
    elif mode.startswith("texture_"):
        axis = [int(part) for part in mode.removeprefix("texture_").split(",")]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
    else:
        raise ValueError(f"unknown mode {mode!r}")


def main() -> None:
    if len(sys.argv) not in (4, 5):
        raise SystemExit("usage: refine_model_branch.py SOURCE.gpx OUTPUT.gpx MODE [VALUE]")
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    mode = sys.argv[3]
    value = None if len(sys.argv) == 4 else float(sys.argv[4])
    project = G2sc.G2Project(str(source))
    configure(project, mode, value)
    project.save(str(output))
    stable = refine_to_stability(project)
    project.save(str(output))
    histogram = project.histograms()[0]
    hap = project.phases()[0].data["Histograms"][histogram.name]
    status = covariance(project).get("Rvals", {})
    result = {
        "mode": mode,
        "stable": stable,
        "rwp_percent": float(histogram.get_wR()),
        "gof": status.get("GOF"),
        "maximum_shift_over_esd": status.get("Max shft/sig"),
        "svd_dropped": status.get("SVD0"),
        "message": status.get("msg"),
        "size": hap["Size"],
        "microstrain": hap["Mustrain"],
        "instrument": {key: histogram.InstrumentParameters[key] for key in ("U", "V", "W", "X", "Y", "Z", "Polariz.")},
        "sample": {key: histogram.SampleParameters[key] for key in ("Shift", "SurfRoughA", "SurfRoughB")},
        "preferred_orientation": hap["Pref.Ori."],
        "correlations": correlation_summary(project),
        "local_rwp": local_rwp(project),
    }
    print("BRANCH_RESULT=" + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
