#!/usr/bin/env python3
"""Regenerate and export the final GSAS-II profile and phase CIFs."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from learned.profile_regeneration import regenerate_profile


def plain(value):
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (list, tuple)):
        return [plain(item) for item in value]
    if isinstance(value, dict):
        return {str(key): plain(item) for key, item in value.items()}
    return value


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: export_submission.py final.gpx")
    project_path = Path(sys.argv[1]).resolve()
    regenerate_profile(project_path)
    project = G2sc.G2Project(str(project_path))
    histogram = project.histograms()[0]
    phases = project.phases()
    if not phases:
        raise ValueError("no phases in final project")

    exports = []
    for number, phase in enumerate(phases, 1):
        safe_name = "".join(character for character in phase.name if character.isalnum())
        cif_path = project_path.parent / f"phase_{number}_{safe_name}.cif"
        phase.export_CIF(str(cif_path))
        exports.append({"phase": phase.name, "cif": cif_path.name})

    profile = np.ma.filled(histogram.data["data"][1], np.nan)
    output_profile = np.column_stack(
        (profile[0], profile[1], profile[3], profile[5], profile[4])
    )
    np.savetxt(
        project_path.parent / "fit.csv",
        output_profile,
        delimiter=",",
        header=(
            "two_theta_deg,observed_counts,calculated_counts,"
            "difference_counts,background_counts"
        ),
        comments="",
        fmt="%.10g",
    )

    cov = project.data.get("Covariance", {}).get("data", {})
    names = list(cov.get("varyList", []))
    variables = list(cov.get("variables", []))
    sigmas = list(cov.get("sig", []))
    refined = {
        name: {"value": variables[index], "esd": sigmas[index]}
        for index, name in enumerate(names)
    }
    phase_summary = []
    for phase in phases:
        general = phase.data["General"]
        hap = phase.data["Histograms"][histogram.name]
        phase_summary.append(
            {
                "name": phase.name,
                "space_group": general["SGData"].get("SpGrp"),
                "cell": general["Cell"],
                "atoms": phase.data["Atoms"],
                "scale": hap["Scale"],
                "size": hap["Size"],
                "microstrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    summary = {
        "exports": exports,
        "histogram_residuals": histogram.data["data"][0],
        "covariance_residuals": cov.get("Rvals", {}),
        "mass_fractions": histogram.ComputeMassFracs(),
        "instrument": histogram.InstrumentParameters,
        "sample": histogram.SampleParameters,
        "background": histogram.Background,
        "phases": phase_summary,
        "refined_parameters": refined,
        "profile_rows": len(output_profile),
        "maximum_profile_identity_error": float(
            np.nanmax(np.abs(profile[5] - (profile[1] - profile[3])))
        ),
    }
    print("EXPORT_SUMMARY=" + json.dumps(plain(summary), sort_keys=True))


if __name__ == "__main__":
    main()
