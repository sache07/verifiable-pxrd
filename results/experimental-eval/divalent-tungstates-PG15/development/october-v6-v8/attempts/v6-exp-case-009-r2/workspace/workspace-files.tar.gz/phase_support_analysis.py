#!/usr/bin/env python3
"""Summarize profile support for a trace candidate in a two-phase GPX file."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2sc

from learned.profile_regeneration import regenerate_profile


def arrays(path: Path):
    histogram = G2sc.G2Project(str(path)).histograms()[0]
    return tuple(np.asarray(row, dtype=float) for row in histogram.data["data"][1])


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: phase_support_analysis.py TWO_PHASE.gpx OFF_COPY.gpx")
    source, off_path = (Path(arg).resolve() for arg in sys.argv[1:])
    on_project = G2sc.G2Project(str(source))
    if len(on_project.phases()) != 2:
        raise ValueError("expected exactly two phases")
    histogram = on_project.histograms()[0]
    candidate = on_project.phases()[1]
    candidate_scale = candidate.data["Histograms"][histogram.name]["Scale"][0]
    regenerate_profile(source)

    off_project = G2sc.G2Project(str(source))
    off_project.save(str(off_path))
    off_project = G2sc.G2Project(str(off_path))
    off_histogram = off_project.histograms()[0]
    off_candidate = off_project.phases()[1]
    off_candidate.data["Histograms"][off_histogram.name]["Scale"][:] = [0.0, False]
    off_project.save(str(off_path))
    regenerate_profile(off_path)

    x, observed, weights, calc_on, background_on, _ = arrays(source)
    _, _, _, calc_off, _, _ = arrays(off_path)
    contribution = calc_on - calc_off
    residual_on = observed - calc_on
    residual_off = observed - calc_off
    step = float(np.median(np.diff(x)))
    peak_indices, _ = find_peaks(
        contribution,
        distance=max(1, round(0.08 / step)),
        prominence=max(0.1, float(np.max(contribution)) * 0.002),
    )
    main_reflections = np.asarray(
        G2sc.G2Project(str(source)).histograms()[0].data["Reflection Lists"]
        [on_project.phases()[0].name]["RefList"],
        dtype=float,
    )
    main_positions = main_reflections[:, 5]
    rows = []
    half_window = max(1, round(0.12 / step))
    for index in peak_indices:
        lo, hi = max(0, index - half_window), min(len(x), index + half_window + 1)
        delta_chi2 = np.sum(
            weights[lo:hi]
            * (residual_off[lo:hi] ** 2 - residual_on[lo:hi] ** 2)
        )
        rows.append(
            {
                "two_theta_deg": float(x[index]),
                "candidate_peak_counts": float(contribution[index]),
                "observed_minus_candidate_off_counts": float(residual_off[index]),
                "observed_minus_candidate_on_counts": float(residual_on[index]),
                "window_delta_chi2": float(delta_chi2),
                "nearest_MnWO4_reflection_deg": float(
                    np.min(np.abs(main_positions - x[index]))
                ),
            }
        )
    rows.sort(key=lambda row: row["candidate_peak_counts"], reverse=True)
    total_delta = float(np.sum(weights * (residual_off**2 - residual_on**2)))
    positive_unique = [
        row
        for row in rows
        if row["window_delta_chi2"] > 2.0
        and row["nearest_MnWO4_reflection_deg"] > 0.10
    ]
    adverse = [row for row in rows if row["window_delta_chi2"] < -2.0]
    print(
        json.dumps(
            {
                "candidate_scale": candidate_scale,
                "overall_delta_chi2_fixed_nuisance": total_delta,
                "positive_unique_peak_count": len(positive_unique),
                "adverse_peak_count": len(adverse),
                "top_profile_peaks": rows[:30],
                "top_positive_unique_peaks": sorted(
                    positive_unique,
                    key=lambda row: row["window_delta_chi2"],
                    reverse=True,
                )[:20],
                "strongest_adverse_predictions": sorted(
                    adverse, key=lambda row: row["window_delta_chi2"]
                )[:20],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
