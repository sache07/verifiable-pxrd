#!/usr/bin/env python3
"""Add one atomistic candidate to a mature GSAS-II model and refine its scale."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_model_branch import covariance, refine_to_stability


def main() -> None:
    if len(sys.argv) != 5:
        raise SystemExit(
            "usage: retest_candidate_phase.py BASE.gpx OUT.gpx CANDIDATE.cif NAME"
        )
    source, output, candidate = map(Path, sys.argv[1:4])
    name = sys.argv[4]
    # Repoint the project before add_phase: GSAS-II's phase importer updates
    # the active project on disk while rebuilding IDs.
    project = G2sc.G2Project(str(source.resolve()))
    project.save(str(output.resolve()))
    project = G2sc.G2Project(str(output.resolve()))
    histogram = project.histograms()[0]
    phase = project.add_phase(
        str(candidate.resolve()),
        phasename=name,
        histograms=[histogram],
        fmthint="CIF",
    )
    phase.data["General"]["Cell"][0] = False
    for atom in phase.data["Atoms"]:
        atom[2] = ""
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"][:] = [0.01, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    project.save(str(output.resolve()))
    stable = refine_to_stability(project)
    project.save(str(output.resolve()))
    status = covariance(project).get("Rvals", {})
    print(
        "CANDIDATE_RESULT="
        + json.dumps(
            {
                "candidate": name,
                "stable": stable,
                "rwp_percent": float(project.histograms()[0].get_wR()),
                "candidate_scale": hap["Scale"],
                "converged": status.get("converged"),
                "svd_dropped": status.get("SVD0"),
                "maximum_shift_over_esd": status.get("Max shft/sig"),
                "message": status.get("msg"),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
