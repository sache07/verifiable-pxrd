#!/usr/bin/env python3
"""Add one candidate phase to a stable project and test complete-pattern support."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def rvals(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def converge(project, rounds=12):
    history = []
    for _ in range(rounds):
        project.refine()
        r = rvals(project)
        history.append(
            {
                "rwp": float(project.histograms()[0].get_wR()),
                "converged": bool(r.get("converged")),
                "svd": int(r.get("SVD0", 0) or 0),
                "max_shift_esd": float(r.get("Max shft/sig") or 0.0),
                "message": r.get("msg"),
            }
        )
        if (
            r.get("converged")
            and not r.get("SVD0", 0)
            and abs(float(r.get("Max shft/sig") or 0.0)) < 0.05
        ):
            break
    return history


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output")
    parser.add_argument("cif")
    parser.add_argument("name")
    parser.add_argument("--rounds", type=int, default=12)
    args = parser.parse_args()

    project = G2sc.G2Project(args.base, newgpx=args.output)
    project.set_Controls("cycles", 12)
    histogram = project.histograms()[0]
    phase = project.add_phase(
        args.cif,
        phasename=args.name,
        histograms=[histogram],
        fmthint="CIF",
    )
    phase.data["Histograms"][histogram.name]["Scale"][0] = 1.0
    phase.set_HAP_refinements({"Scale": True})
    project.save()

    scale_history = converge(project, args.rounds)
    phase.set_refinements({"Cell": True})
    project.save()
    cell_history = converge(project, args.rounds)
    project.save()

    try:
        fractions = histogram.ComputeMassFracs()
    except Exception as error:
        fractions = {"error": repr(error)}
    report = {
        "base": args.base,
        "output": args.output,
        "candidate": args.cif,
        "scale_history": scale_history,
        "cell_history": cell_history,
        "rwp": float(histogram.get_wR()),
        "fractions": fractions,
        "phases": [
            {
                "name": item.name,
                "composition": item.composition,
                "cell": item.get_cell(),
                "scale": item.data["Histograms"][histogram.name]["Scale"],
            }
            for item in project.phases()
        ],
        "convergence": rvals(project),
    }
    print("CANDIDATE_RESULT=" + json.dumps(report, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
