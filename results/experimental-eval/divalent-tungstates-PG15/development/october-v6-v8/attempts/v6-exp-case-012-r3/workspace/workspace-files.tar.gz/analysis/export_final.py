#!/usr/bin/env python3
"""Export the machine-readable deliverables from the frozen GSAS-II project."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PROJECT = Path("final.gpx")

PHASE_METADATA = {
    "NiWO4_wolframite": {
        "display_name": "NiWO4 (wolframite)",
        "formula": "NiWO4",
        "cif_path": "phase_NiWO4.cif",
        "model_source": "Wolframite topology from COD 9013902 with charge-balanced Mg-to-Ni substitution; NiWO4 starting cell from COD 5910277",
    },
    "WO3_monoclinic": {
        "display_name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif_path": "phase_WO3_monoclinic.cif",
        "model_source": "COD 2311041",
    },
}


def finite_float(value):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"nonfinite output value: {value}")
    return value


def main():
    project = G2sc.G2Project(str(PROJECT))
    histogram = project.histograms()[0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    residuals = histogram.residuals
    fractions = histogram.ComputeMassFracs()

    phase_records = []
    for phase in project.phases():
        if phase.name not in PHASE_METADATA:
            raise RuntimeError(f"unexpected final phase: {phase.name}")
        metadata = PHASE_METADATA[phase.name]
        phase.export_CIF(metadata["cif_path"])
        fraction, fraction_esd = fractions[phase.name]
        cell = phase.get_cell()
        p_id = phase.data["pId"]
        h_id = histogram.data["data"][0]["hId"]
        phase_records.append(
            {
                "name": metadata["display_name"],
                "formula": metadata["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": metadata["cif_path"],
                "weight_fraction": finite_float(fraction),
                "weight_fraction_esd_formal": finite_float(fraction_esd),
                "cell": {key: finite_float(value) for key, value in cell.items()},
                "bragg_Rf_percent": finite_float(
                    residuals[f"{p_id}:{h_id}:Rf"]
                ),
                "bragg_Rf2_percent": finite_float(
                    residuals[f"{p_id}:{h_id}:Rf^2"]
                ),
                "model_source": metadata["model_source"],
            }
        )

    total = sum(record["weight_fraction"] for record in phase_records)
    for record in phase_records:
        record["weight_fraction"] /= total

    x, observed, weights, calculated, background, _ = histogram.data["data"][1]
    x = np.asarray(x, dtype=float)
    observed = np.asarray(observed, dtype=float)
    calculated = np.asarray(calculated, dtype=float)
    background = np.asarray(background, dtype=float)
    difference = observed - calculated
    with Path("fit.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity_counts",
                "calculated_intensity_counts",
                "difference_observed_minus_calculated_counts",
                "background_intensity_counts",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    gof = finite_float(rvals["GOF"])
    output = {
        "phases": phase_records,
        "fit_statistics": {
            "Rwp_percent": finite_float(histogram.get_wR()),
            "Rp_percent": finite_float(residuals["R"]),
            "Rexp_percent": finite_float(residuals["wRmin"]),
            "goodness_of_fit": gof,
            "reduced_chi_squared": gof * gof,
            "weighted_sum_of_squares": finite_float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_variables": int(rvals["Nvars"]),
            "converged": bool(rvals["converged"]),
            "svd_dropped_variables": int(rvals.get("SVD0", 0) or 0),
            "maximum_shift_over_esd": finite_float(rvals["Max shft/sig"]),
        },
        "fraction_basis": "Normalized over the modeled crystalline phases only; no amorphous fraction was calibrated.",
        "uncertainty_note": "weight_fraction_esd_formal contains least-squares precision only and excludes phase-model, absorption, preferred-orientation, and uncalibrated-instrument systematics.",
        "profile_path": "fit.csv",
        "project_path": "final.gpx",
        "unresolved_components": [],
        "excluded_trace_tests": [
            {
                "candidate": "NiO",
                "reason": "0.00223(86) modeled weight fraction with only 0.00174 percentage-point Rwp benefit; not reliable enough to include",
            }
        ],
    }
    Path("result.json").write_text(
        json.dumps(output, indent=2, sort_keys=False) + "\n", encoding="utf-8"
    )
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
