#!/usr/bin/env python3
"""Print compact, comparable diagnostics for one or more GSAS-II projects."""

from __future__ import annotations

import argparse
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def correlations(project, cutoff=0.8):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    result = []
    for left in range(len(names)):
        for right in range(left + 1, len(names)):
            denominator = sigma[left] * sigma[right]
            if denominator <= 0:
                continue
            value = float(matrix[left, right] / denominator)
            if abs(value) >= cutoff:
                result.append(
                    {"value": value, "left": names[left], "right": names[right]}
                )
    return sorted(result, key=lambda item: abs(item["value"]), reverse=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("projects", nargs="+")
    parser.add_argument("--correlation-cutoff", type=float, default=0.8)
    args = parser.parse_args()
    for path in args.projects:
        project = G2sc.G2Project(path)
        histogram = project.histograms()[0]
        covariance = project.data.get("Covariance", {}).get("data", {})
        residuals = histogram.residuals
        variables = dict(
            zip(
                covariance.get("varyList", []),
                covariance.get("variables", []),
            )
        )
        sigmas = dict(
            zip(
                covariance.get("varyList", []),
                covariance.get("sig", []),
            )
        )
        phase_rows = []
        fractions = histogram.ComputeMassFracs()
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            phase_rows.append(
                {
                    "name": phase.name,
                    "fraction": fractions.get(phase.name),
                    "cell": phase.get_cell(),
                    "scale": hap["Scale"],
                    "size": hap["Size"],
                    "mustrain": hap["Mustrain"],
                    "preferred_orientation": hap["Pref.Ori."],
                }
            )
        instrument = {
            name: values
            for name, values in histogram.InstrumentParameters.items()
            if name in {"Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        }
        sample = {
            name: value
            for name, value in histogram.SampleParameters.items()
            if name in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
        }
        result = {
            "path": path,
            "rwp": histogram.get_wR(),
            "rp": residuals.get("R"),
            "rexp": residuals.get("wRmin"),
            "gof": covariance.get("Rvals", {}).get("GOF"),
            "convergence": {
                key: covariance.get("Rvals", {}).get(key)
                for key in ("converged", "SVD0", "Max shft/sig", "msg", "Nvars")
            },
            "instrument": instrument,
            "sample": sample,
            "selected_variable_sigmas": {
                name: [variables[name], sigmas.get(name)]
                for name in variables
                if any(
                    token in name
                    for token in (
                        ":U", ":V", ":W", ":X", ":Y", ":Z", ":SH/L",
                        ":Polariz.", "SurfRough", "Mustrain", "Size", "MD",
                    )
                )
            },
            "phases": phase_rows,
            "high_correlations": correlations(project, args.correlation_cutoff),
        }
        print(json.dumps(result, allow_nan=False, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
