#!/usr/bin/env python3
"""Matched staged candidate test with rollback on unstable/worsening steps."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def rvals(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def summary(project):
    h = project.histograms()[0]
    r = rvals(project)
    return {
        "rwp": float(h.get_wR()),
        "converged": bool(r.get("converged")),
        "svd": int(r.get("SVD0", 0) or 0),
        "max_shift_esd": float(r.get("Max shft/sig") or 0.0),
        "message": r.get("msg"),
    }


def configure(project, stage):
    histogram = project.histograms()[0]
    histogram.Background[0][1] = True
    histogram.SampleParameters["Scale"][1] = False
    histogram.SampleParameters["Shift"][1] = False
    for key, value in histogram.InstrumentParameters.items():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = key in stage["instrument"]
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = stage["cells"]
        for atom in phase.data["Atoms"]:
            atom[2] = ""
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])


def refine_stage(project, output, checkpoint, stage_name, max_rounds=3):
    history = []
    project.save(str(checkpoint))
    best_rwp = float(project.histograms()[0].get_wR())
    shift_factor = float(project.data["Controls"]["data"].get("shift factor", 1.0))
    attempts = 0
    accepted = 0
    while attempts < max_rounds:
        attempts += 1
        project.data["Controls"]["data"]["shift factor"] = shift_factor
        project.save(output)
        try:
            project.refine()
        except Exception as error:
            history.append({"error": repr(error), "shift_factor": shift_factor})
            shift_factor *= 0.5
            project = G2sc.G2Project(str(checkpoint), newgpx=output)
            continue
        item = summary(project)
        item["shift_factor"] = shift_factor
        stable_numerics = not item["svd"] and "dropped" not in str(item["message"] or "").lower()
        improved = item["rwp"] <= best_rwp + 0.002
        item["accepted"] = bool(stable_numerics and improved)
        history.append(item)
        if item["accepted"]:
            accepted += 1
            best_rwp = min(best_rwp, item["rwp"])
            project.save(str(checkpoint))
            # Screening only: 0.1 is sufficient to compare candidates. The
            # selected final model is subsequently reconverged at <0.05.
            if item["converged"] and abs(item["max_shift_esd"]) < 0.1:
                break
        else:
            shift_factor *= 0.5
            project = G2sc.G2Project(str(checkpoint), newgpx=output)
            if shift_factor < 0.03:
                break
    project = G2sc.G2Project(str(checkpoint), newgpx=output)
    project.save(output)
    return project, {"stage": stage_name, "accepted_rounds": accepted, "history": history}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output")
    parser.add_argument("cif")
    parser.add_argument("name")
    args = parser.parse_args()

    output = str(Path(args.output).resolve())
    checkpoint = Path(output).with_name(Path(output).stem + "-checkpoint.gpx")
    project = G2sc.G2Project(args.base, newgpx=output)
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    project.data["Controls"]["data"]["shift factor"] = 0.5
    histogram = project.histograms()[0]
    candidate = project.add_phase(
        args.cif,
        phasename=args.name,
        histograms=[histogram],
        fmthint="CIF",
    )
    candidate.data["Histograms"][histogram.name]["Scale"][0] = 1.0
    stages = [
        ("scales-background", {"cells": False, "instrument": []}),
        ("cells", {"cells": True, "instrument": []}),
        ("global-profile", {"cells": True, "instrument": ["W", "Z"]}),
        ("angular", {"cells": True, "instrument": ["W", "Z", "Zero"]}),
    ]
    reports = []
    for name, settings in stages:
        configure(project, settings)
        project, report = refine_stage(project, output, checkpoint, name)
        reports.append(report)

    histogram = project.histograms()[0]
    try:
        fractions = histogram.ComputeMassFracs()
    except Exception as error:
        fractions = {"error": repr(error)}
    result = {
        "base": args.base,
        "output": output,
        "candidate": args.cif,
        "rwp": float(histogram.get_wR()),
        "fractions": fractions,
        "stages": reports,
        "phases": [
            {
                "name": phase.name,
                "composition": phase.composition,
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][histogram.name]["Scale"],
            }
            for phase in project.phases()
        ],
        "convergence": summary(project),
        "instrument": histogram.InstrumentParameters,
    }
    print("STAGED_CANDIDATE_RESULT=" + json.dumps(result, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
