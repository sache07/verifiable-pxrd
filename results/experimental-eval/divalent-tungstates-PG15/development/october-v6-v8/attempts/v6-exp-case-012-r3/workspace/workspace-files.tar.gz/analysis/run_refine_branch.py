#!/usr/bin/env python3
"""Create and converge a matched GSAS-II refinement branch."""

from __future__ import annotations

import argparse
import json
import math
import re

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def status(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine_to_stability(project, max_rounds=12):
    history = []
    for _ in range(max_rounds):
        project.refine()
        r = status(project)
        history.append(
            {
                "rwp": float(project.histograms()[0].get_wR()),
                "converged": bool(r.get("converged")),
                "svd": int(r.get("SVD0", 0) or 0),
                "max_shift_esd": float(r.get("Max shft/sig") or 0.0),
                "message": r.get("msg"),
            }
        )
        if (
            r.get("converged")
            and not r.get("SVD0", 0)
            and abs(float(r.get("Max shft/sig") or 0.0)) < 0.05
        ):
            break
    return history


def covariance_correlations(project):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    rows = []
    if matrix.shape != (len(names), len(names)):
        return rows
    sig = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            den = sig[i] * sig[j]
            if den <= 0:
                continue
            corr = float(matrix[i, j] / den)
            if abs(corr) >= 0.8:
                rows.append([abs(corr), corr, names[i], names[j]])
    rows.sort(reverse=True)
    return rows[:20]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output")
    parser.add_argument("--instrument", default="")
    parser.add_argument(
        "--fix-instrument",
        action="append",
        default=[],
        metavar="NAME=VALUE",
        help="set an instrument term to VALUE and remove it from refinement",
    )
    parser.add_argument(
        "--sample",
        action="append",
        default=[],
        metavar="NAME=VALUE",
        help="set a sample term to VALUE and refine it",
    )
    parser.add_argument(
        "--fix-sample",
        action="append",
        default=[],
        metavar="NAME=VALUE",
        help="set a sample term to VALUE and remove it from refinement",
    )
    parser.add_argument("--size", action="store_true")
    parser.add_argument("--strain", action="store_true")
    parser.add_argument(
        "--fix-size-value",
        type=float,
        help="set the isotropic size value and remove it from refinement",
    )
    parser.add_argument(
        "--fix-strain-value",
        type=float,
        help="set the isotropic microstrain value and remove it from refinement",
    )
    parser.add_argument("--coordinates", action="store_true")
    parser.add_argument("--coordinates-element")
    parser.add_argument("--uiso", action="store_true")
    parser.add_argument("--uiso-element")
    parser.add_argument("--texture-axis", nargs=3, type=int)
    parser.add_argument("--phase-name")
    parser.add_argument("--rounds", type=int, default=12)
    args = parser.parse_args()

    project = G2sc.G2Project(args.base, newgpx=args.output)
    project.set_Controls("cycles", 12)
    histogram = project.histograms()[0]
    phases = project.phases()

    def assignment(item):
        name, separator, value = item.partition("=")
        if not separator:
            raise SystemExit(f"expected NAME=VALUE, got {item!r}")
        return name, float(value)

    for item in args.fix_instrument:
        name, value = assignment(item)
        if name not in histogram.InstrumentParameters:
            raise SystemExit(f"instrument parameter not found: {name}")
        histogram.InstrumentParameters[name][1] = value
        histogram.InstrumentParameters[name][2] = False
    for item in args.sample:
        name, value = assignment(item)
        if name not in histogram.SampleParameters:
            raise SystemExit(f"sample parameter not found: {name}")
        histogram.SampleParameters[name][0] = value
        histogram.SampleParameters[name][1] = True
    for item in args.fix_sample:
        name, value = assignment(item)
        if name not in histogram.SampleParameters:
            raise SystemExit(f"sample parameter not found: {name}")
        histogram.SampleParameters[name][0] = value
        histogram.SampleParameters[name][1] = False

    terms = [x for x in args.instrument.split(",") if x]
    if terms:
        histogram.set_refinements({"Instrument Parameters": terms})
    selected_phases = [
        phase for phase in phases
        if args.phase_name is None or phase.name == args.phase_name
    ]
    if args.phase_name is not None and not selected_phases:
        raise SystemExit(f"phase not found: {args.phase_name}")
    for phase in selected_phases:
        hap = phase.data["Histograms"][histogram.name]
        if args.size:
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
            )
        if args.strain:
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
        if args.fix_size_value is not None:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = args.fix_size_value
            hap["Size"][2][0] = False
        if args.fix_strain_value is not None:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = args.fix_strain_value
            hap["Mustrain"][2][0] = False
        if args.coordinates:
            phase.set_refinements({"Atoms": {"all": "X"}})
        if args.coordinates_element:
            coordinate_index, type_index, _, _ = phase.data["General"]["AtomPtrs"]
            wanted = args.coordinates_element.casefold()
            for atom in phase.data["Atoms"]:
                element = re.match(r"[A-Za-z]+", str(atom[type_index]))
                if element and element.group(0).casefold() == wanted:
                    flags = set(str(atom[coordinate_index - 1]))
                    flags.add("X")
                    atom[coordinate_index - 1] = "".join(sorted(flags))
        if args.uiso:
            phase.set_refinements({"Atoms": {"all": "U"}})
        if args.uiso_element:
            coordinate_index, type_index, _, _ = phase.data["General"]["AtomPtrs"]
            wanted = args.uiso_element.casefold()
            for atom in phase.data["Atoms"]:
                element = re.match(r"[A-Za-z]+", str(atom[type_index]))
                if element and element.group(0).casefold() == wanted:
                    flags = set(str(atom[coordinate_index - 1]))
                    flags.add("U")
                    atom[coordinate_index - 1] = "".join(sorted(flags))
        if args.texture_axis:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][3] = list(args.texture_axis)
            phase.set_HAP_refinements({"Pref.Ori.": True})

    project.save()
    history = refine_to_stability(project, args.rounds)
    project.save()
    report = {
        "base": args.base,
        "output": args.output,
        "history": history,
        "rwp": float(histogram.get_wR()),
        "instrument": histogram.InstrumentParameters,
        "sample": histogram.SampleParameters,
        "phases": [],
        "high_correlations": covariance_correlations(project),
    }
    for phase in phases:
        report["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "hap": phase.data["Histograms"][histogram.name],
                "atoms": phase.data["Atoms"],
            }
        )
    print("BRANCH_RESULT=" + json.dumps(report, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
