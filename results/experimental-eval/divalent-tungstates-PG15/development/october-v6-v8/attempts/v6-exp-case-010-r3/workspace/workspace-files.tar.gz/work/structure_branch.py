#!/usr/bin/env python3
"""Matched coordinate/ADP branches for structural-model validation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


MODES = (
    "wo_w_xyz",
    "wo_all_xyz",
    "mn_all_xyz",
    "wo_w_u",
    "wo_all_u",
    "wo_fixed_u",
)


def rstate(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine(project, attempts=8):
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        status = rstate(project)
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in message:
            return False, message
        if status.get("converged") and abs(float(status.get("Max shft/sig") or 0)) < 0.1:
            return True, None
    return False, "did_not_reach_shift_threshold"


def correlations(project, threshold=0.90):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sig = np.sqrt(np.clip(np.diag(matrix), 0, None))
    rows = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            if sig[i] * sig[j] <= 0:
                continue
            value = float(matrix[i, j] / (sig[i] * sig[j]))
            if abs(value) >= threshold:
                rows.append([names[i], names[j], value])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)


def atom_summary(project):
    answer = {}
    for phase in project.phases():
        answer[phase.name] = [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(atom.coordinates),
                "occupancy": atom.occupancy,
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ]
    return answer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("mode", choices=MODES)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.destination.resolve()))
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""

    wo3 = project.phase("WO3")
    mn = project.phase("Mn2O3")
    if args.mode == "wo_w_xyz":
        for atom in wo3.atoms():
            if atom.element == "W":
                atom.refinement_flags = "X"
    elif args.mode == "wo_all_xyz":
        for atom in wo3.atoms():
            atom.refinement_flags = "X"
    elif args.mode == "mn_all_xyz":
        for atom in mn.atoms():
            atom.refinement_flags = "X"
    elif args.mode == "wo_w_u":
        for atom in wo3.atoms():
            atom.uiso = 0.005
            if atom.element == "W":
                atom.refinement_flags = "U"
    elif args.mode == "wo_all_u":
        for atom in wo3.atoms():
            atom.uiso = 0.005
            atom.refinement_flags = "U"
    elif args.mode == "wo_fixed_u":
        for atom in wo3.atoms():
            atom.uiso = 0.005

    project.save()
    valid, reason = refine(project)
    project.save()
    summary = {
        "mode": args.mode,
        "valid": valid,
        "reason": reason,
        "rwp_percent": project.histograms()[0].get_wR(),
        "atoms": atom_summary(project),
        "correlations_abs_ge_0.90": correlations(project),
        "convergence": rstate(project),
    }
    print("STRUCTURE_BRANCH_RESULT=" + json.dumps(summary, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
