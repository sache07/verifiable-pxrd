#!/usr/bin/env python3
"""Matched leave-one-out tests for retained optional GSAS-II terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def rstate(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine(project, attempts=14):
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        state = rstate(project)
        msg = str(state.get("msg", "") or "").lower()
        if state.get("Aborted") or state.get("SVD0", 0) or "dropped" in msg:
            return False, msg
        if state.get("converged") and abs(float(state.get("Max shft/sig") or 0)) < 0.1:
            return True, None
    return False, "did_not_reach_shift_threshold"


def correlations(project, threshold=0.90):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sig = np.sqrt(np.clip(np.diag(matrix), 0, None))
    rows = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            if sig[i] * sig[j] <= 0:
                continue
            value = float(matrix[i, j] / (sig[i] * sig[j]))
            if abs(value) >= threshold:
                rows.append([names[i], names[j], value])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("kind", choices=("strain", "texture", "polarization"))
    parser.add_argument("--phase")
    args = parser.parse_args()
    if args.kind != "polarization" and not args.phase:
        raise SystemExit("--phase is required for strain and texture")

    project = G2sc.G2Project(
        str(args.source.resolve()), newgpx=str(args.destination.resolve())
    )
    histogram = project.histograms()[0]
    if args.kind == "polarization":
        histogram.InstrumentParameters["Polariz."][1] = 0.5
        histogram.InstrumentParameters["Polariz."][2] = False
    else:
        phase = project.phase(args.phase)
        hap = phase.getHAPvalues(histogram.name)
        if args.kind == "strain":
            hap["Mustrain"][1][0] = 1.0
            hap["Mustrain"][2][:] = [False, False, False]
        else:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False

    project.save()
    valid, reason = refine(project)
    project.save()
    print(
        "REMOVE_OPTIONAL_RESULT="
        + json.dumps(
            {
                "kind": args.kind,
                "phase": args.phase,
                "valid": valid,
                "reason": reason,
                "rwp_percent": histogram.get_wR(),
                "correlations_abs_ge_0.90": correlations(project),
                "convergence": rstate(project),
            },
            sort_keys=True,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
