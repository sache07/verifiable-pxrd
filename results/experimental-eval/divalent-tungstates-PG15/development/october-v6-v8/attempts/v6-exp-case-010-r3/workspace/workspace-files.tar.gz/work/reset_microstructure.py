#!/usr/bin/env python3
"""Reset GSAS-II HAP broadening defaults to negligible values and reconverge."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def rstate(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine(project, attempts=10):
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        state = rstate(project)
        message = str(state.get("msg", "") or "").lower()
        if state.get("Aborted") or state.get("SVD0", 0) or "dropped" in message:
            return False, message
        if state.get("converged") and abs(float(state.get("Max shft/sig") or 0)) < 0.1:
            return True, None
    return False, "did_not_reach_shift_threshold"


def correlations(project, threshold=0.90):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sig = np.sqrt(np.clip(np.diag(matrix), 0, None))
    rows = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            if sig[i] * sig[j] <= 0:
                continue
            value = float(matrix[i, j] / (sig[i] * sig[j]))
            if abs(value) >= threshold:
                rows.append([names[i], names[j], value])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()

    project = G2sc.G2Project(
        str(args.source.resolve()), newgpx=str(args.destination.resolve())
    )
    histogram = project.histograms()[0]
    for phase in project.phases():
        hap = phase.getHAPvalues(histogram.name)
        # Size is in micrometres; 1000 um has negligible Scherrer broadening.
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [1000.0, 1000.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        # Microstrain is in 10^-6; 1 is negligible on this profile scale.
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [1.0, 1.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]

    project.save()
    valid, reason = refine(project)
    project.save()
    print(
        "RESET_MICROSTRUCTURE_RESULT="
        + json.dumps(
            {
                "valid": valid,
                "reason": reason,
                "rwp_percent": histogram.get_wR(),
                "profile": {
                    key: histogram.InstrumentParameters[key]
                    for key in ("U", "V", "W", "X", "Y", "Z")
                },
                "hap": {
                    phase.name: {
                        key: phase.getHAPvalues(histogram.name)[key]
                        for key in ("Size", "Mustrain")
                    }
                    for phase in project.phases()
                },
                "correlations_abs_ge_0.90": correlations(project),
                "convergence": rstate(project),
            },
            sort_keys=True,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
