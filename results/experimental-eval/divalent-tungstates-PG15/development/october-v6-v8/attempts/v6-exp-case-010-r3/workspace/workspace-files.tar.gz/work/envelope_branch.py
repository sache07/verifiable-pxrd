#!/usr/bin/env python3
"""Compare polarization and Suortti surface-roughness envelope branches."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def rstate(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine(project, attempts=7):
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        status = rstate(project)
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in message:
            return False, message
        if status.get("converged") and abs(float(status.get("Max shft/sig") or 0)) < 0.1:
            return True, None
    return False, "did_not_reach_shift_threshold"


def correlations(project, threshold=0.90):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sig = np.sqrt(np.clip(np.diag(matrix), 0, None))
    rows = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            if sig[i] * sig[j] <= 0:
                continue
            value = float(matrix[i, j] / (sig[i] * sig[j]))
            if abs(value) >= threshold:
                rows.append([names[i], names[j], value])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)


def regional(histogram):
    x = np.asarray(histogram.getdata("X"), dtype=float)
    yo = np.asarray(histogram.getdata("Yobs"), dtype=float)
    yc = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    wt = np.asarray(histogram.getdata("Yweight"), dtype=float)
    result = {}
    for low, high in ((10, 30), (30, 50), (50, 70), (70, 100.1)):
        use = (x >= low) & (x < high)
        result[f"{low:g}-{high:g}"] = 100 * math.sqrt(
            np.sum(wt[use] * (yo[use] - yc[use]) ** 2)
            / np.sum(wt[use] * yo[use] ** 2)
        )
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("mode", choices=("polarization", "roughness"))
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.destination.resolve()))
    histogram = project.histograms()[0]
    histogram.InstrumentParameters["Polariz."][2] = False
    histogram.SampleParameters["SurfRoughA"][1] = False
    histogram.SampleParameters["SurfRoughB"][1] = False
    if args.mode == "polarization":
        histogram.InstrumentParameters["Polariz."][1] = 0.5
        histogram.InstrumentParameters["Polariz."][2] = True
    else:
        histogram.SampleParameters["SurfRoughA"][:] = [0.1, True]
        histogram.SampleParameters["SurfRoughB"][:] = [0.1, True]

    project.save()
    valid, reason = refine(project)
    project.save()
    summary = {
        "mode": args.mode,
        "valid": valid,
        "reason": reason,
        "rwp_percent": histogram.get_wR(),
        "regional_rwp_percent": regional(histogram),
        "polarization": histogram.InstrumentParameters["Polariz."],
        "surface_roughness_a": histogram.SampleParameters["SurfRoughA"],
        "surface_roughness_b": histogram.SampleParameters["SurfRoughB"],
        "correlations_abs_ge_0.90": correlations(project),
        "convergence": rstate(project),
    }
    print("ENVELOPE_BRANCH_RESULT=" + json.dumps(summary, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
