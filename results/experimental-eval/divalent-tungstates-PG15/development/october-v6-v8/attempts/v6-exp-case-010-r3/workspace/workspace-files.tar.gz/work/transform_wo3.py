#!/usr/bin/env python3
"""Put the valid COD 2311041 WO3 structure in its near-orthogonal P21/c cell."""

from pathlib import Path

from pymatgen.io.cif import CifParser, CifWriter


source = Path("candidates/wo3_p21c_2311041.cif")
destination = Path("candidates/wo3_p21c_2311041_standard.cif")
structure = CifParser(source).parse_structures(primitive=False)[0]

# new a = old a + old c; new b = old b; new c = -old a.  This is a
# determinant-one basis change and preserves the structure exactly.
structure.make_supercell([[1, 0, 1], [0, 1, 0], [-1, 0, 0]])
CifWriter(structure, symprec=0.01, refine_struct=False).write_file(destination)

print(destination)
print(structure.lattice.abc)
print(structure.lattice.angles)
