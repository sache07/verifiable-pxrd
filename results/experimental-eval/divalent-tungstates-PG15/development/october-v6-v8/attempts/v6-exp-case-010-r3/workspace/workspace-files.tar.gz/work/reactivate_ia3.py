#!/usr/bin/env python3
"""Retest the embedded Ia-3 Mn2O3 model against an accepted Pbca state."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def rstate(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine(project, attempts=14):
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        state = rstate(project)
        msg = str(state.get("msg", "") or "").lower()
        if state.get("Aborted") or state.get("SVD0", 0) or "dropped" in msg:
            return False, msg
        if state.get("converged") and abs(float(state.get("Max shft/sig") or 0)) < 0.1:
            return True, None
    return False, "did_not_reach_shift_threshold"


def correlations(project, threshold=0.90):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sig = np.sqrt(np.clip(np.diag(matrix), 0, None))
    rows = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            if sig[i] * sig[j] <= 0:
                continue
            value = float(matrix[i, j] / (sig[i] * sig[j]))
            if abs(value) >= threshold:
                rows.append([names[i], names[j], value])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    project = G2sc.G2Project(
        str(args.source.resolve()), newgpx=str(args.destination.resolve())
    )
    histogram = project.histograms()[0]
    pbca = project.phase("Mn2O3_Pbca")
    pbca_hap = pbca.getHAPvalues(histogram.name)
    pbca.HAPvalue("Use", False)
    pbca.set_HAP_refinements({"Scale": False})
    pbca.set_refinements({"Cell": False})
    pbca_hap["Mustrain"][2][:] = [False, False, False]
    for atom in pbca.atoms():
        atom.refinement_flags = ""

    ia3 = project.phase("Mn2O3")
    ia3.HAPvalue("Use", True)
    ia3.set_HAP_refinements({"Scale": True})
    ia3.set_refinements({"Cell": True})
    ia3_hap = ia3.getHAPvalues(histogram.name)
    ia3_hap["Mustrain"][1][0] = max(float(pbca_hap["Mustrain"][1][0]), 100.0)
    ia3_hap["Mustrain"][2][0] = True
    for atom in ia3.atoms():
        atom.refinement_flags = "X"

    project.save()
    valid, reason = refine(project)
    project.save()
    print(
        "REACTIVATE_IA3_RESULT="
        + json.dumps(
            {
                "valid": valid,
                "reason": reason,
                "rwp_percent": histogram.get_wR(),
                "cell": ia3.get_cell(),
                "mustrain": ia3.getHAPvalues(histogram.name)["Mustrain"],
                "mass_fractions": {
                    k: {"fraction": v[0], "sigma": v[1]}
                    for k, v in histogram.ComputeMassFracs().items()
                },
                "correlations_abs_ge_0.90": correlations(project),
                "convergence": rstate(project),
            },
            sort_keys=True,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
