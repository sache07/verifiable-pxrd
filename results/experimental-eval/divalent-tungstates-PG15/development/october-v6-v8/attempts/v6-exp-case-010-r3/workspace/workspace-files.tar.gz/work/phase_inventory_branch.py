#!/usr/bin/env python3
"""Matched add-one and leave-one-out phase-inventory tests."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def rstate(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project, attempts=8):
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        status = rstate(project)
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in message:
            return False, message
        if status.get("converged") and abs(float(status.get("Max shft/sig") or 0)) < 0.1:
            return True, None
    return False, "did_not_reach_shift_threshold"


def correlations(project, threshold=0.90):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sig = np.sqrt(np.clip(np.diag(matrix), 0, None))
    rows = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            if sig[i] * sig[j] <= 0:
                continue
            value = float(matrix[i, j] / (sig[i] * sig[j]))
            if abs(value) >= threshold:
                rows.append([names[i], names[j], value])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    subparsers = parser.add_subparsers(dest="mode", required=True)
    add = subparsers.add_parser("add")
    add.add_argument("name")
    add.add_argument("cif", type=Path)
    disable = subparsers.add_parser("disable")
    disable.add_argument("name")
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.destination.resolve()))
    histogram = project.histograms()[0]
    tested = None
    if args.mode == "add":
        tested = project.add_phase(
            str(args.cif.resolve()), phasename=args.name, histograms=[histogram], fmthint="CIF"
        )
        tested.HAPvalue("Scale", 0.1)
        tested.set_HAP_refinements({"Scale": True})
        tested.set_refinements({"Cell": False})
    else:
        tested = project.phase(args.name)
        tested.HAPvalue("Use", False)
        tested.set_HAP_refinements({"Scale": False})

    project.save()
    valid, reason = stable_refine(project)
    if args.mode == "add" and tested.HAPvalue("Scale", targethistlist=[histogram]) > 0:
        tested.set_refinements({"Cell": True})
        valid2, reason2 = stable_refine(project)
        valid = valid and valid2
        reason = reason or reason2
    project.save()
    try:
        fractions = {
            name: {"fraction": values[0], "sigma": values[1]}
            for name, values in histogram.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": repr(exc)}
    summary = {
        "mode": args.mode,
        "tested_phase": tested.name,
        "valid": valid,
        "reason": reason,
        "rwp_percent": histogram.get_wR(),
        "r_factors": histogram.residuals,
        "scales": {
            phase.name: phase.HAPvalue("Scale", targethistlist=[histogram])
            for phase in project.phases()
        },
        "uses": {
            phase.name: phase.HAPvalue("Use", targethistlist=[histogram])
            for phase in project.phases()
        },
        "mass_fractions": fractions,
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "correlations_abs_ge_0.90": correlations(project),
        "convergence": rstate(project),
    }
    print("PHASE_BRANCH_RESULT=" + json.dumps(summary, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
