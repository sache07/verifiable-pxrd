#!/usr/bin/env python3
"""Add one March-Dollase axis while preserving retained texture terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def rstate(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine(project, attempts=10):
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        state = rstate(project)
        msg = str(state.get("msg", "") or "").lower()
        if state.get("Aborted") or state.get("SVD0", 0) or "dropped" in msg:
            return False, msg
        if state.get("converged") and abs(float(state.get("Max shft/sig") or 0)) < 0.1:
            return True, None
    return False, "did_not_reach_shift_threshold"


def correlations(project, threshold=0.90):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sig = np.sqrt(np.clip(np.diag(matrix), 0, None))
    rows = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            if sig[i] * sig[j] <= 0:
                continue
            value = float(matrix[i, j] / (sig[i] * sig[j]))
            if abs(value) >= threshold:
                rows.append([names[i], names[j], value])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("phase")
    parser.add_argument("axis")
    args = parser.parse_args()
    axis = [int(item) for item in args.axis.split(",")]
    if len(axis) != 3 or axis == [0, 0, 0]:
        raise SystemExit("axis must contain three nonzero-combination integers")

    project = G2sc.G2Project(
        str(args.source.resolve()), newgpx=str(args.destination.resolve())
    )
    histogram = project.histograms()[0]
    phase = project.phase(args.phase)
    pref = phase.getHAPvalues(histogram.name)["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = axis
    project.save()
    valid, reason = refine(project)
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {})
    variables = dict(
        zip(cov.get("varyList", []), zip(cov.get("variables", []), cov.get("sig", [])))
    )
    print(
        "TEXTURE_ADD_RESULT="
        + json.dumps(
            {
                "phase": phase.name,
                "axis": axis,
                "valid": valid,
                "reason": reason,
                "rwp_percent": histogram.get_wR(),
                "preference": phase.getHAPvalues(histogram.name)["Pref.Ori."],
                "md_variables": {
                    key: value for key, value in variables.items() if key.endswith(":MD")
                },
                "correlations_abs_ge_0.90": correlations(project),
                "convergence": rstate(project),
            },
            sort_keys=True,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
