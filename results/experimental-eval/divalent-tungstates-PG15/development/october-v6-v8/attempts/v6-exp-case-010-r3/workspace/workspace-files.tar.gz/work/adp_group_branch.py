#!/usr/bin/env python3
"""Test parsimonious grouped WO3 isotropic-ADP models."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def rstate(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project, attempts=8):
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        status = rstate(project)
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in message:
            return False, message
        if status.get("converged") and abs(float(status.get("Max shft/sig") or 0)) < 0.1:
            return True, None
    return False, "did_not_reach_shift_threshold"


def high_correlations(project, threshold=0.90):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sig = np.sqrt(np.clip(np.diag(matrix), 0, None))
    rows = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            if sig[i] * sig[j] <= 0:
                continue
            value = float(matrix[i, j] / (sig[i] * sig[j]))
            if abs(value) >= threshold:
                rows.append([names[i], names[j], value])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("mode", choices=("common", "elements", "w_common"))
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.destination.resolve()))
    phase = project.phase("WO3")
    atoms = phase.atoms()
    for atom in atoms:
        atom.refinement_flags = ""
        atom.uiso = 0.005
    selected = range(len(atoms)) if args.mode != "w_common" else [i for i, atom in enumerate(atoms) if atom.element == "W"]
    for index in selected:
        atoms[index].refinement_flags = "U"

    p_id = phase.id
    if args.mode == "common":
        project.add_EquivConstr([f"{p_id}::AUiso:{i}" for i in selected])
    elif args.mode == "elements":
        for element in ("W", "O"):
            indices = [i for i, atom in enumerate(atoms) if atom.element == element]
            project.add_EquivConstr([f"{p_id}::AUiso:{i}" for i in indices])
    else:
        project.add_EquivConstr([f"{p_id}::AUiso:{i}" for i in selected])

    project.save()
    valid, reason = stable_refine(project)
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {})
    summary = {
        "mode": args.mode,
        "valid": valid,
        "reason": reason,
        "rwp_percent": project.histograms()[0].get_wR(),
        "atoms": [
            {"label": atom.label, "element": atom.element, "uiso": atom.uiso, "flags": atom.refinement_flags}
            for atom in phase.atoms()
        ],
        "variables": list(cov.get("varyList", [])),
        "values": [float(value) for value in cov.get("variables", [])],
        "sigmas": [float(value) for value in cov.get("sig", [])],
        "correlations_abs_ge_0.90": high_correlations(project),
        "convergence": rstate(project),
    }
    print("ADP_BRANCH_RESULT=" + json.dumps(summary, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
