#!/usr/bin/env python3
"""Build and minimally refine matched GSAS-II phase-screening projects."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, label: str, attempts: int = 5) -> bool:
    """Repeat short refinements until convergence or a numerical warning."""
    for attempt in range(1, attempts + 1):
        try:
            project.refine()
        except Exception as exc:
            print(f"STAGE {label} attempt {attempt}: exception {exc!r}")
            return False
        status = covariance_status(project)
        print(
            f"STAGE {label} attempt {attempt}: "
            f"Rwp={project.histograms()[0].get_wR()} "
            f"converged={status.get('converged')} "
            f"max_shift={status.get('Max shft/sig')} "
            f"SVD0={status.get('SVD0')} msg={status.get('msg')!r}"
        )
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in message:
            return False
        if status.get("converged") and abs(float(status.get("Max shft/sig") or 0.0)) < 0.1:
            return True
    return False


def build_project(output: Path, phase_specs: list[tuple[str, Path]]) -> G2sc.G2Project:
    project = G2sc.G2Project(newgpx=str(output))
    histogram = project.add_powder_histogram(
        "work/pattern.xye", "work/cu_kalpha.instprm", fmthint="xye"
    )
    for name, cif in phase_specs:
        project.add_phase(str(cif), phasename=name, histograms=[histogram], fmthint="CIF")

    project.set_Controls("cycles", 8)
    controls = project.data["Controls"]["data"]
    controls["min dM/M"] = 1.0e-5

    # The broad measured peaks require a realistic starting width. These values
    # are still global nuisance parameters and are treated identically in every
    # structural branch.
    for key, value in {"Zero": 0.27, "U": 20.0, "V": -5.0, "W": 30.0}.items():
        histogram.InstrumentParameters[key][1] = value
    for key in ("X", "Y", "Z"):
        histogram.InstrumentParameters[key][1] = 0.0
    histogram.SampleParameters["Scale"][1] = False
    histogram.SampleParameters["Shift"][:] = [0.0, False]

    # A moderate-order empirical background follows the smooth air/scatter
    # curve without adding individual peaks.
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1200.0] + [0.0] * 11,
                "refine": True,
            }
        }
    )
    for index, phase in enumerate(project.phases()):
        phase.HAPvalue("Scale", 0.01 if index == 0 else 0.002)
        phase.set_HAP_refinements({"Scale": True})
    project.save()
    return project


def summarize(project: G2sc.G2Project, valid: bool) -> dict:
    histogram = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    masses = {}
    try:
        masses = {
            key: {"fraction": val[0], "sigma": val[1]}
            for key, val in histogram.ComputeMassFracs().items()
        }
    except Exception as exc:
        masses = {"error": repr(exc)}
    return {
        "valid": valid,
        "project": project.filename,
        "r_factors": histogram.residuals,
        "mass_fractions": masses,
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "phase_scales": {
            phase.name: phase.HAPvalue("Scale", targethistlist=[histogram])
            for phase in project.phases()
        },
        "instrument": {
            key: histogram.InstrumentParameters[key]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z")
        },
        "shift": histogram.SampleParameters["Shift"],
        "convergence": {
            key: covariance_status(project).get(key)
            for key in ("converged", "SVD0", "Max shft/sig", "msg", "Rwp", "GOF")
        },
        "variables": list(cov.get("varyList", [])),
        "values": [float(value) for value in cov.get("variables", [])],
        "sigmas": [float(value) for value in cov.get("sig", [])],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "phase", nargs="+", help="phase specification NAME=path/to/model.cif"
    )
    args = parser.parse_args()
    specs = []
    for spec in args.phase:
        name, path = spec.split("=", 1)
        specs.append((name, Path(path).resolve()))

    project = build_project(args.output.resolve(), specs)
    histogram = project.histograms()[0]
    valid = stable_refine(project, "scale-background")

    if valid:
        histogram.set_refinements({"Instrument Parameters": ["Zero"]})
        valid = stable_refine(project, "zero")
    if valid:
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
        valid = stable_refine(project, "cells")
    if valid:
        histogram.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
        valid = stable_refine(project, "gaussian-profile")

    project.save()
    summary = summarize(project, valid)
    print("SCREEN_RESULT=" + json.dumps(summary, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
