#!/usr/bin/env python3
"""Reload a GSAS-II project, refine to a strict shift/esd threshold, and save."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def state(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--attempts", type=int, default=12)
    args = parser.parse_args()
    project = G2sc.G2Project(
        str(args.source.resolve()), newgpx=str(args.destination.resolve())
    )
    project.save()
    valid = False
    reason = None
    for _ in range(args.attempts):
        try:
            project.refine()
        except Exception as exc:
            reason = repr(exc)
            break
        status = state(project)
        msg = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in msg:
            reason = msg
            break
        if status.get("converged") and abs(float(status.get("Max shft/sig") or 0)) < 0.1:
            valid = True
            break
    if not valid and reason is None:
        reason = "did_not_reach_shift_threshold"
    project.save()
    print(
        "RECONVERGE_RESULT="
        + json.dumps(
            {
                "valid": valid,
                "reason": reason,
                "rwp_percent": project.histograms()[0].get_wR(),
                "convergence": state(project),
            },
            sort_keys=True,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
