#!/usr/bin/env python3
"""Disable one phase and all of its refinement variables in a mature project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def rstate(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("phase")
    args = parser.parse_args()
    project = G2sc.G2Project(
        str(args.source.resolve()), newgpx=str(args.destination.resolve())
    )
    histogram = project.histograms()[0]
    phase = project.phase(args.phase)
    # Force a zero scale while keeping the phase linked. This guarantees that
    # GSAS-II regenerates the profile even when a dominant phase is removed.
    hap = phase.data["Histograms"][histogram.name]
    hap["Use"] = True
    # GSAS-II treats an exact zero scale as a special no-op in some project
    # states, so use its positive numerical floor to force recalculation.
    hap["Scale"][:] = [1.0e-12, False]
    phase.data["General"]["Cell"][0] = False
    hap["Pref.Ori."][2] = False
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][2][:] = [False, False, False]
    cx = phase.data["General"]["AtomPtrs"][0]
    for atom in phase.data["Atoms"]:
        atom[cx - 1] = ""
    # A missing dominant phase can otherwise drive companion cells and
    # coordinates to invalid values while trying to imitate its peaks. Freeze
    # all structural variables for this matched inventory diagnostic, while
    # leaving scales, background, global profile, envelope and active HAP
    # nuisance terms free to reconverge.
    for companion in project.phases():
        companion.data["General"]["Cell"][0] = False
        ccx = companion.data["General"]["AtomPtrs"][0]
        for atom in companion.data["Atoms"]:
            atom[ccx - 1] = ""
    project.save()

    valid = False
    reason = None
    for _ in range(14):
        try:
            project.refine()
        except Exception as exc:
            reason = repr(exc)
            break
        state = rstate(project)
        msg = str(state.get("msg", "") or "").lower()
        if state.get("Aborted") or state.get("SVD0", 0) or "dropped" in msg:
            reason = msg
            break
        if state.get("converged") and abs(float(state.get("Max shft/sig") or 0)) < 0.1:
            valid = True
            break
    if not valid and reason is None:
        reason = "did_not_reach_shift_threshold"
    project.save()
    print(
        "MATURE_PHASE_LEAVEOUT_RESULT="
        + json.dumps(
            {
                "removed_phase": phase.name,
                "valid": valid,
                "reason": reason,
                "rwp_percent": histogram.get_wR(),
                "remaining_fractions": {
                    key: {"fraction": value[0], "sigma": value[1]}
                    for key, value in histogram.ComputeMassFracs().items()
                },
                "convergence": rstate(project),
            },
            sort_keys=True,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
