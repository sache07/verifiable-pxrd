#!/usr/bin/env python3
"""Replace the Ia-3 Mn2O3 component with a Pbca model in a mature project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def rstate(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine(project, attempts=12):
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        status = rstate(project)
        msg = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in msg:
            return False, msg
        if status.get("converged") and abs(float(status.get("Max shft/sig") or 0)) < 0.1:
            return True, None
    return False, "did_not_reach_shift_threshold"


def correlations(project, threshold=0.90):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sig = np.sqrt(np.clip(np.diag(matrix), 0, None))
    rows = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            if sig[i] * sig[j] <= 0:
                continue
            value = float(matrix[i, j] / (sig[i] * sig[j]))
            if abs(value) >= threshold:
                rows.append([names[i], names[j], value])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("pbca_cif", type=Path)
    parser.add_argument("--coordinates", action="store_true")
    args = parser.parse_args()

    project = G2sc.G2Project(
        str(args.source.resolve()), newgpx=str(args.destination.resolve())
    )
    histogram = project.histograms()[0]
    old = project.phase("Mn2O3")
    old_hap = old.getHAPvalues(histogram.name)
    old_strain = float(old_hap["Mustrain"][1][0])
    old.HAPvalue("Use", False)
    old.set_HAP_refinements({"Scale": False})
    old.set_refinements({"Cell": False})
    old_hap["Mustrain"][2][:] = [False, False, False]
    for atom in old.atoms():
        atom.refinement_flags = ""

    replacement = project.add_phase(
        str(args.pbca_cif.resolve()),
        phasename="Mn2O3_Pbca",
        histograms=[histogram],
        fmthint="CIF",
    )
    replacement.HAPvalue("Scale", 4.3)
    replacement.set_HAP_refinements({"Scale": True})
    replacement.set_refinements({"Cell": True})
    replacement.setSampleProfile(histogram, "size", "isotropic", 10.0, LGmix=1.0)
    replacement.setSampleProfile(
        histogram, "microstrain", "isotropic", max(old_strain, 100.0), LGmix=1.0
    )
    replacement.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}
    )
    for atom in replacement.atoms():
        atom.refinement_flags = "X" if args.coordinates else ""

    project.save()
    valid, reason = refine(project)
    project.save()
    try:
        fractions = {
            key: {"fraction": value[0], "sigma": value[1]}
            for key, value in histogram.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": repr(exc)}
    print(
        "REPLACEMENT_RESULT="
        + json.dumps(
            {
                "valid": valid,
                "reason": reason,
                "coordinates_refined": args.coordinates,
                "rwp_percent": histogram.get_wR(),
                "r_factors": histogram.residuals,
                "cell": replacement.get_cell(),
                "mustrain": replacement.getHAPvalues(histogram.name)["Mustrain"],
                "fractions": fractions,
                "correlations_abs_ge_0.90": correlations(project),
                "convergence": rstate(project),
            },
            sort_keys=True,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
