#!/usr/bin/env python3
"""Remove one disabled comparison phase from a GSAS-II project and reconverge."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def rstate(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("phase")
    args = parser.parse_args()

    project = G2sc.G2Project(
        str(args.source.resolve()), newgpx=str(args.destination.resolve())
    )
    phase = project.phase(args.phase)
    if phase is None:
        raise SystemExit(f"phase not found: {args.phase}")
    if any(bool(phase.HAPvalue("Use", targethistlist=[hist])) for hist in project.histograms()):
        raise SystemExit(f"refusing to remove active phase: {args.phase}")

    del project.data["Phases"][args.phase]
    for item in project.names:
        if item and item[0] == "Phases" and args.phase in item:
            item.remove(args.phase)
    for histogram in project.histograms():
        histogram.data.get("Reflection Lists", {}).pop(args.phase, None)
    project.save()

    # Reload so phase IDs and wrappers are regenerated from the cleaned tree.
    project = G2sc.G2Project(str(args.destination.resolve()))
    project.set_Controls("cycles", 8)
    valid = False
    reason = None
    for _ in range(12):
        try:
            project.refine()
        except Exception as exc:
            reason = repr(exc)
            break
        state = rstate(project)
        msg = str(state.get("msg", "") or "").lower()
        if state.get("Aborted") or state.get("SVD0", 0) or "dropped" in msg:
            reason = msg
            break
        if state.get("converged") and abs(float(state.get("Max shft/sig") or 0)) < 0.1:
            valid = True
            break
    if not valid and reason is None:
        reason = "did_not_reach_shift_threshold"
    project.save()
    histogram = project.histograms()[0]
    print(
        "REMOVE_PHASE_RESULT="
        + json.dumps(
            {
                "valid": valid,
                "reason": reason,
                "phases": [phase.name for phase in project.phases()],
                "rwp_percent": histogram.get_wR(),
                "mass_fractions": {
                    key: {"fraction": value[0], "sigma": value[1]}
                    for key, value in histogram.ComputeMassFracs().items()
                },
                "convergence": rstate(project),
            },
            sort_keys=True,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
