#!/usr/bin/env python3
"""Export CIFs, fit.csv, and result.json from the selected GSAS-II project."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PHASE_METADATA = {
    "WO3": {
        "name": "monoclinic tungsten(VI) oxide",
        "formula": "WO3",
        "cif_path": "phase_wo3.cif",
    },
    "Mn2O3_Pbca": {
        "name": "orthorhombic alpha-manganese(III) oxide",
        "formula": "Mn2O3",
        "cif_path": "phase_mn2o3_pbca.cif",
    },
    "MnWO4": {
        "name": "monoclinic manganese(II) tungstate",
        "formula": "MnWO4",
        "cif_path": "phase_mnwo4.cif",
    },
}

OUTPUT_ORDER = ("WO3", "Mn2O3_Pbca", "MnWO4")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output_directory", type=Path)
    args = parser.parse_args()
    output = args.output_directory.resolve()
    output.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(args.project.resolve()))
    histogram = project.histograms()[0]
    actual = {phase.name for phase in project.phases()}
    expected = set(PHASE_METADATA)
    if actual != expected:
        raise SystemExit(f"unexpected phase set: actual={sorted(actual)} expected={sorted(expected)}")

    fractions = histogram.ComputeMassFracs()
    total = sum(float(value[0]) for value in fractions.values())
    if not np.isfinite(total) or total <= 0:
        raise SystemExit(f"invalid mass-fraction sum: {total}")

    residuals = histogram.residuals
    phase_rows = []
    for phase_name in OUTPUT_ORDER:
        phase = project.phase(phase_name)
        metadata = PHASE_METADATA[phase_name]
        cif_path = output / metadata["cif_path"]
        phase.export_CIF(str(cif_path))
        value, sigma = fractions[phase_name]
        cell = phase.get_cell()
        pid = phase.id
        phase_rows.append(
            {
                "name": metadata["name"],
                "formula": metadata["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": metadata["cif_path"],
                "weight_fraction": float(value) / total,
                "weight_fraction_esd": float(sigma) / total,
                "cell": {key: float(value) for key, value in cell.items()},
                "bragg_rf_percent": float(residuals.get(f"{pid}:0:Rf", np.nan)),
                "bragg_rf_squared_percent": float(
                    residuals.get(f"{pid}:0:Rf^2", np.nan)
                ),
            }
        )

    x = np.asarray(histogram.getdata("X"), dtype=float)
    observed = np.asarray(histogram.getdata("Yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    background = np.asarray(histogram.getdata("Background"), dtype=float)
    difference = observed - calculated
    with (output / "fit.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent": float(histogram.get_wR()),
            "rp_percent": float(residuals["R"]),
            "expected_rwp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_variables": int(rvals["Nvars"]),
        },
        "fraction_basis": "normalized over the modeled crystalline phases",
        "unresolved_components": [],
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
    }
    (output / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
