#!/usr/bin/env python3
"""Matched GSAS-II branches for minimal global profile-term selection."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PROFILE_TERMS = ("U", "V", "W", "X", "Y", "Z")


def status(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine(project, attempts=6):
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        state = status(project)
        message = str(state.get("msg", "") or "").lower()
        if state.get("Aborted") or state.get("SVD0", 0) or "dropped" in message:
            return False, message
        if state.get("converged") and abs(float(state.get("Max shft/sig") or 0)) < 0.1:
            return True, None
    return False, "did_not_reach_shift_threshold"


def correlations(project):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    diagonal = np.sqrt(np.clip(np.diag(matrix), 0.0, None))
    answer = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            denominator = diagonal[i] * diagonal[j]
            if denominator <= 0:
                continue
            value = float(matrix[i, j] / denominator)
            if abs(value) >= 0.90:
                answer.append([names[i], names[j], value])
    return sorted(answer, key=lambda row: abs(row[2]), reverse=True)


def regional_rwp(histogram):
    x = np.asarray(histogram.getdata("X"), dtype=float)
    yo = np.asarray(histogram.getdata("Yobs"), dtype=float)
    yc = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    weights = np.asarray(histogram.getdata("Yweight"), dtype=float)
    regions = ((10, 30), (30, 50), (50, 70), (70, 100.1))
    result = {}
    for low, high in regions:
        use = (x >= low) & (x < high) & (weights > 0)
        numerator = np.sum(weights[use] * (yo[use] - yc[use]) ** 2)
        denominator = np.sum(weights[use] * yo[use] ** 2)
        result[f"{low:g}-{high:g}"] = 100 * math.sqrt(numerator / denominator)
    return result


def width_minimum(histogram):
    inst = histogram.InstrumentParameters
    x = np.linspace(*histogram.data["Limits"][1], 3000)
    tangent = np.tan(np.radians(x / 2))
    cosine = np.cos(np.radians(x / 2))
    gaussian = inst["U"][1] * tangent**2 + inst["V"][1] * tangent + inst["W"][1]
    lorentzian = inst["X"][1] / cosine + inst["Y"][1] * tangent + inst["Z"][1]
    gi = int(np.argmin(gaussian))
    li = int(np.argmin(lorentzian))
    return {
        "gaussian_variance_min": float(gaussian[gi]),
        "gaussian_at_2theta": float(x[gi]),
        "lorentzian_width_min": float(lorentzian[li]),
        "lorentzian_at_2theta": float(x[li]),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("terms", help="comma-separated global profile terms")
    args = parser.parse_args()
    selected = {item.strip() for item in args.terms.split(",") if item.strip()}
    unknown = selected - set(PROFILE_TERMS)
    if unknown:
        raise SystemExit(f"unknown profile terms: {sorted(unknown)}")

    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.destination.resolve()))
    histogram = project.histograms()[0]
    starts = {key: float(histogram.InstrumentParameters[key][1]) for key in PROFILE_TERMS}
    for key in PROFILE_TERMS:
        parameter = histogram.InstrumentParameters[key]
        parameter[2] = key in selected
        if key not in selected:
            parameter[1] = 0.0
    # Keep robust nonzero starts for terms that were absent in the source.
    for key in selected:
        if abs(histogram.InstrumentParameters[key][1]) < 1e-12:
            histogram.InstrumentParameters[key][1] = 10.0 if key in {"U", "W"} else 1.0
    project.save()
    valid, reason = refine(project)
    project.save()

    summary = {
        "terms": sorted(selected),
        "valid": valid,
        "reason": reason,
        "rwp_percent": histogram.get_wR(),
        "r_factors": histogram.residuals,
        "regional_rwp_percent": regional_rwp(histogram),
        "profile": {key: histogram.InstrumentParameters[key] for key in PROFILE_TERMS},
        "widths": width_minimum(histogram),
        "correlations_abs_ge_0.90": correlations(project),
        "convergence": status(project),
    }
    print("PROFILE_BRANCH_RESULT=" + json.dumps(summary, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
