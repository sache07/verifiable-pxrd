#!/usr/bin/env python3
"""Test one isotropic phase-size or microstrain term from a stable project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def state(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project, attempts=7):
    for _ in range(attempts):
        try:
            project.refine()
        except Exception as exc:
            return False, repr(exc)
        status = state(project)
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in message:
            return False, message
        if status.get("converged") and abs(float(status.get("Max shft/sig") or 0)) < 0.1:
            return True, None
    return False, "did_not_reach_shift_threshold"


def high_correlations(project, threshold=0.90):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    sig = np.sqrt(np.clip(np.diag(matrix), 0, None))
    result = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            if sig[i] <= 0 or sig[j] <= 0:
                continue
            corr = float(matrix[i, j] / (sig[i] * sig[j]))
            if abs(corr) >= threshold:
                result.append([names[i], names[j], corr])
    return sorted(result, key=lambda row: abs(row[2]), reverse=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("phase")
    parser.add_argument("kind", choices=("size", "strain"))
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(args.destination.resolve()))
    histogram = project.histograms()[0]
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    phase = project.phase(args.phase)
    if args.kind == "size":
        phase.setSampleProfile(histogram, "size", "isotropic", 1.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
        )
    else:
        phase.setSampleProfile(histogram, "microstrain", "isotropic", 1000.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    project.save()
    valid, reason = stable_refine(project)
    project.save()
    hap = phase.getHAPvalues(histogram.name)
    summary = {
        "phase": phase.name,
        "kind": args.kind,
        "valid": valid,
        "reason": reason,
        "rwp_percent": histogram.get_wR(),
        "r_factors": histogram.residuals,
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "correlations_abs_ge_0.90": high_correlations(project),
        "convergence": state(project),
    }
    print("MICROSTRUCTURE_BRANCH_RESULT=" + json.dumps(summary, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
