#!/usr/bin/env python3
"""Freeze the selected GSAS-II branch and write structural/profile exports."""

import csv
import json
from pathlib import Path

import GSASIIscriptable as G2sc

from learned.profile_regeneration import regenerate_profile


SOURCE = Path("branches/14a_angular.gpx")
FINAL = Path("final.gpx")
CIF_PATHS = [Path("phase_NiWO4.cif"), Path("phase_WO3.cif")]


def main():
    selected = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    selected.save()
    regenerate_profile(FINAL.resolve())

    final = G2sc.G2Project(str(FINAL))
    phases = final.phases()
    if len(phases) != 2:
        raise RuntimeError(f"expected two phases, found {len(phases)}")
    for phase, path in zip(phases, CIF_PATHS):
        phase.export_CIF(str(path))

    hist = final.histograms()[0]
    arrays = hist.data["data"][1]
    with Path("fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed_counts", "calculated_counts", "difference_counts", "background_counts"]
        )
        for two_theta, observed, calculated, background, difference in zip(
            arrays[0], arrays[1], arrays[3], arrays[4], arrays[5]
        ):
            writer.writerow(
                [
                    f"{float(two_theta):.8f}",
                    f"{float(observed):.8f}",
                    f"{float(calculated):.8f}",
                    f"{float(difference):.8f}",
                    f"{float(background):.8f}",
                ]
            )

    covariance = final.data["Covariance"]["data"]
    payload = {
        "phase_names": [phase.name for phase in phases],
        "mass_fractions": hist.ComputeMassFracs(),
        "histogram_residuals": hist.residuals,
        "refinement_Rvals": covariance["Rvals"],
        "cells": {phase.name: phase.get_cell_and_esd() for phase in phases},
    }
    print(json.dumps(payload, indent=2, default=lambda value: value.tolist()))


if __name__ == "__main__":
    main()
