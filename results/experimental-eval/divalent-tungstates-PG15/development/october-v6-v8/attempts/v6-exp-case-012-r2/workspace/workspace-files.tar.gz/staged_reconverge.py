#!/usr/bin/env python3
"""Alternating-block reconvergence for the accepted GSAS-II model terms."""

import argparse

import GSASIIscriptable as G2sc

from branch_refinement import freeze_project


def enable(gpx, groups):
    hist = gpx.histograms()[0]
    phases = gpx.phases()
    if "nuisance" in groups:
        hist.data["Background"][0][1] = True
        hist.data["Instrument Parameters"][0]["Zero"][2] = True
        for phase in phases:
            phase.data["General"]["Cell"][0] = True
            for hap in phase.data["Histograms"].values():
                hap["Scale"][1] = True
    if "profile" in groups:
        inst = hist.data["Instrument Parameters"][0]
        for key in ("V", "W", "Z", "Polariz."):
            inst[key][2] = True
    if "coords" in groups:
        for atom in phases[0].atoms():
            atom.refinement_flags = "X"


def status(gpx, stage):
    cov = gpx.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    max_final = max((abs(float(x)) for x in rvals.get("lastShifts", {}).values()), default=0.0)
    print(
        "STAGE_RESULT",
        stage,
        "Rwp", gpx.histograms()[0].get_wR(),
        "GOF", rvals.get("GOF"),
        "Nvars", rvals.get("Nvars"),
        "SVD", rvals.get("SVD0"),
        "converged", rvals.get("converged"),
        "final_max_shift_esd", max_final,
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--no-joint", action="store_true")
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.source, newgpx=args.output)
    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = 16
    controls["min dM/M"] = 0.0001
    freeze_project(gpx)
    gpx.save()

    stages = [
        ("nuisance-1", {"nuisance"}),
        ("profile-1", {"profile"}),
        ("coords-1", {"coords"}),
        ("nuisance-2", {"nuisance"}),
        ("profile-2", {"profile"}),
        ("coords-2", {"coords"}),
        ("nuisance-3", {"nuisance"}),
        ("profile-3", {"profile"}),
    ]
    if not args.no_joint:
        stages.append(("joint", {"nuisance", "profile", "coords"}))

    for name, groups in stages:
        freeze_project(gpx)
        enable(gpx, groups)
        gpx.save()
        gpx.refine()
        gpx.save()
        status(gpx, name)


if __name__ == "__main__":
    main()
