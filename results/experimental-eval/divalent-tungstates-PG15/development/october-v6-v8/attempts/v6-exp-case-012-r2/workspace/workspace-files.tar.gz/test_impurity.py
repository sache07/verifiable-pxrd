#!/usr/bin/env python3
"""Add one candidate phase to a mature project and refine only its scale."""

import argparse

import GSASIIscriptable as G2sc

from branch_refinement import freeze_project


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("candidate")
    parser.add_argument("output")
    parser.add_argument("name")
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.source, newgpx=args.output)
    phase = gpx.add_phase(
        args.candidate,
        phasename=args.name,
        histograms=gpx.histograms(),
        fmthint="CIF",
    )
    freeze_project(gpx)
    phase.data["General"]["Cell"][0] = False
    for hap in phase.data["Histograms"].values():
        hap["Scale"] = [0.001, True]
        hap["Size"][1][0] = 10.0
        hap["Mustrain"][1][0] = 0.0
    gpx.data["Controls"]["data"]["max cyc"] = 12
    gpx.data["Controls"]["data"]["min dM/M"] = 0.0001
    gpx.save()
    gpx.refine()
    gpx.save()

    hist = gpx.histograms()[0]
    cov = gpx.data["Covariance"]["data"]
    key = f"{len(gpx.phases()) - 1}:0:Scale"
    values = dict(zip(cov.get("varyList", []), cov.get("variables", [])))
    sigmas = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    print(
        "IMPURITY_RESULT",
        "Rwp", hist.get_wR(),
        "scale", values.get(key),
        "scale_esd", sigmas.get(key),
        "mass_fractions", hist.ComputeMassFracs(),
        "Rvals", cov.get("Rvals"),
    )


if __name__ == "__main__":
    main()
