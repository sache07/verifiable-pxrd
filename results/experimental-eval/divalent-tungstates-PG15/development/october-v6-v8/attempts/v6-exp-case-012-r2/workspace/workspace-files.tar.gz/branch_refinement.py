#!/usr/bin/env python3
"""Run a tightly controlled one-purpose GSAS-II refinement branch."""

import argparse
import json

import GSASIIscriptable as G2sc


def freeze_project(gpx):
    """Turn off all refinement flags while preserving parameter values."""
    for hist in gpx.histograms():
        hist.data["Background"][0][1] = False
        for value in hist.data["Instrument Parameters"][0].values():
            if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
                value[2] = False
        for value in hist.data["Sample Parameters"].values():
            if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
                value[1] = False

    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        for hap in phase.data["Histograms"].values():
            hap["Scale"][1] = False
            hap["Pref.Ori."][2] = False
            for i in range(len(hap["Size"][2])):
                hap["Size"][2][i] = False
            for i in range(len(hap["Mustrain"][2])):
                hap["Mustrain"][2][i] = False
            for i in range(len(hap["HStrain"][1])):
                hap["HStrain"][1][i] = False
            hap["Extinction"][1] = False


def enable_mode(gpx, mode):
    hist = gpx.histograms()[0]
    phases = gpx.phases()
    if mode == "niw_heavy":
        for atom in phases[0].atoms():
            if atom.element in {"Ni", "W"}:
                atom.refinement_flags = "X"
    elif mode == "niw_oxygen":
        for atom in phases[0].atoms():
            if atom.element == "O":
                atom.refinement_flags = "X"
    elif mode == "niw_all":
        for atom in phases[0].atoms():
            atom.refinement_flags = "X"
    elif mode == "wo3_w":
        for atom in phases[1].atoms():
            if atom.element == "W":
                atom.refinement_flags = "X"
    elif mode == "polariz":
        hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    elif mode == "surf_a":
        hist.data["Sample Parameters"]["SurfRoughA"][1] = True
    elif mode == "surf_b":
        # At the neutral correction A=B=0, only B has a nonzero derivative.
        hist.data["Sample Parameters"]["SurfRoughB"][1] = True
    elif mode == "surf_ab":
        hist.data["Sample Parameters"]["SurfRoughA"][1] = True
        hist.data["Sample Parameters"]["SurfRoughB"][1] = True
    elif mode in {"profile_u", "profile_x", "profile_y", "profile_shl"}:
        key = {"profile_u": "U", "profile_x": "X", "profile_y": "Y", "profile_shl": "SH/L"}[mode]
        hist.data["Instrument Parameters"][0][key][2] = True
    elif mode == "surface_on_top":
        hist.data["Sample Parameters"]["SurfRoughB"][1] = True
    elif mode.startswith("size_p"):
        phase_index = int(mode[-1])
        for hap in phases[phase_index].data["Histograms"].values():
            if hap["Size"][1][0] >= 9.0:
                hap["Size"][1][0] = 1.0
            hap["Size"][2][0] = True
    elif mode.startswith("strain_p"):
        phase_index = int(mode[-1])
        for hap in phases[phase_index].data["Histograms"].values():
            if hap["Mustrain"][1][0] < 1.0:
                hap["Mustrain"][1][0] = 1000.0
            hap["Mustrain"][2][0] = True
    elif mode.startswith("texture_p"):
        # mode syntax: texture_p{phase}_{100|010|001}
        phase_index = int(mode[9])
        axis_text = mode.split("_")[-1]
        axis = [int(x) for x in axis_text]
        for hap in phases[phase_index].data["Histograms"].values():
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = axis
    elif mode == "joint":
        hist.data["Background"][0][1] = True
        inst = hist.data["Instrument Parameters"][0]
        for key in ("Zero", "V", "W", "Z", "Polariz."):
            inst[key][2] = True
        for phase in phases:
            phase.data["General"]["Cell"][0] = True
            for hap in phase.data["Histograms"].values():
                hap["Scale"][1] = True
        for atom in phases[0].atoms():
            atom.refinement_flags = "X"
    elif mode == "joint_neutral_micro":
        enable_mode(gpx, "joint")
        for phase in phases:
            for hap in phase.data["Histograms"].values():
                hap["Size"][1][0] = 1000.0
                hap["Size"][2][0] = False
                hap["Mustrain"][1][0] = 0.0
                hap["Mustrain"][2][0] = False
    elif mode == "joint_strain_p1":
        enable_mode(gpx, "joint")
        for index, phase in enumerate(phases):
            for hap in phase.data["Histograms"].values():
                hap["Size"][1][0] = 1000.0
                hap["Size"][2][0] = False
                if index == 0:
                    hap["Mustrain"][1][0] = 0.0
                    hap["Mustrain"][2][0] = False
                else:
                    hap["Mustrain"][2][0] = True
    elif mode.startswith("joint_no_") or mode in {"joint_bg8", "joint_bg9"}:
        enable_mode(gpx, "joint")
        inst = hist.data["Instrument Parameters"][0]
        if mode == "joint_no_polar":
            inst["Polariz."][1:] = [0.5, False]
        elif mode == "joint_no_v":
            inst["V"][1:] = [0.0, False]
        elif mode == "joint_no_z":
            inst["Z"][1:] = [0.0, False]
        elif mode == "joint_no_zero":
            inst["Zero"][1:] = [0.0, False]
        elif mode == "joint_no_heavy":
            source = {"Ni1": (0.5, 0.653, 0.25), "W1": (0.0, 0.18, 0.25)}
            for atom in phases[0].atoms():
                if atom.label in source:
                    atom.coordinates = source[atom.label]
                    atom.refinement_flags = ""
        elif mode == "joint_no_oxygen":
            source = {"O1": (0.22, 0.11, 0.96), "O2": (0.26, 0.38, 0.39)}
            for atom in phases[0].atoms():
                if atom.label in source:
                    atom.coordinates = source[atom.label]
                    atom.refinement_flags = ""
        elif mode in {"joint_bg8", "joint_bg9"}:
            background = hist.data["Background"][0]
            count = int(mode[-1])
            background[2] = count
            del background[3 + count:]
        else:
            raise ValueError(f"unknown deletion mode: {mode}")
    elif mode.startswith("final_no_") or mode == "final_bg9":
        enable_mode(gpx, "joint_strain_p1")
        inst = hist.data["Instrument Parameters"][0]
        if mode == "final_no_polar":
            inst["Polariz."][1:] = [0.5, False]
        elif mode == "final_no_v":
            inst["V"][1:] = [0.0, False]
        elif mode == "final_no_z":
            inst["Z"][1:] = [0.0, False]
        elif mode == "final_no_zero":
            inst["Zero"][1:] = [0.0, False]
        elif mode == "final_no_heavy":
            source = {"Ni1": (0.5, 0.653, 0.25), "W1": (0.0, 0.18, 0.25)}
            for atom in phases[0].atoms():
                if atom.label in source:
                    atom.coordinates = source[atom.label]
                    atom.refinement_flags = ""
        elif mode == "final_no_oxygen":
            source = {"O1": (0.22, 0.11, 0.96), "O2": (0.26, 0.38, 0.39)}
            for atom in phases[0].atoms():
                if atom.label in source:
                    atom.coordinates = source[atom.label]
                    atom.refinement_flags = ""
        elif mode == "final_no_strain":
            for hap in phases[1].data["Histograms"].values():
                hap["Mustrain"][1][0] = 0.0
                hap["Mustrain"][2][0] = False
        elif mode == "final_bg9":
            background = hist.data["Background"][0]
            background[2] = 9
            del background[12:]
        else:
            raise ValueError(f"unknown final deletion mode: {mode}")
    elif mode in {"final_drop_p0", "final_drop_p1"}:
        enable_mode(gpx, "joint_strain_p1")
        drop_index = int(mode[-1])
        dropped = phases[drop_index]
        dropped.data["General"]["Cell"][0] = False
        for atom in dropped.atoms():
            atom.refinement_flags = ""
        for hap in dropped.data["Histograms"].values():
            hap["Use"] = False
            hap["Scale"][1] = False
            hap["Mustrain"][2][0] = False
    else:
        raise ValueError(f"unknown mode: {mode}")


def summarize(gpx, mode):
    cov = gpx.data.get("Covariance", {}).get("data", {})
    hist = gpx.histograms()[0]
    return {
        "mode": mode,
        "Rwp": hist.get_wR(),
        "Lastshft": cov.get("Lastshft"),
        "varyList": cov.get("varyList", []),
        "variables": cov.get("variables", []),
        "sig": cov.get("sig", []),
        "Rvals": cov.get("Rvals", {}),
        "atoms": [
            {
                "phase": phase.name,
                "label": atom.label,
                "element": atom.element,
                "xyz": list(atom.coordinates),
                "flags": atom.refinement_flags,
            }
            for phase in gpx.phases()
            for atom in phase.atoms()
        ],
        "polariz": hist.data["Instrument Parameters"][0]["Polariz."],
        "surf_a": hist.data["Sample Parameters"]["SurfRoughA"],
        "surf_b": hist.data["Sample Parameters"]["SurfRoughB"],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument(
        "mode",
        choices=(
            "niw_heavy", "niw_oxygen", "niw_all", "wo3_w", "polariz", "surf_a", "surf_b", "surf_ab", "joint", "joint_neutral_micro", "joint_strain_p1",
            "profile_u", "profile_x", "profile_y", "profile_shl", "surface_on_top",
            "size_p0", "size_p1", "strain_p0", "strain_p1",
            "texture_p0_100", "texture_p0_010", "texture_p0_001", "texture_p1_100", "texture_p1_010", "texture_p1_001",
            "joint_no_polar", "joint_no_v", "joint_no_z", "joint_no_zero", "joint_no_heavy", "joint_no_oxygen", "joint_bg8", "joint_bg9",
            "final_no_polar", "final_no_v", "final_no_z", "final_no_zero", "final_no_heavy", "final_no_oxygen", "final_no_strain", "final_bg9",
            "final_drop_p0", "final_drop_p1",
        ),
    )
    args = parser.parse_args()

    gpx = G2sc.G2Project(args.source, newgpx=args.output)
    freeze_project(gpx)
    enable_mode(gpx, args.mode)
    controls = gpx.data["Controls"]["data"]
    controls["max cyc"] = 16
    controls["min dM/M"] = 0.0001
    gpx.save()
    gpx.refine()
    gpx.save()
    def encode(value):
        if hasattr(value, "tolist"):
            return value.tolist()
        if hasattr(value, "item"):
            return value.item()
        return str(value)

    print("BRANCH_RESULT " + json.dumps(summarize(gpx, args.mode), default=encode))


if __name__ == "__main__":
    main()
