#!/usr/bin/env python3
"""Export machine-readable results from the frozen GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"


def main() -> None:
    project = G2sc.G2Project(str(PROJECT))
    histogram = project.histograms()[0]
    arrays = histogram.data["data"][1]
    two_theta = np.asarray(arrays[0], dtype=float)
    observed = np.asarray(arrays[1], dtype=float)
    weights = np.asarray(arrays[2], dtype=float)
    calculated = np.asarray(arrays[3], dtype=float)
    difference = observed - calculated
    if not all(np.all(np.isfinite(item)) for item in (two_theta, observed, calculated, difference)):
        raise ValueError("nonfinite profile value")

    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(("two_theta_deg", "observed", "calculated", "difference"))
        for row in zip(two_theta, observed, calculated, difference):
            writer.writerow(
                (
                    f"{row[0]:.10f}",
                    f"{row[1]:.8f}",
                    f"{row[2]:.8f}",
                    f"{row[3]:.8f}",
                )
            )

    fractions = histogram.ComputeMassFracs()
    cells = {phase.name: phase.get_cell() for phase in project.phases()}
    summary = histogram.data["data"][0]
    refinement = project.data["Covariance"]["data"]["Rvals"]
    full_grid_rwp = 100.0 * np.sqrt(
        np.sum(weights * difference**2) / np.sum(weights * observed**2)
    )
    phase_metadata = {
        "WO3": {
            "name": "tungsten trioxide",
            "formula": "WO3",
            "space_group": "P -1",
            "space_group_number": 2,
            "cif_path": "phase_1_WO3.cif",
        },
        "Mn2O3": {
            "name": "manganese(III) oxide",
            "formula": "Mn2O3",
            "space_group": "Ia-3",
            "space_group_number": 206,
            "cif_path": "phase_2_Mn2O3.cif",
        },
        "MnWO4": {
            "name": "manganese tungstate (wolframite)",
            "formula": "MnWO4",
            "space_group": "P 2/c",
            "space_group_number": 13,
            "cif_path": "phase_3_MnWO4.cif",
        },
    }
    phases = []
    for phase in project.phases():
        fraction, esd = fractions[phase.name]
        record = dict(phase_metadata[phase.name])
        record.update(
            weight_fraction=float(fraction),
            weight_fraction_esd=float(esd),
            cell={key: float(value) for key, value in cells[phase.name].items()},
        )
        phases.append(record)

    result = {
        "phases": phases,
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": float(summary["wR"]),
            "Rp_percent": float(summary["R"]),
            "R_expected_percent": float(summary["wRmin"]),
            "GOF": float(refinement["GOF"]),
            "chi_squared": float(refinement["chisq"]),
            "N_observations": int(refinement["Nobs"]),
            "N_refined_variables": int(refinement["Nvars"]),
            "full_grid_Rwp_percent": float(full_grid_rwp),
        },
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "unresolved_components": [],
        "uncertainty_note": (
            "Reported fraction e.s.d.s are conditional counting-statistical values from the "
            "frozen profile model; the trace MnWO4 fraction has larger systematic uncertainty."
        ),
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=False) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
