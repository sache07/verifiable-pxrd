#!/usr/bin/env python3
"""Matched add/remove/replace phase tests from a mature GSAS-II baseline."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def refine(project: G2sc.G2Project, repeats: int = 2) -> None:
    for attempt in range(1, repeats + 1):
        project.refine()
        state = covariance_status(project)
        value = project.histograms()[0].get_wR()
        print(
            "PHASE_TEST_STEP="
            + json.dumps(
                {
                    "attempt": attempt,
                    "rwp_percent": value,
                    "converged": state.get("converged"),
                    "max_shift_sigma": state.get("Max shft/sig"),
                    "svd_zero": state.get("SVD0"),
                    "message": state.get("msg"),
                },
                sort_keys=True,
                default=str,
            )
        )
        if value is None or not math.isfinite(float(value)):
            raise RuntimeError("nonfinite refinement")
        if state.get("Aborted") or state.get("SVD0", 0):
            raise RuntimeError(f"unstable refinement: {state}")
        if state.get("converged") and float(state.get("Max shft/sig") or 0.0) < 0.1:
            break
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--disable")
    parser.add_argument("--add", help="NAME=CIF")
    parser.add_argument("--replace", help="OLD_NAME=NEW_NAME=CIF")
    parser.add_argument("--refine-added-cell", action="store_true")
    parser.add_argument("--repeats", type=int, default=2)
    args = parser.parse_args()

    operations = [bool(args.disable), bool(args.add), bool(args.replace)]
    if sum(operations) != 1:
        raise SystemExit("specify exactly one of --disable, --add or --replace")

    destination = args.destination.resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(destination))
    histogram = project.histograms()[0]
    added = None

    if args.disable:
        phase = project.phase(args.disable)
        phase.data["Histograms"][histogram.name]["Use"] = False
    elif args.add:
        name, cif = args.add.split("=", 1)
        added = project.add_phase(
            str(Path(cif).resolve()),
            phasename=name,
            histograms=[histogram],
            fmthint="CIF",
        )
        hap = added.data["Histograms"][histogram.name]
        hap["Scale"][:] = [0.05, True]
    else:
        old_name, new_name, cif = args.replace.split("=", 2)
        old = project.phase(old_name)
        old_hap = old.data["Histograms"][histogram.name]
        old_scale = float(old_hap["Scale"][0])
        old_hap["Use"] = False
        added = project.add_phase(
            str(Path(cif).resolve()),
            phasename=new_name,
            histograms=[histogram],
            fmthint="CIF",
        )
        hap = added.data["Histograms"][histogram.name]
        hap["Scale"][:] = [old_scale, True]

    if added is not None:
        added.set_refinements({"Cell": bool(args.refine_added_cell)})
        # A newly imported GSAS-II phase otherwise carries non-neutral default
        # crystallite-size/microstrain broadening.  Keep phase-inventory tests
        # matched to the mature baseline unless broadening is tested explicitly.
        hap = added.data["Histograms"][histogram.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])

    project.set_Controls("cycles", 12)
    project.save()
    refine(project, max(1, args.repeats))

    fractions = histogram.ComputeMassFracs()
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"].get(histogram.name, {})
        rows.append(
            {
                "name": phase.name,
                "use": hap.get("Use"),
                "scale": hap.get("Scale"),
                "mass_fraction": fractions.get(phase.name),
                "cell": phase.get_cell(),
            }
        )
    print(
        "PHASE_TEST_RESULT="
        + json.dumps(
            {
                "rwp_percent": histogram.get_wR(),
                "phases": rows,
                "convergence": covariance_status(project),
            },
            sort_keys=True,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
