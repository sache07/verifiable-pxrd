#!/usr/bin/env python3
"""Create matched refinement branches from an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PROFILE_KEYS = ("U", "V", "W", "X", "Y", "Z")


def status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def correlations(project: G2sc.G2Project, threshold: float = 0.9) -> list[dict]:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    output = []
    for left in range(len(names)):
        for right in range(left + 1, len(names)):
            denominator = math.sqrt(max(matrix[left, left], 0.0)) * math.sqrt(
                max(matrix[right, right], 0.0)
            )
            if denominator <= 0:
                continue
            value = float(matrix[left, right] / denominator)
            if abs(value) >= threshold:
                output.append(
                    {"left": names[left], "right": names[right], "correlation": value}
                )
    output.sort(key=lambda row: abs(row["correlation"]), reverse=True)
    return output


def refine(project: G2sc.G2Project, repeats: int) -> None:
    previous = math.inf
    for attempt in range(1, repeats + 1):
        project.refine()
        current = float(project.histograms()[0].get_wR())
        state = status(project)
        print(
            "BRANCH_STEP="
            + json.dumps(
                {
                    "attempt": attempt,
                    "rwp_percent": current,
                    "converged": state.get("converged"),
                    "max_shift_sigma": state.get("Max shft/sig"),
                    "svd_zero": state.get("SVD0"),
                    "message": state.get("msg"),
                },
                sort_keys=True,
                default=str,
            )
        )
        message = str(state.get("msg", "") or "").lower()
        if not math.isfinite(current):
            raise RuntimeError("nonfinite Rwp")
        if state.get("Aborted") or state.get("SVD0", 0) or "dropped" in message:
            raise RuntimeError(f"unstable refinement: {state}")
        if current > previous + 0.002:
            break
        previous = min(previous, current)
        if state.get("converged") and float(state.get("Max shft/sig") or 0.0) < 0.1:
            break
    project.save()


def summary(project: G2sc.G2Project) -> dict:
    histogram = project.histograms()[0]
    phases = []
    mass_fractions = histogram.ComputeMassFracs()
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "mass_fraction": mass_fractions.get(phase.name),
                "size": hap.get("Size"),
                "mustrain": hap.get("Mustrain"),
                "preferred_orientation": hap.get("Pref.Ori."),
            }
        )
    return {
        "rwp_percent": histogram.get_wR(),
        "instrument": {
            key: histogram.InstrumentParameters.get(key)
            for key in (
                "Lam1",
                "Lam2",
                "I(L2)/I(L1)",
                "Zero",
                "Polariz.",
                "U",
                "V",
                "W",
                "X",
                "Y",
                "Z",
                "SH/L",
            )
        },
        "sample": histogram.SampleParameters,
        "phases": phases,
        "convergence": status(project),
        "high_correlations": correlations(project),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--reset-profile", action="store_true")
    parser.add_argument(
        "--profile",
        default="",
        help="comma-separated instrument profile terms to refine",
    )
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--size-phase")
    parser.add_argument("--strain-phase")
    args = parser.parse_args()

    destination = args.destination.resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(destination))
    histogram = project.histograms()[0]
    if args.reset_profile:
        starts = {"U": 100.0, "V": 0.0, "W": 50.0, "X": 0.0, "Y": 0.0, "Z": 0.0}
        for key, value in starts.items():
            histogram.InstrumentParameters[key][1] = value
            histogram.InstrumentParameters[key][2] = False
    requested = {key.strip() for key in args.profile.split(",") if key.strip()}
    unknown = requested.difference(PROFILE_KEYS)
    if unknown:
        raise ValueError(f"unknown profile terms: {sorted(unknown)}")
    if args.profile:
        for key in PROFILE_KEYS:
            histogram.InstrumentParameters[key][2] = key in requested

    if args.size_phase and args.strain_phase:
        raise ValueError("test size and strain independently")
    if args.size_phase:
        phase = project.phase(args.size_phase)
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "value": 1.0,
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
    if args.strain_phase:
        phase = project.phase(args.strain_phase)
        hap = phase.data["Histograms"][histogram.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [True, False, False]

    project.set_Controls("cycles", 12)
    project.save()
    refine(project, max(1, args.repeats))
    print("BRANCH_RESULT=" + json.dumps(summary(project), sort_keys=True, default=str))


if __name__ == "__main__":
    main()
