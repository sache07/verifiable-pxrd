#!/usr/bin/env python3
"""Create and minimally refine a GSAS-II powder project for model screening.

Run with the GSAS-II Python interpreter. This is a working script used to
compare atomistic phase inventories with identical refinement staging.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def prepare_inputs(pattern: Path, workdir: Path) -> tuple[Path, Path]:
    workdir.mkdir(parents=True, exist_ok=True)
    xye = workdir / "pattern.xye"
    with pattern.open(newline="", encoding="utf-8") as source, xye.open(
        "w", encoding="utf-8"
    ) as destination:
        reader = csv.DictReader(source)
        for row in reader:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            destination.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")

    inst = workdir / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for supplied Cu Ka reflection data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.20;Polariz.:0.5;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:100.0;V:0.0;W:50.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n",
        encoding="utf-8",
    )
    return xye, inst


def covariance_status(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def stable_refine(project: G2sc.G2Project, label: str, repeats: int = 3) -> dict:
    status = {}
    for attempt in range(1, repeats + 1):
        project.refine()
        status = covariance_status(project)
        print(
            json.dumps(
                {
                    "stage": label,
                    "attempt": attempt,
                    "rwp": project.histograms()[0].get_wR(),
                    "converged": status.get("converged"),
                    "max_shift_sigma": status.get("Max shft/sig"),
                    "svd_zero": status.get("SVD0"),
                    "message": status.get("msg"),
                },
                sort_keys=True,
                default=str,
            )
        )
        message = str(status.get("msg", "") or "").lower()
        if status.get("Aborted") or status.get("SVD0", 0) or "dropped" in message:
            raise RuntimeError(f"unstable refinement in {label}: {status}")
        if status.get("converged") and float(status.get("Max shft/sig") or 0.0) < 0.05:
            break
    project.save()
    return status


def summarize(project: G2sc.G2Project) -> dict:
    histogram = project.histograms()[0]
    result = {
        "rwp": histogram.get_wR(),
        "instrument": {
            key: value
            for key, value in histogram.InstrumentParameters.items()
            if key in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            key: value
            for key, value in histogram.SampleParameters.items()
            if key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": [],
        "convergence": covariance_status(project),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "weight_fraction": hap.get("WgtFrac"),
                "size": hap.get("Size"),
                "mustrain": hap.get("Mustrain"),
            }
        )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("models", nargs="+", help="PHASE_NAME=CIF_PATH")
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--workdir", type=Path, default=Path(".tmp/gsas-input"))
    args = parser.parse_args()

    xye, inst = prepare_inputs(args.pattern.resolve(), args.workdir.resolve())
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(output))
    histogram = project.add_powder_histogram(
        str(xye), str(inst), fmthint="xye"
    )
    # The importer enables a histogram-wide scale. Keep it fixed because each
    # phase scale is refined; varying both creates an exact scale redundancy.
    histogram.SampleParameters["Scale"][:] = [1.0, False]
    histogram.set_refinements({"Limits": [10.0, 100.05]})
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 12,
                "coeffs": [1100.0] + [0.0] * 11,
            }
        }
    )

    phases = []
    for item in args.models:
        name, cif = item.split("=", 1)
        phase = project.add_phase(
            str(Path(cif).resolve()),
            phasename=name,
            histograms=[histogram],
            fmthint="CIF",
        )
        phase.set_HAP_refinements({"Scale": True})
        phases.append(phase)

    project.set_Controls("cycles", 8)
    project.save()
    stable_refine(project, "background_scales", repeats=4)

    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    stable_refine(project, "zero", repeats=3)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    stable_refine(project, "cells", repeats=4)

    histogram.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
    stable_refine(project, "global_profile", repeats=4)

    summary = summarize(project)
    print("TRIAL_RESULT=" + json.dumps(summary, sort_keys=True, default=str))
    project.save()


if __name__ == "__main__":
    main()
