#!/usr/bin/env python3
"""Run matched, staged GSAS-II nuisance/profile/microstructure branches."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


PROFILE_KEYS = ("U", "V", "W", "X", "Y", "Z")


def rvals(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def correlations(project: G2sc.G2Project, threshold: float = 0.9) -> list[dict]:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return []
    result = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            denom = math.sqrt(max(matrix[i, i], 0.0) * max(matrix[j, j], 0.0))
            if denom <= 0:
                continue
            corr = float(matrix[i, j] / denom)
            if abs(corr) >= threshold:
                result.append({"left": names[i], "right": names[j], "correlation": corr})
    return sorted(result, key=lambda item: abs(item["correlation"]), reverse=True)


def freeze_to_scales_and_background(project: G2sc.G2Project) -> None:
    histogram = project.histograms()[0]
    for value in histogram.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in histogram.SampleParameters.values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    histogram.Background[0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Babinet": ["BabA", "BabU"],
                "Extinction": True,
                "HStrain": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "Size": True,
                "Scale": True,
            }
        )
        phase.set_HAP_refinements({"Scale": True})


def summarize(project: G2sc.G2Project) -> dict:
    histogram = project.histograms()[0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    values = covariance.get("variables", [])
    sigmas = covariance.get("sig", [])
    vary = covariance.get("varyList", [])
    refined = {
        name: {"value": float(value), "sigma": float(sigma)}
        for name, value, sigma in zip(vary, values, sigmas)
    }
    fractions = histogram.ComputeMassFracs()
    return {
        "rwp_percent": float(histogram.get_wR()),
        "gof": rvals(project).get("GOF"),
        "convergence": rvals(project),
        "refined": refined,
        "high_correlations": correlations(project),
        "instrument": {
            key: histogram.InstrumentParameters.get(key)
            for key in ("Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            key: histogram.SampleParameters.get(key)
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": {
            phase.name: {
                "mass_fraction": fractions.get(phase.name),
                "cell": phase.get_cell(),
                "hap": {
                    key: phase.data["Histograms"][histogram.name].get(key)
                    for key in ("Scale", "Pref.Ori.", "Size", "Mustrain")
                },
            }
            for phase in project.phases()
        },
    }


def refine_keep_best(project: G2sc.G2Project, destination: Path, repeats: int) -> G2sc.G2Project:
    best_path = destination.with_name(destination.stem + "-best.gpx")
    best_rwp = math.inf
    for attempt in range(1, repeats + 1):
        project.refine()
        project.save()
        current = float(project.histograms()[0].get_wR())
        state = rvals(project)
        print(
            "OPTIONAL_STEP="
            + json.dumps(
                {
                    "attempt": attempt,
                    "rwp_percent": current,
                    "converged": state.get("converged"),
                    "max_shift_sigma": state.get("Max shft/sig"),
                    "svd_zero": state.get("SVD0"),
                    "message": state.get("msg"),
                },
                sort_keys=True,
                default=str,
            )
        )
        message = str(state.get("msg", "") or "").lower()
        invalid = (
            not math.isfinite(current)
            or state.get("Aborted")
            or state.get("SVD0", 0)
            or "dropped" in message
        )
        if invalid:
            break
        if current < best_rwp:
            best_rwp = current
            shutil.copy2(destination, best_path)
        if state.get("converged") and float(state.get("Max shft/sig") or 0.0) < 0.1:
            break
        if current > best_rwp + 0.002:
            break
    if not best_path.exists():
        raise RuntimeError("no valid branch cycle")
    shutil.copy2(best_path, destination)
    best_path.unlink()
    return G2sc.G2Project(str(destination))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument(
        "--polarization-value",
        type=float,
        help="set polarization to a fixed value (for a matched leave-out test)",
    )
    parser.add_argument(
        "--roughness",
        nargs=2,
        type=float,
        metavar=("A", "B"),
        help="set Suortti A and B; refine B only",
    )
    parser.add_argument("--roughness-both", action="store_true")
    parser.add_argument("--texture-phase")
    parser.add_argument("--texture-axis", nargs=3, type=int, metavar=("H", "K", "L"))
    parser.add_argument(
        "--neutral-texture-phase",
        help="set the named phase March-Dollase ratio to one and keep it fixed",
    )
    parser.add_argument("--micro-phase")
    parser.add_argument("--micro-kind", choices=("size", "strain"))
    parser.add_argument("--micro-start", type=float)
    parser.add_argument(
        "--clear-micro-all",
        action="store_true",
        help="set all phase sizes to 1000 micrometres and all microstrains to zero",
    )
    parser.add_argument(
        "--clear-micro-phase",
        help="set size broadening neutral and microstrain zero for one phase",
    )
    parser.add_argument("--cells", action="store_true")
    parser.add_argument("--cell-phase")
    parser.add_argument("--zero-profile", choices=PROFILE_KEYS)
    parser.add_argument(
        "--profile-reopt",
        default="",
        help="comma-separated profile terms to refine after zeroing one term",
    )
    args = parser.parse_args()

    destination = args.destination.resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(args.source.resolve()), newgpx=str(destination))
    freeze_to_scales_and_background(project)
    histogram = project.histograms()[0]

    if args.polarization:
        histogram.InstrumentParameters["Polariz."][2] = True
    if args.polarization_value is not None:
        if args.polarization:
            raise ValueError("cannot refine and fix polarization together")
        histogram.InstrumentParameters["Polariz."][1] = args.polarization_value
        histogram.InstrumentParameters["Polariz."][2] = False
    if args.roughness:
        a, b = args.roughness
        histogram.SampleParameters["SurfRoughA"] = [a, bool(args.roughness_both)]
        histogram.SampleParameters["SurfRoughB"] = [b, True]
    if bool(args.texture_phase) != bool(args.texture_axis):
        raise ValueError("texture phase and axis must be supplied together")
    if args.texture_phase:
        phase = project.phase(args.texture_phase)
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(args.texture_axis)
    if args.neutral_texture_phase:
        hap = project.phase(args.neutral_texture_phase).data["Histograms"][histogram.name]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    if bool(args.micro_phase) != bool(args.micro_kind):
        raise ValueError("micro phase and kind must be supplied together")
    if args.clear_micro_all:
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1000.0
            hap["Size"][1][2] = 1.0
            hap["Size"][2] = [False] * len(hap["Size"][2])
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][1][2] = 1.0
            hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    if args.clear_micro_phase:
        hap = project.phase(args.clear_micro_phase).data["Histograms"][histogram.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    if args.micro_phase:
        phase = project.phase(args.micro_phase)
        if args.micro_kind == "size":
            size_options = {
                "type": "isotropic",
                "refine": True,
                "LGmix": {"value": 1.0, "refine": False},
            }
            if args.micro_start is not None:
                size_options["value"] = args.micro_start
            phase.set_HAP_refinements(
                {"Size": size_options}
            )
        else:
            phase.set_HAP_refinements(
                {
                    "Mustrain": {
                        "type": "isotropic",
                        "refine": True,
                        "LGmix": {"value": 1.0, "refine": False},
                    }
                }
            )
            hap = phase.data["Histograms"][histogram.name]
            if args.micro_start is not None:
                hap["Mustrain"][1][0] = args.micro_start
    if args.cells and args.cell_phase:
        raise ValueError("use either --cells or --cell-phase")
    if args.cells:
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
    if args.cell_phase:
        project.phase(args.cell_phase).data["General"]["Cell"][0] = True
    requested = {item.strip() for item in args.profile_reopt.split(",") if item.strip()}
    if requested.difference(PROFILE_KEYS):
        raise ValueError(f"invalid profile terms: {sorted(requested.difference(PROFILE_KEYS))}")
    if args.zero_profile:
        histogram.InstrumentParameters[args.zero_profile][1] = 0.0
        histogram.InstrumentParameters[args.zero_profile][2] = False
    for key in requested:
        histogram.InstrumentParameters[key][2] = True

    project.set_Controls("cycles", 12)
    project.save()
    project = refine_keep_best(project, destination, max(1, args.repeats))
    print("OPTIONAL_RESULT=" + json.dumps(summarize(project), sort_keys=True, default=str))


if __name__ == "__main__":
    main()
