#!/usr/bin/env python3
"""Create, refine, branch, inspect and export the PXRD GSAS-II model.

This is a task-local driver. It deliberately keeps every optional model term
explicit so complete-pattern branches can be compared and rolled back.
"""

from __future__ import annotations

import argparse
import copy
import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def covariance(project: G2sc.G2Project) -> dict:
    return project.data.get("Covariance", {}).get("data", {})


def stable_refine(project: G2sc.G2Project, cycles: int = 8) -> bool:
    """Refine repeatedly until converged or until a numerical warning appears."""
    project.set_Controls("cycles", 8)
    for _ in range(cycles):
        try:
            project.refine()
        except Exception as exc:
            print("REFINEMENT_ERROR", repr(exc))
            return False
        rvals = covariance(project).get("Rvals", {})
        message = str(rvals.get("msg", "") or "").lower()
        if rvals.get("Aborted") or rvals.get("SVD0", 0) or "dropped" in message or "error" in message:
            print("REFINEMENT_UNSTABLE", json.dumps(rvals, default=str))
            return False
        if rvals.get("converged") and float(rvals.get("Max shft/sig") or 0.0) < 0.05:
            return True
    return bool(covariance(project).get("Rvals", {}).get("converged"))


def clear_all_flags(project: G2sc.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) == 2:
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.data["Atoms"]:
            atom[2] = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        if "Pref.Ori." in hap:
            hap["Pref.Ori."][2] = False
        for key in ("Size", "Mustrain"):
            if key in hap:
                hap[key][2] = [False] * len(hap[key][2])
        if "HStrain" in hap:
            hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        if "Extinction" in hap:
            hap["Extinction"][1] = False


def configure_background(hist, ncoeff: int = 12) -> None:
    # Chebyshev-1 is well behaved over a fixed fit range.
    bkg = hist.Background[0]
    bkg[0] = "chebyschev-1"
    bkg[1] = True
    bkg[2] = ncoeff
    initial = [1200.0, -900.0, 500.0, -250.0] + [0.0] * max(0, ncoeff - 4)
    bkg[3:] = initial[:ncoeff]


def create_project(output: Path, phases: list[tuple[str, str]]) -> G2sc.G2Project:
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    configure_background(hist, 12)
    for name, cod_id in phases:
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.HAPvalue("Scale", 1.0)
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    project.data["Controls"]["data"]["shift factor"] = 1.0
    project.set_Controls("cycles", 8)
    project.save()
    return project


def summary(project: G2sc.G2Project, label: str = "") -> dict:
    hist = project.histograms()[0]
    cov = covariance(project)
    rvals = cov.get("Rvals", {})
    result = {
        "label": label,
        "file": project.filename,
        "rwp_percent": hist.get_wR(),
        "rp_percent": hist.residuals.get("R"),
        "gof": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_sigma": rvals.get("Max shft/sig"),
        "variables": len(cov.get("varyList", [])),
        "zero": hist.InstrumentParameters.get("Zero"),
        "profile": {k: hist.InstrumentParameters.get(k) for k in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")},
        "sample": {k: hist.SampleParameters.get(k) for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "phases": [],
    }
    try:
        mass = hist.ComputeMassFracs()
    except Exception as exc:
        mass = {p.name: (math.nan, math.nan) for p in project.phases()}
        result["mass_fraction_error"] = repr(exc)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "mass_fraction": mass.get(phase.name),
            "size": hap.get("Size"),
            "mustrain": hap.get("Mustrain"),
            "preferred_orientation": hap.get("Pref.Ori."),
        })
    return result


def print_summary(project: G2sc.G2Project, label: str) -> None:
    print("MODEL_SUMMARY=" + json.dumps(summary(project, label), sort_keys=True, default=str))


def minimal_refinement(project: G2sc.G2Project, refine_zero: bool = True) -> bool:
    """Matched nuisance model for structural screening."""
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    if not stable_refine(project):
        return False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    if refine_zero:
        hist.InstrumentParameters["Zero"][2] = True
    return stable_refine(project)


def command_create(args) -> None:
    phase_specs = []
    for item in args.phase:
        name, cod_id = item.split("=", 1)
        phase_specs.append((name, cod_id))
    project = create_project(Path(args.output).resolve(), phase_specs)
    ok = minimal_refinement(project, refine_zero=True)
    project.save()
    print_summary(project, "minimal")
    if not ok:
        raise SystemExit(2)


def command_refine(args) -> None:
    project = G2sc.G2Project(args.input, newgpx=args.output)
    project.data["Controls"]["data"]["shift factor"] = float(args.shift_factor)
    project.data["Controls"]["data"]["min dM/M"] = float(args.min_delta)
    hist = project.histograms()[0]
    for name, cod_id, scale in args.add_phase:
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.HAPvalue("Scale", float(scale))
    if args.clear:
        clear_all_flags(project)
    if args.background:
        hist.Background[0][1] = True
    if args.scales:
        for phase in project.phases():
            phase.data["Histograms"][hist.name]["Scale"][1] = True
    if args.cells:
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
    if args.zero:
        hist.InstrumentParameters["Zero"][2] = True
    for key, value in args.fix_instrument:
        hist.InstrumentParameters[key][1] = float(value)
        hist.InstrumentParameters[key][2] = False
    for key in args.instrument:
        hist.InstrumentParameters[key][2] = True
    for key, value in args.fix_sample:
        hist.SampleParameters[key][0] = float(value)
        hist.SampleParameters[key][1] = False
    for key in args.sample:
        hist.SampleParameters[key][1] = True
    for name in args.disable_phase:
        phase = project.phase(name)
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = False
        hap["Scale"] = [0.0, False]
        if "Pref.Ori." in hap:
            hap["Pref.Ori."][2] = False
        for key in ("Size", "Mustrain"):
            if key in hap:
                hap[key][2] = [False] * len(hap[key][2])
        if "HStrain" in hap:
            hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        if "Extinction" in hap:
            hap["Extinction"][1] = False
    for name in args.remove_size:
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]["Size"]
        hap[0] = "isotropic"
        hap[1][0] = 10.0
        hap[2] = [False] * len(hap[2])
    for name in args.remove_strain:
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]["Mustrain"]
        hap[0] = "isotropic"
        hap[1][0] = 0.0
        hap[2] = [False] * len(hap[2])
    for name in args.remove_md:
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]["Pref.Ori."]
        hap[0] = "MD"
        hap[1] = 1.0
        hap[2] = False
    for name in args.size:
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]["Size"]
        hap[0] = "isotropic"
        hap[1][0] = float(args.size_start)
        hap[2] = [False] * len(hap[2])
        hap[2][0] = True
    for name in args.strain:
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]["Mustrain"]
        hap[0] = "isotropic"
        hap[1][0] = float(args.strain_start)
        hap[2] = [False] * len(hap[2])
        hap[2][0] = True
    for phase_name, h, k, l in args.md:
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]["Pref.Ori."]
        hap[0] = "MD"
        hap[1] = 1.0
        hap[2] = True
        hap[3] = [int(h), int(k), int(l)]
    for phase_name, element, flags in args.atoms:
        phase = project.phase(phase_name)
        for atom in phase.atoms():
            if element == "all" or atom.element.split("+")[0].split("-")[0] == element:
                atom.refinement_flags = flags
    ok = stable_refine(project, args.repeats)
    project.save()
    print_summary(project, args.label or "refine")
    if not ok:
        raise SystemExit(2)


def command_summary(args) -> None:
    project = G2sc.G2Project(args.input)
    print_summary(project, args.label or "summary")


def command_export(args) -> None:
    project = G2sc.G2Project(args.input)
    for phase in project.phases():
        safe = phase.name.lower().replace(" ", "_").replace("/", "_")
        phase.export_CIF(str(Path(args.directory) / f"{safe}.cif"))
    hist = project.histograms()[0]
    fields = ["two_theta_deg", "observed", "calculated", "difference", "background"]
    arrays = [hist.getdata(k) for k in ("X", "Yobs", "Ycalc", "Residual", "Background")]
    with open(Path(args.directory) / "fit.csv", "w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(fields)
        writer.writerows(zip(*arrays))
    print_summary(project, "export")


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(required=True)
    q = sub.add_parser("create")
    q.add_argument("output")
    q.add_argument("--phase", action="append", required=True, help="NAME=COD_ID")
    q.set_defaults(func=command_create)
    q = sub.add_parser("refine")
    q.add_argument("input")
    q.add_argument("output")
    q.add_argument("--clear", action="store_true")
    q.add_argument("--background", action="store_true")
    q.add_argument("--scales", action="store_true")
    q.add_argument("--cells", action="store_true")
    q.add_argument("--zero", action="store_true")
    q.add_argument("--instrument", nargs="*", default=[])
    q.add_argument("--sample", nargs="*", default=[])
    q.add_argument("--fix-instrument", action="append", nargs=2, default=[], metavar=("KEY", "VALUE"))
    q.add_argument("--fix-sample", action="append", nargs=2, default=[], metavar=("KEY", "VALUE"))
    q.add_argument("--add-phase", action="append", nargs=3, default=[], metavar=("NAME", "COD_ID", "SCALE"))
    q.add_argument("--disable-phase", action="append", default=[])
    q.add_argument("--remove-size", action="append", default=[])
    q.add_argument("--remove-strain", action="append", default=[])
    q.add_argument("--remove-md", action="append", default=[])
    q.add_argument("--size", action="append", default=[], help="phase name")
    q.add_argument("--strain", action="append", default=[], help="phase name")
    q.add_argument("--size-start", type=float, default=1.0)
    q.add_argument("--strain-start", type=float, default=1000.0)
    q.add_argument("--md", action="append", nargs=4, default=[], metavar=("PHASE", "H", "K", "L"))
    q.add_argument("--atoms", action="append", nargs=3, default=[], metavar=("PHASE", "ELEMENT", "FLAGS"))
    q.add_argument("--repeats", type=int, default=8)
    q.add_argument("--shift-factor", type=float, default=1.0)
    q.add_argument("--min-delta", type=float, default=0.001)
    q.add_argument("--label")
    q.set_defaults(func=command_refine)
    q = sub.add_parser("summary")
    q.add_argument("input")
    q.add_argument("--label")
    q.set_defaults(func=command_summary)
    q = sub.add_parser("export")
    q.add_argument("input")
    q.add_argument("directory")
    q.set_defaults(func=command_export)
    return p


if __name__ == "__main__":
    args = parser().parse_args()
    args.func(args)
