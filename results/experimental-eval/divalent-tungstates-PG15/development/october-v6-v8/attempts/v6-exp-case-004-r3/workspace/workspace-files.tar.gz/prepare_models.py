#!/usr/bin/env python3
"""Prepare reproducible, audited starting models and GSAS-II input data."""

from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
CANDIDATES = ROOT / "candidates"
WORK = ROOT / "work"


def cod_path(identifier: str) -> Path:
    return COD / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def write_cif(
    structure: Structure,
    name: str,
    symprec: float = 0.02,
    space_group_override: tuple[str, str] | None = None,
) -> None:
    path = CANDIDATES / name
    CifWriter(structure, symprec=symprec, refine_struct=False).write_file(path)
    if space_group_override is not None:
        old, new = space_group_override
        text = path.read_text(encoding="utf-8")
        if old not in text:
            raise RuntimeError(f"expected space-group declaration missing in {path}")
        path.write_text(text.replace(old, new, 1), encoding="utf-8")


def main() -> None:
    CANDIDATES.mkdir(exist_ok=True)
    WORK.mkdir(exist_ok=True)

    data = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    np.savetxt(WORK / "pattern.xye", data, fmt=["%.8f", "%.1f"])

    # COD 2311041 is a geometry-clean P21/c WO3 model in a long, oblique
    # setting. This determinant-one basis change gives the conventional-like
    # ~7.30 x 7.54 x 7.69 A setting while preserving the structure exactly.
    wo3 = Structure.from_file(cod_path("2311041"))
    wo3.make_supercell([[1, 0, 1], [0, 1, 0], [1, 0, 0]])
    # In this transformed basis the glide is n (the source is an equivalent
    # nonstandard setting of space-group 14); state it explicitly for GSAS-II.
    write_cif(
        wo3,
        "wo3_p21c_cod2311041.cif",
        space_group_override=(
            "_symmetry_space_group_name_H-M   P2_1/c\n"
            "_cell_length_a",
            "_symmetry_space_group_name_H-M   'P 1 21/n 1'\n"
            "_cell_length_a",
        ),
    )
    # GSAS-II's CIF reader otherwise lets the IT number override the explicit
    # nonstandard setting name with its default P21/c setting.
    wo3_path = CANDIDATES / "wo3_p21c_cod2311041.cif"
    wo3_text = wo3_path.read_text(encoding="utf-8")
    wo3_path.write_text(
        wo3_text.replace("_symmetry_Int_Tables_number   14\n", "", 1),
        encoding="utf-8",
    )

    # Mg2+ and Co2+ are isovalent. Preserve the audited wolframite topology,
    # symmetry and coordinates, changing only the allowed sample element.
    cowo4 = Structure.from_file(cod_path("9013902"))
    cowo4.replace_species({"Mg": "Co"})
    write_cif(cowo4, "cowo4_wolframite_from_cod9013902.cif")

    # Materially distinct WO3 symmetry alternative retained for matched tests.
    wo3_triclinic = Structure.from_file(cod_path("2106293"))
    write_cif(wo3_triclinic, "wo3_p-1_cod2106293.cif", symprec=0.001)

    # Source-supported precursor/oxidation-product alternatives.
    write_cif(Structure.from_file(cod_path("1541662")), "coo_cod1541662.cif")
    write_cif(Structure.from_file(cod_path("9005896")), "co3o4_cod9005896.cif")


if __name__ == "__main__":
    main()
