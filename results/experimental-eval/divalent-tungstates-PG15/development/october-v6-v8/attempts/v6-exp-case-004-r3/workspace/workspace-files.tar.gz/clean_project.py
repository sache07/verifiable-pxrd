#!/usr/bin/env python3
"""Remove inactive phase alternatives from a GSAS-II project."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    source = args.source.resolve()
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2sc.G2Project(gpxfile=str(output))
    histogram = project.histograms()[0]
    inactive = []
    for phase in project.phases():
        hap = phase.data.get("Histograms", {}).get(histogram.name)
        if not hap or not hap.get("Use", True) or hap["Scale"][0] == 0:
            inactive.append(phase.name)
    for name in inactive:
        project.data["Phases"].pop(name, None)
        project.data.get("Restraints", {}).pop(name, None)
        histogram.data.get("Reflection Lists", {}).pop(name, None)
        for item in project.names:
            if item and item[0] == "Phases" and name in item:
                item.remove(name)
    project.update_ids()
    # Texture tests were diagnostic only; keep the accepted random-powder model.
    for phase in project.phases():
        phase.clear_HAP_refinements({"Pref.Ori.": True})
        for hap in phase.data.get("Histograms", {}).values():
            hap["Pref.Ori."][1] = 1.0
    project.save(str(output))
    print("removed inactive phases:", ", ".join(inactive) if inactive else "none")
    print("remaining phases:", ", ".join(phase.name for phase in project.phases()))


if __name__ == "__main__":
    main()
