#!/usr/bin/env python3
"""Export the final GSAS-II project into the requested submission files."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"


def finite_float(value) -> float:
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"nonfinite value: {value!r}")
    return number


def main() -> None:
    project = G2sc.G2Project(gpxfile=str(PROJECT))
    histogram = project.histograms()[0]
    phase_map = {phase.name: phase for phase in project.phases()}
    expected = {"CoWO4", "WO3_triclinic"}
    if set(phase_map) != expected:
        raise ValueError(f"expected phases {sorted(expected)}, found {sorted(phase_map)}")

    exports = {
        "CoWO4": ROOT / "phase_cowo4.cif",
        "WO3_triclinic": ROOT / "phase_wo3.cif",
    }
    for name, path in exports.items():
        phase_map[name].export_CIF(str(path))

    arrays = histogram.data["data"][1]
    two_theta = np.asarray(arrays[0], dtype=float)
    observed = np.asarray(arrays[1], dtype=float)
    weights = np.asarray(arrays[2], dtype=float)
    calculated = np.asarray(arrays[3], dtype=float)
    background = np.asarray(arrays[4], dtype=float)
    difference = observed - calculated
    matrix = np.column_stack(
        [two_theta, observed, calculated, difference, background]
    )
    np.savetxt(
        ROOT / "fit.csv",
        matrix,
        delimiter=",",
        header="two_theta_deg,observed_counts,calculated_counts,difference_counts,background_counts",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
    )

    valid = (
        np.isfinite(observed)
        & np.isfinite(calculated)
        & np.isfinite(weights)
        & (weights > 0)
    )
    weighted_ss = float(np.sum(weights[valid] * difference[valid] ** 2))
    weighted_obs_ss = float(np.sum(weights[valid] * observed[valid] ** 2))
    rwp = 100.0 * math.sqrt(weighted_ss / weighted_obs_ss)
    rp = 100.0 * float(np.sum(np.abs(difference[valid]))) / float(
        np.sum(np.abs(observed[valid]))
    )
    covariance_stats = project.data["Covariance"]["data"]["Rvals"]
    gof = finite_float(covariance_stats["GOF"])
    fractions = histogram.ComputeMassFracs()

    records = []
    metadata = {
        "CoWO4": {
            "name": "cobalt tungstate (wolframite)",
            "formula": "CoWO4",
            "model_origin": (
                "Wolframite MgWO4 topology from COD 9013902 with the "
                "charge-balanced Mg2+ to Co2+ substitution"
            ),
        },
        "WO3_triclinic": {
            "name": "tungsten(VI) oxide (triclinic)",
            "formula": "WO3",
            "model_origin": "Triclinic WO3 atomistic model from COD 2106293",
        },
    }
    for internal_name in ("CoWO4", "WO3_triclinic"):
        phase = phase_map[internal_name]
        fraction, fraction_esd = fractions[internal_name]
        cell = phase.get_cell()
        records.append(
            {
                "name": metadata[internal_name]["name"],
                "formula": metadata[internal_name]["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": exports[internal_name].name,
                "weight_fraction": finite_float(fraction),
                "weight_fraction_esd_conditional": finite_float(fraction_esd),
                "unit_cell": {key: finite_float(value) for key, value in cell.items()},
                "model_origin": metadata[internal_name]["model_origin"],
            }
        )

    result = {
        "phases": records,
        "fraction_basis": (
            "Normalized over the two modeled crystalline phases; amorphous or "
            "unidentified content is not quantified."
        ),
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "GOF": gof,
            "Rexp_percent": rwp / gof,
            "weighted_sum_squares": weighted_ss,
            "N_observations": int(covariance_stats["Nobs"]),
            "N_refined_variables": int(covariance_stats["Nvars"]),
            "converged": bool(covariance_stats["converged"]),
            "maximum_shift_over_esd": finite_float(
                covariance_stats["Max shft/sig"]
            ),
            "svd_dropped_variables": int(covariance_stats.get("SVD0", 0)),
        },
        "measurement_model": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "weighting": (
                "Poisson counting-statistical weights (1/observed counts); "
                "pointwise uncertainties were not supplied"
            ),
        },
        "unresolved_components": [],
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
