#!/usr/bin/env python3
"""Retest one CIF candidate against a mature GSAS-II baseline."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from refinement_branch import project_summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("phase_name")
    parser.add_argument("--scale-start", type=float, default=0.1)
    parser.add_argument("--repeat", type=int, default=3)
    args = parser.parse_args()

    source = args.source.resolve()
    output = args.output.resolve()
    pre = output.with_name(output.stem + "_pre.gpx")
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, pre)
    shutil.copy2(source, output)
    project = G2sc.G2Project(gpxfile=str(output))
    histogram = project.histograms()[0]
    phase = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.phase_name,
        histograms=[histogram],
        fmthint="CIF",
    )
    phase.clear_refinements({"Cell": True, "Atoms": []})
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"] = [float(args.scale_start), True]
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.save(str(output))

    previous = None
    for _ in range(max(1, args.repeat)):
        project.refine()
        values = project.data["Covariance"]["data"]["Rvals"]
        current = float(values.get("Rwp", math.inf))
        if (
            values.get("converged")
            and not values.get("SVD0")
            and abs(float(values.get("Max shft/sig", math.inf))) < 0.05
            and previous is not None
            and abs(previous - current) < 1.0e-5
        ):
            break
        previous = current
    project.save(str(output))

    summary = project_summary(project)
    covariance = project.data.get("Covariance", {}).get("data", {})
    variable = f"{phase.data['pId']}:{hap['hId']}:Scale"
    scale_esd = None
    if variable in covariance.get("varyList", []):
        index = covariance["varyList"].index(variable)
        scale_esd = float(np.sqrt(covariance["covMatrix"][index, index]))
    summary["candidate_test"] = {
        "phase": phase.name,
        "scale": float(hap["Scale"][0]),
        "scale_esd": scale_esd,
        "scale_over_esd": (
            float(hap["Scale"][0]) / scale_esd if scale_esd and scale_esd > 0 else None
        ),
        "cell_refined": bool(phase.data["General"]["Cell"][0]),
    }
    output.with_suffix(".summary.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print("PHASE_BRANCH_RESULT " + json.dumps(summary, separators=(",", ":")))


if __name__ == "__main__":
    main()
