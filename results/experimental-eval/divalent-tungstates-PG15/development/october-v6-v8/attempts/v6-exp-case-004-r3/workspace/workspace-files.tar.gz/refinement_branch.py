#!/usr/bin/env python3
"""Create and run a replayable GSAS-II refinement branch.

This intentionally supports only the small set of nuisance/profile terms used
for the present powder-pattern model comparison.  Every output project gets a
verbatim ``*_pre.gpx`` checkpoint made before its branch settings are applied,
and a compact JSON summary is written next to the refined project.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def csv_names(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


def assignments(values: list[str]) -> dict[str, float]:
    result: dict[str, float] = {}
    for item in values:
        name, value = item.split("=", 1)
        result[name.strip()] = float(value)
    return result


def phase_selection(project: G2sc.G2Project, spec: str):
    requested = csv_names(spec)
    active = [
        phase
        for phase in project.phases()
        if any(
            hap.get("Use", True) and hap["Scale"][0] != 0
            for hap in phase.data.get("Histograms", {}).values()
        )
    ]
    if not requested:
        return []
    if requested == ["all"]:
        return active
    missing = set(requested) - {phase.name for phase in active}
    if missing:
        raise ValueError(f"requested inactive or missing phase(s): {sorted(missing)}")
    return [phase for phase in active if phase.name in requested]


def finite_or_none(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def rwp(observed, calculated, weights):
    valid = (
        np.isfinite(observed)
        & np.isfinite(calculated)
        & np.isfinite(weights)
        & (weights > 0)
    )
    denominator = np.sum(weights[valid] * observed[valid] ** 2)
    if denominator <= 0:
        return math.nan
    return 100.0 * math.sqrt(
        np.sum(weights[valid] * (observed[valid] - calculated[valid]) ** 2)
        / denominator
    )


def project_summary(project: G2sc.G2Project) -> dict:
    histogram = project.histograms()[0]
    arrays = histogram.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    observed = np.asarray(arrays[1], dtype=float)
    weights = np.asarray(arrays[2], dtype=float)
    calculated = np.asarray(arrays[3], dtype=float)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "project": str(Path(project.filename).resolve()),
        "rwp_percent_saved_profile": finite_or_none(rwp(observed, calculated, weights)),
        "Rvals": {
            key: rvals.get(key)
            for key in (
                "Rwp",
                "GOF",
                "Nobs",
                "Nvars",
                "converged",
                "DelChi2",
                "Max shft/sig",
                "SVD0",
            )
        },
        "rwp_by_10deg_bin": {},
        "instrument": {},
        "sample": {},
        "phases": {},
    }
    low = 10.0 * math.floor(float(x.min()) / 10.0)
    high = 10.0 * math.ceil(float(x.max()) / 10.0)
    for edge in np.arange(low, high, 10.0):
        mask = (x >= edge) & (x < edge + 10.0)
        if np.any(mask):
            result["rwp_by_10deg_bin"][f"{edge:g}-{edge + 10:g}"] = finite_or_none(
                rwp(observed[mask], calculated[mask], weights[mask])
            )
    instrument = histogram.data["Instrument Parameters"][0]
    for name in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"):
        if name in instrument:
            result["instrument"][name] = {
                "value": finite_or_none(instrument[name][1]),
                "refine": bool(instrument[name][2]),
            }
    for name in ("Shift", "SurfRoughA", "SurfRoughB", "Transparency"):
        if name in histogram.data["Sample Parameters"]:
            item = histogram.data["Sample Parameters"][name]
            result["sample"][name] = {
                "value": finite_or_none(item[0]),
                "refine": bool(item[1]),
            }
    try:
        mass_fractions = histogram.ComputeMassFracs()
    except Exception:
        mass_fractions = {}
    for phase in project.phases():
        haps = phase.data.get("Histograms", {})
        hap = haps.get(histogram.name)
        if not hap:
            continue
        result["phases"][phase.name] = {
            "active": bool(hap.get("Use", True) and hap["Scale"][0] != 0),
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cell": [finite_or_none(v) if i else bool(v) for i, v in enumerate(phase.data["General"]["Cell"])],
            "scale": finite_or_none(hap["Scale"][0]),
            "weight_fraction": finite_or_none(mass_fractions.get(phase.name)),
            "size": hap.get("Size"),
            "microstrain": hap.get("Mustrain"),
            "preferred_orientation": hap.get("Pref.Ori."),
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--instrument", default="")
    parser.add_argument("--sample", default="")
    parser.add_argument("--initial", action="append", default=[])
    parser.add_argument("--size", default="", help="comma-separated phase names or all")
    parser.add_argument("--size-start", type=float, default=0.1)
    parser.add_argument("--strain", default="", help="comma-separated phase names or all")
    parser.add_argument("--strain-start", type=float, default=1000.0)
    parser.add_argument("--clear-size", default="")
    parser.add_argument("--clear-strain", default="")
    parser.add_argument(
        "--fixed-size",
        action="append",
        default=[],
        help="set and fix an isotropic phase size as PHASE=value",
    )
    parser.add_argument("--clear-instrument", default="")
    parser.add_argument("--clear-sample", default="")
    parser.add_argument("--po-phase", default="")
    parser.add_argument("--po-axis", default="0,0,1")
    parser.add_argument("--po-start", type=float, default=1.0)
    parser.add_argument("--repeat", type=int, default=5)
    args = parser.parse_args()

    source = args.source.resolve()
    output = args.output.resolve()
    if source == output:
        raise ValueError("source and output must differ")
    output.parent.mkdir(parents=True, exist_ok=True)
    pre = output.with_name(output.stem + "_pre.gpx")
    shutil.copy2(source, pre)
    shutil.copy2(source, output)

    project = G2sc.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    histogram = project.histograms()[0]
    instrument = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]

    for name in csv_names(args.clear_instrument):
        instrument[name][2] = False
    for name in csv_names(args.clear_sample):
        sample[name][1] = False
    for name, value in assignments(args.initial).items():
        if name in instrument:
            instrument[name][1] = value
        elif name in sample:
            sample[name][0] = value
        else:
            raise KeyError(f"unknown initial parameter {name!r}")
    for name in csv_names(args.instrument):
        instrument[name][2] = True
    for name in csv_names(args.sample):
        sample[name][1] = True

    for phase in phase_selection(project, args.clear_size):
        phase.clear_HAP_refinements({"Size": True})
    for phase in phase_selection(project, args.clear_strain):
        phase.clear_HAP_refinements({"Mustrain": True})
    for name, value in assignments(args.fixed_size).items():
        selected = phase_selection(project, name)
        if len(selected) != 1:
            raise ValueError(f"fixed size phase {name!r} was not uniquely selected")
        selected[0].setSampleProfile(histogram.name, "size", "isotropic", value)
        selected[0].clear_HAP_refinements({"Size": True})
    for phase in phase_selection(project, args.size):
        phase.setSampleProfile(histogram.name, "size", "isotropic", args.size_start)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}
        )
    for phase in phase_selection(project, args.strain):
        phase.setSampleProfile(
            histogram.name, "microstrain", "isotropic", args.strain_start
        )
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    if args.po_phase:
        axes = [int(value) for value in csv_names(args.po_axis)]
        if len(axes) != 3 or not any(axes):
            raise ValueError("--po-axis must contain three integers, not all zero")
        selected = phase_selection(project, args.po_phase)
        if len(selected) != 1:
            raise ValueError("--po-phase must select exactly one active phase")
        hap = selected[0].data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = float(args.po_start)
        hap["Pref.Ori."][3] = axes
        selected[0].set_HAP_refinements({"Pref.Ori.": True})

    project.save(str(output))
    previous_rwp = None
    for _ in range(max(1, args.repeat)):
        project.refine()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        current_rwp = float(rvals.get("Rwp", math.inf))
        max_shift = abs(float(rvals.get("Max shft/sig", math.inf)))
        converged = bool(rvals.get("converged", False)) and not rvals.get("SVD0")
        if (
            converged
            and max_shift < 0.05
            and previous_rwp is not None
            and abs(previous_rwp - current_rwp) < 1.0e-5
        ):
            break
        previous_rwp = current_rwp
    project.save(str(output))
    summary = project_summary(project)
    sidecar = output.with_suffix(".summary.json")
    sidecar.write_text(json.dumps(summary, indent=2) + "\n")
    print("BRANCH_RESULT " + json.dumps(summary, separators=(",", ":")))


if __name__ == "__main__":
    main()
