#!/usr/bin/env python3
"""Prepare GSAS-II-safe starting models from selected frozen COD records."""

from pathlib import Path
import sys
import warnings

from pymatgen.core import Structure


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
RUNTIME = Path("learned/divalent-tungstates/runtime").resolve()
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    out = Path("work/models")
    out.mkdir(parents=True, exist_ok=True)
    selected = {
        "wo3_2311041": "2311041",
        "co3o4_9005896": "9005896",
        "co3o4_5910031": "5910031",
        "wo3_1528915": "1528915",
        "wo3_2106293": "2106293",
        "wo3_1010618": "1010618",
        "wo3_2107312": "2107312",
        "coo_1541662": "1541662",
    }
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for name, cod_id in selected.items():
            structure = Structure.from_file(cod_path(cod_id), primitive=False)
            structure.remove_oxidation_states()
            write_synthetic_model(structure, out / f"{name}.cif")

    # The available exact CoWO4 COD record is incomplete. Build a diagnostic
    # wolframite model from the complete isostructural CoMoO4 parent and make
    # only the chemically justified Mo -> W site substitution.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        analogue = Structure.from_file(cod_path("7205001"), primitive=False)
        analogue.remove_oxidation_states()
        analogue.replace_species({"Mo": "W"})
        write_synthetic_model(analogue, out / "cowo4_from_comoo4_7205001.cif")


if __name__ == "__main__":
    main()
