#!/usr/bin/env python3
"""Refine symmetry-allowed coordinates on the accepted common profile."""

from __future__ import annotations

import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


WORK = Path("work").resolve()
OUT = WORK / "coordinate_trials"


def capture(project: G2.G2Project, label: str) -> dict:
    project.save()
    OUT.mkdir(parents=True, exist_ok=True)
    shutil.copy2(project.filename, OUT / f"{label}.gpx")
    hist = project.histogram(0)
    masses = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()]
    )
    result = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "weight_fractions": (masses / masses.sum()).tolist(),
        "coordinates": {
            phase.name: {
                atom.label: list(atom.coordinates) for atom in phase.atoms()
            }
            for phase in project.phases()
        },
        "flags": {
            phase.name: {atom.label: atom.refinement_flags for atom in phase.atoms()}
            for phase in project.phases()
        },
        "max_shift_over_esd": project.data["Covariance"]["data"].get("max shft/sig"),
    }
    print(json.dumps({k: result[k] for k in ["label", "rwp_percent", "weight_fractions", "flags", "max_shift_over_esd"]}, indent=2))
    return result


def refine(project: G2.G2Project, label: str, log: list[dict]) -> None:
    project.save()
    project.refine()
    log.append(capture(project, label))


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "intensity_baseline" / "02_polarization_replay.gpx"),
        newgpx=str(WORK / "coordinate_trials_working.gpx"),
    )
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 18)
    phases = project.phases()
    log: list[dict] = []
    capture(project, "00_intensity_profile")

    wo3_w = {a.label: "X" for a in phases[0].atoms() if a.element == "W"}
    phases[0].set_refinements({"Atoms": wo3_w})
    refine(project, "01_WO3_tungsten", log)

    wo3_o = {a.label: "X" for a in phases[0].atoms() if a.element == "O"}
    phases[0].set_refinements({"Atoms": wo3_o})
    refine(project, "02_WO3_all_coordinates", log)
    refine(project, "03_WO3_replay", log)

    co3o4_o = {a.label: "X" for a in phases[1].atoms() if a.element == "O"}
    phases[1].set_refinements({"Atoms": co3o4_o})
    refine(project, "04_add_Co3O4_oxygen", log)
    refine(project, "05_coordinate_replay", log)
    (OUT / "trials.json").write_text(json.dumps(log, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
