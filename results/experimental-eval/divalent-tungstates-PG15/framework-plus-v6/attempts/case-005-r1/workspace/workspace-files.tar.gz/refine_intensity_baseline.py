#!/usr/bin/env python3
"""Resolve common polarization and low-angle roughness before texture tests."""

from __future__ import annotations

import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


WORK = Path("work").resolve()
OUT = WORK / "intensity_baseline"


def capture(project: G2.G2Project, label: str) -> dict:
    project.save()
    OUT.mkdir(parents=True, exist_ok=True)
    shutil.copy2(project.filename, OUT / f"{label}.gpx")
    hist = project.histogram(0)
    result = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "shift_um": hist.SampleParameters["Shift"][0],
        "roughness_A": hist.SampleParameters["SurfRoughA"][0],
        "roughness_B": hist.SampleParameters["SurfRoughB"][0],
        "fractions": hist.ComputeMassFracs() if project.data["Covariance"]["data"].get("covMatrix") is not None else None,
        "frozen": repr(project.data["Controls"]["data"].get("parmFrozen", {})),
    }
    print(json.dumps(result, indent=2, default=float))
    return result


def refine(project: G2.G2Project, label: str, log: list[dict]) -> None:
    project.save()
    project.refine()
    log.append(capture(project, label))


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "strain_first_trials" / "04_strain_size_W.gpx"),
        newgpx=str(WORK / "intensity_baseline_working.gpx"),
    )
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 18)
    hist = project.histogram(0)
    log: list[dict] = []
    capture(project, "00_profile_baseline")

    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "01_polarization", log)
    refine(project, "02_polarization_replay", log)

    hist.SampleParameters["SurfRoughA"] = [0.20, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.9, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughB")
    refine(project, "03_roughness", log)
    refine(project, "04_roughness_replay", log)
    (OUT / "trials.json").write_text(json.dumps(log, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
