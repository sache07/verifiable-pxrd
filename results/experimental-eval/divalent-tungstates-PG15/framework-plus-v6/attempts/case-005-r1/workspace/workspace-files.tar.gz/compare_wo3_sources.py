#!/usr/bin/env python3
"""Compare physically viable WO3 records under one restrained nuisance model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


WORK = Path("work").resolve()
OUT = WORK / "source_trials"


def build(label: str, wo3_file: str) -> dict:
    project = G2.G2Project(newgpx=str(OUT / f"{label}.gpx"))
    hist = project.add_powder_histogram(
        str(WORK / "pattern.xye"), str(WORK / "instrument.instprm"), fmthint="xye"
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [-600.0, True]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [3000.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            }
        }
    )
    phases = [
        project.add_phase(
            str(WORK / "models" / wo3_file),
            phasename=f"WO3_{label}",
            histograms=[hist],
            fmthint="CIF",
        ),
        project.add_phase(
            str(WORK / "models" / "co3o4_9005896.cif"),
            phasename="Co3O4_spinel",
            histograms=[hist],
            fmthint="CIF",
        ),
    ]
    for phase_id, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [8.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        project.set_Controls("parmMin", 0.0, variable=f"{phase_id}:0:Scale")
        project.set_Controls("parmMin", 0.02, variable=f"{phase_id}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{phase_id}:0:Size;i")
    project.set_Controls("parmMin", -1200.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1200.0, variable=":0:Shift")
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.set_Controls("cycles", 12)

    project.save()
    project.refine()
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine()
    for phase in phases:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.10, "refine": True}}
        )
    project.refine()
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.refine()
    project.refine()
    project.save()

    masses = np.array(
        [
            p.data["General"]["Mass"]
            * p.data["Histograms"][hist.name]["Scale"][0]
            for p in phases
        ]
    )
    fractions = masses / masses.sum()
    return {
        "label": label,
        "source": wo3_file,
        "rwp_percent": hist.get_wR(),
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "shift_um": hist.SampleParameters["Shift"][0],
        "phases": [
            {
                "name": p.name,
                "weight_fraction": float(f),
                "cell": p.get_cell(),
                "size_um": p.data["Histograms"][hist.name]["Size"][1][0],
            }
            for p, f in zip(phases, fractions)
        ],
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    candidates = {
        "cod2311041_P21c": "wo3_2311041.cif",
        "cod1528915_P21c": "wo3_1528915.cif",
        "cod2106293_P1": "wo3_2106293.cif",
        "cod2107312_Pnma": "wo3_2107312.cif",
    }
    results = []
    for label, path in candidates.items():
        print(f"\nSOURCE TRIAL {label}")
        try:
            result = build(label, path)
        except Exception as exc:
            result = {"label": label, "source": path, "error": repr(exc)}
        results.append(result)
        print(json.dumps(result, indent=2))
    (OUT / "comparison.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
