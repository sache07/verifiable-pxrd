#!/usr/bin/env python3
"""Refine polarization, symmetry-allowed coordinates, and phase Uiso values."""

from __future__ import annotations

import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


WORK = Path("work").resolve()
OUT = WORK / "structure_trials"


def report(project: G2.G2Project, label: str) -> dict:
    project.save()
    OUT.mkdir(parents=True, exist_ok=True)
    shutil.copy2(project.filename, OUT / f"{label}.gpx")
    hist = project.histogram(0)
    weighted = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted.append(hap["Scale"][0] * phase.data["General"]["Mass"])
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": list(atom.coordinates),
                        "uiso": atom.uiso,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    fractions = np.asarray(weighted) / np.sum(weighted)
    for phase, fraction in zip(phases, fractions):
        phase["weight_fraction"] = float(fraction)
    result = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "shift_um": hist.SampleParameters["Shift"][0],
        "phases": phases,
        "vary_list": project.get_VaryList() or [],
    }
    print(
        json.dumps(
            {
                "label": result["label"],
                "rwp_percent": result["rwp_percent"],
                "polarization": result["polarization"],
                "shift_um": result["shift_um"],
                "phases": [
                    {
                        "name": p["name"],
                        "weight_fraction": p["weight_fraction"],
                        "uiso": [a["uiso"] for a in p["atoms"]],
                        "flags": [a["flags"] for a in p["atoms"]],
                    }
                    for p in phases
                ],
                "n_vary": len(result["vary_list"]),
            },
            indent=2,
        )
    )
    return result


def refine(project: G2.G2Project, label: str, log: list[dict]) -> None:
    project.save()
    project.refine()
    log.append(report(project, label))


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "profile_trials" / "03_size_both_replay.gpx"),
        newgpx=str(WORK / "structure_trials_working.gpx"),
    )
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 18)
    hist = project.histogram(0)
    phases = project.phases()
    log: list[dict] = []
    report(project, "00_start_profile")

    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "01_polarization", log)

    phases[0].set_refinements({"Atoms": {"all": "X"}})
    refine(project, "02_WO3_coordinates", log)
    refine(project, "03_WO3_coordinates_replay", log)

    phases[1].set_refinements({"Atoms": {"all": "X"}})
    refine(project, "04_both_coordinates", log)
    refine(project, "05_both_coordinates_replay", log)

    # The generator assigns one isotropic U value to every site in a phase.
    # Preserve that physical model with equality constraints rather than
    # allowing atom-by-atom ADPs to become intensity surrogates.
    for phase_id, phase in enumerate(phases):
        variables = []
        for atom_id, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "XU"
            variables.append(f"{phase_id}::AUiso:{atom_id}")
            project.set_Controls(
                "parmMin", 0.001, variable=f"{phase_id}::AUiso:{atom_id}"
            )
            project.set_Controls(
                "parmMax", 0.03, variable=f"{phase_id}::AUiso:{atom_id}"
            )
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=True)
    refine(project, "06_phase_uiso", log)
    refine(project, "07_structure_replay", log)

    (OUT / "trials.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
