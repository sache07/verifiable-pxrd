#!/usr/bin/env python3
"""Challenge symmetry-allowed uniaxial microstrain axes phase by phase."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


WORK = Path("work").resolve()
BASE = WORK / "intensity_baseline" / "02_polarization_replay.gpx"
OUT = WORK / "anisotropic_strain_trials"


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histogram(0)
    mass = np.array([p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()])
    return (mass / mass.sum()).tolist()


def trial(phase_id: int, axis: list[int]) -> dict:
    token = "".join(map(str, axis))
    label = f"phase{phase_id}_{token}"
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / f"{label}.gpx"))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 18)
    hist = project.histogram(0)
    phase = project.phase(phase_id)
    hap = phase.data["Histograms"][hist.name]
    base = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = base
    hap["Mustrain"][1][1] = base * 1.25
    hap["Mustrain"][3] = list(axis)
    phase.set_HAP_refinements(
        {"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}}
    )
    for suffix in ["Mustrain;i", "Mustrain;a"]:
        project.set_Controls("parmMin", 0.0, variable=f"{phase_id}:0:{suffix}")
        project.set_Controls("parmMax", 10000.0, variable=f"{phase_id}:0:{suffix}")
    project.save()
    project.refine()
    project.refine()
    project.save()
    return {
        "label": label,
        "phase": phase.name,
        "axis": axis,
        "rwp_percent": hist.get_wR(),
        "strain_values": list(hap["Mustrain"][1]),
        "fractions": fractions(project),
        "frozen": repr(project.data["Controls"]["data"].get("parmFrozen", {})),
    }


def combine(best: dict[int, list[int]]) -> dict:
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / "combined_best.gpx"))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    for phase_id, axis in best.items():
        phase = project.phase(phase_id)
        hap = phase.data["Histograms"][hist.name]
        base = float(hap["Mustrain"][1][0])
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][1] = base * 1.25
        hap["Mustrain"][3] = list(axis)
        phase.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}})
        for suffix in ["Mustrain;i", "Mustrain;a"]:
            project.set_Controls("parmMin", 0.0, variable=f"{phase_id}:0:{suffix}")
            project.set_Controls("parmMax", 10000.0, variable=f"{phase_id}:0:{suffix}")
    project.save(); project.refine(); project.refine(); project.save()
    return {
        "label": "combined_best",
        "rwp_percent": hist.get_wR(),
        "fractions": fractions(project),
        "phases": [
            {
                "name": p.name,
                "strain_type": p.data["Histograms"][hist.name]["Mustrain"][0],
                "strain_values": p.data["Histograms"][hist.name]["Mustrain"][1],
                "axis": p.data["Histograms"][hist.name]["Mustrain"][3],
            }
            for p in project.phases()
        ],
        "frozen": repr(project.data["Controls"]["data"].get("parmFrozen", {})),
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0]]
    results = []
    for phase_id in range(2):
        for axis in axes:
            result = trial(phase_id, axis)
            results.append(result)
            print(json.dumps(result, indent=2))
    best = {i: min((r for r in results if r["label"].startswith(f"phase{i}_")), key=lambda r: r["rwp_percent"])["axis"] for i in range(2)}
    combo = combine(best)
    print(json.dumps(combo, indent=2))
    (OUT / "trials.json").write_text(json.dumps({"individual": results, "combined": combo}, indent=2) + "\n")


if __name__ == "__main__":
    main()
