#!/usr/bin/env python3
"""Create the submission files from the independently replayed final project."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
REPLAY_DIR = ROOT / "work" / "replay_check"


def main() -> None:
    replay = json.loads((REPLAY_DIR / "replay.json").read_text())
    if replay["status"] != "replayed":
        raise RuntimeError("Independent GSAS-II replay failed")
    if replay["profile_review_flags"]:
        raise RuntimeError(f"Replay profile review flags: {replay['profile_review_flags']}")
    if not replay["project_unchanged"] or replay["parameters_optimized"] != 0:
        raise RuntimeError("Replay was not a read-only forward calculation")

    with np.load(REPLAY_DIR / "prediction.npz", allow_pickle=False) as data:
        x = data["x"].copy()
        observed = data["observed"].copy()
        calculated = data["predicted"].copy()
        background = data["background"].copy()
    difference = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(ROOT / "final.gpx"))
    histogram = project.histogram(replay["histogram"])
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    nobs = int(rvals["Nobs"])
    nvars = int(rvals["Nvars"])
    degrees_of_freedom = nobs - nvars
    reduced_chi_square = chi_square / degrees_of_freedom
    gof = float(np.sqrt(reduced_chi_square))
    rexp = float(100.0 * np.sqrt(degrees_of_freedom / denominator))
    fractions = histogram.ComputeMassFracs()
    phase_map = {phase.name: phase for phase in project.phases()}

    phase_metadata = {
        "WO3_monoclinic": {
            "display_name": "tungsten(VI) oxide (monoclinic WO3)",
            "formula": "WO3",
            "space_group": "P 21/c",
            "cif_path": "phase_WO3.cif",
            "source": "COD 2311041",
            "reliability": "phase identity and major-phase fraction reliable; oxygen coordinates retained from the source model",
        },
        "Co3O4_spinel": {
            "display_name": "cobalt(II,III) oxide (spinel Co3O4)",
            "formula": "Co3O4",
            "space_group": "F d -3 m",
            "cif_path": "phase_Co3O4.cif",
            "source": "COD 9005896",
            "reliability": "phase identity and major-phase fraction reliable",
        },
    }

    phases = []
    for replay_phase in replay["phases"]:
        name = replay_phase["name"]
        meta = phase_metadata[name]
        fraction, fraction_esd = fractions[name]
        if abs(float(fraction) - replay_phase["weight_fraction"]) > 1e-10:
            raise RuntimeError("Project and replay fractions differ")
        phases.append(
            {
                "name": meta["display_name"],
                "project_phase": name,
                "formula": meta["formula"],
                "space_group": meta["space_group"],
                "cif_path": meta["cif_path"],
                "weight_fraction": float(replay_phase["weight_fraction"]),
                "weight_fraction_esd": float(fraction_esd),
                "structure_source": meta["source"],
                "reliability": meta["reliability"],
                "refined_cell": phase_map[name].get_cell(),
            }
        )

    project_hash = hashlib.sha256((ROOT / "final.gpx").read_bytes()).hexdigest()
    if project_hash != replay["project_sha256"]:
        raise RuntimeError("final.gpx changed after replay")
    result = {
        "refinement_histogram": replay["histogram"],
        "fraction_basis": "normalized over all modeled crystalline phases",
        "phases": phases,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "rexp_percent": rexp,
            "chi_square": chi_square,
            "reduced_chi_square": reduced_chi_square,
            "goodness_of_fit": gof,
            "n_observations": int(len(x)),
            "n_refined_parameters": nvars,
            "weighting": "1/max(observed_counts, 1)",
            "profile_scope": "entire original observed grid",
        },
        "project_replay": {
            "status": replay["status"],
            "parameters_optimized": replay["parameters_optimized"],
            "project_unchanged": replay["project_unchanged"],
            "profile_review_flags": replay["profile_review_flags"],
            "project_sha256": project_hash,
            "regeneration": replay["regeneration"],
        },
    }

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference, background]),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        # Preserve the exact public floating-point grid on re-import.
        fmt=["%.17g", "%.17g", "%.10f", "%.10f", "%.10f"],
    )
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

    wo3, co3o4 = phases
    shift = float(histogram.data["Sample Parameters"]["Shift"][0])
    report = f"""# Powder X-ray diffraction analysis

## Result

The crystalline pattern is explained by two residual precursor phases: monoclinic WO3 ({100*wo3['weight_fraction']:.2f} wt%) and spinel Co3O4 ({100*co3o4['weight_fraction']:.2f} wt%), normalized over the modeled crystalline material. Their covariance-only 1-sigma fraction uncertainty is {100*wo3['weight_fraction_esd']:.2f} percentage point. A more realistic uncertainty is about 1–2 wt% because source-model, background, profile, absorption and microstructural systematics are not represented by that covariance estimate.

| Phase | Space group | Refined cell (angstrom, degrees) | Weight fraction |
|---|---|---|---:|
| WO3 | P 21/c | a={wo3['refined_cell']['length_a']:.5f}, b={wo3['refined_cell']['length_b']:.5f}, c={wo3['refined_cell']['length_c']:.5f}, beta={wo3['refined_cell']['angle_beta']:.5f} | {wo3['weight_fraction']:.6f} |
| Co3O4 | F d -3 m | a={co3o4['refined_cell']['length_a']:.5f} | {co3o4['weight_fraction']:.6f} |

The independently regenerated full-range fit gives Rwp={rwp:.3f}%, Rp={rp:.3f}% and goodness of fit={gof:.3f} for {len(x)} points and {nvars} refined parameters. The replay recalculated atomic structure factors and reflection lists from `final.gpx`, used no optimization, left the project unchanged, and raised no physical profile-review flags.

## Evidence and model selection

WO3 is required by the resolved 23.46/23.95/24.71 degree triplet and its repeated higher-angle families. Co3O4 is independently required by coherent peaks near 19.37, 31.63, 37.20, 38.90, 45.15, 59.67 and 65.55 degrees. The selected starting structures were COD 2311041 (WO3, P 21/c) and COD 9005896 (Co3O4, F d -3 m); both final CIFs pass the geometry/occupancy screen. Alternate P 21/c and Pnma WO3 records fit worse. A triclinic WO3 record gave a slightly lower early-stage residual but required large source-cell angle distortions toward a monoclinic metric, so it was rejected as a lower-symmetry overfit. A malformed WO3 record and a physically defective alternate Co3O4 record were also rejected.

A diagnostic wolframite CoWO4 model (W substituted into a complete CoMoO4 prototype because the exact local CoWO4 record was incomplete) and rocksalt CoO were each challenged under the same common profile. Both scales collapsed to the nonnegative floor (modeled fractions below 2e-14), and neither has coherent unique residual families. They are therefore not reported as phases; trace quantities below this pattern's practical detection capability cannot be excluded.

## Refinement scope and uncertainty

The physically retained nuisance model uses a six-term smooth background, phase scales and cells, one specimen-displacement correction ({shift:.1f} micrometres in the GSAS-II convention), a common nonnegative peak profile, isotropic phase size, uniaxial [010] WO3 microstrain, isotropic Co3O4 microstrain, and polarization. Surface roughness, preferred orientation, extra asymmetry and unsupported anisotropy were tested and pruned. The final accepted parameter set remained converged through two save/reopen replays (maximum shift/sigma below 0.006).

WO3 tungsten coordinates, its common isotropic displacement parameter, and the spinel oxygen coordinate were replay-stable and retained. Refining all WO3 oxygen coordinates produced alternating solutions (maximum shifts up to about 4.8 sigma), so those oxygen positions cannot be determined reliably from this powder pattern and remain at the source-model values. This limitation has little effect on the phase identities but is relevant if the CIF is used for detailed WO6 bond geometry. Amorphous content, if present, is not quantified because no internal standard was measured.
"""
    (ROOT / "report.md").write_text(report)
    print(json.dumps(result["fit_statistics"], indent=2))


if __name__ == "__main__":
    main()
