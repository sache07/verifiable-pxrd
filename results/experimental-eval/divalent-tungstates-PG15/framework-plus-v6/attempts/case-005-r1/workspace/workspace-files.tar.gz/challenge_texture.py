#!/usr/bin/env python3
"""Compare no texture with symmetry-distinct March-Dollase axes."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


WORK = Path("work").resolve()
BASE = WORK / "intensity_baseline" / "02_polarization_replay.gpx"
OUT = WORK / "texture_trials"


def mass_fractions(project: G2.G2Project) -> list[float]:
    hist = project.histogram(0)
    values = np.array(
        [
            p.data["General"]["Mass"]
            * p.data["Histograms"][hist.name]["Scale"][0]
            for p in project.phases()
        ]
    )
    return (values / values.sum()).tolist()


def trial(phase_id: int, axis: list[int]) -> dict:
    token = "".join(str(v).replace("-", "m") for v in axis)
    label = f"phase{phase_id}_{token}"
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / f"{label}.gpx"))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 15)
    hist = project.histogram(0)
    phase = project.phase(phase_id)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 0.90
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    project.set_Controls("parmMin", 0.7, variable=f"{phase_id}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{phase_id}:0:MD")
    project.save()
    project.refine()
    project.refine()
    project.save()
    return {
        "label": label,
        "phase": phase.name,
        "axis": axis,
        "rwp_percent": hist.get_wR(),
        "md_ratio": hap["Pref.Ori."][1],
        "weight_fractions": mass_fractions(project),
        "frozen": repr(project.data["Controls"]["data"].get("parmFrozen", {})),
    }


def combined(best: dict[int, list[int]]) -> dict:
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / "combined_best.gpx"))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 18)
    hist = project.histogram(0)
    for phase_id, axis in best.items():
        phase = project.phase(phase_id)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 0.90
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        project.set_Controls("parmMin", 0.7, variable=f"{phase_id}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{phase_id}:0:MD")
    project.save()
    project.refine()
    project.refine()
    project.save()
    return {
        "label": "combined_best",
        "rwp_percent": hist.get_wR(),
        "weight_fractions": mass_fractions(project),
        "phases": [
            {
                "name": p.name,
                "axis": p.data["Histograms"][hist.name]["Pref.Ori."][3],
                "md_ratio": p.data["Histograms"][hist.name]["Pref.Ori."][1],
            }
            for p in project.phases()
        ],
        "frozen": repr(project.data["Controls"]["data"].get("parmFrozen", {})),
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    axes = {
        0: [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]],
        1: [[1, 0, 0], [1, 1, 0], [1, 1, 1]],
    }
    results = []
    for phase_id, choices in axes.items():
        for axis in choices:
            result = trial(phase_id, axis)
            results.append(result)
            print(json.dumps(result, indent=2))
    best = {
        phase_id: min(
            (r for r in results if r["label"].startswith(f"phase{phase_id}_")),
            key=lambda r: r["rwp_percent"],
        )["axis"]
        for phase_id in axes
    }
    combo = combined(best)
    print(json.dumps(combo, indent=2))
    (OUT / "trials.json").write_text(json.dumps({"individual": results, "combined": combo}, indent=2) + "\n")


if __name__ == "__main__":
    main()
