#!/usr/bin/env python3
"""Compare phase broadening terms from the clean two-phase baseline."""

from __future__ import annotations

import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


WORK = Path("work").resolve()
OUT = WORK / "profile_trials"


def report(project: G2.G2Project, label: str) -> dict:
    project.save()
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"{label}.gpx"
    shutil.copy2(project.filename, target)
    hist = project.histogram(0)
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(hap["Scale"][0] * phase.data["General"]["Mass"])
        phases.append(
            {
                "name": phase.name,
                "scale": hap["Scale"][0],
                "size_type": hap["Size"][0],
                "size_values": list(hap["Size"][1]),
                "size_flags": list(hap["Size"][2]),
                "strain_type": hap["Mustrain"][0],
                "strain_values": list(hap["Mustrain"][1]),
                "strain_flags": list(hap["Mustrain"][2]),
            }
        )
    fractions = np.asarray(masses) / np.sum(masses)
    for phase, fraction in zip(phases, fractions):
        phase["weight_fraction"] = float(fraction)
    result = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ["U", "W", "X", "SH/L"]
        },
        "shift_um": hist.SampleParameters["Shift"][0],
        "phases": phases,
        "frozen": [str(x) for x in project.data["Controls"]["data"].get("parmFrozen", [])],
    }
    print(json.dumps(result, indent=2))
    return result


def refine(project: G2.G2Project, label: str, log: list[dict]) -> None:
    project.save()
    project.refine()
    log.append(report(project, label))


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "stages" / "02_cells.gpx"),
        newgpx=str(WORK / "profile_trials_working.gpx"),
    )
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 15)
    hist = project.histogram(0)
    phases = project.phases()

    for phase_id in range(len(phases)):
        project.set_Controls("parmMin", 0.02, variable=f"{phase_id}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{phase_id}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{phase_id}:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{phase_id}:0:Mustrain;i")
    for name, low, high in [("U", 0.0, 40.0), ("W", 2.0, 40.0)]:
        project.set_Controls("parmMin", low, variable=f":0:{name}")
        project.set_Controls("parmMax", high, variable=f":0:{name}")

    log: list[dict] = []
    report(project, "00_start_cells")

    phases[0].set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.10, "refine": True}}
    )
    refine(project, "01_size_WO3", log)

    phases[1].set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.10, "refine": True}}
    )
    refine(project, "02_size_both", log)
    refine(project, "03_size_both_replay", log)

    hist.set_refinements({"Instrument Parameters": ["W"]})
    refine(project, "04_size_plus_W", log)

    hist.set_refinements({"Instrument Parameters": ["U"]})
    refine(project, "05_size_plus_UW", log)

    # Challenge isotropic microstrain one phase at a time from a neutral value.
    hap0 = phases[0].data["Histograms"][hist.name]
    hap0["Mustrain"][0] = "isotropic"
    hap0["Mustrain"][1][0] = 300.0
    phases[0].set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, "06_add_strain_WO3", log)

    hap1 = phases[1].data["Histograms"][hist.name]
    hap1["Mustrain"][0] = "isotropic"
    hap1["Mustrain"][1][0] = 300.0
    phases[1].set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, "07_add_strain_both", log)
    refine(project, "08_full_replay", log)

    (OUT / "trials.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
