#!/usr/bin/env python3
"""Lock the accepted refinement, replay it, and export matching phase CIFs."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "work" / "uiso_phase0_3.gpx"
FINAL = ROOT / "final.gpx"
CIFS = [ROOT / "phase_WO3.cif", ROOT / "phase_Co3O4.cif"]


def state(project: G2.G2Project) -> dict:
    histogram = project.histogram(0)
    fractions = histogram.ComputeMassFracs()
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "rwp_percent": float(histogram.get_wR()),
        "max_shift_over_esd": float(rvals.get("Max shft/sig", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "fractions": {
            name: {"value": float(value), "esd": float(esd)}
            for name, (value, esd) in fractions.items()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }


def assert_neutral_rejected_terms(project: G2.G2Project) -> None:
    histogram = project.histogram(0)
    sample = histogram.data["Sample Parameters"]
    assert sample["SurfRoughA"] == [0.0, False]
    assert sample["SurfRoughB"] == [0.0, False]
    assert sample["Transparency"] == [0.0, False]
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        assert hap["Pref.Ori."][0:3] == ["MD", 1.0, False]
        assert hap["Extinction"] == [0.0, False]
        assert hap["Babinet"]["BabA"] == [0.0, False]
        assert hap["Babinet"]["BabU"] == [0.0, False]


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 20)
    assert_neutral_rejected_terms(project)

    project.save()
    states = [state(project)]
    # Two save/reopen refinement replays verify that the accepted parameter set
    # is stable and leave final.gpx at the last converged state.
    for _ in range(2):
        project.save()
        project.refine()
        project.save()
        states.append(state(project))
        project = G2.G2Project(gpxfile=str(FINAL))
        assert_neutral_rejected_terms(project)

    final_state = state(project)
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    if not rvals.get("converged", False):
        raise RuntimeError("Final refinement did not converge")
    if final_state["max_shift_over_esd"] > 0.1:
        raise RuntimeError("Final refinement is not replay-stable")
    if len(project.phases()) != len(CIFS):
        raise RuntimeError("Unexpected phase count")

    project.save()
    for phase, path in zip(project.phases(), CIFS):
        phase.export_CIF(str(path))

    payload = {"replay_states": states, "final": final_state}
    (ROOT / "work" / "finalization_state.json").write_text(
        json.dumps(payload, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(payload, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
