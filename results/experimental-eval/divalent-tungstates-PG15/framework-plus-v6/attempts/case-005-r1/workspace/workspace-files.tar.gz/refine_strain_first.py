#!/usr/bin/env python3
"""Test strain before releasing the common Gaussian profile."""

from __future__ import annotations

import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


WORK = Path("work").resolve()
OUT = WORK / "strain_first_trials"


def state(project: G2.G2Project, label: str) -> dict:
    project.save()
    OUT.mkdir(parents=True, exist_ok=True)
    shutil.copy2(project.filename, OUT / f"{label}.gpx")
    hist = project.histogram(0)
    result = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "instrument": {k: hist.InstrumentParameters[k][1] for k in ["U", "W", "X", "SH/L"]},
        "phases": [],
        "frozen": repr(project.data["Controls"]["data"].get("parmFrozen", {})),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "size": hap["Size"],
                "strain": hap["Mustrain"],
            }
        )
    print(json.dumps(result, indent=2))
    return result


def run(project: G2.G2Project, label: str, log: list[dict]) -> None:
    project.save()
    project.refine()
    log.append(state(project, label))


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "profile_trials" / "03_size_both_replay.gpx"),
        newgpx=str(WORK / "strain_first_working.gpx"),
    )
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 18)
    hist = project.histogram(0)
    phases = project.phases()
    for i in range(2):
        project.set_Controls("parmMin", 0.0, variable=f"{i}:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{i}:0:Mustrain;i")
    for name, low, high in [("U", 0.0, 40.0), ("W", 2.0, 40.0)]:
        project.set_Controls("parmMin", low, variable=f":0:{name}")
        project.set_Controls("parmMax", high, variable=f":0:{name}")

    log: list[dict] = []
    state(project, "00_start_sizes")
    for i, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        run(project, f"0{i+1}_strain_{phase.name}", log)
    run(project, "03_strain_both_replay", log)

    hist.set_refinements({"Instrument Parameters": ["W"]})
    run(project, "04_strain_size_W", log)
    hist.set_refinements({"Instrument Parameters": ["U"]})
    run(project, "05_strain_size_UW", log)
    run(project, "06_full_replay", log)
    (OUT / "trials.json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
