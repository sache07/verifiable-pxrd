#!/usr/bin/env python3
"""Challenge chemically plausible weak phases under the rebuilt common profile."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


WORK = Path("work").resolve()
OUT = WORK / "watchlist_trials"


def challenge(label: str, cif: str) -> dict:
    project = G2.G2Project(
        gpxfile=str(WORK / "structure_trials" / "04_both_coordinates.gpx"),
        newgpx=str(OUT / f"{label}.gpx"),
    )
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 15)
    hist = project.histogram(0)
    old_rwp = hist.get_wR()
    # Hold structural coordinates during the inventory challenge; retain and
    # reconverge the shared background, existing scales/cells, displacement,
    # polarization, and accepted isotropic size terms.
    for phase in project.phases():
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
    added = project.add_phase(
        str(WORK / "models" / cif),
        phasename=label,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = added.data["Histograms"][hist.name]
    hap["Scale"] = [0.05, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.10
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    project.set_Controls("parmMin", 0.0, variable="2:0:Scale")
    project.save()
    project.refine()
    project.refine()
    project.save()

    masses = np.array(
        [
            p.data["General"]["Mass"]
            * p.data["Histograms"][hist.name]["Scale"][0]
            for p in project.phases()
        ]
    )
    fractions = masses / masses.sum()
    try:
        scale_info = project.get_Variable("2:0:Scale")
    except Exception:
        scale_info = (hap["Scale"][0], None)
    return {
        "label": label,
        "cif": cif,
        "starting_rwp_percent": old_rwp,
        "final_rwp_percent": hist.get_wR(),
        "scale_value_esd": scale_info,
        "weight_fractions": {
            phase.name: float(fraction)
            for phase, fraction in zip(project.phases(), fractions)
        },
        "added_cell": added.get_cell(),
        "frozen": repr(project.data["Controls"]["data"].get("parmFrozen", {})),
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    candidates = {
        "CoWO4_wolframite_diagnostic": "cowo4_from_comoo4_7205001.cif",
        "CoO_rocksalt": "coo_1541662.cif",
    }
    results = []
    for label, cif in candidates.items():
        result = challenge(label, cif)
        results.append(result)
        print(json.dumps(result, indent=2))
    (OUT / "watchlist.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
