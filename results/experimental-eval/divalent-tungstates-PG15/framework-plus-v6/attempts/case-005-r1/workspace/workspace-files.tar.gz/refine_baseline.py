#!/usr/bin/env python3
"""Build and refine the common two-phase GSAS-II baseline."""

from __future__ import annotations

import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


WORK = Path("work").resolve()
STAGES = WORK / "stages"


def snapshot(project: G2.G2Project, label: str) -> dict:
    project.save()
    STAGES.mkdir(parents=True, exist_ok=True)
    shutil.copy2(project.filename, STAGES / f"{label}.gpx")
    hist = project.histogram(0)
    phases = project.phases()
    weighted = np.array(
        [
            phase.data["Histograms"][hist.name]["Scale"][0]
            * phase.data["General"]["Mass"]
            for phase in phases
        ],
        dtype=float,
    )
    fractions = weighted / weighted.sum()
    result = {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "background": hist.data["Background"][0],
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "sample": {
            key: hist.SampleParameters[key][0]
            for key in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
        },
        "phases": [],
        "vary_list": project.get_VaryList() or [],
    }
    for phase, fraction in zip(phases, fractions):
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "weight_fraction": float(fraction),
                "scale": hap["Scale"][0],
                "cell": phase.get_cell(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    print(json.dumps(result, indent=2, default=float))
    return result


def refine(project: G2.G2Project, label: str, log: list[dict]) -> None:
    project.save()
    project.refine()
    log.append(snapshot(project, label))


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(WORK / "baseline.gpx"))
    hist = project.add_powder_histogram(
        str(WORK / "pattern.xye"),
        str(WORK / "instrument.instprm"),
        fmthint="xye",
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [-600.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [3000.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": False,
            }
        }
    )
    phases = [
        project.add_phase(
            str(WORK / "models" / "wo3_2311041.cif"),
            phasename="WO3_monoclinic",
            histograms=[hist],
            fmthint="CIF",
        ),
        project.add_phase(
            str(WORK / "models" / "co3o4_9005896.cif"),
            phasename="Co3O4_spinel",
            histograms=[hist],
            fmthint="CIF",
        ),
    ]
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [8.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    project.set_Controls("cycles", 12)
    project.set_Controls("parmMin", -1200.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1200.0, variable=":0:Shift")
    for phase_id in range(len(phases)):
        project.set_Controls("parmMin", 0.0, variable=f"{phase_id}:0:Scale")
    for name, low, high in [
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
    ]:
        project.set_Controls("parmMin", low, variable=f":0:{name}")
        project.set_Controls("parmMax", high, variable=f":0:{name}")

    log: list[dict] = []
    project.set_Controls("cycles", 0)
    project.refine()
    log.append(snapshot(project, "00_initial"))
    project.set_Controls("cycles", 12)

    hist.set_refinements({"Background": {"refine": True}})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    refine(project, "01_scales_background_shift", log)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "02_cells", log)

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(project, "03_common_WX", log)

    hist.set_refinements({"Instrument Parameters": ["U"]})
    refine(project, "04_common_UWX", log)

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine(project, "05_common_asymmetry", log)

    (WORK / "baseline_log.json").write_text(json.dumps(log, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
