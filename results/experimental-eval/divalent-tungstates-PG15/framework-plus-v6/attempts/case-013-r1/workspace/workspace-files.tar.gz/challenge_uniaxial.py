#!/usr/bin/env python3
"""Challenge symmetry-distinct uniaxial microstrain for a selected phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--axis", nargs=3, type=int, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--cycles", type=int, default=10)
    parser.add_argument("--passes", type=int, default=3)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    reports = []
    for mode in ["strain", "both"]:
        output = args.outdir / f"{mode}.gpx"
        project = G2.G2Project(gpxfile=str(args.project), newgpx=str(output))
        project.set_Frozen()
        project.set_Controls("cycles", args.cycles)
        hist = project.histograms()[0]
        for key in ["U", "W", "X"]:
            hist.data["Instrument Parameters"][0][key][2] = False
        for phase_index, phase in enumerate(project.phases()):
            hap = phase.data["Histograms"][hist.name]
            if phase_index != args.phase and hap["Size"][1][0] <= 0.0400001:
                hap["Size"][2][0] = False

        target = project.phases()[args.phase]
        hap = target.data["Histograms"][hist.name]
        if mode == "strain":
            hap["Size"][1][0] = 10.0
            hap["Size"][2][0] = False
        else:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 0.10
            hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = 3000.0
        hap["Mustrain"][1][1] = 3000.0
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = list(args.axis)
        project.set_Controls("parmMin", 0.04, variable=f"{args.phase}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{args.phase}:0:Size;i")
        for suffix in ["i", "a"]:
            project.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;{suffix}")
            project.set_Controls("parmMax", 8000.0, variable=f"{args.phase}:0:Mustrain;{suffix}")
        project.save()

        passes = []
        for pass_number in range(1, args.passes + 1):
            project = G2.G2Project(gpxfile=str(output), newgpx=str(output))
            project.set_Controls("cycles", args.cycles)
            project.refine()
            project.save()
            hist = project.histograms()[0]
            rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
            passes.append({
                "pass": pass_number,
                "wR_percent": hist.get_wR(),
                "max_shift_over_esd": rvals.get("Max shft/sig"),
                "frozen": project.get_Frozen(),
            })
        hist = project.histograms()[0]
        hap = project.phases()[args.phase].data["Histograms"][hist.name]
        reports.append({
            "mode": mode,
            "axis": args.axis,
            "project": str(output),
            "wR_percent": hist.get_wR(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "passes": passes,
            "frozen": project.get_Frozen(),
        })
    (args.outdir / "summary.json").write_text(
        json.dumps(reports, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
