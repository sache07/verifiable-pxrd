#!/usr/bin/env python3
"""Challenge small, physically bounded coordinate shifts for one phase."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def lattice_matrix(cell: dict) -> np.ndarray:
    a, b, c = (cell[f"length_{v}"] for v in "abc")
    alpha, beta, gamma = (math.radians(cell[f"angle_{v}"]) for v in ("alpha", "beta", "gamma"))
    av = np.array([a, 0.0, 0.0])
    bv = np.array([b * math.cos(gamma), b * math.sin(gamma), 0.0])
    cx = c * math.cos(beta)
    cy = c * (math.cos(alpha) - math.cos(beta) * math.cos(gamma)) / math.sin(gamma)
    cv = np.array([cx, cy, math.sqrt(max(c * c - cx * cx - cy * cy, 0.0))])
    return np.vstack([av, bv, cv])


def atom_rows(phase, initial: dict[int, list[float]]) -> list[dict]:
    matrix = lattice_matrix(phase.get_cell())
    rows = []
    for i, atom in enumerate(phase.atoms()):
        delta = np.asarray(atom.coordinates) - np.asarray(initial[i])
        delta -= np.round(delta)
        rows.append(
            {
                "index": i,
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(map(float, atom.coordinates)),
                "initial_coordinates": initial[i],
                "displacement_A": float(np.linalg.norm(delta @ matrix)),
                "uiso_A2": float(atom.uiso),
                "flags": atom.refinement_flags,
            }
        )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--labels", nargs="+", required=True)
    parser.add_argument("--bound-A", type=float, default=0.10)
    parser.add_argument("--cycles", type=int, default=16)
    parser.add_argument("--passes", type=int, default=3)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    project = G2.G2Project(gpxfile=str(args.project), newgpx=str(args.output))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histograms()[0]
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""

    phase = project.phases()[args.phase]
    atoms = phase.atoms()
    initial = {i: list(map(float, atom.coordinates)) for i, atom in enumerate(atoms)}
    lengths = [phase.get_cell()[f"length_{v}"] for v in "abc"]
    selected = []
    for label in args.labels:
        matches = [(i, atom) for i, atom in enumerate(atoms) if atom.label == label]
        if len(matches) != 1:
            raise ValueError(f"Expected one atom labelled {label!r}, found {len(matches)}")
        i, atom = matches[0]
        atom.refinement_flags = "X"
        selected.append(i)
        for axis, length in zip("xyz", lengths):
            center = float(atom.coordinates["xyz".index(axis)])
            delta = args.bound_A / length
            # GSAS-II names these variables dAx/dAy/dAz, but their parameter
            # values are the absolute fractional coordinates.
            variable = f"{phase.data['pId']}::dA{axis}:{i}"
            project.set_Controls("parmMin", center - delta, variable=variable)
            project.set_Controls("parmMax", center + delta, variable=variable)
    project.save()

    history = []
    for pass_number in range(1, args.passes + 1):
        project = G2.G2Project(gpxfile=str(args.output), newgpx=str(args.output))
        project.set_Controls("cycles", args.cycles)
        project.refine()
        project.save()
        hist = project.histograms()[0]
        phase = project.phases()[args.phase]
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        row = {
            "pass": pass_number,
            "wR_percent": hist.get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
            "converged": rvals.get("converged"),
            "frozen": project.get_Frozen(),
            "atoms": atom_rows(phase, initial),
        }
        history.append(row)
        print(json.dumps({
            "pass": pass_number,
            "wR_percent": row["wR_percent"],
            "max_shift_over_esd": row["max_shift_over_esd"],
            "frozen": row["frozen"],
            "selected": [row["atoms"][i] for i in selected],
        }, default=str))
    args.output.with_suffix(".coordinates.json").write_text(
        json.dumps(history, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
