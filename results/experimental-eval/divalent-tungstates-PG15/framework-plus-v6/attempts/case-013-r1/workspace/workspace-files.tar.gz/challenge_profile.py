#!/usr/bin/env python3
"""Compare neutral, size, strain, and combined broadening for one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--phase", type=int, default=0)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--keep-profile", action="store_true")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    reports = []
    for mode in ["neutral", "size", "strain", "both"]:
        out = args.outdir / f"{mode}.gpx"
        project = G2.G2Project(gpxfile=str(args.project), newgpx=str(out))
        project.set_Frozen()
        project.set_Controls("cycles", args.cycles)
        hist = project.histograms()[0]
        inst = hist.data["Instrument Parameters"][0]
        for key, value in [("U", 10.0), ("W", 10.0), ("X", 1.0)]:
            if not args.keep_profile:
                inst[key][1] = value
            inst[key][2] = False
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 10.0
            hap["Size"][2] = [False, False, False]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2] = [False, False, False]
        target = project.phases()[args.phase]
        if mode in {"size", "both"}:
            target.setSampleProfile(hist, "size", "isotropic", 0.5)
            target.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        if mode in {"strain", "both"}:
            target.setSampleProfile(hist, "microstrain", "isotropic", 2000.0)
            target.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        project.save()
        project.set_Controls("parmMin", 0.04, variable=f"{args.phase}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{args.phase}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{args.phase}:0:Mustrain;i")
        project.refine()
        project.save()
        cov = project.data.get("Covariance", {}).get("data", {})
        hap = target.data["Histograms"][hist.name]
        report = {
            "mode": mode,
            "project": str(out),
            "wR_percent": hist.get_wR(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "Rvals": cov.get("Rvals", {}),
            "frozen": project.get_Frozen(),
        }
        reports.append(report)
        print(json.dumps(report, indent=2, default=str))
    (args.outdir / "summary.json").write_text(json.dumps(reports, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
