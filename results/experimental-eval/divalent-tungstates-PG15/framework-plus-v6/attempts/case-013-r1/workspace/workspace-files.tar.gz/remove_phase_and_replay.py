#!/usr/bin/env python3
"""Remove one phase from a GSAS-II branch and reconverge the inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--name", required=True)
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--passes", type=int, default=4)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    project = G2.G2Project(gpxfile=str(args.project), newgpx=str(args.output))
    if args.name not in project.data["Phases"]:
        raise KeyError(f"phase not found: {args.name}")
    del project.data["Phases"][args.name]
    for name_row in project.names:
        if name_row and name_row[0] == "Phases" and args.name in name_row:
            name_row.remove(args.name)
    for hist in project.histograms():
        hist.data.get("Reflection Lists", {}).pop(args.name, None)
    project.update_ids()
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histograms()[0]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    project.save()

    history = []
    for pass_number in range(1, args.passes + 1):
        project = G2.G2Project(gpxfile=str(args.output), newgpx=str(args.output))
        project.set_Controls("cycles", args.cycles)
        project.refine()
        project.save()
        hist = project.histograms()[0]
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        row = {
            "pass": pass_number,
            "wR_percent": hist.get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
            "frozen": project.get_Frozen(),
            "phases": [
                {
                    "name": phase.name,
                    "scale": phase.data["Histograms"][hist.name]["Scale"],
                    "cell": phase.get_cell(),
                }
                for phase in project.phases()
            ],
        }
        history.append(row)
        print(json.dumps(row, default=str))
    args.output.with_suffix(".inventory.json").write_text(
        json.dumps(history, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
