#!/usr/bin/env python3
"""Rank chemistry-compatible COD records against a positive residual profile."""

from __future__ import annotations

import gzip
import json
import math
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d


INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")
ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
L1 = 1.540598
L2 = 1.544426


def path_for(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def shifted_positions(two_theta: np.ndarray, lattice_ratio: float, displacement_deg: float) -> np.ndarray:
    theta = np.deg2rad(two_theta / 2.0)
    arg = np.clip(np.sin(theta) / lattice_ratio, -0.999999, 0.999999)
    moved = np.rad2deg(2.0 * np.arcsin(arg))
    return moved + displacement_deg * np.cos(np.deg2rad(moved / 2.0))


def basis_from_sticks(x: np.ndarray, pos: np.ndarray, inten: np.ndarray, sigma_deg: float) -> np.ndarray:
    out = np.zeros_like(x)
    step = float(np.median(np.diff(x)))
    radius = max(2, int(math.ceil(4.0 * sigma_deg / step)))
    for center, amp in zip(pos, inten):
        j = int(np.searchsorted(x, center))
        lo, hi = max(0, j - radius), min(len(x), j + radius + 1)
        if lo >= hi:
            continue
        out[lo:hi] += amp * np.exp(-0.5 * ((x[lo:hi] - center) / sigma_deg) ** 2)
    return out


def main() -> None:
    with np.load(".tmp/residual.npz") as z:
        x = z["x"]
        raw = z["residual"]
        observed = z["observed"]
    # Retain positive coherent residual while reducing point noise. Weighted
    # least-squares below still uses count-based weights.
    residual = np.maximum(gaussian_filter1d(raw, 1.2), 0.0)
    weights = 1.0 / np.maximum(observed, 200.0)

    with gzip.open(INDEX, "rt") as handle:
        database = json.load(handle)
    records = []
    for system in ["O-Pb-W", "O-W", "O-Pb"]:
        for formula, cod_id, sg, quality in database.get(system, []):
            records.append((system, formula, str(cod_id), sg, quality))

    calc = XRDCalculator(wavelength=L1, symprec=0)
    results = []
    for system, formula, cod_id, sg, quality in records:
        try:
            structure = Structure.from_file(path_for(cod_id))
            pattern = calc.get_pattern(structure, two_theta_range=(9.5, 100.5), scaled=True)
        except Exception as exc:
            results.append({"cod_id": cod_id, "formula": formula, "error": str(exc)})
            continue
        p1 = np.asarray(pattern.x, dtype=float)
        i1 = np.asarray(pattern.y, dtype=float)
        keep = i1 >= 0.4
        p1, i1 = p1[keep], i1[keep]
        # Add the reported Kalpha2 component at half intensity.
        th = np.deg2rad(p1 / 2.0)
        p2 = np.rad2deg(2.0 * np.arcsin(np.clip(np.sin(th) * L2 / L1, -0.999999, 0.999999)))
        base_pos = np.r_[p1, p2]
        base_int = np.r_[i1, 0.5 * i1]

        best = None
        for lattice_ratio in np.linspace(0.975, 1.025, 51):
            for displacement in np.linspace(-0.45, 0.45, 37):
                pos = shifted_positions(base_pos, lattice_ratio, displacement)
                valid = (pos >= x[0]) & (pos <= x[-1])
                basis = basis_from_sticks(x, pos[valid], base_int[valid], 0.085)
                norm = float(np.dot(weights * basis, basis))
                if norm <= 0:
                    continue
                dot = float(np.dot(weights * basis, residual))
                amplitude = max(0.0, dot / norm)
                improvement = 2.0 * amplitude * dot - amplitude * amplitude * norm
                # Penalize strong predicted peaks centered in a negative residual.
                idx = np.clip(np.searchsorted(x, pos[valid]), 0, len(x) - 1)
                missing = float(np.sum(base_int[valid][raw[idx] < -100.0]))
                score = improvement / (1.0 + 0.002 * missing)
                if best is None or score > best[0]:
                    best = (score, lattice_ratio, displacement, amplitude, missing)
        results.append(
            {
                "cod_id": cod_id,
                "formula": formula,
                "system": system,
                "space_group": sg,
                "quality": quality,
                "score": best[0],
                "lattice_ratio": best[1],
                "displacement_deg": best[2],
                "amplitude": best[3],
                "missing_penalty": best[4],
                "cell": [*structure.lattice.abc, *structure.lattice.angles],
            }
        )
    ranked = sorted((row for row in results if "score" in row), key=lambda row: row["score"], reverse=True)
    print(json.dumps(ranked, indent=2))


if __name__ == "__main__":
    main()
