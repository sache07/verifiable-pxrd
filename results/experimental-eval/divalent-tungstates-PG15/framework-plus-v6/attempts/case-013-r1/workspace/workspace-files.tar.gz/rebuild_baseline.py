#!/usr/bin/env python3
"""Rebuild a clean common profile after a phase-inventory change."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "stage": label,
        "wR_percent": hist.get_wR(),
        "profile": {
            key: inst[key] for key in ["U", "V", "W", "X", "Y", "Z", "SH/L"]
        },
        "shift_micrometres": hist.data["Sample Parameters"].get("Shift"),
        "background": hist.data["Background"][0],
        "phases": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        ],
        "Rvals": cov.get("Rvals", {}),
        "frozen": project.get_Frozen(),
    }


def replay(output: Path, cycles: int, label: str) -> tuple[G2.G2Project, dict]:
    project = G2.G2Project(gpxfile=str(output), newgpx=str(output))
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    return project, snapshot(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=12)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    project = G2.G2Project(gpxfile=str(args.project), newgpx=str(args.output))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]

    # Neutral common baseline. V, Y and Z stay zero to avoid correlated width
    # surrogates; one axial asymmetry term remains at its instrumental default.
    for key, value in [("U", 10.0), ("V", 0.0), ("W", 10.0),
                       ("X", 1.0), ("Y", 0.0), ("Z", 0.0), ("SH/L", 0.03)]:
        inst[key][1] = value
        inst[key][2] = False
    for key, upper in [("U", 200.0), ("W", 200.0), ("X", 20.0)]:
        project.set_Controls("parmMin", 0.0, variable=f":0:{key}")
        project.set_Controls("parmMax", upper, variable=f":0:{key}")

    hist.data["Sample Parameters"]["Shift"][1] = True
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.uiso = 0.005
            atom.refinement_flags = ""
    project.save()

    history = []
    project, row = replay(args.output, args.cycles, "neutral_inventory")
    history.append(row)
    print(json.dumps(row, indent=2, default=str))

    for key in ["W", "U", "X"]:
        hist = project.histograms()[0]
        hist.data["Instrument Parameters"][0][key][2] = True
        project.save()
        project, row = replay(args.output, args.cycles, f"release_{key}")
        history.append(row)
        print(json.dumps(row, indent=2, default=str))

    args.output.with_suffix(".baseline.json").write_text(
        json.dumps(history, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
