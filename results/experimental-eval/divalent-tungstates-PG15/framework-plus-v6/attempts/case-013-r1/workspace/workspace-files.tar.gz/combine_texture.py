#!/usr/bin/env python3
"""Apply selected March-Dollase terms together and replay refinements."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def parse_term(value: str) -> tuple[int, list[int]]:
    phase_text, axis_text = value.split(":", 1)
    axis = [int(v) for v in axis_text.split(",")]
    if len(axis) != 3:
        raise argparse.ArgumentTypeError("term must be PHASE:h,k,l")
    return int(phase_text), axis


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--term", action="append", type=parse_term, required=True)
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--passes", type=int, default=4)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    project = G2.G2Project(gpxfile=str(args.project), newgpx=str(args.output))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histograms()[0]
    for key in ["U", "W", "X"]:
        hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[1] = 1.0
        po[2] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
    for phase_index, axis in args.term:
        phase = project.phases()[phase_index]
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = axis
        project.set_Controls("parmMin", 0.5, variable=f"{phase_index}:0:MD")
        project.set_Controls("parmMax", 2.0, variable=f"{phase_index}:0:MD")
    project.save()

    history = []
    for pass_number in range(1, args.passes + 1):
        project = G2.G2Project(gpxfile=str(args.output), newgpx=str(args.output))
        project.set_Controls("cycles", args.cycles)
        project.refine()
        project.save()
        hist = project.histograms()[0]
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        row = {
            "pass": pass_number,
            "wR_percent": hist.get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
            "frozen": project.get_Frozen(),
            "terms": [
                {
                    "phase": i,
                    "name": project.phases()[i].name,
                    "pref_ori": project.phases()[i].data["Histograms"][hist.name]["Pref.Ori."],
                }
                for i, _axis in args.term
            ],
        }
        history.append(row)
        print(json.dumps(row, default=str))
    args.output.with_suffix(".texture.json").write_text(
        json.dumps(history, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
