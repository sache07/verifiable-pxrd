#!/usr/bin/env python3
"""Build and refine a trial multiphase GSAS-II project.

Run with the GSAS-II Python interpreter. This is an analysis helper; the final
project/export script is kept separate once the inventory is selected.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summarize(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    result = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "sample": hist.data["Sample Parameters"],
        "instrument": hist.data["Instrument Parameters"][0],
        "background": hist.data["Background"][0],
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
            }
        )
    cov = project.data.get("Covariance", {}).get("data", {})
    result["Rvals"] = cov.get("Rvals", {})
    result["varyList"] = cov.get("varyList", [])
    result["variables"] = np.asarray(cov.get("variables", []), dtype=float).tolist()
    result["sig"] = np.asarray(cov.get("sig", []), dtype=float).tolist()
    return result


def set_neutral_hap(phase, hist, scale: float) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(scale), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1000.0
    hap["Size"][1][1] = 1000.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ids", nargs="+", required=True)
    parser.add_argument("--names", nargs="+")
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--background", type=int, default=6)
    parser.add_argument("--start-scales", nargs="+", type=float)
    args = parser.parse_args()

    if args.names and len(args.names) != len(args.ids):
        raise ValueError("--names and --ids must have equal lengths")
    names = args.names or [f"COD_{x}" for x in args.ids]
    scales = args.start_scales or [5.0] + [1.0] * (len(args.ids) - 1)
    if len(scales) != len(args.ids):
        raise ValueError("--start-scales and --ids must have equal lengths")

    args.out.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(args.out))
    phases = [
        project.add_phase(str(cod_path(cod_id)), phasename=name, fmthint="CIF")
        for cod_id, name in zip(args.ids, names)
    ]
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", phases=phases,
        fmthint="comma/tab/semicolon separated"
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, True]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background,
                "coeffs": [float(np.percentile(hist.data["data"][1][1], 20))] + [0.0] * (args.background - 1),
                "refine": True,
            },
        }
    )
    for phase, scale in zip(phases, scales):
        set_neutral_hap(phase, hist, scale)

    project.set_Controls("cycles", args.cycles)
    project.save()
    project.set_Controls("parmMin", 0.0, variable="*:0:Scale")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for key, upper in [("U", 40.0), ("W", 40.0), ("X", 6.0)]:
        project.set_Controls("parmMin", 0.0, variable=f":0:{key}")
        project.set_Controls("parmMax", upper, variable=f":0:{key}")
    history = []

    # Smooth background, all scales and one angular correction.
    project.refine()
    history.append(summarize(project, "scales_background_shift"))

    # Refine cells only after scales and displacement have settled. Add each
    # phase sequentially so an unstable minor candidate can be diagnosed.
    for phase in phases:
        phase.set_refinements({"Cell": True})
        project.refine()
        history.append(summarize(project, f"cell_{phase.name}"))

    # Establish a common nonnegative U/W/X profile. V and all other terms stay neutral.
    inst = hist.data["Instrument Parameters"][0]
    for key in ["W", "U", "X"]:
        inst[key][2] = True
        project.refine()
        history.append(summarize(project, f"common_profile_{key}"))

    project.save()
    args.out.with_suffix(".json").write_text(json.dumps(history, indent=2, default=str) + "\n")
    print(json.dumps(history[-1], indent=2, default=str))


if __name__ == "__main__":
    main()
