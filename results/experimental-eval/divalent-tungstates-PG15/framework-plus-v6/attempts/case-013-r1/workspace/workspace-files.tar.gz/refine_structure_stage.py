#!/usr/bin/env python3
"""Apply one controlled atomic-coordinate or uniform-Uiso refinement stage."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def atom_rows(phase) -> list[dict]:
    return [
        {
            "index": i,
            "label": atom.label,
            "element": atom.element,
            "coordinates": list(atom.coordinates),
            "occupancy": atom.occupancy,
            "uiso": atom.uiso,
            "flags": atom.refinement_flags,
        }
        for i, atom in enumerate(phase.atoms())
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--labels", nargs="*")
    parser.add_argument("--uniform-uiso", action="store_true")
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()
    if not args.uniform_uiso and not args.labels:
        raise ValueError("supply --labels or --uniform-uiso")

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.project), newgpx=str(args.output))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histograms()[0]
    for key in ["U", "W", "X"]:
        hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""

    phase = project.phases()[args.phase]
    before = atom_rows(phase)
    if args.uniform_uiso:
        atoms = phase.atoms()
        for atom in atoms:
            atom.uiso = 0.005
            atom.refinement_flags = "U"
        project.save()
        variables = [f"{args.phase}::AUiso:{i}" for i in range(len(atoms))]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=True)
        project.set_Controls("parmMin", 0.001, variable=f"{args.phase}::AUiso:*")
        project.set_Controls("parmMax", 0.03, variable=f"{args.phase}::AUiso:*")
    else:
        for label in args.labels:
            atom = phase.atom(label)
            if atom is None:
                raise ValueError(f"No atom label {label!r} in phase {phase.name}")
            atom.refinement_flags = "X"
        project.save()

    project.refine()
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {})
    report = {
        "project": str(args.output),
        "phase": phase.name,
        "stage": "uniform_uiso" if args.uniform_uiso else "coordinates",
        "labels": args.labels,
        "wR_percent": hist.get_wR(),
        "before": before,
        "after": atom_rows(phase),
        "Rvals": cov.get("Rvals", {}),
        "frozen": project.get_Frozen(),
    }
    args.output.with_suffix(".structure.json").write_text(json.dumps(report, indent=2, default=str) + "\n")
    print(json.dumps(report, indent=2, default=str))


if __name__ == "__main__":
    main()
