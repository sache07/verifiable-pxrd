#!/usr/bin/env python3
"""Save/reopen/replay a GSAS-II project until its active model is stable."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--passes", type=int, default=3)
    parser.add_argument("--prune-u", action="store_true")
    parser.add_argument("--all-cells", action="store_true")
    parser.add_argument("--fix-cell-name")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    project = G2.G2Project(gpxfile=str(args.project), newgpx=str(args.output))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    if args.prune_u:
        u = project.histograms()[0].data["Instrument Parameters"][0]["U"]
        u[1] = 0.0
        u[2] = False
    if args.all_cells:
        hist = project.histograms()[0]
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
            phase.data["Histograms"][hist.name]["Scale"][1] = True
    if args.fix_cell_name:
        project.phase(args.fix_cell_name).set_refinements({"Cell": False})
    project.save()

    history = []
    for pass_number in range(1, args.passes + 1):
        project = G2.G2Project(gpxfile=str(args.output), newgpx=str(args.output))
        project.set_Controls("cycles", args.cycles)
        project.refine()
        project.save()
        hist = project.histograms()[0]
        inst = hist.data["Instrument Parameters"][0]
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        row = {
            "pass": pass_number,
            "wR_percent": hist.get_wR(),
            "profile": {key: inst[key] for key in ["U", "V", "W", "X", "Y", "Z", "SH/L"]},
            "max_shift_over_esd": rvals.get("Max shft/sig"),
            "converged": rvals.get("converged"),
            "frozen": project.get_Frozen(),
        }
        history.append(row)
        print(json.dumps(row, default=str))
    args.output.with_suffix(".stability.json").write_text(
        json.dumps(history, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
