#!/usr/bin/env python3
"""Grid-challenge one physically common isotropic Uiso value per phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--values", nargs="+", type=float, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--passes", type=int, default=2)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    reports = []
    for value in args.values:
        tag = f"{value:.4f}".replace(".", "p")
        output = args.outdir / f"uiso_{tag}.gpx"
        project = G2.G2Project(gpxfile=str(args.project), newgpx=str(output))
        project.set_Frozen()
        project.set_Controls("cycles", args.cycles)
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = ""
        phase = project.phases()[args.phase]
        for atom in phase.atoms():
            atom.uiso = value
        project.save()

        passes = []
        for pass_number in range(1, args.passes + 1):
            project = G2.G2Project(gpxfile=str(output), newgpx=str(output))
            project.set_Controls("cycles", args.cycles)
            project.refine()
            project.save()
            hist = project.histograms()[0]
            rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
            passes.append(
                {
                    "pass": pass_number,
                    "wR_percent": hist.get_wR(),
                    "max_shift_over_esd": rvals.get("Max shft/sig"),
                    "converged": rvals.get("converged"),
                    "frozen": project.get_Frozen(),
                }
            )
        report = {
            "phase_index": args.phase,
            "phase": project.phases()[args.phase].name,
            "uiso_A2": value,
            "project": str(output),
            "passes": passes,
        }
        reports.append(report)
        print(json.dumps(report))
    (args.outdir / "summary.json").write_text(json.dumps(reports, indent=2) + "\n")


if __name__ == "__main__":
    main()
