#!/usr/bin/env python3
"""Set physically common per-phase Uiso values and replay the active model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def parse_term(value: str) -> tuple[int, float]:
    phase, uiso = value.split(":", 1)
    return int(phase), float(uiso)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--term", action="append", type=parse_term, required=True)
    parser.add_argument("--cycles", type=int, default=16)
    parser.add_argument("--passes", type=int, default=4)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    project = G2.G2Project(gpxfile=str(args.project), newgpx=str(args.output))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""
    for phase_index, uiso in args.term:
        for atom in project.phases()[phase_index].atoms():
            atom.uiso = uiso
    project.save()

    history = []
    for pass_number in range(1, args.passes + 1):
        project = G2.G2Project(gpxfile=str(args.output), newgpx=str(args.output))
        project.set_Controls("cycles", args.cycles)
        project.refine()
        project.save()
        hist = project.histograms()[0]
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        row = {
            "pass": pass_number,
            "wR_percent": hist.get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
            "converged": rvals.get("converged"),
            "frozen": project.get_Frozen(),
            "uiso_A2": {
                project.phases()[i].name: sorted({round(float(a.uiso), 8) for a in project.phases()[i].atoms()})
                for i, _value in args.term
            },
        }
        history.append(row)
        print(json.dumps(row))
    args.output.with_suffix(".uiso.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
