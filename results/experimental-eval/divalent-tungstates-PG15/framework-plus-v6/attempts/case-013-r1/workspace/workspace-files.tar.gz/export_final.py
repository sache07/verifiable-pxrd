#!/usr/bin/env python3
"""Freeze the selected GSAS-II replay and export its exact deliverables."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/final_geometry/neutral.gpx")
FINAL = Path("final.gpx")
PATTERN = Path("inputs/pattern.csv")
CIF_NAMES = [
    "phase_1_PbWO4.cif",
    "phase_2_WO3.cif",
    "phase_3_PbO_massicot.cif",
    "phase_4_Pb2WO5.cif",
    "phase_5_PbO_alpha_superstructure.cif",
    "phase_6_Pb2O3.cif",
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    project.save()
    project = G2.G2Project(gpxfile=str(FINAL), newgpx=str(FINAL))
    if len(project.histograms()) != 1:
        raise ValueError("final project must contain exactly one histogram")
    if len(project.phases()) != len(CIF_NAMES):
        raise ValueError("phase/export count mismatch")
    hist = project.histograms()[0]

    saved = np.asarray(hist.data["data"][1], dtype=float)
    x, observed, calculated = saved[0], saved[1], saved[3]
    public = np.loadtxt(PATTERN, delimiter=",", skiprows=1, ndmin=2)
    if not np.allclose(x, public[:, 0], rtol=0, atol=1e-7):
        raise ValueError("project grid differs from input")
    if not np.allclose(observed, public[:, 1], rtol=0, atol=1e-5):
        raise ValueError("project observations differ from input")
    difference = observed - calculated
    np.savetxt(
        "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    phase_rows = []
    contributions = []
    for index, (phase, cif_name) in enumerate(zip(project.phases(), CIF_NAMES)):
        phase.export_CIF(cif_name)
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"])
        scale = float(hap["Scale"][0])
        contributions.append(mass * scale)
        phase_rows.append(
            {
                "index": index,
                "project_name": phase.name,
                "cif_path": cif_name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cell": phase.get_cell(),
                "cell_mass": mass,
                "scale": scale,
                "size": hap["Size"],
                "microstrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "uiso_A2": sorted({round(float(atom.uiso), 10) for atom in phase.atoms()}),
            }
        )
    total = float(sum(contributions))
    for row, contribution in zip(phase_rows, contributions):
        row["weight_fraction"] = float(contribution / total)
        row["cif_sha256"] = sha256(Path(row["cif_path"]))

    weights = 1.0 / np.maximum(observed, 1.0)
    denominator = float(np.sum(weights * observed * observed))
    rwp = float(100.0 * math.sqrt(np.sum(weights * difference * difference) / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    gof = float(rvals["GOF"])
    summary = {
        "project": str(FINAL),
        "project_sha256": sha256(FINAL),
        "histogram": hist.name,
        "n_points": int(len(x)),
        "fit_limits_deg_2theta": list(map(float, hist.data["Limits"][1])),
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": float(rwp / gof),
            "GOF": gof,
            "chi_squared": float(rvals["chisq"]),
            "n_variables": int(rvals["Nvars"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
            "converged": bool(rvals["converged"]),
        },
        "sample": hist.data["Sample Parameters"],
        "instrument": hist.data["Instrument Parameters"][0],
        "background": hist.data["Background"],
        "phases": phase_rows,
        "fit_csv_sha256": sha256(Path("fit.csv")),
    }
    Path(".tmp/final_export_summary.json").write_text(
        json.dumps(summary, indent=2, default=str) + "\n"
    )
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
