#!/usr/bin/env python3
"""Compare symmetry-distinct March-Dollase axes for one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--cycles", type=int, default=10)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    reports = []
    for axis in AXES:
        tag = "".join(map(str, axis))
        out = args.outdir / f"axis_{tag}.gpx"
        project = G2.G2Project(gpxfile=str(args.project), newgpx=str(out))
        project.set_Frozen()
        project.set_Controls("cycles", args.cycles)
        hist = project.histograms()[0]
        for key in ["U", "W", "X"]:
            hist.data["Instrument Parameters"][0][key][2] = False
        for phase in project.phases():
            phase.data["Histograms"][hist.name]["Pref.Ori."][2] = False
            for atom in phase.atoms():
                atom.refinement_flags = ""
        phase = project.phases()[args.phase]
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(axis)
        project.save()
        project.set_Controls("parmMin", 0.5, variable=f"{args.phase}:0:MD")
        project.set_Controls("parmMax", 2.0, variable=f"{args.phase}:0:MD")
        project.refine()
        project.save()
        report = {
            "axis": axis,
            "project": str(out),
            "wR_percent": hist.get_wR(),
            "pref_ori": po,
            "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
            "frozen": project.get_Frozen(),
        }
        reports.append(report)
        print(json.dumps({"axis": axis, "wR_percent": report["wR_percent"], "pref_ori": po, "frozen": report["frozen"]}, indent=2))
    (args.outdir / "summary.json").write_text(json.dumps(reports, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
