#!/usr/bin/env python3
"""Create the isovalent Pb2MoO5 -> Pb2WO5 starting model used in trials."""

from pathlib import Path

from pymatgen.core import Element
from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
PROTOTYPES = {
    "7220560": "Mo",
    "8103050": "Cr",
    "9015570": "Te",
}


for cod_id, replaced_element in PROTOTYPES.items():
    source = ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
    output = Path(f".tmp/pb2wo5_from_{cod_id}.cif")
    structure = CifParser(str(source), occupancy_tolerance=2).parse_structures(
        primitive=False
    )[0]
    structure.replace_species({Element(replaced_element): Element("W")})
    output.parent.mkdir(parents=True, exist_ok=True)
    CifWriter(structure, symprec=1e-5, refine_struct=False).write_file(output)
    print(
        f"wrote {output}: {structure.composition.reduced_formula} "
        f"{structure.get_space_group_info()}"
    )
