#!/usr/bin/env python3
"""Create chemically screened Pb-W-O prototype substitutions for trials."""

from pathlib import Path

from pymatgen.core import Element
from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
TRIALS = {
    # Pb3WO6: isovalent W6+ substitutions in U6+/S6+ Pb3XO6 parents.
    "pb3wo6_from_2310493": ("2310493", "U"),
    "pb3wo6_from_8103588": ("8103588", "S"),
    "pb3wo6_from_1542011": ("1542011", "S"),
    # Reduced-tungsten Pb2W2O7 watch-list model from the closest indexed parent.
    "pb2w2o7_from_9009701": ("9009701", "V"),
    # Isovalent Mo6+ -> W6+ lead-rich intermediate.
    "pb5wo8_from_2007541": ("2007541", "Mo"),
}


for label, (cod_id, replaced_element) in TRIALS.items():
    source = ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
    output = Path(f".tmp/{label}.cif")
    structure = CifParser(str(source), occupancy_tolerance=2).parse_structures(
        primitive=False
    )[0]
    structure.replace_species({Element(replaced_element): Element("W")})
    CifWriter(structure, symprec=1e-5, refine_struct=False).write_file(output)
    print(label, structure.composition.reduced_formula, structure.get_space_group_info())

# Pymatgen standardizes two monoclinic/orthorhombic settings in a form that
# this GSAS-II importer rejects. Preserve the published CIF setting for those
# trials and change only the element tokens/labels.
for label, cod_id, old_element in [
    ("pb3wo6_from_2310493_raw", "2310493", "U"),
    ("pb2w2o7_from_9009701_raw", "9009701", "V"),
]:
    source = ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
    output = Path(f".tmp/{label}.cif")
    text = source.read_text().replace(old_element, "W")
    output.write_text(text)
    print(label, "published setting retained")
