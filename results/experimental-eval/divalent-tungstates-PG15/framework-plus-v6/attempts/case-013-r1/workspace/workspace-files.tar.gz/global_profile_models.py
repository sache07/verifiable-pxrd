#!/usr/bin/env python3
"""Compare global phase-width models under the laboratory profile envelope."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--passes", type=int, default=4)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    reports = []
    for mode in ["neutral", "size", "strain", "both"]:
        output = args.outdir / f"{mode}.gpx"
        project = G2.G2Project(gpxfile=str(args.project), newgpx=str(output))
        project.set_Frozen()
        project.set_Controls("cycles", args.cycles)
        hist = project.histograms()[0]
        inst = hist.data["Instrument Parameters"][0]
        for key, value in [("U", 40.0), ("W", 40.0), ("X", 6.0)]:
            inst[key][1] = value
            inst[key][2] = False
        for phase_index, phase in enumerate(project.phases()):
            phase.set_refinements({"Cell": True})
            hap = phase.data["Histograms"][hist.name]
            hap["Scale"][1] = True
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 0.5 if mode in {"size", "both"} else 10.0
            hap["Size"][2] = [mode in {"size", "both"}, False, False]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 1000.0 if mode in {"strain", "both"} else 0.0
            hap["Mustrain"][2] = [mode in {"strain", "both"}, False, False]
            project.set_Controls("parmMin", 0.04, variable=f"{phase_index}:0:Size;i")
            project.set_Controls("parmMax", 1.5, variable=f"{phase_index}:0:Size;i")
            project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
            project.set_Controls("parmMax", 8000.0, variable=f"{phase_index}:0:Mustrain;i")
        project.save()

        pass_rows = []
        for pass_number in range(1, args.passes + 1):
            project = G2.G2Project(gpxfile=str(output), newgpx=str(output))
            project.set_Controls("cycles", args.cycles)
            project.refine()
            project.save()
            hist = project.histograms()[0]
            rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
            row = {
                "pass": pass_number,
                "wR_percent": hist.get_wR(),
                "max_shift_over_esd": rvals.get("Max shft/sig"),
                "frozen": project.get_Frozen(),
            }
            pass_rows.append(row)
            print(json.dumps({"mode": mode, **row}, default=str))

        hist = project.histograms()[0]
        reports.append({
            "mode": mode,
            "project": str(output),
            "wR_percent": hist.get_wR(),
            "passes": pass_rows,
            "phases": [
                {
                    "name": phase.name,
                    "scale": phase.data["Histograms"][hist.name]["Scale"],
                    "size": phase.data["Histograms"][hist.name]["Size"],
                    "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
                    "cell": phase.get_cell(),
                }
                for phase in project.phases()
            ],
            "frozen": project.get_Frozen(),
        })
    (args.outdir / "summary.json").write_text(
        json.dumps(reports, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
