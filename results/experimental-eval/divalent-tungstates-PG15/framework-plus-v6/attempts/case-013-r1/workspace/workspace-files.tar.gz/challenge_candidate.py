#!/usr/bin/env python3
"""Challenge candidate phases against a fixed, shared nuisance baseline."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def phase_row(phase, hist) -> dict:
    hap = phase.data["Histograms"][hist.name]
    return {
        "name": phase.name,
        "cell": phase.get_cell(),
        "scale": hap["Scale"],
        "mass": phase.data["General"]["Mass"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--ids", nargs="+")
    parser.add_argument("--cifs", nargs="+", type=Path)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    candidates = []
    for cod_id in args.ids or []:
        candidates.append((cod_id, cod_path(cod_id)))
    for cif in args.cifs or []:
        candidates.append((cif.stem, cif))
    if not candidates:
        parser.error("at least one of --ids or --cifs is required")

    reports = []
    for candidate_id, candidate_path in candidates:
        out = args.outdir / f"candidate_{candidate_id}.gpx"
        project = G2.G2Project(gpxfile=str(args.project), newgpx=str(out))
        project.set_Frozen()
        project.set_Controls("cycles", args.cycles)
        hist = project.histograms()[0]
        for key in ["U", "W", "X"]:
            hist.data["Instrument Parameters"][0][key][2] = False
        for old_phase in project.phases():
            old_phase.set_refinements({"Cell": False})
        candidate = project.add_phase(
            str(candidate_path), phasename=f"candidate_{candidate_id}",
            histograms=[hist], fmthint="CIF"
        )
        hap = candidate.data["Histograms"][hist.name]
        hap["Scale"] = [0.5, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        project.save()
        project.set_Controls("parmMin", 0.0, variable=f"{candidate.id}:0:Scale")

        reference_cell = phase_row(candidate, hist)["cell"]
        project.refine()
        project.save()
        fixed_project = args.outdir / f"candidate_{candidate_id}_fixed_cell.gpx"
        shutil.copy2(out, fixed_project)
        fixed_cell = {
            "wR_percent": hist.get_wR(),
            "project": str(fixed_project),
            "candidate": phase_row(candidate, hist),
            "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
        }
        candidate.set_refinements({"Cell": True})
        project.refine()
        project.save()
        refined_cell = {
            "wR_percent": hist.get_wR(),
            "candidate": phase_row(candidate, hist),
            "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
            "frozen": project.get_Frozen(),
        }
        report = {
            "candidate_id": candidate_id,
            "source_cif": str(candidate_path),
            "project": str(out),
            "reference_cell": reference_cell,
            "fixed_cell_fit": fixed_cell,
            "refined_cell_fit": refined_cell,
        }
        reports.append(report)
        print(json.dumps(report, indent=2, default=str))
    (args.outdir / "summary.json").write_text(json.dumps(reports, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
