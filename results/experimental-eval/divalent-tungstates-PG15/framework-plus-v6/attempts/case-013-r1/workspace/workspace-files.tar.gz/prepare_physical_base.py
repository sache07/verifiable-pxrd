#!/usr/bin/env python3
"""Reset unsupported minor-phase ADPs and reconverge a physical base project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=10)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.project), newgpx=str(args.output))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histograms()[0]
    for key in ["U", "W", "X"]:
        hist.data["Instrument Parameters"][0][key][2] = False
    for i, phase in enumerate(project.phases()):
        for atom in phase.atoms():
            atom.uiso = 0.005
            atom.refinement_flags = ""
    project.refine()
    project.save()
    # Reopen and replay the active model through one more refinement so stale
    # covariance variables or calculated arrays cannot masquerade as a gain.
    project = G2.G2Project(gpxfile=str(args.output), newgpx=str(args.output))
    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save()
    hist = project.histograms()[0]
    report = {
        "project": str(args.output),
        "wR_percent": hist.get_wR(),
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "phases": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "atoms": [
                    {"label": atom.label, "coordinates": list(atom.coordinates), "uiso": atom.uiso, "flags": atom.refinement_flags}
                    for atom in phase.atoms()
                ],
                "hap": phase.data["Histograms"][hist.name],
            }
            for phase in project.phases()
        ],
        "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
        "frozen": project.get_Frozen(),
    }
    args.output.with_suffix(".physical.json").write_text(json.dumps(report, indent=2, default=str) + "\n")
    print(json.dumps({"wR_percent": report["wR_percent"], "frozen": report["frozen"]}, indent=2))


if __name__ == "__main__":
    main()
