#!/usr/bin/env python3
"""Challenge polarization, surface roughness and axial asymmetry effects."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--cycles", type=int, default=10)
    parser.add_argument("--passes", type=int, default=3)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    reports = []
    for mode in ["neutral", "polarization", "roughness", "asymmetry", "polarization_roughness"]:
        output = args.outdir / f"{mode}.gpx"
        project = G2.G2Project(gpxfile=str(args.project), newgpx=str(output))
        project.set_Frozen()
        project.set_Controls("cycles", args.cycles)
        hist = project.histograms()[0]
        inst = hist.data["Instrument Parameters"][0]
        sample = hist.data["Sample Parameters"]
        inst["Polariz."] = [inst["Polariz."][0], 0.7, False]
        inst["SH/L"][2] = False
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.0, False]
        if "polarization" in mode:
            inst["Polariz."][2] = True
            project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
            project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
        if "roughness" in mode:
            sample["SurfRoughA"] = [0.3, True]
            sample["SurfRoughB"] = [0.1, True]
            project.set_Controls("parmMin", 0.01, variable=":0:SurfRoughA")
            project.set_Controls("parmMax", 0.9, variable=":0:SurfRoughA")
            project.set_Controls("parmMin", 0.001, variable=":0:SurfRoughB")
            project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughB")
        if mode == "asymmetry":
            inst["SH/L"][2] = True
            project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
            project.set_Controls("parmMax", 0.1, variable=":0:SH/L")
        project.save()

        passes = []
        for pass_number in range(1, args.passes + 1):
            project = G2.G2Project(gpxfile=str(output), newgpx=str(output))
            project.set_Controls("cycles", args.cycles)
            project.refine()
            project.save()
            hist = project.histograms()[0]
            rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
            passes.append({
                "pass": pass_number,
                "wR_percent": hist.get_wR(),
                "max_shift_over_esd": rvals.get("Max shft/sig"),
                "frozen": project.get_Frozen(),
            })
        hist = project.histograms()[0]
        reports.append({
            "mode": mode,
            "project": str(output),
            "wR_percent": hist.get_wR(),
            "polarization": hist.data["Instrument Parameters"][0]["Polariz."],
            "SH_L": hist.data["Instrument Parameters"][0]["SH/L"],
            "SurfRoughA": hist.data["Sample Parameters"]["SurfRoughA"],
            "SurfRoughB": hist.data["Sample Parameters"]["SurfRoughB"],
            "passes": passes,
            "frozen": project.get_Frozen(),
        })
    (args.outdir / "summary.json").write_text(
        json.dumps(reports, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
