#!/usr/bin/env python3
"""Prune profile terms that reached bounds, then replay the full model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--keep-opbo-limit", action="store_true")
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--passes", type=int, default=4)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    project = G2.G2Project(gpxfile=str(args.project), newgpx=str(args.output))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    inst["X"][1] = 6.0
    inst["X"][2] = False
    inst["U"][2] = True
    inst["W"][2] = True
    # PbWO4 size refined to the no-broadening limit once the common profile
    # was rebuilt; remove it. The massicot limit is retained only in the
    # explicit sensitivity branch.
    for phase_index in [0] + ([] if args.keep_opbo_limit else [2]):
        hap = project.phases()[phase_index].data["Histograms"][hist.name]
        hap["Size"][1][0] = 10.0
        hap["Size"][2][0] = False
    project.save()

    history = []
    for pass_number in range(1, args.passes + 1):
        project = G2.G2Project(gpxfile=str(args.output), newgpx=str(args.output))
        project.set_Controls("cycles", args.cycles)
        project.refine()
        project.save()
        hist = project.histograms()[0]
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        history.append({
            "pass": pass_number,
            "wR_percent": hist.get_wR(),
            "max_shift_over_esd": rvals.get("Max shft/sig"),
            "profile": {key: hist.data["Instrument Parameters"][0][key] for key in ["U", "W", "X"]},
            "frozen": project.get_Frozen(),
        })
        print(json.dumps(history[-1], default=str))
    args.output.with_suffix(".prune.json").write_text(
        json.dumps(history, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
