#!/usr/bin/env python3
"""Refine a bounded common U/W/X profile in controlled steps."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.project), newgpx=str(args.output))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    for key in ["U", "W", "X"]:
        inst[key][2] = False
    project.save()
    for key, upper in [("U", 40.0), ("W", 40.0), ("X", 6.0)]:
        project.set_Controls("parmMin", 0.0, variable=f":0:{key}")
        project.set_Controls("parmMax", upper, variable=f":0:{key}")
    history = []
    for key in ["W", "U", "X"]:
        inst[key][2] = True
        project.refine()
        project.save()
        cov = project.data.get("Covariance", {}).get("data", {})
        row = {
            "step": key,
            "wR_percent": hist.get_wR(),
            "profile": {name: inst[name] for name in ["U", "V", "W", "X", "Y", "Z", "SH/L"]},
            "Rvals": cov.get("Rvals", {}),
            "frozen": project.get_Frozen(),
        }
        history.append(row)
        print(json.dumps(row, indent=2, default=str))
    args.output.with_suffix(".profile.json").write_text(json.dumps(history, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
