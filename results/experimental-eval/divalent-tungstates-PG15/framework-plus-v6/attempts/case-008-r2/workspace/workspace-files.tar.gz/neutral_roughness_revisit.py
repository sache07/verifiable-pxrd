from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "shl_constrained_0p070.gpx"
OUT = ROOT / ".tmp" / "roughness_neutral.gpx"


G2.SetPrintLevel("warn")
project = G2.G2Project(str(BASE), newgpx=str(OUT))
project.data["Controls"]["data"]["parmFrozen"] = {}
project.set_Controls("cycles", 28)
hist = project.histogram(0)
sample = hist.data["Sample Parameters"]
sample["SurfRoughA"] = [0.0, False]
sample["SurfRoughB"] = [0.0, False]
project.refine(makeBack=False)
project.save()

# Reopen and calculate once without varying parameters. This makes the reported
# residual an exact replay of the parameter values stored in the project.
project = G2.G2Project(str(OUT))
project.data["Controls"]["data"]["parmFrozen"] = {}
project.set_Controls("cycles", 0)
project.refine(makeBack=False)
project.save()
hist = project.histogram(0)
phase = project.phase(0)
hap = phase.data["Histograms"][hist.name]
print(
    json.dumps(
        {
            "Rwp": hist.get_wR(),
            "roughness": {
                "A": hist.data["Sample Parameters"]["SurfRoughA"],
                "B": hist.data["Sample Parameters"]["SurfRoughB"],
            },
            "MD": hap["Pref.Ori."],
            "coordinates": {
                atom.label: list(atom.coordinates) for atom in phase.atoms()
            },
            "frozen": {
                key: [str(item) for item in vals]
                for key, vals in project.data["Controls"]["data"].get(
                    "parmFrozen", {}
                ).items()
            },
        },
        default=float,
    )
)
