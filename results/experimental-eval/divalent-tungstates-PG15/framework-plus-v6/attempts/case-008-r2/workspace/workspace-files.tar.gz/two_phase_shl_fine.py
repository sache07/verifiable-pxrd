from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "two_phase_cell.gpx"
VALUES = [0.067, 0.068, 0.069, 0.070, 0.071, 0.072, 0.073]


def run(value: float) -> None:
    tag = f"{value:.3f}".replace(".", "p")
    out = ROOT / ".tmp" / f"two_phase_shl_fine_{tag}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 44)
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["SH/L"][1:3] = [float(value), False]
    inst["U"][1:3] = [40.0, False]
    inst["W"][1:3] = [2.0, False]
    project.phase(0).data["Histograms"][hist.name]["Size"][2] = [
        True,
        False,
        False,
    ]
    project.refine(makeBack=False)
    project.save()

    project = G2.G2Project(str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    main_hap = project.phase(0).data["Histograms"][hist.name]
    print(
        json.dumps(
            {
                "SH/L": value,
                "Rwp": hist.get_wR(),
                "size_um": main_hap["Size"][1][0],
                "shift": hist.data["Sample Parameters"]["Shift"][0],
                "scales": {
                    phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
                    for phase in project.phases()
                },
                "frozen": {
                    key: [str(item) for item in values]
                    for key, values in project.data["Controls"]["data"].get(
                        "parmFrozen", {}
                    ).items()
                },
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
for item in sys.argv[1:] or VALUES:
    run(float(item))
