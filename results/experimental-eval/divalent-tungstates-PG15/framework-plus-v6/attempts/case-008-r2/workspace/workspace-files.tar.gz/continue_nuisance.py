from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / ".tmp" / "final_stage_a_nuisance.gpx"
OUT = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else ROOT / ".tmp" / "final_stage_a_continued.gpx"


G2.SetPrintLevel("warn")
project = G2.G2Project(str(BASE), newgpx=str(OUT))
project.data["Controls"]["data"]["parmFrozen"] = {}
project.set_Controls("cycles", 96)
project.refine(makeBack=False)
project.save()
project = G2.G2Project(str(OUT))
project.data["Controls"]["data"]["parmFrozen"] = {}
project.set_Controls("cycles", 0)
project.refine(makeBack=False)
project.save()
hist = project.histogram(0)
print(
    json.dumps(
        {
            "Rwp": hist.get_wR(),
            "cells": {
                phase.name: phase.data["General"]["Cell"]
                for phase in project.phases()
            },
            "scales": {
                phase.name: phase.data["Histograms"][hist.name]["Scale"]
                for phase in project.phases()
            },
            "shift": hist.data["Sample Parameters"]["Shift"],
            "roughness_B": hist.data["Sample Parameters"]["SurfRoughB"],
            "frozen": project.data["Controls"]["data"].get("parmFrozen", {}),
        },
        default=float,
    )
)
