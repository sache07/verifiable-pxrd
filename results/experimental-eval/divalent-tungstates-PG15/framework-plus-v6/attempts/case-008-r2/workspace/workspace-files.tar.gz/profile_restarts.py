from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "finalprofile_texture_001.gpx"
STARTS = {
    "current": [13.6, 0.20, 830.0, 1200.0],
    "w8_s05": [8.0, 0.50, 1500.0, 2200.0],
    "w5_s05": [5.0, 0.50, 1800.0, 2600.0],
    "w3_s08": [3.0, 0.80, 2200.0, 3200.0],
    "w2_s12": [2.1, 1.20, 2600.0, 3800.0],
    "w10_s10": [10.0, 1.00, 1800.0, 2500.0],
}


def run(name):
    W, size, equatorial, axial = STARTS[name]
    out = ROOT / ".tmp" / f"profile_restart_{name}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 32)
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    hap = phase.data["Histograms"][hist.name]
    inst["W"][1:3] = [W, True]
    hap["Size"][1][0] = size
    hap["Size"][2] = [True, False, False]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = equatorial
    hap["Mustrain"][1][1] = axial
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = [1, 0, 0]
    for variable, minimum, maximum in [
        (":0:W", 2.0, 40.0),
        ("0:0:Size;i", 0.04, 1.5),
        ("0:0:Mustrain;i", 0.0, 8000.0),
        ("0:0:Mustrain;a", 0.0, 32000.0),
    ]:
        project.set_Controls("parmMin", minimum, variable=variable)
        project.set_Controls("parmMax", maximum, variable=variable)
    project.refine(makeBack=False)
    project.save()
    print(
        json.dumps(
            {
                "trial": name,
                "Rwp": hist.get_wR(),
                "W": inst["W"][1],
                "size_um": hap["Size"][1][0],
                "mustrain": hap["Mustrain"],
                "shift": hist.data["Sample Parameters"]["Shift"][0],
                "cell": phase.get_cell(),
                "frozen": {
                    key: [str(item) for item in value]
                    for key, value in project.data["Controls"]["data"].get("parmFrozen", {}).items()
                },
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
for trial in sys.argv[1:] or list(STARTS):
    run(trial)
