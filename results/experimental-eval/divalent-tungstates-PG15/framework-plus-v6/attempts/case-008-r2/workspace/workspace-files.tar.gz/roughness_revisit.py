from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "shl_constrained_0p070.gpx"
VALUES = [0.05, 0.10, 0.20, 0.30, 0.40, 0.50]


def run(a_value):
    tag = f"{a_value:.2f}".replace(".", "p")
    out = ROOT / ".tmp" / f"roughness_revisit_{tag}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 28)
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["Polariz."][1:3] = [0.5, False]
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [float(a_value), False]
    sample["SurfRoughB"][1] = True
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    project.refine(makeBack=False)
    project.save()
    hap = phase.data["Histograms"][hist.name]
    print(
        json.dumps(
            {
                "A": a_value,
                "B": sample["SurfRoughB"][0],
                "Rwp": hist.get_wR(),
                "MD": hap["Pref.Ori."],
                "coordinates": {atom.label: list(atom.coordinates) for atom in phase.atoms()},
                "frozen": {
                    key: [str(item) for item in vals]
                    for key, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()
                },
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
values = [float(item) for item in sys.argv[1:]] or VALUES
for value in values:
    run(value)
