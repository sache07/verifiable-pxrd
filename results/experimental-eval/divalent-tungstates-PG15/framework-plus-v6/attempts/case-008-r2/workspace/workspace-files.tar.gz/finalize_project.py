from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_stage_a_converged.gpx"
FINAL = ROOT / "final.gpx"
EXPORTS = [ROOT / "phase_1_MnWO4.cif", ROOT / "phase_2_WO3.cif"]


G2.SetPrintLevel("warn")
project = G2.G2Project(str(SOURCE), newgpx=str(FINAL))
project.data["Controls"]["data"]["parmFrozen"] = {}
project.set_Controls("cycles", 0)
project.refine(makeBack=False)
project.save()

# Export exactly the saved full-precision atom records. Clearing covariance in
# memory mirrors the verifier and prevents a stale parameter vector from being
# substituted during CIF serialization; the GPX itself is not changed here.
project = G2.G2Project(str(FINAL))
project.data["Covariance"]["data"] = {}
for phase, destination in zip(project.phases(), EXPORTS):
    phase.export_CIF(str(destination))

hist = project.histogram(0)
print(
    json.dumps(
        {
            "project": str(FINAL),
            "histogram": hist.name,
            "saved_Rwp": hist.get_wR(),
            "frozen": project.data["Controls"]["data"].get("parmFrozen", {}),
            "exports": [str(path) for path in EXPORTS],
            "phases": [phase.name for phase in project.phases()],
        },
        indent=2,
    )
)
