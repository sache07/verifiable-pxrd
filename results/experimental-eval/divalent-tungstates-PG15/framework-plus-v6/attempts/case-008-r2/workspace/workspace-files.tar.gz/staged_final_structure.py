from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
START = ROOT / ".tmp" / "uiso_scale_p1_0p0110.gpx"


def replay(path: Path) -> G2.G2Project:
    project = G2.G2Project(str(path))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save()
    return G2.G2Project(str(path))


def report(stage: str, project: G2.G2Project) -> None:
    hist = project.histogram(0)
    print(
        json.dumps(
            {
                "stage": stage,
                "Rwp": hist.get_wR(),
                "shift": hist.data["Sample Parameters"]["Shift"],
                "roughness_B": hist.data["Sample Parameters"]["SurfRoughB"],
                "phases": {
                    phase.name: {
                        "cell": phase.data["General"]["Cell"],
                        "scale": phase.data["Histograms"][hist.name]["Scale"],
                        "size": phase.data["Histograms"][hist.name]["Size"],
                        "MD": phase.data["Histograms"][hist.name]["Pref.Ori."],
                        "atoms": {
                            atom.label: {
                                "xyz": list(atom.coordinates),
                                "Uiso": atom.uiso,
                                "flags": atom.refinement_flags,
                            }
                            for atom in phase.atoms()
                        },
                    }
                    for phase in project.phases()
                },
                "frozen": {
                    key: [str(item) for item in values]
                    for key, values in project.data["Controls"]["data"].get(
                        "parmFrozen", {}
                    ).items()
                },
            },
            default=float,
        ),
        flush=True,
    )


def branch(source: Path, destination: Path) -> G2.G2Project:
    project = G2.G2Project(str(source), newgpx=str(destination))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    return project


G2.SetPrintLevel("warn")

# Stage A: common background, both phase scales and cells, one specimen shift,
# and the retained one-parameter surface correction.
stage_a = ROOT / ".tmp" / "final_stage_a_nuisance.gpx"
project = branch(START, stage_a)
hist = project.histogram(0)
hist.data["Background"][0][1] = True
hist.data["Sample Parameters"]["Shift"][1] = True
hist.data["Sample Parameters"]["SurfRoughB"][1] = True
for phase in project.phases():
    phase.data["General"]["Cell"][0] = True
    phase.data["Histograms"][hist.name]["Scale"][1] = True
project.set_Controls("cycles", 40)
project.refine(makeBack=False)
project.save()
project = replay(stage_a)
report("nuisance_cells_scales", project)

# Stage B: the supported MnWO4 common crystallite-size and [001] March-Dollase
# terms. The minor phase retains the common width and neutral texture.
stage_b = ROOT / ".tmp" / "final_stage_b_profile.gpx"
project = branch(stage_a, stage_b)
hist = project.histogram(0)
main_hap = project.phase(0).data["Histograms"][hist.name]
main_hap["Size"][2] = [True, False, False]
main_hap["Pref.Ori."][2] = True
project.set_Controls("cycles", 40)
project.refine(makeBack=False)
project.save()
project = replay(stage_b)
report("main_size_texture", project)

# Stage C: main-phase atomic coordinates. WO3 internal coordinates remain at
# the physically screened neutron model until challenged separately.
stage_c = ROOT / ".tmp" / "final_stage_c_main_coords.gpx"
project = branch(stage_b, stage_c)
for atom in project.phase(0).atoms():
    atom.refinement_flags = "X"
project.set_Controls("cycles", 52)
project.refine(makeBack=False)
project.save()
project = replay(stage_c)
report("main_coordinates", project)
