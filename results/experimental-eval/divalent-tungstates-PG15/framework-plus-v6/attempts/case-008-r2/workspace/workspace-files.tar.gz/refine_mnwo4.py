from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SEED_CIF = ROOT / ".tmp" / "pool" / "models" / "mnwo4_cod_1520200.cif"
WORK_GPX = ROOT / ".tmp" / "mnwo4_work.gpx"


def values(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hap = phase.data["Histograms"][hist.name]
    residual = hist.data["data"][0]
    row = {
        "stage": label,
        "Rwp": hist.get_wR(),
        "GOF": residual.get("GOF"),
        "Nobs": residual.get("Nobs"),
        "cell": phase.get_cell(),
        "instrument": {key: inst[key][1] for key in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]},
        "sample": {key: sample[key][0] for key in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]},
        "background": hist.data["Background"][0][3:],
        "phase_scale": hap["Scale"][0],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(atom.coordinates),
                "occupancy": atom.occupancy,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }
    print(json.dumps(row, indent=2, default=float), flush=True)
    project.save(str(ROOT / ".tmp" / f"stage_{label}.gpx"))
    project.save(str(WORK_GPX))


def run_refinement(project, label):
    project.refine(makeBack=False)
    values(project, label)


G2.SetPrintLevel("warn")
project = G2.G2Project(newgpx=str(WORK_GPX))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma",
)
phase = project.add_phase(
    str(SEED_CIF), phasename="MnWO4", histograms=[hist], fmthint="CIF"
)
project.set_Controls("cycles", 12)

# Keep a single meaningful scale. Start with no phase-specific broadening.
hist.data["Sample Parameters"]["Scale"] = [1.0, False]
hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
hist.data["Sample Parameters"]["Shift"] = [-300.0, False]
hap = phase.data["Histograms"][hist.name]
hap["Scale"] = [50.0, True]
hap["Size"][0] = "isotropic"
hap["Size"][1] = [1000.0, 1000.0, 1.0]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1] = [0.0, 0.0, 1.0]
hap["Mustrain"][2] = [False, False, False]
hap["Pref.Ori."][0] = "MD"
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = False
hap["Extinction"] = [0.0, False]

# Smooth background: enough flexibility for a monotone low-angle tail, while
# remaining far broader than any Bragg peak.
hist.set_refinements(
    {
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 8,
            "coeffs": [900.0, -250.0, 250.0, -150.0, 100.0, -60.0, 30.0, -10.0],
            "refine": True,
        }
    }
)
run_refinement(project, "01_scale_background")

# One physical angular correction, represented as Bragg-Brentano specimen shift.
hist.set_refinements({"Sample Parameters": ["Shift"]})
run_refinement(project, "02_shift")

# Refine the P2/c metric after the angular correction is stable.
phase.set_refinements({"Cell": True})
run_refinement(project, "03_cell")

# Establish the common instrumental width and asymmetry model.
hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
run_refinement(project, "04_uwx")

hist.set_refinements({"Instrument Parameters": ["SH/L"]})
run_refinement(project, "05_asymmetry")

