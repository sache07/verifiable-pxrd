from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "watch_wo3_2311041.gpx"
OUT = ROOT / ".tmp" / "two_phase_cell.gpx"


G2.SetPrintLevel("warn")
project = G2.G2Project(str(BASE), newgpx=str(OUT))
project.data["Controls"]["data"]["parmFrozen"] = {}
project.set_Controls("cycles", 36)
hist = project.histogram(0)
main, minor = project.phases()

# Rebuild the phase-position model after accepting the second phase. Both
# scales, the common zero/displacement term, background, and the main phase
# cell were already active in the accepted one-phase baseline.
minor.data["General"]["Cell"][0] = True
main.data["Histograms"][hist.name]["Scale"][1] = True
minor.data["Histograms"][hist.name]["Scale"][1] = True
hist.data["Sample Parameters"]["Shift"][1] = True
hist.data["Background"][0][1] = True
project.refine(makeBack=False)
project.save()

# Exact project replay.
project = G2.G2Project(str(OUT))
project.data["Controls"]["data"]["parmFrozen"] = {}
project.set_Controls("cycles", 0)
project.refine(makeBack=False)
project.save()
hist = project.histogram(0)
details = {}
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    details[phase.name] = {
        "cell": phase.data["General"]["Cell"][1:7],
        "scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "MD": hap["Pref.Ori."],
    }
print(
    json.dumps(
        {
            "Rwp": hist.get_wR(),
            "phases": details,
            "shift": hist.data["Sample Parameters"]["Shift"],
            "roughness": {
                key: hist.data["Sample Parameters"][key]
                for key in ["SurfRoughA", "SurfRoughB"]
            },
            "frozen": {
                key: [str(item) for item in values]
                for key, values in project.data["Controls"]["data"].get(
                    "parmFrozen", {}
                ).items()
            },
        },
        default=float,
    )
)
