from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "roughgrid_A0p10.gpx"
TRIALS = {
    "base": {},
    "shl": {"shl": True},
    "isostrain": {"strain": "isotropic"},
    "unistrain001": {"strain": "uniaxial", "axis": [0, 0, 1]},
    "unistrain100": {"strain": "uniaxial", "axis": [1, 0, 0]},
    "unistrain010": {"strain": "uniaxial", "axis": [0, 1, 0]},
}


def run(name):
    options = TRIALS[name]
    out = ROOT / ".tmp" / f"rough_profile_{name}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 24)
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    hap = phase.data["Histograms"][hist.name]
    inst["SH/L"][2] = bool(options.get("shl"))

    strain = options.get("strain")
    if strain == "isotropic":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2] = [True, False, False]
    elif strain == "uniaxial":
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = options["axis"]
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]

    for variable, minimum, maximum in [
        (":0:SH/L", 0.005, 0.10),
        ("0:0:Mustrain;i", 0.0, 8000.0),
        ("0:0:Mustrain;a", 0.0, 32000.0),
    ]:
        project.set_Controls("parmMin", minimum, variable=variable)
        project.set_Controls("parmMax", maximum, variable=variable)
    project.refine(makeBack=False)
    project.save()
    sample = hist.data["Sample Parameters"]
    print(
        json.dumps(
            {
                "trial": name,
                "Rwp": hist.get_wR(),
                "SH/L": inst["SH/L"],
                "mustrain": hap["Mustrain"],
                "W": inst["W"][1],
                "size_um": hap["Size"][1][0],
                "roughness": {key: sample[key] for key in ["SurfRoughA", "SurfRoughB"]},
                "coordinates": {atom.label: list(atom.coordinates) for atom in phase.atoms()},
                "frozen": {
                    key: [str(item) for item in value]
                    for key, value in project.data["Controls"]["data"].get("parmFrozen", {}).items()
                },
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
for trial in sys.argv[1:] or list(TRIALS):
    run(trial)
