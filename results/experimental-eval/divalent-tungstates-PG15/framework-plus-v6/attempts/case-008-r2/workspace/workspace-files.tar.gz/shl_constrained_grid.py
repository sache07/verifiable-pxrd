from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "clean_profile.gpx"
VALUES = [0.040, 0.045, 0.050, 0.055, 0.060, 0.065, 0.070, 0.075, 0.080, 0.085, 0.090]


def frozen_names(project):
    return [str(item) for item in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])]


def run(value):
    tag = f"{value:.3f}".replace(".", "p")
    out = ROOT / ".tmp" / f"shl_constrained_{tag}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 28)
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    hap = phase.data["Histograms"][hist.name]
    inst["SH/L"][1:3] = [float(value), False]
    inst["U"][2] = True
    inst["W"][2] = True
    hap["Size"][2] = [True, False, False]
    fixed_at_bound = []
    for _ in range(4):
        project.refine(makeBack=False)
        names = frozen_names(project)
        if not names:
            break
        for name in names:
            if name.endswith(":U"):
                inst["U"][2] = False
            elif name.endswith(":W"):
                inst["W"][2] = False
            elif name.endswith("Size;i"):
                hap["Size"][2][0] = False
            else:
                raise RuntimeError(f"unexpected frozen parameter {name}")
            fixed_at_bound.append(name)
        project.data["Controls"]["data"]["parmFrozen"] = {}
    project.save()
    print(
        json.dumps(
            {
                "SH/L": value,
                "Rwp": hist.get_wR(),
                "U": inst["U"][1],
                "U_refine": inst["U"][2],
                "W": inst["W"][1],
                "W_refine": inst["W"][2],
                "size_um": hap["Size"][1][0],
                "size_refine": hap["Size"][2][0],
                "shift": hist.data["Sample Parameters"]["Shift"][0],
                "fixed_at_bound": fixed_at_bound,
                "remaining_frozen": frozen_names(project),
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
values = [float(item) for item in sys.argv[1:]] or VALUES
for value in values:
    run(value)
