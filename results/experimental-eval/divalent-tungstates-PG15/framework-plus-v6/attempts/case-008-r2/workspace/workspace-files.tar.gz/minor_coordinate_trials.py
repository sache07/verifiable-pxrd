from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "final_stage_a_nuisance.gpx"


def run(mode: str) -> None:
    out = ROOT / ".tmp" / f"minor_coords_{mode}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    minor = project.phase(1)
    for atom in minor.atoms():
        atom.refinement_flags = "X" if mode == "all" or atom.element == "W" else ""
    project.set_Controls("cycles", 64)
    project.refine(makeBack=False)
    covariance = project.data.get("Covariance", {}).get("data", {})
    sigmas = {
        str(name): float(sigma)
        for name, sigma in zip(
            covariance.get("varyList", []), covariance.get("sig", [])
        )
        if str(name).startswith("1::")
    }
    project.save()

    project = G2.G2Project(str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    minor = project.phase(1)
    print(
        json.dumps(
            {
                "mode": mode,
                "Rwp": hist.get_wR(),
                "coordinates": {
                    atom.label: {
                        "element": atom.element,
                        "xyz": list(atom.coordinates),
                        "flags": atom.refinement_flags,
                    }
                    for atom in minor.atoms()
                },
                "coordinate_esds": sigmas,
                "frozen": {
                    key: [str(item) for item in values]
                    for key, values in project.data["Controls"]["data"].get(
                        "parmFrozen", {}
                    ).items()
                },
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
for item in sys.argv[1:] or ["W", "all"]:
    run(item)
