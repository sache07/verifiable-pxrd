from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "minor_profile_common.gpx"
VALUES = [0.003, 0.005, 0.008, 0.012, 0.016, 0.020]


def fractions(project: G2.G2Project, hist_name: str) -> dict[str, float]:
    phases = project.phases()
    weights = np.asarray(
        [
            phase.data["Histograms"][hist_name]["Scale"][0]
            * phase.data["General"]["Mass"]
            for phase in phases
        ],
        dtype=float,
    )
    weights /= weights.sum()
    return {phase.name: float(value) for phase, value in zip(phases, weights)}


def run(phase_index: int, value: float) -> None:
    tag = f"{value:.4f}".replace(".", "p")
    out = ROOT / ".tmp" / f"uiso_scale_p{phase_index}_{tag}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    hist = project.histogram(0)

    # Freeze every nonlinear/nuisance term and condition the ADP comparison
    # only on the two linear phase scales.
    hist.data["Background"][0][1] = False
    sample = hist.data["Sample Parameters"]
    for name in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
        if isinstance(sample.get(name), list) and len(sample[name]) > 1:
            sample[name][1] = False
    for item in hist.data["Instrument Parameters"][0].values():
        if isinstance(item, list) and len(item) > 2 and isinstance(item[2], bool):
            item[2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False

    if phase_index == 1:
        for atom in project.phase(0).atoms():
            atom.uiso = 0.0052
    for atom in project.phase(phase_index).atoms():
        atom.uiso = float(value)
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    project.save()

    project = G2.G2Project(str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    print(
        json.dumps(
            {
                "phase_index": phase_index,
                "Uiso_A2": value,
                "Rwp": hist.get_wR(),
                "fractions": fractions(project, hist.name),
                "scales": {
                    phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
                    for phase in project.phases()
                },
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
phase_index = int(sys.argv[1])
values = [float(item) for item in sys.argv[2:]] or VALUES
for uiso in values:
    run(phase_index, uiso)
