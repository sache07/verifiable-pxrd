from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "fixedrough_texture_001.gpx"
VALUES = [0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60]


def run(a_value):
    tag = f"{a_value:.2f}".replace(".", "p")
    out = ROOT / ".tmp" / f"roughgrid_A{tag}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 24)
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [float(a_value), False]
    sample["SurfRoughB"] = [0.10, True]
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    project.refine(makeBack=False)
    project.save()
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    frozen = {
        key: [str(item) for item in value]
        for key, value in project.data["Controls"]["data"].get("parmFrozen", {}).items()
    }
    print(
        json.dumps(
            {
                "A": a_value,
                "B": sample["SurfRoughB"][0],
                "Rwp": hist.get_wR(),
                "MD": hap["Pref.Ori."],
                "size_um": hap["Size"][1][0],
                "coordinates": {atom.label: list(atom.coordinates) for atom in phase.atoms()},
                "frozen": frozen,
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
values = [float(item) for item in sys.argv[1:]] or VALUES
for value in values:
    run(value)
