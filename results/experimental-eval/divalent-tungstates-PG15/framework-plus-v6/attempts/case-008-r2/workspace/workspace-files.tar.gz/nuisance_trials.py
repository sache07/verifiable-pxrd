from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "texture_110.gpx"
TRIALS = {
    "base": {},
    "shl": {"shl": True},
    "rough": {"rough": True},
    "isostrain": {"strain": "isotropic"},
    "unistrain001": {"strain": "uniaxial", "axis": [0, 0, 1]},
    "unistrain100": {"strain": "uniaxial", "axis": [1, 0, 0]},
    "unistrain010": {"strain": "uniaxial", "axis": [0, 1, 0]},
}


def set_bounds(project):
    for variable, minimum, maximum in [
        (":0:SH/L", 0.005, 0.10),
        (":0:SurfRoughA", 0.05, 0.60),
        (":0:SurfRoughB", 0.02, 0.50),
        ("0:0:Mustrain;i", 0.0, 8000.0),
        ("0:0:Mustrain;a", 0.0, 32000.0),
    ]:
        project.set_Controls("parmMin", minimum, variable=variable)
        project.set_Controls("parmMax", maximum, variable=variable)


def run(name):
    options = TRIALS[name]
    out = ROOT / ".tmp" / f"nuisance_{name}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 20)
    set_bounds(project)
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hap = phase.data["Histograms"][hist.name]

    inst["SH/L"][2] = bool(options.get("shl"))
    if options.get("rough"):
        sample["SurfRoughA"] = [0.30, True]
        sample["SurfRoughB"] = [0.10, True]
    else:
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.0, False]

    strain = options.get("strain")
    if strain == "isotropic":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2] = [True, False, False]
    elif strain == "uniaxial":
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = options["axis"]
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]

    project.refine(makeBack=False)
    project.save()
    result = {
        "trial": name,
        "Rwp": hist.get_wR(),
        "SH/L": inst["SH/L"],
        "roughness": {key: sample[key] for key in ["SurfRoughA", "SurfRoughB"]},
        "mustrain": hap["Mustrain"],
        "W": inst["W"][1],
        "size_um": hap["Size"][1][0],
        "MD": hap["Pref.Ori."],
        "coordinates": {atom.label: list(atom.coordinates) for atom in phase.atoms()},
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }
    print(json.dumps(result, default=float), flush=True)


G2.SetPrintLevel("warn")
for trial in sys.argv[1:] or list(TRIALS):
    run(trial)
