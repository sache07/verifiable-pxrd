from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "two_phase_shl_fine_0p069.gpx"
TRIALS = ["common", "size", "strain"]


def frozen_names(project: G2.G2Project) -> list[str]:
    return [
        str(item)
        for item in project.data["Controls"]["data"]
        .get("parmFrozen", {})
        .get("FrozenList", [])
    ]


def run(trial: str) -> None:
    out = ROOT / ".tmp" / f"minor_profile_{trial}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 52)
    hist = project.histogram(0)
    minor_hap = project.phase(1).data["Histograms"][hist.name]
    minor_hap["Size"][2] = [False, False, False]
    minor_hap["Mustrain"][2] = [False, False, False]
    if trial == "size":
        minor_hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.04, variable="1:0:Size;i")
        project.set_Controls("parmMax", 1.50, variable="1:0:Size;i")
    elif trial == "strain":
        minor_hap["Mustrain"][1][0:2] = [500.0, 500.0]
        minor_hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 300.0, variable="1:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable="1:0:Mustrain;i")
    elif trial != "common":
        raise ValueError(trial)
    project.refine(makeBack=False)
    fixed_at_bound = []
    for name in frozen_names(project):
        if name == "1:0:Size;i":
            minor_hap["Size"][2][0] = False
        elif name == "1:0:Mustrain;i":
            minor_hap["Mustrain"][2][0] = False
        else:
            raise RuntimeError(f"unexpected frozen variable {name}")
        fixed_at_bound.append(name)
    if fixed_at_bound:
        project.data["Controls"]["data"]["parmFrozen"] = {}
        project.refine(makeBack=False)
    project.save()

    project = G2.G2Project(str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    minor_hap = project.phase(1).data["Histograms"][hist.name]
    print(
        json.dumps(
            {
                "trial": trial,
                "Rwp": hist.get_wR(),
                "minor_size": minor_hap["Size"],
                "minor_mustrain": minor_hap["Mustrain"],
                "fixed_at_bound": fixed_at_bound,
                "frozen": {
                    key: [str(item) for item in values]
                    for key, values in project.data["Controls"]["data"].get(
                        "parmFrozen", {}
                    ).items()
                },
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
for item in sys.argv[1:] or TRIALS:
    run(item)
