from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "minor_profile_common.gpx"
VALUES = [0.003, 0.005, 0.008, 0.012, 0.016, 0.020]


def fractions(project: G2.G2Project, hist_name: str) -> dict[str, float]:
    phases = project.phases()
    weights = np.asarray(
        [
            phase.data["Histograms"][hist_name]["Scale"][0]
            * phase.data["General"]["Mass"]
            for phase in phases
        ],
        dtype=float,
    )
    weights /= weights.sum()
    return {phase.name: float(value) for phase, value in zip(phases, weights)}


def run(phase_index: int, value: float) -> None:
    tag = f"{value:.4f}".replace(".", "p")
    out = ROOT / ".tmp" / f"uiso_p{phase_index}_{tag}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 52)
    for atom in project.phase(phase_index).atoms():
        atom.uiso = float(value)
        atom.refinement_flags = atom.refinement_flags.replace("U", "")
    project.refine(makeBack=False)
    project.save()

    project = G2.G2Project(str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    print(
        json.dumps(
            {
                "phase_index": phase_index,
                "Uiso_A2": value,
                "Rwp": hist.get_wR(),
                "fractions": fractions(project, hist.name),
                "coordinates": {
                    phase.name: {
                        atom.label: list(atom.coordinates) for atom in phase.atoms()
                    }
                    for phase in project.phases()
                },
                "frozen": {
                    key: [str(item) for item in values]
                    for key, values in project.data["Controls"]["data"].get(
                        "parmFrozen", {}
                    ).items()
                },
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
phase_index = int(sys.argv[1])
values = [float(item) for item in sys.argv[2:]] or VALUES
for uiso in values:
    run(phase_index, uiso)
