from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


project_path = Path(sys.argv[1])
output_path = Path(sys.argv[2])
project = G2.G2Project(str(project_path), newgpx=str(output_path.with_suffix(".replay.gpx")))
project.set_Controls("cycles", 0)
project.refine(makeBack=False)
hist = project.histogram(0)
data = hist.data["data"][1]
array = np.column_stack([data[0], data[1], data[3], data[4], data[5]])
np.savetxt(
    output_path,
    array,
    delimiter=",",
    header="two_theta_deg,observed,calculated,background,difference",
    comments="",
)
print("replayed_Rwp", hist.get_wR())
for phase_name, refs in hist.reflections().items():
    path = output_path.with_name(output_path.stem + "_" + phase_name + "_reflections.csv")
    np.savetxt(path, refs["RefList"], delimiter=",")
