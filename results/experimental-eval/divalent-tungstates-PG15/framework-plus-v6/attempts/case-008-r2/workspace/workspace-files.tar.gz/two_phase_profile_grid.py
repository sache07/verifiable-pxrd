from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "two_phase_cell.gpx"
VALUES = [0.055, 0.060, 0.065, 0.070, 0.075, 0.080, 0.085]


def frozen_names(project: G2.G2Project) -> list[str]:
    return [
        str(item)
        for item in project.data["Controls"]["data"]
        .get("parmFrozen", {})
        .get("FrozenList", [])
    ]


def run(value: float) -> None:
    tag = f"{value:.3f}".replace(".", "p")
    out = ROOT / ".tmp" / f"two_phase_profile_{tag}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 32)
    hist = project.histogram(0)
    main = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    main_hap = main.data["Histograms"][hist.name]
    inst["SH/L"][1:3] = [float(value), False]
    inst["U"][2] = True
    inst["W"][2] = True
    main_hap["Size"][2] = [True, False, False]
    fixed_at_bound = []
    for _ in range(5):
        project.refine(makeBack=False)
        names = frozen_names(project)
        if not names:
            break
        for name in names:
            if name.endswith(":U"):
                inst["U"][2] = False
            elif name.endswith(":W"):
                inst["W"][2] = False
            elif name.endswith("Size;i") and name.startswith("0:0:"):
                main_hap["Size"][2][0] = False
            else:
                raise RuntimeError(f"unexpected frozen parameter {name}")
            fixed_at_bound.append(name)
        project.data["Controls"]["data"]["parmFrozen"] = {}
    project.save()

    project = G2.G2Project(str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    main_hap = project.phase(0).data["Histograms"][hist.name]
    inst = hist.data["Instrument Parameters"][0]
    print(
        json.dumps(
            {
                "SH/L": value,
                "Rwp": hist.get_wR(),
                "U": inst["U"],
                "W": inst["W"],
                "X": inst["X"],
                "main_size_um": main_hap["Size"][1][0],
                "main_size_refine": main_hap["Size"][2][0],
                "shift": hist.data["Sample Parameters"]["Shift"],
                "fixed_at_bound": fixed_at_bound,
                "remaining_frozen": frozen_names(project),
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
for item in sys.argv[1:] or VALUES:
    run(float(item))
