from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "u_profile_2p0.gpx"
OUT = ROOT / ".tmp" / "clean_profile.gpx"

G2.SetPrintLevel("warn")
project = G2.G2Project(str(BASE), newgpx=str(OUT))
project.data["Controls"]["data"]["parmFrozen"] = {}
project.set_Controls("cycles", 32)
hist = project.histogram(0)
phase = project.phase(0)
inst = hist.data["Instrument Parameters"][0]
hap = phase.data["Histograms"][hist.name]

# The released strain terms collapsed below the laboratory's active range;
# remove them and retain the supported Gaussian U and isotropic-size terms.
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = 0.0
hap["Mustrain"][1][1] = 0.0
hap["Mustrain"][2] = [False, False, False]
inst["U"][2] = True
inst["W"][2] = True
hap["Size"][2] = [True, False, False]
project.refine(makeBack=False)
project.save()

print(
    json.dumps(
        {
            "Rwp": hist.get_wR(),
            "instrument": {key: inst[key][1] for key in ["U", "W", "X", "SH/L", "Polariz."]},
            "size_um": hap["Size"][1][0],
            "mustrain": hap["Mustrain"],
            "MD": hap["Pref.Ori."],
            "cell": phase.get_cell(),
            "shift": hist.data["Sample Parameters"]["Shift"][0],
            "roughness": {key: hist.data["Sample Parameters"][key] for key in ["SurfRoughA", "SurfRoughB"]},
            "coordinates": {atom.label: list(atom.coordinates) for atom in phase.atoms()},
            "frozen": project.data["Controls"]["data"].get("parmFrozen", {}),
        },
        default=float,
        indent=2,
    )
)
