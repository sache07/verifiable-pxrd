from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "clean_profile.gpx"
VALUES = [0.005, 0.010, 0.020, 0.030, 0.050, 0.080, 0.100]


def run(value):
    tag = f"{value:.3f}".replace(".", "p")
    out = ROOT / ".tmp" / f"shl_{tag}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 28)
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["SH/L"][1:3] = [float(value), False]
    project.refine(makeBack=False)
    project.save()
    hap = phase.data["Histograms"][hist.name]
    print(
        json.dumps(
            {
                "SH/L": value,
                "Rwp": hist.get_wR(),
                "shift": hist.data["Sample Parameters"]["Shift"][0],
                "U": inst["U"][1],
                "W": inst["W"][1],
                "size_um": hap["Size"][1][0],
                "cell": phase.get_cell(),
                "frozen": {
                    key: [str(item) for item in vals]
                    for key, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()
                },
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
values = [float(item) for item in sys.argv[1:]] or VALUES
for value in values:
    run(value)
