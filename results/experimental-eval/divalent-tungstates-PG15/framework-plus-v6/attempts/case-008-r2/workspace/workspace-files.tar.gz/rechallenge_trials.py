from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "final_stage_a_nuisance.gpx"
MODEL_DIR = ROOT / ".tmp" / "watch_pool" / "models"
CANDIDATES = {
    "mno_1514108": MODEL_DIR / "mno_cod_1514108.cif",
    "mno_1514231": MODEL_DIR / "mno_cod_1514231.cif",
    "mn3wo6_2002703": MODEL_DIR / "mn3wo6_cod_2002703.cif",
    "mn3o4_1541183": MODEL_DIR / "mn3o4_cod_1541183.cif",
}


def fractions(project: G2.G2Project, hist_name: str) -> dict[str, float]:
    phases = project.phases()
    weights = np.asarray(
        [
            max(0.0, phase.data["Histograms"][hist_name]["Scale"][0])
            * phase.data["General"]["Mass"]
            for phase in phases
        ],
        dtype=float,
    )
    weights /= weights.sum()
    return {phase.name: float(value) for phase, value in zip(phases, weights)}


def scale_esd(project: G2.G2Project, variable: str) -> float | None:
    data = project.data.get("Covariance", {}).get("data", {})
    names = [str(item) for item in data.get("varyList", [])]
    if variable not in names:
        return None
    return float(data.get("sig", [])[names.index(variable)])


def run(name: str) -> None:
    out = ROOT / ".tmp" / f"rechallenge_{name}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    hist = project.histogram(0)
    candidate = project.add_phase(
        str(CANDIDATES[name]),
        phasename=f"rechallenge_{name}",
        histograms=[hist],
        fmthint="CIF",
    )
    candidate.data["General"]["Cell"][0] = False
    hap = candidate.data["Histograms"][hist.name]
    common_size = project.phase(0).data["Histograms"][hist.name]["Size"][1][0]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0:2] = [common_size, common_size]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"] = [0.0, False]
    existing_weight = sum(
        phase.data["Histograms"][hist.name]["Scale"][0]
        * phase.data["General"]["Mass"]
        for phase in project.phases()[:2]
    )
    hap["Scale"] = [
        (0.003 / 0.997) * existing_weight / candidate.data["General"]["Mass"],
        True,
    ]
    variable = f"{candidate.data['pId']}:0:Scale"
    project.set_Controls("parmMin", 0.0, variable=variable)
    project.set_Controls("cycles", 40)
    project.refine(makeBack=False)
    esd = scale_esd(project, variable)
    frozen = {
        str(item)
        for values in project.data["Controls"]["data"].get("parmFrozen", {}).values()
        for item in values
    }
    at_zero = variable in frozen or hap["Scale"][0] <= 0.0
    if at_zero:
        hap["Scale"] = [0.0, False]
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    print(
        json.dumps(
            {
                "candidate": name,
                "Rwp": hist.get_wR(),
                "scale": project.phase(2).data["Histograms"][hist.name]["Scale"][0],
                "scale_esd": esd,
                "hit_zero": at_zero,
                "fractions": fractions(project, hist.name),
                "frozen": project.data["Controls"]["data"].get("parmFrozen", {}),
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
for item in sys.argv[1:] or list(CANDIDATES):
    run(item)
