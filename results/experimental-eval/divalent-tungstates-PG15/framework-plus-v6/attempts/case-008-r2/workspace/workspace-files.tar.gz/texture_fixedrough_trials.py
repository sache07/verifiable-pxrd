from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "nuisance_rough.gpx"
AXES = {
    "none": None,
    "001": [0, 0, 1],
    "100": [1, 0, 0],
    "010": [0, 1, 0],
    "110": [1, 1, 0],
    "111": [1, 1, 1],
}


def run(name):
    out = ROOT / ".tmp" / f"fixedrough_texture_{name}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    inst["Polariz."][1:3] = [0.5, False]
    sample["SurfRoughA"][1] = False
    sample["SurfRoughB"][1] = False
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = name != "none"
    if AXES[name] is not None:
        hap["Pref.Ori."][3] = AXES[name]
    project.set_Controls("parmMin", 0.7, variable="0:0:MD")
    project.set_Controls("parmMax", 1.4, variable="0:0:MD")
    project.refine(makeBack=False)
    project.save()
    print(
        json.dumps(
            {
                "trial": name,
                "Rwp": hist.get_wR(),
                "MD": hap["Pref.Ori."],
                "roughness": {key: sample[key] for key in ["SurfRoughA", "SurfRoughB"]},
                "size_um": hap["Size"][1][0],
                "W": inst["W"][1],
                "coordinates": {atom.label: list(atom.coordinates) for atom in phase.atoms()},
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
for trial in sys.argv[1:] or list(AXES):
    run(trial)
