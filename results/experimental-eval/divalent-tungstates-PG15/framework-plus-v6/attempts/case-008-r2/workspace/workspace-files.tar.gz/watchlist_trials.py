from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
# The backup is the clean one-phase replay made immediately before the
# exploratory add_phase call (which causes GSAS-II to autosave).
BASE = ROOT / ".tmp" / "texture_revisit_final_001.bak0.gpx"
MODEL_DIR = ROOT / ".tmp" / "watch_pool" / "models"
CANDIDATES = {
    "mno_1514108": MODEL_DIR / "mno_cod_1514108.cif",
    "mno_1514231": MODEL_DIR / "mno_cod_1514231.cif",
    "mn3wo6_2002703": MODEL_DIR / "mn3wo6_cod_2002703.cif",
    "wo3_1528915": MODEL_DIR / "wo3_cod_1528915.cif",
    "wo3_2106293": MODEL_DIR / "wo3_cod_2106293.cif",
    "mn3o4_1541183": MODEL_DIR / "mn3o4_cod_1541183.cif",
    "wo3_1004057": ROOT / ".tmp" / "wo3_pool" / "models" / "wo3_cod_1004057.cif",
    "wo3_1521532": ROOT / ".tmp" / "wo3_pool" / "models" / "wo3_cod_1521532.cif",
    "wo3_1521533": ROOT / ".tmp" / "wo3_pool" / "models" / "wo3_cod_1521533.cif",
    "wo3_2311041": ROOT / ".tmp" / "wo3_pool" / "models" / "wo3_cod_2311041.cif",
    "wo3_2107312": ROOT / ".tmp" / "wo3_pool" / "models" / "wo3_cod_2107312.cif",
}


def mass_fractions(project: G2.G2Project, hist_name: str) -> dict[str, float]:
    weights = []
    phases = project.phases()
    for phase in phases:
        hap = phase.data["Histograms"][hist_name]
        weights.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
    weights = np.maximum(np.asarray(weights, dtype=float), 0.0)
    total = float(np.sum(weights))
    return {
        phase.name: (float(weight / total) if total > 0 else 0.0)
        for phase, weight in zip(phases, weights)
    }


def covariance_esd(project: G2.G2Project, variable: str) -> float | None:
    data = project.data.get("Covariance", {}).get("data", {})
    vary = [str(item) for item in data.get("varyList", [])]
    sig = data.get("sig", [])
    if variable not in vary:
        return None
    index = vary.index(variable)
    return float(sig[index]) if index < len(sig) else None


def run(name: str, cif: Path) -> None:
    out = ROOT / ".tmp" / f"watch_{name}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    hist = project.histogram(0)
    main = project.phase(0)
    main_hap = main.data["Histograms"][hist.name]

    candidate = project.add_phase(
        str(cif), phasename=f"watch_{name}", histograms=[hist], fmthint="CIF"
    )
    candidate_hap = candidate.data["Histograms"][hist.name]
    candidate.data["General"]["Cell"][0] = False

    # Use the established common phase width without giving a weak candidate
    # extra size/strain/texture freedom.
    common_size = float(main_hap["Size"][1][0])
    candidate_hap["Size"][0] = "isotropic"
    candidate_hap["Size"][1][0:2] = [common_size, common_size]
    candidate_hap["Size"][2] = [False, False, False]
    candidate_hap["Mustrain"][0] = "isotropic"
    candidate_hap["Mustrain"][1][0:2] = [0.0, 0.0]
    candidate_hap["Mustrain"][2] = [False, False, False]
    candidate_hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    candidate_hap["Extinction"] = [0.0, False]

    # Start every challenge at 0.5 wt% relative to the current main phase.
    main_weight = float(main_hap["Scale"][0]) * float(main.data["General"]["Mass"])
    candidate_mass = float(candidate.data["General"]["Mass"])
    candidate_hap["Scale"] = [
        (0.005 / 0.995) * main_weight / candidate_mass,
        True,
    ]
    scale_var = f"{candidate.data['pId']}:0:Scale"
    project.set_Controls("parmMin", 0.0, variable=scale_var)
    project.set_Controls("cycles", 28)
    project.refine(makeBack=False)
    project.save()

    esd = covariance_esd(project, scale_var)
    frozen = {
        str(item)
        for values in project.data["Controls"]["data"].get("parmFrozen", {}).values()
        for item in values
    }
    hit_zero = scale_var in frozen or float(candidate_hap["Scale"][0]) <= 0.0
    if hit_zero:
        candidate_hap["Scale"] = [0.0, False]

    # Exact replay after any bound handling.
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    candidate = project.phase(1)
    candidate_hap = candidate.data["Histograms"][hist.name]
    print(
        json.dumps(
            {
                "candidate": name,
                "Rwp": hist.get_wR(),
                "scale": float(candidate_hap["Scale"][0]),
                "scale_esd_last_refinement": esd,
                "hit_nonnegative_bound": hit_zero,
                "mass_fractions": mass_fractions(project, hist.name),
                "cell": candidate.data["General"]["Cell"][1:7],
                "frozen_after_replay": {
                    key: [str(item) for item in values]
                    for key, values in project.data["Controls"]["data"].get(
                        "parmFrozen", {}
                    ).items()
                },
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
selected = sys.argv[1:] or list(CANDIDATES)
for item in selected:
    run(item, CANDIDATES[item])
