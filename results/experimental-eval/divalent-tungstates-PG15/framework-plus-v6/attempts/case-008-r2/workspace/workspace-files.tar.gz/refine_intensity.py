from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "trial_size.gpx"
OUT = ROOT / ".tmp" / "intensity_work.gpx"


def summary(project, stage):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    hap = phase.data["Histograms"][hist.name]
    atoms = []
    cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
    for record in phase.data["Atoms"]:
        atoms.append(
            {
                "label": record[ct - 1],
                "element": record[ct],
                "xyz": list(map(float, record[cx : cx + 3])),
                "occ": float(record[cx + 3]),
                "uiso": float(record[cia + 1]) if record[cia] == "I" else None,
                "flags": record[ct + 1],
            }
        )
    result = {
        "stage": stage,
        "Rwp": hist.get_wR(),
        "cell": phase.get_cell(),
        "shift": hist.data["Sample Parameters"]["Shift"][0],
        "instrument": {key: inst[key][1] for key in ["U", "W", "X", "SH/L", "Polariz."]},
        "size_um": hap["Size"][1][0],
        "strain_ppm": hap["Mustrain"][1][0],
        "scale": hap["Scale"][0],
        "atoms": atoms,
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }
    print(json.dumps(result, indent=2, default=float), flush=True)
    project.save(str(ROOT / ".tmp" / f"intensity_{stage}.gpx"))
    project.save(str(OUT))


def refine(project, stage):
    project.refine(makeBack=False)
    summary(project, stage)


G2.SetPrintLevel("warn")
project = G2.G2Project(str(BASE), newgpx=str(OUT))
project.set_Controls("cycles", 20)
phase = project.phase(0)
hist = project.histogram(0)

# The heavy-atom y coordinates dominate the structure factors.
phase.set_refinements({"Atoms": {"Mn0": "X", "W1": "X"}})
refine(project, "01_heavy_coordinates")

# Release the two crystallographically independent oxygen sites.
phase.set_refinements({"Atoms": {"O2": "X", "O3": "X"}})
refine(project, "02_all_coordinates")

# Polarization produces a coherent angle-dependent intensity trend and is
# independently bounded by the laboratory context.
hist.set_refinements({"Instrument Parameters": ["Polariz."]})
project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
refine(project, "03_polarization")

