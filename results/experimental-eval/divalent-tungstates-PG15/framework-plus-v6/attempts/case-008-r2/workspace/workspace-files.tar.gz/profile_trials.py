from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "stage_03_cell.gpx"


def configure(project, size=False, strain=False):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    for key, val in {"U": 10.0, "W": 10.0, "X": 1.0, "SH/L": 0.03}.items():
        inst[key][1] = val
        inst[key][2] = key in {"U", "W", "X"}
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.3 if size else 10.0
    hap["Size"][2] = [size, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0 if strain else 0.0
    hap["Mustrain"][2] = [strain, False, False]
    project.set_Controls("cycles", 20)
    for variable, minimum, maximum in [
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        ("0:0:Size;i", 0.04, 1.5),
        ("0:0:Mustrain;i", 0.0, 8000.0),
    ]:
        project.set_Controls("parmMin", minimum, variable=variable)
        project.set_Controls("parmMax", maximum, variable=variable)


def summarize(project, name):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    hap = phase.data["Histograms"][hist.name]
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "trial": name,
        "Rwp": hist.get_wR(),
        "instrument": {key: inst[key][1] for key in ["U", "W", "X", "SH/L"]},
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "cell": phase.get_cell(),
        "shift": hist.data["Sample Parameters"]["Shift"][0],
        "varyList": cov.get("varyList", []),
        "sig": list(map(float, cov.get("sig", []))),
    }


G2.SetPrintLevel("warn")
results = []
for name, size, strain in [
    ("instrument_only", False, False),
    ("size", True, False),
    ("strain", False, True),
    ("size_strain", True, True),
]:
    out = ROOT / ".tmp" / f"trial_{name}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    configure(project, size=size, strain=strain)
    project.refine(makeBack=False)
    project.save()
    results.append(summarize(project, name))
print(json.dumps(results, indent=2, default=float))
