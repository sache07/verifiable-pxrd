from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "finalprofile_texture_001.gpx"
STARTS = [0.1, 2.0, 10.0, 20.0, 35.0]


def run(u_start):
    tag = str(u_start).replace(".", "p")
    out = ROOT / ".tmp" / f"u_profile_{tag}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 32)
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1:3] = [float(u_start), True]
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMax", 40.0, variable=":0:U")
    project.refine(makeBack=False)
    project.save()
    hap = phase.data["Histograms"][hist.name]
    print(
        json.dumps(
            {
                "start": u_start,
                "Rwp": hist.get_wR(),
                "U": inst["U"][1],
                "W": inst["W"][1],
                "size_um": hap["Size"][1][0],
                "mustrain": hap["Mustrain"],
                "frozen": {
                    key: [str(item) for item in value]
                    for key, value in project.data["Controls"]["data"].get("parmFrozen", {}).items()
                },
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
starts = [float(item) for item in sys.argv[1:]] or STARTS
for value in starts:
    run(value)
