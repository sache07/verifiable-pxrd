from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "intensity_03_polarization.gpx"
AXES = {
    "none": None,
    "001": [0, 0, 1],
    "100": [1, 0, 0],
    "010": [0, 1, 0],
    "110": [1, 1, 0],
    "111": [1, 1, 1],
}


def run(name):
    out = ROOT / ".tmp" / f"texture_{name}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    # Instrument X and Lorentzian size are exactly correlated. Retain the
    # physically explicit phase-size term and fix X to a benign interior value.
    inst["U"][1:3] = [0.0, False]
    inst["X"][1:3] = [1.0, False]
    project.data["Controls"]["data"]["parmFrozen"] = {}
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][2] = [True, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = name != "none"
    if AXES[name] is not None:
        hap["Pref.Ori."][3] = AXES[name]
    project.set_Controls("cycles", 20)
    project.set_Controls("parmMin", 0.04, variable="0:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable="0:0:Size;i")
    project.set_Controls("parmMin", 0.7, variable="0:0:MD")
    project.set_Controls("parmMax", 1.4, variable="0:0:MD")
    project.refine(makeBack=False)
    project.save()
    result = {
        "trial": name,
        "Rwp": hist.get_wR(),
        "MD": hap["Pref.Ori."],
        "size_um": hap["Size"][1][0],
        "W": inst["W"][1],
        "X_fixed": inst["X"][1],
        "cell": phase.get_cell(),
        "shift": hist.data["Sample Parameters"]["Shift"][0],
        "coordinates": {atom.label: list(atom.coordinates) for atom in phase.atoms()},
    }
    print(json.dumps(result, default=float), flush=True)


G2.SetPrintLevel("warn")
names = sys.argv[1:] or list(AXES)
for item in names:
    run(item)
