from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "shl_constrained_0p070.gpx"
STARTS = [0.50, 0.60, 0.75, 0.90]


def run(start):
    tag = f"{start:.2f}".replace(".", "p")
    out = ROOT / ".tmp" / f"polarization_{tag}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 28)
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["Polariz."][1:3] = [float(start), True]
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.refine(makeBack=False)
    project.save()
    hap = phase.data["Histograms"][hist.name]
    print(
        json.dumps(
            {
                "start": start,
                "Rwp": hist.get_wR(),
                "polarization": inst["Polariz."],
                "MD": hap["Pref.Ori."],
                "roughness": {key: hist.data["Sample Parameters"][key] for key in ["SurfRoughA", "SurfRoughB"]},
                "frozen": {
                    key: [str(item) for item in vals]
                    for key, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()
                },
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
starts = [float(item) for item in sys.argv[1:]] or STARTS
for value in starts:
    run(value)
