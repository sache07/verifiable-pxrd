from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "rough_profile_unistrain100.gpx"
AXES = {
    "none": None,
    "001": [0, 0, 1],
    "100": [1, 0, 0],
    "010": [0, 1, 0],
    "110": [1, 1, 0],
    "111": [1, 1, 1],
}


def run(name):
    out = ROOT / ".tmp" / f"finalprofile_texture_{name}.gpx"
    project = G2.G2Project(str(BASE), newgpx=str(out))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 24)
    hist = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = name != "none"
    if AXES[name] is not None:
        hap["Pref.Ori."][3] = AXES[name]
    project.set_Controls("parmMin", 0.7, variable="0:0:MD")
    project.set_Controls("parmMax", 1.4, variable="0:0:MD")
    project.refine(makeBack=False)
    project.save()
    sample = hist.data["Sample Parameters"]
    print(
        json.dumps(
            {
                "trial": name,
                "Rwp": hist.get_wR(),
                "MD": hap["Pref.Ori."],
                "roughness": {key: sample[key] for key in ["SurfRoughA", "SurfRoughB"]},
                "mustrain": hap["Mustrain"],
                "coordinates": {atom.label: list(atom.coordinates) for atom in phase.atoms()},
                "frozen": {
                    key: [str(item) for item in value]
                    for key, value in project.data["Controls"]["data"].get("parmFrozen", {}).items()
                },
            },
            default=float,
        ),
        flush=True,
    )


G2.SetPrintLevel("warn")
for trial in sys.argv[1:] or list(AXES):
    run(trial)
