from __future__ import annotations

from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
with np.load(ROOT / ".tmp" / "replay_final" / "prediction.npz") as data:
    x = data["x"]
    observed = data["observed"]
    calculated = data["predicted"]

profile = np.column_stack([x, observed, calculated, observed - calculated])
np.savetxt(
    ROOT / "fit.csv",
    profile,
    delimiter=",",
    header="two_theta,observed,calculated,difference",
    comments="",
    fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
)
