from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "pool" / "models" / "mnwo4_cod_1520200.cif"

G2.SetPrintLevel("warn")
project = G2.G2Project(newgpx=str(ROOT / ".tmp" / "inspect.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma",
)
phase = project.add_phase(
    str(SOURCE), phasename="MnWO4", histograms=[hist], fmthint="CIF"
)
print("hist", hist.name)
print("instrument", hist.data["Instrument Parameters"])
print("sample", hist.data["Sample Parameters"])
print("background", hist.data["Background"])
print("limits", hist.data["Limits"])
print("phase general", phase.data["General"])
print("atoms")
for atom in phase.atoms():
    print(atom.label, atom.element, atom.coordinates, atom.occupancy, atom.refinement_flags)
print("HAP", phase.data["Histograms"][hist.name])
project.save()
