#!/usr/bin/env python3
"""Build and stage a GSAS-II trial refinement from a small JSON recipe."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def write_inputs(pattern: Path, outdir: Path, instrument: dict) -> tuple[Path, Path]:
    data = np.genfromtxt(pattern, delimiter=",", names=True)
    x = np.asarray(data["two_theta_deg"], float)
    y = np.asarray(data["intensity"], float)
    xye = outdir / "observed.xye"
    np.savetxt(xye, np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.8f %.8f %.8f")
    inst = outdir / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        f"Lam1:{instrument.get('Lam1', 1.540598)};Lam2:{instrument.get('Lam2', 1.544426)};"
        f"I(L2)/I(L1):{instrument.get('I(L2)/I(L1)', 0.5)}\n"
        f"Zero:{instrument.get('Zero', 0.0)};Polariz.:{instrument.get('Polariz.', 0.8)};Azimuth:0.0\n"
        f"U:{instrument.get('U', 10.0)};V:0.0;W:{instrument.get('W', 10.0)};"
        f"X:{instrument.get('X', 1.0)};Y:0.0;Z:0.0;SH/L:{instrument.get('SH/L', 0.02)}\n"
    )
    return xye, inst


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    phases = []
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "composition": phase.composition,
                "scale": list(hap["Scale"]),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    return {
        "stage": label,
        "residuals": hist.residuals,
        "instrument": {k: v for k, v in inst.items() if k in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "I(L2)/I(L1)"}},
        "sample": {k: sample.get(k) for k in ["Type", "Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"]},
        "background": hist.Background,
        "phases": phases,
        "vary_list": [str(v) for v in (project.get_VaryList() or [])],
    }


def sanitize_profile(project: G2.G2Project, profile_keys: list[str]) -> None:
    """Keep the common profile in the physical region before replay."""
    inst = project.histogram(0).InstrumentParameters
    bounds = {
        "U": (0.0, 80.0),
        "W": (0.05, 80.0),
        "X": (0.001, 12.0),
        "SH/L": (0.002, 0.2),
        "Polariz.": (0.0, 1.0),
        "I(L2)/I(L1)": (0.1, 1.0),
    }
    for key in profile_keys:
        if key in bounds and key in inst:
            lo, hi = bounds[key]
            inst[key][1] = min(hi, max(lo, float(inst[key][1])))


def set_bounds(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def run(config_path: Path) -> None:
    cfg = json.loads(config_path.read_text())
    outdir = Path(cfg["outdir"]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    xye, instfile = write_inputs(Path(cfg["pattern"]).resolve(), outdir, cfg.get("instrument", {}))

    G2.SetPrintLevel(cfg.get("print_level", "warn"))
    project = G2.G2Project(newgpx=str(outdir / "trial.gpx"))
    hist = project.add_powder_histogram(str(xye), str(instfile), fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({"Limits": [float(cfg.get("low", 9.90343322)), float(cfg.get("high", 100.09488522))]})
    nback = int(cfg.get("background_n", 8))
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": nback,
                "coeffs": [float(cfg.get("background_start", 800.0))] + [0.0] * (nback - 1),
                "refine": True,
            }
        }
    )

    phases = []
    for item in cfg["phases"]:
        phase = project.add_phase(
            str(Path(item["cif"]).resolve()), phasename=item["name"], histograms=[hist], fmthint="CIF"
        )
        phases.append(phase)
        phase.HAPvalue("Scale", float(item.get("scale_start", 0.1)), [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phase.setSampleProfile(hist, "size", "isotropic", float(item.get("size_start_um", 100.0)), LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", float(item.get("strain_start_ppm", 0.0)), LGmix=1.0)
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}, [hist])
        hap = phase.getHAPvalues(hist.name)
        hap["Extinction"] = [0.0, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]

    project.set_Controls("cycles", int(cfg.get("cycles", 8)))
    stages = []

    def refine(label: str) -> None:
        project.refine(makeBack=False)
        project.save()
        stages.append(snapshot(project, label))

    refine("background_scales")

    angular = cfg.get("angular", "Zero")
    if angular == "Zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        set_bounds(project, f":{hist.id}:Zero", -0.5, 0.5)
    elif angular == "Shift":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        set_bounds(project, f":{hist.id}:Shift", -1200.0, 1200.0)
    elif angular not in (None, "none"):
        raise ValueError(f"unknown angular correction {angular}")
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine("angular_cells")

    profile_keys = list(cfg.get("profile_keys", ["W", "X"]))
    if profile_keys:
        hist.set_refinements({"Instrument Parameters": profile_keys})
        profile_bounds = {
            "U": (0.0, 40.0),
            "W": (2.0, 40.0),
            "X": (0.1, 6.0),
            "SH/L": (0.005, 0.10),
            "Polariz.": (0.5, 1.0),
            "I(L2)/I(L1)": (0.25, 0.75),
        }
        for key in profile_keys:
            if key in profile_bounds:
                set_bounds(project, f":{hist.id}:{key}", *profile_bounds[key])
        refine("common_profile")

    for phase, item in zip(phases, cfg["phases"]):
        broadening = item.get("broadening", [])
        if isinstance(broadening, str):
            broadening = [broadening]
        if "size" in broadening:
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True, "value": float(item.get("size_refine_start_um", 0.5))}}, [hist])
            set_bounds(project, f"{phase.id}:{hist.id}:Size;i", 0.02, 20.0)
            refine(f"size_{phase.name}")
        if "strain" in broadening:
            phase.setSampleProfile(hist, "microstrain", "isotropic", float(item.get("strain_refine_start_ppm", 1000.0)), LGmix=1.0)
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
            set_bounds(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 12000.0)
            refine(f"strain_{phase.name}")

    for phase, item in zip(phases, cfg["phases"]):
        labels = item.get("coordinate_labels", [])
        if labels:
            phase.set_refinements({"Atoms": {label: "X" for label in labels}})
            refine(f"coordinates_{phase.name}")

    if cfg.get("refine_shl", False) and "SH/L" not in profile_keys:
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        set_bounds(project, f":{hist.id}:SH/L", 0.005, 0.10)
        refine("asymmetry")

    refine("replay_all")
    project.save(outdir / "trial.gpx")
    hist = project.histogram(0)
    try:
        mass_fracs = {k: list(v) for k, v in hist.ComputeMassFracs().items()}
    except Exception as exc:
        mass_fracs = {"error": repr(exc)}
    x = np.asarray(hist.getdata("X"), float)
    yo = np.asarray(hist.getdata("Yobs"), float)
    yc = np.asarray(hist.getdata("Ycalc"), float)
    bkg = np.asarray(hist.getdata("Background"), float)
    diff = yo - yc
    with (outdir / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
        writer.writerows(zip(x, yo, yc, diff, bkg))
    result = {
        "config": cfg,
        "stages": stages,
        "final": snapshot(project, "final"),
        "mass_fractions": mass_fracs,
    }
    (outdir / "diagnostics.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"residuals": hist.residuals, "mass_fractions": mass_fracs, "project": str(outdir / 'trial.gpx')}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("config", type=Path)
    run(parser.parse_args().config)
