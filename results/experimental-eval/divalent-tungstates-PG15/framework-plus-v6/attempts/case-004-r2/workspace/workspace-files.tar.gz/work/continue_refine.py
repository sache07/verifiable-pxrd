#!/usr/bin/env python3
"""Branch an existing GSAS-II project, apply controlled changes, and replay it."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def set_bounds(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def snap(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    out = {
        "residuals": hist.residuals,
        "frozen": project.get_Frozen(),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": {},
    }
    for phase in project.phases():
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "composition": phase.composition,
            "hap": phase.getHAPvalues(hist.name),
            "atoms": [
                {
                    "label": a.label,
                    "element": a.element,
                    "coordinates": list(a.coordinates),
                    "occupancy": a.occupancy,
                    "adp": a.ADP,
                    "flags": a.refinement_flags,
                }
                for a in phase.atoms()
            ],
        }
    try:
        out["mass_fractions"] = {k: list(v) for k, v in hist.ComputeMassFracs().items()}
    except Exception as exc:
        out["mass_fractions"] = {"error": repr(exc)}
    return out


def run(path: Path) -> None:
    cfg = json.loads(path.read_text())
    output = Path(cfg["output"]).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel(cfg.get("print_level", "warn"))
    project = G2.G2Project(gpxfile=str(Path(cfg["input"]).resolve()), newgpx=str(output))
    hist = project.histogram(cfg.get("histogram", 0))
    project.set_Controls("cycles", int(cfg.get("cycles", 12)))
    if "limits" in cfg:
        hist.set_refinements({"Limits": [float(cfg["limits"][0]), float(cfg["limits"][1])]})

    if cfg.get("clear_frozen", False):
        project.set_Frozen()

    # Add a watch-list phase to an already converged common profile.  Its
    # scale is constrained nonnegative so that a rejected candidate cannot
    # improve the fit by subtracting intensity.
    for item in cfg.get("add_phases", []):
        phase = project.add_phase(
            str(Path(item["cif"]).resolve()),
            phasename=item["name"],
            histograms=[hist],
            fmthint="CIF",
        )
        phase.HAPvalue("Scale", float(item.get("scale_start", 0.01)), [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phase.setSampleProfile(
            hist,
            "size",
            "isotropic",
            float(item.get("size_um", 0.1)),
            LGmix=1.0,
        )
        phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True},
            [hist],
        )
        phase.set_refinements({"Cell": bool(item.get("cell_refine", False))})
        hap = phase.getHAPvalues(hist.name)
        hap["Extinction"] = [0.0, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        if "uiso" in item:
            for atom in phase.atoms():
                if atom.adp_flag == "I":
                    atom.uiso = float(item["uiso"])
        set_bounds(
            project,
            f"{phase.id}:{hist.id}:Scale",
            0.0,
            float(item.get("scale_max", 100.0)),
        )

    inst = hist.InstrumentParameters
    for key, value in cfg.get("instrument_values", {}).items():
        inst[key][1] = float(value)
    if "instrument_refine" in cfg:
        keys = list(cfg["instrument_refine"])
        for key in inst:
            if isinstance(inst[key], list) and len(inst[key]) > 2 and key in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "I(L2)/I(L1)"}:
                inst[key][2] = key in keys
    for key, limits in cfg.get("instrument_bounds", {}).items():
        set_bounds(project, f":{hist.id}:{key}", float(limits[0]), float(limits[1]))
    for variable, limits in cfg.get("variable_bounds", {}).items():
        set_bounds(project, variable, float(limits[0]), float(limits[1]))

    if "sample_refine" in cfg:
        selected = set(cfg["sample_refine"])
        for key in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
            if key in hist.SampleParameters and isinstance(hist.SampleParameters[key], list):
                hist.SampleParameters[key][1] = key in selected
    for key, value in cfg.get("sample_values", {}).items():
        hist.SampleParameters[key][0] = float(value)

    for name, changes in cfg.get("phases", {}).items():
        phase = project.phase(name)
        if "cell_refine" in changes:
            phase.set_refinements({"Cell": bool(changes["cell_refine"])})
        if "scale_refine" in changes:
            phase.set_HAP_refinements({"Scale": bool(changes["scale_refine"])}, [hist])
        if "size" in changes:
            p = changes["size"]
            mode = p.get("mode", "isotropic")
            if "value" in p:
                if mode == "uniaxial":
                    phase.setSampleProfile(hist, "size", mode, p["value"], p.get("axial", p["value"]), p.get("axis", [0, 0, 1]), p.get("lgmix", 1.0))
                else:
                    phase.setSampleProfile(hist, "size", mode, p["value"], LGmix=p.get("lgmix", 1.0))
            phase.set_HAP_refinements({"Size": {"type": mode, "refine": p.get("refine", False), "direction": p.get("axis", [0, 0, 1])}}, [hist])
        if "strain" in changes:
            p = changes["strain"]
            mode = p.get("mode", "isotropic")
            if "value" in p:
                if mode == "uniaxial":
                    phase.setSampleProfile(hist, "microstrain", mode, p["value"], p.get("axial", p["value"]), p.get("axis", [0, 0, 1]), p.get("lgmix", 1.0))
                else:
                    phase.setSampleProfile(hist, "microstrain", mode, p["value"], LGmix=p.get("lgmix", 1.0))
            phase.set_HAP_refinements({"Mustrain": {"type": mode, "refine": p.get("refine", False), "direction": p.get("axis", [0, 0, 1])}}, [hist])
        if "preferred_orientation" in changes:
            p = changes["preferred_orientation"]
            hap = phase.getHAPvalues(hist.name)["Pref.Ori."]
            hap[0] = "MD"
            hap[1] = float(p.get("ratio", 1.0))
            hap[2] = bool(p.get("refine", False))
            hap[3] = [int(v) for v in p.get("axis", [0, 0, 1])]
        if "atom_flags" in changes:
            phase.set_refinements({"Atoms": changes["atom_flags"]})
        if "set_uiso" in changes:
            for atom in phase.atoms():
                if atom.adp_flag == "I":
                    atom.uiso = float(changes["set_uiso"])
        if "refine_common_uiso" in changes:
            value = float(changes["refine_common_uiso"])
            variables = []
            for index, atom in enumerate(phase.atoms()):
                if atom.adp_flag != "I":
                    continue
                atom.uiso = value
                if "U" not in atom.refinement_flags:
                    atom.refinement_flags = atom.refinement_flags + "U"
                variables.append(f"{phase.id}::AUiso:{index}")
            if len(variables) > 1:
                project.add_EquivConstr(variables, reloadIdx=False)

    before = snap(project)
    project.save()
    project.refine(makeBack=False)
    project.save()
    after = snap(project)

    hist = project.histogram(cfg.get("histogram", 0))
    x = np.asarray(hist.getdata("X"), float)
    yo = np.asarray(hist.getdata("Yobs"), float)
    yc = np.asarray(hist.getdata("Ycalc"), float)
    bkg = np.asarray(hist.getdata("Background"), float)
    fit = output.with_name(output.stem + "_fit.csv")
    with fit.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
        writer.writerows(zip(x, yo, yc, yo - yc, bkg))
    diag = output.with_name(output.stem + "_diagnostics.json")
    diag.write_text(json.dumps({"config": cfg, "before": before, "after": after}, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"residuals": after["residuals"], "mass_fractions": after["mass_fractions"], "frozen": after["frozen"]}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("config", type=Path)
    run(parser.parse_args().config)
