#!/usr/bin/env python3
"""Read a saved GSAS-II project and optionally export its saved fit arrays."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("gpx", type=Path)
parser.add_argument("--fit", type=Path)
parser.add_argument("--cif-dir", type=Path)
args = parser.parse_args()

G2.SetPrintLevel("error")
project = G2.G2Project(gpxfile=str(args.gpx.resolve()))
hist = project.histogram(0)
summary = {
    "histogram": hist.name,
    "residuals": hist.residuals,
    "instrument": hist.InstrumentParameters,
    "sample": hist.SampleParameters,
    "background": hist.Background,
    "frozen": project.get_Frozen(),
    "phases": {},
}
try:
    summary["mass_fractions"] = {k: list(v) for k, v in hist.ComputeMassFracs().items()}
except Exception as exc:
    summary["mass_fractions"] = {"error": repr(exc)}
for phase in project.phases():
    summary["phases"][phase.name] = {
        "cell": phase.get_cell(),
        "composition": phase.composition,
        "hap": phase.getHAPvalues(hist.name),
    }

if args.cif_dir:
    args.cif_dir.mkdir(parents=True, exist_ok=True)
    for phase in project.phases():
        phase.export_CIF(str(args.cif_dir / (phase.name.replace(" ", "_") + ".cif")))

if args.fit:
    x = np.asarray(hist.getdata("X"), float)
    yo = np.asarray(hist.getdata("Yobs"), float)
    yc = np.asarray(hist.getdata("Ycalc"), float)
    wt = np.asarray(hist.getdata("Yweight"), float)
    bkg = np.asarray(hist.getdata("Background"), float)
    with args.fit.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference", "background", "weight"])
        writer.writerows(zip(x, yo, yc, yo - yc, bkg, wt))
print(json.dumps(summary, indent=2, allow_nan=False))
