#!/usr/bin/env python3
import json
import numpy as np
from GSASII import GSASIIscriptable as G2


project = G2.G2Project(gpxfile="final.gpx")
hist = project.histograms()[0]
phases = project.phases()
scales = np.array([phase.data["Histograms"][hist.name]["Scale"][0] for phase in phases])
masses = np.array([phase.data["General"]["Mass"] for phase in phases])
amounts = scales * masses
fraction = amounts[0] / amounts.sum()
derivative = np.array([fraction * (1 - fraction) / scales[0],
                       -fraction * (1 - fraction) / scales[1]])
covariance = project.data["Covariance"]["data"]
names = [f"{phase.data['pId']}:{phase.data['Histograms'][hist.name]['hId']}:Scale" for phase in phases]
indices = [covariance["varyList"].index(name) for name in names]
matrix = np.asarray(covariance["covMatrix"])[np.ix_(indices, indices)]
sigma = float(np.sqrt(derivative @ matrix @ derivative))
print(json.dumps({
    "fractions": [float(fraction), float(1 - fraction)],
    "formal_fraction_sigma": sigma,
    "formal_weight_percent_sigma": 100 * sigma,
    "scale_covariance": matrix.tolist(),
    "scale_variable_names": names,
}, indent=2))
