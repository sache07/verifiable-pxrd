from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")

BASE = "trial3.gpx"
CANDIDATES = {
    "gamma_p21n_1528915": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif",
    "gamma_p21c_2311041": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif",
    "triclinic_p-1_2106293": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/10/62/2106293.cif",
    "old_triclinic_p-1_1010618": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/06/1010618.cif",
    "hp_p21c_1563541": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/56/35/1563541.cif",
    "tetragonal_p4ncc_1521532": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/15/1521532.cif",
}


def neutralize_hap(hap, initial_scale):
    hap["Scale"] = [float(initial_scale), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:2] = [1000.0, 1000.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"] = [0.0, False]


outdir = Path("diagnostics/wo3_comparison")
outdir.mkdir(parents=True, exist_ok=True)
results = []
for tag, cif in CANDIDATES.items():
    output = outdir / f"{tag}.gpx"
    try:
        project = G2.G2Project(BASE, filename=str(output))
        hist = project.histogram(0)
        wo3 = project.add_phase(cif, phasename=f"WO3_{tag}", histograms=[hist], fmthint="CIF")
        hist.data["Sample Parameters"]["Scale"] = [1.0, False]
        for phase in project.phases():
            neutralize_hap(phase.data["Histograms"][hist.name], 2.0 if phase is wo3 else phase.data["Histograms"][hist.name]["Scale"][0])
            phase.set_refinements({"Cell": True})
            for atom in phase.atoms():
                if atom.adp_flag == "I":
                    atom.uiso = 0.005
                    atom.refinement_flags = " "
        project.set_Controls("cycles", 12)
        project.save()
        project.refine()
        project.refine()
        project.save()
        scales = []
        weighted = []
        for phase in project.phases():
            scale = phase.data["Histograms"][hist.name]["Scale"][0]
            mass = phase.data["General"]["Mass"]
            scales.append(scale)
            weighted.append(scale * mass)
        total = sum(weighted)
        fractions = [value / total for value in weighted]
        results.append({
            "candidate": tag,
            "status": "ok",
            "Rwp_percent": hist.get_wR(),
            "cells": {phase.name: phase.get_cell() for phase in project.phases()},
            "scales": scales,
            "weight_fractions": fractions,
            "instrument": {key: value[1] for key, value in hist.data["Instrument Parameters"][0].items() if isinstance(value, list) and len(value) > 1},
            "shift_um": hist.data["Sample Parameters"]["Shift"][0],
        })
    except Exception as exc:
        results.append({"candidate": tag, "status": "error", "error": repr(exc)})

print(json.dumps(results, indent=2))
