#!/usr/bin/env python3
import json
import sys

import numpy as np
from scipy.optimize import least_squares
from GSASII import GSASIIscriptable as G2sc


def floor(t, p):
    return p[0] * (1 - t) ** 2 + 2 * p[1] * t * (1 - t) + p[2] * t ** 2


def fit(x, observed, signal, family, signal_limit=None):
    t = (x - x[0]) / (x[-1] - x[0])
    weights = 1 / np.maximum(observed, 1)
    if family == "exponential":
        def background(p):
            return floor(t, p) + p[3] * np.exp(-(x - x[0]) / p[4])
        starts = [[400, 400, 400, 2000, scale] for scale in (5, 8, 12, 18)]
        lower = [200, 200, 200, 1000, 5]
        upper = [1200, 1200, 1200, 3000, 20]
    elif family == "power_law":
        def background(p):
            return floor(t, p) + p[3] * (1 + (x - x[0]) / p[4]) ** (-p[5])
        starts = [[400, 400, 400, 2000, scale, power]
                  for scale in (5, 8, 12, 18) for power in (1.1, 1.5, 2, 2.8)]
        lower = [200, 200, 200, 1000, 5, 1]
        upper = [1200, 1200, 1200, 3000, 20, 3]
    else:
        raise ValueError(family)
    selected = np.ones(len(x), dtype=bool) if signal_limit is None else signal < signal_limit
    residual = lambda p: (np.sqrt(weights) * (observed - signal - background(p)))[selected]
    results = [least_squares(residual, p, bounds=(lower, upper), max_nfev=20000,
                             ftol=1e-12, xtol=1e-12, gtol=1e-12) for p in starts]
    result = min(results, key=lambda r: np.sum(r.fun ** 2))
    calculated = signal + background(result.x)
    chi2 = float(np.sum(weights * (observed - calculated) ** 2))
    denom = float(np.sum(weights * observed ** 2))
    return {
        "family": family,
        "signal_limit_counts": signal_limit,
        "selected_bins": int(selected.sum()),
        "parameters": result.x.tolist(),
        "chi_square": chi2,
        "rwp_percent": 100 * np.sqrt(chi2 / denom),
        "background_min": float(background(result.x).min()),
        "background_max": float(background(result.x).max()),
    }


for path in sys.argv[1:]:
    project = G2sc.G2Project(gpxfile=path)
    arrays = project.histograms()[0].data["data"][1]
    x, observed, calculated, old_background = map(lambda a: np.asarray(a, float),
                                                   (arrays[0], arrays[1], arrays[3], arrays[4]))
    signal = calculated - old_background
    print(json.dumps({
        "path": path,
        "old_rwp_percent": 100 * np.sqrt(np.sum((observed - calculated) ** 2 / np.maximum(observed, 1))
                                            / np.sum(observed)),
        "fits": [fit(x, observed, signal, family, limit)
                 for family in ("exponential", "power_law")
                 for limit in (None, 10, 25, 50, 100, 200)],
    }))
