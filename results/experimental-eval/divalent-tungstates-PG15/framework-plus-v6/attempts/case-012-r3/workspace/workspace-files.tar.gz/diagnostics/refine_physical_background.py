#!/usr/bin/env python3
"""Alternate a low-dimensional lab-family background with GSAS-II signal refinement."""
from pathlib import Path
import json
import sys

import numpy as np
from scipy.optimize import least_squares
from GSASII import GSASIIscriptable as G2


def background_model(x, family, p):
    t = (x - x[0]) / (x[-1] - x[0])
    floor = p[0] * (1 - t) ** 2 + 2 * p[1] * t * (1 - t) + p[2] * t ** 2
    if family == "exponential":
        return floor + p[3] * np.exp(-(x - x[0]) / p[4])
    return floor + p[3] * (1 + (x - x[0]) / p[4]) ** (-p[5])


def fit_background(x, observed, signal, family, previous=None):
    weights = 1 / np.maximum(observed, 1)
    if family == "exponential":
        lower = np.array([200, 200, 200, 1000, 5.0])
        upper = np.array([1200, 1200, 1200, 3000, 20.0])
        starts = [[400, 400, 400, 2000, scale] for scale in (5.2, 8, 12, 18)]
    elif family == "power_law":
        lower = np.array([200, 200, 200, 1000, 5.0, 1.0])
        upper = np.array([1200, 1200, 1200, 3000, 20.0, 3.0])
        starts = [[400, 400, 400, 2000, scale, power]
                  for scale in (5.2, 8, 12, 18) for power in (1.05, 1.4, 2, 2.8)]
    else:
        raise ValueError(f"unsupported family {family}")
    if previous is not None:
        starts.insert(0, np.clip(previous, lower + 1e-6, upper - 1e-6))

    def residual(p):
        return np.sqrt(weights) * (observed - signal - background_model(x, family, p))

    results = [least_squares(residual, start, bounds=(lower, upper), max_nfev=20000,
                             ftol=1e-11, xtol=1e-11, gtol=1e-11) for start in starts]
    return min(results, key=lambda result: np.sum(result.fun ** 2)).x


def set_fixed_chebyshev(hist, x, curve, degree=32):
    coordinate = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    coefficients = np.polynomial.chebyshev.chebfit(coordinate, curve, degree)
    approximation = np.polynomial.chebyshev.chebval(coordinate, coefficients)
    hist.data["Background"][0] = ["chebyschev-1", False, len(coefficients), *coefficients.tolist()]
    return float(np.max(np.abs(approximation - curve)))


def summarize(project, family, parameters, approximation_error, iteration):
    hist = project.histograms()[0]
    arrays = hist.data["data"][1]
    x, observed, calculated, bkg = [np.asarray(arrays[i], float) for i in (0, 1, 3, 4)]
    weights = 1 / np.maximum(observed, 1)
    chi2 = float(np.sum(weights * (observed - calculated) ** 2))
    denominator = float(np.sum(weights * observed ** 2))
    weighted = [phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
                for phase in project.phases()]
    return {
        "iteration": iteration,
        "family": family,
        "parameters": parameters.tolist(),
        "chebyshev_max_error_counts": approximation_error,
        "rwp_percent": 100 * np.sqrt(chi2 / denominator),
        "background_range_counts": [float(bkg.min()), float(bkg.max())],
        "weight_fractions": (np.asarray(weighted) / sum(weighted)).tolist(),
    }


source, destination, family = sys.argv[1:4]
roughness_a = float(sys.argv[4]) if len(sys.argv) > 4 else None
outer_iterations = int(sys.argv[5]) if len(sys.argv) > 5 else 6
G2.SetPrintLevel("warn")
project = G2.G2Project(source, filename=destination)
project.set_Controls("cycles", 8)
hist = project.histograms()[0]
if roughness_a is not None:
    hist.data["Sample Parameters"]["SurfRoughA"] = [roughness_a, False]
    if roughness_a == 0:
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
parameters = None
log = []

for iteration in range(1, outer_iterations + 1):
    arrays = hist.data["data"][1]
    x, observed, calculated, old_bkg = [np.asarray(arrays[i], float) for i in (0, 1, 3, 4)]
    signal = calculated - old_bkg
    parameters = fit_background(x, observed, signal, family, parameters)
    physical = background_model(x, family, parameters)
    approximation_error = set_fixed_chebyshev(hist, x, physical)
    project.save()
    project.refine()
    project.save()
    entry = summarize(project, family, parameters, approximation_error, iteration)
    entry["surface_roughness_A"] = hist.data["Sample Parameters"]["SurfRoughA"][0]
    entry["surface_roughness_B"] = hist.data["Sample Parameters"]["SurfRoughB"][0]
    log.append(entry)

Path(destination).with_suffix(".physical_background.json").write_text(json.dumps(log, indent=2) + "\n")
print(json.dumps(log, indent=2))
