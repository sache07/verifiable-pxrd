#!/usr/bin/env python3
import json
import sys

import numpy as np
from scipy.optimize import least_squares
from GSASII import GSASIIscriptable as G2sc


def fit_family(x, y, family):
    t = (x - x[0]) / (x[-1] - x[0])
    def floor(p):
        return p[0] * (1 - t) ** 2 + 2 * p[1] * t * (1 - t) + p[2] * t ** 2
    if family == "exponential":
        def model(p):
            return floor(p) + p[3] * np.exp(-(x - x[0]) / p[4])
        start = [400.0, 400.0, 400.0, 1800.0, 10.0]
        lower = [200.0, 200.0, 200.0, 1000.0, 5.0]
        upper = [1200.0, 1200.0, 1200.0, 3000.0, 20.0]
    else:
        def model(p):
            return floor(p) + p[3] * (1 + (x - x[0]) / p[4]) ** (-p[5])
        start = [400.0, 400.0, 400.0, 1800.0, 10.0, 2.0]
        lower = [200.0, 200.0, 200.0, 1000.0, 5.0, 1.0]
        upper = [1200.0, 1200.0, 1200.0, 3000.0, 20.0, 3.0]
    result = least_squares(lambda p: model(p) - y, start, bounds=(lower, upper), max_nfev=10000)
    residual = model(result.x) - y
    return {
        "family": family,
        "parameters": result.x.tolist(),
        "rms_counts": float(np.sqrt(np.mean(residual ** 2))),
        "max_abs_counts": float(np.max(np.abs(residual))),
    }


for path in sys.argv[1:]:
    project = G2sc.G2Project(gpxfile=path)
    hist = project.histograms()[0]
    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], float)
    bkg = np.asarray(arrays[4], float)
    print(json.dumps({
        "path": path,
        "background_min": float(bkg.min()),
        "background_max": float(bkg.max()),
        "fits": [fit_family(x, bkg, name) for name in ("exponential", "power_law")],
    }))
