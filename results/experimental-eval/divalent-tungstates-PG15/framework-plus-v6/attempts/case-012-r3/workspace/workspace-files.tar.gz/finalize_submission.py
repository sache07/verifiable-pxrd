#!/usr/bin/env python3
"""Create the frozen final GSAS-II project and export its phase CIFs."""
from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = "diagnostics/background_power_A0p4_final.gpx"
DESTINATION = "final.gpx"

G2.SetPrintLevel("warn")
project = G2.G2Project(SOURCE, filename=DESTINATION)
hist = project.histograms()[0]

# The A/B roughness grid determines only their combined low-angle correction.
# Freeze the representative converged pair before the final all-other-parameter replay.
sample = hist.data["Sample Parameters"]
sample["SurfRoughA"] = [0.4, False]
sample["SurfRoughB"] = [float(sample["SurfRoughB"][0]), False]
hist.data["Instrument Parameters"][0]["SH/L"][2] = False
hist.data["Instrument Parameters"][0]["Polariz."][2] = False

# The two WO3 W sites improved the profile collectively, but their individual
# coordinate shifts oscillated in the last cycles. Retain the converged model
# and freeze those coordinates; the source oxygen framework was already fixed.
wo3 = project.phase("WO3_gamma_p21c_2311041")
_, atom_type_pointer, _, _ = wo3.data["General"]["AtomPtrs"]
for atom in wo3.data["Atoms"]:
    if atom[atom_type_pointer] == "W":
        atom[2] = "U"

# The physical power-law background is stored as a fixed high-accuracy Chebyshev
# representation; its six generating-family parameters are documented in report.md.
hist.data["Background"][0][1] = False
project.set_Controls("cycles", 12)
project.save()
for _ in range(4):
    project.refine()
project.save()

# Reopen the serialized project before exports, so every artifact comes from disk state.
project = G2.G2Project(gpxfile=DESTINATION)
hist = project.histograms()[0]
phase_dir = Path("phases")
phase_dir.mkdir(exist_ok=True)
paths = {
    "NiWO4": phase_dir / "NiWO4.cif",
    "WO3_gamma_p21c_2311041": phase_dir / "WO3_gamma.cif",
}
for phase in project.phases():
    phase.export_CIF(str(paths[phase.name]))

arrays = hist.data["data"][1]
x, observed, calculated, background = [np.asarray(arrays[i], float) for i in (0, 1, 3, 4)]
weights = 1 / np.maximum(observed, 1)
chi2 = float(np.sum(weights * (observed - calculated) ** 2))
denominator = float(np.sum(weights * observed ** 2))
weighted = [phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()]
fractions = np.asarray(weighted) / sum(weighted)
covariance = project.data.get("Covariance", {}).get("data", {})
rvals = covariance.get("Rvals", {})
summary = {
    "histogram": hist.name,
    "phase_names": [phase.name for phase in project.phases()],
    "cif_paths": [str(paths[phase.name]) for phase in project.phases()],
    "weight_fractions": fractions.tolist(),
    "rwp_percent_from_saved_curve": 100 * np.sqrt(chi2 / denominator),
    "chi_square_from_saved_curve": chi2,
    "background_range_counts": [float(background.min()), float(background.max())],
    "gsas_rvals": rvals,
    "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    "scales": {phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
               for phase in project.phases()},
    "unit_cell_masses": {phase.name: phase.data["General"]["Mass"] for phase in project.phases()},
    "sample_parameters": hist.data["Sample Parameters"],
    "instrument_parameters": hist.data["Instrument Parameters"][0],
}

def plain(value):
    if isinstance(value, dict):
        return {str(key): plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(item) for item in value]
    if hasattr(value, "tolist"):
        return plain(value.tolist())
    if hasattr(value, "item"):
        return value.item()
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return repr(value)

Path(".tmp/final_refinement_summary.json").write_text(json.dumps(plain(summary), indent=2) + "\n")
print(json.dumps(plain(summary), indent=2))
