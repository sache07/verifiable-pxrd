#!/usr/bin/env python3
import json
import sys

from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(gpxfile=sys.argv[1])
hist = project.histograms()[0]

summary = {
    "histogram": hist.name,
    "limits": hist.data.get("Limits"),
    "background": hist.data.get("Background"),
    "instrument": hist.data.get("Instrument Parameters", [{}])[0],
    "sample": hist.data.get("Sample Parameters"),
    "residuals": hist.data.get("Residuals"),
    "covariance": project.data.get("Covariance", {}).get("data", {}),
    "phases": [],
}

for phase in project.phases():
    general = phase.data["General"]
    cx, ct, cs, cia = general["AtomPtrs"]
    atoms = []
    for atom in phase.data["Atoms"]:
        atoms.append({
            "label": atom[ct - 1],
            "element": atom[ct],
            "xyz": atom[cx:cx + 3],
            "occupancy": atom[cx + 3],
            "site_symmetry": atom[cs],
            "multiplicity": atom[cs + 1],
            "adp_type": atom[cia],
            "adp": atom[cia + 1:cia + 8],
            "refine": atom[2],
        })
    summary["phases"].append({
        "name": phase.name,
        "cell": general.get("Cell"),
        "space_group": general.get("SGData", {}).get("SpGrp"),
        "mass": general.get("Mass"),
        "histogram": phase.data.get("Histograms", {}).get(hist.name),
        "atoms": atoms,
    })

def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if hasattr(value, "tolist"):
        return plain(value.tolist())
    if hasattr(value, "item"):
        return value.item()
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return repr(value)

print(json.dumps(plain(summary), indent=2))
