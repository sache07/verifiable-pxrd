#!/usr/bin/env python3
"""Build the public profile and machine-readable result from the verified replay."""
from pathlib import Path
import json

import numpy as np


replay_dir = Path(".tmp/final_replay")
replay = json.loads((replay_dir / "replay.json").read_text())
refinement = json.loads(Path(".tmp/final_refinement_summary.json").read_text())
if replay["status"] != "replayed" or replay["profile_review_flags"]:
    raise RuntimeError(f"final replay did not pass cleanly: {replay}")

with np.load(replay_dir / "prediction.npz", allow_pickle=False) as profile:
    x = profile["x"]
    observed = profile["observed"]
    calculated = profile["predicted"]

difference = observed - calculated
weights = 1 / np.maximum(observed, 1)
chi_square = float(np.sum(weights * difference ** 2))
denominator = float(np.sum(weights * observed ** 2))
n_points = len(x)
n_variables = int(refinement["gsas_rvals"]["Nvars"])
degrees_of_freedom = n_points - n_variables
rwp = float(100 * np.sqrt(chi_square / denominator))
rp = float(100 * np.sum(np.abs(difference)) / np.sum(observed))
reduced_chi_square = chi_square / degrees_of_freedom
gof = float(np.sqrt(reduced_chi_square))
r_expected = rwp / gof
rmse = float(np.sqrt(np.mean(difference ** 2)))

np.savetxt(
    "fit.csv",
    np.column_stack([x, observed, calculated, difference]),
    delimiter=",",
    header="two_theta,observed,calculated,difference",
    comments="",
    fmt="%.12g",
)

phase_metadata = {
    "NiWO4": {
        "name": "NiWO4 (wolframite)",
        "formula": "NiWO4",
        "space_group": "P 2/c",
        "cif_path": "phases/NiWO4.cif",
    },
    "WO3_gamma_p21c_2311041": {
        "name": "gamma-WO3 (monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif_path": "phases/WO3_gamma.cif",
    },
}
formal_fraction_esd = 0.0012152963915781122
model_fraction_uncertainty = 0.003
phases = []
for phase in replay["phases"]:
    phases.append({
        **phase_metadata[phase["name"]],
        "project_phase_name": phase["name"],
        "weight_fraction": phase["weight_fraction"],
        "weight_fraction_formal_esd": formal_fraction_esd,
        "estimated_model_uncertainty_abs": model_fraction_uncertainty,
    })

result = {
    "schema_version": 1,
    "refinement_histogram": replay["histogram"],
    "fraction_basis": "normalized over the modeled crystalline phases",
    "phases": phases,
    "fit_statistics": {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "r_expected_percent": r_expected,
        "chi_square": chi_square,
        "reduced_chi_square": reduced_chi_square,
        "goodness_of_fit": gof,
        "rmse_counts": rmse,
        "n_points": n_points,
        "n_refined_parameters": n_variables,
        "degrees_of_freedom": degrees_of_freedom,
        "weighting": "1/max(observed_counts,1)",
        "profile_source": "fresh native GSAS-II replay of final.gpx over the full observed grid",
    },
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
}
Path("result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
