#!/usr/bin/env python3
from pathlib import Path
import json

import numpy as np
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


out = {}
for path in (Path("phases/NiWO4.cif"), Path("phases/WO3_gamma.cif")):
    structure = Structure.from_file(path)
    analyzer = SpacegroupAnalyzer(structure, symprec=1e-3, angle_tolerance=0.1)
    distances = np.asarray(structure.distance_matrix)
    distances[distances < 1e-10] = np.inf
    oxygen_indices = [i for i, site in enumerate(structure) if site.specie.symbol == "O"]
    oxygen_distances = distances[np.ix_(oxygen_indices, oxygen_indices)].copy()
    oxygen_distances[oxygen_distances < 1e-10] = np.inf
    environments = {}
    for index, site in enumerate(structure):
        symbol = site.specie.symbol
        if symbol == "O":
            continue
        nearest_oxygen = sorted(float(distances[index, j]) for j in oxygen_indices)[:6]
        key = tuple(round(value, 3) for value in nearest_oxygen)
        environments.setdefault(symbol, [])
        if key not in environments[symbol]:
            environments[symbol].append(key)
    out[str(path)] = {
        "reduced_formula": structure.composition.reduced_formula,
        "density_g_cm3": float(structure.density),
        "space_group_symbol": analyzer.get_space_group_symbol(),
        "space_group_number": analyzer.get_space_group_number(),
        "sites_in_cell": len(structure),
        "minimum_interatomic_distance_A": float(np.min(distances)),
        "minimum_O_O_distance_A": float(np.min(oxygen_distances)),
        "six_nearest_oxygen_distances_A": {
            key: [list(values) for values in signatures]
            for key, signatures in environments.items()
        },
    }
print(json.dumps(out, indent=2))
