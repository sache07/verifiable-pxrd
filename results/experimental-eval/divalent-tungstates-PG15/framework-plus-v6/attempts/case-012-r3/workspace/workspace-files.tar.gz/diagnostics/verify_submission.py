#!/usr/bin/env python3
from pathlib import Path
import json
import sys


root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / "learned/divalent-tungstates/scorer/src"))
from replay import annotated_structure, model_agrees  # noqa: E402
from structure_metrics import parse_submission  # noqa: E402
from exported_profile import inspect_export  # noqa: E402


submission, rows, notes = parse_submission(root, {"Ni", "W", "O", "C", "H"})
eligible = bool(submission["_submission_parsing"]["quantification_complete"]
                and not submission["_submission_parsing"]["hard_physical_failure"])
replay = json.loads((root / ".tmp/final_replay/replay.json").read_text())
submitted = [[annotated_structure(export["path"])
              for export in row.get("equivalent_exports", [row])] for row in rows]
consistency = []
for phase in replay["phases"]:
    native = annotated_structure(root / ".tmp/final_replay" / phase["cif"])
    matches = [index for index, group in enumerate(submitted)
               if any(model_agrees(native, structure) for structure in group)]
    consistency.append({"project_phase": phase["name"], "matching_submission_indices": matches})
print(json.dumps({
    "notes": notes,
    "submission_parsing": submission["_submission_parsing"],
    "physical_screens": [row["physical"] for row in rows],
    "replay": replay,
    "project_cif_consistency": consistency,
    "exported_profile": inspect_export(root, root, submission),
    "eligible": eligible,
}, indent=2))
