#!/usr/bin/env python3
import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


source, destination, nio_cif = sys.argv[1:4]
G2.SetPrintLevel("warn")
project = G2.G2Project(source, filename=destination)
hist = project.histograms()[0]
nio = project.add_phase(nio_cif, phasename="NiO_watch", histograms=[hist], fmthint="CIF")
hap = nio.data["Histograms"][hist.name]
hap["Scale"] = [0.05, True]
hap["Size"][0] = "isotropic"
hap["Size"][1][:2] = [1000.0, 1000.0]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][:2] = [0.0, 0.0]
hap["Mustrain"][2] = [False, False, False]
hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
hap["Extinction"] = [0.0, False]
nio.set_refinements({"Cell": True})
for atom in nio.atoms():
    if atom.adp_flag == "I":
        atom.uiso = 0.005
    atom.refinement_flags = " "

project.set_Controls("cycles", 12)
project.save()
project.refine()
project.refine()
project.save()

arrays = hist.data["data"][1]
x, observed, calculated = [np.asarray(arrays[i], float) for i in (0, 1, 3)]
weights = 1 / np.maximum(observed, 1)
chi2 = float(np.sum(weights * (observed - calculated) ** 2))
denominator = float(np.sum(weights * observed ** 2))
weighted = [phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()]
cov = project.data.get("Covariance", {}).get("data", {})
vary = cov.get("varyList", [])
sigmas = cov.get("sig", [])
scale_var = f"{nio.data['pId']}:{hap['hId']}:Scale"
scale_sigma = float(sigmas[vary.index(scale_var)]) if scale_var in vary else None
print(json.dumps({
    "rwp_percent": 100 * np.sqrt(chi2 / denominator),
    "weight_fractions": {phase.name: float(value / sum(weighted))
                         for phase, value in zip(project.phases(), weighted)},
    "nio_scale": hap["Scale"][0],
    "nio_scale_sigma": scale_sigma,
    "nio_scale_over_sigma": hap["Scale"][0] / scale_sigma if scale_sigma else None,
    "nio_cell": nio.get_cell(),
}, indent=2))
