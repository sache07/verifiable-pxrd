#!/usr/bin/env python3
from pathlib import Path
import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


source, destination, count = sys.argv[1], sys.argv[2], int(sys.argv[3])
G2.SetPrintLevel("warn")
project = G2.G2Project(source, filename=destination)
hist = project.histograms()[0]
old = hist.data["Background"][0]
coefficients = list(old[3:count + 3]) + [0.0] * max(0, count - len(old[3:]))
hist.data["Background"][0] = ["chebyschev-1", True, count, *coefficients]
project.set_Controls("cycles", 12)
project.save()
project.refine()
project.refine()
project.save()
arrays = hist.data["data"][1]
x, observed, calculated, background = [np.asarray(arrays[i], float) for i in (0, 1, 3, 4)]
weights = 1 / np.maximum(observed, 1)
chi2 = float(np.sum(weights * (observed - calculated) ** 2))
denominator = float(np.sum(weights * observed ** 2))
weighted = [phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()]
result = {
    "source": source,
    "destination": destination,
    "coefficient_count": count,
    "coefficients": hist.data["Background"][0][3:],
    "background_range_counts": [float(background.min()), float(background.max())],
    "rwp_percent": 100 * np.sqrt(chi2 / denominator),
    "chi_square": chi2,
    "weight_fractions": (np.asarray(weighted) / sum(weighted)).tolist(),
    "converged": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("converged"),
}
Path(destination).with_suffix(".background_order.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
