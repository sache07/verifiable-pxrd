#!/usr/bin/env python3
"""Refine WO3 oxygen positions within a physically screened displacement box."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def show(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print("SUMMARY", label, hist.residuals, hist.ComputeMassFracs())
    print("FROZEN", project.get_Frozen())
    for phase in project.phases():
        print("PHASE", phase.name, phase.get_cell())
        for atom in phase.atoms():
            print("ATOM", atom.label, atom.element, atom.coordinates,
                  atom.refinement_flags, atom.uiso)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("--limit-A", type=float, default=0.06)
    args = parser.parse_args()

    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        for atom in phase.atoms():
            atom.refinement_flags = "U" if "U" in atom.refinement_flags else " "

    phase = project.phase("WO3")
    cell = phase.get_cell()
    limits = [args.limit_A / cell[f"length_{axis}"] for axis in "abc"]
    for i, atom in enumerate(phase.atoms()):
        if atom.element != "O":
            continue
        atom.refinement_flags = "XU"
        for axis, delta in zip("xyz", limits):
            name = f"{phase.id}::dA{axis}:{i}"
            project.set_Controls("parmMin", -delta, variable=name)
            project.set_Controls("parmMax", delta, variable=name)

    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.refine(makeBack=False)
    show(project, "bounded_fit")

    # The fitted coordinates are now the fixed physical model. Clear clipped
    # displacement variables and reconverge all remaining parameters twice.
    for atom in phase.atoms():
        if atom.element == "O":
            atom.refinement_flags = "U"
    project.set_Frozen()
    for label in ("fixed_replay", "fixed_replay2"):
        project.refine(makeBack=False)
        show(project, label)
    project.save()


if __name__ == "__main__":
    main()
