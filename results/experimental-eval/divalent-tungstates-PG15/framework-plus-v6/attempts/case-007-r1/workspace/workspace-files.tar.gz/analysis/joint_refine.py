#!/usr/bin/env python3
"""Jointly reconverge only accepted structural and nuisance parameters."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def show(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print("SUMMARY", label, hist.residuals, hist.ComputeMassFracs())
    print("FROZEN", project.get_Frozen())
    print("INST", {k: hist.InstrumentParameters[k] for k in
                   ("U", "W", "X", "SH/L", "Zero", "Polariz.")})
    print("SAMPLE", {k: hist.SampleParameters[k] for k in
                     ("SurfRoughA", "SurfRoughB", "Shift")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("PHASE", phase.name, phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "strain", hap["Mustrain"],
              "texture", hap["Pref.Ori."])
        for atom in phase.atoms():
            print("ATOM", atom.label, atom.element, atom.coordinates,
                  atom.refinement_flags, atom.uiso)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    args = parser.parse_args()
    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)

    # Explicitly neutralize texture and enable one linked Uiso per phase.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = "U"

    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.refine(makeBack=False)
    show(project, "uiso")

    # Retain only coordinate shifts supported in the staged challenges.
    for atom in project.phase("MgWO4").atoms():
        atom.refinement_flags = "XU"
    for atom in project.phase("WO3").atoms():
        atom.refinement_flags = "XU" if atom.element == "W" else "U"
    for label in ("joint", "replay", "replay2"):
        project.refine(makeBack=False)
        show(project, label)
    project.save()


if __name__ == "__main__":
    main()
