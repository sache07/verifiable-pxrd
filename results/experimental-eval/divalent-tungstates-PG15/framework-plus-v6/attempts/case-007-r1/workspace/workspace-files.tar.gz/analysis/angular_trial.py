#!/usr/bin/env python3
"""Compare a single zero or specimen-displacement correction."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("mode", choices=("zero", "shift"))
    args = parser.parse_args()
    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)

    if args.mode == "zero":
        hist.InstrumentParameters["Zero"][2] = True
        hist.SampleParameters["Shift"] = [0.0, False]
    else:
        hist.InstrumentParameters["Zero"][0] = 0.0
        hist.InstrumentParameters["Zero"][1] = 0.0
        hist.InstrumentParameters["Zero"][2] = False
        # A positive GSAS-II shift moves Bragg peaks to lower recorded 2theta.
        hist.SampleParameters["Shift"] = [-600.0, True]
        project.set_Controls("parmMin", -800.0, variable=":0:Shift")
        project.set_Controls("parmMax", 800.0, variable=":0:Shift")

    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    for label in ("fit", "replay"):
        project.refine(makeBack=False)
        print("SUMMARY", args.mode, label, hist.residuals,
              hist.ComputeMassFracs(), "FROZEN", project.get_Frozen())
        print("GEOMETRY", hist.InstrumentParameters["Zero"],
              hist.SampleParameters["Shift"])
    project.save()


if __name__ == "__main__":
    main()
