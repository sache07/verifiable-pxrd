#!/usr/bin/env python3
"""Challenge one phase with a March-Dollase preferred-orientation axis."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("phase")
    parser.add_argument("axis")
    args = parser.parse_args()
    if len(args.axis) != 3 or any(c not in "0123456789" for c in args.axis):
        raise ValueError("axis must contain three nonnegative integer digits")
    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 0.95 if phase.name == args.phase else 1.0
        hap["Pref.Ori."][2] = phase.name == args.phase
        if phase.name == args.phase:
            hap["Pref.Ori."][3] = [int(v) for v in args.axis]

    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    for label in ("fit", "replay"):
        project.refine(makeBack=False)
        target = project.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."]
        print("SUMMARY", args.phase, args.axis, label,
              hist.residuals["wR"], hist.residuals["R"], target,
              hist.ComputeMassFracs(), "FROZEN", project.get_Frozen())
    project.save()


if __name__ == "__main__":
    main()
