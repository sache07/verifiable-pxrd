#!/usr/bin/env python3
"""Profile fixed common U/X values while all accepted terms reconverge."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("--u", type=float, required=True)
    parser.add_argument("--x", type=float, required=True)
    args = parser.parse_args()
    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)
    for key, value in (("U", args.u), ("X", args.x)):
        hist.InstrumentParameters[key][0] = value
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False

    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    for label in ("fit", "replay"):
        project.refine(makeBack=False)
        print("SUMMARY", args.u, args.x, label, hist.residuals["wR"],
              hist.residuals["R"], hist.ComputeMassFracs(), "FROZEN", project.get_Frozen())
        print("INST", {k: hist.InstrumentParameters[k] for k in ("U", "W", "X", "SH/L")})
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            print("PHASE", phase.name, "size", hap["Size"], "strain", hap["Mustrain"])
    project.save()


if __name__ == "__main__":
    main()
