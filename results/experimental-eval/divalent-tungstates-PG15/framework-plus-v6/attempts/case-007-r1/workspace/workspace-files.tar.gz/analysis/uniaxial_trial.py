#!/usr/bin/env python3
"""Challenge one isotropic-strain phase with a selected uniaxial direction."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("phase")
    parser.add_argument("axis", choices=("100", "010", "001"))
    args = parser.parse_args()
    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    current = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = current
    hap["Mustrain"][1][1] = current * 1.05
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = [int(v) for v in args.axis]

    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    for label in ("fit", "replay"):
        project.refine(makeBack=False)
        print("SUMMARY", args.phase, args.axis, label,
              hist.residuals["wR"], hist.residuals["R"], hist.ComputeMassFracs())
        print("FROZEN", project.get_Frozen())
        for p in project.phases():
            h = p.data["Histograms"][hist.name]
            print("PHASE", p.name, "strain", h["Mustrain"], "size", h["Size"])
    project.save()


if __name__ == "__main__":
    main()
