#!/usr/bin/env python3
"""Plot profile arrays extracted from a GSAS-II project."""

from __future__ import annotations

import argparse

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("npz")
    parser.add_argument("png")
    args = parser.parse_args()
    data = np.load(args.npz)
    x, yo, yc, yb = (data[k] for k in ("x", "yo", "yc", "yb"))
    diff = yo - yc
    fig, axes = plt.subplots(4, 1, figsize=(16, 12), constrained_layout=True)
    windows = ((9.9, 100.1), (10, 35), (35, 65), (65, 100.1))
    for ax, (lo, hi) in zip(axes, windows):
        mask = (x >= lo) & (x <= hi)
        offset = np.percentile(yo[mask], 1) - 1.15 * np.max(np.abs(diff[mask]))
        ax.plot(x[mask], yo[mask], color="black", lw=0.5, label="observed")
        ax.plot(x[mask], yc[mask], color="tab:red", lw=0.65, label="calculated")
        ax.plot(x[mask], yb[mask], color="tab:green", lw=0.55, label="background")
        ax.plot(x[mask], diff[mask] + offset, color="tab:blue", lw=0.5,
                label="difference (offset)")
        ax.axhline(offset, color="0.65", lw=0.4)
        ax.set_xlim(lo, hi)
        ax.set_ylabel("counts")
    axes[0].legend(ncol=4, loc="upper right")
    axes[-1].set_xlabel(r"$2\theta$ (degree)")
    fig.savefig(args.png, dpi=160)


if __name__ == "__main__":
    main()
