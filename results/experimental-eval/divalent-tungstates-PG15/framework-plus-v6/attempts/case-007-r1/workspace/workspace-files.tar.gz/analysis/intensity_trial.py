#!/usr/bin/env python3
"""Compare shared low-angle intensity corrections before phase texture."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("mode", choices=("none", "roughness", "polarization", "both"))
    parser.add_argument("--fixed-a", type=float, default=None)
    parser.add_argument("--freeze-atoms", action="store_true")
    args = parser.parse_args()

    output = Path(args.output_gpx).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(output))
    hist = project.histogram(0)
    project.set_Frozen()

    use_roughness = args.mode in ("roughness", "both")
    use_polarization = args.mode in ("polarization", "both")
    fixed_a = args.fixed_a if args.fixed_a is not None else 0.30
    hist.SampleParameters["SurfRoughA"] = [fixed_a if use_roughness else 0.0,
                                             use_roughness and args.fixed_a is None]
    hist.SampleParameters["SurfRoughB"] = [0.10 if use_roughness else 0.0, use_roughness]
    if use_polarization:
        hist.InstrumentParameters["Polariz."][0] = 0.70
        hist.InstrumentParameters["Polariz."][1] = 0.70
    hist.InstrumentParameters["Polariz."][2] = use_polarization

    if args.freeze_atoms:
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = "U" if "U" in atom.refinement_flags else " "

    for variable, lower, upper in (
        (":0:SurfRoughA", 0.05, 0.60),
        (":0:SurfRoughB", 0.02, 0.50),
        (":0:Polariz.", 0.50, 1.0),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.save()
    for label in ("fit", "replay"):
        project.refine(makeBack=False)
        print("SUMMARY", label)
        print("residuals", hist.residuals)
        print("mass_fracs", hist.ComputeMassFracs())
        print("polarization", hist.InstrumentParameters["Polariz."])
        print("roughness", hist.SampleParameters["SurfRoughA"], hist.SampleParameters["SurfRoughB"])
        print("frozen", project.get_Frozen())
    project.save()


if __name__ == "__main__":
    main()
