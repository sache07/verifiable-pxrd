#!/usr/bin/env python3
"""Revisit MgO strain at an interior fixed common-U value."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("--u", type=float, default=20.0)
    args = parser.parse_args()
    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)
    hist.InstrumentParameters["U"][0] = args.u
    hist.InstrumentParameters["U"][1] = args.u
    hist.InstrumentParameters["U"][2] = False
    phase = project.phase("MgO")
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1600.0
    hap["Mustrain"][1][1] = 1600.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [True, False, False]
    hap["Size"][2] = [True, False, False]

    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    for label in ("fit", "replay", "replay2"):
        project.refine(makeBack=False)
        print("SUMMARY", label, hist.residuals, hist.ComputeMassFracs(),
              "FROZEN", project.get_Frozen())
        print("INST", {k: hist.InstrumentParameters[k] for k in
                       ("U", "W", "X", "SH/L")})
        for p in project.phases():
            h = p.data["Histograms"][hist.name]
            print("PHASE", p.name, "size", h["Size"], "strain", h["Mustrain"])
    project.save()


if __name__ == "__main__":
    main()
