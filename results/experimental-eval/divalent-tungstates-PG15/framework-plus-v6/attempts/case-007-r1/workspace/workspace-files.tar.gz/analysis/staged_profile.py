#!/usr/bin/env python3
"""Establish phase size terms one at a time before re-releasing U/W/X."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def report(project, label: str) -> None:
    hist = project.histogram(0)
    print("SUMMARY", label)
    print("residuals", hist.residuals)
    print("mass_fracs", hist.ComputeMassFracs())
    print("instrument", {k: hist.InstrumentParameters[k][1] for k in ("U", "W", "X", "SH/L")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("phase", phase.name, "size", hap["Size"], "strain", hap["Mustrain"])
    print("frozen", project.get_Frozen())


def refine(project, label: str) -> None:
    project.save()
    project.refine(makeBack=False)
    report(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("--u", type=float, required=True)
    parser.add_argument("--w", type=float, required=True)
    parser.add_argument("--x", type=float, required=True)
    args = parser.parse_args()

    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    hist = project.histogram(0)
    project.set_Frozen()

    # Keep the accepted one-dimensional roughness correction and a physical
    # fixed polarization while broadening is isolated.
    hist.SampleParameters["SurfRoughA"] = [0.05, False]
    hist.SampleParameters["SurfRoughB"][1] = True
    hist.InstrumentParameters["Polariz."][1] = 0.50
    hist.InstrumentParameters["Polariz."][2] = False

    for key, val in (("U", args.u), ("W", args.w), ("X", args.x)):
        hist.InstrumentParameters[key][0] = val
        hist.InstrumentParameters[key][1] = val
        hist.InstrumentParameters[key][2] = False

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        pid = phase.id
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{pid}:0:Size;i")

    project.set_Controls("cycles", 15)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    refine(project, "fixed_common_baseline")

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][1][0] = 0.30
        hap["Size"][2][0] = True
        refine(project, "add_size_" + phase.name)

    for variable, lower, upper in (
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    for key in ("U", "W", "X"):
        hist.InstrumentParameters[key][2] = True
    refine(project, "release_common")
    refine(project, "replay")
    project.save()


if __name__ == "__main__":
    main()
