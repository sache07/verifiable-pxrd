#!/usr/bin/env python3
"""Rebuild a physical phase-width model around the refined structures."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def show(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print("SUMMARY", label, hist.residuals, hist.ComputeMassFracs())
    print("FROZEN", project.get_Frozen())
    print("INST", {k: hist.InstrumentParameters[k] for k in
                   ("U", "W", "X", "SH/L", "Zero", "Polariz.")})
    print("SAMPLE", {k: hist.SampleParameters[k] for k in
                     ("SurfRoughA", "SurfRoughB", "Shift")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("PHASE", phase.name, "size", hap["Size"],
              "strain", hap["Mustrain"], "cell", phase.get_cell())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("--u", type=float, required=True)
    parser.add_argument("--x", type=float, required=True)
    parser.add_argument("--w", type=float, default=5.0)
    parser.add_argument("--refine-w", action="store_true")
    args = parser.parse_args()

    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)

    for key, value, flag in (("U", args.u, False), ("W", args.w, args.refine_w),
                             ("X", args.x, False)):
        hist.InstrumentParameters[key][0] = value
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = flag
    hist.InstrumentParameters["Polariz."][1] = 0.50
    hist.InstrumentParameters["Polariz."][2] = False
    hist.SampleParameters["SurfRoughA"] = [0.05, False]
    hist.SampleParameters["SurfRoughB"][1] = True

    configurations = {
        "MgWO4": (0.80, True, 3650.0, True),
        "WO3": (1.50, False, 5200.0, True),
        "MgO": (0.115, True, 0.0, False),
    }
    for phase in project.phases():
        size, size_flag, strain, strain_flag = configurations[phase.name]
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [size, size, 1.0]
        hap["Size"][2] = [size_flag, False, False]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][1][1] = strain
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [strain_flag, False, False]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        for atom in phase.atoms():
            atom.refinement_flags = " "

    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    for label in ("fit", "replay", "replay2"):
        project.refine(makeBack=False)
        show(project, label)
    project.save()


if __name__ == "__main__":
    main()
