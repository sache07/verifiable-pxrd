#!/usr/bin/env python3
"""Prune unsupported major-phase size terms and reconverge the profile."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    args = parser.parse_args()
    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if phase.name in ("MgWO4", "WO3"):
            hap["Size"][1][0] = 1.5
            hap["Size"][1][1] = 1.5
            hap["Size"][2] = [False, False, False]
            hap["Mustrain"][2] = [True, False, False]
        else:
            hap["Size"][2] = [True, False, False]
            hap["Mustrain"][2] = [False, False, False]
        for atom in phase.atoms():
            atom.refinement_flags = " "

    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    for label in ("fit", "replay", "replay2"):
        project.refine(makeBack=False)
        print("SUMMARY", label, hist.residuals, hist.ComputeMassFracs())
        print("FROZEN", project.get_Frozen())
        print("INST", {k: hist.InstrumentParameters[k] for k in
                       ("U", "W", "X", "SH/L", "Zero")})
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            print("PHASE", phase.name, "size", hap["Size"], "strain", hap["Mustrain"])
    project.save()


if __name__ == "__main__":
    main()
