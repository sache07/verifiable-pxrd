#!/usr/bin/env python3
"""Build a restrained three-phase GSAS-II trial for WO3-record screening."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def initial_background(x: np.ndarray, y: np.ndarray, ncoef: int = 10) -> list[float]:
    step = float(np.median(np.diff(x)))
    width = int(round(4.0 / step))
    if width % 2 == 0:
        width += 1
    baseline = percentile_filter(y, percentile=15, size=width, mode="nearest")
    baseline = gaussian_filter1d(baseline, sigma=1.0 / step)
    xpos = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    return np.polynomial.chebyshev.chebfit(xpos, baseline, ncoef - 1).tolist()


def neutralize_hap(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    # Large size and zero microstrain make unused sample broadening neutral.
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1000.0, 1000.0, 0.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2][:] = [False for _ in hap["Mustrain"][2]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def summary(project, label: str) -> None:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    cells = {p.name: p.get_cell() for p in project.phases()}
    scales = {p.name: p.HAPvalue("Scale", targethistlist=[hist]) for p in project.phases()}
    print(f"SUMMARY {label}")
    print(" residuals", hist.residuals)
    print(" inst", {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "SH/L", "Polariz.")})
    print(" sample", {k: hist.SampleParameters[k][0] for k in ("Shift", "SurfRoughA", "SurfRoughB")})
    print(" scales", scales)
    print(" cells", cells)
    try:
        print(" mass_fracs", hist.ComputeMassFracs())
    except Exception as exc:
        print(" mass_fracs unavailable", repr(exc))


def refine_once(project, label: str) -> None:
    project.save()
    project.refine(makeBack=False)
    summary(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("--angular", choices=("zero", "shift"), default="zero")
    parser.add_argument("--outdir", default=None)
    args = parser.parse_args()

    outdir = ROOT / (args.outdir or f"analysis/trial_{args.wo3_id}_{args.angular}")
    outdir.mkdir(parents=True, exist_ok=True)
    gpx_path = outdir / "trial.gpx"

    project = G2sc.G2Project(newgpx=str(gpx_path))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "analysis/instrument.instprm"),
        fmthint="comma",
    )
    hist.SampleParameters["Scale"][1] = False

    x = np.asarray(hist.getdata("X"), dtype=float)
    y = np.asarray(hist.getdata("Yobs"), dtype=float)
    coeffs = initial_background(x, y, ncoef=10)
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": len(coeffs),
            "coeffs": coeffs,
            "refine": True,
        }
    })

    phase_specs = (
        ("MgWO4", "9013902"),
        ("WO3", args.wo3_id),
        ("MgO", "9000499"),
    )
    phases = []
    for name, cod_id in phase_specs:
        phase = project.add_phase(
            str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase, hist.name)
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
        phases.append(phase)

    # Positive starting scales roughly encode the expected abundance ordering.
    for phase, scale in zip(phases, (1.0, 0.15, 0.03)):
        phase.HAPvalue("Scale", scale, targethistlist=[hist])

    if args.angular == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    else:
        hist.set_refinements({"Sample Parameters": ["Shift"]})

    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    refine_once(project, "background_scales_angular")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine_once(project, "cells")

    # Restrict the common profile to the positive U/W/X terms requested.
    for variable, lower, upper in (
        (":0:U", 0.0, 100.0),
        (":0:W", 0.01, 100.0),
        (":0:X", 0.001, 20.0),
        (":0:SH/L", 0.001, 0.5),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine_once(project, "common_profile")

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine_once(project, "asymmetry")
    refine_once(project, "replay")
    project.save()


if __name__ == "__main__":
    main()
