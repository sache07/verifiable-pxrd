#!/usr/bin/env python3
"""Refine selected atomic coordinates while holding profile widths fixed."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("phase")
    parser.add_argument("labels", help="comma-separated atom labels")
    parser.add_argument("--reset", action="store_true", help="clear all existing atom flags first")
    args = parser.parse_args()

    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)

    # Atomic intensity changes are isolated from width changes at this stage.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        if args.reset:
            for atom in phase.atoms():
                atom.refinement_flags = " "

    phase = project.phase(args.phase)
    labels = [s.strip() for s in args.labels.split(",") if s.strip()]
    for label in labels:
        atom = phase.atom(label)
        if atom is None:
            raise ValueError(f"No atom {label!r} in phase {phase.name!r}")
        flags = atom.refinement_flags.replace(" ", "")
        atom.refinement_flags = "X" + ("U" if "U" in flags else "")

    project.set_Controls("cycles", 18)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    for label in ("fit", "replay"):
        project.refine(makeBack=False)
        print("SUMMARY", label, hist.residuals, hist.ComputeMassFracs())
        print("FROZEN", project.get_Frozen())
        for p in project.phases():
            print("PHASE", p.name, p.get_cell())
            for atom in p.atoms():
                print("ATOM", atom.label, atom.element, atom.coordinates,
                      atom.refinement_flags, atom.uiso)
    project.save()


if __name__ == "__main__":
    main()
