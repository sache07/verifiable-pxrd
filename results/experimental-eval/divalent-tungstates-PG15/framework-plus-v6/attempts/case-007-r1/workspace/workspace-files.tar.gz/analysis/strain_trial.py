#!/usr/bin/env python3
"""Challenge one phase with isotropic microstrain from a common baseline."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def summarize(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print("SUMMARY", label, hist.residuals, hist.ComputeMassFracs())
    print("FROZEN", project.get_Frozen())
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("PHASE", phase.name, "size", hap["Size"], "strain", hap["Mustrain"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("phase")
    args = parser.parse_args()

    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)

    found = False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 600.0 if phase.name == args.phase else 0.0
        hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [phase.name == args.phase, False, False]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        if phase.name == args.phase:
            found = True
            project.set_Controls("parmMin", 1.0, variable=f"{phase.id}:0:Mustrain;i")
            project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;i")
    if not found:
        raise ValueError(f"phase not found: {args.phase}")

    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    for label in ("fit", "replay", "replay2"):
        project.refine(makeBack=False)
        summarize(project, label)
    project.save()


if __name__ == "__main__":
    main()
