#!/usr/bin/env python3
"""Apply the accepted physical model and reconverge it in stable stages."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def report(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print("SUMMARY", label, hist.residuals, hist.ComputeMassFracs(),
          "FROZEN", project.get_Frozen())
    print("INST", {k: hist.InstrumentParameters[k] for k in
                   ("U", "W", "X", "SH/L", "Zero", "Polariz.")})
    print("SAMPLE", {k: hist.SampleParameters[k] for k in
                     ("Shift", "SurfRoughA", "SurfRoughB")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("PHASE", phase.name, phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "strain", hap["Mustrain"])
        print("ATOMS", [(a.label, a.element, a.coordinates, a.uiso,
                          a.refinement_flags) for a in phase.atoms()])


def refine(project: G2sc.G2Project, label: str) -> None:
    project.refine(makeBack=False)
    report(project, label)
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    args = parser.parse_args()
    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)

    # Fixed common profile selected from the physically allowed profile scan.
    for key, value in (("U", 40.0), ("X", 0.1), ("Zero", 0.0),
                       ("Polariz.", 0.5)):
        hist.InstrumentParameters[key][0] = value
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False
    hist.SampleParameters["SurfRoughA"] = [0.05, False]
    hist.SampleParameters["SurfRoughB"][1] = True
    hist.SampleParameters["Shift"][1] = False

    # Neutralize every unsupported HAP term. Retain only replay-stable widths.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        if phase.name in ("MgWO4", "WO3"):
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1.5
            hap["Size"][1][1] = 1.5
            hap["Size"][2] = [False, False, False]
            hap["Mustrain"][2] = [True, True, False]
        else:
            hap["Size"][2] = [True, False, False]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][1][1] = 0.0
            hap["Mustrain"][2] = [False, False, False]

    # MgWO4's unconstrained shared Uiso fell below the source's physical range;
    # fix it at the lower bound. Other phase Uiso values remain interior.
    for atom in project.phase("MgWO4").atoms():
        atom.uiso = 0.003
        atom.refinement_flags = " "
    for phase_name in ("WO3", "MgO"):
        phase = project.phase(phase_name)
        for i, atom in enumerate(phase.atoms()):
            atom.refinement_flags = " "
            project.set_Controls("parmMin", 0.003,
                                 variable=f"{phase.id}::AUiso:{i}")
            project.set_Controls("parmMax", 0.020,
                                 variable=f"{phase.id}::AUiso:{i}")

    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6

    # Re-equilibrate scales/background/profile first, then cells and geometry.
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
    refine(project, "nuisance")

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    refine(project, "cells")

    hist.SampleParameters["Shift"][1] = True
    refine(project, "geometry")

    # Finally release only the coordinate/Uiso terms supported by challenges.
    for atom in project.phase("MgWO4").atoms():
        atom.refinement_flags = "X"
    for atom in project.phase("WO3").atoms():
        atom.refinement_flags = "XU" if atom.element == "W" else "U"
    for atom in project.phase("MgO").atoms():
        atom.refinement_flags = "U"
    refine(project, "structure")
    refine(project, "replay")


if __name__ == "__main__":
    main()
