#!/usr/bin/env python3
"""Refine one symmetry-linked isotropic displacement parameter per phase."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    args = parser.parse_args()

    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)

    # Hold widths fixed while the high-angle intensity falloff is tested.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        variables = []
        for i, atom in enumerate(phase.atoms()):
            atom.uiso = 0.008
            flags = atom.refinement_flags.replace(" ", "")
            atom.refinement_flags = ("X" if "X" in flags else "") + "U"
            variables.append(f"{phase.id}::AUiso:{i}")
            project.set_Controls("parmMin", 0.001, variable=variables[-1])
            project.set_Controls("parmMax", 0.03, variable=variables[-1])
        if len(variables) > 1:
            project.add_EquivConstr(tuple(variables))

    project.set_Controls("cycles", 18)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    for label in ("fit", "replay"):
        project.refine(makeBack=False)
        print("SUMMARY", label, hist.residuals, hist.ComputeMassFracs())
        print("FROZEN", project.get_Frozen())
        for phase in project.phases():
            print("PHASE", phase.name, phase.get_cell())
            for atom in phase.atoms():
                print("ATOM", atom.label, atom.element, atom.coordinates,
                      atom.refinement_flags, atom.uiso)
    project.save()


if __name__ == "__main__":
    main()
