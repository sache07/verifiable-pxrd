#!/usr/bin/env python3
"""Create a replayable, interior-valued common profile with phase sizes."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def show(project, label: str) -> None:
    hist = project.histogram(0)
    print("SUMMARY", label, hist.residuals, hist.ComputeMassFracs())
    print("inst", {k: hist.InstrumentParameters[k] for k in ("U", "W", "X", "SH/L", "Zero", "Polariz.")})
    print("sample", {k: hist.SampleParameters[k] for k in ("SurfRoughA", "SurfRoughB", "Shift")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("phase", phase.name, "size", hap["Size"], "strain", hap["Mustrain"])
    print("frozen", project.get_Frozen())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    args = parser.parse_args()
    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    hist = project.histogram(0)
    project.set_Frozen()

    for key, val in (("U", 39.0), ("W", 2.2)):
        hist.InstrumentParameters[key][0] = val
        hist.InstrumentParameters[key][1] = val
        hist.InstrumentParameters[key][2] = False
    hist.InstrumentParameters["X"][1] = 2.2
    hist.InstrumentParameters["X"][2] = True
    hist.InstrumentParameters["SH/L"][1] = 0.062
    hist.InstrumentParameters["SH/L"][2] = True
    hist.InstrumentParameters["Polariz."][1] = 0.50
    hist.InstrumentParameters["Polariz."][2] = False
    hist.SampleParameters["SurfRoughA"] = [0.05, False]
    hist.SampleParameters["SurfRoughB"][1] = True

    starts = {"MgWO4": 0.16, "WO3": 0.165, "MgO": 0.17}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = starts[phase.name]
        hap["Size"][1][2] = 1.0
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [False, False, False]

    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    for label in ("fit", "replay", "replay2"):
        project.refine(makeBack=False)
        show(project, label)
    project.save()


if __name__ == "__main__":
    main()
