#!/usr/bin/env python3
"""Compare restrained phase-specific broadening models from one GSAS-II project."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def configure_phase(phase, hist, use_size: bool, use_strain: bool) -> None:
    hap = phase.data["Histograms"][hist.name]
    size = hap["Size"]
    size[0] = "isotropic"
    size[1][0] = 0.30 if use_size else 10.0
    size[1][1] = size[1][0]
    size[1][2] = 1.0
    size[2] = [bool(use_size), False, False]
    size[5] = [False for _ in size[5]]

    strain = hap["Mustrain"]
    strain[0] = "isotropic"
    strain[1][0] = 1200.0 if use_strain else 0.0
    strain[1][1] = strain[1][0]
    strain[1][2] = 1.0
    strain[2] = [bool(use_strain), False, False]
    strain[5] = [False for _ in strain[5]]


def summary(project, label: str) -> None:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    print("SUMMARY", label)
    print("residuals", hist.residuals)
    print("mass_fracs", hist.ComputeMassFracs())
    print("instrument", {k: inst[k][1] for k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")})
    print("sample", {k: hist.SampleParameters[k][0] for k in ("Shift", "SurfRoughA", "SurfRoughB")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("phase", phase.name, "size", hap["Size"], "strain", hap["Mustrain"], "cell", phase.get_cell())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("mode", choices=("size", "strain", "both"))
    args = parser.parse_args()

    output = Path(args.output_gpx).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(output))
    hist = project.histogram(0)
    project.set_Frozen()

    # Start below the observed widths so phase terms, rather than the common
    # profile, are responsible for phase-to-phase differences.
    for key, value in (("U", 20.0), ("W", 15.0), ("X", 2.0), ("SH/L", 0.025)):
        hist.InstrumentParameters[key][0] = value
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = True

    for phase in project.phases():
        configure_phase(
            phase,
            hist,
            use_size=args.mode in ("size", "both"),
            use_strain=args.mode in ("strain", "both"),
        )

    for variable, lower, upper in (
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.001, 0.5),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    for phase in project.phases():
        pid = phase.id
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
    project.set_Controls("cycles", 30)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.save()
    project.refine(makeBack=False)
    summary(project, "fit")
    project.refine(makeBack=False)
    summary(project, "replay")
    project.save()


if __name__ == "__main__":
    main()
