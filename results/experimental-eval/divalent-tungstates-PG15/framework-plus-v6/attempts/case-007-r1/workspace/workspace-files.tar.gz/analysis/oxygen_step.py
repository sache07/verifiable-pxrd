#!/usr/bin/env python3
"""Take one damped WO3 oxygen-coordinate step, then freeze and replay it."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


def show(project: G2sc.G2Project, label: str, starts: dict[str, np.ndarray]) -> None:
    hist = project.histogram(0)
    print("SUMMARY", label, hist.residuals, hist.ComputeMassFracs())
    print("FROZEN", project.get_Frozen())
    phase = project.phase("WO3")
    amat, _ = G2lat.cell2AB(phase.data["General"]["Cell"][1:7])
    for atom in phase.atoms():
        xyz = np.asarray(atom.coordinates, dtype=float)
        delta = xyz - starts[atom.label]
        delta -= np.rint(delta)
        distance = float(np.linalg.norm(amat @ delta))
        print("ATOM", atom.label, atom.element, tuple(xyz),
              atom.refinement_flags, atom.uiso, "shift_A", distance)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("--labels", default="O1,O2,O3,O4,O5,O6")
    args = parser.parse_args()

    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)
    phase = project.phase("WO3")
    starts = {atom.label: np.asarray(atom.coordinates, dtype=float) for atom in phase.atoms()}
    selected = {label.strip() for label in args.labels.split(",") if label.strip()}

    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        for atom in p.atoms():
            atom.refinement_flags = "U" if "U" in atom.refinement_flags else " "
    for atom in phase.atoms():
        if atom.label in selected:
            atom.refinement_flags = "XU"

    project.set_Controls("cycles", 1)
    project.refine(makeBack=False)
    show(project, "one_step", starts)

    for atom in phase.atoms():
        if atom.label in selected:
            atom.refinement_flags = "U"
    project.set_Frozen()
    project.set_Controls("cycles", 18)
    for label in ("fixed_replay", "fixed_replay2"):
        project.refine(makeBack=False)
        show(project, label, starts)
    project.save()


if __name__ == "__main__":
    main()
