#!/usr/bin/env python3
"""Render observed, calculated and residual profiles from a GSAS-II project."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx")
    parser.add_argument("png")
    args = parser.parse_args()
    project = G2sc.G2Project(str(Path(args.gpx).resolve()))
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"))
    yo = np.asarray(hist.getdata("Yobs"))
    yc = np.asarray(hist.getdata("Ycalc"))
    residual = yo - yc
    fig, axes = plt.subplots(3, 1, figsize=(15, 11), constrained_layout=True)
    for ax, (lo, hi) in zip(axes, ((9.9, 100.1), (14, 46), (46, 82))):
        sel = (x >= lo) & (x <= hi)
        ax.plot(x[sel], yo[sel], color="black", lw=0.55, label="observed")
        ax.plot(x[sel], yc[sel], color="tab:red", lw=0.7, label="calculated")
        offset = np.percentile(yo[sel], 2) - 1.1 * np.max(np.abs(residual[sel]))
        ax.plot(x[sel], residual[sel] + offset, color="tab:blue", lw=0.55, label="difference (offset)")
        ax.axhline(offset, color="0.7", lw=0.4)
        ax.set_xlim(lo, hi)
        ax.set_ylabel("counts")
    axes[0].legend(loc="upper right", ncol=3)
    axes[-1].set_xlabel(r"$2\theta$ (deg)")
    fig.suptitle(f"{Path(args.gpx).name}; Rwp={hist.residuals.get('wR', float('nan')):.3f}%")
    fig.savefig(args.png, dpi=150)


if __name__ == "__main__":
    main()
