#!/usr/bin/env python3
"""Fit a restrained complementary size/strain model at a fixed common profile."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def report(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print("SUMMARY", label, hist.residuals, hist.ComputeMassFracs())
    print("FROZEN", project.get_Frozen())
    print("INST", {k: hist.InstrumentParameters[k] for k in ("U", "W", "X", "SH/L", "Zero")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("PHASE", phase.name, "size", hap["Size"], "strain", hap["Mustrain"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("--u", type=float, required=True)
    parser.add_argument("--w", type=float, required=True)
    parser.add_argument("--x", type=float, required=True)
    args = parser.parse_args()

    out = Path(args.output_gpx).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input_gpx).resolve()), newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)

    for key, value in (("U", args.u), ("W", args.w), ("X", args.x)):
        hist.InstrumentParameters[key][0] = value
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False

    # The one-term roughness and axial-divergence corrections remain free;
    # common Gaussian/Lorentzian widths are fixed while phase terms are tested.
    configurations = {
        "MgWO4": (0.50, True, 2400.0, True),
        "WO3": (0.50, True, 4300.0, True),
        "MgO": (0.17, True, 0.0, False),
    }
    for phase in project.phases():
        size, size_flag, strain, strain_flag = configurations[phase.name]
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [size, size, 1.0]
        hap["Size"][2] = [size_flag, False, False]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][1][1] = strain
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [strain_flag, False, False]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMin", 1.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;i")

    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    for label in ("fit", "replay", "replay2"):
        project.refine(makeBack=False)
        report(project, label)
    project.save()


if __name__ == "__main__":
    main()
