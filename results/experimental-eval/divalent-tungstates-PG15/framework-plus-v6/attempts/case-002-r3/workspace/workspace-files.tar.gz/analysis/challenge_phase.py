#!/usr/bin/env python3
"""Add one watch-list phase and challenge its scale under a fixed profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("cif")
    ap.add_argument("name")
    ap.add_argument("--scale", type=float, default=0.1)
    ap.add_argument("--passes", type=int, default=3)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.output).resolve()
    p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out))
    p.set_Frozen()
    p.set_Controls("cycles", 18)
    h = p.histogram(0)
    # Re-establish the common nuisance model after changing the inventory.
    for ph in p.phases():
        ph.set_refinements({"Atoms": {"all": ""}})
        ph.set_refinements({"Cell": True})
        ph.set_HAP_refinements({"Scale": True}, [h])
        hap = ph.data["Histograms"][h.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
    q = p.add_phase(str(Path(args.cif).resolve()), phasename=args.name,
                    histograms=[h], fmthint="CIF")
    q.set_refinements({"Atoms": {"all": ""}})
    q.set_refinements({"Cell": False})
    q.set_HAP_refinements({"Scale": True}, [h])
    hap = q.data["Histograms"][h.name]
    hap["Scale"] = [args.scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = hap["Size"][1][1] = 0.10
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = 7000.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    p.set_Controls("parmMin", 0.0, variable="*:0:Scale")
    rows = []
    for i in range(args.passes):
        p.refine(makeBack=False)
        rows.append({"pass": i + 1, "wR": h.residuals.get("wR"),
                     "candidate_scale": hap["Scale"][0],
                     "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])]})
        print(rows[-1])
    p.save(str(out))
    phases = []
    for ph in p.phases():
        hp = ph.data["Histograms"][h.name]
        phases.append({"name": ph.name, "mass": ph.data["General"]["Mass"],
                       "scale": hp["Scale"][0], "cell": ph.get_cell()})
    amounts = np.array([r["mass"] * r["scale"] for r in phases])
    info = {"residuals": h.residuals, "fractions": (amounts / amounts.sum()).tolist(),
            "phases": phases, "passes": rows}
    out.with_suffix(".json").write_text(json.dumps(info, indent=2) + "\n")
    print(json.dumps(info))


if __name__ == "__main__":
    main()
