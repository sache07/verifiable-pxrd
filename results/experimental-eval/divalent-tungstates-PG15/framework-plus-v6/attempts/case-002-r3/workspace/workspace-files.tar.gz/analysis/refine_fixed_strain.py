#!/usr/bin/env python3
"""Test fixed, physically interior phase-strain values while refining sizes."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("wo3_equatorial", type=float)
    ap.add_argument("bao2_isotropic", type=float)
    ap.add_argument("--wo3-ratio", type=float, default=1.2533548236521204)
    ap.add_argument("--passes", type=int, default=2)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.output).resolve()
    p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out))
    p.set_Frozen()
    p.set_Controls("cycles", 18)
    h = p.histogram(0)
    for ph in p.phases():
        ph.set_refinements({"Atoms": {"all": ""}})
        hap = ph.data["Histograms"][h.name]
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][2] = [False, False, False]
    w = p.phase(0).data["Histograms"][h.name]["Mustrain"]
    w[0] = "uniaxial"
    w[1][0] = args.wo3_equatorial
    w[1][1] = args.wo3_equatorial * args.wo3_ratio
    w[3] = [0, 0, 1]
    b = p.phase(1).data["Histograms"][h.name]["Mustrain"]
    b[0] = "isotropic"
    b[1][0] = b[1][1] = args.bao2_isotropic
    for i in range(args.passes):
        p.refine(makeBack=False)
        print(f"pass {i + 1}: wR={h.residuals.get('wR')}")
    p.save(str(out))
    rows = []
    for ph in p.phases():
        hap = ph.data["Histograms"][h.name]
        rows.append({"name": ph.name, "mass": ph.data["General"]["Mass"],
                     "scale": hap["Scale"][0], "size": hap["Size"],
                     "mustrain": hap["Mustrain"]})
    q = np.array([r["mass"] * r["scale"] for r in rows])
    info = {"wR": h.residuals.get("wR"), "fractions": (q / q.sum()).tolist(),
            "phases": rows,
            "frozen": {str(k): [str(v) for v in vals] for k, vals in
                       p.data["Controls"]["data"].get("parmFrozen", {}).items()}}
    out.with_suffix(".json").write_text(json.dumps(info, indent=2) + "\n")
    print(json.dumps(info))


if __name__ == "__main__":
    main()
