#!/usr/bin/env python3
"""Refine WO3 coordinates against source-like W--O distance restraints."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIstrMain as G2str


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--weight", type=float, required=True)
    ap.add_argument("--esd", type=float, default=0.05)
    ap.add_argument("--network-cutoff", type=float, default=0.0,
                    help="If positive, restrain all source distances below this cutoff")
    ap.add_argument("--passes", type=int, default=3)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.output).resolve()
    p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out))
    p.set_Frozen()
    p.set_Controls("cycles", 24)
    h = p.histogram(0)
    for q in p.phases():
        q.set_refinements({"Atoms": {"all": ""}})
        hap = q.data["Histograms"][h.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]

    ph = p.phase(0)
    start = np.array([a.coordinates for a in ph.atoms()], dtype=float)
    p.data["Restraints"]["data"].setdefault(ph.name, {}).setdefault(
        "Bond", {"wtFactor": 1.0, "Range": 1.1, "Bonds": [], "Use": True}
    )
    ph.clearDistRestraint()
    controls, data = ph.InitDisAgl()
    controls["Factors"] = [3.0, 0.0]
    _, distances, _ = G2str.RetDistAngle(controls, data, dmin=0.5)
    bonds = []
    seen = set()
    for center, rows in distances.items():
        atom = ph.atoms()[center]
        for row in rows:
            target, distance = row[0], float(row[-2])
            if args.network_cutoff > 0:
                include = center <= target and 0.8 < distance < args.network_cutoff
            else:
                include = atom.element == "W" and ph.atoms()[target].element == "O" and distance < 2.30
            key = (min(center, target), max(center, target), round(distance, 5))
            if include and key not in seen:
                seen.add(key)
                bonds.append((center, target, distance))
                # Tight search window distinguishes the two split bonds that
                # connect the same independent atom pair.
                ph.addDistRestraint([center], [target], distance, factor=1.003, ESD=args.esd)
    ph.setDistRestraintWeight(args.weight)
    ph.set_refinements({"Atoms": {"all": "X"}})

    rows = []
    for i in range(args.passes):
        p.refine(makeBack=False)
        rvals = p.data["Covariance"]["data"].get("Rvals", {})
        rows.append({"pass": i + 1, "wR": h.residuals.get("wR"),
                     "gof": rvals.get("GOF"), "restraint_sum": rvals.get("RestraintSum"),
                     "max_shift_esd": rvals.get("Max shft/sig"),
                     "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])]})
        print(rows[-1])
    p.save(str(out))
    cell = ph.get_cell()
    beta = np.deg2rad(cell["angle_beta"])
    lattice = np.array([[cell["length_a"], 0, 0], [0, cell["length_b"], 0],
                        [cell["length_c"] * np.cos(beta), 0, cell["length_c"] * np.sin(beta)]])
    final = np.array([a.coordinates for a in ph.atoms()], dtype=float)
    delta = final - start
    delta -= np.rint(delta)
    moved = np.linalg.norm(delta @ lattice, axis=1)
    info = {"residuals": h.residuals, "passes": rows, "weight": args.weight,
            "esd_A": args.esd, "network_cutoff_A": args.network_cutoff,
            "restraint_count": len(ph._getBondRest("summary")["Bonds"]),
            "source_bonds": bonds, "displacements_A": moved.tolist(),
            "oxygen_rms_A": float(np.sqrt(np.mean(moved[[a.element == "O" for a in ph.atoms()]] ** 2))),
            "tungsten_rms_A": float(np.sqrt(np.mean(moved[[a.element == "W" for a in ph.atoms()]] ** 2))),
            "atoms": [{"label": a.label, "element": a.element, "xyz": list(a.coordinates)} for a in ph.atoms()]}
    out.with_suffix(".json").write_text(json.dumps(info, indent=2) + "\n")
    print(json.dumps(info))


if __name__ == "__main__":
    main()
