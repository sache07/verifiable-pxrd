#!/usr/bin/env python3
"""Refine one symmetry-supported March-Dollase axis for each phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("wo3_axis", nargs=3, type=int)
    ap.add_argument("bao2_axis", nargs=3, type=int)
    ap.add_argument("--ratios", nargs=2, type=float, default=[0.916, 1.10])
    ap.add_argument("--passes", type=int, default=4)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.output).resolve()
    p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out))
    p.set_Frozen()
    p.set_Controls("cycles", 18)
    h = p.histogram(0)
    h.InstrumentParameters["Polariz."][2] = False
    for i, (ph, axis, ratio) in enumerate(zip(p.phases(), [args.wo3_axis, args.bao2_axis], args.ratios)):
        ph.set_refinements({"Atoms": {"all": ""}})
        hap = ph.data["Histograms"][h.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        po = hap["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", ratio, True, list(axis)
        p.set_Controls("parmMin", 0.7, variable=f"{i}:0:MD")
        p.set_Controls("parmMax", 1.4, variable=f"{i}:0:MD")
    rows = []
    for j in range(args.passes):
        p.refine(makeBack=False)
        ratios = [ph.data["Histograms"][h.name]["Pref.Ori."][1] for ph in p.phases()]
        rows.append({"pass": j + 1, "wR": h.residuals.get("wR"), "ratios": ratios,
                     "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])]})
        print(rows[-1])
    p.save(str(out))
    phases = []
    for ph in p.phases():
        hap = ph.data["Histograms"][h.name]
        phases.append({"name": ph.name, "mass": ph.data["General"]["Mass"],
                       "scale": hap["Scale"][0], "cell": ph.get_cell(),
                       "pref_ori": hap["Pref.Ori."]})
    amounts = np.array([r["mass"] * r["scale"] for r in phases])
    info = {"residuals": h.residuals, "fractions": (amounts / amounts.sum()).tolist(),
            "phases": phases, "passes": rows}
    out.with_suffix(".json").write_text(json.dumps(info, indent=2) + "\n")
    print(json.dumps(info))


if __name__ == "__main__":
    main()
