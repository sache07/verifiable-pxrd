#!/usr/bin/env python3
"""Branch a common GSAS-II baseline into phase-profile refinement trials."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def reset_instrument(project, values: tuple[float, float, float], refine: bool) -> None:
    project.set_Frozen()
    hist = project.histogram(0)
    for key, value in zip(("U", "W", "X"), values):
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = refine
    for key in ["V", "Y", "Z"]:
        hist.InstrumentParameters[key][1] = 0.0
        hist.InstrumentParameters[key][2] = False


def set_size(phase, hist_name: str, refine: bool, value: float = 0.5) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = value
    hap["Size"][1][1] = value
    hap["Size"][2] = [refine, False, False]


def set_strain(phase, hist_name: str, refine: bool, value: float = 1000.0) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = value
    hap["Mustrain"][1][1] = value
    hap["Mustrain"][2] = [refine, False, False]


def summary(project) -> dict:
    h = project.histogram(0)
    phases = []
    for p in project.phases():
        hap = p.data["Histograms"][h.name]
        phases.append({
            "name": p.name,
            "cell": p.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        })
    return {
        "residuals": h.residuals,
        "instrument": {k: v[1] for k, v in h.InstrumentParameters.items() if isinstance(v, list) and len(v) > 1},
        "shift": h.SampleParameters["Shift"][0],
        "phases": phases,
        "vary_list": [str(v) for v in (project.get_VaryList() or [])],
        "frozen": {str(k): [str(v) for v in vals] for k, vals in project.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--wo3-size", action="store_true")
    ap.add_argument("--wo3-strain", action="store_true")
    ap.add_argument("--bao2-size", action="store_true")
    ap.add_argument("--bao2-strain", action="store_true")
    ap.add_argument("--instrument", nargs=3, type=float, default=[20.0, 10.0, 2.0], metavar=("U", "W", "X"))
    ap.add_argument("--refine-instrument", action="store_true")
    ap.add_argument("--passes", type=int, default=4)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    p.set_Controls("cycles", 18)
    reset_instrument(p, tuple(args.instrument), args.refine_instrument)
    h = p.histogram(0)
    wo3, bao2 = p.phases()[:2]
    set_size(wo3, h.name, args.wo3_size, 0.5 if args.wo3_size else 10.0)
    set_strain(wo3, h.name, args.wo3_strain, 500.0 if args.wo3_strain else 0.0)
    set_size(bao2, h.name, args.bao2_size, 0.3 if args.bao2_size else 10.0)
    set_strain(bao2, h.name, args.bao2_strain, 3500.0 if args.bao2_strain else 0.0)

    # Generator-supported physical ranges, with positive shared profile terms.
    for var, lo, hi in [
        ("*:0:U", 0.0, 40.0), ("*:0:W", 2.0, 40.0), ("*:0:X", 0.1, 6.0),
        ("*:0:Size;i", 0.02, 5.0), ("*:0:Mustrain;i", 0.0, 12000.0),
    ]:
        p.set_Controls("parmMin", lo, variable=var)
        p.set_Controls("parmMax", hi, variable=var)

    pass_residuals = []
    for i in range(args.passes):
        p.refine(makeBack=False)
        pass_residuals.append(dict(p.histogram(0).residuals))
        print(f"pass {i + 1}: wR={p.histogram(0).residuals.get('wR')}")
    p.save(str(output))
    info = summary(p)
    info["pass_residuals"] = pass_residuals
    output.with_suffix(".json").write_text(json.dumps(info, indent=2, allow_nan=False) + "\n")
    print(json.dumps(info, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
