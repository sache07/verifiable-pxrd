#!/usr/bin/env python3
"""Refine selected atom coordinates with bounded per-pass fractional shifts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("phase", type=int)
    ap.add_argument("indices", nargs="+", type=int)
    ap.add_argument("--bound-frac", type=float, default=0.01)
    ap.add_argument("--passes", type=int, default=1)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.output).resolve()
    p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out))
    p.set_Frozen()
    p.set_Controls("cycles", 18)
    h = p.histogram(0)
    for ph in p.phases():
        ph.set_refinements({"Atoms": {"all": ""}})
        hap = ph.data["Histograms"][h.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
    ph = p.phase(args.phase)
    for i in args.indices:
        ph.atoms()[i].refinement_flags = "X"
        if args.bound_frac > 0:
            for key in ("dAx", "dAy", "dAz"):
                p.set_Controls("parmMin", -args.bound_frac, variable=f"{args.phase}::{key}:{i}")
                p.set_Controls("parmMax", args.bound_frac, variable=f"{args.phase}::{key}:{i}")
    rows = []
    for j in range(args.passes):
        p.refine(makeBack=False)
        rows.append({"pass": j + 1, "wR": h.residuals.get("wR"),
                     "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])]})
        print(rows[-1])
    p.save(str(out))
    phases = []
    for phase in p.phases():
        hap = phase.data["Histograms"][h.name]
        phases.append({"name": phase.name, "mass": phase.data["General"]["Mass"],
                       "scale": hap["Scale"][0], "cell": phase.get_cell(),
                       "atoms": [{"label": a.label, "element": a.element,
                                  "xyz": list(a.coordinates), "flags": a.refinement_flags}
                                 for a in phase.atoms()]})
    amounts = np.array([r["mass"] * r["scale"] for r in phases])
    info = {"residuals": h.residuals, "fractions": (amounts / amounts.sum()).tolist(),
            "phases": phases, "passes": rows,
            "vary_list": [str(v) for v in (p.get_VaryList() or [])]}
    out.with_suffix(".json").write_text(json.dumps(info, indent=2) + "\n")
    print(json.dumps(info))


if __name__ == "__main__":
    main()
