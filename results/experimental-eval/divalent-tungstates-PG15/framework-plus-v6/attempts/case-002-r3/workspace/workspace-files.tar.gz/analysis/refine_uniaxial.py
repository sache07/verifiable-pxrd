#!/usr/bin/env python3
"""Test one symmetry-supported uniaxial microstrain model at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("phase", type=int)
    ap.add_argument("axis", nargs=3, type=int)
    ap.add_argument("--passes", type=int, default=3)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    p.set_Frozen()
    p.set_Controls("cycles", 18)
    h = p.histogram(0)
    h.InstrumentParameters["Polariz."][2] = False
    for ph in p.phases():
        ph.set_refinements({"Atoms": {"all": ""}})
        hap = ph.data["Histograms"][h.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]

    ph = p.phase(args.phase)
    hap = ph.data["Histograms"][h.name]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = 7000.0
    hap["Mustrain"][1][1] = 8000.0
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = list(args.axis)
    p.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;i")
    p.set_Controls("parmMax", 8000.0, variable=f"{args.phase}:0:Mustrain;i")
    p.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;a")
    p.set_Controls("parmMax", 32000.0, variable=f"{args.phase}:0:Mustrain;a")

    values = []
    for i in range(args.passes):
        p.refine(makeBack=False)
        values.append({"pass": i + 1, "wR": h.residuals.get("wR"),
                       "mustrain": list(hap["Mustrain"][1]),
                       "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])]})
        print(values[-1])
    p.save(str(output))
    result = {"phase": ph.name, "axis": list(args.axis), "residuals": h.residuals,
              "mustrain": hap["Mustrain"], "passes": values,
              "cells": [q.get_cell() for q in p.phases()]}
    output.with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
