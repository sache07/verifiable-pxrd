#!/usr/bin/env python3
"""Test one March-Dollase axis under an otherwise common fixed profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("phase", type=int)
    ap.add_argument("axis", nargs=3, type=int)
    ap.add_argument("--passes", type=int, default=3)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.output).resolve()
    p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out))
    p.set_Frozen()
    p.set_Controls("cycles", 18)
    h = p.histogram(0)
    h.InstrumentParameters["Polariz."][2] = False
    for ph in p.phases():
        ph.set_refinements({"Atoms": {"all": ""}})
        hap = ph.data["Histograms"][h.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    ph = p.phase(args.phase)
    po = ph.data["Histograms"][h.name]["Pref.Ori."]
    po[1] = 1.0
    po[2] = True
    po[3] = list(args.axis)
    p.set_Controls("parmMin", 0.7, variable=f"{args.phase}:0:MD")
    p.set_Controls("parmMax", 1.4, variable=f"{args.phase}:0:MD")
    rows = []
    for i in range(args.passes):
        p.refine(makeBack=False)
        rows.append({"pass": i + 1, "wR": h.residuals.get("wR"),
                     "ratio": po[1],
                     "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])]})
        print(rows[-1])
    p.save(str(out))
    result = {"phase": ph.name, "axis": list(args.axis), "pref_ori": po,
              "residuals": h.residuals, "passes": rows,
              "cells": [q.get_cell() for q in p.phases()]}
    out.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
