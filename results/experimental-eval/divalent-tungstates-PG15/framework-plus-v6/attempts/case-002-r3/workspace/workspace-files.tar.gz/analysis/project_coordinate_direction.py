#!/usr/bin/env python3
"""Shrink an unconstrained coordinate direction to physical element-wise RMS targets."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("source")
    ap.add_argument("direction")
    ap.add_argument("output")
    ap.add_argument("--oxygen-rms-A", type=float, required=True)
    ap.add_argument("--tungsten-rms-A", type=float, required=True)
    ap.add_argument("--passes", type=int, default=3)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.output).resolve()
    p = G2.G2Project(gpxfile=str(Path(args.source).resolve()), newgpx=str(out))
    q = G2.G2Project(gpxfile=str(Path(args.direction).resolve()))
    p.set_Frozen()
    p.set_Controls("cycles", 18)
    h = p.histogram(0)
    for ph in p.phases():
        ph.set_refinements({"Atoms": {"all": ""}})
        hap = ph.data["Histograms"][h.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]

    ph, dq = p.phase(0), q.phase(0)
    source = np.array([a.coordinates for a in ph.atoms()], float)
    trial = np.array([a.coordinates for a in dq.atoms()], float)
    delta = trial - source
    delta -= np.rint(delta)
    cell = ph.get_cell()
    beta = np.deg2rad(cell["angle_beta"])
    lattice = np.array([[cell["length_a"], 0, 0], [0, cell["length_b"], 0],
                        [cell["length_c"] * np.cos(beta), 0,
                         cell["length_c"] * np.sin(beta)]])
    elements = np.array([a.element for a in ph.atoms()])
    mult = np.array([a.mult for a in ph.atoms()], float)
    targets = {"O": args.oxygen_rms_A, "W": args.tungsten_rms_A}
    scales = {}
    for element, target in targets.items():
        mask = elements == element
        distances = np.linalg.norm(delta[mask] @ lattice, axis=1)
        rms = np.sqrt(np.sum(mult[mask] * distances ** 2) / np.sum(mult[mask]))
        scales[element] = float(target / rms)
        delta[mask] *= scales[element]
    for atom, xyz in zip(ph.atoms(), source + delta):
        atom.coordinates = tuple(xyz)
        atom.refinement_flags = ""

    rows = []
    for i in range(args.passes):
        p.refine(makeBack=False)
        rv = p.data["Covariance"]["data"].get("Rvals", {})
        rows.append({"pass": i + 1, "wR": h.residuals.get("wR"),
                     "max_shift_esd": rv.get("Max shft/sig"),
                     "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])]})
        print(rows[-1])
    p.save(str(out))
    phases = []
    for phase in p.phases():
        hap = phase.data["Histograms"][h.name]
        phases.append({"name": phase.name, "mass": phase.data["General"]["Mass"],
                       "scale": hap["Scale"][0], "cell": phase.get_cell(),
                       "atoms": [{"label": a.label, "element": a.element,
                                  "xyz": list(a.coordinates)} for a in phase.atoms()]})
    amounts = np.array([x["mass"] * x["scale"] for x in phases])
    result = {"residuals": h.residuals, "passes": rows, "targets_A": targets,
              "direction_scales": scales, "fractions": (amounts / amounts.sum()).tolist(),
              "phases": phases}
    out.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
