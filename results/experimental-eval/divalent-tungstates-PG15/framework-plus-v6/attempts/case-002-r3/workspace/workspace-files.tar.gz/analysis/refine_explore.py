#!/usr/bin/env python3
"""Build and refine trial GSAS-II models for the supplied powder pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
SOURCES = {
    "wo3_1528915": ("monoclinic_WO3", "1528915"),
    "wo3_2311041": ("monoclinic_WO3_alt", "2311041"),
    "wo3_1010618": ("monoclinic_WO3_P21m", "1010618"),
    "bao2_1010113": ("tetragonal_BaO2", "1010113"),
    "bawo4_1527204": ("scheelite_BaWO4", "1527204"),
    "ba3wo6_1534803": ("Ba3WO6", "1534803"),
    "ba3w2o9_1533878": ("Ba3W2O9", "1533878"),
}


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_xye(path: Path) -> None:
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(path, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")


def neutralize_hap(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][1][1] = 10.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    result = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "sample": {k: (v[0] if isinstance(v, list) else v) for k, v in hist.SampleParameters.items()},
        "background": list(hist.Background[0]),
        "phases": [],
        "vary_list": [str(v) for v in (project.get_VaryList() or [])],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "mass": phase.data["General"]["Mass"],
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        })
    return result


def refine(project, label: str, log: list[dict]) -> None:
    project.refine(makeBack=False)
    log.append(snapshot(project, label))
    print(label, json.dumps(log[-1]["residuals"], sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", default="baseline")
    parser.add_argument("--phases", nargs="+", default=["wo3_1528915", "bao2_1010113"])
    parser.add_argument("--background", default="chebyschev-1")
    parser.add_argument("--n-background", type=int, default=12)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = ROOT / ".tmp" / args.name
    outdir.mkdir(parents=True, exist_ok=True)
    xye = outdir / "pattern.xye"
    prepare_xye(xye)
    project = G2.G2Project(newgpx=str(outdir / "trial.gpx"))
    hist = project.add_powder_histogram(
        str(xye), str(ROOT / "analysis/instrument.instprm"), fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]

    phases = []
    for key in args.phases:
        phase_name, cod_id = SOURCES[key]
        phase = project.add_phase(
            str(cod_path(cod_id)), phasename=phase_name, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase, hist.name)
        phases.append(phase)

    # A smooth common background. The constant starts near the observed mean;
    # all other terms start neutral and are solved linearly in the first pass.
    hist.set_refinements({"Background": {
        "type": args.background,
        "no. coeffs": args.n_background,
        "coeffs": [500.0] + [0.0] * (args.n_background - 1),
        "refine": True,
    }})
    hist.set_refinements({"Limits": [10.0, 100.0]})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])

    project.set_Controls("cycles", 12)
    # Keep the baseline profile physically nonnegative and the sole angular
    # correction within the laboratory specimen-displacement range.
    for var, lo, hi in [
        ("*:0:U", 0.0, 50.0), ("*:0:W", 0.05, 50.0), ("*:0:X", 0.0, 8.0),
        ("*:0:SH/L", 0.002, 0.2), ("*:0:Shift", -800.0, 800.0),
    ]:
        project.set_Controls("parmMin", lo, variable=var)
        project.set_Controls("parmMax", hi, variable=var)

    log: list[dict] = []
    refine(project, "background_scales", log)

    # One angular correction, then cells, while background and scales remain live.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "shift", log)
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells", log)

    # Establish a shared low-dimensional instrument profile.
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(project, "profile_WX", log)
    hist.set_refinements({"Instrument Parameters": ["U"]})
    refine(project, "profile_UWX", log)

    project.save(str(outdir / "trial.gpx"))
    (outdir / "refinement_log.json").write_text(json.dumps(log, indent=2, allow_nan=False) + "\n")
    print(json.dumps(snapshot(project, "final"), indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
