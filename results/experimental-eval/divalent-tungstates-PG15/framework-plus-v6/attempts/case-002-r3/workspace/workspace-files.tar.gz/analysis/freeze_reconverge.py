#!/usr/bin/env python3
"""Freeze structural/profile terms and reconverge the common nuisance model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--passes", type=int, default=3)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    out = Path(args.output).resolve()
    p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out))
    p.set_Frozen()
    p.set_Controls("cycles", 18)
    h = p.histogram(0)
    for ph in p.phases():
        ph.set_refinements({"Atoms": {"all": ""}})
        hap = ph.data["Histograms"][h.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
    rows = []
    for i in range(args.passes):
        p.refine(makeBack=False)
        rv = p.data["Covariance"]["data"].get("Rvals", {})
        rows.append({"pass": i + 1, "wR": h.residuals.get("wR"),
                     "max_shift_esd": rv.get("Max shft/sig"),
                     "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])]})
        print(rows[-1])
    p.save(str(out))
    phases = []
    for ph in p.phases():
        hap = ph.data["Histograms"][h.name]
        phases.append({"name": ph.name, "mass": ph.data["General"]["Mass"],
                       "scale": hap["Scale"][0], "cell": ph.get_cell(),
                       "atoms": [{"label": a.label, "element": a.element,
                                  "xyz": list(a.coordinates), "flags": a.refinement_flags}
                                 for a in ph.atoms()]})
    amounts = np.array([x["mass"] * x["scale"] for x in phases])
    result = {"residuals": h.residuals, "passes": rows,
              "fractions": (amounts / amounts.sum()).tolist(), "phases": phases}
    out.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
