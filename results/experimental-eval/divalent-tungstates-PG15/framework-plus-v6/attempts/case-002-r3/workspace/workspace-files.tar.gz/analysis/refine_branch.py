#!/usr/bin/env python3
"""Apply controlled refinement changes to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--passes", type=int, default=3)
    ap.add_argument("--shl", action="store_true")
    ap.add_argument("--polarization", action="store_true")
    ap.add_argument("--roughness", action="store_true")
    ap.add_argument("--atom-x", nargs="*", type=int, default=[])
    ap.add_argument("--atom-u", nargs="*", type=int, default=[])
    ap.add_argument("--common-u", nargs="*", type=int, default=[])
    ap.add_argument("--full-range", action="store_true")
    ap.add_argument("--clear-frozen", action="store_true")
    ap.add_argument("--profile-values", nargs=3, type=float, metavar=("U", "W", "X"))
    ap.add_argument("--refine-profile", action="store_true")
    ap.add_argument("--strain-values", nargs="*", type=float)
    ap.add_argument("--refine-strain", nargs="*", type=int, default=[])
    ap.add_argument("--size-values", nargs="*", type=float)
    ap.add_argument("--refine-size", nargs="*", type=int, default=[])
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    p.set_Controls("cycles", 18)
    h = p.histogram(0)
    if args.clear_frozen:
        p.set_Frozen()
    if args.full_range:
        x = h.data["data"][1][0]
        h.set_refinements({"Limits": [float(x[0]), float(x[-1])]})

    if args.shl:
        h.InstrumentParameters["SH/L"][2] = True
        p.set_Controls("parmMin", 0.002, variable="*:0:SH/L")
        p.set_Controls("parmMax", 0.12, variable="*:0:SH/L")
    if args.polarization:
        h.InstrumentParameters["Polariz."][2] = True
        p.set_Controls("parmMin", 0.5, variable="*:0:Polariz.")
        p.set_Controls("parmMax", 1.0, variable="*:0:Polariz.")
    if args.roughness:
        h.SampleParameters["SurfRoughA"] = [0.25, True]
        h.SampleParameters["SurfRoughB"] = [0.10, True]
        p.set_Controls("parmMin", 0.001, variable="*:0:SurfRoughA")
        p.set_Controls("parmMax", 0.8, variable="*:0:SurfRoughA")
        p.set_Controls("parmMin", 0.001, variable="*:0:SurfRoughB")
        p.set_Controls("parmMax", 1.0, variable="*:0:SurfRoughB")

    if args.profile_values is not None:
        for key, value in zip(("U", "W", "X"), args.profile_values):
            h.InstrumentParameters[key][1] = value
            h.InstrumentParameters[key][2] = args.refine_profile
    elif args.refine_profile:
        for key in ("U", "W", "X"):
            h.InstrumentParameters[key][2] = True
    for key, lo, hi in (("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0)):
        p.set_Controls("parmMin", lo, variable=f"*:0:{key}")
        p.set_Controls("parmMax", hi, variable=f"*:0:{key}")

    refine_strain = set(args.refine_strain)
    refine_size = set(args.refine_size)
    for i, ph in enumerate(p.phases()):
        hap = ph.data["Histograms"][h.name]
        if args.strain_values is not None:
            value = args.strain_values[i]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = value
            hap["Mustrain"][1][1] = value
        hap["Mustrain"][2] = [i in refine_strain, False, False]
        if args.size_values is not None:
            value = args.size_values[i]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = value
            hap["Size"][1][1] = value
        hap["Size"][2] = [i in refine_size, False, False]
    p.set_Controls("parmMin", 0.0, variable="*:0:Mustrain;i")
    p.set_Controls("parmMax", 8000.0, variable="*:0:Mustrain;i")
    p.set_Controls("parmMin", 0.04, variable="*:0:Size;i")
    p.set_Controls("parmMax", 1.5, variable="*:0:Size;i")

    atom_x = set(args.atom_x)
    atom_u = set(args.atom_u)
    common_u = set(args.common_u)
    for i, ph in enumerate(p.phases()):
        if i in common_u:
            for atom in ph.atoms():
                atom.uiso = 0.01
        if i in atom_x or i in atom_u or i in common_u:
            flags = ("X" if i in atom_x else "") + ("U" if i in atom_u or i in common_u else "")
            ph.set_refinements({"Atoms": {"all": flags}})
            if i in atom_u or i in common_u:
                p.set_Controls("parmMin", 0.001, variable=f"{i}::AUiso:*")
                p.set_Controls("parmMax", 0.04, variable=f"{i}::AUiso:*")
        if i in common_u and len(ph.atoms()) > 1:
            p.add_EquivConstr(tuple(f"{i}::AUiso:{j}" for j in range(len(ph.atoms()))))

    pass_info = []
    for i in range(args.passes):
        p.refine(makeBack=False)
        rec = {"pass": i + 1, "residuals": dict(h.residuals),
               "max_shift_esd": p.data.get("Covariance", {}).get("data", {}).get("Max shft/sig")}
        pass_info.append(rec)
        print(f"pass {i + 1}: wR={h.residuals.get('wR')}")
    p.save(str(output))

    phases = []
    for ph in p.phases():
        hap = ph.data["Histograms"][h.name]
        phases.append({
            "name": ph.name,
            "cell": ph.get_cell(),
            "scale": hap["Scale"][0],
            "mass": ph.data["General"]["Mass"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
            "atoms": [{"label": a.label, "element": a.element, "xyz": list(a.coordinates),
                       "uiso": a.uiso, "flags": a.refinement_flags} for a in ph.atoms()],
        })
    masses = np.array([r["mass"] * r["scale"] for r in phases])
    result = {
        "residuals": h.residuals,
        "instrument": {k: v[1] for k, v in h.InstrumentParameters.items() if isinstance(v, list) and len(v) > 1},
        "sample": {k: (v[0] if isinstance(v, list) else v) for k, v in h.SampleParameters.items()},
        "fractions": (masses / masses.sum()).tolist(),
        "phases": phases,
        "passes": pass_info,
        "vary_list": [str(v) for v in (p.get_VaryList() or [])],
        "frozen": {str(k): [str(v) for v in vals] for k, vals in p.data["Controls"]["data"].get("parmFrozen", {}).items()},
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
