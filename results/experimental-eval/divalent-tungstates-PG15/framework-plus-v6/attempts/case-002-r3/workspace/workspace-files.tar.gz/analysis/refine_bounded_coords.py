#!/usr/bin/env python3
"""Fit WO3 coordinates inside a hard, source-centered displacement envelope."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--oxygen-max-A", type=float, required=True)
    ap.add_argument("--metal-max-A", type=float, default=0.04)
    ap.add_argument("--passes", type=int, default=1)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.output).resolve()
    p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out))
    p.set_Frozen()
    p.set_Controls("cycles", 24)
    h = p.histogram(0)
    for q in p.phases():
        q.set_refinements({"Atoms": {"all": ""}})
        hap = q.data["Histograms"][h.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
    ph = p.phase(0)
    atoms = ph.atoms()
    start = np.array([a.coordinates for a in atoms], float)
    cell = ph.get_cell()
    axis_lengths = np.array([cell["length_a"], cell["length_b"], cell["length_c"]])
    for i, atom in enumerate(atoms):
        radius = args.oxygen_max_A if atom.element == "O" else args.metal_max_A
        # A cube inscribed in the requested Cartesian displacement sphere.
        frac = radius / np.sqrt(3.0) / axis_lengths
        for j, key in enumerate(("dAx", "dAy", "dAz")):
            p.set_Controls("parmMin", float(start[i, j] - frac[j]), variable=f"0::{key}:{i}")
            p.set_Controls("parmMax", float(start[i, j] + frac[j]), variable=f"0::{key}:{i}")
    ph.set_refinements({"Atoms": {"all": "X"}})

    rows = []
    for j in range(args.passes):
        p.refine(makeBack=False)
        rv = p.data["Covariance"]["data"].get("Rvals", {})
        rows.append({"pass": j + 1, "wR": h.residuals.get("wR"),
                     "max_shift_esd": rv.get("Max shft/sig"),
                     "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])]})
        print(rows[-1])
    p.save(str(out))
    beta = np.deg2rad(ph.get_cell()["angle_beta"])
    lattice = np.array([[ph.get_cell()["length_a"], 0, 0], [0, ph.get_cell()["length_b"], 0],
                        [ph.get_cell()["length_c"] * np.cos(beta), 0,
                         ph.get_cell()["length_c"] * np.sin(beta)]])
    final = np.array([a.coordinates for a in atoms], float)
    delta = final - start
    delta -= np.rint(delta)
    moved = np.linalg.norm(delta @ lattice, axis=1)
    oxygen = np.array([a.element == "O" for a in atoms])
    result = {"residuals": h.residuals, "passes": rows,
              "oxygen_max_A": args.oxygen_max_A, "metal_max_A": args.metal_max_A,
              "displacements_A": moved.tolist(),
              "oxygen_rms_A": float(np.sqrt(np.mean(moved[oxygen] ** 2))),
              "tungsten_rms_A": float(np.sqrt(np.mean(moved[~oxygen] ** 2))),
              "atoms": [{"label": a.label, "element": a.element, "xyz": list(a.coordinates)} for a in atoms]}
    out.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
