#!/usr/bin/env python3
"""Re-challenge polarization and axial-divergence terms independently."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/geometry/shift_-600.gpx")


def main() -> None:
    mode = sys.argv[1]
    out = Path(".tmp/angular_profile") / f"{mode}.gpx"
    out.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.filename = str(out)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    hist = project.histogram(0)
    inst = hist.InstrumentParameters

    if mode in {"fixed_shl", "both_fixed"}:
        inst["SH/L"][1], inst["SH/L"][2] = 0.03, False
    else:
        inst["SH/L"][2] = True
    if mode in {"fixed_polarization", "both_fixed"}:
        inst["Polariz."][1], inst["Polariz."][2] = 0.7, False
    else:
        inst["Polariz."][2] = True

    project.set_Controls("cycles", 25)
    project.refine(makeBack=False)
    project.save(str(out))
    project = G2.G2Project(gpxfile=str(out))
    project.filename = str(out)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 25)
    project.refine(makeBack=False)
    project.save(str(out))

    hist = project.histogram(0)
    phases = project.phases()
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
              for p in phases]
    total = sum(masses)
    result = {
        "mode": mode,
        "Rwp": hist.get_wR(),
        "SH_L": hist.InstrumentParameters["SH/L"][1],
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "shift_um": hist.SampleParameters["Shift"][0],
        "fractions": {p.name: m / total for p, m in zip(phases, masses)},
        "residuals": hist.residuals,
    }
    out.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
