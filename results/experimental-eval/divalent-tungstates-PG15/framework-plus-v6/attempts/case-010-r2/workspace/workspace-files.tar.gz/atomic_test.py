#!/usr/bin/env python3
"""Rebuild a physical two-phase profile and test staged coordinate refinement."""

from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2, GSASIIlattice as G2lat


SOURCE = Path(".tmp/wo3_mn2o3_61/screen.gpx")
OUT = Path(".tmp/atomic_test.gpx")


def set_cell(phase, cell):
    phase.data["General"]["Cell"][1:7] = list(cell)
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def state(project, hist, label):
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
              for p in project.phases()]
    total = sum(masses)
    row = {
        "stage": label,
        "Rwp": hist.get_wR(),
        "GOF": hist.residuals.get("GOF"),
        "fractions": {p.name: m / total for p, m in zip(project.phases(), masses)},
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "zero": hist.data["Instrument Parameters"][0]["Zero"][1],
        "profile": {k: hist.data["Instrument Parameters"][0][k][1]
                    for k in ["U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]},
        "phase_profile": {
            p.name: {
                "size": copy.deepcopy(p.data["Histograms"][hist.name]["Size"]),
                "mustrain": copy.deepcopy(p.data["Histograms"][hist.name]["Mustrain"]),
            }
            for p in project.phases()
        },
        "coordinates": {
            p.name: {a.label: list(a.coordinates) for a in p.atoms()} for p in project.phases()
        },
    }
    print(label, "Rwp", row["Rwp"], "fractions", row["fractions"], flush=True)
    return row


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.filename = str(OUT)
    hist = project.histogram(0)
    wo3, mn2o3 = project.phases()

    # Reset the unstable screening-only Mn2O3 distortion.
    set_cell(mn2o3, [9.4118, 9.4177, 9.4233, 90.0, 90.0, 90.0])
    mn2o3.set_refinements({"Cell": False})
    wo3.set_refinements({"Cell": True})

    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 20.0, "W": 20.0, "X": 2.0}.items():
        inst[key][1] = value
        inst[key][2] = False
    # Start from a narrow common instrumental profile, with broadening assigned
    # to the visibly broader WO3 phase.
    wo3.setSampleProfile(hist, "size", "isotropic", 0.10, LGmix=1.0)
    wo3.setSampleProfile(hist, "microstrain", "isotropic", 2000.0, LGmix=1.0)
    mn2o3.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=1.0)
    mn2o3.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    for phase in (wo3, mn2o3):
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "

    project.update_ids()
    for parameter in ("U", "W", "X", "SH/L"):
        project.set_Controls("parmMin", 0.0, variable=f":0:{parameter}")
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.set_Controls("cycles", 15)

    history = []
    project.refine(makeBack=False)
    history.append(state(project, hist, "physical_reset"))

    # Establish a nonnegative common profile with phase broadening held fixed.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine(makeBack=False)
    history.append(state(project, hist, "common_profile"))

    # Correct cancellation-sensitive WO3 intensities in small, interpretable steps.
    for atom in wo3.atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"
    project.refine(makeBack=False)
    history.append(state(project, hist, "wo3_W_coordinates"))

    for atom in wo3.atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    project.refine(makeBack=False)
    history.append(state(project, hist, "wo3_all_coordinates"))

    # Unknown polarization can otherwise masquerade as an angle-dependent
    # structure-factor trend. SH/L is tested at the same baseline stage.
    hist.set_refinements({"Instrument Parameters": ["Polariz.", "SH/L"]})
    project.refine(makeBack=False)
    history.append(state(project, hist, "polarization_asymmetry"))

    project.save(str(OUT))
    Path(".tmp/atomic_test.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
