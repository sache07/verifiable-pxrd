#!/usr/bin/env python3
"""Staged structural refinement of the physically valid WO3/Mn2O3 model."""

from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/alt_2311041/screen.gpx")
OUT = Path(".tmp/candidate231.gpx")


def capture(project, hist, label):
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
              for p in project.phases()]
    total = sum(masses)
    row = {
        "stage": label,
        "Rwp": hist.get_wR(),
        "residuals": copy.deepcopy(hist.residuals),
        "fractions": {p.name: m / total for p, m in zip(project.phases(), masses)},
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "instrument": {k: copy.deepcopy(v) for k, v in hist.data["Instrument Parameters"][0].items()},
        "phase_profile": {
            p.name: {
                "size": copy.deepcopy(p.data["Histograms"][hist.name]["Size"]),
                "mustrain": copy.deepcopy(p.data["Histograms"][hist.name]["Mustrain"]),
            }
            for p in project.phases()
        },
        "coordinates": {
            p.name: {a.label: list(a.coordinates) for a in p.atoms()} for p in project.phases()
        },
    }
    print(label, row["Rwp"], row["fractions"], flush=True)
    return row


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.filename = str(OUT)
    hist = project.histogram(0)
    wo3, mn2o3 = project.phases()
    project.set_Controls("cycles", 12)
    project.update_ids()
    for parameter in ("U", "W", "X", "SH/L"):
        project.set_Controls("parmMin", 0.0, variable=f":0:{parameter}")
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    for phase in (wo3, mn2o3):
        for atom in phase.atoms():
            atom.refinement_flags = " "

    history = [capture(project, hist, "source")]

    hist.set_refinements({"Instrument Parameters": ["Polariz.", "SH/L"]})
    project.refine(makeBack=False)
    history.append(capture(project, hist, "polarization_asymmetry"))

    for atom in wo3.atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"
    project.refine(makeBack=False)
    history.append(capture(project, hist, "wo3_W"))

    for atom in wo3.atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    project.refine(makeBack=False)
    history.append(capture(project, hist, "wo3_all"))

    for atom in mn2o3.atoms():
        if atom.element == "Mn":
            atom.refinement_flags = "X"
    project.refine(makeBack=False)
    history.append(capture(project, hist, "mn2o3_Mn"))

    for atom in mn2o3.atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    project.refine(makeBack=False)
    history.append(capture(project, hist, "all_coordinates"))

    project.save(str(OUT))
    Path(".tmp/candidate231.json").write_text(json.dumps(history, indent=2) + "\n")
    for i, phase in enumerate(project.phases()):
        phase.export_CIF(f".tmp/candidate231_phase_{i}.cif")


if __name__ == "__main__":
    main()
