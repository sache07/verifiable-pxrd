#!/usr/bin/env python3
"""Build the accepted two-phase model from registration-normalized CIFs."""

from __future__ import annotations

import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(".tmp/normalized_baseline")


def prepare_files():
    ROOT.mkdir(parents=True, exist_ok=True)
    a = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
    xye = ROOT / "pattern.xye"
    np.savetxt(xye, np.c_[a, np.sqrt(np.maximum(a[:, 1], 1.0))], fmt="%.10g")
    inst = ROOT / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha laboratory instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.30;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def capture(project, hist, label):
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
              for p in project.phases()]
    total = sum(masses)
    row = {
        "stage": label,
        "Rwp": hist.get_wR(),
        "residuals": copy.deepcopy(hist.residuals),
        "fractions": {p.name: m / total for p, m in zip(project.phases(), masses)},
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "instrument": copy.deepcopy(hist.data["Instrument Parameters"][0]),
        "background": copy.deepcopy(hist.data["Background"]),
        "profiles": {
            p.name: {
                "size": copy.deepcopy(p.data["Histograms"][hist.name]["Size"]),
                "mustrain": copy.deepcopy(p.data["Histograms"][hist.name]["Mustrain"]),
            }
            for p in project.phases()
        },
        "coordinates": {
            p.name: {a.label: list(a.coordinates) for a in p.atoms()} for p in project.phases()
        },
    }
    print(label, row["Rwp"], row["fractions"], flush=True)
    project.save(str(ROOT / f"{len(HISTORY):02d}_{label}.gpx"))
    return row


HISTORY = []


def main():
    G2.SetPrintLevel("warn")
    xye, instfile = prepare_files()
    project = G2.G2Project(newgpx=str(ROOT / "working.gpx"))
    wo3 = project.add_phase(".tmp/normalized_2311041.cif", phasename="WO3_gamma", fmthint="CIF")
    mn2o3 = project.add_phase(".tmp/normalized_1514103.cif", phasename="Mn2O3_alpha", fmthint="CIF")
    hist = project.add_powder_histogram(str(xye), str(instfile), phases=[wo3, mn2o3], fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1", "no. coeffs": 6,
            "coeffs": [1200.0, -450.0, 300.0, -180.0, 80.0, -30.0], "refine": True,
        }
    })
    wo3.setSampleProfile(hist, "size", "isotropic", 0.12, LGmix=1.0)
    wo3.setSampleProfile(hist, "microstrain", "isotropic", 3000.0, LGmix=1.0)
    mn2o3.setSampleProfile(hist, "size", "isotropic", 0.06, LGmix=1.0)
    mn2o3.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    for phase in (wo3, mn2o3):
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.update_ids()
    project.set_Controls("cycles", 15)
    for p, limits in {
        "0:0:Size;i": (0.02, 5.0), "1:0:Size;i": (0.02, 5.0),
        "0:0:Mustrain;i": (0.0, 20000.0), "1:0:Mustrain;i": (0.0, 20000.0),
        ":0:SH/L": (0.0, 0.2), ":0:Polariz.": (0.0, 1.0),
    }.items():
        project.set_Controls("parmMin", limits[0], variable=p)
        project.set_Controls("parmMax", limits[1], variable=p)

    project.refine(makeBack=False)
    HISTORY.append(capture(project, hist, "background_scales"))

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine(makeBack=False)
    HISTORY.append(capture(project, hist, "zero"))

    wo3.set_refinements({"Cell": True})
    mn2o3.set_refinements({"Cell": True})
    project.refine(makeBack=False)
    HISTORY.append(capture(project, hist, "cells"))

    wo3.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.refine(makeBack=False)
    HISTORY.append(capture(project, hist, "wo3_size"))

    wo3.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project.refine(makeBack=False)
    HISTORY.append(capture(project, hist, "wo3_size_strain"))

    mn2o3.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.refine(makeBack=False)
    HISTORY.append(capture(project, hist, "phase_widths"))

    hist.set_refinements({"Instrument Parameters": ["Polariz.", "SH/L"]})
    project.refine(makeBack=False)
    HISTORY.append(capture(project, hist, "polarization_asymmetry"))

    for atom in wo3.atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"
    project.refine(makeBack=False)
    HISTORY.append(capture(project, hist, "wo3_W"))

    project.save(str(ROOT / "accepted.gpx"))
    (ROOT / "history.json").write_text(json.dumps(HISTORY, indent=2) + "\n")
    for i, phase in enumerate(project.phases()):
        phase.export_CIF(str(ROOT / f"phase_{i}.cif"))


if __name__ == "__main__":
    main()
