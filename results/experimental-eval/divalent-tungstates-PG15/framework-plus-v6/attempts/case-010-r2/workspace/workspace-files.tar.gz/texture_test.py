#!/usr/bin/env python3
"""Challenge the accepted model with one March-Dollase axis at a time."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/normalized_baseline/accepted.gpx")


def main() -> None:
    phase_index = int(sys.argv[1])
    axis = [int(v) for v in sys.argv[2:5]]
    tag = f"p{phase_index}_{axis[0]}{axis[1]}{axis[2]}"
    out = Path(".tmp/texture") / f"{tag}.gpx"
    out.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.filename = str(out)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    phases = project.phases()

    # Every trial starts from random-powder texture for both phases and only
    # releases one physically interpretable March-Dollase coefficient.
    for phase in phases:
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = False
        po[3] = [0, 0, 1]
    target = phases[phase_index]
    po = target.data["Histograms"][hist.name]["Pref.Ori."]
    po[1] = 1.0
    po[2] = True
    po[3] = axis

    project.update_ids()
    project.set_Controls("parmMin", 0.5, variable=f"{phase_index}:0:MD")
    project.set_Controls("parmMax", 2.0, variable=f"{phase_index}:0:MD")
    project.refine(makeBack=False)
    project.save(str(out))

    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
              for p in phases]
    total = sum(masses)
    result = {
        "phase_index": phase_index,
        "phase": target.name,
        "axis": axis,
        "Rwp": hist.get_wR(),
        "fractions": {p.name: m / total for p, m in zip(phases, masses)},
        "MD": float(po[1]),
        "residuals": hist.residuals,
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
        "sig": project.data.get("Covariance", {}).get("data", {}).get("sig", []),
    }
    out.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
