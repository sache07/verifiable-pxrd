#!/usr/bin/env python3
"""Freeze the accepted GSAS-II checkpoint and export submission artifacts."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/angular_profile/full.gpx")
FINAL = Path("final.gpx")
CIFS = [Path("phase_1_WO3_gamma.cif"), Path("phase_2_Mn2O3_alpha.cif")]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.filename = str(FINAL)
    project.save(str(FINAL))

    # Reopen the exact submitted project before all exports.
    project = G2.G2Project(gpxfile=str(FINAL))
    hist = project.histogram(0)
    phases = project.phases()
    if len(phases) != 2 or len(project.histograms()) != 1:
        raise RuntimeError("unexpected final project inventory")
    for phase, path in zip(phases, CIFS):
        phase.export_CIF(str(path))

    x, y, w, ycalc = (np.asarray(v, float) for v in hist.data["data"][1][:4])
    diff = y - ycalc
    np.savetxt(
        "fit.csv", np.column_stack([x, y, ycalc, diff]), delimiter=",",
        header="two_theta,observed,calculated,difference", comments="", fmt="%.12g",
    )

    mass_scales = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
                   for p in phases]
    fractions = np.asarray(mass_scales, float) / sum(mass_scales)
    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    dep = cov.get("depSigDict", {})
    audit = {
        "project": str(FINAL),
        "project_sha256": sha256(FINAL),
        "histogram": hist.name,
        "n_points": int(x.size),
        "x_min_deg": float(x.min()),
        "x_max_deg": float(x.max()),
        "phases": [
            {
                "name": phase.name,
                "cif": str(path),
                "cif_sha256": sha256(path),
                "weight_fraction": float(frac),
                "weight_fraction_esd": float(dep.get(f"{i}:0:WgtFrac", (frac, float("nan")))[1]),
                "cell": phase.get_cell(),
            }
            for i, (phase, path, frac) in enumerate(zip(phases, CIFS, fractions))
        ],
        "fit_statistics": {
            "Rwp_percent": float(hist.get_wR()),
            "Rp_percent": float(hist.residuals["R"]),
            "Rwp_expected_percent": float(hist.residuals["wRmin"]),
            "GOF": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_variables": int(rvals["Nvars"]),
            "converged": bool(rvals["converged"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
        },
        "profile": {
            "shift_um": float(hist.SampleParameters["Shift"][0]),
            "polarization": float(hist.InstrumentParameters["Polariz."][1]),
            "SH_L": float(hist.InstrumentParameters["SH/L"][1]),
            "background": list(hist.Background[0][3:]),
            "phase_terms": {
                p.name: {
                    "size": p.data["Histograms"][hist.name]["Size"],
                    "microstrain": p.data["Histograms"][hist.name]["Mustrain"],
                    "preferred_orientation": p.data["Histograms"][hist.name]["Pref.Ori."],
                }
                for p in phases
            },
        },
        "fit_csv_sha256": sha256(Path("fit.csv")),
    }
    Path(".tmp/final_export_audit.json").write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
