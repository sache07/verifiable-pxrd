#!/usr/bin/env python3
"""Test a bounded two-parameter Suortti surface-roughness correction."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/geometry/shift_-600.gpx")


def main() -> None:
    start_a, start_b = map(float, sys.argv[1:3])
    tag = f"a{start_a:.2f}_b{start_b:.2f}".replace(".", "p")
    out = Path(".tmp/roughness") / f"{tag}.gpx"
    out.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    project = G2.G2Project(gpxfile=str(SOURCE))
    project.filename = str(out)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    hist = project.histogram(0)
    hist.SampleParameters["SurfRoughA"] = [start_a, True]
    hist.SampleParameters["SurfRoughB"] = [start_b, True]
    project.update_ids()
    project.set_Controls("cycles", 25)
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.9, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.001, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 2.0, variable=":0:SurfRoughB")
    project.refine(makeBack=False)
    project.save(str(out))

    project = G2.G2Project(gpxfile=str(out))
    project.filename = str(out)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 25)
    project.refine(makeBack=False)
    project.save(str(out))

    hist = project.histogram(0)
    phases = project.phases()
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
              for p in phases]
    total = sum(masses)
    result = {
        "start": [start_a, start_b],
        "Rwp": hist.get_wR(),
        "SurfRoughA": hist.SampleParameters["SurfRoughA"][0],
        "SurfRoughB": hist.SampleParameters["SurfRoughB"][0],
        "fractions": {p.name: m / total for p, m in zip(phases, masses)},
        "residuals": hist.residuals,
    }
    out.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
