#!/usr/bin/env python3
"""Re-establish a physical common profile, then add phase broadening reversibly."""

from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/alt_2311041/screen.gpx")
OUT = Path(".tmp/profile231.gpx")


def capture(project, hist, label):
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
              for p in project.phases()]
    total = sum(masses)
    row = {
        "stage": label,
        "Rwp": hist.get_wR(),
        "fractions": {p.name: m / total for p, m in zip(project.phases(), masses)},
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "instrument": copy.deepcopy(hist.data["Instrument Parameters"][0]),
        "profiles": {
            p.name: {
                "size": copy.deepcopy(p.data["Histograms"][hist.name]["Size"]),
                "mustrain": copy.deepcopy(p.data["Histograms"][hist.name]["Mustrain"]),
            }
            for p in project.phases()
        },
        "frozen": [str(x) for values in project.data["Controls"]["data"].get("parmFrozen", {}).values()
                   for x in values],
    }
    print(label, row["Rwp"], row["fractions"], flush=True)
    return row


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.filename = str(OUT)
    hist = project.histogram(0)
    wo3, mn2o3 = project.phases()
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 15)

    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 10.0, "W": 10.0, "X": 1.0}.items():
        inst[key][1] = value
        inst[key][2] = False
    wo3.setSampleProfile(hist, "size", "isotropic", 0.10, LGmix=1.0)
    wo3.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    mn2o3.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=1.0)
    mn2o3.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    for phase in (wo3, mn2o3):
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "

    project.update_ids()
    for p, limits in {
        "0:0:Size;i": (0.02, 5.0),
        "1:0:Size;i": (0.02, 5.0),
        "0:0:Mustrain;i": (0.0, 20000.0),
        "1:0:Mustrain;i": (0.0, 20000.0),
    }.items():
        project.set_Controls("parmMin", limits[0], variable=p)
        project.set_Controls("parmMax", limits[1], variable=p)
    for p in ("U", "W", "X"):
        project.set_Controls("parmMin", 0.0, variable=f":0:{p}")

    history = []
    project.refine(makeBack=False)
    history.append(capture(project, hist, "reset"))

    wo3.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.refine(makeBack=False)
    history.append(capture(project, hist, "wo3_size"))

    wo3.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project.refine(makeBack=False)
    history.append(capture(project, hist, "wo3_size_strain"))

    mn2o3.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.refine(makeBack=False)
    history.append(capture(project, hist, "both_sizes_wo3_strain"))

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine(makeBack=False)
    history.append(capture(project, hist, "common_profile_rechallenged"))

    project.save(str(OUT))
    Path(".tmp/profile231.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
