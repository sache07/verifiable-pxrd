#!/usr/bin/env python3
"""Compare one constant-zero correction with one specimen-shift correction."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/strain/p0_001.gpx")


def clean(value):
    if hasattr(value, "tolist"):
        return value.tolist()
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    return value


def main() -> None:
    mode = sys.argv[1]
    start = float(sys.argv[2]) if len(sys.argv) > 2 else 0.0
    tag = mode if mode == "zero" else f"shift_{start:+.0f}"
    out = Path(".tmp/geometry") / f"{tag}.gpx"
    out.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.filename = str(out)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 25)
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters

    if mode == "zero":
        inst["Zero"][2] = True
        sample["Shift"] = [0.0, False]
    elif mode == "shift":
        inst["Zero"][1] = 0.0
        inst["Zero"][2] = False
        sample["Shift"] = [start, True]
        project.update_ids()
        project.set_Controls("parmMin", -2000.0, variable=":0:Shift")
        project.set_Controls("parmMax", 2000.0, variable=":0:Shift")
    else:
        raise ValueError(mode)

    # Two complete passes are used because cell/position/profile terms are
    # strongly coupled to the chosen angular correction.
    project.refine(makeBack=False)
    project.save(str(out))
    project = G2.G2Project(gpxfile=str(out))
    project.filename = str(out)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 25)
    project.refine(makeBack=False)
    project.save(str(out))

    hist = project.histogram(0)
    phases = project.phases()
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
              for p in phases]
    total = sum(masses)
    result = {
        "mode": mode,
        "start": start,
        "Rwp": hist.get_wR(),
        "fractions": {p.name: m / total for p, m in zip(phases, masses)},
        "Zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "Shift_um": float(hist.SampleParameters["Shift"][0]),
        "cells": {p.name: p.get_cell() for p in phases},
        "residuals": clean(hist.residuals),
    }
    out.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
