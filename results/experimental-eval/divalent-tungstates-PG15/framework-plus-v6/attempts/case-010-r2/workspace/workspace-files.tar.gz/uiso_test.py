#!/usr/bin/env python3
"""Refine one isotropic displacement parameter per phase with equivalence constraints."""

from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/normalized_baseline/accepted.gpx")
OUT = Path(".tmp/uiso231.gpx")


def state(project, hist, label):
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
              for p in project.phases()]
    total = sum(masses)
    result = {
        "stage": label,
        "Rwp": hist.get_wR(),
        "fractions": {p.name: m / total for p, m in zip(project.phases(), masses)},
        "uiso": {
            p.name: {a.label: float(a.data[p.data["General"]["AtomPtrs"][3] + 1]) for a in p.atoms()}
            for p in project.phases()
        },
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "instrument": copy.deepcopy(hist.data["Instrument Parameters"][0]),
    }
    print(label, result["Rwp"], result["fractions"], result["uiso"], flush=True)
    return result


def constrain_phase_uiso(project, phase, pid):
    cia = phase.data["General"]["AtomPtrs"][3]
    variables = []
    for i, atom in enumerate(phase.atoms()):
        atom.data[cia + 1] = 0.005
        atom.refinement_flags = ("X" if "X" in atom.refinement_flags else "") + "U"
        variables.append(f"{pid}::AUiso:{i}")
    project.add_EquivConstr(variables, reloadIdx=True)
    project.set_Controls("parmMin", 0.0, variable=variables[0])
    project.set_Controls("parmMax", 0.05, variable=variables[0])


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.filename = str(OUT)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    hist = project.histogram(0)
    wo3, mn2o3 = project.phases()
    project.set_Controls("cycles", 15)
    history = [state(project, hist, "source")]

    constrain_phase_uiso(project, wo3, 0)
    project.refine(makeBack=False)
    history.append(state(project, hist, "wo3_uiso"))

    constrain_phase_uiso(project, mn2o3, 1)
    project.refine(makeBack=False)
    history.append(state(project, hist, "both_uiso"))

    project.save(str(OUT))
    Path(".tmp/uiso231.json").write_text(json.dumps(history, indent=2) + "\n")
    for i, phase in enumerate(project.phases()):
        phase.export_CIF(f".tmp/uiso231_phase_{i}.cif")


if __name__ == "__main__":
    main()
