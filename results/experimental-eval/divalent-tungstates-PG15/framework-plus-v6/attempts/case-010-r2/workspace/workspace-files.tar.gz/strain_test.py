#!/usr/bin/env python3
"""Challenge isotropic and uniaxial microstrain from the accepted checkpoint."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/normalized_baseline/accepted.gpx")


def clean(value):
    if hasattr(value, "tolist"):
        return value.tolist()
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    return value


def main() -> None:
    phase_index = int(sys.argv[1])
    mode = sys.argv[2]
    axis = [int(v) for v in sys.argv[3:6]] if mode == "uniaxial" else None
    suffix = "iso" if axis is None else "".join(str(v) for v in axis)
    tag = f"p{phase_index}_{suffix}"
    out = Path(".tmp/strain") / f"{tag}.gpx"
    out.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.filename = str(out)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    phases = project.phases()
    target = phases[phase_index]
    hap = target.data["Histograms"][hist.name]
    current = float(hap["Mustrain"][1][0])

    if mode == "isotropic":
        start = current if current > 0 else 1000.0
        target.setSampleProfile(hist, "microstrain", "isotropic", start, LGmix=1.0)
        target.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        keys = [f"{phase_index}:0:Mustrain;i"]
    elif mode == "uniaxial":
        start = current if current > 0 else 1000.0
        target.setSampleProfile(hist, "microstrain", "uniaxial", start, start,
                                axis=axis, LGmix=1.0)
        target.set_HAP_refinements({
            "Mustrain": {"type": "uniaxial", "direction": axis,
                          "refine": True}
        })
        keys = [f"{phase_index}:0:Mustrain;i", f"{phase_index}:0:Mustrain;a"]
    else:
        raise ValueError(mode)

    project.update_ids()
    for key in keys:
        project.set_Controls("parmMin", 0.0, variable=key)
        project.set_Controls("parmMax", 20000.0, variable=key)
    project.refine(makeBack=False)
    project.save(str(out))

    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
              for p in phases]
    total = sum(masses)
    result = {
        "phase_index": phase_index,
        "phase": target.name,
        "mode": mode,
        "axis": axis,
        "Rwp": hist.get_wR(),
        "fractions": {p.name: m / total for p, m in zip(phases, masses)},
        "Mustrain": clean(hap["Mustrain"]),
        "residuals": clean(hist.residuals),
    }
    out.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
