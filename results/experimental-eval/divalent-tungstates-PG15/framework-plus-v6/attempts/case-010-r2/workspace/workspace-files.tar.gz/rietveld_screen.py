#!/usr/bin/env python3
"""Small reproducible GSAS-II screening refinement for candidate inventories."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2, GSASIIlattice as G2lat


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inputs(root: Path) -> tuple[Path, Path]:
    root.mkdir(parents=True, exist_ok=True)
    arr = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
    xye = root / "pattern.xye"
    np.savetxt(xye, np.column_stack((arr, np.sqrt(np.maximum(arr[:, 1], 1.0)))), fmt="%.10g")
    inst = root / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha laboratory instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.30;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def snapshot(project: G2.G2Project, hist: G2.G2PwdrData) -> dict:
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        masses.append(max(0.0, mass_scale))
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "mass_scale": mass_scale,
                "cell": phase.get_cell(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    total = sum(masses)
    for phase, value in zip(phases, masses):
        phase["weight_fraction"] = value / total if total else None
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "wR_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "phases": phases,
    }


def run(outdir: Path, ids: list[str], profile: bool = True) -> dict:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    xye, inst = write_inputs(outdir)
    gpx = outdir / "screen.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    phases = []
    for cod_id in ids:
        path = cod_path(cod_id)
        phase = project.add_phase(str(path), phasename=f"COD_{cod_id}", fmthint="CIF")
        if cod_id == "1010618":
            # Peak-indexed starting cell. This keeps the first cell step in the
            # local basin despite the unknown common angular correction.
            cell = [7.39371, 7.64207, 3.89764, 90.5504, 89.7094, 90.4365]
            phase.data["General"]["Cell"][1:7] = cell
            phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))
        phases.append(phase)
    hist = project.add_powder_histogram(str(xye), str(inst), phases=phases, fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    # One angular correction only. Zero is used for robust candidate screening.
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    project.update_ids()
    for parameter in ("U", "W", "X"):
        project.set_Controls("parmMin", 0.0, variable=f":0:{parameter}")
    # A smooth low-order polynomial approximates the continuum during inventory tests.
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [1200.0, -450.0, 300.0, -180.0, 80.0, -30.0],
                "refine": True,
            }
        }
    )
    for phase in phases:
        # Neutral phase broadening. A common instrument profile is established first.
        phase.setSampleProfile(hist, "size", "isotropic", 0.2, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
        phase.set_HAP_refinements({"Scale": True})
    project.set_Controls("cycles", 12)
    history = []
    project.refine(makeBack=False)
    history.append({"stage": "background_scales", **snapshot(project, hist)})

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine(makeBack=False)
    history.append({"stage": "zero", **snapshot(project, hist)})

    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine(makeBack=False)
    history.append({"stage": "zero_cells", **snapshot(project, hist)})

    if profile:
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        project.refine(makeBack=False)
        history.append({"stage": "common_profile", **snapshot(project, hist)})

    project.save(str(gpx))
    result = {"ids": ids, "gpx": str(gpx), "history": history, "final": snapshot(project, hist)}
    (outdir / "summary.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("outdir", type=Path)
    parser.add_argument("ids", nargs="+")
    parser.add_argument("--no-profile", action="store_true")
    args = parser.parse_args()
    result = run(args.outdir, args.ids, not args.no_profile)
    print(json.dumps(result["final"], indent=2, default=str))


if __name__ == "__main__":
    main()
