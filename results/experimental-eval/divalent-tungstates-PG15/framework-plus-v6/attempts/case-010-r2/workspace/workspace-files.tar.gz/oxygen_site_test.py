#!/usr/bin/env python3
"""Release one WO3 oxygen site at a time and physical-screen its motion."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/geometry/shift_-600.gpx")


def cart_displacement(frac0, frac1, cell):
    d = np.asarray(frac1, float) - np.asarray(frac0, float)
    d -= np.rint(d)
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    alpha, beta, gamma = (math.radians(cell[k]) for k in
                          ("angle_alpha", "angle_beta", "angle_gamma"))
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * math.cos(gamma), b * math.sin(gamma), 0.0])
    cx = c * math.cos(beta)
    cy = c * (math.cos(alpha) - math.cos(beta) * math.cos(gamma)) / math.sin(gamma)
    cz = math.sqrt(max(c * c - cx * cx - cy * cy, 0.0))
    return float(np.linalg.norm(d[0] * va + d[1] * vb + d[2] * np.array([cx, cy, cz])))


def main() -> None:
    label = sys.argv[1]
    out = Path(".tmp/oxygen_sites") / f"{label}.gpx"
    out.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.filename = str(out)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 25)
    phase = project.phase(0)
    hist = project.histogram(0)
    atom = phase.atom(label)
    if atom is None or atom.element != "O":
        raise ValueError(label)
    before = list(atom.coordinates)
    atom.refinement_flags = "X"
    project.refine(makeBack=False)
    project.save(str(out))

    phase = project.phase(0)
    atom = phase.atom(label)
    after = list(atom.coordinates)
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
              for p in project.phases()]
    total = sum(masses)
    result = {
        "label": label,
        "Rwp": hist.get_wR(),
        "before": before,
        "after": after,
        "displacement_A": cart_displacement(before, after, phase.get_cell()),
        "fractions": {p.name: m / total for p, m in zip(project.phases(), masses)},
        "residuals": hist.residuals,
    }
    out.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
