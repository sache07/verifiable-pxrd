#!/usr/bin/env python3
"""Prune unsupported terms, reconverge, and export the final GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clean(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    # Retain one specimen-displacement correction; zero, transparency and
    # roughness remain neutral. SH/L was tested and not supported as variable.
    hist.InstrumentParameters["Zero"][1:] = [0.0, False]
    hist.InstrumentParameters["SH/L"][1:] = [0.03, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    for index, phase in enumerate(project.phases()):
        for atom in phase.atoms():
            atom.refinement_flags = " "
            atom.uiso = 0.005
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Extinction"] = [0.0, False]
        if index == 0:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 10.0
            hap["Size"][2] = [False, False, False]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [0, 1, 0]
        else:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
            hap["Pref.Ori."][3] = [0, 0, 1]


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    terms = {
        phase.name: float(phase.data["General"]["Mass"])
        * float(phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in project.phases()
    }
    total = sum(terms.values())
    return {name: value / total for name, value in terms.items()}


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    source = G2.G2Project(gpxfile=str(args.base.resolve()))
    output = args.out.resolve()
    clean(source)
    source.set_Controls("cycles", 25)
    source.set_Frozen()
    source.save(str(output))
    history = []
    for _ in range(args.repeats):
        project = G2.G2Project(gpxfile=str(output))
        clean(project)
        project.set_Controls("cycles", 25)
        project.set_Frozen()
        project.save()
        project.refine()
        project = G2.G2Project(gpxfile=str(output))
        history.append(project.histogram(0).get_wR())
    clean(project)
    project.set_Frozen()
    project.save()
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    result = {
        "output": str(output),
        "wR_history_percent": history,
        "final_wR_percent": hist.get_wR(),
        "Rvals": cov.get("Rvals", {}),
        "fractions": fractions(project),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "frozen": project.get_Frozen(),
        "fit_limits": hist.data["Limits"],
    }
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", type=Path, default=Path("final.gpx"))
    parser.add_argument("--repeats", type=int, default=5)
    run(parser.parse_args())
