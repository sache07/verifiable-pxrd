#!/usr/bin/env python3
"""Refine one symmetry-independent common isotropic U value per phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def converge(path: Path, repeats: int = 4) -> G2.G2Project:
    project = G2.G2Project(gpxfile=str(path))
    project.set_Controls("cycles", 25)
    project.set_Frozen()
    for _ in range(repeats):
        project.refine()
        project = G2.G2Project(gpxfile=str(path))
        project.set_Frozen()
    return project


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    source = G2.G2Project(gpxfile=str(args.base.resolve()))
    output = args.out.resolve()
    source.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    selected = set(args.phase_index if args.phase_index else range(len(project.phases())))
    for index, phase in enumerate(project.phases()):
        atoms = list(phase.atoms())
        if index not in selected:
            for atom in atoms:
                atom.refinement_flags = atom.refinement_flags.replace("U", "")
            continue
        start = args.initial if args.initial is not None else max(args.minimum, atoms[0].uiso)
        for atom_index, atom in enumerate(atoms):
            atom.uiso = start
            atom.refinement_flags = "U"
            variable = f"{phase.id}::AUiso:{atom_index}"
            project.set_Controls("parmMin", args.minimum, variable)
            project.set_Controls("parmMax", args.maximum, variable)
        if len(atoms) > 1:
            project.add_EquivConstr(
                [f"{phase.id}::AUiso:{atom_index}" for atom_index in range(len(atoms))],
                reloadIdx=False,
            )
    project.save()
    project = converge(output, args.repeats)
    result = {
        "base": str(args.base.resolve()),
        "output": str(output),
        "wR_percent": project.histogram(0).get_wR(),
        "frozen": project.get_Frozen(),
        "phases": {
            phase.name: {
                "uiso_A2": [atom.uiso for atom in phase.atoms()],
                "flags": [atom.refinement_flags for atom in phase.atoms()],
            }
            for phase in project.phases()
        },
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase-index", type=int, action="append")
    parser.add_argument("--initial", type=float)
    parser.add_argument("--minimum", type=float, default=0.003)
    parser.add_argument("--maximum", type=float, default=0.020)
    parser.add_argument("--repeats", type=int, default=4)
    run(parser.parse_args())
