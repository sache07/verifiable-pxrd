#!/usr/bin/env python3
"""Profile fixed common phase Uiso values against a common GPX baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def converge(path: Path, repeats: int) -> G2.G2Project:
    project = G2.G2Project(gpxfile=str(path))
    project.set_Controls("cycles", 25)
    project.set_Frozen()
    for _ in range(repeats):
        project.refine()
        project = G2.G2Project(gpxfile=str(path))
        project.set_Frozen()
    return project


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    source = G2.G2Project(gpxfile=str(args.base.resolve()))
    results = []
    for main_u, minor_u in args.pair:
        output = (args.out_dir / f"uiso-{main_u:.5f}-{minor_u:.5f}.gpx").resolve()
        source.save(str(output))
        project = G2.G2Project(gpxfile=str(output))
        for phase, value in zip(project.phases(), (main_u, minor_u)):
            for atom in phase.atoms():
                atom.uiso = value
                atom.refinement_flags = atom.refinement_flags.replace("U", "")
        project.save()
        project = converge(output, args.repeats)
        hist = project.histogram(0)
        results.append(
            {
                "main_uiso_A2": main_u,
                "minor_uiso_A2": minor_u,
                "output": str(output),
                "wR_percent": hist.get_wR(),
                "polarization": hist.InstrumentParameters["Polariz."][1],
                "frozen": project.get_Frozen(),
            }
        )
    print(json.dumps({"base": str(args.base.resolve()), "trials": results}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out-dir", type=Path, default=Path(".tmp"))
    parser.add_argument("--pair", action="append", nargs=2, type=float, required=True)
    parser.add_argument("--repeats", type=int, default=2)
    run(parser.parse_args())
