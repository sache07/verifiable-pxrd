#!/usr/bin/env python3
"""Challenge phase size/strain models from finite, physically useful starts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def converge(path: Path, repeats: int) -> G2.G2Project:
    project = G2.G2Project(gpxfile=str(path))
    project.set_Controls("cycles", 25)
    project.set_Frozen()
    for _ in range(repeats):
        project.refine()
        project = G2.G2Project(gpxfile=str(path))
        project.set_Frozen()
    return project


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    source = G2.G2Project(gpxfile=str(args.base.resolve()))
    output = args.out.resolve()
    source.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histogram(0)
    phase = project.phase(args.phase_index)
    for item in project.phases():
        for atom in item.atoms():
            atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    if args.model == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = args.size_start
        hap["Size"][2] = [True, False, False]
        variable = f"{phase.id}:{hist.id}:Size;i"
        project.set_Controls("parmMin", args.size_min, variable)
        project.set_Controls("parmMax", args.size_max, variable)
    elif args.model == "isotropic_strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = args.strain_start
        hap["Mustrain"][1][1] = args.strain_start
        hap["Mustrain"][2] = [True, False, False]
        variable = f"{phase.id}:{hist.id}:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable)
        project.set_Controls("parmMax", args.strain_max, variable)
    else:
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = args.strain_start
        hap["Mustrain"][1][1] = args.axial_start
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = list(args.axis)
        for suffix in ("Mustrain;i", "Mustrain;a"):
            variable = f"{phase.id}:{hist.id}:{suffix}"
            project.set_Controls("parmMin", 0.0, variable)
            project.set_Controls("parmMax", args.strain_max, variable)
    project.save()
    project = converge(output, args.repeats)
    hap = project.phase(args.phase_index).data["Histograms"][project.histogram(0).name]
    cov = project.data["Covariance"]["data"]
    selected = [
        (str(variable), float(value), float(esd))
        for variable, value, esd in zip(cov.get("varyList", []), cov.get("variables", []), cov.get("sig", []))
        if any(key in str(variable) for key in ("Size", "Mustrain", ":U", ":W", ":X"))
    ]
    print(
        json.dumps(
            {
                "model": args.model,
                "axis": args.axis,
                "output": str(output),
                "wR_percent": project.histogram(0).get_wR(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "selected_variables": selected,
                "Rvals": cov.get("Rvals", {}),
                "frozen": project.get_Frozen(),
            },
            indent=2,
            default=float,
        )
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase-index", type=int, default=0)
    parser.add_argument("--model", choices=("size", "isotropic_strain", "uniaxial_strain"), required=True)
    parser.add_argument("--axis", nargs=3, type=int, default=[0, 0, 1])
    parser.add_argument("--size-start", type=float, default=0.5)
    parser.add_argument("--size-min", type=float, default=0.04)
    parser.add_argument("--size-max", type=float, default=10.0)
    parser.add_argument("--strain-start", type=float, default=500.0)
    parser.add_argument("--axial-start", type=float, default=1000.0)
    parser.add_argument("--strain-max", type=float, default=10000.0)
    parser.add_argument("--repeats", type=int, default=6)
    run(parser.parse_args())
