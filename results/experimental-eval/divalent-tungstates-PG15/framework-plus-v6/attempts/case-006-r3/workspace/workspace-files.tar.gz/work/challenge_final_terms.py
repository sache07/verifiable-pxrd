#!/usr/bin/env python3
"""Remove one accepted nuisance term and reconverge for a nested comparison."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def converge(path: Path, repeats: int = 4) -> G2.G2Project:
    project = G2.G2Project(gpxfile=str(path))
    project.set_Controls("cycles", 25)
    project.set_Frozen()
    for _ in range(repeats):
        project.refine()
        project = G2.G2Project(gpxfile=str(path))
        project.set_Frozen()
    return project


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    source = G2.G2Project(gpxfile=str(args.base.resolve()))
    output = args.out.resolve()
    source.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histogram(0)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = atom.refinement_flags.replace("X", "").replace("U", "")
    if args.remove_texture:
        hap = project.phase(args.remove_texture).data["Histograms"][hist.name]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    if args.remove_size:
        hap = project.phase(args.remove_size).data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
    project.save()
    project = converge(output, args.repeats)
    print(
        json.dumps(
            {
                "base": str(args.base.resolve()),
                "output": str(output),
                "wR_percent": project.histogram(0).get_wR(),
                "frozen": project.get_Frozen(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--remove-texture")
    parser.add_argument("--remove-size")
    parser.add_argument("--repeats", type=int, default=4)
    run(parser.parse_args())
