#!/usr/bin/env python3
"""Challenge a converged GSAS-II inventory with one additional phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    terms = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap and hap.get("Use", True):
            terms[phase.name] = max(0.0, float(hap["Scale"][0])) * float(phase.data["General"]["Mass"])
    total = sum(terms.values())
    return {name: value / total for name, value in terms.items()} if total else {name: 0.0 for name in terms}


def clear_atomic_flags(project: G2.G2Project) -> None:
    for phase in project.phases():
        phase.set_refinements({"Atoms": {atom.label: " " for atom in phase.atoms()}})


def refine_repeated(project_path: Path, repeats: int = 3) -> G2.G2Project:
    project = G2.G2Project(gpxfile=str(project_path))
    project.set_Controls("cycles", 25)
    project.set_Frozen()
    for _ in range(repeats):
        project.refine()
        project = G2.G2Project(gpxfile=str(project_path))
        project.set_Frozen()
    return project


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    output = args.out.resolve()
    source = G2.G2Project(gpxfile=str(args.base.resolve()))
    source.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histogram(0)
    # Freeze coordinates and cells for the scale-first test. Existing refined
    # nuisance flags (smooth background and all phase scales) are retained.
    clear_atomic_flags(project)
    for phase in project.phases():
        phase.clear_refinements({"Cell": False})
        phase.set_HAP_refinements({"Scale": True})
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Zero"]})
    hist.clear_refinements({"Sample Parameters": ["Shift"]})

    added = project.add_phase(
        str(args.cif.resolve()), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    hap = added.data["Histograms"][hist.name]
    hap["Scale"] = [float(args.initial_scale), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][1][1] = 10.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    added.clear_refinements({"Cell": False})
    project.update_ids()
    for phase in project.phases():
        variable = f"{phase.id}:{hist.id}:Scale"
        project.set_Controls("parmMin", 0.0, variable)
        project.set_Controls("parmMax", 1.0e8, variable)
    project.save()

    project = refine_repeated(output)
    scale_stage = {
        "wR_percent": project.histogram(0).get_wR(),
        "fractions": fractions(project),
        "scale": project.phase(args.name).data["Histograms"][project.histogram(0).name]["Scale"][0],
        "cell": project.phase(args.name).get_cell(),
        "frozen": project.get_Frozen(),
    }

    # Only a positive, non-bound scale earns a cell/profile re-challenge.
    cell_stage = None
    if scale_stage["scale"] > args.scale_threshold:
        project = G2.G2Project(gpxfile=str(output))
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
            phase.set_HAP_refinements({"Scale": True})
        project.histogram(0).set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        project.histogram(0).set_refinements({"Sample Parameters": ["Shift"]})
        project.save()
        project = refine_repeated(output)
        cell_stage = {
            "wR_percent": project.histogram(0).get_wR(),
            "fractions": fractions(project),
            "scale": project.phase(args.name).data["Histograms"][project.histogram(0).name]["Scale"][0],
            "cell": project.phase(args.name).get_cell(),
            "shift_um": project.histogram(0).SampleParameters["Shift"][0],
            "instrument": {key: project.histogram(0).InstrumentParameters[key][1] for key in ("U", "W", "X")},
            "frozen": project.get_Frozen(),
        }
    result = {
        "base": str(args.base.resolve()),
        "candidate": str(args.cif.resolve()),
        "name": args.name,
        "scale_first": scale_stage,
        "cell_profile_rechallenge": cell_stage,
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("--name", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--initial-scale", type=float, default=0.5)
    parser.add_argument("--scale-threshold", type=float, default=1.0e-5)
    run(parser.parse_args())
