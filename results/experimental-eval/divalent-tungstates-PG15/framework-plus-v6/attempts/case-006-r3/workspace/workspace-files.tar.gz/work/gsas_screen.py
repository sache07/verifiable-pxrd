#!/usr/bin/env python3
"""Build and stage a GSAS-II screening refinement for one candidate phase."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def write_xye(csv_path: Path, xye_path: Path) -> tuple[np.ndarray, np.ndarray]:
    data = np.loadtxt(csv_path, delimiter=",", skiprows=1)
    x, y = data.T
    sigma = np.sqrt(np.maximum(y, 1.0))
    with xye_path.open("w") as handle:
        for xx, yy, ss in zip(x, y, sigma):
            handle.write(f"{xx:.8f} {yy:.8f} {ss:.12f}\n")
    return x, y


def write_inst(path: Path) -> None:
    path.write_text(
        "# GSAS-II Cu K-alpha reflection geometry screening profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:20.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    result = {
        "stage": label,
        "wR_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "cell": phase.get_cell(),
        "phase_scale": hap["Scale"][0],
        "size": copy.deepcopy(hap["Size"]),
        "mustrain": copy.deepcopy(hap["Mustrain"]),
        "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
        "instrument": {k: copy.deepcopy(v) for k, v in inst.items() if k in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}},
        "sample": {k: copy.deepcopy(sample.get(k)) for k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type")},
        "background": copy.deepcopy(hist.Background),
        "covariance": {
            "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
            "sig": np.asarray(project.data.get("Covariance", {}).get("data", {}).get("sig", [])).tolist(),
            "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
        },
    }
    return result


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    x, y = write_xye(args.pattern.resolve(), out / "pattern.xye")
    write_inst(out / "instrument.instprm")

    project = G2.G2Project(newgpx=str(out / "screen.gpx"))
    phase = project.add_phase(str(args.cif.resolve()), phasename=args.name, fmthint="CIF")
    hist = project.add_powder_histogram(
        str(out / "pattern.xye"), str(out / "instrument.instprm"), phases=[phase], fmthint="xye"
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [float(np.quantile(y, 0.25)), 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": True,
            },
        }
    )

    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = args.initial_size
    hap["Size"][1][1] = args.initial_size
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]

    project.update_ids()
    hid, pid = hist.id, phase.id
    bounds = [
        ("parmMin", 0.0, f"{pid}:{hid}:Scale"),
        ("parmMax", 1.0e8, f"{pid}:{hid}:Scale"),
        ("parmMin", -800.0, f":{hid}:Shift"),
        ("parmMax", 800.0, f":{hid}:Shift"),
        ("parmMin", 0.0, f":{hid}:U"),
        ("parmMax", 80.0, f":{hid}:U"),
        ("parmMin", 0.0, f":{hid}:W"),
        ("parmMax", 80.0, f":{hid}:W"),
        ("parmMin", 0.0, f":{hid}:X"),
        ("parmMax", 12.0, f":{hid}:X"),
        ("parmMin", 0.002, f":{hid}:SH/L"),
        ("parmMax", 0.2, f":{hid}:SH/L"),
    ]
    for control, value, variable in bounds:
        project.set_Controls(control, value, variable)
    project.set_Controls("cycles", args.cycles)

    history = []
    project.refine()
    history.append(snapshot(project, "background_scale"))

    # A deliberately broadened phase keeps derivatives informative while cell and
    # one physical angular correction are brought onto the observed peak families.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    phase.set_refinements({"Cell": True})
    project.set_Frozen()
    project.refine()
    history.append(snapshot(project, "cell_shift"))

    # Restore a nearly neutral phase broadening model, then determine a common
    # nonnegative instrumental U/W/X baseline.
    hap["Size"][1][0] = 1.0
    hap["Size"][1][1] = 1.0
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.set_Frozen()
    project.refine()
    history.append(snapshot(project, "common_profile"))

    project.save()
    imported_x = np.asarray(hist.getdata("X"), float)
    imported_y = np.asarray(hist.getdata("Yobs"), float)
    report = {
        "candidate": str(args.cif.resolve()),
        "phase_name": args.name,
        "grid_max_abs_error": float(np.max(np.abs(imported_x - x))),
        "intensity_max_abs_error": float(np.max(np.abs(imported_y - y))),
        "history": history,
    }
    (out / "screen.json").write_text(json.dumps(report, indent=2, default=float) + "\n")
    print(json.dumps({"candidate": report["candidate"], "stages": [{"stage": row["stage"], "wR_percent": row["wR_percent"], "cell": row["cell"], "shift": row["sample"]["Shift"], "scale": row["phase_scale"], "U": row["instrument"]["U"], "W": row["instrument"]["W"], "X": row["instrument"]["X"]} for row in history]}, indent=2, default=float))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("cif", type=Path)
    parser.add_argument("--name", default="candidate")
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--initial-size", type=float, default=0.05)
    parser.add_argument("--cycles", type=int, default=12)
    run(parser.parse_args())
