#!/usr/bin/env python3
"""Reconverge a smooth Chebyshev background at a selected low order."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    source = G2.G2Project(gpxfile=str(args.base.resolve()))
    output = args.out.resolve()
    source.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histogram(0)
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": args.order}}
    )
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.set_Controls("cycles", 25)
    project.set_Frozen()
    project.save()
    for _ in range(args.repeats):
        project.refine()
        project = G2.G2Project(gpxfile=str(output))
        project.set_Frozen()
    background = np.asarray(project.histogram(0).getdata("background"))
    print(
        json.dumps(
            {
                "order": args.order,
                "output": str(output),
                "wR_percent": project.histogram(0).get_wR(),
                "background_min": float(background.min()),
                "background_max": float(background.max()),
                "coefficients": project.histogram(0).data["Background"][0][3:],
                "frozen": project.get_Frozen(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--order", type=int, required=True)
    parser.add_argument("--repeats", type=int, default=5)
    run(parser.parse_args())
