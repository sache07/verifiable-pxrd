#!/usr/bin/env python3
"""Compare a single zero or specimen-displacement correction."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def converge(path: Path, repeats: int = 5) -> G2.G2Project:
    project = G2.G2Project(gpxfile=str(path))
    project.set_Controls("cycles", 25)
    project.set_Frozen()
    for _ in range(repeats):
        project.refine()
        project = G2.G2Project(gpxfile=str(path))
        project.set_Frozen()
    return project


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    source = G2.G2Project(gpxfile=str(args.base.resolve()))
    output = args.out.resolve()
    source.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histogram(0)
    if args.mode == "zero":
        hist.SampleParameters["Shift"] = [0.0, False]
        hist.InstrumentParameters["Zero"][1:] = [args.initial, True]
    else:
        hist.InstrumentParameters["Zero"][1:] = [0.0, False]
        hist.SampleParameters["Shift"] = [args.initial, True]
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.save()
    project = converge(output, args.repeats)
    hist = project.histogram(0)
    print(
        json.dumps(
            {
                "mode": args.mode,
                "output": str(output),
                "wR_percent": hist.get_wR(),
                "zero_deg": hist.InstrumentParameters["Zero"][1],
                "shift_um": hist.SampleParameters["Shift"][0],
                "frozen": project.get_Frozen(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--mode", choices=("zero", "shift"), required=True)
    parser.add_argument("--initial", type=float, default=0.0)
    parser.add_argument("--repeats", type=int, default=5)
    run(parser.parse_args())
