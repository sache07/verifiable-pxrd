#!/usr/bin/env python3
"""Create explicitly documented CuWO4 end-member models from COD parents."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from pymatgen.core import Structure

RUNTIME = Path(__file__).resolve().parents[1] / "learned" / "divalent-tungstates" / "runtime"
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def screen(structure: Structure) -> dict:
    distance = structure.distance_matrix.copy()
    np.fill_diagonal(distance, np.inf)
    nearest = float(distance.min())
    oxygen = [i for i, site in enumerate(structure) if site.species_string == "O"]
    oo = distance[np.ix_(oxygen, oxygen)]
    return {
        "formula": structure.composition.reduced_formula,
        "space_group": structure.get_space_group_info(symprec=0.01),
        "cell": list(structure.lattice.abc) + list(structure.lattice.angles),
        "density_g_cm3": float(structure.density),
        "minimum_separation_A": nearest,
        "minimum_O_O_A": float(oo.min()),
        "sites": len(structure),
        "ordered": structure.is_ordered,
    }


def main() -> None:
    out = Path("work/candidates")
    out.mkdir(parents=True, exist_ok=True)
    specs = [
        {
            "name": "cuwo4_from_2101690",
            "parent": "2101690",
            "replace": {"Zn": "Cu"},
            "transformation": "Replace the parent record's single Zn-labelled divalent-metal site fully by Cu. The publication reports the Cu0.9Zn0.1WO4 triclinic solid solution; this constructs its CuWO4 end member without changing the measured framework or cell.",
        },
        {
            "name": "cuwo4_from_2101679",
            "parent": "2101679",
            "replace": {"Zn": "Cu"},
            "transformation": "Replace the parent record's single Zn-labelled divalent-metal site fully by Cu. This is the more Zn-rich triclinic solid-solution framework and is retained as a physical alternate.",
        },
        {
            "name": "cuwo4_from_1535336",
            "parent": "1535336",
            "replace": {"Mo": "W"},
            "transformation": "Isovalent Mo(VI)-to-W(VI) substitution in triclinic CuMoO4-III, retaining the parent framework and cell as a diagnostic CuWO4 prototype.",
        },
        {
            "name": "cu2wo4_2002403_normalized",
            "parent": "2002403",
            "replace": {},
            "transformation": "Normalize the published Cu2WO4 CIF through pymatgen and write explicit symmetry/occupancy fields so GSAS-II can import the otherwise incompatible source syntax; no chemical or structural values are intentionally changed.",
        },
    ]
    records = []
    for spec in specs:
        source = cod_path(spec["parent"])
        structure = Structure.from_file(source, primitive=False)
        original = structure.composition.formula
        for old, new in spec["replace"].items():
            structure.replace_species({old: new})
        structure.remove_oxidation_states()
        destination = out / f"{spec['name']}.cif"
        write_synthetic_model(structure, destination, symprec=0.001)
        reread = Structure.from_file(destination, primitive=False)
        records.append(
            {
                **spec,
                "source_cif": str(source),
                "source_formula_as_parsed": original,
                "output_cif": str(destination),
                "physical_screen": screen(reread),
            }
        )
    (out / "provenance.json").write_text(json.dumps({"records": records}, indent=2) + "\n")
    print(json.dumps({"records": records}, indent=2))


if __name__ == "__main__":
    main()
