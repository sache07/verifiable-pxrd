#!/usr/bin/env python3
"""Compare restrained March-Dollase texture axes from a common GPX baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def converge(path: Path, repeats: int = 3) -> G2.G2Project:
    project = G2.G2Project(gpxfile=str(path))
    project.set_Controls("cycles", 25)
    project.set_Frozen()
    for _ in range(repeats):
        project.refine()
        project = G2.G2Project(gpxfile=str(path))
        project.set_Frozen()
    return project


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    source = G2.G2Project(gpxfile=str(args.base.resolve()))
    hist_name = source.histogram(0).name
    phase_name = args.phase or source.phase(args.phase_index).name
    results = []
    for axis in args.axis:
        tag = "".join(str(v).replace("-", "m") for v in axis)
        output = (args.out_dir / f"texture-{args.phase_index}-{tag}.gpx").resolve()
        source.save(str(output))
        project = G2.G2Project(gpxfile=str(output))
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist_name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = float(args.initial)
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        variable = f"{phase.id}:{project.histogram(0).id}:MD"
        project.set_Controls("parmMin", float(args.minimum), variable)
        project.set_Controls("parmMax", float(args.maximum), variable)
        project.save()
        project = converge(output, args.repeats)
        hap = project.phase(phase_name).data["Histograms"][hist_name]
        results.append(
            {
                "axis": list(axis),
                "output": str(output),
                "wR_percent": project.histogram(0).get_wR(),
                "MD": hap["Pref.Ori."][1],
                "frozen": project.get_Frozen(),
            }
        )
    print(json.dumps({"base": str(args.base.resolve()), "phase": phase_name, "trials": results}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out-dir", type=Path, default=Path(".tmp"))
    parser.add_argument("--phase-index", type=int, default=0)
    parser.add_argument("--phase")
    parser.add_argument("--axis", action="append", nargs=3, type=int, required=True)
    parser.add_argument("--initial", type=float, default=0.98)
    parser.add_argument("--minimum", type=float, default=0.70)
    parser.add_argument("--maximum", type=float, default=1.40)
    parser.add_argument("--repeats", type=int, default=3)
    run(parser.parse_args())
