#!/usr/bin/env python3
"""Write a complete observed/calculated/difference profile from verified replay."""

from pathlib import Path
import argparse

import numpy as np


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("prediction", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    data = np.load(args.prediction)
    x = data["x"]
    observed = data["observed"]
    calculated = data["predicted"]
    background = data["background"]
    profile = np.column_stack((x, observed, calculated, observed - calculated, background))
    np.savetxt(
        args.output,
        profile,
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f", "%.10f"],
    )


if __name__ == "__main__":
    main()
