#!/usr/bin/env python3
"""Incrementally refine coordinates for selected phases in a GSAS project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def converge(path: Path, repeats: int = 3) -> G2.G2Project:
    project = G2.G2Project(gpxfile=str(path))
    project.set_Controls("cycles", 25)
    project.set_Frozen()
    for _ in range(repeats):
        project.refine()
        project = G2.G2Project(gpxfile=str(path))
        project.set_Frozen()
    return project


def atom_rows(phase: G2.G2Phase) -> list[dict]:
    return [
        {
            "label": atom.label,
            "element": atom.element,
            "coordinates": list(atom.coordinates),
            "flags": atom.refinement_flags,
            "adp": atom.ADP,
        }
        for atom in phase.atoms()
    ]


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    source = G2.G2Project(gpxfile=str(args.base.resolve()))
    output = args.out.resolve()
    source.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    for phase in project.phases():
        phase.set_refinements({"Atoms": {atom.label: " " for atom in phase.atoms()}})
    project.save()
    history = []
    for phase_name, element_text in args.stage:
        project = G2.G2Project(gpxfile=str(output))
        phase = project.phase(phase_name)
        elements = set(element_text.split(","))
        phase.set_refinements(
            {"Atoms": {atom.label: ("X" if atom.element in elements else " ") for atom in phase.atoms()}}
        )
        project.save()
        project = converge(output)
        history.append(
            {
                "phase": phase_name,
                "elements": sorted(elements),
                "wR_percent": project.histogram(0).get_wR(),
                "atoms": atom_rows(project.phase(phase_name)),
            }
        )
    result = {
        "base": str(args.base.resolve()),
        "output": str(output),
        "history": history,
        "final_wR_percent": project.histogram(0).get_wR(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }
    output.with_suffix(".atoms.json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument(
        "--stage",
        action="append",
        nargs=2,
        metavar=("PHASE", "ELEMENTS"),
        required=True,
        help="Refine coordinates in PHASE for comma-separated ELEMENTS; repeat for staged refinement.",
    )
    run(parser.parse_args())
