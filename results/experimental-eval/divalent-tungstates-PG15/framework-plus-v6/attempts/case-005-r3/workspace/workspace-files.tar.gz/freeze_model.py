#!/usr/bin/env python3
"""Fix weakly identifiable intensity terms, then reconverge the core model."""

from __future__ import annotations

from pathlib import Path
import argparse
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


def fractions(phases, histogram):
    values = np.asarray(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][histogram.name]["Scale"][0]
            for phase in phases
        ],
        dtype=float,
    )
    return (values / values.sum()).tolist()


def snapshot(project):
    histogram = project.histogram(0)
    phases = project.phases()
    covariance = project.data.get("Covariance", {}).get("data", {})
    instrument = histogram.data["Instrument Parameters"][0]
    return {
        "wR_percent": histogram.get_wR(),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "max_shift_over_esd": covariance.get("Rvals", {}).get("Max shft/sig"),
        "fractions": fractions(phases, histogram),
        "uiso": [phase.atoms()[0].uiso for phase in phases],
        "roughness_A": histogram.SampleParameters["SurfRoughA"],
        "roughness_B": histogram.SampleParameters["SurfRoughB"],
        "shift_um": histogram.SampleParameters["Shift"],
        "instrument": {
            key: instrument[key]
            for key in ["U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]
        },
        "cells": [phase.get_cell() for phase in phases],
        "phase_profiles": [
            {
                "scale": phase.data["Histograms"][histogram.name]["Scale"],
                "size": phase.data["Histograms"][histogram.name]["Size"],
                "mustrain": phase.data["Histograms"][histogram.name]["Mustrain"],
            }
            for phase in phases
        ],
        "varyList": [str(value) for value in covariance.get("varyList", [])],
        "parmFrozen": str(project.data["Controls"]["data"].get("parmFrozen", {})),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--uiso", nargs="+", type=float, required=True)
    parser.add_argument("--rough-a", type=float, required=True)
    parser.add_argument("--rough-b", type=float, required=True)
    parser.add_argument("--fix-cells", action="store_true")
    parser.add_argument("--replays", type=int, default=4)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    if len(args.uiso) != len(phases):
        parser.error("one --uiso value is required per phase")

    for phase, value in zip(phases, args.uiso):
        for atom in phase.atoms():
            atom.uiso = value
            atom.refinement_flags = atom.refinement_flags.replace("U", "") or " "
        if args.fix_cells:
            phase.data["General"]["Cell"][0] = False
    histogram.SampleParameters["SurfRoughA"] = [args.rough_a, False]
    histogram.SampleParameters["SurfRoughB"] = [args.rough_b, False]
    project.data["Constraints"]["data"] = {
        key: [] for key in ["Hist", "HAP", "Phase", "Global"]
    }
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 20)
    project.save(str(args.output.resolve()))

    history = []
    best_wR = float("inf")
    best_path = args.output.with_suffix(".best.gpx")
    for _ in range(args.replays):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.refine()
        project.save(str(args.output.resolve()))
        state = snapshot(project)
        history.append(state)
        if state["wR_percent"] < best_wR:
            best_wR = state["wR_percent"]
            shutil.copy2(args.output.resolve(), best_path.resolve())
        project = G2.G2Project(gpxfile=str(args.output.resolve()))

    shutil.copy2(best_path.resolve(), args.output.resolve())
    project = G2.G2Project(gpxfile=str(args.output.resolve()))
    selected = snapshot(project)
    result = {
        "input": str(args.input.resolve()),
        "output": str(args.output.resolve()),
        "history": history,
        "selected": selected,
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
