#!/usr/bin/env python3
"""Create a restrained two-or-more-phase GSAS-II baseline refinement."""

from __future__ import annotations

from pathlib import Path
import argparse
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def plain(value):
    if isinstance(value, dict):
        return {str(key): plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def mass_fractions(phases, histogram_name):
    terms = np.array(
        [
            float(phase.data["General"]["Mass"])
            * float(phase.data["Histograms"][histogram_name]["Scale"][0])
            for phase in phases
        ],
        dtype=float,
    )
    total = float(np.sum(terms))
    return (terms / total).tolist() if total > 0 else [None] * len(terms)


def snapshot(project, histogram, phases, stage):
    covariance = project.data.get("Covariance", {}).get("data", {})
    instrument = histogram.data["Instrument Parameters"][0]
    background = histogram.data["Background"]
    result = {
        "stage": stage,
        "wR_percent": histogram.get_wR(),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "Rvals": covariance.get("Rvals", {}),
        "varyList": [str(item) for item in covariance.get("varyList", [])],
        "sample": histogram.SampleParameters,
        "instrument": instrument,
        "background": background,
        "phases": [],
        "weight_fractions": mass_fractions(phases, histogram.name),
    }
    for phase in phases:
        hap = phase.data["Histograms"][histogram.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    return plain(result)


def build_project(output: Path, cif_paths: list[Path]):
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(output))
    phases = [
        project.add_phase(str(path), phasename=f"phase_{index}_{path.stem}", fmthint="CIF")
        for index, path in enumerate(cif_paths)
    ]
    histogram = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        phases=phases,
        fmthint="xye",
    )
    histogram.SampleParameters["Type"] = "Bragg-Brentano"
    histogram.SampleParameters["Gonio. radius"] = 200.0
    histogram.SampleParameters["Scale"] = [1.0, False]
    histogram.SampleParameters["Shift"] = [-600.0, False]
    histogram.SampleParameters["Transparency"] = [0.0, False]
    histogram.SampleParameters["SurfRoughA"] = [0.0, False]
    histogram.SampleParameters["SurfRoughB"] = [0.0, False]
    histogram.set_refinements(
        {
            "Limits": [9.90343322, 100.09488522],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [3000.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": False,
            },
        }
    )
    for phase in phases:
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
        for atom in phase.data["Atoms"]:
            atom[cia] = "I"
            atom[cia + 1] = 0.005
    project.set_Controls("cycles", 12)
    project.save()
    project.index_ids()
    return project, histogram, phases


def set_bounds(project, histogram, phases):
    hid = histogram.id
    limits = {
        f":{hid}:U": (0.0, 100.0),
        f":{hid}:W": (0.0, 100.0),
        f":{hid}:X": (0.0, 20.0),
        f":{hid}:SH/L": (0.001, 0.2),
        f":{hid}:Polariz.": (0.5, 1.0),
        f":{hid}:Shift": (-1000.0, 1000.0),
    }
    for phase in phases:
        limits[f"{phase.id}:{hid}:Scale"] = (0.0, 1.0e6)
    for variable, (low, high) in limits.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)


def refine(output: Path, cif_paths: list[Path]):
    project, histogram, phases = build_project(output, cif_paths)
    set_bounds(project, histogram, phases)
    history = [snapshot(project, histogram, phases, "initialized")]

    histogram.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [histogram])
    project.refine()
    history.append(snapshot(project, histogram, phases, "background_and_scales"))

    histogram.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine()
    history.append(snapshot(project, histogram, phases, "displacement_and_cells"))

    histogram.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine()
    history.append(snapshot(project, histogram, phases, "common_UWX"))

    histogram.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.refine()
    history.append(snapshot(project, histogram, phases, "common_UWX_SHL"))

    # Replay stability: save, reopen and rerun with exactly the retained flags.
    project.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    histogram = project.histogram(0)
    phases = project.phases()
    project.refine()
    project.save(str(output))
    history.append(snapshot(project, histogram, phases, "reopened_replay"))
    summary = {
        "project": str(output),
        "cifs": [str(path) for path in cif_paths],
        "history": history,
    }
    output.with_suffix(".json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("cifs", nargs="+", type=Path)
    args = parser.parse_args()
    summary = refine(args.output.resolve(), [path.resolve() for path in args.cifs])
    final = summary["history"][-1]
    print(
        json.dumps(
            {
                "project": summary["project"],
                "wR_percent": final["wR_percent"],
                "GOF": final["GOF"],
                "weight_fractions": final["weight_fractions"],
                "shift_um": final["sample"]["Shift"][0],
                "U": final["instrument"]["U"][1],
                "W": final["instrument"]["W"][1],
                "X": final["instrument"]["X"][1],
                "SH_L": final["instrument"]["SH/L"][1],
                "cells": [phase["cell"] for phase in final["phases"]],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
