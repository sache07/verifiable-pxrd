#!/usr/bin/env python3
"""Challenge a refined inventory with one physically screened watch-list phase."""

from pathlib import Path
import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


def fractions(phases, histogram):
    terms = np.asarray(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][histogram.name]["Scale"][0]
            for phase in phases
        ],
        dtype=float,
    )
    total = terms.sum()
    return (terms / total).tolist() if total > 0 else [None] * len(terms)


def snap(project, histogram, phases, stage):
    return {
        "stage": stage,
        "wR_percent": histogram.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "fractions": fractions(phases, histogram),
        "scales": [phase.data["Histograms"][histogram.name]["Scale"] for phase in phases],
        "cells": [phase.get_cell() for phase in phases],
        "varyList": [
            str(item)
            for item in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("candidate", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    histogram = project.histogram(0)
    candidate = project.add_phase(
        str(args.candidate.resolve()),
        phasename=f"watch_{args.candidate.stem}",
        histograms=[histogram],
        fmthint="CIF",
    )
    phases = project.phases()
    hap = candidate.data["Histograms"][histogram.name]
    hap["Scale"] = [0.5, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    cx, ct, cs, cia = candidate.data["General"]["AtomPtrs"]
    for atom in candidate.data["Atoms"]:
        atom[cia] = "I"
        atom[cia + 1] = 0.005
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 15)
    project.save(str(args.output.resolve()))
    project.index_ids()
    project.set_Controls("parmMin", 0.0, variable=f"{candidate.id}:{histogram.id}:Scale")
    project.set_Controls("parmMax", 1.0e6, variable=f"{candidate.id}:{histogram.id}:Scale")
    history = []
    project.refine()
    history.append(snap(project, histogram, phases, "scale_before_cell"))
    scale = candidate.data["Histograms"][histogram.name]["Scale"][0]
    if scale > 1.0e-5:
        candidate.set_refinements({"Cell": True})
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.refine()
        history.append(snap(project, histogram, phases, "cell_rechallenge"))
    project.save(str(args.output.resolve()))
    result = {
        "input": str(args.input.resolve()),
        "candidate": str(args.candidate.resolve()),
        "output": str(args.output.resolve()),
        "history": history,
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
