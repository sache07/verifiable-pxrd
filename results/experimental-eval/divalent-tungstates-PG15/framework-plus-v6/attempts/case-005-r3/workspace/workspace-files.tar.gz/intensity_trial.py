#!/usr/bin/env python3
"""Test polarization and low-angle roughness against a stable inventory/profile."""

from pathlib import Path
import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


def fractions(phases, histogram):
    terms = np.asarray(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][histogram.name]["Scale"][0]
            for phase in phases
        ],
        dtype=float,
    )
    return (terms / terms.sum()).tolist()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "mode",
        choices=[
            "polarization",
            "roughness",
            "both",
            "rough_a_only",
            "rough_b_only",
            "pol_rough_a_only",
            "pol_rough_b_only",
        ],
    )
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    hid = histogram.id
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 15)
    inst = histogram.data["Instrument Parameters"][0]
    use_pol = args.mode in {"polarization", "both", "pol_rough_a_only", "pol_rough_b_only"}
    inst["Polariz."][2] = use_pol
    if args.mode in {"roughness", "both"}:
        histogram.SampleParameters["SurfRoughA"] = [0.20, True]
        histogram.SampleParameters["SurfRoughB"] = [0.05, True]
    elif args.mode in {"rough_a_only", "pol_rough_a_only"}:
        histogram.SampleParameters["SurfRoughA"] = [0.20, True]
        histogram.SampleParameters["SurfRoughB"] = [0.05, False]
    elif args.mode in {"rough_b_only", "pol_rough_b_only"}:
        histogram.SampleParameters["SurfRoughA"] = [0.20, False]
        histogram.SampleParameters["SurfRoughB"] = [0.05, True]
    else:
        histogram.SampleParameters["SurfRoughA"] = [0.0, False]
        histogram.SampleParameters["SurfRoughB"] = [0.0, False]
    project.save(str(args.output.resolve()))
    project.index_ids()
    for variable, low, high in [
        (f":{hid}:U", 0.0, 200.0),
        (f":{hid}:Polariz.", 0.5, 1.0),
        (f":{hid}:SurfRoughA", 0.0, 0.99),
        (f":{hid}:SurfRoughB", 0.0, 2.0),
    ]:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    project.refine()
    project.save(str(args.output.resolve()))
    project = G2.G2Project(gpxfile=str(args.output.resolve()))
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.refine()
    project.save(str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    covariance = project.data.get("Covariance", {}).get("data", {})
    result = {
        "mode": args.mode,
        "output": str(args.output.resolve()),
        "wR_percent": histogram.get_wR(),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "fractions": fractions(phases, histogram),
        "polarization": histogram.data["Instrument Parameters"][0]["Polariz."],
        "roughness_A": histogram.SampleParameters["SurfRoughA"],
        "roughness_B": histogram.SampleParameters["SurfRoughB"],
        "varyList": [str(item) for item in covariance.get("varyList", [])],
        "parmFrozen": str(project.data["Controls"]["data"].get("parmFrozen", {})),
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
