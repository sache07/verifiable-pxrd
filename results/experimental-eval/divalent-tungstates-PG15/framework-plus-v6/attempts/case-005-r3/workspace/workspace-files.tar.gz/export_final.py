#!/usr/bin/env python3
"""Export exact final-project CIFs and replay-derived profile/results."""

from __future__ import annotations

from pathlib import Path
import hashlib
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"
REPLAY = ROOT / ".tmp" / "replay-final"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    before = sha256(PROJECT)
    replay = json.loads((REPLAY / "replay.json").read_text())
    if replay.get("status") != "replayed" or replay.get("project_sha256") != before:
        raise RuntimeError("native replay is missing or does not correspond to final.gpx")

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(PROJECT))
    histogram = project.histogram(0)
    phases = project.phases()
    if histogram.name != replay["histogram"] or len(phases) != len(replay["phases"]):
        raise RuntimeError("project inventory differs from replay inventory")

    # Export saved phase data, without covariance values that could be stale.
    project.data["Covariance"]["data"] = {}
    cif_names = ["phase_WO3.cif", "phase_Co3O4.cif"]
    for phase, filename in zip(phases, cif_names):
        phase.export_CIF(str(ROOT / filename))

    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as data:
        x = data["x"].astype(float)
        observed = data["observed"].astype(float)
        calculated = data["predicted"].astype(float)
        background = data["background"].astype(float)
    public = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if not np.array_equal(x, public[:, 0]) or not np.array_equal(observed, public[:, 1]):
        raise RuntimeError("replay grid or observations differ from pattern.csv")
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.17g", "%.17g", "%.17g", "%.17g"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    parameter_count = len(
        G2.G2Project(gpxfile=str(PROJECT))
        .data.get("Covariance", {})
        .get("data", {})
        .get("varyList", [])
    )
    dof = len(x) - parameter_count
    rwp = 100.0 * np.sqrt(chi_square / denominator)
    rp = 100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed))
    gof = np.sqrt(chi_square / dof)
    rexp = 100.0 * np.sqrt(dof / denominator)
    fractions = [float(row["weight_fraction"]) for row in replay["phases"]]
    if abs(sum(fractions) - 1.0) > 1e-12:
        raise RuntimeError("replay fractions are not normalized")

    result = {
        "phases": [
            {
                "name": "triclinic tungsten(VI) oxide",
                "formula": "WO3",
                "space_group": "P -1",
                "cif_path": cif_names[0],
                "weight_fraction": fractions[0],
            },
            {
                "name": "cobalt(II,III) oxide spinel",
                "formula": "Co3O4",
                "space_group": "F d -3 m",
                "cif_path": cif_names[1],
                "weight_fraction": fractions[1],
            },
        ],
        "fit_statistics": {
            "Rwp_percent": float(rwp),
            "Rp_percent": float(rp),
            "Rexp_percent": float(rexp),
            "GOF": float(gof),
            "weighted_chi_square": chi_square,
            "degrees_of_freedom": int(dof),
            "number_of_points": int(len(x)),
            "number_of_refined_parameters": int(parameter_count),
        },
        "refinement_histogram": histogram.name,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "fraction_basis": "normalized over the modeled crystalline phases",
        "project_sha256": before,
        "native_replay": {
            "status": replay["status"],
            "parameters_optimized": replay["parameters_optimized"],
            "evaluation_grid": replay["evaluation_grid"],
            "profile_review_flags": replay["profile_review_flags"],
            "minimum_background_counts": float(np.min(background)),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    if sha256(PROJECT) != before:
        raise RuntimeError("final.gpx changed during export")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
