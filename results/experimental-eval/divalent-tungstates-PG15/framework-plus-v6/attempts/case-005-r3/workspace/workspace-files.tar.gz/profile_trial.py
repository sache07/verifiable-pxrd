#!/usr/bin/env python3
"""Compare one-phase-at-a-time size and strain broadening in a saved GPX."""

from pathlib import Path
import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


def weight_fractions(phases, histogram_name):
    terms = np.asarray(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][histogram_name]["Scale"][0]
            for phase in phases
        ],
        dtype=float,
    )
    return (terms / terms.sum()).tolist()


def summary(project, histogram, phases, stage):
    inst = histogram.data["Instrument Parameters"][0]
    controls = project.data["Controls"]["data"]
    return {
        "stage": stage,
        "wR_percent": histogram.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "weight_fractions": weight_fractions(phases, histogram.name),
        "shift_um": histogram.SampleParameters["Shift"][0],
        "instrument": {key: inst[key] for key in ["U", "W", "X", "SH/L", "Polariz."]},
        "background": histogram.data["Background"],
        "cells": [phase.get_cell() for phase in phases],
        "phase_profiles": [
            {
                "name": phase.name,
                "size": phase.data["Histograms"][histogram.name]["Size"],
                "mustrain": phase.data["Histograms"][histogram.name]["Mustrain"],
                "preferred_orientation": phase.data["Histograms"][histogram.name]["Pref.Ori."],
            }
            for phase in phases
        ],
        "varyList": [
            str(value)
            for value in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])
        ],
        "parmFrozen": str(controls.get("parmFrozen", {})),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", type=int)
    parser.add_argument("mode", choices=["size", "strain", "both"])
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    if not 0 <= args.phase < len(phases):
        raise SystemExit("phase index out of range")
    hid = histogram.id

    # Rebuild the common width model after the previous neutral-width trial hit bounds.
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 15)
    inst = histogram.data["Instrument Parameters"][0]
    for key, value, refine in [("U", 20.0, True), ("W", 2.0, False), ("X", 12.0, True), ("SH/L", 0.035, False)]:
        inst[key][1] = value
        inst[key][2] = refine
    inst["V"][1], inst["V"][2] = 0.0, False
    inst["Y"][1], inst["Y"][2] = 0.0, False
    inst["Z"][1], inst["Z"][2] = 0.0, False

    for phase in phases:
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]

    chosen = phases[args.phase]
    chosen_hap = chosen.data["Histograms"][histogram.name]
    if args.mode in {"size", "both"}:
        chosen_hap["Size"][1][0] = 0.30
        chosen_hap["Size"][2][0] = True
    if args.mode in {"strain", "both"}:
        chosen_hap["Mustrain"][1][0] = 2000.0
        chosen_hap["Mustrain"][1][1] = 2000.0
        chosen_hap["Mustrain"][2][0] = True

    project.save(str(args.output.resolve()))
    project.index_ids()
    for variable, low, high in [
        (f":{hid}:U", 0.0, 100.0),
        (f":{hid}:X", 0.0, 20.0),
        (f":{hid}:SH/L", 0.001, 0.2),
        (f"{chosen.id}:{hid}:Size;i", 0.02, 20.0),
        (f"{chosen.id}:{hid}:Mustrain;i", 0.0, 10000.0),
    ]:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)

    history = []
    project.refine()
    history.append(summary(project, histogram, phases, "phase_width"))

    # SH/L was strongly supported in the neutral model; release it only after widths settle.
    histogram.data["Instrument Parameters"][0]["SH/L"][2] = True
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.refine()
    history.append(summary(project, histogram, phases, "phase_width_and_SHL"))

    project.save(str(args.output.resolve()))
    project = G2.G2Project(gpxfile=str(args.output.resolve()))
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.refine()
    project.save(str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    history.append(summary(project, histogram, phases, "reopened_replay"))

    result = {
        "input": str(args.input.resolve()),
        "output": str(args.output.resolve()),
        "phase": args.phase,
        "mode": args.mode,
        "history": history,
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result["history"][-1], indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
