#!/usr/bin/env python3
"""Rebuild a stable common nuisance baseline and replay it repeatedly."""

from pathlib import Path
import argparse
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


def fractions(phases, histogram):
    terms = np.asarray(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][histogram.name]["Scale"][0]
            for phase in phases
        ],
        dtype=float,
    )
    return (terms / terms.sum()).tolist()


def snap(project):
    histogram = project.histogram(0)
    phases = project.phases()
    inst = histogram.data["Instrument Parameters"][0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "wR_percent": histogram.get_wR(),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "fractions": fractions(phases, histogram),
        "shift_um": histogram.SampleParameters["Shift"][0],
        "U": inst["U"][1],
        "W": inst["W"][1],
        "X": inst["X"][1],
        "SH_L": inst["SH/L"][1],
        "cells": [phase.get_cell() for phase in phases],
        "varyList": [str(item) for item in covariance.get("varyList", [])],
        "parmFrozen": str(project.data["Controls"]["data"].get("parmFrozen", {})),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=5, help="number of full refinement replays")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    inst = histogram.data["Instrument Parameters"][0]
    inst["SH/L"][1], inst["SH/L"][2] = 0.035, False
    inst["Polariz."][1], inst["Polariz."][2] = 0.7, False
    histogram.SampleParameters["SurfRoughA"] = [0.0, False]
    histogram.SampleParameters["SurfRoughB"] = [0.0, False]
    for phase in phases:
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][1], hap["Pref.Ori."][2] = 1.0, False
        for atom in phase.atoms():
            atom.refinement_flags = " "
            atom.uiso = 0.005
    project.data["Constraints"]["data"] = {
        key: [] for key in ["Hist", "HAP", "Phase", "Global"]
    }
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 20)
    project.save(str(args.output.resolve()))
    project.index_ids()
    project.set_Controls("parmMin", 0.0, variable=f":{histogram.id}:U")
    project.set_Controls("parmMax", 200.0, variable=f":{histogram.id}:U")
    history = []
    best_wR = float("inf")
    best_path = args.output.with_suffix(".best.gpx").resolve()
    for _ in range(args.cycles):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.refine()
        state = snap(project)
        history.append(state)
        if state["wR_percent"] < best_wR:
            best_wR = state["wR_percent"]
            project.save(str(args.output.resolve()))
            shutil.copy2(args.output.resolve(), best_path)
    shutil.copy2(best_path, args.output.resolve())
    project = G2.G2Project(gpxfile=str(args.output.resolve()))
    selected = snap(project)
    result = {
        "input": str(args.input.resolve()),
        "output": str(args.output.resolve()),
        "history": history,
        "selected": selected,
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
