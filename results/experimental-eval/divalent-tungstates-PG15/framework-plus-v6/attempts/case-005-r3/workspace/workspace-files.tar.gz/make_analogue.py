#!/usr/bin/env python3
"""Create an isovalent tungstate analogue and report a basic physical screen."""

from pathlib import Path
import argparse
import json

import numpy as np
from pymatgen.io.cif import CifParser, CifWriter


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("parent", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("substitutions", nargs="+", help="OLD=NEW")
    args = parser.parse_args()
    substitutions = dict(item.split("=", 1) for item in args.substitutions)
    structure = CifParser(
        args.parent.resolve(), occupancy_tolerance=1.0, site_tolerance=1e-5, frac_tolerance=0
    ).parse_structures(primitive=False, on_error="raise")[0]
    structure.remove_oxidation_states()
    structure.replace_species(substitutions)
    CifWriter(structure, symprec=0.001, significant_figures=10).write_file(args.output.resolve())
    distances = structure.distance_matrix.copy()
    np.fill_diagonal(distances, np.inf)
    report = {
        "parent": str(args.parent.resolve()),
        "output": str(args.output.resolve()),
        "substitutions": substitutions,
        "formula": structure.composition.reduced_formula,
        "occupied_composition": structure.composition.get_el_amt_dict(),
        "space_group": structure.get_space_group_info(symprec=0.01),
        "cell": [*structure.lattice.abc, *structure.lattice.angles],
        "density_g_cm3": structure.density,
        "minimum_separation_A": float(np.min(distances)),
    }
    args.output.with_suffix(".provenance.json").write_text(
        json.dumps(report, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(report, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
