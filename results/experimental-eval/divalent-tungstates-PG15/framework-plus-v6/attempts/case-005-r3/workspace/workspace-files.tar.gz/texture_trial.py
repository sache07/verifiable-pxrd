#!/usr/bin/env python3
"""Test one symmetry-distinct March-Dollase axis at a time."""

from pathlib import Path
import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


def fractions(phases, histogram):
    terms = np.asarray(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][histogram.name]["Scale"][0]
            for phase in phases
        ],
        dtype=float,
    )
    return (terms / terms.sum()).tolist()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", type=int)
    parser.add_argument("axis", nargs=3, type=int)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    selected = phases[args.phase]
    hap = selected.data["Histograms"][histogram.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 0.95
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(args.axis)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 15)
    project.save(str(args.output.resolve()))
    project.index_ids()
    variable = f"{selected.id}:{histogram.id}:MD"
    project.set_Controls("parmMin", 0.5, variable=variable)
    project.set_Controls("parmMax", 2.0, variable=variable)
    project.refine()
    project.save(str(args.output.resolve()))
    project = G2.G2Project(gpxfile=str(args.output.resolve()))
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.refine()
    project.save(str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    selected = phases[args.phase]
    covariance = project.data.get("Covariance", {}).get("data", {})
    result = {
        "phase": args.phase,
        "axis": args.axis,
        "output": str(args.output.resolve()),
        "wR_percent": histogram.get_wR(),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "fractions": fractions(phases, histogram),
        "preferred_orientation": selected.data["Histograms"][histogram.name]["Pref.Ori."],
        "varyList": [str(item) for item in covariance.get("varyList", [])],
        "parmFrozen": str(project.data["Controls"]["data"].get("parmFrozen", {})),
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
