#!/usr/bin/env python3
"""Run a bounded, best-tracked trial of selected GSAS-II nuisance terms."""

from __future__ import annotations

from pathlib import Path
import argparse
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


def fractions(phases, histogram):
    terms = np.asarray(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][histogram.name]["Scale"][0]
            for phase in phases
        ],
        dtype=float,
    )
    return (terms / terms.sum()).tolist()


def snapshot(project, stage):
    histogram = project.histogram(0)
    phases = project.phases()
    covariance = project.data.get("Covariance", {}).get("data", {})
    instrument = histogram.data["Instrument Parameters"][0]
    return {
        "stage": stage,
        "wR_percent": histogram.get_wR(),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "max_shift_over_esd": covariance.get("Rvals", {}).get("Max shft/sig"),
        "fractions": fractions(phases, histogram),
        "shift_um": histogram.SampleParameters["Shift"],
        "roughness_A": histogram.SampleParameters["SurfRoughA"],
        "roughness_B": histogram.SampleParameters["SurfRoughB"],
        "instrument": {
            key: instrument[key]
            for key in ["U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]
        },
        "phase_models": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][histogram.name]["Scale"],
                "size": phase.data["Histograms"][histogram.name]["Size"],
                "mustrain": phase.data["Histograms"][histogram.name]["Mustrain"],
                "uiso": phase.atoms()[0].uiso,
                "atom_flags": sorted({atom.refinement_flags for atom in phase.atoms()}),
            }
            for phase in phases
        ],
        "varyList": [str(value) for value in covariance.get("varyList", [])],
        "parmFrozen": str(project.data["Controls"]["data"].get("parmFrozen", {})),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--rough-a", type=float)
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--refine-w", action="store_true")
    parser.add_argument("--refine-shl", action="store_true")
    parser.add_argument("--fix-shift", action="store_true")
    parser.add_argument("--mustrain-phase", type=int)
    parser.add_argument("--mustrain-axis", nargs=3, type=int)
    parser.add_argument("--size-phase", type=int)
    parser.add_argument("--replays", type=int, default=3)
    args = parser.parse_args()

    if (args.mustrain_phase is None) != (args.mustrain_axis is None):
        parser.error("--mustrain-phase and --mustrain-axis must be supplied together")

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    instrument = histogram.data["Instrument Parameters"][0]
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 20)

    if args.rough_a is not None:
        histogram.SampleParameters["SurfRoughA"] = [args.rough_a, False]
        histogram.SampleParameters["SurfRoughB"][1] = True
        if histogram.SampleParameters["SurfRoughB"][0] <= 0:
            histogram.SampleParameters["SurfRoughB"][0] = 0.05
    if args.polarization:
        instrument["Polariz."][2] = True
    if args.refine_w:
        instrument["W"][2] = True
        if instrument["W"][1] < 2:
            instrument["W"][1] = 5.0
    if args.refine_shl:
        instrument["SH/L"][2] = True
    if args.fix_shift:
        histogram.SampleParameters["Shift"][1] = False

    if args.mustrain_phase is not None:
        hap = phases[args.mustrain_phase].data["Histograms"][histogram.name]
        current = max(float(hap["Mustrain"][1][0]), 300.0)
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = current
        hap["Mustrain"][1][1] = current
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = list(args.mustrain_axis)
    if args.size_phase is not None:
        hap = phases[args.size_phase].data["Histograms"][histogram.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][2] = [True, False, False]

    project.save(str(args.output.resolve()))
    project.index_ids()
    hid = histogram.id
    bounds = [
        (f":{hid}:U", 0.0, 200.0),
        (f":{hid}:W", 0.0, 100.0),
        (f":{hid}:X", 0.0, 20.0),
        (f":{hid}:SH/L", 0.001, 0.2),
        (f":{hid}:Polariz.", 0.5, 1.0),
        (f":{hid}:SurfRoughB", 0.0, 1.0),
    ]
    if args.mustrain_phase is not None:
        phase = phases[args.mustrain_phase]
        bounds += [
            (f"{phase.id}:{hid}:Mustrain;i", 0.0, 10000.0),
            (f"{phase.id}:{hid}:Mustrain;a", 0.0, 10000.0),
        ]
    if args.size_phase is not None:
        phase = phases[args.size_phase]
        bounds.append((f"{phase.id}:{hid}:Size;i", 0.02, 20.0))
    for variable, low, high in bounds:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)

    history = [snapshot(project, "configured")]
    best_wR = float("inf")
    best_path = args.output.with_suffix(".best.gpx")
    for index in range(args.replays):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.refine()
        project.save(str(args.output.resolve()))
        state = snapshot(project, f"replay_{index + 1}")
        history.append(state)
        if state["wR_percent"] < best_wR:
            best_wR = state["wR_percent"]
            shutil.copy2(args.output.resolve(), best_path.resolve())
        project = G2.G2Project(gpxfile=str(args.output.resolve()))

    shutil.copy2(best_path.resolve(), args.output.resolve())
    project = G2.G2Project(gpxfile=str(args.output.resolve()))
    selected = snapshot(project, "selected")
    result = {
        "input": str(args.input.resolve()),
        "output": str(args.output.resolve()),
        "options": vars(args) | {"input": str(args.input), "output": str(args.output)},
        "history": history,
        "selected": selected,
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(selected, indent=2))


if __name__ == "__main__":
    main()
