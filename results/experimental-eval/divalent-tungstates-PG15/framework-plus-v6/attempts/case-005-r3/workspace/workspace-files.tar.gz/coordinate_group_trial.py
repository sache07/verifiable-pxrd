#!/usr/bin/env python3
"""Refine a small atom group against a fixed-cell/profile baseline."""

from pathlib import Path
import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


def fractions(phases, histogram):
    values = np.asarray(
        [p.data["General"]["Mass"] * p.data["Histograms"][histogram.name]["Scale"][0] for p in phases]
    )
    return (values / values.sum()).tolist()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", type=int)
    parser.add_argument("indices", nargs="+", type=int)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    selected = phases[args.phase]
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 25)

    # Hold the established angular/profile/cell model while testing coordinates.
    for phase in phases:
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][histogram.name]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Pref.Ori."][2] = False
    histogram.data["Background"][0][1] = False
    for value in histogram.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False
    for key, value in histogram.SampleParameters.items():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False

    for atom_index in args.indices:
        atom = list(selected.atoms())[atom_index]
        atom.refinement_flags = "X"
    project.save(str(args.output.resolve()))
    project.index_ids()
    cx = selected.data["General"]["AtomPtrs"][0]
    for atom_index in args.indices:
        for axis_index, axis in enumerate("xyz"):
            coordinate = float(selected.data["Atoms"][atom_index][cx + axis_index])
            variable = f"{selected.id}::dA{axis}:{atom_index}"
            project.set_Controls("parmMin", coordinate - 0.010, variable=variable)
            project.set_Controls("parmMax", coordinate + 0.010, variable=variable)
    history = []
    for _ in range(2):
        project.refine()
        history.append(
            {
                "wR_percent": project.histogram(0).get_wR(),
                "fractions": fractions(project.phases(), project.histogram(0)),
                "parmFrozen": str(project.data["Controls"]["data"].get("parmFrozen", {})),
            }
        )
    project.save(str(args.output.resolve()))
    for index, phase in enumerate(project.phases()):
        phase.export_CIF(str(args.output.with_name(f"{args.output.stem}_phase{index}.cif")))
    result = {
        "input": str(args.input.resolve()),
        "output": str(args.output.resolve()),
        "phase": args.phase,
        "indices": args.indices,
        "history": history,
        "atoms": project.phase(args.phase).data["Atoms"],
        "varyList": [
            str(item)
            for item in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])
        ],
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
