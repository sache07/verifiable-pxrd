#!/usr/bin/env python3
"""Build a minimal GSAS-II project and print its initial parameter layout."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def main() -> None:
    output = Path(sys.argv[1] if len(sys.argv) > 1 else "probe.gpx").resolve()
    cif_paths = [Path(value).resolve() for value in sys.argv[2:]]
    if not cif_paths:
        raise SystemExit("usage: gsas_probe.py OUTPUT.gpx PHASE.cif [PHASE.cif ...]")

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(output))
    phases = [
        project.add_phase(str(path), phasename=f"phase_{index}_{path.stem}", fmthint="CIF")
        for index, path in enumerate(cif_paths)
    ]
    histogram = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        phases=phases,
        fmthint="xye",
    )
    histogram.SampleParameters["Type"] = "Bragg-Brentano"
    histogram.SampleParameters["Gonio. radius"] = 200.0
    histogram.SampleParameters["Scale"] = [1.0, False]
    histogram.SampleParameters["Shift"] = [-600.0, False]
    histogram.SampleParameters["Transparency"] = [0.0, False]
    histogram.SampleParameters["SurfRoughA"] = [0.0, False]
    histogram.SampleParameters["SurfRoughB"] = [0.0, False]
    histogram.set_refinements(
        {
            "Limits": [9.90343322, 100.09488522],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [3000.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": False,
            },
        }
    )
    for phase in phases:
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        # Match the normalized source-model convention used in this problem.
        cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
        for atom in phase.data["Atoms"]:
            atom[cia] = "I"
            atom[cia + 1] = 0.005

    project.set_Controls("cycles", 8)
    project.save()
    print("histogram", histogram.name, "id", histogram.id)
    print("sample", histogram.SampleParameters)
    print("instrument", histogram.data["Instrument Parameters"][0])
    print("background", histogram.data["Background"])
    for phase in phases:
        print("phase", phase.name, "id", phase.id, "cell", phase.get_cell())
        print("HAP", phase.data["Histograms"][histogram.name])
        print("atoms", phase.data["Atoms"])
    print("controls", project.data["Controls"]["data"])


if __name__ == "__main__":
    main()
