#!/usr/bin/env python3
"""Test restrained atomic coordinates and phase-common isotropic ADPs."""

from pathlib import Path
import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


def fractions(phases, histogram):
    terms = np.asarray(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][histogram.name]["Scale"][0]
            for phase in phases
        ],
        dtype=float,
    )
    return (terms / terms.sum()).tolist()


def append_flag(atom, flag):
    flags = atom.refinement_flags.replace(" ", "")
    if flag not in flags:
        atom.refinement_flags = flags + flag


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--uiso", nargs="*", type=int, default=[])
    parser.add_argument(
        "--coords",
        nargs="*",
        default=[],
        help="Selections such as 0:W, 0:O, 1:O or 0:all",
    )
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 18)

    # Set requested flags and common starting ADPs.
    for phase_index in args.uiso:
        phase = phases[phase_index]
        for atom_index, atom in enumerate(phase.atoms()):
            atom.uiso = 0.008
            append_flag(atom, "U")
    for selection in args.coords:
        phase_text, element = selection.split(":", 1)
        phase = phases[int(phase_text)]
        for atom in phase.atoms():
            atom_element = atom.element.strip().capitalize()
            if element == "all" or atom_element == element:
                append_flag(atom, "X")

    project.save(str(args.output.resolve()))
    project.index_ids()
    project.set_Controls("parmMin", 0.0, variable=f":{histogram.id}:U")
    project.set_Controls("parmMax", 200.0, variable=f":{histogram.id}:U")

    # A phase-common Uiso matches the source/sample convention while avoiding
    # unsupported atom-by-atom thermal parameters.
    for phase_index in args.uiso:
        phase = phases[phase_index]
        variables = [f"{phase.id}::AUiso:{index}" for index, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
        for variable in variables:
            project.set_Controls("parmMin", 0.0005, variable=variable)
            project.set_Controls("parmMax", 0.05, variable=variable)

    for selection in args.coords:
        phase_text, element = selection.split(":", 1)
        phase = phases[int(phase_text)]
        cx = phase.data["General"]["AtomPtrs"][0]
        for atom_index, atom in enumerate(phase.atoms()):
            atom_element = atom.element.strip().capitalize()
            if element != "all" and atom_element != element:
                continue
            for axis_index, axis in enumerate("xyz"):
                variable = f"{phase.id}::dA{axis}:{atom_index}"
                coordinate = float(phase.data["Atoms"][atom_index][cx + axis_index])
                project.set_Controls("parmMin", coordinate - 0.012, variable=variable)
                project.set_Controls("parmMax", coordinate + 0.012, variable=variable)

    project.refine()
    project.save(str(args.output.resolve()))
    project = G2.G2Project(gpxfile=str(args.output.resolve()))
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.refine()
    project.save(str(args.output.resolve()))
    histogram = project.histogram(0)
    phases = project.phases()
    covariance = project.data.get("Covariance", {}).get("data", {})
    exports = []
    for index, phase in enumerate(phases):
        cif = args.output.with_name(f"{args.output.stem}_phase{index}.cif")
        phase.export_CIF(str(cif))
        exports.append(str(cif.resolve()))
    result = {
        "output": str(args.output.resolve()),
        "uiso_phases": args.uiso,
        "coordinate_selections": args.coords,
        "wR_percent": histogram.get_wR(),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "fractions": fractions(phases, histogram),
        "cells": [phase.get_cell() for phase in phases],
        "atoms": [phase.data["Atoms"] for phase in phases],
        "exports": exports,
        "varyList": [str(item) for item in covariance.get("varyList", [])],
        "parmFrozen": str(project.data["Controls"]["data"].get("parmFrozen", {})),
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                key: result[key]
                for key in [
                    "output",
                    "uiso_phases",
                    "coordinate_selections",
                    "wR_percent",
                    "GOF",
                    "fractions",
                    "exports",
                    "varyList",
                    "parmFrozen",
                ]
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
