#!/usr/bin/env python3
"""Refine only phase scales and the watch-list phase cell in a two-phase GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=10)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    hist = project.histogram(0)
    phases = project.phases()
    if len(phases) != 2:
        raise ValueError("Expected one major and one watch-list phase")

    hist.clear_refinements({"Background": True, "Instrument Parameters": list(hist.InstrumentParameters)})
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in phases:
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True,
                                     "Pref.Ori.": True, "HStrain": True})
        phase.set_HAP_refinements({"Scale": True})
    phases[1].set_refinements({"Cell": True})

    project.set_Controls("cycles", args.cycles)
    for _ in range(3):
        project.refine(makeBack=False)
    project.save(str(args.output))

    masses = np.asarray([
        phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in phases
    ])
    report = {
        "names": [phase.name for phase in phases],
        "cells": [phase.get_cell() for phase in phases],
        "scales": [phase.data["Histograms"][hist.name]["Scale"][0] for phase in phases],
        "weight_fractions": (masses / masses.sum()).tolist(),
        "residuals": plain(hist.residuals),
        "varyList": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
    }
    args.output.with_suffix(".json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
