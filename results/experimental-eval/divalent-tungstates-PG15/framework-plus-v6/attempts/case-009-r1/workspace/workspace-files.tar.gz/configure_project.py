#!/usr/bin/env python3
"""Apply bounded profile values to a GSAS-II project and recalculate it."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("profile_json", type=Path)
    parser.add_argument("--strain-axis", nargs=3, type=int)
    parser.add_argument("--axial-strain", type=float)
    args = parser.parse_args()

    values = json.loads(args.profile_json.read_text())["parameters"]
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    for key in ["U", "W", "X", "SH/L"]:
        token = f":0:{key}"
        if token in values:
            inst[key][1] = float(values[token])
        inst[key][2] = False

    size = float(values.get("0:0:Size;i", 10.0))
    strain = float(values.get("0:0:Mustrain;i", 0.0))
    phase.setSampleProfile(hist.name, "size", "isotropic", size, LGmix=1.0)
    if args.strain_axis:
        axial = strain if args.axial_strain is None else args.axial_strain
        phase.setSampleProfile(hist.name, "microstrain", "uniaxial", strain, axial, args.strain_axis, LGmix=1.0)
    else:
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", strain, LGmix=1.0)
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save(str(args.output))


if __name__ == "__main__":
    main()
