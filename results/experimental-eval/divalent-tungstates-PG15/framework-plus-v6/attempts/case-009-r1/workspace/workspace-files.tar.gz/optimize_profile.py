#!/usr/bin/env python3
"""Bounded direct optimization of physical GSAS-II profile parameters."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares
from GSASII import GSASIIstrIO as IO, GSASIIstrMath as M


def load_forward(gpx: Path):
    histograms, phases = IO.GetUsedHistogramsAndPhases(str(gpx))
    name = next(name for name in histograms if name.startswith("PWDR"))
    histograms = {name: histograms[name]}
    hist = histograms[name]
    controls = dict(IO.GetControls(str(gpx)))
    controls.pop("PhasePartials", None)
    rigid = IO.GetRigidBodies(str(gpx))
    ids = rigid.get("RBIds", {"Vector": [], "Residue": []})
    _, rb = IO.GetRigidBodyModels(rigid, Print=False)
    natoms, atomidx, _, phase, pawley, ff, ef, orb, bl, mf, maxss = IO.GetPhaseData(
        phases, {}, ids, Print=False
    )
    controls.update(
        atomIndx=atomidx, Natoms=natoms, FFtables=ff, EFtables=ef,
        ORBtables=orb, BLtables=bl, MFtables=mf, maxSSwave=maxss,
    )
    _, hap, extra = IO.GetHistogramPhaseData(phases, histograms, Controls=controls, Print=False)
    controls.update(extra)
    _, hp, hist1, extra = IO.GetHistogramData(histograms, Print=False)
    controls.update(extra)
    parameters = {**rb, **phase, **hap, **hp}
    IO.GetFprime(controls, histograms)
    arrays = hist["Data"]
    return name, hist, phases, controls, pawley, hist1, parameters, np.asarray(arrays[0]), np.asarray(arrays[1])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx", type=Path)
    parser.add_argument("--output", type=Path, default=Path("profile_opt.json"))
    parser.add_argument("--max-nfev", type=int, default=160)
    parser.add_argument("--uniaxial", action="store_true")
    args = parser.parse_args()

    name, hist, phases, controls, pawley, hist1, base, x, y = load_forward(args.gpx)
    weight = 1.0 / np.sqrt(np.maximum(y, 1.0))
    denominator = float(np.sum(y))
    evaluations = 0

    # q = U, W, log(X), log(size_um), strain_i/1000, [strain_a/1000], log(SH/L)
    q0 = [10.0, 20.0, np.log(1.0), np.log(0.20), 1.0]
    lower = [0.0, 2.0, np.log(0.1), np.log(0.04), 0.0]
    upper = [40.0, 40.0, np.log(6.0), np.log(1.50), 8.0]
    if args.uniaxial:
        if "0:0:Mustrain;a" not in base:
            raise ValueError("Project does not contain uniaxial microstrain parameters")
        q0.append(1.0); lower.append(0.0); upper.append(8.0)
    q0.append(np.log(0.03)); lower.append(np.log(0.005)); upper.append(np.log(0.10))
    q0, lower, upper = map(np.asarray, (q0, lower, upper))

    def unpack(q):
        values = {
            ":0:U": q[0], ":0:W": q[1], ":0:X": np.exp(q[2]),
            "0:0:Size;i": np.exp(q[3]), "0:0:Mustrain;i": 1000.0 * q[4],
        }
        if args.uniaxial:
            values["0:0:Mustrain;a"] = 1000.0 * q[5]
        values[":0:SH/L"] = np.exp(q[-1])
        return values

    def residual(q):
        nonlocal evaluations
        evaluations += 1
        parameters = copy.deepcopy(base)
        parameters.update(unpack(q))
        signal, background = M.getPowderProfile(
            parameters, hist1, x, [], hist, phases, controls, pawley, name
        )
        return (y - signal - background) * weight

    initial = residual(q0)
    result = least_squares(
        residual, q0, bounds=(lower, upper), max_nfev=args.max_nfev,
        x_scale=np.array([20.0, 20.0, 1.0, 1.0] + [2.0] * (2 if args.uniaxial else 1) + [1.0]),
        diff_step=0.01,
        ftol=1e-9, xtol=1e-9, gtol=1e-7, verbose=0,
    )
    final = residual(result.x)
    report = {
        "source_gpx": str(args.gpx),
        "success": bool(result.success),
        "message": result.message,
        "evaluations": evaluations,
        "initial_rwp_percent": 100.0 * float(np.sqrt(np.dot(initial, initial) / denominator)),
        "final_rwp_percent": 100.0 * float(np.sqrt(np.dot(final, final) / denominator)),
        "parameters": {key: float(value) for key, value in unpack(result.x).items()},
        "active_mask": result.active_mask.tolist(),
        "optimality": float(result.optimality),
        "cost": float(result.cost),
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
