#!/usr/bin/env python3
"""Build fit.csv and result.json from the independent final-project replay."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / "final-replay"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    replay = json.loads((REPLAY / "replay.json").read_text())
    if replay.get("status") != "replayed" or replay.get("profile_review_flags"):
        raise RuntimeError("Final project did not pass a clean independent replay")
    if replay.get("project_sha256") != sha256(ROOT / "final.gpx"):
        raise RuntimeError("Replay does not correspond to the current final.gpx")

    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as data:
        x = data["x"].copy()
        observed = data["observed"].copy()
        calculated = data["predicted"].copy()
    public = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1, ndmin=2)
    if not np.array_equal(x, public[:, 0]) or not np.array_equal(observed, public[:, 1]):
        raise RuntimeError("Replay grid or observations differ from pattern.csv")

    difference = observed - calculated
    table = np.column_stack((x, observed, calculated, difference))
    np.savetxt(
        ROOT / "fit.csv",
        table,
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.1f", "%.10f", "%.10f"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    weighted_chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    n_points = int(len(observed))
    n_parameters = 24
    rwp = float(100.0 * np.sqrt(weighted_chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    reduced = float(weighted_chi_square / (n_points - n_parameters))

    result = {
        "schema_version": 1,
        "refinement_histogram": replay["histogram"],
        "phases": [
            {
                "name": "MnWO4 (wolframite)",
                "formula": "MnWO4",
                "space_group": "P 2/c (No. 13)",
                "cif_path": "MnWO4.cif",
                "weight_fraction": 1.0,
                "weight_fraction_basis": "normalized over the modeled crystalline phases",
            }
        ],
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "expected_rwp_percent_poisson_no_parameter_correction": float(
                100.0 * np.sqrt(n_points / denominator)
            ),
            "weighted_chi_square": weighted_chi_square,
            "reduced_chi_square": reduced,
            "goodness_of_fit_sqrt_reduced_chi_square": float(np.sqrt(reduced)),
            "n_points": n_points,
            "n_refined_parameters": n_parameters,
            "weighting": "1/max(observed_counts, 1)",
            "difference_convention": "observed - calculated",
            "calculation_source": "fresh native GSAS-II atomic replay of final.gpx on the complete original grid",
        },
        "project": {
            "path": "final.gpx",
            "sha256": replay["project_sha256"],
            "independent_replay_status": replay["status"],
            "profile_review_flags": replay["profile_review_flags"],
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
