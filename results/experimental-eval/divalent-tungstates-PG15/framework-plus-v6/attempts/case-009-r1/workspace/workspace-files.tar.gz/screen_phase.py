#!/usr/bin/env python3
"""Scale-first candidate phase screen under a fixed common nuisance model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--name", required=True)
    parser.add_argument("--initial-weight", type=float, default=0.02)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    hist = project.histogram(0)
    hist.clear_refinements({"Background": True, "Instrument Parameters": list(hist.InstrumentParameters)})
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True,
                                     "Pref.Ori.": True, "HStrain": True})

    candidate = project.add_phase(
        str(args.candidate), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    candidate.setSampleProfile(hist.name, "size", "isotropic", 0.12, LGmix=1.0)
    candidate.setSampleProfile(hist.name, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap_new = candidate.data["Histograms"][hist.name]
    hap_new["Pref.Ori."][1] = 1.0
    hap_new["Pref.Ori."][2] = False
    hap_new["Extinction"] = [0.0, False]

    major = project.phase(0)
    hap_major = major.data["Histograms"][hist.name]
    major_mass_scale = major.data["General"]["Mass"] * hap_major["Scale"][0]
    new_mass = candidate.data["General"]["Mass"]
    hap_new["Scale"][0] = args.initial_weight / (1.0 - args.initial_weight) * major_mass_scale / new_mass
    major.set_HAP_refinements({"Scale": True})
    candidate.set_HAP_refinements({"Scale": True})

    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save(str(args.output))
    masses = np.array([
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ])
    fractions = masses / masses.sum() if masses.sum() else np.full_like(masses, np.nan)
    report = {
        "candidate": str(args.candidate),
        "names": [p.name for p in project.phases()],
        "scales": [p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()],
        "mass_terms": masses.tolist(),
        "weight_fractions": fractions.tolist(),
        "residuals": {k: v for k, v in hist.residuals.items() if isinstance(v, (int, float))},
        "cells": [p.get_cell() for p in project.phases()],
    }
    args.output.with_suffix(".json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
