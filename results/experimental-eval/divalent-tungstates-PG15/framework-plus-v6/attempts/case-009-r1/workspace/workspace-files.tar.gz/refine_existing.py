#!/usr/bin/env python3
"""Apply one controlled GSAS-II refinement challenge to an existing project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=6)
    parser.add_argument("--iterations", type=int, default=1)
    parser.add_argument("--correction", choices=["keep", "zero", "shift"], default="keep")
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--fix-polarization", type=float)
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--texture-axis", nargs=3, type=int)
    parser.add_argument("--coords", action="store_true")
    parser.add_argument("--adp", action="store_true")
    parser.add_argument("--common-uiso", type=float,
                        help="convert all sites to isotropic ADPs, initialize and constrain them equal")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters

    if args.correction != "keep":
        inst["Zero"][2] = False
        sample["Shift"][1] = False
        if args.correction == "zero":
            sample["Shift"][0] = 0.0
            inst["Zero"][1] = 0.0
            inst["Zero"][2] = True
        else:
            inst["Zero"][1] = 0.0
            sample["Shift"][0] = 0.0
            sample["Shift"][1] = True
    if args.polarization:
        inst["Polariz."][2] = True
    if args.fix_polarization is not None:
        inst["Polariz."][1] = args.fix_polarization
        inst["Polariz."][2] = False
    if args.roughness:
        sample["SurfRoughA"] = [0.20, True]
        sample["SurfRoughB"] = [0.10, True]
    if args.texture_axis:
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(args.texture_axis)
    if args.common_uiso is not None:
        _, _, _, cia = phase.data["General"]["AtomPtrs"]
        for atom in phase.data["Atoms"]:
            atom[cia] = "I"
            atom[cia + 1] = args.common_uiso
            atom[cia + 2:cia + 8] = [0.0] * 6
        variables = tuple(f"0::AUiso:{i}" for i in range(len(phase.data["Atoms"])))
        project.add_EquivConstr(variables)
    if args.coords or args.adp or args.common_uiso is not None:
        flags = ("X" if args.coords else "") + ("U" if (args.adp or args.common_uiso is not None) else "")
        phase.set_refinements({"Atoms": {"all": flags}})

    project.set_Controls("cycles", args.cycles)
    for _ in range(args.iterations):
        project.refine(makeBack=False)
    project.save(str(args.output))

    hap = phase.data["Histograms"][hist.name]
    summary = {
        "arguments": plain(vars(args)),
        "residuals": plain(hist.residuals),
        "cell": phase.get_cell(),
        "instrument": {k: inst[k][1] for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]},
        "sample": {k: sample[k][0] if isinstance(sample[k], list) else sample[k]
                   for k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]},
        "background": plain(hist.Background),
        "hap": {k: plain(hap[k]) for k in ["Scale", "Size", "Mustrain", "Pref.Ori.", "Extinction", "HStrain"]},
        "atoms": plain(phase.data["Atoms"]),
        "varyList": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
        "sig": plain(project.data.get("Covariance", {}).get("data", {}).get("sig", [])),
    }
    args.output.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({k: summary[k] for k in ["residuals", "cell", "instrument", "sample", "hap", "varyList"]}, indent=2))


if __name__ == "__main__":
    main()
