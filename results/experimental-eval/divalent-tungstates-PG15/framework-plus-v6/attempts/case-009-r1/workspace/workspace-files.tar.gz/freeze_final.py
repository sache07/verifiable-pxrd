#!/usr/bin/env python3
"""Freeze the selected atomic model and export its CIF from the same GPX."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("project", type=Path)
    parser.add_argument("cif", type=Path)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.project))
    histograms = project.histograms()
    phases = project.phases()
    if len(histograms) != 1 or len(phases) != 1:
        raise ValueError("The selected final inventory must contain one histogram and one phase")
    hist, phase = histograms[0], phases[0]

    # Make every inactive correction exactly neutral. The accepted isotropic
    # crystallite-size term remains active; microstrain and texture do not.
    inst = hist.InstrumentParameters
    for key in ("Zero", "V", "Y", "Z"):
        inst[key][1] = 0.0
        inst[key][2] = False
    for key in ("U", "W", "X", "SH/L", "Polariz."):
        inst[key][2] = False

    sample = hist.SampleParameters
    sample["Transparency"] = [0.0, False]
    sample["Shift"][1] = False
    sample["SurfRoughA"][1] = False
    sample["SurfRoughB"][1] = False

    background = hist.Background
    background[0][1] = False
    background[1]["nPeaks"] = 0
    background[1]["peaksList"] = []
    background[1]["nDebye"] = 0
    background[1]["debyeTerms"] = []

    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][4] = [False] * len(hap["Mustrain"][4])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["LeBail"] = False
    phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True,
                                 "Pref.Ori.": True, "HStrain": True})
    phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})

    # Equal Uiso values are already stored explicitly on every site, so the
    # now-unused refinement equivalence and stale covariance can be removed.
    constraints = project.data.get("Constraints", {}).get("data", {})
    for key in ("Hist", "HAP", "Phase", "Global"):
        constraints[key] = []
    project.data.setdefault("Covariance", {})["data"] = {}
    project.set_Controls("cycles", 0)
    project.save(str(args.project))

    # Export directly from the exact saved atomic phase.
    frozen = G2.G2Project(gpxfile=str(args.project))
    frozen.data.setdefault("Covariance", {})["data"] = {}
    frozen.phase(0).export_CIF(str(args.cif))


if __name__ == "__main__":
    main()
