#!/usr/bin/env python3
"""Build and stage a reversible GSAS-II trial refinement for MnWO4."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)


def residual(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    values = {}
    for key, value in hist.residuals.items():
        try:
            values[key] = float(value)
        except (TypeError, ValueError):
            continue
    values["cell_volume"] = float(project.phase(0).get_cell()["volume"])
    return values


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    return {
        "label": label,
        "residuals": residual(project),
        "cell": phase.get_cell(),
        "instrument": {k: inst[k][1] for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]},
        "sample": {k: sample[k][0] if isinstance(sample[k], list) else sample[k]
                   for k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]},
        "background": list(hist.Background[0]),
        "hap": {
            "Scale": hap["Scale"][0],
            "Size": hap["Size"],
            "Mustrain": hap["Mustrain"],
            "Pref.Ori.": hap["Pref.Ori."],
            "Extinction": hap["Extinction"],
        },
        "varyList": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
    }


def set_neutral_hap(phase, hist) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 100.0
    hap["Size"][1][1] = 100.0
    hap["Size"][1][2] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="trial.gpx")
    parser.add_argument("--correction", choices=["zero", "shift"], default="shift")
    parser.add_argument("--background", choices=["chebyschev-1", "inv interpolate", "log interpolate"], default="chebyschev-1")
    parser.add_argument("--background-terms", type=int, default=8)
    parser.add_argument("--profile", choices=["instrument", "size", "strain", "size_strain"], default="instrument")
    parser.add_argument("--refine-shl", action="store_true")
    parser.add_argument("--physical-profile", action="store_true",
                        help="separate single-phase width surrogates to avoid negative/correlated U and X")
    parser.add_argument("--cycles", type=int, default=5)
    args = parser.parse_args()

    output = (ROOT / args.output).resolve()
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    datafile = ROOT / ".tmp" / f"{output.stem}.xye"
    datafile.parent.mkdir(exist_ok=True)
    np.savetxt(datafile, np.column_stack([x, y, sigma]), fmt="%.10g")

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(output))
    phase = project.add_phase(str(SOURCE), phasename="MnWO4_wolframite", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(datafile), str(ROOT / "instrument.instprm"), phases=[phase], fmthint="xye"
    )
    hist.data["data"][1][2] = 1.0 / np.maximum(y, 1.0)
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"][1] = False
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    set_neutral_hap(phase, hist)

    coeffs = [800.0] + [0.0] * (args.background_terms - 1)
    hist.set_refinements({
        "Background": {
            "type": args.background,
            "no. coeffs": args.background_terms,
            "coeffs": coeffs,
            "refine": True,
        }
    })
    phase.set_HAP_refinements({"Scale": True})
    project.set_Controls("cycles", args.cycles)
    history = []

    project.refine()
    history.append(snapshot(project, "background_scale"))

    phase.set_refinements({"Cell": True})
    if args.correction == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    else:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine()
    history.append(snapshot(project, "cell_angular"))

    inst = hist.InstrumentParameters
    if args.physical_profile and args.profile == "size":
        inst["U"][1], inst["W"][1], inst["X"][1] = 10.0, 10.0, 0.1
        inst["U"][2], inst["W"][2], inst["X"][2] = True, True, False
        history.append(snapshot(project, "physical_profile_initialized"))
    elif args.physical_profile and args.profile == "strain":
        inst["U"][1], inst["W"][1], inst["X"][1] = 0.0, 10.0, 1.0
        inst["U"][2], inst["W"][2], inst["X"][2] = False, True, True
        history.append(snapshot(project, "physical_profile_initialized"))
    elif args.physical_profile and args.profile == "size_strain":
        inst["U"][1], inst["W"][1], inst["X"][1] = 5.0, 10.0, 0.1
        inst["U"][2], inst["W"][2], inst["X"][2] = False, True, False
        history.append(snapshot(project, "physical_profile_initialized"))
    else:
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        project.refine()
        history.append(snapshot(project, "common_uwx"))

    if args.refine_shl:
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.refine()
        history.append(snapshot(project, "common_shl"))

    if args.profile in {"size", "size_strain"}:
        phase.setSampleProfile(hist.name, "size", "isotropic", 0.2, LGmix=1.0)
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        project.refine()
        history.append(snapshot(project, "isotropic_size"))
    if args.profile in {"strain", "size_strain"}:
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", 1000.0, LGmix=1.0)
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        project.refine()
        history.append(snapshot(project, "isotropic_strain"))

    project.save(str(output))
    report = output.with_suffix(".json")
    report.write_text(json.dumps({"arguments": vars(args), "history": history}, indent=2) + "\n")
    print(json.dumps(history[-1], indent=2))


if __name__ == "__main__":
    main()
