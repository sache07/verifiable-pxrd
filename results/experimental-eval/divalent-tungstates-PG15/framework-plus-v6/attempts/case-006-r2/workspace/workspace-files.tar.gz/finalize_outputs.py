#!/usr/bin/env python3
"""Export the exact final GSAS-II model, profile, fractions, and fit metrics."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"


def main() -> None:
    project = G2.G2Project(gpxfile=str(PROJECT))
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], float)
    observed = np.asarray(arrays[1], float)
    calculated = np.asarray(arrays[3], float)
    background = np.asarray(arrays[4], float)
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference, background]),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt="%.10g",
    )

    phase_files = {"CuWO4": "CuWO4.cif", "WO3_mono_2311041": "WO3.cif"}
    phase_meta = {
        "CuWO4": {"formula": "CuWO4", "space_group": "P -1"},
        "WO3_mono_2311041": {"formula": "WO3", "space_group": "P 21/c"},
    }
    mass_scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scales.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
    total = sum(mass_scales)

    # Export the full-precision saved phase state, not rounded covariance values.
    project.data["Covariance"]["data"] = {}
    rows = []
    for phase, mass_scale in zip(project.phases(), mass_scales):
        filename = phase_files[phase.name]
        phase.export_CIF(str(ROOT / filename))
        rows.append(
            {
                "name": "monoclinic WO3" if phase.name == "WO3_mono_2311041" else phase.name,
                **phase_meta[phase.name],
                "cif_path": filename,
                "weight_fraction": mass_scale / total,
            }
        )

    weights = 1.0 / np.maximum(observed, 1.0)
    weighted_sse = float(np.sum(weights * difference**2))
    rwp = float(100 * np.sqrt(weighted_sse / np.sum(weights * observed**2)))
    rp = float(100 * np.sum(np.abs(difference)) / np.sum(observed))
    rexp = float(hist.residuals.get("wRmin", float("nan")))
    result = {
        "phases": rows,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "rexp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "weighted_sum_of_squares": weighted_sse,
            "n_points": int(x.size),
            "weighting": "1/max(observed_counts, 1); pointwise standard uncertainties were not supplied",
        },
        "refinement_histogram": hist.name,
        "project_path": "final.gpx",
        "fraction_basis": "GSAS-II phase scale multiplied by unit-cell mass, normalized over modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
