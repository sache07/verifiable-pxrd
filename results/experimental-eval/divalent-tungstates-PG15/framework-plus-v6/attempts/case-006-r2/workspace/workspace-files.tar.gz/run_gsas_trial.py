#!/usr/bin/env python3
"""Apply one reversible GSAS-II model trial to a converged project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def summarize(project: G2.G2Project, iteration: int, trial: str) -> dict:
    hist = project.histogram(0)
    xy = hist.data["data"][1]
    obs, calc = np.asarray(xy[1], float), np.asarray(xy[3], float)
    weights = 1 / np.maximum(obs, 1.0)
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": atom.coordinates,
                    "occ": atom.occupancy,
                    "uiso": atom.uiso if atom.adp_flag == "I" else None,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    return {
        "trial": trial,
        "iteration": iteration,
        "rwp_percent": float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2))),
        "residuals": hist.residuals,
        "instrument": {
            k: hist.InstrumentParameters[k][1]
            for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            k: hist.SampleParameters[k][0]
            for k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "background": hist.data["Background"][0],
        "phases": phases,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "frozen": project.get_Frozen(),
    }


def freeze_profile(hist) -> None:
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})


def apply_trial(
    project: G2.G2Project,
    trial: str,
    axis: list[int] | None,
    phase_name: str | None,
    roughness: list[float] | None,
) -> None:
    hist = project.histogram(0)
    phase = project.phase(phase_name) if phase_name else project.phase(0)
    if phase is None:
        raise ValueError(f"phase {phase_name!r} not found")
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    hap = phase.data["Histograms"][hist.name]
    phase_hist = f"{phase.id}:{hist.id}"

    if trial == "shift":
        hist.clear_refinements({"Instrument Parameters": ["Zero"]})
        inst["Zero"][1] = 0.0
        sample["Shift"] = [-580.0, True]
        project.set_Controls("parmMin", -1000.0, variable=":0:Shift")
        project.set_Controls("parmMax", 1000.0, variable=":0:Shift")
    elif trial == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif trial == "shl":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    elif trial == "background8":
        coeffs = list(hist.data["Background"][0][3:]) + [0.0, 0.0]
        hist.set_refinements(
            {"Background": {"type": "chebyschev-1", "no. coeffs": 8, "coeffs": coeffs, "refine": True}}
        )
    elif trial == "release_profile":
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        project.set_Controls("parmMin", 0.0, variable=":0:U")
        project.set_Controls("parmMin", 0.0, variable=":0:W")
        project.set_Controls("parmMin", 0.0, variable=":0:X")
        project.set_Controls("parmMax", 100.0, variable=":0:U")
        project.set_Controls("parmMax", 100.0, variable=":0:W")
        project.set_Controls("parmMax", 20.0, variable=":0:X")
    elif trial == "fix_u_zero":
        hist.clear_refinements({"Instrument Parameters": ["U"]})
        inst["U"][1] = 0.0
    elif trial == "roughness_a":
        sample["SurfRoughA"] = [0.1, True]
        sample["SurfRoughB"] = [0.0, False]
    elif trial == "roughness_ab":
        start_a, start_b = roughness or [0.1, 0.05]
        sample["SurfRoughA"] = [start_a, True]
        sample["SurfRoughB"] = [start_b, True]
        project.set_Controls("parmMin", 0.001, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.999, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.001, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughB")
    elif trial == "cu_coords":
        phase.atom("Cu1").refinement_flags = "X"
    elif trial == "cu_o_coords":
        phase.atom("Cu1").refinement_flags = "X"
        for label in ("O1", "O2", "O3", "O4"):
            phase.atom(label).refinement_flags = "X"
    elif trial == "oxygen_coords":
        for label in ("O1", "O2", "O3", "O4"):
            phase.atom(label).refinement_flags = "X"
    elif trial == "uiso_heavy":
        phase.atom("Cu1").refinement_flags += "U"
        phase.atom("W1").refinement_flags += "U"
        project.set_Controls("parmMin", 0.001, variable="0::AUiso:*")
        project.set_Controls("parmMax", 0.04, variable="0::AUiso:*")
    elif trial == "uiso_all":
        for atom in phase.atoms():
            if "U" not in atom.refinement_flags:
                atom.refinement_flags += "U"
        project.set_Controls("parmMin", 0.001, variable="0::AUiso:*")
        project.set_Controls("parmMax", 0.04, variable="0::AUiso:*")
    elif trial == "size":
        freeze_profile(hist)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][1][1] = 1.0
        hap["Size"][2] = [True, False, False]
        project.set_Controls("parmMin", 0.02, variable=f"{phase_hist}:Size;i")
        project.set_Controls("parmMax", 20.0, variable=f"{phase_hist}:Size;i")
    elif trial == "strain":
        freeze_profile(hist)
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 500.0
        hap["Mustrain"][2] = [True, False, False]
        project.set_Controls("parmMin", 0.0, variable=f"{phase_hist}:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, variable=f"{phase_hist}:Mustrain;i")
    elif trial == "strain_axial":
        if axis is None:
            raise ValueError("strain_axial trial requires --axis h k l")
        freeze_profile(hist)
        hap["Mustrain"][0] = "uniaxial"
        # GSAS-II's uniaxial derivative divides by the equatorial term, so
        # use a numerically neutral 1 ppm floor rather than exact zero.
        hap["Mustrain"][1][0] = 1.0
        hap["Mustrain"][1][1] = 500.0
        hap["Mustrain"][2] = [False, True, False]
        hap["Mustrain"][3] = axis
        project.set_Controls("parmMin", 0.0, variable=f"{phase_hist}:Mustrain;a")
        project.set_Controls("parmMax", 20000.0, variable=f"{phase_hist}:Mustrain;a")
    elif trial == "texture":
        if axis is None:
            raise ValueError("texture trial requires --axis h k l")
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        project.set_Controls("parmMin", 0.5, variable=f"{phase_hist}:MD")
        project.set_Controls("parmMax", 2.0, variable=f"{phase_hist}:MD")
    else:
        raise ValueError(f"unknown trial {trial}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("trial", choices=[
        "shift", "polarization", "shl", "background8", "release_profile", "fix_u_zero", "roughness_a", "roughness_ab",
        "cu_coords", "oxygen_coords", "cu_o_coords", "uiso_heavy", "uiso_all",
        "size", "strain", "strain_axial", "texture",
    ])
    parser.add_argument("--axis", nargs=3, type=int)
    parser.add_argument("--phase")
    parser.add_argument("--roughness", nargs=2, type=float, metavar=("A", "B"))
    parser.add_argument("--iterations", type=int, default=3)
    parser.add_argument("--cycles", type=int, default=20)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    project.set_Frozen()
    apply_trial(project, args.trial, args.axis, args.phase, args.roughness)
    project.set_Controls("cycles", args.cycles)
    project.save()
    project = G2.G2Project(gpxfile=str(args.output.resolve()))
    for iteration in range(1, args.iterations + 1):
        project.refine(makeBack=False)
        print(json.dumps(summarize(project, iteration, args.trial), default=str, separators=(",", ":")))
        project.save()
        project = G2.G2Project(gpxfile=str(args.output.resolve()))


if __name__ == "__main__":
    main()
