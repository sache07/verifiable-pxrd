#!/usr/bin/env python3
"""Create and stage a physically neutral single-phase GSAS-II baseline."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


ROOT = Path(__file__).resolve().parent
GPX = ROOT / "work_baseline.gpx"


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    hap = phase.data["Histograms"][hist.name]
    arrays = hist.data["data"][1]
    obs, calc, back = (np.asarray(arrays[i], float) for i in (1, 3, 4))
    weights = 1 / np.maximum(obs, 1.0)
    rwp = 100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2))
    result = {
        "stage": label,
        "residuals": hist.residuals,
        "rwp_recomputed_percent": float(rwp),
        "cell": phase.get_cell(),
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in sample.items()
            if k in {"Type", "Gonio. radius", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
        },
        "hap": {
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        },
        "background": hist.data["Background"][0],
        "calculated_min_max": [float(calc.min()), float(calc.max())],
        "background_min_max": [float(back.min()), float(back.max())],
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(result, default=str, separators=(",", ":")))
    return result


def save_reopen(project: G2.G2Project) -> G2.G2Project:
    project.save()
    return G2.G2Project(gpxfile=str(GPX))


def refine_stage(project: G2.G2Project, label: str) -> G2.G2Project:
    project.refine(makeBack=False)
    snapshot(project, label)
    return save_reopen(project)


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(GPX))
    phase = project.add_phase(str(ROOT / "models/cuwo4_start.cif"), phasename="CuWO4", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "instrument.instprm"),
        phases=[phase],
        fmthint="comma",
    )
    hist.set_refinements({"Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [1200.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": False,
            }
        }
    )
    sample = hist.SampleParameters
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Scale"] = [1.0, False]
    for key, value in (("Shift", 0.0), ("Transparency", 0.0), ("SurfRoughA", 0.0), ("SurfRoughB", 0.0)):
        sample[key] = [value, False]

    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][1][1] = 10.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]

    # Bounds prevent nonphysical profile and polarization values from being
    # accepted silently. GSAS-II freezes a term if it reaches a bound.
    project.save()
    for variable, lower in ((":0:U", 0.0), (":0:W", 0.0), (":0:X", 0.0), (":0:SH/L", 0.001), (":0:Polariz.", 0.0)):
        project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 80.0, variable=":0:U")
    project.set_Controls("parmMax", 80.0, variable=":0:W")
    project.set_Controls("parmMax", 10.0, variable=":0:X")
    project.set_Controls("parmMin", -0.8, variable=":0:Zero")
    project.set_Controls("parmMax", 0.8, variable=":0:Zero")
    project.set_Controls("cycles", 12)

    # Forward calculation from the neutral model.
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    snapshot(project, "neutral_forward")
    project = save_reopen(project)
    project.set_Controls("cycles", 12)

    hist, phase = project.histogram(0), project.phase(0)
    hist.set_refinements({"Background": {"refine": True}})
    phase.set_HAP_refinements({"Scale": True}, [hist])
    project = refine_stage(project, "background_scale")

    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project = refine_stage(project, "add_zero")

    phase = project.phase(0)
    phase.set_refinements({"Cell": True})
    project = refine_stage(project, "add_cell")

    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["W"]})
    project = refine_stage(project, "add_W")

    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["U", "X"]})
    project = refine_stage(project, "add_U_X")

    project.save()
    print(json.dumps({"completed": str(GPX), "GSAS_II_revision": GSASIIpath.GetVersionNumber()}))


if __name__ == "__main__":
    main()
