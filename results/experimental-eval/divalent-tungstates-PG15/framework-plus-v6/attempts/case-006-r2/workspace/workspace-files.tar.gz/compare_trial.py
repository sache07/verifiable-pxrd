#!/usr/bin/env python3
"""Compare local weighted residuals for isolated reflections in two GPX files."""

from __future__ import annotations

import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline")
    parser.add_argument("trial")
    parser.add_argument("--phase", default="CuWO4")
    parser.add_argument("--separation", type=float, default=0.28)
    args = parser.parse_args()

    base = G2.G2Project(gpxfile=args.baseline)
    trial = G2.G2Project(gpxfile=args.trial)
    h0, h1 = base.histogram(0), trial.histogram(0)
    a0, a1 = h0.data["data"][1], h1.data["data"][1]
    x = np.asarray(a0[0], float)
    obs = np.asarray(a0[1], float)
    calc0 = np.asarray(a0[3], float)
    calc1 = np.asarray(a1[3], float)
    weight = 1.0 / np.maximum(obs, 1.0)

    reflections = h1.data["Reflection Lists"]
    target = np.asarray(reflections[args.phase]["RefList"], float)
    all_rows = []
    for name, block in reflections.items():
        for row in np.asarray(block["RefList"], float):
            all_rows.append((name, tuple(int(v) for v in row[:3]), float(row[5])))

    rows = []
    for ref in target:
        hkl = tuple(int(v) for v in ref[:3])
        pos = float(ref[5])
        others = [abs(pos - p) for name, other_hkl, p in all_rows if name != args.phase or other_hkl != hkl]
        separation = min(others) if others else 999.0
        if separation < args.separation:
            continue
        half_width = 0.20 if pos < 60 else 0.30
        use = np.abs(x - pos) <= half_width
        if not np.any(use):
            continue
        sse0 = float(np.sum(weight[use] * (obs[use] - calc0[use]) ** 2))
        sse1 = float(np.sum(weight[use] * (obs[use] - calc1[use]) ** 2))
        rows.append(
            {
                "hkl": hkl,
                "two_theta": round(pos, 5),
                "separation_deg": round(separation, 4),
                "fcalc_sq": round(float(ref[9]), 2),
                "texture_factor": round(float(ref[12]), 5),
                "weighted_sse_improvement": round(sse0 - sse1, 3),
                "relative_improvement": round((sse0 - sse1) / max(sse0, 1e-12), 5),
            }
        )
    rows.sort(key=lambda row: row["weighted_sse_improvement"], reverse=True)
    print(json.dumps({"best": rows[:20], "worst": rows[-10:]}, indent=2))


if __name__ == "__main__":
    main()
