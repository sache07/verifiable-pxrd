#!/usr/bin/env python3
"""Replace atom-specific isotropic ADPs with one constrained phase ADP."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def report(project: G2.G2Project, phase_name: str, iteration: int) -> dict:
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    obs, calc = np.asarray(arrays[1], float), np.asarray(arrays[3], float)
    weights = 1.0 / np.maximum(obs, 1.0)
    phase = project.phase(phase_name)
    return {
        "iteration": iteration,
        "phase": phase_name,
        "rwp_percent": float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2))),
        "uiso": {atom.label: atom.uiso for atom in phase.atoms()},
        "flags": {atom.label: atom.refinement_flags for atom in phase.atoms()},
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("--start", type=float, default=0.009)
    parser.add_argument("--iterations", type=int, default=3)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    phase = project.phase(args.phase)
    if phase is None:
        raise ValueError(f"phase {args.phase!r} not found")
    variables = []
    for index, atom in enumerate(phase.atoms()):
        atom.uiso = args.start
        if "U" not in atom.refinement_flags:
            atom.refinement_flags += "U"
        variables.append(f"{phase.id}::AUiso:{index}")
    project.add_EquivConstr(variables)
    project.set_Controls("parmMin", 0.001, variable=f"{phase.id}::AUiso:*")
    project.set_Controls("parmMax", 0.04, variable=f"{phase.id}::AUiso:*")
    project.set_Frozen()
    project.set_Controls("cycles", 20)
    project.save()
    project = G2.G2Project(gpxfile=str(args.output.resolve()))
    for iteration in range(1, args.iterations + 1):
        project.refine(makeBack=False)
        print(json.dumps(report(project, args.phase, iteration), separators=(",", ":")))
        project.save()
        project = G2.G2Project(gpxfile=str(args.output.resolve()))


if __name__ == "__main__":
    main()
