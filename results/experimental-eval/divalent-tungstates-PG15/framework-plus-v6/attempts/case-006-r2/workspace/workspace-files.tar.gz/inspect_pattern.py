#!/usr/bin/env python3
"""Quick, reproducible diagnostics for the supplied PXRD scan."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, minimum_filter1d
from scipy.signal import find_peaks, peak_widths


ROOT = Path(__file__).resolve().parent


def summarize_pattern() -> None:
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    step = float(np.median(np.diff(x)))

    # A broad lower-envelope estimate is used only for peak discovery. Refinement
    # will use the raw counts and an explicit GSAS-II background.
    lower = minimum_filter1d(y, size=max(5, round(1.2 / step)), mode="nearest")
    baseline = gaussian_filter1d(lower, sigma=max(1, 0.35 / step), mode="nearest")
    signal = y - baseline
    smooth = gaussian_filter1d(signal, sigma=max(1, 0.018 / step))
    peaks, props = find_peaks(
        smooth,
        prominence=75,
        height=100,
        distance=max(2, round(0.055 / step)),
    )
    widths = peak_widths(smooth, peaks, rel_height=0.5)[0] * step
    order = np.argsort(props["prominences"])[::-1]

    print(
        json.dumps(
            {
                "points": len(x),
                "range_deg": [float(x[0]), float(x[-1])],
                "step_deg": step,
                "intensity_min_max": [float(y.min()), float(y.max())],
                "median_counts": float(np.median(y)),
                "top_peaks": [
                    {
                        "two_theta_deg": round(float(x[peaks[i]]), 5),
                        "counts": round(float(y[peaks[i]]), 1),
                        "height_above_baseline": round(float(smooth[peaks[i]]), 1),
                        "prominence": round(float(props["prominences"][i]), 1),
                        "fwhm_deg_approx": round(float(widths[i]), 4),
                    }
                    for i in order[:100]
                ],
            },
            indent=2,
        )
    )


def list_cod_records() -> None:
    index = Path(
        "<HOME>/.local/share/characterizagent/backends/dara/venv/"
        "lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz"
    )
    with gzip.open(index, "rt") as handle:
        data = json.load(handle)
    for key in ("Cu-O-W", "Cu-O", "O-W"):
        rows = data.get(key, [])
        print(f"COD_SYSTEM {key} ({len(rows)} records)")
        for row in rows:
            print(json.dumps(row, separators=(",", ":")))


if __name__ == "__main__":
    summarize_pattern()
    list_cod_records()
