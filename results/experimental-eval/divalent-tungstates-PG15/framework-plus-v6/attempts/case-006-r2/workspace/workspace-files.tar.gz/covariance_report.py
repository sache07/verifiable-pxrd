#!/usr/bin/env python3
"""Print the strongest saved parameter correlations from a GSAS-II project."""

from __future__ import annotations

import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx")
    parser.add_argument("--threshold", type=float, default=0.8)
    args = parser.parse_args()
    project = G2.G2Project(gpxfile=args.gpx)
    data = project.data["Covariance"]["data"]
    names = list(data.get("varyList", []))
    cov = np.asarray(data.get("covMatrix", []), float)
    sig = np.sqrt(np.maximum(np.diag(cov), 0.0)) if cov.size else np.array([])
    with np.errstate(divide="ignore", invalid="ignore"):
        corr = cov / np.outer(sig, sig) if cov.size else np.empty((0, 0))
    pairs = []
    for i in range(len(names)):
        for j in range(i):
            value = float(corr[i, j])
            if np.isfinite(value) and abs(value) >= args.threshold:
                pairs.append({"a": names[j], "b": names[i], "correlation": value})
    pairs.sort(key=lambda row: abs(row["correlation"]), reverse=True)
    print(json.dumps({"n_parameters": len(names), "pairs": pairs[:80]}, indent=2))


if __name__ == "__main__":
    main()
