#!/usr/bin/env python3
"""Reopen and reconverge a GSAS-II project, reporting each replayed cycle."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def summary(project: G2.G2Project, iteration: int) -> dict:
    hist = project.histogram(0)
    obs = np.asarray(hist.data["data"][1][1], float)
    calc = np.asarray(hist.data["data"][1][3], float)
    w = 1 / np.maximum(obs, 1.0)
    return {
        "iteration": iteration,
        "rwp_percent": float(100 * np.sqrt(np.sum(w * (obs - calc) ** 2) / np.sum(w * obs**2))),
        "residuals": hist.residuals,
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": {
            key: hist.SampleParameters[key][0]
            for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "background": hist.data["Background"][0],
        "haps": {
            p.name: {
                "scale": p.data["Histograms"][hist.name]["Scale"][0],
                "size": p.data["Histograms"][hist.name]["Size"],
                "mustrain": p.data["Histograms"][hist.name]["Mustrain"],
                "pref_ori": p.data["Histograms"][hist.name]["Pref.Ori."],
            }
            for p in project.phases()
        },
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--iterations", type=int, default=3)
    parser.add_argument("--cycles", type=int, default=20)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    project.save()
    project = G2.G2Project(gpxfile=str(args.output.resolve()))
    project.set_Controls("cycles", args.cycles)
    for i in range(1, args.iterations + 1):
        project.refine(makeBack=False)
        print(json.dumps(summary(project, i), default=str, separators=(",", ":")))
        project.save()
        project = G2.G2Project(gpxfile=str(args.output.resolve()))
    project.save()


if __name__ == "__main__":
    main()
