#!/usr/bin/env python3
"""Obtain a robust starting triclinic CuWO4 cell from profile correlation."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Lattice, Structure
from scipy.ndimage import gaussian_filter1d, minimum_filter1d
from scipy.optimize import differential_evolution, minimize


WORK = Path(__file__).resolve().parent
PARENT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/"
    "cif/4/00/08/4000806.cif"
)
LAM1 = 1.540598
LAM2 = 1.544426


def make_profile(structure: Structure, x: np.ndarray, fwhm: float = 0.14) -> np.ndarray:
    pattern = XRDCalculator(wavelength=LAM1).get_pattern(
        structure, two_theta_range=(float(x[0]) - 1, float(x[-1]) + 1)
    )
    sticks = np.zeros_like(x)
    sigma = fwhm / 2.354820045
    radius = max(3, int(np.ceil(4 * sigma / np.median(np.diff(x)))))
    for tt, inten, d in zip(pattern.x, pattern.y, pattern.d_hkls):
        for wavelength, ratio in ((LAM1, 1.0), (LAM2, 0.5)):
            shifted = np.degrees(2 * np.arcsin(wavelength / (2 * d)))
            center = int(round((shifted - x[0]) / np.median(np.diff(x))))
            lo, hi = max(0, center - radius), min(len(x), center + radius + 1)
            if lo >= hi:
                continue
            delta = x[lo:hi] - shifted
            sticks[lo:hi] += ratio * inten * np.exp(-0.5 * (delta / sigma) ** 2)
    return sticks


def main() -> None:
    x_all, y_all = np.loadtxt(WORK / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    use = (x_all >= 12) & (x_all <= 70)
    x, y = x_all[use], y_all[use]
    step = np.median(np.diff(x))
    low = minimum_filter1d(y, size=round(1.3 / step), mode="nearest")
    baseline = gaussian_filter1d(low, 0.45 / step)
    target = np.maximum(gaussian_filter1d(y - baseline, 0.025 / step), 0)
    target /= np.linalg.norm(target)

    parent = Structure.from_file(PARENT)
    species = [site.species for site in parent]
    coords = parent.frac_coords
    evals = 0

    def score(params: np.ndarray) -> float:
        nonlocal evals
        evals += 1
        a, b, c, alpha, beta, gamma, zero = params
        try:
            structure = Structure(Lattice.from_parameters(a, b, c, alpha, beta, gamma), species, coords)
            profile = make_profile(structure, x - zero)
            norm = np.linalg.norm(profile)
            if not np.isfinite(norm) or norm == 0:
                return 2.0
            return float(1 - np.dot(target, profile / norm))
        except Exception:
            return 2.0

    source = np.array([*parent.lattice.abc, *parent.lattice.angles, 0.0])
    ambient_lit = np.array([4.7026, 5.8389, 4.8785, 91.677, 92.469, 82.805, 0.0])
    bounds = [
        (4.55, 4.85), (5.60, 6.05), (4.70, 5.05),
        (88.0, 95.0), (88.0, 96.0), (78.0, 88.0), (-0.3, 0.3),
    ]
    de = differential_evolution(
        score,
        bounds,
        x0=ambient_lit,
        seed=20261109,
        popsize=7,
        maxiter=24,
        tol=2e-5,
        polish=False,
        workers=1,
        updating="immediate",
    )
    local = minimize(score, de.x, method="Powell", bounds=bounds, options={"maxiter": 400, "xtol": 1e-7, "ftol": 1e-9})
    result = {
        "source_cell_and_zero": source.tolist(),
        "source_objective": score(source),
        "ambient_literature_cell_and_zero": ambient_lit.tolist(),
        "ambient_literature_objective": score(ambient_lit),
        "optimized_cell_and_zero": local.x.tolist(),
        "optimized_objective": float(local.fun),
        "evaluations": evals,
        "success": bool(local.success),
        "message": str(local.message),
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
