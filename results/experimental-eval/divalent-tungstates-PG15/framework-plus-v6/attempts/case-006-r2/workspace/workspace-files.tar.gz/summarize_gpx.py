#!/usr/bin/env python3
"""Print compact model summaries for one or more GSAS-II projects."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("projects", nargs="+", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    for path in args.projects:
        project = G2.G2Project(gpxfile=str(path.resolve()))
        hist = project.histogram(0)
        xy = hist.data["data"][1]
        obs, calc = np.asarray(xy[1], float), np.asarray(xy[3], float)
        w = 1 / np.maximum(obs, 1.0)
        phases = []
        mass_scales = []
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
            mass_scales.append(mass_scale)
            phases.append(
                {
                    "name": phase.name,
                    "scale": float(hap["Scale"][0]),
                    "mass_scale": mass_scale,
                    "cell": phase.get_cell(),
                    "size": hap["Size"],
                    "mustrain": hap["Mustrain"],
                    "pref_ori": hap["Pref.Ori."],
                }
            )
        total = sum(max(0.0, value) for value in mass_scales)
        for phase in phases:
            phase["weight_fraction"] = max(0.0, phase["mass_scale"]) / total if total else None
        result = {
            "project": str(path),
            "rwp_percent": float(100 * np.sqrt(np.sum(w * (obs - calc) ** 2) / np.sum(w * obs**2))),
            "phases": phases,
            "instrument": {k: hist.InstrumentParameters[k][1] for k in ("Zero", "Polariz.", "U", "V", "W", "X", "SH/L")},
            "sample": {k: hist.SampleParameters[k][0] for k in ("Shift", "SurfRoughA", "SurfRoughB")},
            "background": hist.data["Background"][0],
            "frozen": project.get_Frozen(),
            "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        }
        print(json.dumps(result, default=str, separators=(",", ":")))


if __name__ == "__main__":
    main()
