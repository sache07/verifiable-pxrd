#!/usr/bin/env python3
"""Plot a profile export and list coherent residual maxima."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks, peak_widths


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("profile", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    x, obs, calc, back, diff = np.loadtxt(args.profile, delimiter=",", skiprows=1).T
    step = np.median(np.diff(x))
    smooth = gaussian_filter1d(diff, max(1, 0.018 / step))
    peaks, props = find_peaks(smooth, prominence=80, height=80, distance=max(2, round(0.06 / step)))
    widths = peak_widths(smooth, peaks, rel_height=0.5)[0] * step
    order = np.argsort(props["prominences"])[::-1]
    print(
        json.dumps(
            [
                {
                    "two_theta": round(float(x[peaks[i]]), 5),
                    "residual_height": round(float(smooth[peaks[i]]), 2),
                    "prominence": round(float(props["prominences"][i]), 2),
                    "fwhm": round(float(widths[i]), 4),
                }
                for i in order[:80]
            ],
            indent=2,
        )
    )
    fig, axes = plt.subplots(4, 1, figsize=(14, 11), sharey=False)
    windows = [(9.9, 35), (35, 55), (55, 75), (75, 100.1)]
    for ax, (lo, hi) in zip(axes, windows):
        use = (x >= lo) & (x <= hi)
        ax.plot(x[use], obs[use], color="black", lw=0.65, label="observed")
        ax.plot(x[use], calc[use], color="crimson", lw=0.65, label="calculated")
        ax.plot(x[use], back[use], color="royalblue", lw=0.5, label="background")
        ax.plot(x[use], diff[use] - 0.08 * np.max(obs[use]), color="green", lw=0.5, label="difference (offset)")
        ax.set_xlim(lo, hi)
    axes[0].legend(ncol=4, fontsize=8)
    axes[-1].set_xlabel(r"$2\theta$ (degrees)")
    fig.tight_layout()
    fig.savefig(args.output, dpi=170)


if __name__ == "__main__":
    main()
