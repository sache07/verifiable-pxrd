#!/usr/bin/env python3
"""Fix phase-wide isotropic ADPs and replay all remaining refinements."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def report(project: G2.G2Project, iteration: int) -> dict:
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    obs, calc = np.asarray(arrays[1], float), np.asarray(arrays[3], float)
    weight = 1.0 / np.maximum(obs, 1.0)
    return {
        "iteration": iteration,
        "rwp_percent": float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2))),
        "uiso": {phase.name: sorted({round(atom.uiso, 12) for atom in phase.atoms()}) for phase in project.phases()},
        "frozen": project.get_Frozen(),
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase-uiso", nargs=2, action="append", metavar=("PHASE", "UISO"), required=True)
    parser.add_argument("--iterations", type=int, default=3)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    values = {name: float(value) for name, value in args.phase_uiso}
    if set(values) != {phase.name for phase in project.phases()}:
        raise ValueError("provide one --phase-uiso value for every phase")
    project.data["Constraints"]["data"]["Phase"] = []
    for phase in project.phases():
        for atom in phase.atoms():
            atom.uiso = values[phase.name]
            atom.refinement_flags = atom.refinement_flags.replace("U", "")
    project.set_Frozen()
    project.set_Controls("cycles", 20)
    project.save()
    project = G2.G2Project(gpxfile=str(args.output.resolve()))
    for iteration in range(1, args.iterations + 1):
        project.refine(makeBack=False)
        print(json.dumps(report(project, iteration), separators=(",", ":")))
        project.save()
        project = G2.G2Project(gpxfile=str(args.output.resolve()))


if __name__ == "__main__":
    main()
