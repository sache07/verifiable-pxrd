#!/usr/bin/env python3
"""Residual-led scale-first challenge for one candidate crystalline phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def report(project: G2.G2Project, stage: str, candidate_name: str) -> dict:
    hist = project.histogram(0)
    xy = hist.data["data"][1]
    obs, calc = np.asarray(xy[1], float), np.asarray(xy[3], float)
    weights = 1 / np.maximum(obs, 1.0)
    masses = []
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(weighted)
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell_mass": float(phase.data["General"]["Mass"]),
                "mass_scale": weighted,
                "cell": phase.get_cell(),
            }
        )
    total = sum(max(0.0, x) for x in masses)
    for row in rows:
        row["weight_fraction"] = max(0.0, row["mass_scale"]) / total if total else None
    return {
        "stage": stage,
        "candidate": candidate_name,
        "rwp_percent": float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2))),
        "residuals": hist.residuals,
        "phases": rows,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "frozen": project.get_Frozen(),
    }


def refine_reopen(project: G2.G2Project, output: Path, stage: str, name: str, iterations: int) -> G2.G2Project:
    for i in range(iterations):
        project.refine(makeBack=False)
        print(json.dumps(report(project, f"{stage}_{i + 1}", name), default=str, separators=(",", ":")))
        project.save()
        project = G2.G2Project(gpxfile=str(output.resolve()))
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("name")
    parser.add_argument("--cell", action="store_true")
    parser.add_argument("--iterations", type=int, default=2)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    phase = project.add_phase(str(args.cif.resolve()), phasename=args.name, histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = hap["Size"][1][1] = 10.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]

    main = project.phase(0)
    main_hap = main.data["Histograms"][hist.name]
    main_mass = float(main.data["General"]["Mass"])
    candidate_mass = float(phase.data["General"]["Mass"])
    hap["Scale"][0] = main_hap["Scale"][0] * main_mass / candidate_mass * 0.01 / 0.99
    hap["Scale"][1] = True
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    project.set_Controls("parmMax", 1000.0, variable=f"{phase.id}:{hist.id}:Scale")
    project.set_Controls("cycles", 20)
    project.save()
    project = G2.G2Project(gpxfile=str(args.output.resolve()))
    project = refine_reopen(project, args.output, "scale", args.name, args.iterations)

    if args.cell:
        candidate = project.phase(args.name)
        candidate.set_refinements({"Cell": True})
        project.set_Frozen()
        project.save()
        project = G2.G2Project(gpxfile=str(args.output.resolve()))
        project = refine_reopen(project, args.output, "cell", args.name, args.iterations)
    project.save()


if __name__ == "__main__":
    main()
