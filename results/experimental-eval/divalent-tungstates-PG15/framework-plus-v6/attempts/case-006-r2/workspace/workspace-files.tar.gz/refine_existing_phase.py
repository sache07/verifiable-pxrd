#!/usr/bin/env python3
"""Refine selected parameters for a phase already present in a GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def compact(project: G2.G2Project, phase_name: str, mode: str, iteration: int) -> dict:
    hist = project.histogram(0)
    xy = hist.data["data"][1]
    obs, calc = np.asarray(xy[1], float), np.asarray(xy[3], float)
    weights = 1 / np.maximum(obs, 1.0)
    mass_scales = [
        float(p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0])
        for p in project.phases()
    ]
    total = sum(max(0.0, m) for m in mass_scales)
    return {
        "phase": phase_name,
        "mode": mode,
        "iteration": iteration,
        "rwp_percent": float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2))),
        "phases": [
            {
                "name": p.name,
                "weight_fraction": max(0.0, m) / total,
                "cell": p.get_cell(),
                "scale": p.data["Histograms"][hist.name]["Scale"][0],
            }
            for p, m in zip(project.phases(), mass_scales)
        ],
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("mode", choices=["cell", "coordinates", "uiso", "coordinates_uiso"])
    parser.add_argument("--iterations", type=int, default=3)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    phase = project.phase(args.phase)
    if phase is None:
        raise ValueError(f"phase {args.phase!r} not found")
    if args.mode == "cell":
        phase.set_refinements({"Cell": True})
    else:
        flag = "XU" if args.mode == "coordinates_uiso" else ("X" if args.mode == "coordinates" else "U")
        for atom in phase.atoms():
            atom.refinement_flags = flag
        if "U" in flag:
            project.set_Controls("parmMin", 0.001, variable=f"{phase.id}::AUiso:*")
            project.set_Controls("parmMax", 0.04, variable=f"{phase.id}::AUiso:*")
    project.set_Frozen()
    project.set_Controls("cycles", 20)
    project.save()
    project = G2.G2Project(gpxfile=str(args.output.resolve()))
    for i in range(1, args.iterations + 1):
        project.refine(makeBack=False)
        print(json.dumps(compact(project, args.phase, args.mode, i), default=str, separators=(",", ":")))
        project.save()
        project = G2.G2Project(gpxfile=str(args.output.resolve()))


if __name__ == "__main__":
    main()
