#!/usr/bin/env python3
"""Export saved GSAS-II arrays and model details for independent diagnostics."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx", type=Path)
    parser.add_argument("prefix", type=Path)
    args = parser.parse_args()
    project = G2.G2Project(gpxfile=str(args.gpx.resolve()))
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    data = np.column_stack([np.asarray(arrays[i], float) for i in (0, 1, 3, 4, 5)])
    np.savetxt(
        args.prefix.with_suffix(".csv"),
        data,
        delimiter=",",
        header="two_theta,observed,calculated,background,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
    )
    details = {
        "histogram": hist.name,
        "residuals": hist.residuals,
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.data["Background"],
        "limits": hist.data["Limits"],
        "phases": [
            {
                "name": p.name,
                "cell": p.get_cell(),
                "general": p.data["General"],
                "hap": p.data["Histograms"].get(hist.name),
                "atoms": p.data["Atoms"],
            }
            for p in project.phases()
        ],
        "covariance": project.data.get("Covariance", {}).get("data", {}),
    }
    args.prefix.with_suffix(".json").write_text(json.dumps(plain(details), indent=2) + "\n")


if __name__ == "__main__":
    main()
