#!/usr/bin/env python3
"""Screen chemically plausible COD structures against the observed peak list."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d, minimum_filter1d
from scipy.optimize import linear_sum_assignment
from scipy.signal import find_peaks


WORK = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


IDS = [
    "4000806", "4000807", "1527404", "2002403",  # Cu-W-O
    "1011194", "9016057", "1010941", "9000603",  # copper oxides
    "1004057", "1010618", "1521532", "1521533", "1528915",
    "1563541", "2311041", "2106293", "2107312",  # tungsten oxides
]


def observed_peaks() -> tuple[np.ndarray, np.ndarray]:
    x, y = np.loadtxt(WORK / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    step = np.median(np.diff(x))
    low = minimum_filter1d(y, size=round(1.2 / step), mode="nearest")
    base = gaussian_filter1d(low, 0.35 / step)
    smooth = gaussian_filter1d(y - base, 0.018 / step)
    idx, p = find_peaks(smooth, prominence=120, distance=round(0.08 / step))
    return x[idx], p["prominences"]


def match_pattern(calc_x: np.ndarray, calc_i: np.ndarray, obs_x: np.ndarray, obs_i: np.ndarray) -> dict:
    # Compare only meaningful calculated families and coherent observed peaks.
    keep = calc_i >= max(calc_i) * 0.015
    cx, ci = calc_x[keep], calc_i[keep]
    # Grid search a small common 2theta zero shift. Cell anisotropy is not
    # optimized here; this is deliberately only an inventory screen.
    best = None
    for zero in np.linspace(-0.35, 0.35, 281):
        delta = np.abs((cx[:, None] + zero) - obs_x[None, :])
        # Dummy assignments allow unmatched calculated peaks at a 0.5 degree cost.
        cost = np.concatenate([delta, np.full((len(cx), len(cx)), 0.5)], axis=1)
        rows, cols = linear_sum_assignment(cost)
        matched = cols < len(obs_x)
        distances = cost[rows, cols]
        weights = ci[rows] / np.sum(ci[rows])
        score = float(np.sum(weights * np.minimum(distances, 0.5)))
        if best is None or score < best[0]:
            best = (score, zero, matched, rows, cols, distances)
    score, zero, matched, rows, cols, distances = best
    selected = matched & (distances < 0.22)
    return {
        "zero_screen_deg": round(float(zero), 4),
        "weighted_peak_distance_deg": round(score, 4),
        "calc_intensity_matched_within_0.22deg": round(float(np.sum(ci[rows[selected]]) / np.sum(ci)), 4),
        "examples": [
            [round(float(cx[r]), 4), round(float(obs_x[c]), 4), round(float(ci[r]), 1)]
            for r, c, ok in zip(rows, cols, selected)
            if ok
        ][:20],
    }


def minimum_distance(structure: Structure) -> float:
    dm = np.asarray(structure.distance_matrix, float)
    dm[dm < 1e-8] = np.inf
    return float(dm.min())


def main() -> None:
    ox, oi = observed_peaks()
    for cod_id in IDS:
        path = cod_path(cod_id)
        try:
            s = Structure.from_file(path)
            pattern = XRDCalculator(wavelength=1.540598).get_pattern(s, two_theta_range=(9.8, 100.2))
            result = {
                "cod_id": cod_id,
                "formula": s.composition.reduced_formula,
                "space_group": s.get_space_group_info(),
                "cell": [round(v, 5) for v in (*s.lattice.abc, *s.lattice.angles)],
                "sites": len(s),
                "density_g_cm3": round(float(s.density), 4),
                "minimum_contact_A": round(minimum_distance(s), 4),
                **match_pattern(np.asarray(pattern.x), np.asarray(pattern.y), ox, oi),
                "strongest_calculated_peaks": [
                    [round(float(x), 4), round(float(i), 2)]
                    for x, i in sorted(zip(pattern.x, pattern.y), key=lambda pair: pair[1], reverse=True)[:20]
                ],
            }
        except Exception as exc:
            result = {"cod_id": cod_id, "error": f"{type(exc).__name__}: {exc}"}
        print(json.dumps(result, separators=(",", ":")))


if __name__ == "__main__":
    main()
