#!/usr/bin/env python3
"""Export inspectable profiles, phase CIFs and key parameters from a GPX file."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    project = G2.G2Project(gpxfile=str(args.project))
    histogram = project.histograms()[0]
    data = histogram.data["data"][1]
    np.savez_compressed(
        args.output / "profile.npz",
        two_theta=np.asarray(data[0], float),
        observed=np.asarray(data[1], float),
        weight=np.asarray(data[2], float),
        calculated=np.asarray(data[3], float),
        background=np.asarray(data[4], float),
        difference=np.asarray(data[5], float),
    )

    rows = []
    mass_scales = []
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][histogram.name]
        phase.export_CIF(str(args.output / f"phase_{index}_{phase.name}.cif"))
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        mass_scales.append(mass_scale)
        rows.append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "mass": phase.data["General"]["Mass"],
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": phase.data["Atoms"],
            "atom_ptrs": phase.data["General"]["AtomPtrs"],
        })
    total = sum(mass_scales)
    for row, mass_scale in zip(rows, mass_scales):
        row["weight_fraction"] = mass_scale / total

    result = {
        "project": str(args.project),
        "histogram": histogram.name,
        "wR_percent": histogram.get_wR(),
        "residuals": histogram.residuals,
        "instrument": histogram.data["Instrument Parameters"][0],
        "sample": histogram.data["Sample Parameters"],
        "background": histogram.data["Background"],
        "phases": rows,
        "vary_list": project.get_VaryList(),
        "covariance": project.data.get("Covariance", {}).get("data", {}),
    }
    (args.output / "diagnostics.json").write_text(json.dumps(plain(result), indent=2) + "\n")


if __name__ == "__main__":
    main()
