#!/usr/bin/env python3
"""Refine one constrained isotropic displacement parameter per selected phase."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+", type=int)
    parser.add_argument("--initial", type=float, default=0.008)
    parser.add_argument("--passes", type=int, default=2)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input))
    project.filename = str(args.output)
    project.save(str(args.output))
    for phase_index in args.phases:
        phase = project.phases()[phase_index]
        variables = []
        for atom_index, atom in enumerate(phase.atoms()):
            atom.uiso = args.initial
            flags = atom.refinement_flags
            if "U" not in flags:
                atom.refinement_flags = flags + "U"
            variables.append(f"{phase.id}::AUiso:{atom_index}")
        project.save(str(args.output))
        project.add_EquivConstr(variables, reloadIdx=True)

    project.set_Controls("cycles", 16)
    for pass_index in range(args.passes):
        project.refine(makeBack=False)
        print(json.dumps({
            "pass": pass_index + 1,
            "wR_percent": project.histograms()[0].get_wR(),
            "uiso": {
                phase.name: [atom.uiso for atom in phase.atoms()]
                for phase in project.phases()
            },
        }))
    project.save(str(args.output))


if __name__ == "__main__":
    main()
