#!/usr/bin/env python3
"""Create the submitted CIFs, fit table and machine-readable result.

The calculated curve and CIFs are taken from a fresh, no-refinement replay of
the exact final.gpx. This keeps every exported quantity tied to the submitted
GSAS-II project rather than to a separately reconstructed model.
"""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"
REPLAY_DIR = ROOT / ".tmp" / "replay_final"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    replay = json.loads((REPLAY_DIR / "replay.json").read_text())
    if replay.get("status") != "replayed":
        raise RuntimeError(f"Final project did not replay: {replay}")
    if sha256(PROJECT) != replay["project_sha256"]:
        raise RuntimeError("final.gpx changed after the verified replay")

    with np.load(REPLAY_DIR / "prediction.npz", allow_pickle=False) as archive:
        x = np.asarray(archive["x"], dtype=float)
        observed = np.asarray(archive["observed"], dtype=float)
        calculated = np.asarray(archive["predicted"], dtype=float)
        background = np.asarray(archive["background"], dtype=float)
    public = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if not np.array_equal(x, public[:, 0]) or not np.array_equal(observed, public[:, 1]):
        raise RuntimeError("Replay does not use the complete original observation grid")
    if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("Invalid calculated profile")

    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
    )

    project = G2.G2Project(gpxfile=str(PROJECT))
    histogram = project.histograms()[0]
    if histogram.name != replay["histogram"]:
        raise RuntimeError("Replay histogram differs from the final project")
    phases = project.phases()
    if [p.name for p in phases] != [p["name"] for p in replay["phases"]]:
        raise RuntimeError("Replay phase inventory differs from the final project")

    exports = {"NiWO4": "NiWO4.cif", "WO3": "WO3.cif"}
    phase_rows = []
    for phase_report in replay["phases"]:
        name = phase_report["name"]
        destination = ROOT / exports[name]
        shutil.copyfile(REPLAY_DIR / phase_report["cif"], destination)
        phase = project.phase(name)
        cell = phase.get_cell()
        phase_rows.append(
            {
                "name": name,
                "formula": name,
                "space_group": "P 2/c" if name == "NiWO4" else "P 21/c",
                "cif_path": destination.name,
                "weight_fraction": float(phase_report["weight_fraction"]),
                "weight_percent": 100.0 * float(phase_report["weight_fraction"]),
                "cell_angstrom_degree": {
                    "a": float(cell["length_a"]),
                    "b": float(cell["length_b"]),
                    "c": float(cell["length_c"]),
                    "alpha": float(cell["angle_alpha"]),
                    "beta": float(cell["angle_beta"]),
                    "gamma": float(cell["angle_gamma"]),
                },
            }
        )

    weights = 1.0 / np.maximum(observed, 1.0)
    weighted_loss = float(np.sum(weights * difference**2))
    weighted_denominator = float(np.sum(weights * observed**2))
    rwp = 100.0 * np.sqrt(weighted_loss / weighted_denominator)
    rp = 100.0 * float(np.sum(np.abs(difference)) / np.sum(observed))
    residuals = histogram.residuals
    rexp = float(residuals.get("wRmin", np.nan))
    n_parameters = len(project.get_VaryList())
    dof = len(observed) - n_parameters
    result = {
        "analysis": "full-pattern atomic Rietveld refinement",
        "refinement_histogram": histogram.name,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent": float(rwp),
            "rp_percent": float(rp),
            "r_expected_percent": rexp,
            "goodness_of_fit_rwp_over_rexp": float(rwp / rexp),
            "weighted_chi_square_sum": weighted_loss,
            "reduced_weighted_chi_square": float(weighted_loss / dof),
            "observations": int(len(observed)),
            "independent_refined_parameters": int(n_parameters),
            "project_saved_rwp_percent": float(histogram.get_wR()),
            "phase_rf_percent": {
                phase.name: float(residuals[f"{phase.id}:0:Rf"])
                for phase in phases
            },
        },
        "calibration": {
            "zero_deg": float(replay["instrument"]["Zero"][1]),
            "polarization": float(replay["instrument"]["Polariz."][1]),
        },
        "profile_checks": {
            "fresh_gsas_forward_replay": True,
            "parameters_optimized_during_replay": int(replay["parameters_optimized"]),
            "complete_original_grid": True,
            "minimum_calculated_counts": float(np.min(calculated)),
            "minimum_background_counts": float(np.min(background)),
            "review_flags": replay["profile_review_flags"],
        },
        "project": {
            "path": PROJECT.name,
            "sha256": replay["project_sha256"],
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    print(json.dumps({
        "rwp_percent": rwp,
        "rp_percent": rp,
        "fractions": {row["name"]: row["weight_fraction"] for row in phase_rows},
        "minimum_calculated": float(np.min(calculated)),
        "minimum_background": float(np.min(background)),
        "project_sha256": replay["project_sha256"],
    }, indent=2))


if __name__ == "__main__":
    main()
