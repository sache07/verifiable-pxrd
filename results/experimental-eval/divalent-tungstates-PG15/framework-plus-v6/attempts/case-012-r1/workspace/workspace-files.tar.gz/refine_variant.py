#!/usr/bin/env python3
"""Apply controlled nuisance/profile variants to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def split_assignment(text: str):
    key, value = text.split("=", 1)
    return key, float(value)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--set-inst", action="append", default=[])
    parser.add_argument("--refine-inst", default="")
    parser.add_argument("--fix-inst", default="")
    parser.add_argument("--set-sample", action="append", default=[])
    parser.add_argument("--refine-sample", default="")
    parser.add_argument("--fix-sample", default="")
    parser.add_argument("--background-n", type=int)
    parser.add_argument("--background-type", choices=[
        "chebyschev-1", "Q^2 power series", "Q^-2 power series",
        "lin interpolate", "inv interpolate", "log interpolate",
    ])
    parser.add_argument("--size", action="append", default=[], help="phase_index=value or phase_index=off")
    parser.add_argument("--strain", action="append", default=[], help="phase_index=value or phase_index=off")
    parser.add_argument("--po", action="append", default=[], help="phase:h,k,l:ratio:refine(0/1)")
    parser.add_argument("--add-phase", action="append", default=[], help="cif_path,name,initial_weight_fraction")
    parser.add_argument("--passes", type=int, default=1)
    parser.add_argument("--cycles", type=int, default=16)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input))
    project.filename = str(args.output)
    histogram = project.histograms()[0]
    instrument = histogram.data["Instrument Parameters"][0]

    for spec in args.add_phase:
        path_text, name, fraction_text = spec.split(",", 2)
        fraction = float(fraction_text)
        if not 0 < fraction < 0.5:
            raise ValueError("initial added-phase fraction must lie between 0 and 0.5")
        old_mass_scale = sum(
            float(phase.data["General"]["Mass"] * phase.data["Histograms"][histogram.name]["Scale"][0])
            for phase in project.phases()
        )
        phase = project.add_phase(
            str(Path(path_text).resolve()), phasename=name,
            histograms=[histogram], fmthint="CIF",
        )
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"] = [
            old_mass_scale * fraction / ((1.0 - fraction) * float(phase.data["General"]["Mass"])),
            True,
        ]
        phase.setSampleProfile(histogram, "size", "isotropic", 0.20, LGmix=1.0)
        phase.setSampleProfile(histogram, "microstrain", "isotropic", 0.0, LGmix=0.0)
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
        hap["Extinction"] = [0.0, False]
        phase.set_refinements({"Cell": True})

    for assignment in args.set_inst:
        key, value = split_assignment(assignment)
        if key not in instrument:
            raise KeyError(f"unknown instrument parameter {key}")
        instrument[key][1] = value
    for key in filter(None, args.refine_inst.split(",")):
        instrument[key][2] = True
    for key in filter(None, args.fix_inst.split(",")):
        instrument[key][2] = False

    sample = histogram.data["Sample Parameters"]
    for assignment in args.set_sample:
        key, value = split_assignment(assignment)
        if key not in sample or not isinstance(sample[key], list):
            raise KeyError(f"unknown refinable sample parameter {key}")
        sample[key][0] = value
    for key in filter(None, args.refine_sample.split(",")):
        sample[key][1] = True
    for key in filter(None, args.fix_sample.split(",")):
        sample[key][1] = False

    if args.background_type is not None:
        n_coeff = args.background_n or histogram.data["Background"][0][2]
        x = np.asarray(histogram.data["data"][1][0], float)
        target = np.asarray(histogram.data["data"][1][4], float)
        if args.background_type == "chebyschev-1":
            t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
            basis = np.polynomial.chebyshev.chebvander(t, n_coeff - 1)
        elif "power series" in args.background_type:
            wave = float(instrument.get("Lam1", instrument.get("Lam"))[1])
            q = 4.0 * np.pi * np.sin(np.deg2rad(x / 2.0)) / wave
            cols = [np.ones_like(x)]
            term = np.ones_like(x)
            for index in range(n_coeff - 1):
                if "^-2" in args.background_type:
                    term = term * (index + 1) * q ** -2
                else:
                    term = term * q ** 2 / (index + 1)
                cols.append(term.copy())
            basis = np.column_stack(cols)
        else:
            if args.background_type == "lin interpolate":
                knots = np.linspace(x[0], x[-1], n_coeff)
            elif args.background_type == "inv interpolate":
                knots = 1.0 / np.linspace(1.0 / x[-1], 1.0 / x[0], n_coeff)
            else:
                knots = np.exp(np.linspace(np.log(x[0]), np.log(x[-1]), n_coeff))
            knots[0], knots[-1] = x[0], x[-1]
            coeffs = np.interp(knots, x, target).tolist()
            basis = None
        if basis is not None:
            coeffs = np.linalg.lstsq(basis, target, rcond=None)[0].tolist()
        histogram.set_refinements({
            "Background": {
                "type": args.background_type, "no. coeffs": n_coeff,
                "coeffs": coeffs, "refine": True,
            }
        })
    elif args.background_n is not None:
        histogram.set_refinements({
            "Background": {"no. coeffs": args.background_n, "refine": True}
        })

    phases = project.phases()
    for spec in args.size:
        index_text, value_text = spec.split("=", 1)
        phase = phases[int(index_text)]
        if value_text == "off":
            phase.setSampleProfile(histogram, "size", "isotropic", 1000.0, LGmix=1.0)
            phase.clear_HAP_refinements({"Size": True})
        else:
            phase.setSampleProfile(histogram, "size", "isotropic", float(value_text), LGmix=1.0)
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    for spec in args.strain:
        index_text, value_text = spec.split("=", 1)
        phase = phases[int(index_text)]
        if value_text == "off":
            phase.setSampleProfile(histogram, "microstrain", "isotropic", 0.0, LGmix=0.0)
            phase.clear_HAP_refinements({"Mustrain": True})
        else:
            phase.setSampleProfile(histogram, "microstrain", "isotropic", float(value_text), LGmix=0.0)
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})

    for spec in args.po:
        phase_text, axis_text, ratio_text, refine_text = spec.split(":")
        phase = phases[int(phase_text)]
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = float(ratio_text)
        hap["Pref.Ori."][2] = bool(int(refine_text))
        hap["Pref.Ori."][3] = [int(v) for v in axis_text.split(",")]

    project.set_Controls("cycles", args.cycles)
    project.save(str(args.output))
    for pass_index in range(args.passes):
        project.refine(makeBack=False)
        print(json.dumps({
            "pass": pass_index + 1,
            "wR_percent": project.histograms()[0].get_wR(),
            "residuals": project.histograms()[0].residuals,
        }, default=str))
    project.save(str(args.output))


if __name__ == "__main__":
    main()
