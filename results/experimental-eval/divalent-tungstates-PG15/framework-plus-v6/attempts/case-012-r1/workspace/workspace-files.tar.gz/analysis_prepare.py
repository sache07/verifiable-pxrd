#!/usr/bin/env python3
"""Prepare local candidate models and GSAS-II import files for this analysis."""

from pathlib import Path
import sys

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
MODEL_DIR = TMP / "candidates"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

sys.path.insert(0, str(ROOT / "learned/divalent-tungstates/runtime"))
from models import write_synthetic_model  # noqa: E402


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def read_structure(cod_id: str) -> Structure:
    parser = CifParser(
        cod_path(cod_id), occupancy_tolerance=1.0, site_tolerance=1e-5,
        frac_tolerance=0,
    )
    structure = parser.parse_structures(primitive=False, on_error="raise")[0]
    structure.remove_oxidation_states()
    return structure


def make_niwo4(cod_id: str, parent_element: str, name: str) -> None:
    structure = read_structure(cod_id)
    structure.replace_species({parent_element: "Ni"})
    # Peak-family indexing gives a near-orthogonal wolframite cell. This is
    # deliberately only an initial cell; GSAS-II refines it independently.
    lattice = Lattice.monoclinic(4.6000, 5.6600, 4.9100, 90.000)
    structure = Structure(
        lattice, structure.species, structure.frac_coords,
        site_properties=structure.site_properties,
    )
    write_synthetic_model(structure, MODEL_DIR / name)


def normalize_source(cod_id: str, name: str) -> None:
    write_synthetic_model(read_structure(cod_id), MODEL_DIR / name)


def main() -> None:
    MODEL_DIR.mkdir(parents=True, exist_ok=True)

    data = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    x, y = data.T
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(
        TMP / "pattern.xye", np.column_stack((x, y, sigma)),
        fmt=["%.8f", "%.8f", "%.8f"],
        header="2theta intensity sigma", comments="# ",
    )

    (TMP / "instrument.instprm").write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:5.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )

    make_niwo4("1520641", "Zn", "niwo4_from_zn1520641.cif")
    make_niwo4("1520200", "Mn", "niwo4_from_mn1520200.cif")
    make_niwo4("1520645", "Cd", "niwo4_from_cd1520645.cif")

    normalize_source("1528915", "wo3_1528915_p21c.cif")
    normalize_source("2311041", "wo3_2311041_p21c.cif")
    normalize_source("2106293", "wo3_2106293_p-1.cif")
    normalize_source("2107312", "wo3_2107312_pnma.cif")
    normalize_source("1010093", "nio_1010093.cif")


if __name__ == "__main__":
    main()
