#!/usr/bin/env python3
"""Build and stage a GSAS-II Rietveld refinement for candidate phases.

Run this script with the GSAS-II Python interpreter.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import traceback

import numpy as np
from scipy import ndimage
from GSASII import GSASIIscriptable as G2


def initial_background(x: np.ndarray, y: np.ndarray, degree: int = 5) -> list[float]:
    baseline = ndimage.percentile_filter(y, percentile=12, size=401, mode="nearest")
    baseline = ndimage.gaussian_filter1d(baseline, 80)
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, baseline, degree).tolist()


def set_neutral_hap(phase, histogram, initial_scale: float) -> None:
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"] = [float(initial_scale), False]
    phase.setSampleProfile(histogram, "size", "isotropic", 1000.0, LGmix=1.0)
    phase.setSampleProfile(histogram, "microstrain", "isotropic", 0.0, LGmix=0.0)
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]


def stage(project, label: str, log: list[dict]) -> None:
    project.refine(makeBack=False)
    histogram = project.histograms()[0]
    entry = {
        "stage": label,
        "wR_percent": histogram.get_wR(),
        "residuals": histogram.residuals,
    }
    try:
        shifts, sigmas = project.get_LastFitResults()
        entry["max_shift_over_sigma"] = max(
            (abs(float(shifts[k]) / float(sigmas[k])) for k in shifts if sigmas.get(k)),
            default=0.0,
        )
    except Exception as exc:
        entry["last_fit_error"] = str(exc)
    log.append(entry)
    print(json.dumps(entry, default=str))


def summarize(project, log: list[dict], output: Path) -> dict:
    histogram = project.histograms()[0]
    inst = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    phase_rows = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        phase_rows.append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "mass": phase.data["General"]["Mass"],
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        })
    total = sum(masses)
    for row, value in zip(phase_rows, masses):
        row["weight_fraction"] = value / total if total > 0 else None
    result = {
        "project": str(output),
        "histogram": histogram.name,
        "wR_percent": histogram.get_wR(),
        "residuals": histogram.residuals,
        "instrument": {key: value for key, value in inst.items()},
        "sample": sample,
        "background": histogram.data["Background"],
        "phases": phase_rows,
        "stages": log,
        "vary_list": project.get_VaryList(),
    }
    output.with_suffix(".summary.json").write_text(
        json.dumps(result, indent=2, default=lambda obj: obj.tolist() if hasattr(obj, "tolist") else str(obj)) + "\n"
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("cifs", type=Path, nargs="+")
    parser.add_argument("--names", nargs="+")
    parser.add_argument("--profile", choices=["neutral", "size", "strain", "size-strain"], default="size-strain")
    parser.add_argument("--atoms", choices=["none", "heavy", "all", "selective"], default="none")
    parser.add_argument("--background", type=int, default=6)
    parser.add_argument("--no-asymmetry", action="store_true")
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(args.output))
    names = args.names or [path.stem for path in args.cifs]
    if len(names) != len(args.cifs):
        raise ValueError("--names must have one value per CIF")
    phases = [
        project.add_phase(str(path.resolve()), phasename=name, fmthint="CIF")
        for path, name in zip(args.cifs, names)
    ]
    histogram = project.add_powder_histogram(
        str(Path(".tmp/pattern.xye").resolve()),
        str(Path(".tmp/instrument.instprm").resolve()),
        phases=phases,
        fmthint="xye",
    )
    histogram.set_refinements({"Limits": [10.00943322, 99.99442286]})
    histogram.SampleParameters["Type"] = "Bragg-Brentano"
    histogram.SampleParameters["Gonio. radius"] = 200.0
    for key, value in [("Shift", 0.0), ("Transparency", 0.0), ("SurfRoughA", 0.0), ("SurfRoughB", 0.0)]:
        histogram.SampleParameters[key] = [value, False]
    histogram.SampleParameters["Scale"] = [1.0, False]

    x = np.asarray(histogram.data["data"][1][0], float)
    y = np.asarray(histogram.data["data"][1][1], float)
    coeffs = initial_background(x, y, args.background - 1)
    histogram.set_refinements({
        "Background": {
            "type": "chebyschev-1", "no. coeffs": args.background,
            "coeffs": coeffs, "refine": False,
        }
    })

    # The common multiplier is arbitrary; relative mass scales start near 70:30.
    nominal = [0.70, 0.30] if len(phases) == 2 else np.ones(len(phases)) / len(phases)
    for phase, fraction in zip(phases, nominal):
        mass = float(phase.data["General"]["Mass"])
        set_neutral_hap(phase, histogram, 10000.0 * float(fraction) / mass)

    project.set_Controls("cycles", 12)
    project.save()
    log: list[dict] = []

    # Inventory comparison uses the same restrained nuisance sequence for every model.
    histogram.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    stage(project, "background_scales", log)

    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    stage(project, "zero_cells", log)

    histogram.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    stage(project, "common_UWX", log)

    if not args.no_asymmetry:
        histogram.set_refinements({"Instrument Parameters": ["SH/L"]})
        stage(project, "common_asymmetry", log)

    if args.profile in ("size", "size-strain"):
        for phase in phases:
            phase.setSampleProfile(histogram, "size", "isotropic", 0.30, LGmix=1.0)
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        stage(project, "phase_size", log)

    if args.profile in ("strain", "size-strain"):
        for phase in phases:
            phase.setSampleProfile(histogram, "microstrain", "isotropic", 1000.0, LGmix=0.0)
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        stage(project, "phase_strain", log)

    if args.atoms != "none":
        for phase in phases:
            flags = {}
            for atom in phase.atoms():
                element = atom.element
                include_oxygen = args.atoms == "all" or (args.atoms == "selective" and phase is phases[0])
                if include_oxygen or element != "O":
                    flags[atom.label] = "X"
            if flags:
                phase.set_refinements({"Atoms": flags})
        stage(project, f"atoms_{args.atoms}", log)

    project.save(str(args.output))
    result = summarize(project, log, args.output)
    print(json.dumps({
        "output": str(args.output), "wR_percent": result["wR_percent"],
        "phases": [{"name": row["name"], "weight_fraction": row["weight_fraction"]} for row in result["phases"]],
    }, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        raise
