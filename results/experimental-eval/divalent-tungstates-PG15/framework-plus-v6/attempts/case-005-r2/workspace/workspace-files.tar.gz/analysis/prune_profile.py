#!/usr/bin/env python3
"""Prune phase size or strain while replaying the accepted common model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project):
    h = project.histogram(0)
    x, y, w, yc, bg, d = map(np.asarray, h.data["data"][1][:6])
    m = (x >= h.data["Limits"][1][0]) & (x <= h.data["Limits"][1][1])
    return float(100 * np.sqrt(np.sum(w[m] * d[m] ** 2) / np.sum(w[m] * y[m] ** 2)))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("parent", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("phase", choices=["WO3", "Co3O4"])
    p.add_argument("model", choices=["size", "strain", "both"])
    p.add_argument("--cycles", type=int, default=20)
    p.add_argument("--passes", type=int, default=3)
    a = p.parse_args()

    G2.SetPrintLevel("warn")
    g = G2.G2Project(str(a.parent.resolve()), newgpx=str(a.output.resolve()))
    g.save(); g.set_Frozen(); g.set_Controls("cycles", a.cycles)
    h = g.histogram(0)
    for ph in g.phases():
        for atom in ph.atoms(): atom.refinement_flags = " "
        if ph.name != a.phase: continue
        hap = ph.data["Histograms"][h.name]
        if a.model not in ["size", "both"]:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = hap["Size"][1][1] = 1000.0
            hap["Size"][2] = [False, False, False]
        if a.model not in ["strain", "both"]:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = 0.0
            hap["Mustrain"][2] = [False, False, False]
    history=[]
    for i in range(a.passes):
        g.refine(makeBack=False)
        hap=g.phase(a.phase).data["Histograms"][h.name]
        history.append({"pass":i+1,"rwp_percent":rwp(g),
            "size":float(hap["Size"][1][0]),
            "strain_type":hap["Mustrain"][0],
            "strain":list(map(float,hap["Mustrain"][1][:2])),
            "frozen":g.get_Frozen()})
    g.save()
    out={"phase":a.phase,"model":a.model,"history":history,"final":history[-1]}
    a.output.with_suffix('.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
    print(json.dumps(out["final"],indent=2))


if __name__ == "__main__": main()
