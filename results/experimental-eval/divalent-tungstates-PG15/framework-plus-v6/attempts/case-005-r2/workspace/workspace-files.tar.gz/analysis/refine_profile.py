#!/usr/bin/env python3
"""Compare restrained phase-size and microstrain models in GSAS-II."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def snapshot(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    x, obs, weight, calc, background, difference = map(
        np.asarray, hist.data["data"][1][:6]
    )
    mask = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    rwp = 100 * np.sqrt(
        np.sum(weight[mask] * difference[mask] ** 2)
        / np.sum(weight[mask] * obs[mask] ** 2)
    )
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": copy.deepcopy(hap["Scale"]),
            "size": copy.deepcopy(hap["Size"]),
            "microstrain": copy.deepcopy(hap["Mustrain"]),
        }
    try:
        fractions = {
            k: list(map(float, v)) for k, v in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": repr(exc)}
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "rwp_percent": float(rwp),
        "gsas_rwp_percent": hist.get_wR(),
        "instrument": copy.deepcopy(hist.InstrumentParameters),
        "sample": copy.deepcopy(hist.SampleParameters),
        "background": copy.deepcopy(hist.Background),
        "phases": phases,
        "mass_fractions": fractions,
        "vary_list": list(map(str, covariance.get("varyList", []))),
        "variables": list(map(float, covariance.get("variables", []))),
        "frozen": project.get_Frozen(),
    }


def selected(mode: str, name: str) -> bool:
    return mode == "both" or mode.lower() == name.lower()


def set_limit(project, variable, lo, hi):
    project.set_Controls("parmMin", lo, variable=variable)
    project.set_Controls("parmMax", hi, variable=variable)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("parent", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--size", choices=["none", "WO3", "Co3O4", "both"],
                        default="none")
    parser.add_argument("--strain", choices=["none", "WO3", "Co3O4", "both"],
                        default="none")
    parser.add_argument("--size-start", type=float, default=0.2)
    parser.add_argument("--strain-start", type=float, default=1000.0)
    parser.add_argument("--passes", type=int, default=3)
    parser.add_argument("--cycles", type=int, default=15)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(args.parent.resolve()),
                           newgpx=str(args.output.resolve()))
    project.save()
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histogram(0)

    # Restore the unknown common instrument to an interior physical starting
    # point before phase-specific broadening is compared.
    for key, value in {"U": 10.0, "W": 10.0, "X": 1.0, "SH/L": 0.03}.items():
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = True
    hist.InstrumentParameters["V"][1:] = [0.0, False]
    hist.InstrumentParameters["Y"][1:] = [0.0, False]
    hist.InstrumentParameters["Z"][1:] = [0.0, False]
    hist.SampleParameters["Shift"][1] = True
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        use_size = selected(args.size, phase.name)
        use_strain = selected(args.strain, phase.name)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = args.size_start if use_size else 1000.0
        hap["Size"][1][1] = hap["Size"][1][0]
        hap["Size"][2] = [use_size, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = args.strain_start if use_strain else 0.0
        hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
        hap["Mustrain"][2] = [use_strain, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    # Bounds are the physically sampled lab envelope, with neutral zero strain.
    for var, lo, hi in [
        (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0), (":0:SH/L", 0.005, 0.1),
        (":0:Shift", -800.0, 800.0),
    ]:
        set_limit(project, var, lo, hi)
    for phase in project.phases():
        p = phase.id
        if selected(args.size, phase.name):
            set_limit(project, f"{p}:0:Size;i", 0.04, 1.5)
        if selected(args.strain, phase.name):
            set_limit(project, f"{p}:0:Mustrain;i", 0.0, 8000.0)

    history = []
    for index in range(args.passes):
        project.refine(makeBack=False)
        history.append({"pass": index + 1, **snapshot(project)})
        # A parameter can transiently cross a limit and be frozen. Keep that
        # fact visible, but do not silently continue optimizing a bound result.
        if project.get_Frozen():
            break
    project.save()
    result = {
        "parent": str(args.parent),
        "project": str(args.output),
        "size_model": args.size,
        "strain_model": args.strain,
        "history": history,
        "final": snapshot(project),
    }
    args.output.with_suffix(".json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    final = result["final"]
    print(json.dumps({
        "project": str(args.output),
        "size": args.size,
        "strain": args.strain,
        "rwp": final["rwp_percent"],
        "instrument": {k: v[1] for k, v in final["instrument"].items()
                       if k in ["U", "W", "X", "SH/L"]},
        "shift": final["sample"]["Shift"][0],
        "phase_profiles": {k: {"size": v["size"][1][0],
                                "strain": v["microstrain"][1][0]}
                           for k, v in final["phases"].items()},
        "fractions": final["mass_fractions"],
        "frozen": final["frozen"],
    }, indent=2))


if __name__ == "__main__":
    main()
