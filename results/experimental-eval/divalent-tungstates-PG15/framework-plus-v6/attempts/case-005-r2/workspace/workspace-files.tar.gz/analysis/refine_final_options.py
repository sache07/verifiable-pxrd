#!/usr/bin/env python3
"""Replay conservative final-model options without changing the parent GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def set_limit(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def snapshot(project):
    hist = project.histogram(0)
    x, obs, weight, calc, background, difference = map(
        np.asarray, hist.data["data"][1][:6]
    )
    use = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    chisq = float(np.sum(weight[use] * difference[use] ** 2))
    rwp = float(100 * np.sqrt(chisq / np.sum(weight[use] * obs[use] ** 2)))
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    mass = hist.ComputeMassFracs()
    windows = {}
    for low, high in [(10, 12), (23, 25), (33, 35), (50, 51), (90, 100)]:
        mask = use & (x >= low) & (x < high)
        windows[f"{low}-{high}"] = {
            "chisq": float(np.sum(weight[mask] * difference[mask] ** 2)),
            "mean_difference": float(np.mean(difference[mask])),
        }
    return {
        "rwp_percent": rwp,
        "chi_square": chisq,
        "nobs": int(np.count_nonzero(use)),
        "nvars": int(rvals.get("Nvars", len(covariance.get("varyList", [])))),
        "gof": float(rvals.get("GOF", np.nan)),
        "background": list(map(float, hist.Background[0][3:])),
        "background_terms": int(hist.Background[0][2]),
        "calculated_background_min": float(np.min(background[use])),
        "calculated_background_max": float(np.max(background[use])),
        "residual_windows": windows,
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "instrument_profile": {key: float(hist.InstrumentParameters[key][1])
                               for key in ["U", "V", "W", "X", "Y", "Z", "SH/L"]},
        "shift_micrometers": float(hist.SampleParameters["Shift"][0]),
        "fractions": {name: [float(value), float(sigma)]
                      for name, (value, sigma) in mass.items()},
        "uiso": {phase.name: [float(atom.uiso) for atom in phase.atoms()]
                 for phase in project.phases()},
        "phase_profile": {
            phase.name: {
                "size_type": phase.data["Histograms"][hist.name]["Size"][0],
                "size": list(map(float, phase.data["Histograms"][hist.name]["Size"][1])),
                "strain_type": phase.data["Histograms"][hist.name]["Mustrain"][0],
                "strain": list(map(float, phase.data["Histograms"][hist.name]["Mustrain"][1])),
            } for phase in project.phases()
        },
        "atom_flags": {phase.name: [atom.refinement_flags for atom in phase.atoms()]
                       for phase in project.phases()},
        "frozen": list(map(str, project.get_Frozen())),
        "vary_list": list(map(str, covariance.get("varyList", []))),
        "message": str(rvals.get("msg", "")),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("parent", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--background-terms", type=int)
    parser.add_argument("--background-type", choices=[
        "chebyschev-1", "Q^2 power series", "Q^-2 power series",
        "lin interpolate", "inv interpolate", "log interpolate",
    ])
    parser.add_argument("--uiso", choices=["none", "WO3", "Co3O4", "both"],
                        default="none")
    parser.add_argument("--coordinate-source", type=Path)
    parser.add_argument("--coordinate-model",
                        choices=["preserve", "none", "WO3-W", "Co3O4-O", "both"],
                        default="preserve")
    parser.add_argument("--passes", type=int, default=3)
    parser.add_argument("--cycles", type=int, default=20)
    parser.add_argument("--fixed-u", type=float,
                        help="set and hold the common Gaussian U term")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.parent.resolve()),
                           newgpx=str(args.output.resolve()))
    project.save()
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histogram(0)

    if args.fixed_u is not None:
        hist.InstrumentParameters["U"][1] = args.fixed_u
        hist.InstrumentParameters["U"][2] = False

    if args.coordinate_source is not None:
        source = G2.G2Project(str(args.coordinate_source.resolve()))
        for phase in project.phases():
            source_phase = source.phase(phase.name)
            source_atoms = source_phase.atoms()
            atoms = phase.atoms()
            if len(atoms) != len(source_atoms):
                raise ValueError(f"Atom-count mismatch for {phase.name}")
            for atom, source_atom in zip(atoms, source_atoms):
                if atom.element != source_atom.element:
                    raise ValueError(f"Atom-order mismatch for {phase.name}")
                atom.coordinates = source_atom.coordinates
                atom.refinement_flags = " "
                if args.coordinate_model in ("both", "WO3-W"):
                    if phase.name == "WO3" and atom.element == "W":
                        atom.refinement_flags = "X"
                if args.coordinate_model in ("both", "Co3O4-O"):
                    if phase.name == "Co3O4" and atom.element == "O":
                        atom.refinement_flags = "X"

    if args.background_terms is not None:
        count = args.background_terms
        old = list(hist.Background[0][3:])
        kind = args.background_type or hist.Background[0][0]
        if kind == hist.Background[0][0]:
            coeffs = old[:count] + [0.0] * max(0, count - len(old))
        elif kind in ("lin interpolate", "inv interpolate", "log interpolate"):
            coeffs = [old[0]] * count
        else:
            coeffs = [old[0]] + [0.0] * (count - 1)
        hist.Background[0] = [kind, True, count] + coeffs

    if args.uiso != "none":
        for phase in project.phases():
            if args.uiso not in ("both", phase.name):
                continue
            variables = []
            for index, atom in enumerate(phase.atoms()):
                atom.refinement_flags = "".join(
                    flag for flag in "XU" if flag in (atom.refinement_flags + "U")
                )
                variable = f"{phase.id}::AUiso:{index}"
                variables.append(variable)
                set_limit(project, variable, 0.003, 0.02)
            if len(variables) > 1:
                project.add_EquivConstr(variables)

    history = []
    for index in range(args.passes):
        project.refine(makeBack=False)
        history.append({"pass": index + 1, **snapshot(project)})
        if project.get_Frozen():
            break
    project.save()
    result = {
        "parent": str(args.parent),
        "project": str(args.output),
        "uiso_model": args.uiso,
        "history": history,
        "final": snapshot(project),
    }
    args.output.with_suffix(".json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(result["final"], indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
