#!/usr/bin/env python3
"""Use the independently regenerated final.gpx curve for public fit outputs."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]


def main():
    with np.load(ROOT / "analysis/replay-direct/prediction.npz") as replay:
        x = replay["x"]
        observed = replay["observed"]
        calculated = replay["predicted"]
    public = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    if not np.array_equal(x, public[:, 0]) or not np.array_equal(observed, public[:, 1]):
        raise ValueError("Independent replay grid or observations differ from input")

    difference = observed - calculated
    weight = 1 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weight * difference ** 2))
    denominator = float(np.sum(weight * observed ** 2))

    result_path = ROOT / "result.json"
    result = json.loads(result_path.read_text())
    stats = result["fit_statistics"]
    npoints = len(x)
    nvars = int(stats["n_refined_variables"])
    dof = npoints - nvars
    stats.update({
        "rwp_percent": float(100 * np.sqrt(chi_square / denominator)),
        "rp_percent": float(100 * np.sum(np.abs(difference)) / np.sum(observed)),
        "expected_rwp_percent": float(100 * np.sqrt(npoints / denominator)),
        "chi_square": chi_square,
        "reduced_chi_square": float(chi_square / dof),
        "goodness_of_fit": float(np.sqrt(chi_square / dof)),
        "n_points": npoints,
        "degrees_of_freedom": dof,
    })
    result_path.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    with (ROOT / "inputs/pattern.csv").open(newline="") as source:
        source_rows = list(csv.reader(source))
    if len(source_rows) != npoints + 1:
        raise ValueError("Unexpected input row count")
    with (ROOT / "fit.csv").open("w", newline="") as destination:
        writer = csv.writer(destination, lineterminator="\n")
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        for source_row, calc, diff in zip(source_rows[1:], calculated, difference):
            writer.writerow([source_row[0], source_row[1], f"{calc:.10f}", f"{diff:.10f}"])
    print(json.dumps(stats, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
