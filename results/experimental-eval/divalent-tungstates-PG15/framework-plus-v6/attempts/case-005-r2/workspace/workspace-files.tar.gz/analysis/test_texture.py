#!/usr/bin/env python3
"""Test one symmetry-distinct March-Dollase axis on a converged project."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project):
    hist = project.histogram(0)
    x, obs, weight, calc, background, diff = map(
        np.asarray, hist.data["data"][1][:6]
    )
    mask = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    return float(100 * np.sqrt(np.sum(weight[mask] * diff[mask] ** 2)
                               / np.sum(weight[mask] * obs[mask] ** 2)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("parent", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", choices=["WO3", "Co3O4"])
    parser.add_argument("axis", help="comma-separated h,k,l")
    parser.add_argument("--cycles", type=int, default=15)
    parser.add_argument("--passes", type=int, default=2)
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]
    if len(axis) != 3 or not any(axis):
        raise ValueError("axis must be a nonzero h,k,l triple")

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.parent.resolve()),
                           newgpx=str(args.output.resolve()))
    project.save()
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histogram(0)
    # Prune terms already shown to be non-identifiable with phase size or shift.
    for key in ["U", "X", "SH/L"]:
        hist.InstrumentParameters[key][2] = False
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = phase.name == args.phase
        hap["Pref.Ori."][3] = axis if phase.name == args.phase else [0, 0, 1]
    target = project.phase(args.phase)
    project.set_Controls("parmMin", 0.7,
                         variable=f"{target.id}:0:MD")
    project.set_Controls("parmMax", 1.4,
                         variable=f"{target.id}:0:MD")

    history = []
    for index in range(args.passes):
        project.refine(makeBack=False)
        target_hap = project.phase(args.phase).data["Histograms"][hist.name]
        history.append({
            "pass": index + 1,
            "rwp_percent": rwp(project),
            "ratio": float(target_hap["Pref.Ori."][1]),
            "frozen": project.get_Frozen(),
        })
    project.save()
    result = {
        "parent": str(args.parent), "project": str(args.output),
        "phase": args.phase, "axis": axis, "history": history,
        "final": history[-1],
        "fractions": {k: list(map(float, v)) for k, v in
                      hist.ComputeMassFracs().items()},
        "instrument": copy.deepcopy(hist.InstrumentParameters),
    }
    args.output.with_suffix(".json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(result["final"]))


if __name__ == "__main__":
    main()
