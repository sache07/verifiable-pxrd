#!/usr/bin/env python3
"""Run a restrained common-profile GSAS-II trial for candidate phases."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
CANDIDATES = ROOT / "analysis/candidates"


def metrics(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    x, obs, weight, calc, background, difference = map(np.asarray, arrays[:6])
    mask = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    num = float(np.sum(weight[mask] * difference[mask] ** 2))
    den = float(np.sum(weight[mask] * obs[mask] ** 2))
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "mass_amu_cell": float(phase.data["General"]["Mass"]),
            "scale": float(hap["Scale"][0]),
            "size": hap["Size"],
            "microstrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    try:
        mass_fractions = {
            k: [float(v[0]), float(v[1])] for k, v in
            hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        mass_fractions = {"error": repr(exc)}
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "stage": label,
        "rwp_percent_independent": 100.0 * np.sqrt(num / den),
        "rwp_percent_gsas": hist.get_wR(),
        "residuals": hist.residuals,
        "limits": list(map(float, hist.data["Limits"][1])),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": phases,
        "mass_fractions": mass_fractions,
        "vary_list": list(map(str, covariance.get("varyList", []))),
        "variables": [float(v) for v in covariance.get("variables", [])],
        "sigmas": [float(v) for v in covariance.get("sig", [])],
    }


def set_neutral_hap(phase, histogram, scale: float) -> None:
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"] = [float(scale), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][1][1] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", required=True)
    parser.add_argument("--co3o4", default="co3o4_9005896")
    parser.add_argument("--cowo4")
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--background-terms", type=int, default=6)
    parser.add_argument("--start-shift", type=float, default=-600.0)
    parser.add_argument("--cycles", type=int, default=12)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(args.out.resolve()))
    hist = project.add_powder_histogram(
        str(ROOT / "analysis/pattern.xye"),
        str(ROOT / "analysis/instrument.instprm"),
        fmthint="xye",
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [args.start_shift, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    specs = [
        ("WO3", args.wo3, 8.0),
        ("Co3O4", args.co3o4, 2.5),
    ]
    if args.cowo4:
        specs.append(("CoWO4", args.cowo4, 0.1))
    for name, candidate, scale in specs:
        phase = project.add_phase(
            str(CANDIDATES / f"{candidate}.cif"), phasename=name,
            histograms=[hist], fmthint="CIF",
        )
        set_neutral_hap(phase, hist, scale)

    coeffs = [3000.0] + [0.0] * (args.background_terms - 1)
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": args.background_terms,
            "coeffs": coeffs,
            "refine": True,
        }
    })
    project.set_Controls("cycles", args.cycles)
    history = []

    # Refit the smooth background and all scales before introducing geometry.
    project.refine()
    history.append(metrics(project, "background_scales"))

    # One physically appropriate Bragg-Brentano angular correction plus cells.
    hist = project.histogram(0)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine()
    history.append(metrics(project, "shift_cells"))

    # Nonnegative common Gaussian/Lorentzian Caglioti terms. V and Y/Z stay 0.
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine()
    history.append(metrics(project, "common_uwx"))

    # Release axial divergence only after the common width model is fitted.
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.refine()
    history.append(metrics(project, "common_uwx_shl"))

    project.save(str(args.out.resolve()))
    summary = {
        "project": str(args.out),
        "candidates": {
            "WO3": args.wo3,
            "Co3O4": args.co3o4,
            **({"CoWO4": args.cowo4} if args.cowo4 else {}),
        },
        "history": history,
        "final": metrics(project, "final"),
    }
    args.out.with_suffix(".json").write_text(
        json.dumps(summary, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps({
        "project": str(args.out),
        "rwp": summary["final"]["rwp_percent_independent"],
        "mass_fractions": summary["final"]["mass_fractions"],
        "cells": {k: v["cell"] for k, v in
                  summary["final"]["phases"].items()},
        "instrument": {k: v[1] for k, v in
                       summary["final"]["instrument"].items()
                       if isinstance(v, list) and len(v) > 2},
        "shift": summary["final"]["sample"]["Shift"][0],
    }, indent=2))


if __name__ == "__main__":
    main()
