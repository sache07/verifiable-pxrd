#!/usr/bin/env python3
"""Refine symmetry-allowed coordinates after profile convergence."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def snapshot(project):
    hist = project.histogram(0)
    x, obs, weight, calc, background, diff = map(
        np.asarray, hist.data["data"][1][:6]
    )
    mask = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    rwp = 100 * np.sqrt(np.sum(weight[mask] * diff[mask] ** 2)
                        / np.sum(weight[mask] * obs[mask] ** 2))
    phases = {}
    for phase in project.phases():
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "atoms": [{
                "label": atom.label,
                "element": atom.element,
                "xyz": list(map(float, atom.coordinates)),
                "flags": atom.refinement_flags,
                "uiso": float(atom.uiso),
            } for atom in phase.atoms()],
        }
    return {
        "rwp_percent": float(rwp),
        "instrument": copy.deepcopy(hist.InstrumentParameters),
        "sample": copy.deepcopy(hist.SampleParameters),
        "phases": phases,
        "frozen": project.get_Frozen(),
        "vary_list": list(map(str, project.data.get("Covariance", {})
                              .get("data", {}).get("varyList", []))),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("parent", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=20)
    parser.add_argument("--passes", type=int, default=2)
    parser.add_argument("--oxygen", action="store_true",
                        help="also refine WO3 oxygen coordinates")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.parent.resolve()),
                           newgpx=str(args.output.resolve()))
    project.save()
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histogram(0)
    # U reached the broad lab-envelope edge in the exploratory simultaneous
    # fit; hold it while coordinates are tested so it cannot absorb intensity
    # or family-dependent residuals.
    hist.InstrumentParameters["U"][2] = False

    for phase in project.phases():
        for atom in phase.atoms():
            if phase.name == "WO3":
                atom.refinement_flags = "X" if (atom.element == "W" or args.oxygen) else " "
            elif phase.name == "Co3O4":
                atom.refinement_flags = "X" if atom.element == "O" else " "
            else:
                atom.refinement_flags = " "

    history = []
    for index in range(args.passes):
        project.refine(makeBack=False)
        history.append({"pass": index + 1, **snapshot(project)})
    project.save()
    result = {
        "parent": str(args.parent),
        "project": str(args.output),
        "wo3_oxygen_refined": args.oxygen,
        "history": history,
        "final": snapshot(project),
    }
    args.output.with_suffix(".json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps({
        "project": str(args.output),
        "oxygen": args.oxygen,
        "rwp": result["final"]["rwp_percent"],
        "frozen": result["final"]["frozen"],
        "atoms": result["final"]["phases"],
    }, indent=2))


if __name__ == "__main__":
    main()
