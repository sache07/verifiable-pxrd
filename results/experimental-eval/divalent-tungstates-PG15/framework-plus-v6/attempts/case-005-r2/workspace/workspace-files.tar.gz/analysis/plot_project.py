#!/usr/bin/env python3
"""Plot a GSAS-II profile and residual for diagnostic inspection."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    project = G2.G2Project(str(args.project))
    x, obs, weight, calc, background, diff = map(
        np.asarray, project.histogram(0).data["data"][1][:6]
    )
    ranges = [(9.9, 100.1), (14, 40), (40, 70), (70, 100.1)]
    fig, axes = plt.subplots(4, 1, figsize=(15, 13), constrained_layout=True)
    for axis, (lo, hi) in zip(axes, ranges):
        mask = (x >= lo) & (x <= hi)
        offset = -0.16 * (obs[mask].max() - obs[mask].min())
        axis.plot(x[mask], obs[mask], color="black", lw=0.75, label="observed")
        axis.plot(x[mask], calc[mask], color="#d62728", lw=0.75,
                  label="calculated")
        axis.plot(x[mask], background[mask], color="#2ca02c", lw=0.65,
                  label="background")
        axis.plot(x[mask], diff[mask] + offset, color="#1f77b4", lw=0.65,
                  label="difference (offset)")
        axis.axhline(offset, color="gray", lw=0.4)
        axis.set_xlim(lo, hi)
        axis.set_ylabel("counts")
    axes[0].legend(ncol=4, fontsize=9)
    axes[-1].set_xlabel(r"$2\theta$ (degrees)")
    fig.suptitle(args.project.name)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=150)


if __name__ == "__main__":
    main()
