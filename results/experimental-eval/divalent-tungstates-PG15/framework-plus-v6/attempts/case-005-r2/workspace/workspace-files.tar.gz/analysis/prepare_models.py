#!/usr/bin/env python3
"""Prepare GSAS-II inputs and physically screened COD-derived candidates."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from pymatgen.io.cif import CifParser
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(__file__).resolve().parents[1]
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
RUNTIME = ROOT / "learned/divalent-tungstates/runtime"
sys.path.insert(0, str(RUNTIME))

from models import write_synthetic_model  # noqa: E402
from gsas_worker_text import instrument_text  # noqa: E402


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def read_structure(cod_id: str):
    parser = CifParser(
        cod_path(cod_id), occupancy_tolerance=1.0, site_tolerance=1e-5,
        frac_tolerance=0,
    )
    structure = parser.parse_structures(primitive=False, on_error="raise")[0]
    structure.remove_oxidation_states()
    return structure


def physical_summary(structure):
    distances = structure.distance_matrix.copy()
    np.fill_diagonal(distances, np.inf)
    analyzer = SpacegroupAnalyzer(structure, symprec=0.001)
    return {
        "formula": structure.composition.reduced_formula,
        "composition": structure.composition.get_el_amt_dict(),
        "space_group": analyzer.get_space_group_symbol(),
        "space_group_number": analyzer.get_space_group_number(),
        "cell": list(structure.lattice.parameters),
        "density_g_cm3": float(structure.density),
        "minimum_separation_A": float(distances.min()),
        "sites": len(structure),
    }


def main() -> None:
    out = ROOT / "analysis"
    candidates = out / "candidates"
    candidates.mkdir(parents=True, exist_ok=True)

    # These are source candidates, not asserted phases. Registration-style
    # normalization matches the synthetic framework convention (neutral atoms,
    # detected symmetry, Uiso = 0.005 A^2).
    source_ids = {
        "wo3_1528915": "1528915",  # monoclinic room-temperature WO3
        "wo3_2311041": "2311041",  # alternate monoclinic setting/model
        "wo3_2106293": "2106293",  # triclinic room-temperature WO3
        "wo3_1010618": "1010618",  # higher-symmetry historic model
        "co3o4_9005896": "9005896",  # room-temperature normal spinel
        "co3o4_5910031": "5910031",  # alternate spinel record
    }
    records = {}
    for name, cod_id in source_ids.items():
        structure = read_structure(cod_id)
        path = candidates / f"{name}.cif"
        write_synthetic_model(structure, path)
        records[name] = {
            "path": str(path.relative_to(ROOT)),
            "basis": "published",
            "cod_id": cod_id,
            **physical_summary(structure),
        }

    # CoWO4 is tested from reliable wolframite analogues because the one exact
    # indexed COD record is an internally duplicated historic CIF.
    analogues = {
        "cowo4_from_zn_1520641": ("1520641", {"Zn": "Co"}),
        "cowo4_from_fe_1567215": ("1567215", {"Fe": "Co"}),
        "cowo4_from_mn_1520200": ("1520200", {"Mn": "Co"}),
        "cowo4_from_comoo4_7205001": ("7205001", {"Mo": "W"}),
    }
    for name, (cod_id, substitutions) in analogues.items():
        structure = read_structure(cod_id)
        structure.replace_species(substitutions)
        path = candidates / f"{name}.cif"
        write_synthetic_model(structure, path)
        records[name] = {
            "path": str(path.relative_to(ROOT)),
            "basis": "analogue_derived",
            "parent_cod_id": cod_id,
            "substitution": substitutions,
            **physical_summary(structure),
        }

    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1,
                      unpack=True)
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(out / "pattern.xye", np.column_stack((x, y, sigma)),
               fmt=["%.8f", "%.8f", "%.8f"])

    instrument = {
        "wavelength_ka1_A": 1.540598,
        "wavelength_ka2_A": 1.544426,
        "ka2_ka1_ratio": 0.5,
        "zero_deg": 0.0,
        "polarization": 0.75,
        "U": 10.0,
        "V": 0.0,
        "W": 10.0,
        "X": 1.0,
        "SH_L": 0.03,
    }
    (out / "instrument.instprm").write_text(instrument_text(instrument))
    (out / "candidate_inventory.json").write_text(
        json.dumps(records, indent=2, sort_keys=True) + "\n"
    )


if __name__ == "__main__":
    main()
