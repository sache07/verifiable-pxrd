#!/usr/bin/env python3
"""Test restrained polarization, surface roughness and phase-common Uiso."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project):
    hist = project.histogram(0)
    x, obs, weight, calc, background, diff = map(
        np.asarray, hist.data["data"][1][:6]
    )
    mask = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    return float(100 * np.sqrt(np.sum(weight[mask] * diff[mask] ** 2)
                               / np.sum(weight[mask] * obs[mask] ** 2)))


def limit(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("parent", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--rough-a-start", type=float, default=0.3)
    parser.add_argument("--rough-b-start", type=float, default=0.1)
    parser.add_argument("--rough-a-min", type=float, default=0.0)
    parser.add_argument("--rough-a-max", type=float, default=1.0)
    parser.add_argument("--rough-b-min", type=float, default=0.0)
    parser.add_argument("--rough-b-max", type=float, default=1.0)
    parser.add_argument("--uiso", choices=["none", "WO3", "Co3O4", "both"],
                        default="none")
    parser.add_argument("--cycles", type=int, default=20)
    parser.add_argument("--passes", type=int, default=3)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.parent.resolve()),
                           newgpx=str(args.output.resolve()))
    project.save()
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histogram(0)
    for key in ["U", "X", "SH/L"]:
        hist.InstrumentParameters[key][2] = False
    hist.InstrumentParameters["Polariz."][2] = args.polarization
    if args.polarization:
        limit(project, ":0:Polariz.", 0.5, 1.0)

    hist.SampleParameters["SurfRoughA"] = [args.rough_a_start if args.roughness else 0.0,
                                             args.roughness]
    hist.SampleParameters["SurfRoughB"] = [args.rough_b_start if args.roughness else 0.0,
                                             args.roughness]
    if args.roughness:
        limit(project, ":0:SurfRoughA", args.rough_a_min, args.rough_a_max)
        limit(project, ":0:SurfRoughB", args.rough_b_min, args.rough_b_max)

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        refine_u = args.uiso == "both" or args.uiso == phase.name
        uvars = []
        for index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U" if refine_u else " "
            if refine_u:
                uvars.append(f"{phase.id}::AUiso:{index}")
        if len(uvars) > 1:
            project.add_EquivConstr(uvars)
            for variable in uvars:
                limit(project, variable, 0.003, 0.02)

    history = []
    for index in range(args.passes):
        project.refine(makeBack=False)
        history.append({
            "pass": index + 1,
            "rwp_percent": rwp(project),
            "polarization": float(hist.InstrumentParameters["Polariz."][1]),
            "roughness_A": float(hist.SampleParameters["SurfRoughA"][0]),
            "roughness_B": float(hist.SampleParameters["SurfRoughB"][0]),
            "uiso": {phase.name: [float(a.uiso) for a in phase.atoms()]
                      for phase in project.phases()},
            "frozen": project.get_Frozen(),
        })
    project.save()
    result = {
        "parent": str(args.parent), "project": str(args.output),
        "polarization_refined": args.polarization,
        "roughness_refined": args.roughness,
        "uiso_refined": args.uiso,
        "history": history, "final": history[-1],
        "fractions": {k: list(map(float, v)) for k, v in
                      hist.ComputeMassFracs().items()},
        "instrument": copy.deepcopy(hist.InstrumentParameters),
        "sample": copy.deepcopy(hist.SampleParameters),
    }
    args.output.with_suffix(".json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(result["final"], indent=2))


if __name__ == "__main__":
    main()
