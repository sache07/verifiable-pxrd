#!/usr/bin/env python3
"""Test uniaxial microstrain for one phase and one crystallographic axis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project):
    hist = project.histogram(0)
    x, obs, weight, calc, background, diff = map(
        np.asarray, hist.data["data"][1][:6]
    )
    mask = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    return float(100 * np.sqrt(np.sum(weight[mask] * diff[mask] ** 2)
                               / np.sum(weight[mask] * obs[mask] ** 2)))


def limit(project, variable, lo, hi):
    project.set_Controls("parmMin", lo, variable=variable)
    project.set_Controls("parmMax", hi, variable=variable)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("parent", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", choices=["WO3", "Co3O4"])
    parser.add_argument("axis", help="comma-separated h,k,l")
    parser.add_argument("--cycles", type=int, default=20)
    parser.add_argument("--passes", type=int, default=3)
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.parent.resolve()),
                           newgpx=str(args.output.resolve()))
    project.save()
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histogram(0)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        if phase.name == args.phase:
            value = float(hap["Mustrain"][1][0])
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][0] = value
            hap["Mustrain"][1][1] = value
            hap["Mustrain"][2] = [True, True, False]
            hap["Mustrain"][3] = axis
            limit(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
            limit(project, f"{phase.id}:0:Mustrain;a", 0.0, 8000.0)

    history = []
    for index in range(args.passes):
        project.refine(makeBack=False)
        hap = project.phase(args.phase).data["Histograms"][hist.name]
        history.append({
            "pass": index + 1, "rwp_percent": rwp(project),
            "equatorial_ppm": float(hap["Mustrain"][1][0]),
            "axial_ppm": float(hap["Mustrain"][1][1]),
            "axial_ratio": float(hap["Mustrain"][1][1] / hap["Mustrain"][1][0]),
            "frozen": project.get_Frozen(),
        })
    project.save()
    result = {"parent": str(args.parent), "project": str(args.output),
              "phase": args.phase, "axis": axis, "history": history,
              "final": history[-1]}
    args.output.with_suffix(".json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(result["final"], indent=2))


if __name__ == "__main__":
    main()
