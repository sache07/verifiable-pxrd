#!/usr/bin/env python3
"""Reopen, replay and export the accepted GSAS-II model consistently."""

from __future__ import annotations

import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
PARENT = ROOT / "analysis/trials/u-grid-0.gpx"
PROJECT = ROOT / "final.gpx"


def plain(value):
    if isinstance(value, dict):
        return {str(key): plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(item) for item in value]
    if isinstance(value, np.ndarray):
        return plain(value.tolist())
    if isinstance(value, np.generic):
        return value.item()
    return value


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(PARENT), newgpx=str(PROJECT))
    project.save()
    project.set_Frozen()
    project.set_Controls("cycles", 20)

    replay_history = []
    for replay in range(3):
        project.refine(makeBack=False)
        covariance = project.data.get("Covariance", {}).get("data", {})
        replay_history.append({
            "replay": replay + 1,
            "rwp_percent": float(project.histogram(0).get_wR()),
            "maximum_shift_over_sigma": float(
                covariance.get("Rvals", {}).get("Max shft/sig", np.nan)
            ),
            "frozen": list(map(str, project.get_Frozen())),
            "message": str(covariance.get("Rvals", {}).get("msg", "")),
        })
    project.save()

    hist = project.histogram(0)
    x, observed, weight, calculated, background, difference = map(
        np.asarray, hist.data["data"][1][:6]
    )
    limits = hist.data["Limits"][1]
    use = (x >= limits[0]) & (x <= limits[1])
    chi_square = float(np.sum(weight[use] * difference[use] ** 2))
    denominator = float(np.sum(weight[use] * observed[use] ** 2))
    rwp = float(100 * np.sqrt(chi_square / denominator))
    rp = float(100 * np.sum(np.abs(difference[use])) / np.sum(observed[use]))

    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    npoints = int(np.count_nonzero(use))
    nvars = int(rvals.get("Nvars", len(covariance.get("varyList", []))))
    degrees_of_freedom = npoints - nvars
    reduced_chi_square = chi_square / degrees_of_freedom
    expected_rwp = float(100 * np.sqrt(npoints / denominator))

    fractions = hist.ComputeMassFracs()
    phase_files = {"WO3": "phase_WO3.cif", "Co3O4": "phase_Co3O4.cif"}
    display_names = {
        "WO3": "gamma-WO3 (monoclinic)",
        "Co3O4": "Co3O4 (spinel)",
    }
    formulas = {"WO3": "WO3", "Co3O4": "Co3O4"}
    phase_rows = []
    phase_details = {}
    for phase in project.phases():
        cif_name = phase_files[phase.name]
        phase.export_CIF(str(ROOT / cif_name))
        fraction, fraction_esd = fractions[phase.name]
        general = phase.data["General"]
        hap = phase.data["Histograms"][hist.name]
        phase_rows.append({
            "name": display_names[phase.name],
            "formula": formulas[phase.name],
            "space_group": general["SGData"]["SpGrp"],
            "cif_path": cif_name,
            "weight_fraction": float(fraction),
            "formal_weight_fraction_esd": float(fraction_esd),
        })
        phase_details[phase.name] = {
            "cell": plain(phase.get_cell()),
            "scale": plain(hap["Scale"]),
            "size": plain(hap["Size"]),
            "microstrain": plain(hap["Mustrain"]),
            "preferred_orientation": plain(hap["Pref.Ori."]),
            "atoms": [{
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(map(float, atom.coordinates)),
                "refinement_flags": atom.refinement_flags,
                "uiso_A2": float(atom.uiso),
            } for atom in phase.atoms()],
        }

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt="%.10f",
    )

    fit_statistics = {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "expected_rwp_percent": expected_rwp,
        "chi_square": chi_square,
        "reduced_chi_square": float(reduced_chi_square),
        "goodness_of_fit": float(np.sqrt(reduced_chi_square)),
        "n_points": npoints,
        "n_refined_variables": nvars,
        "degrees_of_freedom": degrees_of_freedom,
    }
    result = {
        "phases": phase_rows,
        "fit_statistics": fit_statistics,
        "refinement_histogram": hist.name,
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )

    diagnostics = {
        "source_project": str(PARENT.relative_to(ROOT)),
        "final_project": PROJECT.name,
        "replay_history": replay_history,
        "fit_statistics": fit_statistics,
        "fit_limits_deg": list(map(float, limits)),
        "fractions": {name: list(map(float, values))
                      for name, values in fractions.items()},
        "instrument": plain(copy.deepcopy(hist.InstrumentParameters)),
        "sample": plain(copy.deepcopy(hist.SampleParameters)),
        "background": plain(copy.deepcopy(hist.Background)),
        "background_min_counts": float(np.min(background[use])),
        "background_max_counts": float(np.max(background[use])),
        "phase_details": phase_details,
        "frozen": list(map(str, project.get_Frozen())),
        "vary_list": list(map(str, covariance.get("varyList", []))),
        "refinement_message": str(rvals.get("msg", "")),
    }
    (ROOT / "analysis/final_diagnostics.json").write_text(
        json.dumps(diagnostics, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps({
        "project": str(PROJECT),
        "phases": phase_rows,
        "fit_statistics": fit_statistics,
        "replay_history": replay_history,
        "frozen": diagnostics["frozen"],
        "message": diagnostics["refinement_message"],
    }, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
