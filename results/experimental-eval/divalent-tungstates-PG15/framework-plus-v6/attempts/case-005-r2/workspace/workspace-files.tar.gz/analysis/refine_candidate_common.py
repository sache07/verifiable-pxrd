#!/usr/bin/env python3
"""Replay alternate WO3 records under one restrained nuisance/profile model."""

from __future__ import annotations

import argparse,json
from pathlib import Path
import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(g):
 h=g.histogram(0);x,o,w,c,b,d=map(np.asarray,h.data['data'][1][:6]);m=(x>=h.data['Limits'][1][0])&(x<=h.data['Limits'][1][1]);return float(100*np.sqrt(np.sum(w[m]*d[m]**2)/np.sum(w[m]*o[m]**2)))


def main():
 p=argparse.ArgumentParser();p.add_argument('parent',type=Path);p.add_argument('output',type=Path);p.add_argument('--cycles',type=int,default=20);a=p.parse_args()
 G2.SetPrintLevel('warn');g=G2.G2Project(str(a.parent.resolve()),newgpx=str(a.output.resolve()));g.save();g.set_Frozen();g.set_Controls('cycles',a.cycles);h=g.histogram(0)
 vals={'U':40.,'W':10.86,'X':1.70,'SH/L':.0368,'Polariz.':.505}
 for k,v in vals.items():h.InstrumentParameters[k][1]=v;h.InstrumentParameters[k][2]=(k in ['W','Polariz.'])
 h.SampleParameters['SurfRoughA']=[.05,False];h.SampleParameters['SurfRoughB']=[.1008,False];h.SampleParameters['Shift'][1]=True
 g.set_Controls('parmMin',.5,variable=':0:Polariz.');g.set_Controls('parmMax',1.,variable=':0:Polariz.')
 for ph in g.phases():
  hap=ph.data['Histograms'][h.name];hap['Pref.Ori.'][0]='MD';hap['Pref.Ori.'][1]=1.;hap['Pref.Ori.'][2]=False
  if ph.name=='WO3':
   hap['Size'][0]='isotropic';hap['Size'][1][0]=.157;hap['Size'][2]=[True,False,False]
   hap['Mustrain'][0]='uniaxial';hap['Mustrain'][1][0]=4320.;hap['Mustrain'][1][1]=3304.;hap['Mustrain'][2]=[True,True,False];hap['Mustrain'][3]=[0,1,0]
  else:
   hap['Size'][0]='isotropic';hap['Size'][1][0]=.199;hap['Size'][2]=[True,False,False]
   hap['Mustrain'][0]='isotropic';hap['Mustrain'][1][0]=1345.;hap['Mustrain'][2]=[True,False,False]
  for atom in ph.atoms():atom.refinement_flags='X' if (atom.element in ['W'] or (ph.name=='Co3O4' and atom.element=='O')) else ' '
 history=[]
 for i in range(3):
  g.refine(makeBack=False);history.append({'pass':i+1,'rwp_percent':rwp(g),'frozen':g.get_Frozen(),'cell':g.phase('WO3').get_cell()})
 g.save();out={'parent':str(a.parent),'history':history,'final':history[-1]};a.output.with_suffix('.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps(out['final'],indent=2))


if __name__=='__main__':main()
