#!/usr/bin/env python3
"""Challenge a weak candidate phase under a fixed common nuisance model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]


def rwp(project):
    h=project.histogram(0);x,o,w,c,b,d=map(np.asarray,h.data['data'][1][:6])
    m=(x>=h.data['Limits'][1][0])&(x<=h.data['Limits'][1][1])
    return float(100*np.sqrt(np.sum(w[m]*d[m]**2)/np.sum(w[m]*o[m]**2)))


def main():
    p=argparse.ArgumentParser();p.add_argument('parent',type=Path);p.add_argument('output',type=Path)
    p.add_argument('candidate');p.add_argument('--cell',action='store_true');p.add_argument('--cycles',type=int,default=20)
    a=p.parse_args();G2.SetPrintLevel('warn')
    g=G2.G2Project(str(a.parent.resolve()),newgpx=str(a.output.resolve()));g.save();g.set_Frozen();g.set_Controls('cycles',a.cycles)
    h=g.histogram(0)
    for ph in g.phases():
        for atom in ph.atoms():atom.refinement_flags=' '
    phase=g.add_phase(str(ROOT/'analysis/candidates'/f'{a.candidate}.cif'),phasename='CoWO4-watch',histograms=[h],fmthint='CIF')
    hap=phase.data['Histograms'][h.name];hap['Scale']=[0.1,True]
    hap['Size'][0]='isotropic';hap['Size'][1][0]=hap['Size'][1][1]=0.2;hap['Size'][2]=[False,False,False]
    hap['Mustrain'][0]='isotropic';hap['Mustrain'][1][0]=hap['Mustrain'][1][1]=1000.;hap['Mustrain'][2]=[False,False,False]
    hap['Pref.Ori.'][0]='MD';hap['Pref.Ori.'][1]=1.;hap['Pref.Ori.'][2]=False;hap['Extinction']=[0.,False]
    phase.data['General']['Cell'][0]=a.cell
    g.set_Controls('parmMin',0.,variable=f'{phase.id}:0:Scale')
    history=[]
    for i in range(3):
        g.refine(makeBack=False)
        history.append({'pass':i+1,'rwp_percent':rwp(g),'scale':float(hap['Scale'][0]),
            'fractions':{k:list(map(float,v)) for k,v in h.ComputeMassFracs().items()},'cell':phase.get_cell(),'frozen':g.get_Frozen()})
        if g.get_Frozen():break
    g.save();out={'candidate':a.candidate,'cell_refined':a.cell,'history':history,'final':history[-1]}
    a.output.with_suffix('.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps(out['final'],indent=2))


if __name__=='__main__':main()
