#!/usr/bin/env python3
"""Rebuild and refine the selected three-phase GSAS-II model."""

from __future__ import annotations

import argparse
import copy
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def weight_fractions(project: G2.G2Project, hist_name: str) -> dict[str, float]:
    terms = []
    for phase in project.phases():
        scale = phase.data["Histograms"][hist_name]["Scale"][0]
        terms.append((phase.name, max(0.0, scale * phase.data["General"]["Mass"])))
    total = sum(value for _, value in terms)
    return {name: (value / total if total else 0.0) for name, value in terms}


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    return {
        "stage": stage,
        "rwp_percent": hist.get_wR(),
        "fractions": weight_fractions(project, hist.name),
        "instrument": {k: copy.deepcopy(v) for k, v in inst.items()},
        "sample": copy.deepcopy(hist.SampleParameters),
        "background": copy.deepcopy(hist.data["Background"]),
        "frozen": copy.deepcopy(project.get_Frozen()),
        "vary_list": copy.deepcopy(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "phases": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": copy.deepcopy(phase.data["Histograms"][hist.name]["Scale"]),
                "size": copy.deepcopy(phase.data["Histograms"][hist.name]["Size"]),
                "mustrain": copy.deepcopy(phase.data["Histograms"][hist.name]["Mustrain"]),
                "preferred_orientation": copy.deepcopy(phase.data["Histograms"][hist.name]["Pref.Ori."]),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": atom.coordinates,
                        "adp_flag": atom.adp_flag,
                        "adp": copy.deepcopy(atom.ADP),
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
            for phase in project.phases()
        ],
    }


def run_stage(project: G2.G2Project, out: Path, log: list[dict], name: str, cycles: int = 12) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(project.filename, out / f"{name}.gpx")
    row = snapshot(project, name)
    log.append(row)
    print(name, "Rwp", row["rwp_percent"], "fractions", row["fractions"], "frozen", row["frozen"], flush=True)


def clear_refinement_state(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for value in inst.values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    hist.data["Background"][0][1] = False
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}


def make_zno_isotropic(project: G2.G2Project) -> None:
    """Match the supplied model-pool normalization (Uiso=0.005 A^2)."""
    zno = project.phase(2)
    for atom in zno.atoms():
        # G2AtomRecord deliberately has no adp_flag setter. The record layout is
        # stable and exposed by AtomPtrs; switching A->I here leaves coordinates,
        # occupancy and symmetry untouched.
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.005
        atom.refinement_flags = " "


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    args.out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(args.base.resolve()), newgpx=str((args.out / "model.gpx").resolve()))
    hist = project.histogram(0)
    make_zno_isotropic(project)
    clear_refinement_state(project)
    log = [snapshot(project, "imported")]

    # Rebuild a common physically bounded baseline after the inventory change.
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1:3] = [20.0, True]
    inst["W"][1:3] = [25.0, True]
    inst["X"][1:3] = [1.0, False]  # exactly confounded with isotropic size here
    inst["SH/L"][2] = True
    inst["Zero"][2] = True
    inst["Polariz."][2] = False
    hist.data["Background"][0][1] = True
    hist.SampleParameters["SurfRoughA"][1] = True
    hist.SampleParameters["SurfRoughB"][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    project.set_Controls("parmMin", 0.0, ":*:U")
    project.set_Controls("parmMax", 40.0, ":*:U")
    project.set_Controls("parmMin", 2.0, ":*:W")
    project.set_Controls("parmMax", 40.0, ":*:W")
    project.set_Controls("parmMin", 0.005, ":*:SH/L")
    project.set_Controls("parmMax", 0.10, ":*:SH/L")
    project.set_Controls("parmMin", -0.50, ":*:Zero")
    project.set_Controls("parmMax", 0.50, ":*:Zero")
    project.set_Controls("parmMin", 0.05, ":*:SurfRoughA")
    project.set_Controls("parmMax", 0.60, ":*:SurfRoughA")
    project.set_Controls("parmMin", 0.02, ":*:SurfRoughB")
    project.set_Controls("parmMax", 0.50, ":*:SurfRoughB")
    run_stage(project, args.out, log, "common_baseline", 14)

    # Compare phase-specific sizes only after the shared profile has converged.
    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        project.set_Controls("parmMin", 0.04, f"{phase.id}:*:Size;i")
        project.set_Controls("parmMax", 1.50, f"{phase.id}:*:Size;i")
    run_stage(project, args.out, log, "phase_sizes", 14)

    # Symmetry-preserving coordinates are warranted by the known model-source
    # envelope and remaining structured intensity residuals.
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": "X"}})
    run_stage(project, args.out, log, "atomic_coordinates", 16)

    # One common isotropic displacement value per phase, matching the model
    # generation convention and avoiding atom-by-atom intensity surrogates.
    for phase in project.phases():
        for atom in phase.atoms():
            if atom.adp_flag != "I":
                raise RuntimeError(f"anisotropic atom remained in {phase.name}: {atom.label}")
            atom.uiso = 0.005
            atom.refinement_flags = "XU"
        variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables)
        project.set_Controls("parmMin", 0.003, f"{phase.id}::AUiso:*")
        project.set_Controls("parmMax", 0.020, f"{phase.id}::AUiso:*")
    run_stage(project, args.out, log, "common_phase_uiso", 14)

    inst["Polariz."][2] = True
    project.set_Controls("parmMin", 0.50, ":*:Polariz.")
    project.set_Controls("parmMax", 1.00, ":*:Polariz.")
    run_stage(project, args.out, log, "polarization", 12)

    (args.out / "diagnostics.json").write_text(json.dumps(log, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
