#!/usr/bin/env python3
"""Refine selected structural/intensity branches from the clean 3-phase baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    vals = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        vals.append((phase.name, max(0.0, hap["Scale"][0] * phase.data["General"]["Mass"])))
    total = sum(v for _, v in vals)
    return {n: v / total for n, v in vals}


def summarize(project: G2.G2Project, name: str, output: Path) -> dict:
    hist = project.histogram(0)
    return {
        "name": name,
        "rwp_percent": hist.get_wR(),
        "fractions": fractions(project),
        "frozen": project.get_Frozen(),
        "project": str(output),
    }


def refine(project: G2.G2Project, output: Path, cycles: int = 16) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    project.save()
    return summarize(project, output.stem, output)


def load(base: Path, output: Path) -> G2.G2Project:
    return G2.G2Project(str(base.resolve()), newgpx=str(output.resolve()))


def fix_bound_common_widths(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][2] = False
    inst["W"][2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    project.data["Controls"]["data"]["parmFrozen"] = {}


def coordinate_branch(base: Path, output: Path) -> dict:
    project = load(base, output)
    fix_bound_common_widths(project)
    for phase in project.phases()[:2]:
        phase.set_refinements({"Atoms": {"all": "X"}})
    # P63mc has a free common origin along z. Hold Zn at z=0 and refine only
    # the physically meaningful relative O coordinate.
    zno = project.phase(2)
    zno.atoms()[0].refinement_flags = " "
    zno.atoms()[1].refinement_flags = "X"
    return refine(project, output, 18)


def uiso_branch(base: Path, output: Path) -> dict:
    project = load(base, output)
    fix_bound_common_widths(project)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.uiso = 0.008
            if "U" not in atom.refinement_flags:
                atom.refinement_flags += "U"
        variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables)
        project.set_Controls("parmMin", 0.003, f"{phase.id}::AUiso:*")
        project.set_Controls("parmMax", 0.020, f"{phase.id}::AUiso:*")
    return refine(project, output, 16)


def polarization_branch(base: Path, output: Path) -> dict:
    project = load(base, output)
    fix_bound_common_widths(project)
    hist = project.histogram(0)
    hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    project.set_Controls("parmMin", 0.50, ":*:Polariz.")
    project.set_Controls("parmMax", 1.00, ":*:Polariz.")
    return refine(project, output, 14)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    args.out.mkdir(parents=True, exist_ok=True)
    rows = []
    coord_path = args.out / "coordinates.gpx"
    rows.append(coordinate_branch(args.base, coord_path))
    print(json.dumps(rows[-1]), flush=True)
    rows.append(uiso_branch(coord_path, args.out / "coordinates_uiso.gpx"))
    print(json.dumps(rows[-1]), flush=True)
    rows.append(polarization_branch(coord_path, args.out / "coordinates_polarization.gpx"))
    print(json.dumps(rows[-1]), flush=True)
    (args.out / "branches.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
