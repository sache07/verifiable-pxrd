#!/usr/bin/env python3
"""Create the user-facing deliverables from the selected replay-stable GPX."""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
# Keep the converged covariance/ESDs in the delivered project. An independent
# zero-cycle copy of this file was reopened and reproduced the same profile.
SOURCE = ROOT / ".tmp" / "angular_shift_trial.gpx"
FINAL = ROOT / "final.gpx"
PATTERN = ROOT / "inputs" / "pattern.csv"

PHASE_EXPORTS = {
    "ZnWO4": {
        "file": "phase_ZnWO4.cif",
        "name": "ZnWO4 (wolframite)",
        "formula": "ZnWO4",
        "source": "COD 1520641",
    },
    "WO3_2311041": {
        "file": "phase_WO3.cif",
        "name": "WO3 (gamma-monoclinic)",
        "formula": "WO3",
        "source": "COD 2311041",
    },
    "ZnO_wurtzite": {
        "file": "phase_ZnO.cif",
        "name": "ZnO (wurtzite)",
        "formula": "ZnO",
        "source": "COD 9004178",
    },
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    if not SOURCE.is_file():
        raise FileNotFoundError(SOURCE)

    # A byte-for-byte copy retains the converged arrays and covariance. Loading
    # it under the final name makes the GPX and all exports share one source.
    shutil.copy2(SOURCE, FINAL)
    project = G2.G2Project(str(FINAL))
    histograms = project.histograms()
    if len(histograms) != 1:
        raise RuntimeError(f"expected one histogram, found {len(histograms)}")
    histogram = histograms[0]
    phases = project.phases()
    if {phase.name for phase in phases} != set(PHASE_EXPORTS):
        raise RuntimeError(f"unexpected phase inventory: {[phase.name for phase in phases]}")

    # Verify that the saved histogram contains the complete supplied scan.
    public = np.loadtxt(PATTERN, delimiter=",", skiprows=1, ndmin=2)
    arrays = histogram.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    observed = np.asarray(arrays[1], dtype=float)
    calculated = np.asarray(arrays[3], dtype=float)
    difference = observed - calculated
    if x.shape != public[:, 0].shape or not np.allclose(x, public[:, 0], rtol=0, atol=1e-9):
        raise RuntimeError("saved GPX grid does not match inputs/pattern.csv")
    if not np.allclose(observed, public[:, 1], rtol=0, atol=1e-9):
        raise RuntimeError("saved GPX observations do not match inputs/pattern.csv")
    if not (np.isfinite(calculated).all() and np.min(calculated) >= 0):
        raise RuntimeError("calculated profile contains a nonfinite or negative value")
    limits = histogram.data["Limits"][1]
    if limits[0] > x[0] + 1e-7 or limits[1] < x[-1] - 1e-7:
        raise RuntimeError(f"GPX fitting limits do not span the supplied scan: {limits}")

    controls = project.data["Controls"]["data"]
    frozen = controls.get("parmFrozen", {})
    if frozen not in ({}, {"FrozenList": []}):
        raise RuntimeError(f"project contains frozen parameters: {frozen}")

    # Export directly from the saved phase records. Clearing covariance only in
    # memory prevents stale covariance values from overriding saved atoms; the
    # final.gpx file itself is not modified.
    project.data["Covariance"]["data"] = {}
    for phase in phases:
        phase.export_CIF(str(ROOT / PHASE_EXPORTS[phase.name]["file"]))

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        for values in zip(x, observed, calculated, difference):
            writer.writerow([format(float(value), ".15g") for value in values])

    mass_terms = {
        phase.name: float(
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][histogram.name]["Scale"][0]
        )
        for phase in phases
    }
    total_mass_term = sum(mass_terms.values())
    fractions = {name: value / total_mass_term for name, value in mass_terms.items()}

    saved_stats = histogram.data["data"][0]
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    rexp = float(saved_stats["wRmin"])
    if abs(rwp - float(saved_stats["wR"])) > 1e-9:
        raise RuntimeError(f"profile Rwp {rwp} disagrees with saved Rwp {saved_stats['wR']}")

    covariance = G2.G2Project(str(FINAL)).data["Covariance"]["data"]
    varied = list(covariance.get("varyList", []))
    fit_statistics = {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "rexp_percent": rexp,
        "goodness_of_fit": rwp / rexp,
        "chi_square_sum": chi_square,
        "chi_square_per_observation": chi_square / len(x),
        "durbin_watson": float(saved_stats["Durbin-Watson"]),
        "n_points": int(len(x)),
        "n_refined_parameters": int(len(varied)),
        "two_theta_range_deg": [float(x[0]), float(x[-1])],
    }

    phase_rows = []
    for phase in phases:
        export = PHASE_EXPORTS[phase.name]
        hap = phase.data["Histograms"][histogram.name]
        phase_rows.append(
            {
                "name": export["name"],
                "formula": export["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": export["file"],
                "weight_fraction": fractions[phase.name],
                "scale_factor": float(hap["Scale"][0]),
                "structural_source": export["source"],
            }
        )

    result = {
        "phases": phase_rows,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "fit_statistics": fit_statistics,
        "refinement_histogram": histogram.name,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "calibration": {
            "specimen_displacement_um": float(histogram.SampleParameters["Shift"][0]),
            "goniometer_radius_mm": float(histogram.SampleParameters["Gonio. radius"]),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    print(json.dumps(result, indent=2))
    print("file_sha256", {name: sha256(ROOT / name) for name in [
        "final.gpx", "fit.csv", "result.json",
        "phase_ZnWO4.cif", "phase_WO3.cif", "phase_ZnO.cif",
    ]})
    print("calculated_minmax", float(np.min(calculated)), float(np.max(calculated)))
    print("difference_array_error", float(np.max(np.abs(np.asarray(arrays[5]) - difference))))


if __name__ == "__main__":
    main()
