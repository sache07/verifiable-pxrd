#!/usr/bin/env python3
"""Build and refine a compact GSAS-II model for the supplied PXRD scan.

Run with the GSAS-II Python interpreter. This is an exploratory driver; the
final export is produced separately after model selection.
"""

from __future__ import annotations

import argparse
import copy
import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter

from GSASII import GSASIIscriptable as G2


def write_xye(csv_path: Path, xye_path: Path) -> tuple[np.ndarray, np.ndarray]:
    data = np.loadtxt(csv_path, delimiter=",", skiprows=1)
    x, y = data[:, 0], data[:, 1]
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(xye_path, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    return x, y


def write_instrument(path: Path) -> None:
    path.write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha Bragg-Brentano data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:12.0;V:0.0;W:12.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def background_points(x: np.ndarray, y: np.ndarray) -> list[tuple[float, float]]:
    step = float(np.median(np.diff(x)))
    window = int(round(2.2 / step)) | 1
    base = percentile_filter(y, percentile=12, size=window, mode="nearest")
    base = gaussian_filter1d(base, sigma=max(2, int(round(0.28 / step))))
    # Dense enough to initialize a smooth Chebyshev series, but not retained as
    # a pointwise/interpolated background model.
    xp = np.linspace(float(x[0]), float(x[-1]), 25)
    return [(float(v), float(np.interp(v, x, base))) for v in xp]


def phase_weight_fractions(project: G2.G2Project, hist_name: str) -> dict[str, float]:
    terms = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist_name]
        terms.append((phase.name, float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])))
    total = sum(max(0.0, value) for _, value in terms)
    return {name: (max(0.0, value) / total if total else 0.0) for name, value in terms}


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": atom.coordinates,
                        "uiso": atom.uiso if atom.adp_flag == "I" else None,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    return {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "residuals": copy.deepcopy(hist.data["data"][0]),
        "instrument": {k: v[1] if isinstance(v, list) and len(v) > 1 else v for k, v in inst.items()},
        "sample": sample,
        "background": hist.data["Background"][0],
        "weight_fractions": phase_weight_fractions(project, hist.name),
        "phases": copy.deepcopy(phases),
        "vary_list": copy.deepcopy(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "frozen": copy.deepcopy(project.get_Frozen()),
    }


def refine(project: G2.G2Project, log: list[dict], label: str) -> None:
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(project.filename, Path(project.filename).with_name(label + ".gpx"))
    log.append(snapshot(project, label))
    print(label, "Rwp", log[-1]["rwp_percent"], "fractions", log[-1]["weight_fractions"], flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase", action="append", nargs=2, metavar=("NAME", "CIF"), required=True)
    parser.add_argument("--background-terms", type=int, default=8)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.out.mkdir(parents=True, exist_ok=True)
    x, y = write_xye(Path("inputs/pattern.csv"), args.out / "pattern.xye")
    write_instrument(args.out / "instrument.instprm")

    project = G2.G2Project(newgpx=str((args.out / "model.gpx").resolve()))
    hist = project.add_powder_histogram(
        str((args.out / "pattern.xye").resolve()),
        str((args.out / "instrument.instprm").resolve()),
        fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})

    phases = []
    for name, cif in args.phase:
        phase = project.add_phase(str(Path(cif).resolve()), phasename=name, histograms=[hist], fmthint="CIF")
        for atom in phase.atoms():
            if atom.adp_flag == "I":
                atom.uiso = 0.005
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        phase.setSampleProfile(hist.name, "size", "isotropic", 10.0, LGmix=1.0)
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", 0.0, LGmix=1.0)
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]
        phases.append(phase)

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": [0.0] * args.background_terms,
                "refine": True,
                "FixedPoints": background_points(x, y),
                "fit fixed points": True,
            }
        }
    )
    project.save()
    log = [snapshot(project, "initial")]

    # Positive scales plus a smooth common background establish the inventory.
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    refine(project, log, "background_scales")

    # One common angular correction, with the cell metrics allowed to adapt to
    # the sample rather than forcing the published cell.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, log, "zero_cells")

    # Shared nonnegative Caglioti/Lorentzian profile. V and Y stay neutral.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.set_Controls("parmMin", 0.0, ":*:U")
    project.set_Controls("parmMin", 0.0, ":*:W")
    project.set_Controls("parmMin", 0.0, ":*:X")
    project.set_Controls("parmMax", 40.0, ":*:U")
    project.set_Controls("parmMax", 40.0, ":*:W")
    project.set_Controls("parmMin", 0.1, ":*:X")
    project.set_Controls("parmMax", 6.0, ":*:X")
    refine(project, log, "common_uwx")

    # A bound common profile signals specimen broadening. Since instrumental X
    # and isotropic crystallite size have the same angular dependence for one
    # phase, hold X at a plausible interior value while comparing size. The
    # analogous U/strain ambiguity is handled in the same way below.
    project.set_Frozen()
    instrument = hist.data["Instrument Parameters"][0]
    instrument["U"][1:3] = [20.0, False]
    instrument["W"][1:3] = [20.0, True]
    instrument["X"][1:3] = [1.0, False]
    for phase in phases:
        phase.setSampleProfile(hist.name, "size", "isotropic", 0.20, LGmix=1.0)
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        project.set_Controls("parmMin", 0.04, f"{phase.id}:*:Size;i")
        project.set_Controls("parmMax", 1.50, f"{phase.id}:*:Size;i")
    refine(project, log, "isotropic_size")

    project.set_Frozen()
    for phase in phases:
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", 1000.0, LGmix=1.0)
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        project.set_Controls("parmMin", 0.0, f"{phase.id}:*:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, f"{phase.id}:*:Mustrain;i")
    refine(project, log, "size_isotropic_strain")

    # Low-angle asymmetry is released only after the common widths and
    # specimen terms converge.
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.set_Controls("parmMin", 0.002, ":*:SH/L")
    project.set_Controls("parmMax", 0.2, ":*:SH/L")
    refine(project, log, "common_shl")

    # The synthetic-reference envelope and the diffraction residuals both
    # justify a restrained coordinate refinement in the parent symmetry.
    for phase in phases:
        phase.set_refinements({"Atoms": {"all": "X"}})
    refine(project, log, "atomic_coordinates")

    # The source pool uses one isotropic U value per phase. Preserve that
    # physically meaningful equality while refining the shared value.
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = "XU"
        variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables)
        project.set_Controls("parmMin", 0.001, f"{phase.id}::AUiso:*")
        project.set_Controls("parmMax", 0.030, f"{phase.id}::AUiso:*")
    refine(project, log, "coordinates_common_uiso")

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.5, ":*:Polariz.")
    project.set_Controls("parmMax", 1.0, ":*:Polariz.")
    refine(project, log, "polarization")

    (args.out / "diagnostics.json").write_text(json.dumps(log, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
