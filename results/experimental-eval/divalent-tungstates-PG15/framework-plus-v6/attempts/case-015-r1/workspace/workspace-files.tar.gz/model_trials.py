#!/usr/bin/env python3
"""Run reversible GSAS-II nuisance-model trials from a saved baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


TEXTURE_AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def clone(base: Path, output: Path) -> G2.G2Project:
    return G2.G2Project(str(base.resolve()), newgpx=str(output.resolve()))


def texture_trial(base: Path, output: Path, axis: tuple[int, int, int], phase_index: int = 0) -> dict:
    project = clone(base, output)
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    project.set_Controls("parmMin", 0.7, f"{phase.id}:*:MD")
    project.set_Controls("parmMax", 1.4, f"{phase.id}:*:MD")
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    project.save()
    return {
        "kind": "texture",
        "phase": phase.name,
        "axis": axis,
        "rwp_percent": hist.get_wR(),
        "ratio": hap["Pref.Ori."][1],
        "frozen": project.get_Frozen(),
        "project": str(output),
    }


def roughness_trial(base: Path, output: Path) -> dict:
    project = clone(base, output)
    hist = project.histogram(0)
    hist.SampleParameters["SurfRoughA"] = [0.30, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    project.set_Controls("parmMin", 0.05, ":*:SurfRoughA")
    project.set_Controls("parmMax", 0.60, ":*:SurfRoughA")
    project.set_Controls("parmMin", 0.02, ":*:SurfRoughB")
    project.set_Controls("parmMax", 0.50, ":*:SurfRoughB")
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    project.save()
    return {
        "kind": "roughness",
        "rwp_percent": hist.get_wR(),
        "A": hist.SampleParameters["SurfRoughA"][0],
        "B": hist.SampleParameters["SurfRoughB"][0],
        "frozen": project.get_Frozen(),
        "project": str(output),
    }


def strain_trial(base: Path, output: Path, axis: tuple[int, int, int], phase_index: int = 0) -> dict:
    project = clone(base, output)
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    phase.setSampleProfile(hist.name, "microstrain", "uniaxial", 1000.0, 1000.0, list(axis), LGmix=1.0)
    phase.set_HAP_refinements(
        {"Mustrain": {"type": "uniaxial", "refine": True, "direction": list(axis)}}
    )
    for suffix in ("i", "a"):
        project.set_Controls("parmMin", 0.0, f"{phase.id}:*:Mustrain;{suffix}")
        project.set_Controls("parmMax", 8000.0, f"{phase.id}:*:Mustrain;{suffix}")
    project.set_Frozen(variable=f"{phase.id}:0:Mustrain;i", mode="remove")
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    project.save()
    values = phase.data["Histograms"][hist.name]["Mustrain"]
    return {
        "kind": "uniaxial_strain",
        "phase": phase.name,
        "axis": axis,
        "rwp_percent": hist.get_wR(),
        "equatorial_ppm": values[1][0],
        "axial_ppm": values[1][1],
        "frozen": project.get_Frozen(),
        "project": str(output),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--kind", choices=("texture", "roughness", "strain", "all"), default="all")
    parser.add_argument("--phase-index", type=int, default=0)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    args.out.mkdir(parents=True, exist_ok=True)
    rows = []
    if args.kind in ("texture", "all"):
        for axis in TEXTURE_AXES:
            tag = "".join(map(str, axis))
            rows.append(texture_trial(args.base, args.out / f"texture_p{args.phase_index}_{tag}.gpx", axis, args.phase_index))
            print(json.dumps(rows[-1]), flush=True)
    if args.kind in ("roughness", "all"):
        rows.append(roughness_trial(args.base, args.out / "roughness.gpx"))
        print(json.dumps(rows[-1]), flush=True)
    if args.kind in ("strain", "all"):
        for axis in TEXTURE_AXES[:3]:
            tag = "".join(map(str, axis))
            rows.append(strain_trial(args.base, args.out / f"strain_p{args.phase_index}_{tag}.gpx", axis, args.phase_index))
            print(json.dumps(rows[-1]), flush=True)
    (args.out / "trials.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
