#!/usr/bin/env python3
"""Re-converge a uniaxial-strain trial after pruning its bound component."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", type=int, default=0)
    parser.add_argument("--keep", choices=("equatorial", "axial"), required=True)
    args = parser.parse_args()

    project = G2.G2Project(str(args.source.resolve()), newgpx=str(args.output.resolve()))
    histogram = project.histogram(0)
    phase = project.phase(args.phase)
    profile = phase.data["Histograms"][histogram.name]["Mustrain"]
    if profile[0] != "uniaxial":
        raise RuntimeError(f"expected a uniaxial model, found {profile[0]}")
    retained = 0 if args.keep == "equatorial" else 1
    pruned = 1 - retained
    profile[1][pruned] = 0.0
    profile[2][pruned] = False
    profile[2][retained] = True
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("parmMin", 0.0, f"{phase.id}:*:Mustrain;{'i' if retained == 0 else 'a'}")
    project.set_Controls("parmMax", 8000.0, f"{phase.id}:*:Mustrain;{'i' if retained == 0 else 'a'}")
    project.set_Controls("cycles", 30)
    project.refine(makeBack=False)
    project.save()

    result = {
        "project": str(args.output),
        "rwp_percent": histogram.get_wR(),
        "axis": profile[3],
        "equatorial_ppm": profile[1][0],
        "axial_ppm": profile[1][1],
        "flags": profile[2],
        "frozen": [str(value) for value in project.get_Frozen()],
        "sizes_um": {
            p.name: p.data["Histograms"][histogram.name]["Size"][1][0]
            for p in project.phases()
        },
        "strains_ppm": {
            p.name: p.data["Histograms"][histogram.name]["Mustrain"][1][:2]
            for p in project.phases()
        },
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
