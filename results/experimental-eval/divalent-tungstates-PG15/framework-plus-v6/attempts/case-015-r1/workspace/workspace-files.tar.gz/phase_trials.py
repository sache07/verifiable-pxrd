#!/usr/bin/env python3
"""Reversible candidate-phase tests against a common GSAS-II baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project: G2.G2Project, hist_name: str) -> dict[str, float]:
    values = []
    for phase in project.phases():
        scale = phase.data["Histograms"][hist_name]["Scale"][0]
        values.append((phase.name, max(0.0, scale * phase.data["General"]["Mass"])))
    total = sum(v for _, v in values)
    return {name: (value / total if total else 0.0) for name, value in values}


def trial(base: Path, output: Path, name: str, cif: Path) -> dict:
    project = G2.G2Project(str(base.resolve()), newgpx=str(output.resolve()))
    hist = project.histogram(0)
    parent = project.phase(0)
    phase = project.add_phase(str(cif.resolve()), phasename=name, histograms=[hist], fmthint="CIF")
    for atom in phase.atoms():
        if atom.adp_flag == "I":
            atom.uiso = 0.005
        atom.refinement_flags = " "
    parent_hap = parent.data["Histograms"][hist.name]
    hap = phase.data["Histograms"][hist.name]
    # Start at 25 wt% without changing the established parent scale.
    parent_mass = float(parent.data["General"]["Mass"])
    phase_mass = float(phase.data["General"]["Mass"])
    hap["Scale"] = [parent_hap["Scale"][0] * (0.25 / phase_mass) / (0.75 / parent_mass), True]
    phase.setSampleProfile(hist.name, "size", "isotropic", 0.20, LGmix=1.0)
    phase.setSampleProfile(hist.name, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"] = [0.0, False]
    phase.set_HAP_refinements({"Scale": True})
    project.set_Controls("parmMin", 0.0, f"{phase.id}:*:Scale")
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    stage1_rwp = hist.get_wR()
    stage1_frac = fractions(project, hist.name)

    # A positive scale earns a cell/size re-test under the same common profile.
    if stage1_frac.get(name, 0.0) > 0.002:
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        project.set_Controls("parmMin", 0.04, f"{phase.id}:*:Size;i")
        project.set_Controls("parmMax", 1.50, f"{phase.id}:*:Size;i")
        project.set_Controls("cycles", 12)
        project.refine(makeBack=False)
    project.save()
    return {
        "name": name,
        "cif": str(cif),
        "stage1_rwp_percent": stage1_rwp,
        "stage1_fractions": stage1_frac,
        "final_rwp_percent": hist.get_wR(),
        "final_fractions": fractions(project, hist.name),
        "cell": phase.get_cell(),
        "size": hap["Size"],
        "scale": hap["Scale"],
        "frozen": project.get_Frozen(),
        "project": str(output),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--candidate", action="append", nargs=2, metavar=("NAME", "CIF"), required=True)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    args.out.mkdir(parents=True, exist_ok=True)
    rows = []
    for name, cif in args.candidate:
        output = args.out / f"{name}.gpx"
        rows.append(trial(args.base, output, name, Path(cif)))
        print(json.dumps(rows[-1], default=str), flush=True)
    (args.out / "trials.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
