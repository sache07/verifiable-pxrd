#!/usr/bin/env python3
"""Create the internally consistent final GSAS-II submission files."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "variants" / "full-range.gpx"
FINAL = ROOT / "final.gpx"


def main() -> None:
    # Reserialize the selected, full-range project under the required final name.
    project = G2.G2Project(str(SOURCE), newgpx=str(FINAL))
    project.save()

    # All exports below come from a fresh read of the file that will be submitted.
    project = G2.G2Project(str(FINAL))
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("x"), dtype=float)
    observed = np.asarray(hist.getdata("yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("ycalc"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    difference = observed - calculated

    public = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if public.shape != (len(x), 2):
        raise RuntimeError("final project does not cover the complete input scan")
    if not np.allclose(x, public[:, 0], atol=1e-10, rtol=0):
        raise RuntimeError("final project angle grid differs from pattern.csv")
    if not np.allclose(observed, public[:, 1], atol=1e-10, rtol=0):
        raise RuntimeError("final project observations differ from pattern.csv")
    if not np.isfinite(calculated).all() or np.any(calculated < 0):
        raise RuntimeError("final calculated profile is nonfinite or negative")

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference, background)),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.8f", "%.12g", "%.12g", "%.12g"],
    )

    fractions = hist.ComputeMassFracs()
    residuals = dict(hist.residuals)
    rvals = dict(project.data["Covariance"]["data"]["Rvals"])

    phase_specs = [
        {
            "project_name": "CoWO4_CoMoO4_parent",
            "name": "CoWO4 (wolframite)",
            "formula": "CoWO4",
            "space_group": "P 1 2/c 1",
            "cif_path": "CoWO4_wolframite.cif",
            "bragg_r_factor_percent": residuals["0:0:Rf^2"],
        },
        {
            "project_name": "WO3_triclinic_2106293",
            "name": "WO3 (triclinic)",
            "formula": "WO3",
            "space_group": "P -1",
            "cif_path": "WO3_triclinic.cif",
            "bragg_r_factor_percent": residuals["1:0:Rf^2"],
        },
    ]
    phases_by_name = {phase.name: phase for phase in project.phases()}
    if set(phases_by_name) != {spec["project_name"] for spec in phase_specs}:
        raise RuntimeError("unexpected phase inventory in final project")

    # Match the evaluator's export convention: export saved full-precision phase
    # data and do not let stale covariance entries override atom parameters.
    project.data["Covariance"]["data"] = {}
    phase_rows = []
    for spec in phase_specs:
        phases_by_name[spec["project_name"]].export_CIF(str(ROOT / spec["cif_path"]))
        fraction, formal_su = fractions[spec["project_name"]]
        phase_rows.append(
            {
                "name": spec["name"],
                "formula": spec["formula"],
                "space_group": spec["space_group"],
                "cif_path": spec["cif_path"],
                "weight_fraction": float(fraction),
                "weight_fraction_formal_standard_uncertainty": float(formal_su),
                "bragg_r_factor_percent": float(spec["bragg_r_factor_percent"]),
            }
        )

    weights = 1.0 / np.maximum(observed, 1.0)
    independent_rwp = 100.0 * np.sqrt(
        np.sum(weights * difference**2) / np.sum(weights * observed**2)
    )
    result = {
        "phases": phase_rows,
        "refinement_histogram": hist.name,
        "fit_profile": "fit.csv",
        "gsas_project": "final.gpx",
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "expected_Rwp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "independent_full_grid_Rwp_percent": float(independent_rwp),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
        },
    }
    if not np.isclose(sum(row["weight_fraction"] for row in phase_rows), 1.0, atol=1e-12):
        raise RuntimeError("phase fractions do not sum to one")
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    print(json.dumps(result, indent=2))
    print(f"calculated minimum: {calculated.min():.6f}")
    print(f"background minimum: {background.min():.6f}")


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    main()
