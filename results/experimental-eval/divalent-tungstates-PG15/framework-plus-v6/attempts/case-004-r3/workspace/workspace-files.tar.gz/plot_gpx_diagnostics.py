#!/usr/bin/env python3
"""Plot profile/reflection files created by gpx_diagnostics.py."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    directory = args.directory.resolve()
    profile = np.genfromtxt(directory / "profile.csv", delimiter=",", names=True)
    reflections = json.loads((directory / "reflections.json").read_text())
    x = profile["two_theta_deg"]
    y = profile["observed"]
    yc = profile["calculated"]
    residual = profile["difference"]
    bkg = profile["background"]
    phase_names = list(dict.fromkeys(row["phase"] for row in reflections))

    fig, axes = plt.subplots(6, 1, figsize=(15, 15), sharey=False)
    ranges = [(10, 25), (25, 40), (40, 55), (55, 70), (70, 85), (85, 100)]
    for ax, (lo, hi) in zip(axes, ranges):
        use = (x >= lo) & (x <= hi)
        ax.plot(x[use], y[use], color="black", lw=0.65, label="observed")
        ax.plot(x[use], yc[use], color="tab:red", lw=0.7, label="calculated")
        ax.plot(x[use], bkg[use], color="tab:green", lw=0.6, label="background")
        span = max(y[use]) - min(y[use])
        offset = min(y[use]) - 0.28 * span
        ax.plot(x[use], residual[use] + offset, color="tab:blue", lw=0.6, label="difference (offset)")
        tick_base = offset - 0.06 * span
        for phase_index, phase_name in enumerate(phase_names):
            positions = [
                row["two_theta_deg"]
                for row in reflections
                if row["phase"] == phase_name and lo <= row["two_theta_deg"] <= hi
            ]
            ax.vlines(
                positions,
                tick_base - phase_index * 25,
                tick_base - phase_index * 25 + 18,
                lw=0.45,
                label=phase_name if lo == 10 else None,
            )
        ax.set_xlim(lo, hi)
        ax.set_ylabel("counts")
    axes[0].legend(ncol=3, fontsize=8)
    axes[-1].set_xlabel(r"$2\theta$ (deg)")
    fig.tight_layout()
    fig.savefig(directory / "fit_windows.png", dpi=180)


if __name__ == "__main__":
    main()
