#!/usr/bin/env python3
"""Apply one controlled refinement variant to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_phase_profile_flags(project: G2.G2Project) -> None:
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})


def state(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    return {
        "residuals": hist.residuals,
        "fractions": hist.ComputeMassFracs(),
        "instrument": {k: hist.InstrumentParameters[k] for k in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")},
        "sample": {k: hist.SampleParameters.get(k) for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "phases": [
            {
                "name": p.name,
                "cell": p.get_cell(),
                "size": p.data["Histograms"][hist.name]["Size"],
                "mustrain": p.data["Histograms"][hist.name]["Mustrain"],
                "preferred_orientation": p.data["Histograms"][hist.name]["Pref.Ori."],
            }
            for p in project.phases()
        ],
        "vary_list": [str(v) for v in project.data["Covariance"]["data"].get("varyList", [])],
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx", type=Path)
    parser.add_argument("output_gpx", type=Path)
    parser.add_argument(
        "mode",
        choices=[
            "strain-cw",
            "strain-wo3",
            "strain-both",
            "size-cw",
            "size-wo3",
            "size-both",
            "size-strain-wo3",
            "shl",
            "polarization",
            "polarization-fixed",
            "roughness",
            "uiso",
            "uiso-common",
            "uiso-fixed",
            "coordinates-cw",
            "coordinates-cw-heavy",
            "coordinates-cw-restrained",
            "coordinates-wo3",
            "coordinates-wo3-W",
            "coordinates-both",
            "texture",
            "uniaxial-strain",
            "angular-zero",
            "background-terms",
            "profile-u",
            "full-range",
        ],
    )
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--passes", type=int, default=2)
    parser.add_argument("--phase-index", type=int, choices=[0, 1])
    parser.add_argument("--axis", nargs=3, type=int)
    parser.add_argument("--uiso", type=float, default=0.005)
    parser.add_argument("--background-terms", type=int, default=8)
    parser.add_argument("--polarization", type=float, default=1.0)
    parser.add_argument("--restraint-weight", type=float, default=100.0)
    args = parser.parse_args()

    output = args.output_gpx.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(args.input_gpx.resolve()), newgpx=str(output))
    hist = project.histogram(0)
    phases = project.phases()
    clear_phase_profile_flags(project)

    if args.mode == "size-strain-wo3":
        hap = phases[1].data["Histograms"][hist.name]
        if hap["Size"][1][0] >= 9.9:
            hap["Size"][1][0] = 0.3
        if abs(hap["Mustrain"][1][0]) < 1.0:
            hap["Mustrain"][1][0] = 500.0
        phases[1].set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    elif args.mode.startswith("strain-"):
        selected = {"strain-cw": [0], "strain-wo3": [1], "strain-both": [0, 1]}[args.mode]
        for idx in selected:
            hap = phases[idx].data["Histograms"][hist.name]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 500.0
            phases[idx].set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    elif args.mode.startswith("size-"):
        selected = {"size-cw": [0], "size-wo3": [1], "size-both": [0, 1]}[args.mode]
        for idx in selected:
            hap = phases[idx].data["Histograms"][hist.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1.0
            phases[idx].set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True}})
    elif args.mode == "shl":
        hist.InstrumentParameters["SH/L"][2] = True
    elif args.mode == "polarization":
        hist.InstrumentParameters["Polariz."][2] = True
    elif args.mode == "polarization-fixed":
        hist.InstrumentParameters["Polariz."][1] = args.polarization
        hist.InstrumentParameters["Polariz."][2] = False
    elif args.mode == "roughness":
        hist.SampleParameters["SurfRoughA"] = [0.2, True]
        hist.SampleParameters["SurfRoughB"] = [0.1, True]
    elif args.mode == "angular-zero":
        hist.SampleParameters["Shift"] = [0.0, False]
        hist.InstrumentParameters["Zero"][1] = 0.0
        hist.InstrumentParameters["Zero"][2] = True
    elif args.mode == "background-terms":
        current = list(hist.Background[0][3:])
        nterms = args.background_terms
        coeffs = (current + [0.0] * nterms)[:nterms]
        hist.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": nterms,
                    "coeffs": coeffs,
                    "refine": True,
                }
            }
        )
    elif args.mode == "profile-u":
        hist.InstrumentParameters["U"][1] = 5.0
        hist.InstrumentParameters["U"][2] = True
    elif args.mode == "full-range":
        x = hist.getdata("x")
        hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    elif args.mode == "uiso":
        for phase in phases:
            phase.set_refinements({"Atoms": {"all": "U"}})
    elif args.mode == "uiso-common":
        selected = [args.phase_index] if args.phase_index is not None else list(range(len(phases)))
        project.index_ids()
        for idx in selected:
            phase = phases[idx]
            for atom in phase.atoms():
                atom.uiso = 0.005
            phase.set_refinements({"Atoms": {"all": "U"}})
            variables = tuple(f"{phase.id}::AUiso:{atom_index}" for atom_index, _ in enumerate(phase.atoms()))
            project.add_EquivConstr(variables)
    elif args.mode == "uiso-fixed":
        selected = [args.phase_index] if args.phase_index is not None else list(range(len(phases)))
        for idx in selected:
            for atom in phases[idx].atoms():
                atom.uiso = args.uiso
            phases[idx].clear_refinements({"Atoms": [atom.label for atom in phases[idx].atoms()]})
    elif args.mode == "texture":
        if args.phase_index is None or args.axis is None:
            raise ValueError("texture mode requires --phase-index and --axis h k l")
        hap = phases[args.phase_index].data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = list(args.axis)
        phases[args.phase_index].set_HAP_refinements({"Pref.Ori.": True})
    elif args.mode == "uniaxial-strain":
        if args.phase_index is None or args.axis is None:
            raise ValueError("uniaxial-strain mode requires --phase-index and --axis h k l")
        hap = phases[args.phase_index].data["Histograms"][hist.name]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 500.0
        hap["Mustrain"][3] = list(args.axis)
        phases[args.phase_index].set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "direction": list(args.axis),
                    "refine": True,
                }
            }
        )
    elif args.mode == "coordinates-cw-heavy":
        phases[0].set_refinements({"Atoms": {"W1": "X", "Co1": "X"}})
    elif args.mode == "coordinates-cw-restrained":
        phase = phases[0]
        phase.set_refinements({"Atoms": {"all": "X"}})
        project.data["Restraints"]["data"].setdefault(
            phase.name,
            {"Bond": {"wtFactor": 1.0, "Range": 1.1, "Bonds": [], "Use": True}},
        )
        phase.clearDistRestraint()
        oxygen = [atom.label for atom in phase.atoms() if atom.element == "O"]
        for distance in (1.775, 1.895, 2.154):
            phase.addDistRestraint(["W1"], oxygen, distance, factor=1.035, ESD=0.03)
        for distance in (2.023, 2.102, 2.157):
            phase.addDistRestraint(["Co1"], oxygen, distance, factor=1.025, ESD=0.03)
        phase.setDistRestraintWeight(args.restraint_weight)
    elif args.mode == "coordinates-wo3-W":
        atom_flags = {atom.label: "X" for atom in phases[1].atoms() if atom.element == "W"}
        phases[1].set_refinements({"Atoms": atom_flags})
    elif args.mode.startswith("coordinates-"):
        selected = {
            "coordinates-cw": [0],
            "coordinates-wo3": [1],
            "coordinates-both": [0, 1],
        }[args.mode]
        for idx in selected:
            phases[idx].set_refinements({"Atoms": {"all": "X"}})

    project.set_Controls("cycles", args.cycles)
    project.save()
    for _ in range(args.passes):
        project.refine()
        project.save()
    result = state(project)
    output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
