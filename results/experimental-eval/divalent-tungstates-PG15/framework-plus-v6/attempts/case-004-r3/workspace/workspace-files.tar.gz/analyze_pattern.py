#!/usr/bin/env python3
"""Exploratory peak inventory and reference-pattern comparison."""

from __future__ import annotations

import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import percentile_filter
from scipy.signal import find_peaks, peak_widths


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"


def load_pattern() -> tuple[np.ndarray, np.ndarray]:
    data = np.genfromtxt(PATTERN, delimiter=",", names=True)
    return data["two_theta_deg"], data["intensity"]


def candidate_structure(path: str, substitutions: dict[str, str] | None = None) -> Structure:
    structure = Structure.from_file(path)
    if substitutions:
        structure.replace_species(substitutions)
    return structure


def main() -> None:
    x, y = load_pattern()
    step = float(np.median(np.diff(x)))
    # A broad rolling percentile gives a robust visualization baseline without
    # changing the measured data used later in refinement.
    baseline = percentile_filter(y, percentile=18, size=401, mode="nearest")
    net = y - baseline
    peaks, props = find_peaks(net, prominence=80, distance=max(2, int(0.06 / step)))
    widths = peak_widths(net, peaks, rel_height=0.5)[0] * step
    order = np.argsort(props["prominences"])[::-1]

    print(f"points={len(x)} range={x[0]:.8f}..{x[-1]:.8f} step={step:.8f}")
    print(
        f"intensity min/median/max={y.min():.1f}/{np.median(y):.1f}/{y.max():.1f}; "
        f"baseline start/middle/end={baseline[0]:.1f}/{baseline[len(x)//2]:.1f}/{baseline[-1]:.1f}"
    )
    print("rank,2theta,intensity,net,prominence,FWHM_deg")
    for rank, idx in enumerate(order[:80], 1):
        p = peaks[idx]
        print(
            f"{rank},{x[p]:.6f},{y[p]:.1f},{net[p]:.1f},"
            f"{props['prominences'][idx]:.1f},{widths[idx]:.4f}"
        )

    candidates = [
        (
            "CoWO4_from_ZnWO4_1520641",
            "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/06/1520641.cif",
            {"Zn": "Co"},
        ),
        (
            "CoWO4_from_FeWO4_1567215",
            "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/56/72/1567215.cif",
            {"Fe": "Co"},
        ),
        (
            "CoWO4_from_MnWO4_1520200",
            "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif",
            {"Mn": "Co"},
        ),
        (
            "CoO_1541662",
            "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/54/16/1541662.cif",
            None,
        ),
        (
            "Co3O4_9005896",
            "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/58/9005896.cif",
            None,
        ),
        (
            "WO3_1528915",
            "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif",
            None,
        ),
        (
            "WO3_2107312",
            "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/10/73/2107312.cif",
            None,
        ),
        (
            "Co2WO4_5910316",
            "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/5/91/03/5910316.cif",
            None,
        ),
    ]

    calc = XRDCalculator(wavelength="CuKa1")
    print("\nCandidate strongest lines (Cu Kalpha1):")
    simulated: list[tuple[str, np.ndarray, np.ndarray]] = []
    for name, path, subs in candidates:
        try:
            structure = candidate_structure(path, subs)
            patt = calc.get_pattern(structure, two_theta_range=(9.8, 100.2))
            sx, sy = np.asarray(patt.x), np.asarray(patt.y)
            simulated.append((name, sx, sy))
            strongest = np.argsort(sy)[::-1][:14]
            lines = " ".join(f"{sx[i]:.3f}({sy[i]:.0f})" for i in strongest)
            print(f"{name}: {structure.composition.reduced_formula}; {lines}")
        except Exception as exc:
            print(f"{name}: ERROR {exc}")

    fig, (ax, ax2) = plt.subplots(2, 1, figsize=(15, 9), sharex=True, gridspec_kw={"height_ratios": [4, 2]})
    ax.plot(x, y, color="black", lw=0.6, label="observed")
    ax.plot(x, baseline, color="tab:orange", lw=1.0, label="rolling 18th-percentile guide")
    ax.set_yscale("symlog", linthresh=500)
    ax.set_ylabel("counts")
    ax.legend(loc="upper right")
    offset = 0.0
    for name, sx, sy in simulated:
        if "CoWO4" in name:
            amp = 1.0
        else:
            amp = 0.55
        ax2.vlines(sx, offset, offset + amp * sy / 100, lw=0.8, label=name)
        offset += 1.15
    ax2.set_ylim(-0.05, offset)
    ax2.set_yticks([])
    ax2.set_xlabel(r"$2\theta$ (deg)")
    ax2.legend(loc="upper right", ncol=2, fontsize=7)
    fig.tight_layout()
    fig.savefig(ROOT / "pattern_inventory.png", dpi=180)

    with (ROOT / "peak_inventory.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "intensity", "net_guide", "prominence", "fwhm_deg"])
        for idx, p in enumerate(peaks):
            writer.writerow([x[p], y[p], net[p], props["prominences"][idx], widths[idx]])


if __name__ == "__main__":
    main()
