#!/usr/bin/env python3
"""Create and refine a trial GSAS-II project for phase-inventory testing.

Run with the GSAS-II Python environment. The script intentionally uses a
restrained nuisance model so that phase candidates are judged comparably.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

PHASES = {
    "cw_co": (ROOT / "models/CoWO4_from_CoMoO4_7205001.cif", "CoWO4_CoMoO4_parent"),
    "cw_zn": (ROOT / "models/CoWO4_from_ZnWO4_1520641.cif", "CoWO4_ZnWO4_parent"),
    "wo3_mono": (COD / "2/31/10/2311041.cif", "WO3_mono_2311041"),
    "wo3_old": (COD / "1/52/89/1528915.cif", "WO3_mono_1528915"),
    "wo3_tri": (COD / "2/10/62/2106293.cif", "WO3_triclinic_2106293"),
    "wo3_hp": (COD / "1/56/35/1563541.cif", "WO3_HP_1563541"),
    "wo3_ortho": (COD / "2/10/73/2107312.cif", "WO3_ortho_2107312"),
    "coo": (COD / "1/54/16/1541662.cif", "CoO_1541662"),
    "co3o4": (COD / "9/00/58/9005896.cif", "Co3O4_9005896"),
}


def write_inputs(outdir: Path) -> tuple[Path, Path]:
    raw = np.genfromtxt(ROOT / "inputs/pattern.csv", delimiter=",", names=True)
    x = np.asarray(raw["two_theta_deg"], float)
    y = np.asarray(raw["intensity"], float)
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = outdir / "pattern.xye"
    np.savetxt(xye, np.column_stack([x, y, sigma]), fmt=["%.8f", "%.8f", "%.8f"])
    inst = outdir / "instrument.instprm"
    inst.write_text(
        "# Trial Cu Kalpha Bragg-Brentano instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def phase_state(phase: G2.G2Phase, histname: str) -> dict:
    hap = phase.data["Histograms"][histname]
    return {
        "name": phase.name,
        "cell": phase.get_cell(),
        "composition": phase.composition,
        "density": phase.density,
        "scale": float(hap["Scale"][0]),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
    }


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:
        fractions = {"error": str(exc)}
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    return {
        "label": label,
        "residuals": hist.residuals,
        "fractions": fractions,
        "instrument": {k: v for k, v in inst.items() if k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "sample": {k: sample.get(k) for k in ("Type", "Gonio. radius", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "background": hist.Background[0],
        "phases": [phase_state(p, hist.name) for p in project.phases()],
        "vary_list": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
        "frozen": project.get_Frozen(),
    }


def refine(project: G2.G2Project, label: str, history: list[dict]) -> None:
    project.set_Controls("cycles", 8)
    project.refine()
    history.append(snapshot(project, label))
    project.save()
    print(label, json.dumps(history[-1], default=float))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("outdir", type=Path)
    parser.add_argument("phases", nargs="+", choices=sorted(PHASES))
    parser.add_argument("--background-terms", type=int, default=8)
    args = parser.parse_args()

    outdir = args.outdir.resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    xye, inst = write_inputs(outdir)
    project = G2.G2Project(newgpx=str(outdir / "trial.gpx"))
    phase_objs = []
    for key in args.phases:
        cif, name = PHASES[key]
        phase_objs.append(project.add_phase(str(cif.resolve()), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(str(xye), str(inst), phases=phase_objs, fmthint="xye")
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": [900.0] + [0.0] * (args.background_terms - 1),
                "refine": True,
            }
        }
    )
    # Neutralize phase-specific nuisance terms before inventory comparison.
    for phase in phase_objs:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Extinction"] = [0.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]

    project.save()
    history: list[dict] = [snapshot(project, "initial")]

    # Smooth background and all scales first.
    refine(project, "background_scales", history)

    # One physically meaningful angular correction for reflection geometry.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phase_objs:
        # A zero-scale candidate must not be allowed to destroy its cell and
        # destabilize the common nuisance model. It can be challenged again
        # in a separate trial with a physical alternate record.
        hap_scale = phase.data["Histograms"][hist.name]["Scale"][0]
        phase.set_refinements({"Cell": bool(hap_scale > 1e-8)})
    refine(project, "shift_cells", history)

    # Common nonnegative low-dimensional peak-width model. A simultaneous
    # unconstrained U/W/X trial drives U negative for this pattern, so use the
    # physical boundary U=0 and refine W/X; V, Y and Z remain zero.
    hist.InstrumentParameters["U"][1] = 0.0
    hist.InstrumentParameters["U"][2] = False
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(project, "common_profile", history)

    # Re-converge the coupled baseline once more.
    refine(project, "reconverged", history)

    (outdir / "history.json").write_text(json.dumps(history, indent=2, default=float) + "\n")
    project.save()


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
