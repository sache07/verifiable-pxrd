#!/usr/bin/env python3
"""Export plots and residual/reflection diagnostics from a GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpwd as G2pwd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    outdir = args.outdir.resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    project = G2.G2Project(str(args.gpx.resolve()))
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("x"), float)
    y = np.asarray(hist.getdata("yobs"), float)
    yc = np.asarray(hist.getdata("ycalc"), float)
    bkg = np.asarray(hist.getdata("background"), float)
    residual = y - yc
    sigma = np.sqrt(np.maximum(y, 1.0))
    z = residual / sigma

    np.savetxt(
        outdir / "profile.csv",
        np.column_stack([x, y, yc, residual, bkg, z]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background,standardized_difference",
        comments="",
    )

    refl_rows = []
    for phase_name, refdict in hist.reflections().items():
        supercell = refdict.get("Super", False)
        for ref in refdict["RefList"]:
            if supercell:
                h, k, l, m, mult, dsp, pos, sigv, gam, fobs, fcalc, phasev, icorr, prfo = ref[:14]
                hkl = [int(h), int(k), int(l), int(m)]
            else:
                h, k, l, mult, dsp, pos, sigv, gam, fobs, fcalc, phasev, icorr, prfo = ref[:13]
                hkl = [int(h), int(k), int(l)]
            gaussian = np.sqrt(max(sigv, 0.0001)) / 100.0
            lorentzian = gam / 100.0
            fwhm = G2pwd.getgamFW(lorentzian, gaussian)
            refl_rows.append(
                {
                    "phase": phase_name,
                    "hkl": hkl,
                    "d_A": float(dsp),
                    "two_theta_deg": float(pos),
                    "multiplicity": int(mult),
                    "Fobs2": float(fobs),
                    "Fcalc2": float(fcalc),
                    "profile_intensity_factor": float(phasev),
                    "intensity_correction": float(icorr),
                    "preferred_orientation_factor": float(prfo),
                    "fwhm_deg": float(fwhm),
                }
            )
    (outdir / "reflections.json").write_text(json.dumps(refl_rows, indent=2) + "\n")

    def extrema(values: np.ndarray, sign: int) -> list[tuple[int, float]]:
        target = sign * values
        found = []
        for idx in range(10, len(target) - 10):
            if target[idx] < 2.0 or target[idx] != np.max(target[idx - 3 : idx + 4]):
                continue
            shoulder = max(np.min(target[idx - 10 : idx]), np.min(target[idx + 1 : idx + 11]))
            prominence = target[idx] - shoulder
            if prominence >= 2.0:
                found.append((idx, float(prominence)))
        return found

    positive = extrema(z, 1)
    negative = extrema(z, -1)
    residual_rows = []
    for sign, found in ((1, positive), (-1, negative)):
        for idx, prom in found:
            nearby = sorted(
                (r for r in refl_rows if abs(r["two_theta_deg"] - x[idx]) <= 0.25),
                key=lambda r: abs(r["two_theta_deg"] - x[idx]),
            )[:8]
            residual_rows.append(
                {
                    "sign": sign,
                    "two_theta_deg": float(x[idx]),
                    "difference_counts": float(residual[idx]),
                    "standardized_difference": float(z[idx]),
                    "prominence_sigma": float(prom),
                    "nearby_reflections": nearby,
                }
            )
    residual_rows.sort(key=lambda r: r["prominence_sigma"], reverse=True)
    (outdir / "residual_peaks.json").write_text(json.dumps(residual_rows, indent=2) + "\n")

    print("R factors", hist.residuals)
    print("Mass fractions", hist.ComputeMassFracs())
    print("Top residual extrema")
    for row in residual_rows[:40]:
        assignments = "; ".join(
            f"{r['phase']} {r['hkl']} @{r['two_theta_deg']:.3f}"
            for r in row["nearby_reflections"][:3]
        )
        print(
            f"{row['sign']:+d} {row['two_theta_deg']:.4f} "
            f"z={row['standardized_difference']:.2f} prom={row['prominence_sigma']:.2f} {assignments}"
        )

if __name__ == "__main__":
    G2.SetPrintLevel("error")
    main()
