"""Re-introduce BaWO4 into the converged inventory and refine its scale only."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_screen import summarize


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "analysis/final_trials/ba_uiso_p09291.gpx"
OUTPUT = ROOT / "analysis/final_trials/watch_bawo4.gpx"
MODEL = ROOT / "analysis/source_pool/pool/models/bawo4_1527204.cif"


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(INPUT), newgpx=str(OUTPUT))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(MODEL),
        phasename="BaWO4_watch",
        fmthint="CIF",
        histograms=[hist],
    )
    hap = phase.data["Histograms"][hist.name]

    # Start at 1 wt% relative to the established crystalline inventory.
    established_mass_scale = sum(
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()[:-1]
    )
    hap["Scale"] = [0.01 * established_mass_scale / phase.data["General"]["Mass"], True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1000.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    phase.set_refinements({"Cell": False})
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    project.set_Controls("cycles", 5)

    project.refine()
    project.refine()
    result = summarize(project, hist, "bawo4_watch_rechallenge")
    result["watch_source"] = str(MODEL.relative_to(ROOT))
    result["new_phase_cell_refined"] = False
    project.save()
    OUTPUT.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
