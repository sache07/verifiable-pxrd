"""Build a restrained GSAS-II screening refinement for a candidate phase set."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, minimum_filter1d
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def initial_background(x: np.ndarray, y: np.ndarray, degree: int = 7) -> list[float]:
    smoothed = gaussian_filter1d(y, 2.0)
    envelope = minimum_filter1d(smoothed, size=301, mode="nearest")
    envelope = gaussian_filter1d(envelope, 80.0)
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, envelope, degree).tolist()


def rwp_from_arrays(hist) -> float:
    data = hist.data["data"][1]
    y, w, calc = (np.asarray(data[i], float) for i in (1, 2, 3))
    return float(100.0 * np.sqrt(np.sum(w * (y - calc) ** 2) / np.sum(w * y**2)))


def summarize(project, hist, stage: str) -> dict:
    inst = hist.data["Instrument Parameters"][0]
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(mass_scale, 0.0))
        phases.append(
            {
                "name": phase.name,
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
                "scale": float(hap["Scale"][0]),
                "mass_scale": mass_scale,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / total if total > 0 else None
    result = {
        "stage": stage,
        "rwp": rwp_from_arrays(hist),
        "gsas_wR": hist.get_wR(),
        "instrument": {key: float(inst[key][1]) for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")},
        "sample": {
            key: hist.SampleParameters[key][0]
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": phases,
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(result, indent=2))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("phase", nargs="+", help="COD_ID or COD_ID:phase_name")
    parser.add_argument("--no-profile", action="store_true")
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()

    outdir = ROOT / "analysis" / "screens" / args.label
    outdir.mkdir(parents=True, exist_ok=True)
    gpx = outdir / "screen.gpx"

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(gpx))
    phases = []
    for item in args.phase:
        cod_id, _, name = item.partition(":")
        source = Path(cod_id)
        if not source.is_file():
            source = cod_path(cod_id)
        phases.append(
            project.add_phase(
                str(source.resolve()),
                phasename=name or cod_id,
                fmthint="CIF",
            )
        )
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "analysis" / "initial.instprm"),
        phases=phases,
        fmthint="comma",
    )

    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    for key, value in (("Shift", 0.0), ("Transparency", 0.0), ("SurfRoughA", 0.0), ("SurfRoughB", 0.0)):
        hist.SampleParameters[key] = [value, False]

    x, y = (np.asarray(hist.data["data"][1][i], float) for i in (0, 1))
    coeffs = initial_background(x, y)
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(coeffs),
                "coeffs": coeffs,
                "refine": True,
            },
        }
    )

    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [50.0 / float(phase.data["General"]["Mass"]), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1000.0
        hap["Size"][1][1] = 1000.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    project.set_Controls("cycles", 5)
    hid = hist.id
    project.set_Controls("parmMin", -0.5, variable=f":{hid}:Zero")
    project.set_Controls("parmMax", 0.5, variable=f":{hid}:Zero")
    for key, lo, hi in (("U", 0.0, 80.0), ("W", 0.1, 80.0), ("X", 0.0, 15.0)):
        project.set_Controls("parmMin", lo, variable=f":{hid}:{key}")
        project.set_Controls("parmMax", hi, variable=f":{hid}:{key}")
    for phase in phases:
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hid}:Scale")

    records = []
    project.refine()
    records.append(summarize(project, hist, "background_scales"))

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    project.refine()
    records.append(summarize(project, hist, "zero"))

    if args.quick:
        project.save()
        (outdir / "summary.json").write_text(json.dumps(records, indent=2) + "\n")
        return

    if not args.no_profile:
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        project.refine()
        project.refine()
        records.append(summarize(project, hist, "zero_common_profile"))

    for phase in phases:
        phase.set_refinements({"Cell": True})
        project.refine()
    project.refine()
    records.append(summarize(project, hist, "zero_cells_common_profile"))

    project.save()
    (outdir / "summary.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
