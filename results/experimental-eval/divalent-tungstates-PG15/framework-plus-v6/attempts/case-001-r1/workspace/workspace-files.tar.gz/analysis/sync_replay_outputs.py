"""Make the public curve/statistics exactly match the verified native replay."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
REPLAY = ROOT / "analysis/replay_final"


def main() -> None:
    report = json.loads((REPLAY / "replay.json").read_text())
    if report.get("status") != "replayed" or report.get("profile_review_flags"):
        raise RuntimeError("final project did not pass clean native replay")
    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as data:
        x = data["x"].copy()
        y = data["observed"].copy()
        calculated = data["predicted"].copy()
        background = data["background"].copy()
    residual = y - calculated
    weights = 1.0 / np.maximum(y, 1.0)
    chi_square = float(np.sum(weights * residual**2))
    denominator = float(np.sum(weights * y**2))

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, y, calculated, residual, background]),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.10g", "%.12g", "%.12g", "%.12g"],
    )

    result = json.loads((ROOT / "result.json").read_text())
    result["fit_statistics"].update(
        {
            "rwp_percent": 100.0 * float(np.sqrt(chi_square / denominator)),
            "rp_percent": 100.0 * float(np.sum(np.abs(residual)) / np.sum(np.abs(y))),
            "chi_square": chi_square,
            "profile_source": "parameter-free native replay of final.gpx",
        }
    )
    result["replay_validation"] = {
        "status": report["status"],
        "project_sha256": report["project_sha256"],
        "parameters_optimized": report["parameters_optimized"],
        "project_unchanged": report["project_unchanged"],
        "evaluation_grid": report["evaluation_grid"],
        "profile_review_flags": report["profile_review_flags"],
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
