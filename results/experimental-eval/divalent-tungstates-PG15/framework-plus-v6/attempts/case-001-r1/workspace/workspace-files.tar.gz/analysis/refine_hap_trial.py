"""Compare restrained phase-broadening terms from a common GSAS-II baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_screen import summarize


def indices(text: str | None) -> set[int]:
    if not text:
        return set()
    return {int(v) for v in text.split(",")}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("--size", help="comma-separated phase indices")
    parser.add_argument("--strain", help="comma-separated phase indices")
    parser.add_argument("--size-start", type=float, default=0.3)
    parser.add_argument("--strain-start", type=float, default=1500.0)
    parser.add_argument("--profile", action="store_true", help="refine bounded common U/W/X")
    parser.add_argument("--wx", action="store_true", help="refine bounded common W/X with U fixed")
    parser.add_argument("--w", action="store_true", help="refine bounded common W only")
    parser.add_argument("--fix-x", type=float, help="fix the Lorentzian X profile term")
    parser.add_argument("--shl", action="store_true", help="refine bounded axial-divergence SH/L")
    parser.add_argument("--texture", action="append", default=[], help="PHASE:h,k,l March-Dollase trial")
    parser.add_argument("--polarization", action="store_true", help="refine bounded polarization")
    parser.add_argument("--roughness", action="store_true", help="refine bounded Suortti A/B roughness")
    parser.add_argument("--uniaxial", action="append", default=[], help="PHASE:h,k,l microstrain trial")
    args = parser.parse_args()

    output = Path(args.output_gpx).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input_gpx).resolve()), newgpx=str(output))
    hist = project.histogram(0)
    size_phases = indices(args.size)
    strain_phases = indices(args.strain)
    texture_trials = []
    for specification in args.texture:
        phase_text, axis_text = specification.split(":", 1)
        axis = [int(value) for value in axis_text.split(",")]
        if len(axis) != 3 or not any(axis):
            raise ValueError("texture axis must be a nonzero h,k,l triple")
        texture_trials.append((int(phase_text), axis))
    uniaxial_trials = []
    for specification in args.uniaxial:
        phase_text, axis_text = specification.split(":", 1)
        axis = [int(value) for value in axis_text.split(",")]
        if len(axis) != 3 or not any(axis):
            raise ValueError("uniaxial axis must be a nonzero h,k,l triple")
        uniaxial_trials.append((int(phase_text), axis))

    instrument = hist.data["Instrument Parameters"][0]
    if args.fix_x is not None:
        instrument["X"][0] = float(args.fix_x)
        instrument["X"][1] = float(args.fix_x)
        instrument["X"][2] = False
        project.set_Frozen(variable=f":{hist.id}:X", mode="remove")
    if args.profile:
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        for key, lo, hi in (("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0)):
            project.set_Controls("parmMin", lo, variable=f":{hist.id}:{key}")
            project.set_Controls("parmMax", hi, variable=f":{hist.id}:{key}")
    if args.wx:
        hist.set_refinements({"Instrument Parameters": ["W", "X"]})
        for key, lo, hi in (("W", 2.0, 40.0), ("X", 0.1, 6.0)):
            project.set_Controls("parmMin", lo, variable=f":{hist.id}:{key}")
            project.set_Controls("parmMax", hi, variable=f":{hist.id}:{key}")
    if args.w:
        hist.set_refinements({"Instrument Parameters": ["W"]})
        project.set_Controls("parmMin", 2.0, variable=f":{hist.id}:W")
        project.set_Controls("parmMax", 40.0, variable=f":{hist.id}:W")
    if args.shl:
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.set_Controls("parmMin", 0.005, variable=f":{hist.id}:SH/L")
        project.set_Controls("parmMax", 0.1, variable=f":{hist.id}:SH/L")
    if args.polarization:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.5, variable=f":{hist.id}:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=f":{hist.id}:Polariz.")
    if args.roughness:
        hist.SampleParameters["SurfRoughA"][0] = 0.3
        hist.SampleParameters["SurfRoughB"][0] = 0.1
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        for key, lo, hi in (("SurfRoughA", 0.05, 0.6), ("SurfRoughB", 0.02, 0.5)):
            project.set_Controls("parmMin", lo, variable=f":{hist.id}:{key}")
            project.set_Controls("parmMax", hi, variable=f":{hist.id}:{key}")

    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        if index in size_phases:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = args.size_start
            hap["Size"][2][0] = True
            project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:{hist.id}:Size;i")
            project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:{hist.id}:Size;i")
        if index in strain_phases:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = args.strain_start
            hap["Mustrain"][2][0] = True
            project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")
            project.set_Controls("parmMax", 20000.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")
        for texture_phase, axis in texture_trials:
            if index != texture_phase:
                continue
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = axis
            project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:{hist.id}:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:{hist.id}:MD")
        for strain_phase, axis in uniaxial_trials:
            if index != strain_phase:
                continue
            start = max(float(hap["Mustrain"][1][0]), 300.0)
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][0] = start
            hap["Mustrain"][1][1] = start
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][1] = True
            hap["Mustrain"][3] = axis
            for suffix in ("i", "a"):
                project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;{suffix}")
                project.set_Controls("parmMax", 20000.0, variable=f"{phase.id}:{hist.id}:Mustrain;{suffix}")

    project.set_Controls("cycles", 5)
    project.refine()
    project.refine()
    result = summarize(project, hist, "hap_trial")
    result["size_phase_indices"] = sorted(size_phases)
    result["strain_phase_indices"] = sorted(strain_phases)
    result["profile_refined"] = args.profile
    result["wx_refined"] = args.wx
    result["w_refined"] = args.w
    result["fixed_x"] = args.fix_x
    result["shl_refined"] = args.shl
    result["texture_trials"] = [{"phase_index": phase, "axis": axis} for phase, axis in texture_trials]
    result["polarization_refined"] = args.polarization
    result["roughness_refined"] = args.roughness
    result["uniaxial_trials"] = [{"phase_index": phase, "axis": axis} for phase, axis in uniaxial_trials]
    project.save()
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
