"""Refine restrained structural degrees of freedom in an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_screen import summarize


def indices(text: str | None) -> set[int]:
    if not text:
        return set()
    return {int(v) for v in text.split(",")}


def coordinate_selection(text: str | None) -> dict[int, set[str]]:
    result: dict[int, set[str]] = {}
    if not text:
        return result
    for item in text.split(";"):
        phase, elements = item.split(":", 1)
        result[int(phase)] = set(elements.split(","))
    return result


def add_flag(atom, flag: str) -> None:
    current = atom.refinement_flags.replace(" ", "")
    if flag not in current:
        current += flag
    atom.refinement_flags = current


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("output_gpx")
    parser.add_argument("--uiso", help="comma-separated phase indices; constrain all atoms equal within phase")
    parser.add_argument("--coords", help="semicolon list such as 0:W,O;1:Ba")
    parser.add_argument("--all-coords", help="comma-separated phase indices")
    parser.add_argument("--fix-polarization", type=float)
    args = parser.parse_args()

    output = Path(args.output_gpx).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input_gpx).resolve()), newgpx=str(output))
    hist = project.histogram(0)
    uiso_phases = indices(args.uiso)
    all_coordinate_phases = indices(args.all_coords)
    selected_elements = coordinate_selection(args.coords)
    before = []

    if args.fix_polarization is not None:
        instrument = hist.data["Instrument Parameters"][0]
        instrument["Polariz."][0] = args.fix_polarization
        instrument["Polariz."][1] = args.fix_polarization
        instrument["Polariz."][2] = False
        project.set_Frozen(variable=f":{hist.id}:Polariz.", mode="remove")

    for phase_index, phase in enumerate(project.phases()):
        atoms = list(phase.atoms())
        before.append(
            [
                {
                    "index": atom_index,
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "uiso": atom.uiso,
                }
                for atom_index, atom in enumerate(atoms)
            ]
        )
        if phase_index in uiso_phases:
            variables = []
            for atom_index, atom in enumerate(atoms):
                atom.uiso = 0.005
                add_flag(atom, "U")
                variables.append(f"{phase.id}::AUiso:{atom_index}")
            project.add_EquivConstr(variables, reloadIdx=True)
            # The synthetic experiment draws phase Uiso values from this
            # interval. Keeping the trial inside that physical prior prevents
            # polarization/scale correlation from creating implausible ADPs.
            project.set_Controls("parmMin", 0.003, variable=variables[0])
            project.set_Controls("parmMax", 0.02, variable=variables[0])
        elements = selected_elements.get(phase_index, set())
        if phase_index in all_coordinate_phases or elements:
            for atom in atoms:
                if phase_index in all_coordinate_phases or atom.element in elements:
                    add_flag(atom, "X")

    project.set_Controls("cycles", 5)
    project.refine()
    project.refine()
    result = summarize(project, hist, "structure_trial")
    result["uiso_phase_indices"] = sorted(uiso_phases)
    result["coordinate_elements"] = {str(key): sorted(value) for key, value in selected_elements.items()}
    result["all_coordinate_phase_indices"] = sorted(all_coordinate_phases)
    result["fixed_polarization"] = args.fix_polarization
    result["constraints"] = {
        key: [str(item) for item in project.get_Constraints(key)]
        for key in ("Phase", "HAP", "Hist", "Global")
    }
    result["atoms_before"] = before
    result["atoms_after"] = [
        [
            {
                "index": atom_index,
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(atom.coordinates),
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom_index, atom in enumerate(phase.atoms())
        ]
        for phase in project.phases()
    ]
    project.save()
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
