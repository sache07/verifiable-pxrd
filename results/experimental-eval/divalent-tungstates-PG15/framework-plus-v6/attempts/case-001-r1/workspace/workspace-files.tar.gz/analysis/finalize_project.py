"""Converge, reopen, export and summarize the selected two-phase GSAS-II model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/final_trials/ba_uiso_p09291.gpx"
FINAL = ROOT / "final.gpx"


def profile_statistics(hist, project) -> dict:
    arrays = hist.data["data"][1]
    y, w, calculated = (np.asarray(arrays[i], float) for i in (1, 2, 3))
    residual = y - calculated
    denominator = float(np.sum(w * y**2))
    chi_square = float(np.sum(w * residual**2))
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return {
        "rwp_percent": 100.0 * float(np.sqrt(chi_square / denominator)),
        "rp_percent": 100.0 * float(np.sum(np.abs(residual)) / np.sum(np.abs(y))),
        "chi_square": chi_square,
        "goodness_of_fit": float(rvals.get("GOF", np.nan)),
        "n_points": int(len(y)),
        "n_refined_parameters": int(rvals.get("Nvars", len(covariance.get("varyList", [])))),
        "weighting": "1/max(observed_counts,1)",
    }


def cell_record(phase) -> dict:
    a, b, c, alpha, beta, gamma, volume = map(float, phase.data["General"]["Cell"][1:])
    return {
        "a_angstrom": a,
        "b_angstrom": b,
        "c_angstrom": c,
        "alpha_deg": alpha,
        "beta_deg": beta,
        "gamma_deg": gamma,
        "volume_angstrom3": volume,
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    project.set_Controls("cycles", 5)
    for _ in range(3):
        project.refine()
        shift = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("Max shft/sig", 0.0)
        if np.isfinite(shift) and shift < 0.1:
            break
    project.save()

    # Required replay-stability check: reopen the serialized project and run a
    # final full-range least-squares pass before any exports are made.
    project = G2.G2Project(gpxfile=str(FINAL))
    project.set_Controls("cycles", 5)
    project.refine()
    project.save()
    project = G2.G2Project(gpxfile=str(FINAL))
    hist = project.histogram(0)

    if len(project.phases()) != 2 or {p.name for p in project.phases()} != {"WO3", "BaCO3"}:
        raise RuntimeError("final inventory differs from selected two-phase model")

    exports = {"WO3": "phase_WO3.cif", "BaCO3": "phase_BaCO3.cif"}
    formulas = {"WO3": "WO3", "BaCO3": "BaCO3"}
    mass_scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scales.append(float(phase.data["General"]["Mass"] * hap["Scale"][0]))
        phase.export_CIF(str(ROOT / exports[phase.name]))
    total = sum(mass_scales)

    phases = []
    for phase, mass_scale in zip(project.phases(), mass_scales):
        phases.append(
            {
                "name": phase.name,
                "formula": formulas[phase.name],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": exports[phase.name],
                "weight_fraction": mass_scale / total,
                "cell": cell_record(phase),
            }
        )

    arrays = hist.data["data"][1]
    x, y, calculated, background = (np.asarray(arrays[i], float) for i in (0, 1, 3, 4))
    curve = np.column_stack([x, y, calculated, y - calculated, background])
    np.savetxt(
        ROOT / "fit.csv",
        curve,
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.10g", "%.12g", "%.12g", "%.12g"],
    )

    result = {
        "schema_version": 1,
        "phases": phases,
        "fit_statistics": profile_statistics(hist, project),
        "refinement_histogram": hist.name,
        "project_path": "final.gpx",
        "fraction_basis": "normalized over the modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
