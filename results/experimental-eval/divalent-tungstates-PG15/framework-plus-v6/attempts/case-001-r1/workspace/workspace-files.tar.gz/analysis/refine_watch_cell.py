"""Test positional coherence of the weak BaWO4 watch-list contribution."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_screen import summarize


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis/final_trials/watch_bawo4.gpx"
OUTPUT = ROOT / "analysis/final_trials/watch_bawo4_cell.gpx"


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT))
    hist = project.histogram(0)
    phase = project.phases()[2]
    phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 5)
    project.refine()
    project.refine()
    result = summarize(project, hist, "bawo4_watch_cell")
    project.save()
    OUTPUT.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
