from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
G2.SetPrintLevel("warn")
project = G2.G2Project(newgpx=str(ROOT / "analysis" / "import_test.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "analysis" / "initial.instprm"),
    fmthint="comma",
)
print(hist.name)
print(len(hist.data["data"][1][0]))
print(hist.data["data"][1][0][0], hist.data["data"][1][0][-1])
print(hist.data["data"][1][1][0], hist.data["data"][1][2][0])
print(hist.SampleParameters)
print(hist.data["Instrument Parameters"][0])
project.save()
