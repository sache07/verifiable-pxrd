"""Build a replay-stable, physically bounded two-phase refinement baseline."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "clean_two_phase.gpx"


def lattice_matrix(cell: dict) -> np.ndarray:
    a, b, c = (cell["length_a"], cell["length_b"], cell["length_c"])
    alpha, beta, gamma = np.radians([cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]])
    cy = (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)
    return np.array([
        [a, 0.0, 0.0],
        [b * np.cos(gamma), b * np.sin(gamma), 0.0],
        [c * np.cos(beta), c * cy, c * np.sqrt(1.0 - np.cos(beta) ** 2 - cy ** 2)],
    ])


def regularized_coordinates(project: G2.G2Project) -> dict:
    source = G2.G2Project(gpxfile=str(ROOT / "model_precoords.gpx")).phase("WO3_2106293")
    w_trial = G2.G2Project(gpxfile=str(ROOT / "model_wcoords_fixedrough.gpx")).phase("WO3_2106293")
    o_trial = G2.G2Project(gpxfile=str(ROOT / "model_allcoords.gpx")).phase("WO3_2106293")
    source_coords = {a.label: np.asarray(a.coordinates, float) for a in source.atoms()}
    targets = {
        "W": {a.label: np.asarray(a.coordinates, float) for a in w_trial.atoms()},
        "O": {a.label: np.asarray(a.coordinates, float) for a in o_trial.atoms()},
    }
    desired_rms = {"W": 0.040, "O": 0.050}
    lattice = lattice_matrix(source.get_cell())
    report = {}
    phase = project.phase("WO3_2106293")
    for element in ["W", "O"]:
        atoms = [a for a in phase.atoms() if a.element == element]
        deltas = []
        for atom in atoms:
            delta = targets[element][atom.label] - source_coords[atom.label]
            delta -= np.rint(delta)
            deltas.append(delta)
        cart = np.asarray(deltas) @ lattice
        raw_rms = float(np.sqrt(np.mean(np.sum(cart * cart, axis=1))))
        factor = min(1.0, desired_rms[element] / raw_rms)
        for atom, delta in zip(atoms, deltas):
            atom.coordinates = (source_coords[atom.label] + factor * delta) % 1.0
        report[element] = {"unconstrained_mode_rms_A": raw_rms,
                           "retained_fraction": factor,
                           "retained_rms_A": raw_rms * factor}
    return report


def refine_stage(project: G2.G2Project, label: str) -> G2.G2Project:
    project.save(str(OUTPUT))
    project.refine(printFile=str(ROOT / f"clean_{label}.lst"))
    return G2.G2Project(gpxfile=str(OUTPUT))


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(ROOT / "o_shrinkage" / "fraction_0.268.gpx"))
    coordinate_report = regularized_coordinates(project)
    wo3 = project.phase("WO3_2106293")
    mno2 = project.phase("MnO2_1514110")
    hist = project.histograms()[0]

    # Retain the supported phase-average Uiso estimate for MnO2 and the
    # registered WO3 value, but do not let either trade against polarization.
    for atom in wo3.atoms():
        atom.uiso = 0.005
        atom.refinement_flags = ""
    for atom in mno2.atoms():
        atom.uiso = 0.018124672075477945
        atom.refinement_flags = ""
    project.data["Constraints"]["data"]["Phase"] = []

    # Neutralize the now-unsupported WO3 size term; retain only the accepted
    # strain terms and rutile texture. A fixed X=6 is the physical profile cap.
    wo_hap = wo3.data["Histograms"][hist.name]
    mn_hap = mno2.data["Histograms"][hist.name]
    wo_hap["Size"][0] = "isotropic"
    wo_hap["Size"][1][0] = 10.0
    wo_hap["Size"][2] = [False, False, False]
    mn_hap["Size"][0] = "isotropic"
    mn_hap["Size"][1][0] = 10.0
    mn_hap["Size"][2] = [False, False, False]
    wo_hap["Mustrain"][0] = "uniaxial"
    wo_hap["Mustrain"][3] = [0, 0, 1]
    wo_hap["Mustrain"][2][:2] = [False, False]
    mn_hap["Mustrain"][0] = "isotropic"
    mn_hap["Mustrain"][1][0] = max(300.0, float(mn_hap["Mustrain"][1][0]))
    mn_hap["Mustrain"][2][:2] = [False, False]
    mn_hap["Pref.Ori."][0] = "MD"
    mn_hap["Pref.Ori."][3] = [1, 1, 0]
    mn_hap["Pref.Ori."][2] = False

    inst = hist.data["Instrument Parameters"][0]
    inst["U"] = [0.0, 0.0, False]
    inst["X"] = [6.0, 6.0, False]
    inst["SH/L"] = [0.03, 0.03, False]
    inst["W"][2] = True
    inst["Polariz."][2] = True
    hist.SampleParameters["SurfRoughA"] = [0.2, False]
    hist.SampleParameters["SurfRoughB"] = [0.138, False]
    hist.SampleParameters["Shift"][1] = True
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True}, [hist])

    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.02
    for variable, lower, upper in [
        (":0:W", 0.0, 80.0), (":0:Polariz.", 0.5, 1.0),
        (":0:Shift", -800.0, 800.0),
        ("0:0:Scale", 0.0, 1e6), ("1:0:Scale", 0.0, 1e6),
        ("0:0:Mustrain;i", 300.0, 8000.0), ("0:0:Mustrain;a", 300.0, 8000.0),
        ("1:0:Mustrain;i", 300.0, 8000.0), ("1:0:MD", 0.7, 1.4),
    ]:
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    # First reconverge the common baseline with phase-specific broadening held.
    project = refine_stage(project, "common")
    hist = project.histograms()[0]
    wo3 = project.phase("WO3_2106293")
    mno2 = project.phase("MnO2_1514110")
    wo_hap = wo3.data["Histograms"][hist.name]
    mn_hap = mno2.data["Histograms"][hist.name]
    wo_hap["Mustrain"][2][:2] = [True, True]
    mn_hap["Mustrain"][2][:2] = [True, False]
    mn_hap["Pref.Ori."][2] = True
    project = refine_stage(project, "phase_profile")
    project = refine_stage(project, "replay")
    project.save(str(OUTPUT))

    hist = project.histograms()[0]
    report = {
        "Rwp_percent": float(hist.get_wR()),
        "coordinate_regularization": coordinate_report,
        "frozen": [str(v) for v in project.get_Frozen()],
        "instrument": {k: hist.data["Instrument Parameters"][0][k][1]
                       for k in ["U", "W", "X", "SH/L", "Polariz."]},
        "phases": [],
    }
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(phase.data["General"]["Mass"] * hap["Scale"][0])
        report["phases"].append({"name": phase.name, "cell": phase.get_cell(),
                                 "scale": hap["Scale"][0], "size": hap["Size"],
                                 "mustrain": hap["Mustrain"], "texture": hap["Pref.Ori."]})
    masses = np.asarray(masses)
    report["fractions"] = (masses / masses.sum()).tolist()
    (ROOT / "clean_two_phase.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
