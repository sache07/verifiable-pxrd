"""Plot arrays exported by diagnose_final.py in an environment with matplotlib."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
data = np.load(ROOT / "final_arrays.npz")
x, y = data["two_theta"], data["observed"]
calc, diff = data["calculated"], data["difference"]

fig = plt.figure(figsize=(14, 10), constrained_layout=True)
grid = fig.add_gridspec(4, 1, height_ratios=[1.2, 1, 1, 1])
axes = [fig.add_subplot(grid[i, 0]) for i in range(4)]
axes[0].plot(x, y, color="black", lw=0.45, label="observed")
axes[0].plot(x, calc, color="#d62728", lw=0.7, label="calculated")
axes[0].plot(x, diff - 900, color="#1f77b4", lw=0.45, label="difference − 900")
axes[0].set_xlim(x.min(), x.max())
axes[0].set_ylim(-1500, max(y.max() * 1.03, 2000))
axes[0].set_ylabel("counts")
axes[0].legend(loc="upper right", ncol=3, fontsize=8)
for axis, (low, high) in zip(axes[1:], [(15, 35), (35, 65), (65, 95)]):
    mask = (x >= low) & (x <= high)
    axis.plot(x[mask], y[mask], color="black", lw=0.55)
    axis.plot(x[mask], calc[mask], color="#d62728", lw=0.75)
    offset = min(y[mask]) - 250
    axis.plot(x[mask], diff[mask] + offset, color="#1f77b4", lw=0.5)
    axis.axhline(offset, color="0.7", lw=0.4)
    axis.set_xlim(low, high)
    axis.set_ylabel("counts")
axes[-1].set_xlabel(r"$2\theta$ (degrees, Cu K$\alpha$)")
fig.suptitle("Four-phase GSAS-II fit and difference profile", fontsize=13)
fig.savefig(ROOT / "final_diagnostic.png", dpi=180)
