"""Independent numerical and visual diagnostics for the selected project."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final_candidate.gpx"


def main() -> None:
    project = G2.G2Project(gpxfile=str(PROJECT))
    hist = project.histograms()[0]
    x, y, stored_w, calc, bkg, stored_diff = [np.asarray(a, float) for a in hist.data["data"][1]]
    weights = 1.0 / np.maximum(y, 1.0)
    diff = y - calc
    chi2 = float(np.sum(weights * diff * diff))
    denominator = float(np.sum(weights * y * y))
    cov = project.data.get("Covariance", {}).get("data", {})
    nvars = int(cov.get("Rvals", {}).get("Nvars", len(cov.get("varyList", []))))
    metrics = {
        "n_points": int(len(x)),
        "n_variables": nvars,
        "Rwp_percent_independent": 100.0 * float(np.sqrt(chi2 / denominator)),
        "Rp_percent": 100.0 * float(np.sum(np.abs(diff)) / np.sum(y)),
        "chi_square": chi2,
        "reduced_chi_square": chi2 / (len(x) - nvars),
        "GOF": float(np.sqrt(chi2 / (len(x) - nvars))),
        "background_min_counts": float(bkg.min()),
        "background_max_counts": float(bkg.max()),
        "calculated_min_counts": float(calc.min()),
        "stored_difference_max_abs_error": float(np.max(np.abs(stored_diff - diff))),
        "segments": {},
        "phases": [],
    }
    for label, low, high in [("low", x.min(), 35), ("middle", 35, 65), ("high", 65, x.max() + 1e-6)]:
        mask = (x >= low) & (x < high)
        metrics["segments"][label] = {
            "Rwp_percent": 100.0 * float(np.sqrt(np.sum(weights[mask] * diff[mask] ** 2)
                                                  / np.sum(weights[mask] * y[mask] ** 2))),
            "normalized_residual_mean": float(np.mean(diff[mask] / np.sqrt(np.maximum(y[mask], 1.0)))),
            "normalized_residual_rms": float(np.sqrt(np.mean(diff[mask] ** 2 / np.maximum(y[mask], 1.0)))),
        }
    mass = np.array([p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
                     for p in project.phases()])
    sigmas = {str(v): float(s) for v, s in zip(cov.get("varyList", []), cov.get("sig", []))}
    for phase, fraction in zip(project.phases(), mass / mass.sum()):
        hap = phase.data["Histograms"][hist.name]
        scale = float(hap["Scale"][0])
        sigma = sigmas.get(f"{phase.id}:0:Scale")
        metrics["phases"].append({
            "name": phase.name,
            "weight_fraction": float(fraction),
            "scale": scale,
            "scale_esd": sigma,
            "scale_over_esd": None if sigma is None else scale / sigma,
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        })
    matrix = np.asarray(cov.get("covMatrix", []), float)
    variables = [str(v) for v in cov.get("varyList", [])]
    top_corr = []
    if matrix.ndim == 2 and matrix.shape[0] == len(variables):
        sd = np.sqrt(np.maximum(np.diag(matrix), 0))
        corr = matrix / np.outer(sd, sd)
        for i in range(len(variables)):
            for j in range(i + 1, len(variables)):
                if np.isfinite(corr[i, j]):
                    top_corr.append((abs(float(corr[i, j])), float(corr[i, j]), variables[i], variables[j]))
        top_corr.sort(reverse=True)
    metrics["top_correlations"] = [
        {"absolute": a, "correlation": c, "left": left, "right": right}
        for a, c, left, right in top_corr[:12]
    ]
    (ROOT / "final_diagnostics.json").write_text(json.dumps(metrics, indent=2) + "\n")

    np.savez_compressed(ROOT / "final_arrays.npz", two_theta=x, observed=y,
                        calculated=calc, background=bkg, difference=diff)
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print(json.dumps(metrics, indent=2))
        return
    fig = plt.figure(figsize=(14, 10), constrained_layout=True)
    grid = fig.add_gridspec(4, 1, height_ratios=[1.2, 1, 1, 1])
    axes = [fig.add_subplot(grid[i, 0]) for i in range(4)]
    axes[0].plot(x, y, color="black", lw=0.45, label="observed")
    axes[0].plot(x, calc, color="#d62728", lw=0.7, label="calculated")
    axes[0].plot(x, diff - 900, color="#1f77b4", lw=0.45, label="difference − 900")
    axes[0].set_xlim(x.min(), x.max())
    axes[0].set_ylim(-1500, max(y.max() * 1.03, 2000))
    axes[0].set_ylabel("counts")
    axes[0].legend(loc="upper right", ncol=3, fontsize=8)
    for axis, (low, high) in zip(axes[1:], [(15, 35), (35, 65), (65, 95)]):
        mask = (x >= low) & (x <= high)
        axis.plot(x[mask], y[mask], color="black", lw=0.55)
        axis.plot(x[mask], calc[mask], color="#d62728", lw=0.75)
        offset = min(y[mask]) - 250
        axis.plot(x[mask], diff[mask] + offset, color="#1f77b4", lw=0.5)
        axis.axhline(offset, color="0.7", lw=0.4)
        axis.set_xlim(low, high)
        axis.set_ylabel("counts")
    axes[-1].set_xlabel(r"$2\theta$ (degrees, Cu K$\alpha$)")
    fig.suptitle("Four-phase GSAS-II fit and difference profile", fontsize=13)
    fig.savefig(ROOT / "final_diagnostic.png", dpi=180)
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
