"""Test MnWO4 and Mn2O3 simultaneously under the clean common profile."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "combined_watch_trial.gpx"
CANDIDATES = [
    ("MnWO4_wolframite", "1520200", 0.24),
    ("Mn2O3_bixbyite", "1514230", 0.15),
]


def neutralize(phase, hist_name: str, scale: float) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:2] = [10.0, 10.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"] = [0.0, False]


def refine(project, label: str) -> G2.G2Project:
    project.save(str(OUTPUT))
    project.refine(printFile=str(ROOT / f"combined_watch_{label}.lst"))
    return G2.G2Project(gpxfile=str(OUTPUT))


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(ROOT / "clean_two_phase.gpx"))
    # add_phase indexes and autosaves; switch to the branch file first.
    project.save(str(OUTPUT))
    project = G2.G2Project(gpxfile=str(OUTPUT))
    hist = project.histograms()[0]
    added = []
    for label, cod_id, scale in CANDIDATES:
        phase = project.add_phase(str(ROOT / "candidates" / f"{cod_id}.cif"),
                                  phasename=label, histograms=[hist], fmthint="CIF")
        neutralize(phase, hist.name, scale)
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMax", 1e5, variable=f"{phase.id}:0:Scale")
        added.append(phase)
    hist.set_refinements({"Background": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["W", "Polariz."]})
    for phase in project.phases()[:2]:
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.02
    project = refine(project, "scales")
    for phase in project.phases()[2:]:
        phase.set_refinements({"Cell": True})
    project = refine(project, "cells")
    project = refine(project, "replay")
    project.save(str(OUTPUT))

    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    sigmas = {str(v): float(s) for v, s in zip(cov.get("varyList", []), cov.get("sig", []))}
    mass_scale = np.array([p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
                           for p in project.phases()])
    fractions = mass_scale / mass_scale.sum()
    report = {
        "Rwp_percent": float(hist.get_wR()),
        "frozen": [str(v) for v in project.get_Frozen()],
        "phases": [],
    }
    for phase, fraction in zip(project.phases(), fractions):
        scale = float(phase.data["Histograms"][hist.name]["Scale"][0])
        sigma = sigmas.get(f"{phase.id}:0:Scale")
        report["phases"].append({"name": phase.name, "weight_fraction": float(fraction),
                                 "scale": scale, "scale_esd": sigma,
                                 "scale_over_esd": scale / sigma if sigma else None,
                                 "cell": phase.get_cell()})
    (ROOT / "combined_watch_trial.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
