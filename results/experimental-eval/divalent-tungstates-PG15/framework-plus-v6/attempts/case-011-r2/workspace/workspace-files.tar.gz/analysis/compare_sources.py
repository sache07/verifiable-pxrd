"""Challenge viable WO3 source records under one accepted nuisance model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from scipy.signal import savgol_filter
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "source_trials"
OUT.mkdir(parents=True, exist_ok=True)
WO3_IDS = ["1528915", "2311041", "2106293", "2107312", "1563541"]
MNO2_ID = "1514110"


def background(x, y, n=8):
    width = int(round(2.0 / np.median(np.diff(x)))) | 1
    baseline = percentile_filter(y, 18, size=width, mode="nearest")
    baseline = savgol_filter(baseline, max(11, (width // 2) * 2 + 1), 3)
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, baseline, n - 1).tolist()


def configure_hap(phase, histname, is_wo3):
    hap = phase.data["Histograms"][histname]
    hap["Scale"] = [30.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:2] = ([0.17, 10.0] if is_wo3 else [10.0, 10.0])
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:2] = ([4400.0, 0.0] if is_wo3 else [2600.0, 0.0])
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]


def fit(wo3_id):
    folder = OUT / wo3_id
    folder.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(folder / "fit.gpx"))
    hist = project.add_powder_histogram(str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"), fmthint="xye")
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-580.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for key, value in [("Zero", 0.0), ("U", 0.0), ("V", 0.0), ("W", 8.0), ("X", 4.2), ("Y", 0.0), ("Z", 0.0), ("SH/L", 0.03), ("Polariz.", 0.70)]:
        inst[key] = [value, value, False]
    x, y = (np.asarray(hist.data["data"][1][i], float) for i in (0, 1))
    coeffs = background(x, y)
    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 8, "coeffs": coeffs, "refine": True}})
    phases = [
        project.add_phase(str(ROOT / "candidates" / f"{wo3_id}.cif"), phasename=f"WO3_{wo3_id}", histograms=[hist], fmthint="CIF"),
        project.add_phase(str(ROOT / "candidates" / f"{MNO2_ID}.cif"), phasename=f"MnO2_{MNO2_ID}", histograms=[hist], fmthint="CIF"),
    ]
    configure_hap(phases[0], hist.name, True)
    configure_hap(phases[1], hist.name, False)
    project.set_Controls("cycles", 7)
    project.data["Controls"]["data"]["shift factor"] = 0.2
    for var, lo, hi in [
        (":0:W", 0.0, 80.0), (":0:X", 0.05, 10.0), (":0:Shift", -1000.0, 1000.0),
        ("0:0:Size;i", 0.02, 10.0), ("0:0:Mustrain;i", 0.0, 10000.0),
        ("1:0:Mustrain;i", 0.0, 10000.0), ("0:0:Scale", 0.0, 1e6), ("1:0:Scale", 0.0, 1e6),
    ]:
        project.set_Controls("parmMin", lo, variable=var)
        project.set_Controls("parmMax", hi, variable=var)
    project.refine()
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    phases[0].set_refinements({"Cell": True})
    phases[1].set_refinements({"Cell": True})
    project.refine()
    phases[0].data["Histograms"][hist.name]["Size"][2][0] = True
    phases[0].data["Histograms"][hist.name]["Mustrain"][2][0] = True
    phases[1].data["Histograms"][hist.name]["Mustrain"][2][0] = True
    inst["W"][2] = True
    inst["X"][2] = True
    project.refine()
    project.refine()
    project.save()
    scale = np.asarray([p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in phases])
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "wo3_id": wo3_id,
        "Rwp_percent": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "fractions": (scale / scale.sum()).tolist(),
        "cells": [p.get_cell() for p in phases],
        "Shift_um": hist.SampleParameters["Shift"][0],
        "profile": {k: inst[k][1] for k in ["U", "W", "X", "SH/L", "Polariz."]},
        "size_um": [p.data["Histograms"][hist.name]["Size"][1][0] for p in phases],
        "strain_ppm": [p.data["Histograms"][hist.name]["Mustrain"][1][0] for p in phases],
        "frozen": project.get_Frozen(),
    }
    arrays = np.asarray(hist.data["data"][1], float)
    np.savetxt(folder / "fit.csv", np.column_stack([arrays[0], arrays[1], arrays[3], arrays[1] - arrays[3], arrays[4]]), delimiter=",", header="two_theta,observed,calculated,difference,background", comments="")
    (folder / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(result, flush=True)
    return result


def main():
    G2.SetPrintLevel("error")
    results = []
    for wo3_id in WO3_IDS:
        try:
            results.append(fit(wo3_id))
        except Exception as exc:
            results.append({"wo3_id": wo3_id, "error": repr(exc)})
            print(results[-1], flush=True)
    results.sort(key=lambda row: row.get("Rwp_percent", float("inf")))
    (OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
