"""Compare plausible WO3/MnO2 source records under one restrained GSAS-II model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from scipy.signal import savgol_filter

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WO3_IDS = ["1010618", "1528915", "2311041", "2106293", "2107312", "1563541"]
MNO2_IDS = ["1514110", "1514232"]


def model_path(cod_id: str) -> Path:
    return ROOT / "candidates" / f"{cod_id}.cif"


def background_coefficients(x: np.ndarray, y: np.ndarray, count: int = 8) -> list[float]:
    step = float(np.median(np.diff(x)))
    width = int(round(2.0 / step))
    if width % 2 == 0:
        width += 1
    baseline = percentile_filter(y, percentile=18, size=width, mode="nearest")
    smooth_width = max(11, (width // 2) * 2 + 1)
    baseline = savgol_filter(baseline, smooth_width, 3)
    coordinate = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(coordinate, baseline, count - 1).tolist()


def neutralize_hap(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Scale"] = [30.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][1][1] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]


def fit_pair(wo3_id: str, mno2_id: str) -> dict:
    tag = f"wo3-{wo3_id}_mno2-{mno2_id}"
    folder = ROOT / "screen" / tag
    folder.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(folder / "screen.gpx"))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"), fmthint="xye"
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"] = [0.12, 0.12, False]
    inst["U"] = [10.0, 10.0, False]
    inst["W"] = [100.0, 100.0, False]
    inst["X"] = [3.0, 3.0, False]
    inst["SH/L"] = [0.03, 0.03, False]
    x, y = (np.asarray(hist.data["data"][1][i], float) for i in (0, 1))
    coefficients = background_coefficients(x, y)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(coefficients),
                "coeffs": coefficients,
                "refine": False,
            }
        }
    )
    phases = [
        project.add_phase(str(model_path(wo3_id)), phasename=f"WO3_{wo3_id}", histograms=[hist], fmthint="CIF"),
        project.add_phase(str(model_path(mno2_id)), phasename=f"MnO2_{mno2_id}", histograms=[hist], fmthint="CIF"),
    ]
    for phase in phases:
        neutralize_hap(phase, hist.name)
        phase.set_HAP_refinements({"Scale": True}, [hist])

    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.2
    # Common baseline: first stabilize the smooth background and both scales.
    hist.set_refinements({"Background": True})
    project.refine(printFile=str(folder / "step1.lst"))
    # Add one angular correction, then update each cell separately and together.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine(printFile=str(folder / "step2.lst"))
    phases[0].set_refinements({"Cell": True})
    project.refine(printFile=str(folder / "step3.lst"))
    phases[0].clear_refinements({"Cell": True})
    phases[1].set_refinements({"Cell": True})
    project.refine(printFile=str(folder / "step4.lst"))
    phases[0].set_refinements({"Cell": True})
    project.refine(printFile=str(folder / "step5.lst"))
    # Establish one common nonnegative U/W/X profile in stages.
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    project.refine(printFile=str(folder / "step6.lst"))
    hist.set_refinements({"Instrument Parameters": ["U"]})
    project.refine(printFile=str(folder / "step7.lst"))
    project.refine(printFile=str(folder / "step8.lst"))
    project.save()

    scales = np.array([p.data["Histograms"][hist.name]["Scale"][0] for p in phases])
    masses = np.array([p.data["General"]["Mass"] for p in phases]) * scales
    fractions = masses / masses.sum() if masses.sum() > 0 else np.full(2, np.nan)
    covariance = project.data.get("Covariance", {}).get("data", {})
    result = {
        "tag": tag,
        "wR_percent": hist.get_wR(),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "fractions": fractions.tolist(),
        "scales": scales.tolist(),
        "cells": [p.get_cell() for p in phases],
        "instrument": {name: float(inst[name][1]) for name in ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]},
        "background": [float(v) for v in hist.data["Background"][0][3:]],
        "frozen": project.get_Frozen(),
    }
    (folder / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> None:
    G2.SetPrintLevel("warn")
    results = []
    for wo3_id in WO3_IDS:
        for mno2_id in MNO2_IDS:
            try:
                result = fit_pair(wo3_id, mno2_id)
                results.append(result)
                print(result["tag"], result["wR_percent"], result["fractions"], result["instrument"])
            except Exception as exc:
                result = {"tag": f"wo3-{wo3_id}_mno2-{mno2_id}", "error": repr(exc)}
                results.append(result)
                print(result)
    results.sort(key=lambda row: row.get("wR_percent") if row.get("wR_percent") is not None else float("inf"))
    (ROOT / "screen" / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
    print("\nRANKING")
    for result in results:
        print(result.get("wR_percent"), result["tag"], result.get("fractions"), result.get("instrument"))


if __name__ == "__main__":
    main()
