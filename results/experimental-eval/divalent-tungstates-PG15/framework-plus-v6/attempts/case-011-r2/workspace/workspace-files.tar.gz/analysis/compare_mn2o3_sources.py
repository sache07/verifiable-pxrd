"""Compare physical Mn2O3 source records under one restrained nuisance model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCES = ["1514230", "1010586", "1514103"]


def neutralize(phase, hist_name: str, scale: float) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:2] = [10.0, 10.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"] = [0.0, False]


def run(cod_id: str) -> dict:
    folder = ROOT / "mn2o3_source_trials"
    folder.mkdir(exist_ok=True)
    output = folder / f"{cod_id}.gpx"
    project = G2.G2Project(gpxfile=str(ROOT / "clean_two_phase.gpx"))
    # add_phase indexes and autosaves; switch to the branch file first.
    project.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histograms()[0]
    mnwo4 = project.add_phase(str(ROOT / "candidates" / "1520200.cif"),
                              phasename="MnWO4_wolframite", histograms=[hist], fmthint="CIF")
    neutralize(mnwo4, hist.name, 0.27)
    mno = project.add_phase(str(ROOT / "candidates" / f"{cod_id}.cif"),
                            phasename=f"Mn2O3_{cod_id}", histograms=[hist], fmthint="CIF")
    neutralize(mno, hist.name, 0.15)
    for phase in [mnwo4, mno]:
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMax", 1e5, variable=f"{phase.id}:0:Scale")
    hist.set_refinements({"Background": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["W", "Polariz."]})
    for phase in project.phases()[:2]:
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.02
    project.save(str(output))
    project.refine(printFile=str(output.with_suffix(".scales.lst")))
    project = G2.G2Project(gpxfile=str(output))
    for phase in project.phases()[2:]:
        phase.set_refinements({"Cell": True})
    project.save(str(output))
    project.refine(printFile=str(output.with_suffix(".cells.lst")))
    project = G2.G2Project(gpxfile=str(output))
    project.refine(printFile=str(output.with_suffix(".replay.lst")))
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histograms()[0]
    mass = np.array([p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
                     for p in project.phases()])
    return {"cod_id": cod_id, "Rwp_percent": float(hist.get_wR()),
            "fractions": (mass / mass.sum()).tolist(), "cell": project.phases()[-1].get_cell(),
            "frozen": [str(v) for v in project.get_Frozen()]}


def main() -> None:
    G2.SetPrintLevel("warn")
    results = []
    for cod_id in SOURCES:
        result = run(cod_id)
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    path = ROOT / "mn2o3_source_trials" / "summary.json"
    path.write_text(json.dumps(results, indent=2) + "\n")
    print(path)


if __name__ == "__main__":
    main()
