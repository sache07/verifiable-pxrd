"""Reconverge the selected four-phase model with a fixed roughness profile."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "final_roughness_fine" / "A_0.40.gpx"
OUTPUT = ROOT / "final_candidate.gpx"


def snapshot(project: G2.G2Project, path: Path) -> None:
    project.save(str(path))


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    hist = project.histograms()[0]
    hist.SampleParameters["SurfRoughA"] = [0.40, False]
    hist.SampleParameters["SurfRoughB"] = [0.25325136517533, False]
    hist.SampleParameters["Shift"][1] = True
    hist.set_refinements({"Background": True})
    inst = hist.data["Instrument Parameters"][0]
    for name in ["Zero", "U", "V", "X", "Y", "Z", "SH/L"]:
        inst[name][2] = False
    inst["X"] = [6.0, 6.0, False]
    inst["W"][2] = True
    inst["Polariz."][2] = True

    phases = project.phases()
    if [p.name for p in phases] != ["WO3_2106293", "MnO2_1514110",
                                     "MnWO4_wolframite", "Mn2O3_1514230"]:
        raise RuntimeError("unexpected phase inventory")
    for phase in phases:
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
    phases[0].data["Histograms"][hist.name]["Mustrain"][2][:2] = [True, True]
    phases[1].data["Histograms"][hist.name]["Mustrain"][2][0] = True
    phases[1].data["Histograms"][hist.name]["Pref.Ori."][2] = True

    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.02
    for variable, lower, upper in [
        (":0:W", 0.0, 80.0), (":0:Polariz.", 0.5, 1.0),
        (":0:Shift", -800.0, 800.0),
        ("0:0:Mustrain;i", 300.0, 8000.0), ("0:0:Mustrain;a", 300.0, 8000.0),
        ("1:0:Mustrain;i", 300.0, 8000.0), ("1:0:MD", 0.7, 1.4),
    ]:
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    for phase in phases:
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMax", 1e6, variable=f"{phase.id}:0:Scale")

    snapshot(project, OUTPUT)
    history = []
    for index in range(6):
        project = G2.G2Project(gpxfile=str(OUTPUT))
        before = float(project.histograms()[0].get_wR())
        backup = ROOT / f"final_candidate_before_{index}.gpx"
        G2.G2Project(gpxfile=str(OUTPUT)).save(str(backup))
        project = G2.G2Project(gpxfile=str(OUTPUT))
        project.refine(printFile=str(ROOT / f"final_candidate_pass_{index}.lst"))
        project = G2.G2Project(gpxfile=str(OUTPUT))
        after = float(project.histograms()[0].get_wR())
        max_shift = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("Max shft/sig")
        history.append({"pass": index, "before_Rwp": before, "after_Rwp": after,
                        "max_shift_over_esd": max_shift})
        print(history[-1], flush=True)
        if after > before + 1e-7:
            G2.G2Project(gpxfile=str(backup)).save(str(OUTPUT))
            project = G2.G2Project(gpxfile=str(OUTPUT))
            history[-1]["restored"] = True
            break
        if max_shift is not None and max_shift < 0.05:
            break

    project = G2.G2Project(gpxfile=str(OUTPUT))
    hist = project.histograms()[0]
    mass = np.array([p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
                     for p in project.phases()])
    cov = project.data.get("Covariance", {}).get("data", {})
    report = {
        "Rwp_percent": float(hist.get_wR()),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "max_shift_over_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "fractions": (mass / mass.sum()).tolist(),
        "frozen": [str(v) for v in project.get_Frozen()],
        "history": history,
        "instrument": {k: hist.data["Instrument Parameters"][0][k][1]
                       for k in ["U", "W", "X", "SH/L", "Polariz."]},
        "sample": {k: hist.SampleParameters[k][0]
                   for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
    }
    (ROOT / "final_candidate.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
