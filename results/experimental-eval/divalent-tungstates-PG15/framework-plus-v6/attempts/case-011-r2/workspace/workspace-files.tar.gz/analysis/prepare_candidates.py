"""Normalize selected COD records exactly as the synthetic registry does."""

from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

import numpy as np
from pymatgen.io.cif import CifParser
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT.parent / "learned" / "divalent-tungstates" / "runtime"
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
IDS = [
    "1010618", "1528915", "2311041", "2106293", "2107312", "1563541",
    "1514110", "1514232", "1520200", "2002703", "1541183", "9001302",
    "9001963", "1010586", "1514103", "1514230", "1514035", "1514239",
]


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    destination = ROOT / "candidates"
    destination.mkdir(parents=True, exist_ok=True)
    records = []
    for cod_id in IDS:
        source = cod_path(cod_id)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            parser = CifParser(source, occupancy_tolerance=1.0, site_tolerance=1e-5, frac_tolerance=0)
            structures = parser.parse_structures(primitive=False, on_error="raise")
        structure = structures[0]
        structure.remove_oxidation_states()
        output = destination / f"{cod_id}.cif"
        write_synthetic_model(structure, output)
        distance = structure.distance_matrix.copy()
        np.fill_diagonal(distance, np.inf)
        block = next(iter(parser.as_dict().values()))
        analyzer = SpacegroupAnalyzer(structure, symprec=0.001)
        records.append(
            {
                "cod_id": cod_id,
                "source": str(source),
                "normalized": str(output),
                "formula": structure.composition.reduced_formula,
                "expanded_composition": structure.composition.get_el_amt_dict(),
                "sites": len(structure),
                "space_group": analyzer.get_space_group_symbol(),
                "space_group_number": analyzer.get_space_group_number(),
                "cell": [*structure.lattice.abc, *structure.lattice.angles],
                "density_g_cm3": structure.density,
                "minimum_separation_A": float(np.min(distance)),
                "ordered": structure.is_ordered,
                "warnings": [str(item.message) for item in caught],
                "source_conditions": {
                    key: str(block[key])
                    for key in [
                        "_publ_section_title", "_journal_paper_doi", "_journal_year",
                        "_chemical_formula_sum", "_diffrn_ambient_pressure",
                        "_diffrn_ambient_temperature", "_cell_measurement_temperature",
                    ]
                    if key in block
                },
            }
        )
    (destination / "inventory.json").write_text(json.dumps(records, indent=2) + "\n")
    for record in records:
        print(record["cod_id"], record["formula"], record["space_group"], record["cell"], record["minimum_separation_A"])


if __name__ == "__main__":
    main()
