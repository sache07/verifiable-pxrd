"""Build a restrained two-phase GSAS-II baseline for a selected WO3/MnO2 pair."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from scipy.signal import savgol_filter

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def background_coefficients(x: np.ndarray, y: np.ndarray, count: int = 8) -> list[float]:
    step = float(np.median(np.diff(x)))
    width = int(round(2.0 / step)) | 1
    baseline = percentile_filter(y, percentile=18, size=width, mode="nearest")
    baseline = savgol_filter(baseline, max(11, (width // 2) * 2 + 1), 3)
    coordinate = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(coordinate, baseline, count - 1).tolist()


def neutralize_hap(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Scale"] = [30.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:2] = [1.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]


def state(project, hist, label: str) -> dict:
    phases = project.phases()
    scales = np.asarray([p.data["Histograms"][hist.name]["Scale"][0] for p in phases], float)
    masses = np.asarray([p.data["General"]["Mass"] for p in phases], float) * scales
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "label": label,
        "wR_percent": hist.get_wR(),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "fractions": (masses / masses.sum()).tolist() if masses.sum() > 0 else None,
        "scales": scales.tolist(),
        "cells": [p.get_cell() for p in phases],
        "instrument": {name: float(inst[name][1]) for name in ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]},
        "sample": {name: float(sample[name][0]) for name in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]},
        "background": [float(v) for v in hist.data["Background"][0][3:]],
        "hap": [
            {
                "size": p.data["Histograms"][hist.name]["Size"],
                "mustrain": p.data["Histograms"][hist.name]["Mustrain"],
                "preferred_orientation": p.data["Histograms"][hist.name]["Pref.Ori."],
            }
            for p in phases
        ],
        "frozen": project.get_Frozen(),
        "vary_list": [str(v) for v in covariance.get("varyList", [])],
    }


def run_step(project, hist, log: list[dict], folder: Path, label: str) -> None:
    project.refine(printFile=str(folder / f"{label}.lst"))
    record = state(project, hist, label)
    log.append(record)
    print(label, "Rwp", record["wR_percent"], "fractions", record["fractions"],
          "shift", record["sample"]["Shift"], "profile", record["instrument"],
          "frozen", record["frozen"], flush=True)


def build(wo3_id: str, mno2_id: str) -> Path:
    folder = ROOT / "target" / f"wo3-{wo3_id}_mno2-{mno2_id}"
    folder.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(folder / "baseline.gpx"))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"), fmthint="xye"
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-400.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"] = [0.0, 0.0, False]
    inst["U"] = [10.0, 10.0, False]
    inst["V"] = [0.0, 0.0, False]
    inst["W"] = [20.0, 20.0, False]
    inst["X"] = [2.0, 2.0, False]
    inst["Y"] = [0.0, 0.0, False]
    inst["Z"] = [0.0, 0.0, False]
    inst["SH/L"] = [0.03, 0.03, False]
    inst["Polariz."] = [0.70, 0.70, False]
    x, y = (np.asarray(hist.data["data"][1][i], float) for i in (0, 1))
    coefficients = background_coefficients(x, y)
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": 8, "coeffs": coefficients, "refine": False}}
    )
    phases = [
        project.add_phase(
            str(ROOT / "candidates" / f"{wo3_id}.cif"),
            phasename=f"WO3_{wo3_id}", histograms=[hist], fmthint="CIF",
        ),
        project.add_phase(
            str(ROOT / "candidates" / f"{mno2_id}.cif"),
            phasename=f"MnO2_{mno2_id}", histograms=[hist], fmthint="CIF",
        ),
    ]
    for phase in phases:
        neutralize_hap(phase, hist.name)
        phase.set_HAP_refinements({"Scale": True}, [hist])

    project.set_Controls("cycles", 6)
    project.data["Controls"]["data"]["shift factor"] = 0.25
    # Guard the low-dimensional common profile and the one angular correction.
    for variable, lower, upper in [
        (":0:U", 0.0, 80.0), (":0:W", 0.0, 80.0), (":0:X", 0.05, 10.0),
        (":0:SH/L", 0.001, 0.2), (":0:Polariz.", 0.5, 1.0),
        (":0:Shift", -1000.0, 1000.0), ("0:0:Scale", 0.0, 1e6), ("1:0:Scale", 0.0, 1e6),
    ]:
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    log: list[dict] = []
    hist.set_refinements({"Background": True})
    run_step(project, hist, log, folder, "01_background_scales")
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_step(project, hist, log, folder, "02_shift")
    phases[0].set_refinements({"Cell": True})
    run_step(project, hist, log, folder, "03_wo3_cell")
    phases[0].clear_refinements({"Cell": True})
    phases[1].set_refinements({"Cell": True})
    run_step(project, hist, log, folder, "04_mno2_cell")
    phases[0].set_refinements({"Cell": True})
    run_step(project, hist, log, folder, "05_common_baseline")
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    run_step(project, hist, log, folder, "06_WX")
    hist.set_refinements({"Instrument Parameters": ["U"]})
    run_step(project, hist, log, folder, "07_UWX")
    run_step(project, hist, log, folder, "08_reconverged")
    project.save()
    (folder / "stages.json").write_text(json.dumps(log, indent=2) + "\n")
    arrays = np.asarray(hist.data["data"][1], dtype=float)
    np.savetxt(
        folder / "baseline_fit.csv",
        np.column_stack([arrays[0], arrays[1], arrays[3], arrays[1] - arrays[3], arrays[4]]),
        delimiter=",", header="two_theta,observed,calculated,difference,background", comments="",
    )
    return folder


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("mno2_id")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    print(build(args.wo3_id, args.mno2_id))


if __name__ == "__main__":
    main()
