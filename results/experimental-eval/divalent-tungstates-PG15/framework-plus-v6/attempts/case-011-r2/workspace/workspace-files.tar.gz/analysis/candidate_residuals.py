"""Quantify whether weak watch-list phases are supported by coherent peak families."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TRIALS = [
    ("MnWO4_wolframite", ROOT / "final_candidate.gpx"),
    ("Mn2O3_1514230", ROOT / "final_candidate.gpx"),
]


def arrays(hist):
    return [np.asarray(a, float).copy() for a in hist.data["data"][1]]


def analyze(label: str, source: Path) -> dict:
    project = G2.G2Project(gpxfile=str(source))
    hist = project.histograms()[0]
    full = arrays(hist)
    phase = project.phase(label)
    scale = float(phase.data["Histograms"][hist.name]["Scale"][0])

    # Recalculate with exactly the fitted nuisance parameters and zero candidate scale.
    phase.data["Histograms"][hist.name]["Scale"] = [0.0, False]
    temp = ROOT.parent / ".tmp" / f"{label}_zero_scale.gpx"
    temp.parent.mkdir(exist_ok=True)
    project.save(str(temp))
    project.set_Controls("cycles", 0)
    project.refine(printFile=str(temp.with_suffix(".lst")))
    zero = arrays(project.histograms()[0])

    x, y = zero[0], zero[1]
    candidate = full[3] - zero[3]
    residual = y - zero[3]
    # Keep resolved local maxima and integrate over a conservative +/-0.12 degree window.
    maxima, _ = find_peaks(candidate, distance=max(2, int(round(0.08 / np.median(np.diff(x))))))
    maxima = maxima[candidate[maxima] > 0.25]
    ranked = maxima[np.argsort(candidate[maxima])[::-1]]
    families = []
    for index in ranked[:20]:
        mask = np.abs(x - x[index]) <= 0.12
        signal = candidate[mask]
        local_residual = residual[mask]
        weights = 1.0 / np.maximum(y[mask], 1.0)
        families.append({
            "two_theta_deg": float(x[index]),
            "candidate_peak_counts": float(candidate[index]),
            "baseline_residual_counts_at_center": float(residual[index]),
            "integrated_candidate_counts": float(signal.sum()),
            "integrated_baseline_residual_counts": float(local_residual.sum()),
            "weighted_projection": float(np.dot(signal * weights, local_residual) / np.sqrt(np.dot(signal * weights, signal))),
        })
    weights = 1.0 / np.maximum(y, 1.0)
    projection_sigma = float(np.dot(candidate * weights, residual) / np.sqrt(np.dot(candidate * weights, candidate)))
    return {
        "phase": label,
        "fitted_scale": scale,
        "candidate_profile_max_counts": float(candidate.max()),
        "candidate_profile_integral_counts": float(candidate.sum()),
        "global_weighted_projection_sigma": projection_sigma,
        "positive_center_count_top20": int(sum(f["baseline_residual_counts_at_center"] > 0 for f in families)),
        "positive_integral_count_top20": int(sum(f["integrated_baseline_residual_counts"] > 0 for f in families)),
        "top_families": families,
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    result = [analyze(*trial) for trial in TRIALS]
    target = ROOT / "final_minor_phase_evidence.json"
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
