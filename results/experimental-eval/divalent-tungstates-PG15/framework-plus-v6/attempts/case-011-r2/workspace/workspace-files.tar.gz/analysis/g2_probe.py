from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
project = G2.G2Project(newgpx=str(ROOT / "probe.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / "pattern.xye"),
    str(ROOT / "instrument.instprm"),
    fmthint="xye",
)
print(hist.name)
print("points", len(hist.data["data"][1][0]))
print("x endpoints", hist.data["data"][1][0][0], hist.data["data"][1][0][-1])
print("y endpoints", hist.data["data"][1][1][0], hist.data["data"][1][1][-1])
print("instrument", hist.data["Instrument Parameters"][0])
print("sample", hist.data["Sample Parameters"])
print("background", hist.data["Background"])
project.save()
