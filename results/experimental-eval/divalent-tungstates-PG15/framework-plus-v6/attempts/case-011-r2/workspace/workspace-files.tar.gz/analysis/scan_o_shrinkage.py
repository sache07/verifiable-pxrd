"""Profile a physically bounded WO3 oxygen-displacement mode.

The direction comes from the unconstrained coordinate trial, but its amplitude is
shrunk to the generator's defensible oxygen mismatch range before nuisance replay.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "model_mnuiso_test.bak0.gpx"
TARGET = ROOT / "model_allcoords.gpx"
FRACTIONS = [0.0, 0.10, 0.20, 0.268, 0.35, 0.50]


def refine_on_disk(path: Path, passes: int = 2) -> G2.G2Project:
    """Run replay passes, always reloading GSAS-II's retained (non-worse) file."""
    project = G2.G2Project(gpxfile=str(path))
    for index in range(passes):
        before = float(project.histograms()[0].get_wR())
        project.refine(printFile=str(path.with_suffix(f".pass{index}.lst")))
        project = G2.G2Project(gpxfile=str(path))
        after = float(project.histograms()[0].get_wR())
        if after >= before - 1e-8:
            break
    return project


def main() -> None:
    G2.SetPrintLevel("warn")
    target = G2.G2Project(gpxfile=str(TARGET)).phase("WO3_2106293")
    target_by_label = {atom.label: np.asarray(atom.coordinates, float) for atom in target.atoms()}
    results = []
    folder = ROOT / "o_shrinkage"
    folder.mkdir(exist_ok=True)
    for fraction in FRACTIONS:
        project = G2.G2Project(gpxfile=str(BASE))
        phase = project.phase("WO3_2106293")
        displacements = []
        for atom in phase.atoms():
            if atom.element != "O":
                continue
            start = np.asarray(atom.coordinates, float)
            delta = target_by_label[atom.label] - start
            delta -= np.rint(delta)
            atom.coordinates = (start + fraction * delta) % 1.0
            atom.refinement_flags = atom.refinement_flags.replace("X", "")
            displacements.append(delta)
        # Refit the baseline around this one-dimensional structural perturbation.
        hist = project.histograms()[0]
        hist.set_refinements({"Background": True})
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        hist.set_refinements({"Instrument Parameters": ["W", "X", "Polariz."]})
        for existing in project.phases():
            existing.set_refinements({"Cell": True})
            existing.set_HAP_refinements({"Scale": True}, [hist])
        project.set_Controls("cycles", 8)
        project.data["Controls"]["data"]["shift factor"] = 0.02
        path = folder / f"fraction_{fraction:.3f}.gpx"
        project.save(str(path))
        project = refine_on_disk(path)
        phase = project.phase("WO3_2106293")
        # Cartesian RMS relative to the source coordinates, using the refined cell.
        cell = phase.get_cell()
        a, b, c = (cell["length_a"], cell["length_b"], cell["length_c"])
        alpha, beta, gamma = np.radians([cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]])
        lattice = np.array([
            [a, 0.0, 0.0],
            [b * np.cos(gamma), b * np.sin(gamma), 0.0],
            [c * np.cos(beta), c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma),
             c * np.sqrt(1.0 - np.cos(beta) ** 2
                         - ((np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)) ** 2)],
        ])
        cart = np.asarray(displacements) * fraction @ lattice
        rms = float(np.sqrt(np.mean(np.sum(cart * cart, axis=1))))
        results.append({
            "fraction_of_unconstrained_mode": fraction,
            "oxygen_coordinate_rms_A": rms,
            "Rwp_percent": float(project.histograms()[0].get_wR()),
            "path": str(path.relative_to(ROOT.parent)),
            "frozen": [str(v) for v in project.get_Frozen()],
        })
        print(json.dumps(results[-1], indent=2), flush=True)
    output = folder / "summary.json"
    output.write_text(json.dumps(results, indent=2) + "\n")
    print(output)


if __name__ == "__main__":
    main()
