"""Profile the one-dimensional Suortti roughness family in the final inventory."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpwd as G2pwd


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "final_roughB_test.gpx"
STARTS = {0.35: 0.207, 0.40: 0.253, 0.425: 0.290,
          0.45: 0.357, 0.46: 0.422}


def main() -> None:
    G2.SetPrintLevel("warn")
    folder = ROOT / "final_roughness_fine"
    folder.mkdir(exist_ok=True)
    results = []
    for a_value, b_start in STARTS.items():
        output = folder / f"A_{a_value:.2f}.gpx"
        project = G2.G2Project(gpxfile=str(SOURCE))
        project.save(str(output))
        project = G2.G2Project(gpxfile=str(output))
        hist = project.histograms()[0]
        hist.SampleParameters["SurfRoughA"] = [a_value, False]
        hist.SampleParameters["SurfRoughB"] = [b_start, True]
        # Profile A/B with only the smooth background and all phase scales.
        # Cells, widths, texture, polarization and displacement are fixed to
        # the already established common baseline for a fair comparison.
        for values in hist.data["Instrument Parameters"][0].values():
            if isinstance(values, list) and len(values) >= 3 and isinstance(values[2], bool):
                values[2] = False
        hist.SampleParameters["Shift"][1] = False
        hist.set_refinements({"Background": True})
        for phase in project.phases():
            phase.clear_refinements({"Cell": True})
            hap = phase.data["Histograms"][hist.name]
            hap["Scale"][1] = True
            hap["Size"][2] = [False] * len(hap["Size"][2])
            hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
            hap["Pref.Ori."][2] = False
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")
        project.set_Controls("cycles", 8)
        project.data["Controls"]["data"]["shift factor"] = 0.02
        project.save(str(output))
        for index in range(2):
            project.refine(printFile=str(output.with_suffix(f".pass{index}.lst")))
            project = G2.G2Project(gpxfile=str(output))
        hist = project.histograms()[0]
        b_value = float(hist.SampleParameters["SurfRoughB"][0])
        mass = np.array([p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
                         for p in project.phases()])
        cov = project.data.get("Covariance", {}).get("data", {})
        result = {
            "A": a_value,
            "B": b_value,
            "correction_20deg": float(G2pwd.SurfaceRough(a_value, b_value, 20.0)),
            "Rwp_percent": float(hist.get_wR()),
            "fractions": (mass / mass.sum()).tolist(),
            "max_shift_over_esd": cov.get("Rvals", {}).get("Max shft/sig"),
            "frozen": [str(v) for v in project.get_Frozen()],
        }
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    path = folder / "summary.json"
    path.write_text(json.dumps(results, indent=2) + "\n")
    print(path)


if __name__ == "__main__":
    main()
