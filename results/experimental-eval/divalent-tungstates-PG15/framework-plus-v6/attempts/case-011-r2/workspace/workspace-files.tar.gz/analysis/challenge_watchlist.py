"""Re-challenge chemically plausible weak phases under the accepted common profile."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "clean_two_phase.gpx"
OUTPUT_DIR = ROOT / "watch_trials_clean"
CANDIDATES = {
    "MnWO4_wolframite": "1520200",
    "Mn2O3_bixbyite": "1514230",
}


def neutralize_hap(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Scale"] = [0.5, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:2] = [10.0, 10.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]


def phase_fractions(project, hist_name: str) -> list[float]:
    mass_scales = np.array([
        p.data["General"]["Mass"] * p.data["Histograms"][hist_name]["Scale"][0]
        for p in project.phases()
    ])
    return (mass_scales / mass_scales.sum()).tolist()


def scale_esd(project, phase_id: int) -> float | None:
    cov = project.data.get("Covariance", {}).get("data", {})
    target = f"{phase_id}:0:Scale"
    for variable, sigma in zip(cov.get("varyList", []), cov.get("sig", [])):
        if str(variable) == target:
            return float(sigma)
    return None


def run_one(label: str, cod_id: str, base_rwp: float) -> dict:
    output = OUTPUT_DIR / f"{label}.gpx"
    output.parent.mkdir(exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.filename = str(output)
    hist = project.histograms()[0]
    # Explicitly reconverge the common baseline around every inventory change.
    hist.set_refinements({"Background": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["W", "Polariz."]})
    for existing in project.phases():
        existing.set_refinements({"Cell": True})
        existing.set_HAP_refinements({"Scale": True}, [hist])
    phase = project.add_phase(
        str(ROOT / "candidates" / f"{cod_id}.cif"),
        phasename=label,
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_hap(phase, hist.name)
    scale_variable = f"{phase.id}:0:Scale"
    project.set_Controls("parmMin", 0.0, variable=scale_variable)
    project.set_Controls("parmMax", 1e5, variable=scale_variable)
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.05
    project.save(str(output))
    project.refine(printFile=str(output.with_suffix(".scale.lst")))
    project.save(str(output))
    first_scale = float(phase.data["Histograms"][hist.name]["Scale"][0])
    first_sigma = scale_esd(project, phase.id)
    first_fraction = phase_fractions(project, hist.name)[-1]
    first_rwp = float(hist.get_wR())

    # Cell follows scale only when there is a positive, at least marginal signal.
    cell_tested = bool(first_scale > 0 and first_sigma and first_scale / first_sigma > 1.5)
    if cell_tested:
        phase.set_refinements({"Cell": True})
        project.refine(printFile=str(output.with_suffix(".cell.lst")))
        project.save(str(output))

    scale = float(phase.data["Histograms"][hist.name]["Scale"][0])
    sigma = scale_esd(project, phase.id)
    fractions = phase_fractions(project, hist.name)
    return {
        "label": label,
        "cod_id": cod_id,
        "Rwp_percent": float(hist.get_wR()),
        "delta_Rwp_percent_from_base": float(hist.get_wR() - base_rwp),
        "scale": scale,
        "scale_esd": sigma,
        "scale_over_esd": scale / sigma if sigma else None,
        "weight_fraction": fractions[-1],
        "cell_tested": cell_tested,
        "cell": phase.get_cell(),
        "first_scale": first_scale,
        "first_scale_esd": first_sigma,
        "first_weight_fraction": first_fraction,
        "first_Rwp_percent": first_rwp,
        "frozen": [str(v) for v in project.get_Frozen()],
        "phase_fractions": fractions,
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    base_rwp = float(G2.G2Project(gpxfile=str(BASE)).histograms()[0].get_wR())
    results = []
    for label, cod_id in CANDIDATES.items():
        result = run_one(label, cod_id, base_rwp)
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    path = OUTPUT_DIR / "summary.json"
    path.write_text(json.dumps(results, indent=2) + "\n")
    print(path)


if __name__ == "__main__":
    main()
