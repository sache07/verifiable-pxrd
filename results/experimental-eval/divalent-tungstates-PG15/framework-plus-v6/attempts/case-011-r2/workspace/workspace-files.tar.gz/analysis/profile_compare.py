"""Replay-stable size/strain comparisons from a truly neutral HAP baseline."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "profile_trials"
OUT.mkdir(parents=True, exist_ok=True)
SOURCE = ROOT / "sizeprobe.bak0.gpx"


def neutralize(project) -> None:
    hist = project.histogram(0)
    project.set_Frozen()
    inst = hist.data["Instrument Parameters"][0]
    for key, value in [("U", 10.0), ("W", 20.0), ("X", 2.0)]:
        inst[key] = [value, value, False]
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:2] = [10.0, 10.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:2] = [0.0, 0.0]
        hap["Mustrain"][2] = [False, False, False]


def activate(project, phase_index: int, term: str, value: float) -> None:
    hist = project.histogram(0)
    hap = project.phase(phase_index).data["Histograms"][hist.name]
    if term == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = value
        hap["Size"][2][0] = True
        variable = f"{phase_index}:0:Size;i"
        project.set_Controls("parmMin", 0.02, variable=variable)
        project.set_Controls("parmMax", 10.0, variable=variable)
    elif term == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = value
        hap["Mustrain"][2][0] = True
        variable = f"{phase_index}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 10000.0, variable=variable)
    else:
        raise ValueError(term)


def summarize(project, label: str) -> dict:
    hist = project.histogram(0)
    phases = project.phases()
    mass = np.asarray([
        phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in phases
    ])
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "label": label,
        "project": str(Path(project.filename).relative_to(ROOT.parent)),
        "Rwp_percent": hist.get_wR(),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "chi_square": covariance.get("Rvals", {}).get("chisq"),
        "weight_fractions": (mass / mass.sum()).tolist(),
        "size_um": [phase.data["Histograms"][hist.name]["Size"][1][0] for phase in phases],
        "microstrain_ppm": [phase.data["Histograms"][hist.name]["Mustrain"][1][0] for phase in phases],
        "frozen": project.get_Frozen(),
        "vary_list": [str(v) for v in covariance.get("varyList", [])],
    }


def refine(project, label: str) -> dict:
    project.data["Controls"]["data"]["shift factor"] = 0.2
    project.set_Controls("cycles", 8)
    project.refine()
    result = summarize(project, label)
    print(label, result, flush=True)
    return result


def branch(source: Path, label: str, terms: list[tuple[int, str, float]]) -> tuple[Path, dict]:
    target = OUT / f"{label}.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(target))
    for phase_index, term, value in terms:
        activate(project, phase_index, term, value)
    result = refine(project, label)
    project.save()
    return target, result


def main() -> None:
    G2.SetPrintLevel("error")
    neutral_path = OUT / "neutral.gpx"
    neutral = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(neutral_path))
    neutralize(neutral)
    results = [refine(neutral, "neutral")]
    neutral.save()

    _, row = branch(neutral_path, "wo3_size", [(0, "size", 0.15)])
    results.append(row)
    _, row = branch(neutral_path, "wo3_strain", [(0, "strain", 4000.0)])
    results.append(row)
    wo_both, row = branch(neutral_path, "wo3_size_strain", [(0, "size", 0.15), (0, "strain", 4000.0)])
    results.append(row)
    _, row = branch(wo_both, "wo3ss_mno2_size", [(1, "size", 0.3)])
    results.append(row)
    _, row = branch(wo_both, "wo3ss_mno2_strain", [(1, "strain", 1000.0)])
    results.append(row)
    _, row = branch(wo_both, "wo3ss_mno2_size_strain", [(1, "size", 0.3), (1, "strain", 1000.0)])
    results.append(row)
    (OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
