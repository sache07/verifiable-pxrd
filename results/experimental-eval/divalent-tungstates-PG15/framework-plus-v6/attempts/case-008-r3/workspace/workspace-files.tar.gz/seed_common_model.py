#!/usr/bin/env python3
"""Seed a candidate project with the converged common/main-phase model."""
from copy import deepcopy
import sys
from GSASII import GSASIIscriptable as G2


candidate_file, reference_file, target = sys.argv[1:4]
G2.SetPrintLevel('warn')
project = G2.G2Project(candidate_file, newgpx=target)
reference = G2.G2Project(reference_file)
hist = project.histogram(0)
ref_hist = reference.histogram(0)
main_name = project.phases()[0].name
project.data['Phases'][main_name] = deepcopy(reference.data['Phases'][main_name])
for key in ['Limits', 'Background', 'Instrument Parameters', 'Sample Parameters']:
    hist.data[key] = deepcopy(ref_hist.data[key])
project.set_Controls('cycles', 24)
project.data['Controls']['data']['min dM/M'] = 1e-7
project.refine()
project.save()
print(hist.get_wR())
