#!/usr/bin/env python3
"""Create, reopen and reconverge the final GSAS-II project, then export CIFs."""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2


source = sys.argv[1]
target = Path('final.gpx').resolve()
G2.SetPrintLevel('warn')


def prepare(project):
    hist = project.histogram(0)
    x = np.asarray(hist.data['data'][1][0], float)
    hist.data['Limits'] = [(float(x[0]), float(x[-1])), [float(x[0]), float(x[-1])]]
    # Uiso is fixed explicitly at 0.005 A^2 for both phases; its old equality
    # constraint is therefore unused and is removed from the submitted model.
    project.data['Constraints']['data']['Phase'] = []
    project.set_Controls('cycles', 24)
    project.data['Controls']['data']['min dM/M'] = 1e-7


project = G2.G2Project(source, newgpx=str(target))
prepare(project)
project.refine()
project.save()

# Required reopen/replay of the same complete fitting range.
project = G2.G2Project(str(target))
prepare(project)
project.refine()
project.save()

# Export exactly the structures now stored in final.gpx.
project = G2.G2Project(str(target))
hist = project.histogram(0)
paths = ['phase_1_MnWO4.cif', 'phase_2_WO3.cif']
for phase, path in zip(project.phases(), paths):
    phase.export_CIF(path)

masses = np.array([
    phase.data['General']['Mass'] * phase.data['Histograms'][hist.name]['Scale'][0]
    for phase in project.phases()
])
cov = project.data.get('Covariance', {}).get('data', {})
summary = {
    'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
    'histogram': hist.name,
    'Rwp_percent': hist.get_wR(),
    'residuals': hist.data['data'][0],
    'fractions': (masses / masses.sum()).tolist(),
    'cells': [phase.get_cell() for phase in project.phases()],
    'scales': [phase.data['Histograms'][hist.name]['Scale'][0] for phase in project.phases()],
    'instrument': {key: hist.data['Instrument Parameters'][0][key][1]
                   for key in ['Zero', 'Polariz.', 'U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L']},
    'sample': {key: hist.data['Sample Parameters'][key][0]
               for key in ['Shift', 'Transparency', 'SurfRoughA', 'SurfRoughB']},
    'vary_count': len(cov.get('varyList', [])),
}
print(json.dumps(summary, indent=2, default=float))
