#!/usr/bin/env python3
"""Refine selected parameters in an existing multiphase GSAS-II project."""
from pathlib import Path
import json
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2


def apply(project, name):
    hist = project.histogram(0)
    phases = project.phases()
    inst = hist.data['Instrument Parameters'][0]
    if name == 'cell2':
        phases[1].data['General']['Cell'][0] = True
    elif name == 'isofix1':
        for atom in phases[0].atoms():
            atom.data[9] = 'I'
            atom.data[10] = 0.005
            atom.data[11:17] = [0.0] * 6
            atom.refinement_flags = atom.refinement_flags.replace('U', '')
    elif name == 'iso2':
        phase = phases[1]
        for atom in phase.atoms():
            atom.data[9] = 'I'
            atom.data[10] = 0.005
            atom.data[11:17] = [0.0] * 6
            atom.refinement_flags = ''.join(sorted(set(atom.refinement_flags + 'U')))
        project.add_EquivConstr(tuple(f'1::AUiso:{i}' for i in range(len(phase.atoms()))))
    elif name == 'isofix2':
        for atom in phases[1].atoms():
            atom.data[9] = 'I'
            atom.data[10] = 0.005
            atom.data[11:17] = [0.0] * 6
            atom.refinement_flags = atom.refinement_flags.replace('U', '')
    elif name == 'coords2W':
        for atom in phases[1].atoms():
            if atom.element == 'W':
                atom.refinement_flags = ''.join(sorted(set(atom.refinement_flags + 'X')))
    elif name == 'coords2all':
        for atom in phases[1].atoms():
            atom.refinement_flags = ''.join(sorted(set(atom.refinement_flags + 'X')))
    elif name == 'scales':
        for phase in phases:
            phase.data['Histograms'][hist.name]['Scale'][1] = True
    elif name.startswith('bg'):
        count = int(name[len('bg'):])
        background = hist.data['Background'][0]
        coeffs = list(background[3:3 + int(background[2])])
        background[:] = [background[0], True, count] + coeffs[:count] + [0.0] * max(0, count - len(coeffs))
    elif name == 'shlfree':
        inst['SH/L'][2] = True
    elif name.startswith('shl'):
        value = float(name[len('shl'):])
        inst['SH/L'][1] = value
        inst['SH/L'][2] = False
    elif name.startswith('wfix'):
        value = float(name[len('wfix'):])
        inst['W'][1] = value
        inst['W'][2] = False
    elif name == 'wfree':
        inst['W'][2] = True
    elif name.startswith('polfix'):
        value = float(name[len('polfix'):])
        inst['Polariz.'][1] = value
        inst['Polariz.'][2] = False
    elif name == 'zeroonly':
        hist.data['Sample Parameters']['Shift'] = [0.0, False]
        inst['Zero'][1] = 0.0
        inst['Zero'][2] = True
    elif name.startswith('zerostart'):
        hist.data['Sample Parameters']['Shift'] = [0.0, False]
        inst['Zero'][1] = float(name[len('zerostart'):])
        inst['Zero'][2] = True
    elif name == 'roughoff':
        hist.data['Sample Parameters']['SurfRoughA'] = [0.0, False]
        hist.data['Sample Parameters']['SurfRoughB'] = [0.0, False]
    elif name.startswith('roughA'):
        value = float(name[len('roughA'):])
        hist.data['Sample Parameters']['SurfRoughA'] = [value, False]
        hist.data['Sample Parameters']['SurfRoughB'][1] = True
    elif name == 'strain1':
        hap = phases[0].data['Histograms'][hist.name]
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = 1000.0
        hap['Mustrain'][2] = [True, False, False]
    elif name == 'strain2':
        hap = phases[1].data['Histograms'][hist.name]
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = 1000.0
        hap['Mustrain'][2] = [True, False, False]
    elif name == 'nostrain2':
        hap = phases[1].data['Histograms'][hist.name]
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = 0.0
        hap['Mustrain'][2] = [False, False, False]
    elif name == 'size1':
        hap = phases[0].data['Histograms'][hist.name]
        hap['Size'][0] = 'isotropic'
        hap['Size'][1][0] = 0.30
        hap['Size'][2] = [True, False, False]
    elif name == 'size2':
        hap = phases[1].data['Histograms'][hist.name]
        hap['Size'][0] = 'isotropic'
        hap['Size'][1][0] = 0.30
        hap['Size'][2] = [True, False, False]
    elif name.startswith('uniax1_'):
        axis = {'uniax1_001': [0, 0, 1], 'uniax1_100': [1, 0, 0],
                'uniax1_010': [0, 1, 0]}[name]
        hap = phases[0].data['Histograms'][hist.name]
        hap['Mustrain'][0] = 'uniaxial'
        hap['Mustrain'][1][0] = 1000.0
        hap['Mustrain'][1][1] = 1500.0
        hap['Mustrain'][2] = [True, True, False]
        hap['Mustrain'][3] = axis
    elif name.startswith('md1'):
        axis = {'md1001':[0,0,1], 'md1100':[1,0,0], 'md1010':[0,1,0],
                'md1110':[1,1,0], 'md1111':[1,1,1]}[name]
        po = phases[0].data['Histograms'][hist.name]['Pref.Ori.']
        po[0], po[1], po[2], po[3] = 'MD', 1.02, True, axis
    else:
        raise ValueError('unknown action: ' + name)


def main():
    if len(sys.argv) < 4:
        raise SystemExit('usage: refine_multi.py INPUT.gpx OUTPUT.gpx ACTION [ACTION...]')
    source, target, *actions = sys.argv[1:]
    G2.SetPrintLevel('warn')
    project = G2.G2Project(source, newgpx=target)
    for name in actions:
        apply(project, name)
    project.set_Controls('cycles', 18)
    project.data['Controls']['data']['min dM/M'] = 1e-6
    project.refine()
    project.save()
    hist = project.histogram(0)
    masses = np.array([p.data['General']['Mass'] * p.data['Histograms'][hist.name]['Scale'][0]
                       for p in project.phases()])
    result = {
        'Rwp': hist.get_wR(),
        'phases': [
            {'name': p.name, 'fraction': float(m / masses.sum()), 'cell': p.get_cell(),
             'scale': p.data['Histograms'][hist.name]['Scale'][0],
             'size': p.data['Histograms'][hist.name]['Size'],
             'mustrain': p.data['Histograms'][hist.name]['Mustrain'],
             'atoms': [a.data for a in p.atoms()]}
            for p, m in zip(project.phases(), masses)
        ],
        'instrument': {k: hist.data['Instrument Parameters'][0][k][1]
                       for k in ['Polariz.','U','W','X','SH/L']},
        'sample': {k: hist.data['Sample Parameters'][k][0]
                   for k in ['Shift','SurfRoughA','SurfRoughB']},
        'preferred_orientation': [
            p.data['Histograms'][hist.name]['Pref.Ori.'] for p in project.phases()
        ],
    }
    print(json.dumps(result, default=str))


if __name__ == '__main__':
    main()
