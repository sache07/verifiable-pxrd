#!/usr/bin/env python3
"""Write exact CIF, profile and JSON deliverables from the verified final model."""
from pathlib import Path
import csv
import hashlib
import json
import numpy as np
from GSASII import GSASIIscriptable as G2


root = Path(__file__).resolve().parent
project_path = root / 'final.gpx'
before = hashlib.sha256(project_path.read_bytes()).hexdigest()
project = G2.G2Project(str(project_path))
hist = project.histogram(0)

# Match the evaluator's deterministic CIF export: saved atoms, no covariance
# annotations. This leaves final.gpx unchanged and preserves printed precision.
project.data['Covariance']['data'] = {}
cif_paths = ['phase_1_MnWO4.cif', 'phase_2_WO3.cif']
for phase, name in zip(project.phases(), cif_paths):
    phase.export_CIF(str(root / name))
assert hashlib.sha256(project_path.read_bytes()).hexdigest() == before

with np.load(root / '.tmp/replay_final/prediction.npz', allow_pickle=False) as z:
    x = np.asarray(z['x'], float)
    observed = np.asarray(z['observed'], float)
    calculated = np.asarray(z['predicted'], float)
    background = np.asarray(z['background'], float)
difference = observed - calculated

with (root / 'fit.csv').open('w', newline='') as stream:
    writer = csv.writer(stream)
    writer.writerow(['two_theta', 'observed', 'calculated', 'difference', 'background'])
    for row in zip(x, observed, calculated, difference, background):
        writer.writerow([format(float(value), '.12g') for value in row])

weights = 1.0 / np.maximum(observed, 1.0)
loss = float(np.sum(weights * difference ** 2))
denominator = float(np.sum(weights * observed ** 2))
rwp = 100.0 * np.sqrt(loss / denominator)
rp = 100.0 * np.sum(np.abs(difference)) / np.sum(observed)
residuals = hist.data['data'][0]
rexp = float(residuals['wRmin'])

cell_masses = np.array([phase.data['General']['Mass'] for phase in project.phases()], float)
scales = np.array([
    phase.data['Histograms'][hist.name]['Scale'][0] for phase in project.phases()
], float)
fractions = cell_masses * scales
fractions /= fractions.sum()

# Formal scale-covariance uncertainty is retained for reference even though
# model/background selection is the dominant fraction uncertainty.
full_project = G2.G2Project(str(project_path))
covariance = full_project.data['Covariance']['data']
vary = [str(v) for v in covariance['varyList']]
matrix = np.asarray(covariance['covMatrix'], float)
indices = [vary.index('0:0:Scale'), vary.index('1:0:Scale')]
scale_cov = matrix[np.ix_(indices, indices)]
den = float(np.dot(cell_masses, scales))
gradient_minor = np.array([
    -cell_masses[0] * cell_masses[1] * scales[1] / den ** 2,
    cell_masses[1] * cell_masses[0] * scales[0] / den ** 2,
])
minor_su = float(np.sqrt(gradient_minor @ scale_cov @ gradient_minor))

result = {
    'schema': 'pxrd-phase-analysis/1',
    'project_path': 'final.gpx',
    'profile_path': 'fit.csv',
    'refinement_histogram': hist.name,
    'fraction_basis': 'Normalized over the modeled crystalline phases only.',
    'phases': [
        {
            'name': 'MnWO4 (wolframite)',
            'formula': 'MnWO4',
            'space_group': 'P 1 2/c 1 (No. 13)',
            'cif_path': cif_paths[0],
            'weight_fraction': float(fractions[0]),
            'weight_fraction_formal_su': minor_su,
        },
        {
            'name': 'WO3 (room-temperature monoclinic)',
            'formula': 'WO3',
            'space_group': 'P 1 21/c 1 (No. 14)',
            'cif_path': cif_paths[1],
            'weight_fraction': float(fractions[1]),
            'weight_fraction_formal_su': minor_su,
        },
    ],
    'fit_statistics': {
        'rwp_percent': float(rwp),
        'rp_percent': float(rp),
        'rexp_percent': rexp,
        'goodness_of_fit': float(rwp / rexp),
        'reduced_chi_square': float((rwp / rexp) ** 2),
        'weighted_residual_sum': loss,
        'durbin_watson': float(residuals['Durbin-Watson']),
        'n_points': int(len(x)),
        'n_refined_parameters': int(len(vary)),
        'calculation': 'Fresh native GSAS-II atomic/profile replay over the full observed grid.',
    },
    'verification': {
        'project_sha256': before,
        'replay_status': 'replayed',
        'profile_review_flags': [],
    },
}
(root / 'result.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
print(json.dumps(result, indent=2))
