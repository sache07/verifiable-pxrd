#!/usr/bin/env python3
"""Build and inspect an initial GSAS-II MnWO4 refinement project."""
from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parent
SOURCE = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif')


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def main():
    G2.SetPrintLevel('warn')
    out = ROOT / '.tmp' / 'initial.gpx'
    out.parent.mkdir(exist_ok=True)
    project = G2.G2Project(newgpx=str(out))
    phase = project.add_phase(str(SOURCE), phasename='MnWO4_wolframite', fmthint='CIF')
    hist = project.add_powder_histogram(
        str(ROOT / 'inputs' / 'pattern.csv'),
        str(ROOT / 'instrument.instprm'),
        phases=[phase],
        fmthint='comma/tab/semicolon separated',
    )
    hist.SampleParameters['Type'] = 'Bragg-Brentano'
    hist.SampleParameters['Gonio. radius'] = 200.0
    hist.SampleParameters['Scale'] = [1.0, False]
    # Neutralize nuisance terms before testing them.
    hist.SampleParameters['Shift'] = [0.0, False]
    hist.SampleParameters['Transparency'] = [0.0, False]
    hist.SampleParameters['SurfRoughA'] = [0.0, False]
    hist.SampleParameters['SurfRoughB'] = [0.0, False]
    hap = phase.data['Histograms'][hist.name]
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][0] = 1000.0
    hap['Size'][1][1] = 1000.0
    hap['Size'][2] = [False, False, False]
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][0] = 0.0
    hap['Mustrain'][1][1] = 0.0
    hap['Mustrain'][2] = [False, False, False]
    hap['Pref.Ori.'][0] = 'MD'
    hap['Pref.Ori.'][1] = 1.0
    hap['Pref.Ori.'][2] = False
    hap['Pref.Ori.'][3] = [0, 0, 1]
    hap['Extinction'] = [0.0, False]
    hist.set_refinements({'Background': {
        'type': 'chebyschev-1', 'no. coeffs': 6,
        'coeffs': [1100.0, -500.0, 350.0, -220.0, 130.0, -70.0],
        'refine': False,
    }})
    project.set_Controls('cycles', 8)
    project.save()
    report = {
        'histogram': hist.name,
        'npoints': len(hist.data['data'][1][0]),
        'data_arrays': [
            {'shape': list(np.asarray(a).shape), 'min': float(np.min(a)), 'max': float(np.max(a))}
            for a in hist.data['data'][1]
        ],
        'instrument': plain(hist.data['Instrument Parameters'][0]),
        'sample': plain(hist.data['Sample Parameters']),
        'background': plain(hist.data['Background']),
        'hap': plain(hap),
        'cell': phase.get_cell(),
        'atoms': [plain(a.data) for a in phase.atoms()],
    }
    print(json.dumps(report, indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
