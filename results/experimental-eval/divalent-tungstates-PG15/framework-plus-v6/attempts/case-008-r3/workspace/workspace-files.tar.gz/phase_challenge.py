#!/usr/bin/env python3
"""Add one candidate phase to a converged common-profile project and refine scale."""
from pathlib import Path
import json
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    if len(sys.argv) < 4:
        raise SystemExit('usage: phase_challenge.py INPUT.gpx CANDIDATE.cif OUTPUT.gpx [cell]')
    source, cif, target, *options = sys.argv[1:]
    G2.SetPrintLevel('warn')
    project = G2.G2Project(source, newgpx=target)
    hist = project.histogram(0)
    ident = Path(cif).stem
    phase = project.add_phase(cif, phasename='challenge_' + ident, histograms=[hist], fmthint='CIF')
    hap = phase.data['Histograms'][hist.name]
    hap['Scale'] = [0.05 if 'small' in options else 2.0, True]
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][0] = 10.0
    hap['Size'][2] = [False, False, False]
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][0] = 1000.0 if 'strain' in options else 0.0
    hap['Mustrain'][2] = ['strain' in options, False, False]
    hap['Pref.Ori.'][0] = 'MD'
    hap['Pref.Ori.'][1] = 1.0
    hap['Pref.Ori.'][2] = False
    hap['Extinction'] = [0.0, False]
    phase.data['General']['Cell'][0] = 'cell' in options
    for atom in phase.atoms():
        atom.data[9] = 'I'
        atom.data[10] = 0.005
        atom.data[11:17] = [0.0] * 6
        atom.refinement_flags = ''
    project.set_Controls('cycles', 18)
    project.data['Controls']['data']['min dM/M'] = 1e-6
    project.refine()
    project.save()
    masses = np.array([
        p.data['General']['Mass'] * p.data['Histograms'][hist.name]['Scale'][0]
        for p in project.phases()
    ])
    cov = project.data.get('Covariance', {}).get('data', {})
    vary = [str(v) for v in cov.get('varyList', [])]
    sig = np.asarray(cov.get('sig', []), float)
    scale_su = None
    key = f'{phase.id}:0:Scale'
    if key in vary:
        scale_su = float(sig[vary.index(key)])
    result = {
        'candidate': ident,
        'Rwp': hist.get_wR(),
        'scale': float(hap['Scale'][0]),
        'scale_su': scale_su,
        'weight_fraction': float(masses[-1] / masses.sum()),
        'cell': phase.get_cell(),
        'strain': hap['Mustrain'][1][0],
        'all_phases': [
            {'name': p.name, 'scale': p.data['Histograms'][hist.name]['Scale'][0],
             'mass': p.data['General']['Mass'], 'fraction': float(m / masses.sum())}
            for p, m in zip(project.phases(), masses)
        ],
    }
    print(json.dumps(result))


if __name__ == '__main__':
    main()
