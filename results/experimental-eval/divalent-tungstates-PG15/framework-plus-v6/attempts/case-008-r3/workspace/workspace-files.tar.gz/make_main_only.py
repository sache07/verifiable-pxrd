#!/usr/bin/env python3
"""Remove the second phase from a GSAS-II project and reconverge."""
import sys
from GSASII import GSASIIscriptable as G2


source, target = sys.argv[1:3]
G2.SetPrintLevel('warn')
project = G2.G2Project(source, newgpx=target)
hist = project.histogram(0)
phase = project.phases()[1]
del project.data['Phases'][phase.name]
hist.data.get('Reflection Lists', {}).pop(phase.name, None)
for group in project.names:
    if group and group[0] == 'Phases' and phase.name in group:
        group.remove(phase.name)
project.set_Controls('cycles', 18)
project.data['Controls']['data']['min dM/M'] = 1e-6
if 'norefine' not in sys.argv[3:]:
    project.refine()
project.save()
print(hist.get_wR())
