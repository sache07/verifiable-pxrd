#!/usr/bin/env python3
"""Run conservative baseline GSAS-II refinements and print diagnostics."""
from pathlib import Path
import json
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2


def vals(project):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data['Instrument Parameters'][0]
    sample = hist.data['Sample Parameters']
    hap = phase.data['Histograms'][hist.name]
    cov = project.data.get('Covariance', {}).get('data', {})
    return {
        'Rwp_percent': hist.get_wR(),
        'residuals': hist.data['data'][0],
        'cell': phase.get_cell(),
        'scale': hap['Scale'],
        'background': hist.data['Background'][0],
        'instrument': {k: inst[k] for k in ['Zero','Polariz.','U','V','W','X','Y','Z','SH/L']},
        'sample': {k: sample[k] for k in ['Shift','Transparency','SurfRoughA','SurfRoughB']},
        'size': hap['Size'],
        'mustrain': hap['Mustrain'],
        'preferred_orientation': hap['Pref.Ori.'],
        'varyList': [str(v) for v in cov.get('varyList', [])],
        'sig': np.asarray(cov.get('sig', [])).tolist(),
    }


def refine(project, label):
    project.refine()
    target = Path(project.filename).with_name(label + '.gpx')
    project.save(str(target))
    print('\n###', label)
    print(json.dumps(vals(project), indent=2, default=str))


def main():
    if len(sys.argv) != 2:
        raise SystemExit('usage: run_steps.py INPUT.gpx')
    G2.SetPrintLevel('warn')
    project = G2.G2Project(sys.argv[1], newgpx=str(Path(sys.argv[1]).with_name('working.gpx')))
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data['Instrument Parameters'][0]
    sample = hist.data['Sample Parameters']
    hap = phase.data['Histograms'][hist.name]
    project.set_Controls('cycles', 12)
    project.data['Controls']['data']['min dM/M'] = 1e-5

    # Common scale and smooth six-term background only.
    hist.data['Background'][0][1] = True
    hist.SampleParameters['Scale'][1] = False
    hap['Scale'][1] = True
    refine(project, 'stage1_background_scale')

    # One Bragg-Brentano specimen displacement correction.
    sample['Shift'][1] = True
    refine(project, 'stage2_shift')

    # Lattice after angular correction.
    phase.data['General']['Cell'][0] = True
    refine(project, 'stage3_cell')

    # Low-dimensional nonnegative instrument terms. V/Y/Z remain neutral/fixed.
    for key in ['U', 'W', 'X']:
        inst[key][2] = True
    refine(project, 'stage4_profile')

    # Re-converge all accepted baseline terms.
    refine(project, 'stage5_baseline')


if __name__ == '__main__':
    main()
