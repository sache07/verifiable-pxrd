#!/usr/bin/env python3
"""Summarize and plot a GSAS-II powder refinement."""
from pathlib import Path
import sys

import matplotlib.pyplot as plt
import numpy as np
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2


project = G2.G2Project(sys.argv[1])
hist = project.histogram(0)
x, yo, wt, yc, bg, yd = map(np.asarray, hist.data['data'][1][:6])
lo, hi = hist.data['Limits'][1]
mask = (x >= lo) & (x <= hi)
x, yo, wt, yc, bg, yd = (v[mask] for v in (x, yo, wt, yc, bg, yd))
resid = yo - yc

print('range', lo, hi, 'points', len(x), 'Rwp', hist.get_wR())
for a, b in zip(range(10, 100, 10), range(20, 110, 10)):
    use = (x >= a) & (x < b)
    if use.any():
        rwp = 100 * np.sqrt(np.sum(wt[use] * resid[use] ** 2) / np.sum(wt[use] * yo[use] ** 2))
        print(f'bin {a:02d}-{b:03d}: Rwp={rwp:7.3f} max|resid|={np.max(np.abs(resid[use])):8.1f}')

sigma = np.sqrt(np.maximum(yo, 1.0))
z = resid / sigma
distance = max(1, int(round(0.08 / np.median(np.diff(x)))))
pos, _ = find_peaks(z, prominence=2.0, distance=distance)
neg, _ = find_peaks(-z, prominence=2.0, distance=distance)
ranked = sorted([(abs(z[i]), '+' if z[i] >= 0 else '-', i) for i in np.r_[pos, neg]], reverse=True)
print('largest standardized residual extrema')
for _, sign, i in ranked[:40]:
    print(f'{x[i]:10.5f} {sign} z={z[i]:8.3f} resid={resid[i]:9.1f} obs={yo[i]:9.1f} calc={yc[i]:9.1f}')

if len(sys.argv) > 2:
    out = Path(sys.argv[2])
    fig, axes = plt.subplots(2, 1, figsize=(14, 8), sharex=True,
                             gridspec_kw={'height_ratios': [3, 1]})
    axes[0].plot(x, yo, color='black', lw=.5, label='observed')
    axes[0].plot(x, yc, color='red', lw=.65, label='calculated')
    axes[0].plot(x, bg, color='royalblue', lw=.7, label='background')
    axes[0].legend(loc='upper right')
    axes[0].set_ylabel('Counts')
    axes[1].axhline(0, color='0.5', lw=.5)
    axes[1].plot(x, resid, color='navy', lw=.55)
    axes[1].set_ylabel('Obs. - calc.')
    axes[1].set_xlabel(r'$2\theta$ (degrees)')
    fig.tight_layout()
    fig.savefig(out, dpi=180)
