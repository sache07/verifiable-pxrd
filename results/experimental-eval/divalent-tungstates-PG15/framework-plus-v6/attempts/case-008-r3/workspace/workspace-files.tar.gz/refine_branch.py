#!/usr/bin/env python3
"""Apply selected GSAS-II refinements to an existing project."""
from pathlib import Path
import json
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2


def summarize(project):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data['Instrument Parameters'][0]
    sample = hist.data['Sample Parameters']
    hap = phase.data['Histograms'][hist.name]
    cov = project.data.get('Covariance', {}).get('data', {})
    return {
        'Rwp': hist.get_wR(),
        'GOF': hist.data['data'][0].get('GOF'),
        'cell': phase.get_cell(),
        'scale': hap['Scale'][0],
        'instrument': {k: inst[k][1] for k in ['Zero','Polariz.','U','V','W','X','Y','Z','SH/L']},
        'sample': {k: sample[k][0] for k in ['Shift','Transparency','SurfRoughA','SurfRoughB']},
        'size': hap['Size'],
        'mustrain': hap['Mustrain'],
        'preferred_orientation': hap['Pref.Ori.'],
        'background': hist.data['Background'][0],
        'atoms': [a.data for a in phase.atoms()],
        'varyList': [str(v) for v in cov.get('varyList', [])],
        'sig': np.asarray(cov.get('sig', [])).tolist(),
    }


def action(project, name):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data['Instrument Parameters'][0]
    sample = hist.data['Sample Parameters']
    hap = phase.data['Histograms'][hist.name]
    if name == 'shl':
        inst['SH/L'][2] = True
    elif name == 'rough':
        sample['SurfRoughA'] = [0.30, True]
        sample['SurfRoughB'] = [0.10, True]
    elif name.startswith('roughA'):
        aval = float(name[len('roughA'):])
        sample['SurfRoughA'] = [aval, False]
        sample['SurfRoughB'] = [0.10, True]
    elif name == 'polarization':
        inst['Polariz.'][2] = True
    elif name == 'coordinates':
        for atom in phase.atoms():
            atom.refinement_flags = ''.join(sorted(set(atom.refinement_flags + 'X')))
    elif name == 'coordinates_metals':
        for atom in phase.atoms()[:2]:
            atom.refinement_flags = ''.join(sorted(set(atom.refinement_flags + 'X')))
    elif name == 'coordinates_oxygen':
        for atom in phase.atoms()[2:]:
            atom.refinement_flags = ''.join(sorted(set(atom.refinement_flags + 'X')))
    elif name == 'atomic_iso':
        # Registered synthetic library models use one scalar Uiso per phase.
        for atom in phase.atoms():
            atom.data[9] = 'I'
            atom.data[10] = 0.005
            atom.data[11:17] = [0.0] * 6
            atom.refinement_flags = ''.join(sorted(set(atom.refinement_flags + 'U')))
        project.add_EquivConstr(tuple(f'0::AUiso:{i}' for i in range(len(phase.atoms()))))
    elif name == 'size':
        hap['Size'][0] = 'isotropic'
        hap['Size'][1][0] = 0.30
        hap['Size'][2] = [True, False, False]
    elif name == 'size_no_x':
        inst['X'][2] = False
        hap['Size'][0] = 'isotropic'
        hap['Size'][1][0] = 0.30
        hap['Size'][2] = [True, False, False]
    elif name == 'strain':
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = 1000.0
        hap['Mustrain'][2] = [True, False, False]
    elif name == 'strain_resetx':
        inst['X'][1] = 3.0
        inst['X'][2] = True
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = 1000.0
        hap['Mustrain'][2] = [True, False, False]
    elif name.startswith('uniax'):
        axis = {'uniax001':[0,0,1], 'uniax100':[1,0,0], 'uniax010':[0,1,0]}[name]
        inst['X'][1] = 3.0
        inst['X'][2] = True
        hap['Mustrain'][0] = 'uniaxial'
        hap['Mustrain'][1][0] = 1000.0
        hap['Mustrain'][1][1] = 2500.0
        hap['Mustrain'][2] = [True, True, False]
        hap['Mustrain'][3] = axis
    elif name == 'strain_no_u':
        inst['U'][2] = False
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = 1000.0
        hap['Mustrain'][2] = [True, False, False]
    elif name.startswith('md'):
        axis = {'md001':[0,0,1], 'md100':[1,0,0], 'md010':[0,1,0],
                'md110':[1,1,0], 'md111':[1,1,1]}[name]
        hap['Pref.Ori.'][0] = 'MD'
        hap['Pref.Ori.'][1] = 1.02
        hap['Pref.Ori.'][2] = True
        hap['Pref.Ori.'][3] = axis
    elif name == 'clear_md':
        hap['Pref.Ori.'][1] = 1.0
        hap['Pref.Ori.'][2] = False
    else:
        raise ValueError('unknown action: ' + name)


def main():
    if len(sys.argv) < 4:
        raise SystemExit('usage: refine_branch.py INPUT.gpx OUTPUT.gpx ACTION [ACTION...]')
    source, target, *actions = sys.argv[1:]
    G2.SetPrintLevel('warn')
    project = G2.G2Project(source, newgpx=target)
    project.set_Controls('cycles', 18)
    project.data['Controls']['data']['min dM/M'] = 1e-6
    for name in actions:
        action(project, name)
    project.refine()
    project.save()
    print(json.dumps(summarize(project), indent=2, default=str))


if __name__ == '__main__':
    main()
