from pathlib import Path
import json
import math
import sys

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


ROOT = Path.cwd()
WORK = ROOT / ".tmp" / "trials"
WORK.mkdir(parents=True, exist_ok=True)


def instrument_text(U=15.0, W=15.0, X=2.0, shl=0.03, polarization=0.80, zero=0.0):
    return (
        "# Cu K-alpha laboratory instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        f"Zero:{zero};Polariz.:{polarization};Azimuth:0.0\n"
        f"U:{U};V:0.0;W:{W};X:{X};Y:0.0;Z:0.0;SH/L:{shl}\n"
    )


def summary(project, label):
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    x, obs, weight, calc, back, diff = [np.asarray(a, float) for a in arrays[:6]]
    residual = obs - calc
    wr = 100 * np.sqrt(np.sum(weight * residual**2) / np.sum(weight * obs**2))
    signal = calc - back
    print(f"STAGE {label}: project_wR={hist.get_wR()} recomputed_wR={wr:.6f} calc=[{calc.min():.3f},{calc.max():.3f}] back=[{back.min():.3f},{back.max():.3f}] signal_max={signal.max():.3f}")
    inst = hist.data["Instrument Parameters"][0]
    print("  instrument", {k: inst[k] for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."] if k in inst})
    print("  sample", {k: hist.SampleParameters[k] for k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"]})
    print("  background", hist.data["Background"][0])
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("  phase", phase.name, "cell", phase.get_cell(), "mass", phase.data["General"]["Mass"],
              "scale", hap["Scale"], "size", hap["Size"], "mustrain", hap["Mustrain"], "PO", hap["Pref.Ori."])
    cov = project.data.get("Covariance", {}).get("data", {})
    print("  GOF", cov.get("Rvals", {}).get("GOF"), "vary", cov.get("varyList", []))


def set_neutral_profile(project):
    hist = project.histogram(0)
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][1][1] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]


def build():
    x, y = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1).T
    data_path = WORK / "pattern.xye"
    np.savetxt(data_path, np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]), fmt="%.10f %.8f %.8f")
    inst_path = WORK / "instrument.instprm"
    inst_path.write_text(instrument_text())
    project = G2.G2Project(newgpx=str(WORK / "base.gpx"))
    hist = project.add_powder_histogram(str(data_path), str(inst_path), fmthint="xye")
    phase_files = [
        ("WO3_monoclinic", ROOT / ".tmp" / "parents" / "wo3_2311041.cif"),
        ("CaCO3_calcite", ROOT / ".tmp" / "parents" / "caco3_1547347.cif"),
        ("CaWO4_scheelite", ROOT / ".tmp" / "parents" / "cawo4_7219229.cif"),
    ]
    for name, path in phase_files:
        project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
    set_neutral_profile(project)
    baseline = percentile_filter(y, percentile=12, size=501, mode="nearest")
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    coeffs = np.polynomial.chebyshev.chebfit(t, baseline, 8)
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])],
                          "Background": {"type": "chebyschev-1", "no. coeffs": 9,
                                         "coeffs": coeffs.tolist(), "refine": False}})
    # Similar initial mass fractions, in the GSAS scale convention Scale*cell mass.
    initial_fractions = [0.58, 0.20, 0.22]
    common_scale = 30000.0
    for phase, fraction in zip(project.phases(), initial_fractions):
        phase.data["Histograms"][hist.name]["Scale"] = [common_scale * fraction / phase.data["General"]["Mass"], False]
    project.set_Controls("cycles", 0)
    project.refine()
    summary(project, "initial")
    project.save(str(WORK / "base.gpx"))
    return project


def refine_baseline(project):
    hist = project.histogram(0)
    project.set_Controls("cycles", 8)

    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.refine()
    summary(project, "scales_background")
    project.save(str(WORK / "stage1.gpx"))

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine()
    summary(project, "zero_cells")
    project.save(str(WORK / "stage2.gpx"))

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine()
    summary(project, "common_profile")
    project.save(str(WORK / "stage3.gpx"))
    return project


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    print("GSAS-II", GSASIIpath.GetVersionNumber())
    refine_baseline(build())
