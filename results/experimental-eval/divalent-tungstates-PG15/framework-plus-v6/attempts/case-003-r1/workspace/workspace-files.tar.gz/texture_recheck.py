from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


PHASES = {
    "calcite": ("CaCO3_calcite", [[0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]]),
    "scheelite": ("CaWO4_scheelite", [[0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]]),
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("phase", choices=PHASES)
    parser.add_argument("--tag", required=True)
    args = parser.parse_args()
    phase_name, axes = PHASES[args.phase]
    outdir = Path(".tmp/trials/texture_recheck")
    outdir.mkdir(parents=True, exist_ok=True)
    rows = []

    for axis in [None, *axes]:
        label = "none" if axis is None else "".join(map(str, axis))
        destination = outdir / f"{args.tag}_{args.phase}_{label}.gpx"
        project = G2.G2Project(gpxfile=str(args.source), newgpx=str(destination))
        hist = project.histogram(0)
        po = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0 if axis is None else 1.05
        po[2] = axis is not None
        if axis is not None:
            po[3] = axis
        project.set_Controls("cycles", 12)
        project.refine()
        project.refine()
        value = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
        row = {"axis": axis, "rwp_percent": hist.get_wR(), "md_ratio": value[1],
               "gpx": str(destination)}
        rows.append(row)
        print(json.dumps(row, sort_keys=True))

    (outdir / f"{args.tag}_{args.phase}.json").write_text(
        json.dumps(rows, indent=2, sort_keys=True) + "\n"
    )


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
