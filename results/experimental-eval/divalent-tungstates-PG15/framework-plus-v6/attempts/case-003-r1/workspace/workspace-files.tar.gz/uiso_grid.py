from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("target_phase")
    parser.add_argument("--base", nargs=3, type=float, default=[0.005, 0.005, 0.005])
    parser.add_argument("--values", nargs="+", type=float,
                        default=[0.003, 0.005, 0.008, 0.012, 0.016, 0.020])
    parser.add_argument("--tag", default="round1")
    args = parser.parse_args()

    out = Path(".tmp/trials/uiso_grid")
    out.mkdir(parents=True, exist_ok=True)
    phase_names = ["WO3_monoclinic", "CaCO3_calcite", "CaWO4_scheelite"]
    if args.target_phase not in phase_names:
        raise ValueError(args.target_phase)
    target_index = phase_names.index(args.target_phase)
    rows = []

    for value in args.values:
        assignment = list(args.base)
        assignment[target_index] = value
        stem = f"{args.tag}_{target_index}_{value:.4f}".replace(".", "p")
        destination = out / f"{stem}.gpx"
        project = G2.G2Project(gpxfile=str(args.source), newgpx=str(destination))
        project.set_Controls("cycles", 12)
        for name, uiso in zip(phase_names, assignment):
            for atom in project.phase(name).atoms():
                atom.uiso = uiso
                atom.refinement_flags = ""
        project.refine()
        # A second pass makes each fixed-Uiso comparison start from an equally
        # reconverged nuisance/profile model.
        project.refine()
        hist = project.histogram(0)
        row = {
            "target": args.target_phase,
            "value": value,
            "assignment": assignment,
            "rwp_percent": hist.get_wR(),
            "gpx": str(destination),
        }
        rows.append(row)
        print(json.dumps(row, sort_keys=True))

    (out / f"{args.tag}_{target_index}.json").write_text(
        json.dumps(rows, indent=2, sort_keys=True) + "\n"
    )


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
