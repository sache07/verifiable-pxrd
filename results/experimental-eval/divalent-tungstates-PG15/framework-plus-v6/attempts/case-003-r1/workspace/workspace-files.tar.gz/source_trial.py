from pathlib import Path
import argparse
import copy

from GSASII import GSASIIscriptable as G2

from refine_trial import summary


ROOT = Path.cwd()
SOURCE = ROOT / ".tmp" / "trials" / "profile_full1.gpx"


def run(identifier):
    out = ROOT / ".tmp" / "trials" / f"source_{identifier}.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(out))
    hist = project.histogram(0)
    old = project.phase("WO3_monoclinic")
    old_hap = copy.deepcopy(old.data["Histograms"][hist.name])
    old.data["Histograms"][hist.name]["Use"] = False
    old.data["Histograms"][hist.name]["Scale"] = [0.0, False]
    old.set_refinements({"Cell": False})
    new = project.add_phase(str(ROOT / ".tmp" / "parents" / f"wo3_{identifier}.cif"),
                            phasename=f"WO3_trial_{identifier}", histograms=[hist], fmthint="CIF")
    new_hap = new.data["Histograms"][hist.name]
    for key in ["Scale", "Size", "Mustrain", "Pref.Ori.", "Extinction", "Babinet"]:
        new_hap[key] = copy.deepcopy(old_hap[key])
    new_hap["Use"] = True
    new_hap["Scale"][1] = True
    new.set_refinements({"Cell": True})
    # Remove the unsupported calcite size term before replaying the candidate.
    calcite_hap = project.phase("CaCO3_calcite").data["Histograms"][hist.name]
    calcite_hap["Size"][1][0] = 10.0
    calcite_hap["Size"][2] = [False, False, False]
    project.set_Controls("cycles", 12)
    project.refine()
    summary(project, f"source_{identifier}")
    project.save(str(out))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("identifier", choices=["2106293", "1563541", "1528915"])
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run(args.identifier)
