from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2

from refine_trial import summary


ROOT = Path.cwd()
SOURCE = ROOT / ".tmp" / "trials" / "stage1.gpx"


STARTS = {
    "full1": {
        "instrument": [10.0, 10.0, 2.0],
        "size": [0.20, 0.60, 0.08],
        "strain": [500.0, 500.0, 3000.0],
        "size_refine": [True, True, True],
        "strain_refine": [True, True, True],
    },
    "full2": {
        "instrument": [30.0, 25.0, 4.0],
        "size": [0.50, 1.00, 0.15],
        "strain": [1500.0, 1500.0, 5000.0],
        "size_refine": [True, True, True],
        "strain_refine": [True, True, True],
    },
    "size": {
        "instrument": [15.0, 15.0, 2.0],
        "size": [0.20, 0.60, 0.08],
        "strain": [0.0, 0.0, 0.0],
        "size_refine": [True, True, True],
        "strain_refine": [False, False, False],
    },
    "strain": {
        "instrument": [15.0, 15.0, 2.0],
        "size": [10.0, 10.0, 10.0],
        "strain": [1000.0, 1000.0, 3000.0],
        "size_refine": [False, False, False],
        "strain_refine": [True, True, True],
    },
}


def run(name):
    cfg = STARTS[name]
    out = ROOT / ".tmp" / "trials" / f"profile_{name}.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(out))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key, value in zip(["U", "W", "X"], cfg["instrument"]):
        inst[key][1] = value
        inst[key][2] = False
    for phase, size, strain, size_refine, strain_refine in zip(
            project.phases(), cfg["size"], cfg["strain"], cfg["size_refine"], cfg["strain_refine"]):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][2] = [size_refine, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][2] = [strain_refine, False, False]
    project.set_Controls("cycles", 12)
    project.refine()
    summary(project, name + "_phase_profile")
    # Only after phase terms have moved from sensible starts, estimate a common profile.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.refine()
    summary(project, name + "_common_profile")
    project.save(str(out))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("name", choices=sorted(STARTS))
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run(args.name)
