from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path.cwd()
SOURCE = ROOT / ".tmp/trials/coordinate_projections/wo3_w_0p9000.gpx"
FINAL = ROOT / "final.gpx"


def max_shift(project):
    return float(project.data.get("Covariance", {}).get("data", {})
                 .get("Rvals", {}).get("Max shft/sig", np.inf))


def converge(project, label, maximum_passes=5):
    project.set_Controls("cycles", 12)
    history = []
    for iteration in range(maximum_passes):
        project.refine()
        row = {"label": label, "pass": iteration + 1,
               "rwp_percent": project.histogram(0).get_wR(),
               "max_shift_over_esd": max_shift(project)}
        history.append(row)
        print(json.dumps(row, sort_keys=True))
        if row["max_shift_over_esd"] < 0.10:
            break
    return history


def enforce_model(project):
    hist = project.histogram(0)
    x = np.asarray(hist.data["data"][1][0], float)
    hist.data["Limits"] = [[float(x[0]), float(x[-1])],
                           [float(x[0]), float(x[-1])]]
    # These fixed common isotropic values are interior to the laboratory's
    # physical range and were selected from fixed-value profile trials. Only
    # the physically projected WO3 W coordinates differ from the screened
    # room-temperature parent structures.
    fixed_uiso = {
        "WO3_monoclinic": 0.008,
        "CaCO3_calcite": 0.019,
        "CaWO4_scheelite": 0.010,
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        for atom in phase.atoms():
            atom.uiso = fixed_uiso[phase.name]
            atom.refinement_flags = ""
    return hist


def report(project, histories):
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    phase_rows = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        phase_rows.append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "cell_mass_amu": phase.data["General"]["Mass"],
            "size_um": hap["Size"][1][0],
            "mustrain": hap["Mustrain"][:4],
            "preferred_orientation": hap["Pref.Ori."][:4],
            "uiso_A2": sorted(set(a.uiso for a in phase.atoms())),
        })
    for row, value in zip(phase_rows, masses):
        row["weight_fraction"] = value / sum(masses)
    arrays = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    x, obs, weights, calc, background, difference = arrays
    summary = {
        "histogram": hist.name,
        "rwp_percent": hist.get_wR(),
        "rp_percent": cov.get("Rvals", {}).get("Rwp"),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "max_shift_over_esd": max_shift(project),
        "background_range_counts": [float(background.min()), float(background.max())],
        "calculated_range_counts": [float(calc.min()), float(calc.max())],
        "phase_rows": phase_rows,
        "histories": histories,
    }
    print(json.dumps(summary, indent=2, sort_keys=True))
    (ROOT / ".tmp/final_refinement_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )


def main():
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    enforce_model(project)
    histories = converge(project, "initial")
    project.save(str(FINAL))

    # Reopen the actual deliverable and reconverge it, so the saved object is
    # the exact full-range project used for all downstream exports.
    project = G2.G2Project(gpxfile=str(FINAL))
    enforce_model(project)
    histories += converge(project, "reopened")
    project.save(str(FINAL))
    report(project, histories)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
