from pathlib import Path
import argparse

from GSASII import GSASIIscriptable as G2

from refine_trial import summary


ROOT = Path.cwd()
TRIALS = ROOT / ".tmp" / "trials"


def clean(project):
    hist = project.histogram(0)
    # U repeatedly attempts to cross the physical U >= 0 boundary once phase
    # broadening is present. Keep it at the neutral boundary and refine W/X.
    hist.data["Instrument Parameters"][0]["U"][1] = 0.0
    hist.data["Instrument Parameters"][0]["U"][2] = False
    hist.data["Instrument Parameters"][0]["X"][1] = 0.1
    hist.data["Instrument Parameters"][0]["X"][2] = False
    # This size term was singular in independent starts; retain only strain for calcite.
    hap = project.phase("CaCO3_calcite").data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False, False, False]
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Pref.Ori."][2] = False
    return hist


def refine_and_save(project, name):
    project.set_Controls("cycles", 12)
    project.refine()
    summary(project, name)
    out = TRIALS / f"nuisance_{name}.gpx"
    project.save(str(out))
    return out


def run(name):
    if name == "baseline":
        source = TRIALS / "profile_full1.gpx"
    elif name in {"polarization", "roughness", "shl"}:
        source = TRIALS / "nuisance_shift.gpx"
    else:
        source = TRIALS / "nuisance_baseline.gpx"
    out = TRIALS / f"nuisance_{name}.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(out))
    hist = clean(project)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.SampleParameters

    if name == "shift":
        inst["Zero"][1], inst["Zero"][2] = 0.0, False
        sample["Shift"] = [-580.0, True]
    elif name == "polarization":
        inst["Polariz."][2] = True
    elif name == "roughness":
        sample["SurfRoughA"] = [0.20, True]
        sample["SurfRoughB"] = [0.10, True]
    elif name == "shl":
        inst["SH/L"][2] = True
    elif name != "baseline":
        raise ValueError(name)
    first = refine_and_save(project, name)
    if name == "baseline":
        # Explicit save/reopen/replay check with the same full-range flags.
        replay = G2.G2Project(gpxfile=str(first), newgpx=str(TRIALS / "nuisance_baseline_replay.gpx"))
        refine_and_save(replay, "baseline_replay")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("name", choices=["baseline", "shift", "polarization", "roughness", "shl"])
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run(args.name)
