from pathlib import Path
import sys
import warnings

from pymatgen.core import Structure


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
RUNTIME = Path("learned/divalent-tungstates/runtime").resolve()
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model


SOURCES = {
    "wo3_2311041": "2311041",
    "wo3_2106293": "2106293",
    "wo3_1563541": "1563541",
    "wo3_1528915": "1528915",
    "caco3_1547347": "1547347",
    "cawo4_7219229": "7219229",
    "cao_1563196": "1563196",
}


def cod_path(identifier: str) -> Path:
    return ROOT / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


out = Path(".tmp/parents")
out.mkdir(parents=True, exist_ok=True)
for name, identifier in SOURCES.items():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = Structure.from_file(cod_path(identifier), primitive=False)
    destination = out / f"{name}.cif"
    write_synthetic_model(structure, destination)
    print(destination, structure.composition.reduced_formula, structure.get_space_group_info(symprec=1e-3))
