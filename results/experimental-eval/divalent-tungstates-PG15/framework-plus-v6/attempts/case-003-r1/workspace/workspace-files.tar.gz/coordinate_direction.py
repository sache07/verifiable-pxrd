from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("phase")
    parser.add_argument("element")
    parser.add_argument("--source", type=Path, default=Path("final.gpx"))
    parser.add_argument("--tag", required=True)
    args = parser.parse_args()
    outdir = Path(".tmp/trials/coordinate_directions")
    outdir.mkdir(parents=True, exist_ok=True)
    destination = outdir / f"{args.tag}.gpx"
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(destination))
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "X" if (
                phase.name == args.phase and atom.element == args.element
            ) else ""
    project.set_Controls("cycles", 12)
    history = []
    for iteration in range(3):
        project.refine()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        history.append({"pass": iteration + 1,
                        "rwp_percent": project.histogram(0).get_wR(),
                        "max_shift_over_esd": rvals.get("Max shft/sig")})
    project.save(str(destination))
    project.data["Covariance"]["data"] = {}
    project.phase(args.phase).export_CIF(str(outdir / f"{args.tag}.cif"))
    print(json.dumps({
        "phase": args.phase,
        "element": args.element,
        "history": history,
        "atoms": [{"label": atom.label, "element": atom.element,
                   "xyz": list(atom.coordinates)}
                  for atom in project.phase(args.phase).atoms()],
        "gpx": str(destination),
    }, indent=2))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
