from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path.cwd()
SOURCE = ROOT / ".tmp/trials/uiso_grid/r3s_2_0p0100.gpx"
DESTINATION = ROOT / ".tmp/trials/watch_cao.gpx"


def main():
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(DESTINATION))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(ROOT / ".tmp/parents/cao_1563196.cif"),
        phasename="CaO_watch",
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.05, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]
    phase.set_refinements({"Cell": False})

    project.set_Controls("cycles", 12)
    project.refine()
    project.refine()
    scales = []
    for item in project.phases():
        ihap = item.data["Histograms"][hist.name]
        scales.append({"phase": item.name, "scale": ihap["Scale"][0],
                       "mass": item.data["General"]["Mass"]})
    denominator = sum(row["scale"] * row["mass"] for row in scales)
    for row in scales:
        row["weight_fraction"] = row["scale"] * row["mass"] / denominator
    print(json.dumps({"rwp_percent": hist.get_wR(), "phases": scales}, indent=2))
    project.save(str(DESTINATION))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
