from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path.cwd()
REPLAY = ROOT / ".tmp/replay_final"
PROJECT = ROOT / "final.gpx"
CIF_NAMES = {
    "WO3_monoclinic": "wo3_monoclinic.cif",
    "CaCO3_calcite": "caco3_calcite.cif",
    "CaWO4_scheelite": "cawo4_scheelite.cif",
}
FORMULAS = {
    "WO3_monoclinic": "WO3",
    "CaCO3_calcite": "CaCO3",
    "CaWO4_scheelite": "CaWO4",
}


def main():
    replay = json.loads((REPLAY / "replay.json").read_text())
    if replay.get("status") != "replayed":
        raise RuntimeError(replay)

    project = G2.G2Project(gpxfile=str(PROJECT))
    histogram = project.histogram(replay["histogram"])
    covariance = project.data.get("Covariance", {}).get("data", {})
    variable_count = len(covariance.get("varyList", []))
    fraction_esds = {
        phase.name: covariance.get("depSigDict", {})
        .get(f"{phase.id}:{histogram.id}:WgtFrac", (None, None))[1]
        for phase in project.phases()
    }
    # Match the evaluator's export convention: saved phase values are the
    # authority, not potentially stale covariance parameter dictionaries.
    project.data["Covariance"]["data"] = {}
    for phase in project.phases():
        phase.export_CIF(str(ROOT / CIF_NAMES[phase.name]))

    with np.load(REPLAY / "prediction.npz") as arrays:
        x = arrays["x"].copy()
        observed = arrays["observed"].copy()
        calculated = arrays["predicted"].copy()
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.17g", "%.17g", "%.17g", "%.17g"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    dof = len(x) - variable_count
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    phase_rows = []
    for row in replay["phases"]:
        phase = project.phase(row["name"])
        general = phase.data["General"]
        phase_rows.append({
            "name": row["name"],
            "formula": FORMULAS[row["name"]],
            "space_group": general["SGData"]["SpGrp"],
            "cif_path": CIF_NAMES[row["name"]],
            "weight_fraction": row["weight_fraction"],
            "weight_fraction_esd": fraction_esds[row["name"]],
        })
    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "chi_square": chi_square,
            "reduced_chi_square": chi_square / dof,
            "goodness_of_fit": float(np.sqrt(chi_square / dof)),
            "number_of_points": int(len(x)),
            "number_of_refined_variables": int(variable_count),
        },
        "refinement_histogram": replay["histogram"],
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "fraction_basis": "Normalized over the modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n"
    )
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
