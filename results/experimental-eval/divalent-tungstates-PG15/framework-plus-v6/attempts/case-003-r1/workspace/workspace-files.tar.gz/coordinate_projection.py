from pathlib import Path
import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("phase")
    parser.add_argument("element")
    parser.add_argument("direction", type=Path)
    parser.add_argument("--source", type=Path, default=Path("final.gpx"))
    parser.add_argument("--factors", nargs="+", type=float, required=True)
    parser.add_argument("--tag", required=True)
    args = parser.parse_args()
    outdir = Path(".tmp/trials/coordinate_projections")
    outdir.mkdir(parents=True, exist_ok=True)
    direction = G2.G2Project(gpxfile=str(args.direction))
    direction_atoms = {atom.label: np.asarray(atom.coordinates, float)
                       for atom in direction.phase(args.phase).atoms()}
    rows = []

    for factor in args.factors:
        label = f"{factor:.4f}".replace(".", "p")
        destination = outdir / f"{args.tag}_{label}.gpx"
        project = G2.G2Project(gpxfile=str(args.source), newgpx=str(destination))
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = ""
                if phase.name == args.phase and atom.element == args.element:
                    base = np.asarray(atom.coordinates, float)
                    delta = direction_atoms[atom.label] - base
                    delta -= np.round(delta)
                    atom.coordinates = list(base + factor * delta)
        project.set_Controls("cycles", 12)
        project.refine()
        project.refine()
        hist = project.histogram(0)
        masses = []
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            masses.append(hap["Scale"][0] * phase.data["General"]["Mass"])
        row = {
            "factor": factor,
            "rwp_percent": hist.get_wR(),
            "max_shift_over_esd": project.data["Covariance"]["data"]["Rvals"].get("Max shft/sig"),
            "weight_fractions": (np.asarray(masses) / sum(masses)).tolist(),
            "gpx": str(destination),
        }
        rows.append(row)
        print(json.dumps(row, sort_keys=True))
    (outdir / f"{args.tag}.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
