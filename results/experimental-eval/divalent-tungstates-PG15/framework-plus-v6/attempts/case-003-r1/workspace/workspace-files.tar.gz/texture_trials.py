from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path.cwd()
TRIALS = ROOT / ".tmp" / "trials"
SOURCE = TRIALS / "aniso_calcite_after_wo3_001.gpx"

PHASES = {
    "wo3": ("WO3_monoclinic", [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]),
    "calcite": ("CaCO3_calcite", [[0, 0, 1], [1, 0, 0], [1, 1, 1]]),
    "scheelite": ("CaWO4_scheelite", [[0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]]),
    "calcite_noaniso": ("CaCO3_calcite", [[0, 0, 1], [1, 0, 0], [1, 1, 1]]),
    "scheelite_after_calcite": ("CaWO4_scheelite", [[0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]]),
}


def run(short_name):
    phase_name, axes = PHASES[short_name]
    source = (TRIALS / "aniso_wo3_010.gpx" if short_name == "calcite_noaniso"
              else TRIALS / "texture_calcite_noaniso_001.gpx" if short_name == "scheelite_after_calcite"
              else SOURCE)
    results = []
    for axis in axes:
        tag = "".join(str(v) for v in axis)
        out = TRIALS / f"texture_{short_name}_{tag}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(out))
        hist = project.histogram(0)
        inst = hist.data["Instrument Parameters"][0]
        inst["U"][1], inst["U"][2] = 0.0, False
        inst["X"][1], inst["X"][2] = 0.1, False
        calcite = project.phase("CaCO3_calcite").data["Histograms"][hist.name]
        calcite["Size"][1][0] = 10.0
        calcite["Size"][2] = [False, False, False]
        phases_to_clear = ([project.phase(phase_name)] if short_name == "scheelite_after_calcite"
                           else project.phases())
        for phase in phases_to_clear:
            phase.data["Histograms"][hist.name]["Pref.Ori."][1] = 1.0
            phase.data["Histograms"][hist.name]["Pref.Ori."][2] = False
        po = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", 1.05, True, axis
        project.set_Controls("cycles", 12)
        project.refine()
        project.save(str(out))
        h = project.histogram(0)
        refined = project.phase(phase_name).data["Histograms"][h.name]["Pref.Ori."]
        results.append({
            "axis": axis,
            "rwp_percent": h.get_wR(),
            "md_ratio": refined[1],
            "W": h.data["Instrument Parameters"][0]["W"][1],
            "polarization": h.data["Instrument Parameters"][0]["Polariz."][1],
            "shift_um": h.SampleParameters["Shift"][0],
        })
    print(json.dumps({"phase": phase_name, "no_texture_rwp_percent": 7.818557281809866,
                      "trials": results}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=sorted(PHASES))
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run(args.phase)
