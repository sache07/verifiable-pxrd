from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path.cwd()
TRIALS = ROOT / ".tmp" / "trials"
SOURCE = TRIALS / "nuisance_polarization.gpx"

PHASES = {
    "wo3": ("WO3_monoclinic", [[0, 0, 1], [1, 0, 0], [0, 1, 0]]),
    "calcite": ("CaCO3_calcite", [[0, 0, 1], [1, 0, 0]]),
    "scheelite": ("CaWO4_scheelite", [[0, 0, 1], [1, 0, 0]]),
    "calcite_after_wo3": ("CaCO3_calcite", [[0, 0, 1]]),
}


def run(short_name):
    phase_name, axes = PHASES[short_name]
    source = TRIALS / "aniso_wo3_010.gpx" if short_name == "calcite_after_wo3" else SOURCE
    results = []
    for axis in axes:
        tag = "".join(str(v) for v in axis)
        out = TRIALS / f"aniso_{short_name}_{tag}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(out))
        hist = project.histogram(0)
        inst = hist.data["Instrument Parameters"][0]
        inst["U"][1], inst["U"][2] = 0.0, False
        inst["X"][1], inst["X"][2] = 0.1, False
        calcite = project.phase("CaCO3_calcite").data["Histograms"][hist.name]
        calcite["Size"][1][0] = 10.0
        calcite["Size"][2] = [False, False, False]
        hap = project.phase(phase_name).data["Histograms"][hist.name]
        initial = float(hap["Mustrain"][1][0])
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = initial
        hap["Mustrain"][1][1] = initial * 1.15
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = axis
        project.set_Controls("cycles", 12)
        project.refine()
        project.save(str(out))
        h = project.histogram(0)
        selected = project.phase(phase_name).data["Histograms"][h.name]["Mustrain"]
        inst = h.data["Instrument Parameters"][0]
        results.append({
            "axis": axis,
            "rwp_percent": h.get_wR(),
            "equatorial_ppm": selected[1][0],
            "axial_ppm": selected[1][1],
            "W": inst["W"][1],
            "polarization": inst["Polariz."][1],
            "shift_um": h.SampleParameters["Shift"][0],
        })
    print(json.dumps({"phase": phase_name, "isotropic_rwp_percent": 8.035366852113219,
                      "trials": results}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=sorted(PHASES))
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run(args.phase)
