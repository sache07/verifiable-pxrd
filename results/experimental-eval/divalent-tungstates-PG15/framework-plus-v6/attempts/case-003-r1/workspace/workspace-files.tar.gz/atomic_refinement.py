from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path.cwd()
TRIALS = ROOT / ".tmp" / "trials"
SOURCE = TRIALS / "texture_scheelite_after_calcite_111.gpx"


def compact(project, stage):
    hist = project.histogram(0)
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        rows.append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size_um": hap["Size"][1][0],
            "mustrain": hap["Mustrain"][:4],
            "texture": hap["Pref.Ori."][:4],
            "atoms": [{"label": a.label, "element": a.element,
                       "xyz": list(a.coordinates), "uiso": a.uiso,
                       "flags": a.refinement_flags} for a in phase.atoms()],
        })
    print(json.dumps({
        "stage": stage,
        "rwp_percent": hist.get_wR(),
        "shift_um": hist.SampleParameters["Shift"][0],
        "instrument": {k: hist.data["Instrument Parameters"][0][k][1]
                       for k in ["U", "W", "X", "SH/L", "Polariz."]},
        "phases": rows,
    }, indent=2))


def save_stage(project, stage):
    destination = TRIALS / f"atomic_{stage}.gpx"
    project.save(str(destination))
    for phase in project.phases():
        phase.export_CIF(str(TRIALS / f"atomic_{stage}_{phase.name}.cif"))


def refine_stage(project, stage):
    project.set_Controls("cycles", 12)
    project.refine()
    compact(project, stage)
    save_stage(project, stage)


def add_u_flags(project):
    project.update_ids()
    for phase in project.phases():
        variables = []
        for index, atom in enumerate(phase.atoms()):
            flags = atom.refinement_flags
            atom.refinement_flags = ("XU" if "X" in flags else "U")
            variables.append(f"{phase.id}::AUiso:{index}")
        if len(variables) > 1:
            project.add_EquivConstr(tuple(variables))


def main():
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(TRIALS / "atomic_profile_bound.gpx"))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1], inst["U"][2] = 0.0, False
    inst["X"][1], inst["X"][2] = 0.1, False
    # The unconstrained scheelite size slips below the laboratory's 0.04 um
    # support; keep it at that physical boundary and let its strain refine.
    scheelite_hap = project.phase("CaWO4_scheelite").data["Histograms"][hist.name]
    scheelite_hap["Size"][1][0] = 0.04
    scheelite_hap["Size"][2] = [False, False, False]
    refine_stage(project, "profile_bound")

    for atom in project.phase("WO3_monoclinic").atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"
    refine_stage(project, "wo3_w")

    for atom in project.phase("WO3_monoclinic").atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    refine_stage(project, "wo3_all")

    for atom in project.phase("CaCO3_calcite").atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    refine_stage(project, "calcite_o")

    for atom in project.phase("CaWO4_scheelite").atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    refine_stage(project, "all_coordinates")

    add_u_flags(project)
    refine_stage(project, "coordinates_uiso")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
