#!/usr/bin/env python3
"""Run a restrained GSAS-II candidate-screen refinement.

This is intentionally conservative: atomic coordinates, texture, roughness and
anisotropic broadening remain fixed. It is used to compare phase records under
the same low-order background, scale, cell, angular and profile model.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def configure_limits(project, hist, phases):
    h = hist.id
    limits = [
        ("parmMin", 0.0, f":{h}:U"),
        ("parmMin", 0.0, f":{h}:W"),
        ("parmMin", 0.0, f":{h}:X"),
        ("parmMax", 80.0, f":{h}:U"),
        ("parmMax", 80.0, f":{h}:W"),
        ("parmMax", 12.0, f":{h}:X"),
        ("parmMin", -1200.0, f":{h}:Shift"),
        ("parmMax", 1200.0, f":{h}:Shift"),
        ("parmMin", -0.6, f":{h}:Zero"),
        ("parmMax", 0.6, f":{h}:Zero"),
    ]
    for phase in phases:
        limits.extend(
            [
                ("parmMin", 0.0, f"{phase.id}:{h}:Scale"),
                ("parmMin", 0.0, f"{phase.id}:{h}:Mustrain;i"),
                ("parmMax", 20000.0, f"{phase.id}:{h}:Mustrain;i"),
                ("parmMin", 0.02, f"{phase.id}:{h}:Size;i"),
                ("parmMax", 20.0, f"{phase.id}:{h}:Size;i"),
            ]
        )
    for control, value, variable in limits:
        project.set_Controls(control, value, variable)


def summary(project, hist, phases, stages):
    arrays = hist.data["data"][1]
    x, yobs, weights, ycalc, background, residual = [np.asarray(a) for a in arrays]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    out = {
        "project": str(Path(project.filename).resolve()),
        "histogram": hist.name,
        "rwp_percent": float(hist.get_wR()),
        "chi_square": float(np.sum(weights * (yobs - ycalc) ** 2)),
        "n_points": int(len(x)),
        "stages": stages,
        "instrument": {
            key: float(inst[key][1])
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
        },
        "sample": {
            key: float(sample[key][0])
            for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "background": {
            "type": hist.data["Background"][0][0],
            "coefficients": [float(v) for v in hist.data["Background"][0][3:]],
            "min": float(np.min(background)),
            "max": float(np.max(background)),
        },
        "phases": [],
        "vary_list": [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
    }
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        out["phases"].append(
            {
                "name": phase.name,
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:8]],
                "mass": float(phase.data["General"]["Mass"]),
                "scale": float(hap["Scale"][0]),
                "size": [hap["Size"][0], *[float(v) for v in hap["Size"][1]]],
                "mustrain": [hap["Mustrain"][0], *[float(v) for v in hap["Mustrain"][1]]],
                "preferred_orientation": [hap["Pref.Ori."][0], float(hap["Pref.Ori."][1]), hap["Pref.Ori."][3]],
            }
        )
    return out


def run(args):
    G2.SetPrintLevel("warn")
    outdir = args.output.resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(outdir / "screen.gpx"))
    hist = project.add_powder_histogram(
        str(args.pattern.resolve()), str(args.instrument.resolve()), fmthint="comma"
    )
    phases = []
    for item in args.phase:
        name, filename = item.split("=", 1)
        phases.append(
            project.add_phase(
                str(Path(filename).resolve()),
                phasename=name,
                histograms=[hist],
                fmthint="CIF",
            )
        )
    project.index_ids()

    hist.data["Limits"][1] = [float(args.low), float(args.high)]
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Shift"] = [args.initial_shift, args.angular == "shift"]
    hist.data["Instrument Parameters"][0]["Zero"][1] = 0.0
    hist.data["Instrument Parameters"][0]["Zero"][2] = args.angular == "zero"
    if args.initial_profile:
        for key, value in zip(("U", "W", "X"), args.initial_profile):
            hist.data["Instrument Parameters"][0][key][1] = value
    hist.data["Instrument Parameters"][0]["Polariz."][1] = args.initial_polarization
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": (
                    args.initial_background
                    if args.initial_background
                    else [1300.0, -450.0] + [0.0] * (args.background_terms - 2)
                ),
                "refine": True,
            }
        }
    )

    broad = set(args.broad)
    for phase_index, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        initial_scale = (
            args.initial_scales[phase_index]
            if args.initial_scales
            else max(1.0, 8.0 / len(phases))
        )
        hap["Scale"] = [initial_scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [1.0, 1.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Mustrain"][0] = args.strain_mode if phase.name in broad else "isotropic"
        initial_strain = args.broad_strain if phase.name in broad else 0.0
        axial_strain = args.axial_strain if phase.name in broad else 0.0
        hap["Mustrain"][1][0:2] = [initial_strain, axial_strain]
        hap["Mustrain"][2][:] = [False, False, False]
        if phase.name in broad and args.strain_mode == "uniaxial":
            hap["Mustrain"][3] = list(args.strain_axis)
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    configure_limits(project, hist, phases)
    project.set_Controls("cycles", args.cycles)
    stages = []

    def refine(label):
        project.refine()
        stages.append({"label": label, "rwp_percent": float(hist.get_wR())})

    # Common nuisance model, then cells, then the common profile.
    refine("background_scales_angular")
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine("cells")
    if args.mode == "full":
        # Establish phase-width terms against a neutral common profile before
        # allowing the latter to absorb all high-angle breadth.
        for phase in phases:
            if phase.name in broad:
                phase.set_HAP_refinements(
                    {
                        "Mustrain": {
                            "type": args.strain_mode,
                            "direction": list(args.strain_axis),
                            "refine": True,
                        }
                    }
                )
                refine(f"strain_{phase.name}")
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        refine("common_profile")

        # Re-converge all scales/background/cells under the accepted screen model.
        refine("reconverged")
    project.save()
    report = summary(project, hist, phases, stages)
    (outdir / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
    np.savetxt(
        outdir / "fit.csv",
        np.column_stack([hist.data["data"][1][i] for i in (0, 1, 3, 5)]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
    )
    print(json.dumps(report, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", action="append", required=True, help="NAME=CIF")
    parser.add_argument("--broad", action="append", default=[], help="phase name")
    parser.add_argument("--broad-strain", type=float, default=5500.0)
    parser.add_argument("--axial-strain", type=float, default=1000.0)
    parser.add_argument("--strain-mode", choices=("isotropic", "uniaxial"), default="isotropic")
    parser.add_argument("--strain-axis", type=int, nargs=3, default=(0, 0, 1))
    parser.add_argument("--angular", choices=("shift", "zero"), default="shift")
    parser.add_argument("--background-terms", type=int, default=6)
    parser.add_argument("--initial-background", type=float, nargs="+")
    parser.add_argument("--initial-scales", type=float, nargs="+")
    parser.add_argument("--initial-shift", type=float, default=0.0)
    parser.add_argument("--initial-profile", type=float, nargs=3, metavar=("U", "W", "X"))
    parser.add_argument("--initial-polarization", type=float, default=0.8)
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--mode", choices=("cells", "full"), default="full")
    parser.add_argument("--low", type=float, default=10.0)
    parser.add_argument("--high", type=float, default=100.05)
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--instrument", type=Path, default=Path("instrument.instprm"))
    parser.add_argument("--output", type=Path, required=True)
    run(parser.parse_args())


if __name__ == "__main__":
    main()
