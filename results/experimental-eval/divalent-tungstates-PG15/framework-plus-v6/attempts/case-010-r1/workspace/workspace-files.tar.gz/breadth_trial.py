#!/usr/bin/env python3
"""Challenge phase size/microstrain terms against a common GSAS-II profile.

The selected phase terms are first refined while U/W/X are held fixed.  The
common profile is then released and the full existing model is reconverged.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--size", nargs=2, action="append", default=[], metavar=("PHASE", "UM"))
    ap.add_argument(
        "--strain",
        nargs=7,
        action="append",
        default=[],
        metavar=("PHASE", "MODE", "EQUATORIAL", "AXIAL", "H", "K", "L"),
    )
    ap.add_argument("--reset-u", type=float)
    ap.add_argument("--u-max", type=float, default=80.0)
    ap.add_argument("--cycles", type=int, default=18)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    if args.reset_u is not None:
        inst["U"][1] = float(args.reset_u)
    project.set_Controls("parmMin", 0.0, f":{hist.id}:U")
    project.set_Controls("parmMax", float(args.u_max), f":{hist.id}:U")

    challenged = []
    for phase_name, initial in args.size:
        phase = project.phase(phase_name)
        value = float(initial)
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = value
        hap["Size"][2][:] = [True, False, False]
        project.set_Controls("parmMin", 0.02, f"{phase.id}:{hist.id}:Size;i")
        project.set_Controls("parmMax", 20.0, f"{phase.id}:{hist.id}:Size;i")
        challenged.append(f"size:{phase_name}")

    for phase_name, mode, equatorial, axial, hh, kk, ll in args.strain:
        if mode not in {"isotropic", "uniaxial"}:
            raise ValueError(f"invalid strain mode {mode!r}")
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = mode
        hap["Mustrain"][1][0:2] = [float(equatorial), float(axial)]
        hap["Mustrain"][2][:] = [True, mode == "uniaxial", False]
        hap["Mustrain"][3] = [int(hh), int(kk), int(ll)]
        for suffix in ["i"] + (["a"] if mode == "uniaxial" else []):
            project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;{suffix}")
            project.set_Controls("parmMax", 20000.0, f"{phase.id}:{hist.id}:Mustrain;{suffix}")
        challenged.append(f"strain:{phase_name}:{mode}")

    if not challenged:
        raise ValueError("at least one --size or --strain challenge is required")

    before = float(hist.get_wR())
    profile_flags = {key: bool(inst[key][2]) for key in ("U", "W", "X")}
    for key in profile_flags:
        inst[key][2] = False
    project.refine()
    staged = float(hist.get_wR())
    for key, flag in profile_flags.items():
        inst[key][2] = flag
    project.refine()
    project.refine()
    project.save()

    result = {
        "challenged": challenged,
        "rwp_before_percent": before,
        "rwp_breadth_stage_percent": staged,
        "rwp_percent": float(hist.get_wR()),
        "frozen": project.get_Frozen(),
        "instrument": {key: float(inst[key][1]) for key in ("U", "V", "W", "X", "SH/L")},
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
                "size": [hap["Size"][0], *[float(v) for v in hap["Size"][1]], hap["Size"][3]],
                "size_refine": [bool(v) for v in hap["Size"][2]],
                "mustrain": [hap["Mustrain"][0], *[float(v) for v in hap["Mustrain"][1]], hap["Mustrain"][3]],
                "mustrain_refine": [bool(v) for v in hap["Mustrain"][2]],
            }
        )
    arr = hist.data["data"][1]
    np.savetxt(
        args.output.with_suffix(".csv"),
        np.column_stack([arr[i] for i in (0, 1, 3, 5)]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
    )
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
