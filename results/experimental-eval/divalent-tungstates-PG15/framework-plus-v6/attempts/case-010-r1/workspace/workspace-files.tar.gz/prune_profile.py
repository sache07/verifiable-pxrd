#!/usr/bin/env python3
"""Fix or remove selected phase-profile terms, then reconverge."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--fix-size", nargs=2, action="append", default=[], metavar=("PHASE", "UM"))
    ap.add_argument("--disable-strain", action="append", default=[], metavar="PHASE")
    ap.add_argument("--cycles", type=int, default=12)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histograms()[0]
    changes = []
    for name, value in args.fix_size:
        hap = project.phase(name).data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = float(value)
        hap["Size"][2][:] = [False, False, False]
        changes.append({"phase": name, "size_fixed_um": float(value)})
    for name in args.disable_strain:
        hap = project.phase(name).data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0:2] = [0.0, 0.0]
        hap["Mustrain"][2][:] = [False, False, False]
        changes.append({"phase": name, "mustrain_disabled": True})

    before = float(hist.get_wR())
    project.refine()
    project.refine()
    project.save()
    arrays = hist.data["data"][1]
    result = {
        "changes": changes,
        "rwp_before_percent": before,
        "rwp_percent": float(hist.get_wR()),
        "frozen": project.get_Frozen(),
        "instrument": {key: float(hist.data["Instrument Parameters"][0][key][1]) for key in ("Polariz.", "U", "W", "X")},
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append({
            "name": phase.name, "scale": float(hap["Scale"][0]),
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
            "size": [hap["Size"][0], *[float(v) for v in hap["Size"][1]], [bool(v) for v in hap["Size"][2]]],
            "mustrain": [hap["Mustrain"][0], *[float(v) for v in hap["Mustrain"][1]], [bool(v) for v in hap["Mustrain"][2]], hap["Mustrain"][3]],
        })
    np.savetxt(
        args.output.with_suffix(".csv"), np.column_stack([arrays[i] for i in (0, 1, 3, 5)]),
        delimiter=",", header="two_theta_deg,observed,calculated,difference", comments="",
    )
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
