#!/usr/bin/env python3
"""Apply one reversible refinement challenge to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def safe_uiso(atom):
    try:
        return float(atom.uiso)
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--cycles", type=int, default=16)
    ap.add_argument("--instrument", nargs="*", default=[])
    ap.add_argument("--polarization-bounds", type=float, nargs=2, metavar=("MIN", "MAX"))
    ap.add_argument("--roughness", action="store_true")
    ap.add_argument("--roughness-initial", type=float, nargs=2, default=(0.1, 0.1), metavar=("A", "B"))
    ap.add_argument("--roughness-bounds", type=float, nargs=4, default=(0.0, 1.0, 0.0, 1.0), metavar=("AMIN", "AMAX", "BMIN", "BMAX"))
    ap.add_argument("--texture", nargs=5, metavar=("PHASE", "H", "K", "L", "RATIO"))
    ap.add_argument("--atom-element", nargs=2, metavar=("PHASE", "ELEMENT"), action="append", default=[])
    ap.add_argument("--atom-all", action="append", default=[], metavar="PHASE")
    ap.add_argument("--cell", action="append", default=[], metavar="PHASE")
    ap.add_argument("--uiso-element", nargs=2, metavar=("PHASE", "ELEMENT"), action="append", default=[])
    ap.add_argument("--reset-u", type=float)
    ap.add_argument("--u-max", type=float, default=500.0)
    ap.add_argument("--position-bound", type=float, help="maximum fractional-coordinate shift in the first refinement")
    ap.add_argument("--angular", choices=("shift", "zero"))
    ap.add_argument("--zero-initial", type=float, default=0.3)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    p = G2.G2Project(gpxfile=str(args.input.resolve()))
    p.save(str(args.output.resolve()))
    h = p.histograms()[0]
    p.set_Frozen()
    p.set_Controls("cycles", args.cycles)
    if args.reset_u is not None:
        h.data["Instrument Parameters"][0]["U"][1] = args.reset_u
    p.set_Controls("parmMin", 0.0, f":{h.id}:U")
    p.set_Controls("parmMax", args.u_max, f":{h.id}:U")

    if args.angular == "zero":
        h.data["Sample Parameters"]["Shift"] = [0.0, False]
        h.data["Instrument Parameters"][0]["Zero"][1] = args.zero_initial
        h.data["Instrument Parameters"][0]["Zero"][2] = True
        p.set_Controls("parmMin", -0.6, f":{h.id}:Zero")
        p.set_Controls("parmMax", 0.6, f":{h.id}:Zero")
    elif args.angular == "shift":
        h.data["Instrument Parameters"][0]["Zero"] = [0.0, 0.0, False]
        h.data["Sample Parameters"]["Shift"][1] = True

    if args.instrument:
        h.set_refinements({"Instrument Parameters": args.instrument})
        if "Polariz." in args.instrument:
            pmin, pmax = args.polarization_bounds or (0.0, 1.0)
            p.set_Controls("parmMin", pmin, f":{h.id}:Polariz.")
            p.set_Controls("parmMax", pmax, f":{h.id}:Polariz.")
        if "SH/L" in args.instrument:
            p.set_Controls("parmMin", 0.001, f":{h.id}:SH/L")
            p.set_Controls("parmMax", 0.2, f":{h.id}:SH/L")
    if args.roughness:
        sample = h.data["Sample Parameters"]
        sample["SurfRoughA"] = [args.roughness_initial[0], True]
        sample["SurfRoughB"] = [args.roughness_initial[1], True]
        amin, amax, bmin, bmax = args.roughness_bounds
        p.set_Controls("parmMin", amin, f":{h.id}:SurfRoughA")
        p.set_Controls("parmMin", bmin, f":{h.id}:SurfRoughB")
        p.set_Controls("parmMax", amax, f":{h.id}:SurfRoughA")
        p.set_Controls("parmMax", bmax, f":{h.id}:SurfRoughB")
    if args.texture:
        phase_name, hh, kk, ll, ratio = args.texture
        phase = p.phase(phase_name)
        hap = phase.data["Histograms"][h.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = float(ratio)
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [int(hh), int(kk), int(ll)]
        p.set_Controls("parmMin", 0.5, f"{phase.id}:{h.id}:MD")
        p.set_Controls("parmMax", 2.0, f"{phase.id}:{h.id}:MD")

    selected_atoms = []
    for phase_name in args.cell:
        p.phase(phase_name).set_refinements({"Cell": True})
    for phase_name, element in args.atom_element:
        phase = p.phase(phase_name)
        for index, atom in enumerate(phase.atoms()):
            if atom.element == element:
                atom.refinement_flags = "X"
                selected_atoms.append((phase, index, atom))
    for phase_name in args.atom_all:
        phase = p.phase(phase_name)
        for index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "X"
            selected_atoms.append((phase, index, atom))
    for phase_name, element in args.uiso_element:
        for atom in p.phase(phase_name).atoms():
            if atom.element == element:
                atom.refinement_flags = "U" if "X" not in atom.refinement_flags else "XU"

    if args.position_bound is not None:
        for phase, index, atom in selected_atoms:
            for axis in "xyz":
                variable = f"{phase.id}::dA{axis}:{index}"
                p.set_Controls("parmMin", -args.position_bound, variable)
                p.set_Controls("parmMax", args.position_bound, variable)

    before = h.get_wR()
    p.refine()
    if args.position_bound is not None:
        # Keep the bounded coordinate update, then reconverge nuisance terms
        # without allowing another cumulative coordinate step.
        for phase, index, atom in selected_atoms:
            p.phase(phase.name).atoms()[index].refinement_flags = ""
        p.set_Frozen()
    p.refine()
    p.save()
    inst = h.data["Instrument Parameters"][0]
    sample = h.data["Sample Parameters"]
    arr = h.data["data"][1]
    result = {
        "rwp_before_percent": None if before is None else float(before),
        "rwp_percent": float(h.get_wR()),
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "Polariz.", "U", "V", "W", "X", "SH/L")},
        "sample": {
            k: float(sample[k][0]) for k in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "frozen": p.get_Frozen(),
        "phases": [],
        "vary_list": [str(v) for v in p.data.get("Covariance", {}).get("data", {}).get("varyList", [])],
    }
    for ph in p.phases():
        hap = ph.data["Histograms"][h.name]
        result["phases"].append(
            {
                "name": ph.name,
                "scale": float(hap["Scale"][0]),
                "cell": [float(x) for x in ph.data["General"]["Cell"][1:7]],
                "mustrain": [hap["Mustrain"][0], *[float(x) for x in hap["Mustrain"][1]], hap["Mustrain"][3]],
                "size": [hap["Size"][0], *[float(x) for x in hap["Size"][1]], hap["Size"][3]],
                "preferred_orientation": [hap["Pref.Ori."][0], float(hap["Pref.Ori."][1]), hap["Pref.Ori."][3]],
                "atoms": [
                    {
                        "label": a.label,
                        "element": a.element,
                        "coordinates": [float(x) for x in a.coordinates],
                        "flags": a.refinement_flags,
                        "uiso": safe_uiso(a),
                    }
                    for a in ph.atoms()
                ],
            }
        )
    np.savetxt(
        args.output.with_suffix(".csv"),
        np.column_stack([arr[i] for i in (0, 1, 3, 5)]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
    )
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
