#!/usr/bin/env python3
"""Set one common isotropic displacement parameter per selected phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--phase", nargs=2, action="append", default=[], metavar=("PHASE", "UISO_A2"))
    ap.add_argument("--cycles", type=int, default=10)
    args = ap.parse_args()
    if not args.phase:
        raise ValueError("at least one --phase PHASE UISO_A2 is required")

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    chosen = {}
    for name, value in args.phase:
        uiso = float(value)
        if not 0.0 <= uiso <= 0.05:
            raise ValueError("Uiso outside physical trial interval")
        chosen[name] = uiso
        for atom in project.phase(name).atoms():
            atom.uiso = uiso
            atom.refinement_flags = atom.refinement_flags.replace("U", "")

    hist = project.histograms()[0]
    before = float(hist.get_wR())
    project.refine()
    project.refine()
    project.save()
    arr = hist.data["data"][1]
    result = {
        "common_uiso_A2": chosen,
        "rwp_before_percent": before,
        "rwp_percent": float(hist.get_wR()),
        "frozen": project.get_Frozen(),
        "instrument": {key: float(hist.data["Instrument Parameters"][0][key][1]) for key in ("Polariz.", "U", "W", "X")},
        "sample_shift_um": float(hist.data["Sample Parameters"]["Shift"][0]),
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append({
            "name": phase.name,
            "scale": float(hap["Scale"][0]),
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
            "uiso_min": float(min(a.uiso for a in phase.atoms())),
            "uiso_max": float(max(a.uiso for a in phase.atoms())),
        })
    np.savetxt(
        args.output.with_suffix(".csv"),
        np.column_stack([arr[i] for i in (0, 1, 3, 5)]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
    )
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
