#!/usr/bin/env python3
"""Interpolate selected atomic coordinates between two GPX models and reconverge."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("target", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--phase", required=True)
    ap.add_argument("--element", required=True)
    ap.add_argument("--fraction", required=True, type=float)
    ap.add_argument("--cycles", type=int, default=18)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    base = G2.G2Project(gpxfile=str(args.base.resolve()))
    target = G2.G2Project(gpxfile=str(args.target.resolve()))
    base.save(str(args.output.resolve()))
    bphase = base.phase(args.phase)
    tphase = target.phase(args.phase)
    if len(bphase.atoms()) != len(tphase.atoms()):
        raise ValueError("phase atom counts differ")
    shifts = []
    for ba, ta in zip(bphase.atoms(), tphase.atoms()):
        if ba.label != ta.label or ba.element != ta.element:
            raise ValueError("phase atom ordering differs")
        ba.refinement_flags = ""
        if ba.element != args.element:
            continue
        old = np.asarray(ba.coordinates, float)
        delta = np.asarray(ta.coordinates, float) - old
        delta -= np.round(delta)
        ba.coordinates = old + args.fraction * delta
        shifts.append((ba.label, (args.fraction * delta).tolist()))

    base.set_Frozen()
    base.set_Controls("cycles", args.cycles)
    h = base.histograms()[0]
    before = h.get_wR()
    base.refine()
    base.refine()
    base.save()
    arr = h.data["data"][1]
    result = {
        "fraction": args.fraction,
        "rwp_before_percent": float(before),
        "rwp_percent": float(h.get_wR()),
        "shifts_fractional": shifts,
        "phases": [],
    }
    for ph in base.phases():
        hap = ph.data["Histograms"][h.name]
        result["phases"].append(
            {
                "name": ph.name,
                "scale": float(hap["Scale"][0]),
                "cell": [float(x) for x in ph.data["General"]["Cell"][1:7]],
                "atoms": [
                    {"label": a.label, "element": a.element, "coordinates": [float(x) for x in a.coordinates]}
                    for a in ph.atoms()
                ],
            }
        )
    np.savetxt(
        args.output.with_suffix(".csv"),
        np.column_stack([arr[i] for i in (0, 1, 3, 5)]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
    )
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
