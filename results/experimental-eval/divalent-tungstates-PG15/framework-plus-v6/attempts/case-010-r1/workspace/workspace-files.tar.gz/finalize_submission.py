#!/usr/bin/env python3
"""Prune, replay-refine, export, and summarize the final GSAS-II model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "four_pruned.gpx"
OUTPUT = ROOT / "final.gpx"
EXPORTS = {
    "WO3": "phase_wo3.cif",
    "Mn2O3": "phase_mn2o3.cif",
    "MnWO4": "phase_mnwo4.cif",
    "MnO2": "phase_mno2.cif",
}


def configure(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], float)
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Shift"][1] = True
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"] = [0.0, 0.0, False]
    for key in ("V", "Y", "Z"):
        inst[key][1] = 0.0
        inst[key][2] = False
    inst["SH/L"][1] = 0.03
    inst["SH/L"][2] = False
    for key in ("Polariz.", "U", "W", "X"):
        inst[key][2] = True
    hist.data["Background"][0][1] = False

    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2][:] = [False, False, False]
        if phase.name == "WO3":
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][2][:] = [True, True, False]
            hap["Mustrain"][3] = [0, 1, 0]
            phase.set_refinements({"Cell": True})
        elif phase.name == "Mn2O3":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2][:] = [True, False, False]
            phase.set_refinements({"Cell": True})
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0:2] = [0.0, 0.0]
            hap["Mustrain"][2][:] = [False, False, False]
            phase.set_refinements({"Cell": False})
        project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Scale")

    project.set_Controls("parmMin", 0.0, f":{hist.id}:U")
    project.set_Controls("parmMin", 0.0, f":{hist.id}:W")
    project.set_Controls("parmMin", 0.0, f":{hist.id}:X")
    project.set_Controls("parmMax", 500.0, f":{hist.id}:U")
    project.set_Controls("parmMax", 80.0, f":{hist.id}:W")
    project.set_Controls("parmMax", 20.0, f":{hist.id}:X")
    project.set_Controls("parmMin", 0.0, f":{hist.id}:Polariz.")
    project.set_Controls("parmMax", 1.0, f":{hist.id}:Polariz.")
    project.set_Controls("parmMin", -1200.0, f":{hist.id}:Shift")
    project.set_Controls("parmMax", 1200.0, f":{hist.id}:Shift")


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(OUTPUT))
    project.set_Frozen()
    configure(project)
    project.set_Controls("cycles", 16)
    project.refine()
    project.refine()
    project.save()

    # Reopen and replay one full-range refinement before exporting. This also
    # catches state that only fails after serialization.
    project = G2.G2Project(gpxfile=str(OUTPUT))
    project.set_Frozen()
    configure(project)
    project.set_Controls("cycles", 16)
    project.refine()
    project.save()
    frozen = project.get_Frozen()
    if frozen:
        raise RuntimeError(f"final project has frozen variables: {frozen}")

    hist = project.histograms()[0]
    arrays = hist.data["data"][1]
    x, yobs, weights, ycalc = [np.asarray(arrays[i], float) for i in (0, 1, 2, 3)]
    background = np.asarray(arrays[4], float)
    if not all(np.all(np.isfinite(v)) for v in (x, yobs, weights, ycalc, background)):
        raise RuntimeError("nonfinite final profile")
    if np.min(ycalc) < 0 or np.min(background) < 0:
        raise RuntimeError("negative final profile or background")

    phases = []
    mass_scales = []
    for phase in project.phases():
        if phase.name not in EXPORTS:
            raise RuntimeError(f"unexpected final phase {phase.name}")
        phase.export_CIF(str(ROOT / EXPORTS[phase.name]))
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        mass_scales.append(mass_scale)
        phases.append({
            "name": phase.name,
            "cif_path": EXPORTS[phase.name],
            "scale": float(hap["Scale"][0]),
            "cell_mass_amu": float(phase.data["General"]["Mass"]),
        })
    total = float(sum(mass_scales))
    for row, value in zip(phases, mass_scales):
        row["weight_fraction"] = float(value / total)
        row.pop("scale")
        row.pop("cell_mass_amu")

    residual = yobs - ycalc
    chi_square = float(np.sum(weights * residual**2))
    denominator = float(np.sum(weights * yobs**2))
    nvars = len(project.data.get("Covariance", {}).get("data", {}).get("varyList", []))
    dof = int(len(x) - nvars)
    reduced = float(chi_square / dof)
    statistics = {
        "rwp_percent": float(100.0 * np.sqrt(chi_square / denominator)),
        "chi_square": chi_square,
        "reduced_chi_square": reduced,
        "goodness_of_fit": float(np.sqrt(reduced)),
        "n_points": int(len(x)),
        "n_refined_parameters": int(nvars),
    }
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, yobs, ycalc, residual]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
    )
    result = {
        "schema_version": 1,
        "refinement_histogram": hist.name,
        "phase_fraction_basis": "normalized over modeled crystalline phases",
        "phases": phases,
        "fit_statistics": statistics,
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    summary = {
        **result,
        "project": str(OUTPUT),
        "background_min_counts": float(np.min(background)),
        "background_max_counts": float(np.max(background)),
        "instrument": {key: float(hist.data["Instrument Parameters"][0][key][1]) for key in ("Zero", "Polariz.", "U", "V", "W", "X", "SH/L")},
        "sample": {key: float(hist.data["Sample Parameters"][key][0]) for key in ("Shift", "SurfRoughA", "SurfRoughB")},
        "frozen": frozen,
    }
    (ROOT / ".tmp" / "final_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
