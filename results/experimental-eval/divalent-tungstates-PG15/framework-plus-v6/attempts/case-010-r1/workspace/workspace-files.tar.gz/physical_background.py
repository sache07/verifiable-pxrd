#!/usr/bin/env python3
"""Fit the lab's smooth background families and encode one in GSAS-II.

Only the physical family parameters are fitted. The resulting smooth curve is
represented by fixed Chebyshev coefficients so final.gpx has no external
background dependency and can be replayed natively.
"""

from __future__ import annotations

import argparse
import json
from math import comb
from pathlib import Path

import numpy as np
from scipy.optimize import differential_evolution, lsq_linear, minimize, minimize_scalar
from GSASII import GSASIIscriptable as G2


def floor_basis(t: np.ndarray, degree: int) -> np.ndarray:
    return np.column_stack([
        comb(degree, k) * t**k * (1.0 - t) ** (degree - k)
        for k in range(degree + 1)
    ])


def linear_fit(columns: np.ndarray, target: np.ndarray, sqrt_weight: np.ndarray):
    design = columns * sqrt_weight[:, None]
    rhs = target * sqrt_weight
    fit = lsq_linear(design, rhs, bounds=(0.0, 5000.0), tol=1e-11, lsmr_tol=1e-11)
    residual = rhs - design @ fit.x
    return float(residual @ residual), fit.x


def fit_families(x: np.ndarray, target: np.ndarray, weight: np.ndarray):
    t = (x - x[0]) / (x[-1] - x[0])
    dx = x - x[0]
    sw = np.sqrt(weight)
    candidates = []
    for degree in (0, 1, 2):
        basis = floor_basis(t, degree)
        loss, coef = linear_fit(basis, target, sw)
        candidates.append((loss, 2 * (degree + 1), {
            "family": "simple", "degree": degree,
            "floor_coefficients": coef.tolist(), "tail_amplitude": 0.0,
            "scale_deg": None, "power": None,
        }, basis @ coef))

    floor = floor_basis(t, 2)

    def exp_eval(scale: float, keep_curve: bool = False):
        basis = np.column_stack([floor, np.exp(-dx / scale)])
        loss, coef = linear_fit(basis, target, sw)
        return (loss, coef, basis @ coef) if keep_curve else loss

    opt = minimize_scalar(exp_eval, bounds=(5.0, 20.0), method="bounded", options={"xatol": 1e-8})
    loss, coef, curve = exp_eval(float(opt.x), True)
    candidates.append((loss, 2 * 5, {
        "family": "exponential", "degree": 2,
        "floor_coefficients": coef[:3].tolist(), "tail_amplitude": float(coef[3]),
        "scale_deg": float(opt.x), "power": None,
    }, curve))

    def power_eval(values, keep_curve: bool = False):
        scale, power = map(float, values)
        basis = np.column_stack([floor, (1.0 + dx / scale) ** (-power)])
        loss, coef = linear_fit(basis, target, sw)
        return (loss, coef, basis @ coef) if keep_curve else loss

    seed = differential_evolution(power_eval, [(5.0, 20.0), (1.0, 3.0)], seed=7151,
                                  polish=False, workers=1, tol=1e-7)
    opt2 = minimize(power_eval, seed.x, method="L-BFGS-B", bounds=[(5.0, 20.0), (1.0, 3.0)])
    loss, coef, curve = power_eval(opt2.x, True)
    candidates.append((loss, 2 * 6, {
        "family": "power_law", "degree": 2,
        "floor_coefficients": coef[:3].tolist(), "tail_amplitude": float(coef[3]),
        "scale_deg": float(opt2.x[0]), "power": float(opt2.x[1]),
    }, curve))

    # AIC-like selection prevents a negligible reduction from choosing a more
    # elaborate family; differences in these scans are normally much larger.
    loss, penalty, model, curve = min(candidates, key=lambda row: row[0] + row[1])
    model["weighted_residual"] = loss
    model["selection_score"] = loss + penalty
    model["all_family_scores"] = [
        {"family": row[2]["family"], "degree": row[2]["degree"],
         "weighted_residual": row[0], "selection_score": row[0] + row[1]}
        for row in candidates
    ]
    return model, curve


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--terms", type=int, default=24)
    ap.add_argument("--alternations", type=int, default=3)
    ap.add_argument("--cycles", type=int, default=10)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histograms()[0]
    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], float)
    y = np.asarray(arrays[1], float)
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]
    project.refine()  # regenerate the model on the entire submitted grid

    history = []
    for iteration in range(args.alternations):
        arrays = hist.data["data"][1]
        calculated = np.asarray(arrays[3], float)
        old_background = np.asarray(arrays[4], float)
        signal = calculated - old_background
        weight = 1.0 / np.maximum(y, 1.0)
        model, curve = fit_families(x, y - signal, weight)
        tcheb = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
        coeffs = np.polynomial.chebyshev.chebfit(tcheb, curve, args.terms - 1)
        approximation = np.polynomial.chebyshev.chebval(tcheb, coeffs)
        model["chebyshev_terms"] = args.terms
        model["chebyshev_max_abs_error_counts"] = float(np.max(np.abs(curve - approximation)))
        hist.set_refinements({"Background": {
            "type": "chebyschev-1", "no. coeffs": args.terms,
            "coeffs": coeffs.tolist(), "refine": False,
        }})
        project.refine()
        project.refine()
        model["iteration"] = iteration + 1
        model["rwp_percent"] = float(hist.get_wR())
        history.append(model)

    project.save()
    arrays = hist.data["data"][1]
    background = np.asarray(arrays[4], float)
    result = {
        "rwp_percent": float(hist.get_wR()),
        "full_limits": [float(v) for v in hist.data["Limits"][1]],
        "history": history,
        "background_min": float(np.min(background)),
        "background_max": float(np.max(background)),
        "frozen": project.get_Frozen(),
        "instrument": {key: float(hist.data["Instrument Parameters"][0][key][1]) for key in ("Polariz.", "U", "W", "X", "SH/L")},
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append({
            "name": phase.name, "scale": float(hap["Scale"][0]),
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
            "size": [hap["Size"][0], *[float(v) for v in hap["Size"][1]]],
            "mustrain": [hap["Mustrain"][0], *[float(v) for v in hap["Mustrain"][1]], hap["Mustrain"][3]],
        })
    np.savetxt(
        args.output.with_suffix(".csv"),
        np.column_stack([arrays[i] for i in (0, 1, 3, 5)]),
        delimiter=",", header="two_theta_deg,observed,calculated,difference", comments="",
    )
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
