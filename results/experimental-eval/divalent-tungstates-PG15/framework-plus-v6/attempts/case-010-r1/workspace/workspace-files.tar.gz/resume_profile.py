#!/usr/bin/env python3
"""Reopen a GSAS-II trial, release bounded profile variables and reconverge."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--u-max", type=float, default=500.0)
    ap.add_argument("--cycles", type=int, default=16)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    p = G2.G2Project(gpxfile=str(args.input.resolve()))
    p.save(str(args.output.resolve()))
    h = p.histograms()[0]
    p.set_Frozen()
    p.set_Controls("cycles", args.cycles)
    p.set_Controls("parmMin", 0.0, f":{h.id}:U")
    p.set_Controls("parmMax", args.u_max, f":{h.id}:U")
    h.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    p.refine()
    p.refine()
    p.save()
    inst = h.data["Instrument Parameters"][0]
    arr = h.data["data"][1]
    result = {
        "rwp_percent": float(h.get_wR()),
        "instrument": {k: float(inst[k][1]) for k in ("U", "W", "X", "SH/L")},
        "frozen": p.get_Frozen(),
        "phases": [],
    }
    for ph in p.phases():
        hap = ph.data["Histograms"][h.name]
        result["phases"].append(
            {
                "name": ph.name,
                "scale": float(hap["Scale"][0]),
                "cell": [float(x) for x in ph.data["General"]["Cell"][1:7]],
                "mustrain": [hap["Mustrain"][0], *[float(x) for x in hap["Mustrain"][1]]],
            }
        )
    np.savetxt(
        args.output.with_suffix(".csv"),
        np.column_stack([arr[i] for i in (0, 1, 3, 5)]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
    )
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
