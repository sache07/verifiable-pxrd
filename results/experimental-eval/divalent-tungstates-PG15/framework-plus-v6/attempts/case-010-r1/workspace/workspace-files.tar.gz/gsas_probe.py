from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def main():
    out = Path(sys.argv[1])
    cif = Path(sys.argv[2]).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()),
        str(Path("instrument.instprm").resolve()),
        fmthint="comma",
    )
    phase = project.add_phase(
        str(cif), phasename=cif.stem, histograms=[hist], fmthint="CIF"
    )
    project.save()
    print("hist", hist.name)
    print("instrument", hist.data["Instrument Parameters"])
    print("sample", hist.data["Sample Parameters"])
    print("background", hist.data["Background"])
    print("hap", phase.data["Histograms"][hist.name])
    print("cell", phase.data["General"]["Cell"])
    print("mass", phase.data["General"]["Mass"])


if __name__ == "__main__":
    main()
