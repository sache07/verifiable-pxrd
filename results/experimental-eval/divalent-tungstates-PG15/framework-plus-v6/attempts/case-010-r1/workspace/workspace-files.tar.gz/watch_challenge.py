#!/usr/bin/env python3
"""Add one watch-list phase to a converged project and test its scale."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--name", required=True)
    ap.add_argument("--cif", type=Path, required=True)
    ap.add_argument("--initial-scale", type=float, default=0.1)
    ap.add_argument("--cycles", type=int, default=12)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    project.set_Frozen()
    hist = project.histograms()[0]
    phase = project.add_phase(str(args.cif.resolve()), phasename=args.name,
                              histograms=[hist], fmthint="CIF")
    project.index_ids()
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(args.initial_scale), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0:2] = [0.0, 0.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    phase.set_refinements({"Cell": False})
    project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Scale")
    project.set_Controls("cycles", args.cycles)
    before = float(hist.get_wR())
    project.refine()
    project.refine()
    project.save()

    covariance = project.data.get("Covariance", {}).get("data", {})
    variable = f"{phase.id}:{hist.id}:Scale"
    esd = None
    if variable in [str(v) for v in covariance.get("varyList", [])]:
        index = [str(v) for v in covariance["varyList"]].index(variable)
        esd = float(covariance["sig"][index])
    masses = []
    for ph in project.phases():
        phap = ph.data["Histograms"].get(hist.name)
        if phap is not None:
            masses.append((ph.name, float(phap["Scale"][0]), float(ph.data["General"]["Mass"])))
    total = sum(max(0.0, scale) * mass for _, scale, mass in masses)
    result = {
        "candidate": args.name,
        "source_cif": str(args.cif.resolve()),
        "rwp_before_percent": before,
        "rwp_percent": float(hist.get_wR()),
        "candidate_scale": float(hap["Scale"][0]),
        "candidate_scale_esd": esd,
        "candidate_weight_fraction": float(max(0.0, hap["Scale"][0]) * phase.data["General"]["Mass"] / total) if total else None,
        "frozen": project.get_Frozen(),
        "fractions": {name: float(max(0.0, scale) * mass / total) for name, scale, mass in masses} if total else {},
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
