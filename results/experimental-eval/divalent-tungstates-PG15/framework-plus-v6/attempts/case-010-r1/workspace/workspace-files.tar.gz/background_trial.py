#!/usr/bin/env python3
"""Replace the GSAS-II smooth background basis and reconverge a project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--type", required=True, choices=(
        "chebyschev-1", "Q^2 power series", "Q^-2 power series",
        "lin interpolate", "inv interpolate", "log interpolate",
    ))
    ap.add_argument("--terms", required=True, type=int)
    ap.add_argument("--cycles", type=int, default=18)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histograms()[0]
    old = np.asarray(hist.data["data"][1][4], float)
    x = np.asarray(hist.data["data"][1][0], float)
    lo, hi = map(float, hist.data["Limits"][1])
    mask = (x >= lo) & (x <= hi)
    xv, bv = x[mask], old[mask]

    if "interpolate" in args.type:
        if args.type == "lin interpolate":
            nodes = np.linspace(xv[0], xv[-1], args.terms)
        elif args.type == "inv interpolate":
            nodes = 1.0 / np.linspace(1.0 / xv[-1], 1.0 / xv[0], args.terms)
        else:
            nodes = np.exp(np.linspace(np.log(xv[0]), np.log(xv[-1]), args.terms))
        coeffs = np.interp(nodes, xv, bv).tolist()
    elif args.type == "chebyschev-1":
        # Keep the converged low-order coefficients and append neutral terms.
        current = list(hist.data["Background"][0][3:])
        coeffs = (current + [0.0] * args.terms)[: args.terms]
    else:
        coeffs = [float(np.median(bv))] + [0.0] * (args.terms - 1)

    before = float(hist.get_wR())
    hist.set_refinements({"Background": {
        "type": args.type,
        "no. coeffs": args.terms,
        "coeffs": coeffs,
        "refine": True,
    }})
    project.refine()
    project.refine()
    project.save()
    arr = hist.data["data"][1]
    background = np.asarray(arr[4], float)
    result = {
        "type": args.type,
        "terms": args.terms,
        "rwp_before_percent": before,
        "rwp_percent": float(hist.get_wR()),
        "coefficients": [float(v) for v in hist.data["Background"][0][3:]],
        "background_min": float(np.min(background[mask])),
        "background_max": float(np.max(background[mask])),
        "frozen": project.get_Frozen(),
        "instrument": {key: float(hist.data["Instrument Parameters"][0][key][1]) for key in ("U", "W", "X")},
    }
    np.savetxt(
        args.output.with_suffix(".csv"),
        np.column_stack([arr[i] for i in (0, 1, 3, 5)]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
    )
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
