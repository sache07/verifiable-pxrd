#!/usr/bin/env python3
"""Build and incrementally refine an exploratory GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_inputs() -> tuple[Path, Path]:
    raw = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    xye = ROOT / "observed.xye"
    np.savetxt(xye, np.column_stack((raw[:, 0], raw[:, 1], np.sqrt(np.maximum(raw[:, 1], 1.0)))), fmt="%.8f %.8f %.8f")
    inst = ROOT / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def snapshot(gpx: G2.G2Project, label: str, log: list[dict]) -> None:
    hist = gpx.histograms()[0]
    phases = []
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.data["General"]["Cell"][1:8],
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    log.append(
        {
            "step": label,
            "Rwp_percent": hist.get_wR(),
            "GOF": gpx.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
            "background": hist.data["Background"][0],
            "instrument": {k: inst[k] for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."] if k in inst},
            "sample": {k: sample[k] for k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"] if k in sample},
            "phases": phases,
            "vary_list": gpx.data.get("Covariance", {}).get("data", {}).get("varyList", []),
        }
    )
    print(label, "Rwp", hist.get_wR())


def refine(gpx: G2.G2Project, label: str, log: list[dict]) -> None:
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
    gpx.refine()
    snapshot(gpx, label, log)
    gpx.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phases", nargs="+", default=["9013902"], help="COD ids")
    parser.add_argument("--output", default="explore.gpx")
    parser.add_argument("--shift", type=float, default=-650.0, help="initial specimen displacement in micrometres")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    xye, inst = prepare_inputs()
    output = ROOT / args.output
    gpx = G2.G2Project(newgpx=str(output))
    phase_names = {
        "9013902": "MgWO4_wolframite",
        "9000499": "MgO_periclase",
        "1010618": "WO3_monoclinic_old",
        "1528915": "WO3_monoclinic",
        "1563541": "WO3_monoclinic_alt",
        "2106293": "WO3_triclinic",
        "2311041": "WO3_monoclinic_alt2",
        "2107312": "WO3_orthorhombic",
    }
    phases = [gpx.add_phase(str(cod_path(cid)), phasename=phase_names.get(cid, f"COD_{cid}"), fmthint="CIF") for cid in args.phases]
    hist = gpx.add_powder_histogram(str(xye), str(inst), phases=phases, fmthint="xye")
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [args.shift, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements({"Limits": [float(np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)[0, 0]), 100.09455322]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [1200.0, -600.0, 300.0, -150.0, 50.0, -20.0],
                "refine": True,
            }
        }
    )
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][1][1] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        phase.set_HAP_refinements({"Scale": True})

    log: list[dict] = []
    refine(gpx, "background_scales", log)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(gpx, "shift_cells", log)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(gpx, "common_profile", log)

    (ROOT / (output.stem + "_log.json")).write_text(json.dumps(log, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)) + "\n")


if __name__ == "__main__":
    main()
