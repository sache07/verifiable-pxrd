#!/usr/bin/env python3
"""Apply a controlled refinement stage to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def phase_indices(text: str | None, count: int) -> list[int]:
    if text is None:
        return []
    if text == "all":
        return list(range(count))
    result = [int(v) for v in text.split(",")]
    if any(v < 0 or v >= count for v in result):
        raise ValueError(f"phase indices must lie in 0..{count - 1}")
    return result


def summary(gpx: G2.G2Project) -> dict:
    hist = gpx.histograms()[0]
    cov = gpx.data.get("Covariance", {}).get("data", {})
    masses = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in gpx.phases()],
        dtype=float,
    )
    return {
        "Rwp_percent": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "vary_list": copy.deepcopy(cov.get("varyList", [])),
        "variables": np.asarray(cov.get("variables", [])).tolist(),
        "sigmas": np.asarray(cov.get("sig", [])).tolist(),
        "background": copy.deepcopy(hist.data["Background"]),
        "instrument": copy.deepcopy(hist.data["Instrument Parameters"][0]),
        "sample": copy.deepcopy(hist.data["Sample Parameters"]),
        "phases": [
            {
                "name": p.name,
                "cell": copy.deepcopy(p.data["General"]["Cell"][1:8]),
                "scale": copy.deepcopy(p.data["Histograms"][hist.name]["Scale"]),
                "size": copy.deepcopy(p.data["Histograms"][hist.name]["Size"]),
                "mustrain": copy.deepcopy(p.data["Histograms"][hist.name]["Mustrain"]),
                "preferred_orientation": copy.deepcopy(p.data["Histograms"][hist.name]["Pref.Ori."]),
                "atoms": [
                    {
                        "label": a.label,
                        "element": a.element,
                        "coordinates": list(a.coordinates),
                        "uiso": float(a.data[a.cia + 1]),
                        "flags": a.refinement_flags,
                    }
                    for a in p.atoms()
                ],
            }
            for p in gpx.phases()
        ],
        "weight_fractions": (masses / masses.sum()).tolist(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--passes", type=int, default=2)
    parser.add_argument("--coords", help="comma-separated phase indices or all")
    parser.add_argument("--bounded-coords", help="comma-separated phase indices or all")
    parser.add_argument("--heavy-coords", help="comma-separated phase indices or all; refine non-oxygen sites")
    parser.add_argument("--coord-max-shift-a", type=float, default=0.08)
    parser.add_argument("--uiso", help="comma-separated phase indices or all; one constrained Uiso per phase")
    parser.add_argument("--size", help="comma-separated phase indices or all")
    parser.add_argument("--strain", help="comma-separated phase indices or all")
    parser.add_argument("--uniaxial-strain", type=int, help="phase index")
    parser.add_argument("--strain-axis", nargs=3, type=int, default=[0, 0, 1])
    parser.add_argument("--texture", type=int, help="phase index")
    parser.add_argument("--texture-axis", nargs=3, type=int, default=[0, 0, 1])
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--clear-roughness", action="store_true")
    parser.add_argument("--set-rough-a", type=float)
    parser.add_argument("--set-rough-b", type=float)
    parser.add_argument("--refine-rough-a-only", action="store_true")
    parser.add_argument("--refine-rough-b-only", action="store_true")
    parser.add_argument("--shl", action="store_true")
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--background-coeffs", type=int)
    parser.add_argument("--background-type")
    parser.add_argument("--clear-coords", action="store_true")
    parser.add_argument("--clear-uiso", action="store_true")
    parser.add_argument("--clear-size", action="store_true")
    parser.add_argument("--clear-strain", action="store_true")
    parser.add_argument("--clear-texture", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(gpxfile=args.input)
    gpx.save(args.output)
    hist = gpx.histograms()[0]
    phases = gpx.phases()

    if args.background_coeffs is not None or args.background_type is not None:
        ncoeff = args.background_coeffs or int(hist.data["Background"][0][2])
        kind = args.background_type or "chebyschev-1"
        x = np.asarray(hist.data["data"][1][0], dtype=float)
        old_background = np.asarray(hist.data["data"][1][4], dtype=float)
        if not np.any(old_background):
            old_background = np.full_like(x, np.median(hist.data["data"][1][1]))
        t = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
        if kind == "chebyschev":
            design = np.column_stack([t**i for i in range(ncoeff)])
        elif kind == "chebyschev-1":
            design = np.column_stack([np.cos(i * np.arccos(t)) for i in range(ncoeff)])
        elif kind == "cosine":
            design = np.column_stack([np.cos(np.deg2rad(180.0 * x * i / x[-1])) for i in range(ncoeff)])
        elif kind in ["Q^2 power series", "Q^-2 power series"]:
            inst = hist.data["Instrument Parameters"][0]
            wave = float(inst.get("Lam", inst.get("Lam1"))[1])
            q = 4.0 * np.pi * np.sin(np.deg2rad(x / 2.0)) / wave
            columns = [np.ones_like(x)]
            qt = np.ones_like(x)
            for i in range(ncoeff - 1):
                qt = qt * ((i + 1) * q**-2 if "-2" in kind else q**2 / (i + 1))
                columns.append(qt.copy())
            design = np.column_stack(columns)
        elif kind in ["lin interpolate", "inv interpolate", "log interpolate"]:
            if kind == "lin interpolate":
                knots = np.linspace(x[0], x[-1], ncoeff)
            elif kind == "inv interpolate":
                knots = 1.0 / np.linspace(1.0 / x[-1], 1.0 / x[0], ncoeff)
            else:
                knots = np.exp(np.linspace(np.log(x[0]), np.log(x[-1]), ncoeff))
            knots[0], knots[-1] = x[0], x[-1]
            design = np.column_stack([np.interp(x, knots, np.eye(ncoeff)[i]) for i in range(ncoeff)])
        else:
            raise ValueError(f"unsupported background type: {kind}")
        coeffs = np.linalg.lstsq(design, old_background, rcond=None)[0].tolist()
        hist.set_refinements(
            {
                "Background": {
                    "type": kind,
                    "no. coeffs": ncoeff,
                    "coeffs": coeffs,
                    "refine": True,
                }
            }
        )
    if args.clear_coords:
        for phase in phases:
            for atom in phase.atoms():
                atom.refinement_flags = atom.refinement_flags.replace("X", "")
    if args.clear_uiso:
        for phase in phases:
            for atom in phase.atoms():
                atom.refinement_flags = atom.refinement_flags.replace("U", "")
    if args.clear_size:
        for phase in phases:
            phase.clear_HAP_refinements({"Size": True})
            size = phase.data["Histograms"][hist.name]["Size"]
            size[0] = "isotropic"
            size[1][0] = 100.0
            size[1][1] = 100.0
    if args.clear_strain:
        for phase in phases:
            phase.clear_HAP_refinements({"Mustrain": True})
            mustrain = phase.data["Histograms"][hist.name]["Mustrain"]
            mustrain[0] = "isotropic"
            mustrain[1][0] = 0.0
            mustrain[1][1] = 0.0
    if args.clear_texture:
        for phase in phases:
            phase.clear_HAP_refinements({"Pref.Ori.": True})
            phase.data["Histograms"][hist.name]["Pref.Ori."][1] = 1.0

    for i in phase_indices(args.coords, len(phases)):
        for atom in phases[i].atoms():
            if "X" not in atom.refinement_flags:
                atom.refinement_flags += "X"
    for i in phase_indices(args.bounded_coords, len(phases)):
        phase = phases[i]
        lengths = phase.data["General"]["Cell"][1:4]
        for j, atom in enumerate(phase.atoms()):
            if "X" not in atom.refinement_flags:
                atom.refinement_flags += "X"
            for axis, length in zip("xyz", lengths):
                variable = f"{phase.id}::dA{axis}:{j}"
                bound = args.coord_max_shift_a / float(length)
                gpx.set_Controls("parmMin", -bound, variable=variable)
                gpx.set_Controls("parmMax", bound, variable=variable)
    for i in phase_indices(args.heavy_coords, len(phases)):
        for atom in phases[i].atoms():
            if atom.element != "O" and "X" not in atom.refinement_flags:
                atom.refinement_flags += "X"

    # The generator and physical model use one isotropic displacement value per phase.
    # Constrain all independent sites in a phase to that common scalar.
    for i in phase_indices(args.uiso, len(phases)):
        phase = phases[i]
        values = [float(a.data[a.cia + 1]) for a in phase.atoms()]
        start = float(np.clip(np.mean(values), 0.003, 0.03))
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = start
            if "U" not in atom.refinement_flags:
                atom.refinement_flags += "U"
        variables = [f"{phase.id}::AUiso:{j}" for j in range(len(phase.atoms()))]
        if len(variables) > 1:
            gpx.add_EquivConstr(variables, reloadIdx=True)
        gpx.set_Controls("parmMin", 0.0001, variable=variables[0])
        gpx.set_Controls("parmMax", 0.08, variable=variables[0])

    for i in phase_indices(args.size, len(phases)):
        phase = phases[i]
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True, "value": 0.5}})
        gpx.set_Controls("parmMin", 0.01, variable=f"{phase.id}:{hist.id}:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable=f"{phase.id}:{hist.id}:Size;i")

    for i in phase_indices(args.strain, len(phases)):
        phase = phases[i]
        hap = phase.data["Histograms"][hist.name]
        if hap["Mustrain"][1][0] <= 0:
            hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")
        gpx.set_Controls("parmMax", 20000.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")

    if args.uniaxial_strain is not None:
        phase = phases[args.uniaxial_strain]
        hap = phase.data["Histograms"][hist.name]
        base = max(float(hap["Mustrain"][1][0]), 1000.0)
        hap["Mustrain"][1][0] = base
        hap["Mustrain"][1][1] = base
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "direction": args.strain_axis,
                    "refine": True,
                }
            }
        )
        for suffix in ["i", "a"]:
            variable = f"{phase.id}:{hist.id}:Mustrain;{suffix}"
            gpx.set_Controls("parmMin", 0.0, variable=variable)
            gpx.set_Controls("parmMax", 20000.0, variable=variable)

    if args.texture is not None:
        phase = phases[args.texture]
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[3] = list(args.texture_axis)
        phase.set_HAP_refinements({"Pref.Ori.": True})
        gpx.set_Controls("parmMin", 0.2, variable=f"{phase.id}:{hist.id}:MD")
        gpx.set_Controls("parmMax", 5.0, variable=f"{phase.id}:{hist.id}:MD")

    if args.roughness:
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.2, False]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.1, False]
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        gpx.set_Controls("parmMin", 0.0, variable=f":{hist.id}:SurfRoughA")
        gpx.set_Controls("parmMax", 0.99, variable=f":{hist.id}:SurfRoughA")
        gpx.set_Controls("parmMin", 0.0, variable=f":{hist.id}:SurfRoughB")
        gpx.set_Controls("parmMax", 2.0, variable=f":{hist.id}:SurfRoughB")
    if args.clear_roughness:
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    if args.set_rough_a is not None:
        hist.data["Sample Parameters"]["SurfRoughA"][0] = args.set_rough_a
    if args.set_rough_b is not None:
        hist.data["Sample Parameters"]["SurfRoughB"][0] = args.set_rough_b
    if args.refine_rough_a_only:
        hist.data["Sample Parameters"]["SurfRoughA"][1] = True
        hist.data["Sample Parameters"]["SurfRoughB"][1] = False
        gpx.set_Controls("parmMin", 0.0, variable=f":{hist.id}:SurfRoughA")
        gpx.set_Controls("parmMax", 0.99, variable=f":{hist.id}:SurfRoughA")
    if args.refine_rough_b_only:
        hist.data["Sample Parameters"]["SurfRoughA"][1] = False
        hist.data["Sample Parameters"]["SurfRoughB"][1] = True
        gpx.set_Controls("parmMin", 0.0, variable=f":{hist.id}:SurfRoughB")
        gpx.set_Controls("parmMax", 2.0, variable=f":{hist.id}:SurfRoughB")
    if args.shl:
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        gpx.set_Controls("parmMin", 0.001, variable=f":{hist.id}:SH/L")
        gpx.set_Controls("parmMax", 0.5, variable=f":{hist.id}:SH/L")
    if args.polarization:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        gpx.set_Controls("parmMin", 0.0, variable=f":{hist.id}:Polariz.")
        gpx.set_Controls("parmMax", 1.0, variable=f":{hist.id}:Polariz.")

    for key in ["U", "W", "X"]:
        gpx.set_Controls("parmMin", 0.0, variable=f":{hist.id}:{key}")
    gpx.set_Controls("parmMin", -2000.0, variable=f":{hist.id}:Shift")
    gpx.set_Controls("parmMax", 2000.0, variable=f":{hist.id}:Shift")
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
    gpx.set_Controls("cycles", 20)

    reports = []
    for run in range(args.passes):
        gpx.refine()
        reports.append({"pass": run + 1, **summary(gpx)})
        print(f"pass {run + 1}: Rwp={reports[-1]['Rwp_percent']:.6f}%")
        gpx.save()
    Path(args.output).with_suffix(".json").write_text(json.dumps(reports, indent=2) + "\n")


if __name__ == "__main__":
    main()
