from __future__ import annotations

import json
import math
import shutil
from pathlib import Path

import numpy as np


root = Path(__file__).resolve().parent
replay_dir = root / ".tmp" / "replay-final"
replay = json.loads((replay_dir / "replay.json").read_text())
if replay.get("status") != "replayed":
    raise RuntimeError(f"Final GSAS-II replay failed: {replay}")
if replay.get("profile_review_flags"):
    raise RuntimeError(f"Final profile has review flags: {replay['profile_review_flags']}")

expected_names = ["MgWO4_wolframite", "WO3_triclinic", "MgO_periclase"]
actual_names = [row["name"] for row in replay["phases"]]
if actual_names != expected_names:
    raise RuntimeError(f"Unexpected final phase order: {actual_names}")

cif_names = ["phase_mgwo4.cif", "phase_wo3.cif", "phase_mgo.cif"]
for index, name in enumerate(cif_names):
    shutil.copy2(replay_dir / f"phase_{index}.cif", root / name)

profile = np.load(replay_dir / "prediction.npz")
x = np.asarray(profile["x"], dtype=float)
observed = np.asarray(profile["observed"], dtype=float)
calculated = np.asarray(profile["predicted"], dtype=float)
difference = observed - calculated

public = np.loadtxt(root / "inputs" / "pattern.csv", delimiter=",", skiprows=1, ndmin=2)
if public.shape != (len(x), 2):
    raise RuntimeError("Replayed profile does not have the original scan shape")
if not np.allclose(public[:, 0], x, rtol=0, atol=1e-7):
    raise RuntimeError("Replayed profile does not use the original two-theta grid")
if not np.allclose(public[:, 1], observed, rtol=0, atol=1e-5):
    raise RuntimeError("Replayed profile does not use the original observed counts")
if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
    raise RuntimeError("Replayed calculated profile is not physical")

np.savetxt(
    root / "fit.csv",
    np.column_stack((x, observed, calculated, difference)),
    delimiter=",",
    header="two_theta,observed,calculated,difference",
    comments="",
    fmt=["%.8f", "%.10f", "%.10f", "%.10f"],
)

weights = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weights * difference**2))
denominator = float(np.sum(weights * observed**2))
rwp_percent = float(100.0 * math.sqrt(chi_square / denominator))
rp_percent = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
refinement_history = json.loads((root / "logbg8.json").read_text())
n_parameters = len(refinement_history[-1]["vary_list"])
degrees_of_freedom = len(x) - n_parameters
goodness_of_fit = float(math.sqrt(chi_square / degrees_of_freedom))

fractions = [float(row["weight_fraction"]) for row in replay["phases"]]
if not math.isclose(sum(fractions), 1.0, rel_tol=0, abs_tol=1e-12):
    raise RuntimeError("Final crystalline weight fractions are not normalized")

phase_records = [
    {
        "name": "MgWO4_wolframite",
        "formula": "MgWO4",
        "space_group": "P 2/c",
        "cod_source": "COD 9013902",
        "cif_path": cif_names[0],
        "weight_fraction": fractions[0],
        "weight_fraction_esd": 0.00308,
    },
    {
        "name": "WO3_triclinic",
        "formula": "WO3",
        "space_group": "P -1",
        "cod_source": "COD 2106293",
        "cif_path": cif_names[1],
        "weight_fraction": fractions[1],
        "weight_fraction_esd": 0.00131,
    },
    {
        "name": "MgO_periclase",
        "formula": "MgO",
        "space_group": "F m -3 m",
        "cod_source": "COD 9000499",
        "cif_path": cif_names[2],
        "weight_fraction": fractions[2],
        "weight_fraction_esd": 0.00338,
    },
]

result = {
    "refinement_histogram": replay["histogram"],
    "project_path": "final.gpx",
    "fraction_basis": "normalized over the three modeled crystalline phases",
    "phases": phase_records,
    "fit_statistics": {
        "rwp_percent": rwp_percent,
        "rp_percent": rp_percent,
        "chi_square": chi_square,
        "goodness_of_fit": goodness_of_fit,
        "degrees_of_freedom": degrees_of_freedom,
        "n_observations": len(x),
        "n_refined_parameters": n_parameters,
        "weighting": "1/max(observed_counts, 1)",
        "profile_scope": "entire original measured grid",
    },
    "verification": {
        "method": "independent native GSAS-II atomic forward replay",
        "status": replay["status"],
        "final_gpx_sha256": replay["project_sha256"],
        "profile_review_flags": replay["profile_review_flags"],
    },
}
(root / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

report = f"""# Powder XRD phase analysis

## Result

The scan is modeled as three crystalline phases. Fractions are normalized over those phases only.

| Phase | Structural model | Refined cell (angstrom, degrees) | Crystalline wt.% |
|---|---|---|---:|
| MgWO4, wolframite | P 2/c; COD 9013902 | a=4.69016, b=5.67480, c=4.92910, beta=90.7737 | {100*fractions[0]:.4f} |
| WO3, triclinic | P -1; COD 2106293 | a=7.30361, b=7.53377, c=7.68982, alpha=89.8626, beta=90.8030, gamma=90.0887 | {100*fractions[1]:.4f} |
| MgO, periclase | F m -3 m; COD 9000499 | a=4.21309 | {100*fractions[2]:.4f} |

The corresponding atomic models are `phase_mgwo4.cif`, `phase_wo3.cif`, and `phase_mgo.cif`. `final.gpx` is the exact project independently replayed to create `fit.csv` and the fractions above.

## Evidence and model selection

The chemistry is consistent with reaction of the reported MgO and WO3 precursors at 900 degrees C. Wolframite MgWO4 accounts for the dominant peak families across the complete 9.90-100.09 degree 2-theta range. Residual WO3 is required by the coherent 23.43/23.93/24.67 degree cluster and additional families near 34.47 and 50.2 degrees. Periclase MgO is independently supported by its isolated 200 line at 43.209 degrees and its higher-angle family near 62.54 degrees; its scale remains positive after the common profile is rebuilt.

Several WO3 records/polymorphs were challenged under the same restrained nuisance model. Triclinic P -1 COD 2106293 gave the best replay-stable whole-pattern agreement; tested monoclinic alternatives COD 2311041 and COD 1528915 left larger structured residuals. The three retained phases all improve coherent families rather than single bins, and no auxiliary background peaks were used.

## Refinement and fit quality

The Cu K-alpha1/K-alpha2 wavelengths and 0.5 intensity ratio were fixed to the metadata. The full-range GSAS-II Rietveld model used a positive eight-node log-interpolated background, one specimen-displacement correction, common nonnegative U/W/X profile terms, refined polarization, isotropic MgWO4 size broadening, uniaxial WO3 microstrain, and weak replay-stable March-Dollase corrections. Unused size/strain terms were neutralized. The background is positive throughout (273.9-2360.3 counts), and independent replay raised no negative-width, negative-background, occupancy, or displacement-parameter flags.

On the complete measured grid, Rwp is {rwp_percent:.5f}%, Rp is {rp_percent:.5f}%, chi-square is {chi_square:.3f}, and GOF is {goodness_of_fit:.5f} ({len(x)} points, {n_parameters} refined parameters, weights 1/max(counts,1)).

## Remaining uncertainty

The fractions are conditional crystalline-phase fractions: without an internal standard they do not measure amorphous material or absolute reaction yield. Formal scale-covariance uncertainties are about 0.31, 0.13, and 0.34 wt.% for MgWO4, WO3, and MgO respectively, but model/background systematics are likely larger.

The WO3 polymorph assignment is the least secure because its broadened reflections overlap MgWO4. Its cell and scale are supported, and its W coordinates were only slightly adjusted, but the minor-phase oxygen coordinates could not be determined reliably from this powder scan; the published COD 2106293 oxygen geometry was therefore retained. Free oxygen refinement produced large, non-robust shifts and was rejected. Low-level additional crystalline material below the sensitivity of this pattern cannot be excluded.
"""
(root / "report.md").write_text(report)

print(json.dumps({
    "phases": [{"name": row["name"], "weight_fraction": row["weight_fraction"]} for row in phase_records],
    "rwp_percent": rwp_percent,
    "chi_square": chi_square,
    "gof": goodness_of_fit,
    "project_sha256": replay["project_sha256"],
}, indent=2))
