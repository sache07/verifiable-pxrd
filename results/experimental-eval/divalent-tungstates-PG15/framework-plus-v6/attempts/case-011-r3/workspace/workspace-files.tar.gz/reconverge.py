#!/usr/bin/env python3
"""Repeatedly save, reopen and refine a GSAS-II project over its full range."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def state(project, iteration):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    cov = project.data.get("Covariance", {}).get("data", {})
    masses, phases = [], []
    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        mass = float(p.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(0.0, mass))
        phases.append(
            {
                "name": p.name,
                "scale": float(hap["Scale"][0]),
                "cell": [float(v) for v in p.data["General"]["Cell"][1:]],
                "size": hap["Size"],
                "strain": hap["Mustrain"],
                "texture": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for p, m in zip(phases, masses):
        p["weight_fraction"] = m / total
    return {
        "iteration": iteration,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "shift_um": float(hist.data["Sample Parameters"]["Shift"][0]),
        "instrument": {k: float(inst[k][1]) for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "phases": phases,
        "frozen": project.get_Frozen(),
        "vary_list": [str(v) for v in cov.get("varyList", [])],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--rounds", type=int, default=6)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    project.save(str(output))
    history = [state(project, 0)]
    for iteration in range(1, args.rounds + 1):
        project.refine(makeBack=False)
        project.save(str(output))
        project = G2.G2Project(gpxfile=str(output))
        history.append(state(project, iteration))
        print(json.dumps({k: history[-1][k] for k in ("iteration", "rwp_percent", "gof", "shift_um", "instrument", "frozen")}, default=str))
    output.with_suffix(".json").write_text(json.dumps({"history": history}, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
