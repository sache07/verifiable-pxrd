#!/usr/bin/env python3
"""Compare one March-Dollase axis while reconverging the active model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--axis", nargs=3, type=int, required=True)
    parser.add_argument("--ratio", type=float, default=1.1)
    parser.add_argument("--neutral-size", default="", help="comma-separated phase indices")
    args = parser.parse_args()

    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    project.set_Frozen(None)
    project.set_Controls("cycles", 16)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    hist = project.histogram(0)
    for token in filter(None, args.neutral_size.split(",")):
        phase = project.phase(int(token))
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][1][1] = 10.0
        hap["Size"][2] = [False, False, False]

    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = float(args.ratio)
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(args.axis)
    project.set_Controls("parmMin", 0.3, f"{phase.id}:{hist.id}:MD")
    project.set_Controls("parmMax", 3.0, f"{phase.id}:{hist.id}:MD")
    project.refine(makeBack=False)
    project.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    cov = project.data.get("Covariance", {}).get("data", {})
    rows, masses = [], []
    for p in project.phases():
        h = p.data["Histograms"][hist.name]
        m = float(p.data["General"]["Mass"] * h["Scale"][0])
        masses.append(m)
        rows.append(
            {
                "name": p.name,
                "scale": float(h["Scale"][0]),
                "texture": h["Pref.Ori."],
                "size": h["Size"],
                "strain": h["Mustrain"],
                "cell": [float(v) for v in p.data["General"]["Cell"][1:]],
            }
        )
    total = sum(masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = mass / total
    result = {
        "input": str(Path(args.input).resolve()),
        "output": str(output),
        "phase": args.phase,
        "axis": args.axis,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "shift_um": float(hist.data["Sample Parameters"]["Shift"][0]),
        "instrument": {k: float(inst[k][1]) for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "phases": rows,
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "frozen": project.get_Frozen(),
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
