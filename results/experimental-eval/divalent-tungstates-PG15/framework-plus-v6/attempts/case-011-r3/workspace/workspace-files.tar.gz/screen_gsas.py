#!/usr/bin/env python3
"""Build and refine a comparable GSAS-II screening model.

Run with the GSAS-II Python interpreter. This deliberately keeps the nuisance
model small so that alternate structure records can be compared fairly.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inputs(root: Path, pattern: Path) -> tuple[Path, Path]:
    data = np.loadtxt(pattern, delimiter=",", skiprows=1)
    x, y = data.T
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = root / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y, sigma)), fmt="%.10g")
    inst = root / "instrument.instprm"
    inst.write_text(
        "#GSAS-II Cu Kalpha Bragg-Brentano screening profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def initial_background(pattern: Path, ncoeff: int) -> list[float]:
    x, y = np.loadtxt(pattern, delimiter=",", skiprows=1).T
    step = float(np.median(np.diff(x)))
    # A low rolling percentile suppresses Bragg peaks without following them.
    width = max(101, int(round(4.0 / step)) | 1)
    baseline = percentile_filter(y, percentile=8, size=width, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, baseline, ncoeff - 1).tolist()


def project_snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phase_rows = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(mass_scale, 0.0))
        phase_rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "mass_scale": mass_scale,
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for row, mass in zip(phase_rows, masses):
        row["weight_fraction"] = mass / total if total > 0 else None
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "shift_um": float(sample["Shift"][0]),
        "background": hist.data["Background"][0],
        "instrument": {
            key: float(inst[key][1])
            for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
            if key in inst
        },
        "phases": phase_rows,
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "frozen": project.get_Frozen(),
    }


def reopen(gpx: Path) -> G2.G2Project:
    return G2.G2Project(gpxfile=str(gpx))


def refine_and_reopen(project: G2.G2Project, gpx: Path, label: str, history: list[dict]) -> G2.G2Project:
    project.refine(makeBack=False)
    project.save(str(gpx))
    project = reopen(gpx)
    history.append(project_snapshot(project, label))
    return project


def neutralize_hap(phase, hist_name: str, scale: float) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [float(scale), False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][1][1] = 10.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ids", nargs="+", required=True, help="COD identifiers")
    parser.add_argument("--names", nargs="+", help="phase names, parallel to --ids")
    parser.add_argument("--out", required=True)
    parser.add_argument("--pattern", default="inputs/pattern.csv")
    parser.add_argument("--background-coeffs", type=int, default=6)
    parser.add_argument("--profile", action="store_true", help="refine common U/W/X")
    parser.add_argument("--shl", action="store_true", help="also refine SH/L")
    args = parser.parse_args()

    if args.names and len(args.names) != len(args.ids):
        parser.error("--names must parallel --ids")
    names = args.names or [f"COD_{item}" for item in args.ids]
    root = Path(args.out).resolve()
    root.mkdir(parents=True, exist_ok=True)
    pattern = Path(args.pattern).resolve()
    xye, inst = write_inputs(root, pattern)
    gpx = root / "screen.gpx"

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [-500.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements({"Limits": [float(np.loadtxt(pattern, delimiter=",", skiprows=1)[0, 0]),
                                     float(np.loadtxt(pattern, delimiter=",", skiprows=1)[-1, 0])]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_coeffs,
                "coeffs": initial_background(pattern, args.background_coeffs),
                "refine": False,
            }
        }
    )

    phases = []
    for cod_id, name in zip(args.ids, names):
        phase = project.add_phase(str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF")
        neutralize_hap(phase, hist.name, 1000.0 / float(phase.data["General"]["Mass"]))
        phases.append(phase)

    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    project.set_Controls("parmMin", -1500.0, ":*:Shift")
    project.set_Controls("parmMax", 1500.0, ":*:Shift")
    for phase in phases:
        pid = phase.id
        hid = hist.id
        project.set_Controls("parmMin", 0.0, f"{pid}:{hid}:Scale")
    for key in ("U", "W", "X"):
        project.set_Controls("parmMin", 0.0, f":*:{key}")
    project.set_Controls("parmMax", 100.0, ":*:U")
    project.set_Controls("parmMax", 100.0, ":*:W")
    project.set_Controls("parmMax", 10.0, ":*:X")

    project.save(str(gpx))
    history = [project_snapshot(project, "initial")]

    # Refit the same restrained nuisance model after every source choice.
    # Call these separately because the GSAS-II Background=True shortcut
    # returns immediately from set_refinements.
    hist.set_refinements({"Background": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project = refine_and_reopen(project, gpx, "background_scales_shift", history)

    hist = project.histogram(0)
    phases = project.phases()
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project = refine_and_reopen(project, gpx, "cells", history)

    if args.profile:
        hist = project.histogram(0)
        keys = ["U", "W", "X"] + (["SH/L"] if args.shl else [])
        hist.set_refinements({"Instrument Parameters": keys})
        project = refine_and_reopen(project, gpx, "common_profile", history)

    project.save(str(gpx))
    output = {
        "ids": args.ids,
        "names": names,
        "gpx": str(gpx),
        "history": history,
    }
    (root / "summary.json").write_text(json.dumps(output, indent=2, default=str) + "\n")
    print(json.dumps(history[-1], indent=2, default=str))


if __name__ == "__main__":
    main()
