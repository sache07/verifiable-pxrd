#!/usr/bin/env python3
"""Compare polarization and low-angle surface-roughness corrections."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def snapshot(project, iteration):
    h = project.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    sample = h.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    masses = [float(p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0]) for p in project.phases()]
    return {
        "iteration": iteration,
        "rwp_percent": h.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "polarization": float(inst["Polariz."][1]),
        "roughness_A": float(sample["SurfRoughA"][0]),
        "roughness_B": float(sample["SurfRoughB"][0]),
        "fractions": [v / sum(masses) for v in masses],
        "instrument": {k: float(inst[k][1]) for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "frozen": project.get_Frozen(),
        "vary_list": [str(v) for v in cov.get("varyList", [])],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--roughness-A", type=float, default=None, help="fix A and refine only B")
    parser.add_argument("--shl", action="store_true", help="refine axial-divergence asymmetry")
    parser.add_argument("--rounds", type=int, default=3)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    p.set_Controls("cycles", 20)
    p.data["Controls"]["data"]["min dM/M"] = 1e-7
    h = p.histogram(0)
    if args.polarization:
        h.set_refinements({"Instrument Parameters": ["Polariz."]})
        p.set_Controls("parmMin", 0.0, ":*:Polariz.")
        p.set_Controls("parmMax", 1.0, ":*:Polariz.")
    if args.shl:
        h.set_refinements({"Instrument Parameters": ["SH/L"]})
        p.set_Controls("parmMin", 0.001, ":*:SH/L")
        p.set_Controls("parmMax", 0.2, ":*:SH/L")
    if args.roughness:
        fixed_a = args.roughness_A is not None
        h.data["Sample Parameters"]["SurfRoughA"] = [float(args.roughness_A if fixed_a else 0.2), not fixed_a]
        h.data["Sample Parameters"]["SurfRoughB"] = [0.1, True]
        p.set_Controls("parmMin", 0.0, ":*:SurfRoughA")
        p.set_Controls("parmMax", 1.0, ":*:SurfRoughA")
        p.set_Controls("parmMin", 0.0, ":*:SurfRoughB")
        p.set_Controls("parmMax", 1.0, ":*:SurfRoughB")
    p.save(str(output))
    history = [snapshot(p, 0)]
    for i in range(1, args.rounds + 1):
        p.refine(makeBack=False)
        p.save(str(output))
        p = G2.G2Project(gpxfile=str(output))
        history.append(snapshot(p, i))
    result = {"polarization_tested": args.polarization, "roughness_tested": args.roughness, "history": history}
    output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(history[-1], indent=2, default=str))


if __name__ == "__main__":
    main()
