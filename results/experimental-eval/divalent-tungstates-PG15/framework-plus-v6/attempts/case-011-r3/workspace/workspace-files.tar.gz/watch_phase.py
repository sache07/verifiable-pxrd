#!/usr/bin/env python3
"""Challenge one watch-list phase under a fixed accepted profile model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def fractions(project):
    hist = project.histogram(0)
    masses = [float(p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]) for p in project.phases()]
    total = sum(max(0.0, v) for v in masses)
    return [max(0.0, v) / total for v in masses]


def snap(project, label):
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "fractions": fractions(project),
        "scales": [float(p.data["Histograms"][hist.name]["Scale"][0]) for p in project.phases()],
        "cells": [[float(v) for v in p.data["General"]["Cell"][1:]] for p in project.phases()],
        "names": [p.name for p in project.phases()],
        "frozen": project.get_Frozen(),
        "vary_list": [str(v) for v in cov.get("varyList", [])],
    }


def fit(project, output, label, history):
    project.refine(makeBack=False)
    project.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    history.append(snap(project, label))
    return project


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--id")
    parser.add_argument("--cif")
    parser.add_argument("--name", required=True)
    parser.add_argument("--initial-fraction", type=float, default=0.001)
    args = parser.parse_args()
    if bool(args.id) == bool(args.cif):
        parser.error("supply exactly one of --id or --cif")

    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    project.set_Frozen(None)
    project.set_Controls("cycles", 14)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    hist = project.histogram(0)

    # Hold the accepted profile/texture model fixed during detection.
    for entry in hist.data["Instrument Parameters"][0].values():
        if isinstance(entry, list) and len(entry) >= 3:
            entry[2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False

    source = cod_path(args.id) if args.id else Path(args.cif).resolve()
    phase = project.add_phase(str(source), phasename=args.name, histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    current_mass = sum(float(p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]) for p in project.phases()[:-1])
    hap["Scale"] = [float(args.initial_fraction) * current_mass / float(phase.data["General"]["Mass"]), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][1][1] = 10.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]
    project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Scale")
    project.save(str(output))
    history = [snap(project, "initial")]

    # Existing background, all scales and the one displacement correction
    # remain active from the source project; fit candidate scale before cell.
    project = fit(project, output, "scale", history)
    project.set_Frozen(None)
    for p in project.phases():
        p.set_refinements({"Cell": True})
    project = fit(project, output, "cells", history)
    result = {"candidate_id": args.id, "candidate_cif": args.cif, "candidate_name": args.name, "history": history}
    output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(history[-1], indent=2, default=str))


if __name__ == "__main__":
    main()
