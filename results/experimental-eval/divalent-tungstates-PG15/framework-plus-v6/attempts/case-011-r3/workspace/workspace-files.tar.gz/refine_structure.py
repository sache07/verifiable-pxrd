#!/usr/bin/env python3
"""Staged coordinate and common-per-phase Uiso refinement for the two parents."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def state(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    cov = project.data.get("Covariance", {}).get("data", {})
    phases, masses = [], []
    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        mass = float(p.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(0.0, mass))
        phases.append(
            {
                "name": p.name,
                "cell": [float(v) for v in p.data["General"]["Cell"][1:]],
                "scale": float(hap["Scale"][0]),
                "atoms": [
                    {
                        "label": a.label,
                        "element": a.element,
                        "coordinates": [float(v) for v in a.coordinates],
                        "uiso": float(a.uiso),
                        "flags": a.refinement_flags,
                    }
                    for a in p.atoms()
                ],
                "size": hap["Size"],
                "strain": hap["Mustrain"],
                "texture": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for p, mass in zip(phases, masses):
        p["weight_fraction"] = mass / total
    return {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "shift_um": float(hist.data["Sample Parameters"]["Shift"][0]),
        "instrument": {k: float(inst[k][1]) for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "phases": phases,
        "frozen": project.get_Frozen(),
        "vary_list": [str(v) for v in cov.get("varyList", [])],
    }


def run(project, output, label, history, rounds=2):
    for subround in range(rounds):
        project.refine(makeBack=False)
        project.save(str(output))
        project = G2.G2Project(gpxfile=str(output))
        history.append(state(project, f"{label}_{subround + 1}"))
    return project


def append_flag(atom, flag):
    atom.refinement_flags = "".join(c for c in "XU" if c in (atom.refinement_flags + flag))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--main-only", action="store_true", help="stop after W and MnO2-O coordinates")
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    if len(project.phases()) != 2:
        raise ValueError("This staged script expects the two provisional parent phases")
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    project.save(str(output))
    history = [state(project, "initial")]

    # Registered synthetic models use a neutral 0.005 A^2 before the
    # phase-level displacement draw; remove source-record ADP differences.
    for p in project.phases():
        for atom in p.atoms():
            atom.uiso = 0.005
    project = run(project, output, "neutral_uiso", history, rounds=2)

    # Heavy-atom coordinates are profile-sensitive and better conditioned.
    p0 = project.phase(0)
    for atom in p0.atoms():
        if atom.element == "W":
            append_flag(atom, "X")
    project = run(project, output, "wo3_w_coordinates", history, rounds=2)

    # The rutile oxygen x parameter controls several independent families.
    p1 = project.phase(1)
    for atom in p1.atoms():
        if atom.element == "O":
            append_flag(atom, "X")
    project = run(project, output, "mno2_o_coordinate", history, rounds=2)

    if args.main_only:
        project.save(str(output))
        output.with_suffix(".json").write_text(json.dumps({"history": history}, indent=2, default=str) + "\n")
        print(json.dumps(history[-1], indent=2, default=str))
        return

    # Release WO3 oxygen coordinates only after heavy atoms and profile settle.
    p0 = project.phase(0)
    for atom in p0.atoms():
        if atom.element == "O":
            append_flag(atom, "X")
    project = run(project, output, "wo3_o_coordinates", history, rounds=3)

    # One scalar Uiso per phase, matching the specimen model. Equivalence
    # constraints avoid atom-wise ADPs becoming intensity surrogates.
    for p in project.phases():
        for atom in p.atoms():
            append_flag(atom, "U")
        variables = [f"{p.id}::AUiso:{i}" for i, _ in enumerate(p.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=True, override=True)
        project.set_Controls("parmMin", 0.001, f"{p.id}::AUiso:*")
        project.set_Controls("parmMax", 0.03, f"{p.id}::AUiso:*")
    project = run(project, output, "phase_uiso", history, rounds=3)
    project.save(str(output))
    output.with_suffix(".json").write_text(json.dumps({"history": history}, indent=2, default=str) + "\n")
    print(json.dumps(history[-1], indent=2, default=str))


if __name__ == "__main__":
    main()
