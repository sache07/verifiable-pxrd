#!/usr/bin/env python3
"""Create submission CIFs, replay profile and result.json from verified outputs."""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / ".tmp" / "replay-final"


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    replay = json.loads((REPLAY / "replay.json").read_text())
    summary = json.loads((ROOT / ".tmp" / "final-project-summary.json").read_text())
    if replay["status"] != "replayed" or not replay["project_unchanged"]:
        raise RuntimeError("final project did not pass atomic forward replay")

    names = ["wo3_monoclinic.cif", "mno2_pyrolusite.cif", "mnwo4_wolframite.cif"]
    formulas = ["WO3", "MnO2", "MnWO4"]
    labels = [
        "monoclinic WO3",
        "beta-MnO2 (pyrolusite)",
        "MnWO4 (wolframite)",
    ]
    space_groups = ["P 21/c", "P 42/m n m", "P 2/c"]
    cod_sources = ["COD 2311041", "COD 1514110", "COD 1520200"]
    formal_fraction_esd = [0.0018017794, 0.0017483862, 0.0005358125]
    phases = []
    for i, (source, target) in enumerate(zip(replay["phases"], names)):
        shutil.copyfile(REPLAY / source["cif"], ROOT / target)
        phases.append(
            {
                "name": labels[i],
                "formula": formulas[i],
                "space_group": space_groups[i],
                "cif_path": target,
                "weight_fraction": float(source["weight_fraction"]),
                "weight_fraction_formal_esd": formal_fraction_esd[i],
                "starting_structure": cod_sources[i],
                "project_phase": source["name"],
            }
        )

    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as z:
        x = z["x"].copy()
        observed = z["observed"].copy()
        calculated = z["predicted"].copy()
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.10f",
    )
    weights = 1.0 / np.maximum(observed, 1.0)
    loss = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(loss / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))

    result = {
        "phases": phases,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "goodness_of_fit": float(summary["gof"]),
            "chi_square": loss,
            "n_observations": int(summary["n_observations"]),
            "n_refined_parameters": int(summary["n_variables"]),
            "maximum_shift_over_esd": float(summary["max_shift_over_esd"]),
            "calculation": "independent native GSAS-II atomic forward replay on the full observed grid",
        },
        "refinement_histogram": replay["histogram"],
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "project_sha256": replay["project_sha256"],
        "replay_status": replay["status"],
        "profile_review_flags": replay["profile_review_flags"],
        "measurement_model": {
            "radiation": "Cu K-alpha1/K-alpha2",
            "wavelengths_angstrom": [1.540598, 1.544426],
            "kalpha2_to_kalpha1_ratio": 0.5,
            "specimen_displacement_micrometre": -603.6344449614911,
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    manifest = {
        "final.gpx": sha256(ROOT / "final.gpx"),
        "fit.csv": sha256(ROOT / "fit.csv"),
        "result.json": sha256(ROOT / "result.json"),
        **{name: sha256(ROOT / name) for name in names},
    }
    (ROOT / ".tmp" / "final-artifact-hashes.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"rwp_percent": rwp, "rp_percent": rp, "phases": phases, "hashes": manifest}, indent=2))


if __name__ == "__main__":
    main()
