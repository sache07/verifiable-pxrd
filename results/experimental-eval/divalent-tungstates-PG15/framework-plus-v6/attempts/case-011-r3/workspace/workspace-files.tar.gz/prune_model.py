#!/usr/bin/env python3
"""Prune unsupported/bound nuisance flags and reconverge the accepted baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def snapshot(p, i):
    h = p.histogram(0); inst = h.data["Instrument Parameters"][0]; sample = h.data["Sample Parameters"]
    cov = p.data.get("Covariance", {}).get("data", {})
    masses, rows = [], []
    for phase in p.phases():
        hap = phase.data["Histograms"][h.name]; m = float(phase.data["General"]["Mass"] * hap["Scale"][0]); masses.append(m)
        rows.append({"name": phase.name, "scale": float(hap["Scale"][0]), "cell": list(map(float, phase.data["General"]["Cell"][1:])),
                     "size": hap["Size"], "strain": hap["Mustrain"], "texture": hap["Pref.Ori."],
                     "atoms": [{"label": a.label, "element": a.element, "coordinates": list(map(float, a.coordinates)),
                                "uiso": float(a.uiso), "flags": a.refinement_flags} for a in phase.atoms()]})
    total = sum(masses)
    for row, m in zip(rows, masses): row["weight_fraction"] = m / total
    return {"iteration": i, "rwp_percent": h.get_wR(), "gof": cov.get("Rvals", {}).get("GOF"),
            "shift_um": float(sample["Shift"][0]), "roughness_A": float(sample["SurfRoughA"][0]),
            "roughness_B": float(sample["SurfRoughB"][0]), "polarization": float(inst["Polariz."][1]),
            "instrument": {k: float(inst[k][1]) for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
            "phases": rows, "frozen": p.get_Frozen(), "vary_list": [str(v) for v in cov.get("varyList", [])]}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("input"); ap.add_argument("output"); ap.add_argument("--rounds", type=int, default=4)
    args = ap.parse_args(); output = Path(args.output).resolve(); output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn"); p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output)); h = p.histogram(0)
    inst = h.data["Instrument Parameters"][0]; sample = h.data["Sample Parameters"]
    inst["U"][1:] = [0.0, False]
    inst["SH/L"][1:] = [0.03, False]
    sample["SurfRoughA"] = [0.2, False]
    sample["SurfRoughB"][1] = False
    for phase in p.phases():
        for atom in phase.atoms():
            atom.uiso = 0.005
            atom.refinement_flags = atom.refinement_flags.replace("U", "")
    p.set_Frozen(None); p.set_Controls("cycles", 20); p.data["Controls"]["data"]["min dM/M"] = 1e-7
    p.save(str(output)); history = [snapshot(p, 0)]
    for i in range(1, args.rounds + 1):
        p.refine(makeBack=False); p.save(str(output)); p = G2.G2Project(gpxfile=str(output)); history.append(snapshot(p, i))
    output.with_suffix(".json").write_text(json.dumps({"history": history}, indent=2, default=str) + "\n")
    print(json.dumps(history[-1], indent=2, default=str))


if __name__ == "__main__": main()
