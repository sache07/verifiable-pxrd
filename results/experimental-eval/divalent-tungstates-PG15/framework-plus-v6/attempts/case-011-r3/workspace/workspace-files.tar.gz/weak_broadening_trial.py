#!/usr/bin/env python3
"""Compare neutral, size-only, and strain-only broadening for the weak phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def state(project, iteration, mode):
    hist = project.histogram(0)
    phase = project.phases()[-1]
    hap = phase.data["Histograms"][hist.name]
    masses = [max(0.0, float(p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0])) for p in project.phases()]
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "iteration": iteration,
        "mode": mode,
        "rwp_percent": float(hist.get_wR()),
        "gof": float(cov.get("Rvals", {}).get("GOF", float("nan"))),
        "weak_fraction": masses[-1] / sum(masses),
        "weak_cell": [float(x) for x in phase.data["General"]["Cell"][1:]],
        "weak_size": hap["Size"],
        "weak_strain": hap["Mustrain"],
        "frozen": project.get_Frozen(),
        "vary_list": [str(v) for v in cov.get("varyList", [])],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--mode", choices=("size", "strain"), required=True)
    parser.add_argument("--rounds", type=int, default=4)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    hist = project.histogram(0)
    phase = project.phases()[-1]
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    if args.mode == "size":
        hap["Size"][1][0] = 0.5
        hap["Size"][2][0] = True
        project.set_Controls("parmMin", 0.02, f"{phase.id}:{hist.id}:Size;i")
        project.set_Controls("parmMax", 20.0, f"{phase.id}:{hist.id}:Size;i")
    else:
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, f"{phase.id}:{hist.id}:Mustrain;i")
    project.set_Frozen(None)
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.save(str(output))
    history = [state(project, 0, args.mode)]
    for iteration in range(1, args.rounds + 1):
        project.set_Frozen(None)
        project.refine(makeBack=False)
        project.save(str(output))
        project = G2.G2Project(gpxfile=str(output))
        history.append(state(project, iteration, args.mode))
    output.with_suffix(".json").write_text(json.dumps({"history": history}, indent=2, default=str) + "\n")
    print(json.dumps(history[-1], indent=2, default=str))


if __name__ == "__main__":
    main()
