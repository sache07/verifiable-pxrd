#!/usr/bin/env python3
"""Create physically screened MnWO4 models from isostructural divalent analogues."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.io.cif import CifFile, CifParser, CifWriter


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PARENTS = {"fe_9008124": ("9008124", "Fe"), "zn_1520641": ("1520641", "Zn"), "mg_9013902": ("9013902", "Mg")}


def path_for(cod_id):
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main():
    out = Path(".tmp/mnwo4-analogues").resolve(); out.mkdir(parents=True, exist_ok=True)
    records = []
    for name, (cod_id, old) in PARENTS.items():
        source = path_for(cod_id)
        structure = CifParser(source, occupancy_tolerance=1.0, frac_tolerance=0).parse_structures(primitive=False)[0]
        structure.remove_oxidation_states()
        structure.replace_species({old: "Mn"})
        target = out / f"mnwo4_from_{name}.cif"
        writer = CifWriter(structure, symprec=0.001, significant_figures=10)
        cif = CifFile.from_str(str(writer))
        for block in cif.data.values():
            tag = "_atom_site_U_iso_or_equiv"
            block.data[tag] = ["0.0050000000"] * len(block.data["_atom_site_label"])
            loop = next(loop for loop in block.loops if "_atom_site_label" in loop)
            if tag not in loop: loop.append(tag)
        target.write_text(str(cif) + "\n")
        distances = structure.distance_matrix.copy()
        import numpy as np
        np.fill_diagonal(distances, np.inf)
        records.append({"name": name, "parent_cod_id": cod_id, "parent_element": old, "cif": str(target),
                        "substitution": f"{old}2+ -> Mn2+ on the wolframite divalent-cation site",
                        "space_group": structure.get_space_group_info(), "cell": list(structure.lattice.parameters),
                        "minimum_interatomic_distance_A": float(distances.min()), "density_g_cm3": float(structure.density)})
    (out / "provenance.json").write_text(json.dumps(records, indent=2, default=str) + "\n")
    print(json.dumps(records, indent=2, default=str))


if __name__ == "__main__": main()
