#!/usr/bin/env python3
"""Refine one equivalenced isotropic displacement parameter per phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def add_u_flag(atom):
    atom.refinement_flags = "".join(c for c in "XU" if c in (atom.refinement_flags + "U"))


def state(p, iteration):
    h = p.histogram(0)
    cov = p.data.get("Covariance", {}).get("data", {})
    masses, rows = [], []
    for phase in p.phases():
        hap = phase.data["Histograms"][h.name]
        mass = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(mass)
        rows.append({"name": phase.name, "uiso": [float(a.uiso) for a in phase.atoms()],
                     "scale": float(hap["Scale"][0]), "flags": [a.refinement_flags for a in phase.atoms()]})
    total = sum(masses)
    for row, mass in zip(rows, masses): row["weight_fraction"] = mass / total
    return {"iteration": iteration, "rwp_percent": h.get_wR(), "gof": cov.get("Rvals", {}).get("GOF"),
            "phases": rows, "frozen": p.get_Frozen(),
            "vary_list": [str(v) for v in cov.get("varyList", [])]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--rounds", type=int, default=3)
    args = parser.parse_args()
    output = Path(args.output).resolve(); output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    p.set_Controls("cycles", 20); p.data["Controls"]["data"]["min dM/M"] = 1e-7
    for phase in p.phases():
        for atom in phase.atoms(): add_u_flag(atom)
        variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1: p.add_EquivConstr(variables, reloadIdx=True, override=True)
        p.set_Controls("parmMin", 0.001, f"{phase.id}::AUiso:*")
        p.set_Controls("parmMax", 0.03, f"{phase.id}::AUiso:*")
    p.save(str(output)); history = [state(p, 0)]
    for i in range(1, args.rounds + 1):
        p.refine(makeBack=False); p.save(str(output)); p = G2.G2Project(gpxfile=str(output)); history.append(state(p, i))
    output.with_suffix(".json").write_text(json.dumps({"history": history}, indent=2, default=str) + "\n")
    print(json.dumps(history[-1], indent=2, default=str))


if __name__ == "__main__": main()
