#!/usr/bin/env python3
"""Replay-stable phase-broadening trials from a screened GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def snapshot(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    rows, masses = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(0.0, mass))
        rows.append(
            {
                "name": phase.name,
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
                "scale": float(hap["Scale"][0]),
                "size_type": hap["Size"][0],
                "size_values": [float(v) for v in hap["Size"][1]],
                "size_flags": list(hap["Size"][2]),
                "strain_type": hap["Mustrain"][0],
                "strain_values": [float(v) for v in hap["Mustrain"][1]],
                "strain_flags": list(hap["Mustrain"][2]),
            }
        )
    total = sum(masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = mass / total if total else None
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "shift_um": float(sample["Shift"][0]),
        "instrument": {k: float(inst[k][1]) for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")},
        "phases": rows,
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "frozen": project.get_Frozen(),
    }


def save_reopen(project, output, label, history):
    project.refine(makeBack=False)
    project.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    history.append(snapshot(project, label))
    return project


def indices(text):
    if not text:
        return []
    return [int(v) for v in text.split(",")]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--size", default="", help="phase indices, enabled sequentially")
    parser.add_argument("--strain", default="", help="phase indices, enabled sequentially")
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--shl", action="store_true")
    parser.add_argument("--u", type=float, default=15.0)
    parser.add_argument("--w", type=float, default=10.0)
    parser.add_argument("--x", type=float, default=1.5)
    args = parser.parse_args()

    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key, value in (("U", args.u), ("W", args.w), ("X", args.x)):
        inst[key][1] = float(value)
        inst[key][2] = False
    inst["SH/L"][2] = False
    project.set_Frozen(None)
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    project.set_Controls("parmMin", 0.0, ":*:U")
    project.set_Controls("parmMin", 0.0, ":*:W")
    project.set_Controls("parmMin", 0.0, ":*:X")
    project.set_Controls("parmMax", 100.0, ":*:U")
    project.set_Controls("parmMax", 100.0, ":*:W")
    project.set_Controls("parmMax", 10.0, ":*:X")

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][1][1] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]

    project.save(str(output))
    history = [snapshot(project, "reset")]
    # Re-equilibrate background, scales, displacement and cells after reset.
    project = save_reopen(project, output, "reconverged", history)

    for idx in indices(args.size):
        hist = project.histogram(0)
        phase = project.phase(idx)
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.2, "refine": True}}, [hist])
        project.set_Controls("parmMin", 0.02, f"{phase.id}:{hist.id}:Size;i")
        project.set_Controls("parmMax", 20.0, f"{phase.id}:{hist.id}:Size;i")
        project = save_reopen(project, output, f"size_phase_{idx}", history)

    for idx in indices(args.strain):
        hist = project.histogram(0)
        phase = project.phase(idx)
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
        project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, f"{phase.id}:{hist.id}:Mustrain;i")
        project = save_reopen(project, output, f"strain_phase_{idx}", history)

    if args.profile:
        hist = project.histogram(0)
        keys = ["U", "W", "X"] + (["SH/L"] if args.shl else [])
        hist.set_refinements({"Instrument Parameters": keys})
        project = save_reopen(project, output, "common_profile", history)

    project.save(str(output))
    summary = {"input": str(Path(args.input).resolve()), "output": str(output), "history": history}
    output.with_suffix(".json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps(history[-1], indent=2, default=str))


if __name__ == "__main__":
    main()
