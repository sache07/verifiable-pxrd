#!/usr/bin/env python3
"""Rebuild the accepted profile after adding weak wolframite MnWO4."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fractions(project, hist):
    masses = [
        max(0.0, float(p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]))
        for p in project.phases()
    ]
    total = sum(masses)
    return [m / total for m in masses]


def snapshot(project, iteration):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    fracs = fractions(project, hist)
    phases = []
    for phase, frac in zip(project.phases(), fracs):
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "weight_fraction": frac,
                "scale": float(hap["Scale"][0]),
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
                "size": hap["Size"],
                "strain": hap["Mustrain"],
                "texture": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": a.label,
                        "element": a.element,
                        "coordinates": [float(x) for x in a.coordinates],
                        "flags": a.refinement_flags,
                    }
                    for a in phase.atoms()
                ],
            }
        )
    return {
        "iteration": iteration,
        "rwp_percent": float(hist.get_wR()),
        "gof": float(cov.get("Rvals", {}).get("GOF", float("nan"))),
        "shift_um": float(sample["Shift"][0]),
        "roughness_A": float(sample["SurfRoughA"][0]),
        "roughness_B": float(sample["SurfRoughB"][0]),
        "instrument": {
            k: float(inst[k][1])
            for k in ("Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "phases": phases,
        "frozen": project.get_Frozen(),
        "vary_list": [str(v) for v in cov.get("varyList", [])],
    }


def activate_supported_model(project):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    # One angular correction, six-term smooth background and restrained
    # common profile. Terms previously found unsupported remain neutral/fixed.
    hist.data["Background"][0][1] = True
    sample["Shift"][1] = True
    sample["SurfRoughA"] = [0.2, False]
    sample["SurfRoughB"][1] = False
    for key in ("U", "V", "Y", "Z", "SH/L"):
        inst[key][2] = False
    inst["U"][1] = 0.0
    inst["V"][1] = 0.0
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.03
    for key in ("W", "X", "Polariz."):
        inst[key][2] = True

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Extinction"] = [0.0, False]
        project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Scale")

    wo3, mno2, mnwo4 = project.phases()
    # Retain only the replay-stable phase broadening/texture terms.
    wo3_hap = wo3.data["Histograms"][hist.name]
    wo3_hap["Size"][2] = [True, False, False]
    wo3_hap["Mustrain"][2] = [True, False, False]
    wo3_hap["Pref.Ori."][2] = False
    mno2_hap = mno2.data["Histograms"][hist.name]
    mno2_hap["Size"][2] = [False, False, False]
    mno2_hap["Mustrain"][2] = [True, False, False]
    mno2_hap["Pref.Ori."][0] = "MD"
    mno2_hap["Pref.Ori."][2] = True
    mno2_hap["Pref.Ori."][3] = [1, 1, 0]
    weak_hap = mnwo4.data["Histograms"][hist.name]
    weak_hap["Size"][0] = "isotropic"
    weak_hap["Size"][1][:2] = [10.0, 10.0]
    weak_hap["Size"][2] = [False, False, False]
    weak_hap["Mustrain"][0] = "isotropic"
    weak_hap["Mustrain"][1][:2] = [0.0, 0.0]
    weak_hap["Mustrain"][2] = [False, False, False]
    weak_hap["Pref.Ori."][0] = "MD"
    weak_hap["Pref.Ori."][1] = 1.0
    weak_hap["Pref.Ori."][2] = False

    # Only coordinates demonstrated as supported in the dominant phases.
    for atom in wo3.atoms():
        atom.refinement_flags = "X" if atom.element == "W" else ""
    for atom in mno2.atoms():
        atom.refinement_flags = "X" if atom.element == "O" else ""
    for atom in mnwo4.atoms():
        atom.refinement_flags = ""

    project.set_Controls("parmMin", 0.02, f"{wo3.id}:{hist.id}:Size;i")
    project.set_Controls("parmMax", 20.0, f"{wo3.id}:{hist.id}:Size;i")
    for phase in (wo3, mno2):
        project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;i")
        project.set_Controls("parmMax", 20000.0, f"{phase.id}:{hist.id}:Mustrain;i")
    project.set_Controls("parmMin", 0.5, f"{mno2.id}:{hist.id}:MD")
    project.set_Controls("parmMax", 2.0, f"{mno2.id}:{hist.id}:MD")
    project.set_Controls("parmMin", 0.0, f":{hist.id}:W")
    project.set_Controls("parmMax", 100.0, f":{hist.id}:W")
    project.set_Controls("parmMin", 0.0, f":{hist.id}:X")
    project.set_Controls("parmMax", 20.0, f":{hist.id}:X")
    project.set_Controls("parmMin", 0.0, f":{hist.id}:Polariz.")
    project.set_Controls("parmMax", 1.0, f":{hist.id}:Polariz.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--rounds", type=int, default=6)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    activate_supported_model(project)
    project.set_Frozen(None)
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    project.save(str(output))
    history = [snapshot(project, 0)]
    for iteration in range(1, args.rounds + 1):
        project.set_Frozen(None)
        project.refine(makeBack=False)
        project.save(str(output))
        project = G2.G2Project(gpxfile=str(output))
        history.append(snapshot(project, iteration))
        print(json.dumps({k: history[-1][k] for k in ("iteration", "rwp_percent", "gof", "shift_um", "instrument", "frozen")}, default=str))
    output.with_suffix(".json").write_text(json.dumps({"history": history}, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
