#!/usr/bin/env python3
"""Write the accepted GSAS-II project and a machine-readable project summary."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    source = Path(args.input).resolve()
    output = Path(args.output).resolve()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.set_Frozen(None)
    project.save(str(output))
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    masses = [float(p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]) for p in project.phases()]
    total = sum(masses)
    phases = []
    for phase, mass in zip(project.phases(), masses):
        cell, cell_esd = phase.get_cell_and_esd()
        phases.append(
            {
                "name": phase.name,
                "weight_fraction": mass / total,
                "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
                "cell": cell,
                "cell_esd": cell_esd,
                "formula": phase.data["General"].get("Name", phase.name),
                "space_group": phase.data["General"]["SGData"].get("SpGrp"),
            }
        )
    summary = {
        "project": str(output),
        "histogram": hist.name,
        "native_rwp_percent": float(hist.get_wR()),
        "gof": float(cov["Rvals"]["GOF"]),
        "chi_square": float(cov["Rvals"]["chisq"]),
        "n_observations": int(cov["Rvals"]["Nobs"]),
        "n_variables": int(cov["Rvals"]["Nvars"]),
        "max_shift_over_esd": float(cov["Rvals"]["Max shft/sig"]),
        "frozen": project.get_Frozen(),
        "phases": phases,
    }
    Path(".tmp/final-project-summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
