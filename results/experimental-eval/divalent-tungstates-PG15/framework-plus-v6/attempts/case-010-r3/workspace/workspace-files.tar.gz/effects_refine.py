#!/usr/bin/env python3
"""Compare common intensity corrections before testing phase texture."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def nums(d):
    return {
        k: float(v)
        for k, v in d.items()
        if isinstance(v, (int, float, np.integer, np.floating))
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--polarization", action="store_true")
    ap.add_argument("--roughness", action="store_true")
    ap.add_argument("--shift", action="store_true", help="use specimen Shift in place of Zero")
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    proj = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    hist = proj.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    inst["Polariz."][2] = bool(args.polarization)
    sample["SurfRoughA"][1] = bool(args.roughness)
    sample["SurfRoughB"][1] = bool(args.roughness)
    sample["Shift"][1] = bool(args.shift)
    if args.roughness:
        sample["SurfRoughA"][0] = 0.30
        sample["SurfRoughB"][0] = 0.10
    else:
        sample["SurfRoughA"][0] = 0.0
        sample["SurfRoughB"][0] = 0.0
    if args.shift:
        inst["Zero"][1] = 0.0
        inst["Zero"][2] = False
        sample["Shift"][0] = -575.0
    else:
        sample["Shift"][0] = 0.0
        sample["Shift"][1] = False

    proj.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    proj.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    proj.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    proj.set_Controls("parmMax", 0.999, variable=":0:SurfRoughA")
    proj.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    proj.set_Controls("parmMax", 2.0, variable=":0:SurfRoughB")
    proj.set_Controls("parmMin", -2000.0, variable=":0:Shift")
    proj.set_Controls("parmMax", 2000.0, variable=":0:Shift")
    proj.set_Controls("cycles", 16)
    proj.refine(makeBack=False)
    proj.set_Controls("cycles", 16)
    proj.refine(makeBack=False)
    proj.save(args.output)
    result = {
        "residuals": nums(hist.residuals),
        "instrument": {k: v for k, v in inst.items() if isinstance(v, list)},
        "sample": sample,
        "vary_list": [str(v) for v in proj.get_VaryList()],
        "frozen": proj.get_Frozen(),
    }
    Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
