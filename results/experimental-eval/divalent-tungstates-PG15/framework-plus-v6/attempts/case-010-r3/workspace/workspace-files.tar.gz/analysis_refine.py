#!/usr/bin/env python3
"""Build and stage restrained GSAS-II refinements for candidate PXRD inventories.

This is an analysis helper for the current pattern. It intentionally keeps a
single smooth background, one zero correction, one common instrumental
profile, and neutral phase-specific broadening/texture at the screening stage.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inst(path: Path) -> None:
    path.write_text(
        "# GSAS-II Cu Ka laboratory Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.25;Polariz.:0.75;Azimuth:0.0\n"
        "U:8.0;V:0.0;W:12.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.025\n"
    )


def phase_summary(phase, hist_name: str) -> dict:
    hap = phase.data["Histograms"][hist_name]
    return {
        "name": phase.name,
        "cell": phase.get_cell(),
        "scale": float(hap["Scale"][0]),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "mass": float(phase.data["General"]["Mass"]),
    }


def clamp_profile(hist) -> None:
    inst = hist.data["Instrument Parameters"][0]
    for key, lo in (("U", 0.0), ("W", 0.01), ("X", 0.001), ("SH/L", 0.001)):
        if key in inst:
            inst[key][1] = max(float(inst[key][1]), lo)
    if "Polariz." in inst:
        inst["Polariz."][1] = min(1.0, max(0.0, float(inst["Polariz."][1])))


def run_refinement(proj, label: str, log: list[dict]) -> None:
    proj.set_Controls("cycles", 8)
    proj.refine(makeBack=False)
    hist = proj.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    entry = {
        "stage": label,
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if isinstance(v, (int, float, np.integer, np.floating))
        },
        "instrument": {
            k: float(v[1])
            for k, v in inst.items()
            if isinstance(v, list) and len(v) >= 2 and isinstance(v[1], (int, float))
        },
        "sample": {
            k: float(v[0])
            for k, v in sample.items()
            if isinstance(v, list) and v and isinstance(v[0], (int, float))
        },
        "background": list(hist.data["Background"][0]),
        "phases": [phase_summary(p, hist.name) for p in proj.phases()],
    }
    log.append(entry)
    print(label, json.dumps(entry["residuals"], sort_keys=True))


def build(args) -> None:
    G2.SetPrintLevel("warn")
    out = Path(args.output).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    inst_path = out.with_suffix(".instprm")
    write_inst(inst_path)

    proj = G2.G2Project(newgpx=str(out))
    hist = proj.add_powder_histogram(
        str(Path(args.pattern).resolve()), str(inst_path), fmthint="comma"
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": [1100.0] + [0.0] * (args.background_terms - 1),
                "refine": True,
            },
        }
    )

    phases = []
    for spec in args.cifs:
        path = cod_path(spec) if spec.isdigit() and len(spec) == 7 else Path(spec)
        if not path.is_file():
            raise FileNotFoundError(path)
        phase = proj.add_phase(
            str(path.resolve()),
            phasename=f"phase_{len(phases)}_{path.stem}",
            histograms=[hist],
            fmthint="CIF",
        )
        phases.append(phase)

    # Neutral nuisance model for phase screening.
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [max(0.1, 1.0 / len(phases)), True]
        phase.setSampleProfile(hist.name, "size", "isotropic", 10.0)
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", 0.0)
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    log: list[dict] = []

    # First fit a smooth background and all scales at a close initial zero.
    run_refinement(proj, "background_scales", log)

    # Refit background/scales with exactly one angular correction and cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_refinement(proj, "zero_cells", log)

    # Establish one nonnegative common U/W/X profile.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    run_refinement(proj, "common_profile", log)
    clamp_profile(hist)
    run_refinement(proj, "common_profile_reconverged", log)

    # Release axial-divergence asymmetry only after the symmetric profile.
    if args.refine_asymmetry:
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        run_refinement(proj, "asymmetry", log)
        clamp_profile(hist)
        run_refinement(proj, "asymmetry_reconverged", log)

    proj.save(str(out))
    report = {
        "project": str(out),
        "pattern": str(Path(args.pattern).resolve()),
        "cifs": [str(cod_path(x) if x.isdigit() and len(x) == 7 else Path(x).resolve()) for x in args.cifs],
        "stages": log,
    }
    out.with_suffix(".json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("output")
    p.add_argument("cifs", nargs="+")
    p.add_argument("--pattern", default="inputs/pattern.csv")
    p.add_argument("--background-terms", type=int, default=8)
    p.add_argument("--refine-asymmetry", action="store_true")
    build(p.parse_args())


if __name__ == "__main__":
    main()
