#!/usr/bin/env python3
"""Test whether a weak phase supports its own isotropic size/strain terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("phase", type=int)
    ap.add_argument("--size", action="store_true")
    ap.add_argument("--strain", action="store_true")
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    proj = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    hist = proj.histogram(0)
    phase = proj.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][2][0] = bool(args.size)
    hap["Mustrain"][2][0] = bool(args.strain)
    proj.set_Controls("parmMin", 0.001, variable=f"{args.phase}:0:Size;i")
    proj.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;i")
    for _ in range(2):
        proj.set_Controls("cycles", 20)
        proj.refine(makeBack=False)
    proj.save(args.output)
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in proj.phases()]
    cov = proj.data.get("Covariance", {}).get("data", {})
    sigmas = dict(zip([str(v) for v in cov.get("varyList", [])], cov.get("sig", [])))
    result = {
        "rwp": float(hist.residuals["wR"]),
        "weight_fractions": [float(v / sum(masses)) for v in masses],
        "size_um": float(hap["Size"][1][0]),
        "size_sigma": sigmas.get(f"{args.phase}:0:Size;i"),
        "strain_ppm": float(hap["Mustrain"][1][0]),
        "strain_sigma": sigmas.get(f"{args.phase}:0:Mustrain;i"),
        "frozen": proj.get_Frozen(),
    }
    Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
