#!/usr/bin/env python3
"""Prune correlated phase-profile terms and reconverge a full-range project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("phase", type=int)
    ap.add_argument("--drop-size", action="store_true")
    ap.add_argument("--drop-strain", action="store_true")
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    proj = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    hist = proj.histogram(0)
    phase = proj.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    if args.drop_size:
        phase.setSampleProfile(hist.name, "size", "isotropic", 10.0)
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])
    if args.drop_strain:
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", 0.0)
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    for _ in range(2):
        proj.set_Controls("cycles", 20)
        proj.refine(makeBack=False)
    proj.save(args.output)
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in proj.phases()]
    result = {
        "rwp": float(hist.residuals["wR"]),
        "weight_fractions": [float(v / sum(masses)) for v in masses],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "vary_list": [str(v) for v in proj.get_VaryList()],
        "frozen": proj.get_Frozen(),
    }
    Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
