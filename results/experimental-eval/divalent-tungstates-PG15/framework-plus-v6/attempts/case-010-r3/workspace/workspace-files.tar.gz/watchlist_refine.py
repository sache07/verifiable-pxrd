#!/usr/bin/env python3
"""Re-challenge a plausible weak phase under a converged common model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def result(proj, phase, label):
    hist = proj.histogram(0)
    hap = phase.data["Histograms"][hist.name]
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in proj.phases()]
    return {
        "stage": label,
        "rwp": float(hist.residuals["wR"]),
        "candidate_scale": float(hap["Scale"][0]),
        "candidate_mass_fraction": float(masses[-1] / sum(masses)) if sum(masses) > 0 else None,
        "cell": phase.get_cell(),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "frozen": proj.get_Frozen(),
        "vary_list": [str(v) for v in proj.get_VaryList()],
    }


def refine(proj, phase, label, log):
    proj.set_Controls("cycles", 16)
    proj.refine(makeBack=False)
    item = result(proj, phase, label)
    log.append(item)
    print(json.dumps(item, indent=2, allow_nan=False))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("cif")
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    proj = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    hist = proj.histogram(0)
    path = cod_path(args.cif) if args.cif.isdigit() and len(args.cif) == 7 else Path(args.cif)
    phase = proj.add_phase(str(path.resolve()), phasename=f"watch_{path.stem}", histograms=[hist], fmthint="CIF")
    pidx = len(proj.phases()) - 1
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.10, True]
    phase.set_refinements({"Cell": False})
    phase.setSampleProfile(hist.name, "size", "isotropic", 10.0)
    phase.setSampleProfile(hist.name, "microstrain", "isotropic", 0.0)
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    proj.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Scale")
    log = []
    refine(proj, phase, "neutral_profile_scale", log)

    # A second fair test gives the record the broadening already established
    # for the occupied product/precursor phases, but does not add new terms.
    proj.set_Frozen(variable=f"{pidx}:0:Scale", mode="remove")
    hap["Scale"] = [max(0.05, float(hap["Scale"][0])), True]
    phase.setSampleProfile(hist.name, "size", "isotropic", 0.16)
    phase.setSampleProfile(hist.name, "microstrain", "isotropic", 4000.0)
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    refine(proj, phase, "established_broadening_scale", log)

    if hap["Scale"][0] > 1e-7:
        phase.set_refinements({"Cell": True})
        refine(proj, phase, "candidate_cell", log)
    proj.save(args.output)
    Path(args.output).with_suffix(".json").write_text(
        json.dumps({"input": args.input, "source": str(path), "stages": log}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
