#!/usr/bin/env python3
"""Stage symmetry-preserving coordinate and common-per-phase Uiso refinement."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def residuals(hist):
    return {
        k: float(v)
        for k, v in hist.residuals.items()
        if isinstance(v, (int, float, np.integer, np.floating))
    }


def atom_state(phase):
    return [
        {
            "label": a.label,
            "element": a.element,
            "coordinates": [float(v) for v in a.coordinates],
            "occupancy": float(a.occupancy),
            "flags": a.refinement_flags,
            "uiso": float(a.data[a.cia + 1]),
            "site_symmetry": str(a.data[a.cs]),
            "multiplicity": int(a.data[a.cs + 1]),
        }
        for a in phase.atoms()
    ]


def snapshot(proj, label):
    hist = proj.histogram(0)
    return {
        "stage": label,
        "residuals": residuals(hist),
        "vary_list": [str(v) for v in proj.get_VaryList()],
        "phases": [
            {
                "name": p.name,
                "cell": p.get_cell(),
                "atoms": atom_state(p),
                "hap": copy.deepcopy(p.data["Histograms"][hist.name]),
            }
            for p in proj.phases()
        ],
    }


def refine(proj, label, log, cycles=8):
    proj.set_Controls("cycles", cycles)
    proj.refine(makeBack=False)
    state = snapshot(proj, label)
    log.append(state)
    print(label, state["residuals"].get("wR"))


def set_uiso(atom, value):
    atom.data[atom.cia] = "I"
    atom.data[atom.cia + 1] = float(value)


def add_common_uiso_constraints(proj):
    proj.index_ids()
    for pidx, phase in enumerate(proj.phases()):
        variables = [f"{pidx}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            proj.add_EquivConstr(variables, reloadIdx=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--oxygen", action="store_true", help="refine oxygen coordinates after heavy atoms")
    ap.add_argument("--uiso", action="store_true", help="refine one constrained Uiso per phase")
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    proj = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    hist = proj.histogram(0)
    # The registered pool convention is 0.005 A^2; use it as the common,
    # phase-neutral starting point before fitting one value per phase.
    for phase in proj.phases():
        for atom in phase.atoms():
            set_uiso(atom, 0.005)
            atom.refinement_flags = " "

    log = []
    refine(proj, "common_uiso_start_reconvergence", log)

    # Heavy-atom shifts dominate X-ray structure factors and are tested first.
    for phase in proj.phases():
        for atom in phase.atoms():
            if atom.element != "O":
                atom.refinement_flags = "X"
    refine(proj, "heavy_atom_coordinates", log, cycles=12)

    if args.oxygen:
        for phase in proj.phases():
            for atom in phase.atoms():
                if atom.element == "O":
                    atom.refinement_flags = "X"
        refine(proj, "oxygen_coordinates", log, cycles=12)

    if args.uiso:
        for phase in proj.phases():
            for atom in phase.atoms():
                atom.refinement_flags = atom.refinement_flags.strip() + "U"
        proj.save(args.output)
        add_common_uiso_constraints(proj)
        refine(proj, "common_phase_uiso", log, cycles=12)

    refine(proj, "structural_reconvergence", log, cycles=16)
    proj.save(args.output)
    Path(args.output).with_suffix(".json").write_text(
        json.dumps({"input": args.input, "output": args.output, "stages": log}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
