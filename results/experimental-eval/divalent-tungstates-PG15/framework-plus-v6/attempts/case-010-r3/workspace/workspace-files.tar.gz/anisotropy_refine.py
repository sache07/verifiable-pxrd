#!/usr/bin/env python3
"""Challenge one phase with uniaxial microstrain along a specified axis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("phase", type=int)
    ap.add_argument("h", type=int)
    ap.add_argument("k", type=int)
    ap.add_argument("l", type=int)
    ap.add_argument("--ratio", type=float, default=1.25)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    proj = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    hist = proj.histogram(0)
    phase = proj.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    equatorial = float(hap["Mustrain"][1][0])
    phase.setSampleProfile(
        hist.name,
        "microstrain",
        "uniaxial",
        equatorial,
        equatorial * args.ratio,
        [args.h, args.k, args.l],
    )
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    proj.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;i")
    proj.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:Mustrain;a")
    proj.set_Controls("cycles", 16)
    proj.refine(makeBack=False)
    proj.set_Controls("cycles", 16)
    proj.refine(makeBack=False)
    proj.save(args.output)
    residuals = {
        k: float(v)
        for k, v in hist.residuals.items()
        if isinstance(v, (int, float, np.integer, np.floating))
    }
    cov = proj.data.get("Covariance", {}).get("data", {})
    sigmas = dict(zip([str(v) for v in cov.get("varyList", [])], cov.get("sig", [])))
    result = {
        "residuals": residuals,
        "phase": phase.name,
        "axis": [args.h, args.k, args.l],
        "equatorial_ppm": float(hap["Mustrain"][1][0]),
        "axial_ppm": float(hap["Mustrain"][1][1]),
        "sigma_equatorial": sigmas.get(f"{args.phase}:0:Mustrain;i"),
        "sigma_axial": sigmas.get(f"{args.phase}:0:Mustrain;a"),
        "frozen": proj.get_Frozen(),
        "vary_list": [str(v) for v in proj.get_VaryList()],
    }
    Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
