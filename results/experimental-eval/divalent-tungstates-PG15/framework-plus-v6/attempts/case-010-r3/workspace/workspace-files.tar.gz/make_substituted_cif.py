#!/usr/bin/env python3
"""Create a composition-substituted analogue while preserving the parent framework."""

import argparse
from pathlib import Path

from pymatgen.core import Element, Structure
from pymatgen.io.cif import CifWriter


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("parent")
    ap.add_argument("output")
    ap.add_argument("old")
    ap.add_argument("new")
    args = ap.parse_args()
    structure = Structure.from_file(args.parent, primitive=False)
    structure.replace_species({args.old: args.new})
    structure.remove_oxidation_states()
    CifWriter(structure, symprec=1e-3, significant_figures=10).write_file(args.output)
    print(args.output, structure.composition, structure.get_space_group_info(), structure.lattice)


if __name__ == "__main__":
    main()
