#!/usr/bin/env python3
"""Rebuild a physically nonnegative phase-profile model from a screened GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def numeric_residuals(hist):
    return {
        k: float(v)
        for k, v in hist.residuals.items()
        if isinstance(v, (int, float, np.integer, np.floating))
    }


def snapshot(proj, label):
    hist = proj.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    phases = []
    for p in proj.phases():
        h = p.data["Histograms"][hist.name]
        phases.append(
            {
                "name": p.name,
                "scale": float(h["Scale"][0]),
                "mass": float(p.data["General"]["Mass"]),
                "cell": p.get_cell(),
                "size": h["Size"],
                "mustrain": h["Mustrain"],
                "preferred_orientation": h["Pref.Ori."],
            }
        )
    return {
        "stage": label,
        "residuals": numeric_residuals(hist),
        "instrument": {
            k: float(v[1])
            for k, v in inst.items()
            if isinstance(v, list)
            and len(v) >= 2
            and isinstance(v[1], (int, float, np.integer, np.floating))
        },
        "background": list(hist.data["Background"][0]),
        "phases": phases,
        "vary_list": [str(v) for v in proj.get_VaryList()],
        "frozen": proj.get_Frozen(),
    }


def refine(proj, label, log, cycles=8):
    proj.set_Controls("cycles", cycles)
    proj.refine(makeBack=False)
    item = snapshot(proj, label)
    log.append(item)
    print(label, item["residuals"].get("wR"), item["instrument"])


def clear_flags(proj):
    hist = proj.histogram(0)
    hist.clear_refinements({"Instrument Parameters": list(hist.data["Instrument Parameters"][0])})
    hist.clear_refinements({"Sample Parameters": [k for k, v in hist.data["Sample Parameters"].items() if isinstance(v, list) and len(v) > 1]})
    for p in proj.phases():
        p.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
                "HStrain": True,
                "Babinet": ["BabA", "BabU"],
            }
        )
        p.clear_refinements({"Cell": True, "Atoms": [a.label for a in p.atoms()]})
    proj.set_Frozen()


def set_nonnegative_profile_limits(proj):
    # Histogram 0 constant-wavelength profile variables.
    for var in (":0:U", ":0:W", ":0:X"):
        proj.set_Controls("parmMin", 0.001, variable=var)
    proj.set_Controls("parmMin", 0.001, variable=":0:SH/L")
    proj.set_Controls("parmMax", 1.0, variable=":0:SH/L")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--u", type=float, default=15.0)
    ap.add_argument("--w", type=float, default=12.0)
    ap.add_argument("--x", type=float, default=1.0)
    ap.add_argument("--shl", type=float, default=0.025)
    ap.add_argument("--initial-size", type=float, default=1.0)
    ap.add_argument("--initial-strain", type=float, default=1000.0)
    ap.add_argument("--refine-instrument", action="store_true")
    ap.add_argument("--refine-asymmetry", action="store_true")
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    proj = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    clear_flags(proj)
    set_nonnegative_profile_limits(proj)
    hist = proj.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key, value in (("U", args.u), ("W", args.w), ("X", args.x), ("SH/L", args.shl)):
        inst[key][1] = value
        inst[key][2] = False
    inst["V"][1:] = [0.0, False]
    inst["Y"][1:] = [0.0, False]
    inst["Z"][1:] = [0.0, False]

    # Keep the established inventory positional model active throughout.
    hist.set_refinements({"Background": True, "Instrument Parameters": ["Zero"]})
    for p in proj.phases():
        p.set_refinements({"Cell": True})
        p.set_HAP_refinements({"Scale": True})
        h = p.data["Histograms"][hist.name]
        p.setSampleProfile(hist.name, "size", "isotropic", 10.0)
        p.setSampleProfile(hist.name, "microstrain", "isotropic", 0.0)
        h["Size"][2] = [False, False, False]
        h["Mustrain"][2] = [False, False, False]
        h["Pref.Ori."][0] = "MD"
        h["Pref.Ori."][1] = 1.0
        h["Pref.Ori."][2] = False

    log = []
    refine(proj, "neutral_reconvergence", log)

    # Compare phase size one phase at a time, retaining supported terms.
    for i, p in enumerate(proj.phases()):
        p.setSampleProfile(hist.name, "size", "isotropic", args.initial_size)
        p.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        refine(proj, f"size_phase_{i}", log)

    # Then compare the complementary Gaussian phase broadening.
    for i, p in enumerate(proj.phases()):
        p.setSampleProfile(hist.name, "microstrain", "isotropic", args.initial_strain)
        p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        refine(proj, f"strain_phase_{i}", log)

    if args.refine_instrument:
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        refine(proj, "common_profile_released", log)

    if args.refine_asymmetry:
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        refine(proj, "asymmetry_released", log)

    refine(proj, "full_reconvergence", log, cycles=12)
    proj.save(args.output)
    Path(args.output).with_suffix(".json").write_text(
        json.dumps({"input": args.input, "output": args.output, "stages": log}, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
