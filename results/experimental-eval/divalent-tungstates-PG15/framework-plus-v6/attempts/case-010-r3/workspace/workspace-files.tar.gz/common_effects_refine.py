#!/usr/bin/env python3
"""Reparameterize shared polarization/roughness corrections and reconverge."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--a", type=float, required=True)
    ap.add_argument("--b", type=float, required=True)
    ap.add_argument("--polar", type=float, required=True)
    ap.add_argument("--refine-a", action="store_true")
    ap.add_argument("--refine-b", action="store_true")
    ap.add_argument("--refine-polar", action="store_true")
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    proj = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    hist = proj.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    inst["Polariz."][1:] = [args.polar, bool(args.refine_polar)]
    sample["SurfRoughA"] = [args.a, bool(args.refine_a)]
    sample["SurfRoughB"] = [args.b, bool(args.refine_b)]
    proj.set_Frozen()
    proj.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    proj.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    proj.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    proj.set_Controls("parmMax", 0.999, variable=":0:SurfRoughA")
    proj.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    proj.set_Controls("parmMax", 2.0, variable=":0:SurfRoughB")
    for _ in range(2):
        proj.set_Controls("cycles", 20)
        proj.refine(makeBack=False)
    proj.save(args.output)
    cov = proj.data.get("Covariance", {}).get("data", {})
    vary = [str(v) for v in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), float)
    corr = []
    if matrix.size:
        sd = np.sqrt(np.diag(matrix))
        c = matrix / np.outer(sd, sd)
        for i in range(len(vary)):
            for j in range(i):
                if abs(c[i, j]) > 0.9:
                    corr.append([float(c[i, j]), vary[j], vary[i]])
    result = {
        "rwp": float(hist.residuals["wR"]),
        "polarization": inst["Polariz."],
        "roughness_a": sample["SurfRoughA"],
        "roughness_b": sample["SurfRoughB"],
        "frozen": proj.get_Frozen(),
        "high_correlations": sorted(corr, key=lambda x: -abs(x[0]))[:20],
    }
    Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
