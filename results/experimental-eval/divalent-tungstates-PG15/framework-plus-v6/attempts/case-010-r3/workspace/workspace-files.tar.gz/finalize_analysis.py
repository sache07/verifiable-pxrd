#!/usr/bin/env python3
"""Reopen, reconverge over the complete scan, and export final GSAS-II results."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return plain(value.tolist())
    if isinstance(value, np.generic):
        return value.item()
    return value


def weight_fraction_covariance(project, histogram):
    phases = project.phases()
    masses = np.array([p.data["General"]["Mass"] for p in phases], dtype=float)
    scales = np.array(
        [p.data["Histograms"][histogram.name]["Scale"][0] for p in phases],
        dtype=float,
    )
    weighted = masses * scales
    fractions = weighted / weighted.sum()

    covdata = project.data.get("Covariance", {}).get("data", {})
    vary = [str(v) for v in covdata.get("varyList", [])]
    covariance = np.asarray(covdata.get("covMatrix", []), dtype=float)
    scale_names = [f"{p.id}:{histogram.id}:Scale" for p in phases]
    scale_covariance = np.zeros((len(phases), len(phases)), dtype=float)
    if covariance.size:
        for i, name_i in enumerate(scale_names):
            if name_i not in vary:
                continue
            ii = vary.index(name_i)
            for j, name_j in enumerate(scale_names):
                if name_j in vary:
                    scale_covariance[i, j] = covariance[ii, vary.index(name_j)]

    total = weighted.sum()
    jacobian = np.empty((len(phases), len(phases)), dtype=float)
    for i in range(len(phases)):
        for j in range(len(phases)):
            jacobian[i, j] = (
                (masses[i] if i == j else 0.0) / total
                - weighted[i] * masses[j] / total**2
            )
    fraction_covariance = jacobian @ scale_covariance @ jacobian.T
    fraction_su = np.sqrt(np.maximum(0.0, np.diag(fraction_covariance)))
    return fractions, fraction_su, fraction_covariance


def project_summary(project):
    histogram = project.histogram(0)
    fractions, fraction_su, fraction_covariance = weight_fraction_covariance(
        project, histogram
    )
    covariance = project.data.get("Covariance", {}).get("data", {})
    vary = [str(v) for v in covariance.get("varyList", [])]
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    correlations = []
    if matrix.size:
        su = np.sqrt(np.maximum(0.0, np.diag(matrix)))
        denom = np.outer(su, su)
        corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
        for i in range(len(vary)):
            for j in range(i):
                if abs(corr[i, j]) >= 0.9:
                    correlations.append(
                        [float(corr[i, j]), vary[j], vary[i]]
                    )
    rvals = covariance.get("Rvals", {})
    phases = []
    for i, (phase, fraction, su) in enumerate(
        zip(project.phases(), fractions, fraction_su)
    ):
        hap = phase.data["Histograms"][histogram.name]
        atoms = []
        for atom in phase.atoms():
            atoms.append(
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": [float(v) for v in atom.coordinates],
                    "occupancy": float(atom.occupancy),
                    "refinement_flags": atom.refinement_flags,
                    "displacement_type": atom.data[atom.cia],
                    "displacement_values": plain(atom.data[atom.cia + 1 :]),
                }
            )
        phases.append(
            {
                "index": i,
                "project_name": phase.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cell": phase.get_cell(),
                "cell_mass": float(phase.data["General"]["Mass"]),
                "scale": float(hap["Scale"][0]),
                "weight_fraction": float(fraction),
                "weight_fraction_su_from_scale_covariance": float(su),
                "size": plain(hap["Size"]),
                "microstrain": plain(hap["Mustrain"]),
                "preferred_orientation": plain(hap["Pref.Ori."]),
                "atoms": atoms,
            }
        )
    return {
        "histogram": histogram.name,
        "limits": plain(histogram.data["Limits"]),
        "residuals": plain(histogram.residuals),
        "rvals": plain(rvals),
        "instrument_parameters": plain(histogram.data["Instrument Parameters"][0]),
        "sample_parameters": plain(histogram.data["Sample Parameters"]),
        "background": plain(histogram.data["Background"]),
        "phases": phases,
        "fraction_covariance": plain(fraction_covariance),
        "vary_list": vary,
        "frozen": plain(project.get_Frozen()),
        "high_correlations": sorted(
            correlations, key=lambda item: -abs(item[0])
        ),
    }


def refine_full_range(source: Path, output: Path, freeze_atoms: bool = False):
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    histogram = project.histogram(0)
    x = np.asarray(histogram.getdata("x"), dtype=float)
    histogram.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    if freeze_atoms:
        # Coordinates have already passed the staged structural refinement.
        # Freeze the accepted values for the final nuisance reconvergence to
        # remove the near-singular paired-W coordinate directions.
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = " "
    project.set_Frozen()
    project.set_Controls("cycles", 30)
    for _ in range(2):
        project.refine(makeBack=False)
    project.save(str(output))

    # The accepted model is deliberately reopened and replayed over the same
    # complete range so that all submitted exports derive from the saved GPX.
    project = G2.G2Project(gpxfile=str(output))
    project.set_Frozen()
    project.set_Controls("cycles", 30)
    project.refine(makeBack=False)
    project.save(str(output))
    return project


def export(project, output_dir: Path):
    histogram = project.histogram(0)
    cif_names = ["phase_1_WO3.cif", "phase_2_Mn2O3.cif", "phase_3_MnWO4.cif"]
    if len(project.phases()) != len(cif_names):
        raise ValueError(f"Expected three phases, found {len(project.phases())}")
    for phase, name in zip(project.phases(), cif_names):
        phase.export_CIF(str(output_dir / name))

    x = np.asarray(histogram.getdata("x"), dtype=float)
    observed = np.asarray(histogram.getdata("yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("ycalc"), dtype=float)
    with (output_dir / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        for values in zip(x, observed, calculated, observed - calculated):
            writer.writerow(
                [f"{values[0]:.8f}", f"{values[1]:.8f}", f"{values[2]:.8f}", f"{values[3]:.8f}"]
            )
    return cif_names


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--export", action="store_true")
    parser.add_argument("--freeze-atoms", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    output = args.output.resolve()
    project = refine_full_range(args.source.resolve(), output, args.freeze_atoms)
    if args.export:
        export(project, output.parent)
    summary = project_summary(project)
    summary_path = output.parent / ".tmp" / "final_summary.json"
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    print(
        json.dumps(
            {
                "project": str(output),
                "histogram": summary["histogram"],
                "limits": summary["limits"],
                "rwp": summary["residuals"]["wR"],
                "rp": summary["residuals"]["R"],
                "gof": summary["rvals"]["GOF"],
                "fractions": [p["weight_fraction"] for p in summary["phases"]],
                "fraction_su": [
                    p["weight_fraction_su_from_scale_covariance"]
                    for p in summary["phases"]
                ],
                "high_correlations": summary["high_correlations"],
                "frozen": summary["frozen"],
            },
            indent=2,
            allow_nan=False,
        )
    )


if __name__ == "__main__":
    main()
