#!/usr/bin/env python3
"""Challenge one phase with a specified March-Dollase texture axis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("phase", type=int)
    ap.add_argument("h", type=int)
    ap.add_argument("k", type=int)
    ap.add_argument("l", type=int)
    ap.add_argument("--start", type=float, default=0.95)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    proj = G2.G2Project(gpxfile=args.input, newgpx=args.output)
    hist = proj.histogram(0)
    for i, phase in enumerate(proj.phases()):
        hap = phase.data["Histograms"][hist.name]
        if i == args.phase:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = args.start
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [args.h, args.k, args.l]
        else:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
    var = f"{args.phase}:0:MD"
    proj.set_Controls("parmMin", 0.5, variable=var)
    proj.set_Controls("parmMax", 2.0, variable=var)
    proj.set_Controls("cycles", 16)
    proj.refine(makeBack=False)
    proj.set_Controls("cycles", 16)
    proj.refine(makeBack=False)
    proj.save(args.output)
    phase = proj.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    residuals = {
        k: float(v)
        for k, v in hist.residuals.items()
        if isinstance(v, (int, float, np.integer, np.floating))
    }
    cov = proj.data.get("Covariance", {}).get("data", {})
    sigmas = dict(zip([str(v) for v in cov.get("varyList", [])], cov.get("sig", [])))
    result = {
        "residuals": residuals,
        "phase": phase.name,
        "axis": [args.h, args.k, args.l],
        "ratio": float(hap["Pref.Ori."][1]),
        "sigma": None if var not in sigmas else float(sigmas[var]),
        "frozen": proj.get_Frozen(),
        "vary_list": [str(v) for v in proj.get_VaryList()],
    }
    Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
