#!/usr/bin/env python3
"""Package and cross-check the selected GSAS-II refinement.

Run with the GSAS-II Python interpreter.  The optional replay prediction is
the read-only, freshly regenerated profile from the scorer's replay worker;
when supplied it is used for fit.csv and the reported profile statistics.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "refinement_work" / "final_selected_physical.gpx"
FINAL = ROOT / "final.gpx"
PATTERN = ROOT / "inputs" / "pattern.csv"

EXPORTS = {
    "MnWO4": "phase_1_MnWO4.cif",
    "WO3_monoclinic": "phase_2_WO3_monoclinic.cif",
    "WO3_triclinic": "phase_3_WO3_triclinic.cif",
}

DISPLAY_NAMES = {
    "MnWO4": "MnWO4 (wolframite, P2/c)",
    "WO3_monoclinic": "WO3 (monoclinic)",
    "WO3_triclinic": "WO3 (triclinic)",
}

FORMULAS = {
    "MnWO4": "MnWO4",
    "WO3_monoclinic": "WO3",
    "WO3_triclinic": "WO3",
}

PROVENANCE = {
    "MnWO4": (
        "Wolframite framework from COD 1520200; cell, Mn/W/O coordinates and a tied "
        "isotropic U were refined against this pattern."
    ),
    "WO3_monoclinic": (
        "Physical P21/c hybrid: W sublattice from room-temperature X-ray COD 1528915 "
        "and O sublattice from neutron COD 2311041; cell refined, atoms fixed."
    ),
    "WO3_triclinic": (
        "Triclinic source model COD 2106293; scale refined with source cell and atoms fixed."
    ),
}


def mass_fractions(project: G2.G2Project):
    histogram = project.histogram(0)
    phases = project.phases()
    scales = np.array([
        float(p.data["Histograms"][histogram.name]["Scale"][0]) for p in phases
    ])
    masses = np.array([float(p.data["General"]["Mass"]) for p in phases])
    amounts = scales * masses
    fractions = amounts / amounts.sum()

    covariance = project.data.get("Covariance", {}).get("data", {})
    vary = [str(v) for v in covariance.get("varyList", [])]
    full_cov = np.asarray(covariance.get("covMatrix", []), dtype=float)
    indices = []
    for p in phases:
        key = f"{p.id}:{histogram.id}:Scale"
        indices.append(vary.index(key) if key in vary else None)
    fraction_cov = np.full((len(phases), len(phases)), np.nan)
    fraction_esd = np.full(len(phases), np.nan)
    fraction_corr = np.full((len(phases), len(phases)), np.nan)
    if all(i is not None for i in indices) and full_cov.ndim == 2:
        scale_cov = full_cov[np.ix_(indices, indices)]
        total = amounts.sum()
        jacobian = np.empty((len(phases), len(phases)))
        for i in range(len(phases)):
            for j in range(len(phases)):
                jacobian[i, j] = (
                    (masses[i] * total if i == j else 0.0)
                    - amounts[i] * masses[j]
                ) / total**2
        fraction_cov = jacobian @ scale_cov @ jacobian.T
        fraction_esd = np.sqrt(np.maximum(np.diag(fraction_cov), 0.0))
        denominator = np.outer(fraction_esd, fraction_esd)
        fraction_corr = np.divide(
            fraction_cov, denominator,
            out=np.full_like(fraction_cov, np.nan), where=denominator > 0,
        )
    return phases, scales, fractions, fraction_esd, fraction_corr


def export_cifs(project: G2.G2Project) -> None:
    # The project covariance contains the final *increments* for coordinate
    # variables.  As in the independent replay worker, export full-precision
    # saved atoms rather than reapplying possibly stale increments.
    export_project = G2.G2Project(gpxfile=str(FINAL))
    export_project.data["Covariance"]["data"] = {}
    for phase in export_project.phases():
        phase.export_CIF(str(ROOT / EXPORTS[phase.name]), quickmode=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--prediction", type=Path,
        help="prediction.npz from a read-only atomic replay of final.gpx",
    )
    args = parser.parse_args()

    if not SOURCE.is_file():
        raise FileNotFoundError(SOURCE)
    shutil.copy2(SOURCE, FINAL)
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(FINAL))
    histogram = project.histogram(0)
    phases, scales, fractions, fraction_esd, fraction_corr = mass_fractions(project)
    if [p.name for p in phases] != list(EXPORTS):
        raise RuntimeError(f"Unexpected final phase order: {[p.name for p in phases]}")
    if len(project.histograms()) != 1:
        raise RuntimeError("Final project must contain exactly one observed histogram")

    observed = np.loadtxt(PATTERN, delimiter=",", skiprows=1, ndmin=2)
    x, y = observed.T
    project_x = np.asarray(histogram.getdata("X"), dtype=float)
    project_y = np.asarray(histogram.getdata("Yobs"), dtype=float)
    if not np.allclose(project_x, x, rtol=0, atol=1e-7):
        raise RuntimeError("Final project grid differs from pattern.csv")
    if not np.allclose(project_y, y, rtol=0, atol=1e-5):
        raise RuntimeError("Final project observations differ from pattern.csv")

    profile_origin = "saved GSAS-II profile"
    calculated = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    if args.prediction is not None:
        with np.load(args.prediction, allow_pickle=False) as replay:
            if not np.array_equal(replay["x"], x) or not np.array_equal(replay["observed"], y):
                raise RuntimeError("Replay profile grid/observations differ from pattern.csv")
            calculated = np.asarray(replay["predicted"], dtype=float)
        profile_origin = "read-only GSAS-II atomic replay"
    if np.any(~np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("Calculated profile contains invalid intensities")

    difference = y - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, y, calculated, difference)),
        delimiter=",", header="two_theta,observed,calculated,difference",
        comments="", fmt="%.17g",
    )

    export_cifs(project)

    weights = 1.0 / np.maximum(y, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * y**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(y)))
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    nobs = int(rvals.get("Nobs", len(y)))
    nvars = int(rvals.get("Nvars", 0))
    gof = float(np.sqrt(chi_square / max(nobs - nvars, 1)))
    rexp = float(rwp / gof)

    records = []
    for index, (phase, scale, fraction, esd) in enumerate(
        zip(phases, scales, fractions, fraction_esd)
    ):
        general = phase.data["General"]
        cell = [float(v) for v in general["Cell"][1:8]]
        records.append({
            "name": DISPLAY_NAMES[phase.name],
            "project_phase_name": phase.name,
            "formula": FORMULAS[phase.name],
            "space_group": general["SGData"]["SpGrp"].strip(),
            "structure_provenance": PROVENANCE[phase.name],
            "cif_path": EXPORTS[phase.name],
            "weight_fraction": float(fraction),
            "weight_fraction_formal_esd": None if not np.isfinite(esd) else float(esd),
            "GSAS_scale": float(scale),
            "cell": {
                "a_A": cell[0], "b_A": cell[1], "c_A": cell[2],
                "alpha_deg": cell[3], "beta_deg": cell[4], "gamma_deg": cell[5],
                "volume_A3": cell[6],
            },
        })

    result = {
        "phases": records,
        "fit_statistics": {
            "profile_origin": profile_origin,
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": rexp,
            "goodness_of_fit": gof,
            "chi_square": chi_square,
            "Nobs": nobs,
            "Nvars": nvars,
            "stored_GSAS_Rwp_percent": float(rvals.get("Rwp", np.nan)),
            "stored_GSAS_goodness_of_fit": float(rvals.get("GOF", np.nan)),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_over_esd": float(rvals.get("Max shft/sig", np.nan)),
        },
        "fraction_diagnostics": {
            "normalization": "scale times unit-cell mass, normalized over modeled crystalline phases",
            "sum": float(fractions.sum()),
            "formal_fraction_correlation_matrix": fraction_corr.tolist(),
            "note": "Formal covariance excludes phase-selection and nuisance-model uncertainty.",
        },
        "refinement_histogram": histogram.name,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
