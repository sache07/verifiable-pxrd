#!/usr/bin/env python3
"""Small, reproducible GSAS-II driver for the supplied powder pattern.

Run this script with the GSAS-II Python interpreter.  It keeps each refinement
stage in a separate GPX file so that model changes can be compared and replayed.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import shutil
import sys

import numpy as np
from scipy.ndimage import percentile_filter

try:
    from GSASII import GSASIIscriptable as G2
    from GSASII import GSASIIpath
except ModuleNotFoundError:
    # The materials-science interpreter has pymatgen but not GSAS-II and is
    # used only for ``prepare``. Refinement commands use $GSAS2_PYTHON.
    G2 = None
    GSASIIpath = None


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
WORK = ROOT / "refinement_work"
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

CANDIDATES = {
    "MnWO4": "1520200",
    "Mn3WO6": "2002703",
    "MnO": "1514108",
    "MnO_rocksalt_alt": "1514231",
    "MnO_wurtzite": "4117966",
    "Mn2O3": "1010586",
    "Mn2O3_bixbyite": "1514230",
    "Mn3O4": "9001963",
    "Mn3O4_alt": "1011262",
    "WO3_monoclinic": "1528915",
    "WO3_monoclinic_neutron": "2311041",
    "WO3_monoclinic_HP": "1563541",
    "WO3_triclinic": "2106293",
    "WO3_orthorhombic": "2107312",
    "WO3_tetragonal": "1521532",
    "WO3_hexagonal": "1004057",
}


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_registered_model(source: Path, destination: Path) -> None:
    """Reproduce the frozen generator's neutral/Uiso registration convention."""
    from pymatgen.io.cif import CifParser, CifWriter

    parser = CifParser(source, occupancy_tolerance=1.0, site_tolerance=1e-5,
                       frac_tolerance=0)
    structures = parser.parse_structures(primitive=False, on_error="raise")
    if len(structures) != 1:
        raise ValueError(f"Expected one structure in {source}")
    structure = structures[0]
    structure.remove_oxidation_states()
    for i, site in enumerate(structure):
        site.label = f"{site.species_string}{i}"
    writer = CifWriter(structure, symprec=0.001, significant_figures=10)
    tag = "_atom_site_U_iso_or_equiv"
    for block in writer.cif_file.data.values():
        block.data[tag] = ["0.0050000000"] * len(block.data["_atom_site_label"])
        loop = next(loop for loop in block.loops if "_atom_site_label" in loop)
        if tag not in loop:
            loop.append(tag)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(str(writer) + "\n")


def prepare() -> None:
    WORK.mkdir(parents=True, exist_ok=True)
    values = np.genfromtxt(PATTERN, delimiter=",", names=True)
    x = np.asarray(values["two_theta_deg"], float)
    y = np.asarray(values["intensity"], float)
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(WORK / "pattern.xye", np.column_stack((x, y, sigma)), fmt="%.10g")
    (WORK / "instrument.instprm").write_text(
        "# Cu Kalpha Bragg-Brentano starting profile; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    provenance = {}
    for name, cod_id in CANDIDATES.items():
        source = cod_path(cod_id)
        destination = WORK / "models" / f"{name}.cif"
        write_registered_model(source, destination)
        provenance[name] = {
            "cod_id": cod_id,
            "source": str(source),
            "registered_model": str(destination.relative_to(ROOT)),
            "normalization": "neutral elements; symmetry tolerance 0.001 A; Uiso=0.005 A^2",
        }
    (WORK / "model_provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    print(json.dumps({"prepared": str(WORK), "points": len(x), "candidates": list(CANDIDATES)}, indent=2))


def initial_background(x: np.ndarray, y: np.ndarray, count: int = 8) -> list[float]:
    # A low percentile suppresses Bragg peaks; the Chebyshev projection only
    # supplies stable starting values and is subsequently refined by GSAS-II.
    baseline = percentile_filter(y, percentile=20, size=401, mode="nearest")
    t = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    return np.polynomial.chebyshev.chebfit(t, baseline, count - 1).tolist()


def init_project(output: Path, model_names: list[str]) -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(output))
    phases = []
    for name in model_names:
        phases.append(project.add_phase(str(WORK / "models" / f"{name}.cif"),
                                        phasename=name, fmthint="CIF"))
    histogram = project.add_powder_histogram(str(WORK / "pattern.xye"),
                                              str(WORK / "instrument.instprm"),
                                              phases=phases)
    histogram.set_refinements({"Limits": [9.90343322, 100.09488522]})
    sp = histogram.SampleParameters
    sp["Type"] = "Bragg-Brentano"
    sp["Gonio. radius"] = 200.0
    sp["Shift"] = [-300.0, False]
    sp["Transparency"] = [0.0, False]
    sp["SurfRoughA"] = [0.0, False]
    sp["SurfRoughB"] = [0.0, False]
    x = np.asarray(histogram.getdata("X"), float)
    y = np.asarray(histogram.getdata("Yobs"), float)
    coeffs = initial_background(x, y, 8)
    histogram.set_refinements({
        "Background": {"type": "chebyschev-1", "no. coeffs": 8,
                       "coeffs": coeffs, "refine": False}
    })
    for phase in phases:
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"] = [1.0 / len(phases), False]
        phase.setSampleProfile(histogram, "size", "isotropic", 1000.0, LGmix=1.0)
        phase.setSampleProfile(histogram, "microstrain", "isotropic", 0.0, LGmix=0.0)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]
    project.set_Controls("cycles", 0)
    project.save()
    project.refine()
    project.save(str(output))
    print_summary(project, "initial calculation")


def freeze_all(project: G2.G2Project) -> None:
    for histogram in project.histograms():
        histogram.clear_refinements({"Background": True})
        histogram.clear_refinements({
            "Instrument Parameters": list(histogram.InstrumentParameters.keys())
        })
        sample_keys = [k for k, v in histogram.SampleParameters.items()
                       if isinstance(v, list) and len(v) > 1 and isinstance(v[1], (bool, np.bool_))]
        if sample_keys:
            histogram.clear_refinements({"Sample Parameters": sample_keys})
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True,
                                     "Pref.Ori.": True, "Extinction": True})


def common_flags(project: G2.G2Project, profile: bool = False,
                 asymmetry: bool = False, polarization: bool = False,
                 atoms: str = "", adp: bool = False,
                 refine_shift: bool = True) -> None:
    """Apply the common accepted model with optional progressively released terms."""
    histogram = project.histogram(0)
    histogram.set_refinements({"Background": True})
    if refine_shift:
        histogram.set_refinements({"Sample Parameters": ["Shift"]})
    instrument = []
    if profile:
        instrument.extend(["U", "W", "X"])
    if asymmetry:
        instrument.append("SH/L")
    if polarization:
        instrument.append("Polariz.")
    if instrument:
        histogram.set_refinements({"Instrument Parameters": instrument})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
        if atoms or adp:
            flag = ("X" if atoms else "") + ("U" if adp else "")
            phase.set_refinements({"Atoms": {"all": flag}})


def principal_texture_110(project: G2.G2Project) -> None:
    """Retain the supported MnWO4 texture and neutralize minor phases."""
    histogram = project.histogram(0)
    for phase_index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][3] = [1, 1, 0] if phase_index == 0 else [0, 0, 1]
        if phase_index == 0:
            phase.set_HAP_refinements({"Pref.Ori.": True})
        else:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False


def run_stage(input_path: Path, output_path: Path, stage: str, cycles: int) -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(input_path), newgpx=str(output_path))
    freeze_all(project)
    texture_axes = {
        "texture_001": [0, 0, 1],
        "texture_100": [1, 0, 0],
        "texture_010": [0, 1, 0],
        "texture_110": [1, 1, 0],
        "texture_111": [1, 1, 1],
    }
    if stage == "common":
        common_flags(project)
    elif stage == "profile":
        common_flags(project, profile=True)
    elif stage == "asymmetry":
        common_flags(project, profile=True, asymmetry=True)
    elif stage == "asymmetry_fixed_shift":
        common_flags(project, profile=True, asymmetry=True, refine_shift=False)
    elif stage == "polarization":
        common_flags(project, profile=True, asymmetry=True, polarization=True)
    elif stage == "polarization_no_asym":
        common_flags(project, profile=True, asymmetry=False, polarization=True)
    elif stage == "polarization_fixed_shift":
        common_flags(project, profile=True, asymmetry=True, polarization=True,
                     refine_shift=False)
    elif stage == "coordinates":
        common_flags(project, profile=True, asymmetry=True, polarization=True, atoms="X")
    elif stage == "coordinates_no_asym":
        common_flags(project, profile=True, asymmetry=False, polarization=True, atoms="X")
    elif stage == "coordinates_fixed_shift":
        common_flags(project, profile=True, asymmetry=True, polarization=True,
                     atoms="X", refine_shift=False)
    elif stage == "coordinates_adp":
        common_flags(project, profile=True, asymmetry=True, polarization=True,
                     atoms="X", adp=True)
    elif stage in {"inventory_common", "principal_heavy", "principal_all_coords",
                   "principal_coords_uiso_fixedpolar"}:
        # Common two-phase baseline: one smooth background, one angular
        # correction and profile shared by all phases. Only the supported
        # principal-phase March-Dollase term is released.
        common_flags(project, profile=True, asymmetry=False,
                     polarization=stage != "principal_coords_uiso_fixedpolar")
        principal_texture_110(project)
        principal = project.phases()[0]
        if stage == "principal_heavy":
            flags = {atom.label: ("X" if atom.element in {"Mn", "W"} else " ")
                     for atom in principal.atoms()}
            principal.set_refinements({"Atoms": flags})
        elif stage in {"principal_all_coords", "principal_coords_uiso_fixedpolar"}:
            principal.set_refinements({"Atoms": {"all": (
                "XU" if stage == "principal_coords_uiso_fixedpolar" else "X")}})
        if stage == "principal_coords_uiso_fixedpolar":
            if not project.get_Constraints("Phase"):
                variables = tuple(f"0::AUiso:{i}" for i, _ in enumerate(principal.atoms()))
                project.add_EquivConstr(variables)
    elif stage == "final_inventory_common":
        common_flags(project, profile=True, asymmetry=False, polarization=False)
        project.histogram(0).InstrumentParameters["Polariz."][1] = 0.50
        principal_texture_110(project)
    elif stage in {"final_weak_last_common", "final_weak_last_A_coords",
                   "final_weak_last_fixedrough_coordsU"}:
        common_flags(project, profile=True, asymmetry=False, polarization=False)
        histogram = project.histogram(0)
        histogram.InstrumentParameters["Polariz."][1] = 0.50
        principal_texture_110(project)
        project.phases()[-1].set_refinements({"Cell": False})
        principal = project.phases()[0]
        if stage == "final_weak_last_A_coords":
            histogram.SampleParameters["SurfRoughB"][0] = 0.14
            histogram.SampleParameters["SurfRoughB"][1] = False
            histogram.set_refinements({"Sample Parameters": ["SurfRoughA"]})
            principal.set_refinements({"Atoms": {"all": "X"}})
        elif stage == "final_weak_last_fixedrough_coordsU":
            histogram.SampleParameters["SurfRoughB"][0] = 0.14
            histogram.SampleParameters["SurfRoughB"][1] = False
            histogram.SampleParameters["SurfRoughA"][1] = False
            principal.set_refinements({"Atoms": {"all": "XU"}})
            if not project.get_Constraints("Phase"):
                variables = tuple(f"0::AUiso:{i}" for i, _ in enumerate(principal.atoms()))
                project.add_EquivConstr(variables)
    elif stage == "final_texture_none" or stage.startswith("final_texture_"):
        common_flags(project, profile=True, asymmetry=False, polarization=False)
        histogram = project.histogram(0)
        histogram.InstrumentParameters["Polariz."][1] = 0.50
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
            if phase.name == "WO3_triclinic":
                phase.set_refinements({"Cell": False})
        if stage != "final_texture_none":
            suffix = stage.removeprefix("final_texture_")
            axis = {"001": [0, 0, 1], "100": [1, 0, 0], "010": [0, 1, 0],
                    "110": [1, 1, 0], "111": [1, 1, 1]}[suffix]
            principal = project.phases()[0]
            hap = principal.data["Histograms"][histogram.name]
            hap["Pref.Ori."][3] = axis
            principal.set_HAP_refinements({"Pref.Ori.": True})
    elif stage == "final_fulltexture_none" or stage.startswith("final_fulltexture_"):
        common_flags(project, profile=True, asymmetry=False, polarization=False)
        histogram = project.histogram(0)
        histogram.InstrumentParameters["Polariz."][1] = 0.50
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
            if phase.name == "WO3_triclinic":
                phase.set_refinements({"Cell": False})
        principal = project.phases()[0]
        if stage != "final_fulltexture_none":
            suffix = stage.removeprefix("final_fulltexture_")
            axis = {"001": [0, 0, 1], "100": [1, 0, 0], "010": [0, 1, 0],
                    "110": [1, 1, 0], "111": [1, 1, 1]}[suffix]
            hap = principal.data["Histograms"][histogram.name]
            hap["Pref.Ori."][3] = axis
            principal.set_HAP_refinements({"Pref.Ori.": True})
        principal.set_refinements({"Atoms": {"all": "XU"}})
        if not project.get_Constraints("Phase"):
            variables = tuple(f"0::AUiso:{i}" for i, _ in enumerate(principal.atoms()))
            project.add_EquivConstr(variables)
    elif stage in {"final_selected_001", "final_selected_001_asym"}:
        common_flags(project, profile=True,
                     asymmetry=stage == "final_selected_001_asym", polarization=False)
        histogram = project.histogram(0)
        histogram.InstrumentParameters["Polariz."][1] = 0.50
        for phase_index, phase in enumerate(project.phases()):
            hap = phase.data["Histograms"][histogram.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][3] = [0, 0, 1]
            if phase_index == 0:
                phase.set_HAP_refinements({"Pref.Ori.": True})
            else:
                hap["Pref.Ori."][1] = 1.0
                hap["Pref.Ori."][2] = False
            if phase.name == "WO3_triclinic":
                phase.set_refinements({"Cell": False})
        principal = project.phases()[0]
        principal.set_refinements({"Atoms": {"all": "XU"}})
        if not project.get_Constraints("Phase"):
            variables = tuple(f"0::AUiso:{i}" for i, _ in enumerate(principal.atoms()))
            project.add_EquivConstr(variables)
    elif stage == "principal_coords_no_texture" or stage.startswith("principal_coords_texture_"):
        common_flags(project, profile=True, asymmetry=False, polarization=True)
        principal = project.phases()[0]
        principal.set_refinements({"Atoms": {"all": "X"}})
        histogram = project.histogram(0)
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
        if stage != "principal_coords_no_texture":
            suffix = stage.removeprefix("principal_coords_texture_")
            axis = {"001": [0, 0, 1], "100": [1, 0, 0], "010": [0, 1, 0],
                    "110": [1, 1, 0], "111": [1, 1, 1]}[suffix]
            hap = principal.data["Histograms"][histogram.name]
            hap["Pref.Ori."][3] = axis
            principal.set_HAP_refinements({"Pref.Ori.": True})
    elif stage in {"minor_size", "minor_strain_iso",
                   "principal_strain_001", "principal_strain_100", "principal_strain_010"}:
        common_flags(project, profile=True, asymmetry=False, polarization=True)
        principal_texture_110(project)
        histogram = project.histogram(0)
        target = project.phases()[1] if stage.startswith("minor_") else project.phases()[0]
        if stage == "minor_size":
            target.setSampleProfile(histogram, "size", "isotropic", 1.0, LGmix=1.0)
            target.set_HAP_refinements({
                "Size": {"type": "isotropic", "value": 1.0, "refine": True,
                         "LGmix": {"value": 1.0, "refine": False}}
            })
        elif stage == "minor_strain_iso":
            current = max(float(target.data["Histograms"][histogram.name]
                                ["Mustrain"][1][0]), 100.0)
            target.setSampleProfile(histogram, "microstrain", "isotropic", current,
                                    LGmix=0.0)
            target.set_HAP_refinements({
                "Mustrain": {"type": "isotropic", "refine": True,
                              "LGmix": {"value": 0.0, "refine": False}}
            })
        else:
            axis = {"principal_strain_001": [0, 0, 1],
                    "principal_strain_100": [1, 0, 0],
                    "principal_strain_010": [0, 1, 0]}[stage]
            target.setSampleProfile(histogram, "microstrain", "uniaxial",
                                    1000.0, 1000.0, axis=axis, LGmix=0.0)
            target.set_HAP_refinements({
                "Mustrain": {"type": "uniaxial", "refine": True,
                              "direction": axis,
                              "LGmix": {"value": 0.0, "refine": False}}
            })
    elif stage == "roughness_principal":
        common_flags(project, profile=True, asymmetry=False, polarization=True)
        principal_texture_110(project)
        histogram = project.histogram(0)
        if not 0.0 < float(histogram.SampleParameters["SurfRoughA"][0]) < 1.0:
            histogram.SampleParameters["SurfRoughA"][0] = 0.30
        if not 0.0 < float(histogram.SampleParameters["SurfRoughB"][0]) < 1.0:
            histogram.SampleParameters["SurfRoughB"][0] = 0.10
        histogram.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    elif stage.startswith("roughness_B") or stage.startswith("roughness_coords_B"):
        common_flags(project, profile=True, asymmetry=False, polarization=True)
        principal_texture_110(project)
        histogram = project.histogram(0)
        key = stage.replace("roughness_coords_", "roughness_")
        fixed_b = {
            "roughness_B002": 0.02, "roughness_B005": 0.05,
            "roughness_B010": 0.10, "roughness_B015": 0.15,
            "roughness_B020": 0.20, "roughness_B030": 0.30,
            "roughness_B050": 0.50,
        }[key]
        histogram.SampleParameters["SurfRoughB"][0] = fixed_b
        histogram.SampleParameters["SurfRoughB"][1] = False
        if not 0.0 < float(histogram.SampleParameters["SurfRoughA"][0]) < 1.0:
            histogram.SampleParameters["SurfRoughA"][0] = 0.25
        histogram.set_refinements({"Sample Parameters": ["SurfRoughA"]})
        if stage.startswith("roughness_coords_"):
            project.phases()[0].set_refinements({"Atoms": {"all": "X"}})
    elif stage.startswith("roughness_coords_fixedpolar_B"):
        common_flags(project, profile=True, asymmetry=False, polarization=False)
        principal_texture_110(project)
        histogram = project.histogram(0)
        histogram.InstrumentParameters["Polariz."][1] = 0.50
        fixed_b = {"010": 0.10, "014": 0.14, "015": 0.15,
                   "020": 0.20}[stage[-3:]]
        histogram.SampleParameters["SurfRoughB"][0] = fixed_b
        histogram.SampleParameters["SurfRoughB"][1] = False
        if not 0.0 < float(histogram.SampleParameters["SurfRoughA"][0]) < 1.0:
            histogram.SampleParameters["SurfRoughA"][0] = 0.20
        histogram.set_refinements({"Sample Parameters": ["SurfRoughA"]})
        project.phases()[0].set_refinements({"Atoms": {"all": "X"}})
    elif stage == "roughness_coords_fixedpolar_freeAB":
        common_flags(project, profile=True, asymmetry=False, polarization=False)
        principal_texture_110(project)
        histogram = project.histogram(0)
        histogram.InstrumentParameters["Polariz."][1] = 0.50
        histogram.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        project.phases()[0].set_refinements({"Atoms": {"all": "X"}})
    elif stage == "final_model_B014_uiso":
        common_flags(project, profile=True, asymmetry=False, polarization=False)
        principal_texture_110(project)
        histogram = project.histogram(0)
        histogram.InstrumentParameters["Polariz."][1] = 0.50
        histogram.SampleParameters["SurfRoughB"][0] = 0.14
        histogram.SampleParameters["SurfRoughB"][1] = False
        histogram.set_refinements({"Sample Parameters": ["SurfRoughA"]})
        principal = project.phases()[0]
        principal.set_refinements({"Atoms": {"all": "XU"}})
        if not project.get_Constraints("Phase"):
            variables = tuple(f"0::AUiso:{i}" for i, _ in enumerate(principal.atoms()))
            project.add_EquivConstr(variables)
    elif stage == "final_model_B014_fixedrough_uiso":
        common_flags(project, profile=True, asymmetry=False, polarization=False)
        principal_texture_110(project)
        histogram = project.histogram(0)
        histogram.InstrumentParameters["Polariz."][1] = 0.50
        histogram.SampleParameters["SurfRoughB"][0] = 0.14
        histogram.SampleParameters["SurfRoughB"][1] = False
        histogram.SampleParameters["SurfRoughA"][1] = False
        principal = project.phases()[0]
        principal.set_refinements({"Atoms": {"all": "XU"}})
        if not project.get_Constraints("Phase"):
            variables = tuple(f"0::AUiso:{i}" for i, _ in enumerate(principal.atoms()))
            project.add_EquivConstr(variables)
    elif stage in texture_axes:
        common_flags(project, profile=True, asymmetry=False, polarization=True)
        for phase in project.phases():
            hap = phase.data["Histograms"][project.histogram(0).name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][3] = texture_axes[stage]
            phase.set_HAP_refinements({"Pref.Ori.": True})
    elif stage in {"roughness_110", "coordinates_texture_110", "coordinates_heavy_texture_110",
                   "uiso_texture_110", "coordinates_uiso_texture_110", "zero_texture_110",
                   "uiso_fixedpolar_texture_110",
                   "strain_iso_110",
                   "strain_001_110", "strain_100_110", "strain_010_110",
                   "size_iso_110"}:
        common_flags(project, profile=True, asymmetry=False,
                     polarization=stage != "uiso_fixedpolar_texture_110",
                     atoms="X" if stage in {"coordinates_texture_110", "coordinates_uiso_texture_110"} else "",
                     adp=stage in {"uiso_texture_110", "coordinates_uiso_texture_110",
                                   "uiso_fixedpolar_texture_110"},
                     refine_shift=stage != "zero_texture_110")
        histogram = project.histogram(0)
        if stage == "zero_texture_110":
            histogram.SampleParameters["Shift"][0] = 0.0
            histogram.InstrumentParameters["Zero"][1] = 0.0
            histogram.set_refinements({"Instrument Parameters": ["Zero"]})
        if stage == "roughness_110":
            histogram.SampleParameters["SurfRoughA"][0] = 0.30
            histogram.SampleParameters["SurfRoughB"][0] = 0.10
            histogram.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        for phase in project.phases():
            hap = phase.data["Histograms"][histogram.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][3] = [1, 1, 0]
            phase.set_HAP_refinements({"Pref.Ori.": True})
            if stage == "coordinates_heavy_texture_110":
                flags = {atom.label: ("X" if atom.element in {"Mn", "W"} else " ")
                         for atom in phase.atoms()}
                phase.set_refinements({"Atoms": flags})
            if stage == "strain_iso_110":
                phase.setSampleProfile(histogram, "microstrain", "isotropic", 1000.0,
                                       LGmix=1.0)
                phase.set_HAP_refinements({
                    "Mustrain": {"type": "isotropic", "refine": True,
                                  "LGmix": {"value": 1.0, "refine": False}}
                })
            elif stage.startswith("strain_"):
                axis = {"strain_001_110": [0, 0, 1],
                        "strain_100_110": [1, 0, 0],
                        "strain_010_110": [0, 1, 0]}[stage]
                start = max(float(hap["Mustrain"][1][0]), 100.0)
                phase.setSampleProfile(histogram, "microstrain", "uniaxial",
                                       start, start, axis=axis, LGmix=1.0)
                phase.set_HAP_refinements({
                    "Mustrain": {"type": "uniaxial", "refine": True,
                                  "direction": axis,
                                  "LGmix": {"value": 1.0, "refine": False}}
                })
            elif stage == "size_iso_110":
                phase.setSampleProfile(histogram, "size", "isotropic", 1.0, LGmix=1.0)
                phase.set_HAP_refinements({
                    "Size": {"type": "isotropic", "value": 1.0, "refine": True,
                             "LGmix": {"value": 1.0, "refine": False}}
                })
        if stage in {"uiso_texture_110", "coordinates_uiso_texture_110",
                     "uiso_fixedpolar_texture_110"}:
            # The registered/generating convention uses one isotropic U per phase.
            # Add the equivalence only when the input project has no constraint yet.
            phase_constraints = project.get_Constraints("Phase")
            if not phase_constraints:
                for phase_index, phase in enumerate(project.phases()):
                    variables = tuple(f"{phase_index}::AUiso:{i}" for i, _ in enumerate(phase.atoms()))
                    project.add_EquivConstr(variables)
    elif stage == "calculate":
        pass
    else:
        raise ValueError(f"Unknown stage {stage}")
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine()
    project.save(str(output_path))
    print_summary(project, stage)


def rwp(histogram) -> float:
    y = np.asarray(histogram.getdata("Yobs"), float)
    yc = np.asarray(histogram.getdata("Ycalc"), float)
    w = np.asarray(histogram.getdata("Yweight"), float)
    return float(100.0 * np.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y ** 2)))


def phase_fraction(project: G2.G2Project, phase, histogram) -> float:
    # GSAS-II powder mass fraction is HAP scale times unit-cell mass.
    hap_scale = float(phase.data["Histograms"][histogram.name]["Scale"][0])
    return hap_scale * float(phase.data["General"]["Mass"])


def summary(project: G2.G2Project) -> dict:
    histogram = project.histogram(0)
    inst = histogram.InstrumentParameters
    sample = histogram.SampleParameters
    raw = [phase_fraction(project, p, histogram) for p in project.phases()]
    total = sum(raw)
    phases = []
    for p, value in zip(project.phases(), raw):
        hap = p.data["Histograms"][histogram.name]
        phases.append({
            "name": p.name,
            "weight_fraction": value / total if total > 0 else None,
            "scale": float(hap["Scale"][0]),
            "cell": [float(v) for v in p.data["General"]["Cell"][1:8]],
            "size": hap["Size"],
            "microstrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": [{"label": a.label, "element": a.element,
                       "coordinates": list(a.coordinates), "uiso": a.uiso,
                       "refine": a.refinement_flags} for a in p.atoms()],
        })
    values = {k: float(v[1]) for k, v in inst.items()
              if isinstance(v, list) and len(v) > 1 and isinstance(v[1], (int, float, np.number))}
    result = {
        "gpx": project.filename,
        "gsas_ii_revision": GSASIIpath.GetVersionNumber(),
        "histogram": histogram.name,
        "rwp_percent_recomputed": rwp(histogram),
        "instrument": values,
        "sample": {k: (float(v[0]) if isinstance(v, list) else v)
                   for k, v in sample.items()
                   if k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type"]},
        "background": histogram.Background,
        "phases": phases,
        "vary_list": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
        "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }
    return result


def print_summary(project: G2.G2Project, label: str) -> None:
    result = summary(project)
    print(f"\n--- {label} ---")
    print(json.dumps(result, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)))


def inspect(path: Path) -> None:
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(path))
    print_summary(project, "inspection")


def compact(path: Path) -> None:
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(path))
    data = summary(project)
    print(json.dumps({
        "gpx": str(path),
        "rwp_percent": data["rwp_percent_recomputed"],
        "converged": data["Rvals"].get("converged"),
        "SVD0": data["Rvals"].get("SVD0"),
        "phases": [{"name": p["name"], "weight_fraction": p["weight_fraction"],
                    "scale": p["scale"], "cell": p["cell"][:6]}
                   for p in data["phases"]],
    }, indent=2))


def export_curve(path: Path, output: Path) -> None:
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(path))
    histogram = project.histogram(0)
    columns = np.column_stack([
        histogram.getdata("X"), histogram.getdata("Yobs"),
        histogram.getdata("Ycalc"), histogram.getdata("Background"),
        histogram.getdata("Residual"),
    ])
    np.savetxt(output, columns, delimiter=",",
               header="two_theta,observed,calculated,background,difference", comments="")
    output.with_suffix(".json").write_text(json.dumps(summary(project), indent=2,
        default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)) + "\n")
    print(output)


def add_phase_test(input_path: Path, output_path: Path, model_name: str,
                   start_fraction: float, cycles: int,
                   final_restrained_model: bool = False) -> None:
    """Re-challenge one watch-list phase under the accepted common profile."""
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(input_path), newgpx=str(output_path))
    histogram = project.histogram(0)
    existing = project.phases()
    if any(p.name == model_name for p in existing):
        raise ValueError(f"Phase {model_name} already present")
    phase = project.add_phase(str(WORK / "models" / f"{model_name}.cif"),
                              phasename=model_name, fmthint="CIF",
                              histograms=[histogram])
    total_mass_scale = sum(float(p.data["Histograms"][histogram.name]["Scale"][0]) *
                           float(p.data["General"]["Mass"]) for p in existing)
    phase.data["Histograms"][histogram.name]["Scale"][0] = (
        start_fraction / max(1.0 - start_fraction, 1e-6) * total_mass_scale /
        float(phase.data["General"]["Mass"])
    )
    phase.setSampleProfile(histogram, "size", "isotropic", 10.0, LGmix=1.0)
    phase.setSampleProfile(histogram, "microstrain", "isotropic", 0.0, LGmix=0.0)
    hap = phase.data["Histograms"][histogram.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    freeze_all(project)
    common_flags(project, profile=True, asymmetry=False,
                 polarization=not final_restrained_model)
    if final_restrained_model:
        histogram.InstrumentParameters["Polariz."][1] = 0.50
        for existing_phase in project.phases():
            if existing_phase.name == "WO3_triclinic":
                existing_phase.set_refinements({"Cell": False})
    # Scale is challenged before the candidate cell. A weak/absent phase must
    # not improve the fit by collapsing or expanding its lattice out of range.
    phase.set_refinements({"Cell": False})
    # Retain/reconverge the established texture only on the principal phase.
    principal_texture_110(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine()
    project.save(str(output_path))
    print_summary(project, f"watch-list {model_name}")


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("prepare")
    p = sub.add_parser("init")
    p.add_argument("output", type=Path)
    p.add_argument("models", nargs="+", choices=sorted(CANDIDATES))
    p = sub.add_parser("stage")
    p.add_argument("input", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("stage", choices=["calculate", "common", "profile", "asymmetry",
                                     "asymmetry_fixed_shift", "polarization",
                                     "polarization_no_asym", "polarization_fixed_shift", "coordinates",
                                     "coordinates_no_asym",
                                     "coordinates_fixed_shift", "coordinates_adp",
                                     "texture_001", "texture_100", "texture_010",
                                     "texture_110", "texture_111", "roughness_110",
                                     "coordinates_texture_110", "coordinates_heavy_texture_110",
                                     "uiso_texture_110", "coordinates_uiso_texture_110",
                                     "uiso_fixedpolar_texture_110",
                                     "inventory_common", "principal_heavy",
                                     "final_inventory_common",
                                     "final_weak_last_common",
                                     "final_weak_last_A_coords",
                                     "final_weak_last_fixedrough_coordsU",
                                     "final_texture_none", "final_texture_001",
                                     "final_texture_100", "final_texture_010",
                                     "final_texture_110", "final_texture_111",
                                     "final_fulltexture_none", "final_fulltexture_001",
                                     "final_fulltexture_100", "final_fulltexture_010",
                                     "final_fulltexture_110", "final_fulltexture_111",
                                     "final_selected_001",
                                     "final_selected_001_asym",
                                     "principal_all_coords",
                                     "principal_coords_uiso_fixedpolar",
                                     "principal_coords_no_texture",
                                     "principal_coords_texture_001",
                                     "principal_coords_texture_100",
                                     "principal_coords_texture_010",
                                     "principal_coords_texture_110",
                                     "principal_coords_texture_111",
                                     "minor_size", "minor_strain_iso",
                                     "principal_strain_001", "principal_strain_100",
                                     "principal_strain_010",
                                     "roughness_principal",
                                     "roughness_B002", "roughness_B005",
                                     "roughness_B010", "roughness_B015",
                                     "roughness_B020", "roughness_B030",
                                     "roughness_B050",
                                     "roughness_coords_B010",
                                     "roughness_coords_B015",
                                     "roughness_coords_B020",
                                     "roughness_coords_fixedpolar_B010",
                                     "roughness_coords_fixedpolar_B014",
                                     "roughness_coords_fixedpolar_B015",
                                     "roughness_coords_fixedpolar_B020",
                                     "roughness_coords_fixedpolar_freeAB",
                                     "final_model_B014_uiso",
                                     "final_model_B014_fixedrough_uiso",
                                     "zero_texture_110", "strain_iso_110",
                                     "strain_001_110", "strain_100_110", "strain_010_110",
                                     "size_iso_110"])
    p.add_argument("--cycles", type=int, default=12)
    p = sub.add_parser("inspect")
    p.add_argument("project", type=Path)
    p = sub.add_parser("compact")
    p.add_argument("project", type=Path)
    p = sub.add_parser("export-curve")
    p.add_argument("project", type=Path)
    p.add_argument("output", type=Path)
    p = sub.add_parser("add-phase-test")
    p.add_argument("input", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("model", choices=sorted(CANDIDATES))
    p.add_argument("--start-fraction", type=float, default=0.02)
    p.add_argument("--cycles", type=int, default=50)
    p = sub.add_parser("add-phase-final")
    p.add_argument("input", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("model", choices=sorted(CANDIDATES))
    p.add_argument("--start-fraction", type=float, default=0.005)
    p.add_argument("--cycles", type=int, default=50)
    args = parser.parse_args()
    if args.command == "prepare":
        prepare()
    elif args.command == "init":
        init_project(args.output.resolve(), args.models)
    elif args.command == "stage":
        run_stage(args.input.resolve(), args.output.resolve(), args.stage, args.cycles)
    elif args.command == "inspect":
        inspect(args.project.resolve())
    elif args.command == "compact":
        compact(args.project.resolve())
    elif args.command == "export-curve":
        export_curve(args.project.resolve(), args.output.resolve())
    elif args.command == "add-phase-test":
        add_phase_test(args.input.resolve(), args.output.resolve(), args.model,
                       args.start_fraction, args.cycles)
    elif args.command == "add-phase-final":
        add_phase_test(args.input.resolve(), args.output.resolve(), args.model,
                       args.start_fraction, args.cycles, final_restrained_model=True)


if __name__ == "__main__":
    main()
