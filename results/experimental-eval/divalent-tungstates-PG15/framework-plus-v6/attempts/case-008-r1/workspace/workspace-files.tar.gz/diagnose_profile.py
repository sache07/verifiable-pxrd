#!/usr/bin/env python3
"""Profile diagnostics for a GSAS-II observed/calculated export."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.signal import find_peaks, peak_widths


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("curve", type=Path)
    parser.add_argument("--plot", type=Path)
    args = parser.parse_args()
    d = np.genfromtxt(args.curve, delimiter=",", names=True)
    x = d["two_theta"]
    obs = d["observed"]
    calc = d["calculated"]
    bg = d["background"]
    diff = obs - calc
    z = diff / np.sqrt(np.maximum(obs, 1.0))
    weights = 1 / np.maximum(obs, 1.0)
    denom = np.sum(weights * obs**2)

    print("range_start range_end n mean_z rms_z rwp_contribution_percent mean_diff")
    edges = np.arange(10, 101, 5)
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (x >= lo) & (x < hi)
        num = np.sum(weights[m] * diff[m] ** 2)
        print(f"{lo:5.1f} {hi:5.1f} {m.sum():5d} {np.mean(z[m]):9.4f} "
              f"{np.sqrt(np.mean(z[m]**2)):9.4f} {100*np.sqrt(num/denom):9.4f} "
              f"{np.mean(diff[m]):10.3f}")

    smooth = gaussian_filter1d(diff, 2.0)
    # Remove only a very slow residual baseline before finding coherent omitted peaks.
    slow = percentile_filter(smooth, percentile=45, size=401, mode="nearest")
    residual_peaks, props = find_peaks(smooth - slow, prominence=40, distance=6, width=2)
    widths = peak_widths(smooth - slow, residual_peaks, rel_height=0.5)[0] * np.median(np.diff(x))
    order = np.argsort(props["prominences"])[::-1]
    print("\npositive residual features")
    print("rank two_theta residual prominence fwhm observed calculated")
    for rank, j in enumerate(order[:80], 1):
        i = residual_peaks[j]
        print(f"{rank:3d} {x[i]:10.5f} {diff[i]:10.2f} {props['prominences'][j]:10.2f} "
              f"{widths[j]:8.4f} {obs[i]:10.2f} {calc[i]:10.2f}")

    if args.plot:
        fig, axes = plt.subplots(3, 1, figsize=(14, 10), sharex=True,
                                 gridspec_kw={"height_ratios": [2.2, 1, 1]})
        axes[0].plot(x, obs, color="black", lw=0.6, label="observed")
        axes[0].plot(x, calc, color="tab:red", lw=0.7, label="calculated")
        axes[0].plot(x, bg, color="tab:green", lw=0.7, label="background")
        axes[0].legend(loc="upper right")
        axes[0].set_ylabel("counts")
        axes[1].plot(x, diff, color="tab:blue", lw=0.55)
        axes[1].axhline(0, color="black", lw=0.5)
        axes[1].set_ylabel("obs - calc")
        axes[2].plot(x, z, color="tab:purple", lw=0.5)
        axes[2].axhline(0, color="black", lw=0.5)
        axes[2].set_ylabel("weighted residual")
        axes[2].set_xlabel(r"2$\theta$ (deg)")
        fig.tight_layout()
        fig.savefig(args.plot, dpi=170)
        print(f"\nplot {args.plot}")


if __name__ == "__main__":
    main()
