#!/usr/bin/env python3
"""Replace the weak 1960 monoclinic WO3 coordinates by a physical neutron model.

This is a controlled alternate-source challenge: all accepted nuisance terms,
the other two phases and their starting values come from the selected model.
"""

from __future__ import annotations

import copy
import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_refine import WORK, freeze_all, common_flags, print_summary


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["neutron", "hybrid"], default="neutron")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    loader_path = ROOT / ".tmp" / "neutron_model_loader.gpx"
    loader = G2.G2Project(newgpx=str(loader_path))
    neutron = loader.add_phase(
        str(WORK / "models" / "WO3_monoclinic_neutron.cif"),
        phasename="WO3_monoclinic_neutron", fmthint="CIF",
    )

    output = ROOT / ".tmp" / f"physical_alt_{args.mode}.gpx"
    project = G2.G2Project(
        gpxfile=str(ROOT / "refinement_work" / "final_selected_001.gpx"),
        newgpx=str(output),
    )
    target = project.phase("WO3_monoclinic")
    preserved = {
        "Histograms": copy.deepcopy(target.data["Histograms"]),
        "pId": target.data["pId"],
        "ranId": target.data["ranId"],
    }
    if args.mode == "neutron":
        target.data["General"] = copy.deepcopy(neutron.data["General"])
        target.data["General"]["Name"] = "WO3_monoclinic_neutron"
        target.data["Atoms"] = copy.deepcopy(neutron.data["Atoms"])
        target.data["Drawing"] = copy.deepcopy(neutron.data["Drawing"])
        target.data["Pawley ref"] = []
        target.data["RBModels"] = copy.deepcopy(neutron.data["RBModels"])
    else:
        # Both records describe the same P21/c polymorph in the same registered
        # setting. Retain the X-ray-sensitive 1960 W sublattice while replacing
        # its low-precision O sites by the 1966 neutron coordinates.
        old_w = [copy.deepcopy(a) for a in target.data["Atoms"]
                 if str(a[target.data["General"]["AtomPtrs"][1]]).startswith("W")]
        neutron_o = [copy.deepcopy(a) for a in neutron.data["Atoms"]
                     if str(a[neutron.data["General"]["AtomPtrs"][1]]).startswith("O")]
        target.data["Atoms"] = old_w + neutron_o
        target.data["General"]["Name"] = "WO3_monoclinic_hybrid"
        target.data["Drawing"] = {}
    target.data.update(preserved)

    freeze_all(project)
    common_flags(project, profile=True, asymmetry=False, polarization=False)
    histogram = project.histogram(0)
    histogram.InstrumentParameters["Polariz."][1] = 0.50
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][3] = [0, 0, 1]
        if index == 0:
            phase.set_HAP_refinements({"Pref.Ori.": True})
            phase.set_refinements({"Atoms": {"all": "XU"}})
        else:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
        if phase.name == "WO3_triclinic":
            phase.set_refinements({"Cell": False})
    project.set_Controls("cycles", 80)
    project.save()
    project.refine()
    project.save(str(output))
    print_summary(project, f"physical {args.mode} alternate")


if __name__ == "__main__":
    main()
