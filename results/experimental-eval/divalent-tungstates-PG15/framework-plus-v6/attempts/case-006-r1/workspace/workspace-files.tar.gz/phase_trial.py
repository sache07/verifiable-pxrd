#!/usr/bin/env python3
"""Challenge a refined inventory with one physically screened candidate phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def summary(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    terms = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        terms.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
    total = sum(max(0.0, value) for value in terms)
    phases = []
    for phase, term in zip(project.phases(), terms):
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "formula": phase.data["General"].get("Name", phase.name),
                "scale": hap["Scale"],
                "cell_mass": phase.data["General"]["Mass"],
                "weight_fraction": max(0.0, term) / total if total else None,
                "cell": phase.get_cell(),
            }
        )
    return {
        "stage": stage,
        "wR_percent": hist.get_wR(),
        "phases": phases,
        "vary_list": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("name")
    parser.add_argument("--cell", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    project.set_Controls("cycles", 16)
    hist = project.histogram(0)
    phase = project.add_phase(
        str(args.candidate), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][1][1] = 10.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    for atom in phase.atoms():
        atom.refinement_flags = " "
        if atom.adp_flag == "I":
            atom.uiso = 0.008

    pid, hid = phase.id, hist.id
    project.save()
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Scale")
    project.set_Controls("parmMax", 1000.0, variable=f"{pid}:{hid}:Scale")
    project.refine()
    reports = [summary(project, "scale")]
    candidate_fraction = reports[-1]["phases"][-1]["weight_fraction"] or 0.0
    if args.cell and candidate_fraction > 0.0001:
        phase.set_refinements({"Cell": True})
        project.refine()
        reports.append(summary(project, "cell"))
    project.save()
    print(json.dumps(reports, indent=2, default=float))


if __name__ == "__main__":
    main()
