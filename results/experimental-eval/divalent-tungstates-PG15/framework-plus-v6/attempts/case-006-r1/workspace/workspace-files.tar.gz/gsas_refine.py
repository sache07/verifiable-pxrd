#!/usr/bin/env python3
"""Build and refine the provisional single-phase GSAS-II model."""

from __future__ import annotations

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def snapshot(project: G2.G2Project, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, ROOT / f"stage_{label}.gpx")
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    hap = phase.data["Histograms"][hist.name]
    values = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "residuals": hist.residuals,
        "cell": phase.get_cell(),
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
            if key in inst
        },
        "sample": {
            key: hist.SampleParameters[key][0]
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if key in hist.SampleParameters
        },
        "scale": hap["Scale"][0],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "background": hist.data["Background"][0],
        "vary_list": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
        "max_shift_over_esd": project.data.get("Covariance", {}).get("data", {}).get("Max shft/sig", None),
    }
    print(json.dumps(values, indent=2, default=float))


def refine(project: G2.G2Project, label: str) -> None:
    project.refine()
    snapshot(project, label)


def build() -> G2.G2Project:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(ROOT / "working.gpx"))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        fmthint="xye",
    )
    phase = project.add_phase(
        str(ROOT / "candidate_cuwo4.cif"),
        phasename="CuWO4_P-1",
        histograms=[hist],
        fmthint="CIF",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"][1] = False
    for key, value in {
        "Shift": 0.0,
        "Transparency": 0.0,
        "SurfRoughA": 0.0,
        "SurfRoughB": 0.0,
    }.items():
        hist.SampleParameters[key][0] = value

    hist.set_refinements(
        {
            "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [1200.0, -300.0, 150.0, -50.0, 20.0, 0.0],
                "refine": False,
            },
        }
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 100.0
    hap["Size"][1][1] = 100.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    project.set_Controls("cycles", 12)
    project.save()
    for variable, lower, upper in (
        (":0:Zero", -1.0, 1.0),
        (":0:U", 0.0, 100.0),
        (":0:W", 0.001, 100.0),
        (":0:X", 0.0, 20.0),
        (":0:SH/L", 0.001, 0.2),
        (":0:Polariz.", 0.3, 1.0),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    snapshot(project, "initial")
    return project


def main() -> None:
    project = build()
    hist = project.histogram(0)
    phase = project.phase(0)

    hist.set_refinements({"Background": {"refine": True}})
    phase.set_HAP_refinements({"Scale": True})
    refine(project, "bg_scale")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "zero")

    phase.set_refinements({"Cell": True})
    refine(project, "cell")

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(project, "profile_wx")

    hist.set_refinements({"Instrument Parameters": ["U"]})
    refine(project, "profile_uwx")


if __name__ == "__main__":
    main()
