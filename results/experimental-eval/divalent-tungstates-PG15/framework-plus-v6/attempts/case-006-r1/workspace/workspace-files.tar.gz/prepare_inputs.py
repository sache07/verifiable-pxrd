#!/usr/bin/env python3
"""Prepare a chemically adapted CuWO4 model and GSAS-II input files."""

from pathlib import Path
import warnings

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/10/16/2101690.cif"
)
CU2WO4_SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/00/24/2002403.cif"
)


def main() -> None:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = Structure.from_file(SOURCE, primitive=False)
    structure.remove_oxidation_states()
    for index, site in enumerate(structure):
        if site.specie.symbol == "Zn":
            structure.replace(index, "Cu")
    if structure.composition.reduced_formula != "CuWO4":
        raise RuntimeError(f"Unexpected adapted composition: {structure.composition}")
    CifWriter(structure, symprec=1e-3, significant_figures=10).write_file(
        ROOT / "candidate_cuwo4.cif"
    )

    # Re-serialize the physically screened COD Cu2WO4 record so GSAS-II can
    # read its unusual P1 symmetry loop during a watch-list scale challenge.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        cu2wo4 = Structure.from_file(CU2WO4_SOURCE, primitive=False)
    cu2wo4.remove_oxidation_states()
    CifWriter(cu2wo4, symprec=1e-3, significant_figures=10).write_file(
        ROOT / "candidate_cu2wo4_watch.cif"
    )

    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(
        ROOT / "pattern.xye",
        np.column_stack((x, y, sigma)),
        fmt=["%.8f", "%.8f", "%.8f"],
        header="2theta intensity sigma",
    )

    (ROOT / "instrument.instprm").write_text(
        "#GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:8.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


if __name__ == "__main__":
    main()
