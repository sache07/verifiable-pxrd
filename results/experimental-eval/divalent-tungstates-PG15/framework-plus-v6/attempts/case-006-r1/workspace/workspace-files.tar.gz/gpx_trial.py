#!/usr/bin/env python3
"""Apply one reversible GSAS-II trial to a saved refinement project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def set_bound(project: G2.G2Project, variable: str, lower: float, upper: float) -> None:
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def report(project: G2.G2Project, mode: str) -> None:
    hist = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    print(
        json.dumps(
            {
                "mode": mode,
                "output": project.filename,
                "wR_percent": hist.get_wR(),
                "residuals": hist.residuals,
                "cell": phase.get_cell(),
                "instrument": {
                    key: hist.InstrumentParameters[key][1:]
                    for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
                    if key in hist.InstrumentParameters
                },
                "sample": {
                    key: hist.SampleParameters[key]
                    for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
                    if key in hist.SampleParameters
                },
                "hap_scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": list(atom.coordinates),
                        "uiso": atom.uiso,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
                "vary_list": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
                "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).keys()],
            },
            indent=2,
            default=float,
        )
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "mode",
        choices=[
            "reconverge",
            "u_zero",
            "shl",
            "roughness",
            "roughness_b0",
            "roughness_b005",
            "roughness_b01",
            "roughness_b02",
            "roughness_b03",
            "polarization",
            "size",
            "strain",
            "size_strain",
            "atoms",
            "uiso",
            "uiso_003",
            "uiso_005",
            "uiso_008",
            "uiso_012",
            "uiso_016",
            "uiso_020",
            "texture_100",
            "texture_010",
            "texture_001",
            "texture_110",
            "texture_111",
            "second_size",
            "second_strain",
            "second_strain_100",
            "second_strain_010",
            "second_strain_001",
            "second_watoms",
            "second_atoms",
            "neutral_sizes",
        ],
    )
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    project.set_Controls("cycles", 16)
    hist = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]

    if args.mode == "neutral_sizes":
        for candidate in project.phases():
            candidate_hap = candidate.data["Histograms"][hist.name]
            candidate_hap["Size"][0] = "isotropic"
            candidate_hap["Size"][1][0] = 100.0
            candidate_hap["Size"][1][1] = 100.0
            candidate_hap["Size"][2] = [False, False, False]
    elif args.mode == "u_zero":
        hist.InstrumentParameters["U"][1] = 0.0
        hist.InstrumentParameters["U"][2] = False
    elif args.mode == "shl":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        set_bound(project, ":0:SH/L", 0.001, 0.2)
    elif args.mode == "roughness":
        hist.SampleParameters["SurfRoughA"][0] = 0.3
        hist.SampleParameters["SurfRoughB"][0] = 0.1
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        set_bound(project, ":0:SurfRoughA", 0.001, 0.999)
        set_bound(project, ":0:SurfRoughB", 0.001, 2.0)
    elif args.mode.startswith("roughness_b"):
        fixed_a = {
            "roughness_b0": 0.0,
            "roughness_b005": 0.05,
            "roughness_b01": 0.1,
            "roughness_b02": 0.2,
            "roughness_b03": 0.3,
        }[args.mode]
        hist.SampleParameters["SurfRoughA"] = [fixed_a, False]
        hist.SampleParameters["SurfRoughB"] = [0.1, True]
        set_bound(project, ":0:SurfRoughB", 0.001, 2.0)
    elif args.mode == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        set_bound(project, ":0:Polariz.", 0.3, 1.0)
    elif args.mode in ("size", "size_strain"):
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True}})
        set_bound(project, "0:0:Size;i", 0.01, 10.0)
    if args.mode in ("strain", "size_strain"):
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        set_bound(project, "0:0:Mustrain;i", 0.0, 20000.0)
    elif args.mode == "atoms":
        for atom in phase.atoms():
            atom.refinement_flags = " " if atom.element == "W" else "X"
    elif args.mode == "uiso":
        for atom in phase.atoms():
            atom.uiso = 0.01
            atom.refinement_flags = "U"
    elif args.mode.startswith("uiso_"):
        value = float(args.mode.split("_")[1]) / 1000.0
        for atom in phase.atoms():
            atom.uiso = value
    elif args.mode.startswith("texture_"):
        axes = {
            "texture_100": [1, 0, 0],
            "texture_010": [0, 1, 0],
            "texture_001": [0, 0, 1],
            "texture_110": [1, 1, 0],
            "texture_111": [1, 1, 1],
        }
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = axes[args.mode]
        phase.set_HAP_refinements({"Pref.Ori.": True})
        set_bound(project, "0:0:MD", 0.5, 2.0)
    elif args.mode in (
        "second_size",
        "second_strain",
        "second_strain_100",
        "second_strain_010",
        "second_strain_001",
        "second_watoms",
        "second_atoms",
    ):
        second = project.phase(1)
        second_hap = second.data["Histograms"][hist.name]
        if args.mode == "second_size":
            second_hap["Size"][0] = "isotropic"
            second_hap["Size"][1][0] = 1.0
            second.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
            )
            set_bound(project, "1:0:Size;i", 0.01, 10.0)
        elif args.mode == "second_strain":
            second_hap["Mustrain"][0] = "isotropic"
            second_hap["Mustrain"][1][0] = 1000.0
            second.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
            set_bound(project, "1:0:Mustrain;i", 0.0, 20000.0)
        elif args.mode.startswith("second_strain_"):
            axis = {
                "second_strain_100": [1, 0, 0],
                "second_strain_010": [0, 1, 0],
                "second_strain_001": [0, 0, 1],
            }[args.mode]
            value = float(second_hap["Mustrain"][1][0])
            second_hap["Mustrain"][0] = "uniaxial"
            second_hap["Mustrain"][1][0] = value
            second_hap["Mustrain"][1][1] = value
            second_hap["Mustrain"][2][0] = True
            second_hap["Mustrain"][2][1] = True
            second_hap["Mustrain"][3] = axis
            set_bound(project, "1:0:Mustrain;i", 0.0, 20000.0)
            set_bound(project, "1:0:Mustrain;a", 0.0, 20000.0)
        else:
            for atom in second.atoms():
                atom.refinement_flags = "X" if (
                    args.mode == "second_atoms" or atom.element == "W"
                ) else " "

    project.save()
    project.refine()
    project.save()
    report(project, args.mode)


if __name__ == "__main__":
    main()
