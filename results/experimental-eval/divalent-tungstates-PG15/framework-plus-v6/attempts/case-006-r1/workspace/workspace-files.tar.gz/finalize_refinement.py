#!/usr/bin/env python3
"""Freeze the accepted model, reconverge it, and export exact final artifacts."""

from __future__ import annotations

import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "two_phase_aniso_conv2.gpx"
FINAL = ROOT / "final.gpx"


def project_summary(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "weight_fraction": fractions[phase.name],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": list(atom.coordinates),
                        "uiso": atom.uiso,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    return {
        "histogram": hist.name,
        "residuals": hist.residuals,
        "sample": {
            key: hist.SampleParameters[key]
            for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "instrument": {
            key: hist.InstrumentParameters[key]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
        },
        "background": hist.data["Background"],
        "limits": hist.data["Limits"],
        "phases": phases,
        "max_shift_over_esd": project.data.get("Covariance", {})
        .get("data", {})
        .get("Rvals", {})
        .get("Max shft/sig"),
        "vary_list": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    project.set_Controls("cycles", 50)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histogram(0)

    # Roughness B was supported but nearly collinear with scale. Preserve its
    # converged value and remove that unstable covariance from the final pass.
    hist.SampleParameters["SurfRoughB"][1] = False
    project.save()
    project.refine()
    project.save()

    # Reopen and replay the complete range so that all saved profile arrays and
    # the covariance correspond to a clean, reproducible final pass. Repeat if
    # the small least-squares shifts need another saved-project restart.
    for _ in range(4):
        project = G2.G2Project(gpxfile=str(FINAL))
        project.set_Controls("cycles", 50)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
        project.refine()
        project.save()
        shift = (
            project.data.get("Covariance", {})
            .get("data", {})
            .get("Rvals", {})
            .get("Max shft/sig", float("inf"))
        )
        if shift < 0.1:
            break

    # Export values without uncertainty-driven decimal truncation. The saved
    # covariance is restored in memory and the GPX itself is not rewritten.
    covariance = copy.deepcopy(project.data["Covariance"]["data"])
    project.data["Covariance"]["data"] = {}
    project.phase(0).export_CIF(str(ROOT / "phase_cuwo4.cif"))
    project.phase(1).export_CIF(str(ROOT / "phase_wo3.cif"))
    project.data["Covariance"]["data"] = covariance

    hist = project.histogram(0)
    profile = np.asarray(hist.data["data"][1], dtype=float)
    x, observed, calculated = profile[0], profile[1], profile[3]
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, observed - calculated)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
    )
    print(json.dumps(project_summary(project), indent=2, default=float))


if __name__ == "__main__":
    main()
