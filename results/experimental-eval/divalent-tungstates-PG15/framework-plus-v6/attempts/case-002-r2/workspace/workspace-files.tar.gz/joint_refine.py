#!/usr/bin/env python3
"""Jointly reconverge only the accepted four-phase model terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument("--repeats", type=int, default=6)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.base, newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Polariz.", "SH/L", "U", "W", "X"]})
    hist.set_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    hist.set_refinements({"Background": True})
    phases = project.phases()
    for index, phase in enumerate(phases):
        phase.set_refinements({"Cell": index < 2})
        phase.set_HAP_refinements({"Scale": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
    # Accepted WO3 texture; no texture on other phases.
    po = phases[0].data["Histograms"][hist.name]["Pref.Ori."]
    po[:4] = ["MD", po[1], True, [0, 1, 0]]
    # The specimen generator uses one tied Uiso per phase. Existing equivalence
    # constraints are retained; only the two major phases have enough signal.
    for phase in phases[:2]:
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    project.save()
    limits = [
        (":0:Shift", -800.0, 800.0),
        (":0:SurfRoughA", 0.05, 0.6),
        (":0:SurfRoughB", 0.0, 0.5),
        ("0:0:MD", 0.7, 1.4),
        ("0::AUiso:0", 0.003, 0.02),
        ("1::AUiso:0", 0.003, 0.02),
    ]
    for index in range(len(phases)):
        limits.append((f"{index}:0:Scale", 0.0, 1.0e6))
    for variable, low, high in limits:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    rows = []
    for iteration in range(args.repeats):
        project.set_Controls("cycles", 10)
        project.refine()
        project.save()
        rows.append(snapshot(project, f"iteration_{iteration + 1}"))
        print(iteration + 1, "Rwp", rows[-1]["rwp"], "fractions", rows[-1].get("mass_fractions"))
    out.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
