#!/usr/bin/env python3
"""Joint bounded profile challenge for the two major phases."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument("--repeats", type=int, default=8)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.base, newgpx=str(out))
    hist = project.histogram(0)
    hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Pref.Ori.": True, "Size": True, "Mustrain": True})
    project.set_Frozen()
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    p0, p1 = project.phases()[:2]
    p0.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "uniaxial", "direction": [0, 1, 0], "refine": True},
    })
    p1.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    project.save()
    limits = [
        (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0), (":0:X", 0.1, 6.0),
        ("0:0:Size;i", 0.04, 1.5), ("1:0:Size;i", 0.04, 1.5),
        ("0:0:Mustrain;i", 0.0, 8000.0), ("0:0:Mustrain;a", 0.0, 32000.0),
        ("1:0:Mustrain;i", 0.0, 8000.0),
    ]
    for variable, low, high in limits:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    rows = []
    for iteration in range(args.repeats):
        project.set_Controls("cycles", 10)
        project.refine()
        project.save()
        rows.append(snapshot(project, f"iteration_{iteration + 1}"))
        print(iteration + 1, "Rwp", rows[-1]["rwp"])
    out.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
