#!/usr/bin/env python3
"""Print a compact JSON summary of a GSAS-II project."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=args.gpx)
    row = snapshot(project, "inspect")
    row["phases"] = [
        {
            **summary,
            "uiso": [atom.uiso for atom in phase.atoms()],
            "atom_flags": [atom.refinement_flags for atom in phase.atoms()],
        }
        for phase, summary in zip(project.phases(), row["phases"])
    ]
    frozen = project.data.get("Controls", {}).get("data", {}).get("parmFrozen")
    row["frozen"] = None if frozen is None else {
        key: [str(value) for value in values] for key, values in frozen.items()
    }
    print(json.dumps(row, indent=2, default=float))


if __name__ == "__main__":
    main()
