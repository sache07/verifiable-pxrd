#!/usr/bin/env python3
"""Freeze, recalculate, and export the accepted GSAS-II submission model."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from five_phase_refine import clean


BASE = Path("five_phase/final_model.gpx")
FINAL = Path("final.gpx")
EXPORTS = [
    ("triclinic WO3", "phase_triclinic_WO3.cif", "2106293"),
    ("tetragonal BaO2", "phase_BaO2.cif", "1010113"),
    ("tetragonal BaWO4", "phase_BaWO4.cif", "1527204"),
    ("cubic BaO", "phase_BaO.cif", "1011362"),
    ("monoclinic WO3", "phase_monoclinic_WO3.cif", "2311041"),
]


def strip_constraints(project: G2.G2Project) -> None:
    node = project.data.get("Constraints", {})
    data = node.get("data", node) if isinstance(node, dict) else {}
    if isinstance(data, dict):
        for key in ("Phase", "HAP", "Hist", "Global"):
            if key in data:
                data[key] = []


def freeze(project: G2.G2Project) -> None:
    project.set_Frozen()
    clean(project)
    strip_constraints(project)
    project.set_Controls("cycles", 0)


def recalculate(project: G2.G2Project) -> None:
    freeze(project)
    project.save()
    project.refine()
    freeze(project)
    project.save()


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(FINAL))
    recalculate(project)

    # Reopen and replay once more from the on-disk project before exporting.
    project = G2.G2Project(gpxfile=str(FINAL))
    recalculate(project)
    project.data.get("Covariance", {}).get("data", {}).clear()
    project.save()

    hist = project.histogram(0)
    phases = project.phases()
    if len(phases) != len(EXPORTS):
        raise RuntimeError(f"expected {len(EXPORTS)} phases, found {len(phases)}")

    masses = np.array([
        phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in phases
    ], dtype=float)
    if np.any(masses <= 0) or not np.all(np.isfinite(masses)):
        raise RuntimeError("final project contains a nonpositive crystalline scale")
    fractions = masses / masses.sum()

    phase_rows = []
    for phase, fraction, (label, filename, source) in zip(phases, fractions, EXPORTS):
        phase.export_CIF(str(Path(filename).resolve()))
        phase_rows.append({
            "name": label,
            "formula": phase.data["General"].get("Name", label),
            "cif_path": filename,
            "weight_fraction": float(fraction),
            "source_record": f"COD {source}",
        })

    x, observed, _, calculated, _, stored_difference = [
        np.asarray(values, dtype=float) for values in hist.data["data"][1][:6]
    ]
    difference = observed - calculated
    if not np.allclose(difference, stored_difference, rtol=0, atol=1e-8):
        raise RuntimeError("saved GSAS difference array is inconsistent")
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))

    with Path("fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        for row in zip(x, observed, calculated, difference):
            writer.writerow([f"{row[0]:.8f}", f"{row[1]:.10g}", f"{row[2]:.12g}", f"{row[3]:.12g}"])

    result = {
        "schema_version": 1,
        "refinement_histogram": hist.name,
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "chi_square": chi_square,
            "data_points": int(len(x)),
            "weighting": "1/max(observed_counts, 1)",
        },
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")
    Path("final_summary.json").write_text(json.dumps({
        "project": str(FINAL),
        "histogram": hist.name,
        "rwp_percent": rwp,
        "rp_percent": rp,
        "chi_square": chi_square,
        "phases": phase_rows,
    }, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
