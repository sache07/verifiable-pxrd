from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel("warn")
project = G2.G2Project(newgpx="import_test.gpx")
hist = project.add_powder_histogram(
    "inputs/pattern.csv", "instrument.instprm"
)
x, y, w = [np.asarray(v) for v in hist.data["data"][1][:3]]
print(hist.name, len(x), x[0], x[-1], y.min(), y.max())
print("weight", w.min(), w.max(), w[:5])
print("limits", hist.data["Limits"])
print("instrument", hist.data["Instrument Parameters"][0])
print("sample", hist.data["Sample Parameters"])
print("background", hist.data["Background"])
