#!/usr/bin/env python3
"""Rechallenge weak phases by fixing selected scales to zero."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from five_phase_refine import clean, limits
from refine_trial import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument("--omit", type=int, nargs="+", required=True)
    parser.add_argument("--repeats", type=int, default=4)
    args = parser.parse_args()
    omitted = set(args.omit)

    G2.SetPrintLevel("warn")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.base, newgpx=str(out))
    project.set_Frozen()
    clean(project)
    hist = project.histogram(0)
    hist.set_refinements({"Background": True})
    hist.set_refinements({"Sample Parameters": ["Shift", "SurfRoughB"]})
    rows = [(":0:Shift", -800.0, 800.0), (":0:SurfRoughB", 0.02, 0.5)]
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        if index in omitted:
            hap["Scale"] = [0.0, False]
        else:
            phase.set_HAP_refinements({"Scale": True})
            rows.append((f"{index}:0:Scale", 0.0, 1.0e6))
        if index in (0, 1, 4):
            phase.set_refinements({"Cell": True})
    limits(project, rows)
    project.save()

    log = []
    for iteration in range(args.repeats):
        project.set_Controls("cycles", 10)
        project.refine()
        project.save()
        log.append(snapshot(project, f"iteration_{iteration + 1}"))
        print(iteration + 1, "Rwp", log[-1]["rwp"])
    log[-1]["omitted_phase_indices"] = sorted(omitted)
    out.with_suffix(".json").write_text(json.dumps(log, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
