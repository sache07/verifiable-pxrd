#!/usr/bin/env python3
"""Test restrained structural refinements from a replay-safe baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


def add_flag(atom, flag: str) -> None:
    flags = atom.refinement_flags.strip()
    if flag not in flags:
        atom.refinement_flags = flags + flag


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument(
        "--mode",
        choices=["uiso", "w-pos", "wo3-o-pos", "wo3-all-pos", "bao2-o-pos"],
        required=True,
    )
    parser.add_argument("--repeats", type=int, default=4)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.base, newgpx=str(out))
    project.set_Frozen()
    phases = project.phases()
    for phase in phases:
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})

    if args.mode == "uiso":
        for phase_index, phase in enumerate(phases):
            variables = []
            for atom_index, atom in enumerate(phase.atoms()):
                add_flag(atom, "U")
                variables.append(f"{phase_index}::AUiso:{atom_index}")
            if len(variables) > 1:
                project.add_EquivConstr(variables, reloadIdx=False)
            project.set_Controls("parmMin", 0.003, variable=variables[0])
            project.set_Controls("parmMax", 0.02, variable=variables[0])
    else:
        if args.mode == "w-pos":
            selected = [(0, i, atom) for i, atom in enumerate(phases[0].atoms()) if atom.element == "W"]
        elif args.mode == "wo3-o-pos":
            selected = [(0, i, atom) for i, atom in enumerate(phases[0].atoms()) if atom.element == "O"]
        elif args.mode == "wo3-all-pos":
            selected = [(0, i, atom) for i, atom in enumerate(phases[0].atoms())]
        else:
            selected = [(1, i, atom) for i, atom in enumerate(phases[1].atoms()) if atom.element == "O"]
        for phase_index, atom_index, atom in selected:
            add_flag(atom, "X")
            for axis in "xyz":
                variable = f"{phase_index}::dA{axis}:{atom_index}"
                project.set_Controls("parmMin", -0.02, variable=variable)
                project.set_Controls("parmMax", 0.02, variable=variable)

    project.save()
    rows = []
    for iteration in range(args.repeats):
        project.set_Controls("cycles", 10)
        project.refine()
        project.save()
        rows.append(snapshot(project, f"iteration_{iteration + 1}"))
        print(iteration + 1, "Rwp", rows[-1]["rwp"])
    rows[-1]["test_mode"] = args.mode
    out.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
