#!/usr/bin/env python3
"""Test one bounded global intensity/profile nuisance term."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument("--mode", choices=["polarization", "shl", "roughness"], required=True)
    parser.add_argument("--repeats", type=int, default=4)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.base, newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Polariz.", "SH/L"]})
    hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    if args.mode == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        limits = [(":0:Polariz.", 0.5, 1.0)]
    elif args.mode == "shl":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        limits = [(":0:SH/L", 0.005, 0.1)]
    else:
        hist.data["Sample Parameters"]["SurfRoughA"][0] = 0.3
        hist.data["Sample Parameters"]["SurfRoughB"][0] = 0.1
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        limits = [(":0:SurfRoughA", 0.05, 0.6), (":0:SurfRoughB", 0.0, 0.5)]
    project.save()
    for variable, low, high in limits:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    rows = []
    for iteration in range(args.repeats):
        project.set_Controls("cycles", 10)
        project.refine()
        project.save()
        rows.append(snapshot(project, f"iteration_{iteration + 1}"))
        print(iteration + 1, "Rwp", rows[-1]["rwp"])
    rows[-1]["test_mode"] = args.mode
    out.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
