#!/usr/bin/env python3
"""Challenge one chemically plausible weak phase under a fixed accepted model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import cod_path, snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument("cod_id")
    parser.add_argument("name")
    parser.add_argument("--repeats", type=int, default=4)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.base, newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Polariz.", "SH/L", "U", "W", "X"]})
    hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Pref.Ori.": True, "Size": True, "Mustrain": True})
    phase = project.add_phase(str(cod_path(args.cod_id)), phasename=args.name, histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.1, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.5
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 7000.0
    hap["Mustrain"][2] = [False, False, False]
    for atom in phase.atoms():
        atom.uiso = 0.01
    project.save()
    phase_index = len(project.phases()) - 1
    project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Scale")
    rows = []
    for iteration in range(args.repeats):
        project.set_Controls("cycles", 10)
        project.refine()
        project.save()
        rows.append(snapshot(project, f"iteration_{iteration + 1}"))
        print(iteration + 1, "Rwp", rows[-1]["rwp"], "scale", hap["Scale"][0])
    rows[-1].update(test_cod_id=args.cod_id, test_phase_name=args.name)
    out.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
