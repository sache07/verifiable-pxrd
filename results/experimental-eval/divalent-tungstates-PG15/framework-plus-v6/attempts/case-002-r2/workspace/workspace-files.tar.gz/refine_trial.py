#!/usr/bin/env python3
"""Create a controlled two-phase GSAS-II trial for record comparison."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    rows = {
        "stage": label,
        "rwp": hist.get_wR(),
        "instrument": {key: value[1] for key, value in inst.items() if isinstance(value, list) and len(value) >= 2},
        "sample": {key: value[0] for key, value in hist.data["Sample Parameters"].items() if isinstance(value, list) and len(value) == 2},
        "background": hist.data["Background"][0][:],
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        rows["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"][0],
                "size": copy.deepcopy(hap["Size"]),
                "mustrain": copy.deepcopy(hap["Mustrain"]),
                "pref_ori": copy.deepcopy(hap["Pref.Ori."]),
            }
        )
    try:
        rows["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        rows["mass_fraction_error"] = str(exc)
    rows["vary"] = [str(v) for v in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])]
    return rows


def refine(project: G2.G2Project, label: str, log: list[dict], cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    log.append(snapshot(project, label))
    print(label, "Rwp", log[-1]["rwp"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("out")
    parser.add_argument("--bao2-id", default="1010113")
    parser.add_argument("--background-terms", type=int, default=11)
    parser.add_argument("--initial-size", type=float, default=0.3)
    parser.add_argument("--initial-strain", type=float, default=1000.0)
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram("inputs/pattern.csv", "instrument.instprm")
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][:2] = [20.0, 20.0]
    inst["W"][:2] = [20.0, 20.0]
    inst["X"][:2] = [2.0, 2.0]

    x, y = (np.asarray(v, float) for v in hist.data["data"][1][:2])
    baseline = percentile_filter(y, 20, size=401, mode="nearest")
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    coeffs = np.polynomial.chebyshev.chebfit(t, baseline, args.background_terms - 1)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(coeffs),
                "coeffs": coeffs.tolist(),
                "refine": True,
            }
        }
    )

    phases = [
        project.add_phase(str(cod_path(args.wo3_id)), phasename=f"WO3_{args.wo3_id}", histograms=[hist], fmthint="CIF"),
        project.add_phase(str(cod_path(args.bao2_id)), phasename=f"BaO2_{args.bao2_id}", histograms=[hist], fmthint="CIF"),
    ]
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:2] = [args.initial_size, args.initial_size]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:2] = [args.initial_strain, args.initial_strain]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.uiso = 0.01

    log: list[dict] = []
    project.save()
    # Known laboratory envelope; limits also prevent negative analytic widths.
    for variable, low, high in [
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:Shift", -800.0, 800.0),
        ("0:0:Scale", 0.0, 1.0e6),
        ("1:0:Scale", 0.0, 1.0e6),
        ("0:0:Size;i", 0.04, 1.5),
        ("1:0:Size;i", 0.04, 1.5),
        ("0:0:Mustrain;i", 0.0, 8000.0),
        ("1:0:Mustrain;i", 0.0, 8000.0),
    ]:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    refine(project, "background_scales", log)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "shift_cells", log)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, "common_profile", log)

    if args.quick:
        (out.with_suffix(".json")).write_text(json.dumps(log, indent=2, default=float) + "\n")
        return

    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        refine(project, f"{phase.name}_size", log)
        phase.clear_HAP_refinements({"Size": True})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        refine(project, f"{phase.name}_strain", log)
        phase.clear_HAP_refinements({"Mustrain": True})

    (out.with_suffix(".json")).write_text(json.dumps(log, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
