#!/usr/bin/env python3
"""Rechallenge a two-phase project with a fixed specimen-broadening baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument("--size", type=float, required=True)
    parser.add_argument("--strain", type=float, required=True)
    parser.add_argument("--shl", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.base, newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key, value in [("U", 20.0), ("W", 20.0), ("X", 2.0), ("SH/L", 0.02)]:
        inst[key][1] = value
        inst[key][2] = key != "SH/L" or args.shl
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = args.size
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = args.strain
        hap["Mustrain"][2] = [False, False, False]
    project.save()
    for variable, low, high in [
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.1),
    ]:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    project.set_Controls("cycles", 10)
    project.refine()
    project.save()
    row = snapshot(project, "fixed_profile_rechallenge")
    row["fixed_size"] = args.size
    row["fixed_strain"] = args.strain
    row["refined_shl"] = args.shl
    out.with_suffix(".json").write_text(json.dumps(row, indent=2, default=float) + "\n")
    print(out, "Rwp", row["rwp"], "profile", {k: row["instrument"][k] for k in ["U", "W", "X", "SH/L"]})


if __name__ == "__main__":
    main()
