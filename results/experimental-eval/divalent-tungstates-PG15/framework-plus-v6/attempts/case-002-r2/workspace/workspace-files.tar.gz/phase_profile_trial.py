#!/usr/bin/env python3
"""Test one phase-specific broadening term from a common-profile project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument("--phase", type=int, choices=[0, 1], required=True)
    parser.add_argument("--term", choices=["size", "strain", "uniaxial-strain"], required=True)
    parser.add_argument("--axis", nargs=3, type=int, default=[0, 0, 1])
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.base, newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    phases = project.phases()
    for phase in phases:
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    phase = phases[args.phase]
    if args.term == "size":
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        variables = [(f"{args.phase}:0:Size;i", 0.04, 5.0)]
    elif args.term == "strain":
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        variables = [(f"{args.phase}:0:Mustrain;i", 0.0, 8000.0)]
    else:
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "direction": args.axis,
                    "refine": True,
                }
            }
        )
        variables = [
            (f"{args.phase}:0:Mustrain;i", 0.0, 8000.0),
            (f"{args.phase}:0:Mustrain;a", 0.0, 32000.0),
        ]
    project.save()
    for variable, low, high in variables:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    project.set_Controls("cycles", 10)
    project.refine()
    project.save()
    row = snapshot(project, f"phase_{args.phase}_{args.term}")
    row.update(test_phase=args.phase, test_term=args.term, test_axis=args.axis)
    out.with_suffix(".json").write_text(json.dumps(row, indent=2, default=float) + "\n")
    hap = phase.data["Histograms"][hist.name]
    print(out, "Rwp", row["rwp"], "size", hap["Size"], "strain", hap["Mustrain"])


if __name__ == "__main__":
    main()
