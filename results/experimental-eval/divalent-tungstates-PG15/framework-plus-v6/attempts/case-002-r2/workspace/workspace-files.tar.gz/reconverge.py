#!/usr/bin/env python3
"""Repeat a refinement recipe until nonlinear parameters settle."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument("--repeats", type=int, default=6)
    parser.add_argument("--cycles", type=int, default=10)
    parser.add_argument("--clear-instrument", action="store_true")
    parser.add_argument("--refine-instrument", action="store_true")
    parser.add_argument("--clear-profile", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.base, newgpx=str(out))
    if args.clear_instrument:
        project.histogram(0).clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        project.set_Frozen()
    if args.refine_instrument:
        project.set_Frozen()
        project.histogram(0).set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        for variable, low, high in [
            (":0:U", 0.0, 40.0),
            (":0:W", 2.0, 40.0),
            (":0:X", 0.1, 6.0),
        ]:
            project.set_Controls("parmMin", low, variable=variable)
            project.set_Controls("parmMax", high, variable=variable)
    if args.clear_profile:
        for phase in project.phases():
            phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        project.set_Frozen()
    project.save()
    rows = []
    for iteration in range(args.repeats):
        project.set_Controls("cycles", args.cycles)
        project.refine()
        project.save()
        row = snapshot(project, f"iteration_{iteration + 1}")
        rows.append(row)
        print(iteration + 1, "Rwp", row["rwp"])
    out.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
