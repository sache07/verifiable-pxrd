#!/usr/bin/env python3
"""Test whether a weak phase has enough positional support to refine its cell."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--repeats", type=int, default=4)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.base, newgpx=str(out))
    project.set_Frozen()
    for index, phase in enumerate(project.phases()):
        if index >= 2:
            phase.set_refinements({"Cell": index == args.phase})
    project.save()
    rows = []
    for iteration in range(args.repeats):
        project.set_Controls("cycles", 10)
        project.refine()
        project.save()
        rows.append(snapshot(project, f"iteration_{iteration + 1}"))
        print(iteration + 1, "Rwp", rows[-1]["rwp"], "cell", project.phases()[args.phase].get_cell())
    rows[-1]["test_phase"] = args.phase
    out.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
