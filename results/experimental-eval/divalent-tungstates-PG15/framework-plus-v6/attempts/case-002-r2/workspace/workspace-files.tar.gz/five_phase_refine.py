#!/usr/bin/env python3
"""Bounded replay-safe refinement challenges for the five-phase inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


INST = ["U", "W", "X", "SH/L", "Polariz."]
SAMPLE = ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"]


def clean(project: G2.G2Project) -> None:
    """Clear refine flags without changing the current physical model."""
    hist = project.histogram(0)
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({"Instrument Parameters": INST})
    hist.clear_refinements({"Sample Parameters": SAMPLE})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Scale": True, "Pref.Ori.": True, "Size": True, "Mustrain": True}
        )


def limits(project: G2.G2Project, rows: list[tuple[str, float, float]]) -> None:
    for variable, low, high in rows:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)


def add_core(project: G2.G2Project, roughness: bool = True) -> None:
    """Refine terms that must reconverge after every inventory/profile change."""
    hist = project.histogram(0)
    hist.set_refinements({"Background": True})
    sample = ["Shift"] + (["SurfRoughB"] if roughness else [])
    hist.set_refinements({"Sample Parameters": sample})
    phases = project.phases()
    for index, phase in enumerate(phases):
        phase.set_HAP_refinements({"Scale": True})
        if index in (0, 1, 4):
            phase.set_refinements({"Cell": True})
    rows = [(":0:Shift", -800.0, 800.0)]
    if roughness:
        rows.append((":0:SurfRoughB", 0.02, 0.5))
    rows.extend((f"{i}:0:Scale", 0.0, 1.0e6) for i in range(len(phases)))
    limits(project, rows)


def tie_uiso(project: G2.G2Project, phase_index: int) -> None:
    """Vary one isotropic U value for every independent site of a phase."""
    phase = project.phases()[phase_index]
    variables = []
    for atom_index, atom in enumerate(phase.atoms()):
        atom.refinement_flags = "U"
        variables.append(f"{phase_index}::AUiso:{atom_index}")
    # The starting project already contains tied-Uiso equivalences for phases
    # 0 and 1. Add one only for phases introduced after that project was made.
    if len(variables) > 1 and phase_index not in (0, 1):
        project.add_EquivConstr(variables, reloadIdx=False)
    limits(project, [(variables[0], 0.003, 0.02)])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument(
        "--mode",
        choices=["core", "instrument", "phase-profile", "texture", "uiso", "coordinates"],
        default="core",
    )
    parser.add_argument("--phase", type=int, default=4)
    parser.add_argument("--term", default="U")
    parser.add_argument("--axis", nargs=3, type=int, default=[0, 0, 1])
    parser.add_argument("--start", type=float)
    parser.add_argument("--start-axial", type=float)
    parser.add_argument("--fix-equatorial", action="store_true")
    parser.add_argument("--coord-bound", type=float, default=0.005)
    parser.add_argument("--roughness", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--disable-roughness", action="store_true")
    parser.add_argument("--repeats", type=int, default=5)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.base, newgpx=str(out))
    project.set_Frozen()
    clean(project)
    if args.disable_roughness:
        sample = project.histogram(0).data["Sample Parameters"]
        sample["SurfRoughA"][0] = 0.0
        sample["SurfRoughB"][0] = 0.0
        args.roughness = False
    add_core(project, args.roughness)
    hist = project.histogram(0)
    phases = project.phases()

    if args.mode == "instrument":
        if args.term not in {"U", "W", "X", "SH/L", "Polariz."}:
            raise ValueError("invalid instrument term")
        if args.start is not None:
            hist.data["Instrument Parameters"][0][args.term][1] = args.start
        hist.set_refinements({"Instrument Parameters": [args.term]})
        bounds = {
            "U": (0.0, 40.0), "W": (2.0, 40.0), "X": (0.1, 6.0),
            "SH/L": (0.005, 0.1), "Polariz.": (0.5, 1.0),
        }[args.term]
        limits(project, [(f":0:{args.term}", *bounds)])
    elif args.mode == "phase-profile":
        phase = phases[args.phase]
        hap = phase.data["Histograms"][hist.name]
        if args.term == "size":
            hap["Size"][0] = "isotropic"
            if args.start is not None:
                hap["Size"][1][0] = args.start
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
            limits(project, [(f"{args.phase}:0:Size;i", 0.04, 1.5)])
        elif args.term == "strain":
            hap["Mustrain"][0] = "isotropic"
            if args.start is not None:
                hap["Mustrain"][1][0] = args.start
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
            limits(project, [(f"{args.phase}:0:Mustrain;i", 0.0, 8000.0)])
        elif args.term == "uniaxial-strain":
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][3] = list(args.axis)
            if args.start is not None:
                hap["Mustrain"][1][0] = args.start
            if args.start_axial is not None:
                hap["Mustrain"][1][1] = args.start_axial
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "uniaxial", "direction": args.axis, "refine": True}}
            )
            if args.fix_equatorial:
                hap["Mustrain"][2] = [False, True, False]
                equatorial = float(hap["Mustrain"][1][0])
                limits(project, [
                    (f"{args.phase}:0:Mustrain;a", 0.25 * equatorial, 4.0 * equatorial),
                ])
            else:
                limits(project, [
                    (f"{args.phase}:0:Mustrain;i", 0.0, 8000.0),
                    (f"{args.phase}:0:Mustrain;a", 0.0, 32000.0),
                ])
        else:
            raise ValueError("invalid phase-profile term")
    elif args.mode == "texture":
        phase = phases[args.phase]
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[:4] = ["MD", 1.0 if args.start is None else args.start, True, list(args.axis)]
        limits(project, [(f"{args.phase}:0:MD", 0.7, 1.4)])
    elif args.mode == "uiso":
        tie_uiso(project, args.phase)
    elif args.mode == "coordinates":
        phase = phases[args.phase]
        selected = [
            (i, atom) for i, atom in enumerate(phase.atoms())
            if args.term == "all" or atom.element == args.term
        ]
        if not selected:
            raise ValueError("no atoms selected")
        rows = []
        for atom_index, atom in selected:
            atom.refinement_flags = "X"
            for axis in "xyz":
                rows.append((f"{args.phase}::dA{axis}:{atom_index}", -args.coord_bound, args.coord_bound))
        limits(project, rows)

    project.save()
    rows = []
    for iteration in range(args.repeats):
        project.set_Controls("cycles", 10)
        project.refine()
        project.save()
        row = snapshot(project, f"iteration_{iteration + 1}")
        rows.append(row)
        print(iteration + 1, "Rwp", row["rwp"])
    rows[-1].update(
        test_mode=args.mode, test_phase=args.phase, test_term=args.term,
        test_axis=args.axis, roughness=args.roughness,
    )
    out.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
