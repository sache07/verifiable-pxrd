#!/usr/bin/env python3
"""Test one March-Dollase axis from a replay-safe common baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_trial import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("out")
    parser.add_argument("--phase", type=int, choices=[0, 1], required=True)
    parser.add_argument("--axis", nargs=3, type=int, required=True)
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.base, newgpx=str(out))
    project.set_Frozen()
    hist = project.histogram(0)
    for phase in project.phases():
        phase.clear_HAP_refinements({"Pref.Ori.": True})
    phase = project.phases()[args.phase]
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(args.axis)
    project.save()
    project.set_Controls("parmMin", 0.7, variable=f"{args.phase}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{args.phase}:0:MD")
    rows = []
    for iteration in range(args.repeats):
        project.set_Controls("cycles", 10)
        project.refine()
        project.save()
        rows.append(snapshot(project, f"iteration_{iteration + 1}"))
        print(iteration + 1, "Rwp", rows[-1]["rwp"], "MD", po[1])
    rows[-1].update(test_phase=args.phase, test_axis=args.axis)
    out.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
