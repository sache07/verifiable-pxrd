#!/usr/bin/env python3
"""Build and refine trial GSAS-II models for the supplied powder pattern.

Run with the GSAS-II Python interpreter. This is an analysis helper; final
exports are produced separately after model selection.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
MNWO4 = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)


def prepare_observation(folder: Path) -> tuple[Path, Path]:
    """Write GSAS-II-readable observation and nominal instrument files."""
    folder.mkdir(parents=True, exist_ok=True)
    x, y = np.loadtxt(PATTERN, delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = folder / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    inst = folder / "instrument.instprm"
    inst.write_text(
        "# Laboratory Cu Kalpha starting profile; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst


def initial_background(x: np.ndarray, y: np.ndarray, n: int) -> list[float]:
    """Estimate a smooth lower envelope and express it as Chebyshev terms."""
    # A local 15th percentile rejects Bragg peaks. The normal-quantile offset
    # approximately recenters Poisson fluctuations before the low-order fit.
    q = percentile_filter(y, percentile=15, size=181, mode="nearest")
    envelope = q + 1.04 * np.sqrt(np.maximum(q, 1.0))
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    keep = (x > x[0] + 0.15) & (x < x[-1] - 0.15)
    return np.polynomial.chebyshev.chebfit(t[keep], envelope[keep], n - 1).tolist()


def set_isotropic_adps(phase: G2.G2Phase, value: float = 0.01) -> None:
    """Put all input atoms on one physically positive isotropic ADP model."""
    _, _, _, cia = phase.data["General"]["AtomPtrs"]
    for atom in phase.data["Atoms"]:
        atom[cia] = "I"
        atom[cia + 1] = float(value)
        atom[cia + 2 : cia + 8] = [0.0] * 6


def neutralize_hap(phase: G2.G2Phase, hist: G2.G2PwdrData) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:2] = [1000.0, 1000.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:2] = [0.0, 0.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]


def set_bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def refine(project: G2.G2Project, label: str, cycles: int = 8) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "stage": label,
        "rwp": float(hist.get_wR()),
        "gof": float(cov.get("Rvals", {}).get("GOF", np.nan)),
        "nvars": len(cov.get("varyList", [])),
        "vary": list(cov.get("varyList", [])),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(result), flush=True)
    return result


def build(args: argparse.Namespace) -> None:
    out = ROOT / args.out
    xye, instfile = prepare_observation(out)
    gpx = out / "trial.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    phase = project.add_phase(
        str(Path(args.source).resolve()), phasename=args.phase_name, fmthint="CIF"
    )
    hist = project.add_powder_histogram(
        str(xye), str(instfile), phases=[phase], fmthint="xye"
    )
    project.update_ids()
    set_isotropic_adps(phase)
    neutralize_hap(phase, hist)

    x = np.asarray(hist.getdata("X"), float)
    y = np.asarray(hist.getdata("Yobs"), float)
    coeffs = initial_background(x, y, args.nbg)
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.nbg,
                "coeffs": coeffs,
                "refine": True,
            },
        }
    )
    sample = hist.data["Sample Parameters"]
    sample["Type"] = "Bragg-Brentano"
    # Absolute histogram scale and all phase scales are exactly collinear.
    # Keep the former fixed so phase scales remain quantitative.
    sample["Scale"] = [1.0, False]
    sample["Gonio. radius"] = 200.0
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    instrument = hist.data["Instrument Parameters"][0]
    starts = {
        "Zero": 0.0,
        "Polariz.": 0.75,
        "U": 10.0,
        "V": 0.0,
        "W": 10.0,
        "X": 1.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.02,
        "I(L2)/I(L1)": 0.5,
    }
    for key, value in starts.items():
        if key in instrument:
            instrument[key][0] = value
            instrument[key][1] = value
            instrument[key][2] = False

    project.save()
    prefix = f":{hist.id}:"
    set_bound(project, prefix + "U", 0.0, 80.0)
    set_bound(project, prefix + "W", 0.2, 80.0)
    set_bound(project, prefix + "X", 0.01, 15.0)
    set_bound(project, prefix + "SH/L", 0.002, 0.2)
    set_bound(project, prefix + "Polariz.", 0.5, 1.0)
    set_bound(project, prefix + "Shift", -800.0, 800.0)

    history = []
    history.append(refine(project, "background_scale"))

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    history.append(refine(project, "cell_shift"))

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    history.append(refine(project, "common_uwx"))

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    history.append(refine(project, "common_asymmetry"))

    if args.refine_polarization:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        history.append(refine(project, "polarization"))

    # Reopen/replay the active settings to expose any save/load instability.
    project.save()
    project = G2.G2Project(gpxfile=str(gpx))
    history.append(refine(project, "reopened_replay", cycles=10))

    hist = project.histogram(0)
    phase = project.phase(0)
    summary = {
        "history": history,
        "histogram": hist.name,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "cell": phase.get_cell(),
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": atom.coordinates,
                "adp": atom.ADP,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
        "hap": phase.data["Histograms"][hist.name],
        "background": hist.data["Background"],
    }
    (out / "summary.json").write_text(
        json.dumps(summary, indent=2, default=lambda value: value.tolist()) + "\n"
    )
    np.savetxt(
        out / "fit.csv",
        np.column_stack(
            [
                hist.getdata("X"),
                hist.getdata("Yobs"),
                hist.getdata("Ycalc"),
                hist.getdata("Residual"),
                hist.getdata("Background"),
            ]
        ),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="trials/mnwo4_base")
    parser.add_argument("--source", default=str(MNWO4))
    parser.add_argument("--phase-name", default="MnWO4_wolframite")
    parser.add_argument("--nbg", type=int, default=8)
    parser.add_argument("--refine-polarization", action="store_true")
    build(parser.parse_args())


if __name__ == "__main__":
    main()
