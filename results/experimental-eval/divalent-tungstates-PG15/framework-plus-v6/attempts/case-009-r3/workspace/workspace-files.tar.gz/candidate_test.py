#!/usr/bin/env python3
"""Challenge a converged one-phase GSAS-II model with one candidate phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def isotropic_atoms(phase: G2.G2Phase, uiso: float = 0.008) -> None:
    _, _, _, cia = phase.data["General"]["AtomPtrs"]
    for atom in phase.data["Atoms"]:
        atom[cia] = "I"
        atom[cia + 1] = uiso
        atom[cia + 2 : cia + 8] = [0.0] * 6
    for atom in phase.atoms():
        atom.refinement_flags = ""


def neutral_hap(phase: G2.G2Phase, hist: G2.G2PwdrData, scale: float) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:3] = [10.0, 10.0, 1.0]
    hap["Size"][2][:3] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:3] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:3] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]


def refine(project: G2.G2Project, cycles: int = 20) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--name", required=True)
    parser.add_argument("--start-weight", type=float, default=0.01)
    parser.add_argument("--refine-cell-threshold", type=float, default=0.002)
    args = parser.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)
    gpx = args.output / "trial.gpx"
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(gpx.resolve()))
    project.update_ids()
    project.set_Frozen()
    hist = project.histogram(0)
    principal = project.phase(0)
    candidate = project.add_phase(
        str(args.candidate.resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    project.update_ids()
    candidate_index = len(project.phases()) - 1
    isotropic_atoms(candidate)

    principal_hap = principal.data["Histograms"][hist.name]
    numerator = principal_hap["Scale"][0] * principal.data["General"]["Mass"]
    start_scale = (
        args.start_weight
        / (1.0 - args.start_weight)
        * numerator
        / candidate.data["General"]["Mass"]
    )
    neutral_hap(candidate, hist, start_scale)
    candidate.set_refinements({"Cell": False})
    bound(project, f"{candidate.id}:{hist.id}:Scale", 0.0, 1000.0)
    project.save()

    refine(project)
    frozen = list(project.get_Frozen())
    scale_var = f"{candidate.id}:{hist.id}:Scale"
    if scale_var in frozen:
        candidate.data["Histograms"][hist.name]["Scale"][1] = False
        project.set_Frozen()
        refine(project)

    def fractions() -> list[float]:
        products = np.array(
            [
                phase.data["Histograms"][hist.name]["Scale"][0]
                * phase.data["General"]["Mass"]
                for phase in project.phases()
            ],
            float,
        )
        return (products / products.sum()).tolist()

    preliminary = fractions()[candidate_index]
    if preliminary >= args.refine_cell_threshold:
        candidate.set_refinements({"Cell": True})
        refine(project)

    # Reopen and replay all active settings before accepting the scale test.
    project.save()
    project = G2.G2Project(gpxfile=str(gpx))
    refine(project)
    hist = project.histogram(0)
    phases = project.phases()
    final_fractions = fractions()
    candidate_final = phases[candidate_index]
    cov = project.data.get("Covariance", {}).get("data", {})
    vary = list(cov.get("varyList", []))
    sig = np.asarray(cov.get("sig", []), float)
    scale_sigma = None
    if scale_var in vary:
        scale_sigma = float(sig[vary.index(scale_var)])
    x = np.asarray(hist.getdata("X"), float)
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    diff = obs - calc
    chisq = float(np.sum(diff**2 / np.maximum(obs, 1.0)))
    denominator = float(np.sum(obs**2 / np.maximum(obs, 1.0)))
    result = {
        "candidate": args.name,
        "source": str(args.candidate.resolve()),
        "rwp_percent": 100.0 * np.sqrt(chisq / denominator),
        "weighted_chisq": chisq,
        "n_parameters": len(vary),
        "bic": chisq + len(vary) * np.log(len(x)),
        "fractions": {
            phase.name: fraction for phase, fraction in zip(phases, final_fractions)
        },
        "candidate_scale": candidate_final.data["Histograms"][hist.name]["Scale"][0],
        "candidate_scale_sigma": scale_sigma,
        "candidate_cell": candidate_final.get_cell(),
        "candidate_mass": candidate_final.data["General"]["Mass"],
        "scale_refined": candidate_final.data["Histograms"][hist.name]["Scale"][1],
        "cell_refined": candidate_final.data["General"]["Cell"][0],
        "frozen_then_fixed": scale_var in frozen,
        "vary_list": vary,
    }
    (args.output / "diagnostics.json").write_text(
        json.dumps(result, indent=2, default=lambda value: value.tolist()) + "\n"
    )
    np.savetxt(
        args.output / "fit.csv",
        np.column_stack((x, obs, calc, diff, hist.getdata("Background"))),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )
    print(json.dumps(result, default=lambda value: value.tolist()), flush=True)


if __name__ == "__main__":
    main()
