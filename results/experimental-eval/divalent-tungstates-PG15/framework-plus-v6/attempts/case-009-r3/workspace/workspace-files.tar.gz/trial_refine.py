#!/usr/bin/env python3
"""Branch a GSAS-II project to challenge one or more physical model terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIElem as G2elem


def parse_axis(text: str) -> list[int]:
    axis = [int(value) for value in text.split(",")]
    if len(axis) != 3 or not any(axis):
        raise argparse.ArgumentTypeError("axis must be three comma-separated integers")
    return axis


def bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def run_refinement(project: G2.G2Project, cycles: int) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()


def settle_limited_terms(project: G2.G2Project) -> list[str]:
    """Fix any parameter clamped at a physical bound before replay."""
    frozen = project.get_Frozen()
    if not frozen:
        return []
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hap = project.phase(0).data["Histograms"][hist.name]
    for variable in frozen:
        name = variable.split(":")[-1]
        if name in inst:
            inst[name][2] = False
        elif name in sample and isinstance(sample[name], list):
            sample[name][1] = False
        elif name == "MD":
            hap["Pref.Ori."][2] = False
        elif name == "Mustrain;i":
            hap["Mustrain"][2][0] = False
        elif name == "Mustrain;a":
            hap["Mustrain"][2][1] = False
        elif name == "Size;i":
            hap["Size"][2][0] = False
        elif name.startswith("AUiso"):
            for atom in project.phase(0).atoms():
                atom.refinement_flags = atom.refinement_flags.replace("U", "")
            project.data["Constraints"]["data"]["Phase"] = []
    project.set_Frozen()
    project.save()
    return frozen


def diagnostics(project: G2.G2Project, out: Path, label: str, clamped: list[str]) -> dict:
    hist = project.histogram(0)
    phase = project.phase(0)
    x = np.asarray(hist.getdata("X"), float)
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    diff = obs - calc
    bkg = np.asarray(hist.getdata("Background"), float)
    weights = 1.0 / np.maximum(obs, 1.0)
    chisq = float(np.sum(weights * diff**2))
    denominator = float(np.sum(weights * obs**2))
    cov = project.data.get("Covariance", {}).get("data", {})
    vary = list(cov.get("varyList", []))
    hap = phase.data["Histograms"][hist.name]
    result = {
        "label": label,
        "rwp_percent": 100.0 * np.sqrt(chisq / denominator),
        "weighted_chisq": chisq,
        "reduced_chisq": chisq / max(1, len(x) - len(vary)),
        "n_parameters": len(vary),
        "bic": chisq + len(vary) * np.log(len(x)),
        "cell": phase.get_cell(),
        "instrument": {key: value[1] for key, value in hist.data["Instrument Parameters"][0].items()},
        "sample": {
            key: (value[0] if isinstance(value, list) else value)
            for key, value in hist.data["Sample Parameters"].items()
            if key in ["Scale", "Shift", "SurfRoughA", "SurfRoughB", "Transparency"]
        },
        "hap": {
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        },
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": atom.coordinates,
                "adp": atom.ADP,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
        "background_min": float(np.min(bkg)),
        "background_max": float(np.max(bkg)),
        "vary_list": vary,
        "clamped_then_fixed": clamped,
    }
    np.savetxt(
        out / "fit.csv",
        np.column_stack((x, obs, calc, diff, bkg)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )
    phase.export_CIF(str(out / "phase.cif"))
    (out / "diagnostics.json").write_text(
        json.dumps(result, indent=2, default=lambda value: value.tolist()) + "\n"
    )
    print(json.dumps(result, default=lambda value: value.tolist()), flush=True)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--label", default="trial")
    parser.add_argument("--texture-axis", type=parse_axis)
    parser.add_argument("--texture-start", type=float, default=0.9)
    parser.add_argument("--no-texture", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--coordinates", action="store_true")
    parser.add_argument("--uiso", action="store_true")
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--mustrain-axis", type=parse_axis)
    parser.add_argument("--isotropic-mustrain", action="store_true")
    parser.add_argument("--isotropic-size", action="store_true")
    parser.add_argument("--fix-x", type=float)
    parser.add_argument(
        "--background-type",
        choices=[
            "chebyschev-1",
            "lin interpolate",
            "inv interpolate",
            "log interpolate",
            "Q^-2 power series",
        ],
    )
    parser.add_argument("--background-terms", type=int)
    parser.add_argument("--debye-tail", action="store_true")
    parser.add_argument("--cycles", type=int, default=15)
    args = parser.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)
    gpx = args.output / "trial.gpx"
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(gpx.resolve()))
    project.update_ids()
    project.set_Frozen()
    hist = project.histogram(0)
    phase = project.phase(0)
    instrument = hist.data["Instrument Parameters"][0]
    # The baseline trial showed that U wanted to become negative. Keep the
    # accepted nonnegative boundary explicitly fixed while other causes are tested.
    instrument["U"][1] = max(0.0, instrument["U"][1])
    instrument["U"][2] = False
    if args.fix_x is not None:
        instrument["X"][1] = args.fix_x
        instrument["X"][2] = False

    original_background = np.asarray(hist.getdata("Background"), float)
    if args.background_type or args.background_terms:
        old_background = np.asarray(hist.getdata("Background"), float)
        x = np.asarray(hist.getdata("X"), float)
        background = hist.data["Background"][0]
        kind = args.background_type or background[0]
        terms = args.background_terms or int(background[2])
        if terms < 2:
            raise ValueError("at least two background terms are required")
        if kind == "chebyschev-1" and background[0] == kind:
            values = list(background[3 : 3 + min(terms, int(background[2]))])
            values.extend([0.0] * (terms - len(values)))
        elif kind in {"lin interpolate", "inv interpolate", "log interpolate"}:
            if kind == "lin interpolate":
                knots = np.linspace(x[0], x[-1], terms)
            elif kind == "inv interpolate":
                knots = 1.0 / np.linspace(1.0 / x[-1], 1.0 / x[0], terms)
            else:
                knots = np.exp(np.linspace(np.log(x[0]), np.log(x[-1]), terms))
            knots[0], knots[-1] = x[0], x[-1]
            values = np.interp(knots, x, old_background).tolist()
        elif kind == "Q^-2 power series":
            wave = float(instrument["Lam1"][1])
            q = 4.0 * np.pi * np.sin(np.radians(x / 2.0)) / wave
            columns = [np.ones_like(q)]
            term = np.ones_like(q)
            for index in range(terms - 1):
                term = term * (index + 1) * q ** -2
                columns.append(term.copy())
            values = np.linalg.lstsq(np.column_stack(columns), old_background, rcond=None)[0].tolist()
        else:
            raise ValueError(f"cannot initialize background type {kind!r}")
        hist.data["Background"][0] = [kind, True, terms, *values]

    if args.debye_tail:
        background, extras = hist.data["Background"]
        if background[0] != "chebyschev-1":
            raise ValueError("the Debye-tail trial requires a chebyschev-1 floor")
        x = np.asarray(hist.getdata("X"), float)
        terms = int(background[2])
        z = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
        floor_columns = [np.cos(index * np.arccos(z)) for index in range(terms)]
        wave = float(instrument["Lam1"][1])
        q = 4.0 * np.pi * np.sin(np.radians(x / 2.0)) / wave
        sq = (q / (4.0 * np.pi)) ** 2
        form_factor = np.asarray(G2elem.ScatFac(G2elem.GetFormFactorCoeff("Si")[0], sq)[0]) ** 2
        radius = 0.01
        sinc = np.sin(q * radius) / (q * radius)
        best = None
        for u_value in np.geomspace(0.001, 10.0, 121):
            tail = form_factor * sinc * np.exp(-u_value * q**2)
            matrix = np.column_stack([*floor_columns, tail])
            coefficients = np.linalg.lstsq(matrix, original_background, rcond=None)[0]
            predicted = matrix @ coefficients
            score = float(np.sum((predicted - original_background) ** 2))
            if coefficients[-1] >= 0.0 and np.min(predicted) > 0.0 and (best is None or score < best[0]):
                best = (score, u_value, coefficients)
        if best is None:
            raise RuntimeError("could not initialize a positive Debye background tail")
        _, u_value, coefficients = best
        hist.data["Background"][0] = [
            "chebyschev-1",
            True,
            terms,
            *coefficients[:-1].tolist(),
        ]
        extras["nDebye"] = 1
        extras["debyeTerms"] = [
            [float(coefficients[-1]), True, radius, False, float(u_value), True]
        ]
        bound(project, f":{hist.id}:DebyeA;0", 0.0, 10000.0)
        bound(project, f":{hist.id}:DebyeU;0", 0.0001, 20.0)

    hap = phase.data["Histograms"][hist.name]

    if args.isotropic_size:
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:3] = [1.0, 1.0, 1.0]
        hap["Size"][2][:3] = [True, False, False]
        bound(project, f"{phase.id}:{hist.id}:Size;i", 0.02, 10.0)

    if args.mustrain_axis:
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][:3] = [500.0, 1500.0, 1.0]
        hap["Mustrain"][2][:3] = [True, True, False]
        hap["Mustrain"][3] = args.mustrain_axis
        bound(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 12000.0)
        bound(project, f"{phase.id}:{hist.id}:Mustrain;a", 0.0, 32000.0)
    elif args.isotropic_mustrain:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:3] = [1000.0, 1000.0, 1.0]
        hap["Mustrain"][2][:3] = [True, False, False]
        bound(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 12000.0)

    if args.no_texture:
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
    elif args.texture_axis:
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = args.texture_start
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = args.texture_axis
        bound(project, f"{phase.id}:{hist.id}:MD", 0.5, 2.0)

    if args.roughness:
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.35, True]
        sample["SurfRoughB"] = [0.08, True]
        # The laboratory's physically screened Suortti realization range.
        bound(project, f":{hist.id}:SurfRoughA", 0.05, 0.60)
        bound(project, f":{hist.id}:SurfRoughB", 0.02, 0.50)

    if args.polarization:
        instrument["Polariz."][2] = True
        bound(project, f":{hist.id}:Polariz.", 0.5, 1.0)

    if args.coordinates or args.uiso:
        for atom in phase.atoms():
            keep_uiso = args.uiso or (args.coordinates and "U" in atom.refinement_flags)
            atom.refinement_flags = ("X" if args.coordinates else "") + ("U" if keep_uiso else "")

    if args.uiso:
        variables = [f"{phase.id}::AUiso:{index}" for index, _ in enumerate(phase.atoms())]
        project.add_EquivConstr(variables)
        bound(project, f"{phase.id}::AUiso:*", 0.001, 0.04)

    project.save()
    run_refinement(project, args.cycles)
    clamped = settle_limited_terms(project)
    if clamped:
        run_refinement(project, args.cycles)

    # A save/reopen/full replay is part of accepting any model change.
    project.save()
    project = G2.G2Project(gpxfile=str(gpx))
    run_refinement(project, args.cycles)
    clamped.extend(settle_limited_terms(project))
    if project.get_Frozen():
        raise RuntimeError("limited variables remain frozen after settling")
    diagnostics(project, args.output, args.label, sorted(set(clamped)))


if __name__ == "__main__":
    main()
