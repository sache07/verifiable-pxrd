#!/usr/bin/env python3
"""Replay the accepted model and export all requested submission artifacts."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials" / "final_coords" / "trial.gpx"


def fraction_covariance(project: G2.G2Project, hist: G2.G2PwdrData) -> tuple[np.ndarray, np.ndarray]:
    phases = project.phases()
    scales = np.array(
        [phase.data["Histograms"][hist.name]["Scale"][0] for phase in phases], float
    )
    masses = np.array([phase.data["General"]["Mass"] for phase in phases], float)
    products = scales * masses
    total = products.sum()
    fractions = products / total

    covariance = project.data["Covariance"]["data"]
    vary = list(covariance["varyList"])
    indices = [vary.index(f"{phase.id}:{hist.id}:Scale") for phase in phases]
    scale_covariance = np.asarray(covariance["covMatrix"], float)[np.ix_(indices, indices)]
    jacobian = np.empty((len(phases), len(phases)))
    for i in range(len(phases)):
        for j in range(len(phases)):
            jacobian[i, j] = masses[j] * ((i == j) * total - products[i]) / total**2
    fraction_cov = jacobian @ scale_covariance @ jacobian.T
    esds = np.sqrt(np.maximum(np.diag(fraction_cov), 0.0))
    return fractions, esds


def main() -> None:
    final_gpx = ROOT / "final.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(final_gpx))
    project.update_ids()
    project.set_Controls("cycles", 30)
    project.refine()
    project.save()

    # A second load is intentional: all exports come from the serialized state
    # that will be submitted, not from an in-memory predecessor.
    project = G2.G2Project(gpxfile=str(final_gpx))
    project.set_Controls("cycles", 30)
    project.refine()
    project.save()
    if project.get_Frozen():
        raise RuntimeError(f"final project retains frozen variables: {project.get_Frozen()}")

    hist = project.histogram(0)
    phases = project.phases()
    if len(project.histograms()) != 1 or len(phases) != 2:
        raise RuntimeError("the accepted model must contain one histogram and two phases")

    cif_names = ["phase_mnwo4.cif", "phase_mn2o3.cif"]
    for phase, filename in zip(phases, cif_names):
        phase.export_CIF(str(ROOT / filename))

    x = np.asarray(hist.getdata("X"), float)
    observed = np.asarray(hist.getdata("Yobs"), float)
    calculated = np.asarray(hist.getdata("Ycalc"), float)
    background = np.asarray(hist.getdata("Background"), float)
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference, background)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt="%.10f",
    )

    fractions, fraction_esds = fraction_covariance(project, hist)
    weights = 1.0 / np.maximum(observed, 1.0)
    chisq = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    covariance = project.data["Covariance"]["data"]
    n_parameters = len(covariance["varyList"])
    n_observations = len(x)
    rwp = 100.0 * np.sqrt(chisq / denominator)
    rp = 100.0 * float(np.sum(np.abs(difference)) / np.sum(observed))
    reduced = chisq / (n_observations - n_parameters)
    fit_statistics = {
        "r_wp_percent": rwp,
        "r_p_percent": rp,
        "weighted_chi_square": chisq,
        "reduced_chi_square": reduced,
        "goodness_of_fit": float(np.sqrt(reduced)),
        "n_observations": n_observations,
        "n_refined_parameters": n_parameters,
        "weighting": "1/max(observed_counts, 1); no pointwise uncertainties supplied",
    }
    records = []
    labels = [
        ("MnWO4", "wolframite", "P 2/c"),
        ("Mn2O3", "bixbyite", "I a -3"),
    ]
    for phase, filename, fraction, esd, (formula, structure_type, space_group) in zip(
        phases, cif_names, fractions, fraction_esds, labels
    ):
        records.append(
            {
                "name": f"{formula} ({structure_type})",
                "formula": formula,
                "space_group": space_group,
                "cif_path": filename,
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(esd),
                "cell": phase.get_cell(),
            }
        )
    result = {
        "phases": records,
        "fit_statistics": fit_statistics,
        "refinement_histogram": hist.name,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "project": "final.gpx",
        "profile": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
