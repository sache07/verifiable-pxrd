from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("phases", help="comma-separated phase indices")
parser.add_argument("--base", required=True)
parser.add_argument("--tag")
args = parser.parse_args()
indices = [int(value) for value in args.phases.split(",")]
tag = args.tag or "_".join(str(value) for value in indices)
target = ROOT / "analysis" / f"trial_isostrain_p{tag}.gpx"

project = G2.G2Project(args.base, newgpx=str(target))
hist = project.histogram(0)
controls = project.data["Controls"]["data"]
controls["max cyc"] = 40
controls["min dM/M"] = 1e-6
controls["shift factor"] = 0.20
project.set_Frozen()

for index in indices:
    phase = project.phase(index)
    hap = phase.data["Histograms"][hist.name]
    values = [float(hap["Mustrain"][1][0])]
    if hap["Mustrain"][0] == "uniaxial":
        values.append(float(hap["Mustrain"][1][1]))
    start = sum(values) / len(values)
    phase.setSampleProfile(hist.name, "microstrain", "isotropic", start, LGmix=1.0)
    phase.set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    project.set_Controls("parmMin", 300.0, variable=f"{phase.id}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;i")

project.refine()
project.save()
project = G2.G2Project(str(target))
project.data["Controls"]["data"]["shift factor"] = 0.15
project.set_Frozen()
project.refine()
project.save()

hist = project.histogram(0)
print("ISOTROPIC_STRAIN", json.dumps({
    "phases": indices,
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "mustrain": {
        project.phase(index).name:
        project.phase(index).data["Histograms"][hist.name]["Mustrain"]
        for index in indices
    },
    "max_shift_over_esd": project.data["Covariance"]["data"]["Rvals"].get("Max shft/sig"),
    "frozen": [str(v) for v in project.get_Frozen()],
}, sort_keys=True))
