import argparse

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("base")
parser.add_argument("trial")
parser.add_argument("candidate")
parser.add_argument("--n", type=int, default=60)
args = parser.parse_args()

base = G2.G2Project(args.base).histogram(0)
trial = G2.G2Project(args.trial).histogram(0)
xb, ob, wb, cb, bb, db = [np.asarray(v, float) for v in base.data["data"][1][:6]]
xt, ot, wt, ct, bt, dt = [np.asarray(v, float) for v in trial.data["data"][1][:6]]
if not np.allclose(xb, xt):
    raise ValueError("grids differ")

lists = trial.data["Reflection Lists"]
candidate = np.asarray(lists[args.candidate]["RefList"], float)
other_positions = {
    name: np.asarray(block["RefList"], float)[:, 5]
    for name, block in lists.items() if name != args.candidate
}

# Column 9 is the calculated intensity-like reflection quantity in these PXC
# lists. Group alpha-doublet/accidental near-degeneracies by reporting the
# strongest reflections first and a local weighted-SSE change.
order = np.argsort(candidate[:, 9])[::-1]
print("h k l position intensity nearest_main local_delta_chi2 base_z trial_z")
for row in candidate[order[:args.n]]:
    pos = row[5]
    i = int(np.argmin(np.abs(xb - pos)))
    window = np.abs(xb - pos) <= 0.12
    base_chi = np.sum(wb[window] * (ob[window] - cb[window])**2)
    trial_chi = np.sum(wt[window] * (ot[window] - ct[window])**2)
    main = other_positions.get("WO3_monoclinic", np.array([np.nan]))
    nearest = float(main[np.argmin(np.abs(main - pos))] - pos)
    base_z = (ob[i] - cb[i]) / np.sqrt(max(ob[i], 1.0))
    trial_z = (ot[i] - ct[i]) / np.sqrt(max(ot[i], 1.0))
    print(f"{int(row[0]):3d} {int(row[1]):3d} {int(row[2]):3d} {pos:9.4f} {row[9]:11.2f} "
          f"{nearest:+9.4f} {base_chi-trial_chi:12.2f} {base_z:8.2f} {trial_z:8.2f}")
