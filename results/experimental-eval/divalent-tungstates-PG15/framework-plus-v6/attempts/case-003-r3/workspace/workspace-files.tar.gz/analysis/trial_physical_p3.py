from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
parser = argparse.ArgumentParser()
parser.add_argument("variant", choices=("p1_fitted", "p1_parent"))
args = parser.parse_args()

target = ANALYSIS / f"trial_physical_p3_{args.variant}.gpx"
project = G2.G2Project(str(ROOT / "final.gpx"), newgpx=str(target))
project.set_Controls("cycles", 24)
project.set_Frozen()

if args.variant == "p1_fitted":
    source_phase = project.phase(1)
else:
    source_phase = G2.G2Project(str(ANALYSIS / "normalized.gpx")).phase(1)

destination_phase = project.phase(3)
for destination_atom, source_atom in zip(destination_phase.atoms(), source_phase.atoms()):
    if destination_atom.element != source_atom.element:
        raise RuntimeError("Incompatible WO3 atom ordering")
    destination_atom.coordinates = list(source_atom.coordinates)
    destination_atom.refinement_flags = " "

history = []
for index in range(4):
    project.refine()
    history.append(project.histogram(0).residuals.get("wR"))
project.save()
destination_phase.export_CIF(
    str(ANALYSIS / f"physical_p3_{args.variant}.cif"), quickmode=True
)

hist = project.histogram(0)
products = {
    phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
    * phase.data["General"]["Mass"]
    for phase in project.phases()
}
total = sum(products.values())
print("PHYSICAL_P3", json.dumps({
    "variant": args.variant,
    "wR_history_percent": history,
    "fractions": {name: value / total for name, value in products.items()},
    "frozen": [str(v) for v in project.get_Frozen()],
}, sort_keys=True))
