from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
parser = argparse.ArgumentParser()
parser.add_argument("variant", choices=("p0wide", "medium", "hybrid", "wide"))
args = parser.parse_args()

target = ANALYSIS / f"trial_coordinate_{args.variant}.gpx"
project = G2.G2Project(
    str(ANALYSIS / "trial_calcite_0p02_tex001.gpx"),
    newgpx=str(target),
)

sources = {}
if args.variant == "p0wide":
    sources[0] = ("trial_bounded_atoms_p0_0p008.gpx", "all")
elif args.variant == "medium":
    sources[0] = ("trial_bounded_atoms_p0_0p006.gpx", "all")
    sources[1] = ("trial_bounded_atoms_p1_0p006.gpx", "all")
elif args.variant == "hybrid":
    sources[0] = ("trial_bounded_atoms_p0_0p008.gpx", "all")
    sources[1] = ("trial_bounded_atoms_p1_0p008.gpx", "W")
elif args.variant == "wide":
    sources[0] = ("trial_bounded_atoms_p0_0p008.gpx", "all")
    sources[1] = ("trial_bounded_atoms_p1_0p008.gpx", "all")

for phase_id, (filename, selection) in sources.items():
    source = G2.G2Project(str(ANALYSIS / filename))
    destination_phase = project.phase(phase_id)
    source_phase = source.phase(phase_id)
    for destination_atom, source_atom in zip(destination_phase.atoms(), source_phase.atoms()):
        if selection == "all" or destination_atom.element == selection:
            destination_atom.coordinates = source_atom.coordinates
        destination_atom.refinement_flags = " "

project.set_Frozen()
project.set_Controls("cycles", 16)
for _ in range(3):
    project.refine()

hist = project.histogram(0)
print("COORDINATE_HYBRID_SUMMARY", json.dumps({
    "variant": args.variant,
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "frozen": project.get_Frozen(),
    "phases": [{
        "name": phase.name,
        "atoms": [{"label": atom.label, "xyz": list(atom.coordinates)} for atom in phase.atoms()],
    } for phase in project.phases()],
}, sort_keys=True))
project.save()
