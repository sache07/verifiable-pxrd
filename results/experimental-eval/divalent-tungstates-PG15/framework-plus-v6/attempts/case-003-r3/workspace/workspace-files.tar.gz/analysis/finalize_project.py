from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "trial_sizegrid_p3_10p0.gpx"
FINAL = ROOT / "final.gpx"


def fractions(project):
    hist = project.histogram(0)
    products = {
        phase.name: (
            phase.data["Histograms"][hist.name]["Scale"][0]
            * phase.data["General"]["Mass"]
        )
        for phase in project.phases()
    }
    total = sum(products.values())
    return {name: value / total for name, value in products.items()}


def enforce_physical_model(project):
    """Reapply the accepted model and the documented physical bounds."""
    project.set_Controls("cycles", 24)
    project.set_Frozen()
    hist = project.histogram(0)

    # Include every supplied observation in the final fit and saved profile.
    x = np.asarray(hist.data["data"][1][0], dtype=float)
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]

    inst = hist.data["Instrument Parameters"][0]
    for key, value in {
        "Lam1": 1.540598,
        "Lam2": 1.544426,
        "I(L2)/I(L1)": 0.5,
        "Polariz.": 0.5,
        "U": 0.001,
        "V": 0.0,
        "X": 1.0,
        "Y": 0.0,
        "Zero": 0.0,
    }.items():
        inst[key][1] = value
        inst[key][2] = False
    inst["W"][2] = True
    inst["SH/L"][2] = True

    sample = hist.data["Sample Parameters"]
    sample["Shift"][1] = True
    sample["SurfRoughA"] = [0.05, False]
    sample["SurfRoughB"][1] = True

    project.set_Controls("parmMin", 2.0, variable=":0:W")
    project.set_Controls("parmMax", 40.0, variable=":0:W")
    project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.10, variable=":0:SH/L")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
        if hap["Size"][2][0]:
            project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
            project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:0:Size;i")
        if hap["Mustrain"][2][0]:
            project.set_Controls("parmMin", 300.0, variable=f"{phase.id}:0:Mustrain;i")
            project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;i")
        if hap["Mustrain"][0] == "uniaxial" and hap["Mustrain"][2][1]:
            project.set_Controls("parmMin", 300.0, variable=f"{phase.id}:0:Mustrain;a")
            project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;a")
        if hap["Pref.Ori."][2]:
            project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")

    # The second WO3 component's size broadening was unsupported. Keep the
    # term at its neutral large-size value, fixed, rather than interpreting it.
    p3_hap = project.phase(3).data["Histograms"][hist.name]
    p3_hap["Size"][0] = "isotropic"
    p3_hap["Size"][1][0] = 10.0
    project.phase(3).clear_HAP_refinements({"Size": True})


project = G2.G2Project(str(BASE), newgpx=str(FINAL))
enforce_physical_model(project)

history = []
for pass_index in range(3):
    project.refine()
    history.append({
        "pass": pass_index + 1,
        "wR_percent": project.histogram(0).residuals.get("wR"),
        "fractions": fractions(project),
        "frozen": [str(v) for v in project.get_Frozen()],
    })
project.save()

# Save/reopen/replay the accepted full-range refinement once more. This is the
# exact project subsequently used for every export.
project = G2.G2Project(str(FINAL))
enforce_physical_model(project)
project.refine()
project.save()
history.append({
    "pass": "reopened",
    "wR_percent": project.histogram(0).residuals.get("wR"),
    "fractions": fractions(project),
    "frozen": [str(v) for v in project.get_Frozen()],
})

print("FINAL_REFINEMENT", json.dumps(history, indent=2, sort_keys=True))
