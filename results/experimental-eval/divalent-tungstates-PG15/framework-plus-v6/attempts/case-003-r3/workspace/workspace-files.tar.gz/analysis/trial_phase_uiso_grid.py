from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int)
parser.add_argument("uiso", type=float)
parser.add_argument("--base", required=True)
args = parser.parse_args()

tag = str(args.uiso).replace(".", "p")
target = ROOT / "analysis" / f"trial_uisogrid_p{args.phase}_{tag}.gpx"
project = G2.G2Project(args.base, newgpx=str(target))
project.set_Controls("cycles", 16)
project.set_Frozen()
phase = project.phase(args.phase)
for atom in phase.atoms():
    atom.ADP = args.uiso
    atom.refinement_flags = " "

for _ in range(3):
    project.refine()

hist = project.histogram(0)
products = {
    p.name: p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
    for p in project.phases()
}
total = sum(products.values())
print("UISO_GRID_SUMMARY", json.dumps({
    "phase": phase.name,
    "uiso": args.uiso,
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "fractions": {name: value / total for name, value in products.items()},
    "frozen": project.get_Frozen(),
}, sort_keys=True))
project.save()
