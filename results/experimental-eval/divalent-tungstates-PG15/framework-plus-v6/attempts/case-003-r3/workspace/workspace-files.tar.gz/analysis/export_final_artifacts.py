from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "final.gpx"
PHASE_FILES = [
    "phase_CaWO4_scheelite.cif",
    "phase_WO3_monoclinic_broad.cif",
    "phase_CaCO3_calcite.cif",
    "phase_WO3_monoclinic_sharp.cif",
]

project = G2.G2Project(str(PROJECT))
hist = project.histogram(0)

for phase, filename in zip(project.phases(), PHASE_FILES):
    phase.export_CIF(str(ROOT / filename), quickmode=True)

x, observed, weights, calculated, background, saved_difference = [
    np.asarray(column, dtype=float) for column in hist.data["data"][1][:6]
]
if not np.allclose(observed - calculated, saved_difference, rtol=0, atol=1e-7):
    raise RuntimeError("GSAS-II saved difference array is inconsistent")
np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x, observed, calculated, observed - calculated)),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference",
    comments="",
    fmt=["%.8f", "%.10g", "%.10g", "%.10g"],
)

products = {
    phase.name: (
        phase.data["Histograms"][hist.name]["Scale"][0]
        * phase.data["General"]["Mass"]
    )
    for phase in project.phases()
}
total = sum(products.values())
fractions = {name: value / total for name, value in products.items()}

covariance = project.data["Covariance"]["data"]
rvals = covariance["Rvals"]
independent_weights = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(independent_weights * (observed - calculated) ** 2))
denominator = float(np.sum(independent_weights * observed**2))
summary = {
    "histogram": hist.name,
    "phase_files": PHASE_FILES,
    "fractions": fractions,
    "gsas": {
        "rp_percent": hist.residuals.get("R"),
        "rwp_percent": hist.residuals.get("wR"),
        "chi_square": rvals.get("chisq"),
        "n_observations": rvals.get("Nobs"),
        "n_variables": rvals.get("Nvars"),
        "goodness_of_fit": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
    },
    "saved_profile": {
        "rwp_percent": 100.0 * np.sqrt(chi_square / denominator),
        "chi_square": chi_square,
        "point_count": len(x),
        "minimum_calculated": float(np.min(calculated)),
    },
    "frozen": [str(v) for v in project.get_Frozen()],
}
print("FINAL_EXPORT", json.dumps(summary, indent=2, sort_keys=True))
