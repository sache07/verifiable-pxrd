from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
parser = argparse.ArgumentParser()
parser.add_argument("cod_id", choices=("1528915", "2311041", "2106293", "2107312", "1010618"))
args = parser.parse_args()


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


target = ROOT / "analysis" / f"trial_wo3_{args.cod_id}.gpx"
project = G2.G2Project(newgpx=str(target))
for name, cod_id in [
    ("CaWO4_scheelite", "7219229"),
    (f"WO3_{args.cod_id}", args.cod_id),
    ("CaCO3_calcite", "1547347"),
]:
    project.add_phase(str(cod_path(cod_id)), phasename=name, fmthint="CIF")
hist = project.add_powder_histogram(
    str(ROOT / "analysis" / "pattern.xye"),
    str(ROOT / "analysis" / "instrument.instprm"),
    phases="all",
    fmthint="xye",
)
hist.set_refinements({
    "Limits": [10.0, 100.0],
    "Background": {
        "type": "chebyschev-1",
        "no. coeffs": 8,
        "coeffs": [1000.0, -300.0, 200.0, -100.0, 50.0, 0.0, 0.0, 0.0],
        "refine": True,
    },
})
sample = hist.data["Sample Parameters"]
sample["Type"] = "Bragg-Brentano"
sample["Gonio. radius"] = 200.0
sample["Shift"] = [-550.0, True]
sample["Transparency"] = [0.0, False]
sample["SurfRoughA"] = [0.0, False]
sample["SurfRoughB"] = [0.0, False]
sample["Scale"] = [1.0, False]
inst = hist.data["Instrument Parameters"][0]
inst["U"] = [0.001, 0.001, False]
inst["W"] = [12.0, 12.0, False]
inst["X"] = [1.0, 1.0, False]

project.set_Controls("cycles", 14)
for variable, low, high in [
    (":0:Shift", -800.0, 800.0),
    (":0:W", 2.0, 40.0),
]:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)

for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    phase.setSampleProfile(hist.name, "size", "isotropic", 10.0, LGmix=1.0)
    phase.setSampleProfile(hist.name, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    phase.set_refinements({"Cell": True})
    project.set_Controls("parmMin", 1e-8, variable=f"{phase.id}:0:Scale")

# Source-change baseline: reconverge smooth background, scales, displacement, cells.
for _ in range(3):
    project.set_Frozen()
    project.refine()

# Apply the same restrained profile family to every candidate record.
specs = [(0.04, 4400.0, False, True), (0.35, 7400.0, True, True), (10.0, 5000.0, False, True)]
for phase, (size, strain, refine_size, refine_strain) in zip(project.phases(), specs):
    phase.setSampleProfile(hist.name, "size", "isotropic", size, LGmix=1.0)
    phase.setSampleProfile(hist.name, "microstrain", "isotropic", strain, LGmix=1.0)
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": refine_size},
        "Mustrain": {"type": "isotropic", "refine": refine_strain},
    })
    if refine_size:
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 2.0, variable=f"{phase.id}:0:Size;i")
    if refine_strain:
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 12000.0, variable=f"{phase.id}:0:Mustrain;i")
hist.set_refinements({"Instrument Parameters": ["W"]})
for _ in range(3):
    project.set_Frozen()
    project.refine()

hist = project.histogram(0)
phases = []
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    phases.append({
        "name": phase.name,
        "cell": phase.get_cell(),
        "scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
    })
summary = {
    "cod_id": args.cod_id,
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "phases": phases,
    "shift": hist.data["Sample Parameters"]["Shift"],
    "W": hist.data["Instrument Parameters"][0]["W"],
    "frozen": project.get_Frozen(),
}
print("WO3_RECORD_SUMMARY", json.dumps(summary, sort_keys=True))
project.save()
