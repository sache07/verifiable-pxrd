from pathlib import Path
import argparse

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


parser = argparse.ArgumentParser()
parser.add_argument("cifs", nargs="+")
args = parser.parse_args()
calculator = XRDCalculator(wavelength=1.540598)

for filename in args.cifs:
    path = Path(filename)
    print("CANDIDATE", path.stem, path)
    try:
        structure = Structure.from_file(path, primitive=False)
        analyzer = SpacegroupAnalyzer(structure, symprec=0.05)
        distances = structure.distance_matrix.copy()
        distances[distances < 1e-8] = np.inf
        print(" formula", structure.composition.formula)
        print(" reduced", structure.composition.reduced_formula)
        print(" space_group", analyzer.get_space_group_symbol(), analyzer.get_space_group_number())
        print(" cell", structure.lattice.parameters)
        print(" density", structure.density, "min_distance", np.min(distances))
        pattern = calculator.get_pattern(structure, two_theta_range=(10, 100), scaled=True)
        order = np.argsort(pattern.y)[::-1]
        for i in order[:30]:
            hkls = ",".join(str(entry["hkl"]) for entry in pattern.hkls[i])
            print(f" {pattern.x[i]:8.4f} {pattern.y[i]:8.3f} {hkls}")
    except Exception as exc:
        print(" ERROR", type(exc).__name__, str(exc))
