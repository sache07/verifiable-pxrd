from pathlib import Path
import argparse

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("project")
parser.add_argument("phase", type=int)
parser.add_argument("output")
args = parser.parse_args()

project = G2.G2Project(args.project)
phase = project.phase(args.phase)
output = Path(args.output).resolve()
phase.export_CIF(str(output), quickmode=True)
print(output)
