from pathlib import Path
import argparse
from collections import defaultdict

import numpy as np
from pymatgen.core import Structure


parser = argparse.ArgumentParser()
parser.add_argument("cifs", nargs="+")
args = parser.parse_args()

for filename in args.cifs:
    structure = Structure.from_file(filename, primitive=False)
    print("STRUCTURE", Path(filename).name, structure.composition.reduced_formula,
          "density", float(structure.density), "sites", len(structure))
    pair_distances = defaultdict(list)
    for i, site in enumerate(structure):
        for neighbor in structure.get_neighbors(site, 3.2):
            j = int(neighbor.index)
            if i < j or (i == j and tuple(neighbor.image) > (0, 0, 0)):
                pair = tuple(sorted((site.specie.symbol, neighbor.specie.symbol)))
                pair_distances[pair].append(float(neighbor.nn_distance))
    for pair in sorted(pair_distances):
        values = np.asarray(pair_distances[pair])
        print(" pair", "-".join(pair), "min", values.min(), "q10", np.quantile(values, .1),
              "count_lt_1p8", int(np.sum(values < 1.8)))
    for i, site in enumerate(structure):
        if site.specie.symbol != "W":
            continue
        distances = sorted(float(n.nn_distance) for n in structure.get_neighbors(site, 3.0)
                           if n.specie.symbol == "O")
        print(" W_site", i, "six_nearest_O", [round(v, 4) for v in distances[:6]],
              "seventh", round(distances[6], 4) if len(distances) > 6 else None)
