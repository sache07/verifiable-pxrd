from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int, choices=(0, 1, 2))
parser.add_argument("--bound", type=float, required=True)
parser.add_argument("--base", required=True)
args = parser.parse_args()

tag = str(args.bound).replace(".", "p")
target = ANALYSIS / f"trial_revisit_coords_p{args.phase}_{tag}.gpx"
project = G2.G2Project(args.base, newgpx=str(target))
parent_project = G2.G2Project(str(ANALYSIS / "normalized.gpx"))
project.set_Controls("cycles", 20)
project.set_Frozen()
phase = project.phase(args.phase)
parent_phase = parent_project.phase(args.phase)
starts = [list(atom.coordinates) for atom in phase.atoms()]
parents = [list(atom.coordinates) for atom in parent_phase.atoms()]

phase.set_refinements({"Atoms": {"all": "X"}})
for i, atom in enumerate(phase.atoms()):
    for j, axis in enumerate("xyz"):
        variable = f"{phase.id}::dA{axis}:{i}"
        project.set_Controls("parmMin", parents[i][j] - args.bound, variable=variable)
        project.set_Controls("parmMax", parents[i][j] + args.bound, variable=variable)

for _ in range(3):
    project.refine()
for atom in phase.atoms():
    atom.refinement_flags = " "
project.set_Frozen()
project.set_Controls("cycles", 12)
project.refine()

hist = project.histogram(0)
print("REVISIT_COORDINATES_SUMMARY", json.dumps({
    "phase": phase.name,
    "bound_fractional": args.bound,
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "frozen": project.get_Frozen(),
    "atoms": [{
        "label": atom.label,
        "parent": parents[i],
        "start": starts[i],
        "final": list(atom.coordinates),
        "delta_parent": [float(v - p) for v, p in zip(atom.coordinates, parents[i])],
    } for i, atom in enumerate(phase.atoms())],
}, sort_keys=True))
project.save()
