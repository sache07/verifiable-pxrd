from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
project = G2.G2Project(
    str(ANALYSIS / "trial_bounded_atoms_p3_0p004_rechallenge.gpx"),
    newgpx=str(ANALYSIS / "four_phase_coordinates.gpx"),
)
parent = G2.G2Project(str(ANALYSIS / "normalized.gpx"))
sources = {
    0: G2.G2Project(str(ANALYSIS / "trial_revisit_coords_p0_0p004.gpx")),
    1: G2.G2Project(str(ANALYSIS / "trial_revisit_coords_p1_0p004.gpx")),
    2: G2.G2Project(str(ANALYSIS / "trial_revisit_coords_p2_0p008.gpx")),
}

# Phase 1's unconstrained box result was marginally above the documented
# aggregate element-wise RMS. Scale its fitted displacement vectors uniformly
# to 0.04 A for W and 0.05 A for O, matching the synthetic perturbation rule.
phase1_factors = {
    "W": 0.040 / 0.043124410125684735,
    "O": 0.050 / 0.056359214925370806,
}

for phase_id, source in sources.items():
    destination_phase = project.phase(phase_id)
    source_phase = source.phase(phase_id)
    parent_phase = parent.phase(phase_id)
    for atom, source_atom, parent_atom in zip(
            destination_phase.atoms(), source_phase.atoms(), parent_phase.atoms()):
        if phase_id == 1:
            factor = phase1_factors[atom.element]
            coords = []
            for start, fitted in zip(parent_atom.coordinates, source_atom.coordinates):
                delta = fitted - start
                delta -= round(delta)
                coords.append(start + factor * delta)
            atom.coordinates = coords
        else:
            atom.coordinates = source_atom.coordinates
        atom.refinement_flags = " "

project.set_Frozen()
project.set_Controls("cycles", 16)
for _ in range(4):
    project.refine()

hist = project.histogram(0)
products = {
    phase.name: phase.data["Histograms"][hist.name]["Scale"][0] * phase.data["General"]["Mass"]
    for phase in project.phases()
}
total = sum(products.values())
print("FOUR_PHASE_COORDINATE_SUMMARY", json.dumps({
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "fractions": {name: value / total for name, value in products.items()},
    "frozen": project.get_Frozen(),
    "phases": [{
        "name": phase.name,
        "atoms": [{"label": atom.label, "xyz": list(atom.coordinates), "uiso": atom.ADP}
                  for atom in phase.atoms()],
    } for phase in project.phases()],
}, sort_keys=True))
project.save()
