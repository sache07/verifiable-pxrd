from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    cod_id = str(cod_id)
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


project_path = ROOT / "analysis" / "initial.gpx"
project = G2.G2Project(newgpx=str(project_path))
phase_specs = [
    ("CaWO4_scheelite", "7219229"),
    ("WO3_monoclinic", "1528915"),
    ("CaCO3_calcite", "1547347"),
]
for name, cod_id in phase_specs:
    project.add_phase(str(cod_path(cod_id)), phasename=name, fmthint="CIF")

hist = project.add_powder_histogram(
    str(ROOT / "analysis" / "pattern.xye"),
    str(ROOT / "analysis" / "instrument.instprm"),
    phases="all",
    fmthint="xye",
)
hist.set_refinements({
    "Limits": [10.0, 100.0],
    "Background": {
        "type": "chebyschev-1",
        "no. coeffs": 8,
        "coeffs": [1000.0, -300.0, 200.0, -100.0, 50.0, 0.0, 0.0, 0.0],
        "refine": False,
    },
})
sample = hist.data["Sample Parameters"]
sample["Type"] = "Bragg-Brentano"
sample["Gonio. radius"] = 200.0
sample["Shift"] = [0.0, False]
sample["Transparency"] = [0.0, False]
sample["SurfRoughA"] = [0.0, False]
sample["SurfRoughB"] = [0.0, False]
sample["Scale"] = [1.0, False]

for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, False]
    phase.setSampleProfile(hist.name, "size", "isotropic", 1000.0, LGmix=1.0)
    phase.setSampleProfile(hist.name, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]

project.set_Controls("cycles", 0)
project.refine()
hist = project.histogram(0)
arrays = hist.data["data"][1]
print("histogram", hist.name)
print("residuals", hist.residuals)
print("max observed/calculated/background", *(float(np.max(arrays[i])) for i in (1, 3, 4)))
print("sample", hist.data["Sample Parameters"])
print("instrument", hist.data["Instrument Parameters"][0])
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    print(phase.name, phase.get_cell(), "mass", phase.data["General"]["Mass"], "scale", hap["Scale"])
project.save()
