from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
project = G2.G2Project(
    str(ROOT / "analysis" / "cells.gpx"),
    newgpx=str(ROOT / "analysis" / "profiles.gpx"),
)
hist = project.histogram(0)
project.set_Controls("cycles", 16)
project.set_Frozen()

starts = {
    "CaWO4_scheelite": (0.05, 3700.0),
    "WO3_monoclinic": (0.36, 7000.0),
    "CaCO3_calcite": (0.41, 3800.0),
}
for phase in project.phases():
    size, strain = starts[phase.name]
    phase.setSampleProfile(hist.name, "size", "isotropic", size, LGmix=1.0)
    phase.setSampleProfile(hist.name, "microstrain", "isotropic", strain, LGmix=1.0)
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
    project.set_Controls("parmMax", 2.0, variable=f"{phase.id}:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
    project.set_Controls("parmMax", 12000.0, variable=f"{phase.id}:0:Mustrain;i")


def report(label):
    h = project.histogram(0)
    print("PROFILE_STAGE", label, json.dumps(h.residuals, sort_keys=True))
    print("instrument", {k: h.data["Instrument Parameters"][0][k]
          for k in ("U", "V", "W", "X", "SH/L")})
    for p in project.phases():
        hap = p.data["Histograms"][h.name]
        print(p.name, "size", hap["Size"], "mustrain", hap["Mustrain"],
              "scale", hap["Scale"], "cell", p.get_cell())
    print("shift", h.data["Sample Parameters"]["Shift"], "frozen", project.get_Frozen())


# Compare/reconverge the accepted phase-width terms with the common profile fixed.
for _ in range(3):
    project.set_Frozen()
    project.refine()
report("all_phase_widths_common_fixed")

# X is fixed because it is exactly confounded with a common offset in isotropic
# Lorentzian crystallite-size broadening. Refine the identifiable Gaussian U/W pair.
project.set_Controls("parmMin", 0.001, variable=":0:U")
project.set_Controls("parmMax", 40.0, variable=":0:U")
project.set_Controls("parmMin", 2.0, variable=":0:W")
project.set_Controls("parmMax", 40.0, variable=":0:W")
hist.set_refinements({"Instrument Parameters": ["U", "W"]})
for _ in range(3):
    project.set_Frozen()
    project.refine()
report("uw_rechallenged")
project.save()
