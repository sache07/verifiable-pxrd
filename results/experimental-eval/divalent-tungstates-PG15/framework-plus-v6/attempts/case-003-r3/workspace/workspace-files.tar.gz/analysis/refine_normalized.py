from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
PARENTS = ROOT / "analysis" / "parents"
target = ROOT / "analysis" / "normalized.gpx"
project = G2.G2Project(newgpx=str(target))
for name, filename in [
    ("CaWO4_scheelite", "CaWO4_scheelite_7219229.cif"),
    ("WO3_monoclinic", "WO3_monoclinic_2311041.cif"),
    ("CaCO3_calcite", "CaCO3_calcite_1547347.cif"),
]:
    project.add_phase(str(PARENTS / filename), phasename=name, fmthint="CIF")

hist = project.add_powder_histogram(
    str(ROOT / "analysis" / "pattern.xye"),
    str(ROOT / "analysis" / "instrument.instprm"),
    phases="all",
    fmthint="xye",
)
hist.set_refinements({
    "Limits": [10.0, 100.0],
    "Background": {
        "type": "chebyschev-1",
        "no. coeffs": 8,
        "coeffs": [1000.0, -300.0, 200.0, -100.0, 50.0, 0.0, 0.0, 0.0],
        "refine": True,
    },
})
sample = hist.data["Sample Parameters"]
sample["Type"] = "Bragg-Brentano"
sample["Gonio. radius"] = 200.0
sample["Shift"] = [-550.0, True]
sample["Transparency"] = [0.0, False]
sample["SurfRoughA"] = [0.0, False]
sample["SurfRoughB"] = [0.0, False]
sample["Scale"] = [1.0, False]
inst = hist.data["Instrument Parameters"][0]
inst["U"] = [0.001, 0.001, False]
inst["W"] = [13.0, 13.0, False]
inst["X"] = [1.0, 1.0, False]
inst["SH/L"] = [0.03, 0.03, False]

project.set_Controls("cycles", 16)
for variable, low, high in [
    (":0:Shift", -800.0, 800.0),
    (":0:W", 2.0, 40.0),
    (":0:SH/L", 0.001, 0.2),
    (":0:Polariz.", 0.5, 1.0),
    (":0:SurfRoughA", 0.05, 0.6),
    (":0:SurfRoughB", 0.02, 0.5),
]:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)

for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    phase.setSampleProfile(hist.name, "size", "isotropic", 10.0, LGmix=1.0)
    phase.setSampleProfile(hist.name, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    phase.set_refinements({"Cell": True})
    project.set_Controls("parmMin", 1e-8, variable=f"{phase.id}:0:Scale")

# Rebuild source-change baseline.
for _ in range(3):
    project.set_Frozen()
    project.refine()

# Accepted phase profile: isotropic CaWO4/calcite, uniaxial [010] WO3.
profile_specs = [
    ("isotropic", 0.04, 6500.0, None, None, False),
    ("uniaxial", 0.22, 5800.0, 3900.0, [0, 1, 0], True),
    ("isotropic", 10.0, 3800.0, None, None, False),
]
for phase, (mode, size, eq_strain, ax_strain, axis, refine_size) in zip(project.phases(), profile_specs):
    phase.setSampleProfile(hist.name, "size", "isotropic", size, LGmix=1.0)
    if mode == "uniaxial":
        phase.setSampleProfile(hist.name, "microstrain", "uniaxial", eq_strain, ax_strain, axis, LGmix=1.0)
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": refine_size},
            "Mustrain": {"type": "uniaxial", "refine": True, "direction": axis},
        })
        for suffix in ("i", "a"):
            project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;{suffix}")
            project.set_Controls("parmMax", 32000.0, variable=f"{phase.id}:0:Mustrain;{suffix}")
    else:
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", eq_strain, LGmix=1.0)
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": refine_size},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 12000.0, variable=f"{phase.id}:0:Mustrain;i")
    if refine_size:
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 2.0, variable=f"{phase.id}:0:Size;i")
hist.set_refinements({"Instrument Parameters": ["W"]})
for _ in range(3):
    project.set_Frozen()
    project.refine()

# Rechallenge shared intensity/asymmetry terms after the profile inventory changed.
inst["Polariz."][1] = 0.65
hist.set_refinements({"Instrument Parameters": ["Polariz.", "SH/L"]})
sample["SurfRoughA"] = [0.10, True]
sample["SurfRoughB"] = [0.04, True]
for _ in range(3):
    project.set_Frozen()
    project.refine()

hist = project.histogram(0)
summary = {
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "sample": hist.data["Sample Parameters"],
    "instrument": hist.data["Instrument Parameters"][0],
    "frozen": project.get_Frozen(),
    "phases": [],
}
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    summary["phases"].append({
        "name": phase.name,
        "cell": phase.get_cell(),
        "scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "atoms": [{"label": a.label, "xyz": list(a.coordinates), "adp": a.ADP} for a in phase.atoms()],
    })
print("NORMALIZED_SUMMARY", json.dumps(summary, sort_keys=True))
project.save()
