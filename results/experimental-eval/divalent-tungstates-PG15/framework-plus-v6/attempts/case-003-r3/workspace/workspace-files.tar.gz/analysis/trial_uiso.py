from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int, choices=(0, 1, 2))
args = parser.parse_args()

target = ROOT / "analysis" / f"trial_uiso_p{args.phase}.gpx"
project = G2.G2Project(str(ROOT / "analysis" / "normalized.gpx"), newgpx=str(target))
project.set_Controls("cycles", 16)
project.set_Frozen()
hist = project.histogram(0)
hist.data["Instrument Parameters"][0]["Polariz."] = [0.5, 0.5, False]
hist.data["Sample Parameters"]["SurfRoughA"] = [0.05, False]
hist.data["Sample Parameters"]["SurfRoughB"][1] = True

phase = project.phase(args.phase)
for atom in phase.atoms():
    atom.ADP = 0.005
    atom.refinement_flags = "U"
variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
project.add_EquivConstr(variables)
for variable in variables:
    project.set_Controls("parmMin", 0.001, variable=variable)
    project.set_Controls("parmMax", 0.030, variable=variable)

for _ in range(3):
    project.set_Frozen()
    project.refine()

hist = project.histogram(0)
phase = project.phase(args.phase)
summary = {
    "phase": phase.name,
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "uiso": [float(a.ADP) for a in phase.atoms()],
    "frozen": project.get_Frozen(),
    "constraints": [str(c) for c in project.get_Constraints("Phase")],
}
print("UISO_TRIAL_SUMMARY", json.dumps(summary, sort_keys=True))
project.save()
