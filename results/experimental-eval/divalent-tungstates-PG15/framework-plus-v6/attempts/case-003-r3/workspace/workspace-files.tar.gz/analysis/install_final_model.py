from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "trial_isostrain_pp1_replay.gpx"
TARGET = ROOT / "final.gpx"

project = G2.G2Project(str(SOURCE), newgpx=str(TARGET))
project.set_Frozen()
controls = project.data["Controls"]["data"]
controls["max cyc"] = 40
controls["min dM/M"] = 1e-6
controls["shift factor"] = 0.15

# Remove stale axial bookkeeping after accepting the isotropic broad-WO3
# model. The active forward model already used only the isotropic value.
hist = project.histogram(0)
broad = project.phase(1).data["Histograms"][hist.name]["Mustrain"]
broad[0] = "isotropic"
broad[1][1] = 1000.0
broad[2][1] = False

project.save()

products = {
    phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
    * phase.data["General"]["Mass"]
    for phase in project.phases()
}
total = sum(products.values())
print("INSTALLED_FINAL", json.dumps({
    "source": str(SOURCE),
    "target": str(TARGET),
    "fractions": {name: value / total for name, value in products.items()},
    "frozen": [str(v) for v in project.get_Frozen()],
}, sort_keys=True))
