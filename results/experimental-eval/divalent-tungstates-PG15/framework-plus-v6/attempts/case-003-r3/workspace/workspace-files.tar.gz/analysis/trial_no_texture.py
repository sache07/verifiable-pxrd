from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int)
parser.add_argument("--base", required=True)
args = parser.parse_args()

target = ROOT / "analysis" / f"trial_notexture_p{args.phase}.gpx"
project = G2.G2Project(args.base, newgpx=str(target))
project.set_Controls("cycles", 16)
project.set_Frozen()
hist = project.histogram(0)
phase = project.phase(args.phase)
hap = phase.data["Histograms"][hist.name]
hap["Pref.Ori."][0] = "MD"
hap["Pref.Ori."][1] = 1.0
phase.clear_HAP_refinements({"Pref.Ori.": True})

for _ in range(3):
    project.refine()

hist = project.histogram(0)
print("NO_TEXTURE_SUMMARY", json.dumps({
    "phase": phase.name,
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "frozen": project.get_Frozen(),
}, sort_keys=True))
project.save()
