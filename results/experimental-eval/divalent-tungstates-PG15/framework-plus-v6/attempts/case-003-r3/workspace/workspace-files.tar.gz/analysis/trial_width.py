from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int, choices=(0, 1, 2))
parser.add_argument("mode", choices=("size", "strain", "both"))
args = parser.parse_args()

target = ROOT / "analysis" / f"trial_p{args.phase}_{args.mode}.gpx"
project = G2.G2Project(str(ROOT / "analysis" / "cells.gpx"), newgpx=str(target))
project.set_Controls("cycles", 12)
project.set_Frozen()
phase = project.phase(args.phase)
hist = project.histogram(0)

phase.setSampleProfile(hist.name, "size", "isotropic", 0.30, LGmix=1.0)
phase.setSampleProfile(hist.name, "microstrain", "isotropic", 1000.0, LGmix=1.0)
hap = phase.data["Histograms"][hist.name]
hap["Size"][2] = [False] * len(hap["Size"][2])
hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])

if args.mode in ("size", "both"):
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.set_Controls("parmMin", 0.02, variable=f"{phase.id}:0:Size;i")
    project.set_Controls("parmMax", 10.0, variable=f"{phase.id}:0:Size;i")
else:
    phase.setSampleProfile(hist.name, "size", "isotropic", 10.0, LGmix=1.0)

if args.mode in ("strain", "both"):
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
    project.set_Controls("parmMax", 20000.0, variable=f"{phase.id}:0:Mustrain;i")
else:
    phase.setSampleProfile(hist.name, "microstrain", "isotropic", 0.0, LGmix=1.0)

for _ in range(3):
    project.set_Frozen()
    project.refine()

phase = project.phase(args.phase)
hist = project.histogram(0)
hap = phase.data["Histograms"][hist.name]
summary = {
    "phase": phase.name,
    "mode": args.mode,
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "size": hap["Size"],
    "mustrain": hap["Mustrain"],
    "scale": hap["Scale"],
    "cell": phase.get_cell(),
    "shift": hist.data["Sample Parameters"]["Shift"],
    "frozen": project.get_Frozen(),
    "vary": project.data["Covariance"]["data"].get("varyList", []),
}
print("TRIAL_SUMMARY", json.dumps(summary, sort_keys=True))
project.save()
