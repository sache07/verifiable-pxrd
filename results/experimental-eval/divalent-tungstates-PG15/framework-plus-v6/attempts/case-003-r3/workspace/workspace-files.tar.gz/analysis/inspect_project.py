from pathlib import Path
import argparse
import json

import numpy as np
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIpwd as G2pwd


parser = argparse.ArgumentParser()
parser.add_argument("project")
parser.add_argument("--n-peaks", type=int, default=40)
args = parser.parse_args()

project = G2.G2Project(args.project)
hist = project.histogram(0)
x, obs, wt, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
resid = obs - calc
poisson = resid / np.sqrt(np.maximum(obs, 1.0))

print("PROJECT", Path(args.project).resolve())
print("HISTOGRAM", hist.name)
print("RESIDUALS", json.dumps(hist.residuals, sort_keys=True, default=str))
print("LIMITS", hist.data.get("Limits"))
print("INSTRUMENT")
for key, value in hist.data["Instrument Parameters"][0].items():
    if key in {"Lam", "Lam1", "Lam2", "I(L2)/I(L1)", "U", "V", "W", "X", "Y", "SH/L", "Polariz.", "Zero"}:
        print(" ", key, value)
print("SAMPLE", json.dumps(hist.data["Sample Parameters"], sort_keys=True, default=str))
print("BACKGROUND", json.dumps(hist.data["Background"], sort_keys=True, default=str))
print("VARY", json.dumps(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])))
print("FROZEN", json.dumps(project.get_Frozen(), default=str))

print("PHASES")
for phase in project.phases():
    general = phase.data["General"]
    hap = phase.data["Histograms"][hist.name]
    print(json.dumps({
        "id": phase.id,
        "name": phase.name,
        "formula": general.get("Pretty Formula"),
        "mass": general.get("Mass"),
        "cell": phase.get_cell(),
        "scale": hap.get("Scale"),
        "size": hap.get("Size"),
        "mustrain": hap.get("Mustrain"),
        "pref_ori": hap.get("Pref.Ori."),
        "atoms": [{
            "label": atom.label,
            "type": atom.element,
            "xyz": list(atom.coordinates),
            "adp": atom.ADP,
            "flags": atom.refinement_flags,
        } for atom in phase.atoms()],
    }, sort_keys=True, default=str))
    if hap.get("Mustrain", [None])[0] == "generalized":
        refs = np.asarray(hist.data["Reflection Lists"][phase.name]["RefList"], float)
        metric, _ = G2lat.cell2Gmat(general["Cell"][1:7])
        effective = G2pwd.getMustrain(refs[:, :3].T, metric, general["SGData"], hap["Mustrain"])
        print(" GENERALIZED_EFFECTIVE_MUSTRAIN", phase.name,
              "min", np.nanmin(effective), "max", np.nanmax(effective),
              "quantiles", np.nanquantile(effective, [0, .1, .5, .9, 1]).tolist(),
              "nonfinite", int(np.sum(~np.isfinite(effective))))

# Positive-only features are the most useful inventory challenge. Require enough
# separation to avoid reporting every point in a broad residual lobe.
indices, props = find_peaks(poisson, prominence=2.0, distance=max(1, int(0.08 / np.median(np.diff(x)))))
order = indices[np.argsort(poisson[indices])[::-1]]
reflection_positions = {}
for name, block in hist.data.get("Reflection Lists", {}).items():
    refs = np.asarray(block.get("RefList", []), dtype=float)
    reflection_positions[name] = refs[:, 5] if refs.size else np.array([])
print("TOP_POSITIVE_RESIDUAL_MAXIMA")
for i in order[:args.n_peaks]:
    nearest = []
    for name, positions in reflection_positions.items():
        if positions.size:
            j = int(np.argmin(np.abs(positions - x[i])))
            nearest.append(f"{name}:{positions[j] - x[i]:+.3f}")
    print(f"{x[i]:.5f} obs={obs[i]:.2f} calc={calc[i]:.2f} diff={resid[i]:.2f} "
          f"z={poisson[i]:.2f} nearest=" + ",".join(nearest))

print("REFLECTION_LIST_KEYS", list(hist.data.get("Reflection Lists", {})))
for name, block in hist.data.get("Reflection Lists", {}).items():
    refs = np.asarray(block.get("RefList", []), dtype=object)
    print("REFLECTION_LIST", name, "shape", refs.shape, "type", block.get("Type"))
    if refs.size:
        print(" FIRST", refs[:3].tolist())
