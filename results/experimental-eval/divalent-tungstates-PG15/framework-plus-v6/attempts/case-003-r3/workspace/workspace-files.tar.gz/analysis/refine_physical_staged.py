from pathlib import Path
import copy
import json
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
TARGET = ANALYSIS / "physical_staged_work.gpx"


def state(project, label):
    hist = project.histogram(0)
    products = {
        phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
        * phase.data["General"]["Mass"]
        for phase in project.phases()
    }
    total = sum(products.values())
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "label": label,
        "wR_percent": hist.residuals.get("wR"),
        "chi_square": rvals.get("chisq"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "fractions": {name: value / total for name, value in products.items()},
        "frozen": [str(v) for v in project.get_Frozen()],
    }
    print("PHYSICAL_STAGE", json.dumps(record, sort_keys=True), flush=True)
    return record


project = G2.G2Project(str(ROOT / "final.gpx"), newgpx=str(TARGET))
hist = project.histogram(0)

# The two components are interpreted as distinct domain populations of the
# same room-temperature monoclinic WO3 framework. Share the physically sound
# refined framework coordinates while retaining independent cells/profiles.
for destination_atom, source_atom in zip(project.phase(3).atoms(), project.phase(1).atoms()):
    if destination_atom.element != source_atom.element:
        raise RuntimeError("Incompatible WO3 atom ordering")
    destination_atom.coordinates = list(source_atom.coordinates)
    destination_atom.refinement_flags = " "

# Capture the accepted final refinement flags, then release them in stable
# blocks after the structure-factor change.
accepted = {
    "background": hist.data["Background"][0][1],
    "instrument": {
        key: value[2] for key, value in hist.data["Instrument Parameters"][0].items()
        if isinstance(value, list) and len(value) > 2
    },
    "sample": {
        key: value[1] for key, value in hist.data["Sample Parameters"].items()
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)
    },
    "phases": [],
}
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    accepted["phases"].append({
        "cell": phase.data["General"]["Cell"][0],
        "scale": hap["Scale"][1],
        "size2": copy.deepcopy(hap["Size"][2]),
        "size5": copy.deepcopy(hap["Size"][5]),
        "mustrain2": copy.deepcopy(hap["Mustrain"][2]),
        "mustrain5": copy.deepcopy(hap["Mustrain"][5]),
        "pref_ori": hap["Pref.Ori."][2],
    })

hist.data["Background"][0][1] = False
for value in hist.data["Instrument Parameters"][0].values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for key, value in hist.data["Sample Parameters"].items():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = False
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][2] = False

controls = project.data["Controls"]["data"]
controls["max cyc"] = 40
controls["min dM/M"] = 1e-6
controls["shift factor"] = 0.35
project.set_Frozen()

# Stage 1: smooth background and every crystalline scale.
hist.data["Background"][0][1] = accepted["background"]
for phase, flags in zip(project.phases(), accepted["phases"]):
    phase.data["Histograms"][hist.name]["Scale"][1] = flags["scale"]
project.refine()
state(project, "scales_background")
shutil.copy2(TARGET, ANALYSIS / "physical_stage1_scales.gpx")

# Stage 2: cells and the one angular displacement correction.
for phase, flags in zip(project.phases(), accepted["phases"]):
    phase.data["General"]["Cell"][0] = flags["cell"]
hist.data["Sample Parameters"]["Shift"][1] = accepted["sample"]["Shift"]
project.set_Frozen()
project.refine()
state(project, "cells_shift")
shutil.copy2(TARGET, ANALYSIS / "physical_stage2_cells.gpx")

# Stage 3: common peak profile, axial divergence and low-angle roughness.
for key in ("W", "SH/L"):
    hist.data["Instrument Parameters"][0][key][2] = accepted["instrument"][key]
hist.data["Sample Parameters"]["SurfRoughB"][1] = accepted["sample"]["SurfRoughB"]
project.set_Frozen()
project.refine()
state(project, "common_profile")
shutil.copy2(TARGET, ANALYSIS / "physical_stage3_common.gpx")

# Stage 4: only the phase-width and orientation terms that survived their
# individual challenges in the prior model.
for phase, flags in zip(project.phases(), accepted["phases"]):
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][2] = flags["size2"]
    hap["Size"][5] = flags["size5"]
    hap["Mustrain"][2] = flags["mustrain2"]
    hap["Mustrain"][5] = flags["mustrain5"]
    hap["Pref.Ori."][2] = flags["pref_ori"]
project.set_Frozen()
project.refine()
state(project, "all_accepted_terms")
project.save()
shutil.copy2(TARGET, ANALYSIS / "physical_stage4_all.gpx")

# Reopen and replay with all accepted terms. Keep both states for explicit
# backtracking if the nearly collinear phase scales make the replay worse.
project = G2.G2Project(str(TARGET))
project.data["Controls"]["data"]["shift factor"] = 0.20
project.set_Frozen()
project.refine()
state(project, "reopened_all_terms")
project.save()
shutil.copy2(TARGET, ANALYSIS / "physical_stage5_reopened.gpx")
