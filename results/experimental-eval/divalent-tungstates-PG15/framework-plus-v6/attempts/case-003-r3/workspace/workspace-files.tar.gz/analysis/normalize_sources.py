from pathlib import Path
import sys
import warnings

from pymatgen.io.cif import CifParser


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "learned" / "divalent-tungstates" / "runtime"))
from models import write_synthetic_model


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = ROOT / "analysis" / "parents"
OUT.mkdir(parents=True, exist_ok=True)

records = {
    "CaWO4_scheelite_7219229": "7219229",
    "WO3_monoclinic_2311041": "2311041",
    "WO3_monoclinic_1528915": "1528915",
    "WO3_monoclinic_1563541": "1563541",
    "WO3_triclinic_2106293": "2106293",
    "WO3_orthorhombic_2107312": "2107312",
    "WO3_monoclinic_1010618": "1010618",
    "CaCO3_calcite_1547347": "1547347",
    "CaO_1563196": "1563196",
    "Ca3WO6_1563081": "1563081",
    "Ca4p26W10O30_4030741": "4030741",
    "W18O49_1528166": "1528166",
    "W10O29_1538317": "1538317",
    "W3O8_2101050": "2101050",
}
for name, cod_id in records.items():
    source = COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = CifParser(
            source, occupancy_tolerance=1.0, site_tolerance=1e-5, frac_tolerance=0
        ).parse_structures(primitive=False, on_error="raise")[0]
    structure.remove_oxidation_states()
    target = OUT / f"{name}.cif"
    write_synthetic_model(structure, target)
    print(name, structure.composition.reduced_formula, len(structure), structure.density, target)
