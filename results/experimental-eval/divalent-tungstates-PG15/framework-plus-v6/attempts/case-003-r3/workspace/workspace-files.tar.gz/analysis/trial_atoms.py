from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int, choices=(0, 1, 2))
parser.add_argument("--uiso", action="store_true")
parser.add_argument("--source", default="profiles.gpx")
args = parser.parse_args()

suffix = "xu" if args.uiso else "x"
source_tag = Path(args.source).stem
target = ROOT / "analysis" / f"trial_atoms_{source_tag}_p{args.phase}_{suffix}.gpx"
project = G2.G2Project(str(ROOT / "analysis" / args.source), newgpx=str(target))
project.set_Controls("cycles", 16)
project.set_Frozen()
hist = project.histogram(0)

# Remove terms that the common-profile replay found unsupported or bound.
inst = hist.data["Instrument Parameters"][0]
inst["U"] = [0.001, 0.001, False]
for p in project.phases():
    hap = p.data["Histograms"][hist.name]
    if p.name == "CaWO4_scheelite":
        hap["Size"][1][0] = 0.04
        hap["Size"][2][0] = False
    elif p.name == "CaCO3_calcite":
        hap["Size"][1][0] = 10.0
        hap["Size"][2][0] = False

phase = project.phase(args.phase)
flags = "XU" if args.uiso else "X"
if args.uiso:
    for atom in phase.atoms():
        atom.uiso = 0.01
phase.set_refinements({"Atoms": {"all": flags}})

for _ in range(3):
    project.set_Frozen()
    project.refine()

phase = project.phase(args.phase)
hist = project.histogram(0)
atoms = []
for atom in phase.atoms():
    try:
        uiso = float(atom.uiso)
    except Exception:
        uiso = None
    atoms.append({
        "label": atom.label,
        "element": atom.element,
        "xyz": list(map(float, atom.coordinates)),
        "uiso": uiso,
        "flags": atom.refinement_flags,
    })
summary = {
    "phase": phase.name,
    "flags": flags,
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "atoms": atoms,
    "frozen": project.get_Frozen(),
    "vary": project.data["Covariance"]["data"].get("varyList", []),
}
print("ATOM_TRIAL_SUMMARY", json.dumps(summary, sort_keys=True))
project.save()
