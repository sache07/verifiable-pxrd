from pathlib import Path
import argparse
import json
import subprocess
import sys

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
WORKER = ROOT / "learned" / "divalent-tungstates" / "scorer" / "runtime" / "replay_worker.py"
OBSERVED = ROOT / "inputs" / "pattern.csv"

parser = argparse.ArgumentParser()
parser.add_argument("projects", nargs="+")
args = parser.parse_args()

summaries = []
for project_arg in args.projects:
    project = Path(project_arg).resolve()
    destination = ROOT / "analysis" / "replays" / project.stem
    destination.mkdir(parents=True, exist_ok=True)
    request = destination / "request.json"
    request.write_text(json.dumps({
        "project": str(project),
        "observed": str(OBSERVED),
        "histogram": "PWDR pattern.xye",
    }, indent=2) + "\n")
    process = subprocess.run(
        [sys.executable, str(WORKER), str(request)],
        cwd=destination,
        capture_output=True,
        text=True,
        timeout=180,
    )
    report = json.loads((destination / "replay.json").read_text())
    summary = {
        "project": str(project),
        "returncode": process.returncode,
        "status": report.get("status"),
        "error": report.get("error"),
        "profile_review_flags": report.get("profile_review_flags"),
        "phases": report.get("phases"),
    }
    prediction_path = destination / "prediction.npz"
    if report.get("status") == "replayed" and prediction_path.is_file():
        with np.load(prediction_path, allow_pickle=False) as data:
            observed = data["observed"]
            predicted = data["predicted"]
        weights = 1.0 / np.maximum(observed, 1.0)
        chi_square = float(np.sum(weights * (observed - predicted) ** 2))
        denominator = float(np.sum(weights * observed**2))
        summary.update({
            "chi_square": chi_square,
            "rwp_percent": 100.0 * np.sqrt(chi_square / denominator),
            "minimum_predicted": float(np.min(predicted)),
        })
    summaries.append(summary)
    print("REPLAY_PROJECT", json.dumps(summary, sort_keys=True), flush=True)

if any(item["status"] != "replayed" for item in summaries):
    raise SystemExit(2)
