from pathlib import Path

import json
import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
project = G2.G2Project(
    str(ROOT / "analysis" / "initial.gpx"),
    newgpx=str(ROOT / "analysis" / "cells.gpx"),
)
hist = project.histogram(0)
project.set_Controls("cycles", 12)

for variable, low, high in [
    (":0:Shift", -800.0, 800.0),
    (":0:U", 0.001, 80.0),
    (":0:W", 0.001, 80.0),
    (":0:X", 0.001, 12.0),
]:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)
for phase in project.phases():
    project.set_Controls("parmMin", 1e-8, variable=f"{phase.id}:0:Scale")

hist.data["Sample Parameters"]["Shift"][0] = -500.0
hist.set_refinements({
    "Background": {"refine": True},
    "Sample Parameters": ["Shift"],
})
for phase in project.phases():
    phase.set_HAP_refinements({"Scale": True})
project.refine()

for phase in project.phases():
    phase.set_refinements({"Cell": True})
for _ in range(3):
    project.set_Frozen()
    project.refine()

h = project.histogram(0)
arrays = h.data["data"][1]
print("residuals", json.dumps(h.residuals, sort_keys=True))
print("sample", h.data["Sample Parameters"])
print("instrument", h.data["Instrument Parameters"][0])
print("profile extrema", float(np.max(arrays[3])), float(np.min(arrays[4])), float(np.max(arrays[4])))
for phase in project.phases():
    hap = phase.data["Histograms"][h.name]
    print(phase.name, phase.get_cell(), "scale", hap["Scale"], "size", hap["Size"], "mustrain", hap["Mustrain"])
print("vary", project.data["Covariance"]["data"].get("varyList", []))
print("frozen", project.get_Frozen())
project.save()
