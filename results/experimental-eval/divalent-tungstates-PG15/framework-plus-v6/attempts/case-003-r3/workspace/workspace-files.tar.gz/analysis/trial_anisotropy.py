from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int, choices=(0, 1, 2, 3))
parser.add_argument("axis", help="comma-separated h,k,l")
parser.add_argument("--base", default=str(ROOT / "analysis" / "trial_nuisance_all.gpx"))
args = parser.parse_args()
axis = [int(v) for v in args.axis.split(",")]
if len(axis) != 3 or not any(axis):
    raise ValueError("axis must be a nonzero h,k,l triple")
tag = "".join(str(v).replace("-", "m") for v in axis)

suffix = "_rechallenge" if Path(args.base).name != "trial_nuisance_all.gpx" else ""
target = ROOT / "analysis" / f"trial_aniso_p{args.phase}_{tag}{suffix}.gpx"
project = G2.G2Project(
    args.base,
    newgpx=str(target),
)
project.set_Controls("cycles", 16)
project.set_Frozen()
hist = project.histogram(0)
hist.data["Instrument Parameters"][0]["Polariz."] = [0.5, 0.5, False]
hist.data["Sample Parameters"]["SurfRoughA"] = [0.05, False]
hist.data["Sample Parameters"]["SurfRoughB"][1] = True

phase = project.phase(args.phase)
hap = phase.data["Histograms"][hist.name]
iso = float(hap["Mustrain"][1][0])
phase.setSampleProfile(hist.name, "microstrain", "uniaxial", iso, iso, axis, LGmix=1.0)
phase.set_HAP_refinements({
    "Mustrain": {"type": "uniaxial", "refine": True, "direction": axis}
})
for suffix in ("i", "a"):
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;{suffix}")
    project.set_Controls("parmMax", 32000.0, variable=f"{phase.id}:0:Mustrain;{suffix}")

for _ in range(3):
    project.set_Frozen()
    project.refine()

hist = project.histogram(0)
phase = project.phase(args.phase)
summary = {
    "phase": phase.name,
    "axis": axis,
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
    "frozen": project.get_Frozen(),
}
print("ANISO_TRIAL_SUMMARY", json.dumps(summary, sort_keys=True))
project.save()
