from pathlib import Path

import json
import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
source = ROOT / "analysis" / "initial.gpx"
target = ROOT / "analysis" / "baseline.gpx"
project = G2.G2Project(str(source), newgpx=str(target))
hist = project.histogram(0)
project.set_Controls("cycles", 8)


def snapshot(label):
    h = project.histogram(0)
    arrays = h.data["data"][1]
    print("\nSNAPSHOT", label)
    print("residuals", json.dumps(h.residuals, sort_keys=True))
    print("sample", {k: h.data["Sample Parameters"].get(k) for k in
          ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")})
    print("instrument", {k: v for k, v in h.data["Instrument Parameters"][0].items()
          if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")})
    print("range", {
        "obs_max": float(np.max(arrays[1])),
        "calc_max": float(np.max(arrays[3])),
        "background_min": float(np.min(arrays[4])),
        "background_max": float(np.max(arrays[4])),
        "calc_min": float(np.min(arrays[3])),
    })
    for phase in project.phases():
        hap = phase.data["Histograms"][h.name]
        print(phase.name, "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"][:4], "mustrain", hap["Mustrain"][:4],
              "PO", hap["Pref.Ori."][:4])
    print("vary", project.data.get("Covariance", {}).get("data", {}).get("varyList", []))
    print("frozen", project.get_Frozen())


# Limits prevent nuisance terms from becoming nonphysical. The GSAS-II limit
# mechanism freezes only if a trial crosses a bound, so starts are kept interior.
for variable, low, high in [
    (":0:Shift", -800.0, 800.0),
    (":0:U", 0.001, 80.0),
    (":0:W", 0.001, 80.0),
    (":0:X", 0.001, 12.0),
    (":0:SH/L", 0.001, 0.2),
]:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)
for phase in project.phases():
    project.set_Controls("parmMin", 1e-8, variable=f"{phase.id}:0:Scale")

# First reconverge only smooth background, all scales and one displacement term.
hist.data["Sample Parameters"]["Shift"][0] = -500.0
hist.set_refinements({
    "Background": {"refine": True},
    "Sample Parameters": ["Shift"],
})
for phase in project.phases():
    phase.set_HAP_refinements({"Scale": True})
project.refine()
snapshot("background_scales_shift")

# Next permit symmetry-constrained cells while keeping the common terms active.
for phase in project.phases():
    phase.set_refinements({"Cell": True})
project.set_Frozen()
project.refine()
snapshot("cells")

# Establish a low-dimensional common instrumental profile. V/Y/Z stay fixed at 0.
hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
project.set_Frozen()
project.refine()
snapshot("common_profile")
project.save()
