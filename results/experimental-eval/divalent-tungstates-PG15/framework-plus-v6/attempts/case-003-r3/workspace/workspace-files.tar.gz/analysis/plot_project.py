from pathlib import Path
import argparse

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("project")
parser.add_argument("output")
args = parser.parse_args()

project = G2.G2Project(args.project)
hist = project.histogram(0)
x, obs, wt, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
fig, axes = plt.subplots(3, 1, figsize=(14, 10), sharex=True,
                         gridspec_kw={"height_ratios": [2.2, 1.2, 1.2]})
axes[0].plot(x, obs, color="black", lw=0.55, label="observed")
axes[0].plot(x, calc, color="tab:red", lw=0.7, label="calculated")
axes[0].plot(x, bkg, color="tab:blue", lw=0.6, label="background")
axes[0].set_ylim(-100, min(30000, 1.08 * obs.max()))
axes[0].legend(loc="upper right", ncol=3)
axes[0].set_ylabel("counts")
axes[1].plot(x, obs-calc, color="tab:green", lw=0.55)
axes[1].axhline(0, color="gray", lw=0.5)
axes[1].set_ylim(-5000, 5000)
axes[1].set_ylabel("obs - calc")
axes[2].plot(x, (obs-calc)/np.sqrt(np.maximum(obs, 1)), color="tab:purple", lw=0.55)
axes[2].axhline(0, color="gray", lw=0.5)
axes[2].set_ylim(-15, 15)
axes[2].set_ylabel("Poisson residual")
axes[2].set_xlabel(r"$2\theta$ (degrees)")
for ax in axes:
    ax.set_xlim(10, 100)
    ax.grid(alpha=0.15)
fig.tight_layout()
fig.savefig(args.output, dpi=160)
