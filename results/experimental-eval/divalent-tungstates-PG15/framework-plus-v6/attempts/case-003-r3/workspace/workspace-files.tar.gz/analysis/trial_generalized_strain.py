from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIspc as G2spc


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int, choices=(0, 1, 2))
parser.add_argument("--base", default=str(ROOT / "analysis" / "regularized.gpx"))
args = parser.parse_args()

target = ROOT / "analysis" / f"trial_generalized_strain_p{args.phase}.gpx"
project = G2.G2Project(args.base, newgpx=str(target))
project.set_Controls("cycles", 20)
project.set_Frozen()
hist = project.histogram(0)
phase = project.phase(args.phase)
hap = phase.data["Histograms"][hist.name]

start = float(hap["Mustrain"][1][0])
values = list(G2spc.Muiso2Shkl(start, phase.data["General"]["SGData"], phase.data["General"]["Cell"][1:7]))
hap["Mustrain"][0] = "generalized"
hap["Mustrain"][4] = values
hap["Mustrain"][5] = [True] * len(values)
hap["Mustrain"][2] = [False, False, False]

for _ in range(4):
    project.refine()

hist = project.histogram(0)
hap = phase.data["Histograms"][hist.name]
print("GENERALIZED_STRAIN_SUMMARY", json.dumps({
    "phase": phase.name,
    "names": G2spc.MustrainNames(phase.data["General"]["SGData"]),
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "mustrain": hap["Mustrain"],
    "frozen": project.get_Frozen(),
    "vary": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
}, sort_keys=True, default=str))
project.save()
