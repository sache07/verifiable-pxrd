from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("uiso", type=float, choices=(0.005, 0.010, 0.015, 0.020))
parser.add_argument("--texture", action="store_true")
args = parser.parse_args()

tag = str(args.uiso).replace(".", "p") + ("_tex001" if args.texture else "_notex")
target = ROOT / "analysis" / f"trial_calcite_{tag}.gpx"
project = G2.G2Project(str(ROOT / "analysis" / "coordinates.gpx"), newgpx=str(target))
project.set_Controls("cycles", 16)
project.set_Frozen()
hist = project.histogram(0)
phase = project.phase(2)

for atom in phase.atoms():
    atom.ADP = args.uiso
    atom.refinement_flags = " "
hap = phase.data["Histograms"][hist.name]
hap["Pref.Ori."][0] = "MD"
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = False
hap["Pref.Ori."][3] = [0, 0, 1]
if args.texture:
    phase.set_HAP_refinements({"Pref.Ori.": True})
    project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")

for _ in range(3):
    project.refine()

hist = project.histogram(0)
phase = project.phase(2)
summary = {
    "uiso": args.uiso,
    "texture": args.texture,
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "pref_ori": phase.data["Histograms"][hist.name]["Pref.Ori."],
    "frozen": project.get_Frozen(),
}
print("CALCITE_MODEL_SUMMARY", json.dumps(summary, sort_keys=True))
project.save()
