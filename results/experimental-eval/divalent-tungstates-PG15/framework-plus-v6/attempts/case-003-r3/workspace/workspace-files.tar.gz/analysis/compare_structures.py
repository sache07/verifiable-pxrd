from pathlib import Path
import argparse

import numpy as np
from scipy.optimize import linear_sum_assignment
from pymatgen.core import Structure


parser = argparse.ArgumentParser()
parser.add_argument("parent")
parser.add_argument("models", nargs="+")
args = parser.parse_args()
parent = Structure.from_file(args.parent, primitive=False)

for filename in args.models:
    model = Structure.from_file(filename, primitive=False)
    print("MODEL", Path(filename).name)
    if parent.composition != model.composition or len(parent) != len(model):
        print(" composition_or_size_mismatch", parent.composition, model.composition, len(parent), len(model))
        continue
    strain = model.lattice.matrix @ np.linalg.inv(parent.lattice.matrix) - np.eye(3)
    print(" max_cell_deformation", float(np.max(np.abs(np.linalg.eigvals((strain + strain.T) / 2)))))
    for element in sorted({site.specie.symbol for site in parent}):
        pidx = [i for i, site in enumerate(parent) if site.specie.symbol == element]
        midx = [i for i, site in enumerate(model) if site.specie.symbol == element]
        distances = parent.lattice.get_all_distances(parent.frac_coords[pidx], model.frac_coords[midx])
        rows, cols = linear_sum_assignment(distances)
        assigned = distances[rows, cols]
        print(" ", element, "rms_A", float(np.sqrt(np.mean(assigned**2))),
              "max_A", float(np.max(assigned)), "values", np.round(np.sort(assigned), 5).tolist())
