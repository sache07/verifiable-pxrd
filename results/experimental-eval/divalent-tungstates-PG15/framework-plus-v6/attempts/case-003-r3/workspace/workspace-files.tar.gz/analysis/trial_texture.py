from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int, choices=(0, 1, 2, 3))
parser.add_argument("axis", help="comma-separated h,k,l")
parser.add_argument("--base", default=str(ROOT / "analysis" / "trial_nuisance_all.gpx"))
args = parser.parse_args()
axis = [int(v) for v in args.axis.split(",")]
if len(axis) != 3 or not any(axis):
    raise ValueError("axis must be a nonzero h,k,l triple")
tag = "".join(str(v).replace("-", "m") for v in axis)

suffix = "_rechallenge" if Path(args.base).name != "trial_nuisance_all.gpx" else ""
target = ROOT / "analysis" / f"trial_texture_p{args.phase}_{tag}{suffix}.gpx"
project = G2.G2Project(
    args.base,
    newgpx=str(target),
)
project.set_Controls("cycles", 16)
project.set_Frozen()
hist = project.histogram(0)

# Keep accepted common intensity corrections while fixing values that reached
# physical prior bounds; only B and SH/L remain active in these comparisons.
inst = hist.data["Instrument Parameters"][0]
inst["Polariz."] = [0.5, 0.5, False]
sample = hist.data["Sample Parameters"]
sample["SurfRoughA"] = [0.05, False]
sample["SurfRoughB"][1] = True
if Path(args.base).name == "trial_nuisance_all.gpx":
    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

phase = project.phase(args.phase)
hap = phase.data["Histograms"][hist.name]
hap["Pref.Ori."][0] = "MD"
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = False
hap["Pref.Ori."][3] = axis
phase.set_HAP_refinements({"Pref.Ori.": True})
project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")

for _ in range(3):
    project.set_Frozen()
    project.refine()

hist = project.histogram(0)
phase = project.phase(args.phase)
summary = {
    "phase": phase.name,
    "axis": axis,
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "pref_ori": phase.data["Histograms"][hist.name]["Pref.Ori."],
    "frozen": project.get_Frozen(),
}
print("TEXTURE_TRIAL_SUMMARY", json.dumps(summary, sort_keys=True))
project.save()
