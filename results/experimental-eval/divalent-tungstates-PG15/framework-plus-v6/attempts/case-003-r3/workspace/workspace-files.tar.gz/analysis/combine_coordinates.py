from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
project = G2.G2Project(
    str(ANALYSIS / "trial_bounded_atoms_p1_0p004.gpx"),
    newgpx=str(ANALYSIS / "coordinates.gpx"),
)

sources = {
    0: G2.G2Project(str(ANALYSIS / "trial_bounded_atoms_p0_0p004.gpx")),
    2: G2.G2Project(str(ANALYSIS / "trial_bounded_atoms_p2_0p008.gpx")),
}
for phase_id, source in sources.items():
    destination_phase = project.phase(phase_id)
    source_phase = source.phase(phase_id)
    for dest_atom, source_atom in zip(destination_phase.atoms(), source_phase.atoms()):
        dest_atom.coordinates = source_atom.coordinates

# Keep coordinate values fixed for the common replay and use physically
# normalized isotropic ADPs. WO3 sits at the documented lower Uiso edge.
for phase in project.phases():
    value = 0.003 if phase.name == "WO3_monoclinic" else 0.005
    for atom in phase.atoms():
        atom.ADP = value
        atom.refinement_flags = " "

project.set_Frozen()
project.set_Controls("cycles", 16)
for _ in range(3):
    project.refine()

hist = project.histogram(0)
summary = {
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "phases": [],
    "frozen": project.get_Frozen(),
}
for phase in project.phases():
    summary["phases"].append({
        "name": phase.name,
        "cell": phase.get_cell(),
        "atoms": [{"label": a.label, "xyz": list(a.coordinates), "uiso": a.ADP} for a in phase.atoms()],
    })
print("COORDINATE_MODEL_SUMMARY", json.dumps(summary, sort_keys=True))
project.save()
