from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int, choices=(0, 1, 2, 3))
parser.add_argument("--bound", type=float, default=0.008)
parser.add_argument("--base", default=str(ROOT / "analysis" / "normalized.gpx"))
args = parser.parse_args()

tag = str(args.bound).replace(".", "p")
suffix = "_rechallenge" if Path(args.base).name != "normalized.gpx" else ""
target = ROOT / "analysis" / f"trial_bounded_atoms_p{args.phase}_{tag}{suffix}.gpx"
project = G2.G2Project(args.base, newgpx=str(target))
project.set_Controls("cycles", 20)
project.set_Frozen()
hist = project.histogram(0)
hist.data["Instrument Parameters"][0]["Polariz."] = [0.5, 0.5, False]
hist.data["Sample Parameters"]["SurfRoughA"] = [0.05, False]
hist.data["Sample Parameters"]["SurfRoughB"][1] = True

phase = project.phase(args.phase)
starts = [list(a.coordinates) for a in phase.atoms()]
phase.set_refinements({"Atoms": {"all": "X"}})
for i, atom in enumerate(phase.atoms()):
    for j, axis in enumerate("xyz"):
        variable = f"{phase.id}::dA{axis}:{i}"
        # GSAS-II applies dA limits to the corresponding absolute atom
        # coordinate (A{x,y,z}), so bounds must be centered on the parent.
        project.set_Controls("parmMin", starts[i][j] - args.bound, variable=variable)
        project.set_Controls("parmMax", starts[i][j] + args.bound, variable=variable)

# Repeated passes keep each coordinate inside the fixed parent-centered box;
# a final nuisance-only pass recalculates the profile after any bound clipping.
for _ in range(3):
    project.refine()
for atom in phase.atoms():
    atom.refinement_flags = " "
project.set_Frozen()
project.set_Controls("cycles", 10)
project.refine()

hist = project.histogram(0)
phase = project.phase(args.phase)
summary = {
    "phase": phase.name,
    "bound_fractional": args.bound,
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "atoms": [
        {
            "label": a.label,
            "start": starts[i],
            "final": list(a.coordinates),
            "delta_fractional": [float(v-s) for v, s in zip(a.coordinates, starts[i])],
        }
        for i, a in enumerate(phase.atoms())
    ],
    "frozen": project.get_Frozen(),
}
print("BOUNDED_ATOM_SUMMARY", json.dumps(summary, sort_keys=True))
project.save()
