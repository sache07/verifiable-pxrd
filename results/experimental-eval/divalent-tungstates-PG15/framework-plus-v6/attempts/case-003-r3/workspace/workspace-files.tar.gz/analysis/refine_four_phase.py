from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
project = G2.G2Project(
    str(ANALYSIS / "trial_candidate_WO3m_1528915_add.gpx"),
    newgpx=str(ANALYSIS / "four_phase.gpx"),
)
project.set_Controls("cycles", 20)
project.set_Frozen()
hist = project.histogram(0)
candidate = project.phase(3)

# The screening size term ran to an exploratory 2 um ceiling, indicating no
# supported extra size broadening. Fix it at the documented 1.5 um physical
# upper edge and retain the independently supported isotropic microstrain.
candidate_hap = candidate.data["Histograms"][hist.name]
candidate_hap["Size"][1][0] = 1.5
candidate.clear_HAP_refinements({"Size": True})

# Apply the experiment's physical ranges to all active terms. Common U and X
# remain fixed because they are exactly confounded with phase strain and size.
project.set_Controls("parmMin", 2.0, variable=":0:W")
project.set_Controls("parmMax", 40.0, variable=":0:W")
project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
project.set_Controls("parmMax", 0.10, variable=":0:SH/L")
project.set_Controls("parmMin", -800.0, variable=":0:Shift")
project.set_Controls("parmMax", 800.0, variable=":0:Shift")
project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")

for phase in project.phases():
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    hap = phase.data["Histograms"][hist.name]
    if hap["Size"][2][0]:
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:0:Size;i")
    if hap["Mustrain"][2][0]:
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0 if phase.id != 1 else 32000.0,
                             variable=f"{phase.id}:0:Mustrain;i")
    if hap["Mustrain"][0] == "uniaxial" and hap["Mustrain"][2][1]:
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;a")
        project.set_Controls("parmMax", 32000.0, variable=f"{phase.id}:0:Mustrain;a")

for _ in range(4):
    project.refine()

hist = project.histogram(0)
products = {
    phase.name: phase.data["Histograms"][hist.name]["Scale"][0] * phase.data["General"]["Mass"]
    for phase in project.phases()
}
total = sum(products.values())
print("FOUR_PHASE_SUMMARY", json.dumps({
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "fractions": {name: value / total for name, value in products.items()},
    "frozen": project.get_Frozen(),
    "candidate_cell": candidate.get_cell(),
    "candidate_size": candidate_hap["Size"],
    "candidate_mustrain": candidate_hap["Mustrain"],
}, sort_keys=True, default=str))
project.save()
