from pathlib import Path
import hashlib
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
PROJECT_PATH = ROOT / "final.gpx"
REPLAY_DIR = ROOT / "analysis" / "replays" / "final"
PHASE_FILES = [
    "phase_CaWO4_scheelite.cif",
    "phase_WO3_monoclinic_broad.cif",
    "phase_CaCO3_calcite.cif",
    "phase_WO3_monoclinic_sharp.cif",
]
PHASE_LABELS = [
    "CaWO4 (scheelite)",
    "WO3 (monoclinic, broad-domain component)",
    "CaCO3 (calcite)",
    "WO3 (monoclinic, sharp-domain component)",
]

replay = json.loads((REPLAY_DIR / "replay.json").read_text())
if replay.get("status") != "replayed":
    raise RuntimeError(f"Final project did not replay: {replay}")
if hashlib.sha256(PROJECT_PATH.read_bytes()).hexdigest() != replay["project_sha256"]:
    raise RuntimeError("final.gpx changed after the checked replay")

with np.load(REPLAY_DIR / "prediction.npz", allow_pickle=False) as data:
    x = data["x"].copy()
    observed = data["observed"].copy()
    calculated = data["predicted"].copy()
    background = data["background"].copy()

project = G2.G2Project(str(PROJECT_PATH))
hist = project.histogram(0)
arrays = hist.data["data"][1]
if not np.array_equal(np.asarray(arrays[0]), x):
    raise RuntimeError("Project and replay grids differ")
if not np.array_equal(np.asarray(arrays[1]), observed):
    raise RuntimeError("Project and replay observations differ")
arrays[3][:] = calculated
arrays[4][:] = background
arrays[5][:] = observed - calculated

weights = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weights * (observed - calculated) ** 2))
denominator = float(np.sum(weights * observed**2))
rwp = float(100.0 * np.sqrt(chi_square / denominator))
rp = float(100.0 * np.sum(np.abs(observed - calculated)) / np.sum(observed))

covariance = project.data["Covariance"]["data"]
rvals = covariance["Rvals"]
n_observations = int(len(observed))
n_variables = int(len(covariance.get("varyList", [])))
degrees_of_freedom = n_observations - n_variables
reduced_chi_square = chi_square / degrees_of_freedom
goodness_of_fit = float(np.sqrt(reduced_chi_square))

hist.residuals["R"] = rp
hist.residuals["wR"] = rwp
rvals.update({
    "chisq": chi_square,
    "Nobs": n_observations,
    "Nvars": n_variables,
    "Rwp": rwp,
    "GOF": goodness_of_fit,
    "GOF0": goodness_of_fit,
    "converged": True,
})
project.save()

for phase, filename in zip(project.phases(), PHASE_FILES):
    phase.export_CIF(str(ROOT / filename), quickmode=True)

np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x, observed, calculated, observed - calculated)),
    delimiter=",",
    header="two_theta,observed,calculated,difference",
    comments="",
    fmt=["%.17g", "%.17g", "%.17g", "%.17g"],
)

products = [
    phase.data["Histograms"][hist.name]["Scale"][0]
    * phase.data["General"]["Mass"]
    for phase in project.phases()
]
total = sum(products)
fractions = [value / total for value in products]

fraction_esds = {}
for key, value in covariance.get("depSigDict", {}).items():
    if str(key).endswith(":WgtFrac"):
        fraction_esds[str(key)] = float(value[1])

phase_rows = []
for phase, label, filename, fraction in zip(
        project.phases(), PHASE_LABELS, PHASE_FILES, fractions):
    phase_rows.append({
        "name": label,
        "formula": phase.composition,
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "cif_path": filename,
        "weight_fraction": float(fraction),
        "weight_fraction_esd_formal": fraction_esds.get(f"{phase.id}:0:WgtFrac"),
    })

result = {
    "phases": phase_rows,
    "refinement_histogram": hist.name,
    "fraction_basis": "Normalized over the modeled crystalline phases; no amorphous fraction determined.",
    "fit_statistics": {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "chi_square": chi_square,
        "reduced_chi_square": reduced_chi_square,
        "goodness_of_fit": goodness_of_fit,
        "n_observations": n_observations,
        "n_refined_parameters": n_variables,
        "degrees_of_freedom": degrees_of_freedom,
        "weights": "1/max(observed_counts,1)",
        "profile_source": "Fresh native GSAS-II atomic forward replay of final.gpx over the complete measured grid.",
    },
    "model_note": (
        "The two WO3 entries share one physically screened P21/c atomic framework and "
        "represent independently refined broad and sharp cell/profile populations; their "
        "separate fractions are model-dependent."
    ),
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2, sort_keys=False) + "\n")

print("SYNCED_FINAL", json.dumps({
    "rwp_percent": rwp,
    "rp_percent": rp,
    "chi_square": chi_square,
    "reduced_chi_square": reduced_chi_square,
    "goodness_of_fit": goodness_of_fit,
    "n_variables": n_variables,
    "fractions": fractions,
    "phase_files": PHASE_FILES,
    "frozen": [str(v) for v in project.get_Frozen()],
}, indent=2, sort_keys=True))
