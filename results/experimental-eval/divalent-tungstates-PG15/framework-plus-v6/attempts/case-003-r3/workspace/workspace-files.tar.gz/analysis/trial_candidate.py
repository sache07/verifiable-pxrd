from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("cif")
parser.add_argument("--replace-phase", type=int)
parser.add_argument("--base", default=str(ROOT / "analysis" / "trial_calcite_0p02_tex001.gpx"))
args = parser.parse_args()

mode = f"replace{args.replace_phase}" if args.replace_phase is not None else "add"
target = ROOT / "analysis" / f"trial_candidate_{args.name}_{mode}.gpx"
project = G2.G2Project(args.base, newgpx=str(target))
project.set_Controls("cycles", 16)
project.set_Frozen()
hist = project.histogram(0)

displaced_product = None
if args.replace_phase is not None:
    displaced = project.phase(args.replace_phase)
    displaced_hap = displaced.data["Histograms"][hist.name]
    displaced_product = float(displaced_hap["Scale"][0]) * float(displaced.data["General"]["Mass"])
    displaced_hap["Scale"] = [0.0, False]
    displaced.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in displaced.atoms()]})
    displaced.clear_HAP_refinements({
        "Scale": True,
        "Size": True,
        "Mustrain": True,
        "Pref.Ori.": True,
        "HStrain": True,
        "Extinction": True,
        "Babinet": ["BabA", "BabU"],
    })

candidate = project.add_phase(args.cif, phasename=args.name, histograms=[hist], fmthint="CIF")
for atom in candidate.atoms():
    atom.ADP = 0.005
    atom.refinement_flags = " "

hap = candidate.data["Histograms"][hist.name]
initial_scale = 0.2 if displaced_product is None else displaced_product / float(candidate.data["General"]["Mass"])
hap["Scale"] = [initial_scale, True]
candidate.setSampleProfile(hist.name, "size", "isotropic", 0.30, LGmix=1.0)
candidate.setSampleProfile(hist.name, "microstrain", "isotropic", 1000.0, LGmix=1.0)
candidate.set_HAP_refinements({"Scale": True})
project.set_Controls("parmMin", 0.0, variable=f"{candidate.id}:0:Scale")


def summarize(stage):
    h = project.histogram(0)
    products = []
    for phase in project.phases():
        phap = phase.data["Histograms"].get(h.name)
        if not phap:
            continue
        products.append((phase.name, float(phap["Scale"][0]) * float(phase.data["General"]["Mass"])))
    total = sum(max(value, 0.0) for _, value in products)
    fractions = {name: max(value, 0.0) / total if total else 0.0 for name, value in products}
    print("CANDIDATE_STAGE", stage, json.dumps({
        "name": candidate.name,
        "mode": mode,
        "wR_percent": h.residuals.get("wR"),
        "R_percent": h.residuals.get("R"),
        "candidate_scale": candidate.data["Histograms"][h.name]["Scale"],
        "candidate_fraction": fractions.get(candidate.name),
        "fractions": fractions,
        "cell": candidate.get_cell(),
        "size": candidate.data["Histograms"][h.name]["Size"],
        "mustrain": candidate.data["Histograms"][h.name]["Mustrain"],
        "frozen": project.get_Frozen(),
    }, sort_keys=True, default=str))
    return fractions.get(candidate.name, 0.0)


for _ in range(3):
    project.refine()
fraction = summarize("scale")

# Only release the candidate's cell and widths if scale-only screening finds a
# nontrivial contribution. This prevents a null phase from wandering through
# parameter space while still allowing registration mismatch and broadening.
if fraction > 0.0005:
    candidate.set_refinements({"Cell": True})
    candidate.set_HAP_refinements({
        "Scale": True,
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    project.set_Controls("parmMin", 0.04, variable=f"{candidate.id}:0:Size;i")
    project.set_Controls("parmMax", 2.0, variable=f"{candidate.id}:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable=f"{candidate.id}:0:Mustrain;i")
    project.set_Controls("parmMax", 12000.0, variable=f"{candidate.id}:0:Mustrain;i")
    for _ in range(3):
        project.set_Frozen()
        project.refine()
    summarize("cell_width")

project.save()
