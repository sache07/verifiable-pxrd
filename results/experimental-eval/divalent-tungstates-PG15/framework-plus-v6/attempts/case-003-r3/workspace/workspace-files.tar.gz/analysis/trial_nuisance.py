from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=("polarization", "roughness", "both", "shl", "all"))
args = parser.parse_args()

target = ROOT / "analysis" / f"trial_nuisance_{args.mode}.gpx"
project = G2.G2Project(
    str(ROOT / "analysis" / "trial_wo3_2311041.gpx"),
    newgpx=str(target),
)
project.set_Controls("cycles", 16)
project.set_Frozen()
hist = project.histogram(0)
inst = hist.data["Instrument Parameters"][0]

if args.mode in ("polarization", "both", "all"):
    inst["Polariz."][1] = 0.70
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")

if args.mode in ("roughness", "both", "all"):
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.20, True]
    sample["SurfRoughB"] = [0.10, True]
    project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.6, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")

if args.mode in ("shl", "all"):
    inst["SH/L"][1] = 0.03
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.set_Controls("parmMin", 0.001, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.2, variable=":0:SH/L")

for _ in range(3):
    project.set_Frozen()
    project.refine()

hist = project.histogram(0)
summary = {
    "mode": args.mode,
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "polarization": hist.data["Instrument Parameters"][0]["Polariz."],
    "SH_L": hist.data["Instrument Parameters"][0]["SH/L"],
    "rough_A": hist.data["Sample Parameters"]["SurfRoughA"],
    "rough_B": hist.data["Sample Parameters"]["SurfRoughB"],
    "frozen": project.get_Frozen(),
    "vary": project.data["Covariance"]["data"].get("varyList", []),
}
print("NUISANCE_TRIAL_SUMMARY", json.dumps(summary, sort_keys=True))
project.save()
