from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
project = G2.G2Project(
    str(ANALYSIS / "trial_calcite_0p02_tex001.gpx"),
    newgpx=str(ANALYSIS / "regularized.gpx"),
)
parent = G2.G2Project(str(ANALYSIS / "normalized.gpx"))

# Independent expanded-structure checks gave these RMS displacements from the
# registered parents for the bounded refinements. Scale each element's fitted
# displacement vector uniformly, matching the generator's documented
# perturbation convention, so no aggregate RMS exceeds the laboratory prior.
fits = {
    0: (G2.G2Project(str(ANALYSIS / "trial_bounded_atoms_p0_0p004.gpx")),
        {"O": 0.050 / 0.05431364818624492}),
    1: (G2.G2Project(str(ANALYSIS / "trial_bounded_atoms_p1_0p004.gpx")),
        {"W": 0.040 / 0.041261442666902445,
         "O": 0.050 / 0.055493262779965}),
}

for phase_id, (fit_project, factors) in fits.items():
    destination = project.phase(phase_id)
    parent_phase = parent.phase(phase_id)
    fit_phase = fit_project.phase(phase_id)
    for atom, parent_atom, fit_atom in zip(destination.atoms(), parent_phase.atoms(), fit_phase.atoms()):
        factor = factors.get(atom.element, 1.0)
        coords = []
        for start, fitted in zip(parent_atom.coordinates, fit_atom.coordinates):
            delta = fitted - start
            delta -= round(delta)
            coords.append(start + factor * delta)
        atom.coordinates = coords
        atom.refinement_flags = " "

project.set_Frozen()
project.set_Controls("cycles", 16)
for _ in range(3):
    project.refine()

hist = project.histogram(0)
print("REGULARIZED_COORDINATES_SUMMARY", json.dumps({
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "frozen": project.get_Frozen(),
    "phases": [{
        "name": phase.name,
        "atoms": [{"label": atom.label, "xyz": list(atom.coordinates)} for atom in phase.atoms()],
    } for phase in project.phases()],
}, sort_keys=True))
project.save()
