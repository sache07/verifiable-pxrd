from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("phase", type=int)
parser.add_argument("size", type=float)
parser.add_argument("--base", required=True)
args = parser.parse_args()

tag = str(args.size).replace(".", "p")
target = ROOT / "analysis" / f"trial_sizegrid_p{args.phase}_{tag}.gpx"
project = G2.G2Project(args.base, newgpx=str(target))
project.set_Controls("cycles", 16)
project.set_Frozen()
hist = project.histogram(0)
phase = project.phase(args.phase)
hap = phase.data["Histograms"][hist.name]
hap["Size"][0] = "isotropic"
hap["Size"][1][0] = args.size
phase.clear_HAP_refinements({"Size": True})

for _ in range(3):
    project.refine()

hist = project.histogram(0)
print("SIZE_GRID_SUMMARY", json.dumps({
    "phase": phase.name,
    "size_um": args.size,
    "wR_percent": hist.residuals.get("wR"),
    "R_percent": hist.residuals.get("R"),
    "mustrain": hap["Mustrain"],
    "frozen": project.get_Frozen(),
}, sort_keys=True, default=str))
project.save()
