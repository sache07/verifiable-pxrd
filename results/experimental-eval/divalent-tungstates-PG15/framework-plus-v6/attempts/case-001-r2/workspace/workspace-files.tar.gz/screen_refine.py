#!/usr/bin/env python3
"""Small GSAS-II screening refinement for candidate COD phase records.

This deliberately keeps atomic coordinates fixed and uses the same restrained
background/profile model for every candidate inventory. It is for comparing
records and polymorphs, not for producing the final refinement.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    phases = []
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    return {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in sample.items()
            if k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")
        },
        "background": hist.Background,
        "phases": phases,
    }


def refine(project: G2sc.G2Project, label: str, log: list[dict], listing: Path) -> None:
    project.save()
    project.refine(printFile=str(listing))
    project.reload()
    state = snapshot(project, label)
    log.append(state)
    print(label, "Rwp", state["residuals"].get("wR"), "GOF data", state["residuals"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ids", nargs="+", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--names", nargs="*")
    args = parser.parse_args()

    args.out.parent.mkdir(parents=True, exist_ok=True)
    names = args.names or args.ids
    if len(names) != len(args.ids):
        raise ValueError("--names must match --ids")

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(newgpx=str(args.out))
    project["Controls"]["data"]["max cyc"] = 12
    project["Controls"]["data"]["min dM/M"] = 1e-5
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-500.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [700.0, -300.0, 150.0, -80.0, 40.0, -20.0, 10.0, -5.0],
                "refine": True,
            },
        }
    )
    inst = hist.InstrumentParameters
    for key, val in {"U": 10.0, "V": 0.0, "W": 20.0, "X": 1.0, "Y": 0.0, "SH/L": 0.03}.items():
        inst[key][1] = val
        inst[key][2] = False
    inst["Zero"][1] = 0.0
    inst["Zero"][2] = False
    inst["Polariz."][1] = 0.7
    inst["Polariz."][2] = False

    phases = []
    for cod_id, name in zip(args.ids, names):
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=f"{name}_{cod_id}",
            histograms=[hist],
            fmthint="CIF",
        )
        phase.setSampleProfile(hist.name, "size", "isotropic", 1000.0, LGmix=1.0)
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", 0.01, LGmix=1.0)
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True}
        )
        phase.getHAPvalues(hist.name)["Scale"][0] = 1.0
        phase.set_HAP_refinements({"Scale": True})
        phases.append(phase)

    log: list[dict] = []
    listing = args.out.with_suffix(".lst")
    refine(project, "background_scales", log, listing)

    hist.SampleParameters["Shift"][1] = True
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "shift_cells", log, listing)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, "common_profile", log, listing)

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine(project, "asymmetry", log, listing)

    # A common profile is the inventory-comparison endpoint. Recompute once
    # after reopening to ensure the saved project is replay-stable.
    project.save()
    project = G2sc.G2Project(str(args.out))
    project.refine(printFile=str(listing))
    project.reload()
    log.append(snapshot(project, "replay"))
    args.out.with_suffix(".json").write_text(json.dumps(log, indent=2, default=float) + "\n")
    print(json.dumps(log[-1], indent=2, default=float))


if __name__ == "__main__":
    main()
