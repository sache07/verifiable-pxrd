#!/usr/bin/env python3
"""Refine coordinates for selected phases while holding nuisance choices fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--phases", nargs="+", type=int, choices=(0, 1), required=True)
    ap.add_argument("--uiso", action="store_true")
    ap.add_argument("--heavy-only", action="store_true")
    args = ap.parse_args()

    G2sc.SetPrintLevel("warn")
    p = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    p.set_Frozen()
    p.set_Controls("cycles", 15)
    p["Controls"]["data"]["min dM/M"] = 1e-5
    p["Controls"]["data"]["shift factor"] = 0.5
    h = p.histogram(0)
    h.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for i, ph in enumerate(p.phases()):
        ph.set_refinements({"Atoms": {"all": " "}})
        if i in args.phases:
            flags = "XU" if args.uiso else "X"
            if args.heavy_only:
                for atom in ph.atoms():
                    if atom.element in ("Ba", "W"):
                        ph.set_refinements({"Atoms": {atom.label: flags}})
            else:
                ph.set_refinements({"Atoms": {"all": flags}})
    p.save()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    h = p.histogram(0)
    result = {
        "refined_phases": args.phases,
        "uiso": args.uiso,
        "heavy_only": args.heavy_only,
        "rwp": h.residuals.get("wR"),
        "phases": [],
    }
    for ph in p.phases():
        result["phases"].append(
            {
                "name": ph.name,
                "cell": ph.get_cell(),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": list(atom.coordinates),
                        "uiso": atom.uiso if atom.adp_flag == "I" else None,
                        "flags": atom.refinement_flags,
                    }
                    for atom in ph.atoms()
                ],
            }
        )
    args.out.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
