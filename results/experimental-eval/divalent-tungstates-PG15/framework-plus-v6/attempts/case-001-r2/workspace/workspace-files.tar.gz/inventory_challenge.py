#!/usr/bin/env python3
"""Add one watch-list phase and refine its scale before any cell freedom."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--id", required=True)
    ap.add_argument("--name", required=True)
    args = ap.parse_args()

    G2sc.SetPrintLevel("warn")
    p = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    p.set_Frozen()
    p.set_Controls("cycles", 12)
    p["Controls"]["data"]["min dM/M"] = 1e-5
    h = p.histogram(0)
    h.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    ph = p.add_phase(str(cod_path(args.id)), phasename=f"{args.name}_{args.id}",
                     histograms=[h], fmthint="CIF")
    for atom in ph.atoms():
        atom.uiso = 0.005
        atom.refinement_flags = " "
    ph.set_refinements({"Cell": False})
    ph.setSampleProfile(h.name, "size", "isotropic", 0.1, LGmix=1.0)
    ph.setSampleProfile(h.name, "microstrain", "isotropic", 0.0, LGmix=1.0)
    ph.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True})
    hap = ph.getHAPvalues(h.name)
    hap["Scale"] = [0.1, True]
    p.save()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    h = p.histogram(0)
    ph = p.phases()[-1]
    hap = ph.getHAPvalues(h.name)
    masses = [x.data["General"]["Mass"] for x in p.phases()]
    scales = [x.getHAPvalues(h.name)["Scale"][0] for x in p.phases()]
    weighted = [m * s for m, s in zip(masses, scales)]
    denom = sum(weighted)
    result = {
        "candidate": ph.name,
        "rwp": h.residuals.get("wR"),
        "scale": hap["Scale"][0],
        "implied_weight_fraction": weighted[-1] / denom if denom else None,
        "all_scales": scales,
    }
    args.out.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
