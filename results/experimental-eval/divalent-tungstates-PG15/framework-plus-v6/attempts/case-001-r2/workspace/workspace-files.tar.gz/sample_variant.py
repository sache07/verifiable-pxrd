#!/usr/bin/env python3
"""Test Bragg-Brentano surface roughness on a converged project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--initial", nargs=2, type=float, default=(0.3, 0.1), metavar=("A", "B"))
    ap.add_argument("--refine", choices=("A", "B", "both"), default="both")
    ap.add_argument("--bounded", action="store_true")
    args = ap.parse_args()

    G2sc.SetPrintLevel("warn")
    p = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    p.set_Frozen()
    p.set_Controls("cycles", 15)
    p["Controls"]["data"]["min dM/M"] = 1e-5
    h = p.histogram(0)
    h.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    h.SampleParameters["SurfRoughA"] = [args.initial[0], args.refine in ("A", "both")]
    h.SampleParameters["SurfRoughB"] = [args.initial[1], args.refine in ("B", "both")]
    if args.bounded:
        for variable, bounds in ((":0:SurfRoughA", (0.05, 0.6)), (":0:SurfRoughB", (0.02, 0.5))):
            p.set_Controls("parmMin", bounds[0], variable=variable)
            p.set_Controls("parmMax", bounds[1], variable=variable)
    p.save()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    h = p.histogram(0)
    result = {
        "rwp": h.residuals.get("wR"),
        "A": h.SampleParameters["SurfRoughA"][0],
        "B": h.SampleParameters["SurfRoughB"][0],
        "frozen": p.get_Frozen(),
        "polarization": h.InstrumentParameters["Polariz."][1],
    }
    args.out.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
