#!/usr/bin/env python3
"""Refine selected shared GSAS-II profile terms from a converged project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("terms", nargs="+", choices=("U", "W", "X", "SH/L", "Polariz."))
    ap.add_argument("--bounded", action="store_true")
    args = ap.parse_args()

    G2sc.SetPrintLevel("warn")
    p = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    p.set_Frozen()
    p.set_Controls("cycles", 12)
    p["Controls"]["data"]["min dM/M"] = 1e-5
    h = p.histogram(0)
    h.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    h.set_refinements({"Instrument Parameters": args.terms})
    if args.bounded:
        bounds = {"U": (0.0, 40.0), "W": (2.0, 40.0), "X": (0.1, 6.0),
                  "SH/L": (0.005, 0.1), "Polariz.": (0.5, 1.0)}
        for term in args.terms:
            lo, hi = bounds[term]
            p.set_Controls("parmMin", lo, variable=f":0:{term}")
            p.set_Controls("parmMax", hi, variable=f":0:{term}")
    p.save()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    h = p.histogram(0)
    result = {
        "terms": args.terms,
        "bounded": args.bounded,
        "rwp": h.residuals.get("wR"),
        "instrument": {k: h.InstrumentParameters[k][1] for k in ("U", "W", "X", "SH/L", "Polariz.")},
        "frozen": p.get_Frozen(),
        "phases": [],
    }
    for ph in p.phases():
        hap = ph.getHAPvalues(h.name)
        result["phases"].append(
            {"name": ph.name, "size": hap["Size"][1], "mustrain": hap["Mustrain"][1]}
        )
    args.out.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
