#!/usr/bin/env python3
"""Compare one March-Dollase axis for one phase at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--phase", type=int, required=True)
    ap.add_argument("--axis", nargs=3, type=int, required=True)
    ap.add_argument("--preserve-other", action="store_true")
    args = ap.parse_args()

    G2sc.SetPrintLevel("warn")
    p = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    p.set_Frozen()
    p.set_Controls("cycles", 12)
    p["Controls"]["data"]["min dM/M"] = 1e-5
    h = p.histogram(0)
    h.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    if not 0 <= args.phase < len(p.phases()):
        raise ValueError("phase index out of range")
    for i, ph in enumerate(p.phases()):
        hap = ph.getHAPvalues(h.name)
        if not args.preserve_other or i == args.phase:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
    target = p.phases()[args.phase]
    hap = target.getHAPvalues(h.name)
    hap["Pref.Ori."][3] = list(args.axis)
    target.set_HAP_refinements({"Pref.Ori.": True})
    p.save()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    h = p.histogram(0)
    result = {
        "target": p.phases()[args.phase].name,
        "axis": args.axis,
        "rwp": h.residuals.get("wR"),
        "ratio": p.phases()[args.phase].getHAPvalues(h.name)["Pref.Ori."][1],
    }
    args.out.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
