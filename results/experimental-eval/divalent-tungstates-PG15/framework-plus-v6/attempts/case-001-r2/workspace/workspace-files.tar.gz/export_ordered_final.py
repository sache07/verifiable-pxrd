#!/usr/bin/env python3
"""Freeze and export the selected ordered-phase refinement."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE = Path("ordered_texture_trials/110b.gpx")
PROJECT = Path("final.gpx")


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(SOURCE), newgpx=str(PROJECT))
    project.set_Controls("cycles", 15)
    project["Controls"]["data"]["min dM/M"] = 1e-5
    project.save()
    for _ in range(2):
        project.refine(printFile="final.lst")
        project.reload()
    project.set_Frozen()
    project.save()

    # Reopen the exact saved project before making all deliverable exports.
    project = G2sc.G2Project(str(PROJECT))
    hist = project.histogram("PWDR pattern.csv")
    outputs = {
        "BaCO3_9010928": Path("phase_BaCO3.cif"),
        "WO3_2311041": Path("phase_WO3.cif"),
        "BaWO4_ordered_BaMoO4_analogue": Path("phase_BaWO4.cif"),
    }
    for phase in project.phases():
        phase.export_CIF(str(outputs[phase.name]))

    x = np.asarray(hist.getdata("x"), dtype=float)
    observed = np.asarray(hist.getdata("yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("ycalc"), dtype=float)
    difference = observed - calculated
    np.savetxt(
        "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.10f", "%.8f", "%.8f", "%.8f"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    covariance = project["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    nvars = int(rvals.get("Nvars", len(covariance.get("varyList", []))))
    gof = float(np.sqrt(chi_square / max(1, len(observed) - nvars)))
    dep = covariance.get("depSigDict", {})

    contributions = []
    phases = []
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        contribution = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        contributions.append(contribution)
        fraction_key = f"{phase.data['pId']}:{hist.id}:WgtFrac"
        fraction_esd = dep.get(fraction_key, (None, None))[1]
        phases.append(
            {
                "project_name": phase.name,
                "cif_path": str(outputs[phase.name]),
                "cell": phase.get_cell(),
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "scale": float(hap["Scale"][0]),
                "size_um": float(hap["Size"][1][0]),
                "mustrain": [float(hap["Mustrain"][1][0]), float(hap["Mustrain"][1][1])],
                "texture_ratio": float(hap["Pref.Ori."][1]),
                "texture_axis": list(hap["Pref.Ori."][3]),
                "weight_fraction_esd_project": None if fraction_esd is None else float(fraction_esd),
            }
        )
    total = sum(contributions)
    for phase, contribution in zip(phases, contributions):
        phase["weight_fraction"] = float(contribution / total)

    background = np.asarray(hist.getdata("background"), dtype=float)
    summary = {
        "histogram": hist.name,
        "fit_statistics": {
            "rwp_percent_full_grid": rwp,
            "rp_percent_full_grid": rp,
            "chi_square_full_grid": chi_square,
            "goodness_of_fit_full_grid": gof,
            "gsas_rwp_percent": float(hist.residuals.get("wR", rwp)),
            "gsas_gof": float(rvals.get("GOF", gof)),
            "n_points": int(len(observed)),
            "n_refined_parameters": nvars,
        },
        "instrument": {
            key: float(hist.InstrumentParameters[key][1])
            for key in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.", "Zero")
        },
        "specimen_shift_um": float(hist.SampleParameters["Shift"][0]),
        "background_min": float(np.min(background)),
        "calculated_min": float(np.min(calculated)),
        "phases": phases,
        "frozen": project.get_Frozen(),
    }
    Path("final_summary.json").write_text(json.dumps(summary, indent=2, default=float) + "\n")
    print(json.dumps(summary, indent=2, default=float))


if __name__ == "__main__":
    main()
