#!/usr/bin/env python3
"""Create the final, replay-stable GSAS-II refinement and exports."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


BASE = Path("bawo4_texture/001.gpx")
OUT = Path("final.gpx")


def set_flags(atom, flags: str) -> None:
    atom.refinement_flags = flags


def main() -> None:
    G2sc.SetPrintLevel("warn")
    p = G2sc.G2Project(str(BASE), newgpx=str(OUT))
    p.set_Frozen()
    p.set_Controls("cycles", 15)
    p["Controls"]["data"]["min dM/M"] = 1e-5
    p["Controls"]["data"]["shift factor"] = 0.5
    h = p.histogram(0)

    # Use every observed bin and no excluded regions.
    x = h.getdata("x")
    h.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    h.Excluded([])
    h.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "refine": True,
            }
        }
    )

    # One angular correction (specimen displacement); physical common profile.
    h.SampleParameters["Scale"] = [1.0, False]
    h.SampleParameters["SurfRoughA"] = [0.0, False]
    h.SampleParameters["SurfRoughB"] = [0.0, False]
    h.SampleParameters["Shift"][1] = True
    h.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    for key, value in {
        "U": 35.0,
        "W": 9.996920578923996,
        "X": 1.0907237016579354,
        "SH/L": 0.03,
        "Polariz.": 1.0,
    }.items():
        h.InstrumentParameters[key][1] = value
        h.InstrumentParameters[key][2] = False
    h.InstrumentParameters["V"][1:] = [0.0, False]
    h.InstrumentParameters["Y"][1:] = [0.0, False]
    h.InstrumentParameters["Z"][1:] = [0.0, False]
    h.InstrumentParameters["Zero"][1:] = [0.0, False]

    ba, wo, bw = p.phases()

    # Rebuild the only constraint explicitly: one common Uiso for BaCO3.
    p["Constraints"]["data"]["Phase"] = []
    ba_source = {
        "Ba": [0.25, 0.4162, 0.7556],
        "C": [0.25, 0.7434, -0.0711],
        "O1": [0.25, 0.9011, -0.0775],
        "O2": [0.4654, 0.6805, -0.0788],
    }
    for atom in ba.atoms():
        atom.coordinates = ba_source[atom.label]
        atom.uiso = 0.0185
        set_flags(atom, "U")
    ba.set_refinements({"Cell": True})
    ba.setSampleProfile(h.name, "size", "isotropic", 0.073, LGmix=1.0)
    ba.set_HAP_refinements({"Scale": True, "Size": {"type": "isotropic", "refine": True}})
    ba.setSampleProfile(h.name, "microstrain", "isotropic", 0.0, LGmix=1.0)
    ba.clear_HAP_refinements({"Mustrain": True, "HStrain": True})
    ba_hap = ba.getHAPvalues(h.name)
    ba_hap["Pref.Ori."][0:4] = ["MD", 0.921, True, [1, 1, 0]]

    # Refine only the W coordinates; the powder data did not determine O safely.
    for atom in wo.atoms():
        atom.uiso = 0.003
        set_flags(atom, "X" if atom.element == "W" else " ")
    wo.set_refinements({"Cell": True})
    wo.setSampleProfile(h.name, "size", "isotropic", 0.150, LGmix=1.0)
    wo.set_HAP_refinements({"Scale": True, "Size": {"type": "isotropic", "refine": True}})
    wo.setSampleProfile(h.name, "microstrain", "uniaxial", 5600.0, 4850.0, axis=[0, 1, 0], LGmix=1.0)
    wo.set_HAP_refinements(
        {"Mustrain": {"type": "uniaxial", "refine": True, "direction": [0, 1, 0]}}
    )
    wo_hap = wo.getHAPvalues(h.name)
    wo_hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    wo.clear_HAP_refinements({"Pref.Ori.": True, "HStrain": True})

    # BaWO4 is weak: retain source coordinates and a restrained physical width.
    for atom in bw.atoms():
        atom.uiso = 0.005
        set_flags(atom, " ")
    bw.set_refinements({"Cell": True})
    bw.setSampleProfile(h.name, "size", "isotropic", 0.04, LGmix=1.0)
    bw.setSampleProfile(h.name, "microstrain", "isotropic", 0.0, LGmix=1.0)
    bw.set_HAP_refinements({"Scale": True})
    bw.clear_HAP_refinements({"Size": True, "Mustrain": True, "HStrain": True})
    bw_hap = bw.getHAPvalues(h.name)
    bw_hap["Pref.Ori."][0:4] = ["MD", 0.780, True, [0, 0, 1]]

    p.save()
    p.index_ids()
    p.add_EquivConstr([f"0::AUiso:{i}" for i in range(len(ba.atoms()))], reloadIdx=False)

    # Determine axial asymmetry with Shift held, then refine Shift with SH/L fixed.
    h.SampleParameters["Shift"][1] = False
    h.set_refinements({"Instrument Parameters": ["SH/L"]})
    p.save()
    p.refine(printFile="final.lst")
    p.reload()
    h = p.histogram(0)
    shl = float(h.InstrumentParameters["SH/L"][1])
    if not 0.005 <= shl <= 0.10:
        shl = 0.03
    h.InstrumentParameters["SH/L"][1:] = [shl, False]
    h.SampleParameters["Shift"][1] = True
    p.set_Frozen()
    p.save()
    p.refine(printFile="final.lst")
    p.reload()
    p.refine(printFile="final.lst")
    p.reload()
    p.set_Frozen()
    p.save()

    # Reopen once more and export exactly the saved phase models.
    p = G2sc.G2Project(str(OUT))
    h = p.histogram(0)
    phase_files = [Path("phase_BaCO3.cif"), Path("phase_WO3.cif"), Path("phase_BaWO4.cif")]
    for ph, path in zip(p.phases(), phase_files):
        ph.export_CIF(str(path))

    x = np.asarray(h.getdata("x"), float)
    obs = np.asarray(h.getdata("yobs"), float)
    calc = np.asarray(h.getdata("ycalc"), float)
    diff = obs - calc
    np.savetxt(
        "fit.csv",
        np.column_stack([x, obs, calc, diff]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    weights = 1.0 / np.maximum(obs, 1.0)
    chi_sq = float(np.sum(weights * diff**2))
    denominator = float(np.sum(weights * obs**2))
    rwp = float(100.0 * np.sqrt(chi_sq / denominator))
    rp = float(100.0 * np.sum(np.abs(diff)) / np.sum(obs))
    cov = p["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    nvars = int(rvals.get("Nvars", len(cov.get("varyList", []))))
    dof = max(1, len(obs) - nvars)
    gof = float(np.sqrt(chi_sq / dof))
    masses = []
    phase_summary = []
    for ph, path in zip(p.phases(), phase_files):
        hap = ph.getHAPvalues(h.name)
        contribution = float(ph.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(contribution)
        phase_summary.append(
            {
                "project_name": ph.name,
                "cif_path": str(path),
                "cell": ph.get_cell(),
                "scale": float(hap["Scale"][0]),
                "size_um": float(hap["Size"][1][0]),
                "mustrain": [float(hap["Mustrain"][1][0]), float(hap["Mustrain"][1][1])],
                "texture_ratio": float(hap["Pref.Ori."][1]),
                "texture_axis": list(hap["Pref.Ori."][3]),
            }
        )
    total = sum(masses)
    for item, mass in zip(phase_summary, masses):
        item["weight_fraction"] = float(mass / total)

    background = np.asarray(h.getdata("background"), float)
    summary = {
        "histogram": h.name,
        "fit_statistics": {
            "rwp_percent_full_grid": rwp,
            "rp_percent_full_grid": rp,
            "chi_square_full_grid": chi_sq,
            "goodness_of_fit_full_grid": gof,
            "gsas_rwp_percent": float(h.residuals.get("wR", rwp)),
            "gsas_gof": float(rvals.get("GOF", gof)),
            "n_points": int(len(obs)),
            "n_refined_parameters": nvars,
        },
        "instrument": {k: h.InstrumentParameters[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.", "Zero")},
        "specimen_shift_um": float(h.SampleParameters["Shift"][0]),
        "background_min": float(np.min(background)),
        "calculated_min": float(np.min(calc)),
        "phases": phase_summary,
        "frozen": p.get_Frozen(),
    }
    Path("final_summary.json").write_text(json.dumps(summary, indent=2, default=float) + "\n")
    print(json.dumps(summary, indent=2, default=float))


if __name__ == "__main__":
    main()
