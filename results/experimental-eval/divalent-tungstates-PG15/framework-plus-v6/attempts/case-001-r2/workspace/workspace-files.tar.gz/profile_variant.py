#!/usr/bin/env python3
"""Refine physically bounded phase-broadening trials from a common GPX model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--mode", choices=("size", "strain", "both"), required=True)
    ap.add_argument("--instrument", nargs=3, type=float, metavar=("U", "W", "X"),
                    default=(20.0, 10.0, 1.0))
    args = ap.parse_args()

    G2sc.SetPrintLevel("warn")
    p = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    p.set_Frozen()
    p.set_Controls("cycles", 12)
    p["Controls"]["data"]["min dM/M"] = 1e-5
    h = p.histogram(0)
    h.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for key, value in zip(("U", "W", "X"), args.instrument):
        h.InstrumentParameters[key][1] = value
    h.InstrumentParameters["SH/L"][1] = 0.03

    for ph in p.phases():
        ph.clear_HAP_refinements({"Size": True, "Mustrain": True})
        if args.mode in ("size", "both"):
            ph.setSampleProfile(h.name, "size", "isotropic", 0.25, LGmix=1.0)
            ph.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        else:
            ph.setSampleProfile(h.name, "size", "isotropic", 10.0, LGmix=1.0)
        if args.mode in ("strain", "both"):
            ph.setSampleProfile(h.name, "microstrain", "isotropic", 1500.0, LGmix=1.0)
            ph.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        else:
            ph.setSampleProfile(h.name, "microstrain", "isotropic", 0.01, LGmix=1.0)

    p.save()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    # A second cycle after save/reopen is both a convergence and replay check.
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    h = p.histogram(0)
    result = {
        "mode": args.mode,
        "rwp": h.residuals.get("wR"),
        "residuals": h.residuals,
        "instrument": {k: h.InstrumentParameters[k][1] for k in ("U", "W", "X", "SH/L")},
        "shift": h.SampleParameters["Shift"][0],
        "phases": [],
        "frozen": p.get_Frozen(),
    }
    for ph in p.phases():
        hap = ph.getHAPvalues(h.name)
        result["phases"].append(
            {
                "name": ph.name,
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "cell": ph.get_cell(),
            }
        )
    args.out.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
