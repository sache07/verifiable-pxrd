#!/usr/bin/env python3
"""Fit one shared isotropic displacement parameter per phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--initial", nargs=2, type=float, default=(0.01, 0.01))
    ap.add_argument("--fixed", action="store_true")
    ap.add_argument("--refine-phases", nargs="*", type=int, choices=(0, 1))
    args = ap.parse_args()

    G2sc.SetPrintLevel("warn")
    p = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    p.set_Frozen()
    p.set_Controls("cycles", 15)
    p["Controls"]["data"]["min dM/M"] = 1e-5
    p["Controls"]["data"]["shift factor"] = 0.5
    h = p.histogram(0)
    h.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    p.save()
    p.index_ids()
    refine_phases = set(args.refine_phases if args.refine_phases is not None else ([] if args.fixed else [0, 1]))
    for i, ph in enumerate(p.phases()):
        vars_ = []
        for j, atom in enumerate(ph.atoms()):
            atom.uiso = args.initial[i]
            atom.refinement_flags = atom.refinement_flags.replace("U", "")
            if i in refine_phases:
                atom.refinement_flags += "U"
                vars_.append(f"{i}::AUiso:{j}")
        if i in refine_phases and len(vars_) > 1:
            p.add_EquivConstr(vars_, reloadIdx=False)
    p.save()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    h = p.histogram(0)
    result = {
        "fixed": args.fixed,
        "refine_phases": sorted(refine_phases),
        "rwp": h.residuals.get("wR"),
        "phases": [
            {
                "name": ph.name,
                "uiso": [atom.uiso for atom in ph.atoms()],
                "flags": [atom.refinement_flags for atom in ph.atoms()],
            }
            for ph in p.phases()
        ],
    }
    args.out.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
