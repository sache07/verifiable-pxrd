#!/usr/bin/env python3
"""Replace the split-site BaWO4 record with an ordered scheelite analogue."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc


def summary(project: G2sc.G2Project, label: str) -> None:
    h = project.histogram(0)
    masses = []
    rows = []
    for ph in project.phases():
        hap = ph.getHAPvalues(h.name)
        masses.append(ph.data["General"]["Mass"] * hap["Scale"][0])
        rows.append(
            {
                "name": ph.name,
                "scale": hap["Scale"][0],
                "cell": ph.get_cell(),
                "texture": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = mass / total
    print(json.dumps({"step": label, "rwp": h.residuals.get("wR"), "phases": rows}, default=float))


def main() -> None:
    G2sc.SetPrintLevel("warn")
    p = G2sc.G2Project("final.gpx", newgpx="ordered_variant.gpx")
    h = p.histogram(0)
    old = "BaWO4_1527204"
    del p.data["Phases"][old]
    next(item for item in p.names if item[0] == "Phases").remove(old)
    h.data["Reflection Lists"].pop(old, None)
    p.data["Covariance"]["data"] = {}
    p.set_Frozen()
    p.save()

    ph = p.add_phase(
        "candidate_BaWO4_ordered.cif",
        phasename="BaWO4_ordered_BaMoO4_analogue",
        histograms=[h],
        fmthint="CIF",
    )
    for atom in ph.atoms():
        atom.uiso = 0.005
        atom.refinement_flags = " "
    ph.setSampleProfile(h.name, "size", "isotropic", 0.04, LGmix=1.0)
    ph.setSampleProfile(h.name, "microstrain", "isotropic", 0.0, LGmix=1.0)
    ph.clear_HAP_refinements({"Size": True, "Mustrain": True, "HStrain": True, "Pref.Ori.": True})
    hap = ph.getHAPvalues(h.name)
    hap["Scale"] = [0.17, True]
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    ph.set_refinements({"Cell": False})
    p.set_Controls("cycles", 15)
    p["Controls"]["data"]["min dM/M"] = 1e-5
    p.save()

    # Scale before cell, with the established common nuisance model.
    p.refine(printFile="ordered_variant.lst")
    p.reload()
    summary(p, "scale_only")

    ph = p.phase("BaWO4_ordered_BaMoO4_analogue")
    ph.set_refinements({"Cell": True})
    p.save()
    p.refine(printFile="ordered_variant.lst")
    p.reload()
    summary(p, "cell")

    ph = p.phase("BaWO4_ordered_BaMoO4_analogue")
    hap = ph.getHAPvalues(p.histogram(0).name)
    hap["Pref.Ori."][0:4] = ["MD", 0.8, True, [0, 0, 1]]
    p.save()
    p.refine(printFile="ordered_variant.lst")
    p.reload()
    p.refine(printFile="ordered_variant.lst")
    p.reload()
    p.set_Frozen()
    p.save()
    summary(p, "texture")


if __name__ == "__main__":
    main()
