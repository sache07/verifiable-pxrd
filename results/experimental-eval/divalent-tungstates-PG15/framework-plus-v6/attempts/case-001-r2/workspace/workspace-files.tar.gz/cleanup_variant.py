#!/usr/bin/env python3
"""Prune unsupported terms and compare the borderline BaCO3 strain term."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--ba-strain", choices=("refine", "zero"), required=True)
    args = ap.parse_args()

    G2sc.SetPrintLevel("warn")
    p = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    p.set_Frozen()
    p.set_Controls("cycles", 15)
    p["Controls"]["data"]["min dM/M"] = 1e-5
    p["Controls"]["data"]["shift factor"] = 0.5
    h = p.histogram(0)
    h.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    h.InstrumentParameters["Polariz."][1] = 1.0
    h.SampleParameters["SurfRoughA"] = [0.0, False]
    h.SampleParameters["SurfRoughB"] = [0.0, False]

    ba = p.phases()[0]
    ba_atom = ba.atom("Ba")
    ba_atom.coordinates = [0.25, 0.4162, 0.7556]
    ba_atom.refinement_flags = ba_atom.refinement_flags.replace("X", "")
    ba_hap = ba.getHAPvalues(h.name)
    ba_hap["Mustrain"][0] = "isotropic"
    if args.ba_strain == "zero":
        ba_hap["Mustrain"][1][0] = 0.0
        ba.clear_HAP_refinements({"Mustrain": True})
    else:
        ba_hap["Mustrain"][1][0] = max(300.0, ba_hap["Mustrain"][1][0])
        ba.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})

    p.save()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    h = p.histogram(0)
    result = {
        "ba_strain_mode": args.ba_strain,
        "rwp": h.residuals.get("wR"),
        "instrument": {k: h.InstrumentParameters[k][1] for k in ("Polariz.", "U", "W", "X", "SH/L")},
        "phases": [],
        "frozen": p.get_Frozen(),
    }
    for ph in p.phases():
        hap = ph.getHAPvalues(h.name)
        result["phases"].append(
            {
                "name": ph.name,
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "texture": hap["Pref.Ori."],
                "cell": ph.get_cell(),
                "atoms": [
                    {"label": a.label, "xyz": list(a.coordinates), "uiso": a.uiso, "flags": a.refinement_flags}
                    for a in ph.atoms()
                ],
            }
        )
    args.out.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
