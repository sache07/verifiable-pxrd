#!/usr/bin/env python3
"""Test one phase at a time for symmetry-compatible uniaxial microstrain."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--phase", type=int, choices=(0, 1), required=True)
    ap.add_argument("--axis", nargs=3, type=int, required=True)
    args = ap.parse_args()

    G2sc.SetPrintLevel("warn")
    p = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    p.set_Frozen()
    p.set_Controls("cycles", 12)
    p["Controls"]["data"]["min dM/M"] = 1e-5
    h = p.histogram(0)
    h.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    phases = p.phases()
    target = phases[args.phase]
    hap = target.getHAPvalues(h.name)
    iso = float(hap["Mustrain"][1][0])
    target.clear_HAP_refinements({"Mustrain": True})
    target.setSampleProfile(
        h.name, "microstrain", "uniaxial", iso, iso, axis=args.axis, LGmix=1.0
    )
    target.set_HAP_refinements(
        {"Mustrain": {"type": "uniaxial", "refine": True, "direction": args.axis}}
    )
    p.save()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    p.refine(printFile=str(args.out.with_suffix(".lst")))
    p.reload()
    h = p.histogram(0)
    result = {
        "target": p.phases()[args.phase].name,
        "axis": args.axis,
        "rwp": h.residuals.get("wR"),
        "profiles": [],
    }
    for ph in p.phases():
        hap = ph.getHAPvalues(h.name)
        result["profiles"].append(
            {"name": ph.name, "size": hap["Size"], "mustrain": hap["Mustrain"]}
        )
    args.out.with_suffix(".json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
