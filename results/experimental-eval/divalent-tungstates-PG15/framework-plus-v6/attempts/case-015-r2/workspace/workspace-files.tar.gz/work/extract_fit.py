#!/usr/bin/env python3
"""Export profile arrays and a compact GSAS-II project summary."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    project = G2.G2Project(gpxfile=str(args.project.resolve()))
    hist = project.histogram(0)
    names = ["X", "Yobs", "Ycalc", "Background", "Residual", "Yweight"]
    arrays = [np.asarray(hist.getdata(name), float) for name in names]
    np.savetxt(
        args.output,
        np.column_stack(arrays),
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference,weight",
        comments="",
    )
    masses = [
        phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ]
    summary = {
        "residuals": hist.residuals,
        "instrument": {k: v[1] if isinstance(v, list) and len(v) > 1 else v for k, v in hist.InstrumentParameters.items()},
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": [
            {
                "name": phase.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cell": phase.get_cell(),
                "weight_fraction": mass / sum(masses),
                "hap": phase.data["Histograms"][hist.name],
            }
            for phase, mass in zip(project.phases(), masses)
        ],
    }
    args.output.with_suffix(".json").write_text(json.dumps(summary, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
