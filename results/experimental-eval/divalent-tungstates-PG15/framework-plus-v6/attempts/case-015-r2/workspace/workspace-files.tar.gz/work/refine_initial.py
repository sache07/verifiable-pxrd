#!/usr/bin/env python3
"""Create and stage an initial GSAS-II Rietveld refinement for the scan."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def instrument_text() -> str:
    return (
        "#GSAS-II instrument parameter file for Cu Kalpha Bragg-Brentano data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:0.0;V:0.0;W:40.0;X:4.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def summarize(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    print(f"{label}: residuals={hist.residuals}")
    print(
        " instrument",
        {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")},
    )
    print(" background", hist.Background[0])
    print(" sample", {k: hist.SampleParameters[k] for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            " phase",
            phase.name,
            "cell",
            phase.get_cell(),
            "scale",
            hap["Scale"],
            "size",
            hap["Size"],
            "mustrain",
            hap["Mustrain"],
            "prefori",
            hap["Pref.Ori."],
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+", type=Path)
    args = parser.parse_args()

    root = args.output.parent.resolve()
    root.mkdir(parents=True, exist_ok=True)
    data = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
    xye = root / "pattern.xye"
    np.savetxt(xye, np.column_stack((data, np.sqrt(np.maximum(data[:, 1], 1.0)))), fmt="%.8f %.8f %.8f")
    instfile = root / "instrument.instprm"
    instfile.write_text(instrument_text())

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(args.output.resolve()))
    hist = project.add_powder_histogram(str(xye), str(instfile), fmthint="xye")
    hist.data["data"][0]["histTitle"] = "Observed Cu Kalpha powder scan"
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [float(data[0, 0]), float(data[-1, 0])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [650.0, -350.0, 200.0, -90.0, 35.0, -10.0],
                "refine": True,
            },
        }
    )

    phases = []
    for i, cif in enumerate(args.phases):
        phase = project.add_phase(str(cif.resolve()), phasename=f"phase_{i + 1}", fmthint="CIF", histograms=[hist])
        hap = phase.data["Histograms"][hist.name]
        # Equal starting mass fractions; GSAS phase mass is Scale * cell mass.
        hap["Scale"] = [10000.0 / (max(1, len(args.phases)) * phase.data["General"]["Mass"]), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        phases.append(phase)

    project.set_Controls("cycles", 12)
    project.refine()
    summarize(project, "scale+background")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine()
    summarize(project, "zero+cells")

    # Establish a common nonnegative instrumental baseline. V, Y and Z stay neutral.
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    project.refine()
    summarize(project, "common-profile")
    project.save()


if __name__ == "__main__":
    main()
