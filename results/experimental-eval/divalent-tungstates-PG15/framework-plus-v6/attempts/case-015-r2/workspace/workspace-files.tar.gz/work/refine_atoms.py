#!/usr/bin/env python3
"""Apply a controlled atomic-coordinate/thermal refinement stage."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def report(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    masses = [
        phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ]
    print("residuals", hist.residuals)
    print("Rvals", project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}))
    for phase, mass in zip(project.phases(), masses):
        print("phase", phase.id, phase.name, "fraction", mass / sum(masses))
        for index, atom in enumerate(phase.atoms()):
            print(
                " atom", index, atom.label, atom.element,
                "xyz", tuple(round(v, 8) for v in atom.coordinates),
                "Uiso", round(atom.uiso, 8), "flags", repr(atom.refinement_flags),
            )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--uiso", action="store_true", help="refine one common Uiso for the phase")
    parser.add_argument("--fixed-uiso", type=float, help="set and hold a common Uiso for the phase")
    parser.add_argument("--coords", default="", help="comma-separated atom labels, element symbols, or 'all'")
    parser.add_argument("--hold-axes", default="", help="coordinate axes (for example 'y') to hold for selected atoms")
    parser.add_argument("--freeze-coords", action="store_true", help="hold all coordinates in the phase")
    parser.add_argument("--cycles", type=int, default=18)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve()))
    project.set_Frozen()
    phase = project.phase(args.phase)

    if args.freeze_coords:
        for atom in phase.atoms():
            atom.refinement_flags = atom.refinement_flags.replace("X", "")

    if args.fixed_uiso is not None:
        for atom in phase.atoms():
            atom.uiso = args.fixed_uiso
            atom.refinement_flags = atom.refinement_flags.replace("U", "")

    if args.uiso:
        atoms = list(phase.atoms())
        # The registered-model convention and synthetic model both use a
        # single isotropic displacement parameter within each phase.
        for atom in atoms:
            atom.refinement_flags = "U"
        variables = tuple(f"{phase.id}::AUiso:{i}" for i in range(len(atoms)))
        if len(variables) > 1:
            project.add_EquivConstr(variables, override=True)
        for variable in variables:
            project.set_Controls("parmMin", 0.001, variable=variable)
            project.set_Controls("parmMax", 0.03, variable=variable)

    selectors = {item.strip() for item in args.coords.split(",") if item.strip()}
    if selectors:
        for index, atom in enumerate(phase.atoms()):
            if "all" in selectors or atom.label in selectors or atom.element in selectors:
                flags = atom.refinement_flags
                atom.refinement_flags = flags + ("" if "X" in flags else "X")
                for axis in args.hold_axes.lower():
                    if axis not in "xyz":
                        raise ValueError(f"invalid held coordinate axis: {axis}")
                    project.add_HoldConstr((f"{phase.id}::dA{axis}:{index}",), override=True)

    project.set_Controls("cycles", args.cycles)
    project.refine()
    report(project)
    project.save()


if __name__ == "__main__":
    main()
