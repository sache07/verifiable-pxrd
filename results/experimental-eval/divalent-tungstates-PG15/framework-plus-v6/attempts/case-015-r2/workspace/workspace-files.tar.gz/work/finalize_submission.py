#!/usr/bin/env python3
"""Create the audited final GSAS-II project and direct project exports."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


INSTRUMENT_KEYS = ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]
SAMPLE_KEYS = ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
EXPORTS = [
    ("ZnWO4 (wolframite)", "phase_ZnWO4_wolframite.cif"),
    ("WO3 (monoclinic)", "phase_WO3_monoclinic.cif"),
    ("ZnO (wurtzite)", "phase_ZnO_wurtzite.cif"),
]


def clear_dormant_constraints(project: G2.G2Project) -> None:
    constraints = project.data["Constraints"]["data"]
    for key in ("Hist", "HAP", "Phase", "Global"):
        constraints[key] = []
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}


def enforce_final_model(project: G2.G2Project) -> None:
    """Make the retained terms explicit and neutralize every rejected term."""
    clear_dormant_constraints(project)
    hist = project.histogram(0)
    phases = project.phases()
    if len(phases) != 3:
        raise RuntimeError(f"expected three phases, found {len(phases)}")

    # One angular correction: Bragg-Brentano specimen displacement. The
    # alternative constant zero correction was rejected in the model comparison.
    for key in INSTRUMENT_KEYS:
        hist.InstrumentParameters[key][2] = key in {"W", "X"}
    hist.InstrumentParameters["Zero"][1] = 0.0
    hist.InstrumentParameters["U"][1] = 0.0
    hist.InstrumentParameters["V"][1] = 0.0
    hist.InstrumentParameters["Y"][1] = 0.0
    hist.InstrumentParameters["Z"][1] = 0.0
    hist.InstrumentParameters["SH/L"][1] = 0.03
    hist.InstrumentParameters["Polariz."][1] = 0.9

    for key in SAMPLE_KEYS:
        if isinstance(hist.SampleParameters.get(key), list) and len(hist.SampleParameters[key]) > 1:
            hist.SampleParameters[key][1] = key == "Shift"
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.27, False]
    hist.SampleParameters["SurfRoughB"] = [0.18, False]
    hist.set_refinements({"Limits": [float(hist.getdata("X")[0]), float(hist.getdata("X")[-1])]})
    hist.set_refinements({"Background": {"refine": True}})

    for phase in phases:
        phase.set_refinements({"Cell": True, "Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Extinction"] = [0.0, False]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    # ZnWO4: no supported size/strain term; small [001] texture correction.
    hap = phases[0].data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0:2] = [0.0, 0.0]
    hap["Pref.Ori."][1] = float(hap["Pref.Ori."][1]) if hap["Pref.Ori."][2] else 0.9887
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = [0, 0, 1]

    # WO3: uniaxial microstrain is retained along [100].
    hap = phases[1].data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = [1, 0, 0]

    # ZnO: isotropic coherent-domain size; no supported strain or texture.
    hap = phases[2].data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][2] = [True, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0:2] = [0.0, 0.0]


def phase_fraction(project: G2.G2Project) -> list[float]:
    hist = project.histogram(0)
    masses = [
        phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ]
    return [float(value / sum(masses)) for value in masses]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    final_gpx = out / "final.gpx"

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(final_gpx))
    enforce_final_model(project)
    project.set_Controls("cycles", 40)
    project.refine()
    project.save()

    # Save/reopen/replay is part of the final audit, not merely a file copy.
    project = G2.G2Project(gpxfile=str(final_gpx))
    enforce_final_model(project)
    project.set_Controls("cycles", 40)
    project.refine()
    project.save()

    # Reopen once more so every export is taken from the exact persisted model.
    project = G2.G2Project(gpxfile=str(final_gpx))
    hist = project.histogram(0)
    fractions = phase_fraction(project)
    for phase, (_, filename) in zip(project.phases(), EXPORTS):
        phase.export_CIF(str(out / filename))

    x = np.asarray(hist.getdata("X"), float)
    observed = np.asarray(hist.getdata("Yobs"), float)
    calculated = np.asarray(hist.getdata("Ycalc"), float)
    difference = observed - calculated
    background = np.asarray(hist.getdata("Background"), float)
    np.savetxt(
        out / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt="%.10g",
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rp = float(100 * np.sum(np.abs(difference)) / np.sum(observed))
    covariance = project.data.get("Covariance", {}).get("data", {})
    nvars = int(covariance.get("Rvals", {}).get("Nvars", len(covariance.get("varyList", []))))
    values = {
        "histogram": hist.name,
        "fractions": fractions,
        "fit_statistics": {
            "Rwp_percent": float(100 * np.sqrt(chi_square / denominator)),
            "Rp_percent": rp,
            "chi_square": chi_square,
            "reduced_chi_square": float(chi_square / max(1, len(x) - nvars)),
            "GSAS_Rwp_percent": float(hist.residuals["wR"]),
            "GSAS_Rp_percent": float(hist.residuals["R"]),
            "data_points": int(len(x)),
            "refined_variables": nvars,
        },
        "instrument": {key: hist.InstrumentParameters[key][1] for key in INSTRUMENT_KEYS},
        "sample": {key: hist.SampleParameters[key][0] for key in SAMPLE_KEYS},
        "background_range_counts": [float(background.min()), float(background.max())],
        "calculated_range_counts": [float(calculated.min()), float(calculated.max())],
        "phases": [],
        "convergence": covariance.get("Rvals", {}),
    }
    for phase, (label, filename), fraction in zip(project.phases(), EXPORTS, fractions):
        hap = phase.data["Histograms"][hist.name]
        values["phases"].append(
            {
                "project_name": phase.name,
                "label": label,
                "cif": filename,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cell": phase.get_cell(),
                "weight_fraction": fraction,
                "scale": float(hap["Scale"][0]),
                "cell_mass": float(phase.data["General"]["Mass"]),
                "size": hap["Size"],
                "microstrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": list(atom.coordinates),
                        "occupancy": atom.occupancy,
                        "Uiso_A2": atom.uiso,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    (out / "work" / "final_values.json").write_text(json.dumps(values, indent=2, default=str) + "\n")
    print(json.dumps(values, indent=2, default=str))


if __name__ == "__main__":
    main()
