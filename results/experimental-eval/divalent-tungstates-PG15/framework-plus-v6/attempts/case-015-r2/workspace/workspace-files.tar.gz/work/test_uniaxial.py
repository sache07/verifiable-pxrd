#!/usr/bin/env python3
"""Test one phase for symmetry-axis uniaxial microstrain."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", type=int)
    parser.add_argument("axis", help="h,k,l")
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]
    if len(axis) != 3 or not any(axis):
        raise ValueError("axis must be a nonzero h,k,l triple")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve()))
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
    })
    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 10, "refine": True}})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True, "Size": {"type": "isotropic", "refine": True}})
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
    target = phases[args.phase]
    hap = target.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][1][1] = 1000.0
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = axis
    for phase in phases:
        limits = {
            f"{phase.id}:0:Scale": (0.0, 1.0e6),
            f"{phase.id}:0:Size;i": (0.04, 1.5),
        }
        if phase is target:
            limits[f"{phase.id}:0:Mustrain;i"] = (0.0, 8000.0)
            limits[f"{phase.id}:0:Mustrain;a"] = (0.0, 8000.0)
        for variable, (lower, upper) in limits.items():
            project.set_Controls("parmMin", lower, variable=variable)
            project.set_Controls("parmMax", upper, variable=variable)
    project.set_Controls("cycles", 12)
    project.refine()
    h = project.histogram(0)
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0] for p in phases]
    print("residuals", h.residuals)
    for phase, mass in zip(phases, masses):
        profile = phase.data["Histograms"][h.name]
        print(phase.name, mass / sum(masses), "size", profile["Size"], "mustrain", profile["Mustrain"])
    print("frozen", project.get_Frozen())
    project.save()


if __name__ == "__main__":
    main()
