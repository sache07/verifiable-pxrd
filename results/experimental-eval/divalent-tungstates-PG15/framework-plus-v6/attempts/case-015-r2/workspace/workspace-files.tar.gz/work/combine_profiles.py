#!/usr/bin/env python3
"""Refine selected phase-size and uniaxial-strain models together."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def axis(text: str) -> list[int] | None:
    if text.lower() == "none":
        return None
    values = [int(v) for v in text.split(",")]
    if len(values) != 3 or not any(values):
        raise ValueError("axis must be none or h,k,l")
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("axes", nargs="+", help="one none or h,k,l per phase")
    parser.add_argument("--phase0-ratio", type=float, help="constrain phase-0 axial/equatorial strain ratio")
    parser.add_argument("--phase0-fixed", help="fix phase-0 equatorial strain,axial/equatorial ratio")
    args = parser.parse_args()
    axes = [axis(v) for v in args.axes]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve()))
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()
    if len(axes) != len(phases):
        raise ValueError("need one axis specification per phase")
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
    })
    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 10, "refine": True}})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    initial = [(2000.0, 600.0), (2800.0, 4000.0), (1000.0, 1000.0)]
    for phase, direction, strain in zip(phases, axes, initial):
        phase.set_refinements({"Cell": True, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True, "Size": {"type": "isotropic", "refine": True}})
        hap = phase.data["Histograms"][hist.name]
        if direction is None:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][1][1] = 0.0
            hap["Mustrain"][2] = [False, False, False]
        else:
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][0] = strain[0]
            hap["Mustrain"][1][1] = strain[1]
            hap["Mustrain"][2] = [True, True, False]
            hap["Mustrain"][3] = direction
        limits = {
            f"{phase.id}:0:Scale": (0.0, 1.0e6),
            f"{phase.id}:0:Size;i": (0.04, 1.5),
        }
        if direction is not None:
            limits[f"{phase.id}:0:Mustrain;i"] = (300.0, 8000.0)
            limits[f"{phase.id}:0:Mustrain;a"] = (300.0, 8000.0)
        for variable, (lower, upper) in limits.items():
            project.set_Controls("parmMin", lower, variable=variable)
            project.set_Controls("parmMax", upper, variable=variable)
    if args.phase0_fixed is not None:
        if axes[0] is None:
            raise ValueError("phase-0 fixed strain needs an active phase-0 uniaxial model")
        eq, ratio = [float(v) for v in args.phase0_fixed.split(",")]
        if eq < 0 or ratio <= 0:
            raise ValueError("invalid fixed phase-0 strain")
        hap0 = phases[0].data["Histograms"][hist.name]
        hap0["Mustrain"][1][0] = eq
        hap0["Mustrain"][1][1] = eq * ratio
        hap0["Mustrain"][2] = [False, False, False]
    if args.phase0_ratio is not None:
        if args.phase0_fixed is not None:
            raise ValueError("choose a constrained or fixed phase-0 ratio, not both")
        if axes[0] is None or args.phase0_ratio <= 0:
            raise ValueError("phase-0 ratio needs an active phase-0 uniaxial model")
        # Equivalence convention: m0*v0 = m1*v1, hence axial = ratio*equatorial.
        project.add_EquivConstr(
            ("0:0:Mustrain;i", "0:0:Mustrain;a"),
            [1.0, 1.0 / args.phase0_ratio],
            override=True,
        )
    project.set_Controls("cycles", 16)
    project.refine()
    h = project.histogram(0)
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0] for p in phases]
    print("residuals", h.residuals)
    for phase, mass in zip(phases, masses):
        profile = phase.data["Histograms"][h.name]
        print(phase.name, mass / sum(masses), "size", profile["Size"], "mustrain", profile["Mustrain"])
    print("frozen", project.get_Frozen())
    project.save()


if __name__ == "__main__":
    main()
