#!/usr/bin/env python3
"""Re-challenge a converged one-phase project with one physical candidate."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def report(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    masses = [
        phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ]
    print(label, "residuals", hist.residuals)
    print("instrument", {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")})
    for phase, mass in zip(project.phases(), masses):
        hap = phase.data["Histograms"][hist.name]
        print(
            phase.name,
            "fraction",
            mass / sum(masses),
            "scale",
            hap["Scale"],
            "cell",
            phase.get_cell(),
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("--name", default="candidate")
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    primary = project.phase(0)
    candidate = project.add_phase(
        str(args.candidate.resolve()), phasename=args.name, fmthint="CIF", histograms=[hist]
    )
    # Start the candidate at 20 wt%, relative to the converged primary scale.
    primary_mass_scale = primary.data["General"]["Mass"] * primary.data["Histograms"][hist.name]["Scale"][0]
    candidate_hap = candidate.data["Histograms"][hist.name]
    candidate_hap["Scale"] = [0.25 * primary_mass_scale / candidate.data["General"]["Mass"], True]
    candidate_hap["Size"][0] = "isotropic"
    candidate_hap["Size"][1][0] = 10.0
    candidate_hap["Size"][2] = [False, False, False]
    candidate_hap["Mustrain"][0] = "isotropic"
    candidate_hap["Mustrain"][1][0] = 0.0
    candidate_hap["Mustrain"][1][1] = 0.0
    candidate_hap["Mustrain"][2] = [False, False, False]
    candidate_hap["Pref.Ori."][0] = "MD"
    candidate_hap["Pref.Ori."][1] = 1.0
    candidate_hap["Pref.Ori."][2] = False
    candidate_hap["Extinction"] = [0.0, False]
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        phase.set_HAP_refinements({"Scale": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]})
    hist.set_refinements({"Background": {"refine": True}})
    project.set_Controls("cycles", 12)
    project.refine()
    report(project, "scales")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    report(project, "cells")

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    project.refine()
    report(project, "profile")
    project.save()


if __name__ == "__main__":
    main()
