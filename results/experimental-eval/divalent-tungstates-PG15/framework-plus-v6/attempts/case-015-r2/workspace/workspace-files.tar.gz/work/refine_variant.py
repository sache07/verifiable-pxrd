#!/usr/bin/env python3
"""Apply one controlled GSAS-II refinement stage to a project copy."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


INSTRUMENT_KEYS = ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]
SAMPLE_KEYS = ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]


def floats(text: str, count: int) -> list[float]:
    values = [float(value) for value in text.split(",")]
    if len(values) != count:
        raise argparse.ArgumentTypeError(f"expected {count} comma-separated values")
    return values


def report(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    masses = [
        phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ]
    print("residuals", hist.residuals)
    print("instrument", {key: hist.InstrumentParameters[key] for key in INSTRUMENT_KEYS})
    print("sample", {key: hist.SampleParameters[key] for key in SAMPLE_KEYS})
    print("background", hist.Background[0])
    for phase, mass in zip(project.phases(), masses):
        hap = phase.data["Histograms"][hist.name]
        print(
            "phase",
            phase.name,
            "fraction",
            mass / sum(masses),
            "cell",
            phase.get_cell(),
            "size",
            hap["Size"],
            "mustrain",
            hap["Mustrain"],
            "prefori",
            hap["Pref.Ori."],
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--reset-flags", action="store_true")
    parser.add_argument("--background-coeffs", type=int)
    parser.add_argument("--instrument-values", help="U,W,X,SH/L,polarization")
    parser.add_argument("--refine-instrument", default="", help="comma-separated GSAS keys")
    parser.add_argument("--clear-instrument", default="", help="comma-separated GSAS keys")
    parser.add_argument("--zero-value", type=float)
    parser.add_argument("--shift-value", type=float)
    parser.add_argument("--roughness-values", help="SurfRoughA,SurfRoughB")
    parser.add_argument("--refine-roughness", action="store_true")
    parser.add_argument("--refine-sample", default="", help="comma-separated GSAS sample parameter keys")
    parser.add_argument("--size-values", help="one isotropic size in micrometres per phase")
    parser.add_argument("--refine-size", action="store_true")
    parser.add_argument("--size-phases", help="comma-separated phase indices to refine for size")
    parser.add_argument("--strain-values", help="one isotropic microstrain value in ppm per phase")
    parser.add_argument("--refine-strain", action="store_true")
    parser.add_argument("--strain-phases", help="comma-separated phase indices to refine for strain")
    parser.add_argument("--uniaxial-phase", type=int)
    parser.add_argument("--uniaxial-axis", help="h,k,l")
    parser.add_argument("--uniaxial-values", help="equatorial,axial strain in ppm")
    parser.add_argument("--texture-phase", type=int)
    parser.add_argument("--texture-axis", help="h,k,l")
    parser.add_argument("--texture-value", type=float, default=1.0)
    parser.add_argument("--refine-cells", action="store_true")
    parser.add_argument("--refine-scales", action="store_true")
    parser.add_argument("--physical-bounds", action="store_true")
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.base.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    phases = project.phases()
    if args.reset_flags:
        hist.clear_refinements({
            "Instrument Parameters": INSTRUMENT_KEYS,
            "Sample Parameters": SAMPLE_KEYS,
        })
        hist.set_refinements({"Background": {"refine": False}})
        for phase in phases:
            phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
            phase.clear_HAP_refinements(
                {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
            )
    if args.background_coeffs is not None:
        hist.set_refinements({
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_coeffs,
                "refine": True,
            }
        })
    if args.instrument_values:
        u, w, x, shl, pol = floats(args.instrument_values, 5)
        for key, value in zip(("U", "W", "X", "SH/L", "Polariz."), (u, w, x, shl, pol)):
            hist.InstrumentParameters[key][1] = value
    if args.zero_value is not None:
        hist.InstrumentParameters["Zero"][1] = args.zero_value
    if args.shift_value is not None:
        hist.SampleParameters["Shift"][0] = args.shift_value
    clear_inst = [key for key in args.clear_instrument.split(",") if key]
    if clear_inst:
        hist.clear_refinements({"Instrument Parameters": clear_inst})
    refine_inst = [key for key in args.refine_instrument.split(",") if key]
    if refine_inst:
        hist.set_refinements({"Instrument Parameters": refine_inst})
    if args.roughness_values:
        a, b = floats(args.roughness_values, 2)
        hist.SampleParameters["SurfRoughA"][0] = a
        hist.SampleParameters["SurfRoughB"][0] = b
    if args.refine_roughness:
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    refine_sample = [key for key in args.refine_sample.split(",") if key]
    if refine_sample:
        hist.set_refinements({"Sample Parameters": refine_sample})
    if args.size_values:
        values = floats(args.size_values, len(phases))
        for phase, value in zip(phases, values):
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = value
            hap["Size"][2] = [False, False, False]
    if args.refine_size or args.size_phases:
        selected = range(len(phases)) if not args.size_phases else [int(v) for v in args.size_phases.split(",")]
        for index in selected:
            phase = phases[index]
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    if args.strain_values:
        values = floats(args.strain_values, len(phases))
        for phase, value in zip(phases, values):
            hap = phase.data["Histograms"][hist.name]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = value
            hap["Mustrain"][1][1] = value
            hap["Mustrain"][2] = [False, False, False]
    if args.refine_strain or args.strain_phases:
        selected = range(len(phases)) if not args.strain_phases else [int(v) for v in args.strain_phases.split(",")]
        for index in selected:
            phase = phases[index]
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    if args.uniaxial_phase is not None:
        if not args.uniaxial_axis or not args.uniaxial_values:
            raise ValueError("uniaxial phase needs axis and values")
        direction = [int(v) for v in args.uniaxial_axis.split(",")]
        values = floats(args.uniaxial_values, 2)
        phase = phases[args.uniaxial_phase]
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0:2] = values
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = direction
    if args.texture_phase is not None:
        if not args.texture_axis:
            raise ValueError("texture phase needs an axis")
        direction = [int(v) for v in args.texture_axis.split(",")]
        phase = phases[args.texture_phase]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = args.texture_value
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = direction
    if args.refine_cells:
        for phase in phases:
            phase.set_refinements({"Cell": True})
    if args.refine_scales:
        for phase in phases:
            phase.set_HAP_refinements({"Scale": True})
    if args.physical_bounds:
        limits = {
            ":0:U": (0.0, 40.0),
            ":0:W": (2.0, 40.0),
            ":0:X": (0.1, 6.0),
            ":0:SH/L": (0.005, 0.1),
            ":0:Polariz.": (0.5, 1.0),
            ":0:SurfRoughA": (0.05, 0.6),
            ":0:SurfRoughB": (0.02, 0.5),
        }
        for phase in phases:
            limits[f"{phase.id}:0:Scale"] = (0.0, 1.0e6)
            limits[f"{phase.id}:0:Size;i"] = (0.04, 1.5)
            limits[f"{phase.id}:0:Mustrain;i"] = (0.0, 8000.0)
            limits[f"{phase.id}:0:Mustrain;a"] = (0.0, 8000.0)
            limits[f"{phase.id}:0:MD"] = (0.7, 1.4)
        for variable, (lower, upper) in limits.items():
            project.set_Controls("parmMin", lower, variable=variable)
            project.set_Controls("parmMax", upper, variable=variable)
    project.set_Controls("cycles", args.cycles)
    project.refine()
    report(project)
    project.save()


if __name__ == "__main__":
    main()
