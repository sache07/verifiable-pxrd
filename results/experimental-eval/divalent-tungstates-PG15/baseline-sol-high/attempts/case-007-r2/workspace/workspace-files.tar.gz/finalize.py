#!/usr/bin/env python3
"""Export the final GSAS-II refinement products requested by the task."""

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
GPX = ROOT / "final.gpx"
CIF_NAMES = {
    "MgWO4_wolframite": "MgWO4_wolframite.cif",
    "WO3_gamma_monoclinic": "WO3_gamma_monoclinic.cif",
    "MgO_periclase": "MgO_periclase.cif",
}


def main():
    project = G2sc.G2Project(str(GPX))
    hist = project.histogram(0)
    residuals = hist.residuals
    mass_fractions = hist.ComputeMassFracs()

    for phase in project.phases():
        phase.export_CIF(str(ROOT / CIF_NAMES[phase.name]))

    x, yobs, weight, ycalc, background, ydiff = hist.data["data"][1]
    lower = hist.Limits("lower")
    upper = hist.Limits("upper")
    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "two_theta_deg", "observed_counts", "calculated_counts",
            "difference_counts", "background_counts"
        ])
        for vals in zip(x, yobs, ycalc, background):
            xx, yo, yc, yb = (float(v) for v in vals)
            # GSAS-II stores calculated values only for the exact channel
            # slice used in refinement (the final channel may bracket a limit).
            if yc == 0.0:
                continue
            writer.writerow([
                f"{xx:.8f}", f"{yo:.8f}", f"{yc:.8f}",
                f"{yo-yc:.8f}", f"{yb:.8f}",
            ])

    rvals = project.data["Covariance"]["data"]["Rvals"]
    nobs = int(rvals["Nobs"])
    nvar = int(rvals["Nvars"])
    rwp = float(residuals["wR"])
    rexp = float(residuals["wRmin"])
    chi_square = float(rvals["chisq"])
    result = {
        "method": "Rietveld refinement with GSAS-II",
        "project": "final.gpx",
        "profile": "fit.csv",
        "refinement_range_two_theta_deg": [lower, upper],
        "phases": [],
        "fit_statistics": {
            "R_wp_percent": rwp,
            "R_p_percent": float(residuals["R"]),
            "R_wp_background_subtracted_percent": float(residuals["wRb"]),
            "R_p_background_subtracted_percent": float(residuals["Rb"]),
            "R_exp_percent": rexp,
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square_sum": chi_square,
            "reduced_chi_square": chi_square / (nobs - nvar),
            "observations": nobs,
            "refined_parameters": nvar,
        },
    }
    for index, phase in enumerate(project.phases()):
        frac, sigma = mass_fractions[phase.name]
        cell = phase.get_cell()
        result["phases"].append({
            "name": phase.name,
            "formula": {
                "MgWO4_wolframite": "MgWO4",
                "WO3_gamma_monoclinic": "WO3",
                "MgO_periclase": "MgO",
            }[phase.name],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": CIF_NAMES[phase.name],
            "weight_fraction": frac,
            "weight_percent": 100.0 * frac,
            "formal_weight_fraction_esd": sigma,
            "unit_cell": cell,
            "R_F_percent": float(residuals[f"{index}:0:Rf"]),
            "R_F_squared_percent": float(residuals[f"{index}:0:Rf^2"]),
        })
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
