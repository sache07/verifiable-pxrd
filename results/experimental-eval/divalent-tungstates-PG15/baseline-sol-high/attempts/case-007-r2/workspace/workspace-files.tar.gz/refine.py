#!/usr/bin/env python3
"""Build and refine the final GSAS-II model for the supplied PXRD pattern."""

import csv
import json
import math
import os
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "inputs" / "pattern.csv"
XYE = ROOT / "pattern.xye"
INST = ROOT / "cu_kalpha.instprm"
GPX = ROOT / "final.gpx"
SOURCE_CIFS = {
    "MgWO4_wolframite": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/9/01/39/9013902.cif"
    ),
    "WO3_gamma_monoclinic": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/1/52/89/1528915.cif"
    ),
    "MgO_periclase": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/9/00/04/9000499.cif"
    ),
}


def make_input_files():
    rows = []
    with INPUT.open(newline="") as handle:
        for row in csv.DictReader(handle):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            rows.append((x, y, math.sqrt(max(y, 1.0))))
    np.savetxt(XYE, np.asarray(rows), fmt=("%.8f", "%.8f", "%.8f"))
    INST.write_text(
        "#GSAS-II instrument parameter file for lab Cu K-alpha Bragg-Brentano data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.5;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:1000.0;V:0.0;W:200.0;X:5.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )


def summarize(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    print(label, hist.residuals)
    print(" cell", phase.get_cell())
    print(" inst", {k: v for k, v in hist.InstrumentParameters.items()
                     if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")})
    print(" scale", phase.data["Histograms"][hist.name]["Scale"])


def main():
    make_input_files()
    if GPX.exists():
        GPX.unlink()
    project = G2sc.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(
        str(XYE), str(INST), fmthint="xye"
    )
    phases = [
        project.add_phase(str(cif), phasename=name, histograms=[hist])
        for name, cif in SOURCE_CIFS.items()
    ]
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 99.9)
    project.data["Controls"]["data"]["max cyc"] = 8
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-4
    # Initialize a flexible smooth background, but keep the crystallographic
    # model deliberately parsimonious for this single-phase pattern.
    hist.set_refinements({
        "Background": {"type": "chebyschev-1", "no. coeffs": 12, "refine": True},
    })
    # GSAS-II enables the histogram-wide sample scale on import. With a phase
    # scale also active this is exactly singular, so retain only the HAP scale.
    hist.clear_refinements({"Sample Parameters": ["Scale"]})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.save()

    stages = [
        ("background and scale", {}),
        ("zero", {
            "set": {"Instrument Parameters": ["Zero"]},
        }),
        ("cell", {"set": {"Cell": True}}),
        ("Gaussian profile U,W", {"set": {"Instrument Parameters": ["U", "W"]}}),
        ("Gaussian profile V", {"set": {"Instrument Parameters": ["V"]}}),
        ("Lorentzian profile X", {"set": {"Instrument Parameters": ["X"]}}),
        ("Lorentzian profile Y", {"set": {"Instrument Parameters": ["Y"]}}),
    ]
    for label, recipe in stages:
        try:
            project.do_refinements([recipe])
            summarize(project, label)
        except Exception as exc:
            print("STAGE FAILED", label, repr(exc))
            raise

    project.save()
    summarize(project, "FINAL")

    # Store a machine-readable snapshot for downstream output generation.
    out = {
        "residuals": hist.residuals,
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {k: v for k, v in hist.InstrumentParameters.items()
                       if k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "SH/L")},
    }
    (ROOT / "refinement_snapshot.json").write_text(json.dumps(out, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
