#!/usr/bin/env python3
"""Build and refine trial GSAS-II models for the supplied PXRD pattern."""

from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(code: str) -> Path:
    return COD / code[0] / code[1:3] / code[3:5] / f"{code}.cif"


def prepare_inputs(work: Path) -> tuple[Path, Path]:
    work.mkdir(parents=True, exist_ok=True)
    xye = work / "pattern.xye"
    rows = []
    with (ROOT / "inputs/pattern.csv").open() as stream:
        for row in csv.DictReader(stream):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            rows.append((x, y, math.sqrt(max(y, 1.0))))
    np.savetxt(xye, rows, fmt="%.8f %.8f %.8f")

    inst = work / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for lab Cu Kalpha data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:2.0;V:-2.0;W:5.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def phase_scale(phase, histname: str, value: float) -> None:
    phase.data["Histograms"][histname]["Scale"][0] = value


def set_cell(phase, cell: list[float]) -> None:
    phase.data["General"]["Cell"][1:7] = cell
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="1010618")
    parser.add_argument("--name", default="trial")
    parser.add_argument("--final", action="store_true")
    parser.add_argument("--bawo4", action="store_true")
    args = parser.parse_args()

    work = ROOT / ".tmp" / args.name
    xye, inst = prepare_inputs(work)
    wo3_in = work / f"WO3_{args.wo3}.cif"
    bao2_in = work / "BaO2_1010113.cif"
    shutil.copyfile(cod_path(args.wo3), wo3_in)
    shutil.copyfile(cod_path("1010113"), bao2_in)

    outgpx = ROOT / ("final.gpx" if args.final else f".tmp/{args.name}.gpx")
    gpx = G2sc.G2Project(newgpx=str(outgpx))
    hist = gpx.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    wo3 = gpx.add_phase(str(wo3_in), phasename="WO3", histograms=[hist], fmthint="CIF")
    bao2 = gpx.add_phase(str(bao2_in), phasename="BaO2", histograms=[hist], fmthint="CIF")
    bawo4 = None
    if args.bawo4:
        bawo4_in = work / "BaWO4_1527204.cif"
        shutil.copyfile(cod_path("1527204"), bawo4_in)
        bawo4 = gpx.add_phase(str(bawo4_in), phasename="BaWO4", histograms=[hist], fmthint="CIF")
    phase_scale(wo3, hist.name, 1.0)
    phase_scale(bao2, hist.name, 0.4)
    if bawo4 is not None:
        phase_scale(bawo4, hist.name, 0.02)
    # Only relative phase scales are refined; the global histogram scale is
    # fixed to avoid an exact scale-factor singularity.
    hist.SampleParameters["Scale"] = [1.0, False]

    # Peak locations and the common broad profile can be read directly from
    # this high-count pattern. Starting close to those values keeps the
    # nonlinear cell/profile refinement in its physical basin.
    if args.wo3 == "1528915":
        set_cell(wo3, [7.321, 7.539, 7.695, 90.0, 90.73, 90.0])
    set_cell(bao2, [3.817, 3.817, 6.851, 90.0, 90.0, 90.0])
    ip = hist.InstrumentParameters
    for key, value in {"Zero": 0.297, "U": 0.0, "V": 0.0, "W": 1.0,
                       "X": 10.0, "Y": 61.0, "SH/L": 0.002}.items():
        ip[key][1] = value
        ip[key][2] = False

    hist.set_refinements({"Limits": [10.0, 100.0]})
    # A flexible smooth Chebyshev background handles the strong low-angle
    # air/scatter slope without assigning it to phase scale factors.
    hist.set_refinements({"Background": {"type": "chebyschev-1", "refine": True,
                                         "no. coeffs": 18}})

    # Stable staged Rietveld refinement: scale/background, cells/zero, then
    # profile terms and isotropic size/microstrain for each phase.
    gpx.set_Controls("cycles", 12)
    stages = [
        {"set": {"PhaseFraction": True, "Background": True}},
        {"set": {"Cell": True}},
        {"set": {"Instrument Parameters": ["X", "Y"]}},
        {"set": {"Instrument Parameters": ["Zero"]}},
        {},
    ]
    for i, project in enumerate(gpx.iter_refinements(stages)):
        print("STAGE", i + 1, json.dumps(project.histogram(0).residuals, sort_keys=True))
        print("CELLS", {p.name: p.get_cell() for p in project.phases()})

    gpx.save()
    mass_fracs = hist.ComputeMassFracs()
    print("FINAL_RESIDUALS", json.dumps(hist.residuals, sort_keys=True))
    print("MASS_FRACS", mass_fracs)
    print("INSTRUMENT", {k: v for k, v in hist.InstrumentParameters.items() if k in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]})
    for p in gpx.phases():
        print("PHASE", p.name, p.get_cell(), p.data["Histograms"][hist.name])

    if args.final:
        # Export exactly the models and profile stored in final.gpx.
        for p in gpx.phases():
            p.export_CIF(str(ROOT / f"{p.name}.cif"))

        x = hist.getdata("x")
        yobs = hist.getdata("yobs")
        ycalc = hist.getdata("ycalc")
        background = hist.getdata("background")
        # GSAS-II pads points outside the selected refinement limits with
        # zero calculated intensity. Export only the 8,284 fitted points.
        use = ycalc != 0
        columns = [x[use], yobs[use], ycalc[use],
                   (yobs - ycalc)[use], background[use]]
        with (ROOT / "fit.csv").open("w", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(["two_theta_deg", "observed", "calculated",
                             "difference", "background"])
            writer.writerows(zip(*columns))

        r = hist.residuals
        rv = gpx.data["Covariance"]["data"]["Rvals"]
        phase_meta = {
            "WO3": ("WO3", "P 21/c", 14),
            "BaO2": ("BaO2", "I 4/m m m", 139),
        }
        phases_json = []
        for p in gpx.phases():
            formula, sg, sgno = phase_meta[p.name]
            frac, su = mass_fracs[p.name]
            cell, cell_su = p.get_cell_and_esd()
            phases_json.append({
                "name": p.name,
                "formula": formula,
                "space_group": sg,
                "space_group_number": sgno,
                "cif_path": f"{p.name}.cif",
                "weight_fraction": frac,
                "weight_fraction_formal_su": su,
                "weight_percent": 100.0 * frac,
                "unit_cell": cell,
                "unit_cell_formal_su": cell_su,
            })
        result = {
            "phases": phases_json,
            "fraction_basis": "normalized over modeled crystalline phases",
            "fit_statistics": {
                "Rp_percent": r["R"],
                "Rwp_percent": r["wR"],
                "Rexp_percent": r["wRmin"],
                "goodness_of_fit": rv["GOF"],
                "chi_square": rv["chisq"],
                "observations": rv["Nobs"],
                "refined_variables": rv["Nvars"],
                "converged": bool(rv["converged"]),
            },
            "project_path": "final.gpx",
            "profile_path": "fit.csv",
        }
        (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

        wo3_frac, wo3_su = mass_fracs["WO3"]
        bao2_frac, bao2_su = mass_fracs["BaO2"]
        wc = gpx.phase("WO3").get_cell()
        bc = gpx.phase("BaO2").get_cell()
        report = f"""# PXRD phase analysis

The crystalline pattern is modeled by monoclinic WO3 (P 21/c, No. 14) and tetragonal BaO2 (I 4/m m m, No. 139). The refined crystalline-only fractions are **{100*wo3_frac:.2f} wt% WO3** and **{100*bao2_frac:.2f} wt% BaO2**. These fractions sum to 100% over the modeled crystalline material; amorphous content is not measurable from this dataset alone.

## Evidence

The monoclinic WO3 model accounts for the diagnostic 23.42/23.92/24.66 degree triplet and its higher-angle families, while BaO2 accounts for the paired features near 26.33/27.07 degrees and lines at 33.54, 42.98, 46.64, 47.97, and 55.3-55.9 degrees. A trial BaWO4 phase refined to about 0.13(15) wt% and its characteristic approximately 32 degree line is absent, so it was not retained. The refined cells are WO3: a={wc['length_a']:.5f}, b={wc['length_b']:.5f}, c={wc['length_c']:.5f} A, beta={wc['angle_beta']:.4f} degrees; BaO2: a={bc['length_a']:.5f}, c={bc['length_c']:.5f} A.

The final GSAS-II Rietveld fit converged with Rp={r['R']:.3f}%, Rwp={r['wR']:.3f}%, Rexp={r['wRmin']:.3f}%, and goodness of fit={rv['GOF']:.3f}. Since pointwise uncertainties were not supplied, counting uncertainties were taken as sqrt(counts). A Cu Kalpha1/Kalpha2 model used the reported wavelengths and 0.5 intensity ratio; the refined zero offset is {hist.InstrumentParameters['Zero'][1]:.4f} degrees.

## Uncertainty and limits

The covariance-matrix standard uncertainties of the fractions are only {100*wo3_su:.2f} and {100*bao2_su:.2f} percentage points, but they do not include model systematics. The peaks are broad, the instrument profile was not calibrated, and WO3/BaO2 overlap strongly near 26-34 degrees; a more realistic compositional uncertainty is about 2-3 wt% absolute. Oxygen occupancy in the peroxide was not refined, so the data support the BaO2 structure type but do not reliably distinguish ideal BaO2 from a slightly oxygen-deficient peroxide. Minor crystalline phases below roughly 0.5-1 wt% and any amorphous material cannot be excluded reliably.
"""
        (ROOT / "report.md").write_text(report)


if __name__ == "__main__":
    main()
