from pathlib import Path
import sys
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
mode = sys.argv[1]
source = ROOT / ('texture.gpx' if mode in ('stabilized', 'continue_texture') else 'trial.bak0.gpx')
proj = G2sc.G2Project(str(source), newgpx=str(ROOT / f'{mode}.gpx'))
proj.data['Controls']['data']['max cyc'] = 12
hist = proj.histogram(0)
phases = {p.name: p for p in proj.phases()}

# Remove the redundant overall-scale degree of freedom. Relative phase scales
# remain refined and are converted to mass fractions by GSAS-II.
hist.data['Sample Parameters']['Scale'][1] = False
for ph in phases.values():
    ph.clear_HAP_refinements({'Size': True, 'Mustrain': True}, [hist])

if mode in ('texture', 'size_texture'):
    po = phases['CaCO3_calcite'].getHAPvalues(hist.name)['Pref.Ori.']
    po[0], po[1], po[2], po[3] = 'MD', 1.0, True, [1, 0, 4]

if mode == 'size_texture':
    # The common profile was established from the full pattern. Hold it fixed
    # while testing positive-only isotropic domain-size broadening.
    hist.clear_refinements({'Instrument Parameters': ['U','V','W','X','Y','SH/L']})
    starts = {'WO3_monoclinic': 10.0, 'CaWO4_scheelite': 0.1, 'CaCO3_calcite': 10.0}
    for name, ph in phases.items():
        ph.set_HAP_refinements({'Size': {'type': 'isotropic', 'value': starts[name], 'refine': True}}, [hist])

if mode == 'stabilized':
    # Axial divergence and zero are >97% correlated for this uncalibrated
    # profile. Retain the fitted asymmetry value but hold it fixed.
    hist.clear_refinements({'Instrument Parameters': ['SH/L']})

proj.do_refinements([{}])
proj.save()
print('MODE', mode, 'Rwp', hist.get_wR(), 'mass_fractions', hist.ComputeMassFracs())
print('sample scale', hist.data['Sample Parameters']['Scale'])
print('instrument', {k:v for k,v in hist.data['Instrument Parameters'][0].items()
                     if k in ('Zero','U','V','W','X','Y','SH/L')})
for ph in proj.phases():
    hap = ph.getHAPvalues(hist.name)
    print(ph.name, 'cell', ph.get_cell(), 'scale', hap['Scale'],
          'PO', hap['Pref.Ori.'][:4], 'size', hap['Size'][:3])
