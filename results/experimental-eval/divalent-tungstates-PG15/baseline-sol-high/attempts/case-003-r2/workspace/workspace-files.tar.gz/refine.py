from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')

def cod_cif(cod_id):
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'

proj = G2sc.G2Project(newgpx=str(ROOT / 'trial.gpx'))
hist = proj.add_powder_histogram(str(ROOT / 'pattern.xye'), str(ROOT / 'instrument.instprm'), fmthint='xye')
phase_specs = [
    ('WO3_monoclinic', '2311041'),
    ('CaWO4_scheelite', '7219229'),
    ('CaCO3_calcite', '1547347'),
]
phases = []
for name, cod_id in phase_specs:
    phases.append(proj.add_phase(str(cod_cif(cod_id)), phasename=name, histograms=[hist]))

proj.data['Controls']['data']['max cyc'] = 8
hist.set_refinements({
    'Limits': [10.0, 100.0],
    'Background': {'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 15},
})
for ph in phases:
    ph.set_HAP_refinements({'Scale': True}, [hist])

def status(label):
    print('\nSTATUS', label, 'Rwp=', hist.get_wR())
    print('residuals', hist.data['data'][0])
    print('inst', {k:v for k,v in hist.data['Instrument Parameters'][0].items()
                   if k in ('Zero','U','V','W','X','Y','Z','SH/L')})
    for ph in phases:
        hap = ph.getHAPvalues(hist.name)
        print(ph.name, 'scale=', hap['Scale'], 'cell=', ph.get_cell(),
              'size=', hap['Size'], 'mustrain=', hap['Mustrain'])

# Establish background and phase scales, then progressively release parameters.
proj.do_refinements([{}])
status('scales/background')
hist.set_refinements({'Instrument Parameters': ['Zero']})
proj.do_refinements([{}])
status('zero')
for ph in phases:
    ph.set_refinements({'Cell': True})
proj.do_refinements([{}])
status('cells')
hist.set_refinements({'Instrument Parameters': ['U','V','W','X','Y','SH/L']})
proj.do_refinements([{}])
status('instrument profile')
for ph in phases:
    ph.set_HAP_refinements({
        'Size': {'type': 'isotropic', 'value': 1.0, 'refine': True},
        'Mustrain': {'type': 'isotropic', 'refine': True},
    }, [hist])
proj.do_refinements([{}])
status('sample broadening')
proj.save(ROOT / 'trial.gpx')
