from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
proj = G2sc.G2Project(str(ROOT / 'texture.gpx'), newgpx=str(ROOT / 'final.gpx'))
proj.save()
hist = proj.histogram(0)

phase_info = {
    'WO3_monoclinic': {
        'name': 'tungsten(VI) oxide (monoclinic)', 'formula': 'WO3',
        'cif': 'phase_wo3.cif', 'cod': '2311041', 'systematic_uncertainty': 0.03,
    },
    'CaWO4_scheelite': {
        'name': 'calcium tungstate (scheelite)', 'formula': 'CaWO4',
        'cif': 'phase_cawo4.cif', 'cod': '7219229', 'systematic_uncertainty': 0.02,
    },
    'CaCO3_calcite': {
        'name': 'calcium carbonate (calcite)', 'formula': 'CaCO3',
        'cif': 'phase_calcite.cif', 'cod': '1547347', 'systematic_uncertainty': 0.03,
    },
}

mass_fracs = hist.ComputeMassFracs()
phases_out = []
residuals = hist.data['data'][0]
for phase in proj.phases():
    info = phase_info[phase.name]
    phase.export_CIF(str(ROOT / info['cif']))
    value, esd = mass_fracs[phase.name]
    pid = phase.id
    phases_out.append({
        'name': info['name'],
        'formula': info['formula'],
        'space_group': phase.data['General']['SGData']['SpGrp'].strip(),
        'cif_path': info['cif'],
        'structure_source': f'COD {info["cod"]}',
        'weight_fraction': value,
        'weight_percent': 100.0 * value,
        'weight_fraction_formal_esd': esd,
        'weight_fraction_estimated_systematic_uncertainty': info['systematic_uncertainty'],
        'bragg_r_factor_percent': residuals[f'{pid}:0:Rf'],
        'refined_cell': phase.get_cell(),
    })

x = np.asarray(hist.getdata('X'), dtype=float)
yobs = np.asarray(hist.getdata('Yobs'), dtype=float)
ycalc = np.asarray(hist.getdata('Ycalc'), dtype=float)
bkg = np.asarray(hist.getdata('Background'), dtype=float)
diff = yobs - ycalc
# GSAS-II evaluates bins whose centers straddle the nominal limits, so select
# the exact set for which it populated the calculated profile.
use = (ycalc != 0.0) | (bkg != 0.0)
np.savetxt(
    ROOT / 'fit.csv',
    np.column_stack((x[use], yobs[use], ycalc[use], diff[use], bkg[use])),
    delimiter=',',
    header='two_theta_deg,observed_counts,calculated_counts,difference_observed_minus_calculated_counts,background_counts',
    comments='',
    fmt='%.10g',
)

rvals = proj.data['Covariance']['data']['Rvals']
result = {
    'phases': phases_out,
    'weight_fraction_basis': 'normalized over modeled crystalline phases; sums to 1',
    'fit_statistics': {
        'r_wp_percent': residuals['wR'],
        'r_p_percent': residuals['R'],
        'r_exp_percent': residuals['wRmin'],
        'goodness_of_fit': rvals['GOF'],
        'chi_square': rvals['chisq'],
        'reduced_chi_square': rvals['GOF'] ** 2,
        'n_observations': rvals['Nobs'],
        'n_refined_variables': rvals['Nvars'],
        'fit_range_two_theta_deg': [10.0, 100.0],
        'difference_definition': 'observed - calculated',
    },
    'measurement_model': {
        'radiation': 'Cu K-alpha doublet',
        'wavelength_kalpha1_angstrom': 1.540598,
        'wavelength_kalpha2_angstrom': 1.544426,
        'kalpha2_to_kalpha1_ratio': 0.5,
        'weights': 'Poisson approximation, sigma = sqrt(observed counts)',
        'refined_zero_offset_two_theta_deg': hist.data['Instrument Parameters'][0]['Zero'][1],
    },
    'project_path': 'final.gpx',
    'profile_path': 'fit.csv',
}
(ROOT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
