from pathlib import Path
import json
import shutil
import csv
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
FINAL = ROOT / 'final.gpx'
shutil.copy2(ROOT / 'physical.gpx', FINAL)
gpx = G2sc.G2Project(str(FINAL))
hist = gpx.histogram(0)
x = np.asarray(hist.getdata('x'), dtype=float)
hist.Limits('lower', float(x[0]))
hist.Limits('upper', float(x[-1]))
gpx.set_Controls('cycles', 12)
# Repeat to make sure the final saved project, over the full supplied range,
# is at the local minimum used for all exported quantities.
for _ in range(3):
    gpx.do_refinements([{}])
gpx.save(str(FINAL))

hist = gpx.histogram(0)
phases = gpx.phases()
cif_names = ['phase_1_WO3_triclinic.cif', 'phase_2_BaO2_tetragonal.cif']
for phase, name in zip(phases, cif_names):
    phase.export_CIF(str(ROOT / name))

x = np.asarray(hist.getdata('x'), dtype=float)
yobs = np.asarray(hist.getdata('yobs'), dtype=float)
ycalc = np.asarray(hist.getdata('ycalc'), dtype=float)
bkg = np.asarray(hist.getdata('background'), dtype=float)
diff = yobs - ycalc
with (ROOT / 'fit.csv').open('w', newline='') as fp:
    writer = csv.writer(fp)
    writer.writerow(['two_theta_deg', 'observed', 'calculated',
                     'difference_observed_minus_calculated', 'background'])
    writer.writerows(zip(x, yobs, ycalc, diff, bkg))

mass_fracs = hist.ComputeMassFracs()
res = hist.residuals
weights = np.asarray(hist.getdata('yweight'), dtype=float)
cov = gpx.data['Covariance']['data']
n_variables = len(cov.get('varyList', []))
chi_sq = float(np.sum(weights * diff**2))
n_points = int(len(x))
dof = n_points - n_variables
reduced_chi_sq = chi_sq / dof

phase_records = []
for phase, cif_name in zip(phases, cif_names):
    fraction, fraction_esd = mass_fracs[phase.name]
    phase_records.append({
        'name': 'triclinic WO3' if 'WO3' in phase.name else 'tetragonal BaO2',
        'formula': 'WO3' if 'WO3' in phase.name else 'BaO2',
        'space_group': phase.data['General']['SGData']['SpGrp'].strip(),
        'cif_path': cif_name,
        'weight_fraction': float(fraction),
        'weight_fraction_formal_esd': float(fraction_esd),
        'cell': {k: float(v) for k, v in phase.get_cell().items()},
    })

result = {
    'phases': phase_records,
    'weight_fraction_basis': 'normalized over modeled crystalline phases; sums to 1',
    'fit_statistics': {
        'Rwp_percent': float(res['wR']),
        'Rp_percent': float(res['R']),
        'Rwp_background_subtracted_percent': float(res['wRb']),
        'R_expected_percent': float(res['wRmin']),
        'goodness_of_fit_Rwp_over_Rexp': float(res['wR'] / res['wRmin']),
        'chi_squared': chi_sq,
        'reduced_chi_squared': reduced_chi_sq,
        'n_points': n_points,
        'n_refined_variables': n_variables,
        'WO3_R_F_percent': float(res['0:0:Rf']),
        'WO3_R_F_squared_percent': float(res['0:0:Rf^2']),
        'BaO2_R_F_percent': float(res['1:0:Rf']),
        'BaO2_R_F_squared_percent': float(res['1:0:Rf^2']),
    },
    'profile_path': 'fit.csv',
    'gsasii_project_path': 'final.gpx',
    'uncertainty_note': ('Formal e.s.d. values use Poisson counting weights inferred as '
                         'sigma=sqrt(counts); no pointwise uncertainties or calibrated '
                         'instrument profile were supplied, so systematic uncertainty is larger.'),
}
(ROOT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')

report = f'''# PXRD phase analysis

## Result

The modeled crystalline material is **triclinic WO3 (P -1)** at **{phase_records[0]['weight_fraction']*100:.2f} wt%** and **tetragonal BaO2 (I 4/m m m)** at **{phase_records[1]['weight_fraction']*100:.2f} wt%**, normalized over those two crystalline phases. The final full-range Rietveld fit has Rwp = {res['wR']:.2f}%, Rp = {res['R']:.2f}%, Rexp = {res['wRmin']:.2f}%, and GOF = {res['wR']/res['wRmin']:.2f}.

## Evidence

The WO3 model accounts for the diagnostic low-angle triplet at approximately 23.42, 23.92, and 24.66 degrees 2theta and its repeated split-peak families near 33.5-34.5, 42, 47-50, and 55-56 degrees. BaO2 is independently required by the peaks near 26.33/27.07, 33.54, 42.98, 46.64, and 55.86 degrees. A BaWO4 product is not supported: its characteristic 31.85-degree reflection is absent above the fitted background, and adding product-like peak positions is not needed to explain the profile.

The room-temperature monoclinic WO3 models are close alternatives because WO3 polymorphs are pseudosymmetrically related. Under the same physically constrained profile treatment, the best monoclinic P21/c model gave Rwp = 8.59%, versus {res['wR']:.2f}% for P -1, and the triclinic model better reproduced the observed splitting. Higher-symmetry tetragonal/orthorhombic WO3 models fit substantially worse. This supports P -1, but the exact WO3 symmetry remains the principal structural uncertainty.

## Refinement and uncertainty

The GSAS-II model used Cu Kalpha1/Kalpha2 wavelengths 1.540598/1.544426 A with the reported 0.5 intensity ratio. A 12-term Chebyshev background, zero offset, lattice parameters, phase scales, one angle-dependent Gaussian width term, and isotropic crystallite-size terms were refined. A positive fixed baseline instrumental width was retained because no calibrated profile was supplied. Refined apparent sizes are about 0.15 micrometers for WO3 and 0.10 micrometers for BaO2; these are profile parameters, not robust particle-size measurements.

Atomic coordinates were retained from COD 2106293 (WO3) and COD 1010113 (BaO2); the submitted CIFs contain the refined cells and those reference coordinates. The data do not justify an unconstrained atomic-coordinate refinement. Formal fraction e.s.d.'s are about {phase_records[0]['weight_fraction_formal_esd']*100:.2f} percentage points, but this understates uncertainty because pointwise errors and a calibrated instrumental profile were unavailable. A practical model-dependent uncertainty is several percentage points. Fractions exclude any amorphous content, which cannot be quantified without an internal standard.
'''
(ROOT / 'report.md').write_text(report)

print(json.dumps(result, indent=2))
