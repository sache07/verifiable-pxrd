from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(ROOT / 'optimized.gpx'))
hist = gpx.histogram(0)
wo3, bao2 = gpx.phases()
gpx.set_Controls('cycles', 12)

# Keep a positive, fixed constant-width contribution and refine only the
# angle-dependent Gaussian term. Remove the unphysical microstrain trial.
hist.InstrumentParameters['W'][1:] = [60.0, False]
hist.InstrumentParameters['U'][1:] = [1500.0, True]
hist.InstrumentParameters['V'][1:] = [-10.0, False]
for phase in (wo3, bao2):
    hap = phase.getHAPvalues(hist.name)
    hap['Size'][1][0] = 1.0
    hap['Size'][2][0] = False
    hap['Mustrain'][1][0] = 1000.0
    hap['Mustrain'][2][0] = False

gpx.do_refinements([{}])
print('BASE', hist.residuals, hist.ComputeMassFracs())
for phase in (wo3, bao2):
    phase.set_HAP_refinements({'Size': {'type': 'isotropic', 'value': 0.10,
                                        'refine': True}})
gpx.do_refinements([{}])
print('SIZE', hist.residuals, hist.ComputeMassFracs())
print('INST', {k: hist.InstrumentParameters[k] for k in
               ('Zero', 'U', 'V', 'W', 'X', 'Y')})
for phase in (wo3, bao2):
    print(phase.name, phase.get_cell(),
          phase.getHAPvalues(hist.name)['Size'])
gpx.save(str(ROOT / 'physical.gpx'))
