from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def summarize(gpx, label):
    hist = gpx.histogram(0)
    print('\nSUMMARY', label)
    print('residuals', hist.residuals)
    print('instrument', {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ('Lam1', 'Lam2', 'I(L2)/I(L1)', 'Zero',
                                  'U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L')})
    print('sample', hist.SampleParameters)
    for phase in gpx.phases():
        print(phase.name, phase.get_cell(),
              'scale', phase.getHAPvalues(hist.name)['Scale'],
              'mass', phase.data['General']['Mass'])
    try:
        print('mass fractions', hist.ComputeMassFracs())
    except Exception as exc:
        print('mass fraction error', repr(exc))


def main():
    out = ROOT / 'trial.gpx'
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(str(ROOT / 'pattern.xye'),
                                    str(ROOT / 'cu_kalpha.instprm'),
                                    fmthint='xye')
    hist.Limits('lower', 10.0)
    hist.Limits('upper', 100.0)

    wo3 = gpx.add_phase(str(cod_cif('1010618')), phasename='WO3_monoclinic',
                        histograms=[hist], fmthint='CIF')
    bao2 = gpx.add_phase(str(cod_cif('1010113')), phasename='BaO2_tetragonal',
                         histograms=[hist], fmthint='CIF')

    # A flexible but smooth background is needed for the strongly curved raw-count baseline.
    hist.set_refinements({'Background': {'type': 'chebyschev-1',
                                         'no. coeffs': 12,
                                         'refine': True}})
    wo3.set_HAP_refinements({'Scale': True})
    bao2.set_HAP_refinements({'Scale': True})
    gpx.set_Controls('cycles', 8)
    gpx.save(str(out))

    # Stabilize scale/background first, then peak positions and profile terms.
    gpx.do_refinements([{}])
    summarize(gpx, 'scale/background')

    wo3.set_refinements({'Cell': True})
    bao2.set_refinements({'Cell': True})
    hist.set_refinements({'Instrument Parameters': ['Zero']})
    gpx.do_refinements([{}])
    summarize(gpx, 'cells/zero')

    hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
    gpx.do_refinements([{}])
    summarize(gpx, 'instrument profile')

    wo3.set_HAP_refinements({'Size': {'type': 'isotropic', 'value': 1.0,
                                      'refine': True}})
    bao2.set_HAP_refinements({'Size': {'type': 'isotropic', 'value': 1.0,
                                       'refine': True}})
    gpx.do_refinements([{}])
    summarize(gpx, 'size')

    gpx.save(str(out))


if __name__ == '__main__':
    main()
