from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')

def cif(cid):
    return COD / cid[0] / cid[1:3] / cid[3:5] / f'{cid}.cif'

for cid in ('1528915', '2311041'):
    out = ROOT / f'physical_{cid}.gpx'
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(str(ROOT / 'pattern.xye'),
                                    str(ROOT / 'cu_kalpha.instprm'),
                                    fmthint='xye')
    hist.Limits('lower', 10.0); hist.Limits('upper', 100.0)
    hist.clear_refinements({'Sample Parameters': ['Scale']})
    wo3 = gpx.add_phase(str(cif(cid)), phasename=f'WO3_{cid}',
                        histograms=[hist], fmthint='CIF')
    bao2 = gpx.add_phase(str(cif('1010113')), phasename='BaO2',
                         histograms=[hist], fmthint='CIF')
    hist.set_refinements({'Background': {'type': 'chebyschev-1',
                                         'no. coeffs': 12, 'refine': True}})
    for ph in (wo3, bao2): ph.set_HAP_refinements({'Scale': True})
    gpx.set_Controls('cycles', 12)
    gpx.save(str(out)); gpx.do_refinements([{}])

    hist.InstrumentParameters['Zero'][1] = 0.295
    hist.InstrumentParameters['U'][1] = 900.0
    hist.InstrumentParameters['W'][1] = 60.0
    hist.InstrumentParameters['W'][2] = False
    hist.set_refinements({'Instrument Parameters': ['Zero', 'U']})
    wo3.set_refinements({'Cell': True}); bao2.set_refinements({'Cell': True})
    for _ in range(2): gpx.do_refinements([{}])
    for ph in (wo3, bao2):
        ph.set_HAP_refinements({'Size': {'type': 'isotropic', 'value': 0.10,
                                         'refine': True}})
    gpx.do_refinements([{}])
    gpx.save(str(out))
    print('FINALMODEL', cid, hist.residuals, hist.ComputeMassFracs(),
          wo3.get_cell(), bao2.get_cell())
