from pathlib import Path
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(ROOT / 'compare_2106293.gpx'))
hist = gpx.histogram(0)
wo3, bao2 = gpx.phases()
gpx.set_Controls('cycles', 12)

# Reset the over-correlated Caglioti trial to a physically reasonable starting profile.
for key, value in {'U': 20.0, 'V': -10.0, 'W': 50.0,
                   'X': 5.0, 'Y': 5.0, 'Zero': 0.0}.items():
    hist.InstrumentParameters[key][1] = value
    hist.InstrumentParameters[key][2] = False

def show(tag):
    print('STATE', tag, hist.residuals, hist.ComputeMassFracs())
    print('INST', {k: hist.InstrumentParameters[k] for k in
                   ('Zero', 'U', 'V', 'W', 'X', 'Y')})
    print('CELLS', wo3.get_cell(), bao2.get_cell())
    for phase in (wo3, bao2):
        hap = phase.getHAPvalues(hist.name)
        print('HAP', phase.name, hap['Scale'], hap['Size'], hap['Mustrain'])

# Cell parameters had not reached convergence in the broad-profile model.
for i in range(3):
    gpx.do_refinements([{}])
    show(f'cell_{i}')

# Refine the zero offset only after lattice parameters have stabilized.
hist.set_refinements({'Instrument Parameters': ['Zero']})
gpx.do_refinements([{}])
show('zero')

# Use a restrained profile sequence: constant Gaussian width, then angle term.
hist.set_refinements({'Instrument Parameters': ['W']})
gpx.do_refinements([{}])
show('W')
hist.set_refinements({'Instrument Parameters': ['U']})
gpx.do_refinements([{}])
show('UW')

# Phase-specific broadening captures the visibly different peak widths.
for phase in (wo3, bao2):
    phase.set_HAP_refinements({'Size': {'type': 'isotropic', 'value': 0.15,
                                        'refine': True}})
gpx.do_refinements([{}])
show('size')
for phase in (wo3, bao2):
    phase.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
gpx.do_refinements([{}])
show('size_strain')

gpx.save(str(ROOT / 'optimized.gpx'))
