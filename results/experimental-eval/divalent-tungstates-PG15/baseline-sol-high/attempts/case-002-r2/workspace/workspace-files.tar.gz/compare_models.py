from pathlib import Path
import traceback

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
CANDIDATES = ['1528915', '1563541', '2311041', '2106293', '2107312',
              '1521532', '1521533']


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def run(cod_id):
    path = ROOT / f'compare_{cod_id}.gpx'
    gpx = G2sc.G2Project(newgpx=str(path))
    hist = gpx.add_powder_histogram(str(ROOT / 'pattern.xye'),
                                    str(ROOT / 'cu_kalpha.instprm'),
                                    fmthint='xye')
    hist.Limits('lower', 10.0)
    hist.Limits('upper', 100.0)
    # Remove the exact global-scale/HAP-scale redundancy.
    hist.clear_refinements({'Sample Parameters': ['Scale']})
    wo3 = gpx.add_phase(str(cod_cif(cod_id)), phasename=f'WO3_{cod_id}',
                        histograms=[hist], fmthint='CIF')
    bao2 = gpx.add_phase(str(cod_cif('1010113')), phasename='BaO2',
                         histograms=[hist], fmthint='CIF')
    hist.set_refinements({'Background': {'type': 'chebyschev-1',
                                         'no. coeffs': 12,
                                         'refine': True}})
    wo3.set_HAP_refinements({'Scale': True})
    bao2.set_HAP_refinements({'Scale': True})
    gpx.set_Controls('cycles', 10)
    gpx.save(str(path))
    gpx.do_refinements([{}])
    wo3.set_refinements({'Cell': True})
    bao2.set_refinements({'Cell': True})
    gpx.do_refinements([{}])
    # Refine only stable Gaussian profile terms for model comparison.
    hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W']})
    gpx.do_refinements([{}])
    fractions = hist.ComputeMassFracs()
    print('RESULT', cod_id, hist.residuals, fractions,
          wo3.get_cell(), bao2.get_cell())


for cod_id in CANDIDATES:
    try:
        run(cod_id)
    except Exception as exc:
        print('FAILED', cod_id, repr(exc))
        traceback.print_exc()
