from pathlib import Path
import csv
import json
import math
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent

gpx = G2sc.G2Project(str(ROOT / 'trial2.gpx'), newgpx=str(ROOT / 'final.gpx'))
h = gpx.histogram(0)

# SH/L and zero shift were >97% correlated when both were varied. Retain the
# converged asymmetry value and refine the remaining active parameters.
inst = h.data['Instrument Parameters'][0]
inst['SH/L'][2] = False
for _ in range(2):
    gpx.do_refinements([{}])
gpx.save()

phase_dir = ROOT / 'phases'
phase_dir.mkdir(exist_ok=True)
cif_paths = {}
for phase in gpx.phases():
    out = phase_dir / f'{phase.name}.cif'
    phase.export_CIF(str(out))
    cif_paths[phase.name] = str(out.relative_to(ROOT))

x = np.asarray(h.getdata('X'), dtype=float)
yobs = np.asarray(h.getdata('Yobs'), dtype=float)
ycalc = np.asarray(h.getdata('Ycalc'), dtype=float)
bkg = np.asarray(h.getdata('Background'), dtype=float)
diff = yobs - ycalc
with open(ROOT / 'fit.csv', 'w', newline='') as f:
    wr = csv.writer(f)
    wr.writerow(['two_theta_deg', 'observed_intensity', 'calculated_intensity',
                 'difference_intensity', 'background_intensity'])
    wr.writerows(zip(x, yobs, ycalc, diff, bkg))

fractions = h.ComputeMassFracs()
res = h.data['data'][0]
cov = gpx.data['Covariance']['data']
nvar = len(cov.get('varyList', []))
nobs = int(res['Nobs'])
chisq = float(cov.get('Rvals', {}).get('chisq', np.sum(diff**2 / np.maximum(yobs, 1.0))))
gof = math.sqrt(chisq / max(nobs - nvar, 1))

formula = {'NiWO4': 'NiWO4', 'WO3': 'WO3'}
phases = []
for phase in gpx.phases():
    frac, esd = fractions[phase.name]
    cell, cell_esd = phase.get_cell_and_esd()
    phases.append({
        'name': phase.name,
        'formula': formula[phase.name],
        'cif_path': cif_paths[phase.name],
        'weight_fraction': frac,
        'weight_fraction_esd': esd,
        'weight_percent': 100.0 * frac,
        'cell': cell,
        'cell_esd': cell_esd,
    })

fit_stats = {
    'Rwp_percent': float(res['wR']),
    'Rp_percent': float(res['R']),
    'Rexp_percent': float(res['wRmin']),
    'goodness_of_fit': gof,
    'chi_squared': chisq,
    'number_of_observations': nobs,
    'number_of_refined_variables': nvar,
    'difference_definition': 'observed - calculated',
}
result = {
    'phases': phases,
    'weight_fraction_basis': 'normalized over modeled crystalline phases',
    'fit_statistics': fit_stats,
    'profile_path': 'fit.csv',
    'gsasii_project_path': 'final.gpx',
}
with open(ROOT / 'result.json', 'w') as f:
    json.dump(result, f, indent=2)
    f.write('\n')

ni = next(p for p in phases if p['name'] == 'NiWO4')
wo = next(p for p in phases if p['name'] == 'WO3')
report = f'''# PXRD phase analysis

The crystalline pattern is modeled by two phases: wolframite-type **NiWO4** (monoclinic P2/c) and residual **WO3** (room-temperature monoclinic P21/n). The refined crystalline-phase-normalized fractions are **{ni['weight_percent']:.2f} wt% NiWO4** and **{wo['weight_percent']:.2f} wt% WO3**.

## Evidence

NiWO4 accounts for the dominant 30.87 degree line and its coherent families near 15.60, 19.19, 23.91, 24.85, 31.48, 36.52, 41.63, 54.58, 62.28, and 65.8 degrees 2theta. Monoclinic WO3 is required by the characteristic triplet at 23.06, 23.53, and 24.28 degrees and supporting lines near 33-34 and 49.87 degrees. These lines are not allowed by the NiWO4 model and are fitted together by the WO3 structure.

A trial NiO phase refined to 0.055(102) wt% and did not improve Rwp; it is therefore not detected reliably and was excluded from the submitted crystalline model. No further coherent unmatched line family supports another phase.

## Refinement and uncertainty

The final GSAS-II Rietveld fit has Rwp = {fit_stats['Rwp_percent']:.3f}%, Rp = {fit_stats['Rp_percent']:.3f}%, Rexp = {fit_stats['Rexp_percent']:.3f}%, and goodness-of-fit = {fit_stats['goodness_of_fit']:.3f} over {nobs} points. Cu Kalpha1/Kalpha2 wavelengths and the reported 0.5 intensity ratio were used. Unit cells, phase scales, a common empirical peak profile, zero shift, and a 15-term Chebyshev background were refined; atomic coordinates and occupancies were retained from reference structures.

The covariance-only fraction standard uncertainties are {100*ni['weight_fraction_esd']:.3f} and {100*wo['weight_fraction_esd']:.3f} percentage points, but they understate systematic error. Because no calibrated instrumental profile or external standard was supplied, peak broadening, preferred orientation, microabsorption, and background choices are partly confounded. A practical uncertainty of about 1-2 wt% is more realistic. Fractions are normalized only over the modeled crystalline phases; amorphous content, if present, cannot be quantified from these data alone.
'''
(ROOT / 'report.md').write_text(report)

print(json.dumps(result, indent=2))
