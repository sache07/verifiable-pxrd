from pathlib import Path
import csv
import numpy as np
import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent

def make_xye():
    rows = []
    with open(ROOT/'inputs/pattern.csv', newline='') as f:
        rd = csv.DictReader(f)
        for r in rd:
            y = float(r['intensity'])
            rows.append((float(r['two_theta_deg']), y, max(y, 1.0)**0.5))
    np.savetxt(ROOT/'pattern.xye', rows, fmt='%.8f %.8f %.8f')

def summarize(gpx, tag):
    h = gpx.histogram(0)
    print(tag, 'wR', h.get_wR(), 'residuals', h.data['data'][0])
    print('instrument', h.data['Instrument Parameters'][0])
    print('sample', h.data['Sample Parameters'])
    print('background', h.data['Background'][0])
    for p in gpx.phases():
        print('phase', p.name, 'cell', p.get_cell(), 'density', p.density,
              'scale', p.data['Histograms'][h.name]['Scale'],
              'size', p.data['Histograms'][h.name]['Size'],
              'mustrain', p.data['Histograms'][h.name]['Mustrain'])

def main():
    make_xye()
    gpx = G2sc.G2Project(newgpx=str(ROOT/'trial.gpx'))
    h = gpx.add_powder_histogram(str(ROOT/'pattern.xye'), str(ROOT/'instrument.instprm'), fmthint='xye')
    p = gpx.add_phase(str(ROOT/'niwo4_start.cif'), phasename='NiWO4', histograms=[h])
    p2 = gpx.add_phase(str(ROOT/'wo3_start.cif'), phasename='WO3', histograms=[h])
    h.Limits('lower', 10.05)
    h.Limits('upper', 99.90)
    # Chebyshev background; refine progressively for stability.
    h.set_refinements({'Background': {'type':'chebyschev-1', 'refine':True, 'no. coeffs':15}})
    # The overall sample scale and individual phase scales are redundant.
    h.data['Sample Parameters']['Scale'] = [1.0, False]
    p.set_HAP_refinements({'Scale': True}, [h])
    p2.set_HAP_refinements({'Scale': True}, [h])
    gpx.do_refinements([{}])
    summarize(gpx, 'scale+bkg')
    p.set_refinements({'Cell': True})
    p2.set_refinements({'Cell': True})
    gpx.do_refinements([{}])
    summarize(gpx, 'cell+shift')
    h.set_refinements({'Instrument Parameters':['U','V','W']})
    gpx.do_refinements([{}])
    summarize(gpx, 'profile')
    print('mass fractions', h.ComputeMassFracs())
    gpx.save()

if __name__ == '__main__':
    main()
