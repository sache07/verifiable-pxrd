#!/usr/bin/env python3
"""Nested-model check with the tentative BaWO4 phase set to zero."""

from GSASII import GSASIIscriptable as G2sc

G2sc.SetPrintLevel("warn")
project = G2sc.G2Project("final.gpx", newgpx=".tmp/no_bawo4.gpx")
hist = project.histogram(0)
phase = project.phase("BaWO4")
phase.getHAPvalues(hist)["Scale"] = [0.0, False]
project.set_Controls("cycles", 10)
project.do_refinements([{}])
print(project.data["Covariance"]["data"]["Rvals"])
