#!/usr/bin/env python3
"""Finalize the selected GSAS-II model and export all requested deliverables."""

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(".tmp/instrument_uwx.gpx", newgpx="final.gpx")
hist = project.histogram(0)
phases = project.phases()

# Include every measured point. Alternate position and profile blocks to avoid
# the strong cell/zero/profile correlations seen when all are varied together.
x = np.asarray(hist.getdata("X"), dtype=float)
hist.Limits("lower", float(x[0]))
hist.Limits("upper", float(x[-1]))
project.set_Controls("cycles", 10)

for _ in range(2):
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases[:2]:
        phase.set_refinements({"Cell": True})
    phases[2].clear_refinements({"Cell": True})  # trace phase: literature cell
    project.do_refinements([{}])

    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.clear_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.do_refinements([{}])

# One final cycle block with the reported profile and phase scales active.
project.do_refinements([{}])
project.save("final.gpx")

# Re-open the exact saved project before export, ensuring every derivative
# output is tied to the submitted GPX state.
project = G2sc.G2Project("final.gpx")
hist = project.histogram(0)
phases = project.phases()

cif_files = {
    "WO3": "phase_1_WO3.cif",
    "BaCO3": "phase_2_BaCO3.cif",
    "BaWO4": "phase_3_BaWO4.cif",
}
for phase in phases:
    phase.export_CIF(cif_files[phase.name])

x = np.asarray(hist.getdata("X"), dtype=float)
yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
bkg = np.asarray(hist.getdata("Background"), dtype=float)
diff = yobs - ycalc
with Path("fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
    writer.writerows(zip(x, yobs, ycalc, diff, bkg))

cov = project.data["Covariance"]["data"]
rvals = cov["Rvals"]
lo, hi = hist.data["Limits"][1]
mask = (x >= lo) & (x <= hi)
rp = 100.0 * np.abs(diff[mask]).sum() / np.abs(yobs[mask]).sum()
rwp = float(rvals["Rwp"])
gof = float(rvals["GOF"])
rexp = rwp / gof
mass = hist.ComputeMassFracs()

source_cod = {"WO3": "2311041", "BaCO3": "9010928", "BaWO4": "1527204"}
phase_results = []
for phase in phases:
    fraction, esd = mass[phase.name]
    phase_results.append({
        "name": phase.name,
        "formula": phase.name,
        "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
        "cif_path": cif_files[phase.name],
        "weight_fraction": float(fraction),
        "weight_fraction_esd_formal": float(esd),
        "source_structure_cod_id": source_cod[phase.name],
    })

result = {
    "phases": phase_results,
    "weight_fraction_normalization": "modeled crystalline phases sum to 1.0",
    "fit_statistics": {
        "R_wp_percent": rwp,
        "R_p_percent": float(rp),
        "R_exp_percent": float(rexp),
        "goodness_of_fit": gof,
        "reduced_chi_square": gof * gof,
        "chi_square": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_variables": int(rvals["Nvars"]),
        "two_theta_range_deg": [float(lo), float(hi)],
    },
    "profile_path": "fit.csv",
    "gsas_project_path": "final.gpx",
}
with Path("result.json").open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps({
    "result": result,
    "cells": {phase.name: phase.get_cell_and_esd() for phase in phases},
    "instrument": {
        key: hist.data["Instrument Parameters"][0][key]
        for key in ("Zero", "U", "V", "W", "X", "Y")
    },
    "Rvals": {key: value for key, value in rvals.items()
              if isinstance(value, (int, float, str, bool, type(None)))},
}, indent=2, default=float))
