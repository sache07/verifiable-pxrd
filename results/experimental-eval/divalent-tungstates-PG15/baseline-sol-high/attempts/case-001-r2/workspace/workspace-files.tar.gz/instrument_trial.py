#!/usr/bin/env python3
"""Evaluate reduced, positive-definite instrument-profile parameterizations."""

import argparse
import json
from GSASII import GSASIIscriptable as G2sc


ap = argparse.ArgumentParser()
ap.add_argument("mode", choices=("uwx", "wx", "ux"))
args = ap.parse_args()
G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(".tmp/trial_with_bawo4.gpx",
                         newgpx=f".tmp/instrument_{args.mode}.gpx")
hist = project.histogram(0)
inst = hist.data["Instrument Parameters"][0]
for key, value in {"U": 100.0, "V": 0.0, "W": 25.0,
                   "X": 10.0, "Y": 0.0}.items():
    inst[key][1] = value
    inst[key][2] = False

# Hold positions while replacing the profile model, and leave no sample-size
# terms active. Background and phase scales remain refined.
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
inst["Zero"][2] = False

hist.set_refinements({"Instrument Parameters": list(args.mode.upper())})
project.set_Controls("cycles", 12)
project.do_refinements([{}])
project.save()
print(json.dumps({
    "mode": args.mode,
    "Rwp": project.data["Covariance"]["data"]["Rvals"]["Rwp"],
    "GOF": project.data["Covariance"]["data"]["Rvals"]["GOF"],
    "instrument": {k: inst[k][1] for k in ("U", "V", "W", "X", "Y")},
    "mass_fractions": hist.ComputeMassFracs(),
}, indent=2))
