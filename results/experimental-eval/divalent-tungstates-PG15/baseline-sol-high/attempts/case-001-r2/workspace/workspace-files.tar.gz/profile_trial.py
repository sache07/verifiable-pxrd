#!/usr/bin/env python3
"""Test physically constrained broadening models from the selected phase model."""

import argparse
import json
from GSASII import GSASIIscriptable as G2sc


ap = argparse.ArgumentParser()
ap.add_argument("mode", choices=("fixed", "ux", "uwx"))
args = ap.parse_args()
G2sc.SetPrintLevel("warn")

project = G2sc.G2Project(".tmp/trial_with_bawo4.gpx",
                         newgpx=f".tmp/profile_{args.mode}.gpx")
hist = project.histogram(0)
inst = hist.data["Instrument Parameters"][0]
for key, value in {"U": 50.0, "V": 0.0, "W": 25.0,
                   "X": 5.0, "Y": 0.0}.items():
    inst[key][1] = value
    inst[key][2] = False

# Use phase broadening only where the phase intensity supports it. The trace
# phase inherits the common instrumental width and is not given extra freedom.
for phase in project.phases()[:2]:
    phase.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=0.5)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=0.5)
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    }, [hist])

project.set_Controls("cycles", 8)
project.do_refinements([{}])
if args.mode == "ux":
    hist.set_refinements({"Instrument Parameters": ["U", "X"]})
    project.do_refinements([{}])
elif args.mode == "uwx":
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.do_refinements([{}])
project.save()

print(json.dumps({
    "mode": args.mode,
    "Rwp": project.data["Covariance"]["data"]["Rvals"]["Rwp"],
    "GOF": project.data["Covariance"]["data"]["Rvals"]["GOF"],
    "instrument": {k: inst[k][1] for k in ("U", "V", "W", "X", "Y")},
    "mass_fractions": hist.ComputeMassFracs(),
    "profiles": {
        p.name: {k: p.getHAPvalues(hist)[k] for k in ("Size", "Mustrain")}
        for p in project.phases()
    },
}, indent=2))
