#!/usr/bin/env python3
"""Add a candidate trace phase to an existing GSAS-II model."""

import json
from pathlib import Path
from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")
source = Path(".tmp/trial_m2311041b.gpx")
project = G2sc.G2Project(str(source), newgpx=".tmp/trial_with_bawo4.gpx")
hist = project.histogram(0)
cod = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/72/1527204.cif")
phase = project.add_phase(str(cod), phasename="BaWO4", histograms=[hist], fmthint="CIF")
phase.getHAPvalues(hist)["Scale"][0] = 0.1
phase.set_HAP_refinements({"Scale": True}, [hist])
project.set_Controls("cycles", 6)
project.do_refinements([{}])
project.save()
print(json.dumps({
    "Rwp": project.data["Covariance"]["data"]["Rvals"]["Rwp"],
    "GOF": project.data["Covariance"]["data"]["Rvals"]["GOF"],
    "mass_fractions": hist.ComputeMassFracs(),
    "scales": {p.name: p.getHAPvalues(hist)["Scale"] for p in project.phases()},
}, indent=2))
