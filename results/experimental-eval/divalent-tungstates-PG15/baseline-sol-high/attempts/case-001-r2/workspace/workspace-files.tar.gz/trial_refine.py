#!/usr/bin/env python3
"""Run compact GSAS-II trial refinements for phase-model selection."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("name")
    ap.add_argument("phases", nargs="+", help="phase_name:COD_ID")
    args = ap.parse_args()

    G2sc.SetPrintLevel("warn")
    out = Path(".tmp") / f"trial_{args.name}.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram("inputs/pattern.csv", "instrument.instprm")
    # The CSV importer enables the overall sample scale by default. Hold it at
    # unity so it is not exactly redundant with every phase scale.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)

    phases = []
    for spec in args.phases:
        name, cod_id = spec.split(":", 1)
        phases.append(project.add_phase(str(cod_path(cod_id)), phasename=name,
                                        histograms=[hist], fmthint="CIF"))

    # Eight background coefficients handle the broad, smoothly decaying air/
    # specimen background without using narrow terms that could mimic Bragg peaks.
    hist.set_refinements({"Background": {"type": "chebyschev-1",
                                          "refine": True,
                                          "no. coeffs": 8}})
    project.set_Controls("cycles", 5)

    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    steps = [
        {},
        {"set": {"Cell": True}},
        {"set": {"Instrument Parameters": ["Zero"]}},
        {"set": {"Instrument Parameters": ["U", "V", "W"]}},
        {"set": {"Instrument Parameters": ["X", "Y"]}},
        {},
    ]
    try:
        project.do_refinements(steps)
    except Exception as exc:
        print(json.dumps({"model": args.name, "error": repr(exc)}))
        return

    cov = project.data["Covariance"]["data"]
    result = {
        "model": args.name,
        "Rwp": cov.get("Rvals", {}).get("Rwp"),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "wR_hist": hist.get_wR(),
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {k: v[1] for k, v in hist.data["Instrument Parameters"][0].items()},
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "scales": {p.name: p.getHAPvalues(hist)["Scale"] for p in project.phases()},
        "residual_abs_sum": float(np.abs(hist.getdata("Residual")).sum()),
    }
    project.save()
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
