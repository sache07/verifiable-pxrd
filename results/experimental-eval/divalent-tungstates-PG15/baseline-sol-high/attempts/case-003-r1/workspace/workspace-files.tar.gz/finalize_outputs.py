#!/usr/bin/env python3
"""Freeze the selected GSAS-II model and export all requested deliverables."""

from pathlib import Path
import csv
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/tri_finaltest.bak0.gpx"
FINAL = ROOT / "final.gpx"


def rename_phase(project, old, new):
    phase_data = project.data["Phases"].pop(old)
    phase_data["General"]["Name"] = new
    project.data["Phases"][new] = phase_data
    phase_names = next(row for row in project.names if row[0] == "Phases")
    phase_names[phase_names.index(old)] = new
    for hist in project.histograms():
        refl = hist.data["Reflection Lists"]
        refl[new] = refl.pop(old)
        for key, value in hist.data["data"][0].items():
            if key.endswith("::Name") and value == old:
                hist.data["data"][0][key] = new


def main():
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    rename_phase(project, "WO3_monoclinic", "WO3_triclinic")
    project.save()

    # Reload the exact submitted project before every derived export.
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)

    cif_names = {
        "WO3_triclinic": "WO3_triclinic.cif",
        "CaWO4_scheelite": "CaWO4_scheelite.cif",
        "CaCO3_calcite": "CaCO3_calcite.cif",
    }
    formulas = {
        "WO3_triclinic": "WO3",
        "CaWO4_scheelite": "CaWO4",
        "CaCO3_calcite": "CaCO3",
    }
    for phase_name, filename in cif_names.items():
        project.phase(phase_name).export_CIF(str(ROOT / filename))

    x = np.asarray(hist.getdata("x"), dtype=float)
    observed = np.asarray(hist.getdata("yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("ycalc"), dtype=float)
    difference = np.asarray(hist.getdata("residual"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    low, high = hist.data["Limits"][1]
    # GSAS-II includes the first grid point that brackets the upper limit.
    # Reproduce that exact slice so fit.csv has the same Nobs as the project.
    first = int(np.searchsorted(x, low))
    last = int(np.searchsorted(x, high)) + 1
    use = slice(first, last)
    with (ROOT / "fit.csv").open("w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow([
            "two_theta_deg", "observed_counts", "calculated_counts",
            "difference_counts", "background_counts",
        ])
        writer.writerows(zip(x[use], observed[use], calculated[use],
                             difference[use], background[use]))

    mass_fracs = hist.ComputeMassFracs()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    residuals = hist.residuals
    phases = []
    for phase_name in cif_names:
        value, su = mass_fracs[phase_name]
        phase = project.phase(phase_name)
        phases.append({
            "name": phase_name,
            "formula": formulas[phase_name],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": cif_names[phase_name],
            "weight_fraction": value,
            "weight_fraction_formal_su": su,
        })

    result = {
        "phases": phases,
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "fit_statistics": {
            "Rp_percent": residuals["R"],
            "Rwp_percent": residuals["wR"],
            "Rexp_percent": residuals["wRmin"],
            "goodness_of_fit": rvals["GOF"],
            "chi_squared": rvals["chisq"],
            "background_Rp_percent": residuals["Rb"],
            "background_Rwp_percent": residuals["wRb"],
            "n_observations": rvals["Nobs"],
            "n_refined_variables": rvals["Nvars"],
            "two_theta_range_deg": [low, high],
        },
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    with (ROOT / "result.json").open("w") as fp:
        json.dump(result, fp, indent=2)
        fp.write("\n")

    report = f"""# PXRD phase analysis

## Result

The crystalline pattern is modeled with three phases:

| Phase | Structural model | Crystalline weight fraction |
|---|---|---:|
| WO3 | triclinic P -1 | {100*mass_fracs['WO3_triclinic'][0]:.2f}% |
| CaWO4 | scheelite, I 41/a | {100*mass_fracs['CaWO4_scheelite'][0]:.2f}% |
| CaCO3 | calcite, R -3 c | {100*mass_fracs['CaCO3_calcite'][0]:.2f}% |

Fractions are normalized only over the modeled crystalline phases. The fit over {low:.1f}-{high:.1f} degrees 2theta has Rp = {residuals['R']:.2f}%, Rwp = {residuals['wR']:.2f}%, Rexp = {residuals['wRmin']:.2f}%, and GOF = {rvals['GOF']:.2f}.

## Evidence

The 23-25 degree triplet and the dense higher-angle family identify WO3. A triclinic P -1 model fits the resolved splitting materially better than the pseudo-monoclinic P21/c alternative (unaugmented Rwp about 9.64% versus 11.70%). Scheelite CaWO4 is required by its independent reflections near 18.9, 29.0, 34.5, and 47.5 degrees, while calcite is required by the 29.7, 36.3, 39.7, and 43.5 degree family. These assignments are also chemically consistent with partial reaction of CaCO3 and WO3 at the reported 500 degrees C.

The refinement used the supplied Cu K-alpha1/K-alpha2 wavelengths and ratio, a reflection-geometry specimen shift, phase scales and cells, a smooth 10-term background, and peak-profile terms. The broad CaWO4 contribution required an isotropic microstrain term. Atomic coordinates were retained from the reference structures.

## Remaining uncertainty

The GSAS-II covariance matrix gives formal fraction standard uncertainties of {100*mass_fracs['WO3_triclinic'][1]:.2f}, {100*mass_fracs['CaWO4_scheelite'][1]:.2f}, and {100*mass_fracs['CaCO3_calcite'][1]:.2f} percentage points, but these understate model uncertainty. No calibrated instrumental profile or pointwise uncertainties were supplied; Poisson counting uncertainties were used. The broad CaWO4 fraction is coupled to its line-broadening model and is realistically uncertain by roughly 2-3 percentage points. The WO3 cell is close to monoclinic metric symmetry, so the subtle P -1 versus P21/c polymorph distinction is less secure than the chemical phase identity, despite the better P -1 profile fit. Amorphous material, if present, is not quantified, and all reported fractions exclude it. Residual intensity remains around several modeled peak clusters, so trace phases below the profile residual cannot be ruled out reliably.
"""
    (ROOT / "report.md").write_text(report)


if __name__ == "__main__":
    main()
