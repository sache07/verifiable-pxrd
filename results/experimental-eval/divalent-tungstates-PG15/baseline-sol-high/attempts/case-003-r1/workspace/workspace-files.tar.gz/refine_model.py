#!/usr/bin/env python3
"""Build and refine the three-phase GSAS-II model for pattern.csv."""

from pathlib import Path
import csv
import math
import sys

import numpy as np

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "pattern.xye"
INST = ROOT / "instrument.instprm"
GPX = ROOT / "final.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def convert_pattern() -> None:
    with (ROOT / "inputs/pattern.csv").open(newline="") as src, DATA.open("w") as dst:
        reader = csv.DictReader(src)
        dst.write("# two_theta intensity sigma\n")
        for row in reader:
            y = float(row["intensity"])
            dst.write(f'{float(row["two_theta_deg"]):.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n')


def build() -> G2sc.G2Project:
    convert_pattern()
    project = G2sc.G2Project(newgpx=str(GPX), author="Codex PXRD analysis")
    hist = project.add_powder_histogram(str(DATA), str(INST), fmthint="xye")
    specs = [
        ("WO3_monoclinic", "1528915"),
        ("CaWO4_scheelite", "7219229"),
        ("CaCO3_calcite", "1547347"),
    ]
    for name, cod_id in specs:
        project.add_phase(str(cod_path(cod_id)), phasename=name,
                          histograms=[hist], fmthint="CIF")
    project.save()
    return project


def show(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    print("hist", hist.name)
    print("residuals", hist.residuals)
    print("instrument", hist.InstrumentParameters)
    print("sample", hist.SampleParameters)
    print("background", hist.Background[0])
    print("limits", hist.data["Limits"])
    for phase in project.phases():
        print("phase", phase.name, phase.composition, phase.get_cell())
        print("HAP", phase.data["Histograms"][hist.name])


def summarize(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as err:
        print("mass fractions unavailable", err)
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")})
    print("sample", {k: v for k, v in hist.SampleParameters.items()
                     if k in ("Scale", "DisplaceX", "Shift", "Transparency")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "scale", hap["Scale"], "cell", phase.get_cell(),
              "size", hap["Size"][:3], "mustrain", hap["Mustrain"][:3])


def refine() -> G2sc.G2Project:
    project = build()
    hist = project.histogram(0)
    project.set_Controls("cycles", 8)
    hist.SampleParameters["Scale"] = [1.0, False]
    # In GSAS-II, reflection-mode specimen displacement is "Shift" in microns.
    # The observed peaks are about 0.25 degrees above reference positions at low
    # angle, corresponding to a specimen height offset of roughly -0.4 mm.
    hist.SampleParameters["Shift"] = [-430.0, False]
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 10},
    })
    for phase, start in zip(project.phases(), (4.0, 1.0, 10.0)):
        phase.data["Histograms"][hist.name]["Scale"][0] = start
        phase.set_HAP_refinements({"Scale": True})
    for _ in range(2):
        project.refine()
    summarize(project, "background and scales (fixed specimen shift)")

    project.set_Controls("parmMin", -1000.0, variable=":0:Shift")
    project.set_Controls("parmMax", 200.0, variable=":0:Shift")
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for _ in range(2):
        project.refine()
    summarize(project, "plus specimen shift")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    for _ in range(3):
        project.refine()
    summarize(project, "plus unit cells")

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    for _ in range(2):
        project.refine()
    summarize(project, "plus Gaussian profile")

    hist.set_refinements({"Instrument Parameters": ["X", "Y"]})
    for _ in range(3):
        project.refine()
    summarize(project, "plus Lorentzian profile")
    project.save()
    return project


if __name__ == "__main__":
    G2sc.SetPrintLevel("warn")
    if len(sys.argv) > 1 and sys.argv[1] == "show":
        show(G2sc.G2Project(str(GPX)))
    elif len(sys.argv) > 1 and sys.argv[1] == "refine":
        refine()
    else:
        show(build())
