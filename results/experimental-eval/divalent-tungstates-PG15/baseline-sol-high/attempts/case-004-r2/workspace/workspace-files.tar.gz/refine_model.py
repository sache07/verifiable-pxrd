#!/usr/bin/env python3
"""Build and refine the two-phase CoWO4/WO3 GSAS-II model."""

from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
GPX = ROOT / "final.gpx"


def residual_snapshot(project, label):
    hist = project.histogram(0)
    print(f"\n[{label}] residuals={hist.residuals}")
    inst = hist.data["Instrument Parameters"][0]
    print("instrument", {k: v[1] for k, v in inst.items() if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"][:3], "mustrain", hap["Mustrain"][:3])


def main():
    project = G2sc.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "cu_ka1ka2.instprm"),
        fmthint="comma",
    )
    cowo4 = project.add_phase(
        str(ROOT / "coWO4_start.cif"), phasename="CoWO4",
        histograms=[hist], fmthint="CIF"
    )
    wo3 = project.add_phase(
        str(ROOT / "wo3_start.cif"), phasename="WO3",
        histograms=[hist], fmthint="CIF"
    )

    # Fix the histogram multiplier so independently refined HAP scales define
    # the phase ratio. Restrict the fit to the actual measured interval.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements({"Limits": [10.0, 100.0]})

    # Conservative profile starting values for an uncalibrated laboratory scan.
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 10.0, "V": -8.0, "W": 12.0, "X": 0.0, "Y": 4.0}.items():
        inst[key][1] = value

    stages = [
        ("background/scales", {
            "set": {
                "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 15},
                "PhaseFraction": True,
            }
        }),
        ("cells", {"set": {"Cell": True}}),
        ("zero", {"set": {"Instrument Parameters": ["Zero"]}}),
        ("profile-Gaussian", {"set": {"Instrument Parameters": ["U", "V", "W"]}}),
        ("profile-Lorentzian", {"set": {"Instrument Parameters": ["X", "Y"]}}),
        ("repeat", {}),
    ]

    for label, recipe in stages:
        project.do_refinements([recipe])
        residual_snapshot(project, label)

    project.save(str(GPX))
    print("mass fractions", hist.ComputeMassFracs())


if __name__ == "__main__":
    main()
