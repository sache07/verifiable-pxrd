from pathlib import Path
import csv
import json
import math
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "inputs" / "pattern.csv"
XYE = ROOT / "pattern.xye"
INST = ROOT / "cu_ka.instprm"
GPX = ROOT / "final.gpx"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

PHASES = [
    ("CaWO4_scheelite", COD / "7/21/92/7219229.cif", ROOT / "CaWO4_scheelite.cif"),
    ("WO3_monoclinic", COD / "1/52/89/1528915.cif", ROOT / "WO3_monoclinic.cif"),
    ("CaCO3_calcite", COD / "1/54/73/1547347.cif", ROOT / "CaCO3_calcite.cif"),
]


def prepare_inputs():
    # GSAS-II's xye reader interprets column 3 as sigma; Poisson uncertainties
    # are appropriate for the unprocessed counts supplied here.
    with DATA.open(newline="") as src, XYE.open("w") as dst:
        reader = csv.DictReader(src)
        for row in reader:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8g} {math.sqrt(max(y, 1.0)):.8g}\n")
    INST.write_text(
        "#GSAS-II instrument parameter file for lab Cu Ka1/Ka2 reflection data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.25;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:2.0;V:-2.0;W:5.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )


def show_state(tag, project, hist):
    print(f"STATE {tag}: wR={hist.get_wR()} residuals={hist.data['data'][0]}")
    print("  instrument", {k: v for k, v in hist.data["Instrument Parameters"][0].items()
                           if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)")})
    for ph in project.phases():
        print(" ", ph.name, ph.get_cell(), "scale", ph.HAPvalue("Scale"))


def run_refinement():
    prepare_inputs()
    if GPX.exists():
        GPX.unlink()
    project = G2sc.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(str(XYE), str(INST), fmthint="xye")
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "no. coeffs": 15, "refine": True},
    })
    # The histogram/sample scale and phase scales are exactly redundant. Keep
    # the former fixed so phase scales, and hence mass fractions, have a
    # nonsingular covariance matrix.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    for name, source, _ in PHASES:
        project.add_phase(str(source), phasename=name, histograms=[hist], fmthint="CIF")

    # Set reasonable starting phase scales before the first least-squares cycle.
    for ph, value in zip(project.phases(), (10.0, 30.0, 60.0)):
        ph.HAPvalue("Scale", value)

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 8
    controls["min dM/M"] = 1e-5
    controls["shift factor"] = 1.0

    # Stage parameters to minimize scale/profile/cell correlation.
    project.set_refinement({"set": {"Background": True, "Scale": True}})
    project.refine(printFile=str(ROOT / "refine.lst"))
    show_state("scale_background", project, hist)

    project.set_refinement({"set": {"Instrument Parameters": ["Zero"]}})
    project.refine(printFile=str(ROOT / "refine.lst"))
    show_state("zero", project, hist)

    project.set_refinement({"set": {"Cell": True}})
    project.refine(printFile=str(ROOT / "refine.lst"))
    show_state("cells", project, hist)

    project.set_refinement({"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}})
    project.refine(printFile=str(ROOT / "refine.lst"))
    show_state("profile", project, hist)

    # Allow each phase an isotropic coherent-domain broadening term. This is
    # sufficiently parsimonious for a single laboratory pattern.
    for ph in project.phases()[:2]:
        ph.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True}})
    project.refine(printFile=str(ROOT / "refine.lst"))
    show_state("size", project, hist)

    # U and V are strongly correlated for this uncalibrated profile. Retain the
    # refined V value but fix it for the final cycle to obtain a well-conditioned
    # covariance matrix without changing the fitted line shape.
    hist.clear_refinements({"Instrument Parameters": ["V"]})
    controls["max cyc"] = 20
    # Complete convergence; a restart after a damped/stuck cycle is sometimes
    # needed when the phase-size terms are first introduced.
    for _ in range(3):
        project.refine(printFile=str(ROOT / "refine.lst"))
        if project.data["Covariance"]["data"].get("Rvals", {}).get("converged"):
            break
    project.save(str(GPX))

    # Export structures from the actual refined project.
    for ph, (_, _, outfile) in zip(project.phases(), PHASES):
        ph.export_CIF(str(outfile))

    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    bkg = np.asarray(hist.getdata("Background"), dtype=float)
    limits = hist.data["Limits"][1]
    used = (x >= limits[0]) & (x <= limits[1])
    x, yobs, ycalc, bkg = x[used], yobs[used], ycalc[used], bkg[used]
    diff = yobs - ycalc
    with (ROOT / "fit.csv").open("w", newline="") as fp:
        out = csv.writer(fp)
        out.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
        out.writerows(zip(x, yobs, ycalc, diff, bkg))

    fractions = hist.ComputeMassFracs()
    resid = hist.data["data"][0]
    result = {
        "phases": [
            {
                "name": ph.name,
                "formula": {"CaWO4_scheelite": "CaWO4", "WO3_monoclinic": "WO3", "CaCO3_calcite": "CaCO3"}[ph.name],
                "cif_path": str(outfile.relative_to(ROOT)),
                "weight_fraction": fractions[ph.name][0],
                "weight_fraction_esd": fractions[ph.name][1],
                "space_group": ph.data["General"]["SGData"]["SpGrp"].strip(),
                "cell": ph.get_cell(),
            }
            for ph, (_, _, outfile) in zip(project.phases(), PHASES)
        ],
        "fit_statistics": {
            "Rwp_percent": float(resid.get("wR")),
            "Rp_percent": float(resid.get("R")),
            "GOF": float(project.data["Covariance"]["data"].get("Rvals", {}).get("GOF")),
        },
        "pattern": "fit.csv",
        "project": "final.gpx",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    run_refinement()
