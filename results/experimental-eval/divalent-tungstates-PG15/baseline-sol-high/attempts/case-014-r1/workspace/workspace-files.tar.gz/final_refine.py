#!/usr/bin/env python3
"""Create the final two-phase GSAS-II refinement and deliverables."""
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
GPX = ROOT / 'final.gpx'
XYE = ROOT / '.tmp' / 'pattern_final.xye'


def cod_path(cod_id):
    cod_id = str(cod_id)
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def write_xye():
    XYE.parent.mkdir(exist_ok=True)
    with open(ROOT / 'inputs' / 'pattern.csv', newline='') as src, open(XYE, 'w') as dst:
        for row in csv.DictReader(src):
            x = float(row['two_theta_deg'])
            y = float(row['intensity'])
            # No point uncertainties were supplied. Poisson counting errors
            # are the least-assumptive weights for the original count data.
            dst.write(f'{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n')


def refine_project():
    write_xye()
    if GPX.exists():
        GPX.unlink()
    gpx = G2sc.G2Project(newgpx=str(GPX))
    hist = gpx.add_powder_histogram(
        str(XYE), str(ROOT / 'instrument.instprm'), fmthint='xye')
    hist.data['Sample Parameters']['Scale'][1] = False

    gpx.add_phase(str(cod_path('1546036')), phasename='SrWO4',
                  histograms=[hist], fmthint='CIF')
    gpx.add_phase(str(cod_path('1528915')), phasename='WO3',
                  histograms=[hist], fmthint='CIF')

    # The supplied pattern is in reflection geometry. Its peak-position drift
    # across 2theta requires the Bragg-Brentano sample-shift correction.
    # Atomic coordinates are held at the reference values; only phase scales,
    # cells, background, sample shift, and a conservative profile are refined.
    inst = hist.data['Instrument Parameters'][0]
    for key in ('U', 'V', 'Y', 'Z'):
        inst[key][1] = 0.0
        inst[key][2] = False
    gpx.set_Controls('cycles', 15)
    stages = [
        {'set': {
            'Background': {'type': 'chebyschev-1', 'refine': True,
                           'no. coeffs': 12},
            'Scale': True,
        }},
        {'set': {'Sample Parameters': ['Shift']}},
        {'set': {'Cell': True}},
        {'set': {'Instrument Parameters': ['W']}},
        {'set': {'Instrument Parameters': ['X']}},
        {'set': {
            'Background': {'type': 'chebyschev-1', 'refine': True,
                           'no. coeffs': 18},
        }},
    ]
    for stage in stages:
        gpx.do_refinements([stage])

    # Ensure the submitted structure is a restrained/reference-coordinate
    # Rietveld model, not a powder-overfit coordinate model.
    for phase in gpx.phases():
        phase.clear_refinements({'Atoms': [a.label for a in phase.atoms()]})
    gpx.do_refinements([{}])
    gpx.save()
    return gpx


def export_results(gpx):
    hist = gpx.histogram(0)
    phase_cifs = {
        'SrWO4': ROOT / 'phase_1_SrWO4.cif',
        'WO3': ROOT / 'phase_2_WO3.cif',
    }
    for phase in gpx.phases():
        phase.export_CIF(str(phase_cifs[phase.name]))

    columns = ['x', 'yobs', 'ycalc', 'background', 'residual']
    arrays = [np.asarray(hist.getdata(k), dtype=float) for k in columns]
    with open(ROOT / 'fit.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['two_theta_deg', 'observed', 'calculated',
                         'difference_observed_minus_calculated', 'background'])
        for x, yo, yc, bg, diff in zip(*arrays):
            writer.writerow([f'{x:.8f}', f'{yo:.8f}', f'{yc:.8f}',
                             f'{diff:.8f}', f'{bg:.8f}'])

    mass = hist.ComputeMassFracs()
    r = hist.data['data'][0]
    rwp = float(r['wR'])
    rexp = float(r['wRmin'])
    stats = {
        'Rwp_percent': rwp,
        'Rp_percent': float(r['R']),
        'Rexp_percent': rexp,
        'goodness_of_fit': rwp / rexp,
        'reduced_chi_squared': (rwp / rexp) ** 2,
        'weighted_background_R_percent': float(r['wRb']),
        'durbin_watson': float(r['Durbin-Watson']),
        'n_observations': int(r['Nobs']),
    }
    phases = []
    for phase in gpx.phases():
        frac, su = mass[phase.name]
        phase_r_key = f'{phase.id}:0:Rf'
        phase_r2_key = f'{phase.id}:0:Rf^2'
        phases.append({
            'name': phase.name,
            'formula': 'SrWO4' if phase.name == 'SrWO4' else 'WO3',
            'space_group': phase.data['General']['SGData']['SpGrp'],
            'cif_path': phase_cifs[phase.name].name,
            'weight_fraction': float(frac),
            'weight_fraction_esd_statistical': float(su),
            'cell': {k: float(v) for k, v in phase.get_cell().items()},
            'Rf_percent': float(r.get(phase_r_key, float('nan'))),
            'Rf_squared_percent': float(r.get(phase_r2_key, float('nan'))),
        })
    result = {
        'method': 'two-phase Rietveld refinement with GSAS-II',
        'weight_fraction_basis': 'normalized over modeled crystalline phases',
        'phases': phases,
        'fit_statistics': stats,
        'project_path': 'final.gpx',
        'profile_path': 'fit.csv',
    }
    with open(ROOT / 'result.json', 'w') as f:
        json.dump(result, f, indent=2, allow_nan=False)

    p1, p2 = phases
    shift = hist.data['Sample Parameters']['Shift'][0]
    report = f"""# Phase analysis report

The crystalline pattern is modeled as scheelite **SrWO4** (space group {p1['space_group']}) plus residual room-temperature monoclinic **WO3** (space group {p2['space_group']}). The refined crystalline-only fractions are **{100*p1['weight_fraction']:.2f} wt% SrWO4** and **{100*p2['weight_fraction']:.2f} wt% WO3**. The covariance-matrix counting-statistical standard uncertainty is {100*p1['weight_fraction_esd_statistical']:.2f} percentage point for either fraction, but the practical uncertainty is larger (roughly a few wt%) because no calibrated instrumental profile, standard reference, or supplied pointwise uncertainties were available.

## Evidence

SrWO4 accounts for the dominant scheelite reflection series, including the intense features near 28.00, 33.39, 45.44, 51.98, 56.08, and 57.34 degrees 2theta. Monoclinic WO3 accounts for the independent low-angle group near 23.45, 23.97, and 24.73 degrees and additional features around 34, 42, 50, 55, and 62 degrees. Alternative SrCO3 and Sr3W2O9 models predict strong peaks that are absent and refined unstably or to negligible useful contribution. Orthorhombic WO3 gave a slightly poorer profile match than monoclinic WO3, while the latter is also the expected room-temperature polymorph.

The final fit has Rwp = {stats['Rwp_percent']:.2f}%, Rp = {stats['Rp_percent']:.2f}%, Rexp = {stats['Rexp_percent']:.2f}%, and goodness-of-fit = {stats['goodness_of_fit']:.2f}. A Bragg-Brentano sample-shift term ({shift:.1f} micrometres in the GSAS-II convention) was required by the systematic 2theta-dependent peak offset. Because that correction is large and no external calibrant was supplied, refined cell parameters carry additional systematic uncertainty beyond their least-squares errors.

## Remaining uncertainty

Atomic coordinates were held at literature values (COD 1546036 for SrWO4 and COD 1528915 for WO3); the data support phase identity and unit-cell/scale refinement but do not reliably determine subtle coordinate or displacement-parameter changes. Broad residual intensity may include imperfect profile/background modeling or an amorphous contribution. The reported fractions are therefore normalized only over the two modeled crystalline phases and do not quantify amorphous material. Poisson counting uncertainties (sqrt(counts)) were used because the input supplied none.
"""
    (ROOT / 'report.md').write_text(report)


if __name__ == '__main__':
    project = refine_project()
    export_results(project)
    print('Final project:', GPX)
    print('Rwp:', project.histogram(0).get_wR())
    print('Mass fractions:', project.histogram(0).ComputeMassFracs())
