#!/usr/bin/env python3
"""Screen chemically plausible phase models with GSAS-II."""
import csv
import json
import math
import os
import sys
from pathlib import Path

import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cod_path(cod_id):
    cod_id = str(cod_id)
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def make_xye():
    out = ROOT / '.tmp' / 'pattern.xye'
    out.parent.mkdir(exist_ok=True)
    with open(ROOT / 'inputs' / 'pattern.csv', newline='') as src, open(out, 'w') as dst:
        rows = csv.DictReader(src)
        for row in rows:
            x = float(row['two_theta_deg'])
            y = float(row['intensity'])
            dst.write(f'{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n')
    return out


def run_model(label, phase_ids):
    work = ROOT / '.tmp' / 'screen'
    work.mkdir(parents=True, exist_ok=True)
    gpxpath = work / f'{label}.gpx'
    if gpxpath.exists():
        gpxpath.unlink()
    gpx = G2sc.G2Project(newgpx=str(gpxpath))
    hist = gpx.add_powder_histogram(str(make_xye()), str(ROOT / 'instrument.instprm'), fmthint='xye')
    # The histogram scale and phase scales are exactly collinear. Keep the
    # former fixed so phase scales and derived mass fractions are identifiable.
    hist.data['Sample Parameters']['Scale'][1] = False
    phases = []
    for name, cod_id in phase_ids:
        phases.append(gpx.add_phase(str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint='CIF'))
    gpx.set_Controls('cycles', 8)
    # Stable staged refinement. Keep zero fixed because no calibrant was supplied.
    refs = [
        {'set': {'Background': {'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 12},
                  'Scale': True}},
        {'set': {'Sample Parameters': ['Shift']}},
        {'set': {'Cell': True}},
        {'set': {'Instrument Parameters': ['W']}},
        {'set': {'Instrument Parameters': ['U', 'X']}},
    ]
    try:
        for i, ref in enumerate(refs):
            gpx.do_refinements([ref])
            h = gpx.histogram(0)
            print(label, 'step', i, 'wR', h.get_wR(), 'res', h.data['data'][0], flush=True)
        gpx.save()
        h = gpx.histogram(0)
        result = {
            'label': label,
            'wR': h.get_wR(),
            'residuals': h.data['data'][0],
            'instrument': h.data['Instrument Parameters'][0],
            'phases': {},
        }
        for ph in gpx.phases():
            hap = ph.data['Histograms'][h.name]
            result['phases'][ph.name] = {'cell': ph.get_cell(), 'scale': hap['Scale'][0]}
        try:
            result['mass_fracs'] = h.ComputeMassFracs()
        except Exception as exc:
            result['mass_frac_error'] = repr(exc)
        return result
    except Exception as exc:
        return {'label': label, 'error': repr(exc)}


MODELS = {
    'srwo4': [('SrWO4', '1546036')],
    'wo3_p21m': [('SrWO4', '1546036'), ('WO3', '1010618')],
    'wo3_p21c': [('SrWO4', '1546036'), ('WO3', '1528915')],
    'wo3_p21c_loopstra': [('SrWO4', '1546036'), ('WO3', '2311041')],
    'wo3_p21c_alt': [('SrWO4', '1546036'), ('WO3', '1563541')],
    'wo3_pnma': [('SrWO4', '1546036'), ('WO3', '2107312')],
    'srco3_pnma': [('SrWO4', '1546036'), ('SrCO3', '9008198')],
    'srco3_r3m': [('SrWO4', '1546036'), ('SrCO3', '1539128')],
    'sr3w2o9': [('SrWO4', '1546036'), ('Sr3W2O9', '2311977')],
}

if __name__ == '__main__':
    chosen = sys.argv[1:] or list(MODELS)
    results = []
    for key in chosen:
        print('MODEL', key, flush=True)
        results.append(run_model(key, MODELS[key]))
    with open(ROOT / '.tmp' / 'screen_results.json', 'w') as f:
        json.dump(results, f, indent=2, default=str)
    print(json.dumps(results, indent=2, default=str))
