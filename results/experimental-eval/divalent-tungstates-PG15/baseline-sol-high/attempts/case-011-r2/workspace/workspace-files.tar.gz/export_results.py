from pathlib import Path
import csv
import json
import math
import numpy as np

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(ROOT / 'final.gpx'))
h = gpx.histogram(0)

# Structural exports are generated directly from the final project.
cif_names = {'WO3': 'phase_WO3.cif', 'beta-MnO2': 'phase_beta-MnO2.cif'}
for ph in gpx.phases():
    ph.export_CIF(str(ROOT / cif_names[ph.name]))

# Export the profile on exactly the range used in the refinement.
x = np.asarray(h.getdata('x'))
obs = np.asarray(h.getdata('yobs'))
calc = np.asarray(h.getdata('ycalc'))
bkg = np.asarray(h.getdata('background'))
diff = np.asarray(h.getdata('residual'))
lo, hi = h.Limits('lower'), h.Limits('upper')
sel = (x >= lo) & (x <= hi)
with (ROOT / 'fit.csv').open('w', newline='') as fp:
    w = csv.writer(fp)
    w.writerow(['two_theta_deg', 'observed_intensity', 'calculated_intensity',
                'difference_observed_minus_calculated', 'calculated_background'])
    w.writerows(zip(x[sel], obs[sel], calc[sel], diff[sel], bkg[sel]))

r = h.residuals
fracs = h.ComputeMassFracs()
rwp = float(r['wR'])
rexp = float(r['wRmin'])
gof = rwp / rexp

phase_records = []
for ph in gpx.phases():
    frac, esd = fracs[ph.name]
    sg = ph.data['General']['SGData']['SpGrp'].strip()
    formula = 'WO3' if ph.name == 'WO3' else 'MnO2'
    phase_records.append({
        'name': ph.name,
        'formula': formula,
        'space_group': sg,
        'cif_path': cif_names[ph.name],
        'weight_fraction': float(frac),
        'weight_fraction_formal_esd': float(esd),
        'unit_cell': {k: float(v) for k, v in ph.get_cell().items()},
    })

result = {
    'number_of_modeled_crystalline_phases': len(phase_records),
    'phase_fractions_basis': 'normalized over modeled crystalline phases',
    'phases': phase_records,
    'fit_statistics': {
        'Rp_percent': float(r['R']),
        'Rwp_percent': rwp,
        'Rexp_percent': rexp,
        'goodness_of_fit': gof,
        'reduced_chi_squared': gof * gof,
        'profile_points_used': int(sel.sum()),
        'two_theta_range_deg': [float(lo), float(hi)],
        'weighting': 'Poisson counting weights, w = 1/Iobs (no pointwise uncertainties supplied)',
    },
    'project_path': 'final.gpx',
    'profile_path': 'fit.csv',
}
(ROOT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')

wo3 = next(p for p in phase_records if p['name'] == 'WO3')
mno2 = next(p for p in phase_records if p['name'] == 'beta-MnO2')
report = f'''# Powder diffraction phase analysis

Two crystalline phases are required: monoclinic WO3 ({wo3['space_group']}) and rutile-type beta-MnO2 ({mno2['space_group']}). The refined crystalline-normalized fractions are **{100*wo3['weight_fraction']:.2f} wt% WO3** and **{100*mno2['weight_fraction']:.2f} wt% beta-MnO2**. Formal least-squares standard uncertainties are {100*wo3['weight_fraction_formal_esd']:.2f} percentage points, but a more realistic compositional uncertainty is about 1–2 percentage points because calibrated instrumental broadening is unavailable and the result is mildly texture-dependent.

## Evidence

The WO3 assignment is fixed by its characteristic monoclinic triplet at observed 2theta approximately 23.44, 23.92, and 24.69 degrees and the groups near 33.6–34.5, 50.2, and 55–57 degrees. Beta-MnO2 accounts for the rutile reflections at approximately 29.01, 37.68, 56.96, 59.66, 65.13, 72.2–72.5, and 86.61 degrees. Both reference patterns require the same reflection-geometry specimen displacement, supporting a common instrumental/sample-origin shift rather than separate unidentified lattices. MnWO4 was tested chemically but rejected: its strong low-angle line near 18.5 degrees and 30.0–30.5 degree doublet are absent.

This phase assemblage corresponds to predominantly unreacted WO3 and MnO2 precursors, which is chemically plausible after the reported low 300 degrees C heat treatment.

The final two-phase Rietveld refinement gives Rp = {float(r['R']):.3f}%, Rwp = {rwp:.3f}%, Rexp = {rexp:.3f}%, and goodness-of-fit = {gof:.3f}. Unit cells refined to a = {wo3['unit_cell']['length_a']:.5f}, b = {wo3['unit_cell']['length_b']:.5f}, c = {wo3['unit_cell']['length_c']:.5f} A, beta = {wo3['unit_cell']['angle_beta']:.4f} degrees for WO3, and a = {mno2['unit_cell']['length_a']:.5f}, c = {mno2['unit_cell']['length_c']:.5f} A for beta-MnO2. A single March-Dollase term per phase describes modest preferred orientation. W coordinates and the rutile oxygen x coordinate were allowed to refine; WO3 oxygen coordinates and all occupancies were retained from the stoichiometric reference models because Cu X-ray data do not constrain them reliably enough.

## Remaining uncertainty

Fractions are normalized only over the modeled crystalline phases. Without an internal standard, any amorphous content cannot be measured and is not included. Removing the texture correction changes the WO3 fraction from {100*wo3['weight_fraction']:.2f} to about 66.91 wt%, which is the main observed model sensitivity. No additional crystalline phase is required by the residual; heavily overlapped trace phases below roughly 1–2 wt% cannot be excluded. The formal fraction errors in `result.json` therefore should not be interpreted as total accuracy.
'''
(ROOT / 'report.md').write_text(report)

print(json.dumps(result, indent=2))
