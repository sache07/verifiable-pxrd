from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
DB = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
WO3_CIF = DB / '1/52/89/1528915.cif'
MNO2_CIF = DB / '1/51/41/1514110.cif'


def show(gpx, tag):
    h = gpx.histogram(0)
    inst = h.InstrumentParameters
    print('\n', tag, h.residuals)
    print('sample', h.SampleParameters)
    print('instrument', {k: v for k, v in inst.items()
                         if k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'Z',
                                  'SH/L', 'I(L2)/I(L1)')})
    for p in gpx.phases():
        print(p.name, p.get_cell(), p.data['Histograms'][h.name])


gpx = G2sc.G2Project(newgpx=str(ROOT / 'final.gpx'))
h = gpx.add_powder_histogram(str(ROOT / 'inputs/pattern.csv'),
                             str(ROOT / 'instrument.instprm'),
                             fmthint='comma')
wo3 = gpx.add_phase(str(WO3_CIF), phasename='WO3', histograms=[h], fmthint='CIF')
mno2 = gpx.add_phase(str(MNO2_CIF), phasename='beta-MnO2', histograms=[h], fmthint='CIF')

# The common positive shift of all observed reflections is characteristic of
# sample displacement in Bragg-Brentano geometry. Units here are micrometres.
h.SampleParameters['Shift'][0] = -650.0
h.SampleParameters['Gonio. radius'] = 240.0
h.SampleParameters['Scale'][0] = 1.0
h.SampleParameters['Scale'][1] = False
# Start from a modest, positive-definite laboratory profile. Width terms are
# introduced sequentially below to avoid the strong U/V/W/X/Y degeneracy.
for key, value in {'U': 2.0, 'V': -2.0, 'W': 5.0,
                   'X': 5.0, 'Y': 5.0, 'SH/L': 0.02}.items():
    h.InstrumentParameters[key][1] = value
h.set_refinements({
    'Limits': [10.0, 100.0],
    'Background': {'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 12},
    'Sample Parameters': ['Shift'],
})
for p in (wo3, mno2):
    p.set_HAP_refinements({'Scale': True})

gpx.set_Controls('cycles', 8)
gpx.refine()
show(gpx, 'background, displacement and phase scales')

for p in (wo3, mno2):
    p.set_refinements({'Cell': True})
gpx.refine()
show(gpx, 'plus unit cells')

h.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y', 'SH/L']})
h.InstrumentParameters['U'][2] = False
h.InstrumentParameters['V'][2] = False
h.InstrumentParameters['Y'][2] = False
gpx.refine()
show(gpx, 'plus W, X and axial divergence')

h.InstrumentParameters['Y'][2] = True
gpx.refine()
show(gpx, 'plus Y profile term')

# SH/L is almost perfectly correlated with displacement for this pattern;
# retain its fitted value but fix it for the remaining stages and final
# covariance calculation.
h.InstrumentParameters['SH/L'][2] = False

# The diagnostic intensity ratios show mild texture: enhancement of 020 for
# monoclinic WO3 and 110 for rutile MnO2. Refine one March-Dollase coefficient
# for each rather than adding many empirical spherical-harmonic terms.
wo3.data['Histograms'][h.name]['Pref.Ori.'][3] = [0, 1, 0]
mno2.data['Histograms'][h.name]['Pref.Ori.'][3] = [1, 1, 0]
for p in (wo3, mno2):
    p.set_HAP_refinements({'Pref.Ori.': True})
gpx.refine()
show(gpx, 'plus preferred orientation')

# Refine only coordinates with meaningful X-ray contrast. The source WO3 W
# coordinates are rounded, and oxygen x in rutile is directly observable from
# intensity ratios. WO3 oxygen coordinates and all occupancies remain fixed.
wo3.set_refinements({'Atoms': {a.label: ('X' if a.element == 'W' else ' ')
                                for a in wo3.atoms()}})
mno2.set_refinements({'Atoms': {a.label: ('X' if a.element == 'O' else ' ')
                                 for a in mno2.atoms()}})
gpx.refine()
show(gpx, 'plus atomic coordinates')

gpx.save(str(ROOT / 'final.gpx'))
