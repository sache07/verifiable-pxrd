from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent


def summary(proj, label):
    hist = proj.histogram(0)
    phase = proj.phase(0)
    print(label, 'residuals=', hist.residuals)
    print(label, 'cell=', phase.get_cell())
    print(label, 'inst=', {k: v for k, v in hist.data['Instrument Parameters'][0].items()
                            if k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L', 'I(L2)/I(L1)')})
    print(label, 'HAP=', phase.data['Histograms'][hist.name])


def main():
    gpx = ROOT / 'working.gpx'
    proj = G2sc.G2Project(newgpx=str(gpx))
    hist = proj.add_powder_histogram(str(ROOT / 'pattern.xye'),
                                     str(ROOT / 'instrument.instprm'),
                                     fmthint='xye')
    phase = proj.add_phase(str(ROOT / 'ZnWO4_seed.cif'), phasename='ZnWO4',
                           histograms=[hist], fmthint='CIF')
    hist.set_refinements({'Limits': [10.0, 100.0],
                          'Background': {'type': 'chebyschev-1',
                                         'no. coeffs': 12,
                                         'refine': True}})
    phase.set_HAP_refinements({'Scale': True})
    proj.save()
    proj.refine()
    summary(proj, 'scale_background')

    phase.set_refinements({'Cell': True})
    hist.set_refinements({'Instrument Parameters': ['Zero']})
    proj.refine()
    summary(proj, 'cell_zero')

    hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y', 'SH/L']})
    proj.refine()
    summary(proj, 'profile')

    phase.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True,
                                            'LGmix': {'value': 0.5, 'refine': True}},
                               'Size': {'type': 'isotropic', 'value': 10.0,
                                        'refine': True,
                                        'LGmix': {'value': 0.5, 'refine': True}}})
    proj.refine()
    summary(proj, 'broadening')

    phase.set_refinements({'Atoms': {'all': 'X'}})
    proj.refine()
    summary(proj, 'coordinates')
    proj.save(ROOT / 'working.gpx')

    # Export the arrays for diagnostic inspection.
    x, yobs, weight, ycalc, ybkg, ydiff = hist.data['data'][1]
    arr = np.column_stack([x, yobs, ycalc, yobs-ycalc, ybkg, weight])
    np.savetxt(ROOT / 'working_fit.csv', arr, delimiter=',',
               header='two_theta_deg,observed,calculated,difference,background,weight',
               comments='')
    phase.export_CIF(str(ROOT / 'working_ZnWO4.cif'))


if __name__ == '__main__':
    main()
