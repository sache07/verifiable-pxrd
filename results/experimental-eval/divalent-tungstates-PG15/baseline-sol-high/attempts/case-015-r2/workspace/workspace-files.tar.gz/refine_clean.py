from pathlib import Path
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent


def show(proj, label):
    h = proj.histogram(0)
    ph = proj.phase(0)
    inst = h.data['Instrument Parameters'][0]
    print('\n', label, h.residuals, flush=True)
    print('cell', ph.get_cell(), flush=True)
    print('inst', {k: inst[k][1:] for k in ('Zero','U','V','W','X','Y','SH/L')}, flush=True)
    print('scales sample/HAP', h.data['Sample Parameters']['Scale'],
          ph.data['Histograms'][h.name]['Scale'], flush=True)


def run_refine(proj, label):
    proj.refine()
    show(proj, label)


def main():
    proj = G2sc.G2Project(newgpx=str(ROOT / 'clean.gpx'))
    h = proj.add_powder_histogram(str(ROOT / 'pattern.xye'),
                                  str(ROOT / 'instrument.instprm'),
                                  fmthint='xye')
    ph = proj.add_phase(str(ROOT / 'ZnWO4_seed.cif'), phasename='ZnWO4',
                        histograms=[h], fmthint='CIF')
    proj.data['Controls']['data']['max cyc'] = 6
    hap = ph.data['Histograms'][h.name]
    hap['Scale'] = [1.0, False]
    h.set_refinements({'Limits': [10.0, 100.0],
                       'Background': {'type': 'chebyschev-1',
                                      'no. coeffs': 12, 'refine': True}})
    proj.save()
    run_refine(proj, 'background_scale')

    ph.set_refinements({'Cell': True})
    run_refine(proj, 'cell')

    h.set_refinements({'Instrument Parameters': ['W']})
    run_refine(proj, 'W')

    h.set_refinements({'Instrument Parameters': ['U', 'V']})
    run_refine(proj, 'UVW')

    h.set_refinements({'Instrument Parameters': ['X']})
    run_refine(proj, 'UVWX')

    h.set_refinements({'Instrument Parameters': ['Y']})
    run_refine(proj, 'UVWXY')

    h.set_refinements({'Instrument Parameters': ['Zero']})
    run_refine(proj, 'zero')
    proj.save()


if __name__ == '__main__':
    main()
