from pathlib import Path
import json
import math
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
PHASE_INFO = {
    'ZnWO4': {'formula': 'ZnWO4', 'space_group': 'P 1 2/c 1', 'cif': 'ZnWO4.cif'},
    'WO3': {'formula': 'WO3', 'space_group': 'P 1 21/n 1', 'cif': 'WO3.cif'},
    'ZnO': {'formula': 'ZnO', 'space_group': 'P 63 m c', 'cif': 'ZnO.cif'},
}


def main():
    project = G2sc.G2Project(gpxfile=str(ROOT / 'stable.gpx'),
                             newgpx=str(ROOT / 'final.gpx'))
    hist = project.histogram(0)
    project.save()

    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    total = sum(v[0] for v in fractions.values())
    phases_json = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info['cif']))
        fraction, su = fractions[phase.name]
        phases_json.append({
            'name': phase.name,
            'formula': info['formula'],
            'space_group': info['space_group'],
            'cif_path': info['cif'],
            'weight_fraction': fraction / total,
            'weight_fraction_percent': 100.0 * fraction / total,
            'formal_weight_fraction_standard_uncertainty': su,
            'cell': phase.get_cell(),
        })

    x, yobs, weight, ycalc, ybkg, ydiff = hist.data['data'][1]
    profile = np.column_stack((x, yobs, ycalc, yobs - ycalc, ybkg, weight))
    np.savetxt(ROOT / 'fit.csv', profile, delimiter=',', comments='',
               header=('two_theta_deg,observed_intensity,calculated_intensity,'
                       'difference_observed_minus_calculated,background_intensity,weight'))

    rvals = project.data['Covariance']['data']['Rvals']
    residuals = hist.residuals
    fit_stats = {
        'Rwp_percent': float(rvals['Rwp']),
        'Rp_percent': float(residuals['R']),
        'Rexp_percent': float(residuals['wRmin']),
        'goodness_of_fit': float(rvals['GOF']),
        'chi_squared': float(rvals['chisq']),
        'reduced_chi_squared': float(rvals['chisq'] / (rvals['Nobs'] - rvals['Nvars'])),
        'number_of_observations': int(rvals['Nobs']),
        'number_of_refined_variables': int(rvals['Nvars']),
        'converged': bool(rvals['converged']),
        'maximum_shift_over_sigma': float(rvals['Max shft/sig']),
        'profile_range_two_theta_deg': [float(x[0]), float(x[-1])],
        'weighting': 'Poisson approximation, sigma=sqrt(observed counts)',
    }
    result = {
        'phases': phases_json,
        'weight_fraction_basis': 'normalized over modeled crystalline phases; amorphous content not determined',
        'fit_statistics': fit_stats,
        'profile_path': 'fit.csv',
        'gsasii_project_path': 'final.gpx',
    }
    (ROOT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')

    p = {entry['name']: entry for entry in phases_json}
    report = f"""# PXRD phase analysis

The pattern is modeled with three crystalline phases: wolframite-type ZnWO4, monoclinic WO3, and wurtzite ZnO. Quantitative phase analysis gives {p['ZnWO4']['weight_fraction_percent']:.2f} wt% ZnWO4, {p['WO3']['weight_fraction_percent']:.2f} wt% WO3, and {p['ZnO']['weight_fraction_percent']:.2f} wt% ZnO, normalized over these modeled crystalline phases.

This assemblage is chemically consistent with partial formation of ZnWO4 from the reported ZnO and WO3 precursors after heating at 900 degrees C, with both precursors remaining crystalline.

## Evidence

ZnWO4 accounts for the dominant groups at approximately 15.7, 19.0, 23.9-24.6, 30.7-31.4, and 36.5 degrees 2theta. Monoclinic WO3 is required by the independent 23.2-24.4 degree triplet and lines near 26.7, 28.9, 33.3-34.3, 41.6, and 50.0 degrees. ZnO is supported by its wurtzite series near 31.9, 34.4, 36.3, 47.6, 56.7, and 62.9 degrees. After including these phases, the residual contains no coherent set of unmatched peaks that supports a fourth crystalline phase.

The starting structures were COD 1520641 (ZnWO4), COD 1528915 (WO3), and COD 9004178 (ZnO). Lattice parameters and the ZnWO4/WO3 heavy-atom coordinates were refined in GSAS-II. Oxygen coordinates were retained from the reference structures because this laboratory Cu X-ray pattern does not determine them reliably.

## Fit and uncertainty

The final fit has Rwp = {fit_stats['Rwp_percent']:.3f}%, Rp = {fit_stats['Rp_percent']:.3f}%, Rexp = {fit_stats['Rexp_percent']:.3f}%, and goodness of fit = {fit_stats['goodness_of_fit']:.3f} over {fit_stats['number_of_observations']} points. The refinement converged with maximum shift/s.u. = {fit_stats['maximum_shift_over_sigma']:.3f}.

GSAS-II formal fraction s.u. values are {100*p['ZnWO4']['formal_weight_fraction_standard_uncertainty']:.2f}, {100*p['WO3']['formal_weight_fraction_standard_uncertainty']:.2f}, and {100*p['ZnO']['formal_weight_fraction_standard_uncertainty']:.2f} percentage points, respectively. These are optimistic because pointwise uncertainties and a calibrated instrumental profile were not supplied; Poisson counting weights were assumed, and the refined U/V profile terms are strongly correlated. A more realistic interpretation is about +/-2-3 percentage points for the major phase and +/-1-2 percentage points for each minor phase. Fractions describe only the modeled crystalline material; amorphous content cannot be obtained from these data without an internal standard.
"""
    (ROOT / 'report.md').write_text(report)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
