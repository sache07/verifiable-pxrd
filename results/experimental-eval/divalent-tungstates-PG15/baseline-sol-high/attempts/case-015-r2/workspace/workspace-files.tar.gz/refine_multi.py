from pathlib import Path
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
USE_ZNO = len(sys.argv) > 1 and sys.argv[1].lower() == 'zno'
TAG = 'three' if USE_ZNO else 'two'


def show(p, label):
    h = p.histogram(0)
    inst = h.data['Instrument Parameters'][0]
    print('\n', label, h.residuals, flush=True)
    print('mass', h.ComputeMassFracs(), flush=True)
    print('inst', {k: inst[k][1:] for k in ('Zero','U','V','W','X','Y','SH/L')}, flush=True)
    for ph in p.phases():
        print(ph.name, ph.get_cell(), ph.data['Histograms'][h.name]['Scale'], flush=True)


def cycle(p, label):
    p.refine()
    show(p, label)


def main():
    p = G2sc.G2Project(newgpx=str(ROOT / f'{TAG}.gpx'))
    h = p.add_powder_histogram(str(ROOT / 'pattern.xye'),
                               str(ROOT / 'instrument.instprm'), fmthint='xye')
    phases = [p.add_phase(str(ROOT / 'ZnWO4_seed.cif'), phasename='ZnWO4',
                          histograms=[h], fmthint='CIF'),
              p.add_phase(str(ROOT / 'WO3_seed.cif'), phasename='WO3',
                          histograms=[h], fmthint='CIF')]
    if USE_ZNO:
        phases.append(p.add_phase(str(ROOT / 'ZnO_seed.cif'), phasename='ZnO',
                                  histograms=[h], fmthint='CIF'))
    p.data['Controls']['data']['max cyc'] = 6
    phases[0].data['Histograms'][h.name]['Scale'] = [1.0, False]
    for ph in phases[1:]:
        ph.data['Histograms'][h.name]['Scale'] = [0.1, True]
    inst = h.data['Instrument Parameters'][0]
    inst['W'][0] = inst['W'][1] = 150.0
    h.set_refinements({'Limits': [10.0, 100.0],
                       'Background': {'type': 'chebyschev-1',
                                      'no. coeffs': 12, 'refine': True}})
    p.save()
    cycle(p, 'scales_background')
    phases[0].set_refinements({'Cell': True})
    cycle(p, 'ZnWO4_cell')
    phases[1].set_refinements({'Cell': True})
    cycle(p, 'WO3_cell')
    if USE_ZNO:
        phases[2].set_refinements({'Cell': True})
        cycle(p, 'ZnO_cell')
    h.set_refinements({'Instrument Parameters': ['W']})
    cycle(p, 'W')
    h.set_refinements({'Instrument Parameters': ['U', 'V']})
    cycle(p, 'UVW')
    h.set_refinements({'Instrument Parameters': ['X']})
    cycle(p, 'UVWX')
    h.set_refinements({'Instrument Parameters': ['Zero']})
    cycle(p, 'zero')
    p.save()
    x, yo, wt, yc, yb, yd = h.data['data'][1]
    np.savetxt(ROOT / f'{TAG}_fit.csv', np.c_[x, yo, yc, yo-yc, yb, wt],
               delimiter=',', comments='',
               header='two_theta_deg,observed,calculated,difference,background,weight')


if __name__ == '__main__':
    main()
