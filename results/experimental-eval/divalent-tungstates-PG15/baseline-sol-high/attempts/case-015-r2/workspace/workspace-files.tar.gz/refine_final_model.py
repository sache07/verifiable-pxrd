from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent


def show(p, label):
    h = p.histogram(0)
    print('\n', label, h.residuals, flush=True)
    print('mass', h.ComputeMassFracs(), flush=True)
    print('lastshift', max(abs(x) for x in p.data['Covariance']['data'].get('Lastshft', [0.])), flush=True)
    for ph in p.phases():
        print(ph.name, ph.get_cell(), flush=True)
        for a in ph.atoms():
            print(' ', a.label, a.coordinates, a.refinement_flags, flush=True)


def main():
    p = G2sc.G2Project(gpxfile=str(ROOT / 'three.gpx'),
                       newgpx=str(ROOT / 'candidate_final.gpx'))
    p.data['Controls']['data']['max cyc'] = 10
    p.save()
    p.refine()
    show(p, 'converge_1')
    p.refine()
    show(p, 'converge_2')

    # Refine only the heavy-atom coordinates supported by laboratory XRD.
    p.phase('ZnWO4').set_refinements({'Atoms': {'W1': 'X', 'Zn1': 'X'}})
    p.refine()
    show(p, 'ZnWO4_heavy_atoms')
    p.phase('WO3').set_refinements({'Atoms': {'W1': 'X', 'W2': 'X'}})
    p.refine()
    show(p, 'WO3_heavy_atoms')
    p.save()


if __name__ == '__main__':
    main()
