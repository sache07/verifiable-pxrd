import gzip
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.optimize import nnls
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure

ROOT = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
INFO = Path('<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz')

obs = pd.read_csv('inputs/pattern.csv')
x = obs.two_theta_deg.to_numpy()
y = obs.intensity.to_numpy()
step = np.median(np.diff(x))
baseline = percentile_filter(y, percentile=10, size=501)
ynet = np.clip(y - baseline, 0, None)

def cifpath(codid):
    s = str(codid)
    return ROOT / s[0] / s[1:3] / s[3:5] / (s + '.cif')

def sticks(struct):
    # Explicit K-alpha1/K-alpha2 synthesis with the supplied 0.5 ratio.
    z = np.zeros_like(x)
    for wave, frac in [(1.540598, 1.0), (1.544426, 0.5)]:
        pat = XRDCalculator(wavelength=wave).get_pattern(struct, two_theta_range=(x[0]-1, x[-1]+1))
        xx = np.asarray(pat.x)
        ii = np.asarray(pat.y) * frac
        jj = np.rint((xx-x[0])/step).astype(int)
        good = (jj >= 0) & (jj < len(z))
        np.add.at(z, jj[good], ii[good])
    return z

with gzip.open(INFO, 'rt') as f:
    info = json.load(f)

entries = []
for key, vals in info.items():
    elems = set(key.split('-'))
    if elems.issubset({'Mn','W','O'}) and 'O' in elems:
        for formula, codid, sg, residual in vals:
            entries.append((key, formula, str(codid), sg, residual))

rows = []
for key, formula, codid, sg, residual in entries:
    p = cifpath(codid)
    if not p.exists():
        continue
    try:
        st = Structure.from_file(p)
    except Exception as exc:
        print('skip', codid, exc)
        continue
    best = None
    stick = sticks(st)
    for fwhm in [0.10,0.14,0.18,0.22,0.28,0.36]:
        broadened = gaussian_filter1d(stick, fwhm/2.35482/step)
        for zero in np.arange(-0.50, 0.501, 0.025):
            calc = np.interp(x-zero, x, broadened, left=0, right=0)
            scale = np.dot(ynet,calc)/np.dot(calc,calc)
            resid = ynet-np.maximum(scale,0)*calc
            score = np.sqrt(np.mean(resid**2))/np.sqrt(np.mean(ynet**2))
            corr = np.corrcoef(ynet,calc)[0,1]
            v=(score,corr,zero,fwhm,scale)
            if best is None or v[0] < best[0]: best=v
    rows.append((best[0],best[1],key,formula,codid,sg,residual,best[2],best[3],st.volume,st.composition.reduced_formula))

for r in sorted(rows)[:80]:
    print('%7.4f corr=%6.3f %-7s %-14s id=%s sg=%3d dbR=%s zero=%+.3f fw=%.2f V=%.2f red=%s' % r)
