from pathlib import Path
import json
import math
import numpy as np

from GSASII import GSASIIscriptable as G2sc

WD = Path(__file__).resolve().parent
DB = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
WO3_CIF = DB / '2/31/10/2311041.cif'
MN2O3_CIF = DB / '1/51/42/1514230.cif'
WORK_GPX = WD / 'staged.gpx'


def brief(label, hist, phases):
    print('\n', label, hist.residuals)
    for p in phases:
        print(p.name, p.get_cell(), p.data['Histograms'][hist.name]['Scale'])
    print('inst', {k: hist.InstrumentParameters[k] for k in ['Zero','U','V','W']})


def refine(label, gpx, hist, phases):
    gpx.save(str(WORK_GPX))
    gpx.refine(makeBack=False)
    brief(label, hist, phases)


gpx = G2sc.G2Project(newgpx=str(WORK_GPX))
hist = gpx.add_powder_histogram(str(WD/'inputs/pattern.csv'),
                                str(WD/'cu_ka.instprm'), fmthint='comma')
wo3 = gpx.add_phase(str(WO3_CIF), phasename='WO3_monoclinic',
                    histograms=[hist], fmthint='CIF')
mn2o3 = gpx.add_phase(str(MN2O3_CIF), phasename='Mn2O3_bixbyite',
                      histograms=[hist], fmthint='CIF')
phases = [wo3, mn2o3]
gpx.set_Controls('cycles', 8)

# One absolute intensity scale is sufficient; refine the phase scales only.
hist.data['Sample Parameters']['Scale'] = [1.0, False]
inst = hist.InstrumentParameters
inst['U'] = [20.0, 20.0, False]
inst['V'] = [0.0, 0.0, False]
inst['W'] = [200.0, 200.0, False]

hist.set_refinements({'Background': {
    'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 10}})
wo_hap = wo3.data['Histograms'][hist.name]
mn_hap = mn2o3.data['Histograms'][hist.name]
wo_hap['Use'] = True
wo_hap['Scale'][1] = True
mn_hap['Use'] = False
mn_hap['Scale'][1] = False
refine('major scale/background', gpx, hist, phases)

# Establish the common angular calibration using the major phase only.
wo3.set_refinements({'Cell': True})
hist.set_refinements({'Instrument Parameters': ['Zero']})
refine('major cell/zero', gpx, hist, phases)

# A two-term Gaussian Caglioti profile is adequate and avoids U/V/W collinearity.
hist.set_refinements({'Instrument Parameters': ['U','W']})
refine('major profile', gpx, hist, phases)

# Freeze calibration/profile, then turn on the indexed minor phase.
wo3.clear_refinements({'Cell': True})
hist.clear_refinements({'Instrument Parameters': ['Zero','U','V','W']})
mn_hap['Use'] = True
mn_hap['Scale'][0] = 1.0
mn_hap['Scale'][1] = True
refine('minor scale', gpx, hist, phases)

# With a nonzero minor scale, refine its cubic lattice parameter.
mn2o3.set_refinements({'Cell': True})
refine('minor cell', gpx, hist, phases)

# Joint final pass; retain V=0 to limit profile correlation.
wo3.set_refinements({'Cell': True})
hist.set_refinements({'Instrument Parameters': ['Zero','U','W']})
refine('joint final', gpx, hist, phases)

gpx.save(str(WD/'final.gpx'))

# Export structures directly from the final GSAS-II project.
wo3.export_CIF(str(WD/'WO3_monoclinic.cif'))
mn2o3.export_CIF(str(WD/'Mn2O3_bixbyite.cif'))

columns = ['two_theta_deg','observed','calculated','difference','background']
arrays = [hist.getdata('X'), hist.getdata('Yobs'), hist.getdata('Ycalc'),
          hist.getdata('Residual'), hist.getdata('Background')]
np.savetxt(WD/'fit.csv', np.column_stack(arrays), delimiter=',',
           header=','.join(columns), comments='', fmt='%.8g')

mass_fracs = hist.ComputeMassFracs()
res = hist.residuals
cov = gpx.data['Covariance']['data']
rvals = cov.get('Rvals', {})
stats = {
    'Rwp_percent': float(res['wR']),
    'Rp_percent': float(res['R']),
    'Rwp_background_percent': float(res['wRb']),
    'Rp_background_percent': float(res['Rb']),
    'Rexp_percent': float(res['wRmin']),
    'goodness_of_fit': float(rvals.get('GOF', math.nan)),
    'chi_squared': float(rvals.get('chisq', math.nan)),
    'reduced_chi_squared': float(rvals.get('GOF', math.nan)**2),
    'number_of_observations': int(len(arrays[0])),
    'number_of_refined_parameters': int(len(cov.get('varyList', []))),
}
phase_rows = []
for p, cifname in [(wo3,'WO3_monoclinic.cif'), (mn2o3,'Mn2O3_bixbyite.cif')]:
    frac, su = mass_fracs[p.name]
    phase_rows.append({
        'name': p.name,
        'formula': 'WO3' if p is wo3 else 'Mn2O3',
        'cif_path': cifname,
        'weight_fraction': float(frac),
        'weight_fraction_esd': float(su),
        'space_group': p.data['General']['SGData']['SpGrp'].strip(),
        'refined_cell': p.get_cell(),
    })

result = {
    'phases': phase_rows,
    'weight_fraction_basis': 'normalized over modeled crystalline phases',
    'fit_statistics': stats,
    'project_path': 'final.gpx',
    'profile_path': 'fit.csv',
}
(WD/'result.json').write_text(json.dumps(result, indent=2) + '\n')
print('MASS_FRACS', mass_fracs)
print('RESULT', json.dumps(result, indent=2))
