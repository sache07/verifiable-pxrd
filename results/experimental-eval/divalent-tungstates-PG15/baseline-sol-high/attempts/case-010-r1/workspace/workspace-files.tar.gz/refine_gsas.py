from pathlib import Path
import numpy as np

from GSASII import GSASIIscriptable as G2sc

WD = Path(__file__).resolve().parent
SOURCE = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
WO3 = SOURCE / '2/31/10/2311041.cif'
MN2O3 = SOURCE / '1/51/42/1514230.cif'

gpx = G2sc.G2Project(newgpx=str(WD/'work_two.gpx'))
hist = gpx.add_powder_histogram(str(WD/'inputs/pattern.csv'), str(WD/'cu_ka.instprm'), fmthint='comma')
wo3 = gpx.add_phase(str(WO3), phasename='WO3_monoclinic', histograms=[hist], fmthint='CIF')
mn2o3 = gpx.add_phase(str(MN2O3), phasename='Mn2O3_bixbyite', histograms=[hist], fmthint='CIF')
gpx.set_Controls('cycles', 6)
# Keep the histogram scale fixed: only the phase scale is physically needed.
hist.data['Sample Parameters']['Scale'] = [1.0, False]
# Start close to the measured K-alpha1 peak width (~0.15 degrees 2theta).
hist.InstrumentParameters['U'] = [20.0, 20.0, False]
hist.InstrumentParameters['V'] = [0.0, 0.0, False]
hist.InstrumentParameters['W'] = [200.0, 200.0, False]

# Staged refinement reduces correlations among scale, background, lattice and profile.
steps = [
    {'set': {'Background': {'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 10},
             'Scale': True}},
    {'set': {'Cell': True, 'Instrument Parameters': ['Zero']}},
    {'set': {'Instrument Parameters': ['U','V','W']}},
]

for i, proj in enumerate(gpx.iter_refinements(steps), 1):
    print('STEP', i, hist.residuals)
    print('CELLS', wo3.get_cell(), mn2o3.get_cell())
    print('INST', {k:v for k,v in hist.InstrumentParameters.items() if k in ['Zero','U','V','W','X','Y','SH/L']})

gpx.save(str(WD/'work_two.gpx'))
cols = ['X','Yobs','Ycalc','Background','Residual']
arr = np.column_stack([np.asarray(hist.getdata(k)) for k in cols])
np.savetxt(WD/'work_two_fit.csv', arr, delimiter=',', header=','.join(cols), comments='')
print('FINAL',hist.residuals)
print('CELLS_FINAL',wo3.get_cell(),mn2o3.get_cell())
print('HAPS',wo3.data['Histograms'][hist.name],mn2o3.data['Histograms'][hist.name])
print('MASS_FRACS',hist.ComputeMassFracs())
