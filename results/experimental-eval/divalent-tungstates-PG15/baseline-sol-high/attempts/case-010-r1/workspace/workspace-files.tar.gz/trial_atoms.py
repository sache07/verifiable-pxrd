from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

wd=Path(__file__).resolve().parent
p=G2sc.G2Project(str(wd/'final.gpx'))
p.save(str(wd/'atom_trial.gpx'))
h=p.histogram(0); ph=p.phase('WO3_monoclinic')
print('before',h.residuals)
for a in ph.atoms():
    print(a.label,a.coordinates,a.refinement_flags)
ph.set_refinements({'Atoms':{'W1':'X','W2':'X'}})
p.set_Controls('cycles',8)
p.refine(makeBack=False)
print('after',h.residuals)
for a in ph.atoms():
    print(a.label,a.coordinates,a.refinement_flags)
p.save(str(wd/'atom_trial.gpx'))
