#!/usr/bin/env python3
"""Create a trial GSAS-II refinement for one or more candidate phases."""

import json
import os
import sys

from GSASII import GSASIIscriptable as G2sc


def main():
    if len(sys.argv) < 3:
        raise SystemExit("usage: refine_trial.py OUTPUT.gpx PHASE.cif [PHASE.cif ...]")
    output = os.path.abspath(sys.argv[1])
    cif_paths = [os.path.abspath(p) for p in sys.argv[2:]]

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(newgpx=output)
    hist = project.add_powder_histogram(
        os.path.abspath("inputs/pattern.csv"),
        os.path.abspath("instrument.instprm"),
        fmthint="comma",
    )
    # Keep the overall histogram scale fixed; phase scales carry the intensity.
    # Refining both creates an exact scale correlation.
    hist.SampleParameters["Scale"] = [1.0, False]
    project.data["Controls"]["data"]["max cyc"] = 8
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 12,
        },
    })
    phases = []
    for i, cif_path in enumerate(cif_paths):
        phase = project.add_phase(
            cif_path,
            phasename=f"phase_{i + 1}_{os.path.basename(cif_path).split('.')[0]}",
            histograms=[hist],
            fmthint="CIF",
        )
        phases.append(phase)

    # Robust staged refinement: intensity/background, lattice, then profile.
    project.do_refinements([
        {"set": {"Scale": True}},
        {"set": {"Cell": True}, "phases": [phases[0]]},
        {"set": {"Sample Parameters": ["Shift"]}},
        {"set": {"Instrument Parameters": ["W", "Y"]}},
        {"set": {"Instrument Parameters": ["U", "V"]}},
    ])
    project.save(output)

    summary = {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {k: v for k, v in hist.InstrumentParameters.items()},
        "phases": {p.name: p.get_cell_and_esd() for p in phases},
    }
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
