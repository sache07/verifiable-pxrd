from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
p = G2sc.G2Project(str(root / "final.gpx"), newgpx=str(root / "profile_uwx.gpx"))
h = p.histogram(0)
h.InstrumentParameters["V"][1] = 0.0
h.InstrumentParameters["V"][2] = False
p.set_Controls("cycles", 12)
p.do_refinements([{}])
p.do_refinements([{}])
print(h.residuals)
print(h.InstrumentParameters)
print(p.data["Covariance"]["data"]["Rvals"])
