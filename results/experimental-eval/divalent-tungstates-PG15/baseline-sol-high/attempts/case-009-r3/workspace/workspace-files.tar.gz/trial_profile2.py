from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
for tag, add in [("gx", {"X": 5.0}), ("gy", {"Y": 5.0}), ("gxy", {"X": 5.0, "Y": 5.0})]:
    p = G2sc.G2Project(str(root / "profile_gaussian.gpx"), newgpx=str(root / f"profile_{tag}.gpx"))
    h = p.histogram(0)
    for key, val in add.items():
        h.InstrumentParameters[key][1] = val
        h.InstrumentParameters[key][2] = True
    p.set_Controls("cycles", 12)
    p.do_refinements([{}])
    p.do_refinements([{}])
    print(tag, h.residuals)
    print("inst", h.InstrumentParameters)
