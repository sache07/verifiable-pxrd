from pathlib import Path
import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
gpx = root / "scratch.gpx"
proj = G2sc.G2Project(newgpx=str(gpx))
hist = proj.add_powder_histogram(
    str(root / "pattern.xye"), str(root / "instrument.instprm"), fmthint="xye"
)
phase = proj.add_phase(
    "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif",
    phasename="MnWO4",
    histograms=[hist],
    fmthint="CIF",
)
proj.save()
print("hist", hist.name)
print("sample", hist.SampleParameters)
print("instrument", hist.InstrumentParameters)
print("background", hist.data["Background"])
print("limits", hist.data["Limits"])
print("phase cell", phase.get_cell())
print("HAP", phase.data["Histograms"][hist.name])
