from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
for tag, fixed in [("x_only", {"Y": 0.0}), ("gaussian", {"X": 0.0, "Y": 0.0})]:
    p = G2sc.G2Project(str(root / "trial_none.gpx"), newgpx=str(root / f"profile_{tag}.gpx"))
    h = p.histogram(0)
    for key, val in fixed.items():
        h.InstrumentParameters[key][1] = val
        h.InstrumentParameters[key][2] = False
    p.set_Controls("cycles", 12)
    p.do_refinements([{}])
    p.do_refinements([{}])
    print(tag, h.residuals)
    print("inst", h.InstrumentParameters)
