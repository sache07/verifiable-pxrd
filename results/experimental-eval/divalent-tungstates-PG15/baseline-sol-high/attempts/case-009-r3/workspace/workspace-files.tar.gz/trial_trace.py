from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
db = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
candidates = {
    "Mn3O4": "9001963",
    "WO3_monoclinic": "1528915",
    "WO3_triclinic": "2106293",
    "Mn3WO6": "2002703",
}
for name, codid in candidates.items():
    cif = db / codid[0] / codid[1:3] / codid[3:5] / f"{codid}.cif"
    p = G2sc.G2Project(str(root / "final.gpx"), newgpx=str(root / f"trace_{name}.gpx"))
    h = p.histogram(0)
    ph = p.add_phase(str(cif), phasename=name, histograms=[h], fmthint="CIF")
    ph.data["Histograms"][h.name]["Scale"] = [0.01, True]
    p.set_Controls("cycles", 10)
    try:
        p.do_refinements([{}])
        p.save()
        print(name, "scale", ph.data["Histograms"][h.name]["Scale"],
              "res", h.residuals, "mass", h.ComputeMassFracs())
    except Exception as exc:
        print(name, "ERROR", repr(exc))
