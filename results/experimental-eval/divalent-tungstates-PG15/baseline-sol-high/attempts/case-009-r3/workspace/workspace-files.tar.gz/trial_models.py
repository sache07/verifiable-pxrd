from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
axes = [None, [1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0], [1, 0, 1], [0, 1, 1]]
for axis in axes:
    tag = "none" if axis is None else "".join(map(str, axis))
    p = G2sc.G2Project(str(root / "final.gpx"), newgpx=str(root / f"trial_{tag}.gpx"))
    h = p.histogram(0)
    ph = p.phase(0)
    h.InstrumentParameters["Polariz."][1] = 1.0
    h.InstrumentParameters["Polariz."][2] = False
    po = ph.data["Histograms"][h.name]["Pref.Ori."]
    po[1] = 1.0
    po[2] = axis is not None
    if axis is not None:
        po[3] = axis
    p.set_Controls("cycles", 12)
    p.do_refinements([{}])
    p.do_refinements([{}])
    print(tag, h.residuals, "pol", h.InstrumentParameters["Polariz."], "PO", po)
