from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
SOURCE_CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif")

proj = G2sc.G2Project(newgpx=str(ROOT / "final.gpx"))
hist = proj.add_powder_histogram(
    str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"), fmthint="xye"
)
phase = proj.add_phase(
    str(SOURCE_CIF), phasename="MnWO4", histograms=[hist], fmthint="CIF"
)
# Start the high-pressure reference cell near the ambient-pressure pattern.
phase.data["General"]["Cell"][1:7] = [4.8300, 5.7580, 4.9960, 90.0, 91.15, 90.0]
from GSASII import GSASIIlattice as G2lat
phase.data["General"]["Cell"][7] = G2lat.calc_V(
    G2lat.cell2A(phase.data["General"]["Cell"][1:7])
)

# Use the physically admissible edge of the polarization range. An unconstrained
# fit drives this above 1, so it is not refined. Start from a broad but positive
# pseudo-Voigt profile and refine only terms that remain positive on this range.
inst = hist.InstrumentParameters
for key, value in {"Polariz.": 1.0, "U": 230.0, "V": -300.0,
                   "W": 115.0, "X": 5.0, "Y": 0.0}.items():
    inst[key][1] = value
    inst[key][2] = False

proj.set_Controls("cycles", 10)

steps = [
    {"set": {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 18}}},
    {"set": {"Cell": True, "Sample Parameters": ["Shift"]}},
    {"set": {"Instrument Parameters": ["U", "V", "W"]}},
    {"set": {"Instrument Parameters": ["X"]}},
    {},
]

for i, step in enumerate(steps, 1):
    proj.do_refinements([step])
    print("STEP", i, hist.residuals)
    print("CELL", phase.get_cell())
    print("SAMPLE", {k: v for k, v in hist.SampleParameters.items() if isinstance(v, list)})
    print("INST", hist.InstrumentParameters)
    print("HAP", phase.data["Histograms"][hist.name])

proj.save(str(ROOT / "final.gpx"))
phase.export_CIF(str(ROOT / "MnWO4.cif"))

xy = hist.data["data"][1]
arr = np.column_stack((xy[0], xy[1], xy[3], xy[5]))
np.savetxt(
    ROOT / "fit.csv", arr, delimiter=",",
    header="two_theta_deg,intensity_observed,intensity_calculated,intensity_difference",
    comments="", fmt="%.8g",
)

print("FINAL", hist.residuals)
print("MASS", hist.ComputeMassFracs())
print("CELL_ESD", phase.get_cell_and_esd())
