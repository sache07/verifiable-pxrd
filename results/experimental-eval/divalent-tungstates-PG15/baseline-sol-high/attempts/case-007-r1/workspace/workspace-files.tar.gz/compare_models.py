from pathlib import Path
import numpy as np

from GSASII import GSASIIfiles as G2fil
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CIFS = {
    "MgWO4": COD / "9/01/39/9013902.cif",
    "WO3_mono_n": COD / "1/52/89/1528915.cif",
    "WO3_mono_m": COD / "1/01/06/1010618.cif",
    "WO3_mono_c": COD / "1/56/35/1563541.cif",
    "WO3_ortho": COD / "2/10/73/2107312.cif",
    "WO3_tri": COD / "2/10/62/2106293.cif",
    "WO3_alt": COD / "2/31/10/2311041.cif",
    "MgO": COD / "9/00/04/9000499.cif",
}


def iparms():
    names = ["Type", "Lam1", "Lam2", "Zero", "I(L2)/I(L1)", "Polariz.",
             "U", "V", "W", "X", "Y", "Z", "SH/L", "Azimuth"]
    vals = ["PXC", 1.540598, 1.544426, 0.36, 0.5, 0.5,
            200.0, 0.0, 45.0, 0.0, 5.0, 0.0, 0.002, 0.0]
    return [G2fil.makeInstDict(names, vals, [False] * len(vals)), {}]


def build(model_name, phase_names):
    gpx = ROOT / f"model_{model_name}.gpx"
    p = G2sc.G2Project(newgpx=str(gpx))
    h = p.add_powder_histogram(str(ROOT / "pattern.xye"), iparms(), fmthint="xye")
    h.SampleParameters["Scale"] = [1.0, False]
    h.SampleParameters.update({
        "Type": "Bragg-Brentano", "Shift": [0.0, False],
        "Transparency": [0.0, False], "SurfRoughA": [0.0, False],
        "SurfRoughB": [0.0, False],
    })
    phases = []
    for name in phase_names:
        phases.append(p.add_phase(str(CIFS[name]), phasename=name, histograms=[h], fmthint="CIF"))
    h.set_refinements({
        "Limits": {"low": 10.0, "high": 100.0},
        "Background": {"type": "chebyschev-1", "no. coeffs": 12, "refine": True},
    })
    p.data["Controls"]["data"]["max cyc"] = 10
    p.data["Controls"]["data"]["min dM/M"] = 1e-5

    for ph in phases:
        ph.set_HAP_refinements({"Scale": True})
    h.set_refinements({"Instrument Parameters": ["Zero"]})
    p.refine()
    print("RESULT", model_name, "stage1", h.residuals)

    for ph in phases:
        ph.set_refinements({"Cell": True})
    p.refine()
    print("RESULT", model_name, "cell", h.residuals)

    h.set_refinements({"Instrument Parameters": ["W"]})
    p.refine()
    h.set_refinements({"Instrument Parameters": ["U", "V"]})
    p.refine()
    h.set_refinements({"Instrument Parameters": ["X", "Y"]})
    p.refine()
    print("RESULT", model_name, "profile", h.residuals)
    print("CELLS", model_name, {ph.name: ph.get_cell() for ph in phases})
    print("SCALES", model_name, {ph.name: ph.data["Histograms"][h.name]["Scale"] for ph in phases})
    print("INST", model_name, h.InstrumentParameters)
    try:
        print("MASS", model_name, h.ComputeMassFracs())
    except Exception as err:
        print("MASS_ERROR", model_name, repr(err))
    p.save()


def main():
    models = {
        "n_mgo_fresh": ["MgWO4", "WO3_mono_n", "MgO"],
        "tri_mgo": ["MgWO4", "WO3_tri", "MgO"],
        "alt_mgo": ["MgWO4", "WO3_alt", "MgO"],
    }
    for model, phases in models.items():
        try:
            build(model, phases)
        except Exception as err:
            print("MODEL_ERROR", model, repr(err))


if __name__ == "__main__":
    main()
