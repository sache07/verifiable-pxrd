from pathlib import Path
import json
import math
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "texture_110.gpx"
FINAL = ROOT / "final.gpx"


def main():
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    hist = project.histogram(0)
    hist.set_refinements({
        "Limits": {"low": 9.90343322, "high": 100.09488522},
        "Background": {"type": "chebyschev-1", "no. coeffs": 12, "refine": True},
    })

    # Refine phase scales and metrics jointly. Keep the mild [110]
    # March-Dollase correction selected by the comparison refinement.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
    mgwo4 = project.phase("MgWO4")
    po = mgwo4.data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[2], po[3] = "MD", True, [1, 1, 0]

    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 20
    controls["min dM/M"] = 1e-5
    project.refine()

    # One last covariance evaluation at the converged parameter values.
    project.refine()
    project.save(str(FINAL))

    cif_paths = {
        "MgWO4": ROOT / "phase_1_MgWO4.cif",
        "WO3_tri": ROOT / "phase_2_WO3_triclinic.cif",
        "MgO": ROOT / "phase_3_MgO.cif",
    }
    for phase in project.phases():
        phase.export_CIF(str(cif_paths[phase.name]))

    x = np.asarray(hist.getdata("X"), dtype=float)
    yobs = np.asarray(hist.getdata("Yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    difference = yobs - ycalc
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, yobs, ycalc, difference, background)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt="%.8f",
    )

    mass = hist.ComputeMassFracs()
    total = sum(v[0] for v in mass.values())
    fractions = {name: val[0] / total for name, val in mass.items()}
    fraction_esd = {name: val[1] / total for name, val in mass.items()}
    residuals = hist.residuals
    rwp = float(residuals["wR"])
    rexp = float(residuals["wRmin"])
    gof = rwp / rexp

    cells = {phase.name: phase.get_cell_and_esd() for phase in project.phases()}
    phase_records = []
    labels = {
        "MgWO4": ("magnesium tungstate", "MgWO4", "P 1 2/c 1"),
        "WO3_tri": ("tungsten trioxide (triclinic model)", "WO3", "P -1"),
        "MgO": ("magnesium oxide", "MgO", "F m -3 m"),
    }
    for phase in project.phases():
        common_name, formula, space_group = labels[phase.name]
        cell, cell_esd = cells[phase.name]
        phase_records.append({
            "name": common_name,
            "formula": formula,
            "space_group": space_group,
            "cif_path": cif_paths[phase.name].name,
            "weight_fraction": fractions[phase.name],
            "weight_fraction_formal_esd": fraction_esd[phase.name],
            "refined_cell": cell,
            "refined_cell_formal_esd": cell_esd,
        })

    result = {
        "phases": phase_records,
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(residuals["R"]),
            "Rwp_background_subtracted_percent": float(residuals["wRb"]),
            "Rp_background_subtracted_percent": float(residuals["Rb"]),
            "Rexp_percent": rexp,
            "goodness_of_fit": gof,
            "reduced_chi_squared": gof * gof,
            "n_profile_points": int(x.size),
            "refinement_range_two_theta_deg": [float(x[0]), float(x[-1])],
        },
        "project_path": FINAL.name,
        "profile_path": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    md = float(mgwo4.data["Histograms"][hist.name]["Pref.Ori."][1])
    zero = float(hist.InstrumentParameters["Zero"][1])
    report = f"""# PXRD phase analysis

The refined crystalline assemblage is **MgWO4 + WO3 + MgO**. Quantitative phase analysis, normalized over these modeled crystalline phases, gives **{100*fractions['MgWO4']:.2f} wt% MgWO4**, **{100*fractions['WO3_tri']:.2f} wt% WO3**, and **{100*fractions['MgO']:.2f} wt% MgO**. The formal least-squares standard uncertainties are {100*fraction_esd['MgWO4']:.2f}, {100*fraction_esd['WO3_tri']:.2f}, and {100*fraction_esd['MgO']:.2f} percentage points, respectively; realistic uncertainty is larger because no calibrated instrumental profile, absorption standard, or particle-size/microabsorption information was supplied.

## Evidence

MgWO4 accounts for the dominant wolframite-type sequence (including the strong peaks near 15.93, 19.24, 24.21, 30.81, and 31.11 degrees 2theta). Peaks not explained by MgWO4 near 23.43, 23.93, 24.67, 26.91, 28.94, and 34.47 degrees identify WO3. The 43.21 and 62.54 degree lines, together with the weaker high-angle reflections, require MgO; its refined cubic cell is {cells['MgO'][0]['length_a']:.5f} A. Adding WO3 reduced Rwp from about 19.8% for MgWO4 alone to 11.7%, and adding MgO reduced it further. The submitted joint fit has Rwp = {rwp:.3f}%, Rp = {residuals['R']:.3f}%, Rexp = {rexp:.3f}%, and goodness-of-fit = {gof:.3f}.

The WO3 peaks are fit best with a triclinic P-1 model (Rwp about 10.55% before the final texture/joint refinement), versus about 10.58% for an alternative monoclinic P21/c setting and 10.88% for the simpler monoclinic P21/n model. A mild MgWO4 [110] March-Dollase correction (ratio {md:.3f}) improves the profile and is consistent with reflection geometry. The fitted common zero offset is {zero:.4f} degrees 2theta. Cu Kalpha1/Kalpha2 wavelengths and their fixed 0.5 intensity ratio were taken from the metadata; Poisson counting uncertainties (sigma = sqrt(counts)) were used because pointwise uncertainties were not supplied.

## Remaining uncertainty

The presence of all three chemical phases is robust. The exact WO3 symmetry is less secure: triclinic and monoclinic WO3 models are very similar at this resolution and differ only modestly in fit quality, so the submitted P-1 structure should be regarded as the best-supported model rather than an unambiguous polymorph determination. The quoted phase-fraction standard uncertainties are formal only; preferred orientation and especially microabsorption contrast between MgO and the W-rich phases can shift the absolute fractions by more than those values. No amorphous fraction can be quantified without an internal standard, so the fractions apply only to modeled crystalline material.
"""
    (ROOT / "report.md").write_text(report)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
