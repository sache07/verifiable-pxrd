from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent

for tag, hkl in {"100": [1, 0, 0], "010": [0, 1, 0], "001": [0, 0, 1],
                 "110": [1, 1, 0], "011": [0, 1, 1], "101": [1, 0, 1]}.items():
    p = G2sc.G2Project(str(ROOT / "model_tri_mgo.gpx"), newgpx=str(ROOT / f"texture_{tag}.gpx"))
    h = p.histogram(0)
    h.clear_refinements({"Background": True,
                         "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
    for ph in p.phases():
        ph.clear_refinements({"Cell": True})
        ph.clear_HAP_refinements({"Scale": True, "Pref.Ori.": True})
    mg = p.phase("MgWO4")
    po = mg.data["Histograms"][h.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = hkl
    p.data["Controls"]["data"]["max cyc"] = 10
    p.refine()
    print("TEXTURE", tag, h.residuals, "PO", po)
