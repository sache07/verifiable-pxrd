from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
MGOCIF = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/04/9000499.cif"

p = G2sc.G2Project(str(ROOT / "model_n.gpx"), newgpx=str(ROOT / "model_n_mgo2.gpx"))
h = p.histogram(0)
h.clear_refinements({"Background": True, "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y"]})
for ph in p.phases():
    ph.clear_refinements({"Cell": True})
    ph.clear_HAP_refinements({"Scale": True})

mgo = p.add_phase(MGOCIF, phasename="MgO", histograms=[h], fmthint="CIF")
mgo.data["Histograms"][h.name]["Scale"] = [0.1, True]
p.data["Controls"]["data"]["max cyc"] = 10
p.refine()
print("MGO_ONLY_SCALE", h.residuals)
print("MGO_SCALE", mgo.data["Histograms"][h.name]["Scale"])
try:
    print("MASS", h.ComputeMassFracs())
except Exception as err:
    print("MASSERR", repr(err))

for ph in p.phases():
    ph.set_HAP_refinements({"Scale": True})
h.set_refinements({"Background": {"refine": True}, "Instrument Parameters": ["Zero"]})
p.refine()
mgo.set_refinements({"Cell": True})
p.refine()
print("MGO_JOINT", h.residuals)
print("SCALES", {ph.name: ph.data["Histograms"][h.name]["Scale"] for ph in p.phases()})
print("CELLS", {ph.name: ph.get_cell() for ph in p.phases()})
print("MASS", h.ComputeMassFracs())
p.save()
