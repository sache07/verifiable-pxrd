from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
p = G2sc.G2Project(str(ROOT / "model_tri_mgo.gpx"), newgpx=str(ROOT / "settled.gpx"))
h = p.histogram(0)
h.clear_refinements({"Background": True})
for ph in p.phases():
    ph.clear_refinements({"Cell": True})
    ph.clear_HAP_refinements({"Scale": True, "Pref.Ori.": True})
p.data["Controls"]["data"]["max cyc"] = 20
p.refine()
print("SETTLED", h.residuals)
print("VARY", p.get_VaryList())
print("INST", h.InstrumentParameters)
p.save()
