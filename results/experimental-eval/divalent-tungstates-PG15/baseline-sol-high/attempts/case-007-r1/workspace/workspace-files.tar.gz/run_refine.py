from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIfiles as G2fil
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CSV = ROOT / "inputs" / "pattern.csv"
CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/01/39/9013902.cif")


def instrument_parameters():
    names = [
        "Type", "Lam1", "Lam2", "Zero", "I(L2)/I(L1)", "Polariz.",
        "U", "V", "W", "X", "Y", "Z", "SH/L", "Azimuth",
    ]
    values = [
        "PXC", 1.540598, 1.544426, 0.0, 0.5, 0.5,
        2.0, -1.0, 0.15, 0.0, 0.02, 0.0, 0.002, 0.0,
    ]
    return [G2fil.makeInstDict(names, values, [False] * len(values)), {}]


def make_xye():
    arr = np.genfromtxt(CSV, delimiter=",", names=True)
    x = arr["two_theta_deg"]
    y = arr["intensity"]
    sigma = np.sqrt(np.maximum(y, 1.0))
    out = ROOT / "pattern.xye"
    np.savetxt(out, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    return out


def log_state(tag, project, hist, phase):
    print("STATE", tag)
    print("residuals", hist.residuals)
    print("cell", phase.get_cell())
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()})
    print("sample", hist.SampleParameters)
    print("HAP", phase.data["Histograms"][hist.name])


def main():
    xye = make_xye()
    project = G2sc.G2Project(newgpx=str(ROOT / "trial.gpx"))
    hist = project.add_powder_histogram(str(xye), instrument_parameters(), fmthint="xye")
    phase = project.add_phase(str(CIF), phasename="MgWO4", histograms=[hist], fmthint="CIF")
    hist.set_refinements({
        "Limits": {"low": 10.0, "high": 100.0},
        "Background": {"type": "chebyschev-1", "no. coeffs": 10, "refine": True},
    })
    project.data["Controls"]["data"]["max cyc"] = 12
    project.data["Controls"]["data"]["min dM/M"] = 1e-5

    # First establish background, phase scale and the large angular offset.
    phase.set_HAP_refinements({"Scale": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    log_state("scale-background-zero", project, hist, phase)

    # Refine lattice and peak-shape terms in controlled stages.
    phase.set_refinements({"Cell": True})
    project.refine()
    log_state("cell", project, hist, phase)

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]})
    project.refine()
    log_state("profile", project, hist, phase)

    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project.refine()
    log_state("microstrain", project, hist, phase)
    project.save(str(ROOT / "trial.gpx"))


if __name__ == "__main__":
    main()
