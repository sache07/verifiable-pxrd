#!/usr/bin/env python3
"""Add and refine the residual fergusonite phase in the two-phase model."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIfiles as G2fil
from GSASII import GSASIIlattice as G2lat

G2fil.G2SetPrintLevel("all")
ROOT = Path(__file__).resolve().parent
base = ROOT / ".tmp" / "trial_1528915.gpx"
out = ROOT / ".tmp" / "three_phase.gpx"
project = G2sc.G2Project(str(base))
project.set_Controls("cycles", 12)
hist = project.histograms()[0]

# Freeze the converged two-phase metric/profile temporarily while the new
# phase scale is introduced.
hist.clear_refinements({"Background": True})
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "SH/L"]})
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Scale": True})

ferg = project.add_phase(
    "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/54/60/1546037.cif",
    phasename="SrWO4_fergusonite",
    histograms=[hist],
    fmthint="CIF",
)
# Residual-pattern search gives an isotropic 0.98387 scale relative to the
# database cell; this places the phase close enough for full cell refinement.
cell = ferg.data["General"]["Cell"]
cell[1:4] = [v * 0.98387 for v in cell[1:4]]
cell[7] = G2lat.calc_V(G2lat.cell2A(cell[1:7]))

for phase in project.phases():
    phase.set_HAP_refinements({"Scale": True})
hist.set_refinements({"Background": {"refine": True}})
project.refine(newfile=str(out), printFile=str(ROOT / ".tmp" / "three_phase.lst"))

ferg.set_refinements({"Cell": True})
project.refine(printFile=str(ROOT / ".tmp" / "three_phase.lst"))

for phase in project.phases():
    phase.set_refinements({"Cell": True})
hist.set_refinements({"Instrument Parameters": ["Zero"]})
project.refine(printFile=str(ROOT / ".tmp" / "three_phase.lst"))

hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "SH/L"]})
for _ in range(3):
    project.refine(printFile=str(ROOT / ".tmp" / "three_phase.lst"))
project.save(str(out))

print("Rwp", hist.get_wR())
print("Rvals", project["Covariance"]["data"].get("Rvals"))
print("instrument", hist.data["Instrument Parameters"][0])
for phase in project.phases():
    print(phase.name, phase.get_cell(), phase.getHAPvalues(hist)["Scale"])
