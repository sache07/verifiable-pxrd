#!/usr/bin/env python3
"""Test phase-specific isotropic crystallite-size broadening."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIfiles as G2fil

G2fil.G2SetPrintLevel("all")
root = Path(__file__).resolve().parent
project = G2sc.G2Project(str(root / ".tmp" / "three_phase.gpx"))
project.set_Controls("cycles", 12)
hist = project.histograms()[0]
main = project.phase("SrWO4")

# Undo the unsuccessful preferred-orientation trial.
po = main.getHAPvalues(hist)["Pref.Ori."]
po[1], po[2] = 1.0, False

# Separate sample broadening from the already established common instrument
# profile. Introduce one isotropic size term at a time.
hist.clear_refinements({"Instrument Parameters": ["U", "V", "W", "SH/L"]})
for phase in project.phases():
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True}})
    project.refine(printFile=str(root / ".tmp" / "size.lst"))

for _ in range(2):
    project.refine(printFile=str(root / ".tmp" / "size.lst"))
project.save(str(root / ".tmp" / "size.gpx"))
print("Rwp", hist.get_wR())
print("Rvals", project["Covariance"]["data"].get("Rvals"))
for phase in project.phases():
    print(phase.name, phase.getHAPvalues(hist)["Size"])
print("mass", hist.ComputeMassFracs())
