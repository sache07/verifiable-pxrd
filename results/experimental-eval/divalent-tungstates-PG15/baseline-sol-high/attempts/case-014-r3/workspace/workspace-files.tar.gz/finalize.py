#!/usr/bin/env python3
"""Create the final GSAS-II project and all requested deliverables."""

from pathlib import Path
import csv
import json

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIfiles as G2fil

G2fil.G2SetPrintLevel("all")
ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "po_atoms.gpx"
FINAL = ROOT / "final.gpx"

project = G2sc.G2Project(str(SOURCE))
hist = project.histograms()[0]

# Use descriptive phase names throughout the submitted project.
old_name = "candidate_1528915"
new_name = "WO3_monoclinic"
phase_data = project.data["Phases"].pop(old_name)
phase_data["General"]["Name"] = new_name
project.data["Phases"][new_name] = phase_data
project.names[-1] = [new_name if item == old_name else item for item in project.names[-1]]
refl = hist.data["Reflection Lists"]
if old_name in refl:
    refl[new_name] = refl.pop(old_name)

# Reject the exploratory preferred-orientation and unconstrained oxygen-site
# changes; retain the database atomic model while keeping refined cells,
# scales, zero/profile, and background terms.
main = project.phase("SrWO4")
main.atom("O").coordinates = (0.2497, 0.0925, 0.0421)
main.clear_refinements({"Atoms": ["O"]})
po = main.getHAPvalues(hist)["Pref.Ori."]
po[1], po[2], po[3] = 1.0, False, [0, 0, 1]
for phase in project.phases():
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})

project.set_Controls("cycles", 12)
project.save(str(FINAL))
project = G2sc.G2Project(str(FINAL))
hist = project.histograms()[0]
for _ in range(2):
    project.refine(printFile=str(ROOT / "final.lst"))
project.save(str(FINAL))

phase_specs = [
    ("SrWO4", "SrWO4 (scheelite)", "SrWO4", "I 41/a", "phase_srwo4_scheelite.cif", "1546036"),
    ("WO3_monoclinic", "WO3 (monoclinic)", "WO3", "P 21/n", "phase_wo3_monoclinic.cif", "1528915"),
    ("SrWO4_fergusonite", "SrWO4 (fergusonite)", "SrWO4", "I 2/a", "phase_srwo4_fergusonite.cif", "1546037"),
]

mass_fracs = hist.ComputeMassFracs()
phases_out = []
for project_name, display_name, formula, sg, cif_name, cod_id in phase_specs:
    phase = project.phase(project_name)
    phase.export_CIF(str(ROOT / cif_name))
    fraction, esd = mass_fracs[project_name]
    cell, cell_esd = phase.get_cell_and_esd()
    phases_out.append({
        "name": display_name,
        "formula": formula,
        "space_group": sg,
        "cif_path": cif_name,
        "weight_fraction": fraction,
        "weight_fraction_esd": esd,
        "reference_cod_id": cod_id,
        "refined_cell": cell,
        "refined_cell_esd": cell_esd,
    })

# Export the exact profile stored in the submitted project.
x, yobs, weights, ycalc, background, stored_difference = hist.data["data"][1]
lo, hi = hist.data["Limits"][1]
with (ROOT / "fit.csv").open("w", newline="") as fp:
    writer = csv.writer(fp)
    writer.writerow([
        "two_theta_deg", "observed_intensity", "calculated_intensity",
        "difference_observed_minus_calculated", "calculated_background",
        "used_in_refinement",
    ])
    for xx, yo, yc, bg in zip(x, yobs, ycalc, background):
        writer.writerow([f"{xx:.8f}", f"{yo:.8g}", f"{yc:.8g}",
                         f"{yo-yc:.8g}", f"{bg:.8g}", lo <= xx <= hi])

rvals = project["Covariance"]["data"]["Rvals"]
residuals = hist.residuals
fit_stats = {
    "Rwp_percent": float(residuals["wR"]),
    "Rp_percent": float(residuals["R"]),
    "weighted_R_bragg_percent": float(residuals["wRb"]),
    "R_bragg_percent": float(residuals["Rb"]),
    "goodness_of_fit": float(rvals["GOF"]),
    "chi_squared": float(rvals["chisq"]),
    "number_of_observations": int(rvals["Nobs"]),
    "number_of_variables": int(rvals["Nvars"]),
    "converged": bool(rvals["converged"]),
    "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
    "refinement_two_theta_range_deg": [float(lo), float(hi)],
}

result = {
    "phases": phases_out,
    "fit_statistics": fit_stats,
    "profile_path": "fit.csv",
    "gsasii_project_path": "final.gpx",
    "weight_fraction_basis": "Normalized over modeled crystalline phases",
}
with (ROOT / "result.json").open("w") as fp:
    json.dump(result, fp, indent=2)
    fp.write("\n")

fractions = {p["name"]: 100 * p["weight_fraction"] for p in phases_out}
report = f"""# PXRD phase analysis

The pattern is best described by three crystalline components: tetragonal scheelite SrWO4 ({fractions['SrWO4 (scheelite)']:.2f} wt%), monoclinic WO3 ({fractions['WO3 (monoclinic)']:.2f} wt%), and a monoclinic fergusonite-type SrWO4 component ({fractions['SrWO4 (fergusonite)']:.2f} wt%). Fractions are normalized over these modeled crystalline phases; amorphous material, if present, is not quantified.

## Evidence and refinement

The dominant lines at 18.33, 27.99, 30.22, 33.39, 45.47, 51.98, and 56.08 degrees 2theta index as scheelite SrWO4 (I 41/a). The weak triplet at approximately 23.46, 23.97, and 24.73 degrees, together with its higher-angle lines, identifies room-temperature monoclinic WO3 (P 21/n). After these two phases were fitted, a coherent residual family at approximately 29.75, 32.60, 44.66, and 48.62 degrees matched monoclinic fergusonite SrWO4 (I 2/a); adding this phase reduced Rwp from 19.00% to {fit_stats['Rwp_percent']:.2f}%.

Starting atomic models were COD 1546036, 1528915, and 1546037. The unit cells, phase scales, zero offset, common profile terms, and a 10-term Chebyshev background were refined against the original count data using the supplied Cu K-alpha1/K-alpha2 wavelengths and 0.5 intensity ratio. Literature atomic coordinates were retained. Trials with preferred orientation and phase-specific size broadening did not improve the fit. A free scheelite oxygen-coordinate trial lowered Rwp slightly but gave an implausibly long W-O distance, so it was rejected.

Final fit statistics are Rwp = {fit_stats['Rwp_percent']:.3f}%, Rp = {fit_stats['Rp_percent']:.3f}%, and GOF = {fit_stats['goodness_of_fit']:.3f}. The refinement converged with maximum shift/esd = {fit_stats['maximum_shift_over_esd']:.3f}.

## Remaining uncertainty

The scheelite and monoclinic WO3 assignments are strong. The fergusonite match is diffraction-based and internally consistent, but this polymorph is usually pressure-stabilized and no high-pressure synthesis context was provided. It may therefore represent a closely related low-symmetry Sr-W-O phase rather than unambiguous ambient fergusonite. Several modest residual intensity mismatches remain, and the instrument profile was not calibrated independently. Formal fraction standard uncertainties are about 0.2-0.3 wt%, but model/profile systematics are larger; a practical uncertainty of roughly 2-3 wt% absolute should be attached to the minor-phase fractions. No SrCO3 phase was included because its strongest expected reflections near 25.3 and 25.9 degrees are absent.
"""
with (ROOT / "report.md").open("w") as fp:
    fp.write(report)

print(json.dumps(result, indent=2))
