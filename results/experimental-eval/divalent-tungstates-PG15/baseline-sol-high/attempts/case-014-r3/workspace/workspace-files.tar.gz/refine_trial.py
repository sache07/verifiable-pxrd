#!/usr/bin/env python3
"""Run a reproducible GSAS-II trial refinement for SrWO4 + one candidate."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIfiles as G2fil

G2fil.G2SetPrintLevel("none")


ROOT = Path(__file__).resolve().parent
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return DB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def run(candidate: str | None) -> dict:
    tag = candidate or "single"
    out = ROOT / ".tmp" / f"trial_{tag}.gpx"
    out.parent.mkdir(exist_ok=True)
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma/tab/semicolon",
    )
    # Keep the global sample scale fixed; phase scales carry the quantitative
    # phase information. Refining both creates an exact scale singularity.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    main = project.add_phase(
        str(cod_path("1546036")), phasename="SrWO4", histograms=[hist], fmthint="CIF"
    )
    phases = [main]
    if candidate:
        minor = project.add_phase(
            str(cod_path(candidate)), phasename=f"candidate_{candidate}", histograms=[hist], fmthint="CIF"
        )
        phases.append(minor)

    project.set_Controls("cycles", 8)
    hist.set_refinements({
        "Limits": [10.05, 99.95],
        "Background": {"type": "chebyschev-1", "no. coeffs": 10, "refine": True},
    })
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})

    # Work from the least-correlated terms toward profile and lattice terms.
    project.refine(printFile=str(ROOT / ".tmp" / f"trial_{tag}.lst"))
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine(printFile=str(ROOT / ".tmp" / f"trial_{tag}.lst"))
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "SH/L"]})
    project.refine(printFile=str(ROOT / ".tmp" / f"trial_{tag}.lst"))
    project.save(str(out))

    result = {
        "candidate": candidate,
        "wR_percent": hist.get_wR(),
        "project": str(out),
        "instrument": hist.data["Instrument Parameters"][0],
        "phases": {},
    }
    for phase in phases:
        hap = phase.getHAPvalues(hist)
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
        }
    return result


if __name__ == "__main__":
    candidate = None if len(sys.argv) < 2 or sys.argv[1] == "none" else sys.argv[1]
    print(json.dumps(run(candidate), indent=2, default=str))
