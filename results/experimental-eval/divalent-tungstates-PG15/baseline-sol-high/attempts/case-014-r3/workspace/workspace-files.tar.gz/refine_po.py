#!/usr/bin/env python3
"""Test physically simple March-Dollase corrections and atomic coordinates."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIfiles as G2fil

G2fil.G2SetPrintLevel("all")
root = Path(__file__).resolve().parent
project = G2sc.G2Project(str(root / ".tmp" / "three_phase.gpx"))
project.set_Controls("cycles", 12)
hist = project.histograms()[0]
main = project.phase("SrWO4")

# The dominant 112 reflection is systematically overpredicted while most
# other scheelite reflections are underpredicted. Test a single-axis MD
# correction along 112, adding only one parameter.
po = main.getHAPvalues(hist)["Pref.Ori."]
po[3] = [1, 1, 2]
main.set_HAP_refinements({"Pref.Ori.": True})
for _ in range(2):
    project.refine(printFile=str(root / ".tmp" / "po.lst"))
project.save(str(root / ".tmp" / "po.gpx"))
print("Rwp after PO", hist.get_wR(), "PO", main.getHAPvalues(hist)["Pref.Ori."])

# Refine the only free positional site in scheelite (oxygen 16f).
main.set_refinements({"Atoms": {"O": "X"}})
for _ in range(2):
    project.refine(printFile=str(root / ".tmp" / "po_atoms.lst"))
project.save(str(root / ".tmp" / "po_atoms.gpx"))
print("Rwp after O xyz", hist.get_wR(), "O", main.atom("O").coordinates)
print("Rvals", project["Covariance"]["data"].get("Rvals"))
print("mass", hist.ComputeMassFracs())
