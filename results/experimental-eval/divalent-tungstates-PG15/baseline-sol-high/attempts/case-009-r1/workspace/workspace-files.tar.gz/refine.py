from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
GPX = ROOT / "trial.gpx"
DATA = ROOT / "pattern.xye"
INST = ROOT / "instrument.instprm"
CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif")

proj = G2sc.G2Project(newgpx=str(GPX))
hist = proj.add_powder_histogram(str(DATA), str(INST), fmthint="xye")
phase = proj.add_phase(str(CIF), phasename="MnWO4", histograms=[hist], fmthint="CIF")
proj.set_Controls("cycles", 8)

# Use the full measured range. A moderately flexible background is needed for
# the strong low-angle air/scatter tail in the raw counts.
hist.set_refinements({"Limits": [10.0, 100.0]})
hist.set_refinements({"Background": {
    "type": "chebyschev-1", "refine": True, "no. coeffs": 15
}})
phase.set_HAP_refinements({"Scale": True}, [hist])
proj.save()

def run(label):
    print("\n=====", label, "=====")
    proj.refine()
    print("wR", hist.get_wR(), "cell", phase.get_cell())
    print("residuals", hist.residuals)
    print("instrument", {k:v for k,v in hist.InstrumentParameters.items() if k in ('Zero','U','V','W','X','Y','Z','SH/L','I(L2)/I(L1)')})
    print("HAP", phase.getHAPvalues(hist))

run("background + scale")
phase.set_refinements({"Cell": True})
hist.set_refinements({"Instrument Parameters": ["Zero"]})
run("cell + zero")
hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
run("profile")
run("profile repeat")

proj.save(str(GPX))
print("FINAL", hist.get_wR(), phase.get_cell(), hist.residuals)
