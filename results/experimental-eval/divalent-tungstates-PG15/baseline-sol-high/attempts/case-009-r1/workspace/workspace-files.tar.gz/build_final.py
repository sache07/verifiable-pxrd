from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat

ROOT = Path(__file__).resolve().parent
SOURCE_CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif")

p = G2sc.G2Project(newgpx=str(ROOT / "final.gpx"))
h = p.add_powder_histogram(str(ROOT / "pattern.xye"),
                           str(ROOT / "instrument.instprm"), fmthint="xye")
ph = p.add_phase(str(SOURCE_CIF), phasename="MnWO4_wolframite",
                 histograms=[h], fmthint="CIF")
p.set_Controls("cycles", 16)

# The available COD model is reported at 2.4 GPa. Keep its chemically sound
# fractional coordinates as the starting/retained model, but initialize its
# metric at ambient MnWO4 values before refining the unit cell.
cell = [4.8290, 5.7580, 4.9960, 90.0, 91.15, 90.0]
ph.data["General"]["Cell"][1:7] = cell
ph.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))

# Remove the exact global-scale/phase-scale redundancy.
h.data["Sample Parameters"]["Scale"] = [1.0, False]
h.data["Sample Parameters"]["Shift"] = [-400.0, False]
ph.data["Histograms"][h.name]["Scale"] = [1.0, True]

x = h.getdata("X")
h.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
h.set_refinements({"Background": {
    "type": "chebyschev-1", "refine": True, "no. coeffs": 15
}})

# With no calibrated instrumental profile, use only positive constant Gaussian
# and Lorentzian terms. This avoids an underdetermined five-term Caglioti fit.
for key, val in {"U": 0.0, "V": 0.0, "W": 100.0,
                 "X": 10.0, "Y": 0.0}.items():
    h.InstrumentParameters[key][1:] = [val, False]
h.InstrumentParameters["Zero"][1:] = [0.0, False]
for key in ("W", "X"):
    p.set_Controls("parmMin", 0.0, variable=f":0:{key}")
p.save()

def refine(label):
    print("\n=====", label, "=====")
    p.refine()
    print("Rwp", h.get_wR(), "cell", ph.get_cell())

refine("background and phase scale")
ph.set_refinements({"Cell": True})
h.set_refinements({"Sample Parameters": ["Shift"]})
refine("cell and specimen height")
h.set_refinements({"Instrument Parameters": ["W", "X"]})
refine("simple profile")
refine("final convergence")
p.save(str(ROOT / "final.gpx"))

# Export all primary numerical artifacts from the final in-memory project.
ph.export_CIF(str(ROOT / "MnWO4.cif"))
arr = np.column_stack([
    h.getdata("X"), h.getdata("Yobs"), h.getdata("Ycalc"),
    h.getdata("Residual"), h.getdata("Background")
])
np.savetxt(ROOT / "fit.csv", arr, delimiter=",",
           header="two_theta_deg,observed_intensity,calculated_intensity,difference_observed_minus_calculated,background_intensity",
           comments="", fmt="%.12g")

r = h.residuals
rv = p.data["Covariance"]["data"]["Rvals"]
cell_val, cell_esd = ph.get_cell_and_esd()
result = {
    "phases": [{
        "name": "MnWO4 (wolframite)",
        "formula": "MnWO4",
        "space_group": "P2/c",
        "cif_path": "MnWO4.cif",
        "weight_fraction": 1.0,
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "cell": cell_val,
        "cell_esd": cell_esd,
    }],
    "fit_statistics": {
        "Rwp_percent": float(r["wR"]),
        "Rp_percent": float(r["R"]),
        "Rexp_percent": float(r["wRmin"]),
        "goodness_of_fit": float(rv["GOF"]),
        "chi_square": float(rv["chisq"]),
        "n_observations": int(rv["Nobs"]),
        "n_variables": int(rv["Nvars"]),
        "weighted_background_R_percent": float(r["wRb"]),
        "Bragg_R_percent": float(r["Rb"]),
    },
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
