from pathlib import Path
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat

ROOT=Path(__file__).resolve().parent
p=G2sc.G2Project(newgpx=str(ROOT/'simple.gpx'))
h=p.add_powder_histogram(str(ROOT/'pattern.xye'),str(ROOT/'instrument.instprm'),fmthint='xye')
ph=p.add_phase('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif',phasename='MnWO4',histograms=[h],fmthint='CIF')
p.set_Controls('cycles',16)
cell=[4.829,5.758,4.996,90.,91.15,90.]
ph.data['General']['Cell'][1:7]=cell
ph.data['General']['Cell'][7]=G2lat.calc_V(G2lat.cell2A(cell))
h.data['Sample Parameters']['Scale']=[1.,False]
h.data['Sample Parameters']['Shift']=[-400.,False]
ph.data['Histograms'][h.name]['Scale']=[1.,True]
h.set_refinements({'Limits':[10.,100.], 'Background':{'type':'chebyschev-1','refine':True,'no. coeffs':15}})
for k,v in {'U':0.,'V':0.,'W':100.,'X':10.,'Y':0.}.items(): h.InstrumentParameters[k][1:]=[v,False]
for k in ('W','X'): p.set_Controls('parmMin',0.,variable=f':0:{k}')
p.save()
def go(s):
 print('\n===',s,'===');p.refine();print('wR',h.get_wR(),'cell',ph.get_cell());print('shift',h.data['Sample Parameters']['Shift']);print('prof',{k:h.InstrumentParameters[k] for k in ('U','V','W','X','Y')});print(h.residuals)
go('background scale')
ph.set_refinements({'Cell':True});h.set_refinements({'Sample Parameters':['Shift']});go('cell shift')
h.set_refinements({'Instrument Parameters':['W','X']});go('profile');go('profile repeat')
ph.set_refinements({'Atoms':{'all':'X'}});go('coordinates');go('coordinates repeat')
p.save()
