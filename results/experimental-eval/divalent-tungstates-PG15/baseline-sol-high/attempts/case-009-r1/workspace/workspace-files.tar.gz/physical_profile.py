from pathlib import Path
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "pattern.xye"
INST = ROOT / "instrument.instprm"
CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif")

def run_model(tag, refine_v=True, refine_y=False):
    out = ROOT / f"physical_{tag}.gpx"
    p = G2sc.G2Project(newgpx=str(out))
    h = p.add_powder_histogram(str(DATA), str(INST), fmthint="xye")
    ph = p.add_phase(str(CIF), phasename="MnWO4", histograms=[h], fmthint="CIF")
    p.set_Controls("cycles", 16)
    cell = [4.8290, 5.7580, 4.9960, 90.0, 91.15, 90.0]
    ph.data["General"]["Cell"][1:7] = cell
    ph.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))
    h.data["Sample Parameters"]["Scale"] = [1.0, False]
    ph.data["Histograms"][h.name]["Scale"] = [1.0, True]
    h.set_refinements({"Limits": [10., 100.]})
    h.set_refinements({"Background": {"type":"chebyschev-1", "refine":True, "no. coeffs":15}})
    for key,val in {"U":700.,"V":-200.,"W":25.,"X":15.,"Y":0.}.items():
        h.InstrumentParameters[key][1:] = [val,False]
    h.InstrumentParameters["Zero"][1:] = [0.,False]
    h.data["Sample Parameters"]["Shift"] = [-400.,False]
    # Keep width terms in their physically meaningful domain.
    for key in ("U","W","X","Y"):
        p.set_Controls("parmMin", 0.0, variable=f":0:{key}")
    p.save()

    def ref(label):
        print("\n===",tag,label,"===")
        p.refine()
        print("wR",h.get_wR(),"cell",ph.get_cell())
        print("sample",h.data['Sample Parameters']['Shift'])
        print("profile",{k:h.InstrumentParameters[k] for k in ('U','V','W','X','Y')})
        print("res",h.residuals)

    ref("background scale")
    ph.set_refinements({"Cell":True})
    h.set_refinements({"Sample Parameters":["Shift"]})
    ref("cell shift")
    names=["U","W","X"]
    if refine_v: names.append("V")
    if refine_y: names.append("Y")
    h.set_refinements({"Instrument Parameters":names})
    ref("profile")
    ref("profile repeat")
    ph.set_refinements({"Atoms":{"all":"X"}})
    ref("coordinates")
    ref("coordinates repeat")
    p.save()

run_model("uwx", refine_v=False, refine_y=False)
run_model("uvwx", refine_v=True, refine_y=False)
run_model("uvwxy", refine_v=True, refine_y=True)
