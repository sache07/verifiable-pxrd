from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT=Path(__file__).resolve().parent
candidates={
 "WO3_monoclinic":"<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif",
 "Mn3WO6":"<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/00/27/2002703.cif",
 "Mn3O4_candidate":"<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/13/9001302.cif",
}

for name,cif in candidates.items():
 p=G2sc.G2Project(str(ROOT/'final.gpx'),newgpx=str(ROOT/f'minor_{name}.gpx'))
 h=p.histogram(0); main=p.phase(0)
 test=p.add_phase(cif,phasename=name,histograms=[h],fmthint='CIF')
 p.set_Controls('cycles',12)
 # Freeze the accepted single-phase model and fit only the candidate scale.
 h.data['Background'][0][1]=False
 for v in h.InstrumentParameters.values():
  if isinstance(v,list) and len(v)>2: v[2]=False
 for key,val in h.data['Sample Parameters'].items():
  if isinstance(val,list) and len(val)>1 and isinstance(val[1],bool): val[1]=False
 for phase in (main,test):
  phase.data['General']['Cell'][0]=False
  for atom in phase.atoms(): atom.refinement_flags=' '
  phase.data['Histograms'][h.name]['Scale'][1]=False
 test.data['Histograms'][h.name]['Scale']=[0.1,True]
 p.save();p.refine();p.save()
 cov=p.data['Covariance']['data']; key=f'{test.id}:0:Scale'
 if key in cov['varyList']:
  i=cov['varyList'].index(key); sig=cov['sig'][i]
 else: sig=None
 print('CANDIDATE',name,'Rwp',h.get_wR(),'scale',test.getHAPvalues(h)['Scale'],'sig',sig)
 try: print('MASS',h.ComputeMassFracs())
 except Exception as e: print('MASS_ERROR',repr(e))
