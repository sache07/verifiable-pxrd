from pathlib import Path
import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "pattern.xye"
INST = ROOT / "instrument.instprm"
CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif")

def create(tag, posmode="shift", atoms=False, yterm=False, bgterms=15):
    path = ROOT / f"compare_{tag}.gpx"
    proj = G2sc.G2Project(newgpx=str(path))
    hist = proj.add_powder_histogram(str(DATA), str(INST), fmthint="xye")
    phase = proj.add_phase(str(CIF), phasename="MnWO4", histograms=[hist], fmthint="CIF")
    proj.set_Controls("cycles", 12)

    # Ambient-pressure MnWO4 metric; the source CIF coordinates are retained,
    # but its 2.4 GPa cell is not an appropriate ambient starting value.
    cell = [4.8290, 5.7580, 4.9960, 90.0, 91.15, 90.0]
    phase.data["General"]["Cell"][1:7] = cell
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))

    # Avoid the exact sample-scale/phase-scale redundancy.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    phase.data["Histograms"][hist.name]["Scale"] = [1.0, True]
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements({"Background": {
        "type": "chebyschev-1", "refine": True, "no. coeffs": bgterms
    }})

    # Reasonable broad laboratory-profile starting point from the pilot fit.
    for key, val in {"U": 500.0, "V": -150.0, "W": 20.0,
                     "X": 30.0, "Y": 0.0}.items():
        hist.InstrumentParameters[key][1] = val
        hist.InstrumentParameters[key][2] = False
    hist.InstrumentParameters["Zero"][1:] = [0.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    proj.save()

    def run(label):
        print(f"\n===== {tag}: {label} =====")
        proj.refine()
        print("wR", hist.get_wR(), "cell", phase.get_cell())
        print("res", hist.residuals)
        print("sample", {k:v for k,v in hist.data['Sample Parameters'].items()
                         if k in ('Scale','Shift')})
        print("inst", {k:v for k,v in hist.InstrumentParameters.items()
                       if k in ('Zero','U','V','W','X','Y','I(L2)/I(L1)')})

    run("background + phase scale")
    phase.set_refinements({"Cell": True})
    if posmode == "shift":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    elif posmode == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run("cell + position correction")
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X"]})
    if yterm:
        hist.set_refinements({"Instrument Parameters": ["Y"]})
    run("profile")
    run("profile repeat")
    if atoms:
        phase.set_refinements({"Atoms": {"all": "X"}})
        run("atomic coordinates")
        run("coordinates repeat")
    proj.save()
    return hist.get_wR()

for args in [
    ("zero", "zero", False, False, 15),
    ("shift", "shift", False, False, 15),
    ("shift_atoms", "shift", True, False, 15),
    ("shift_atoms_y", "shift", True, True, 15),
]:
    try:
        print("MODEL_RESULT", args[0], create(*args))
    except Exception as exc:
        print("MODEL_FAILED", args[0], repr(exc))
