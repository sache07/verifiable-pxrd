from pathlib import Path
import json
import re

import numpy as np

import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "inputs" / "pattern.csv"
SOURCE_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/4/00/08/4000806.cif"
)


def make_inputs():
    arr = np.loadtxt(INPUT, delimiter=",", skiprows=1)
    # The supplied data have no pointwise uncertainties. Counting-statistical
    # weights are the least-assumptive approximation for raw counts.
    np.savetxt(
        ROOT / "pattern.xye",
        np.column_stack((arr[:, 0], arr[:, 1], np.sqrt(np.maximum(arr[:, 1], 1.0)))),
        fmt="%.8f %.8f %.8f",
    )

    text = SOURCE_CIF.read_text()
    values = {
        "_cell_length_a": "4.7026",
        "_cell_length_b": "5.8387",
        "_cell_length_c": "4.8783",
        "_cell_angle_alpha": "91.676",
        "_cell_angle_beta": "92.469",
        "_cell_angle_gamma": "82.805",
    }
    for tag, value in values.items():
        text = re.sub(rf"(?m)^{re.escape(tag)}\s+\S+", f"{tag:<32}{value}", text)
    (ROOT / "initial_CuWO4.cif").write_text(text)

    (ROOT / "instrument.instprm").write_text(
        "#GSAS-II instrument parameter file\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:2.0;V:-2.0;W:5.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )


def show(stage, project, hist, phase):
    print("\nSTAGE", stage)
    print("residuals", hist.residuals)
    print("cell", phase.get_cell())
    print("inst", {k: v for k, v in hist.InstrumentParameters.items() if k in ['Zero','U','V','W','X','Y','SH/L','I(L2)/I(L1)']})
    print("sample", hist.SampleParameters)
    print("scale", phase.data['Histograms'][hist.name]['Scale'])


def main():
    make_inputs()
    gpx = ROOT / "trial.gpx"
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"), fmthint="xye"
    )
    phase = project.add_phase(
        str(ROOT / "initial_CuWO4.cif"), phasename="CuWO4", histograms=[hist], fmthint="CIF"
    )
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 15,
            "coeffs": [1400.0] + [0.0] * 14,
        },
    })
    phase.set_HAP_refinements({"Scale": True})
    project.set_Controls("cycles", 8)
    project.refine()
    show("scale+bkg", project, hist, phase)

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    show("cell+zero", project, hist, phase)

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]})
    project.refine()
    show("profile", project, hist, phase)

    # Sample height in reflection geometry is often more physical than a free
    # constant zero, but inspect stability before retaining it.
    hist.set_refinements({"Sample Parameters": ["DisplaceX"]})
    project.refine()
    show("displacement", project, hist, phase)
    project.save()


if __name__ == "__main__":
    main()
