from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main():
    project = G2sc.G2Project(
        str(ROOT / "twophase_refine.gpx"), newgpx=str(ROOT / "final.gpx")
    )
    hist = project.histogram(0)
    project.set_Controls("cycles", 12)
    # One final cycle sequence ensures that the saved covariance matrix and
    # exported profiles all correspond to the submitted project state.
    for _ in range(3):
        project.refine()
    project.save()

    phases = project.phases()
    cif_names = ["CuWO4.cif", "WO3.cif"]
    for phase, cif_name in zip(phases, cif_names):
        phase.export_CIF(str(ROOT / cif_name))

    x, observed, weights, calculated, background, difference = hist.data["data"][1]
    low, high = hist.data["Limits"][1]
    use = (x >= low) & (x <= high)
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack(
            (x[use], observed[use], calculated[use], background[use], difference[use])
        ),
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference_observed_minus_calculated",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
    )

    mass_fracs = hist.ComputeMassFracs()
    residuals = hist.residuals
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    phase_rows = []
    display_names = ["CuWO4", "WO3"]
    formulas = ["CuWO4", "WO3"]
    space_groups = ["P -1", "P 21/c"]
    for phase, display, formula, sg, cif_name in zip(
        phases, display_names, formulas, space_groups, cif_names
    ):
        frac, frac_esd = mass_fracs[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phase_rows.append(
            {
                "name": display,
                "formula": formula,
                "space_group": sg,
                "cif_path": cif_name,
                "weight_fraction": frac,
                "weight_fraction_formal_esd": frac_esd,
                "unit_cell": cell,
                "unit_cell_formal_esd": cell_esd,
            }
        )

    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "R_p_percent": residuals["R"],
            "R_wp_percent": residuals["wR"],
            "R_exp_percent": residuals["wRmin"],
            "goodness_of_fit": rvals.get("GOF"),
            "reduced_chi_square": (rvals.get("GOF") or 0.0) ** 2,
            "CuWO4_R_F_percent": residuals.get("0:0:Rf"),
            "CuWO4_R_F2_percent": residuals.get("0:0:Rf^2"),
            "WO3_R_F_percent": residuals.get("1:0:Rf"),
            "WO3_R_F2_percent": residuals.get("1:0:Rf^2"),
            "modeled_two_theta_range_deg": [float(low), float(high)],
            "number_of_profile_points": int(use.sum()),
        },
        "weighting": "Poisson approximation: sigma(I)=sqrt(max(I,1)); input uncertainties were not supplied.",
        "fraction_normalization": "Normalized over the modeled crystalline phases only.",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    cu = phase_rows[0]
    wo = phase_rows[1]
    report = f"""# PXRD phase analysis

The pattern is modeled as **triclinic CuWO4 (P -1)** with a small amount of **monoclinic WO3 (P 21/c)**. The refined crystalline-phase fractions are **{100*cu['weight_fraction']:.2f} wt% CuWO4** and **{100*wo['weight_fraction']:.2f} wt% WO3**, normalized to the modeled crystalline material.

## Evidence

The CuO + WO3 precursor chemistry and 800 °C treatment support copper tungstate formation, but phase assignment was based on the diffraction pattern. The strong lines at approximately 15.61, 19.32, 23.23/23.88/24.43, 26.27, 28.98, 30.44, and 31.94 degrees 2theta, together with the dense high-angle splitting, are indexed by the triclinic CuWO4 cell. Its refined cell is a = {cu['unit_cell']['length_a']:.6f} A, b = {cu['unit_cell']['length_b']:.6f} A, c = {cu['unit_cell']['length_c']:.6f} A, alpha = {cu['unit_cell']['angle_alpha']:.5f} deg, beta = {cu['unit_cell']['angle_beta']:.5f} deg, gamma = {cu['unit_cell']['angle_gamma']:.5f} deg.

A screen of CuO, Cu3WO6, and the available WO3 polymorphs found no positive CuO contribution and only a negligible, non-robust Cu3WO6 contribution. Room-temperature monoclinic WO3 was the best minor-phase model. Adding it reduced Rwp from 7.65% for CuWO4 alone to {residuals['wR']:.2f}% in the jointly refined model and gave a positive scale corresponding to {100*wo['weight_fraction']:.2f} wt%. The refined WO3 cell is a = {wo['unit_cell']['length_a']:.5f} A, b = {wo['unit_cell']['length_b']:.5f} A, c = {wo['unit_cell']['length_c']:.5f} A, beta = {wo['unit_cell']['angle_beta']:.4f} deg.

The final profile statistics are Rp = {residuals['R']:.2f}%, Rwp = {residuals['wR']:.2f}%, Rexp = {residuals['wRmin']:.2f}%, and goodness of fit = {rvals.get('GOF', float('nan')):.2f}. The refined and calculated profiles in `fit.csv` cover {low:.2f}-{high:.2f} degrees 2theta.

## Remaining uncertainty

No pointwise standard uncertainties or calibrated instrumental profile were supplied, so sqrt(counts) weights and an empirical Cu K-alpha1/K-alpha2 profile were used. Formal fraction uncertainties from the least-squares covariance are about {100*wo['weight_fraction_formal_esd']:.2f} wt% for WO3, but they do not include model, microabsorption, preferred-orientation, or instrumental systematic errors; a more realistic uncertainty for the minor phase is approximately +/-0.5 wt%. The large refined zero offset is correlated with absolute lattice scale, so the very small formal cell errors understate absolute-cell uncertainty.

CuWO4 Cu/O positions were refined while W was fixed to define the origin. For the ~2 wt% WO3 phase, atomic coordinates were retained from COD 2311041 and only its cell and scale were refined; its a, c, and beta values are weakly constrained because most WO3 peaks overlap CuWO4. Thus the WO3 phase identity and approximate fraction are supported, but detailed WO3 coordinates cannot be determined reliably from this pattern. Fractions exclude any amorphous material, which cannot be quantified without an internal standard.
"""
    (ROOT / "report.md").write_text(report)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
