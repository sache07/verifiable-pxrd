from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def prep(name):
    p = G2sc.G2Project(str(ROOT / "trial.gpx"), newgpx=str(ROOT / name))
    h = p.histogram(0)
    ph = p.phase(0)
    h.SampleParameters["Scale"][1] = False
    h.SampleParameters["DisplaceX"][1] = False
    ph.data["Histograms"][h.name]["Scale"][1] = True
    p.set_Controls("cycles", 12)
    return p, h, ph


def report(label, p, h, ph):
    print("\n", label, h.residuals)
    print("cell", ph.get_cell())
    print("scale", ph.data["Histograms"][h.name]["Scale"])
    print("pref", ph.data["Histograms"][h.name]["Pref.Ori."])
    print("inst", {k: v for k, v in h.InstrumentParameters.items() if k in ["Zero", "U", "V", "W", "X", "Y", "SH/L"]})
    for a in ph.atoms():
        print(a.label, a.coordinates, a.uiso, a.refinement_flags)


def coordinates():
    p, h, ph = prep("coords.gpx")
    # Establish a non-singular baseline first.
    p.refine()
    report("baseline", p, h, ph)
    ph.set_refinements({"Atoms": {"Cu1": "X"}})
    p.refine()
    report("Cu xyz", p, h, ph)
    ph.set_refinements({"Atoms": {"O1": "X", "O2": "X", "O3": "X", "O4": "X"}})
    p.refine()
    report("Cu+O xyz", p, h, ph)
    p.save()


def physical_profile():
    p, h, ph = prep("physical.gpx")
    for key in ["Y"]:
        h.InstrumentParameters[key][1] = 0.0
        h.InstrumentParameters[key][2] = False
    p.refine()
    report("Y fixed zero", p, h, ph)
    p.save()


def preferred_orientation():
    p, h, ph = prep("pref.gpx")
    # Test the strongest low-index reciprocal directions. Retain only if
    # stable and materially better than the no-texture model.
    hap = ph.data["Histograms"][h.name]
    for axis in ([1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0], [1, 1, -1]):
        hap["Pref.Ori."][3] = list(axis)
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        p.refine()
        report("MD " + str(axis), p, h, ph)
        hap["Pref.Ori."][2] = False
    p.save()


if __name__ == "__main__":
    coordinates()
    physical_profile()
    preferred_orientation()
