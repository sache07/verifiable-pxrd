from pathlib import Path
import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
DB = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')

IDS = {
    'SrWO4': '1546036',
    'WO3': '1010618',
    'WO3_mono': '1528915',
    'WO3_mono2': '1563541',
    'WO3_tric': '2106293',
    'WO3_ortho': '2107312',
    'WO3_tetra': '1521532',
    'SrO': '7200689',
    'SrO2': '9008161',
    'Sr3W2O9': '2311977',
    'SrCO3': '9008198',
}


def cif_for(cod_id):
    hits = list(DB.rglob(cod_id + '.cif'))
    if len(hits) != 1:
        raise RuntimeError(f'Expected one CIF for {cod_id}, found {hits}')
    return hits[0]


def make_project(names):
    tag = '_'.join(names)
    work = ROOT / '.tmp' / ('screen_' + tag)
    work.mkdir(parents=True, exist_ok=True)
    gpx = work / 'model.gpx'
    if gpx.exists():
        gpx.unlink()
    proj = G2sc.G2Project(newgpx=str(gpx))
    hist = proj.add_powder_histogram(str(ROOT / 'pattern.xye'), str(ROOT / 'instrument.instprm'), fmthint='xye')
    hist.set_refinements({
        'Limits': [10.05, 99.90],
        'Background': {'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 16},
    })
    # The histogram scale and phase scales are exactly redundant. Keep the
    # histogram scale fixed and refine the HAP scale for each phase.
    hist.data['Sample Parameters']['Scale'][1] = False
    inst = hist.data['Instrument Parameters'][0]
    # Approximate the observed broad laboratory profile before fitting.
    for key, val in {'U': 0.0, 'V': 0.0, 'W': 150.0, 'X': 0.0, 'Y': 0.0}.items():
        inst[key][0] = inst[key][1] = val
        inst[key][2] = False
    phases = []
    for i, name in enumerate(names):
        ph = proj.add_phase(str(cif_for(IDS[name])), phasename=name, histograms=[hist], fmthint='CIF')
        hap = ph.data['Histograms'][hist.name]
        hap['Scale'][0] = 1.0 if i == 0 else 0.03
        hap['Scale'][1] = True
        if i:
            hap['Use'] = False
        phases.append(ph)
    proj.save()
    proj.set_Controls('cycles', 8)
    # Stabilize the dominant phase before introducing candidate minorities.
    proj.do_refinements([{}])
    phases[0].set_refinements({'Cell': True})
    hist.set_refinements({'Instrument Parameters': ['Zero']})
    proj.do_refinements([{}])
    hist.set_refinements({'Instrument Parameters': ['W']})
    proj.do_refinements([{}])
    # Add candidate phases sequentially so a weaker phase cannot suppress a
    # stronger one during the first linear scale adjustment.
    for ph in phases[1:]:
        ph.data['Histograms'][hist.name]['Use'] = True
        proj.do_refinements([{}])
        ph.set_refinements({'Cell': True})
        proj.do_refinements([{}, {}])
    proj.save()
    masses = hist.ComputeMassFracs()
    inst = hist.data['Instrument Parameters'][0]
    out = {
        'names': names,
        'Rwp': hist.get_wR(),
        'GOF': proj.data['Covariance']['data'].get('Rvals', {}).get('GOF'),
        'mass_fracs': masses,
        'cells': {p.name: p.get_cell() for p in proj.phases()},
        'inst': {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
    }
    print(json.dumps(out, indent=2))
    return out


if __name__ == '__main__':
    make_project(sys.argv[1:])
