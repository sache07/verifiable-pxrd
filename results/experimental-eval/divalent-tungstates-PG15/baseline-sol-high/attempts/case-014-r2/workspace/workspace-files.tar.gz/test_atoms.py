from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
mode = sys.argv[1]
src = root / '.tmp' / 'texture_112.gpx'
dst = root / '.tmp' / ('atoms_' + mode + '.gpx')
proj = G2sc.G2Project(str(src), newgpx=str(dst))
proj.set_Controls('cycles', 12)
main = proj.phase('SrWO4')
if mode in ('ox', 'oxu'):
    main.set_refinements({'Atoms': {'O': 'X'}})
if mode in ('u', 'oxu'):
    for atom in main.atoms():
        atom.refinement_flags += 'U'
proj.do_refinements([{}, {}])
proj.save()
atoms = []
for a in main.atoms():
    atoms.append({'label': a.label, 'xyz': a.coordinates,
                  'uiso': None if a.adp_flag != 'I' else a.uiso,
                  'flags': a.refinement_flags})
print(json.dumps({
    'mode': mode,
    'Rwp': proj.histogram(0).get_wR(),
    'GOF': proj.data['Covariance']['data']['Rvals']['GOF'],
    'mass': proj.histogram(0).ComputeMassFracs(),
    'atoms': atoms,
}, indent=2))
