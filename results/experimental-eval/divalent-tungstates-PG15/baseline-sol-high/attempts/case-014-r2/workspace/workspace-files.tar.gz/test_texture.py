from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
direction = [int(v) for v in sys.argv[1:4]]
tag = ''.join(map(str, direction))
src = root / '.tmp' / 'screen_SrWO4_Sr3W2O9_WO3' / 'model.gpx'
dst = root / '.tmp' / ('texture_' + tag + '.gpx')
proj = G2sc.G2Project(str(src), newgpx=str(dst))
proj.set_Controls('cycles', 12)
# The historical WO3 model is triclinic with exact 90-degree angles, which
# makes unconstrained six-parameter cell refinement ill-conditioned.
proj.phase('WO3').clear_refinements({'Cell': True})
ph = proj.phase('SrWO4')
hap = ph.data['Histograms'][proj.histogram(0).name]
hap['Pref.Ori.'][3] = direction
ph.set_HAP_refinements({'Pref.Ori.': True})
proj.do_refinements([{}, {}])
proj.save()
print(json.dumps({
    'direction': direction,
    'Rwp': proj.histogram(0).get_wR(),
    'GOF': proj.data['Covariance']['data']['Rvals']['GOF'],
    'MD': hap['Pref.Ori.'][1],
    'mass': proj.histogram(0).ComputeMassFracs(),
}, indent=2))
