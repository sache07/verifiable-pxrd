from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
mode = sys.argv[1]
tokens = mode.split('_')
src = (root / '.tmp' / 'option_uv.gpx') if 'fromuv' in tokens else (root / '.tmp' / 'screen_SrWO4_Sr3W2O9_WO3_mono' / 'model.gpx')
dst = root / '.tmp' / ('option_' + mode + '.gpx')
proj = G2sc.G2Project(str(src), newgpx=str(dst))
proj.set_Controls('cycles', 12)
hist = proj.histogram(0)
main = proj.phase('SrWO4')
if 'pol' in tokens:
    hist.set_refinements({'Instrument Parameters': ['Polariz.']})
if 'uv' in tokens:
    hist.set_refinements({'Instrument Parameters': ['U', 'V']})
if 'x' in tokens:
    hist.set_refinements({'Instrument Parameters': ['X']})
if 'y' in tokens:
    hist.set_refinements({'Instrument Parameters': ['Y']})
if 'sh' in tokens:
    hist.set_refinements({'Instrument Parameters': ['SH/L']})
if 'po' in tokens:
    hap = main.data['Histograms'][hist.name]
    hap['Pref.Ori.'][3] = [1, 1, 2]
    main.set_HAP_refinements({'Pref.Ori.': True})
if 'ox' in tokens:
    main.set_refinements({'Atoms': {'O': 'X'}})
proj.do_refinements([{}, {}, {}])
proj.save()
inst = hist.data['Instrument Parameters'][0]
print(json.dumps({
    'mode': mode,
    'Rwp': hist.get_wR(),
    'GOF': proj.data['Covariance']['data']['Rvals']['GOF'],
    'max_shift_esd': proj.data['Covariance']['data']['Rvals']['Max shft/sig'],
    'polarization': inst['Polariz.'][1],
    'profile_UVW': [inst[k][1] for k in ('U', 'V', 'W')],
    'mass': hist.ComputeMassFracs(),
    'O_xyz': main.atom('O').coordinates,
    'MD': main.data['Histograms'][hist.name]['Pref.Ori.'][1],
}, indent=2))
