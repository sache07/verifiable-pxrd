from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
source = root / '.tmp' / 'option_fromuv_x.gpx'
final_gpx = root / 'final.gpx'

# Load the converged refinement under the required final filename. All exports
# below are generated from this in-memory copy of final.gpx.
proj = G2sc.G2Project(str(source), newgpx=str(final_gpx))
proj.save()
hist = proj.histogram(0)

phase_output = {
    'SrWO4': ('SrWO4 (scheelite)', 'phase_SrWO4.cif'),
    'Sr3W2O9': ('Sr3W2O9 (monoclinic)', 'phase_Sr3W2O9.cif'),
    'WO3_mono': ('WO3 (monoclinic)', 'phase_WO3.cif'),
}

mass = hist.ComputeMassFracs()
phase_rows = []
residuals = hist.residuals
for phase in proj.phases():
    display, filename = phase_output[phase.name]
    phase.export_CIF(str(root / filename))
    frac, esd = mass[phase.name]
    cell, cell_esd = phase.get_cell_and_esd()
    phase_rows.append({
        'name': display,
        'formula': phase.name.replace('_mono', ''),
        'cif_path': filename,
        'weight_fraction': frac,
        'weight_fraction_esd_formal': esd,
        'space_group': phase.data['General']['SGData']['SpGrp'].strip(),
        'cell_angstrom_degrees': cell,
        'cell_esd_formal': cell_esd,
        'phase_Rf_percent': residuals.get(f'{phase.id}:0:Rf'),
        'phase_Rf2_percent': residuals.get(f'{phase.id}:0:Rf^2'),
    })

data = hist.data['data'][1]
x, yobs, weights, ycalc, background, difference = [np.asarray(v) for v in data]
low, high = hist.data['Limits'][1]
beg = int(np.searchsorted(x, low))
end = int(np.searchsorted(x, high)) + 1  # GSAS-II includes the upper bracketing point
used = slice(beg, end)
if not np.allclose(difference[used], (yobs - ycalc)[used]):
    raise RuntimeError('GSAS-II difference array is not observed minus calculated')
np.savetxt(
    root / 'fit.csv',
    np.column_stack((x[used], yobs[used], ycalc[used], difference[used], background[used])),
    delimiter=',',
    header='two_theta_deg,observed_counts,calculated_counts,difference_obs_minus_calc,background_counts',
    comments='',
    fmt=['%.8f', '%.8f', '%.8f', '%.8f', '%.8f'],
)

rvals = proj.data['Covariance']['data']['Rvals']
result = {
    'phases': phase_rows,
    'weight_fraction_normalization': 'modeled crystalline phases sum to 1.0',
    'fit_statistics': {
        'Rwp_percent': residuals['wR'],
        'Rp_percent': residuals['R'],
        'Rexp_percent': residuals['wRmin'],
        'GOF_chi': rvals['GOF'],
        'chi_squared': rvals['chisq'],
        'N_observations': rvals['Nobs'],
        'N_variables': rvals['Nvars'],
        'max_shift_over_esd_final': rvals['Max shft/sig'],
        'refinement_two_theta_range_deg': [float(low), float(high)],
    },
    'project_path': 'final.gpx',
    'profile_path': 'fit.csv',
    'weighting': 'Poisson approximation sigma=sqrt(counts); pointwise uncertainties were not supplied',
}
with open(root / 'result.json', 'w') as fp:
    json.dump(result, fp, indent=2)
    fp.write('\n')

print(json.dumps(result, indent=2))
