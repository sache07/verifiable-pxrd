#!/usr/bin/env python3
"""Compare constrained, physically valid peak-profile variants."""
from pathlib import Path
import sys

sys.path.insert(0, "<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages")
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
base = root / "final.gpx"
for w in (1.0, 10.0, 25.0, 50.0, 100.0):
    out = root / f"trial_w{int(w)}.gpx"
    p = G2sc.G2Project(str(base), newgpx=str(out))
    h = p.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    for key, val in (("U", 0.0), ("V", 0.0), ("W", w), ("X", 10.0), ("Y", 0.0)):
        inst[key][1] = val
        inst[key][2] = key in ("X", "Y")
    p.data["Controls"]["data"]["max cyc"] = 20
    p.do_refinements([{}])
    rv = p.data["Covariance"]["data"].get("Rvals", {})
    print("RESULT", w, rv.get("Rwp"), rv.get("GOF"), inst["X"][1], inst["Y"][1], rv.get("converged"), rv.get("Max shft/sig"))
