#!/usr/bin/env python3
"""Create and refine the final GSAS-II model for the supplied PXRD pattern."""

from pathlib import Path
import csv
import json
import math
import shutil
import sys

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
G2_SITE = Path("<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages")
sys.path.insert(0, str(G2_SITE))
from GSASII import GSASIIscriptable as G2sc  # noqa: E402


def make_inputs():
    p = pd.read_csv(ROOT / "inputs/pattern.csv")
    x = p["two_theta_deg"].to_numpy(float)
    y = p["intensity"].to_numpy(float)
    # GSAS-II's xye reader expects sigma(I), not weight. Counts are Poisson-limited;
    # protect against a zero count while preserving the supplied, unprocessed data.
    sig = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(ROOT / "pattern.xye", np.column_stack([x, y, sig]), fmt="%.8f %.8f %.8f")

    (ROOT / "cu_ka.instprm").write_text(
        "#GSAS-II instrument parameter file\n"
        "Bank:1.0\n"
        "Type:PXC\n"
        # Metadata specifies that the wavelength actually intended for use was
        # K-alpha1. The source K-alpha2 wavelength/ratio is retained in the
        # report, but is not included in the monochromated profile calculation.
        "Lam:1.540598\n"
        "Zero:0.0\n"
        "Polariz.:0.7\n"
        "U:500.0\n"
        "V:0.0\n"
        "W:100.0\n"
        "X:10.0\n"
        "Y:0.0\n"
        "Z:0.0\n"
        "SH/L:0.02\n"
        "Azimuth:0.0\n"
        "Diff-type:Bragg-Brentano\n"
        "InstrName:PIXcel1D-Medipix3, Cu K-alpha\n"
    )


def run_refinement():
    make_inputs()
    gpx_path = ROOT / "final.gpx"
    if gpx_path.exists():
        gpx_path.unlink()
    gpx = G2sc.G2Project(newgpx=str(gpx_path))
    hist = gpx.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "cu_ka.instprm"), fmthint="xye"
    )
    phase = gpx.add_phase(
        str(ROOT / "mnwo4_start.cif"), phasename="MnWO4", histograms=[hist]
    )
    # The overall histogram and phase scales are mathematically redundant.
    # Keep the former fixed and refine the phase scale only.
    hist.data["Sample Parameters"]["Scale"][1] = False
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 16,
        },
    })
    phase.set_HAP_refinements({"Scale": True})
    gpx.data["Controls"]["data"]["max cyc"] = 12
    gpx.data["Controls"]["data"]["min dM/M"] = 0.0001
    gpx.save()

    # Stage parameters to preserve stability and reduce correlations.
    gpx.do_refinements([{}])
    phase.set_refinements({"Cell": True})
    gpx.do_refinements([{}])
    hist.set_refinements({"Instrument Parameters": ["W"]})
    gpx.do_refinements([{}])
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    gpx.do_refinements([{}])
    hist.set_refinements({"Instrument Parameters": ["U", "V", "X"]})
    gpx.do_refinements([{}])
    # Refine coordinates only after lattice/profile convergence. Occupancies
    # and displacement factors remain fixed to avoid powder-data overfitting.
    phase.set_refinements({"Atoms": {"all": "X"}})
    gpx.do_refinements([{}])
    gpx.save()
    return gpx, hist, phase


def export_results(gpx, hist, phase):
    phase.export_CIF(str(ROOT / "phase_1_MnWO4.cif"))

    x = np.asarray(hist.getdata("x"), float)
    yo = np.asarray(hist.getdata("yobs"), float)
    yc = np.asarray(hist.getdata("ycalc"), float)
    bkg = np.asarray(hist.getdata("background"), float)
    diff = yo - yc
    pd.DataFrame({
        "two_theta_deg": x,
        "observed_intensity": yo,
        "calculated_intensity": yc,
        "difference_intensity": diff,
        "background_intensity": bkg,
    }).to_csv(ROOT / "fit.csv", index=False, float_format="%.8g")

    hstats = hist.data["data"][0]
    cov = gpx.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    cell = phase.get_cell()
    stats = {
        "Rwp_percent": float(hstats.get("wR", rvals.get("Rwp", float("nan")))),
        "Rp_percent": float(hstats.get("R", rvals.get("Rp", float("nan")))),
        "goodness_of_fit": float(rvals.get("GOF", cov.get("Rvals", {}).get("GOF", float("nan")))),
        "weighted_chi_squared": float(rvals.get("chisq", float("nan"))),
        "number_of_observations": int(rvals.get("Nobs", len(x))),
        "number_of_variables": int(rvals.get("Nvars", len(cov.get("varyList", [])))),
    }
    # Replace unavailable values with JSON null.
    stats = {k: (None if isinstance(v, float) and not math.isfinite(v) else v) for k, v in stats.items()}
    result = {
        "phases": [{
            "name": "MnWO4",
            "formula": "MnWO4",
            "space_group": "P 2/c",
            "cif_path": "phase_1_MnWO4.cif",
            "weight_fraction": 1.0,
            "weight_fraction_percent": 100.0,
            "weight_fraction_basis": "normalized over modeled crystalline phases",
            "cell_angstrom_degrees": {
                "a": float(cell["length_a"]),
                "b": float(cell["length_b"]),
                "c": float(cell["length_c"]),
                "alpha": float(cell["angle_alpha"]),
                "beta": float(cell["angle_beta"]),
                "gamma": float(cell["angle_gamma"]),
                "volume_angstrom3": float(cell["volume"]),
            },
        }],
        "fit_statistics": stats,
        "profile_path": "fit.csv",
        "gsasii_project_path": "final.gpx",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    print("Histogram stats:", hstats)
    print("Rvals:", rvals)
    print("Cell:", cell)
    print("Instrument:", hist.data["Instrument Parameters"][0])
    print("HAP:", phase.data["Histograms"][hist.name])
    print("Atoms:")
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.refinement_flags)


if __name__ == "__main__":
    project, powder, mnwo4 = run_refinement()
    export_results(project, powder, mnwo4)
