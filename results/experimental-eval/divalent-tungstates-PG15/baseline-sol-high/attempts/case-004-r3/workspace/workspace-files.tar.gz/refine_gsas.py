from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
def status(project, label):
    hist = project.histogram(0)
    print(f"{label}: wR={hist.get_wR()}")
    print("cells", {p.name: p.get_cell() for p in project.phases()})
    print("inst", {k: v for k, v in hist.InstrumentParameters.items()
                   if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")})


def main():
    variant = sys.argv[1] if len(sys.argv) > 1 else "loopstra"
    trial = len(sys.argv) > 1
    gpx = ROOT / (f"trial_{variant}.gpx" if trial else "final.gpx")
    wo3_source = (
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/2/10/62/2106293.cif" if variant == "triclinic" else
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/2/31/10/2311041.cif" if variant == "loopstra" else
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/1/52/89/1528915.cif"
    )
    suffix = f"_{variant}_trial" if trial else ""
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"),
        fmthint="Topas xye")
    cowo4 = project.add_phase(
        str(ROOT / "CoWO4_start.cif"), phasename="CoWO4_wolframite",
        histograms=[hist])
    wo3 = project.add_phase(wo3_source,
        phasename=("WO3_triclinic" if variant == "triclinic" else "WO3_monoclinic"),
        histograms=[hist])

    hist.set_refinements({
        "Limits": {"low": 10.0, "high": 100.0},
        "Background": {"type": "chebyschev-1", "no. coeffs": 12,
                       "refine": True},
    })
    project.refine()
    status(project, "scale/background")

    # Hold CoWO4's phase scale at 1 as the reference and refine the WO3
    # phase scale; the histogram scale then supplies the arbitrary global
    # intensity normalization without a singular scale combination.
    wo3.set_HAP_refinements({"Scale": True})
    project.refine()
    status(project, "phase fraction")

    cowo4.set_refinements({"Cell": True})
    wo3.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    status(project, "cell/zero")

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    project.refine()
    status(project, "profile")

    # Additional cycles allow the cell, profile and phase fraction parameters
    # to settle after the large profile-width correction.
    for _ in range(3):
        project.refine()
    status(project, "final")

    project.save(str(gpx))
    cowo4.export_CIF(str(ROOT / f"CoWO4{suffix}.cif"), quickmode=True)
    wo3.export_CIF(str(ROOT / f"WO3{suffix}.cif"), quickmode=True)

    # Reload the saved project so exported arrays demonstrably come from it.
    final_project = G2sc.G2Project(str(gpx))
    final_hist = final_project.histogram(0)
    cols = [final_hist.getdata(k) for k in
            ("X", "Yobs", "Ycalc", "Background", "Residual", "Yweight")]
    # GSAS-II evaluates one point beyond the nominal upper limit; select the
    # exact calculated range rather than reconstructing its index convention.
    use = cols[2] != 0
    out = np.column_stack([col[use] for col in cols])
    np.savetxt(
        ROOT / f"fit{suffix}.csv", out, delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference,weight",
        comments="", fmt="%.8g")

    print("FINAL_W_R_PERCENT", final_hist.get_wR())
    print("FINAL_CELLS", {p.name: p.get_cell() for p in final_project.phases()})
    print("FINAL_MASS_FRACTIONS", final_hist.ComputeMassFracs())
    print("FINAL_HAPS", {p.name: p.data["Histograms"] for p in final_project.phases()})


if __name__ == "__main__":
    main()
