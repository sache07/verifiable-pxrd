from pathlib import Path
import csv
import json
import math

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def main():
    project = G2sc.G2Project(str(ROOT / 'test_x.gpx'))
    project.save(str(ROOT / 'final.gpx'))
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    residuals = hist.residuals

    # Export exactly the phase models stored in the submitted project.
    phase_records = []
    phase_meta = {
        'WO3': ('WO3.cif', 'monoclinic tungsten(VI) oxide', 'WO3'),
        'BaCO3': ('BaCO3.cif', 'orthorhombic barium carbonate (witherite)', 'BaCO3'),
    }
    for phase in project.phases():
        cif_name, description, formula = phase_meta[phase.name]
        phase.export_CIF(str(ROOT / cif_name))
        frac, esd = fractions[phase.name]
        phase_records.append({
            'name': phase.name,
            'description': description,
            'formula': formula,
            'space_group': phase.data['General']['SGData']['SpGrp'].strip(),
            'cif_path': cif_name,
            'weight_fraction': frac,
            'weight_fraction_formal_esd': esd,
            'estimated_model_systematic_uncertainty': 0.02,
            'unit_cell': phase.get_cell(),
            'r_f_percent': residuals[f'{phase.id}:0:Rf'],
            'r_f_squared_percent': residuals[f'{phase.id}:0:Rf^2'],
        })

    # GSAS-II arrays are x, observed, weight, calculated total, background,
    # observed-calculated. Write only the range actually used in refinement.
    x, obs, weight, calc, background, diff = hist.data['data'][1]
    low, high = hist.data['Limits'][1]
    mask = (x >= low) & (x <= high)
    with open(ROOT / 'fit.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['two_theta_deg', 'observed_counts', 'calculated_counts',
                         'difference_counts', 'background_counts'])
        writer.writerows(zip(x[mask], obs[mask], calc[mask], diff[mask], background[mask]))

    rwp = float(residuals['wR'])
    rexp = float(residuals['wRmin'])
    gof = rwp / rexp
    result = {
        'phases': phase_records,
        'fractions_normalized_over_modeled_crystalline_phases': True,
        'fit_statistics': {
            'r_wp_percent': rwp,
            'r_p_percent': float(residuals['R']),
            'r_exp_percent': rexp,
            'goodness_of_fit': gof,
            'reduced_chi_squared': gof * gof,
            'background_subtracted_r_wp_percent': float(residuals['wRb']),
            'background_subtracted_r_p_percent': float(residuals['Rb']),
            'two_theta_range_deg': [float(low), float(high)],
            'number_of_profile_points': int(mask.sum()),
        },
        'measurement_model': {
            'radiation': 'Cu K-alpha doublet',
            'wavelength_kalpha1_angstrom': 1.540598,
            'wavelength_kalpha2_angstrom': 1.544426,
            'kalpha2_to_kalpha1_ratio': 0.5,
            'point_weights': 'Poisson estimate, sigma=sqrt(max(counts,1)); input uncertainties absent',
        },
        'project_path': 'final.gpx',
        'profile_path': 'fit.csv',
    }
    with open(ROOT / 'result.json', 'w') as f:
        json.dump(result, f, indent=2)
        f.write('\n')

    print(json.dumps(result, indent=2))
    print('sample_shift_micrometers', hist.data['Sample Parameters']['Shift'])
    print('instrument', {k: hist.data['Instrument Parameters'][0][k]
                         for k in ('W', 'X', 'SH/L')})


if __name__ == '__main__':
    main()
