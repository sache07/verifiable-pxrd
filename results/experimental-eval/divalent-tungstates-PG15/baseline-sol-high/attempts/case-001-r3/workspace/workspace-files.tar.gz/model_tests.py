from pathlib import Path
import argparse
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent


def report(p):
    h = p.histogram(0)
    print('FINAL', h.residuals)
    print('MASS', h.ComputeMassFracs())
    print('INST', {k: h.data['Instrument Parameters'][0][k] for k in ('U','V','W','X','Y')})
    for ph in p.phases():
        hap = ph.data['Histograms'][h.name]
        print('PHASE', ph.name, 'PO', hap['Pref.Ori.'], 'SIZE', hap['Size'][:3], 'STRAIN', hap['Mustrain'][:3])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('tag')
    ap.add_argument('kind', choices=['x', 'u', 'size', 'po'])
    ap.add_argument('--phase')
    ap.add_argument('--axis', nargs=3, type=int)
    ns = ap.parse_args()
    out = ROOT / f'test_{ns.tag}.gpx'
    p = G2sc.G2Project(str(ROOT / 'model_two_shift.gpx'))
    p.save(str(out))
    h = p.histogram(0)
    if ns.kind == 'x':
        h.set_refinements({'Instrument Parameters': ['X']})
    elif ns.kind == 'u':
        h.set_refinements({'Instrument Parameters': ['U']})
    elif ns.kind == 'size':
        for ph in p.phases():
            ph.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True, 'value': 1.0}})
    elif ns.kind == 'po':
        ph = p.phase(ns.phase)
        po = ph.data['Histograms'][h.name]['Pref.Ori.']
        po[3] = ns.axis
        ph.set_HAP_refinements({'Pref.Ori.': True})
    p.do_refinements([{}, {}])
    p.save(str(out))
    report(p)


if __name__ == '__main__':
    main()
