from pathlib import Path
import json
import shutil
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
PHASES = {
    'WO3': COD / '1/52/89/1528915.cif',
    'BaCO3': COD / '9/01/09/9010928.cif',
}


def make_xye():
    arr = np.loadtxt(ROOT / 'inputs/pattern.csv', delimiter=',', skiprows=1)
    # GSAS-II expects sigma in the third column. Poisson counting statistics
    # are the only defensible estimate where pointwise uncertainties are absent.
    out = np.column_stack((arr[:, 0], arr[:, 1], np.sqrt(np.maximum(arr[:, 1], 1.0))))
    np.savetxt(ROOT / 'pattern.xye', out, fmt=['%.8f', '%.8f', '%.8f'])


def show(proj, tag):
    hist = proj.histogram(0)
    print('\n', tag, hist.residuals)
    inst = hist.data['Instrument Parameters'][0]
    print('inst', {k: inst[k] for k in ('Zero','U','V','W','X','Y','SH/L')})
    for ph in proj.phases():
        h = ph.data['Histograms'][hist.name]
        print(ph.name, ph.get_cell(), 'scale', h['Scale'], 'size', h['Size'], 'mustrain', h['Mustrain'][:4])


def main():
    make_xye()
    proj = G2sc.G2Project(newgpx=str(ROOT / 'working.gpx'))
    hist = proj.add_powder_histogram(str(ROOT / 'pattern.xye'), str(ROOT / 'instrument.instprm'), fmthint='xye')
    phases = []
    for name, src in PHASES.items():
        phases.append(proj.add_phase(str(src), phasename=name, histograms=[hist], fmthint='CIF'))

    hist.set_refinements({
        'Limits': [10.0, 100.0],
        'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True},
    })
    # Keep phase coordinate models fixed at their literature values. Refine
    # pattern scale, unit cells and line broadening in a stable sequence.
    for ph in phases:
        ph.set_HAP_refinements({'Scale': True})

    proj.save()
    proj.do_refinements([{}])
    show(proj, 'scale/background')

    for ph in phases:
        ph.set_refinements({'Cell': True})
    proj.do_refinements([{}])
    show(proj, 'cells')

    hist.set_refinements({'Instrument Parameters': ['Zero']})
    proj.do_refinements([{}])
    show(proj, 'zero')

    hist.set_refinements({'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']})
    proj.do_refinements([{}])
    show(proj, 'profile')

    for ph in phases:
        ph.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
    proj.do_refinements([{}])
    show(proj, 'mustrain')

    proj.save(str(ROOT / 'working.gpx'))


if __name__ == '__main__':
    main()
