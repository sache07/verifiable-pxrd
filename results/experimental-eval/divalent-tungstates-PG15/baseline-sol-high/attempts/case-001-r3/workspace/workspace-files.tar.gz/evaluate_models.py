from pathlib import Path
import argparse
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
BASE_PHASES = [
    ('WO3', COD / '1/52/89/1528915.cif'),
    ('BaCO3', COD / '9/01/09/9010928.cif'),
]


def make_xye():
    arr = np.loadtxt(ROOT / 'inputs/pattern.csv', delimiter=',', skiprows=1)
    out = np.column_stack((arr[:, 0], arr[:, 1], np.sqrt(np.maximum(arr[:, 1], 1.0))))
    np.savetxt(ROOT / 'pattern.xye', out, fmt=['%.8f', '%.8f', '%.8f'])


def summary(proj, tag):
    h = proj.histogram(0)
    print('\nSUMMARY', tag)
    print('residuals', h.residuals)
    print('massfracs', h.ComputeMassFracs())
    print('sample', {k: h.data['Sample Parameters'][k] for k in ('Scale', 'Shift', 'Transparency')})
    inst = h.data['Instrument Parameters'][0]
    print('inst', {k: inst[k] for k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'SH/L')})
    for ph in proj.phases():
        hap = ph.data['Histograms'][h.name]
        print(ph.name, ph.get_cell(), 'scale', hap['Scale'], 'size', hap['Size'][:3], 'mustrain', hap['Mustrain'][:3])


def build(tag, add_bawo4=False, use_shift=False):
    make_xye()
    gpx = ROOT / f'model_{tag}.gpx'
    proj = G2sc.G2Project(newgpx=str(gpx))
    # More cycles are needed after adding each independent class of variables.
    proj.data['Controls']['data']['max cyc'] = 12
    hist = proj.add_powder_histogram(str(ROOT / 'pattern.xye'), str(ROOT / 'instrument.instprm'), fmthint='xye')
    phases_in = list(BASE_PHASES)
    if add_bawo4:
        phases_in.append(('BaWO4', COD / '1/52/72/1527204.cif'))
    phases = [proj.add_phase(str(src), phasename=name, histograms=[hist], fmthint='CIF')
              for name, src in phases_in]

    # Remove the otherwise exact scale degeneracy between the histogram and
    # phase scale factors.
    hist.data['Sample Parameters']['Scale'] = [1.0, False]
    inst = hist.data['Instrument Parameters'][0]
    # Start from a broad but well-behaved uncalibrated laboratory profile.
    for key, value in [('U', 0.0), ('V', 0.0), ('W', 100.0), ('X', 0.0), ('Y', 0.0)]:
        inst[key][1] = value
        inst[key][2] = False
    hist.set_refinements({
        'Limits': [10.0, 100.0],
        'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True},
    })
    for ph in phases:
        ph.set_HAP_refinements({'Scale': True})
    proj.save()
    proj.do_refinements([{}])

    for ph in phases:
        ph.set_refinements({'Cell': True})
    proj.do_refinements([{}])

    if use_shift:
        hist.set_refinements({'Sample Parameters': ['Shift']})
        proj.do_refinements([{}])

    # One global Gaussian width is estimable without a calibrated profile.
    hist.set_refinements({'Instrument Parameters': ['W']})
    proj.do_refinements([{}])

    # Phase-dependent microstrain captures the visibly different broadening.
    for ph in phases:
        ph.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}})
    proj.do_refinements([{}])

    # A final pass after all variables have equilibrated.
    proj.do_refinements([{}])
    proj.save(str(gpx))
    summary(proj, tag)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('tag')
    ap.add_argument('--bawo4', action='store_true')
    ap.add_argument('--shift', action='store_true')
    ns = ap.parse_args()
    build(ns.tag, ns.bawo4, ns.shift)
