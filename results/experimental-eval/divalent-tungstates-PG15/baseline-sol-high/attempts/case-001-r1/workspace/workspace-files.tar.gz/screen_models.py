from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

np.seterr(under='ignore')

ROOT = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
OUT = Path('.tmp/screen2')
OUT.mkdir(parents=True, exist_ok=True)


def cif(cod_id):
    matches = list(ROOT.rglob(f'{cod_id}.cif'))
    if len(matches) != 1:
        raise RuntimeError((cod_id, matches))
    return str(matches[0])


models = {
    'wo3_p21m': [('WO3_P21m', '1010618')],
    'wo3_p21c': [('WO3_P21c', '1528915')],
    'wo3_p21n': [('WO3_P21n', '2311041')],
    'wo3_p1': [('WO3_P-1', '2106293')],
    'wo3_pnma': [('WO3_Pnma', '2107312')],
    'wo3_p21m_baco3': [('WO3_P21m', '1010618'), ('BaCO3', '9010928')],
    'wo3_p21c_baco3': [('WO3_P21c', '1528915'), ('BaCO3', '9010928')],
    'wo3_p21n_baco3': [('WO3_P21n', '2311041'), ('BaCO3', '9010928')],
    'wo3_p21m_baco3_bawo4': [('WO3_P21m', '1010618'), ('BaCO3', '9010928'), ('BaWO4', '1527204')],
}

summary = {}
for label, entries in models.items():
    print('\n' + '=' * 72 + '\nMODEL', label, flush=True)
    gpx = OUT / f'{label}.gpx'
    proj = G2sc.G2Project(newgpx=str(gpx))
    hist = proj.add_powder_histogram('inputs/pattern.csv', 'instrument.instprm')
    hist.Limits('lower', 10.0)
    hist.Limits('upper', 90.0)
    # The CSV importer defaults the overall sample scale to refinable. Keep
    # that fixed so phase scales are identifiable.
    hist.SampleParameters['Scale'][1] = False
    phases = []
    for name, cod_id in entries:
        phases.append(proj.add_phase(cif(cod_id), phasename=name, histograms=[hist]))
    proj['Controls']['data']['max cyc'] = 15
    try:
        steps = [
            {'set': {'Background': {'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 12},
                      'Scale': True}},
            {'set': {'Instrument Parameters': ['Zero']}},
            {'set': {'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']}},
        ]
        for i, step in enumerate(steps):
            np.seterr(under='ignore')
            proj.do_refinements([step])
            print('STEP', i, hist.residuals, flush=True)
        proj.save()
        try:
            mass = hist.ComputeMassFracs()
        except Exception as exc:
            mass = {'error': repr(exc)}
        summary[label] = {
            'residuals': hist.residuals,
            'mass_fractions': mass,
            'cells': {p.name: p.get_cell() for p in phases},
            'scales': {p.name: p.HAPvalue('Scale') for p in phases},
            'instrument': {k: v[1] for k, v in hist.InstrumentParameters.items()
                           if k in ['Zero', 'U', 'V', 'W', 'X', 'Y']},
        }
    except Exception as exc:
        import traceback
        traceback.print_exc()
        summary[label] = {'error': repr(exc), 'residuals': hist.residuals}
        proj.save()
    print('SUMMARY', json.dumps(summary[label], indent=2), flush=True)

(OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
