from pathlib import Path
import csv
import json
import numpy as np

np.seterr(under='ignore')

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cod_cif(cod_id):
    paths = list(COD.rglob(f'{cod_id}.cif'))
    if len(paths) != 1:
        raise RuntimeError(f'Expected one CIF for COD {cod_id}, found {paths}')
    return str(paths[0])


project = G2sc.G2Project(newgpx=str(WORK / 'final.gpx'))
hist = project.add_powder_histogram(
    str(WORK / 'inputs/pattern.csv'), str(WORK / 'instrument.instprm'))
hist.Limits('lower', float(hist.getdata('x').min()))
hist.Limits('upper', float(hist.getdata('x').max()))

# Avoid the otherwise exact correlation between the overall sample scale and
# the individual phase scales.
hist.SampleParameters['Scale'][1] = False

# Broad but physical starting profile for an uncalibrated laboratory pattern.
for key, value in {
    'Zero': 0.20, 'U': 100.0, 'V': 0.0,
    'W': 100.0, 'X': 5.0, 'Y': 0.0,
}.items():
    hist.InstrumentParameters[key][1] = value
    hist.InstrumentParameters[key][2] = False

wo3 = project.add_phase(
    cod_cif('1528915'), phasename='WO3_monoclinic', histograms=[hist])
baco3 = project.add_phase(
    cod_cif('9010928'), phasename='BaCO3_witherite', histograms=[hist])

project['Controls']['data']['max cyc'] = 12


def refine(settings, phase='all'):
    np.seterr(under='ignore')
    project.do_refinements([settings], phase=phase)


# Scales/background, positions and cells, followed by a conservative profile
# model. Atomic coordinates are held at the literature values because this
# powder pattern does not independently constrain them.
refine({'set': {
    'Background': {'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 12},
    'Scale': True,
}})
refine({'set': {'Instrument Parameters': ['Zero']}})
hist.clear_refinements({'Instrument Parameters': ['Zero']})
refine({'set': {'Cell': True}}, wo3)
wo3.clear_refinements({'Cell': True})
refine({'set': {'Cell': True}}, baco3)
baco3.clear_refinements({'Cell': True})
refine({'set': {'Instrument Parameters': ['W']}})
refine({'set': {'Instrument Parameters': ['X']}})

# One second position/cell pass removes remaining covariance from the starting
# cells, then U/W/X and all scale/background terms are jointly converged.
hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'Y']})
refine({'set': {'Instrument Parameters': ['Zero']}})
hist.clear_refinements({'Instrument Parameters': ['Zero']})
refine({'set': {'Cell': True}}, wo3)
wo3.clear_refinements({'Cell': True})
refine({'set': {'Cell': True}}, baco3)
baco3.clear_refinements({'Cell': True})
refine({'set': {'Instrument Parameters': ['U', 'W', 'X']}})
refine({})
project.save()

mass_fracs = hist.ComputeMassFracs()
res = hist.residuals
cov_r = project.data['Covariance']['data']['Rvals']

phase_dir = WORK / 'phases'
phase_dir.mkdir(exist_ok=True)
wo3_path = phase_dir / 'wo3_monoclinic.cif'
baco3_path = phase_dir / 'baco3_witherite.cif'
wo3.export_CIF(str(wo3_path))
baco3.export_CIF(str(baco3_path))

x = np.asarray(hist.getdata('x'), dtype=float)
yobs = np.asarray(hist.getdata('yobs'), dtype=float)
ycalc = np.asarray(hist.getdata('ycalc'), dtype=float)
ybkg = np.asarray(hist.getdata('background'), dtype=float)
ydiff = yobs - ycalc
with (WORK / 'fit.csv').open('w', newline='') as stream:
    writer = csv.writer(stream)
    writer.writerow([
        'two_theta_deg', 'observed_intensity', 'calculated_intensity',
        'difference_observed_minus_calculated', 'background_intensity'])
    writer.writerows(zip(x, yobs, ycalc, ydiff, ybkg))

phases = []
for phase, formula, sg, cod_id, path in [
    (wo3, 'WO3', 'P 1 21/n 1', '1528915', wo3_path),
    (baco3, 'BaCO3', 'P m c n', '9010928', baco3_path),
]:
    value, esd = mass_fracs[phase.name]
    phases.append({
        'name': phase.name,
        'formula': formula,
        'space_group': sg,
        'source_structure': f'COD {cod_id}',
        'cif_path': str(path.relative_to(WORK)),
        'weight_fraction': value,
        'weight_fraction_esd_formal': esd,
        'refined_cell': phase.get_cell(),
    })

result = {
    'phases': phases,
    'weight_fraction_basis': 'normalized over modeled crystalline phases',
    'fit_statistics': {
        'Rwp_percent': res['wR'],
        'Rp_percent': res['R'],
        'Rwp_background_subtracted_percent': res['wRb'],
        'Rp_background_subtracted_percent': res['Rb'],
        'Rexp_percent': res['wRmin'],
        'goodness_of_fit': cov_r['GOF'],
        'chi_square': cov_r['chisq'],
        'n_observations': cov_r['Nobs'],
        'n_variables': cov_r['Nvars'],
        'refinement_converged': bool(cov_r['converged']),
        'two_theta_range_deg': [hist.Limits('lower'), hist.Limits('upper')],
    },
    'project_path': 'final.gpx',
    'profile_path': 'fit.csv',
}
(WORK / 'result.json').write_text(json.dumps(result, indent=2) + '\n')

print(json.dumps(result, indent=2))
