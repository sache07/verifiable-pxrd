#!/usr/bin/env python3
import csv
import json
import os

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.dirname(__file__))
project = G2sc.G2Project(os.path.join(ROOT, "final.gpx"))
hist = project.histogram(0)

# Export the refined structures directly from the submitted project.
cif_names = {
    "WO3_triclinic": "WO3_triclinic.cif",
    "CoWO4_wolframite": "CoWO4_wolframite.cif",
}
for phase in project.phases():
    phase.export_CIF(os.path.join(ROOT, cif_names[phase.name]))

# The calculated array in the project corresponds to the refined 10--100 deg range.
x = hist.getdata("x")
yobs = hist.getdata("yobs")
ycalc = hist.getdata("ycalc")
low, high = hist.data["Limits"][1]
i_begin = int(np.searchsorted(x, low))
i_end = int(np.searchsorted(x, high)) + 1  # GSAS-II includes the boundary-adjacent point
with open(os.path.join(ROOT, "fit.csv"), "w", newline="") as fp:
    writer = csv.writer(fp)
    writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
    for xx, yo, yc in zip(x[i_begin:i_end], yobs[i_begin:i_end], ycalc[i_begin:i_end]):
        writer.writerow([f"{float(xx):.8f}", f"{float(yo):.8f}",
                         f"{float(yc):.8f}", f"{float(yo-yc):.8f}"])

fractions = hist.ComputeMassFracs()
res = hist.residuals
rvals = project.data["Covariance"]["data"]["Rvals"]
phase_info = {
    "WO3_triclinic": ("WO3", "P -1"),
    "CoWO4_wolframite": ("CoWO4", "P 2/c"),
}
result = {
    "phases": [],
    "fraction_basis": "weight fractions normalized over modeled crystalline phases",
    "fit_statistics": {
        "Rwp_percent": float(res["wR"]),
        "Rp_percent": float(res["R"]),
        "Rexp_percent": float(res["wRmin"]),
        "GOF": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_variables": int(rvals["Nvars"]),
        "two_theta_range_deg": [float(low), float(high)],
    },
}
for phase in project.phases():
    value, esd = fractions[phase.name]
    formula, space_group = phase_info[phase.name]
    result["phases"].append({
        "name": phase.name,
        "formula": formula,
        "space_group": space_group,
        "cif_path": cif_names[phase.name],
        "weight_fraction": float(value),
        "weight_fraction_esd": float(esd),
    })

with open(os.path.join(ROOT, "result.json"), "w") as fp:
    json.dump(result, fp, indent=2)
    fp.write("\n")
