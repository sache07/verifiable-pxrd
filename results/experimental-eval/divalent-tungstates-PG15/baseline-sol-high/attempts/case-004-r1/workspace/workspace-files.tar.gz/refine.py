#!/usr/bin/env python3
import csv
import json
import math
import os
import sys

import numpy as np

import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.dirname(__file__))
PATTERN = os.path.join(ROOT, "inputs", "pattern.csv")
XYE = os.path.join(ROOT, "pattern.xye")
INST = os.path.join(ROOT, "instrument.instprm")
WO3_START = os.environ.get(
    "WO3_START",
    "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif",
)
COWO4_START = os.path.join(ROOT, "candidate_cowo4.cif")
GPX = os.path.join(ROOT, os.environ.get("GPX_NAME", "final.gpx"))


def make_xye():
    data = np.genfromtxt(PATTERN, delimiter=",", names=True)
    # Counts are raw; Poisson counting uncertainties are the defensible default.
    sigma = np.sqrt(np.maximum(data["intensity"], 1.0))
    np.savetxt(XYE, np.column_stack((data["two_theta_deg"], data["intensity"], sigma)),
               fmt=("%.8f", "%.8f", "%.8f"))


def show(proj, label):
    h = proj.histogram(0)
    print("\n==", label, "==")
    print("residuals", h.residuals)
    print("instrument", {k: v for k, v in h.InstrumentParameters.items()
                         if k in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"]})
    for p in proj.phases():
        print(p.name, p.get_cell(), p.HAPvalue("Scale", targethistlist=[h]))
    try:
        print("mass fractions", h.ComputeMassFracs())
    except Exception as exc:
        print("mass fraction error", repr(exc))


def main():
    make_xye()
    if os.path.exists(GPX):
        os.unlink(GPX)
    gpx = G2sc.G2Project(newgpx=GPX)
    gpx.data["Controls"]["data"]["max cyc"] = 8
    hist = gpx.add_powder_histogram(XYE, INST, fmthint="xye")
    wo3_name = "WO3_triclinic" if "2106293" in WO3_START else "WO3_monoclinic"
    wo3 = gpx.add_phase(WO3_START, phasename=wo3_name, histograms=[hist], fmthint="CIF")
    cowo4 = gpx.add_phase(COWO4_START, phasename="CoWO4_wolframite", histograms=[hist], fmthint="CIF")
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)

    # Initialize a flexible smooth background and positive phase scales.
    hist.SampleParameters["Scale"][1] = False
    hist.set_refinements({"Background": {"type": "chebyschev-1", "refine": True,
                                           "no. coeffs": 12,
                                           "coeffs": [900.0] + [0.0] * 11}})
    wo3.data["Histograms"][hist.name]["Scale"][0] = 0.5
    cowo4.data["Histograms"][hist.name]["Scale"][0] = 0.3
    for p in [wo3, cowo4]:
        p.set_HAP_refinements({"Scale": True}, [hist])

    gpx.save()
    # Establish background and scales, then cells and profile in conservative stages.
    gpx.do_refinements([{}])
    show(gpx, "background + scales")

    for p in [wo3, cowo4]:
        p.set_refinements({"Cell": True})
    gpx.do_refinements([{}])
    show(gpx, "cells")

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    gpx.do_refinements([{}])
    show(gpx, "instrument profile")

    # Repeat the same final model until parameter shifts stabilize.
    for cycle in range(3):
        gpx.do_refinements([{}])
        show(gpx, f"final stabilization {cycle + 1}")

    gpx.save()


if __name__ == "__main__":
    main()
