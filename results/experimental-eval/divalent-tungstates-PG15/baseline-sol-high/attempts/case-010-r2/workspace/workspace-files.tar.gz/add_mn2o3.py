import json
import os

import numpy as np
from GSASII import GSASIIscriptable as G2sc


gpx = G2sc.G2Project("improved.gpx", newgpx="two_phase.gpx")
hist = gpx.histogram(0)
wo3 = gpx.phase(0)

# Freeze coordinates after the preceding structure refinement while testing a
# chemically plausible residual phase.
for atom in wo3.atoms():
    atom.refinement_flags = " "

mn = gpx.add_phase(
    "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/51/42/1514230.cif",
    phasename="Mn2O3", histograms=[hist], fmthint="CIF")
mn.data["Histograms"][hist.name]["Scale"] = [0.8, True]
mn.data["General"]["Cell"][0] = True

gpx.set_Controls("cycles", 10)
gpx.do_refinements([{}])
print("STEP0", hist.residuals, hist.ComputeMassFracs(), mn.get_cell())
gpx.do_refinements([{}])
print("STEP1", hist.residuals, hist.ComputeMassFracs(), mn.get_cell())
gpx.save()

arr = np.column_stack([hist.getdata(k) for k in
                       ["X", "Yobs", "Ycalc", "Background", "Residual"]])
np.savetxt("two_phase_fit.csv", arr, delimiter=",",
           header="two_theta_deg,observed,calculated,background,difference",
           comments="")
print("FINAL", json.dumps({"residuals": hist.residuals,
                            "mass_fractions": hist.ComputeMassFracs(),
                            "wo3_cell": wo3.get_cell(),
                            "mn2o3_cell": mn.get_cell()}, default=float))
