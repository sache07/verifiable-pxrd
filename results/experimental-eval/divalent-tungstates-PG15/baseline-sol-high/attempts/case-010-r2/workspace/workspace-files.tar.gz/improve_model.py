import json
import os

import numpy as np
from GSASII import GSASIIscriptable as G2sc


gpx = G2sc.G2Project("screen_wo3_2311041.gpx", newgpx="improved.gpx")
hist = gpx.histogram(0)
phase = gpx.phase(0)
hist.data["Sample Parameters"]["DisplaceX"][1] = False
gpx.set_Controls("cycles", 12)

recipes = [
    {"set": {"Sample Parameters": ["Shift"]}},
    {"set": {"Cell": True}},
    {},
    {"set": {"Atoms": {"W1": "X", "W2": "X"}}},
    {},
    {"set": {"Atoms": {"all": "X"}}},
    {},
]

for i, recipe in enumerate(recipes):
    gpx.do_refinements([recipe])
    print("STEP", i, hist.residuals, phase.get_cell(),
          "SHIFT", hist.SampleParameters["Shift"])

gpx.save()
arr = np.column_stack([hist.getdata(k) for k in
                       ["X", "Yobs", "Ycalc", "Background", "Residual"]])
np.savetxt("improved_fit.csv", arr, delimiter=",",
           header="two_theta_deg,observed,calculated,background,difference",
           comments="")
print("FINAL", json.dumps({"residuals": hist.residuals,
                            "cell": phase.get_cell(),
                            "shift": hist.SampleParameters["Shift"]}, default=float))
