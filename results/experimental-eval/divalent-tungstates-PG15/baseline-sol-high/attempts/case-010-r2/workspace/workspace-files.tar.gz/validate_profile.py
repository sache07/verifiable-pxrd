from GSASII import GSASIIscriptable as G2sc


gpx = G2sc.G2Project("coord_check.gpx", newgpx="profile_check.gpx")
h = gpx.histogram(0)
ip = h.InstrumentParameters
for key, value in {"U": 0.0, "V": 0.0, "W": 20.0}.items():
    ip[key][1] = value
    ip[key][2] = False
ip["X"][2] = True
ip["Y"][2] = True
gpx.set_Controls("cycles", 12)
gpx.do_refinements([{}])
print("PROFILE", h.residuals, h.ComputeMassFracs(),
      {k: ip[k] for k in ["U", "V", "W", "X", "Y"]})
gpx.save()
