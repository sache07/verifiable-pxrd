import json
import os
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def run(cif, tag):
    out = os.path.abspath(f"screen_{tag}.gpx")
    if os.path.exists(out):
        os.unlink(out)
    gpx = G2sc.G2Project(newgpx=out)
    hist = gpx.add_powder_histogram(
        os.path.abspath("pattern.xye"), os.path.abspath("instrument.instprm"),
        fmthint="xye",
    )
    phase = gpx.add_phase(cif, phasename=tag, histograms=[hist], fmthint="CIF")
    hist.data["Sample Parameters"]["Scale"][0] = 1.0
    hist.data["Sample Parameters"]["Scale"][1] = False
    phase.data["Histograms"][hist.name]["Scale"][0] = 1.0
    gpx.set_Controls("cycles", 8)
    refs = [
        {"set": {"Background": {"type": "chebyschev-1", "refine": True,
                                  "no. coeffs": 12}, "Scale": True}},
        {"set": {"Cell": True}},
        {"set": {"Sample Parameters": ["DisplaceX"]}},
        {"set": {"Instrument Parameters": ["U", "V", "W"]}},
        {"set": {"Instrument Parameters": ["X", "Y"]}},
    ]
    try:
        for i, r in enumerate(refs):
            gpx.do_refinements([r])
            print("STEP", i, hist.residuals, phase.get_cell())
    except Exception as err:
        print("REFINE_ERROR", repr(err))
    gpx.save()
    result = {
        "tag": tag,
        "cif": cif,
        "residuals": hist.residuals,
        "cell": phase.get_cell(),
        "instrument": {k: v for k, v in hist.InstrumentParameters.items()
                       if k in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y"]},
        "sample": {k: v for k, v in hist.SampleParameters.items()
                   if k in ["Scale", "DisplaceX", "DisplaceY"]},
    }
    print("RESULT", json.dumps(result, default=float))


if __name__ == "__main__":
    run(os.path.abspath(sys.argv[1]), sys.argv[2])
