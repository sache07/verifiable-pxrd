from GSASII import GSASIIscriptable as G2sc


source = {
    "O6": (0.714, 0.487, 0.721),
    "O2": (0.225, 0.474, 0.007),
    "W1": (0.028, 0.037, 0.746),
    "O5": (0.716, 0.043, 0.708),
    "O3": (0.998, 0.262, 0.712),
    "O1": (0.206, 0.042, 0.995),
    "W2": (0.534, 0.023, 0.750),
    "O4": (0.519, 0.259, 0.789),
}

gpx = G2sc.G2Project("two_phase.gpx", newgpx="coord_check.gpx")
h = gpx.histogram(0)
p = gpx.phase("wo3_2311041")
for atom in p.atoms():
    atom.coordinates = source[atom.label]
    atom.refinement_flags = " "
gpx.set_Controls("cycles", 10)
gpx.do_refinements([{}])
print("RESET", h.residuals, h.ComputeMassFracs())
for label in ("W1", "W2"):
    p.atom(label).refinement_flags = "X"
gpx.do_refinements([{}])
print("WREF", h.residuals, h.ComputeMassFracs())
for atom in p.atoms():
    print(atom.label, atom.coordinates, atom.refinement_flags)
gpx.save()
