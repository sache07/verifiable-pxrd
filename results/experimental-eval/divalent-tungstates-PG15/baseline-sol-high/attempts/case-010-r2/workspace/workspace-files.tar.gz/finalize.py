import json
import os

import numpy as np
from GSASII import GSASIIscriptable as G2sc


for path in ("final.gpx", "phase_wo3.cif", "phase_mn2o3.cif", "fit.csv"):
    if os.path.exists(path):
        os.unlink(path)

gpx = G2sc.G2Project("profile_check.gpx", newgpx="final.gpx")
gpx.set_Controls("cycles", 12)
gpx.do_refinements([{}])
gpx.save()

hist = gpx.histogram(0)
wo3 = gpx.phase("wo3_2311041")
mn2o3 = gpx.phase("Mn2O3")
wo3.export_CIF("phase_wo3.cif")
mn2o3.export_CIF("phase_mn2o3.cif")

profile = np.column_stack([
    hist.getdata("X"), hist.getdata("Yobs"), hist.getdata("Ycalc"),
    hist.getdata("Background"), hist.getdata("Residual")])
np.savetxt(
    "fit.csv", profile, delimiter=",",
    header="two_theta_deg,observed,calculated,background,difference",
    comments="", fmt="%.8g")

fractions = hist.ComputeMassFracs()
res = hist.residuals
summary = {
    "residuals": res,
    "mass_fractions": fractions,
    "cells": {},
    "sample_shift": hist.SampleParameters["Shift"],
    "instrument_profile": {k: hist.InstrumentParameters[k]
                           for k in ["Lam1", "Lam2", "I(L2)/I(L1)",
                                     "U", "V", "W", "X", "Y"]},
}
for ph in (wo3, mn2o3):
    cell, esd = ph.get_cell_and_esd()
    summary["cells"][ph.name] = {"value": cell, "esd": esd,
                                 "composition": ph.composition,
                                 "density_g_cm3": ph.density}
with open("final_summary.json", "w") as fp:
    json.dump(summary, fp, indent=2)
print(json.dumps(summary, indent=2))
