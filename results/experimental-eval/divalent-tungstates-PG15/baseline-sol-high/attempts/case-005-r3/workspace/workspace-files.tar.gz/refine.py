import json
import os

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.dirname(__file__))
INPUT = os.path.join(ROOT, "inputs", "pattern.csv")
GPX = os.path.join(ROOT, "final.gpx")
XYE = os.path.join(ROOT, "pattern.xye")
INST = os.path.join(ROOT, "instrument.instprm")

WO3_CIF = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif"
CO3O4_CIF = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/58/9005896.cif"


def prepare_inputs():
    data = np.genfromtxt(INPUT, delimiter=",", names=True)
    x = data["two_theta_deg"]
    y = data["intensity"]
    # No uncertainties were supplied. Counting-statistical uncertainties are
    # the least-assumptive choice for unprocessed counts.
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(XYE, np.column_stack((x, y, sigma)), fmt="%.8f %.8g %.8g")
    with open(INST, "w", encoding="ascii") as stream:
        stream.write("#GSAS-II instrument parameter file for Cu Kalpha reflection data\n")
        stream.write("Type:PXC;Bank:1\n")
        stream.write("Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n")
        stream.write("U:2.0;V:-2.0;W:5.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n")


def dump_state(project, label):
    hist = project.histogram(0)
    print("\nSTATE", label)
    print("residuals", hist.residuals)
    print("sample", hist.SampleParameters)
    print("instrument", hist.InstrumentParameters)
    for phase in project.phases():
        print("phase", phase.name)
        print("cell", phase.data["General"]["Cell"])
        print("hap", phase.data["Histograms"])


def main():
    prepare_inputs()
    if os.path.exists(GPX):
        os.remove(GPX)
    project = G2sc.G2Project(newgpx=GPX)
    hist = project.add_powder_histogram(XYE, INST, fmthint="xye")
    wo3 = project.add_phase(WO3_CIF, phasename="WO3_monoclinic", histograms=[hist])
    co3o4 = project.add_phase(CO3O4_CIF, phasename="Co3O4_spinel", histograms=[hist])
    # Avoid the otherwise exact degeneracy between the histogram scale and all
    # phase scales. Use the visible angle-dependent offset as a safe starting
    # value so that the narrow Co3O4 peaks overlap before least squares starts.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-600.0, False]
    wo3.data["Histograms"][hist.name]["Scale"][0] = 1.0
    co3o4.data["Histograms"][hist.name]["Scale"][0] = 0.25
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12},
    })
    wo3.set_HAP_refinements({"Scale": True})
    co3o4.set_HAP_refinements({"Scale": True})
    project.save()
    project.refine()
    dump_state(project, "scale+background")

    # The peak offset decreases with angle, as expected for sample displacement
    # in Bragg-Brentano reflection geometry.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine()
    dump_state(project, "displacement")

    wo3.set_refinements({"Cell": True})
    co3o4.set_refinements({"Cell": True})
    project.refine()
    dump_state(project, "cells")

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]})
    project.refine()
    dump_state(project, "profile")

    # Axial divergence and sample height are strongly correlated here. Keep the
    # fitted asymmetry value, then converge the remaining profile/cell/scale
    # variables without adding unsupported size or microstrain terms.
    hist.InstrumentParameters["SH/L"][2] = False
    project.refine()
    # U/V/W are highly correlated without a calibrated standard. Retain the
    # fitted V value and fix it for the final covariance calculation.
    hist.InstrumentParameters["V"][2] = False
    for _ in range(4):
        project.refine()
    project.save()
    dump_state(project, "final")

    # Derive all deliverables from the saved final project.
    project = G2sc.G2Project(GPX)
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    print("mass fractions", fractions)
    cif_paths = {}
    for phase in project.phases():
        out = os.path.join(ROOT, phase.name + ".cif")
        phase.export_CIF(out)
        cif_paths[phase.name] = os.path.basename(out)

    x, yobs, weight, ycalc, ybkg, ydiff = hist.data["data"][1]
    lo, hi = hist.data["Limits"][1]
    used = (x >= lo) & (x <= hi)
    with open(os.path.join(ROOT, "fit.csv"), "w", encoding="utf-8") as stream:
        stream.write("two_theta_deg,observed,calculated,difference,background\n")
        for row in zip(x[used], yobs[used], ycalc[used], ydiff[used], ybkg[used]):
            stream.write(",".join(f"{float(v):.10g}" for v in row) + "\n")

    residuals = hist.residuals
    fit_stats = {
        "Rwp_percent": float(residuals["wR"]),
        "Rp_percent": float(residuals["R"]),
        "Rwp_background_percent": float(residuals["wRb"]),
        "Rp_background_percent": float(residuals["Rb"]),
        "Rexp_percent": float(residuals["wRmin"]),
        "goodness_of_fit": float(residuals["wR"] / residuals["wRmin"]),
        "two_theta_range_deg": [float(x[used][0]), float(x[used][-1])],
        "nominal_refinement_limits_deg": [float(lo), float(hi)],
        "weighting": "Poisson approximation, sigma=sqrt(observed counts)",
    }
    phases = []
    for phase in project.phases():
        frac, su = fractions[phase.name]
        phases.append({
            "name": phase.name,
            "formula": "WO3" if phase.name.startswith("WO3") else "Co3O4",
            "cif_path": cif_paths[phase.name],
            "weight_fraction": float(frac),
            "weight_fraction_esd": float(su),
        })
    result = {
        "phases": phases,
        "normalization": "Modeled crystalline phases sum to 1.0; amorphous/unidentified material is not quantified.",
        "fit_statistics": fit_stats,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    with open(os.path.join(ROOT, "result.json"), "w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
