#!/usr/bin/env python3
"""Build and refine the final GSAS-II model for the supplied PXRD scan."""

from pathlib import Path
import csv
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "inputs" / "pattern.csv"
WORK = ROOT / "gsas_work"
GPX = ROOT / "final.gpx"

COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
SOURCE_CIFS = {
    "WO3": ROOT / "gsas_work/WO3_Loopstra_niggli.cif",
    "Co3O4": COD / "9/00/58/9005896.cif",
}


def prepare_inputs():
    WORK.mkdir(exist_ok=True)
    x, y = np.loadtxt(INPUT, delimiter=",", skiprows=1).T
    # GSAS-II's xye reader expects sigma, while the project stores 1/sigma^2.
    sigma = np.sqrt(np.maximum(y, 1.0))
    with (WORK / "pattern.xye").open("w") as f:
        f.write("# Supplied PXRD pattern\n")
        for xx, yy, ss in zip(x, y, sigma):
            f.write(f"{xx:.8f} {yy:.6f} {ss:.6f}\n")

    with (WORK / "instrument.instprm").open("w") as f:
        f.write("#GSAS-II instrument parameter file for reflection Cu Ka data\n")
        f.write("Type:PXC;Bank:1\n")
        f.write("Lam1:1.540598;Lam2:1.544426;Zero:0.30;Polariz.:0.5;Azimuth:0.0;I(L2)/I(L1):0.5\n")
        # A realistic broad starting profile for the observed laboratory data.
        f.write("U:10.0;V:-5.0;W:25.0;X:0.0;Y:8.0;Z:0.0;SH/L:0.002\n")
    return x, y


def summarize(proj, label):
    hist = proj.histogram(0)
    inst = hist.InstrumentParameters
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print("instrument", {k: v[1] for k, v in inst.items() if k in ('Zero','U','V','W','X','Y','Z','SH/L','I(L2)/I(L1)')})
    print("sample", hist.SampleParameters)
    for phase in proj.phases():
        hap = phase.data['Histograms'][hist.name]
        print(phase.name, phase.get_cell(), "scale", hap['Scale'], "size", hap['Size'][:3], "mustrain", hap['Mustrain'][:3])


def main():
    x, y = prepare_inputs()
    if GPX.exists():
        GPX.unlink()

    proj = G2sc.G2Project(newgpx=str(GPX))
    hist = proj.add_powder_histogram(
        str(WORK / "pattern.xye"), str(WORK / "instrument.instprm"),
        fmthint="xye",
    )
    hist.Limits('lower', float(x[0]))
    hist.Limits('upper', float(x[-1]))

    phases = []
    for name, path in SOURCE_CIFS.items():
        phases.append(proj.add_phase(str(path), phasename=name, histograms=[hist]))

    # Set plausible initial scale values, profile and a flexible smooth background.
    hist.data['Background'][0] = ['chebyschev-1', True, 12] + [float(np.percentile(y, 10))] + [0.0] * 11
    hist.data['Sample Parameters']['Scale'] = [1.0, False]
    for phase, start in zip(phases, (0.7, 0.3)):
        phase.data['Histograms'][hist.name]['Scale'][0] = start

    proj.set_Controls('cycles', 8)
    proj.save()
    summarize(proj, "initial")

    stages = [
        ("scale-background", {'set': {'Background': {'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 12}, 'PhaseFraction': True}}),
        ("zero", {'set': {'Instrument Parameters': ['Zero']}}),
        ("cells", {'set': {'Cell': True}}),
        ("profile", {'set': {'Instrument Parameters': ['W', 'Y']}}),
    ]
    for label, recipe in stages:
        proj.do_refinements([recipe])
        summarize(proj, label)

    # Final cycles with all selected parameters active.
    proj.do_refinements([{}])
    proj.save()
    summarize(proj, "final")

    # Refined structure CIFs exported from this exact saved project.
    cif_names = {'WO3': 'phase_WO3.cif', 'Co3O4': 'phase_Co3O4.cif'}
    for phase in proj.phases():
        cif_path = ROOT / cif_names[phase.name]
        phase.export_CIF(str(cif_path))
        # GSAS-II's quick phase exporter reduces the WO3 formula but not the
        # atom counts; normalize the formula metadata to WO3 with Z=8.
        if phase.name == 'WO3':
            txt = cif_path.read_text()
            txt = txt.replace('_cell_formula_units_Z  4', '_cell_formula_units_Z  8')
            txt = txt.replace('_chemical_formula_sum  "O6 W2"', '_chemical_formula_sum  "O3 W"')
            txt = txt.replace('_chemical_formula_weight  463.69', '_chemical_formula_weight  231.84')
            cif_path.write_text(txt)

    # Combined observed/calculated/difference profile requested by the task.
    xx = np.asarray(hist.getdata('x'))
    yo = np.asarray(hist.getdata('yobs'))
    yc = np.asarray(hist.getdata('ycalc'))
    bg = np.asarray(hist.getdata('background'))
    diff = yo - yc
    with (ROOT / 'fit.csv').open('w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['two_theta_deg', 'observed', 'calculated', 'difference', 'background'])
        w.writerows(zip(xx, yo, yc, diff, bg))

    # GSAS-II computes Hill-Howard mass fractions and propagates the covariance matrix.
    mass_fracs = hist.ComputeMassFracs()
    rwp = float(hist.residuals['wR'])
    rp = float(hist.residuals['R'])
    rexp = float(hist.residuals['wRmin'])
    covariance = proj.data['Covariance']['data']
    result = {
        'phases': [
            {
                'name': p.name,
                'formula': 'WO3' if p.name == 'WO3' else 'Co3O4',
                'cif_path': cif_names[p.name],
                'weight_fraction': mass_fracs[p.name][0],
                'weight_fraction_esd': mass_fracs[p.name][1],
                'space_group': p.data['General']['SGData']['SpGrp'].strip(),
                'refined_cell': p.get_cell(),
            }
            for p in proj.phases()
        ],
        'fit_statistics': {
            'Rwp_percent': rwp,
            'Rp_percent': rp,
            'Rexp_percent': rexp,
            'goodness_of_fit': rwp / rexp,
            'reduced_chi_squared': (rwp / rexp) ** 2,
            'observations': int(len(xx)),
            'refined_variables': int(len(covariance.get('varyList', []))),
        },
        'weight_fraction_basis': 'normalized over modeled crystalline phases',
    }
    with (ROOT / 'result.json').open('w') as f:
        json.dump(result, f, indent=2)
        f.write('\n')


if __name__ == '__main__':
    main()
