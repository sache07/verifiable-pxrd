from pathlib import Path
import json
import sys
import traceback

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat

WORK = Path(__file__).resolve().parent
ROOT = WORK / 'candidates'


def cif(cod_id):
    matches = list(ROOT.glob(f'{cod_id}.cif'))
    if len(matches) != 1:
        raise RuntimeError(f'COD {cod_id}: found {len(matches)} CIFs')
    return str(matches[0])


models = {
    'scheelite': [('PbWO4_scheelite', '9009811')],
    'scheelite_raspite': [('PbWO4_scheelite', '9009811'), ('PbWO4_raspite', '9007617')],
    'scheelite_WO3_mono': [('PbWO4_scheelite', '9009811'), ('WO3_P21m', '1010618')],
    'scheelite_WO3_P21c': [('PbWO4_scheelite', '9009811'), ('WO3_P21c', '1528915')],
    'scheelite_WO3_triclinic': [('PbWO4_scheelite', '9009811'), ('WO3_P-1', '2106293')],
    'scheelite_PbO_litharge': [('PbWO4_scheelite', '9009811'), ('PbO_litharge', '9012700')],
    'scheelite_PbO_massicot': [('PbWO4_scheelite', '9009811'), ('PbO_massicot', '2310433')],
    'scheelite_WO3mono_raspite': [('PbWO4_scheelite', '9009811'), ('WO3_P21m', '1010618'), ('PbWO4_raspite', '9007617')],
    'scheelite_WO3P21c_raspite': [('PbWO4_scheelite', '9009811'), ('WO3_P21c', '1528915'), ('PbWO4_raspite', '9007617')],
    'scheelite_WO3P21c_massicot': [('PbWO4_scheelite', '9009811'), ('WO3_P21c', '1528915'), ('PbO_massicot', '2310433')],
    'scheelite_WO3P21c_raspite_massicot': [('PbWO4_scheelite', '9009811'), ('WO3_P21c', '1528915'), ('PbWO4_raspite', '9007617'), ('PbO_massicot', '2310433')],
}


def run(name, phases):
    out = WORK / f'test6_{name}.gpx'
    proj = G2sc.G2Project(newgpx=str(out))
    hist = proj.add_powder_histogram(str(WORK / 'inputs/pattern.csv'), str(WORK / 'instrument.instprm'), fmthint='comma')
    for phase_name, cod_id in phases:
        phase = proj.add_phase(cif(cod_id), phasename=phase_name, histograms=[hist], fmthint='CIF')
        # Old COD entries frequently omit displacement factors (imported as
        # exactly zero), which is numerically unsafe in GSAS-II. Use a modest,
        # fixed common Uiso; positional parameters remain those of the entry.
        cia = phase.data['General']['AtomPtrs'][3]
        for atom in phase.data['Atoms']:
            atom[cia] = 'I'
            atom[cia + 1] = 0.01
            atom[cia + 2:cia + 8] = [0.0] * 6
        cell = phase.data['General']['Cell']
        if cod_id == '9009811':
            cell[1] *= 0.991
            cell[2] *= 0.991
            cell[3] *= 0.993
        else:
            cell[1:4] = [v * 0.994 for v in cell[1:4]]
        cell[7] = G2lat.calc_V(G2lat.cell2A(cell[1:7]))
    # Start scales at comparable values. GSAS-II will refine them immediately.
    hist.SampleParameters['Scale'][:] = [1.0, False]
    for i, phase in enumerate(proj.phases()):
        phase.data['Histograms'][hist.name]['Scale'][0] = 1.0 if i == 0 else 0.1
    hist.set_refinements({'Limits': [10.05, 99.90],
                          'Background': {'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 10}})
    proj.set_Controls('cycles', 12)
    steps = [
        {'set': {'Scale': True}},
        {'set': {'Instrument Parameters': ['Zero']}},
    ]
    for phase in proj.phases():
        steps.append({'set': {'Cell': True}, 'phases': [phase]})
    steps.append({'set': {'Instrument Parameters': ['U', 'W']}})
    for step in steps:
        proj.do_refinements([step])
    proj.save()
    result = {'model': name, 'residuals': hist.residuals,
              'instrument': {k: v[1] for k, v in hist.InstrumentParameters.items() if k in ['U','V','W','X','Y','Zero']},
              'phases': {}}
    try:
        result['mass_fractions'] = hist.ComputeMassFracs()
    except Exception as err:
        result['mass_fraction_error'] = repr(err)
    for phase in proj.phases():
        hap = phase.data['Histograms'][hist.name]
        result['phases'][phase.name] = {'cell': phase.get_cell(), 'scale': hap['Scale'][0], 'size': hap['Size'][1]}
    return result


selected = sys.argv[1:] or list(models)
all_results = []
for name in selected:
    phases = models[name]
    print(f'\n===== {name} =====', flush=True)
    try:
        result = run(name, phases)
        print(json.dumps(result, indent=2, default=str), flush=True)
        all_results.append(result)
    except Exception as err:
        traceback.print_exc()
        all_results.append({'model': name, 'error': repr(err)})

print('\nSUMMARY')
for result in all_results:
    print(result['model'], result.get('residuals'), result.get('mass_fractions'), result.get('error'))
