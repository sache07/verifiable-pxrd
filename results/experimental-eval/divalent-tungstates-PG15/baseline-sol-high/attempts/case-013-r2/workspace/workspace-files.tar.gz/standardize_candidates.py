from pathlib import Path
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

root = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
out = Path(__file__).resolve().parent / 'candidates'
out.mkdir(exist_ok=True)

for cod_id in ['9009811', '9007617', '1010618', '1528915', '2106293', '9012700', '2310433']:
    source = next(root.rglob(f'{cod_id}.cif'))
    structure = Structure.from_file(source)
    structure = SpacegroupAnalyzer(structure, symprec=1e-3).get_refined_structure()
    target = out / f'{cod_id}.cif'
    CifWriter(structure, symprec=1e-3, refine_struct=True, write_site_properties=False).write_file(target)
    check = Structure.from_file(target)
    print(cod_id, check.composition.reduced_formula, check.get_space_group_info(), check.lattice)
