from pathlib import Path
import csv
import json

from GSASII import GSASIIscriptable as G2sc

WORK = Path(__file__).resolve().parent
source = WORK / 'test6_scheelite_WO3P21c_massicot.gpx'
final_gpx = WORK / 'final.gpx'

project = G2sc.G2Project(gpxfile=str(source), newgpx=str(final_gpx))
hist = project.histogram(0)
x = hist.getdata('x')
hist.set_refinements({'Limits': [float(x[0]), float(x[-1])]})
project.data['Controls']['data']['max cyc'] = 16
project.data['Controls']['data']['min dM/M'] = 1e-5

# Recompute over the complete submitted range and continue until parameter
# changes are negligible. All final refinement flags are inherited from the
# selected three-phase model.
project.do_refinements([{}, {}, {}])
project.save(str(final_gpx))

hist = project.histogram(0)
fractions = hist.ComputeMassFracs()
resid = hist.residuals
rvals = project.data['Covariance']['data']['Rvals']

phase_meta = {
    'PbWO4_scheelite': {
        'display_name': 'PbWO4 (scheelite/stolzite)',
        'formula': 'PbWO4',
        'space_group': 'I 41/a',
        'cif': 'phase_PbWO4_scheelite.cif',
        'reference_cod_id': '9009811',
    },
    'WO3_P21c': {
        'display_name': 'WO3 (monoclinic)',
        'formula': 'WO3',
        'space_group': 'P 21/c',
        'cif': 'phase_WO3_monoclinic.cif',
        'reference_cod_id': '1528915',
    },
    'PbO_massicot': {
        'display_name': 'PbO (massicot)',
        'formula': 'PbO',
        'space_group': 'P b c m',
        'cif': 'phase_PbO_massicot.cif',
        'reference_cod_id': '2310433',
    },
}

phase_results = []
for phase in project.phases():
    meta = phase_meta[phase.name]
    phase.export_CIF(str(WORK / meta['cif']))
    cell, cell_esd = phase.get_cell_and_esd()
    wf, wf_esd = fractions[phase.name]
    phase_results.append({
        'name': meta['display_name'],
        'formula': meta['formula'],
        'space_group': meta['space_group'],
        'cif_path': meta['cif'],
        'reference_cod_id': meta['reference_cod_id'],
        'weight_fraction': wf,
        'weight_fraction_esd_formal': wf_esd,
        'cell': cell,
        'cell_esd_formal': cell_esd,
    })

fit_columns = ['two_theta_deg', 'intensity_observed', 'intensity_calculated',
               'intensity_difference_obs_minus_calc', 'background_calculated']
fit_arrays = [hist.getdata(k) for k in ['x', 'yobs', 'ycalc', 'residual', 'background']]
with (WORK / 'fit.csv').open('w', newline='') as stream:
    writer = csv.writer(stream)
    writer.writerow(fit_columns)
    writer.writerows(zip(*fit_arrays))

fit_stats = {
    'Rwp_percent': float(resid['wR']),
    'Rp_percent': float(resid['R']),
    'R_background_percent': float(resid['Rb']),
    'Rwp_background_percent': float(resid['wRb']),
    'Rexp_percent': float(resid['wRmin']),
    'goodness_of_fit': float(rvals['GOF']),
    'chi_squared': float(rvals['chisq']),
    'number_of_observations': int(rvals['Nobs']),
    'number_of_refined_variables': int(rvals['Nvars']),
    'two_theta_range_deg': [float(x[0]), float(x[-1])],
}

result = {
    'phases': phase_results,
    'weight_fraction_basis': 'Normalized over the three modeled crystalline phases; sums to 1.0.',
    'fit_statistics': fit_stats,
    'project_path': 'final.gpx',
    'profile_path': 'fit.csv',
    'unmodeled_component_note': (
        'Several weak-to-moderate residual Bragg features remain, especially near '
        '25.91 and 30-31 degrees 2theta. Their structure and fraction are not '
        'reliably determined; amorphous content is also unconstrained.'
    ),
}
with (WORK / 'result.json').open('w') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')

wf = {item['formula'] + '_' + item['space_group']: 100 * item['weight_fraction']
      for item in phase_results}
report = f"""# Powder diffraction phase analysis

The supported crystalline model contains three phases (fractions normalized only over these modeled crystalline phases):

- PbWO4, scheelite/stolzite type, I 41/a: **{wf['PbWO4_I 41/a']:.2f} wt%**
- WO3, monoclinic, P 21/c: **{wf['WO3_P 21/c']:.2f} wt%**
- PbO, massicot, P b c m: **{wf['PbO_P b c m']:.2f} wt%**

## Evidence

The dominant scheelite PbWO4 assignment is fixed by its complete strong-line sequence at approximately 27.70, 29.91, 33.06, 45.03, 47.28, 51.49, 55.54, and 56.82 degrees 2theta. Monoclinic WO3 accounts for the diagnostic low-angle group near 23.39, 23.89, and 24.64 degrees and lines near 26.77, 34.43, and 41.91 degrees. Orthorhombic massicot PbO accounts for the residual family near 29.35, 30.62, 38.09, and related higher-angle features. Trial models containing raspite PbWO4, tetragonal litharge PbO, or the older P 21/m WO3 model did not improve the complete multiphase fit; the raspite scale became effectively zero once monoclinic WO3 and massicot were included.

The final GSAS-II fit over {fit_stats['two_theta_range_deg'][0]:.4f}-{fit_stats['two_theta_range_deg'][1]:.4f} degrees gives Rwp = {fit_stats['Rwp_percent']:.2f}%, Rp = {fit_stats['Rp_percent']:.2f}%, Rexp = {fit_stats['Rexp_percent']:.2f}%, and goodness-of-fit = {fit_stats['goodness_of_fit']:.2f}. A 2theta zero offset was refined because no calibrated instrument profile was supplied. Background, phase scales, unit cells, zero, and two profile coefficients were refined; atomic coordinates were held to the reference structures and a common fixed Uiso = 0.01 A^2 was used.

## Remaining uncertainty

Residual Bragg intensity remains, most clearly at about 25.91 degrees and across 30-31 degrees. Chemistry permits a Pb-rich ternary intermediate (for example Pb2WO5), but no available structural candidate gave a defensible Rietveld model, so no CIF or fraction is reported for it. The reported fractions therefore exclude any unidentified crystalline material and any amorphous content. The formal least-squares fraction uncertainties are only about 0.2-0.4 wt%, but they do not include this model uncertainty; the practical uncertainty is several wt%. The comparatively high goodness-of-fit and phase Bragg R factors for the minor phases reinforce that the minor-phase fractions are semiquantitative rather than high-accuracy assay values.
"""
(WORK / 'report.md').write_text(report)

print(json.dumps(result, indent=2))
