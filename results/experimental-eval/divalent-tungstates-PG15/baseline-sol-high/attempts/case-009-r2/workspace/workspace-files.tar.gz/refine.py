from pathlib import Path
import csv
import json
import math
import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
WORK_XYE = ROOT / "pattern.xye"
INST = ROOT / "cu_ka.instprm"
GPX = ROOT / "final.gpx"
SOURCE_CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif")


def make_inputs():
    arr = np.genfromtxt(PATTERN, delimiter=",", names=True)
    x = arr["two_theta_deg"]
    y = arr["intensity"]
    # With no pointwise uncertainties supplied, counting-statistical weights
    # are the least assumptive choice for raw counts.
    sig = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(WORK_XYE, np.column_stack((x, y, sig)), fmt="%.8f %.8f %.8f")
    INST.write_text(
        "#GSAS-II instrument parameter file for lab CuKa data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:2.0;V:-2.0;W:5.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )


def log_state(tag, project):
    h = project.histogram(0)
    p = project.phase(0)
    inst = h.data["Instrument Parameters"][0]
    print("STATE", tag)
    print(" residuals", h.residuals)
    print(" cell", p.get_cell())
    print(" instrument", {k: v[1] for k, v in inst.items() if k in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)"]})


def refine():
    make_inputs()
    gpx = G2sc.G2Project(newgpx=str(GPX), author="OpenAI Codex phase analysis")
    hist = gpx.add_powder_histogram(str(WORK_XYE), str(INST), fmthint="xye")
    phase = gpx.add_phase(str(SOURCE_CIF), phasename="MnWO4", histograms=[hist], fmthint="CIF")
    gpx.set_Controls("cycles", 12)

    # There are two multiplicative scales in a powder histogram. Keep the
    # histogram/sample scale fixed and refine the phase (HAP) scale only.
    hist.data["Sample Parameters"]["Scale"][0] = 1.0
    hist.data["Sample Parameters"]["Scale"][1] = False
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 100.0, "V": -50.0, "W": 50.0}.items():
        inst[key][1] = value

    # Keep the full measured range. Use a flexible smooth polynomial for the
    # sloping instrumental/air-scatter background in the raw counts.
    hist.set_refinements({
        "Limits": [9.90343322, 100.09488522],
        "Background": {"type": "chebyschev-1", "no. coeffs": 15, "refine": True},
    })
    phase.set_HAP_refinements({"Scale": True})
    gpx.do_refinements([{}])
    log_state("background+scale", gpx)

    # Le Bail intensity extraction decouples peak positions/profile from any
    # small intensity mismatch in the literature starting coordinates.
    phase.set_refinements({"Cell": True, "LeBail": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for i in range(2):
        gpx.do_refinements([{}])
        log_state(f"LeBail cell {i+1}", gpx)

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    for i in range(2):
        gpx.do_refinements([{}])
        log_state(f"LeBail profile {i+1}", gpx)

    phase.set_refinements({"LeBail": False})
    gpx.do_refinements([{}])
    log_state("Rietveld", gpx)

    # The heavy-atom y coordinates are well supported by X-ray intensities.
    # Keep oxygen coordinates at their literature values: unconstrained oxygen
    # refinement from this laboratory pattern gives chemically implausible
    # W--O distances, so those parameters are not determined reliably here.
    phase.set_refinements({"Atoms": {"Mn1": "X", "W1": "X"}})
    gpx.do_refinements([{}])
    log_state("coordinates", gpx)

    gpx.save(str(GPX))
    phase.export_CIF(str(ROOT / "phase_MnWO4.cif"))
    export_results(gpx)


def export_results(gpx):
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    d = hist.data["data"][1]
    x, yobs, wt, ycalc, ybkg, ydiff = [np.asarray(a) for a in d[:6]]
    lo, hi = hist.data["Limits"][1]
    mask = (x >= lo) & (x <= hi)
    with (ROOT / "fit.csv").open("w", newline="") as fp:
        w = csv.writer(fp)
        w.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
        for vals in zip(x[mask], yobs[mask], ycalc[mask], ydiff[mask], ybkg[mask]):
            w.writerow([f"{v:.8g}" for v in vals])

    residuals = {k: (float(v) if isinstance(v, (int, float, np.integer, np.floating)) else str(v))
                 for k, v in hist.residuals.items()}
    rwp = residuals.get("wR")
    rexp = residuals.get("wRmin")
    gof = rwp / rexp if rwp is not None and rexp not in (None, 0) else None
    fit_stats = {
        "Rwp_percent": rwp,
        "Rp_percent": residuals.get("R"),
        "Rexp_percent": rexp,
        "GOF": gof,
        "weighted_chi_squared": gof * gof if gof is not None else None,
        "GSASII_residuals": residuals,
        "refined_range_two_theta_deg": [float(lo), float(hi)],
        "weighting": "1/max(observed_counts,1); no pointwise uncertainties supplied",
    }
    cell, cell_esd = phase.get_cell_and_esd()
    result = {
        "phase_count": 1,
        "fraction_basis": "normalized over modeled crystalline phases",
        "phases": [{
            "name": "MnWO4",
            "formula": "MnWO4",
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": "phase_MnWO4.cif",
            "weight_fraction": 1.0,
            "weight_fraction_esd": None,
            "cell": {k: float(v) for k, v in cell.items()},
            "cell_esd": {k: float(v) for k, v in cell_esd.items()},
        }],
        "fit_statistics": fit_stats,
        "refined_specimen_shift_micrometres": float(hist.data["Sample Parameters"]["Shift"][0]),
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    refine()
