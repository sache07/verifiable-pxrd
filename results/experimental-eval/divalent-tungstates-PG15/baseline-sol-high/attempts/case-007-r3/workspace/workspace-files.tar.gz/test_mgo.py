from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

gpx = G2sc.G2Project(gpxfile=str(ROOT / "trial.bak0.gpx"), newgpx=str(ROOT / "model_mgo.gpx"))
hist = gpx.histogram(0)
mgo = gpx.add_phase(
    str(DB / "9/00/04/9000499.cif"),
    phasename="MgO",
    histograms=[hist],
    fmthint="CIF",
)
mgo.data["Histograms"][hist.name]["Scale"][0] = 0.5
mgo.set_HAP_refinements({"Scale": True})
gpx.set_Controls("cycles", 12)
gpx.save()
gpx.do_refinements([{}])
print("SCALE FIT", hist.residuals)
for ph in gpx.phases():
    print(ph.name, ph.data["Histograms"][hist.name]["Scale"], ph.get_cell())

mgo.set_refinements({"Cell": True})
gpx.do_refinements([{}])
print("CELL FIT", hist.residuals)
for ph in gpx.phases():
    print(ph.name, ph.data["Histograms"][hist.name]["Scale"], ph.get_cell())
print("MASS", hist.ComputeMassFracs())
gpx.save()
