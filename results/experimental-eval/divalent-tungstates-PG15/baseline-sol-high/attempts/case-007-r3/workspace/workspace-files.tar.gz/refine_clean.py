from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def set_cell(phase, cell):
    phase.data["General"]["Cell"][1:7] = list(cell)
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def show(project, label):
    hist = project.histogram(0)
    print("\n###", label, hist.residuals)
    for phase in project.phases():
        print(phase.name, phase.get_cell(), phase.data["Histograms"][hist.name]["Scale"])


gpx = G2sc.G2Project(newgpx=str(ROOT / "clean.gpx"))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma",
)
hist.Limits("lower", 10.0)
hist.Limits("upper", 100.0)
hist.data["Sample Parameters"]["Scale"] = [1.0, False]

mgwo4 = gpx.add_phase(str(DB / "9/01/39/9013902.cif"), phasename="MgWO4", histograms=[hist], fmthint="CIF")
wo3 = gpx.add_phase(str(DB / "1/52/89/1528915.cif"), phasename="WO3", histograms=[hist], fmthint="CIF")

# Starting metrics place peaks close enough for derivatives before zero is refined.
set_cell(mgwo4, [4.631, 5.611, 4.881, 90.0, 90.84, 90.0])
set_cell(wo3, [7.212, 7.440, 7.588, 90.0, 90.90, 90.0])

hist.set_refinements({"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 14}})
for phase, scale in [(mgwo4, 30.0), (wo3, 2.0)]:
    phase.data["Histograms"][hist.name]["Scale"][0] = scale
    phase.set_HAP_refinements({"Scale": True})

gpx.set_Controls("cycles", 12)
gpx.save()
gpx.do_refinements([{}])
show(gpx, "background and phase scales")

mgwo4.set_refinements({"Cell": True})
wo3.set_refinements({"Cell": True})
gpx.do_refinements([{}])
show(gpx, "major-phase cells")

hist.set_refinements({"Instrument Parameters": ["W", "X", "Zero"]})
gpx.do_refinements([{}])
show(gpx, "basic profile and zero")

# Repeat the cells now that zero is close to its final value.
gpx.do_refinements([{}])
show(gpx, "cell/profile convergence")

hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "Zero"]})
gpx.do_refinements([{}])
show(gpx, "full Caglioti/pseudo-Voigt profile")

# MgO is weak, so introduce it only after the major phases and zero are stable.
mgo = gpx.add_phase(str(DB / "9/00/04/9000499.cif"), phasename="MgO", histograms=[hist], fmthint="CIF")
mgo.data["Histograms"][hist.name]["Scale"][0] = 0.5
mgo.set_HAP_refinements({"Scale": True})
gpx.do_refinements([{}])
show(gpx, "MgO scale")

# Refine its cubic metric after its scale has stabilized.
mgo.set_refinements({"Cell": True})
gpx.do_refinements([{}])
show(gpx, "MgO cell")

# Axial divergence is justified by the reflection geometry and low-angle asymmetry.
hist.set_refinements({"Instrument Parameters": ["SH/L"]})
gpx.do_refinements([{}])
show(gpx, "axial divergence")

print("MASS FRACTIONS", hist.ComputeMassFracs())
gpx.save()
