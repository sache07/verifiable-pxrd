from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def set_cell(phase, cell):
    phase.data["General"]["Cell"][1:7] = list(cell)
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def status(project, label):
    hist = project.histogram(0)
    print("\nSTATUS", label, hist.residuals)
    inst = hist.data["Instrument Parameters"][0]
    print("INST", {k: v for k, v in inst.items() if k in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]})
    for ph in project.phases():
        hap = ph.data["Histograms"][hist.name]
        print("PHASE", ph.name, ph.get_cell(), "scale", hap["Scale"], "size", hap["Size"], "mustrain", hap["Mustrain"])


gpx = G2sc.G2Project(newgpx=str(ROOT / "trial.gpx"))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma",
)
hist.Limits("lower", 10.0)
hist.Limits("upper", 100.0)

mgwo4 = gpx.add_phase(
    str(DB / "9/01/39/9013902.cif"),
    phasename="MgWO4",
    histograms=[hist],
    fmthint="CIF",
)
wo3 = gpx.add_phase(
    str(DB / "1/52/89/1528915.cif"),
    phasename="WO3",
    histograms=[hist],
    fmthint="CIF",
)
set_cell(mgwo4, [4.631, 5.611, 4.881, 90.0, 90.84, 90.0])
set_cell(wo3, [7.212, 7.440, 7.588, 90.0, 90.90, 90.0])

# Start with a smooth but flexible background and one scale per phase.
hist.set_refinements({"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 14}})
hist.data["Sample Parameters"]["Scale"] = [1.0, False]
mgwo4.data["Histograms"][hist.name]["Scale"][0] = 25.0
wo3.data["Histograms"][hist.name]["Scale"][0] = 2.0
for ph in gpx.phases():
    ph.set_HAP_refinements({"Scale": True})
gpx.set_Controls("cycles", 12)
gpx.save()
gpx.do_refinements([{}])
status(gpx, "background+scales")

# Refine lattice metrics after the phase intensities have stabilized.
for ph in gpx.phases():
    ph.set_refinements({"Cell": True})
gpx.do_refinements([{}])
status(gpx, "cells")

# Instrument peak widths and zero are not calibrated in the metadata.
hist.set_refinements({"Instrument Parameters": ["W", "X", "Zero"]})
gpx.do_refinements([{}])
status(gpx, "basic profile")

hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "Zero", "SH/L"]})
gpx.do_refinements([{}])
status(gpx, "full profile")

# Add isotropic specimen broadening only after instrumental terms settle.
for ph in gpx.phases():
    ph.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 2.0, "refine": True, "LGmix": {"value": 0.5, "refine": False}},
        "Mustrain": {"type": "isotropic", "refine": True, "LGmix": {"value": 0.5, "refine": False}},
    })
gpx.do_refinements([{}])
status(gpx, "sample broadening")
gpx.save()
