import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
gpx = G2sc.G2Project(gpxfile=str(ROOT / "clean.bak0.gpx"), newgpx=str(ROOT / "final.gpx"))
hist = gpx.histogram(0)

# The axial-divergence trial was statistically ill-conditioned and is not used.
hist.clear_refinements({"Instrument Parameters": ["SH/L"]})
hist.data["Instrument Parameters"][0]["SH/L"][1] = 0.002
gpx.set_Controls("cycles", 20)
gpx.save()
gpx.do_refinements([{}])
gpx.save()

phase_files = {
    "MgWO4": "MgWO4.cif",
    "WO3": "WO3.cif",
    "MgO": "MgO.cif",
}
for phase in gpx.phases():
    phase.export_CIF(str(ROOT / phase_files[phase.name]))

data = hist.data["data"][1]
x, yobs, weights, ycalc, ybkg, diff = [np.asarray(a) for a in data[:6]]
lo, hi = hist.data["Limits"][1]
mask = (x >= lo) & (x <= hi)
with (ROOT / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(["two_theta_deg", "observed_intensity", "calculated_intensity", "difference_intensity", "background_intensity"])
    for row in zip(x[mask], yobs[mask], ycalc[mask], diff[mask], ybkg[mask]):
        writer.writerow([f"{float(v):.8g}" for v in row])

mass = hist.ComputeMassFracs()
residuals = hist.residuals
rvals = gpx.data["Covariance"]["data"]["Rvals"]
phase_results = []
for phase in gpx.phases():
    fraction, fraction_esd = mass[phase.name]
    phase_results.append({
        "name": phase.name,
        "formula": phase.name,
        "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
        "cif_path": phase_files[phase.name],
        "weight_fraction": float(fraction),
        "weight_fraction_formal_esd": float(fraction_esd),
        "cell": {key: float(value) for key, value in phase.get_cell().items()},
    })

result = {
    "phases": phase_results,
    "fraction_basis": "normalized over modeled crystalline phases",
    "fit_statistics": {
        "Rwp_percent": float(residuals["wR"]),
        "Rp_percent": float(residuals["R"]),
        "Rexp_percent": float(residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_variables": int(rvals["Nvars"]),
        "two_theta_range_deg": [float(lo), float(hi)],
    },
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
    "weighting": "Poisson counting weights (1/I), because pointwise uncertainties were not supplied",
}
with (ROOT / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps(result, indent=2))
print("residual check max", float(np.max(np.abs(diff[mask] - (yobs[mask] - ycalc[mask])))))
