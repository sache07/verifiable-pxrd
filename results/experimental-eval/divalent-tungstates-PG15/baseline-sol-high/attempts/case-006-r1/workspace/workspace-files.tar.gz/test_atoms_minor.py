from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(ROOT / "atoms_trial.gpx"), newgpx=str(ROOT / "atoms_minor_trial.gpx"))
hist = gpx.histogram(0)
for name, cif in {
    "CuO": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/11/1011194.cif",
    "WO3": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif",
}.items():
    ph = gpx.add_phase(cif, phasename=name, histograms=[hist], fmthint="CIF")
    ph.HAPvalue("Scale", 0.1)

gpx.set_Controls("cycles", 12)
gpx.do_refinements([{"set": {"Scale": True}}])
print("scales only", hist.residuals, hist.ComputeMassFracs())
for ph in gpx.phases(): print(ph.name, ph.HAPvalue("Scale"), ph.get_cell())

# Refine only the WO3 cell; CuO is already statistically absent.
gpx.do_refinements([{"set": {"Cell": True}}], phase="WO3")
print("plus WO3 cell", hist.residuals, hist.ComputeMassFracs())
for ph in gpx.phases(): print(ph.name, ph.HAPvalue("Scale"), ph.get_cell())
gpx.save()
