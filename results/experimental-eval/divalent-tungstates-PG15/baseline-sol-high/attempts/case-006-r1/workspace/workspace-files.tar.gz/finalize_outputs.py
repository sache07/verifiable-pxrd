from pathlib import Path
import csv
from bisect import bisect_left
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
source = ROOT / "shl_repeat.gpx"
final_path = ROOT / "final.gpx"

gpx = G2sc.G2Project(str(source), newgpx=str(final_path))
gpx.save()

phase_files = {
    "CuWO4": ROOT / "phase_cuwo4.cif",
    "WO3": ROOT / "phase_wo3.cif",
}
for name, path in phase_files.items():
    gpx.phase(name).export_CIF(str(path))

hist = gpx.histogram(0)
x = hist.getdata("X")
yobs = hist.getdata("Yobs")
ycalc = hist.getdata("Ycalc")
background = hist.getdata("Background")
residual = hist.getdata("Residual")
low, high = hist.data["Limits"][1]
start = bisect_left(x, low)
# GSAS-II includes the first point at/above the upper limit in its profile
# residual, so mirror its xB:xF indexing exactly.
stop = min(len(x), bisect_left(x, high) + 1)

with (ROOT / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow([
        "two_theta_deg",
        "observed_intensity",
        "calculated_intensity",
        "difference_observed_minus_calculated",
        "background_intensity",
    ])
    for values in zip(
        x[start:stop], yobs[start:stop], ycalc[start:stop],
        residual[start:stop], background[start:stop],
    ):
        writer.writerow([f"{value:.8g}" for value in values])

print("project", final_path)
print("residuals", hist.residuals)
print("mass fractions", hist.ComputeMassFracs())
for phase in gpx.phases():
    print(phase.name, phase.get_cell_and_esd(), phase_files[phase.name])
