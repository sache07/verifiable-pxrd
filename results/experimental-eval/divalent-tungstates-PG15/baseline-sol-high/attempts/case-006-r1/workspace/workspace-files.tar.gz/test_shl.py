from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(ROOT / "wo3_trial.gpx"), newgpx=str(ROOT / "shl_trial.gpx"))
hist = gpx.histogram(0)
gpx.set_Controls("cycles", 15)
for i in range(3):
    gpx.do_refinements([{}])
    print("repeat", i, hist.residuals, hist.ComputeMassFracs(), hist.InstrumentParameters["SH/L"])
gpx.do_refinements([{"set": {"Instrument Parameters": ["SH/L"]}}])
print("SHL", hist.residuals, hist.ComputeMassFracs(), hist.InstrumentParameters["SH/L"])
gpx.save()
