from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
CANDIDATES = {
    "CuO": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/11/1011194.cif",
    "WO3": "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif",
}

gpx = G2sc.G2Project(str(ROOT / "trial.gpx"), newgpx=str(ROOT / "minor_trial.gpx"))
hist = gpx.histogram(0)
cuwo4 = gpx.phase("CuWO4")

# Remove the exact sample/HAP scale degeneracy inherited from the import.
sample_scale = hist.SampleParameters["Scale"][0]
major_scale = cuwo4.HAPvalue("Scale")
hist.SampleParameters["Scale"] = [1.0, False]
cuwo4.HAPvalue("Scale", sample_scale * major_scale)
cuwo4.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])

for name, cif in CANDIDATES.items():
    ph = gpx.add_phase(cif, phasename=name, histograms=[hist], fmthint="CIF")
    ph.HAPvalue("Scale", 0.1)

gpx.set_Controls("cycles", 12)
gpx.do_refinements([{"set": {"Scale": True}}])
print("after scales", hist.residuals)
for ph in gpx.phases():
    print(ph.name, "scale", ph.HAPvalue("Scale"), "cell", ph.get_cell())
print("mass", hist.ComputeMassFracs())

# Let candidate cells settle only if a nonzero scale survives.
gpx.do_refinements([{"set": {"Cell": True}}], phase=["CuO", "WO3"])
print("after cells", hist.residuals)
for ph in gpx.phases():
    print(ph.name, "scale", ph.HAPvalue("Scale"), "cell", ph.get_cell())
print("mass", hist.ComputeMassFracs())
gpx.save()
