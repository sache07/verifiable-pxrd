from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(ROOT / "wo3_trial.gpx"), newgpx=str(ROOT / "adp_trial.gpx"))
hist = gpx.histogram(0)
phase = gpx.phase("CuWO4")
refs = {}
for atom in phase.atoms():
    refs[atom.label] = ("XU" if "X" in atom.refinement_flags else "U")
gpx.set_Controls("cycles", 12)
gpx.do_refinements([{"set": {"Atoms": refs}}], phase="CuWO4")
print(hist.residuals, hist.ComputeMassFracs())
for atom in phase.atoms(): print(atom.label, atom.coordinates, atom.uiso, atom.refinement_flags)
gpx.save()
