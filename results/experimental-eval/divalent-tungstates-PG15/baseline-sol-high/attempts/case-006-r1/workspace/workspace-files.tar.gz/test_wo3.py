from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(ROOT / "atoms_trial.gpx"), newgpx=str(ROOT / "wo3_trial.gpx"))
hist = gpx.histogram(0)
wo3 = gpx.add_phase(
    "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif",
    phasename="WO3", histograms=[hist], fmthint="CIF")
wo3.HAPvalue("Scale", 0.5)
gpx.set_Controls("cycles", 12)
gpx.do_refinements([{"set": {"Scale": True}}])
print("scale", hist.residuals, hist.ComputeMassFracs())
for ph in gpx.phases(): print(ph.name, ph.HAPvalue("Scale"), ph.get_cell())
gpx.do_refinements([{"set": {"Cell": True}}], phase="WO3")
print("cell", hist.residuals, hist.ComputeMassFracs())
for ph in gpx.phases(): print(ph.name, ph.HAPvalue("Scale"), ph.get_cell())
gpx.save()
