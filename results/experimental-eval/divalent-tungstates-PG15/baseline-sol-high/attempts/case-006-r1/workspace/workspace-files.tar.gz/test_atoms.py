from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(ROOT / "trial.gpx"), newgpx=str(ROOT / "atoms_trial.gpx"))
hist = gpx.histogram(0)
phase = gpx.phase("CuWO4")

sample_scale = hist.SampleParameters["Scale"][0]
major_scale = phase.HAPvalue("Scale")
hist.SampleParameters["Scale"] = [1.0, False]
phase.HAPvalue("Scale", sample_scale * major_scale)
phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])

gpx.set_Controls("cycles", 15)
gpx.do_refinements([{"set": {"Atoms": {"O1": "X", "O2": "X", "O3": "X", "O4": "X"}}}])
print("oxygen coords", hist.residuals)
for atom in phase.atoms():
    print(atom.label, atom.coordinates, atom.uiso, atom.refinement_flags)

# Test Cu as well, retaining W as an origin anchor.
gpx.do_refinements([{"set": {"Atoms": {"Cu1": "X"}}}])
print("oxygen + Cu coords", hist.residuals)
for atom in phase.atoms():
    print(atom.label, atom.coordinates, atom.uiso, atom.refinement_flags)
gpx.save()
