from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
IPARM = ROOT / "instrument.instprm"
CUWO4 = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/4/00/08/4000806.cif")

gpx = G2sc.G2Project(newgpx=str(ROOT / "trial.gpx"))
hist = gpx.add_powder_histogram(str(PATTERN), str(IPARM), fmthint="comma")
phase = gpx.add_phase(str(CUWO4), phasename="CuWO4", histograms=[hist], fmthint="CIF")

# Ambient-pressure triclinic CuWO4 cell; the local COD entry supplies the
# correct P-1 atom model but was measured under pressure and is compressed.
cell = [4.703, 5.839, 4.878, 91.68, 92.47, 82.80]
phase.data["General"]["Cell"][1:7] = cell
from GSASII import GSASIIlattice as G2lat
phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))

hist.Limits("lower", 10.0)
hist.Limits("upper", 100.0)
hist.data["Background"][0][0] = "chebyschev-1"
hist.data["Background"][0][2] = 12
hist.data["Background"][0][3:] = [0.0] * 12

gpx.set_Controls("cycles", 8)
steps = [
    {"set": {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12}, "Scale": True}},
    {"set": {"Cell": True}},
    {"set": {"Instrument Parameters": ["Zero"]}},
    {"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}},
    {"set": {"Size": {"type": "isotropic", "refine": True, "value": 1.0},
             "Mustrain": {"type": "isotropic", "refine": True}}},
]

for i, step in enumerate(steps, 1):
    try:
        gpx.do_refinements([step])
        print("STEP", i, hist.residuals, phase.get_cell())
        print("INST", {k:v for k,v in hist.InstrumentParameters.items() if k in ["Zero","U","V","W","X","Y","SH/L"]})
        print("HAP", phase.getHAPvalues(hist))
    except Exception as exc:
        print("FAILED STEP", i, repr(exc))
        raise

gpx.save()
print("FINAL", hist.residuals)
