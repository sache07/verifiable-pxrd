#!/usr/bin/env python3
"""Build and refine a three-phase GSAS-II model for the supplied PXRD data."""

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PHASE_SOURCES = {
    "PbWO4_scheelite": COD / "9/00/98/9009811.cif",
    "PbO_massicot": COD / "2/31/04/2310433.cif",
    "WO3_monoclinic": COD / "1/52/89/1528915.cif",
}
FORMULAS = {
    "PbWO4_scheelite": "PbWO4",
    "PbO_massicot": "PbO",
    "WO3_monoclinic": "WO3",
}


def make_xye():
    """Use Poisson counting uncertainties because none were supplied."""
    with (ROOT / "inputs/pattern.csv").open(newline="") as src, (ROOT / "pattern.xye").open("w") as dst:
        rows = csv.DictReader(src)
        for row in rows:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")


def summarize(project, label):
    hist = project.histogram(0)
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")})
    for phase in project.phases():
        print(phase.name, "cell", phase.get_cell(), "scale", phase.HAPvalue("Scale"))
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as err:
        print("mass fractions unavailable at this stage:", err)


def main():
    make_xye()
    project = G2sc.G2Project(newgpx=str(ROOT / "final.gpx"))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"), fmthint="xye"
    )
    phases = []
    for name, source in PHASE_SOURCES.items():
        phases.append(project.add_phase(
            str(source), phasename=name, histograms=[hist], fmthint="CIF"
        ))

    # Reasonable starts keep the first scale dominant while allowing residual oxides.
    for phase, scale in zip(phases, (1.0, 0.08, 0.08)):
        phase.HAPvalue("Scale", scale)
    # Peak matching gives a common instrumental offset near +0.27 degrees.
    # Seeding it here prevents minor-phase scales from collapsing before the
    # offset is activated as a refinement variable.
    hist.InstrumentParameters["Zero"][1] = 0.27

    project.data["Controls"]["data"]["max cyc"] = 12
    hist.set_refinements({
        "Limits": [10.00943322, 99.99442286],
        "Background": {"type": "chebyschev-1", "no. coeffs": 15, "refine": True},
    })
    # The phase scales determine quantitative composition. A simultaneously
    # refined histogram scale is redundant and causes a singular covariance.
    hist.clear_refinements({"Sample Parameters": ["Scale"]})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})

    project.save()
    project.do_refinements([{}])
    summarize(project, "background and phase scales")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.do_refinements([{}])
    summarize(project, "zero offset")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.do_refinements([{}])
    summarize(project, "unit cells")

    hist.set_refinements({"Instrument Parameters": ["W"]})
    project.do_refinements([{}])
    summarize(project, "Gaussian profile")

    hist.set_refinements({"Instrument Parameters": ["X"]})
    project.do_refinements([{}])
    summarize(project, "full common profile")

    # Repeat the final flag set to settle the coupled cell, scale, background,
    # zero and profile terms after the profile model has been activated.
    project.do_refinements([{}, {}])
    summarize(project, "settled final model")

    project.save()

    # Export the exact final refined structures.
    cif_paths = {}
    for phase in project.phases():
        out = ROOT / f"{phase.name}.cif"
        phase.export_CIF(str(out))
        cif_paths[phase.name] = out.name

    # Export observed, calculated and obs-calc arrays from the final histogram.
    x = np.asarray(hist.getdata("X"))
    yobs = np.asarray(hist.getdata("Yobs"))
    ycalc = np.asarray(hist.getdata("Ycalc"))
    # Use the explicit obs-calc definition for every exported point, including
    # the end points just outside the active refinement limits.
    diff = yobs - ycalc
    bkg = np.asarray(hist.getdata("Background"))
    with (ROOT / "fit.csv").open("w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
        writer.writerows(zip(x, yobs, ycalc, diff, bkg))

    fractions = hist.ComputeMassFracs()
    residuals = hist.residuals
    result = {
        "phases": [
            {
                "name": phase.name,
                "formula": FORMULAS[phase.name],
                "cif_path": cif_paths[phase.name],
                "weight_fraction": fractions[phase.name][0],
                "weight_fraction_esd": fractions[phase.name][1],
            }
            for phase in project.phases()
        ],
        "fit_statistics": {
            "Rwp_percent": residuals.get("wR"),
            "Rp_percent": residuals.get("R"),
            "Rwp_background_subtracted_percent": residuals.get("wRb"),
            "Rp_background_subtracted_percent": residuals.get("Rb"),
            "Rexp_percent": residuals.get("wRmin"),
            "goodness_of_fit": (
                residuals.get("wR") / residuals.get("wRmin")
                if residuals.get("wRmin") else None
            ),
        },
        "measurement_range_two_theta_deg": [float(x[0]), float(x[-1])],
        "weighting": "Poisson counting weights, sigma=sqrt(observed counts)",
    }
    with (ROOT / "result.json").open("w") as fp:
        json.dump(result, fp, indent=2)
        fp.write("\n")

    project.save()
    summarize(project, "final")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
