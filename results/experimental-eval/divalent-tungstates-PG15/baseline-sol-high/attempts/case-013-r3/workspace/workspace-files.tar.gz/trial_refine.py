from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')

def cod(cid):
    return COD / cid[0] / cid[1:3] / cid[3:5] / f'{cid}.cif'

def show(gpx, tag):
    h = gpx.histogram(0)
    print('\n', tag, h.residuals)
    print('instrument', {k: v for k,v in h.InstrumentParameters.items() if k in ('Zero','U','V','W','X','Y','Z','SH/L','I(L2)/I(L1)')})
    for p in gpx.phases():
        hap=p.getHAPvalues(h)
        print(p.name, p.get_cell(), 'scale',hap['Scale'], 'size',hap['Size'][:3], 'micro',hap['Mustrain'][:3])

def main():
    out = ROOT/'trial.gpx'
    gpx = G2sc.G2Project(newgpx=str(out))
    h = gpx.add_powder_histogram(str(ROOT/'inputs/pattern.csv'), str(ROOT/'cu_ka.instprm'), fmthint='comma')
    p1 = gpx.add_phase(str(cod('9009811')), phasename='PbWO4_scheelite', histograms=[h], fmthint='CIF')
    p2 = gpx.add_phase(str(cod('1528915')), phasename='WO3_monoclinic', histograms=[h], fmthint='CIF')
    h.set_refinements({'Limits':[10.02,99.98], 'Background':{'type':'chebyschev-1','refine':True,'no. coeffs':12}})
    p1.data['Histograms'][h.name]['Scale'][0]=0.8
    p2.data['Histograms'][h.name]['Scale'][0]=0.2
    for p in (p1,p2): p.set_HAP_refinements({'Scale':True})
    gpx.save()
    stages = [
        ('scale_background', {}),
        ('zero_cell', {'set':{'Cell':True,'Instrument Parameters':['Zero']}}),
        ('profile', {'set':{'Instrument Parameters':['U','V','W','X','Y','SH/L']}}),
        ('size', {'set':{'Size':{'type':'isotropic','value':1.0,'refine':True}}}),
    ]
    for tag,ref in stages:
        try:
            gpx.do_refinements([ref])
            show(gpx,tag)
            gpx.save()
        except Exception as e:
            print('FAILED',tag,type(e).__name__,e)
            raise

if __name__ == '__main__': main()
