from pathlib import Path
import csv
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'diffuse_100000_10000.gpx'
FINAL = ROOT / 'final.gpx'
PHASE_DIR = ROOT / 'phases'
PHASE_DIR.mkdir(exist_ok=True)

# Save the selected, converged project under the required final name. All
# submitted numerical products below are read back from this exact object.
gpx = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
gpx.save()
h = gpx.histogram(0)

phase_meta = {
    'PbWO4_scheelite': ('PbWO4', 'I 41/a', 'phases/pbwo4_scheelite.cif'),
    'WO3_monoclinic': ('WO3', 'P 1 21/n 1', 'phases/wo3_monoclinic.cif'),
    'PbO_massicot': ('PbO', 'P b c m', 'phases/pbo_massicot.cif'),
    'PbO_litharge': ('PbO', 'P 4/n m m', 'phases/pbo_litharge.cif'),
    'Pb3O4': ('Pb3O4', 'P 42/m b c', 'phases/pb3o4.cif'),
}

mass_fracs = h.ComputeMassFracs()
phase_rows = []
for phase in gpx.phases():
    formula, spgrp, relpath = phase_meta[phase.name]
    phase.export_CIF(str(ROOT / relpath))
    frac, esd = mass_fracs[phase.name]
    cell, cell_esd = phase.get_cell_and_esd()
    phase_rows.append({
        'name': phase.name,
        'formula': formula,
        'space_group': spgrp,
        'cif_path': relpath,
        'weight_fraction': frac,
        'weight_fraction_formal_esd': esd,
        'refined_cell_angstrom_degrees': cell,
    })

x, yobs, weight, ycalc, background, difference = h.data['data'][1]
with (ROOT / 'fit.csv').open('w', newline='') as fp:
    writer = csv.writer(fp)
    writer.writerow(['two_theta_deg', 'observed', 'calculated', 'difference', 'background'])
    writer.writerows((xx, yo, yc, dd, bg) for xx, yo, yc, dd, bg in
                     zip(x, yobs, ycalc, difference, background) if yc != 0.0)

rvals = gpx.data['Covariance']['data']['Rvals']
fit_stats = {
    'Rwp_percent': h.residuals['wR'],
    'Rp_percent': h.residuals['R'],
    'R_background_percent': h.residuals['Rb'],
    'weighted_R_background_percent': h.residuals['wRb'],
    'goodness_of_fit': rvals['GOF'],
    'chi_square': rvals['chisq'],
    'n_observations': rvals['Nobs'],
    'n_refined_variables': rvals['Nvars'],
    'converged': bool(rvals['converged']),
    'maximum_shift_over_esd': rvals['Max shft/sig'],
}

result = {
    'phases': phase_rows,
    'weight_fraction_basis': 'Normalized over the five modeled crystalline phases; the broad/diffuse component is excluded.',
    'fit_statistics': fit_stats,
    'project_path': 'final.gpx',
    'profile_path': 'fit.csv',
}
(ROOT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')

report = f"""# Quantitative phase analysis

The crystalline pattern is best described by five phases: scheelite PbWO4, monoclinic WO3, orthorhombic PbO (massicot), tetragonal PbO (litharge), and minor Pb3O4. The refined crystalline-only weight fractions are {100*mass_fracs['PbWO4_scheelite'][0]:.2f}%, {100*mass_fracs['WO3_monoclinic'][0]:.2f}%, {100*mass_fracs['PbO_massicot'][0]:.2f}%, {100*mass_fracs['PbO_litharge'][0]:.2f}%, and {100*mass_fracs['Pb3O4'][0]:.2f}%, respectively.

## Evidence

The dominant line set (27.70, 33.06, 45.03, 55.54 degrees 2theta and higher-angle partners) identifies tetragonal scheelite PbWO4. The 23.39/23.89/24.64-degree triplet and the 26.77, 34.43, and 41.91-degree lines identify monoclinic WO3. Residual-model comparisons distinguish massicot by its 29.35, 30.62, 32.86, and 38.12-degree lines; adding it lowered Rwp from about 18.30% to 15.67%. Weaker but repeated line matches support litharge (about 28.9, 32.1, 36.0, 45.9, 48.9, and 60.0 degrees) and Pb3O4 (notably the 26.7, 31.0, and 34.4-degree regions). Alternative raspite PbWO4 and WO2 models refined to effectively zero scale.

The final GSAS-II Rietveld fit uses the metadata Cu Kalpha1/Kalpha2 wavelengths and 0.5 intensity ratio, refined phase scales and cells, a common uncalibrated instrument profile, and isotropic size broadening for PbWO4. It converged with Rwp = {fit_stats['Rwp_percent']:.3f}%, Rp = {fit_stats['Rp_percent']:.3f}%, and GOF = {fit_stats['goodness_of_fit']:.3f}.

## Remaining uncertainty

A broad envelope centered near 29.89 degrees (plus a conspicuous unmatched broad feature near 25.91 degrees) cannot be assigned or quantified reliably from this dataset. It is represented empirically as diffuse background and is excluded from the crystalline normalization; therefore the reported values are not absolute bulk fractions if amorphous or unidentified material is present. The litharge and Pb3O4 assignments are less secure than the three major phases because their strongest lines overlap other phases. Their formal least-squares uncertainties understate model and instrument-profile uncertainty; a realistic systematic uncertainty is several weight-percent for the major phases and roughly 1-2 weight-percent for each minor phase. Pointwise uncertainties were not supplied, so GSAS-II used counting-statistical proxy weights (1/intensity); the GOF should be interpreted accordingly.
"""
(ROOT / 'report.md').write_text(report)

print(json.dumps({'fractions': mass_fracs, 'fit_statistics': fit_stats}, indent=2))
