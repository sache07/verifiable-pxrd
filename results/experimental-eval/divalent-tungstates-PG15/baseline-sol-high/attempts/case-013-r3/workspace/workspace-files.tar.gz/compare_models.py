from pathlib import Path
import json, traceback
from GSASII import GSASIIscriptable as G2sc

ROOT=Path(__file__).resolve().parent
COD=Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
def cod(cid): return COD/cid[0]/cid[1:3]/cid[3:5]/f'{cid}.cif'

models = {
 'massicot_litharge': [('PbO_massicot','2310433'),('PbO_litharge','9012700')],
 'massicot_Pb3O4': [('PbO_massicot','2310433'),('Pb3O4','1537983')],
 'massicot_litharge_Pb3O4': [('PbO_massicot','2310433'),('PbO_litharge','9012700'),('Pb3O4','1537983')],
}

def run(name, extras):
 out=ROOT/f'cmp_{name}.gpx'
 g=G2sc.G2Project(newgpx=str(out))
 h=g.add_powder_histogram(str(ROOT/'inputs/pattern.csv'),str(ROOT/'cu_ka.instprm'),fmthint='comma')
 phase_defs=[('PbWO4_scheelite','9009811'),('WO3_monoclinic','1528915')]+extras
 ps=[]
 for pname,cid in phase_defs:
  ps.append(g.add_phase(str(cod(cid)),phasename=pname,histograms=[h],fmthint='CIF'))
 h.set_refinements({'Limits':[10.02,99.98], 'Background':{'type':'chebyschev-1','refine':True,'no. coeffs':12}})
 h.SampleParameters['Scale']=[1.0,False]
 init=[.8,.18]+[.02]*len(extras)
 for p,s in zip(ps,init):
  p.data['Histograms'][h.name]['Scale']=[s,True]
 # sequential fitting; keep only stable instrumental Caglioti terms
 for refs in [{}, {'set':{'Cell':True,'Instrument Parameters':['Zero']}},
              {'set':{'Instrument Parameters':['U','V','W','SH/L']}}]:
  g.do_refinements([refs])
 # extra cycles to convergence
 g.do_refinements([{}])
 g.save()
 try: mf=h.ComputeMassFracs()
 except Exception as e: mf={'error':str(e)}
 return {'model':name,'wR':h.residuals.get('wR'),'R':h.residuals.get('R'),
         'GOF':g.data['Covariance']['data'].get('Rvals',{}).get('GOF'),
         'mass_fractions':mf,
         'scales':{p.name:p.getHAPvalues(h)['Scale'][0] for p in ps},
         'cells':{p.name:p.get_cell() for p in ps},
         'inst':{k:v[1] for k,v in h.InstrumentParameters.items() if k in ('Zero','U','V','W','SH/L')}}

results=[]
for name,extras in models.items():
 try:
  r=run(name,extras); results.append(r); print('RESULT',json.dumps(r,default=lambda x:list(x) if hasattr(x,'__iter__') else str(x)))
 except Exception as e:
  print('ERROR',name,type(e).__name__,e); traceback.print_exc()
Path(ROOT/'compare_results.json').write_text(json.dumps(results,indent=2))
