from pathlib import Path
import sys
import numpy as np
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2sc

root=Path(__file__).resolve().parent
gpx_name=sys.argv[1] if len(sys.argv)>1 else 'trial.gpx'
g=G2sc.G2Project(str(root/gpx_name))
h=g.histogram(0)
print('sample',h.SampleParameters)
print('background',h.Background)
try: print('massfracs',h.ComputeMassFracs())
except Exception as e: print('massfracs failed',type(e).__name__,e)
print('covariance keys',g.data['Covariance']['data'].keys())
x,yo,w,yc,yb,yd=h.data['data'][1]
peaks,props=find_peaks(yd,prominence=120,distance=8)
for i in peaks[np.argsort(props['prominences'])[::-1]][:60]:
    print(f'resid {x[i]:.4f} {yd[i]:.1f} prom={props["prominences"][np.where(peaks==i)[0][0]]:.1f}')
np.savetxt(root/'trial_fit.csv',np.column_stack((x,yo,yc,yd,yb)),delimiter=',',
           header='two_theta_deg,observed,calculated,difference,background',comments='')
