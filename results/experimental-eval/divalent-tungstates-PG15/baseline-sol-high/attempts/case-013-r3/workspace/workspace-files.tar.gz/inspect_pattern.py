import pandas as pd
import matplotlib.pyplot as plt

p = pd.read_csv("trial_fit.csv")
x, y = p.iloc[:, 0], p.iloc[:, 1]
fig, axs = plt.subplots(3, 1, figsize=(14, 10), constrained_layout=True)
for ax, lim in zip(axs, [(10, 45), (20, 38), (38, 100)]):
    m = (x >= lim[0]) & (x <= lim[1])
    ax.plot(x[m], y[m], lw=.65, color="black", label="obs")
    ax.plot(x[m], p.calculated[m], lw=.65, color="red", label="calc")
    ax.plot(x[m], p.difference[m], lw=.55, color="blue", label="diff")
    ax.set_xlim(*lim)
    ax.set_ylabel("counts")
    ax.grid(alpha=.2)
    ax.legend(ncol=3)
axs[-1].set_xlabel(r"2$\theta$ (deg)")
fig.savefig("pattern_inspect.png", dpi=160)
