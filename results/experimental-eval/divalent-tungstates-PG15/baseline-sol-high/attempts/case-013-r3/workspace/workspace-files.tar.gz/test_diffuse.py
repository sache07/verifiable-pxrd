from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT=Path(__file__).resolve().parent
for intensity,sigma in [(20000,3000),(50000,5000),(100000,10000)]:
 out=ROOT/f'diffuse_{intensity}_{sigma}.gpx'
 g=G2sc.G2Project(str(ROOT/'size_PbWO4.gpx'),newgpx=str(out)); h=g.histogram(0)
 # Broad empirical contribution for the diffuse 28-32 degree envelope.
 h.add_back_peak(29.7,intensity,sigma,0.0,[True,True,True,False])
 g.save(); g.do_refinements([{}]); g.do_refinements([{}]); g.save()
 print('RESULT',intensity,sigma,h.residuals,h.Background[1]['peaksList'],h.ComputeMassFracs())
