from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT=Path(__file__).resolve().parent
base=ROOT/'cmp_massicot_litharge_Pb3O4.gpx'
phase_names=['PbWO4_scheelite','WO3_monoclinic','PbO_massicot','PbO_litharge','Pb3O4']
tests=[[p] for p in phase_names]+[phase_names[1:],phase_names]
results=[]
for subset in tests:
 name='size_'+'_'.join(x.split('_')[0] for x in subset)
 out=ROOT/f'{name}.gpx'
 g=G2sc.G2Project(str(base),newgpx=str(out)); h=g.histogram(0)
 # Fix uncalibrated instrument profile at the common-width result.
 for k in ('U','V','W','X','Y','Z','SH/L'):
  if k in h.InstrumentParameters: h.InstrumentParameters[k][2]=False
 for pnm in subset:
  p=g.phase(pnm)
  p.set_HAP_refinements({'Size':{'type':'isotropic','value':1.0,'refine':True}})
 g.save(); g.do_refinements([{}]); g.do_refinements([{}]); g.save()
 r={'test':name,'wR':h.residuals.get('wR'),'R':h.residuals.get('R'),
    'mf':h.ComputeMassFracs(),
    'sizes':{p.name:p.getHAPvalues(h)['Size'][1][0] for p in g.phases()}}
 print('RESULT',json.dumps(r)); results.append(r)
(ROOT/'broadening_results.json').write_text(json.dumps(results,indent=2))
