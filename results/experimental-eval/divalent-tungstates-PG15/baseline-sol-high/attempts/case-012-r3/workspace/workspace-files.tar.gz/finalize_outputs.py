from pathlib import Path
import csv
import json
import math
import numpy as np
import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
G2sc.SetPrintLevel('warn')
p = G2sc.G2Project(str(ROOT / 'stable.gpx'), newgpx=str(ROOT / 'final.gpx'))
h = p.histogram(0)
p.set_Controls('cycles', 5)
p.do_refinements([{}])
p.save()

fractions = h.ComputeMassFracs()
res = h.residuals
covres = p.data['Covariance']['data']['Rvals']

cif_names = {'NiWO4': 'phase_NiWO4.cif', 'WO3': 'phase_WO3.cif'}
phase_records = []
for ph in p.phases():
    ph.export_CIF(str(ROOT / cif_names[ph.name]))
    cell, cell_esd = ph.get_cell_and_esd()
    frac, frac_esd = fractions[ph.name]
    phase_records.append({
        'name': ph.name,
        'formula': 'NiWO4' if ph.name == 'NiWO4' else 'WO3',
        'space_group': ph.data['General']['SGData']['SpGrp'].strip(),
        'cif_path': cif_names[ph.name],
        'weight_fraction': frac,
        'weight_fraction_esd': frac_esd,
        'cell': cell,
        'cell_esd': cell_esd,
        'bragg_R_F_percent': res[f'{ph.id}:0:Rf'],
        'bragg_R_F2_percent': res[f'{ph.id}:0:Rf^2'],
    })

x = np.asarray(h.getdata('X'), dtype=float)
yo = np.asarray(h.getdata('Yobs'), dtype=float)
yc = np.asarray(h.getdata('Ycalc'), dtype=float)
bg = np.asarray(h.getdata('Background'), dtype=float)
diff = yo - yc
# Export only the range used in the refinement; GSAS-II stores zeros in the
# calculated arrays for the few points just outside the selected limits.
used = (yc != 0.0) | (bg != 0.0)
with open(ROOT / 'fit.csv', 'w', newline='') as fp:
    w = csv.writer(fp)
    w.writerow(['two_theta_deg', 'observed_intensity', 'calculated_intensity',
                'difference_observed_minus_calculated', 'calculated_background'])
    w.writerows(zip(x[used], yo[used], yc[used], diff[used], bg[used]))

fit_stats = {
    'R_p_percent': res['R'],
    'R_wp_percent': res['wR'],
    'R_exp_percent': res['wRmin'],
    'goodness_of_fit': covres['GOF'],
    'chi_squared': covres['chisq'],
    'n_observations': covres['Nobs'],
    'n_refined_parameters': covres['Nvars'],
    'refinement_converged': bool(covres.get('converged', False)),
    'max_shift_over_esd': covres.get('Max shft/sig'),
    'two_theta_refined_range_deg': [10.05, 99.95],
    'weighting': 'Poisson counting weights, sigma=sqrt(observed counts)'
}

result = {
    'phases': phase_records,
    'weight_fraction_basis': 'normalized over modeled crystalline phases',
    'fit_statistics': fit_stats,
    'project_path': 'final.gpx',
    'profile_path': 'fit.csv'
}
with open(ROOT / 'result.json', 'w') as fp:
    json.dump(result, fp, indent=2)
    fp.write('\n')

byname = {r['name']: r for r in phase_records}
n = byname['NiWO4']; w = byname['WO3']
report = f'''# Quantitative phase analysis

The pattern is modeled as **wolframite-type NiWO4 (P 2/c)** plus **monoclinic WO3 (P 21/n)**. The refined crystalline-phase fractions are **{100*n['weight_fraction']:.2f} wt% NiWO4** and **{100*w['weight_fraction']:.2f} wt% WO3** (normalized to the two modeled crystalline phases). The least-squares formal 1-sigma uncertainty is {100*n['weight_fraction_esd']:.2f} wt%-point for either fraction.

## Evidence

NiWO4 accounts for the dominant reflections at approximately 19.2, 23.9, 24.9, 30.9, 36.5, 41.6, 54.6, and 65.5-65.8 degrees 2theta. Residual monoclinic WO3 is required by its characteristic split group at approximately 23.1, 23.5, and 24.3 degrees and supporting reflections near 28.8, 33.2-34.1, and 49.9 degrees. These assignments are chemically consistent with the NiO + WO3 precursor context and 900 degrees C heating.

The starting structural models were the wolframite NiWO4 model reconstructed from COD 5910277 and room-temperature monoclinic WO3 from COD 1528915. Unit-cell metrics, phase scales, background, zero offset, and stable profile/microstrain terms were refined in GSAS-II. Final cells are NiWO4 a={n['cell']['length_a']:.6f}, b={n['cell']['length_b']:.6f}, c={n['cell']['length_c']:.6f} A, beta={n['cell']['angle_beta']:.4f} degrees and WO3 a={w['cell']['length_a']:.6f}, b={w['cell']['length_b']:.6f}, c={w['cell']['length_c']:.6f} A, beta={w['cell']['angle_beta']:.4f} degrees.

The final fit has Rwp={fit_stats['R_wp_percent']:.2f}%, Rp={fit_stats['R_p_percent']:.2f}%, Rexp={fit_stats['R_exp_percent']:.2f}%, and GOF={fit_stats['goodness_of_fit']:.2f}. A trial NiO phase refined to the numerical lower bound (about 1e-12 scale), did not account for a distinct 43.3 degree reflection, and destabilized the fit; NiO was therefore not retained as a detected crystalline phase.

## Remaining uncertainty

The reported fraction esd is the internal least-squares value and is smaller than the likely absolute accuracy. No calibrated instrumental profile, internal standard, or absorption correction was supplied; profile/size-strain correlation and possible microabsorption from W-rich grains make a realistic composition uncertainty of a few wt%-points more appropriate. The atomic coordinates were retained from the reference structures because this laboratory powder pattern does not constrain independent coordinate refinement reliably; the submitted CIFs primarily represent phase identity plus refined lattice metrics. Trace phases below the pattern's practical detection level and amorphous material cannot be excluded, and the fractions are explicitly normalized only over the modeled crystalline phases.
'''
with open(ROOT / 'report.md', 'w') as fp:
    fp.write(report)

print(json.dumps(result, indent=2))
