from pathlib import Path
import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
G2sc.SetPrintLevel('warn')
p = G2sc.G2Project(str(ROOT / 'working_final.gpx'), newgpx=str(ROOT / 'stable.gpx'))
h = p.histogram(0)
p.set_Controls('cycles', 3)

# Eliminate the exact overall-scale/phase-scale degeneracy. The absolute
# overall scale is arbitrary; phase scale ratios determine weight fractions.
h.data['Sample Parameters']['Scale'][1] = False
# Eliminate the observed >90% Y/microstrain correlation, retaining the
# converged global Y value while allowing physically positive phase widths.
h.clear_refinements({'Instrument Parameters': ['Y']})
p.do_refinements([{}])
p.do_refinements([{}])
p.save()

print('residuals', h.residuals)
print('mass fractions', h.ComputeMassFracs())
print('sample scale', h.data['Sample Parameters']['Scale'])
print('vary', p.data['Covariance']['data']['varyList'])
for ph in p.phases():
    print(ph.name, ph.get_cell(), ph.data['Histograms'][h.name]['Scale'],
          ph.data['Histograms'][h.name]['Mustrain'])
