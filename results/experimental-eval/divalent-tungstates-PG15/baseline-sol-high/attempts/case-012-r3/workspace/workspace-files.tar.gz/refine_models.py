from pathlib import Path
import json
import numpy as np
import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
G2sc.SetPrintLevel('warn')

WO3 = '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif'
NIO = '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/00/1010093.cif'


def make_xye():
    a = np.loadtxt(ROOT / 'inputs/pattern.csv', delimiter=',', skiprows=1)
    sig = np.sqrt(np.maximum(a[:, 1], 1.0))
    np.savetxt(ROOT / 'pattern.xye', np.column_stack((a, sig)), fmt='%.8f %.8f %.8f')


def refine(tag, phase_files):
    gpx = ROOT / f'{tag}.gpx'
    p = G2sc.G2Project(newgpx=str(gpx))
    h = p.add_powder_histogram(str(ROOT / 'pattern.xye'), str(ROOT / 'lab_cuka.instprm'), fmthint='xye')
    phases = []
    for name, fn in phase_files:
        phases.append(p.add_phase(str(fn), phasename=name, histograms=[h], fmthint='CIF'))

    h.set_refinements({'Limits': [10.05, 99.95],
                       'Background': {'type': 'chebyschev-1', 'no. coeffs': 15,
                                      'refine': True}})
    # Sequentially introduce the robust parameters before profile detail.
    p.do_refinements([{'set': {'Scale': True}}])
    p.do_refinements([{'set': {'Cell': True}}])
    p.do_refinements([{'set': {'Instrument Parameters': ['Zero', 'W', 'Y']}}])
    p.do_refinements([{'set': {'Instrument Parameters': ['U', 'V', 'X', 'SH/L']}}])
    # Allow phase-dependent broadening after the common instrumental profile is stable.
    p.do_refinements([{'set': {'Mustrain': {'type': 'isotropic', 'refine': True}}}])
    p.do_refinements([{}])
    p.save()

    out = {
        'tag': tag,
        'residuals': h.residuals,
        'mass_fractions': h.ComputeMassFracs(),
        'instrument': {k: v for k, v in h.InstrumentParameters.items()
                       if k in ['Lam1', 'Lam2', 'I(L2)/I(L1)', 'Zero', 'U', 'V', 'W', 'X', 'Y', 'SH/L']},
        'phases': {}
    }
    for ph in phases:
        out['phases'][ph.name] = {
            'cell': ph.get_cell(),
            'hap': ph.data['Histograms'][h.name],
        }
    print(json.dumps(out, indent=2, default=lambda x: x.tolist() if hasattr(x, 'tolist') else str(x)))
    return p


if __name__ == '__main__':
    make_xye()
    models = {
        'model_niwo4': [('NiWO4', ROOT / 'niwo4_start.cif')],
        'model_niwo4_wo3': [('NiWO4', ROOT / 'niwo4_start.cif'), ('WO3', WO3)],
        'model_niwo4_wo3_nio': [('NiWO4', ROOT / 'niwo4_start.cif'), ('WO3', WO3), ('NiO', NIO)],
    }
    for tag, files in models.items():
        print('\nMODEL', tag)
        try:
            refine(tag, files)
        except Exception as exc:
            print('FAILED', tag, repr(exc))
