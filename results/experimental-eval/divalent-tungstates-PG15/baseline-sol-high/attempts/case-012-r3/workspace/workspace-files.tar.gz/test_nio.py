from pathlib import Path
import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
NIO = '<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/00/1010093.cif'
G2sc.SetPrintLevel('warn')
p = G2sc.G2Project(str(ROOT / 'stable.gpx'), newgpx=str(ROOT / 'test_nio.gpx'))
h = p.histogram(0)
p.set_Controls('cycles', 3)
nio = p.add_phase(NIO, phasename='NiO', histograms=[h], fmthint='CIF')
nio.data['Histograms'][h.name]['Scale'][0] = 0.02
nio.set_HAP_refinements({'Scale': True}, [h])
p.do_refinements([{}])
p.do_refinements([{}])
p.save()
print('residuals', h.residuals)
print('mass fractions', h.ComputeMassFracs())
print('NiO scale', nio.data['Histograms'][h.name]['Scale'])
