from pathlib import Path
import json
import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
G2sc.SetPrintLevel('warn')
p = G2sc.G2Project(str(ROOT / 'model_niwo4_wo3.gpx'), newgpx=str(ROOT / 'working_final.gpx'))
h = p.histogram(0)
p.set_Controls('cycles', 2)

# Keep only the empirically stable global profile terms from the completed fit.
h.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'Y', 'SH/L']})
h.set_refinements({'Instrument Parameters': ['Zero', 'W', 'Y']})
p.do_refinements([{}])
print('global profile', h.residuals)

# Test phase-dependent microstrain; retained because the two phases need visibly
# different widths and this parameterization remains positive and interpretable.
for ph in p.phases():
    ph.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}}, [h])
p.do_refinements([{}])
print('with phase microstrain', h.residuals)

# One final covariance-consistent cycle with all retained flags.
p.do_refinements([{}])
p.save()
print('mass fractions', h.ComputeMassFracs())
print('instrument', {k: v for k, v in h.InstrumentParameters.items()
                     if k in ['Zero', 'U', 'V', 'W', 'X', 'Y', 'SH/L']})
for ph in p.phases():
    print(ph.name, ph.get_cell(), ph.data['Histograms'][h.name]['Mustrain'])
