from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
REFERENCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)


def make_project(tag, profile_terms, refine_atoms=False):
    filename = ROOT / ".tmp" / f"{tag}.gpx"
    gpx = G2sc.G2Project(newgpx=str(filename))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma/tab",
    )
    phase = gpx.add_phase(
        str(REFERENCE), phasename="MnWO4", histograms=[hist], fmthint="CIF"
    )
    # Fix the redundant overall histogram scale; refine the phase scale only.
    hist.SampleParameters["Scale"] = [1.0, False]
    # Start near the ambient-pressure wolframite metric found in the initial fit.
    cell = phase.data["General"]["Cell"]
    cell[1:7] = [4.8343, 5.7607, 4.9996, 90.0, 91.2196, 90.0]
    hist.SampleParameters["Shift"] = [-500.0, False]
    phase.HAPvalue("Scale", 8.0, targethistlist=[hist])
    phase.set_HAP_refinements({"Scale": True}, [hist])
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 12,
        },
    })
    gpx.set_Controls("cycles", 12)
    gpx.refine()

    phase = gpx.phase(0)
    hist = gpx.histogram(0)
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    gpx.refine()

    hist = gpx.histogram(0)
    hist.set_refinements({"Instrument Parameters": profile_terms})
    gpx.refine()
    gpx.refine()

    if refine_atoms:
        phase = gpx.phase(0)
        phase.set_refinements({"Atoms": {"all": "X"}})
        gpx.refine()
        gpx.refine()

    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    rv = gpx.data["Covariance"]["data"].get("Rvals", {})
    print("\nMODEL", tag)
    print("residuals", hist.residuals)
    print("Rvals", {k: rv.get(k) for k in ["Rwp", "GOF", "Nobs", "Nvars", "SVD0", "converged", "Max shft/sig", "msg"]})
    print("cell", phase.get_cell())
    print("shift", hist.SampleParameters["Shift"])
    print("profile", {k: hist.InstrumentParameters[k] for k in ["U", "V", "W", "X", "Y"]})
    print("scale", phase.HAPvalue("Scale", targethistlist=[hist]))
    if refine_atoms:
        print("atoms")
        for atom in phase.data["Atoms"]:
            print(atom[:17])
    gpx.save()


G2sc.SetPrintLevel("warn")
make_project("uvw", ["U", "V", "W"])
make_project("uvwx", ["U", "V", "W", "X"])
make_project("uvwxy", ["U", "V", "W", "X", "Y"])
make_project("uvwxy_atoms", ["U", "V", "W", "X", "Y"], refine_atoms=True)
