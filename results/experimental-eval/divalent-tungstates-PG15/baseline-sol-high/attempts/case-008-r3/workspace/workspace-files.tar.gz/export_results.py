from pathlib import Path
import csv
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
project = G2sc.G2Project(str(ROOT / "final.gpx"))
hist = project.histogram(0)
phases = project.phases()

cif_names = ["MnWO4.cif", "WO3.cif"]
for phase, cif_name in zip(phases, cif_names):
    phase.export_CIF(str(ROOT / cif_name))

x = hist.getdata("X")
yobs = hist.getdata("Yobs")
ycalc = hist.getdata("Ycalc")
background = hist.getdata("Background")
difference = hist.getdata("Residual")
with (ROOT / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_intensity_counts",
            "calculated_intensity_counts",
            "difference_obs_minus_calc_counts",
            "calculated_background_counts",
        ]
    )
    writer.writerows(zip(x, yobs, ycalc, difference, background))

fractions = hist.ComputeMassFracs()
residuals = hist.residuals
rvals = project.data["Covariance"]["data"]["Rvals"]
phase_records = []
formulas = ["MnWO4", "WO3"]
cod_ids = ["1520200", "1528915"]
for index, (phase, cif_name, formula, cod_id) in enumerate(
    zip(phases, cif_names, formulas, cod_ids)
):
    fraction, fraction_esd = fractions[phase.name]
    cell, cell_esd = phase.get_cell_and_esd()
    phase_records.append(
        {
            "name": "manganese tungstate (wolframite)" if index == 0 else "tungsten trioxide (gamma-WO3)",
            "formula": formula,
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "reference_cod_id": cod_id,
            "cif_path": cif_name,
            "weight_fraction": fraction,
            "weight_fraction_esd_formal": fraction_esd,
            "bragg_Rf_percent": residuals[f"{index}:0:Rf"],
            "unit_cell": cell,
            "unit_cell_esd": cell_esd,
        }
    )

result = {
    "phases": phase_records,
    "weight_fraction_basis": "normalized over modeled crystalline phases",
    "fit_statistics": {
        "Rwp_percent": residuals["wR"],
        "Rp_percent": residuals["R"],
        "Rexp_percent": residuals["wRmin"],
        "goodness_of_fit": rvals["GOF"],
        "reduced_chi_square": rvals["GOF"] ** 2,
        "chi_square": rvals["chisq"],
        "number_of_observations": rvals["Nobs"],
        "number_of_variables": rvals["Nvars"],
        "two_theta_range_deg": [float(x[0]), float(x[-1])],
        "difference_definition": "observed - calculated",
    },
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
}
with (ROOT / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
