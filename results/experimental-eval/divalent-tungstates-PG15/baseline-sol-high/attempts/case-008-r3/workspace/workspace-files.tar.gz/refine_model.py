from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INST = ROOT / "instrument.instprm"
REFERENCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)
PROJECT = ROOT / "trial.gpx"


def status(label, project):
    hist = project.histogram(0)
    phase = project.phase(0)
    print(f"\n{label}")
    print("residuals", hist.residuals)
    print("cell", phase.get_cell())
    print("HAP scale", phase.HAPvalue("Scale", targethistlist=[hist]))
    print("instrument", hist.InstrumentParameters)
    print("sample", hist.SampleParameters)


G2sc.SetPrintLevel("warn")
gpx = G2sc.G2Project(newgpx=str(PROJECT))
hist = gpx.add_powder_histogram(
    str(PATTERN), str(INST), fmthint="comma/tab"
)
phase = gpx.add_phase(
    str(REFERENCE), phasename="MnWO4", histograms=[hist], fmthint="CIF"
)
gpx.set_Controls("cycles", 8)
hist.set_refinements({
    "Limits": [10.0, 100.0],
    "Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": 12,
    },
})
phase.HAPvalue("Scale", 1.0, targethistlist=[hist])
phase.set_HAP_refinements({"Scale": True}, [hist])
gpx.refine()
status("background + scale", gpx)

phase = gpx.phase(0)
hist = gpx.histogram(0)
phase.set_refinements({"Cell": True})
hist.set_refinements({"Instrument Parameters": ["Zero"]})
gpx.refine()
status("cell + zero", gpx)

hist = gpx.histogram(0)
hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y"]})
gpx.refine()
status("profile", gpx)

phase = gpx.phase(0)
phase.set_HAP_refinements({
    "Size": {"type": "isotropic", "value": 1.0, "refine": True},
    "Mustrain": {"type": "isotropic", "refine": True},
}, [gpx.histogram(0)])
gpx.refine()
status("size + microstrain", gpx)

gpx.save()
