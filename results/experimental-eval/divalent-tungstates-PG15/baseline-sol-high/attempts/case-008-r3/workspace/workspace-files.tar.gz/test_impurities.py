from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
BASE = ROOT / ".tmp" / "uvwxy_atoms.gpx"
CANDIDATES = {
    "Mn3WO6": "2002703",
    "MnO": "1514108",
    "MnO_alt": "1514231",
    "Mn3O4": "1541183",
    "Mn2O3": "1010586",
    "MnO2": "1514110",
    "WO3_hex": "1004057",
    "WO3_monoclinic": "1010618",
    "WO3_tetragonal": "1521532",
    "WO3_orthorhombic": "1521533",
    "WO3_alt_monoclinic": "1528915",
    "WO3_modern_monoclinic": "1563541",
    "WO3_second_monoclinic": "2311041",
    "WO3_triclinic": "2106293",
    "WO3_alt2": "2107312",
}


def cif_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


G2sc.SetPrintLevel("warn")
for name, cod_id in CANDIDATES.items():
    out = ROOT / ".tmp" / f"impurity_{name}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cif_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
    )
    phase.HAPvalue("Scale", 0.1, targethistlist=[hist])
    phase.set_HAP_refinements({"Scale": True}, [hist])
    project.set_Controls("parmMin", 0.0, variable="1:0:Scale")
    project.set_Controls("cycles", 15)
    for _ in range(2):
        project.refine()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as err:
        fractions = {"error": str(err)}
    print(
        "RESULT",
        name,
        "Rwp", rvals.get("Rwp"),
        "GOF", rvals.get("GOF"),
        "scale", project.phase(1).HAPvalue("Scale", targethistlist=[hist]),
        "massfracs", fractions,
        "SVD", rvals.get("SVD0"),
        "msg", rvals.get("msg"),
    )
