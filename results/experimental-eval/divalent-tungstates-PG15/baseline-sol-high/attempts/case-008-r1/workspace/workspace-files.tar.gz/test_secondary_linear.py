#!/usr/bin/env python3
import os
from GSASII import GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.dirname(__file__))
SRC = os.path.join(ROOT, "main_converged.bak0.gpx")
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"
cases = {
    "MnO": f"{COD}/1/51/41/1514108.cif",
    "Mn3O4": f"{COD}/1/01/12/1011262.cif",
    "Mn2O3": f"{COD}/1/51/42/1514230.cif",
    "WO3_mono": f"{COD}/1/52/89/1528915.cif",
    "WO3_ortho": f"{COD}/1/01/06/1010618.cif",
    "WO3_hex": f"{COD}/1/00/40/1004057.cif",
    "Mn3WO6": f"{COD}/2/00/27/2002703.cif",
}

def freeze(g, h):
    h.data["Background"][0][1] = False
    for val in h.data["Instrument Parameters"][0].values():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    for key, val in h.data["Sample Parameters"].items():
        if isinstance(val, list) and len(val) == 2 and isinstance(val[1], bool):
            val[1] = False
    for p in g.phases():
        p.data["General"]["Cell"][0] = False
        for a in p.atoms(): a.refinement_flags = ""
        hap = p.getHAPvalues(h)
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])

for name, cif in cases.items():
    out = os.path.join(ROOT, f"linear_{name}.gpx")
    g = G2sc.G2Project(SRC, newgpx=out)
    h, main = g.histogram(0), g.phase(0)
    freeze(g, h)
    sec = g.add_phase(cif, phasename=name, histograms=[h], fmthint="CIF")
    sec.HAPvalue("Scale", 0.01, targethistlist=[h])
    sec.set_HAP_refinements({"Scale": True}, [h])
    g.set_Controls("cycles", 8)
    g.do_refinements([{}])
    g.save(out)
    cov = g.data["Covariance"]["data"]
    vname = "1:0:Scale"
    i = cov["varyList"].index(vname)
    scale, sig = cov["variables"][i], cov["sig"][i]
    vals = [(p.name, p.HAPvalue("Scale", targethistlist=[h]), p.data["General"]["Mass"])
            for p in g.phases()]
    den = sum(v[1]*v[2] for v in vals)
    frac = scale*vals[1][2]/den if den else None
    print("SUMMARY", name, "wR", h.get_wR(), "scale", scale, "sig", sig,
          "z", scale/sig if sig else None, "wtfrac", frac)
