#!/usr/bin/env python3
import os
from GSASII import GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.dirname(__file__))
g = G2sc.G2Project(os.path.join(ROOT, "two_phase.bak0.gpx"),
                   newgpx=os.path.join(ROOT, "two_phase_cell.gpx"))
h = g.histogram(0)
for val in h.data["Instrument Parameters"][0].values():
    if isinstance(val, list) and len(val) > 2: val[2] = False
h.data["Background"][0][1] = False
for key, val in h.data["Sample Parameters"].items():
    if isinstance(val, list) and len(val) == 2 and isinstance(val[1], bool): val[1] = False
for p in g.phases():
    p.data["General"]["Cell"][0] = False
    for a in p.atoms(): a.refinement_flags = ""
    hap = p.getHAPvalues(h)
    hap["Scale"][1] = False
    hap["Pref.Ori."][2] = False
wo3 = g.phase(1)
wo3.data["General"]["Cell"][0] = True
wo3.getHAPvalues(h)["Scale"][1] = True
g.set_Controls("cycles", 16)
g.do_refinements([{}])
g.save()
print("FINAL", h.get_wR(), g.data["Covariance"]["data"].get("Rvals"))
print("CELL", wo3.get_cell_and_esd())
print("FRAC", h.ComputeMassFracs())
