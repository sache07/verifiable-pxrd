#!/usr/bin/env python3
import os
from GSASII import GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.dirname(__file__))
SRC = os.path.join(ROOT, "variant_zero.gpx")
axes = ((1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1),
        (2,1,0),(1,2,0),(2,0,1),(1,0,2),(0,2,1),(0,1,2))
for axis in axes:
    tag = "".join(map(str,axis))
    out = os.path.join(ROOT, f"po_zero_{tag}.gpx")
    g = G2sc.G2Project(SRC, newgpx=out)
    h, p = g.histogram(0), g.phase(0)
    po = p.getHAPvalues(h)["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 1.0, True, list(axis)
    g.set_Controls("cycles", 8)
    g.do_refinements([{}])
    g.save(out)
    print("SUMMARY", tag, h.get_wR(), "MD", p.getHAPvalues(h)["Pref.Ori."])
