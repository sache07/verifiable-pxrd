#!/usr/bin/env python3
import os
from GSASII import GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.dirname(__file__))
SRC = os.path.join(ROOT, "linear_WO3_mono.gpx")
OUT = os.path.join(ROOT, "two_phase.gpx")
g = G2sc.G2Project(SRC, newgpx=OUT)
h = g.histogram(0)
mnwo4, wo3 = g.phase(0), g.phase(1)

h.data["Background"][0][1] = True
for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L"):
    h.data["Instrument Parameters"][0][key][2] = True
mnwo4.data["General"]["Cell"][0] = True
for a in mnwo4.atoms(): a.refinement_flags = "X"
mnwo4.getHAPvalues(h)["Scale"][1] = True
mnwo4.getHAPvalues(h)["Pref.Ori."][2] = True
wo3.getHAPvalues(h)["Scale"][1] = True

g.set_Controls("cycles", 16)
g.do_refinements([{}])
print("BASE", h.get_wR(), g.data["Covariance"]["data"].get("Rvals"))
print("CELLS", mnwo4.get_cell_and_esd(), wo3.get_cell())

# Let the weak WO3 lattice follow its resolved peak positions, but hold its
# atomic coordinates at the literature values because its fraction is small.
wo3.data["General"]["Cell"][0] = True
g.do_refinements([{}])
print("CELLREF", h.get_wR(), g.data["Covariance"]["data"].get("Rvals"))
print("CELLS", mnwo4.get_cell_and_esd(), wo3.get_cell_and_esd())
g.save(OUT)

for p in g.phases():
    s = p.HAPvalue("Scale", targethistlist=[h])
    m = p.data["General"]["Mass"]
    print("PHASE", p.name, "scale", s, "mass", m, "product", s*m)
print("INST", h.data["Instrument Parameters"][0])
print("SAMPLE", h.data["Sample Parameters"])
print("RES", h.residuals)
