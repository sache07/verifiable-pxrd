#!/usr/bin/env python3
import os
from GSASII import GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.dirname(__file__))
SRC = os.path.join(ROOT, "po_zero_110.gpx")
cases = {
    "all_X": {"all": "X"},
    "metals_X": {"Mn1": "X", "W1": "X"},
    "oxygen_X": {"O1": "X", "O2": "X"},
    "all_XU": {"all": "XU"},
}
for tag, atoms in cases.items():
    out = os.path.join(ROOT, f"atoms_{tag}.gpx")
    g = G2sc.G2Project(SRC, newgpx=out)
    h, p = g.histogram(0), g.phase(0)
    g.set_Controls("cycles", 12)
    g.do_refinements([{"set": {"Atoms": atoms}}])
    g.save(out)
    print("SUMMARY", tag, h.get_wR(), p.get_cell())
    for a in p.atoms(): print("ATOM", tag, a.label, a.coordinates, repr(a.refinement_flags), a.data[9:17])
