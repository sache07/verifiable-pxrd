#!/usr/bin/env python3
import os
from GSASII import GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.dirname(__file__))
SRC = os.path.join(ROOT, "atoms_all_X.gpx")
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"
cases = {
    "MnO": f"{COD}/1/51/41/1514108.cif",
    "Mn3O4": f"{COD}/1/01/12/1011262.cif",
    "Mn2O3": f"{COD}/1/51/42/1514230.cif",
    "WO3": f"{COD}/1/52/89/1528915.cif",
    "Mn3WO6": f"{COD}/2/00/27/2002703.cif",
}
for name, cif in cases.items():
    out = os.path.join(ROOT, f"secondary_{name}.gpx")
    g = G2sc.G2Project(SRC, newgpx=out)
    h, main = g.histogram(0), g.phase(0)
    sec = g.add_phase(cif, phasename=name, histograms=[h], fmthint="CIF")
    sec.HAPvalue("Scale", 0.1, targethistlist=[h])
    sec.set_HAP_refinements({"Scale": True}, [h])
    g.set_Controls("cycles", 12)
    g.do_refinements([{}])
    g.save(out)
    vals = []
    for p in g.phases():
        scale = p.HAPvalue("Scale", targethistlist=[h])
        mass = p.data["General"]["Mass"]
        vals.append((p.name, scale, mass, scale*mass))
    den = sum(v[3] for v in vals)
    fracs = [(v[0], v[3]/den if den else None) for v in vals]
    print("SUMMARY", name, "wR", h.get_wR(), "vals", vals, "fracs", fracs)
