#!/usr/bin/env python3
import os
from GSASII import GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.dirname(__file__))
DATA = os.path.join(ROOT, "pattern.xye")
IPRM = os.path.join(ROOT, "instrument.instprm")
CIF = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif"

def build(tag, position, po_axis=None):
    out = os.path.join(ROOT, f"variant_{tag}.gpx")
    g = G2sc.G2Project(newgpx=out)
    h = g.add_powder_histogram(DATA, IPRM, fmthint="xye")
    p = g.add_phase(CIF, phasename="MnWO4", histograms=[h], fmthint="CIF")
    h.data["Sample Parameters"]["Scale"][1] = False
    g.set_Controls("cycles", 8)
    g.do_refinements([{"set": {
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12},
        "PhaseFraction": True,
    }}])
    posset = {"Cell": True}
    if position == "zero":
        posset["Instrument Parameters"] = ["Zero"]
    elif position == "dispx":
        posset["Sample Parameters"] = ["DisplaceX"]
    elif position == "both":
        posset["Instrument Parameters"] = ["Zero"]
        posset["Sample Parameters"] = ["DisplaceX"]
    g.do_refinements([{"set": posset}])
    g.do_refinements([{"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]}}])
    if po_axis is not None:
        po = p.getHAPvalues(h)["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", 1.0, True, list(po_axis)
        g.do_refinements([{}])
    g.save(out)
    print("SUMMARY", tag, "wR", h.get_wR(), "res", h.residuals)
    print("CELL", p.get_cell_and_esd())
    print("SAMPLE", h.data["Sample Parameters"])
    print("INST", h.data["Instrument Parameters"][0])
    print("HAP", p.getHAPvalues(h))
    try: print("MASS", h.ComputeMassFracs())
    except Exception as e: print("MASS_ERROR", repr(e))

for pos in ("zero", "dispx", "both"):
    build(pos, pos)
for axis in ((1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(1,1,1)):
    build("dispx_po"+"".join(map(str,axis)), "dispx", axis)
