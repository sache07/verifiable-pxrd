#!/usr/bin/env python3
import os
from GSASII import GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.dirname(__file__))
g = G2sc.G2Project(os.path.join(ROOT, "atoms_all_X.gpx"),
                   newgpx=os.path.join(ROOT, "main_converged.gpx"))
g.set_Controls("cycles", 16)
for i in range(4):
    g.do_refinements([{}])
    h = g.histogram(0)
    print("ROUND", i+1, h.get_wR(), g.data["Covariance"]["data"].get("Rvals"))
g.save()
p = g.phase(0)
print("CELL", p.get_cell_and_esd())
for a in p.atoms(): print("ATOM", a.label, a.coordinates, repr(a.refinement_flags), a.data[9:17])
