#!/usr/bin/env python3
import csv
import json
import os
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.dirname(__file__))
SRC = os.path.join(ROOT, "two_phase_full2.gpx")
FINAL = os.path.join(ROOT, "final.gpx")

g = G2sc.G2Project(SRC, newgpx=FINAL)
g.save(FINAL)
h = g.histogram(0)
phases = g.phases()
phases[0].export_CIF(os.path.join(ROOT, "phase_1_MnWO4.cif"))
phases[1].export_CIF(os.path.join(ROOT, "phase_2_WO3.cif"))

x, yobs, weight, ycalc, ybkg, diff = h.data["data"][1]
lo, hi = h.data["Limits"][1]
mask = (x >= lo) & (x <= hi)
with open(os.path.join(ROOT, "fit.csv"), "w", newline="") as fp:
    writer = csv.writer(fp)
    writer.writerow(["two_theta_deg", "observed", "calculated", "background", "difference"])
    for vals in zip(x[mask], yobs[mask], ycalc[mask], ybkg[mask], diff[mask]):
        writer.writerow([f"{float(v):.12g}" for v in vals])

print("limits", lo, hi, "points", int(mask.sum()))
print("profile_identity_max_abs", float(np.max(np.abs(yobs[mask] - ycalc[mask] - diff[mask]))))
print("residuals", h.residuals)
print("mass_fractions", h.ComputeMassFracs())
print("covariance_rvals", g.data["Covariance"]["data"].get("Rvals"))
for p in phases:
    print("phase", p.name, "cell", p.get_cell_and_esd())
    for a in p.atoms():
        print("atom", p.name, a.label, a.element, a.coordinates, a.occupancy, a.data[9:17])
