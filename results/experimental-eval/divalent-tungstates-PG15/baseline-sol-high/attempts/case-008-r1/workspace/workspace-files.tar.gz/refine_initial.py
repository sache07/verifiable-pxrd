#!/usr/bin/env python3
import json
import os
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.dirname(__file__))
DATA = os.path.join(ROOT, "pattern.xye")
IPRM = os.path.join(ROOT, "instrument.instprm")
CIF = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif"
GPX = os.path.join(ROOT, "trial_mnwo4.gpx")

gpx = G2sc.G2Project(newgpx=GPX)
hist = gpx.add_powder_histogram(DATA, IPRM, fmthint="xye")
phase = gpx.add_phase(CIF, phasename="MnWO4", histograms=[hist], fmthint="CIF")
gpx.set_Controls("cycles", 6)
print("hist", hist.name)
print("sample", hist.data["Sample Parameters"])
print("inst", hist.data["Instrument Parameters"][0])
print("cell0", phase.get_cell())
print("hap0", phase.getHAPvalues(hist))

steps = [
    {"set": {"Limits": [10.0, 100.0],
              "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12},
              "PhaseFraction": True}},
    {"set": {"Cell": True, "Instrument Parameters": ["Zero"]}},
    {"set": {"Instrument Parameters": ["U", "V", "W", "X", "Y"]}},
    {"set": {"Mustrain": {"type": "isotropic", "refine": True, "value": 1000.0},
              "Size": {"type": "isotropic", "refine": True, "value": 1.0}}},
]
for i, step in enumerate(steps, 1):
    print("STEP", i, step)
    gpx.do_refinements([step])
    print("residuals", hist.residuals)
    print("cell", phase.get_cell())
    print("inst", hist.data["Instrument Parameters"][0])
    print("scale", phase.HAPvalue("Scale", targethistlist=[hist]))

gpx.save(GPX)
print("massfracs", hist.ComputeMassFracs())
print("final residuals", hist.residuals)
print("final cell", phase.get_cell_and_esd())
print("final HAP", phase.getHAPvalues(hist))
