#!/usr/bin/env python3
"""Build and refine a two-phase GSAS-II model for the supplied PXRD pattern."""

import csv
import json
import math
import os

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = os.path.abspath(os.path.dirname(__file__))
PATTERN = os.path.join(ROOT, "inputs", "pattern.csv")
XYE = os.path.join(ROOT, "pattern.xye")
GPX = os.path.join(ROOT, "final.gpx")
INSTRUMENT = os.path.join(ROOT, "instrument.instprm")
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"


def cod_cif(cod_id):
    return os.path.join(COD, cod_id[0], cod_id[1:3], cod_id[3:5], cod_id + ".cif")


def make_xye():
    data = np.loadtxt(PATTERN, delimiter=",", skiprows=1)
    # No point uncertainties were supplied. Poisson counting uncertainties are
    # the least-assumptive choice for the original count data.
    sigma = np.sqrt(np.maximum(data[:, 1], 1.0))
    np.savetxt(XYE, np.column_stack((data, sigma)), fmt="%.8f %.8f %.8f")


def summary(proj, label):
    h = proj.histogram(0)
    cells = {p.name: p.get_cell() for p in proj.phases()}
    scales = {p.name: p.HAPvalue("Scale", targethistlist=[h]) for p in proj.phases()}
    print(label, "residuals=", h.residuals)
    print(label, "cells=", cells)
    print(label, "scales=", scales)
    print(label, "instrument=", {k: v for k, v in h.InstrumentParameters.items()
                                   if k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "SH/L")})


def build_and_refine():
    make_xye()
    proj = G2sc.G2Project(newgpx=GPX)
    hist = proj.add_powder_histogram(XYE, INSTRUMENT, fmthint="xye")
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "no. coeffs": 12, "refine": True},
    })

    # Room-temperature gamma-WO3 (monoclinic P21/n, an alternative setting of
    # P21/c) and unreacted tetragonal BaO2 are the phase models. COD 1528915
    # gave the best whole-pattern match among the tested WO3 polymorph models.
    wo3 = proj.add_phase(cod_cif("1528915"), phasename="WO3_monoclinic",
                         histograms=[hist], fmthint="CIF")
    bao2 = proj.add_phase(cod_cif("1010113"), phasename="BaO2_tetragonal",
                          histograms=[hist], fmthint="CIF")

    wo3.HAPvalue("Scale", 1.0, [hist])
    bao2.HAPvalue("Scale", 0.6, [hist])
    # GSAS-II initializes the Bragg-Brentano specimen scale as variable. It is
    # redundant with all HAP phase scales, so fix it to prevent an SVD null mode.
    hist.SampleParameters["Scale"] = [1.0, False]
    proj.set_Controls("cycles", 12)

    # Stage parameters to avoid strong scale/background/profile correlations.
    stages = [
        {"set": {"Scale": True}},
        {"set": {"Cell": True}},
        {"set": {"Instrument Parameters": ["Zero"]}},
        # W, X and Y supply one Gaussian and two Lorentzian profile terms.
        # U and V remain at the nominal laboratory values because all five
        # terms were highly correlated without a calibrated profile standard.
        {"set": {"Instrument Parameters": ["W", "X", "Y"]}},
        {},
    ]
    for i, stage in enumerate(stages, 1):
        proj.do_refinements([stage])
        summary(proj, f"stage{i}")

    proj.save(GPX)
    return proj


def write_outputs(proj):
    hist = proj.histogram(0)
    phase_cifs = {
        "WO3_monoclinic": "phase_WO3.cif",
        "BaO2_tetragonal": "phase_BaO2.cif",
    }
    for name, relpath in phase_cifs.items():
        proj.phase(name).export_CIF(os.path.join(ROOT, relpath))

    x = np.asarray(hist.getdata("X"), float)
    yobs = np.asarray(hist.getdata("Yobs"), float)
    ycalc = np.asarray(hist.getdata("Ycalc"), float)
    bkg = np.asarray(hist.getdata("Background"), float)
    # Explicitly compute observed-calculated so the identity remains true at
    # the handful of points outside the 10-100 degree refinement limits, where
    # GSAS-II leaves its stored residual array at zero.
    diff = yobs - ycalc
    with open(os.path.join(ROOT, "fit.csv"), "w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
        writer.writerows(zip(x, yobs, ycalc, diff, bkg))

    fractions = hist.ComputeMassFracs()
    residuals = {k: float(v) for k, v in hist.residuals.items()
                 if isinstance(v, (float, int, np.floating, np.integer))}
    phase_meta = {
        "WO3_monoclinic": {"space_group": "P 21/n", "source_cod_id": "1528915"},
        "BaO2_tetragonal": {"space_group": "I 4/m m m", "source_cod_id": "1010113"},
    }
    phases = []
    for name, relpath in phase_cifs.items():
        frac, su = fractions[name]
        cell = proj.phase(name).get_cell()
        phases.append({
            "name": name,
            "formula": "WO3" if name.startswith("WO3") else "BaO2",
            **phase_meta[name],
            "cif_path": relpath,
            "weight_fraction": float(frac),
            "weight_fraction_esd": float(su),
            "refined_cell": {key: float(value) for key, value in cell.items()},
        })
    chi2 = ((residuals.get("wR") / residuals.get("wRmin")) ** 2
            if residuals.get("wRmin") else None)
    result = {
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": residuals.get("wR"),
            "Rp_percent": residuals.get("R"),
            "Rwp_background_subtracted_percent": residuals.get("wRb"),
            "Rp_background_subtracted_percent": residuals.get("Rb"),
            "expected_Rwp_percent": residuals.get("wRmin"),
            "reduced_chi_squared": chi2,
            "goodness_of_fit_sqrt_chi_squared": math.sqrt(chi2) if chi2 else None,
            "points_refined": int(np.count_nonzero((x >= 10.0) & (x <= 100.0))),
        },
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over modeled crystalline phases",
    }
    with open(os.path.join(ROOT, "result.json"), "w") as fp:
        json.dump(result, fp, indent=2)
        fp.write("\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    project = build_and_refine()
    write_outputs(project)
