#!/usr/bin/env python3
"""Compare plausible WO3 polymorph CIFs under the same fixed profile model."""

import os
import numpy as np
from GSASII import GSASIIscriptable as G2sc

ROOT = os.path.abspath(os.path.dirname(__file__))
COD = "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"


def cif(i):
    return os.path.join(COD, i[0], i[1:3], i[3:5], i + ".cif")


profile = {
    "Zero": 0.29595,
    "U": 57.96,
    "V": 533.30,
    "W": -179.29,
    "X": 15.26,
    "Y": 34.35,
}

for cid in ["1010618", "1528915", "2311041", "2106293", "2107312", "1563541"]:
    path = os.path.join(ROOT, ".tmp", f"cmp_{cid}.gpx")
    p = G2sc.G2Project(newgpx=path)
    h = p.add_powder_histogram(os.path.join(ROOT, "pattern.xye"),
                               os.path.join(ROOT, "instrument.instprm"), fmthint="xye")
    h.SampleParameters["Scale"] = [1.0, False]
    for key, val in profile.items():
        h.InstrumentParameters[key][1] = val
        h.InstrumentParameters[key][2] = False
    h.set_refinements({"Limits": [10.0, 100.0],
                       "Background": {"type": "chebyschev-1", "no. coeffs": 12, "refine": True}})
    a = p.add_phase(cif(cid), phasename=f"WO3_{cid}", histograms=[h], fmthint="CIF")
    b = p.add_phase(cif("1010113"), phasename="BaO2", histograms=[h], fmthint="CIF")
    a.HAPvalue("Scale", 3.0, [h]); b.HAPvalue("Scale", 9.0, [h])
    p.set_Controls("cycles", 15)
    p.do_refinements([{"set": {"Scale": True}}, {"set": {"Cell": True}}, {}])
    print("RESULT", cid, h.get_wR(), h.residuals, h.ComputeMassFracs(),
          a.get_cell(), b.get_cell())
