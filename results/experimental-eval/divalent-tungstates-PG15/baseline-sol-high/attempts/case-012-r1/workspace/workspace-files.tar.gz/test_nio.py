from pathlib import Path
from shutil import copyfile
from GSASII import GSASIIscriptable as G2sc
root=Path(__file__).resolve().parent
copyfile(root/'physical_profile.gpx',root/'test_nio.gpx')
g=G2sc.G2Project(str(root/'test_nio.gpx')); h=g.histogram(0)
for p in g.phases():
    for atom in p.atoms(): atom.refinement_flags = ' '
nio=g.add_phase(str(root/'NiO_start.cif'),phasename='NiO',histograms=[h],fmthint='CIF')
nio.HAPvalue('Scale',0.05);nio.set_HAP_refinements({'Scale':True});nio.set_refinements({'Cell':True})
g.set_Controls('cycles',20);g.refine();g.save()
print('wR',h.get_wR(),'massfracs',h.ComputeMassFracs())
print('NiO scale',nio.HAPvalue('Scale'),'cell',nio.get_cell())
print('residuals',h.data['data'][0])
