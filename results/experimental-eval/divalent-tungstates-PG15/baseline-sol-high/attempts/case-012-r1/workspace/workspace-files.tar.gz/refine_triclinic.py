from pathlib import Path
from GSASII import GSASIIscriptable as G2sc
root=Path(__file__).resolve().parent
g=G2sc.G2Project(newgpx=str(root/'triclinic_test.gpx'))
h=g.add_powder_histogram(str(root/'pattern.xye'),str(root/'lab_cuka.instprm'),fmthint='xye')
p1=g.add_phase(str(root/'NiWO4_start.cif'),phasename='NiWO4',histograms=[h],fmthint='CIF')
p2=g.add_phase(str(root/'WO3_triclinic_start.cif'),phasename='WO3_triclinic',histograms=[h],fmthint='CIF')
h.data['Sample Parameters']['Scale']=[1.0,False]
inst=h.data['Instrument Parameters'][0]
for key,val in {'U':0.0,'V':0.0,'W':40.0,'X':5.0,'Y':0.0,'SH/L':0.002}.items(): inst[key][1:]=[val,False]
g.set_Controls('cycles',15);h.set_refinements({'Limits':[10.01,99.99]})
h.set_refinements({'Background':{'type':'chebyschev-1','no. coeffs':12,'refine':True}})
for p in (p1,p2): p.set_HAP_refinements({'Scale':True})
g.refine()
for p in (p1,p2): p.set_refinements({'Cell':True})
h.set_refinements({'Instrument Parameters':['Zero','W','X']});g.refine()
p1.set_refinements({'Atoms':{'all':'X'}});g.refine()
p2.set_refinements({'Atoms':{'all':'X'}});g.refine();g.save()
print('wR',h.get_wR(),'mass',h.ComputeMassFracs())
print('residuals',h.data['data'][0])
print('inst',{k:v[1:] for k,v in inst.items() if k in ('Zero','U','V','W','X','Y','SH/L')})
for p in (p1,p2):print(p.name,p.get_cell())
