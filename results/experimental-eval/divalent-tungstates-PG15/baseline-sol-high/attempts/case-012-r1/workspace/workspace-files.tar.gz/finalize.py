from pathlib import Path
from shutil import copyfile
import csv
import json
import math
import numpy as np
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
copyfile(root / 'physical_profile.gpx', root / 'final.gpx')
g = G2sc.G2Project(str(root / 'final.gpx'))
h = g.histogram(0)
h.data['Limits'][1] = list(h.data['Limits'][0])

# Freeze coordinates at the values established in the structural refinement;
# finish the quantitative refinement with lattice, scales, background and the
# deliberately compact W/X profile model active.
for phase in g.phases():
    for atom in phase.atoms():
        atom.refinement_flags = ' '
g.set_Controls('cycles', 20)
for _ in range(1):
    g.refine()
g.save(str(root / 'final.gpx'))

# Reload the submitted project and create all reported products from it.
g = G2sc.G2Project(str(root / 'final.gpx'))
h = g.histogram(0)
p_nwo = g.phase('NiWO4')
p_wo3 = g.phase('WO3')
p_nwo.export_CIF(str(root / 'NiWO4.cif'))
p_wo3.export_CIF(str(root / 'WO3.cif'))

mass = h.ComputeMassFracs()
res = h.data['data'][0]
rvals = g.data['Covariance']['data']['Rvals']
rwp = float(h.get_wR())
rexp = float(res['wRmin'])
gof = float(rvals['GOF'])
chisq = float(rvals['chisq'])
nobs = int(rvals['Nobs'])
nvars = int(rvals['Nvars'])

x = np.asarray(h.getdata('X'), dtype=float)
yobs = np.asarray(h.getdata('Yobs'), dtype=float)
ycalc = np.asarray(h.getdata('Ycalc'), dtype=float)
ybkg = np.asarray(h.getdata('Background'), dtype=float)
ydiff = yobs - ycalc
with open(root / 'fit.csv', 'w', newline='') as fp:
    w = csv.writer(fp)
    w.writerow(['two_theta_deg', 'observed_intensity', 'calculated_intensity',
                'difference_intensity', 'background_intensity'])
    for row in zip(x, yobs, ycalc, ydiff, ybkg):
        w.writerow([f'{v:.10g}' for v in row])

phase_specs = [
    ('NiWO4', 'NiWO4', 'P 1 2/c 1', 'NiWO4.cif'),
    ('WO3', 'WO3', 'P 1 21/n 1', 'WO3.cif'),
]
phases = []
for name, formula, sg, cifname in phase_specs:
    phase = g.phase(name)
    frac, su = mass[name]
    phases.append({
        'name': name,
        'formula': formula,
        'space_group': sg,
        'cif_path': cifname,
        'weight_fraction': float(frac),
        'weight_fraction_esd': float(su),
        'weight_percent': 100.0 * float(frac),
        'cell': {k: float(v) for k, v in phase.get_cell().items()},
        'R_F_squared_percent': float(res[f'{phase.id}:0:Rf^2']),
    })

result = {
    'phases': phases,
    'weight_fraction_basis': 'Normalized over the modeled crystalline phases; amorphous content not determined.',
    'fit_statistics': {
        'Rwp_percent': rwp,
        'Rp_percent': float(res['R']),
        'Rexp_percent': rexp,
        'goodness_of_fit': gof,
        'chi_squared': chisq,
        'reduced_chi_squared': chisq / (nobs - nvars),
        'N_observations': nobs,
        'N_refined_variables': nvars,
        'two_theta_refinement_limits_deg': [float(v) for v in h.data['Limits'][1]],
        'profile_data_range_deg': [float(x.min()), float(x.max())],
        'Durbin_Watson': float(res['Durbin-Watson']),
    },
    'measurement_model': {
        'radiation': 'Cu K-alpha1/K-alpha2',
        'wavelength_Kalpha1_angstrom': 1.540598,
        'wavelength_Kalpha2_angstrom': 1.544426,
        'Kalpha2_to_Kalpha1_ratio': 0.5,
        'uncertainty_model': 'Poisson counting weights (sigma=sqrt(counts)); input supplied no pointwise uncertainties.',
    },
    'project_path': 'final.gpx',
    'profile_path': 'fit.csv',
}
with open(root / 'result.json', 'w') as fp:
    json.dump(result, fp, indent=2)
    fp.write('\n')

print(json.dumps(result, indent=2))
