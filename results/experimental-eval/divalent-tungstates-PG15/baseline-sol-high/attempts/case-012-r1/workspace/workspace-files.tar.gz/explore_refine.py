from pathlib import Path
import numpy as np
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
gpx = G2sc.G2Project(newgpx=str(root / 'explore.gpx'))
h = gpx.add_powder_histogram(str(root / 'pattern.xye'), str(root / 'lab_cuka.instprm'), fmthint='xye')
p = gpx.add_phase(str(root / 'NiWO4_start.cif'), phasename='NiWO4', histograms=[h], fmthint='CIF')
gpx.set_Controls('cycles', 8)
h.set_refinements({'Limits': [10.01, 99.99]})

def report(tag):
    inst = h.data['Instrument Parameters'][0]
    print('\nREPORT', tag, 'wR', h.get_wR())
    print('cell', p.get_cell())
    print('scale', p.HAPvalue('Scale'))
    print('inst', {k: v[1] for k,v in inst.items() if k in ('Lam1','Lam2','I(L2)/I(L1)','Zero','U','V','W','X','Y','Z','SH/L')})
    print('residuals', h.data['data'][0])

# Stable staged refinement: scale/background, lattice/zero, then profile.
h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
p.set_HAP_refinements({'Scale': True})
gpx.refine()
report('scale_background')

p.set_refinements({'Cell': True})
h.set_refinements({'Instrument Parameters': ['Zero']})
gpx.refine()
report('cell_zero')

h.set_refinements({'Instrument Parameters': ['U','V','W','X','Y','SH/L']})
gpx.refine()
report('profile')

# Atomic coordinates and common isotropic displacement parameters are tested last.
p.set_refinements({'Atoms': {'all': 'XU'}})
gpx.refine()
report('atoms')
gpx.save(str(root / 'explore.gpx'))

x = np.asarray(h.getdata('X'))
yo = np.asarray(h.getdata('Yobs'))
yc = np.asarray(h.getdata('Ycalc'))
yb = np.asarray(h.getdata('Background'))
with open(root / 'explore_fit.csv', 'w') as out:
    out.write('two_theta_deg,y_obs,y_calc,y_bkg,y_diff\n')
    for row in zip(x,yo,yc,yb,yo-yc):
        out.write(','.join(f'{v:.10g}' for v in row)+'\n')

for a in p.atoms():
    print('atom', a.label, a.element, a.coordinates, a.uiso, a.refinement_flags)
