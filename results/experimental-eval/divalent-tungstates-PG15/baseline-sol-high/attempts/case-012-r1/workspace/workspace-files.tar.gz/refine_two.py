from pathlib import Path
import numpy as np
from GSASII import GSASIIscriptable as G2sc

root = Path(__file__).resolve().parent
gpx = G2sc.G2Project(newgpx=str(root / 'two_phase.gpx'))
h = gpx.add_powder_histogram(str(root / 'pattern.xye'), str(root / 'lab_cuka.instprm'), fmthint='xye')
p1 = gpx.add_phase(str(root / 'NiWO4_start.cif'), phasename='NiWO4', histograms=[h], fmthint='CIF')
p2 = gpx.add_phase(str(root / 'WO3_start.cif'), phasename='WO3', histograms=[h], fmthint='CIF')
h.data['Sample Parameters']['Scale'] = [1.0, False]
inst = h.data['Instrument Parameters'][0]
for key, val in {'U':100.0, 'V':0.0, 'W':50.0, 'X':10.0, 'Y':0.0, 'SH/L':0.002}.items():
    inst[key][1] = val
    inst[key][2] = False
gpx.set_Controls('cycles', 12)
h.set_refinements({'Limits': [10.01, 99.99]})

def report(tag):
    print('\nREPORT', tag, 'wR', h.get_wR())
    print('NiWO4', p1.get_cell(), 'scale', p1.HAPvalue('Scale'))
    print('WO3', p2.get_cell(), 'scale', p2.HAPvalue('Scale'))
    print('inst', {k: v[1] for k,v in inst.items() if k in ('Zero','U','V','W','X','Y','SH/L')})
    print('residuals', h.data['data'][0])

h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 12, 'refine': True}})
for p in (p1,p2): p.set_HAP_refinements({'Scale': True})
gpx.refine(); report('scale_background')

for p in (p1,p2): p.set_refinements({'Cell': True})
h.set_refinements({'Instrument Parameters': ['Zero']})
gpx.refine(); report('cells_zero')

h.set_refinements({'Instrument Parameters': ['U','V','W','X']})
gpx.refine(); report('profile')

p1.set_refinements({'Atoms': {'all': 'X'}})
gpx.refine(); report('NiWO4_coords')

p2.set_refinements({'Atoms': {'all': 'X'}})
gpx.refine(); report('all_coords')

gpx.save(str(root / 'two_phase.gpx'))
x = np.asarray(h.getdata('X')); yo = np.asarray(h.getdata('Yobs'))
yc = np.asarray(h.getdata('Ycalc')); yb = np.asarray(h.getdata('Background'))
with open(root / 'two_fit.csv', 'w') as out:
    out.write('two_theta_deg,y_obs,y_calc,y_bkg,y_diff\n')
    for row in zip(x,yo,yc,yb,yo-yc): out.write(','.join(f'{v:.10g}' for v in row)+'\n')
print('massfracs',h.ComputeMassFracs())
for p in (p1,p2):
    print('PHASE',p.name)
    for a in p.atoms(): print('atom', a.label, a.element, a.coordinates, a.uiso, a.refinement_flags)
