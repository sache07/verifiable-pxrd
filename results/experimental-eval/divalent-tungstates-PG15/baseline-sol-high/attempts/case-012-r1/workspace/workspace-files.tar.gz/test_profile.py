from pathlib import Path
from shutil import copyfile
from GSASII import GSASIIscriptable as G2sc

root=Path(__file__).resolve().parent
copyfile(root/'two_phase.gpx',root/'physical_profile.gpx')
g=G2sc.G2Project(str(root/'physical_profile.gpx'))
h=g.histogram(0); inst=h.data['Instrument Parameters'][0]
inst['U'][1]=0.0; inst['U'][2]=False
inst['V'][1]=0.0; inst['V'][2]=False
inst['W'][2]=True; inst['X'][2]=True
g.set_Controls('cycles',15)
g.refine();g.save()
print('wR',h.get_wR())
print('inst',{k:v[1:] for k,v in inst.items() if k in ('Zero','U','V','W','X','Y','SH/L')})
print('massfracs',h.ComputeMassFracs())
print('residuals',h.data['data'][0])
for p in g.phases(): print(p.name,p.get_cell())
