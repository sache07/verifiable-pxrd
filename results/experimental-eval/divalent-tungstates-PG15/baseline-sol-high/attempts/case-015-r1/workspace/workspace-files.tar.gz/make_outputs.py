#!/usr/bin/env python3
"""Export the final GSAS-II model and requested deliverables."""

from __future__ import annotations

import csv
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trial_extended.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "ZnWO4": {
        "name": "zinc tungstate (wolframite)",
        "formula": "ZnWO4",
        "space_group": "P 2/c",
        "cif": "phase_zinc_tungstate.cif",
        "reference": "COD 1520641",
    },
    "WO3_1528915": {
        "name": "tungsten(VI) oxide (monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/n",
        "cif": "phase_tungsten_oxide.cif",
        "reference": "COD 1528915",
    },
    "ZnO": {
        "name": "zinc oxide (wurtzite)",
        "formula": "ZnO",
        "space_group": "P 63mc",
        "cif": "phase_zinc_oxide.cif",
        "reference": "COD 9004178",
    },
}


def main() -> None:
    shutil.copy2(SOURCE, FINAL)
    gpx = G2sc.G2Project(str(FINAL))
    hist = gpx.histogram(0)

    # Structural files are exported from the same final project that supplies
    # the profile and phase fractions.
    for phase in gpx.phases():
        phase.export_CIF(str(ROOT / PHASE_INFO[phase.name]["cif"]))

    x, yobs, weight, ycalc, background, difference = hist.data["data"][1]
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity_counts",
                "calculated_intensity_counts",
                "difference_observed_minus_calculated_counts",
                "calculated_background_counts",
            ]
        )
        writer.writerows(
            (xx, yo, yc, yd, yb)
            for xx, yo, yc, yd, yb in zip(x, yobs, ycalc, difference, background)
            if yc != 0.0
        )

    mass_fracs = hist.ComputeMassFracs()
    rvals = gpx.data["Covariance"]["data"]["Rvals"]
    hist_rvals = hist.data["data"][0]
    phases = []
    for phase in gpx.phases():
        info = PHASE_INFO[phase.name]
        frac, frac_esd = mass_fracs[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phases.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "space_group": info["space_group"],
                "cif_path": info["cif"],
                "weight_fraction": frac,
                "weight_fraction_formal_esd": frac_esd,
                "reference_structure": info["reference"],
                "refined_cell": cell,
                "refined_cell_esd": cell_esd,
            }
        )

    fit_stats = {
        "Rwp_percent": rvals["Rwp"],
        "Rexp_percent": rvals["Rwp"] / rvals["GOF"],
        "Rp_percent": hist_rvals["R"],
        "GOF": rvals["GOF"],
        "chi_squared": rvals["chisq"],
        "durbin_watson": hist_rvals["Durbin-Watson"],
        "number_of_observations": rvals["Nobs"],
        "number_of_refined_variables": rvals["Nvars"],
    }
    result = {
        "phases": phases,
        "weight_fraction_basis": "normalized over modeled crystalline phases; sum = 1",
        "fit_statistics": fit_stats,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    report = f"""# PXRD phase analysis

## Result

The crystalline pattern is modeled with three phases:

| Phase | Space group | Weight fraction* |
|---|---:|---:|
| ZnWO4 (wolframite) | P 2/c | {100*phases[0]['weight_fraction']:.2f}% |
| WO3 (monoclinic) | P 21/n | {100*phases[1]['weight_fraction']:.2f}% |
| ZnO (wurtzite) | P 63mc | {100*phases[2]['weight_fraction']:.2f}% |

\*Normalized over the modeled crystalline phases only. No internal standard was present, so an amorphous fraction cannot be measured.

The final GSAS-II Rietveld fit has Rwp = {fit_stats['Rwp_percent']:.2f}%, Rexp = {fit_stats['Rexp_percent']:.2f}%, GOF = {fit_stats['GOF']:.2f}, and Rp = {fit_stats['Rp_percent']:.2f}% over {fit_stats['number_of_observations']} observations (10-100 degrees 2theta). The Cu Kalpha1/Kalpha2 wavelengths and 0.5 intensity ratio were fixed to the metadata values. Because pointwise uncertainties were absent, counting-statistical weights (sigma = sqrt(counts)) were used.

## Evidence

ZnWO4 accounts for the dominant wolframite line set, including the strong features near 18.98, 24.62, 30.69, 36.50, 51.86, and 53.77 degrees 2theta, and is the expected reaction product of ZnO and WO3 at 900 degrees C. Monoclinic WO3 accounts for the characteristic group near 23-25 degrees and additional reflections near 33-34 and 41 degrees. Wurtzite ZnO is supported by its 31.8/34.4/36.3-degree group and higher-angle lines. Under an identical initial protocol, ZnWO4 alone gave Rwp about 18.0%; ZnWO4 + WO3 gave 10.85%; adding ZnO reduced this to 10.05% and gave a low ZnO Bragg R factor. Refining the physically bounded polarization correction and the major-phase coordinates produced the submitted 6.37% fit.

The starting structures were COD 1520641 (ZnWO4), COD 1528915 (WO3), and COD 9004178 (ZnO). Unit cells and phase scales were refined for all phases. Coordinates were refined only for the 76 wt% ZnWO4 phase; minor-phase coordinates were retained from the reference structures because the overlapping laboratory pattern does not determine them independently.

## Remaining uncertainty

The formal least-squares fraction uncertainties are only about 0.1 wt%, but they understate the practical uncertainty. There is no calibrated instrumental profile, no supplied intensity uncertainties, and no particle-size information for a microabsorption correction; the W-rich phases and ZnO have substantially different absorption. The effective polarization was also unspecified: an unconstrained refinement moved above the physical range, so it was fixed at the physical upper bound (1.0). Fractions changed by less than 0.3 wt% between polarization treatments, but a practical uncertainty of roughly 1-2 wt% per phase is more realistic.

Closely related monoclinic/triclinic WO3 descriptions fit nearly equivalently; the higher-symmetry P 21/n model (an alternate setting of the source P 21/c structure) was selected on parsimony and chemical plausibility, so the exact room-temperature WO3 distortion is less certain than the WO3 phase assignment. Residual serial correlation (Durbin-Watson = {fit_stats['durbin_watson']:.2f}) indicates remaining profile/intensity systematics. No additional phase is uniquely required by the residual; a weak, strongly overlapped impurity below roughly 1-2 wt% could remain undetected.
"""
    (ROOT / "report.md").write_text(report)
    gpx.save()


if __name__ == "__main__":
    main()
