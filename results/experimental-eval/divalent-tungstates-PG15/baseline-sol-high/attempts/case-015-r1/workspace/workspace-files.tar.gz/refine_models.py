#!/usr/bin/env python3
"""Build and compare GSAS-II Rietveld models for the supplied PXRD pattern."""

from __future__ import annotations

import json
import math
import os
import shutil
import sys
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INST = ROOT / "cu_kalpha.instprm"
XYE = ROOT / "pattern.xye"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

CIFS = {
    "ZnWO4": COD / "1/52/06/1520641.cif",
    "WO3_2106293": COD / "2/10/62/2106293.cif",
    "WO3_1528915": COD / "1/52/89/1528915.cif",
    "WO3_2311041": COD / "2/31/10/2311041.cif",
    "W18O49": COD / "1/52/81/1528166.cif",
    "ZnO": COD / "9/00/41/9004178.cif",
}

MODELS = {
    "zwo": ["ZnWO4"],
    "zwo_wo3a": ["ZnWO4", "WO3_2106293"],
    "zwo_wo3b": ["ZnWO4", "WO3_1528915"],
    "zwo_wo3c": ["ZnWO4", "WO3_2311041"],
    "zwo_w18": ["ZnWO4", "W18O49"],
    "zwo_zno": ["ZnWO4", "ZnO"],
    "zwo_wo3a_zno": ["ZnWO4", "WO3_2106293", "ZnO"],
    "zwo_wo3b_zno": ["ZnWO4", "WO3_1528915", "ZnO"],
}


def prepare_inputs() -> None:
    p = np.genfromtxt(PATTERN, delimiter=",", names=True)
    # No point uncertainties were supplied. Counting-statistical sigma is the
    # least-assumptive starting weight for raw counts.
    sigma = np.sqrt(np.maximum(p["intensity"], 1.0))
    np.savetxt(XYE, np.c_[p["two_theta_deg"], p["intensity"], sigma], fmt="%.8f %.8f %.8f")
    INST.write_text(
        "#GSAS-II instrument parameter file for lab Cu Kalpha data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:40.0;V:-20.0;W:180.0;X:0.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )


def run_model(tag: str, phase_keys: list[str]) -> dict:
    out = ROOT / f"trial_{tag}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(str(XYE), str(INST), fmthint="xye")
    phases = []
    for key in phase_keys:
        phases.append(gpx.add_phase(str(CIFS[key]), phasename=key, histograms=[hist], fmthint="CIF"))

    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 15},
    })
    # Avoid the exact degeneracy between the overall histogram scale and all
    # phase scales; phase scales alone carry the quantitative information.
    hist.data["Sample Parameters"]["Scale"][1] = False
    for ph in phases:
        ph.set_HAP_refinements({"Scale": True})
    gpx.data["Controls"]["data"]["max cyc"] = 6
    gpx.refine(printFile=str(ROOT / f"trial_{tag}.lst"))

    # Lattice and specimen displacement/zero shift.
    for ph in phases:
        ph.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    gpx.refine(printFile=str(ROOT / f"trial_{tag}.lst"))

    # Gaussian Caglioti profile terms. Lorentzian X/Y are held at zero because
    # they are unsupported by the present broad, heavily overlapped peaks and
    # destabilize model comparison.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    gpx.refine(printFile=str(ROOT / f"trial_{tag}.lst"))

    h = gpx.histogram(0)
    d0 = h.data["data"][0]
    inst = h.data["Instrument Parameters"][0]
    result = {
        "tag": tag,
        "phases": phase_keys,
        "wR_percent": h.get_wR(),
        "Rvals": d0,
        "instrument": {k: v for k, v in inst.items() if k in ["U", "V", "W", "X", "Y", "Zero"]},
        "cells": {ph.name: ph.data["General"]["Cell"] for ph in gpx.phases()},
        "scales": {ph.name: ph.data["Histograms"][h.name]["Scale"] for ph in gpx.phases()},
    }
    gpx.save()
    return result


def main() -> None:
    prepare_inputs()
    requested = sys.argv[1:] or list(MODELS)
    results = []
    for tag in requested:
        print(f"\n===== MODEL {tag}: {MODELS[tag]} =====", flush=True)
        try:
            results.append(run_model(tag, MODELS[tag]))
        except Exception as exc:
            results.append({"tag": tag, "error": repr(exc)})
            print(f"FAILED {tag}: {exc!r}", flush=True)
    (ROOT / "trial_results.json").write_text(json.dumps(results, indent=2, default=str) + "\n")
    print(json.dumps(results, indent=2, default=str))


if __name__ == "__main__":
    main()
