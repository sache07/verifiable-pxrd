#!/usr/bin/env python3
"""Test additional physically motivated parameters on the selected model."""

import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


root = Path(__file__).resolve().parent
source = root / "trial_zwo_wo3b_zno.gpx"
target = root / "trial_extended.gpx"
shutil.copy2(source, target)
gpx = G2sc.G2Project(str(target))
hist = gpx.histogram(0)
gpx.data["Controls"]["data"]["max cyc"] = 10

for item in sys.argv[1:] or ["polarization", "zwo_coords"]:
    if item == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif item == "polarization_one":
        hist.data["Instrument Parameters"][0]["Polariz."][1] = 1.0
        hist.data["Instrument Parameters"][0]["Polariz."][2] = False
    elif item == "zwo_coords":
        gpx.phase("ZnWO4").set_refinements({"Atoms": {"all": "X"}})
    elif item == "zwo_uiso":
        gpx.phase("ZnWO4").set_refinements({"Atoms": {"all": "U"}})
    elif item == "zno_coords":
        gpx.phase("ZnO").set_refinements({"Atoms": {"all": "X"}})
    else:
        raise ValueError(item)
    gpx.refine(printFile=str(root / "trial_extended.lst"))
    print(item, "wR", gpx.histogram(0).get_wR())

gpx.save()
