from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

root=Path(__file__).resolve().parent
gpx=G2sc.G2Project(str(root/'compare_zw_wo3_zno.gpx'),newgpx=str(root/'continued.gpx'))
gpx.set_Controls('cycles',20)
gpx.refine(makeBack=False)
gpx.save()
h=gpx.histogram(0)
print('RESULT',json.dumps({
 'residuals':h.residuals,
 'fractions':h.ComputeMassFracs(),
 'rvals':gpx.data['Covariance']['data']['Rvals'],
 'instrument':h.InstrumentParameters,
 'cells':{p.name:p.get_cell_and_esd() for p in gpx.phases()},
},default=str))
