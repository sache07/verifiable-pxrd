from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
DB = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
CIFS = {
    'ZnWO4': DB / '1/52/06/1520641.cif',
    'WO3': DB / '1/52/89/1528915.cif',
    'ZnO': ROOT / 'zno_clean.cif',
}


def run(tag, names, refine_strain=True, refine_w=False):
    gpx_path = ROOT / f'physical_{tag}.gpx'
    if gpx_path.exists():
        gpx_path.unlink()
    gpx = G2sc.G2Project(newgpx=str(gpx_path))
    h = gpx.add_powder_histogram(str(ROOT/'pattern.xye'), str(ROOT/'cu_doublet_sharp.instprm'), fmthint='xye')
    h.Limits('lower', 10.0)
    h.Limits('upper', 100.0)
    h.SampleParameters['Scale'] = [1.0, False]
    h.set_refinements({'Background': {'type':'chebyschev-1','refine':True,'no. coeffs':12}})
    phases=[]
    for i,name in enumerate(names):
        p=gpx.add_phase(str(CIFS[name]), phasename=name, histograms=[h], fmthint='CIF')
        hap=p.data['Histograms'][h.name]
        hap['Scale']=[1.0 if i==0 else 0.1, True]
        hap['Size'][1][0]=0.1
        phases.append(p)
    gpx.set_Controls('cycles', 12)
    gpx.refine(makeBack=False)
    h.set_refinements({'Instrument Parameters':['Zero']})
    gpx.refine(makeBack=False)
    for p in phases: p.set_refinements({'Cell':True})
    gpx.refine(makeBack=False)
    for p in phases:
        p.set_HAP_refinements({'Size':{'type':'isotropic','value':0.1,'refine':True}},[h])
    gpx.refine(makeBack=False)
    if refine_strain:
        for p in phases:
            p.set_HAP_refinements({'Mustrain':{'type':'isotropic','refine':True}},[h])
        gpx.refine(makeBack=False)
    if refine_w:
        h.set_refinements({'Instrument Parameters':['W']})
        gpx.refine(makeBack=False)
    gpx.save()
    out={
        'tag':tag,'residuals':h.residuals,'fractions':h.ComputeMassFracs(),
        'cells':{p.name:p.get_cell_and_esd() for p in phases},
        'size':{p.name:p.data['Histograms'][h.name]['Size'] for p in phases},
        'mustrain':{p.name:p.data['Histograms'][h.name]['Mustrain'] for p in phases},
        'instrument':h.InstrumentParameters,
    }
    print('RESULT',json.dumps(out,default=str))
    return out


if __name__=='__main__':
    results=[]
    for args in [
        ('three_size',['ZnWO4','WO3','ZnO'],False,False),
        ('three_size_strain',['ZnWO4','WO3','ZnO'],True,False),
        ('three_size_strain_w',['ZnWO4','WO3','ZnO'],True,True),
        ('two_size_strain',['ZnWO4','WO3'],True,False),
    ]:
        try: results.append(run(*args))
        except Exception as e: print('FAIL',args[0],repr(e))
    (ROOT/'physical_summary.json').write_text(json.dumps(results,indent=2,default=str))
