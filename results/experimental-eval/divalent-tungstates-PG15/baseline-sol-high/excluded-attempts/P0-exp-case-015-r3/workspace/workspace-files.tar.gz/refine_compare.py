from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
DB = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
CANDIDATES = {
    'ZnWO4': DB / '1/52/06/1520641.cif',
    'WO3': DB / '1/52/89/1528915.cif',
    'ZnO': ROOT / 'zno_clean.cif',
}


def do_refine(gpx):
    gpx.save()
    gpx.refine(makeBack=False)


def model(tag, names, instrument='cu_doublet.instprm'):
    path = ROOT / f'compare_{tag}.gpx'
    if path.exists():
        path.unlink()
    gpx = G2sc.G2Project(newgpx=str(path))
    hist = gpx.add_powder_histogram(str(ROOT / 'pattern.xye'), str(ROOT / instrument), fmthint='xye')
    hist.Limits('lower', 10.0)
    hist.Limits('upper', 100.0)
    hist.SampleParameters['Scale'][0] = 1.0
    hist.SampleParameters['Scale'][1] = False
    hist.set_refinements({'Background': {'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 12}})
    phases = []
    for i, name in enumerate(names):
        p = gpx.add_phase(str(CANDIDATES[name]), phasename=name, histograms=[hist], fmthint='CIF')
        p.data['Histograms'][hist.name]['Scale'][0] = 1.0 if i == 0 else 0.1
        p.set_HAP_refinements({'Scale': True}, [hist])
        phases.append(p)
    gpx.set_Controls('cycles', 12)
    # Staged refinement: intensity terms, zero, phase metrics, then shared profile.
    do_refine(gpx)
    hist.set_refinements({'Instrument Parameters': ['Zero']})
    do_refine(gpx)
    for p in phases:
        p.set_refinements({'Cell': True})
    do_refine(gpx)
    hist.set_refinements({'Instrument Parameters': ['W', 'X']})
    do_refine(gpx)
    hist.set_refinements({'Instrument Parameters': ['U', 'V', 'Y']})
    do_refine(gpx)
    gpx.save()
    try:
        fractions = hist.ComputeMassFracs()
    except Exception:
        fractions = {p.name: (1.0 if len(phases) == 1 else None, None) for p in phases}
    out = {
        'tag': tag,
        'residuals': hist.residuals,
        'fractions': fractions,
        'cells': {p.name: p.get_cell_and_esd() for p in phases},
        'scale': {p.name: p.data['Histograms'][hist.name]['Scale'] for p in phases},
        'instrument': hist.InstrumentParameters,
        'sample': hist.SampleParameters,
    }
    print('RESULT', json.dumps(out, default=str))
    return out


if __name__ == '__main__':
    cases = [
        ('zw', ['ZnWO4']),
        ('zw_wo3', ['ZnWO4', 'WO3']),
        ('zw_zno', ['ZnWO4', 'ZnO']),
        ('zw_wo3_zno', ['ZnWO4', 'WO3', 'ZnO']),
    ]
    results = []
    for tag, names in cases:
        try:
            results.append(model(tag, names))
        except Exception as err:
            print('FAIL', tag, repr(err))
    (ROOT / 'compare_summary.json').write_text(json.dumps(results, indent=2, default=str))
