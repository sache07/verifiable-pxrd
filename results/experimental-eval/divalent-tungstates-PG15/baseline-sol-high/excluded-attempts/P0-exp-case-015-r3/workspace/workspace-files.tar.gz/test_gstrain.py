from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

root=Path(__file__).resolve().parent
gpx=G2sc.G2Project(str(root/'physical_three_size_w.gpx'),newgpx=str(root/'gstrain.gpx'))
h=gpx.histogram(0)
for p in gpx.phases():
    p.set_HAP_refinements({'Mustrain':{
        'type':'isotropic','refine':True,
        'LGmix':{'value':0.0,'refine':False}
    }},[h])
gpx.set_Controls('cycles',12)
gpx.refine(makeBack=False)
gpx.save()
out={
 'residuals':h.residuals,'fractions':h.ComputeMassFracs(),
 'mustrain':{p.name:p.data['Histograms'][h.name]['Mustrain'] for p in gpx.phases()},
 'size':{p.name:p.data['Histograms'][h.name]['Size'] for p in gpx.phases()},
 'instrument':h.InstrumentParameters,
 'cells':{p.name:p.get_cell_and_esd() for p in gpx.phases()},
}
print('RESULT',json.dumps(out,default=str))
