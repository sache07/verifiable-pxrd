from pathlib import Path
import json
import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
DB = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
CANDIDATES = {
    'ZnWO4': DB / '1/52/06/1520641.cif',
    'ZnO': DB / '9/00/41/9004178.cif',
    'WO3_monoclinic': DB / '1/01/06/1010618.cif',
    'WO3_tetragonal': DB / '1/52/15/1521532.cif',
}


def refine_model(tag, phase_names, instrument='cu_doublet.instprm'):
    out = ROOT / f'trial_{tag}.gpx'
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / 'pattern.xye'), str(ROOT / instrument), fmthint='xye'
    )
    hist.Limits('lower', 10.0)
    hist.Limits('upper', 100.0)
    phases = []
    for name in phase_names:
        phases.append(gpx.add_phase(
            str(CANDIDATES[name]), phasename=name,
            histograms=[hist], fmthint='CIF'
        ))
    gpx.set_Controls('cycles', 8)
    # First stabilize background and phase scales.
    gpx.do_refinements([
        {'set': {
            'Background': {'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 15},
            'Scale': True,
        }},
        {'set': {'Cell': True, 'Instrument Parameters': ['Zero']}},
        {'set': {'Instrument Parameters': ['U', 'V', 'W', 'X', 'Y']}},
        {'set': {'Size': {'type': 'isotropic', 'value': 1.0, 'refine': True}}},
    ], makeBack=False)
    gpx.save()
    result = {
        'tag': tag,
        'phases': phase_names,
        'residuals': hist.residuals,
        'mass_fractions': hist.ComputeMassFracs(),
        'instrument': {k: v for k, v in hist.InstrumentParameters.items()},
        'cells': {p.name: p.get_cell() for p in phases},
        'scales': {p.name: p.data['Histograms'][hist.name]['Scale'] for p in phases},
        'sizes': {p.name: p.data['Histograms'][hist.name]['Size'] for p in phases},
    }
    print(json.dumps(result, indent=2, default=str))
    return result


if __name__ == '__main__':
    models = [
        ('zw_doublet', ['ZnWO4'], 'cu_doublet.instprm'),
        ('zw_k1', ['ZnWO4'], 'cu_kalpha1.instprm'),
        ('zw_mwo3', ['ZnWO4', 'WO3_monoclinic'], 'cu_doublet.instprm'),
        ('zw_zno', ['ZnWO4', 'ZnO'], 'cu_doublet.instprm'),
        ('zw_mwo3_zno', ['ZnWO4', 'WO3_monoclinic', 'ZnO'], 'cu_doublet.instprm'),
        ('zw_two_wo3', ['ZnWO4', 'WO3_monoclinic', 'WO3_tetragonal'], 'cu_doublet.instprm'),
    ]
    results = []
    for tag, phases, inst in models:
        try:
            results.append(refine_model(tag, phases, inst))
        except Exception as err:
            print(f'FAILED {tag}: {err!r}')
    (ROOT / 'trial_summary.json').write_text(json.dumps(results, indent=2, default=str))
