"""Create the requested submission artifacts from the verified GSAS-II replay."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / ".tmp" / "replay-cand"
PROJECT = ROOT / ".tmp" / "mono-final-cand" / "project.gpx"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


replay = json.loads((REPLAY / "replay.json").read_text())
if replay.get("status") != "replayed":
    raise RuntimeError(f"Final project did not replay: {replay}")
if sha256(PROJECT) != replay["project_sha256"]:
    raise RuntimeError("Project changed after its verified replay")

shutil.copy2(PROJECT, ROOT / "final.gpx")
exports = {
    "NiWO4": "phase_NiWO4.cif",
    "WO3": "phase_WO3.cif",
}
for index, phase in enumerate(replay["phases"]):
    shutil.copy2(REPLAY / phase["cif"], ROOT / exports[phase["name"]])

with np.load(REPLAY / "prediction.npz", allow_pickle=False) as archive:
    x = archive["x"].copy()
    observed = archive["observed"].copy()
    calculated = archive["predicted"].copy()
    background = archive["background"].copy()

public = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
if not np.array_equal(x, public[:, 0]) or not np.array_equal(observed, public[:, 1]):
    raise RuntimeError("Replay profile does not use the complete public scan")

np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x, observed, calculated, observed - calculated, background)),
    delimiter=",",
    header="two_theta,observed,calculated,difference,background",
    comments="",
    fmt=["%.8f", "%.8f", "%.10f", "%.10f", "%.10f"],
)

weights = 1.0 / np.maximum(observed, 1.0)
residual = observed - calculated
chi_square = float(np.sum(weights * residual**2))
rwp = float(100.0 * np.sqrt(chi_square / np.sum(weights * observed**2)))
rp = float(100.0 * np.sum(np.abs(residual)) / np.sum(observed))
n_parameters = 55
reduced_chi_square = chi_square / (len(x) - n_parameters)

# Formal scale-covariance uncertainty from the final least-squares fit is
# 0.00148966 for either complementary fraction. Systematic model uncertainty
# is discussed separately in report.md.
fraction_esd = 0.0014896594607953571
result = {
    "phases": [
        {
            "name": phase["name"],
            "space_group": "P2/c" if phase["name"] == "NiWO4" else "P2_1/c",
            "cif_path": exports[phase["name"]],
            "weight_fraction": phase["weight_fraction"],
            "weight_fraction_esd": fraction_esd,
        }
        for phase in replay["phases"]
    ],
    "fit_statistics": {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "chi_square": chi_square,
        "reduced_chi_square": reduced_chi_square,
        "goodness_of_fit": float(np.sqrt(reduced_chi_square)),
        "number_of_observations": int(len(x)),
        "number_of_refined_parameters": n_parameters,
        "weighting": "1/max(observed_counts,1)",
        "profile_source": "zero-optimization atomic replay of final.gpx on the complete observed grid",
    },
    "refinement_histogram": replay["histogram"],
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

print(json.dumps(result, indent=2))
