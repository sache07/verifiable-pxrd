from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
WORK = ROOT / ".tmp" / "models"


def cod_path(record_id: str) -> Path:
    return COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def write_cif(structure: Structure, path: Path) -> None:
    structure = structure.copy()
    structure.remove_oxidation_states()
    CifWriter(structure, symprec=1e-3, significant_figures=10).write_file(path)


WORK.mkdir(parents=True, exist_ok=True)

# Repair COD 5910277. The source mixes symmetry-expanded sites with asymmetric-unit
# sites. Ni1, W1, O1 and O5 form the chemically complete asymmetric unit in P 2/c.
ni_lattice = Lattice.monoclinic(4.600, 5.665, 4.912, 90.5)
ni_repaired = Structure.from_spacegroup(
    "P 1 2/c 1",
    ni_lattice,
    ["Ni", "W", "O", "O"],
    [[0.5, 0.653, 0.25], [0.0, 0.180, 0.25], [0.220, 0.110, -0.040], [0.260, 0.380, 0.390]],
)
write_cif(ni_repaired, WORK / "niwo4_repaired_5910277.cif")

# A modern wolframite coordinate model (COD 1520641, ZnWO4) with Zn -> Ni and
# the NiWO4 cell from COD 5910277 provides an independent starting model.
zn = Structure.from_file(cod_path("1520641"), primitive=False)
for idx, site in enumerate(zn):
    if site.specie.symbol == "Zn":
        zn.replace(idx, "Ni")
ni_analogue = Structure(ni_lattice, zn.species, zn.frac_coords)
write_cif(ni_analogue, WORK / "niwo4_from_znwo4_1520641.cif")

# Normalize the most plausible ambient WO3 references into CIFs accepted
# consistently by the scriptable GSAS-II importer.
for record_id in ("1528915", "2311041", "2106293", "2107312", "1010618"):
    structure = Structure.from_file(cod_path(record_id), primitive=False)
    write_cif(structure, WORK / f"wo3_{record_id}.cif")

# Residual precursor controls.
for record_id, name in (("1010093", "nio_1010093"),):
    structure = Structure.from_file(cod_path(record_id), primitive=False)
    write_cif(structure, WORK / f"{name}.cif")

# GSAS-II's xye reader interprets column 3 as sigma. Poisson weights reproduce
# the weighting used for the requested reported Rwp.
x, y = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1).T
np.savetxt(WORK / "pattern.xye", np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]), fmt="%.8f %.8f %.8f")

print(WORK)
