"""Project refined displacement directions onto physically justified RMS bounds."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def parse_targets(text: str) -> dict[str, float]:
    result = {}
    for item in text.split(","):
        key, value = item.split("=", 1)
        result[key] = float(value)
    return result


def phase(project, name):
    for item in project.phases():
        if item.name == name:
            return item
    raise ValueError(name)


def run(args):
    G2.SetPrintLevel("warn")
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
    target_phase = phase(project, args.phase)

    parent_project = G2.G2Project(newgpx=str(out / "parent-import.gpx"))
    parent_phase = parent_project.add_phase(str(Path(args.parent).resolve()), phasename="parent", fmthint="CIF")
    current_atoms = target_phase.atoms()
    parent_atoms = parent_phase.atoms()
    if len(current_atoms) != len(parent_atoms):
        raise ValueError("Parent and project asymmetric units differ")
    if [a.element for a in current_atoms] != [a.element for a in parent_atoms]:
        raise ValueError("Parent and project atom ordering differs")

    targets = parse_targets(args.targets)
    lattice = np.asarray(parent_phase.data["General"]["Cell"][1:7], float)
    # Convert with the parent CIF's direct-lattice matrix through GSAS-II's
    # reciprocal metric representation already available in the phase object.
    from GSASII import GSASIIlattice as G2lat
    direct, _ = G2lat.cell2AB(lattice)
    deltas = np.asarray([a.coordinates for a in current_atoms]) - np.asarray([a.coordinates for a in parent_atoms])
    deltas -= np.rint(deltas)

    before = {}
    after = {}
    for element, target in targets.items():
        indices = [i for i, atom in enumerate(current_atoms) if atom.element == element]
        if not indices:
            raise ValueError(f"No {element} atoms")
        distances = np.linalg.norm(deltas[indices] @ direct, axis=1)
        rms = float(np.sqrt(np.mean(distances ** 2)))
        if rms <= 1e-12:
            raise ValueError(f"No refined displacement direction for {element}")
        deltas[indices] *= target / rms
        before[element] = rms
        after[element] = target

    for index, (atom, parent_atom) in enumerate(zip(current_atoms, parent_atoms)):
        if atom.element in targets:
            atom.coordinates = (np.asarray(parent_atom.coordinates) + deltas[index]) % 1.0
        atom.refinement_flags = atom.refinement_flags.replace("X", "")

    project.save(str(out / "project.gpx"))
    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save(str(out / "project.gpx"))
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    x, obs, calc, bkg = (np.asarray(arrays[i], float) for i in (0, 1, 3, 4))
    np.savetxt(out / "fit.csv", np.column_stack([x, obs, calc, obs-calc, bkg]), delimiter=",",
               header="two_theta_deg,observed,calculated,difference,background", comments="")
    report = {"phase": args.phase, "targets_A": targets, "input_rms_A": before,
              "output_rms_A": after, "cycles": args.cycles,
              "residuals": {k: (float(v) if isinstance(v, (int, float, np.number)) else v)
                            for k, v in hist.residuals.items()}}
    (out / "clamp.json").write_text(json.dumps(report, indent=2) + "\n")
    if not args.quiet:
        print(json.dumps(report, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--parent", required=True)
    parser.add_argument("--targets", required=True, help="Element=rms,... in angstrom")
    parser.add_argument("--cycles", type=int, default=0)
    parser.add_argument("--quiet", action="store_true")
    run(parser.parse_args())


if __name__ == "__main__":
    main()
