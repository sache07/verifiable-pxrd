"""Run a reproducible GSAS-II trial refinement for candidate Ni-W-O phases."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2


def instrument_text() -> str:
    return (
        "# GSAS-II Cu K-alpha laboratory Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:12.0;V:0.0;W:12.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def summarize(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    def plain(value):
        if isinstance(value, (int, float, np.number)):
            return float(value)
        return value
    result = {
        "step": label,
        "residuals": {k: plain(v) for k, v in hist.residuals.items()},
        "instrument": {k: v[1] if isinstance(v, list) and len(v) > 1 else v
                       for k, v in hist.InstrumentParameters.items()},
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "mass": float(phase.data["General"]["Mass"]),
        })
    return result


def run_refinement(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    inst = out / "instrument.instprm"
    inst.write_text(instrument_text())

    project = G2.G2Project(newgpx=str(out / "trial.gpx"))
    hist = project.add_powder_histogram(str(Path(args.pattern).resolve()), str(inst), fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({
        "Limits": [10.02, 99.98],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": args.background_terms,
            "coeffs": [800.0] + [0.0] * (args.background_terms - 1),
            "refine": True,
        },
    })

    phase_specs = [("NiWO4", args.ni), ("WO3", args.wo)]
    if args.nio:
        phase_specs.append(("NiO", args.nio))
    phases = [
        project.add_phase(str(Path(path).resolve()), phasename=name, histograms=[hist], fmthint="CIF")
        for name, path in phase_specs
    ]

    # Positive scales, with an approximate mass-normalized starting inventory.
    fractions = [0.72, 0.28] if len(phases) == 2 else [0.69, 0.28, 0.03]
    for phase, fraction in zip(phases, fractions):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 * fraction / float(phase.data["General"]["Mass"]), True]
        phase.setSampleProfile(hist, "size", "isotropic", 0.4)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 800.0)
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]

    project.set_Controls("cycles", 8)
    history = []

    def refine(label: str) -> None:
        project.refine()
        history.append(summarize(project, label))
        project.save(str(out / "trial.gpx"))

    refine("background_scales")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine("cells")

    # Constant zero first; specimen displacement is separated in a later cycle.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine("zero")
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine("zero_shift")

    # Refine the instrumental profile before adding specimen broadening.
    profile_parameters = ["U", "W", "X", "SH/L"] if args.physical_profile else ["U", "V", "W", "X", "Y", "SH/L"]
    hist.set_refinements({"Instrument Parameters": profile_parameters})
    refine("instrument_profile")

    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine("isotropic_size")
    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine("isotropic_microstrain")

    # Refine the two cation y coordinates and oxygen positions in NiWO4. For
    # WO3, coordinates are left fixed in screening trials to avoid comparing
    # variants by over-parameterization.
    if args.refine_atoms:
        phases[0].set_refinements({"Atoms": {"all": "XU"}})
        refine("niwo4_atoms")

    project.save(str(out / "trial.gpx"))
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    x, obs, calc, bkg = (np.asarray(arrays[i], dtype=float) for i in (0, 1, 3, 4))
    np.savetxt(out / "fit.csv", np.column_stack([x, obs, calc, obs - calc, bkg]),
               delimiter=",", header="two_theta_deg,observed,calculated,difference,background", comments="")
    (out / "history.json").write_text(json.dumps(history, indent=2, default=str) + "\n")
    print(json.dumps(history[-1], indent=2, default=str))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", required=True)
    parser.add_argument("--ni", required=True)
    parser.add_argument("--wo", required=True)
    parser.add_argument("--nio")
    parser.add_argument("--out", required=True)
    parser.add_argument("--background-terms", type=int, default=15)
    parser.add_argument("--refine-atoms", action="store_true")
    parser.add_argument("--physical-profile", action="store_true")
    args = parser.parse_args()
    try:
        run_refinement(args)
    except Exception:
        Path(args.out).mkdir(parents=True, exist_ok=True)
        (Path(args.out) / "error.log").write_text(traceback.format_exc())
        raise


if __name__ == "__main__":
    main()
