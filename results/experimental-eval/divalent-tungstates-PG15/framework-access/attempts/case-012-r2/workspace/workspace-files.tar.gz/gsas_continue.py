"""Continue a GSAS-II refinement while preserving a complete project trail."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def parse_axis(value: str) -> list[int]:
    axis = [int(v) for v in value.split(",")]
    if len(axis) != 3 or not any(axis):
        raise argparse.ArgumentTypeError("axis must be three comma-separated integers")
    return axis


def phase_by_name(project: G2.G2Project, name: str):
    for phase in project.phases():
        if phase.name == name:
            return phase
    raise ValueError(f"No phase named {name}")


def summary(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"])
        scale = float(hap["Scale"][0])
        masses.append(mass * scale)
        phases.append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "mass": mass,
            "scale": scale,
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": [{"label": a.label, "element": a.element, "xyz": list(a.coordinates),
                       "uiso": float(a.uiso), "flags": a.refinement_flags} for a in phase.atoms()],
        })
    total = sum(masses)
    for row, mass in zip(phases, masses):
        row["weight_fraction"] = mass / total
    return {
        "step": label,
        "residuals": {k: (float(v) if isinstance(v, (int, float, np.number)) else v)
                      for k, v in hist.residuals.items()},
        "instrument": {k: (v[1] if isinstance(v, list) and len(v) > 1 else v)
                       for k, v in hist.InstrumentParameters.items()},
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": phases,
    }


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
    # Change the active filename before any operation (notably add_phase) that
    # may save implicitly, so the source project remains immutable.
    project.save(str(out / "project.gpx"))
    hist = project.histogram(0)
    for item in args.add_phase:
        name, path = item.split(":", 1)
        phase = project.add_phase(str(Path(path).resolve()), phasename=name, histograms=[hist], fmthint="CIF")
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [0.1, True]
        phase.setSampleProfile(hist, "size", "isotropic", 0.4)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 800.0)
    project.save(str(out / "project.gpx"))
    project.set_Controls("cycles", args.cycles)

    for item in args.set_instrument:
        key, value = item.split(":", 1)
        if key not in hist.InstrumentParameters:
            raise ValueError(f"Unknown instrument parameter {key}")
        hist.InstrumentParameters[key][1] = float(value)
    if args.fix_instrument:
        hist.clear_refinements({"Instrument Parameters": args.fix_instrument})

    # Optional deterministic profile restarts are useful when a screening fit
    # has driven a broadening term to a numerical boundary.  Values use the
    # native GSAS-II units (micrometres for size and ppm for microstrain).
    for item in args.set_size:
        name, value = item.split(":", 1)
        phase = phase_by_name(project, name)
        phase.setSampleProfile(hist, "size", "isotropic", float(value))
    for item in args.set_strain:
        name, value = item.split(":", 1)
        phase = phase_by_name(project, name)
        phase.setSampleProfile(hist, "microstrain", "isotropic", float(value))
    for name in args.fix_size:
        phase = phase_by_name(project, name)
        phase.data["Histograms"][hist.name]["Size"][2] = [False, False, False]
    for name in args.fix_strain:
        phase = phase_by_name(project, name)
        phase.data["Histograms"][hist.name]["Mustrain"][2] = [False, False, False]
    if (args.set_instrument or args.fix_instrument or args.set_size or args.set_strain
            or args.fix_size or args.fix_strain):
        project.set_Frozen()
        project.save(str(out / "project.gpx"))
    if args.generator_bounds:
        # Keep refinable nuisance parameters within the documented laboratory
        # generator ranges. GSAS-II clips and freezes any variable that tries
        # to leave one of these intervals.
        bounds = {
            ":0:Zero": (-0.25, 0.25), ":0:Polariz.": (0.5, 1.0),
            ":0:U": (0.0, 40.0), ":0:W": (2.0, 40.0),
            ":0:X": (0.1, 6.0), ":0:SH/L": (0.005, 0.1),
            ":0:Shift": (-800.0, 800.0),
        }
        for phase in project.phases():
            bounds[f"{phase.id}:0:Size;i"] = (0.04, 1.5)
            bounds[f"{phase.id}:0:Mustrain;i"] = (0.0, 8000.0)
            for index, _atom in enumerate(phase.atoms()):
                bounds[f"{phase.id}::AUiso:{index}"] = (0.003, 0.02)
        project.set_Frozen()
        for variable, (lower, upper) in bounds.items():
            project.set_Controls("parmMin", lower, variable)
            project.set_Controls("parmMax", upper, variable)
        project.save(str(out / "project.gpx"))
    if args.clear_phase_constraints:
        project.data["Constraints"]["data"]["Phase"] = []
        project.save(str(out / "project.gpx"))
    history = [summary(project, "input")]

    def refine(label: str) -> None:
        project.refine()
        project.save(str(out / "project.gpx"))
        history.append(summary(project, label))

    if args.physical_profile:
        inst = hist.InstrumentParameters
        for key in ("V", "Y", "Z"):
            inst[key][1] = 0.0
        hist.clear_refinements({"Instrument Parameters": ["V", "Y", "Z"]})
        starts = {"U": 20.0, "W": 20.0, "X": 2.0, "SH/L": 0.03}
        ranges = {"U": (0.0, 40.0), "W": (2.0, 40.0),
                  "X": (0.1, 6.0), "SH/L": (0.005, 0.1)}
        for key, (lower, upper) in ranges.items():
            if not lower <= float(inst[key][1]) <= upper:
                inst[key][1] = starts[key]
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        refine("physical_profile")

    if args.add_phase:
        refine("added_phase")

    if args.polarization:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        refine("polarization")

    if args.background_terms:
        old = list(hist.Background[0][3:])
        coeffs = (old + [0.0] * args.background_terms)[:args.background_terms]
        hist.set_refinements({"Background": {"type": "chebyschev-1",
                                              "no. coeffs": args.background_terms,
                                              "coeffs": coeffs, "refine": True}})
        refine(f"background_{args.background_terms}")

    if args.ni_atoms:
        phase = phase_by_name(project, "NiWO4")
        for atom in phase.atoms():
            flags = atom.refinement_flags.replace(" ", "")
            atom.refinement_flags = "".join(sorted(set(flags + "X")))
        refine("niwo4_atoms")

    if args.wo_atoms != "none":
        phase = phase_by_name(project, "WO3")
        atom_flags = {}
        for atom in phase.atoms():
            if args.wo_atoms == "all" or atom.element == "W":
                atom_flags[atom.label] = "X"
        phase.set_refinements({"Atoms": atom_flags})
        refine(f"wo3_atoms_{args.wo_atoms}")

    for name in args.common_uiso:
        phase = phase_by_name(project, name)
        values = [float(a.uiso) for a in phase.atoms()]
        start = min(0.02, max(0.003, float(np.median(values))))
        varnames = []
        for index, atom in enumerate(phase.atoms()):
            atom.uiso = start
            flags = atom.refinement_flags.replace(" ", "")
            atom.refinement_flags = "".join(sorted(set(flags + "U")))
            varnames.append(f"{phase.id}::AUiso:{index}")
        if len(varnames) > 1:
            project.add_EquivConstr(varnames)
        refine(f"common_uiso_{name}")

    for item in args.orientation:
        name, axis_text = item.split(":", 1)
        axis = parse_axis(axis_text)
        phase = phase_by_name(project, name)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = axis
        phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
        refine(f"orientation_{name}_{''.join(map(str, axis))}")

    for item in args.uniaxial_strain:
        name, axis_text = item.split(":", 1)
        axis = parse_axis(axis_text)
        phase = phase_by_name(project, name)
        hap = phase.data["Histograms"][hist.name]
        equatorial = max(10.0, float(hap["Mustrain"][1][0]))
        phase.setSampleProfile(hist, "microstrain", "uniaxial", equatorial, equatorial, axis)
        phase.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "refine": True}}, [hist])
        refine(f"uniaxial_strain_{name}_{''.join(map(str, axis))}")

    if args.surface_roughness:
        hist.SampleParameters["SurfRoughA"] = [0.3, True]
        hist.SampleParameters["SurfRoughB"] = [0.08, True]
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        refine("surface_roughness")

    if args.final_cycles:
        project.set_Controls("cycles", args.final_cycles)
        refine("final_cycles")

    project.save(str(out / "project.gpx"))
    arrays = project.histogram(0).data["data"][1]
    x, obs, calc, bkg = (np.asarray(arrays[i], dtype=float) for i in (0, 1, 3, 4))
    np.savetxt(out / "fit.csv", np.column_stack([x, obs, calc, obs - calc, bkg]), delimiter=",",
               header="two_theta_deg,observed,calculated,difference,background", comments="")
    (out / "history.json").write_text(json.dumps(history, indent=2, default=str) + "\n")
    if not args.quiet:
        print(json.dumps(history[-1], indent=2, default=str))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--cycles", type=int, default=10)
    parser.add_argument("--final-cycles", type=int, default=0)
    parser.add_argument("--physical-profile", action="store_true")
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--background-terms", type=int)
    parser.add_argument("--wo-atoms", choices=("none", "W", "all"), default="none")
    parser.add_argument("--ni-atoms", action="store_true")
    parser.add_argument("--common-uiso", action="append", default=[], choices=("NiWO4", "WO3"))
    parser.add_argument("--orientation", action="append", default=[],
                        help="phase:axis, e.g. NiWO4:0,0,1")
    parser.add_argument("--uniaxial-strain", action="append", default=[],
                        help="phase:axis, e.g. WO3:1,0,0")
    parser.add_argument("--surface-roughness", action="store_true")
    parser.add_argument("--add-phase", action="append", default=[], help="name:path")
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--clear-phase-constraints", action="store_true")
    parser.add_argument("--set-size", action="append", default=[], help="phase:value_um")
    parser.add_argument("--set-strain", action="append", default=[], help="phase:value_ppm")
    parser.add_argument("--fix-size", action="append", default=[], choices=("NiWO4", "WO3"))
    parser.add_argument("--fix-strain", action="append", default=[], choices=("NiWO4", "WO3"))
    parser.add_argument("--generator-bounds", action="store_true")
    parser.add_argument("--set-instrument", action="append", default=[], help="parameter:value")
    parser.add_argument("--fix-instrument", action="append", default=[])
    run(parser.parse_args())


if __name__ == "__main__":
    main()
