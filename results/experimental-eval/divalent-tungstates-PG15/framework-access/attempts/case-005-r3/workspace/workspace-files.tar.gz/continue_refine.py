#!/usr/bin/env python3
"""Continue the selected structural refinement with atomic parameters."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


SOURCE = Path(".tmp/advanced-2311041.gpx").resolve()
OUT = Path(".tmp/atomic-2311041.gpx").resolve()


def state(project: G2.G2Project, label: str) -> dict:
    h = project.histogram(0)
    rv = h.data["data"][0]
    cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    d = {
        "label": label, "Rwp": rv.get("wR"), "GOF": cov.get("GOF"),
        "converged": cov.get("converged"), "max_shift_esd": cov.get("Max shft/sig"),
        "zero": h.data["Instrument Parameters"][0]["Zero"],
        "shift": h.data["Sample Parameters"]["Shift"],
        "instrument": {k: h.data["Instrument Parameters"][0][k]
                       for k in ["U", "W", "X", "SH/L", "Polariz."]},
        "phases": {},
    }
    for p in project.phases():
        hap = p.data["Histograms"][h.name]
        d["phases"][p.name] = {
            "cell": p.data["General"]["Cell"], "scale": hap["Scale"],
            "size": hap["Size"], "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
            "atoms": [{"label": a.label, "xyz": a.coordinates,
                       "uiso": a.uiso, "flags": a.refinement_flags}
                      for a in p.atoms()],
        }
    print(json.dumps({
        "stage": label, "Rwp": d["Rwp"], "GOF": d["GOF"],
        "converged": d["converged"], "max_shift_esd": d["max_shift_esd"],
        "zero": d["zero"], "shift": d["shift"],
        "profile": d["instrument"],
        "phase": {n: {"cell": q["cell"][1:7], "scale": q["scale"][0],
                         "size": q["size"][1][0], "strain": q["mustrain"][1][0]}
                  for n, q in d["phases"].items()},
    }, default=str), flush=True)
    return d


def checkpoint(project: G2.G2Project, name: str) -> None:
    project.save()
    shutil.copy2(project.filename, OUT.with_name(f"atomic-{name}.gpx"))


def refine(project: G2.G2Project, label: str, history: list[dict], repeats: int = 2) -> None:
    project.set_Controls("cycles", 12)
    for i in range(repeats):
        project.refine(makeBack=False)
        history.append(state(project, f"{label}.{i + 1}"))
    checkpoint(project, label)


def bounds(project: G2.G2Project, var: str, lo: float, hi: float) -> None:
    project.set_Controls("parmMin", lo, variable=var)
    project.set_Controls("parmMax", hi, variable=var)


def clear_model_flags(project: G2.G2Project) -> None:
    h = project.histogram(0)
    h.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Zero", "Polariz."],
                         "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for p in project.phases():
        p.clear_refinements({"Cell": True, "Atoms": [a.label for a in p.atoms()]})
        p.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True,
                                 "Pref.Ori.": True})


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUT))
    project.set_Frozen()
    clear_model_flags(project)
    h = project.histogram(0)
    co, wo = project.phases()

    # Reconstruct the best converged physically bounded profile before the
    # unstable all-at-once instrument step in the exploratory refinement.
    inst = h.data["Instrument Parameters"][0]
    for key, val in {"U": 10.0, "W": 10.0, "X": 1.0, "SH/L": 0.02,
                     "Zero": 0.0, "Polariz.": 0.7}.items():
        inst[key][1] = val
        inst[key][2] = False
    h.data["Sample Parameters"]["Shift"] = [-610.4654043655944, False]
    values = {
        "Co3O4": {
            "cell": [8.08241824174062, 8.08241824174062, 8.08241824174062,
                     90.0, 90.0, 90.0], "scale": 5.624879188822572,
            "size": 0.12816016199695585, "strain": 547.2255823163244,
        },
        "WO3": {
            "cell": [7.692777885240306, 7.535423566944619, 10.544225207357552,
                     90.0, 136.15702987275048, 90.0], "scale": 17.85756046851897,
            "size": 0.0960258556751935, "strain": 2003.9900243280754,
        },
    }
    # Cell values are already represented internally through reciprocal-metric
    # terms; retain the current near-identical cells and let them re-equilibrate.
    for p in [co, wo]:
        hap = p.data["Histograms"][h.name]
        v = values[p.name]
        p.data["General"]["Cell"][1:7] = v["cell"]
        p.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(v["cell"]))
        hap["Scale"] = [v["scale"], True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = v["size"]
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = v["strain"]
        hap["Mustrain"][2] = [True, False, False]
        p.set_refinements({"Cell": True})
        for a in p.atoms():
            a.uiso = 0.01
            a.refinement_flags = " "
    h.set_refinements({"Background": True})
    for var, lo, hi in [
        ("0:0:Scale", 1e-6, 100.0), ("1:0:Scale", 1e-6, 100.0),
        ("0:0:Size;i", 0.04, 1.5), ("1:0:Size;i", 0.04, 1.5),
        ("0:0:Mustrain;i", 0.0, 8000.0), ("1:0:Mustrain;i", 0.0, 8000.0),
    ]:
        bounds(project, var, lo, hi)
    history = [state(project, "reset")]
    refine(project, "profile_reset", history, 2)

    # Refine the heavy-atom framework first. Coordinate bounds correspond to
    # much more than the modest reference mismatch but prevent origin drift.
    parent_xyz = {}
    for i, a in enumerate(wo.atoms()):
        if a.element != "W":
            continue
        parent_xyz[i] = a.coordinates
        a.refinement_flags = "X"
        for axis, x in zip("xyz", a.coordinates):
            bounds(project, f"1::A{axis}:{i}", x - 0.02, x + 0.02)
    refine(project, "tungsten_coordinates", history, 3)

    # Refine the oxygen framework and the one free spinel oxygen coordinate.
    for phase_id, p in enumerate([co, wo]):
        for i, a in enumerate(p.atoms()):
            if a.element != "O":
                continue
            a.refinement_flags = "X"
            for axis, x in zip("xyz", a.coordinates):
                bounds(project, f"{phase_id}::A{axis}:{i}", x - 0.02, x + 0.02)
    refine(project, "oxygen_coordinates", history, 3)

    # The synthetic specimen assigns one Uiso per phase. Apply that model
    # explicitly with equivalence constraints rather than fitting each site.
    for phase_id, p in enumerate([co, wo]):
        vars_ = []
        for i, a in enumerate(p.atoms()):
            a.refinement_flags = a.refinement_flags.replace("U", "") + "U"
            var = f"{phase_id}::AUiso:{i}"
            vars_.append(var)
            bounds(project, var, 0.003, 0.02)
        project.add_EquivConstr(vars_, reloadIdx=True)
    refine(project, "phase_uiso", history, 3)

    project.save()
    OUT.with_suffix(".history.json").write_text(json.dumps(history, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
