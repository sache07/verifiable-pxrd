#!/usr/bin/env python3
"""Run one bounded GSAS-II model variant from a common clean checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


DEFAULT_SOURCE = Path(".tmp/restrained-2311041.bak0.gpx")


def bound(p: G2.G2Project, var: str, lo: float, hi: float) -> None:
    p.set_Controls("parmMin", lo, variable=var)
    p.set_Controls("parmMax", hi, variable=var)


def clean(p: G2.G2Project) -> None:
    p.set_Frozen()
    for key in ["Hist", "HAP", "Phase", "Global"]:
        p.data["Constraints"]["data"][key] = []
    h = p.histogram(0)
    h.clear_refinements({
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L", "Zero", "Polariz."],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    })
    h.set_refinements({"Background": True})
    for phase in p.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "


def apply_mode(p: G2.G2Project, mode: str) -> None:
    h = p.histogram(0)
    phases = p.phases()
    if mode == "base":
        return
    if mode == "polarization":
        h.set_refinements({"Instrument Parameters": ["Polariz."]})
        bound(p, ":0:Polariz.", 0.5, 1.0)
        return
    if mode == "surface":
        h.data["Sample Parameters"]["SurfRoughA"] = [0.2, True]
        h.data["Sample Parameters"]["SurfRoughB"] = [0.1, True]
        bound(p, ":0:SurfRoughA", 0.0, 0.6)
        bound(p, ":0:SurfRoughB", 0.02, 0.5)
        return
    if mode in {"U", "W", "X", "SH/L"}:
        h.set_refinements({"Instrument Parameters": [mode]})
        lo, hi = {"U": (0.0, 40.0), "W": (2.0, 40.0),
                  "X": (0.1, 6.0), "SH/L": (0.005, 0.10)}[mode]
        bound(p, f":0:{mode}", lo, hi)
        return
    if mode == "shift":
        h.set_refinements({"Sample Parameters": ["Shift"]})
        bound(p, ":0:Shift", -800.0, 800.0)
        return
    if mode == "zero":
        h.set_refinements({"Instrument Parameters": ["Zero"]})
        bound(p, ":0:Zero", -0.25, 0.25)
        return
    if mode.startswith("background") and mode[10:].isdigit():
        ncoeff = int(mode[10:])
        bg = h.data["Background"][0]
        old = list(bg[3:])
        coeffs = (old + [0.0] * ncoeff)[:ncoeff]
        h.set_refinements({"Background": {"type": bg[0], "no. coeffs": ncoeff,
                                           "coeffs": coeffs,
                                           "refine": True}})
        return
    if mode == "coordsW":
        for atom in phases[1].atoms():
            if atom.element == "W":
                atom.refinement_flags = "X"
        return
    if mode == "coordsCoO":
        for atom in phases[0].atoms():
            if atom.element == "O":
                atom.refinement_flags = "X"
        return
    if mode == "cells":
        for phase in phases:
            phase.set_refinements({"Cell": True})
        return
    if mode == "phaseprofiles":
        for phase_id, phase in enumerate(phases):
            hap = phase.data["Histograms"][h.name]
            hap["Size"][2][0] = True
            if hap["Mustrain"][0] == "uniaxial":
                hap["Mustrain"][2][0] = True
                hap["Mustrain"][2][1] = True
            else:
                hap["Mustrain"][2][0] = True
        return
    parts = mode.split("_")
    if len(parts) == 3 and parts[0] == "uisofix":
        phase_id = int(parts[1])
        value = float(parts[2])
        for atom in phases[phase_id].atoms():
            atom.uiso = value
            atom.refinement_flags = " "
        return
    if len(parts) == 4 and parts[0] == "pofix":
        phase_id = int(parts[1])
        axis = [int(v) for v in parts[2]]
        ratio = float(parts[3])
        hap = phases[phase_id].data["Histograms"][h.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = ratio
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = axis
        return
    if len(parts) == 3 and parts[0] == "po":
        phase_id = int(parts[1])
        axis = [int(v) for v in parts[2]]
        hap = phases[phase_id].data["Histograms"][h.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        bound(p, f"{phase_id}:0:MD", 0.7, 1.4)
        return
    if len(parts) == 3 and parts[0] == "strain":
        phase_id = int(parts[1])
        axis = [int(v) for v in parts[2]]
        hap = phases[phase_id].data["Histograms"][h.name]
        iso = float(hap["Mustrain"][1][0])
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = iso
        hap["Mustrain"][1][1] = iso
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = axis
        bound(p, f"{phase_id}:0:Mustrain;i", 0.0, 8000.0)
        bound(p, f"{phase_id}:0:Mustrain;a", 0.0, 8000.0)
        return
    raise ValueError(f"unknown mode {mode}")


def summarize(p: G2.G2Project, mode: str) -> dict:
    h = p.histogram(0)
    cov = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "mode": mode, "Rwp": h.get_wR(), "GOF": cov.get("GOF"),
        "converged": cov.get("converged"), "max_shift_esd": cov.get("Max shft/sig"),
        "frozen": p.get_Frozen(),
        "instrument": h.data["Instrument Parameters"][0],
        "sample": h.data["Sample Parameters"], "background": h.data["Background"],
        "phases": {},
    }
    for phase in p.phases():
        hap = phase.data["Histograms"][h.name]
        result["phases"][phase.name] = {
            "cell": phase.data["General"]["Cell"], "scale": hap["Scale"],
            "size": hap["Size"], "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    return result


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("mode")
    ap.add_argument("output", type=Path)
    ap.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    p = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    clean(p)
    apply_mode(p, args.mode)
    p.set_Controls("cycles", 12)
    p.refine(makeBack=False)
    p.save()
    result = summarize(p, args.mode)
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps({"mode": args.mode, "Rwp": result["Rwp"],
                      "GOF": result["GOF"], "converged": result["converged"],
                      "frozen": result["frozen"]}, default=str))


if __name__ == "__main__":
    main()
