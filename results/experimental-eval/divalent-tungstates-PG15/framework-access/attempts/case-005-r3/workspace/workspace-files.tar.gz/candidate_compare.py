#!/usr/bin/env python3
"""Comparable bounded refinement for alternative WO3 structure models."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_work import cod_path, instrument_text


def limit(p: G2.G2Project, var: str, lo: float, hi: float) -> None:
    p.set_Controls("parmMin", lo, variable=var)
    p.set_Controls("parmMax", hi, variable=var)


def step(p: G2.G2Project, label: str, repeats: int = 1) -> None:
    p.set_Controls("cycles", 12)
    for _ in range(repeats):
        p.refine(makeBack=False)
    h = p.histogram(0)
    print(label, h.get_wR(), [(q.name, q.get_cell(),
          q.data["Histograms"][h.name]["Scale"],
          q.data["Histograms"][h.name]["Size"][1],
          q.data["Histograms"][h.name]["Mustrain"][1]) for q in p.phases()], flush=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("candidate")
    ap.add_argument("output", type=Path)
    args = ap.parse_args()
    out = args.output.resolve()
    instfile = out.with_suffix(".instprm")
    instfile.write_text(instrument_text())
    G2.SetPrintLevel("warn")
    p = G2.G2Project(newgpx=str(out))
    co = p.add_phase(str(cod_path("9005896")), phasename="Co3O4", fmthint="CIF")
    wo = p.add_phase(str(cod_path(args.candidate)), phasename="WO3", fmthint="CIF")
    h = p.add_powder_histogram(str(Path("inputs/pattern.csv").resolve()), str(instfile),
                               phases=[co, wo], fmthint="comma/tab/semicolon separated")
    h.set_refinements({"Limits": [10.0, 100.0],
                       "Background": {"type": "chebyschev-1", "no. coeffs": 16,
                                      "coeffs": [3000.0] + [0.0] * 15, "refine": True}})
    h.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    h.data["Sample Parameters"]["Gonio. radius"] = 200.0
    h.data["Sample Parameters"]["Shift"] = [-650.0, False]
    h.data["Instrument Parameters"][0]["Polariz."][1] = 0.866877
    for phase, scale, size, strain, uiso in [(co, 4.0, .2, 1500., .014),
                                             (wo, 15.0, .12, 3000., .010)]:
        hap = phase.data["Histograms"][h.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"; hap["Size"][1][0] = size; hap["Size"][2] = [False] * 3
        hap["Mustrain"][0] = "isotropic"; hap["Mustrain"][1][0] = strain; hap["Mustrain"][2] = [False] * 3
        for a in phase.atoms(): a.uiso = uiso
    for var, lo, hi in [(":0:Shift", -800, 800), ("0:0:Scale", 1e-6, 100),
                        ("1:0:Scale", 1e-6, 100), ("0:0:Size;i", .04, 1.5),
                        ("1:0:Size;i", .04, 1.5), ("0:0:Mustrain;i", 0, 8000),
                        ("1:0:Mustrain;i", 0, 8000)]: limit(p, var, lo, hi)
    step(p, "scales", 2)
    h.set_refinements({"Sample Parameters": ["Shift"]}); step(p, "shift", 2)
    co.set_refinements({"Cell": True}); wo.set_refinements({"Cell": True}); step(p, "cells", 2)
    co.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    wo.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    step(p, "strain", 2)
    co.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    wo.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    step(p, "size", 2)
    p.save()


if __name__ == "__main__":
    main()
