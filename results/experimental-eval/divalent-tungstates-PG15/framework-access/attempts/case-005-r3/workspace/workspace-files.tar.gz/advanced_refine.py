#!/usr/bin/env python3
"""Constrained Rietveld refinement for the Co3O4 + WO3 hypothesis."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2

from refine_work import cod_path, instrument_text


OUT = Path(".tmp/advanced-2311041.gpx").resolve()


def rvals(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    rv = dict(hist.data["data"][0])
    cov = project.data.get("Covariance", {}).get("data", {})
    rv.update({f"cov_{k}": cov.get("Rvals", {}).get(k) for k in
               ["converged", "DelChi2", "GOF", "Max shft/sig", "msg"]})
    return rv


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.data["General"]["Cell"],
            "mass": phase.data["General"]["Mass"],
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
            "atoms": [{"label": a.label, "element": a.element,
                       "coordinates": a.coordinates, "uiso": a.uiso,
                       "flags": a.refinement_flags} for a in phase.atoms()],
        }
    snap = {
        "label": label,
        "rvals": rvals(project),
        "instrument": inst,
        "sample": sample,
        "background": hist.data["Background"],
        "phases": phases,
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }
    print(json.dumps({
        "stage": label,
        "Rwp": snap["rvals"].get("wR"),
        "GOF": snap["rvals"].get("cov_GOF"),
        "converged": snap["rvals"].get("cov_converged"),
        "zero": inst["Zero"],
        "shift": sample["Shift"],
        "profile": {k: inst[k] for k in ["U", "W", "X", "SH/L", "Polariz."]},
        "phase": {n: {"cell": q["cell"][1:7], "scale": q["scale"][0],
                         "size": q["size"][1], "strain": q["mustrain"][1],
                         "po": q["pref_ori"][1:4]}
                  for n, q in phases.items()},
    }, default=str), flush=True)
    return snap


def refine(project: G2.G2Project, label: str, log: list[dict], repeats: int = 1) -> None:
    project.set_Controls("cycles", 12)
    for i in range(repeats):
        project.refine(makeBack=False)
        log.append(snapshot(project, f"{label}.{i + 1}"))


def set_limit(project: G2.G2Project, variable: str, lo: float, hi: float) -> None:
    project.set_Controls("parmMin", lo, variable=variable)
    project.set_Controls("parmMax", hi, variable=variable)


def build() -> tuple[G2.G2Project, list[dict]]:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    inst_file = OUT.with_suffix(".instprm")
    inst_file.write_text(instrument_text())
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(OUT))
    co = project.add_phase(str(cod_path("9005896")), phasename="Co3O4", fmthint="CIF")
    wo = project.add_phase(str(cod_path("2311041")), phasename="WO3", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()), str(inst_file),
        phases=[co, wo], fmthint="comma/tab/semicolon separated")
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "no. coeffs": 12,
                       "coeffs": [3000.0] + [0.0] * 11, "refine": True},
    })
    sample = hist.data["Sample Parameters"]
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [-650.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    # Physically central starting values. Uiso is assigned per phase in the
    # generator, so use one common starting value on every site.
    for p, scale, size, strain in [(co, 4.0, 0.7, 500.0),
                                    (wo, 10.0, 0.3, 2500.0)]:
        hap = p.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        for atom in p.atoms():
            atom.uiso = 0.01
            atom.refinement_flags = " "

    # Bounds prevent the correlated profile and displacement terms from
    # stepping into nonphysical regions while the model is incomplete.
    for name, lo, hi in [
        (":0:Zero", -0.25, 0.25), (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0), (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
        ("0:0:Scale", 1e-6, 100.0), ("1:0:Scale", 1e-6, 100.0),
        ("0:0:Size;i", 0.04, 1.5), ("1:0:Size;i", 0.04, 1.5),
        ("0:0:Mustrain;i", 0.0, 8000.0), ("1:0:Mustrain;i", 0.0, 8000.0),
    ]:
        set_limit(project, name, lo, hi)
    log = [snapshot(project, "initial")]
    return project, log


def main() -> None:
    project, log = build()
    hist = project.histogram(0)
    co, wo = project.phases()

    refine(project, "background_scales", log, 2)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "shift", log, 2)

    co.set_refinements({"Cell": True})
    wo.set_refinements({"Cell": True})
    refine(project, "cells_shift", log, 2)

    # Fit phase broadening while the common instrumental profile remains
    # stable, then let the common profile terms respond.
    co.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    wo.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, "isotropic_strain", log, 2)

    co.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    wo.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine(project, "isotropic_size", log, 2)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "instrument_profile", log, 3)

    # Zero and specimen height are nearly collinear. Refine zero only after
    # fixing the now-estimated height, while retaining the cell refinements.
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "zero_fixed_shift", log, 2)

    project.save()
    OUT.with_suffix(".history.json").write_text(json.dumps(log, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
