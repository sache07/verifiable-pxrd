#!/usr/bin/env python3
"""Working GSAS-II refinement driver for the supplied powder pattern.

This is intentionally kept in the analysis workspace so every numerical
choice used to build the final project is reproducible.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def instrument_text() -> str:
    # Deliberately central starting values. The terms used by the generator
    # (Zero, U, W, X, SH/L and polarization) are refined in stages below.
    return (
        "#GSAS-II instrument parameter file; Cu Kalpha Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )


def summarize(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "label": label,
        "Rwp": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("GOF"),
        "instrument": {k: v[:3] if isinstance(v, list) else v for k, v in inst.items()},
        "sample": sample,
        "background": hist.data["Background"][0],
        "phases": {},
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.data["General"]["Cell"],
            "mass": phase.data["General"]["Mass"],
            "composition": phase.composition,
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
            "atoms": [
                {
                    "label": a.label,
                    "element": a.element,
                    "coordinates": a.coordinates,
                    "occupancy": a.occupancy,
                    "uiso": a.uiso if a.adp_flag == "I" else None,
                    "flags": a.refinement_flags,
                }
                for a in phase.atoms()
            ],
        }
    compact = {
        "label": label,
        "Rwp": result["Rwp"],
        "GOF": result["GOF"],
        "zero": inst.get("Zero"),
        "shift": sample.get("Shift"),
        "cells": {name: values["cell"] for name, values in result["phases"].items()},
        "scales": {name: values["scale"] for name, values in result["phases"].items()},
    }
    print(json.dumps(compact, default=str), flush=True)
    return result


def run_refinement(project: G2.G2Project, label: str, summaries: list[dict]) -> None:
    print(f"\n===== {label} =====", flush=True)
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    summaries.append(summarize(project, label))


def build(candidate: str, output: Path, stop_after: str | None = None) -> G2.G2Project:
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    inst_file = output.with_suffix(".instprm")
    inst_file.write_text(instrument_text())

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(output))
    co = project.add_phase(str(cod_path("9005896")), phasename="Co3O4", fmthint="CIF")
    wo = project.add_phase(str(cod_path(candidate)), phasename=f"WO3_{candidate}", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()),
        str(inst_file),
        phases=[co, wo],
        fmthint="comma/tab/semicolon separated",
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    # The observed peak displacement falls approximately as cos(theta), which
    # gives this direct starting estimate for specimen height (micrometres).
    hist.data["Sample Parameters"]["Shift"] = [-650.0, False]
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [3000.0] + [0.0] * 11,
            "refine": True,
        },
    })
    for phase, scale in [(co, 1.3), (wo, 4.0)]:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    summaries: list[dict] = [summarize(project, "initial")]

    run_refinement(project, "background_scales", summaries)
    if stop_after == "scales":
        project.save()
        return project

    # First determine the Bragg-Brentano specimen-height displacement without
    # allowing the cells to absorb it.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(project, "shift", summaries)
    if stop_after == "zero":
        project.save()
        return project

    # Allow each crystal metric to account for the small reference mismatch.
    co.set_refinements({"Cell": True})
    wo.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, "cells", summaries)
    if stop_after == "cells":
        project.save()
        return project

    # Refine the common instrumental width terms and isotropic specimen broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    co.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True},
                            "Mustrain": {"type": "isotropic", "refine": True}})
    wo.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True},
                            "Mustrain": {"type": "isotropic", "refine": True}})
    run_refinement(project, "profiles", summaries)

    project.save()
    output.with_suffix(".summary.json").write_text(json.dumps(summaries, indent=2, default=str) + "\n")
    print(f"GSAS-II revision {GSASIIpath.GetVersionNumber()}")
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", help="COD id for the WO3 model")
    parser.add_argument("output", type=Path)
    parser.add_argument("--stop-after", choices=["scales", "zero", "cells"])
    args = parser.parse_args()
    build(args.candidate, args.output, args.stop_after)


if __name__ == "__main__":
    main()
