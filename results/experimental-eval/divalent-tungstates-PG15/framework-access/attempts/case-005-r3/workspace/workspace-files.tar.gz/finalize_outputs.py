#!/usr/bin/env python3
"""Create the submission files from the verified full-grid project replay."""

from __future__ import annotations

import json
from pathlib import Path
import shutil

import numpy as np


REPLAY = Path(".tmp/final_replay")
report = json.loads((REPLAY / "replay.json").read_text())
if report.get("status") != "replayed":
    raise SystemExit(f"project replay failed: {report}")

phase_info = {
    "Co3O4": {
        "filename": "Co3O4.cif",
        "formula": "Co3O4",
        "space_group": "Fd-3m",
        "source_model": "COD 9005896",
    },
    "WO3": {
        "filename": "WO3.cif",
        "formula": "WO3",
        "space_group": "P21/c",
        "source_model": "COD 2311041",
    },
}

phases = []
for row in report["phases"]:
    info = phase_info[row["name"]]
    shutil.copyfile(REPLAY / row["cif"], info["filename"])
    phases.append(
        {
            "name": row["name"],
            "formula": info["formula"],
            "space_group": info["space_group"],
            "cif_path": info["filename"],
            "weight_fraction": float(row["weight_fraction"]),
            "weight_percent": 100.0 * float(row["weight_fraction"]),
            "source_model": info["source_model"],
        }
    )

with np.load(REPLAY / "prediction.npz", allow_pickle=False) as archive:
    x = archive["x"].copy()
    observed = archive["observed"].copy()
    calculated = archive["predicted"].copy()

difference = observed - calculated
np.savetxt(
    "fit.csv",
    np.column_stack([x, observed, calculated, difference]),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference",
    comments="",
    fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
)

weights = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weights * difference**2))
denominator = float(np.sum(weights * observed**2))
n_parameters = 39
statistics = {
    "rwp_percent": float(100.0 * np.sqrt(chi_square / denominator)),
    "rp_percent": float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed))),
    "chi_square": chi_square,
    "goodness_of_fit": float(np.sqrt(chi_square / (len(x) - n_parameters))),
    "n_points": int(len(x)),
    "n_parameters_last_cycle": n_parameters,
    "weighting": "1/max(observed_counts,1)",
    "profile_scope": "complete measured grid",
}

result = {
    "phases": phases,
    "unresolved_components": [],
    "fit_statistics": statistics,
    "refinement_histogram": report["histogram"],
    "final_project": "final.gpx",
    "calibration": {
        "zero_deg": float(report["instrument"]["Zero"][1]),
        "polarization": float(report["instrument"]["Polariz."][1]),
    },
}
Path("result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps({"phases": phases, "fit_statistics": statistics}, indent=2))

