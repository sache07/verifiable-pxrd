#!/usr/bin/env python3
"""Freeze the selected GSAS-II checkpoint as the submitted project."""

from pathlib import Path
import shutil


SOURCE = Path(".tmp/opt5-profile2.gpx")
DESTINATION = Path("final.gpx")

if not SOURCE.is_file():
    raise SystemExit(f"missing selected checkpoint: {SOURCE}")

shutil.copyfile(SOURCE, DESTINATION)
print(f"copied {SOURCE} -> {DESTINATION} ({DESTINATION.stat().st_size} bytes)")
