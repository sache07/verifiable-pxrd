#!/usr/bin/env python3
"""Chemically bounded coordinate and displacement refinement."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/atomic-tungsten_coordinates.gpx").resolve()
OUT = Path(".tmp/restrained-2311041.gpx").resolve()


def report(p: G2.G2Project, label: str) -> dict:
    h = p.histogram(0)
    cov = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "stage": label, "Rwp": h.get_wR(), "GOF": cov.get("GOF"),
        "converged": cov.get("converged"), "max_shift_esd": cov.get("Max shft/sig"),
        "frozen": p.get_Frozen(),
        "phases": {},
    }
    for phase in p.phases():
        hap = phase.data["Histograms"][h.name]
        result["phases"][phase.name] = {
            "cell": phase.data["General"]["Cell"], "scale": hap["Scale"],
            "size": hap["Size"], "mustrain": hap["Mustrain"],
            "atoms": [{"label": a.label, "element": a.element,
                       "xyz": a.coordinates, "uiso": a.uiso,
                       "flags": a.refinement_flags} for a in phase.atoms()],
        }
    print(json.dumps({k: v for k, v in result.items() if k != "phases"}, default=str), flush=True)
    return result


def bounds(p: G2.G2Project, var: str, lo: float, hi: float) -> None:
    p.set_Controls("parmMin", lo, variable=var)
    p.set_Controls("parmMax", hi, variable=var)


def refine(p: G2.G2Project, label: str, history: list[dict]) -> None:
    p.set_Controls("cycles", 12)
    p.refine(makeBack=False)
    history.append(report(p, label))
    p.save()


def main() -> None:
    G2.SetPrintLevel("warn")
    p = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUT))
    p.set_Frozen()
    h = p.histogram(0)
    co, wo = p.phases()
    # The selected checkpoint has a stable profile and sensible W shifts.
    # Freeze W coordinates; reset all Uiso values before fitting O shifts.
    for phase in [co, wo]:
        for atom in phase.atoms():
            atom.refinement_flags = " "
            atom.uiso = 0.01

    # Bounds apply to GSAS-II's coordinate increments (dA*), not to absolute
    # coordinates. A single refinement then limits each shift to about
    # 0.05--0.08 A for these cells.
    for phase_id, phase in enumerate([co, wo]):
        for atom_id, atom in enumerate(phase.atoms()):
            if atom.element != "O":
                continue
            atom.refinement_flags = "X"
            for axis in "xyz":
                bounds(p, f"{phase_id}::dA{axis}:{atom_id}", -0.008, 0.008)

    history = [report(p, "start")]
    refine(p, "bounded_oxygen", history)

    # Freeze coordinates at the bounded result before refining one Uiso per
    # phase. Equivalence constraints encode the specimen model explicitly.
    for phase in [co, wo]:
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    for phase_id, phase in enumerate([co, wo]):
        vars_ = []
        for atom_id, _ in enumerate(phase.atoms()):
            var = f"{phase_id}::AUiso:{atom_id}"
            vars_.append(var)
            bounds(p, var, 0.003, 0.02)
        p.add_EquivConstr(vars_, reloadIdx=True)
    refine(p, "phase_uiso", history)

    # Freeze atomic parameters so subsequent profile/texture tests cannot
    # accumulate coordinate increments.
    for phase in [co, wo]:
        for atom in phase.atoms():
            atom.refinement_flags = " "
    p.save()
    OUT.with_suffix(".history.json").write_text(json.dumps(history, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
