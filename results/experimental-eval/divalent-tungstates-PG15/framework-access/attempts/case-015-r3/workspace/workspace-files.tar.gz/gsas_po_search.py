#!/usr/bin/env python3
"""Screen the documented March-Dollase axes for each phase."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def rwp(project: G2.G2Project) -> float:
    _, obs, weights, calc = project.histogram(0).data["data"][1][:4]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2)))


def configure(project: G2.G2Project, phase_index: int, axis: tuple[int, int, int]) -> None:
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"]})
    hist.clear_refinements({"Background": True})
    for pidx, phase in enumerate(project.phases()):
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
        if pidx == phase_index:
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][3] = list(axis)
            phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
            project.set_Controls("parmMin", 0.7, variable=f"{pidx}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pidx}:0:MD")
    project.set_Frozen()
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    results = []
    for pidx in range(3):
        for aidx, axis in enumerate(AXES):
            path = args.outdir / f"po-p{pidx}-a{aidx}.gpx"
            project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(path.resolve()))
            configure(project, pidx, axis)
            project.set_Controls("cycles", 4)
            project.refine(makeBack=False)
            hist = project.histogram(0)
            result = {
                "phase_index": pidx,
                "phase": project.phases()[pidx].name,
                "axis": axis,
                "ratio": project.phases()[pidx].data["Histograms"][hist.name]["Pref.Ori."][1],
                "rwp": rwp(project),
                "frozen": project.get_Frozen(),
                "path": str(path),
            }
            results.append(result)
            print(json.dumps(result), flush=True)
    for pidx in range(3):
        candidates = [row for row in results if row["phase_index"] == pidx and not row["frozen"]]
        best = min(candidates, key=lambda row: row["rwp"])
        shutil.copy2(best["path"], args.outdir / f"po-p{pidx}-best.gpx")
    print(json.dumps({
        "best_by_phase": [min([row for row in results if row["phase_index"] == pidx and not row["frozen"]], key=lambda row: row["rwp"]) for pidx in range(3)]
    }, indent=2), flush=True)


if __name__ == "__main__":
    main()
