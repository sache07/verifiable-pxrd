#!/usr/bin/env python3
"""Export the internally consistent final GPX, CIFs, profile and result JSON."""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main(source_name: str) -> None:
    root = Path.cwd()
    source = Path(source_name).resolve()
    final_path = root / "final.gpx"
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(final_path))
    project.save()
    # Reopen the submitted project so every derivative is taken from exactly
    # the file that will be replayed.
    project = G2.G2Project(gpxfile=str(final_path))
    hist = project.histogram(0)
    filenames = {"ZnWO4": "ZnWO4.cif", "WO3": "WO3.cif", "ZnO": "ZnO.cif"}
    for phase in project.phases():
        phase.export_CIF(str(root / filenames[phase.name]))

    x, observed, weights, calculated = [np.asarray(a, dtype=float) for a in hist.data["data"][1][:4]]
    original = np.loadtxt(root / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if len(original) != len(x) or not np.allclose(original[:, 0], x, atol=1e-9, rtol=0):
        raise RuntimeError("final project grid does not match pattern.csv")
    if not np.allclose(original[:, 1], observed, atol=1e-9, rtol=0):
        raise RuntimeError("final project observations do not match pattern.csv")
    if not np.isfinite(calculated).all() or np.min(calculated) < 0:
        raise RuntimeError("invalid calculated profile")
    with (root / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        for xx, yo, yc in zip(x, observed, calculated):
            writer.writerow([f"{xx:.8f}", f"{yo:.1f}", f"{yc:.10f}", f"{yo - yc:.10f}"])

    mass_scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scales.append(max(0.0, hap["Scale"][0]) * phase.data["General"]["Mass"])
    mass_scales = np.asarray(mass_scales)
    fractions = mass_scales / mass_scales.sum()
    residual = observed - calculated
    denominator = float(np.sum(weights * observed**2))
    chi_square = float(np.sum(weights * residual**2))
    rwp = float(100 * np.sqrt(chi_square / denominator))
    rp = float(100 * np.sum(np.abs(residual)) / np.sum(np.abs(observed)))
    expected_rwp = float(100 * np.sqrt(len(observed) / denominator))
    cov = project.data.get("Covariance", {}).get("data", {})
    nvars = int(cov.get("Rvals", {}).get("Nvars", len(cov.get("varyList", []))))
    reduced = chi_square / max(1, len(observed) - nvars)
    formulas = {"ZnWO4": "ZnWO4", "WO3": "WO3", "ZnO": "ZnO"}
    phases = []
    for phase, fraction in zip(project.phases(), fractions):
        phases.append({
            "name": phase.name,
            "formula": formulas[phase.name],
            "space_group": phase.data["General"]["SGData"].get("SpGrp", "").strip(),
            "cif_path": filenames[phase.name],
            "weight_fraction": float(fraction),
        })
    inst = hist.data["Instrument Parameters"][0]
    result = {
        "phases": phases,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "refinement_histogram": hist.name,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "chi_square": chi_square,
            "reduced_chi_square": float(reduced),
            "poisson_expected_Rwp_percent": expected_rwp,
            "n_points": int(len(observed)),
            "n_refined_parameters": nvars,
        },
        "calibration": {
            "zero_deg": float(inst["Zero"][1]),
            "specimen_shift_um": float(hist.SampleParameters["Shift"][0]),
        },
    }
    (root / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main(sys.argv[1])
