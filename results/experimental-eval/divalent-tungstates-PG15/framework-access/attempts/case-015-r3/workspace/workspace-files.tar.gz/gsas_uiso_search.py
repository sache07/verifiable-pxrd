#!/usr/bin/env python3
"""Profile physically allowed common isotropic ADPs for each phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


VALUES = (0.003, 0.0045, 0.0065, 0.009, 0.013, 0.018, 0.020)


def rwp(project: G2.G2Project) -> float:
    _, obs, weights, calc = project.histogram(0).data["data"][1][:4]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2)))


def configure(project: G2.G2Project, phase_index: int, uiso: float) -> None:
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"]})
    hist.clear_refinements({"Background": True})
    for pidx, phase in enumerate(project.phases()):
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
            if pidx == phase_index:
                atom.data[atom.cia] = "I"
                atom.uiso = uiso
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.set_Frozen()
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    results = []
    for pidx in range(3):
        for vidx, value in enumerate(VALUES):
            path = args.outdir / f"uiso-p{pidx}-v{vidx}.gpx"
            project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(path.resolve()))
            configure(project, pidx, value)
            project.set_Controls("cycles", 2)
            project.refine(makeBack=False)
            result = {
                "phase_index": pidx,
                "phase": project.phases()[pidx].name,
                "uiso_A2": value,
                "rwp": rwp(project),
                "frozen": project.get_Frozen(),
                "path": str(path),
            }
            results.append(result)
            print(json.dumps(result), flush=True)
    print(json.dumps({
        "best_by_phase": [min([row for row in results if row["phase_index"] == pidx], key=lambda row: row["rwp"]) for pidx in range(3)]
    }, indent=2), flush=True)


if __name__ == "__main__":
    main()
