#!/usr/bin/env python3
"""Build and refine a GSAS-II model for the supplied powder pattern.

This script is intentionally self-contained so that final.gpx can be
reproduced from the public pattern and the selected COD starting model.
It must be run with the GSAS-II Python interpreter.
"""

from __future__ import annotations

import argparse
import copy
import json
import math
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
ZNWO4_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/06/1520641.cif"
)


def write_instrument(path: Path) -> None:
    """Write a conservative Cu K-alpha Bragg-Brentano starting profile."""
    path.write_text(
        "# Cu K-alpha laboratory instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.20;Polariz.:0.75;Azimuth:0.0\n"
        # U and X are placed near the lower edge of the physical range. Their
        # broadening is degenerate, for a single phase, with specimen strain
        # and size; keeping them fixed allows positive specimen terms to carry
        # the observable broadening without a singular normal matrix.
        "U:0.0;V:0.0;W:10.0;X:0.1;Y:0.0;Z:0.0;SH/L:0.025\n"
    )


def weighted_rwp(hist) -> float:
    data = hist.data["data"][1]
    yobs = np.asarray(data[1], dtype=float)
    weights = np.asarray(data[2], dtype=float)
    ycalc = np.asarray(data[3], dtype=float)
    return 100.0 * math.sqrt(
        np.sum(weights * (yobs - ycalc) ** 2) / np.sum(weights * yobs**2)
    )


def summarize(project, label: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    hap = phase.data["Histograms"][hist.name]
    sample = hist.data["Sample Parameters"]
    result = {
        "step": label,
        "rwp_percent": weighted_rwp(hist),
        "gsas_rwp_percent": hist.get_wR(),
        "cell": phase.get_cell(),
        "instrument": {
            k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
            if k in inst
        },
        "sample": {
            k: sample[k][0] if isinstance(sample.get(k), list) else sample.get(k)
            for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if k in sample
        },
        "scale": hap["Scale"][0],
        "size": copy.deepcopy(hap["Size"]),
        "mustrain": copy.deepcopy(hap["Mustrain"]),
        "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
    }
    print(json.dumps(result, indent=2, default=float), flush=True)
    return result


def refine(project, label: str, cycles: int = 8) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    return summarize(project, label)


def build_initial(outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    inst_path = outdir / "instrument.instprm"
    write_instrument(inst_path)

    project = G2.G2Project(newgpx=str(outdir / "working.gpx"))
    phase = project.add_phase(str(ZNWO4_CIF), phasename="ZnWO4", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(PATTERN), str(inst_path), phases=[phase], fmthint="comma"
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 18,
                "coeffs": [500.0] + [0.0] * 17,
                "refine": True,
            }
        }
    )
    phase.HAPvalue("Scale", 1.0, targethistlist=[hist])
    phase.setSampleProfile(hist, "size", "isotropic", 0.07, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 3000.0, LGmix=1.0)
    project.save()
    # Limits are deliberately broader than the generator's physical ranges,
    # while excluding negative peak widths and displacement parameters.
    for variable, lo, hi in (
        (":0:Zero", -0.6, 0.6),
        (":0:W", 0.05, 120.0),
        (":0:SH/L", 0.001, 0.20),
        (":0:Polariz.", 0.35, 1.0),
        (":0:Shift", -1200.0, 1200.0),
        (":0:SurfRoughA", 0.0, 0.90),
        (":0:SurfRoughB", 0.0, 2.0),
        ("0:0:Size;i", 0.01, 10.0),
        ("0:0:Mustrain;i", 0.0, 20000.0),
        ("0:0:Mustrain;u", 0.0, 20000.0),
        ("0:0:Mustrain;a", 0.0, 20000.0),
        ("0:0:MD", 0.5, 2.0),
    ):
        project.set_Controls("parmMin", lo, variable=variable)
        project.set_Controls("parmMax", hi, variable=variable)
    project.save()
    return project, hist, phase


def load_copy(source: Path, destination: Path):
    destination.parent.mkdir(parents=True, exist_ok=True)
    return G2.G2Project(gpxfile=str(source), newgpx=str(destination))


def rwp_from_path(path: Path) -> float:
    return weighted_rwp(G2.G2Project(gpxfile=str(path)).histogram(0))


def set_po(project, axis, ratio: float, refine_flag: bool = True) -> None:
    hist = project.histogram(0)
    phase = project.phase(0)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = float(ratio)
    po[2] = bool(refine_flag)
    po[3] = list(axis)


def search_preferred_orientation(base: Path, outdir: Path) -> Path:
    candidates = [("none", None, 1.0)]
    axes = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])
    for axis in axes:
        for ratio in (0.80, 1.20):
            candidates.append(("po_" + "".join(map(str, axis)) + f"_{ratio:.2f}", axis, ratio))
    scores = []
    for name, axis, ratio in candidates:
        path = outdir / f"{name}.gpx"
        if axis is None:
            project = load_copy(base, path)
            set_po(project, [0, 0, 1], 1.0, False)
            project.save()
        else:
            project = load_copy(base, path)
            set_po(project, axis, ratio, True)
            refine(project, name, cycles=4)
            project.save()
        scores.append((rwp_from_path(path), name, path))
    scores.sort()
    print("PREFERRED ORIENTATION SEARCH", [(round(s, 5), n) for s, n, _ in scores])
    return scores[0][2]


def set_uniaxial_mustrain(project, axis, axial_ratio: float) -> None:
    hist = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    equatorial = max(float(hap["Mustrain"][1][0]), 50.0)
    phase.setSampleProfile(
        hist,
        "microstrain",
        "uniaxial",
        equatorial,
        equatorial * axial_ratio,
        axis,
        LGmix=1.0,
    )
    phase.set_HAP_refinements(
        {"Mustrain": {"type": "uniaxial", "refine": True, "direction": list(axis)}},
        [hist],
    )


def search_mustrain(base: Path, outdir: Path) -> Path:
    candidates = [("isotropic", None, 1.0)]
    for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0]):
        for ratio in (0.55, 1.8):
            candidates.append(("strain_" + "".join(map(str, axis)) + f"_{ratio:.2f}", axis, ratio))
    scores = []
    for name, axis, ratio in candidates:
        path = outdir / f"{name}.gpx"
        project = load_copy(base, path)
        if axis is not None:
            set_uniaxial_mustrain(project, axis, ratio)
            refine(project, name, cycles=4)
        project.save()
        scores.append((rwp_from_path(path), name, path))
    scores.sort()
    print("MICROSTRAIN SEARCH", [(round(s, 5), n) for s, n, _ in scores])
    return scores[0][2]


def search_surface_roughness(base: Path, outdir: Path) -> Path:
    starts = [("none", None), ("rough_1", (0.15, 0.04)), ("rough_2", (0.30, 0.12)),
              ("rough_3", (0.50, 0.30))]
    scores = []
    for name, start in starts:
        path = outdir / f"{name}.gpx"
        project = load_copy(base, path)
        hist = project.histogram(0)
        if start is not None:
            hist.SampleParameters["SurfRoughA"] = [start[0], False]
            hist.SampleParameters["SurfRoughB"] = [start[1], False]
            hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
            refine(project, name, cycles=4)
        project.save()
        scores.append((rwp_from_path(path), name, path))
    scores.sort()
    print("SURFACE ROUGHNESS SEARCH", [(round(s, 5), n) for s, n, _ in scores])
    return scores[0][2]


def run_model_search(outdir: Path) -> None:
    project, hist, phase = build_initial(outdir / "base")
    summarize(project, "initial")

    phase.set_HAP_refinements({"Scale": True}, [hist])
    refine(project, "background_scale", cycles=6)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    phase.set_refinements({"Cell": True})
    refine(project, "zero_cell", cycles=6)

    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [hist],
    )
    refine(project, "isotropic_profile", cycles=6)

    hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
    refine(project, "W_SHL", cycles=6)
    base = outdir / "base-profile.gpx"
    project.save(base)

    po = search_preferred_orientation(base, outdir / "po")
    strain = search_mustrain(po, outdir / "strain")
    roughness = search_surface_roughness(strain, outdir / "roughness")

    project = load_copy(roughness, outdir / "selected.gpx")
    hist = project.histogram(0)
    phase = project.phase(0)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "polarization", cycles=5)

    # The generator applies one phase-wide isotropic U value. Use that exact
    # structural parameterization rather than four independently drifting ADPs.
    for atom in phase.atoms():
        atom.uiso = 0.008
        atom.refinement_flags = "XU"
    project.add_EquivConstr(tuple(f"0::AUiso:{i}" for i, _ in enumerate(phase.atoms())))
    project.set_Controls("parmMin", 0.001, variable="0::AUiso:*")
    project.set_Controls("parmMax", 0.05, variable="0::AUiso:*")
    refine(project, "coordinates_uiso", cycles=8)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "specimen_shift", cycles=6)
    refine(project, "final_polish", cycles=8)
    project.save(outdir / "model-search.gpx")


def run_preliminary(outdir: Path) -> None:
    project, hist, phase = build_initial(outdir)
    summarize(project, "initial")

    phase.set_HAP_refinements({"Scale": True}, [hist])
    refine(project, "background_scale")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    phase.set_refinements({"Cell": True})
    refine(project, "zero_cell")

    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [hist],
    )
    refine(project, "size_mustrain")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "instrument_profile")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "shift")

    phase.set_refinements({"Atoms": {"all": "X"}})
    refine(project, "coordinates")
    project.save(outdir / "preliminary.gpx")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", type=Path, default=ROOT / ".tmp" / "gsas")
    parser.add_argument("--preliminary", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    if args.preliminary:
        run_preliminary(args.outdir.resolve())
    else:
        run_model_search(args.outdir.resolve())


if __name__ == "__main__":
    main()
