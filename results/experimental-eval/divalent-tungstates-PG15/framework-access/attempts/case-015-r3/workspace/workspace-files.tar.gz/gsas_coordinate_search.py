#!/usr/bin/env python3
"""Monitored coordinate refinement for the well-resolved principal phase."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ZNWO4_SOURCE = (
    (0.00000, 0.18258, 0.25000),
    (0.50000, 0.68400, 0.25000),
    (0.21690, 0.10510, -0.06370),
    (0.25650, 0.37770, 0.39960),
)


def rwp(project: G2.G2Project) -> float:
    _, obs, weights, calc = project.histogram(0).data["data"][1][:4]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2)))


def p0_displacements(project: G2.G2Project) -> dict:
    phase = project.phases()[0]
    amat, _ = G2lat.cell2AB(phase.data["General"]["Cell"][1:7])
    values = []
    for atom, xyz0 in zip(phase.atoms(), ZNWO4_SOURCE):
        delta = np.asarray(atom.coordinates) - np.asarray(xyz0)
        delta -= np.round(delta)
        values.append(float(np.linalg.norm(np.inner(amat, delta))))
    return {
        "by_atom_A": {atom.label: value for atom, value in zip(phase.atoms(), values)},
        "max_A": max(values),
        "rms_A": float(np.sqrt(np.mean(np.square(values)))),
    }


def configure(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1] = 5.524
    inst["SH/L"][1] = 0.0868
    inst["Polariz."][1] = 0.988
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"]})
    hist.clear_refinements({"Background": True})
    for pidx, phase in enumerate(project.phases()):
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
        for atom in phase.atoms():
            atom.refinement_flags = "X" if pidx == 0 else " "
        if pidx == 2:
            for atom in phase.atoms():
                atom.uiso = 0.013
    project.set_Frozen()
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    configure(project)
    best = float("inf")
    best_path = args.output.with_name(args.output.stem + "-best.gpx")
    for iteration in range(6):
        project.set_Controls("cycles", 2)
        project.refine(makeBack=False)
        displacement = p0_displacements(project)
        result = {
            "iteration": iteration + 1,
            "rwp": rwp(project),
            "displacement": displacement,
            "coordinates": {atom.label: list(atom.coordinates) for atom in project.phases()[0].atoms()},
            "frozen": project.get_Frozen(),
        }
        print(json.dumps(result, indent=2), flush=True)
        # The forward model's documented mismatch cap is 0.08 A RMS. Retain
        # only snapshots comfortably inside that physical support.
        if result["rwp"] < best and displacement["rms_A"] <= 0.08 and not result["frozen"]:
            best = result["rwp"]
            project.save()
            shutil.copy2(project.filename, best_path)
    final = G2.G2Project(gpxfile=str(best_path), newgpx=str(args.output.resolve()))
    final.save()


if __name__ == "__main__":
    main()
