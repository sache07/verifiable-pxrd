#!/usr/bin/env python3
"""Screen Suortti surface roughness starts against a converged powder model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project: G2.G2Project) -> float:
    _, obs, weights, calc = project.histogram(0).data["data"][1][:4]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2)))


def configure(project: G2.G2Project, start_a: float, start_b: float) -> None:
    hist = project.histogram(0)
    # Isolate the angle-dependent common intensity correction while retaining
    # scales and a smooth background as nuisance terms.
    hist.clear_refinements({"Instrument Parameters": [
        "Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."
    ]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency"]})
    # A and B are nearly collinear over this angular range. Profile A on a
    # physically allowed grid and refine B, rather than retain a singular pair.
    hist.SampleParameters["SurfRoughA"] = [start_a, False]
    hist.SampleParameters["SurfRoughB"] = [start_b, True]
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
    hist.set_refinements({"Background": True})
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")
    project.set_Frozen()
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    starts = [(0.05, 0.023), (0.10, 0.0245), (0.20, 0.028), (0.40, 0.037), (0.60, 0.055)]
    results = []
    for index, (start_a, start_b) in enumerate(starts):
        path = args.outdir / f"rough-{index}.gpx"
        project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(path.resolve()))
        configure(project, start_a, start_b)
        project.set_Controls("cycles", 6)
        project.refine(makeBack=False)
        hist = project.histogram(0)
        result = {
            "path": str(path),
            "start": [start_a, start_b],
            "final": [hist.SampleParameters["SurfRoughA"][0], hist.SampleParameters["SurfRoughB"][0]],
            "rwp": rwp(project),
            "frozen": project.get_Frozen(),
            "vary": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
        }
        results.append(result)
        print(json.dumps(result), flush=True)
    best = min(results, key=lambda row: row["rwp"])
    shutil.copy2(best["path"], args.outdir / "rough-best.gpx")
    print(json.dumps({"best": best}, indent=2), flush=True)


if __name__ == "__main__":
    main()
