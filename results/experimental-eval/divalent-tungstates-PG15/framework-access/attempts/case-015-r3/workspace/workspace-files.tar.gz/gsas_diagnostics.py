#!/usr/bin/env python3
"""Print compact diagnostics for a GSAS-II powder project."""

from __future__ import annotations

import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def main(path: str) -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=path)
    hist = project.histogram(0)
    x, obs, weights, calc, background, residual = hist.data["data"][1][:6]
    denom = np.sum(weights * obs**2)
    rwp = 100.0 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / denom)
    rp = 100.0 * np.sum(np.abs(obs - calc)) / np.sum(np.abs(obs))
    expected = 100.0 * np.sqrt(len(obs) / denom)
    inst = hist.data["Instrument Parameters"][0]
    scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        scales.append(max(0.0, hap["Scale"][0]) * phase.data["General"]["Mass"])
    scales = np.asarray(scales)
    scales /= scales.sum()
    cov = project.data.get("Covariance", {}).get("data", {})
    info = {
        "file": path,
        "histogram": hist.name,
        "n_points": len(x),
        "limits": hist.data["Limits"],
        "rwp_percent": rwp,
        "rp_percent": rp,
        "poisson_expected_rwp_percent": expected,
        "chi_square": float(cov.get("Rvals", {}).get("chisq", np.nan)),
        "reduced_chi_square": float(cov.get("Rvals", {}).get("GOF", np.nan)) ** 2,
        "gsas_rvals": cov.get("Rvals", {}),
        "instrument": {key: inst[key] for key in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.") if key in inst},
        "sample": hist.SampleParameters,
        "background": hist.data["Background"],
        "profile_extrema": {
            "observed": [float(np.min(obs)), float(np.max(obs))],
            "calculated": [float(np.min(calc)), float(np.max(calc))],
            "background": [float(np.min(background)), float(np.max(background))],
            "residual": [float(np.min(residual)), float(np.max(residual))],
        },
        "phases": [],
        "frozen": project.get_Frozen(),
        "vary_list": cov.get("varyList", []),
    }
    for fraction, phase in zip(scales, project.phases()):
        hap = phase.data["Histograms"][hist.name]
        info["phases"].append({
            "name": phase.name,
            "weight_fraction": float(fraction),
            "cell": phase.get_cell(),
            "space_group": phase.data["General"]["SGData"].get("SpGrp"),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "extinction": hap["Extinction"],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "occupancy": atom.occupancy,
                    "uiso": atom.uiso,
                    "flags": atom.refinement_flags,
                    "adp_type": atom.data[atom.cia],
                }
                for atom in phase.atoms()
            ],
        })
    print(json.dumps(info, indent=2, default=lambda value: value.tolist() if hasattr(value, "tolist") else str(value)))


if __name__ == "__main__":
    main(sys.argv[1])
