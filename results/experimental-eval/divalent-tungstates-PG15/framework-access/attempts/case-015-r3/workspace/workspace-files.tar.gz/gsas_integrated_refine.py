#!/usr/bin/env python3
"""Final integrated refinement with only supported structural degrees of freedom."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


SOURCE = {
    0: (
        (0.00000, 0.18258, 0.25000),
        (0.50000, 0.68400, 0.25000),
        (0.21690, 0.10510, -0.06370),
        (0.25650, 0.37770, 0.39960),
    ),
    1: (
        (0.714, 0.487, 0.721),
        (0.225, 0.474, 0.007),
        (0.028, 0.037, 0.746),
        (0.716, 0.043, 0.708),
        (0.998, 0.262, 0.712),
        (0.206, 0.042, 0.995),
        (0.534, 0.023, 0.750),
        (0.519, 0.259, 0.789),
    ),
    2: (
        (0.33333, 0.66667, 0.00000),
        (0.33333, 0.66667, 0.38210),
    ),
}


def rwp(project: G2.G2Project) -> float:
    _, obs, weights, calc = project.histogram(0).data["data"][1][:4]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2)))


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    raw = np.asarray([
        max(phase.data["Histograms"][hist.name]["Scale"][0], 0.0) * phase.data["General"]["Mass"]
        for phase in project.phases()
    ])
    raw /= raw.sum()
    return {phase.name: float(value) for phase, value in zip(project.phases(), raw)}


def displacement(project: G2.G2Project, pidx: int) -> dict:
    phase = project.phases()[pidx]
    amat, _ = G2lat.cell2AB(phase.data["General"]["Cell"][1:7])
    values = []
    for atom, xyz0 in zip(phase.atoms(), SOURCE[pidx]):
        delta = np.asarray(atom.coordinates) - np.asarray(xyz0)
        delta -= np.round(delta)
        values.append(float(np.linalg.norm(np.inner(amat, delta))))
    return {
        "by_atom_A": {atom.label: value for atom, value in zip(phase.atoms(), values)},
        "max_A": max(values),
        "rms_A": float(np.sqrt(np.mean(np.square(values)))),
    }


def configure(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["W"][1] = 40.0
    inst["X"][1] = 0.2
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.set_refinements({"Instrument Parameters": ["Zero", "U", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"]})
    hist.SampleParameters["SurfRoughA"] = [0.05, False]
    hist.set_refinements({"Sample Parameters": ["Shift", "SurfRoughB"]})
    hist.set_refinements({"Background": True})

    phases = project.phases()
    for pidx, phase in enumerate(phases):
        phase.set_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.uiso = 0.013 if pidx == 2 else 0.003
            atom.refinement_flags = " "

    phases[0].set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    for atom in phases[0].atoms():
        atom.refinement_flags = "X"

    phases[1].set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    }, [hist])
    for atom in phases[1].atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"

    p2hap = phases[2].data["Histograms"][hist.name]
    # The ZnO strain screen converged to the inactive boundary and was not
    # identifiable independently from its size term.
    p2hap["Mustrain"][1][0] = 0.0
    phases[2].set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    phases[2].atoms()[1].refinement_flags = "X"

    bounds = (
        (":0:Zero", -0.25, 0.25),
        (":0:U", 0.0, 40.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
        (":0:Shift", -800.0, 800.0),
        (":0:SurfRoughB", 0.02, 0.5),
        ("0:0:Size;i", 0.04, 1.5),
        ("1:0:Size;i", 0.04, 1.5),
        ("1:0:Mustrain;i", 0.0, 8000.0),
        ("2:0:Size;i", 0.04, 1.5),
    )
    for variable, low, high in bounds:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    project.set_Frozen()
    project.save()


def valid(project: G2.G2Project) -> bool:
    d0, d1, d2 = [displacement(project, index) for index in range(3)]
    return (
        not project.get_Frozen()
        and d0["rms_A"] <= 0.08
        and max(d1["by_atom_A"][label] for label in ("W1", "W2")) <= 0.12
        and d2["by_atom_A"]["O"] <= 0.12
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    configure(project)
    best = float("inf")
    best_path = args.output.with_name(args.output.stem + "-best.gpx")
    for iteration in range(8):
        project.set_Controls("cycles", 3)
        project.refine(makeBack=False)
        hist = project.histogram(0)
        inst = hist.data["Instrument Parameters"][0]
        profiles = {}
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            profiles[phase.name] = {"size_um": hap["Size"][1][0], "strain_ppm": hap["Mustrain"][1][0]}
        result = {
            "iteration": iteration + 1,
            "rwp": rwp(project),
            "fractions": fractions(project),
            "instrument": {key: inst[key][1] for key in ("Zero", "U", "W", "X", "SH/L", "Polariz.")},
            "sample": {key: hist.SampleParameters[key][0] for key in ("Shift", "SurfRoughA", "SurfRoughB")},
            "profiles": profiles,
            "displacements": {project.phases()[i].name: displacement(project, i) for i in range(3)},
            "frozen": project.get_Frozen(),
        }
        print(json.dumps(result, indent=2), flush=True)
        if result["rwp"] < best and valid(project):
            best = result["rwp"]
            project.save()
            shutil.copy2(project.filename, best_path)
    final = G2.G2Project(gpxfile=str(best_path), newgpx=str(args.output.resolve()))
    final.save()


if __name__ == "__main__":
    main()
