#!/usr/bin/env python3
"""Converge the final model after fixing boundary/correlated nuisance terms."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project: G2.G2Project) -> float:
    _, obs, weights, calc = project.histogram(0).data["data"][1][:4]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2)))


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    raw = np.asarray([
        max(0.0, phase.data["Histograms"][hist.name]["Scale"][0]) * phase.data["General"]["Mass"]
        for phase in project.phases()
    ])
    raw /= raw.sum()
    return {phase.name: float(value) for phase, value in zip(project.phases(), raw)}


def configure(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["U"] = [inst["U"][0], 0.0, False]
    inst["W"] = [inst["W"][0], 40.0, False]
    inst["X"] = [inst["X"][0], 0.2, False]
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.set_refinements({"Instrument Parameters": ["Zero", "SH/L", "Polariz."]})

    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"]})
    # Zero and specimen height were 99.95% correlated. Retain their converged
    # combined correction with height fixed and refine only Zero.
    hist.SampleParameters["Shift"] = [-239.44, False]
    hist.SampleParameters["SurfRoughA"] = [0.05, False]
    hist.set_refinements({"Sample Parameters": ["SurfRoughB"]})
    hist.set_refinements({"Background": True})

    phases = project.phases()
    for pidx, phase in enumerate(phases):
        phase.set_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.uiso = 0.013 if pidx == 2 else 0.003
            atom.refinement_flags = " "

    phases[0].set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    for atom in phases[0].atoms():
        atom.refinement_flags = "X"

    phases[1].set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    }, [hist])
    for atom in phases[1].atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"

    # ZnO is minor and its internal coordinate was weakly determined. Fix it
    # at the last displacement-supported solution (0.052 A from the source).
    phases[2].atoms()[1].coordinates = [0.33333, 0.66667, 0.37209876879300524]
    p2hap = phases[2].data["Histograms"][hist.name]
    p2hap["Mustrain"][1][0] = 0.0
    phases[2].set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])

    for variable, low, high in (
        (":0:Zero", -0.25, 0.25),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
        (":0:SurfRoughB", 0.02, 0.5),
        ("0:0:Size;i", 0.04, 1.5),
        ("1:0:Size;i", 0.04, 1.5),
        ("1:0:Mustrain;i", 0.0, 8000.0),
        ("2:0:Size;i", 0.04, 1.5),
    ):
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    project.set_Frozen()
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    configure(project)
    best = float("inf")
    best_path = args.output.with_name(args.output.stem + "-best.gpx")
    for iteration in range(6):
        project.set_Controls("cycles", 3)
        project.refine(makeBack=False)
        hist = project.histogram(0)
        result = {
            "iteration": iteration + 1,
            "rwp": rwp(project),
            "fractions": fractions(project),
            "zero": hist.data["Instrument Parameters"][0]["Zero"][1],
            "shift": hist.SampleParameters["Shift"][0],
            "roughness": [hist.SampleParameters["SurfRoughA"][0], hist.SampleParameters["SurfRoughB"][0]],
            "frozen": project.get_Frozen(),
        }
        print(json.dumps(result, indent=2), flush=True)
        if result["rwp"] < best and not result["frozen"]:
            best = result["rwp"]
            project.save()
            shutil.copy2(project.filename, best_path)
    final = G2.G2Project(gpxfile=str(best_path), newgpx=str(args.output.resolve()))
    final.save()


if __name__ == "__main__":
    main()
