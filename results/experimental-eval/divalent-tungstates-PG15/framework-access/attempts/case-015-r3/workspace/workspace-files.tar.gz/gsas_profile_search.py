#!/usr/bin/env python3
"""Screen additional phase broadening terms and WO3 strain anisotropy."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project: G2.G2Project) -> float:
    _, obs, weights, calc = project.histogram(0).data["data"][1][:4]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2)))


def freeze_model(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"]})
    hist.clear_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])


def iso_branch(source: Path, path: Path, pidx: int, size_start: float | None = None) -> dict:
    project = G2.G2Project(gpxfile=str(source.resolve()), newgpx=str(path.resolve()))
    freeze_model(project)
    hist = project.histogram(0)
    phase = project.phases()[pidx]
    hap = phase.data["Histograms"][hist.name]
    if size_start is not None:
        hap["Size"][1][0] = size_start
    if hap["Mustrain"][1][0] <= 0:
        hap["Mustrain"][1][0] = 300.0
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    }, [hist])
    project.set_Controls("parmMin", 0.04, variable=f"{pidx}:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{pidx}:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{pidx}:0:Mustrain;i")
    project.set_Frozen()
    project.save()
    project.set_Controls("cycles", 6)
    project.refine(makeBack=False)
    return {
        "kind": "isotropic_both",
        "phase_index": pidx,
        "phase": phase.name,
        "start_size": size_start,
        "size_um": hap["Size"][1][0],
        "strain_ppm": hap["Mustrain"][1][0],
        "rwp": rwp(project),
        "frozen": project.get_Frozen(),
        "path": str(path),
    }


def uniaxial_branch(source: Path, path: Path, axis: tuple[int, int, int]) -> dict:
    project = G2.G2Project(gpxfile=str(source.resolve()), newgpx=str(path.resolve()))
    freeze_model(project)
    hist = project.histogram(0)
    pidx = 1
    phase = project.phases()[pidx]
    hap = phase.data["Histograms"][hist.name]
    value = hap["Mustrain"][1][0]
    hap["Mustrain"][1][1] = value * 1.05
    phase.set_HAP_refinements({"Mustrain": {
        "type": "uniaxial", "direction": axis, "refine": True
    }}, [hist])
    for suffix in ("i", "a"):
        project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;{suffix}")
        project.set_Controls("parmMax", 8000.0, variable=f"{pidx}:0:Mustrain;{suffix}")
    project.set_Frozen()
    project.save()
    project.set_Controls("cycles", 6)
    project.refine(makeBack=False)
    return {
        "kind": "uniaxial_strain",
        "phase_index": pidx,
        "phase": phase.name,
        "axis": axis,
        "equatorial_ppm": hap["Mustrain"][1][0],
        "axial_ppm": hap["Mustrain"][1][1],
        "rwp": rwp(project),
        "frozen": project.get_Frozen(),
        "path": str(path),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--uniax-only", action="store_true")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    results = []
    if not args.uniax_only:
        jobs = [(0, None), (1, 0.10), (1, 0.30), (1, 1.0), (2, None)]
        for index, (pidx, start) in enumerate(jobs):
            result = iso_branch(args.source, args.outdir / f"iso-{index}.gpx", pidx, start)
            results.append(result)
            print(json.dumps(result), flush=True)
    for index, axis in enumerate(((0, 0, 1), (1, 0, 0), (0, 1, 0))):
        result = uniaxial_branch(args.source, args.outdir / f"uniax-{index}.gpx", axis)
        results.append(result)
        print(json.dumps(result), flush=True)
    print(json.dumps({"results": results}, indent=2), flush=True)


if __name__ == "__main__":
    main()
