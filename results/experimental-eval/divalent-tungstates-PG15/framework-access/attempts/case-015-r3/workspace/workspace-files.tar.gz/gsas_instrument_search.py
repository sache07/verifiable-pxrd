#!/usr/bin/env python3
"""Profile remaining common instrument/calibration parameters."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SPECS = {
    "Zero": (-0.25, 0.25),
    "SH/L": (0.005, 0.10),
    "Polariz.": (0.5, 1.0),
    "U": (0.0, 40.0),
    "W": (2.0, 40.0),
}


def rwp(project: G2.G2Project) -> float:
    _, obs, weights, calc = project.histogram(0).data["data"][1][:4]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2)))


def configure(project: G2.G2Project, parameter: str, start: float | None) -> None:
    hist = project.histogram(0)
    keys = ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]
    hist.clear_refinements({"Instrument Parameters": keys})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"]})
    hist.clear_refinements({"Background": True})
    inst = hist.data["Instrument Parameters"][0]
    if start is not None:
        inst[parameter][1] = start
    hist.set_refinements({"Instrument Parameters": [parameter]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
    low, high = SPECS[parameter]
    project.set_Controls("parmMin", low, variable=f":0:{parameter}")
    project.set_Controls("parmMax", high, variable=f":0:{parameter}")
    project.set_Frozen()
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    jobs = [
        ("Zero", None),
        ("SH/L", None),
        ("Polariz.", 0.95),
        ("U", 0.0),
        ("U", 10.0),
        ("W", 38.0),
    ]
    results = []
    for index, (parameter, start) in enumerate(jobs):
        path = args.outdir / f"instrument-{index}.gpx"
        project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(path.resolve()))
        configure(project, parameter, start)
        project.set_Controls("cycles", 6)
        project.refine(makeBack=False)
        inst = project.histogram(0).data["Instrument Parameters"][0]
        result = {
            "parameter": parameter,
            "start": start,
            "value": inst[parameter][1],
            "rwp": rwp(project),
            "frozen": project.get_Frozen(),
            "path": str(path),
        }
        results.append(result)
        print(json.dumps(result), flush=True)
    print(json.dumps({"results": results}, indent=2), flush=True)


if __name__ == "__main__":
    main()
