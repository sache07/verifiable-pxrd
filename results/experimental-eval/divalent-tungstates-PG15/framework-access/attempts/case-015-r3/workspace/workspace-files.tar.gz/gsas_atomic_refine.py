#!/usr/bin/env python3
"""Monitored heavy-atom/ADP refinement from a physically valid parent model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project):
    d = project.histogram(0).data["data"][1]
    return float(100 * np.sqrt(np.sum(d[2] * (d[1] - d[3]) ** 2) / np.sum(d[2] * d[1] ** 2)))


def atom_displacements(project, start):
    result = {}
    for pidx, phase in enumerate(project.phases()):
        # GSAS-II cell convention is sufficient for reporting a conservative
        # nearest-image displacement diagnostic here.
        cell = phase.get_cell()
        from GSASII import GSASIIlattice as G2lat
        amat, _ = G2lat.cell2AB((cell["length_a"], cell["length_b"], cell["length_c"],
                                cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]))
        shifts = []
        for atom, xyz0 in zip(phase.atoms(), start[pidx]):
            delta = np.asarray(atom.coordinates) - np.asarray(xyz0)
            delta -= np.round(delta)
            shifts.append(float(np.linalg.norm(np.inner(amat, delta))))
        result[phase.name] = {"max_A": max(shifts), "rms_A": float(np.sqrt(np.mean(np.square(shifts)))),
                              "by_atom_A": shifts}
    return result


def configure(project):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][2] = False
    inst["W"][2] = False
    project.set_Frozen()

    phases = project.phases()
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = " "

    # Convert the old anisotropic ZnO source ADPs to the isotropic form used by
    # the synthetic specimen model. The atom record has storage for both forms.
    for atom in phases[2].atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.008

    # Apply a fixed common isotropic U within each phase, as in the forward
    # model. ADPs are weakly determined here; allowing them to refine drove
    # heavy-phase values negative, so retain physically supported values.
    for pidx, phase in enumerate(phases):
        value = 0.007 if pidx == 2 else 0.003
        for atom in phase.atoms():
            atom.uiso = value
            atom.refinement_flags = " "

    # Refine coordinates only where Cu X-rays carry substantial information.
    for atom in phases[0].atoms():
        if atom.element in {"W", "Zn"}:
            atom.refinement_flags = "X"
    for atom in phases[1].atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"
    # Fix the ZnO origin on Zn and refine only the internal oxygen coordinate.
    phases[2].atoms()[1].refinement_flags = "X"
    project.save()


def run(source: Path, output: Path):
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    start = [[atom.coordinates for atom in phase.atoms()] for phase in project.phases()]
    configure(project)
    best = float("inf")
    best_path = output.with_name(output.stem + "-best.gpx")
    for iteration in range(5):
        project.set_Frozen()
        project.set_Controls("cycles", 2)
        project.refine(makeBack=False)
        score = rwp(project)
        info = {"iteration": iteration + 1, "Rwp": score,
                "displacements": atom_displacements(project, start),
                "uiso": {phase.name: [atom.uiso for atom in phase.atoms()] for phase in project.phases()},
                "frozen": project.get_Frozen()}
        print(json.dumps(info, indent=2), flush=True)
        if score < best:
            best = score
            project.save()
            shutil.copy2(project.filename, best_path)
    final = G2.G2Project(gpxfile=str(best_path), newgpx=str(output))
    final.save()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run(args.source.resolve(), args.output.resolve())


if __name__ == "__main__":
    main()
