#!/usr/bin/env python3
"""Stabilize profile parameters in an existing multiphase GSAS-II project."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp_full(hist) -> float:
    _, obs, weights, calc = hist.data["data"][1][:4]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2)))


def fractions(project):
    hist = project.histogram(0)
    values = [
        max(phase.data["Histograms"][hist.name]["Scale"][0], 0.0) * phase.data["General"]["Mass"]
        for phase in project.phases()
    ]
    total = sum(values)
    return {phase.name: value / total for phase, value in zip(project.phases(), values)}


def status(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    print(json.dumps({
        "label": label,
        "full_Rwp": rwp_full(hist),
        "GSAS_Rwp": hist.get_wR(),
        "fractions": fractions(project),
        "instrument": {k: inst[k][1] for k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")},
        "sample": {k: hist.SampleParameters[k][0] for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "profile": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"][:4],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"][:4],
            }
            for phase in project.phases()
        },
        "frozen": project.get_Frozen(),
    }, indent=2, default=float), flush=True)


def refine_rounds(project, label, rounds=4, cycles=3, best_path=None):
    best = float("inf")
    for i in range(rounds):
        project.set_Frozen()
        project.set_Controls("cycles", cycles)
        project.refine(makeBack=False)
        status(project, f"{label}_{i + 1}")
        score = rwp_full(project.histogram(0))
        if best_path is not None and score < best:
            best = score
            project.save()
            shutil.copy2(project.filename, best_path)


def run(source: Path, output: Path):
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = project.histogram(0)
    phases = project.phases()
    x = hist.data["data"][1][0]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})

    inst = hist.data["Instrument Parameters"][0]
    for key, value in (("U", 20.0), ("W", 30.0), ("X", 0.2)):
        inst[key][1] = value
        inst[key][2] = False
    # Common nuisance values from the profile-wide search. They lie within the
    # stated laboratory support and are held fixed while phase models are compared.
    inst["SH/L"][1] = 0.088
    inst["Polariz."][1] = 1.0
    inst["SH/L"][2] = False
    inst["Polariz."][2] = False

    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    hist.SampleParameters["Shift"][0] = -70.0
    for phase in phases:
        # Profile optimization should not be able to trade peak width against
        # unconstrained coordinate shifts. Coordinates are handled in a later,
        # monitored stage.
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
    # A preliminary bounded search showed that ZnWO4 and ZnO are size-broadened
    # with no resolvable strain, while WO3 is strain-broadened and its size is
    # not separately identifiable. Use that lower-dimensional parameterization.
    phases[0].setSampleProfile(hist, "size", "isotropic", 0.11, LGmix=1.0)
    phases[0].setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    phases[0].set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    phases[1].setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=1.0)
    phases[1].setSampleProfile(hist, "microstrain", "isotropic", 2800.0, LGmix=1.0)
    phases[1].set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    phases[2].setSampleProfile(hist, "size", "isotropic", 0.05, LGmix=1.0)
    phases[2].setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    phases[2].set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])

    # Enforce the actual laboratory's physical support for common instrumental
    # broadening; effective phase terms remain slightly broader to absorb the
    # X/size degeneracy.
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMax", 40.0, variable=":0:U")
    project.set_Controls("parmMin", 2.0, variable=":0:W")
    project.set_Controls("parmMax", 40.0, variable=":0:W")
    for i in range(len(phases)):
        project.set_Controls("parmMin", 0.01, variable=f"{i}:0:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{i}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{i}:0:Mustrain;i")
        project.set_Controls("parmMax", 15000.0, variable=f"{i}:0:Mustrain;i")
    project.save()
    status(project, "reset")

    # W converged to the physical upper edge in the broad search. Fixing it
    # there avoids its strong correlation with all three phase widths.
    inst["U"][1] = 5.0
    inst["W"][1] = 40.0
    inst["U"][2] = True
    inst["W"][2] = False
    best_path = output.with_name(output.stem + "-best.gpx")
    refine_rounds(project, "stable_profile", rounds=4, cycles=4, best_path=best_path)
    # Finish on the best converged snapshot, not a later oscillatory iterate.
    best_project = G2.G2Project(gpxfile=str(best_path), newgpx=str(output))
    best_project.save()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run(args.source.resolve(), args.output.resolve())


if __name__ == "__main__":
    main()
