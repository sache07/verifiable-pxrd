#!/usr/bin/env python3
"""Staged physically bounded refinement of the selected three-phase model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def rwp(project: G2.G2Project) -> float:
    _, obs, weights, calc = project.histogram(0).data["data"][1][:4]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2)))


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    raw = np.array([
        max(0.0, phase.data["Histograms"][hist.name]["Scale"][0]) * phase.data["General"]["Mass"]
        for phase in project.phases()
    ])
    raw /= raw.sum()
    return {phase.name: float(value) for phase, value in zip(project.phases(), raw)}


def displacements(project: G2.G2Project, start: list[list[np.ndarray]]) -> dict[str, dict[str, float]]:
    result = {}
    for pidx, phase in enumerate(project.phases()):
        amat, _ = G2lat.cell2AB(phase.data["General"]["Cell"][1:7])
        values = []
        for atom, xyz0 in zip(phase.atoms(), start[pidx]):
            delta = np.asarray(atom.coordinates) - xyz0
            delta -= np.round(delta)
            values.append(float(np.linalg.norm(np.inner(amat, delta))))
        result[phase.name] = {"max_A": max(values), "rms_A": float(np.sqrt(np.mean(np.square(values))))}
    return result


def configure(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    phases = project.phases()
    # Preserve the profiled, nonsingular roughness representation.
    hist.SampleParameters["SurfRoughA"] = [0.05, False]
    hist.SampleParameters["SurfRoughB"][1] = True
    hist.SampleParameters["Shift"][1] = True
    hist.set_refinements({"Background": True, "Instrument Parameters": ["Zero"]})
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "SH/L", "Polariz."):
        inst[key][2] = False
    # Retain the stable profile parameterization selected in the broad search.
    for pidx, phase in enumerate(phases):
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}, [hist])
        for atom in phase.atoms():
            atom.refinement_flags = " "
            atom.uiso = 0.007 if pidx == 2 else 0.003
        if pidx == 0:
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
            for atom in phase.atoms():
                if atom.element in {"W", "Zn"}:
                    atom.refinement_flags = "X"
        elif pidx == 1:
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
            for atom in phase.atoms():
                if atom.element == "W":
                    atom.refinement_flags = "X"
        else:
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
            phase.atoms()[1].refinement_flags = "X"
    # Bounds come directly from the stated laboratory support.
    for variable, low, high in (
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:SurfRoughB", 0.02, 0.5),
        ("0:0:Size;i", 0.04, 1.5),
        ("1:0:Mustrain;i", 0.0, 8000.0),
        ("2:0:Size;i", 0.04, 1.5),
    ):
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    project.set_Frozen()
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve()))
    start = [[np.asarray(atom.coordinates, dtype=float) for atom in phase.atoms()] for phase in project.phases()]
    configure(project)
    best = float("inf")
    best_path = args.output.with_name(args.output.stem + "-best.gpx")
    for iteration in range(5):
        project.set_Controls("cycles", 3)
        project.refine(makeBack=False)
        hist = project.histogram(0)
        score = rwp(project)
        row = {
            "iteration": iteration + 1,
            "rwp": score,
            "fractions": fractions(project),
            "zero": hist.data["Instrument Parameters"][0]["Zero"][1],
            "shift": hist.SampleParameters["Shift"][0],
            "roughness": [hist.SampleParameters["SurfRoughA"][0], hist.SampleParameters["SurfRoughB"][0]],
            "displacements_from_input": displacements(project, start),
            "frozen": project.get_Frozen(),
        }
        print(json.dumps(row, indent=2), flush=True)
        if score < best and not project.get_Frozen():
            best = score
            project.save()
            shutil.copy2(project.filename, best_path)
    final = G2.G2Project(gpxfile=str(best_path), newgpx=str(args.output.resolve()))
    final.save()


if __name__ == "__main__":
    main()
