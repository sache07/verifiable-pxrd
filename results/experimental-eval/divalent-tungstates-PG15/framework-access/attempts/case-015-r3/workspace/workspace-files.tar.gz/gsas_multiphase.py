#!/usr/bin/env python3
"""Three-phase GSAS-II refinement for ZnWO4 + WO3 + ZnO."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PHASES = (
    ("ZnWO4", "1520641"),
    ("WO3", "1528915"),
    ("ZnO", "9004178"),
)


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_instrument(path: Path) -> None:
    path.write_text(
        "# Cu K-alpha laboratory instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.15;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:20.0;X:0.2;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def rwp(hist) -> float:
    x, obs, weights, calc = hist.data["data"][1][:4]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2)))


def fractions(project) -> dict[str, float]:
    hist = project.histogram(0)
    raw = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw.append(max(float(hap["Scale"][0]), 0.0) * float(phase.data["General"]["Mass"]))
    total = sum(raw)
    return {phase.name: value / total for phase, value in zip(project.phases(), raw)}


def summary(project, label: str) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    out = {
        "step": label,
        "Rwp": rwp(hist),
        "GSAS_Rwp": hist.get_wR(),
        "fractions": fractions(project),
        "instrument": {k: inst[k][1] for k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")},
        "sample": {k: hist.SampleParameters[k][0] for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"][1][:3],
            "mustrain": hap["Mustrain"][1][:3],
            "PO": hap["Pref.Ori."][:4],
        }
    print(json.dumps(out, indent=2, default=float), flush=True)


def refine(project, label: str, cycles: int = 6) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    summary(project, label)


def build(outdir: Path, wo3_id: str = "1528915"):
    outdir.mkdir(parents=True, exist_ok=True)
    inst = outdir / "instrument.instprm"
    write_instrument(inst)
    project = G2.G2Project(newgpx=str(outdir / "working.gpx"))
    phase_specs = (("ZnWO4", "1520641"), ("WO3", wo3_id), ("ZnO", "9004178"))
    phases = [
        project.add_phase(str(cod_path(cod_id)), phasename=name, fmthint="CIF")
        for name, cod_id in phase_specs
    ]
    hist = project.add_powder_histogram(
        str(PATTERN), str(inst), phases=phases, fmthint="comma"
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": 18,
                        "coeffs": [500.0] + [0.0] * 17, "refine": True}}
    )
    for i, phase in enumerate(phases):
        phase.HAPvalue("Scale", 10.0 if i == 0 else 2.0, targethistlist=[hist])
        phase.setSampleProfile(hist, "size", "isotropic", 0.12, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 500.0, LGmix=1.0)
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.save()
    for variable, lo, hi in (
        (":0:Zero", -0.6, 0.6), (":0:U", 0.0, 100.0), (":0:W", 0.1, 120.0),
        (":0:SH/L", 0.001, 0.2), (":0:Polariz.", 0.35, 1.0),
        (":0:Shift", -1200.0, 1200.0), (":0:SurfRoughA", 0.0, 0.9),
        (":0:SurfRoughB", 0.0, 2.0),
    ):
        project.set_Controls("parmMin", lo, variable=variable)
        project.set_Controls("parmMax", hi, variable=variable)
    for i in range(len(phases)):
        for suffix, lo, hi in (("Size;i", 0.015, 10.0), ("Mustrain;i", 0.0, 20000.0),
                               ("Mustrain;u", 0.0, 20000.0), ("Mustrain;a", 0.0, 20000.0),
                               ("MD", 0.5, 2.0)):
            project.set_Controls("parmMin", lo, variable=f"{i}:0:{suffix}")
            project.set_Controls("parmMax", hi, variable=f"{i}:0:{suffix}")
    project.save()
    return project, hist, phases


def run(outdir: Path, wo3_id: str = "1528915") -> None:
    project, hist, phases = build(outdir, wo3_id=wo3_id)
    summary(project, "initial")
    refine(project, "scales_background", 8)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "zero_cells", 8)
    project.save(outdir / "positions.gpx")

    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    refine(project, "sizes", 8)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    refine(project, "instrument_profile", 8)

    # Turn on strain only after the common instrument terms and size have
    # stabilized, to reduce broadening correlations.
    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    refine(project, "microstrain", 8)
    project.save(outdir / "profile.gpx")

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = "X"
    refine(project, "coordinates_polarization", 10)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "shift", 8)
    refine(project, "polish", 10)
    project.save(outdir / "multiphase.gpx")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", type=Path, default=ROOT / ".tmp" / "multi")
    parser.add_argument("--wo3-id", default="1528915")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run(args.outdir.resolve(), wo3_id=args.wo3_id)


if __name__ == "__main__":
    main()
