#!/usr/bin/env python3
"""Check smooth Chebyshev background order without changing phase models."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project: G2.G2Project) -> float:
    _, obs, weights, calc = project.histogram(0).data["data"][1][:4]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2)))


def configure(project: G2.G2Project, order: int) -> None:
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"]})
    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": order, "refine": True}})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.set_Frozen()
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    results = []
    for order in (18, 24, 30, 36):
        path = args.outdir / f"background-{order}.gpx"
        project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(path.resolve()))
        configure(project, order)
        project.set_Controls("cycles", 6)
        project.refine(makeBack=False)
        background = project.histogram(0).data["data"][1][4]
        result = {
            "order": order,
            "rwp": rwp(project),
            "background_min": float(np.min(background)),
            "background_max": float(np.max(background)),
            "frozen": project.get_Frozen(),
            "path": str(path),
        }
        results.append(result)
        print(json.dumps(result), flush=True)
    print(json.dumps({"results": results}, indent=2), flush=True)


if __name__ == "__main__":
    main()
