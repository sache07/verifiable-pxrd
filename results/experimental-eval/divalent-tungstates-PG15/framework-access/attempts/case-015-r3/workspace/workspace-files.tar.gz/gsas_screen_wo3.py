#!/usr/bin/env python3
"""Compare candidate WO3 structures in the established three-phase model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def rwp(hist):
    _, obs, weights, calc = hist.data["data"][1][:4]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2)))


def run(wo3_id: str, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    inst = outdir / "instrument.instprm"
    inst.write_text(
        "# Cu K-alpha laboratory instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.15;Polariz.:1.0;Azimuth:0.0\n"
        "U:0.0;V:0.0;W:40.0;X:0.2;Y:0.0;Z:0.0;SH/L:0.088\n"
    )
    project = G2.G2Project(newgpx=str(outdir / "screen.gpx"))
    specs = (("ZnWO4", "1520641"), ("WO3", wo3_id), ("ZnO", "9004178"))
    phases = [project.add_phase(str(cod_path(cid)), phasename=name, fmthint="CIF") for name, cid in specs]
    hist = project.add_powder_histogram(str(ROOT / "inputs" / "pattern.csv"), str(inst),
                                         phases=phases, fmthint="comma")
    x = hist.data["data"][1][0]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])],
                          "Background": {"type": "chebyschev-1", "no. coeffs": 18,
                                         "coeffs": [500.0] + [0.0] * 17, "refine": True}})
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [-70.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    starts = ((0.11, 0.0), (1.0, 5000.0), (0.08, 0.0))
    for phase, (size, strain) in zip(phases, starts):
        phase.HAPvalue("Scale", 5.0)
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phase.setSampleProfile(hist, "size", "isotropic", size, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", strain, LGmix=1.0)
        phase.set_refinements({"Cell": True})
    phases[0].set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    phases[1].set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    phases[2].set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save()
    result = {"wo3_id": wo3_id, "Rwp": rwp(hist), "GSAS_Rwp": hist.get_wR(),
              "cell": phases[1].get_cell(),
              "scales": {p.name: p.data["Histograms"][hist.name]["Scale"][0] for p in phases}}
    (outdir / "screen.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    run(args.wo3_id, args.outdir.resolve())


if __name__ == "__main__":
    main()
