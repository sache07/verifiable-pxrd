from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def refine(project, label):
    project.set_Controls("cycles", 10)
    project.refine()
    print(label, project.histogram(0).residuals["wR"])


def main(cod_id, tag):
    project = G2.G2Project(newgpx=str(ROOT / f"variant_{tag}.gpx"))
    project.add_phase(str(ROOT / "NiWO4_start.cif"), phasename="NiWO4", fmthint="CIF")
    project.add_phase(str(cod_path(cod_id)), phasename=f"WO3_{cod_id}", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"),
        phases="all", fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.InstrumentParameters["U"][1:] = [5.0, False]
    hist.set_refinements({
        "Limits": [10.01, 99.99],
        "Background": {
            "type": "chebyschev-1", "no. coeffs": 12,
            "coeffs": [700.0] + [0.0] * 11, "refine": True,
        },
    })
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.uiso = 0.01
    refine(project, "scales")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, "cells")
    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 0.8, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    refine(project, "profile")
    for phase in project.phases():
        for atom in phase.atoms():
            if atom.element in {"W", "Ni"}:
                atom.refinement_flags = "X"
    refine(project, "heavy")
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "X"
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "all")
    project.save()
    q = np.asarray([
        p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
        for p in project.phases()
    ])
    print("RESULT", tag, hist.residuals, (q / q.sum()).tolist())
    print("INST", {k: v[1:] for k, v in hist.InstrumentParameters.items() if k in ["Zero", "Polariz.", "U", "W", "X", "SH/L"]})
    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        print("PHASE", p.name, p.get_cell(), "size", hap["Size"][:3], "strain", hap["Mustrain"][:3])


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
