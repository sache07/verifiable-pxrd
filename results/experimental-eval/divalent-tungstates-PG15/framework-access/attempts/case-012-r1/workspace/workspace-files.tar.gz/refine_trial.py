from pathlib import Path
import csv
import math
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WO3_SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/31/10/2311041.cif"
)


def prepare_inputs():
    rows = []
    with (ROOT / "inputs/pattern.csv").open(newline="") as fp:
        for row in csv.DictReader(fp):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            rows.append((x, y, math.sqrt(max(y, 1.0))))
    with (ROOT / "pattern.xye").open("w") as fp:
        fp.write("# 2theta intensity sigma\n")
        for x, y, sig in rows:
            fp.write(f"{x:.8f} {y:.8f} {sig:.8f}\n")

    (ROOT / "instrument.instprm").write_text(
        "# GSAS-II Cu Kalpha laboratory starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.80;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    shutil.copyfile(WO3_SOURCE, ROOT / "WO3_start.cif")


def report(project, label):
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print(
        "instrument",
        {k: inst[k][1] for k in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."] if k in inst},
    )
    print(
        "sample",
        {k: sample[k][0] if isinstance(sample.get(k), list) else sample.get(k)
         for k in ["Scale", "Shift", "SurfRoughA", "SurfRoughB", "Transparency"]},
    )
    scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        scales.append(hap["Scale"][0] * phase.data["General"]["Mass"])
        print(
            phase.name,
            "cell", phase.get_cell(),
            "scale", hap["Scale"][0],
            "size", hap["Size"][:3],
            "mustrain", hap["Mustrain"][:3],
            "PO", hap["Pref.Ori."][:4],
        )
    scales = np.asarray(scales)
    print("weight fractions", scales / scales.sum())
    project.save()


def run():
    prepare_inputs()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(ROOT / "trial.gpx"))
    niwo4 = project.add_phase(
        str(ROOT / "NiWO4_start.cif"), phasename="NiWO4", fmthint="CIF"
    )
    wo3 = project.add_phase(
        str(ROOT / "WO3_start.cif"), phasename="WO3", fmthint="CIF"
    )
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"),
        phases="all", fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.set_refinements({
        "Limits": [10.01, 99.99],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [700.0] + [0.0] * 11,
            "refine": True,
        },
    })
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.uiso = 0.01
    project.set_Controls("cycles", 8)
    project.refine()
    report(project, "background + scales")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    report(project, "zero")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine()
    report(project, "cells")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    project.refine()
    report(project, "instrument profile")

    for phase in project.phases():
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 1.0, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    project.refine()
    report(project, "phase broadening")

    project.save(str(ROOT / "trial.gpx"))


if __name__ == "__main__":
    run()
