from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def fractions(project):
    hist = project.histogram(0)
    q = np.array([
        p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
        for p in project.phases()
    ])
    return q / q.sum()


def main():
    source, tag, *actions = sys.argv[1:]
    project = G2.G2Project(str(ROOT / source), newgpx=str(ROOT / f"test_{tag}.gpx"))
    hist = project.histogram(0)
    for action in actions:
        if action == "shift":
            hist.SampleParameters["Shift"][1] = True
        elif action == "pol":
            hist.InstrumentParameters["Polariz."][2] = True
        elif action == "rough":
            hist.SampleParameters["SurfRoughA"] = [0.3, True]
            hist.SampleParameters["SurfRoughB"] = [0.1, True]
        elif action.startswith("u="):
            value = float(action.split("=", 1)[1])
            hist.InstrumentParameters["U"][1] = value
            hist.InstrumentParameters["U"][2] = False
        elif action.startswith("x="):
            value = float(action.split("=", 1)[1])
            hist.InstrumentParameters["X"][1] = value
            hist.InstrumentParameters["X"][2] = False
        elif action == "fix-shl":
            hist.InstrumentParameters["SH/L"][2] = False
        elif action.startswith("nostrain"):
            phase = project.phases()[int(action[8:])]
            hap = phase.data["Histograms"][hist.name]
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        elif action.startswith("po"):
            # po<phase-index>=h,k,l
            lhs, rhs = action.split("=", 1)
            phase = project.phases()[int(lhs[2:])]
            axis = [int(v) for v in rhs.split(",")]
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = axis
        elif action.startswith("strain"):
            # strain<phase-index>=h,k,l
            lhs, rhs = action.split("=", 1)
            phase = project.phases()[int(lhs[6:])]
            axis = [int(v) for v in rhs.split(",")]
            hap = phase.data["Histograms"][hist.name]
            old = float(hap["Mustrain"][1][0])
            phase.set_HAP_refinements({
                "Mustrain": {
                    "type": "uniaxial", "direction": axis,
                    "refine": True,
                }
            })
            hap["Mustrain"][1][0] = max(old, 10.0)
            hap["Mustrain"][1][1] = max(old, 10.0)
        elif action == "uiso-heavy":
            for phase in project.phases():
                for atom in phase.atoms():
                    if atom.element in {"W", "Ni"}:
                        atom.refinement_flags = "XU" if "X" in atom.refinement_flags else "U"
        elif action == "uiso-all":
            for phase in project.phases():
                for atom in phase.atoms():
                    atom.refinement_flags = "XU" if "X" in atom.refinement_flags else "U"
        elif action.startswith("oxygen"):
            phase = project.phases()[int(action[6:])]
            for atom in phase.atoms():
                if atom.element == "O":
                    atom.refinement_flags = "X"
        else:
            raise ValueError(action)
    project.set_Controls("cycles", 15)
    project.refine()
    project.save()
    print("RESULT", tag, hist.residuals["wR"], fractions(project).tolist())
    print("INST", {k: v[1:] for k, v in hist.InstrumentParameters.items() if k in ["Zero", "Polariz.", "U", "V", "W", "X", "SH/L"]})
    print("SAMPLE", {k: hist.SampleParameters[k] for k in ["Scale", "Shift", "SurfRoughA", "SurfRoughB"]})
    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        print("PHASE", p.name, "size", hap["Size"][:3], "strain", hap["Mustrain"][:4], "po", hap["Pref.Ori."][:4])


if __name__ == "__main__":
    main()
