from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def summarize(project, tag):
    hist = project.histogram(0)
    print("\n", tag, hist.residuals)
    print("instrument", {k: v[1:] for k, v in hist.InstrumentParameters.items() if k in ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]})
    print("sample", hist.SampleParameters)
    weighted = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted.append(hap["Scale"][0] * phase.data["General"]["Mass"])
        print(phase.name, phase.get_cell(), "scale", hap["Scale"], "size", hap["Size"][:3], "strain", hap["Mustrain"][:3], "PO", hap["Pref.Ori."][:4])
        for atom in phase.atoms():
            print(" ", atom.label, atom.element, atom.coordinates, atom.refinement_flags, atom.uiso)
    weighted = np.asarray(weighted)
    print("weight fractions", weighted / weighted.sum())
    project.save()


def normalize_scale(project):
    hist = project.histogram(0)
    sample_scale = hist.SampleParameters["Scale"][0]
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][0] *= sample_scale
    hist.SampleParameters["Scale"] = [1.0, False]


def run(mode):
    out = ROOT / f"branch_{mode}.gpx"
    project = G2.G2Project(str(ROOT / "trial.gpx"), newgpx=str(out))
    hist = project.histogram(0)
    normalize_scale(project)
    hist.InstrumentParameters["U"][1] = 0.0
    hist.InstrumentParameters["U"][2] = False
    project.set_Controls("cycles", 12)
    project.refine()
    summarize(project, "fixed scale and U")

    if mode == "heavyX":
        for phase in project.phases():
            for atom in phase.atoms():
                if atom.element in {"W", "Ni"}:
                    atom.refinement_flags = "X"
    elif mode == "allX":
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = "X"
    elif mode == "heavyXU":
        for phase in project.phases():
            for atom in phase.atoms():
                if atom.element in {"W", "Ni"}:
                    atom.refinement_flags = "XU"
    elif mode == "allXU":
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = "XU"
    elif mode != "base":
        raise ValueError(mode)
    if mode != "base":
        project.refine()
        summarize(project, mode)
    project.save(str(out))


if __name__ == "__main__":
    run(sys.argv[1])
