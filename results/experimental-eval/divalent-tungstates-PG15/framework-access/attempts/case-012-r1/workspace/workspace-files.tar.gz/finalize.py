from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def main():
    project = G2.G2Project(
        str(ROOT / "test_u5.gpx"), newgpx=str(ROOT / "final.gpx")
    )
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("x"), dtype=float)
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})

    # Recalculate the saved profile over every measured bin without changing
    # the refined model parameters.
    project.set_Controls("cycles", 0)
    project.refine()
    project.save()

    observed = np.asarray(hist.getdata("yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("ycalc"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference, background]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f", "%.10f"],
    )

    # Export directly from the full-precision saved atoms. Clearing covariance
    # only during export mirrors GSAS-II's independent project replay behavior.
    covariance = project.data["Covariance"]["data"]
    project.data["Covariance"]["data"] = {}
    outputs = []
    for phase, filename in zip(
        project.phases(), ["phase_NiWO4.cif", "phase_WO3.cif"]
    ):
        phase.export_CIF(str(ROOT / filename))
        outputs.append((phase, filename))
    project.data["Covariance"]["data"] = covariance
    project.save()

    masses = np.asarray([
        phase.data["Histograms"][hist.name]["Scale"][0]
        * phase.data["General"]["Mass"]
        for phase, _ in outputs
    ])
    fractions = masses / masses.sum()
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    nvars = int(covariance.get("Rvals", {}).get("Nvars", len(covariance.get("varyList", []))))
    dof = max(1, len(x) - nvars)
    summary = {
        "histogram": hist.name,
        "fractions": fractions.tolist(),
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "r_exp_percent": float(hist.residuals.get("wRmin")),
            "chi_square": chi_square,
            "reduced_chi_square": chi_square / dof,
            "goodness_of_fit": float(np.sqrt(chi_square / dof)),
            "n_points": int(len(x)),
            "n_refined_parameters": nvars,
        },
        "cells": {phase.name: phase.get_cell() for phase, _ in outputs},
        "instrument": {
            key: float(hist.InstrumentParameters[key][1])
            for key in ["Zero", "Polariz.", "U", "V", "W", "X", "SH/L"]
        },
    }
    (ROOT / "final_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
