from __future__ import annotations

import copy
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags, rwp


SOURCE = Path(".tmp/background_60.gpx")
OUTPUT = Path(".tmp/final_optimized.gpx")


def snapshot(project: G2.G2Project):
    return copy.deepcopy(project.data), copy.deepcopy(project.names)


def restore(project: G2.G2Project, state) -> None:
    project.data, project.names = copy.deepcopy(state[0]), copy.deepcopy(state[1])
    project.update_ids()


def enable_scales(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def set_bounds(project: G2.G2Project) -> None:
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:Polariz.": (0.5, 1.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
    }
    for phase in project.phases():
        bounds[f"{phase.id}:0:Scale"] = (0.0, 1.0e6)
        bounds[f"{phase.id}:0:Size;i"] = (0.04, 1.5)
        bounds[f"{phase.id}:0:Mustrain;i"] = (0.0, 8000.0)
        bounds[f"{phase.id}:0:Mustrain;a"] = (0.0, 32000.0)
        bounds[f"{phase.id}:0:MD"] = (0.65, 1.5)
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)


def try_stage(project: G2.G2Project, label: str, setup, passes: int = 3) -> None:
    initial = rwp(project)
    best = initial
    best_state = snapshot(project)
    clear_flags(project)
    set_bounds(project)
    setup(project)
    project.set_Controls("cycles", 32)
    for index in range(passes):
        project.refine()
        current = rwp(project)
        last = np.asarray(project.data["Covariance"]["data"].get("Lastshft", []), float)
        shift = float(np.max(np.abs(last))) if last.size else 0.0
        print(label, index + 1, "Rwp", current, "maxshift", shift,
              "frozen", project.get_Frozen(), flush=True)
        if np.isfinite(current) and current < best:
            best = current
            best_state = snapshot(project)
        if not np.isfinite(current) or current > best + 0.01 or shift < 0.08:
            break
    restore(project, best_state)
    project.save(OUTPUT.resolve())
    print(label, "retained", best, "delta", best - initial, flush=True)


def with_scales(setup):
    def wrapped(project):
        enable_scales(project)
        setup(project)
    return wrapped


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE.resolve()), newgpx=str(OUTPUT.resolve()))
    set_bounds(project)
    print("START", rwp(project), flush=True)

    def instrument(project):
        hist = project.histogram(0)
        for name in ("U", "W", "X", "SH/L"):
            hist.InstrumentParameters[name][2] = True

    try_stage(project, "instrument", with_scales(instrument), passes=4)

    def calibration(project):
        hist = project.histogram(0)
        hist.InstrumentParameters["Zero"][2] = True
        hist.SampleParameters["Shift"][1] = True

    try_stage(project, "calibration", with_scales(calibration), passes=3)

    for phase_name in ("WO3", "CaWO4"):
        def phase_width(project, phase_name=phase_name):
            hist = project.histogram(0)
            hap = project.phase(phase_name).data["Histograms"][hist.name]
            hap["Size"][2][0] = True
            hap["Mustrain"][2] = [True, True, False]

        try_stage(project, f"width_{phase_name}", with_scales(phase_width), passes=4)

    def calcite_size(project):
        hist = project.histogram(0)
        project.phase("CaCO3").data["Histograms"][hist.name]["Size"][2][0] = True

    try_stage(project, "width_CaCO3_size", with_scales(calcite_size), passes=3)

    def calcite_strain(project):
        hist = project.histogram(0)
        project.phase("CaCO3").data["Histograms"][hist.name]["Mustrain"][2][0] = True

    try_stage(project, "width_CaCO3_strain", with_scales(calcite_strain), passes=3)

    for phase_name in ("CaWO4", "CaCO3"):
        def texture(project, phase_name=phase_name):
            hist = project.histogram(0)
            project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."][2] = True

        try_stage(project, f"texture_{phase_name}", with_scales(texture), passes=3)

    def final_background(project):
        project.histogram(0).data["Background"][0][1] = True

    try_stage(project, "background", with_scales(final_background), passes=4)

    # End with scales in the covariance matrix so mass-fraction uncertainties
    # are available, while leaving all model values otherwise fixed.
    try_stage(project, "scales", lambda p: enable_scales(p), passes=3)
    clear_flags(project)
    project.save(OUTPUT.resolve())
    print("FINAL", rwp(project), project.histogram(0).ComputeMassFracs(), flush=True)


if __name__ == "__main__":
    main()
