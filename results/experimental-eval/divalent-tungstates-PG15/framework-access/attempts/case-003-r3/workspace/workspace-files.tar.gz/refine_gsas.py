from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


ROOT = Path(__file__).resolve().parent
PHASE_FILES = {
    "WO3": ROOT / "starting_models" / "WO3.cif",
    "CaWO4": ROOT / "starting_models" / "CaWO4.cif",
    "CaCO3": ROOT / "starting_models" / "CaCO3.cif",
}


def make_xye() -> Path:
    raw = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    x = np.asarray(raw["two_theta_deg"], float)
    y = np.asarray(raw["intensity"], float)
    sigma = np.sqrt(np.maximum(y, 1.0))
    out = ROOT / "pattern.xye"
    np.savetxt(out, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    return out


def rolling_baseline(x: np.ndarray, y: np.ndarray) -> list[tuple[float, float]]:
    # Fixed points only seed the GSAS-II Chebyshev background coefficients.
    # A local low percentile avoids fitting the prominent Bragg peaks.
    points = []
    centers = np.linspace(float(x[0]) + 0.5, float(x[-1]) - 0.5, 48)
    for center in centers:
        vals = y[np.abs(x - center) <= 0.45]
        points.append((float(center), float(np.percentile(vals, 12))))
    return points


def fit_metrics(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    x, yo, w, yc, yb, yd = (np.asarray(a, float) for a in hist.data["data"][1][:6])
    denom = float(np.sum(w * yo * yo))
    rwp = 100.0 * np.sqrt(float(np.sum(w * (yo - yc) ** 2)) / denom)
    gof = float(project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF", np.nan))
    try:
        fractions = {k: list(v) for k, v in hist.ComputeMassFracs().items()}
    except Exception as exc:
        fractions = {"error": str(exc)}
    result = {
        "stage": label,
        "rwp_percent_all_points": rwp,
        "gsas_residuals": hist.residuals,
        "gof": gof,
        "background_min_max": [float(np.min(yb)), float(np.max(yb))],
        "calculated_min_max": [float(np.min(yc)), float(np.max(yc))],
        "fractions": fractions,
        "instrument": {
            key: val[:3] if isinstance(val, list) else val
            for key, val in hist.InstrumentParameters.items()
            if key in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "sample": {
            key: val
            for key, val in hist.SampleParameters.items()
            if key in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type"}
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "mass": phase.data["General"]["Mass"],
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": atom.coordinates,
                    "uiso": atom.uiso if atom.adp_flag == "I" else atom.ADP,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    print(json.dumps(result, indent=2, default=float))
    return result


def refine(project: G2.G2Project, label: str, snapshots: bool = True) -> dict:
    project.set_Controls("cycles", 12)
    for attempt in range(3):
        project.refine()
        last = np.asarray(project.data.get("Covariance", {}).get("data", {}).get("Lastshft", []), float)
        maximum = float(np.max(np.abs(last))) if last.size else 0.0
        print(f"stage {label} pass {attempt + 1}: maximum shift/esd={maximum:.4g}")
        if maximum < 0.15:
            break
    result = fit_metrics(project, label)
    if snapshots:
        project.save(ROOT / f"trial_{label}.gpx")
    return result


def initialize() -> G2.G2Project:
    G2.SetPrintLevel("warn")
    xye = make_xye()
    project = G2.G2Project(newgpx=str(ROOT / "trial.gpx"))
    hist = project.add_powder_histogram(str(xye), str(ROOT / "instrument.instprm"), fmthint="xye")
    x0 = np.genfromtxt(xye, max_rows=1)[0]
    x1 = np.genfromtxt(xye)[-1, 0]
    hist.set_refinements({"Limits": [float(x0), float(x1)]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    x, y = (np.asarray(a, float) for a in hist.data["data"][1][:2])
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [0.0] * 12,
                "FixedPoints": rolling_baseline(x, y),
                "fit fixed points": True,
                "refine": False,
            }
        }
    )

    for name, path in PHASE_FILES.items():
        phase = project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
        for atom in phase.atoms():
            atom.uiso = 0.005
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Size"][1][1] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 500.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]

    # Keep the uncalibrated profile/specimen model in its physically meaningful
    # region. This also prevents phase broadening from being spuriously absorbed
    # by a negative instrumental width term.
    limits = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Polariz.": (0.5, 1.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:Shift": (-800.0, 800.0),
    }
    for phase in project.phases():
        limits[f"{phase.id}:0:Scale"] = (0.0, 1.0e6)
        limits[f"{phase.id}:0:Size;i"] = (0.02, 10.0)
        limits[f"{phase.id}:0:Mustrain;i"] = (0.0, 20000.0)
        limits[f"{phase.id}::AUiso:*"] = (0.001, 0.03)
    for variable, (low, high) in limits.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)

    # Calculate once and put all phase scales near the observed count level.
    project.set_Controls("cycles", 0)
    project.refine()
    hist = project.histogram(0)
    x, yo, w, yc, yb = (np.asarray(a, float) for a in hist.data["data"][1][:5])
    target = float(np.max(np.maximum(yo - yb, 1.0)))
    current = float(np.max(np.maximum(yc - yb, 1e-12)))
    multiplier = target / current
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][0] *= multiplier
    project.save()
    fit_metrics(project, "initialized")
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--until",
        choices=["scales", "cells", "shift", "size", "strain", "instrument", "wcoords", "coords", "adp"],
        default="coords",
    )
    args = parser.parse_args()
    project = initialize()
    hist = project.histogram(0)

    # Scale, smooth background and the dominant constant angular offset.
    hist.set_refinements(
        {
            "Background": {"refine": True},
            "Instrument Parameters": ["Zero"],
        }
    )
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    refine(project, "scales")
    if args.until == "scales":
        return

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, "cells")
    if args.until == "cells":
        return

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "shift")
    if args.until == "shift":
        return

    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.5, "refine": True}})
    refine(project, "size")
    if args.until == "size":
        return

    for phase in project.phases():
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, "strain")
    if args.until == "strain":
        return

    project.set_Frozen()
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    refine(project, "instrument")
    if args.until == "instrument":
        return

    for phase in project.phases():
        for atom in phase.atoms():
            if atom.element == "W":
                atom.refinement_flags = "X"
    refine(project, "wcoords")
    if args.until == "wcoords":
        return

    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "X"
    refine(project, "coords")
    if args.until == "coords":
        return

    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "XU"
    refine(project, "adp")


if __name__ == "__main__":
    print(f"GSAS-II revision {GSASIIpath.GetVersionNumber()}")
    main()
