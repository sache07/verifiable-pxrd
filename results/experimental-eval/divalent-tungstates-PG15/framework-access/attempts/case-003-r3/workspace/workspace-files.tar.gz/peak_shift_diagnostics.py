from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np


parser = argparse.ArgumentParser()
parser.add_argument("profile", type=Path)
parser.add_argument("reflection_prefix", type=Path)
args = parser.parse_args()

profile = np.genfromtxt(args.profile, delimiter=",", names=True)
x = profile["two_theta_deg"]
observed = profile["observed"] - profile["background"]
calculated = profile["calculated"] - profile["background"]

for phase in ("WO3", "CaWO4", "CaCO3"):
    path = Path(str(args.reflection_prefix) + f"_{phase}_reflections.csv")
    refl = np.genfromtxt(path, delimiter=",", names=True)
    order = np.argsort(refl["Fcalc2"])[::-1]
    print("\n", phase)
    used = []
    for index in order:
        center = float(refl["two_theta_deg"][index])
        strength = float(refl["Fcalc2"][index])
        if not 15 < center < 95 or any(abs(center - prior) < 0.55 for prior in used):
            continue
        mask = np.abs(x - center) <= 0.34
        if np.count_nonzero(mask) < 20:
            continue
        xx = x[mask]
        yy = observed[mask]
        best = (np.inf, None, None)
        for width_scale in np.linspace(0.65, 1.45, 81):
            for shift in np.linspace(-0.08, 0.08, 81):
                source_x = center + (xx - center - shift) / width_scale
                model = np.interp(source_x, x, calculated)
                design = np.column_stack((model, np.ones_like(model), xx - center))
                coef, *_ = np.linalg.lstsq(design, yy, rcond=None)
                residual = yy - design @ coef
                loss = float(np.sum(residual**2 / np.maximum(profile["observed"][mask], 1.0)))
                if loss < best[0]:
                    best = (loss, shift, width_scale, coef)
        print(
            f"hkl=({int(refl['h'][index]):2d},{int(refl['k'][index]):2d},{int(refl['l'][index]):2d}) "
            f"2theta={center:8.4f} F2={strength:10.1f} local_shift(obs-calc)={best[1]:+7.4f} "
            f"width(obs/calc)={best[2]:5.2f} amp={best[3][0]:6.3f}"
        )
        used.append(center)
        if len(used) >= 18:
            break
