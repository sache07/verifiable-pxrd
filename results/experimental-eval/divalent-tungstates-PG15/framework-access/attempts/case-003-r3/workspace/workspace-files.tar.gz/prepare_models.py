from pathlib import Path
import sys
import warnings

from pymatgen.io.cif import CifParser


FRAMEWORK_RUNTIME = Path("learned/divalent-tungstates/runtime").resolve()
sys.path.insert(0, str(FRAMEWORK_RUNTIME))
from models import write_synthetic_model  # noqa: E402


sources = {
    "WO3": Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif"),
    "CaWO4": Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/7/21/92/7219229.cif"),
    "CaCO3": Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/54/73/1547347.cif"),
}

outdir = Path("starting_models")
outdir.mkdir(exist_ok=True)
for name, source in sources.items():
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        parser = CifParser(source, occupancy_tolerance=1.0, site_tolerance=1e-5, frac_tolerance=0)
        structures = parser.parse_structures(primitive=False, on_error="raise")
    if len(structures) != 1:
        raise RuntimeError(f"{source} supplied {len(structures)} structures")
    structure = structures[0]
    structure.remove_oxidation_states()
    output = outdir / f"{name}.cif"
    write_synthetic_model(structure, output)
    print(
        f"{name}: {structure.composition.reduced_formula}, {len(structure)} sites, "
        f"{structure.get_space_group_info(symprec=0.01)}, "
        f"cell={tuple(round(v, 6) for v in structure.lattice.abc + structure.lattice.angles)}; "
        f"warnings={[str(item.message) for item in caught]}"
    )
