from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


AXES_TEXTURE = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])
AXES_STRAIN = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def rwp(project: G2.G2Project) -> float:
    arrays = project.histogram(0).data["data"][1]
    yo, w, yc = (np.asarray(arrays[i], float) for i in (1, 2, 3))
    return float(100 * np.sqrt(np.sum(w * (yo - yc) ** 2) / np.sum(w * yo**2)))


def clear_flags(project: G2.G2Project) -> None:
    project.set_Frozen()
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], (bool, np.bool_)):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (bool, np.bool_)):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False


def fresh(source: Path, destination: Path) -> G2.G2Project:
    project = G2.G2Project(str(source.resolve()), newgpx=str(destination.resolve()))
    clear_flags(project)
    project.set_Controls("cycles", 16)
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--mode", choices=["texture", "strain", "roughness"], required=True)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    temp = Path(".tmp/effect_screens")
    temp.mkdir(parents=True, exist_ok=True)
    base = G2.G2Project(str(args.project.resolve()))
    print("BASE", rwp(base))

    if args.mode == "texture":
        for phase0 in base.phases():
            for axis in AXES_TEXTURE:
                tag = f"texture_{phase0.id}_{''.join(map(str, axis))}"
                project = fresh(args.project, temp / f"{tag}.gpx")
                phase = project.phase(phase0.name)
                hap = phase.data["Histograms"][project.histogram(0).name]
                hap["Pref.Ori."][0] = "MD"
                hap["Pref.Ori."][1] = 1.0
                hap["Pref.Ori."][2] = True
                hap["Pref.Ori."][3] = list(axis)
                project.set_Controls("parmMin", 0.6, variable=f"{phase.id}:0:MD")
                project.set_Controls("parmMax", 1.6, variable=f"{phase.id}:0:MD")
                project.refine()
                print(
                    "TEXTURE", phase.name, axis,
                    "Rwp", rwp(project),
                    "ratio", project.phase(phase.name).data["Histograms"][project.histogram(0).name]["Pref.Ori."][1],
                    "vary", project.data["Covariance"]["data"].get("varyList"),
                )
    elif args.mode == "strain":
        for phase0 in base.phases():
            for axis in AXES_STRAIN:
                tag = f"strain_{phase0.id}_{''.join(map(str, axis))}"
                project = fresh(args.project, temp / f"{tag}.gpx")
                phase = project.phase(phase0.name)
                hap = phase.data["Histograms"][project.histogram(0).name]
                iso = float(hap["Mustrain"][1][0])
                hap["Mustrain"][0] = "uniaxial"
                hap["Mustrain"][1][0] = iso
                hap["Mustrain"][1][1] = iso
                hap["Mustrain"][2] = [True, True, False]
                hap["Mustrain"][3] = list(axis)
                for term in ("Mustrain;i", "Mustrain;a"):
                    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:{term}")
                    project.set_Controls("parmMax", 20000.0, variable=f"{phase.id}:0:{term}")
                project.refine()
                values = project.phase(phase.name).data["Histograms"][project.histogram(0).name]["Mustrain"]
                print(
                    "STRAIN", phase.name, axis,
                    "Rwp", rwp(project),
                    "values", values[1][:2],
                    "vary", project.data["Covariance"]["data"].get("varyList"),
                )
    else:
        project = fresh(args.project, temp / "roughness.gpx")
        hist = project.histogram(0)
        hist.SampleParameters["SurfRoughA"] = [0.25, True]
        hist.SampleParameters["SurfRoughB"] = [0.10, True]
        project.set_Controls("parmMin", 0.001, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.9, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.001, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughB")
        project.refine()
        print(
            "ROUGHNESS Rwp", rwp(project),
            "A", hist.SampleParameters["SurfRoughA"],
            "B", hist.SampleParameters["SurfRoughB"],
            "vary", project.data["Covariance"]["data"].get("varyList"),
        )


if __name__ == "__main__":
    main()
