from __future__ import annotations

import argparse
import copy
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags, rwp


def max_shift(project: G2.G2Project) -> float:
    last = np.asarray(project.data.get("Covariance", {}).get("data", {}).get("Lastshft", []), float)
    return float(np.max(np.abs(last))) if last.size else 0.0


def refine(project: G2.G2Project, label: str, passes: int = 3, cycles: int = 24) -> None:
    project.set_Controls("cycles", cycles)
    best_rwp = rwp(project)
    best_data = copy.deepcopy(project.data)
    best_names = copy.deepcopy(project.names)
    for i in range(passes):
        project.refine()
        shift = max_shift(project)
        current = rwp(project)
        print(f"{label} pass={i + 1} Rwp={current:.7f} maxshift={shift:.5g} frozen={project.get_Frozen()}")
        if current < best_rwp:
            best_rwp = current
            best_data = copy.deepcopy(project.data)
            best_names = copy.deepcopy(project.names)
        elif current > best_rwp + 0.01:
            break
        if shift < 0.12:
            break
    project.data = best_data
    project.names = best_names
    project.update_ids()
    print(f"{label} retained Rwp={best_rwp:.7f}")
    project.save(project.filename.replace(".gpx", f"_{label}.gpx"))


def set_bounds(project: G2.G2Project) -> None:
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:Polariz.": (0.5, 1.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
    }
    for phase in project.phases():
        bounds[f"{phase.id}:0:Scale"] = (0.0, 1e6)
        bounds[f"{phase.id}:0:Size;i"] = (0.04, 1.5)
        bounds[f"{phase.id}:0:Mustrain;i"] = (0.0, 8000.0)
        bounds[f"{phase.id}:0:Mustrain;a"] = (0.0, 32000.0)
        bounds[f"{phase.id}:0:MD"] = (0.65, 1.5)
        bounds[f"{phase.id}::AUiso:*"] = (0.003, 0.020)
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)


def enable_scales(project: G2.G2Project) -> None:
    for phase in project.phases():
        phase.data["Histograms"][project.histogram(0).name]["Scale"][1] = True


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--coordinates", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    clear_flags(project)
    set_bounds(project)

    # Keep phase-width parameters in the physically generated interval.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][1][0] = float(np.clip(hap["Size"][1][0], 0.04, 1.5))

    # The isolated screens select a [010] uniaxial width for monoclinic WO3
    # and weak [001] March-Dollase texture for calcite.
    wo_hap = project.phase("WO3").data["Histograms"][hist.name]
    wo_iso = float(wo_hap["Mustrain"][1][0])
    wo_hap["Mustrain"][0] = "uniaxial"
    wo_hap["Mustrain"][1][0] = wo_iso
    wo_hap["Mustrain"][1][1] = 0.65 * wo_iso
    wo_hap["Mustrain"][2] = [True, True, False]
    wo_hap["Mustrain"][3] = [0, 1, 0]
    cc_hap = project.phase("CaCO3").data["Histograms"][hist.name]
    cc_hap["Pref.Ori."][0] = "MD"
    cc_hap["Pref.Ori."][1] = 0.93
    cc_hap["Pref.Ori."][2] = True
    cc_hap["Pref.Ori."][3] = [0, 0, 1]

    # The synthetic reference assigns one isotropic displacement parameter per
    # phase. Enforce that physically meaningful model rather than fitting every
    # atom independently.
    project.data["Constraints"]["data"]["Phase"] = []
    for phase in project.phases():
        variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=True)
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    enable_scales(project)
    print("start", rwp(project))
    refine(project, "effects", passes=4)
    hist = project.histogram(0)

    # Readjust the smooth continuum without changing peak positions or widths.
    clear_flags(project)
    enable_scales(project)
    hist.data["Background"][0][1] = True
    refine(project, "background", passes=2)
    hist = project.histogram(0)

    # Phase-specific widths next; this avoids forcing all broadening into the
    # shared instrumental profile.
    clear_flags(project)
    enable_scales(project)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        if phase.name == "WO3":
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][2] = [True, True, False]
            hap["Mustrain"][3] = [0, 1, 0]
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2][0] = True
    project.set_Frozen()
    refine(project, "phaseprofile", passes=4)
    hist = project.histogram(0)

    # Shared instrument shape. Keep angular calibration fixed in this stage.
    clear_flags(project)
    enable_scales(project)
    for name in ("Polariz.", "SH/L", "U", "W", "X"):
        hist.InstrumentParameters[name][2] = True
    project.set_Frozen()
    refine(project, "instrument", passes=4)
    hist = project.histogram(0)

    # Peak positions: common zero/displacement followed by symmetry-constrained
    # cells. The two are staged because they are intrinsically correlated.
    clear_flags(project)
    hist.InstrumentParameters["Zero"][2] = True
    hist.SampleParameters["Shift"][1] = True
    project.set_Frozen()
    refine(project, "calibration", passes=4)
    hist = project.histogram(0)
    clear_flags(project)
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    project.set_Frozen()
    refine(project, "cells", passes=4)

    if args.coordinates:
        # Coordinate shifts are refined only after the profile nuisance model is
        # established. First W (dominant X-ray scattering), then oxygen sites.
        clear_flags(project)
        enable_scales(project)
        for phase in project.phases():
            for atom in phase.atoms():
                if atom.element == "W":
                    atom.refinement_flags = "X"
        refine(project, "wcoords", passes=4)
        clear_flags(project)
        enable_scales(project)
        for phase in project.phases():
            for atom in phase.atoms():
                if atom.element in {"W", "O"}:
                    atom.refinement_flags = "X"
        refine(project, "coords", passes=5)

    project.save(args.output.resolve())
    print("final", rwp(project), project.histogram(0).ComputeMassFracs())


if __name__ == "__main__":
    main()
