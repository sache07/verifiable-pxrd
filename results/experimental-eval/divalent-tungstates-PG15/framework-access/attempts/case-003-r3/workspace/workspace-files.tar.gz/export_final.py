from __future__ import annotations

import copy
import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/final_optimized.gpx")
FINAL = Path("final.gpx")

PHASE_INFO = {
    "WO3": {
        "name": "monoclinic tungsten trioxide",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif_path": "phase_WO3.cif",
    },
    "CaWO4": {
        "name": "calcium tungstate (scheelite)",
        "formula": "CaWO4",
        "space_group": "I 41/a",
        "cif_path": "phase_CaWO4.cif",
    },
    "CaCO3": {
        "name": "calcium carbonate (calcite)",
        "formula": "CaCO3",
        "space_group": "R -3 c",
        "cif_path": "phase_CaCO3.cif",
    },
}


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE.resolve()), newgpx=str(FINAL.resolve()))
    project.save(FINAL.resolve())
    hist = project.histogram(0)
    arrays = [np.asarray(value, dtype=float) for value in hist.data["data"][1][:6]]
    x, observed, weight, calculated, background, _saved_difference = arrays
    difference = observed - calculated

    original = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1, ndmin=2)
    if original.shape != (len(x), 2):
        raise RuntimeError("GSAS-II histogram does not span the complete input pattern")
    if not np.allclose(x, original[:, 0], rtol=0, atol=1e-10):
        raise RuntimeError("GSAS-II angle grid differs from the input pattern")
    if not np.allclose(observed, original[:, 1], rtol=0, atol=1e-10):
        raise RuntimeError("GSAS-II observations differ from the input pattern")
    if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("Calculated profile contains invalid intensities")
    if np.min(background) < 0:
        raise RuntimeError("Refined background became negative")

    with Path("fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        for row in zip(x, observed, calculated, difference):
            writer.writerow([format(float(value), ".15g") for value in row])

    fractions = hist.ComputeMassFracs()
    fraction_sum = sum(value[0] for value in fractions.values())
    if not np.isclose(fraction_sum, 1.0, rtol=0, atol=1e-10):
        raise RuntimeError("GSAS-II crystalline mass fractions are not normalized")

    # CIF export can consult the most recent covariance vector. Temporarily
    # remove it so the exported values are unambiguously the saved GPX atoms.
    covariance = copy.deepcopy(project.data["Covariance"]["data"])
    project.data["Covariance"]["data"] = {}
    for phase in project.phases():
        phase.export_CIF(PHASE_INFO[phase.name]["cif_path"])
    project.data["Covariance"]["data"] = covariance

    chi_square = float(np.sum(weight * difference**2))
    denominator = float(np.sum(weight * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    rvals = covariance.get("Rvals", {})
    gof = float(rvals.get("GOF", np.nan))
    rexp = float(rwp / gof) if np.isfinite(gof) and gof > 0 else None

    phase_rows = []
    for phase in project.phases():
        info = dict(PHASE_INFO[phase.name])
        info["weight_fraction"] = float(fractions[phase.name][0])
        info["weight_percent"] = float(100.0 * fractions[phase.name][0])
        phase_rows.append(info)

    result = {
        "method": "multiphasic GSAS-II Rietveld refinement",
        "refinement_histogram": hist.name,
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "R_expected_percent": rexp,
            "goodness_of_fit": gof,
            "chi_square": chi_square,
            "number_of_observations": int(len(x)),
        },
    }
    Path("result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2))
    print("background_range", float(np.min(background)), float(np.max(background)))


if __name__ == "__main__":
    main()
