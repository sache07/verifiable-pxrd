from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def summary(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    x, yo, w, yc, yb = (np.asarray(a, float) for a in hist.data["data"][1][:5])
    rwp = 100 * np.sqrt(np.sum(w * (yo - yc) ** 2) / np.sum(w * yo**2))
    print(f"{label}: Rwp={rwp:.6f}% GSAS={hist.residuals.get('wR')} frozen={project.get_Frozen()}")
    try:
        print("fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("fraction error", exc)
    print(
        "instrument",
        {k: hist.InstrumentParameters[k][1] for k in ("Zero", "Polariz.", "U", "W", "X", "SH/L")},
    )
    print(
        "sample",
        {k: hist.SampleParameters[k][0] for k in ("Shift", "SurfRoughA", "SurfRoughB")},
    )
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            phase.name,
            "cell", phase.get_cell(),
            "scale", hap["Scale"][0],
            "size", hap["Size"][0:3],
            "strain", hap["Mustrain"][0:3],
            "MD", hap["Pref.Ori."][:4],
        )


def run_refinement(project: G2.G2Project, label: str, passes: int = 4) -> None:
    project.set_Controls("cycles", 12)
    for i in range(passes):
        project.refine()
        last = np.asarray(project.data["Covariance"]["data"].get("Lastshft", []), float)
        maximum = float(np.max(np.abs(last))) if last.size else 0.0
        print(f"{label} pass {i + 1}: max shift/esd={maximum:.6g}")
        if maximum < 0.12:
            break
    summary(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--through", choices=["wcoords", "coords", "uiso"], default="coords")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)

    # Reopen bounded variables for joint readjustment. A large size is the
    # resolution-limited limit; keep it within the generation's physical scale.
    project.set_Frozen()
    calcite_hap = project.phase("CaCO3").data["Histograms"][hist.name]
    calcite_hap["Size"][1][0] = min(calcite_hap["Size"][1][0], 1.5)
    for phase in project.phases():
        project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:0:Size;i")
    hist.InstrumentParameters["Zero"][1] = min(hist.InstrumentParameters["Zero"][1], 0.249)
    hist.InstrumentParameters["U"][1] = max(hist.InstrumentParameters["U"][1], 0.1)
    hist.InstrumentParameters["X"][1] = max(hist.InstrumentParameters["X"][1], 0.11)

    for phase in project.phases():
        for atom in phase.atoms():
            if atom.element == "W":
                atom.refinement_flags = "X"
    run_refinement(project, "wcoords")
    project.save()
    if args.through == "wcoords":
        return

    project.set_Frozen()
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "X"
    run_refinement(project, "coords", passes=5)
    project.save()
    if args.through == "coords":
        return

    project.set_Frozen()
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "XU"
    run_refinement(project, "uiso", passes=5)
    project.save()


if __name__ == "__main__":
    main()
