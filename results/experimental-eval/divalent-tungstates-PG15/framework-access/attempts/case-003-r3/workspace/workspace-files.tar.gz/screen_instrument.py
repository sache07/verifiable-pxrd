from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags, rwp


source = Path(sys.argv[1]).resolve()
G2.SetPrintLevel("warn")
bounds = {
    "Zero": (-0.25, 0.25),
    "Polariz.": (0.5, 1.0),
    "SH/L": (0.005, 0.10),
    "U": (0.0, 40.0),
    "W": (2.0, 40.0),
    "X": (0.1, 6.0),
}
tests = [(name,) for name in bounds] + [("U", "W", "X"), ("U", "W", "X", "SH/L"), ("Polariz.", "SH/L")]
for names in tests:
    tag = "_".join(name.replace("/", "-").replace(".", "") for name in names)
    project = G2.G2Project(str(source), newgpx=str(Path(f".tmp/instrument_{tag}.gpx").resolve()))
    clear_flags(project)
    hist = project.histogram(0)
    for name in names:
        hist.InstrumentParameters[name][2] = True
        low, high = bounds[name]
        project.set_Controls("parmMin", low, variable=f":0:{name}")
        project.set_Controls("parmMax", high, variable=f":0:{name}")
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    project.set_Controls("cycles", 40)
    project.refine()
    print(names, "Rwp", rwp(project), {name: hist.InstrumentParameters[name][1] for name in names}, "frozen", project.get_Frozen())

# Sample displacement/zero together, and each separately.
for names in (("Zero",), ("Shift",), ("Zero", "Shift")):
    tag = "_".join(names)
    project = G2.G2Project(str(source), newgpx=str(Path(f".tmp/calibration_{tag}.gpx").resolve()))
    clear_flags(project)
    hist = project.histogram(0)
    if "Zero" in names:
        hist.InstrumentParameters["Zero"][2] = True
        project.set_Controls("parmMin", -0.25, variable=":0:Zero")
        project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    if "Shift" in names:
        hist.SampleParameters["Shift"][1] = True
        project.set_Controls("parmMin", -800, variable=":0:Shift")
        project.set_Controls("parmMax", 800, variable=":0:Shift")
    project.set_Controls("cycles", 40)
    project.refine()
    print(names, "Rwp", rwp(project), "zero", hist.InstrumentParameters["Zero"][1], "shift", hist.SampleParameters["Shift"][0], "frozen", project.get_Frozen())
