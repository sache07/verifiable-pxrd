from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags, rwp


source = Path(sys.argv[1]).resolve()
G2.SetPrintLevel("warn")
for count in (30, 36, 42, 50, 60):
    output = Path(f".tmp/background_{count}.gpx").resolve()
    project = G2.G2Project(str(source), newgpx=str(output))
    clear_flags(project)
    hist = project.histogram(0)
    bkg = hist.data["Background"][0]
    old = list(bkg[3:])
    bkg[2] = count
    bkg[3:] = (old + [0.0] * count)[:count]
    bkg[1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    project.set_Controls("cycles", 40)
    project.refine()
    yb = np.asarray(hist.data["data"][1][4], float)
    print(count, "Rwp", rwp(project), "background", float(yb.min()), float(yb.max()))
