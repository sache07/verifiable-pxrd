from __future__ import annotations

import argparse
import copy
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags, rwp


def refine_best(project: G2.G2Project, label: str, passes: int = 4, cycles: int = 24) -> None:
    project.set_Controls("cycles", cycles)
    best = rwp(project)
    best_data = copy.deepcopy(project.data)
    best_names = copy.deepcopy(project.names)
    for i in range(passes):
        project.refine()
        current = rwp(project)
        last = np.asarray(project.data["Covariance"]["data"].get("Lastshft", []), float)
        shift = float(np.max(np.abs(last))) if last.size else 0.0
        print(label, i + 1, "Rwp", current, "shift", shift, "frozen", project.get_Frozen())
        if current < best:
            best = current
            best_data = copy.deepcopy(project.data)
            best_names = copy.deepcopy(project.names)
        elif current > best + 0.01:
            break
        if shift < 0.12:
            break
    project.data = best_data
    project.names = best_names
    project.update_ids()
    print(label, "retained", best)


def enable_scales(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
    clear_flags(project)
    project.data["Constraints"]["data"]["Phase"] = []
    hist = project.histogram(0)

    # Restore one physical isotropic displacement parameter per phase. The
    # calcite master reached the stated upper physical bound in the prior fit.
    for phase in project.phases():
        value = min(0.020, phase.atoms()[0].uiso)
        for atom in phase.atoms():
            atom.uiso = value
            atom.refinement_flags = " "

    # Improved-model screens resolve CaWO4 uniaxial strain along [010] and a
    # weaker [111] March-Dollase term.
    cw = project.phase("CaWO4").data["Histograms"][hist.name]
    cw["Mustrain"][0] = "uniaxial"
    cw["Mustrain"][1][0] = 4905.0
    cw["Mustrain"][1][1] = 7556.0
    cw["Mustrain"][2] = [True, True, False]
    cw["Mustrain"][3] = [0, 1, 0]
    cw["Pref.Ori."][0] = "MD"
    cw["Pref.Ori."][1] = 1.114
    cw["Pref.Ori."][2] = True
    cw["Pref.Ori."][3] = [1, 1, 1]
    project.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable="1:0:Mustrain;i")
    project.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;a")
    project.set_Controls("parmMax", 32000.0, variable="1:0:Mustrain;a")
    project.set_Controls("parmMin", 0.65, variable="1:0:MD")
    project.set_Controls("parmMax", 1.5, variable="1:0:MD")
    print("start", rwp(project))
    refine_best(project, "cawo4_effects")

    # Refit scales and smooth background after enforcing common Uiso values.
    clear_flags(project)
    enable_scales(project)
    project.histogram(0).data["Background"][0][1] = True
    refine_best(project, "scales_background", passes=3)

    # Joint phase widths only, retaining the selected anisotropy types.
    clear_flags(project)
    enable_scales(project)
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        if phase.name in {"WO3", "CaWO4"}:
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][2] = [True, True, False]
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2][0] = True
    refine_best(project, "phase_widths", passes=3)

    # One final isolated coordinate pass lets intensities respond to the newly
    # resolved CaWO4 texture without moving peak positions/profile terms.
    clear_flags(project)
    enable_scales(project)
    for phase in project.phases():
        for atom in phase.atoms():
            if atom.element in {"W", "O"}:
                atom.refinement_flags = "X"
    refine_best(project, "coordinates", passes=3)

    project.save(args.output.resolve())
    print("final", rwp(project), project.histogram(0).ComputeMassFracs())


if __name__ == "__main__":
    main()
