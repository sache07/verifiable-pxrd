from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(Path("final.gpx").resolve()))
    hist = project.histogram(0)
    data = hist.data["data"][1]
    x = np.asarray(data[0], dtype=float)
    observed = np.asarray(data[1], dtype=float)
    weight = np.asarray(data[2], dtype=float)

    with np.load(".tmp/replay_check/prediction.npz", allow_pickle=False) as replay:
        replay_x = replay["x"]
        replay_observed = replay["observed"]
        calculated = replay["predicted"]
        background = replay["background"]
    if (not np.allclose(x, replay_x, rtol=0, atol=1e-10)
            or not np.allclose(observed, replay_observed, rtol=0, atol=1e-10)):
        raise RuntimeError("Forward-replay grid or observations do not match final.gpx")
    if np.any(calculated < 0) or np.any(background < 0):
        raise RuntimeError("Forward replay contains a negative calculated profile or background")

    difference = observed - calculated
    data[3][:] = calculated
    data[4][:] = background
    data[5][:] = difference

    chi_square = float(np.sum(weight * difference**2))
    denominator = float(np.sum(weight * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    rvals = project.data["Covariance"]["data"].setdefault("Rvals", {})
    nobs = int(len(x))
    nvars = int(rvals.get("Nvars", 0))
    gof = float(np.sqrt(chi_square / (nobs - nvars)))
    rvals.update(chisq=chi_square, Nobs=nobs, Rwp=rwp, GOF=gof)
    project.save(Path("final.gpx").resolve())

    with Path("fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        for row in zip(x, observed, calculated, difference):
            writer.writerow([format(float(value), ".15g") for value in row])

    result_path = Path("result.json")
    result = json.loads(result_path.read_text())
    result["fit_statistics"] = {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "R_expected_percent": float(rwp / gof),
        "goodness_of_fit": gof,
        "chi_square": chi_square,
        "number_of_observations": nobs,
        "profile_source": "native GSAS-II forward replay from final.gpx",
    }
    result_path.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print("Rwp", rwp, "Rp", rp, "GOF", gof, "chi_square", chi_square)


if __name__ == "__main__":
    main()
