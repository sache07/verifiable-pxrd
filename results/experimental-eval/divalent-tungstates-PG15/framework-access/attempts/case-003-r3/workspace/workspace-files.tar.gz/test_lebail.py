from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags, rwp


source = Path(sys.argv[1]).resolve()
project = G2.G2Project(str(source), newgpx=str(Path(".tmp/lebail.gpx").resolve()))
G2.SetPrintLevel("warn")
clear_flags(project)
for phase in project.phases():
    phase.set_refinements({"LeBail": True})
hist = project.histogram(0)
hist.data["Background"][0][1] = True
project.set_Controls("cycles", 30)
print("before", rwp(project))
for i in range(5):
    project.refine()
    print(i + 1, rwp(project), hist.residuals)
