from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags, rwp


source = Path(sys.argv[1]).resolve()
G2.SetPrintLevel("warn")
base = G2.G2Project(str(source))
print("BASE", rwp(base))
for phase0 in base.phases():
    for mode in ("size", "strain", "both"):
        out = Path(f".tmp/phaseprof_{phase0.id}_{mode}.gpx").resolve()
        project = G2.G2Project(str(source), newgpx=str(out))
        clear_flags(project)
        hist = project.histogram(0)
        phase = project.phase(phase0.name)
        hap = phase.data["Histograms"][hist.name]
        if mode in {"size", "both"}:
            hap["Size"][2][0] = True
            project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
            project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:0:Size;i")
        if mode in {"strain", "both"}:
            if hap["Mustrain"][0] == "uniaxial":
                hap["Mustrain"][2] = [True, True, False]
                for term in ("Mustrain;i", "Mustrain;a"):
                    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:{term}")
                    project.set_Controls("parmMax", 32000.0, variable=f"{phase.id}:0:{term}")
            else:
                hap["Mustrain"][2][0] = True
                project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
                project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;i")
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        project.set_Controls("cycles", 40)
        project.refine()
        result = project.phase(phase.name).data["Histograms"][project.histogram(0).name]
        print(phase.name, mode, "Rwp", rwp(project), "size", result["Size"][1][0], "strain", result["Mustrain"][1][:2], "frozen", project.get_Frozen())
