from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.signal import find_peaks, peak_widths


data = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
x = data["two_theta_deg"]
y = data["intensity"]
step = float(np.median(np.diff(x)))

# A low rolling percentile follows the broad fluorescence/background envelope
# without tracking ordinary Bragg peaks. This is for peak reconnaissance only.
window = int(round(2.5 / step))
if window % 2 == 0:
    window += 1
background = gaussian_filter1d(percentile_filter(y, 15, size=window), 0.35 / step)
signal = y - background
noise = np.sqrt(np.maximum(y, 1.0))

peaks, props = find_peaks(
    gaussian_filter1d(signal, 0.018 / step),
    prominence=5.0 * np.median(noise),
    distance=max(2, int(round(0.06 / step))),
)
width = peak_widths(signal, peaks, rel_height=0.5)[0] * step
rows = sorted(
    zip(x[peaks], y[peaks], signal[peaks], props["prominences"], width),
    key=lambda row: row[2],
    reverse=True,
)

print(f"points={len(x)} range={x[0]:.6f}..{x[-1]:.6f} step={step:.7f}")
print(
    f"intensity min/median/max={y.min():.1f}/{np.median(y):.1f}/{y.max():.1f}; "
    f"estimated background endpoints={background[0]:.1f}/{background[-1]:.1f}"
)
print(f"peaks found={len(rows)}")
print("rank  2theta       observed  net       prominence  FWHM(deg)")
for i, row in enumerate(rows[:100], 1):
    print(f"{i:3d}  {row[0]:10.5f}  {row[1]:8.1f}  {row[2]:8.1f}  {row[3]:10.1f}  {row[4]:9.4f}")

fig, axes = plt.subplots(2, 1, figsize=(15, 8), constrained_layout=True)
axes[0].plot(x, y, lw=0.6, color="black")
axes[0].plot(x, background, lw=1.0, color="tab:orange")
axes[0].set(ylabel="Counts", xlim=(x[0], x[-1]))
axes[1].plot(x, signal, lw=0.6, color="black")
axes[1].scatter(x[peaks], signal[peaks], s=7, color="tab:red")
axes[1].set(xlabel=r"$2\theta$ (deg)", ylabel="Counts above baseline", xlim=(x[0], x[-1]))
fig.savefig("pattern_overview.png", dpi=180)
