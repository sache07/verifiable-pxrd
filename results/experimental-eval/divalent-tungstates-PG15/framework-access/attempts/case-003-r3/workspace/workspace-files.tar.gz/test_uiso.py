from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags, rwp


source = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
G2.SetPrintLevel("warn")
project = G2.G2Project(str(source), newgpx=str(output))
clear_flags(project)
project.data["Constraints"]["data"]["Phase"] = []
for phase in project.phases():
    variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
    if len(variables) > 1:
        project.add_EquivConstr(variables, reloadIdx=True)
    for atom in phase.atoms():
        atom.refinement_flags = "U"
    phase.set_HAP_refinements({"Scale": True})
    project.set_Controls("parmMin", 0.001, variable=f"{phase.id}::AUiso:*")
    project.set_Controls("parmMax", 0.03, variable=f"{phase.id}::AUiso:*")
project.set_Controls("cycles", 30)
print("before", rwp(project))
project.refine()
print("after", rwp(project), "vary", project.data["Covariance"]["data"].get("varyList"))
print("fractions", project.histogram(0).ComputeMassFracs())
for phase in project.phases():
    print(phase.name, [atom.uiso for atom in phase.atoms()])
project.save()
