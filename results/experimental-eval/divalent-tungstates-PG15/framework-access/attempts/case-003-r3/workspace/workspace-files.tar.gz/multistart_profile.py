from __future__ import annotations

import copy
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from screen_effects import clear_flags, rwp


index = int(sys.argv[1])
source = Path(sys.argv[2]).resolve()
output = Path(sys.argv[3]).resolve()
G2.SetPrintLevel("warn")
project = G2.G2Project(str(source), newgpx=str(output))
clear_flags(project)
hist = project.histogram(0)
rng = np.random.default_rng(20261105 + index)

if index:
    initial_instrument = {
        "U": rng.uniform(0.0, 40.0),
        "W": rng.uniform(2.0, 40.0),
        "X": math.exp(rng.uniform(math.log(0.1), math.log(6.0))),
        "SH/L": math.exp(rng.uniform(math.log(0.005), math.log(0.10))),
    }
    for key, value in initial_instrument.items():
        hist.InstrumentParameters[key][1] = float(value)
else:
    initial_instrument = {key: hist.InstrumentParameters[key][1] for key in ("U", "W", "X", "SH/L")}

# A moderately flexible positive background approximation. Added terms start at
# zero and are solved linearly with the profile scales.
bkg = hist.data["Background"][0]
old = list(bkg[3:])
bkg[2] = 30
bkg[3:] = (old + [0.0] * 30)[:30]
bkg[1] = True

for name, low, high in (("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0), ("SH/L", 0.005, 0.10)):
    hist.InstrumentParameters[name][2] = True
    project.set_Controls("parmMin", low, variable=f":0:{name}")
    project.set_Controls("parmMax", high, variable=f":0:{name}")

initial_phases = {}
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    if index:
        hap["Size"][1][0] = float(math.exp(rng.uniform(math.log(0.04), math.log(1.5))))
        strain = 0.0 if rng.random() < 0.2 else float(math.exp(rng.uniform(math.log(300.0), math.log(8000.0))))
        hap["Mustrain"][1][0] = strain
        if hap["Mustrain"][0] == "uniaxial":
            hap["Mustrain"][1][1] = strain * float(math.exp(rng.uniform(math.log(0.25), math.log(4.0))))
    initial_phases[phase.name] = {
        "size": hap["Size"][1][0],
        "strain": hap["Mustrain"][1][:2],
    }
    hap["Scale"][1] = True
    hap["Size"][2][0] = True
    project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:0:Size;i")
    if hap["Mustrain"][0] == "uniaxial":
        hap["Mustrain"][2] = [True, True, False]
        for term in ("Mustrain;i", "Mustrain;a"):
            project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:{term}")
            project.set_Controls("parmMax", 32000.0, variable=f"{phase.id}:0:{term}")
    else:
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;i")

print("START", index, "Rwp", rwp(project), "instrument", initial_instrument, "phases", initial_phases)
project.set_Controls("cycles", 45)
best = rwp(project)
best_data = copy.deepcopy(project.data)
best_names = copy.deepcopy(project.names)
for attempt in range(3):
    project.set_Frozen()
    try:
        project.refine()
    except Exception as exc:
        print("REFINE_ERROR", attempt + 1, repr(exc))
        break
    current = rwp(project)
    print("PASS", attempt + 1, "Rwp", current, "frozen", project.get_Frozen())
    if current < best:
        best = current
        best_data = copy.deepcopy(project.data)
        best_names = copy.deepcopy(project.names)
    elif current > best + 0.02:
        break

project.data = best_data
project.names = best_names
project.update_ids()
project.save(output)
hist = project.histogram(0)
print("BEST", index, best, "instrument", {k: hist.InstrumentParameters[k][1] for k in ("U", "W", "X", "SH/L")})
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    print("PHASE", phase.name, "size", hap["Size"][1][0], "strain", hap["Mustrain"][1][:2])
