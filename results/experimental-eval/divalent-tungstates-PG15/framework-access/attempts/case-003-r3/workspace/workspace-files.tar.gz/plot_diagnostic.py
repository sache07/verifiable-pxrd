from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks


parser = argparse.ArgumentParser()
parser.add_argument("profile", type=Path)
args = parser.parse_args()

data = np.genfromtxt(args.profile, delimiter=",", names=True)
x = data["two_theta_deg"]
yo = data["observed"]
yc = data["calculated"]
yb = data["background"]
diff = yo - yc
step = np.median(np.diff(x))
stdres = diff / np.sqrt(np.maximum(yo, 1.0))
smooth = gaussian_filter1d(stdres, 0.08 / step)
peaks, _ = find_peaks(np.abs(smooth), prominence=0.15, distance=int(0.12 / step))
order = peaks[np.argsort(np.abs(smooth[peaks]))[::-1]]
print("strongest smoothed standardized residual features")
for idx in order[:50]:
    print(f"{x[idx]:9.4f} deg  smooth={smooth[idx]:+8.3f}  raw={stdres[idx]:+8.3f}")
print(
    "standardized residual mean/std/rms:",
    np.mean(stdres),
    np.std(stdres),
    np.sqrt(np.mean(stdres**2)),
)

fig, axes = plt.subplots(3, 1, figsize=(16, 10), constrained_layout=True)
axes[0].plot(x, yo, lw=0.5, color="black", label="observed")
axes[0].plot(x, yc, lw=0.7, color="tab:red", label="calculated")
axes[0].plot(x, yb, lw=0.7, color="tab:blue", label="background")
axes[0].legend(ncol=3)
axes[0].set(ylabel="Counts", xlim=(x[0], x[-1]))
axes[1].plot(x, diff, lw=0.5, color="tab:blue")
axes[1].axhline(0, lw=0.5, color="black")
axes[1].set(ylabel="Observed - calculated", xlim=(x[0], x[-1]))
axes[2].plot(x, stdres, lw=0.4, alpha=0.55, color="gray")
axes[2].plot(x, smooth, lw=0.9, color="tab:purple")
axes[2].axhline(0, lw=0.5, color="black")
axes[2].set(xlabel=r"$2\theta$ (deg)", ylabel="Standardized residual", xlim=(x[0], x[-1]))
fig.savefig(args.profile.with_suffix(".png"), dpi=180)
