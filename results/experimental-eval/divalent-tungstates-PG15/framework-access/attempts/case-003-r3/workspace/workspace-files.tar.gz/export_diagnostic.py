from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("project", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()

project = G2.G2Project(str(args.project.resolve()))
hist = project.histogram(0)
x, observed, weight, calculated, background, difference = (
    np.asarray(a, float) for a in hist.data["data"][1][:6]
)
with args.output.open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["two_theta_deg", "observed", "calculated", "background", "difference", "weight"])
    writer.writerows(zip(x, observed, calculated, background, difference, weight))

base = args.output.with_suffix("")
for phase, values in hist.data["Reflection Lists"].items():
    refl = np.asarray(values["RefList"], float)
    np.savetxt(
        str(base) + f"_{phase}_reflections.csv",
        refl,
        delimiter=",",
        header="h,k,l,multiplicity,d_A,two_theta_deg,sigma,gamma,Fobs2,Fcalc2,phase_deg,Icorr,alpha,beta,wave",
        comments="",
    )
