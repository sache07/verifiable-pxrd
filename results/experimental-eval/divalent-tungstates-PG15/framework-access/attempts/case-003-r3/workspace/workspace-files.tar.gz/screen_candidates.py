from __future__ import annotations

import gzip
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d, percentile_filter


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
COD_INDEX = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/"
    "site-packages/dara/data/cod_filtered_info_2024.json.gz"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


data = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
x = data["two_theta_deg"]
y = data["intensity"]
step = float(np.median(np.diff(x)))
window = int(round(2.5 / step)) | 1
background = gaussian_filter1d(percentile_filter(y, 15, size=window), 0.35 / step)
obs = np.maximum(y - background, 0.0)
obs /= np.linalg.norm(obs)

with gzip.open(COD_INDEX, "rt") as handle:
    index = json.load(handle)

records = []
for key in ("Ca-O-W", "O-W", "C-Ca-O", "Ca-O"):
    for formula, cod_id, sg, rval in index.get(key, []):
        records.append((key, formula, cod_id, sg, rval))


def gaussian_profile(two_theta, intensity, shift, fwhm):
    profile = np.zeros_like(x)
    # Include the stated Cu Kalpha doublet explicitly.
    for lam, ratio in ((1.540598, 1.0), (1.544426, 0.5)):
        theta1 = np.radians(two_theta / 2.0)
        arg = np.sin(theta1) * lam / 1.540598
        keep = arg < 1.0
        pos = np.degrees(2.0 * np.arcsin(arg[keep])) + shift
        amp = intensity[keep] * ratio
        for center, height in zip(pos, amp):
            local_fwhm = fwhm * (1.0 + 0.35 * np.tan(np.radians(center / 2.0)))
            sigma = local_fwhm / 2.35482
            lo = np.searchsorted(x, center - 4.0 * sigma)
            hi = np.searchsorted(x, center + 4.0 * sigma)
            if hi > lo:
                z = (x[lo:hi] - center) / sigma
                profile[lo:hi] += height * np.exp(-0.5 * z * z)
    norm = np.linalg.norm(profile)
    return profile / norm if norm else profile


calc = XRDCalculator(wavelength=1.540598)
rows = []
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    for key, formula, cod_id, sg, rval in records:
        path = cod_path(cod_id)
        try:
            structure = Structure.from_file(path, primitive=False)
            patt = calc.get_pattern(structure, two_theta_range=(9.5, 100.6), scaled=False)
            tt = np.asarray(patt.x, float)
            inten = np.asarray(patt.y, float)
            best = (-np.inf, None, None)
            for fwhm in (0.12, 0.16, 0.20, 0.26, 0.34):
                for shift in np.arange(-0.10, 0.551, 0.01):
                    profile = gaussian_profile(tt, inten, shift, fwhm)
                    score = float(np.dot(obs, profile))
                    if score > best[0]:
                        best = (score, shift, fwhm)
            sg_info = structure.get_space_group_info(symprec=0.05)
            rows.append(
                {
                    "key": key,
                    "formula_index": formula,
                    "id": cod_id,
                    "sg_index": sg,
                    "r": rval,
                    "formula": structure.composition.reduced_formula,
                    "sg": sg_info,
                    "abc": structure.lattice.abc,
                    "angles": structure.lattice.angles,
                    "sites": len(structure),
                    "density": structure.density,
                    "score": best[0],
                    "shift": best[1],
                    "fwhm": best[2],
                    "top_peaks": sorted(zip(inten, tt), reverse=True)[:8],
                }
            )
        except Exception as exc:
            print(f"ERROR {cod_id} {formula}: {exc}")

for row in sorted(rows, key=lambda item: item["score"], reverse=True):
    abc = ",".join(f"{v:.4f}" for v in row["abc"])
    ang = ",".join(f"{v:.2f}" for v in row["angles"])
    peaks = " ".join(f"{tt:.2f}({ii:.0f})" for ii, tt in row["top_peaks"][:6])
    print(
        f"{row['score']:.4f} id={row['id']} idx={row['formula_index']:<18s} "
        f"parsed={row['formula']:<14s} SG={row['sg'][0]}({row['sg'][1]}) "
        f"sites={row['sites']:<3d} rho={row['density']:.3f} "
        f"shift={row['shift']:+.2f} fwhm={row['fwhm']:.2f} "
        f"abc={abc} angles={ang} peaks={peaks}"
    )

Path("candidate_screen.json").write_text(json.dumps(rows, indent=2, default=list) + "\n")
