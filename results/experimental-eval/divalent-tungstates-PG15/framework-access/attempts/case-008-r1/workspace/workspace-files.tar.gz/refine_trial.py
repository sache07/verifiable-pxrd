#!/usr/bin/env python3
"""Continue a one-phase GSAS-II refinement with selected physical effects."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project):
    hist = project.histograms()[0]
    x, yo, wt, yc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    return 100 * math.sqrt(np.sum(wt[use] * (yo[use] - yc[use]) ** 2) / np.sum(wt[use] * yo[use] ** 2))


def state(project, stage):
    hist = project.histograms()[0]
    phase = project.phases()[0]
    hap = phase.data["Histograms"][hist.name]
    inst = hist.data["Instrument Parameters"][0]
    row = {
        "stage": stage,
        "rwp": rwp(project),
        "cell": phase.get_cell(),
        "instrument": {k: inst[k][1] for k in ["Zero", "U", "W", "X", "SH/L", "Polariz."]},
        "sample": {k: hist.SampleParameters[k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "size": hap["Size"][1],
        "mustrain": hap["Mustrain"][1],
        "po": hap["Pref.Ori."][:4],
        "scale": hap["Scale"][0],
        "atoms": [dict(label=a.label, xyz=a.coordinates, uiso=a.uiso) for a in phase.atoms()],
        "residuals": hist.residuals,
    }
    print(json.dumps(row, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)))
    return row


def clear_all(project):
    hist = project.histograms()[0]
    phase = project.phases()[0]
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
            "Background": False,
        }
    )
    phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
    phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})


def run_refine(project, label, hist_set=None, phase_set=None, hap_set=None):
    hist = project.histograms()[0]
    phase = project.phases()[0]
    if hist_set:
        hist.set_refinements(hist_set)
    if phase_set:
        phase.set_refinements(phase_set)
    if hap_set:
        phase.set_HAP_refinements(hap_set)
    project.refine()
    return state(project, label)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("base")
    p.add_argument("output")
    p.add_argument("--background", type=int, default=12)
    p.add_argument("--coords", action="store_true")
    p.add_argument("--uiso", action="store_true")
    p.add_argument("--po", nargs=3, type=int)
    p.add_argument("--rough", nargs=2, type=float)
    p.add_argument("--refine-rough", action="store_true")
    p.add_argument("--no-shift", action="store_true")
    p.add_argument("--no-polarization", action="store_true")
    p.add_argument("--profile", action="store_true")
    p.add_argument("--fixed-u", type=float)
    p.add_argument("--fixed-w", type=float)
    p.add_argument("--fixed-x", type=float)
    p.add_argument("--size-value", type=float)
    p.add_argument("--mustrain-isotropic", action="store_true")
    p.add_argument("--mustrain-axis", nargs=3, type=int)
    p.add_argument("--start-shl", type=float)
    args = p.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(Path(args.base).resolve()), newgpx=str(Path(args.output).resolve()))
    clear_all(project)
    hist = project.histograms()[0]
    phase = project.phases()[0]
    hap = phase.data["Histograms"][hist.name]
    project.data["Constraints"]["data"]["Phase"] = []
    project.set_Controls("cycles", 12)

    # Keep the broadening model physical. Instrumental U/W/X absorb the
    # isotropic single-phase size/strain degeneracies unless --profile is used.
    if not args.profile:
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = max(0.04, float(hap["Size"][1][0]))
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = max(0.0, float(hap["Mustrain"][1][0]))
    if args.fixed_u is not None:
        hist.data["Instrument Parameters"][0]["U"][1] = float(args.fixed_u)
    if args.fixed_w is not None:
        hist.data["Instrument Parameters"][0]["W"][1] = float(args.fixed_w)
    if args.fixed_x is not None:
        hist.data["Instrument Parameters"][0]["X"][1] = float(args.fixed_x)
    if args.size_value is not None:
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = float(args.size_value)
    if args.start_shl is not None:
        hist.data["Instrument Parameters"][0]["SH/L"][1] = float(args.start_shl)
    if args.mustrain_axis:
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = 1500.0
        hap["Mustrain"][1][1] = 1500.0
        hap["Mustrain"][3] = list(args.mustrain_axis)
    if args.mustrain_isotropic:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1500.0

    bkg = hist.data["Background"][0]
    old = list(bkg[3:])
    if args.background != bkg[2]:
        vals = old[: args.background] + [0.0] * max(0, args.background - len(old))
        hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": args.background, "coeffs": vals, "refine": True}})

    if args.rough:
        hist.SampleParameters["SurfRoughA"] = [args.rough[0], False]
        hist.SampleParameters["SurfRoughB"] = [args.rough[1], False]
    if args.po:
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = list(args.po)

    # Baseline variables that remain active for all subsequent stages.
    instrument_terms = ["Zero", "SH/L"]
    if args.fixed_u is None:
        instrument_terms.append("U")
    if args.fixed_w is None:
        instrument_terms.append("W")
    if args.fixed_x is None:
        instrument_terms.append("X")
    base_hist = {
        "Background": {"refine": True},
        "Instrument Parameters": instrument_terms,
    }
    if not args.no_shift:
        base_hist["Sample Parameters"] = ["Shift"]
    run_refine(project, "baseline", base_hist, {"Cell": True}, {"Scale": True})

    if not args.no_polarization:
        run_refine(project, "polarization", {"Instrument Parameters": ["Polariz."]})

    if args.coords:
        run_refine(project, "coordinates", phase_set={"Atoms": {"all": "X"}})

    if args.uiso:
        for atom in phase.atoms():
            atom.uiso = 0.008
        project.save()
        project.add_EquivConstr([f"0::AUiso:{i}" for i in range(len(phase.atoms()))])
        run_refine(project, "common_uiso", phase_set={"Atoms": {"all": "XU" if args.coords else "U"}})

    if args.po:
        run_refine(project, "preferred_orientation", hap_set={"Pref.Ori.": True})

    if args.refine_rough:
        if hist.SampleParameters["SurfRoughA"][0] == 0 and hist.SampleParameters["SurfRoughB"][0] == 0:
            hist.SampleParameters["SurfRoughA"] = [0.3, False]
            hist.SampleParameters["SurfRoughB"] = [0.1, False]
        run_refine(project, "surface_roughness", {"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})

    if args.profile:
        run_refine(
            project,
            "profile",
            hap_set={
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
        )

    if args.mustrain_axis:
        run_refine(
            project,
            "uniaxial_mustrain",
            hap_set={
                "Mustrain": {
                    "type": "uniaxial",
                    "refine": True,
                    "direction": list(args.mustrain_axis),
                }
            },
        )
    if args.mustrain_isotropic:
        run_refine(
            project,
            "isotropic_mustrain",
            hap_set={"Mustrain": {"type": "isotropic", "refine": True}},
        )

    project.save()
    hist = project.histograms()[0]
    x, yo, wt, yc, yb = [np.asarray(v, float) for v in hist.data["data"][1][:5]]
    np.savetxt(Path(args.output).with_suffix(".csv"), np.column_stack([x, yo, yc, yo - yc, yb]), delimiter=",", header="two_theta,observed,calculated,difference,background", comments="")


if __name__ == "__main__":
    main()
