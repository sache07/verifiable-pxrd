#!/usr/bin/env python3
"""Create the submitted artifacts from the selected GSAS-II project.

The profile is regenerated with the same read-only atomic forward calculation
used by the evaluator, so fit.csv never depends on cached arrays in the GPX.
"""

from __future__ import annotations

import json
import math
import os
import shutil
import sys
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
SOURCE_PROJECT = ROOT / ".tmp" / "phys231_recalc.gpx"
FINAL_PROJECT = ROOT / "final.gpx"
REPLAY_DIR = ROOT / ".tmp" / "replay_final"
RUNTIME = ROOT / "learned" / "divalent-tungstates" / "scorer" / "runtime"


def main() -> None:
    if not SOURCE_PROJECT.is_file():
        raise FileNotFoundError(SOURCE_PROJECT)

    # The selected project has already had a zero-cycle GSAS-II calculation.
    # Copy the binary project byte-for-byte so the verified model is preserved.
    shutil.copy2(SOURCE_PROJECT, FINAL_PROJECT)
    REPLAY_DIR.mkdir(parents=True, exist_ok=True)

    sys.path.insert(0, str(RUNTIME))
    from replay_worker import replay  # noqa: PLC0415

    previous = Path.cwd()
    try:
        os.chdir(REPLAY_DIR)
        replay_report = replay(
            {
                "project": str(FINAL_PROJECT),
                "observed": str(ROOT / "inputs" / "pattern.csv"),
                "histogram": "PWDR pattern.xye",
            }
        )
    finally:
        os.chdir(previous)

    if replay_report.get("status") != "replayed":
        raise RuntimeError(json.dumps(replay_report, indent=2))
    if replay_report.get("profile_review_flags"):
        raise RuntimeError(
            "Profile review flags: "
            + ", ".join(replay_report["profile_review_flags"])
        )

    phases = replay_report["phases"]
    if [phase["name"] for phase in phases] != ["MnWO4", "WO3_2311041"]:
        raise RuntimeError(f"Unexpected phase inventory: {phases!r}")
    shutil.copy2(REPLAY_DIR / phases[0]["cif"], ROOT / "phase_mnwo4.cif")
    shutil.copy2(REPLAY_DIR / phases[1]["cif"], ROOT / "phase_wo3.cif")

    with np.load(REPLAY_DIR / "prediction.npz", allow_pickle=False) as data:
        x = data["x"].copy()
        observed = data["observed"].copy()
        calculated = data["predicted"].copy()
        background = data["background"].copy()

    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = 100.0 * math.sqrt(chi_square / denominator)
    rp = 100.0 * float(np.sum(np.abs(difference)) / np.sum(observed))
    summary = {
        "project_sha256": replay_report["project_sha256"],
        "histogram": replay_report["histogram"],
        "points": int(len(x)),
        "rwp_percent": rwp,
        "rp_percent": rp,
        "chi_square_sum": chi_square,
        "background_min_counts": float(np.min(background)),
        "calculated_min_counts": float(np.min(calculated)),
        "phases": [
            {
                "project_name": phase["name"],
                "weight_fraction": phase["weight_fraction"],
            }
            for phase in phases
        ],
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
