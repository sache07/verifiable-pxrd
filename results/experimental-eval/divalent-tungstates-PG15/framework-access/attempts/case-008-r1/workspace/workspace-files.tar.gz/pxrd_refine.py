#!/usr/bin/env python3
"""Build and refine trial GSAS-II projects for the supplied PXRD pattern."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp_arrays(hist):
    x, yo, wt, yc, yb, yd = [np.asarray(v, dtype=float) for v in hist.data["data"][1][:6]]
    limits = hist.data["Limits"][1]
    mask = (x >= limits[0]) & (x <= limits[1])
    den = np.sum(wt[mask] * yo[mask] ** 2)
    num = np.sum(wt[mask] * (yo[mask] - yc[mask]) ** 2)
    return 100.0 * math.sqrt(num / den), mask


def snapshot(project, label):
    hist = project.histograms()[0]
    rwp, _ = rwp_arrays(hist)
    inst = hist.data["Instrument Parameters"][0]
    samp = hist.data["Sample Parameters"]
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"][1],
                "mustrain": hap["Mustrain"][1],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": a.label,
                        "element": a.element,
                        "xyz": a.coordinates,
                        "uiso": a.uiso if a.adp_flag == "I" else a.ADP,
                    }
                    for a in phase.atoms()
                ],
            }
        )
    row = {
        "stage": label,
        "rwp_percent_recomputed": rwp,
        "residuals": hist.residuals,
        "instrument": {k: v[1] if isinstance(v, list) and len(v) > 1 else v for k, v in inst.items()},
        "sample": samp,
        "background": hist.data["Background"],
        "phases": phases,
    }
    print(json.dumps(row, default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o)))
    return row


def set_initial_values(project):
    hist = project.histograms()[0]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [1000.0, -300.0, 100.0, -40.0, 20.0, -10.0, 5.0, 0.0],
                "refine": False,
            },
        }
    )
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][1][1] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]


def refine(args):
    G2.SetPrintLevel("warn")
    out = Path(args.output).resolve()
    project = G2.G2Project(newgpx=str(out))
    phases = [
        project.add_phase(str(Path(cif).resolve()), phasename=name, fmthint="CIF")
        for name, cif in zip(args.names, args.cifs)
    ]
    hist = project.add_powder_histogram(
        str(Path(args.data).resolve()), str(Path(args.instrument).resolve()), phases=phases, fmthint="xye"
    )
    set_initial_values(project)
    project.set_Controls("cycles", 8)
    project.save()

    history = []
    # Refine in conservative stages so that peak positions and scale are captured
    # before profile and structural degrees of freedom are introduced.
    stages = [
        ("background_scales", {"set": {"Background": {"refine": True}, "Scale": True}}),
        ("zero", {"set": {"Instrument Parameters": ["Zero"]}}),
        ("cells", {"set": {"Cell": True}}),
        ("profile_UWX", {"set": {"Instrument Parameters": ["U", "W", "X"]}}),
        ("size", {"set": {"Size": {"type": "isotropic", "refine": True}}}),
        ("mustrain", {"set": {"Mustrain": {"type": "isotropic", "refine": True}}}),
    ]
    if args.shift:
        stages.append(("sample_shift", {"set": {"Sample Parameters": ["Shift"]}}))
    for label, recipe in stages:
        try:
            project.do_refinements([recipe])
            history.append(snapshot(project, label))
        except Exception as exc:
            print(json.dumps({"stage": label, "error": repr(exc)}))
            project = G2.G2Project(str(out))
            break

    project.save()
    hist = project.histograms()[0]
    arr = np.column_stack([np.asarray(v, float) for v in hist.data["data"][1][[0, 1, 3, 5, 4]]])
    np.savetxt(out.with_suffix(".csv"), arr, delimiter=",", header="two_theta,observed,calculated,difference,background", comments="")
    out.with_suffix(".json").write_text(json.dumps(history, indent=2, default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o)) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default=".tmp/pattern.xye")
    parser.add_argument("--instrument", default=".tmp/instrument.instprm")
    parser.add_argument("--output", required=True)
    parser.add_argument("--names", nargs="+", required=True)
    parser.add_argument("--cifs", nargs="+", required=True)
    parser.add_argument("--shift", action="store_true")
    args = parser.parse_args()
    if len(args.names) != len(args.cifs):
        parser.error("--names and --cifs lengths differ")
    refine(args)


if __name__ == "__main__":
    main()
