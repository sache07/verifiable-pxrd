#!/usr/bin/env python3
"""Run controlled joint refinements for the MnWO4 + WO3 model."""

from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
            "Background": False,
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    project.data["Constraints"]["data"]["Phase"] = []
    project.data["Constraints"]["data"]["HAP"] = []


def fractions(project: G2.G2Project) -> list[float]:
    hist = project.histograms()[0]
    amounts = np.array(
        [
            p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
            for p in project.phases()
        ],
        float,
    )
    return (amounts / amounts.sum()).tolist()


def stats(project: G2.G2Project) -> dict:
    hist = project.histograms()[0]
    x, yo, wt, yc, yb = [np.asarray(v, float) for v in hist.data["data"][1][:5]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    loss = np.sum(wt[use] * (yo[use] - yc[use]) ** 2)
    denominator = np.sum(wt[use] * yo[use] ** 2)
    result = {
        "rwp": 100 * math.sqrt(loss / denominator),
        "rp": 100 * np.sum(np.abs(yo[use] - yc[use])) / np.sum(yo[use]),
        "chi_square_sum": loss,
        "fractions": fractions(project),
        "background_min": float(yb[use].min()),
        "calculated_min": float(yc[use].min()),
        "residuals": hist.residuals,
        "instrument": {
            k: hist.data["Instrument Parameters"][0][k][1]
            for k in ["Zero", "U", "W", "X", "SH/L", "Polariz."]
        },
        "sample": {
            k: hist.SampleParameters[k][0]
            for k in ["Shift", "SurfRoughA", "SurfRoughB"]
        },
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"][:4],
                "mustrain": hap["Mustrain"][:4],
                "po": hap["Pref.Ori."][:4],
                "atoms": [
                    {"label": a.label, "xyz": list(a.coordinates), "uiso": a.uiso}
                    for a in phase.atoms()
                ],
            }
        )
    return result


def report(project: G2.G2Project, stage: str) -> None:
    print(json.dumps({"stage": stage, **stats(project)}, default=str))


def refine(project: G2.G2Project, stage: str) -> None:
    project.refine()
    report(project, stage)


def cif_cell(path: str) -> list[float]:
    text = Path(path).read_text()
    values = []
    for tag in (
        "_cell_length_a",
        "_cell_length_b",
        "_cell_length_c",
        "_cell_angle_alpha",
        "_cell_angle_beta",
        "_cell_angle_gamma",
    ):
        match = re.search(rf"(?mi)^\s*{re.escape(tag)}\s+([^\s#]+)", text)
        if not match:
            raise ValueError(f"Missing {tag} in {path}")
        token = re.sub(r"\([^)]*\)$", "", match.group(1).strip("'\""))
        values.append(float(token))
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("output")
    parser.add_argument("--background", type=int, default=20)
    parser.add_argument("--major-structure", action="store_true")
    parser.add_argument("--major-coords", action="store_true")
    parser.add_argument("--major-uiso", action="store_true")
    parser.add_argument("--fix-major-uiso", type=float)
    parser.add_argument("--major-po", nargs=3, type=int)
    parser.add_argument("--minor-w-coords", action="store_true")
    parser.add_argument("--minor-all-coords", action="store_true")
    parser.add_argument("--minor-uiso", action="store_true")
    parser.add_argument("--coordinate-window", type=float, default=0.010)
    parser.add_argument("--major-size", action="store_true")
    parser.add_argument("--major-strain", choices=["isotropic", "uniaxial"])
    parser.add_argument("--major-strain-axis", nargs=3, type=int, default=[1, 0, 0])
    parser.add_argument("--minor-profile", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--fix-zero", action="store_true")
    parser.add_argument("--fix-shift", action="store_true")
    parser.add_argument("--start-zero", type=float)
    parser.add_argument("--start-shift", type=float)
    parser.add_argument("--reset-cells", nargs=2, metavar=("MAJOR_CIF", "MINOR_CIF"))
    parser.add_argument("--staged-cells", action="store_true")
    parser.add_argument("--shift-factor", type=float, default=1.0)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        str(Path(args.base).resolve()), newgpx=str(Path(args.output).resolve())
    )
    clear_flags(project)
    hist = project.histograms()[0]
    major, minor = project.phases()
    source_cells = None
    if args.reset_cells:
        source_cells = [cif_cell(path) for path in args.reset_cells]
        for phase, cell in zip((major, minor), source_cells):
            phase.data["General"]["Cell"] = [
                False,
                *cell,
                G2lat.calc_V(G2lat.cell2A(cell)),
            ]
    if args.start_zero is not None:
        hist.data["Instrument Parameters"][0]["Zero"][1] = float(args.start_zero)
    if args.start_shift is not None:
        hist.SampleParameters["Shift"][0] = float(args.start_shift)
    if args.fix_major_uiso is not None:
        for atom in major.atoms():
            atom.uiso = float(args.fix_major_uiso)
    project.set_Controls("cycles", 16)
    project.data["Controls"]["data"]["shift factor"] = float(args.shift_factor)
    # Remove any boundary freezes inherited from an exploratory parent and use
    # the ranges that generated this problem as hard physical limits.
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
        ":0:Shift": (-800.0, 800.0),
        ":0:SurfRoughA": (0.05, 0.60),
        ":0:SurfRoughB": (0.02, 0.50),
        f"{major.id}::AUiso:*": (0.003, 0.020),
        f"{minor.id}::AUiso:*": (0.003, 0.020),
        f"{major.id}:0:MD": (0.7, 1.4),
        f"{minor.id}:0:MD": (0.7, 1.4),
        f"{major.id}:0:Size;i": (0.04, 1.5),
        f"{minor.id}:0:Size;i": (0.04, 1.5),
        f"{major.id}:0:Mustrain;i": (300.0, 8000.0),
        f"{major.id}:0:Mustrain;a": (75.0, 32000.0),
        f"{minor.id}:0:Mustrain;i": (300.0, 8000.0),
        f"{minor.id}:0:Mustrain;a": (75.0, 32000.0),
        f"{major.id}:0:Scale": (1e-8, 1e5),
        f"{minor.id}:0:Scale": (1e-8, 1e5),
    }
    if source_cells:
        # A principal strain of at most 0.5% changes reciprocal metric diagonal
        # terms by about 1%. The additive A4 allowance covers monoclinic shear.
        for phase, cell in zip((major, minor), source_cells):
            metric = np.asarray(G2lat.cell2A(cell), float)
            for index in (0, 1, 2):
                bounds[f"{phase.id}::A{index}"] = (
                    float(metric[index] * (1 - 0.0102)),
                    float(metric[index] * (1 + 0.0102)),
                )
            shear_allowance = 0.011 * 2 * math.sqrt(metric[0] * metric[2])
            bounds[f"{phase.id}::A4"] = (
                float(metric[4] - shear_allowance),
                float(metric[4] + shear_allowance),
            )
    # GSAS-II names coordinate increments dAx/dAy/dAz but applies parameter
    # limits to the resulting absolute Ax/Ay/Az value. Bound each coordinate
    # around the current registered-model value, not around zero.
    for phase in (major, minor):
        for atom_index, atom in enumerate(phase.atoms()):
            for axis, value in zip("xyz", atom.coordinates):
                bounds[f"{phase.id}::dA{axis}:{atom_index}"] = (
                    float(value) - float(args.coordinate_window),
                    float(value) + float(args.coordinate_window),
                )
    for variable, (lower, upper) in bounds.items():
        project.set_Controls("parmMin", lower, variable)
        project.set_Controls("parmMax", upper, variable)
    # Refine on every supplied point, including the short margins outside 10--100 degrees.
    hist.data["Limits"][1] = list(hist.data["Limits"][0])

    bkg = hist.data["Background"][0]
    if bkg[2] != args.background:
        old = list(bkg[3:])
        values = old[: args.background] + [0.0] * max(0, args.background - len(old))
        hist.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": args.background,
                    "coeffs": values,
                    "refine": True,
                }
            }
        )

    inst_terms = ["X", "SH/L", "Polariz."]
    if not args.fix_zero:
        inst_terms.insert(0, "Zero")
    sample_terms = [] if args.fix_shift else ["Shift"]
    if args.roughness:
        sample_terms += ["SurfRoughA", "SurfRoughB"]
    base_refinements = {
        "Background": {"refine": True},
        "Instrument Parameters": inst_terms,
    }
    if sample_terms:
        base_refinements["Sample Parameters"] = sample_terms
    hist.set_refinements(base_refinements)
    for phase in (major, minor):
        if not args.staged_cells:
            phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
    refine(project, "baseline")

    if args.staged_cells:
        for phase in (major, minor):
            phase.set_refinements({"Cell": True})
        refine(project, "cells")

    refine_major_coords = args.major_structure or args.major_coords
    refine_major_uiso = args.major_structure or args.major_uiso
    if refine_major_coords or refine_major_uiso:
        # The synthetic specimen uses one isotropic Uiso per phase. Preserve that
        # equality while allowing all symmetry-independent coordinates to move.
        if refine_major_uiso:
            project.add_EquivConstr(
                [f"{major.id}::AUiso:{i}" for i in range(len(major.atoms()))]
            )
        atom_mode = "XU" if refine_major_coords and refine_major_uiso else (
            "X" if refine_major_coords else "U"
        )
        major.set_refinements({"Atoms": {"all": atom_mode}})
        refine(project, "major_structure")

    if args.major_po:
        hap = major.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][3] = list(args.major_po)
        major.set_HAP_refinements({"Pref.Ori.": True})
        refine(project, "major_po")

    if args.minor_w_coords or args.minor_all_coords:
        labels = (
            [a.label for a in minor.atoms()]
            if args.minor_all_coords
            else [a.label for a in minor.atoms() if a.element == "W"]
        )
        minor.set_refinements({"Atoms": {label: "X" for label in labels}})
        refine(project, "minor_coordinates")

    if args.minor_uiso:
        project.add_EquivConstr(
            [f"{minor.id}::AUiso:{i}" for i in range(len(minor.atoms()))]
        )
        minor.set_refinements({"Atoms": {"all": "U"}})
        refine(project, "minor_uiso")

    if args.major_size:
        major.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}
        )
        refine(project, "major_size")

    if args.major_strain:
        major.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": args.major_strain,
                    "refine": True,
                    "direction": list(args.major_strain_axis),
                }
            }
        )
        refine(project, "major_strain")

    if args.minor_profile:
        minor.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
        refine(project, "minor_profile")

    project.save()
    report(project, "final")


if __name__ == "__main__":
    main()
