#!/usr/bin/env python3
"""Add a candidate minor phase to an existing one-phase GSAS-II project."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project):
    hist = project.histograms()[0]
    x, yo, wt, yc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    return 100 * math.sqrt(np.sum(wt[use] * (yo[use] - yc[use]) ** 2) / np.sum(wt[use] * yo[use] ** 2))


def fractions(project):
    hist = project.histograms()[0]
    vals = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        vals.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
    vals = np.maximum(vals, 0)
    vals /= vals.sum()
    return vals.tolist()


def state(project, stage):
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    out = {
        "stage": stage,
        "rwp": rwp(project),
        "fractions": fractions(project),
        "instrument": {k: inst[k][1] for k in ["Zero", "U", "W", "X", "SH/L", "Polariz."]},
        "sample": {k: hist.SampleParameters[k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"].append(
            {
                "name": phase.name,
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"][0],
                "cell": phase.get_cell(),
                "size": hap["Size"][1],
                "mustrain": hap["Mustrain"][1],
                "po": hap["Pref.Ori."][:4],
                "atoms": [dict(label=a.label, xyz=a.coordinates, uiso=a.uiso) for a in phase.atoms()],
            }
        )
    print(json.dumps(out, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)))
    return out


def clear_flags(project):
    hist = project.histograms()[0]
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
            "Background": False,
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})


def refine(project, stage):
    project.refine()
    state(project, stage)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("base")
    p.add_argument("cif")
    p.add_argument("output")
    p.add_argument("--name", default="minor")
    p.add_argument("--scale", type=float, default=1.0)
    p.add_argument("--background", type=int, default=20)
    p.add_argument("--coords", action="store_true")
    p.add_argument("--uiso", action="store_true")
    p.add_argument("--profile", action="store_true")
    args = p.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(Path(args.base).resolve()), newgpx=str(Path(args.output).resolve()))
    clear_flags(project)
    hist = project.histograms()[0]
    minor = project.add_phase(str(Path(args.cif).resolve()), phasename=args.name, histograms=[hist], fmthint="CIF")
    project.data["Constraints"]["data"]["Phase"] = []
    project.set_Controls("cycles", 12)

    hap = minor.data["Histograms"][hist.name]
    hap["Scale"] = [float(args.scale), False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.3
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1200.0
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    for atom in minor.atoms():
        atom.uiso = 0.008

    bkg = hist.data["Background"][0]
    if bkg[2] != args.background:
        old = list(bkg[3:])
        vals = old[: args.background] + [0.0] * max(0, args.background - len(old))
        hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": args.background, "coeffs": vals, "refine": True}})

    # Keep U/W at physically allowed boundary values selected in the major-phase
    # profile fit; X and SH/L remain free and shared by both phases.
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1] = 40.0
    inst["W"][1] = 2.0
    hist.set_refinements(
        {
            "Background": {"refine": True},
            "Instrument Parameters": ["Zero", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift"],
        }
    )
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
    refine(project, "scale_cells")

    if args.profile:
        minor.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
        refine(project, "minor_profile")

    if args.coords:
        minor.set_refinements({"Atoms": {"all": "X"}})
        refine(project, "minor_coordinates")

    if args.uiso:
        project.save()
        pid = minor.id
        project.add_EquivConstr([f"{pid}::AUiso:{i}" for i in range(len(minor.atoms()))])
        minor.set_refinements({"Atoms": {"all": "XU" if args.coords else "U"}})
        refine(project, "minor_common_uiso")

    project.save()
    hist = project.histograms()[0]
    x, yo, wt, yc, yb = [np.asarray(v, float) for v in hist.data["data"][1][:5]]
    np.savetxt(Path(args.output).with_suffix(".csv"), np.column_stack([x, yo, yc, yo - yc, yb]), delimiter=",", header="two_theta,observed,calculated,difference,background", comments="")


if __name__ == "__main__":
    main()
