#!/usr/bin/env python3
"""Branch a project and test bounded Suortti surface roughness."""

from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def main(source, output, aval, bval):
    project = G2.G2Project(gpxfile=source, newgpx=output)
    hist = project.histogram(0)
    x = np.asarray(hist.data["data"][1][0], float)
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    hist.SampleParameters["SurfRoughA"] = [float(aval), True]
    hist.SampleParameters["SurfRoughB"] = [float(bval), True]
    project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    project.refine()
    project.save()
    y, yc = [np.asarray(v, float) for v in hist.data["data"][1][1:4:2]]
    w = 1 / np.maximum(y, 1)
    rwp = 100 * np.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y ** 2))
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(phase.data["General"]["Mass"] * hap["Scale"][0])
    print("rwp", rwp, "residuals", hist.residuals)
    print("roughness", hist.SampleParameters["SurfRoughA"], hist.SampleParameters["SurfRoughB"])
    print("instrument", {k: hist.InstrumentParameters[k] for k in ["U", "W", "X", "SH/L", "Polariz."]})
    print("fractions", [m / sum(masses) for m in masses])
    print("frozen", project.get_Frozen())


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], float(sys.argv[3]), float(sys.argv[4]))
