#!/usr/bin/env python3
"""Build a small candidate Rietveld project and print its state."""

from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def report(project, tag):
    hist = project.histogram(0)
    print(f"\n--- {tag} ---")
    print("residuals", hist.residuals)
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")})
    print("sample", hist.SampleParameters)
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        masses.append(max(mass, 0.0))
        print("phase", phase.name, "cell", phase.get_cell(), "mass", phase.data["General"]["Mass"])
        print("  HAP", {k: hap[k] for k in ("Scale", "Size", "Mustrain", "Pref.Ori.", "HStrain")})
    if sum(masses):
        print("weight_fractions", {p.name: m / sum(masses) for p, m in zip(project.phases(), masses)})
    cov = project.data.get("Covariance", {}).get("data", {})
    print("vary", list(zip(cov.get("varyList", []), cov.get("variables", []), cov.get("sig", []))))


def main(ids):
    G2.SetPrintLevel("warn")
    out = ROOT / ("probe_" + "_".join(ids) + ".gpx")
    project = G2.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(str(ROOT / "pattern.xye"), str(ROOT / "initial.instprm"), fmthint="xye")
    hist.set_refinements({"Limits": [10.0, 100.0]})
    phases = []
    for cod_id in ids:
        phase = project.add_phase(str(cif_path(cod_id)), phasename=cod_id, histograms=[hist], fmthint="CIF")
        phases.append(phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.10
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0

    project.set_Controls("cycles", 8)
    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 8,
                                          "coeffs": [700.0, -400.0, 200.0, -100.0, 50.0, -20.0, 10.0, 0.0],
                                          "refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    project.refine()
    report(project, "background + scales")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    hist.SampleParameters["Shift"][1] = True
    project.refine()
    report(project, "cells + zero + shift")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True},
                                   "Mustrain": {"type": "isotropic", "refine": True}})
    project.refine()
    report(project, "profile")
    project.save()


if __name__ == "__main__":
    main(sys.argv[1:] or ["1520641", "9004178", "1528915"])
