#!/usr/bin/env python3
"""Branch a project and test one March-Dollase texture axis."""

import sys
import numpy as np
from GSASII import GSASIIscriptable as G2


def main(source, output, phase_index, axis):
    project = G2.G2Project(gpxfile=source, newgpx=output)
    hist = project.histogram(0)
    # Hold the established model fixed so this is a one-parameter diagnostic.
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for item in project.phases():
        item.data["General"]["Cell"][0] = False
        for atom in item.atoms():
            atom.refinement_flags = " "
        hap = item.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    phase = project.phases()[phase_index]
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = axis
    project.set_Controls("parmMin", 0.70, variable=f"{phase_index}:0:MD")
    project.set_Controls("parmMax", 1.40, variable=f"{phase_index}:0:MD")
    project.set_Frozen()
    project.set_Controls("cycles", 10)
    project.refine()
    project.save()
    y = np.asarray(hist.data["data"][1][1], float)
    yc = np.asarray(hist.data["data"][1][3], float)
    w = 1 / np.maximum(y, 1)
    rwp = 100 * np.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y ** 2))
    print("rwp", rwp, "residuals", hist.residuals)
    print("phase", phase.name, "preferred_orientation", po)
    print("all_orientation", [(p.name, p.data["Histograms"][hist.name]["Pref.Ori."])
                               for p in project.phases()])
    print("frozen", project.get_Frozen())


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], int(sys.argv[3]), [int(v) for v in sys.argv[4:7]])
