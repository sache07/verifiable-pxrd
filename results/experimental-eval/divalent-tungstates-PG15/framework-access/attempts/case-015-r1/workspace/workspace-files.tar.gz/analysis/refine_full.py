#!/usr/bin/env python3
"""Physically bounded three-phase Rietveld refinement for model comparison."""

from pathlib import Path
import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def set_limit(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def stage(project, label, history):
    project.refine()
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "stage": label,
        "wR_percent": float(hist.residuals.get("wR", np.nan)),
        "R_percent": float(hist.residuals.get("R", np.nan)),
        "GOF": float(cov.get("GOF", np.nan)),
        "max_shift_esd": float(cov.get("Max shft/sig", np.nan)),
        "frozen": project.get_Frozen(),
    }
    history.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)


def fractions(project):
    hist = project.histogram(0)
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    total = sum(masses)
    return [m / total for m in masses]


def summarize(project, history, out_json):
    hist = project.histogram(0)
    data = hist.data["data"][1]
    x, yobs, weight, ycalc, bkg = [np.asarray(a, float) for a in data[:5]]
    calc_rwp = 100.0 * np.sqrt(np.sum(weight * (yobs - ycalc) ** 2) /
                               np.sum(weight * yobs ** 2))
    phase_rows = []
    wf = fractions(project)
    for phase, frac in zip(project.phases(), wf):
        hap = phase.data["Histograms"][hist.name]
        phase_rows.append({
            "name": phase.name,
            "weight_fraction": frac,
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": [{"label": a.label, "element": a.element, "xyz": list(a.coordinates),
                       "uiso": a.uiso, "flags": a.refinement_flags}
                      for a in phase.atoms()],
        })
    result = {
        "history": history,
        "residuals": hist.residuals,
        "calculated_rwp_percent": calc_rwp,
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "background_min": float(np.min(bkg)),
        "background_max": float(np.max(bkg)),
        "phases": phase_rows,
        "frozen": project.get_Frozen(),
    }
    out_json.write_text(json.dumps(result, indent=2, allow_nan=True) + "\n")
    print(json.dumps({"summary": str(out_json), "wR": calc_rwp,
                      "fractions": dict(zip([p.name for p in project.phases()], wf))},
                     sort_keys=True), flush=True)


def main(wo3_id, tag):
    G2.SetPrintLevel("warn")
    ids = ["1520641", "9004178", wo3_id]
    stem = f"full_{tag}_{wo3_id}"
    gpx = ROOT / f"{stem}.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(str(ROOT / "pattern.xye"), str(ROOT / "initial.instprm"), fmthint="xye")
    hist.set_refinements({"Limits": [9.91, 100.09]})
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-195.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    for key, value in {"U": 10.0, "W": 10.0, "X": 1.0, "SH/L": 0.02,
                       "Zero": 0.0, "Polariz.": 0.70}.items():
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False

    start_scales = [26.0, 9.5, 1.9]
    phases = []
    for pid, (cod_id, scale) in enumerate(zip(ids, start_scales)):
        phase = project.add_phase(str(ROOT / "candidates" / f"{cod_id}.cif"),
                                  phasename=cod_id, histograms=[hist], fmthint="CIF")
        phases.append(phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.10
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        set_limit(project, f"{pid}:0:Scale", 1e-8, 1000.0)
        set_limit(project, f"{pid}:0:Size;i", 0.04, 1.50)
        set_limit(project, f"{pid}:0:Mustrain;i", 0.0, 8000.0)

    set_limit(project, ":0:Shift", -800.0, 800.0)
    set_limit(project, ":0:Zero", -0.25, 0.25)
    for key, limits in {"U": (0.0, 40.0), "W": (2.0, 40.0), "X": (0.1, 6.0),
                        "SH/L": (0.005, 0.10), "Polariz.": (0.5, 1.0)}.items():
        set_limit(project, f":0:{key}", *limits)

    project.set_Controls("cycles", 6)
    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 10,
                                          "coeffs": [700.0, -400.0, 200.0, -100.0, 50.0,
                                                     -20.0, 10.0, -5.0, 2.0, 0.0],
                                          "refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    history = []
    stage(project, "background_scales", history)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.SampleParameters["Shift"][1] = True
    stage(project, "cells_shift", history)

    hist.SampleParameters["Shift"][1] = False
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stage(project, "cells_zero", history)

    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.SampleParameters["Shift"][1] = True
    stage(project, "cells_shift_again", history)
    hist.SampleParameters["Shift"][1] = False

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    stage(project, "instrument_W_X", history)

    phases[0].set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    stage(project, "main_size", history)
    for phase in phases[1:]:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    stage(project, "all_sizes", history)

    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    stage(project, "all_mustrain", history)

    hist.set_refinements({"Instrument Parameters": ["U", "SH/L"]})
    stage(project, "complete_profile", history)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    stage(project, "polarization", history)

    # Re-enter from the physically clipped solution with a strongly damped,
    # longer joint cycle. This lets correlated size/profile terms move back
    # inside their bounds after the early single-family stages.
    project.set_Frozen()
    project.set_Controls("cycles", 20)
    stage(project, "joint_convergence", history)

    project.save()
    summarize(project, history, ROOT / f"{stem}.json")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit("usage: refine_full.py WO3_COD_ID [TAG]")
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "run")
