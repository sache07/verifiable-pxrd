#!/usr/bin/env python3
"""Jointly refine selected structural variables from the verified baseline."""

import sys
import numpy as np
from GSASII import GSASIIscriptable as G2


def copy_coordinates(target, source, selected):
    for i, (dst, src) in enumerate(zip(target.atoms(), source.atoms())):
        use = selected == "all" or (selected == "heavy" and dst.element != "O")
        if use:
            dst.coordinates = src.coordinates
            dst.refinement_flags = "X"
        else:
            dst.refinement_flags = " "


def main(source, output, structure_mode, broadening, texture):
    project = G2.G2Project(gpxfile=source, newgpx=output)
    hist = project.histogram(0)

    zwo_source = G2.G2Project(gpxfile="analysis/coord_zwo_all_2311041.gpx").phases()[0]
    wo3_source = G2.G2Project(gpxfile="analysis/coord_wo3_all_2311041.gpx").phases()[2]
    copy_coordinates(project.phases()[0], zwo_source, "all")
    if structure_mode == "all":
        copy_coordinates(project.phases()[2], wo3_source, "all")
    elif structure_mode == "heavy":
        heavy_source = G2.G2Project(gpxfile="analysis/coord_wo3_heavy_2311041.gpx").phases()[2]
        copy_coordinates(project.phases()[2], heavy_source, "heavy")
    else:
        copy_coordinates(project.phases()[2], wo3_source, "none")
    for atom in project.phases()[1].atoms():
        atom.refinement_flags = " "

    main_hap = project.phases()[0].data["Histograms"][hist.name]
    if broadening == "uniaxial":
        strain = main_hap["Mustrain"]
        strain[0] = "uniaxial"
        strain[1][0:3] = [228.92740889962295, 0.0, 1.0]
        strain[2][0:3] = [True, False, False]
        strain[3] = [0, 0, 1]
    else:
        main_hap["Mustrain"][0] = "isotropic"
        main_hap["Mustrain"][1][0] = 0.0
        main_hap["Mustrain"][2] = [False for _ in main_hap["Mustrain"][2]]

    po = main_hap["Pref.Ori."]
    po[1] = 0.987476
    po[2] = texture == "texture"
    po[3] = [0, 0, 1]

    # Preserve broad physical/generator bounds while allowing joint adjustment.
    for phase_index in range(3):
        project.set_Controls("parmMin", 0.04, variable=f"{phase_index}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{phase_index}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Scale")
    project.set_Controls("parmMin", 0.0, variable="0:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable="0:0:Mustrain;i")
    project.set_Controls("parmMin", 0.0, variable="0:0:Mustrain;a")
    project.set_Controls("parmMax", 8000.0, variable="0:0:Mustrain;a")
    project.set_Controls("parmMin", 0.0, variable="2:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable="2:0:Mustrain;i")
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.1, variable=":0:SH/L")
    project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.6, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")
    project.set_Controls("parmMin", 0.5, variable="0:0:MD")
    project.set_Controls("parmMax", 2.0, variable="0:0:MD")
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.refine()
    project.save()

    y = np.asarray(hist.data["data"][1][1], float)
    yc = np.asarray(hist.data["data"][1][3], float)
    w = 1 / np.maximum(y, 1)
    rwp = 100 * np.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y ** 2))
    print("rwp", rwp, "frozen", project.get_Frozen())
    print("residuals", hist.residuals)
    print("instrument", hist.InstrumentParameters)
    print("sample", hist.SampleParameters)
    for i, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        print("phase", i, phase.name, "scale", hap["Scale"], "size", hap["Size"],
              "strain", hap["Mustrain"], "po", hap["Pref.Ori."])
        for atom in phase.atoms():
            print("atom", i, atom.label, atom.element, atom.coordinates, atom.refinement_flags)


if __name__ == "__main__":
    main(*sys.argv[1:6])
