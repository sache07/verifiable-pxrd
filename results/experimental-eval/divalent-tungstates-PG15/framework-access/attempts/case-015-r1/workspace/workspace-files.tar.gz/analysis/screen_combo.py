#!/usr/bin/env python3
"""Fast, conservative GSAS-II screening fit for a supplied COD-ID phase set."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def main(ids):
    G2.SetPrintLevel("warn")
    stem = "screen_" + "_".join(ids)
    gpx = ROOT / f"{stem}.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(str(ROOT / "pattern.xye"), str(ROOT / "initial.instprm"), fmthint="xye")
    hist.set_refinements({"Limits": [15.0, 75.0]})
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    phases = []
    for pid, cod_id in enumerate(ids):
        phase = project.add_phase(str(ROOT / "candidates" / f"{cod_id}.cif"),
                                  phasename=cod_id, histograms=[hist], fmthint="CIF")
        phases.append(phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.10
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")

    project.set_Controls("cycles", 5)
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 8,
                                          "coeffs": [700.0, -400.0, 200.0, -100.0,
                                                     50.0, -20.0, 10.0, 0.0],
                                          "refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    project.refine()

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.SampleParameters["Shift"][1] = True
    project.refine()

    # One additional scale/cell cycle after profile positions have moved.
    project.refine()
    project.save()

    masses = []
    details = []
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        masses.append(max(mass, 0.0))
        details.append({"id": phase.name, "cell": phase.get_cell(), "scale": hap["Scale"][0],
                        "mass_term": mass})
    total = sum(masses)
    for row, mass in zip(details, masses):
        row["weight_fraction"] = mass / total if total else None
    result = {"ids": ids, "residuals": hist.residuals, "shift_um": hist.SampleParameters["Shift"][0],
              "phases": details, "gpx": str(gpx)}
    (ROOT / f"{stem}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit("usage: screen_combo.py COD_ID [COD_ID ...]")
    main(sys.argv[1:])
