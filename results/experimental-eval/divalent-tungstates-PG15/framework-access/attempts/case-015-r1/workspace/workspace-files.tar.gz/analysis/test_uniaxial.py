#!/usr/bin/env python3
"""Branch a project and test one phase with bounded uniaxial microstrain."""

import sys
import numpy as np
from GSASII import GSASIIscriptable as G2


def main(source, output, phase_index, axis):
    project = G2.G2Project(gpxfile=source, newgpx=output)
    hist = project.histogram(0)
    # Hold the established model fixed: this diagnoses only the two strain
    # components for one candidate axis.
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for item in project.phases():
        item.data["General"]["Cell"][0] = False
        for atom in item.atoms():
            atom.refinement_flags = " "
        ihap = item.data["Histograms"][hist.name]
        ihap["Scale"][1] = False
        ihap["Size"][2] = [False for _ in ihap["Size"][2]]
        ihap["Size"][5] = [False for _ in ihap["Size"][5]]
        ihap["Mustrain"][2] = [False for _ in ihap["Mustrain"][2]]
        ihap["Mustrain"][5] = [False for _ in ihap["Mustrain"][5]]
        ihap["Pref.Ori."][2] = False
        ihap["HStrain"][1] = [False for _ in ihap["HStrain"][1]]
    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][hist.name]
    strain = hap["Mustrain"]
    strain[0] = "uniaxial"
    start = max(300.0, float(strain[1][0]))
    strain[1][0] = start
    strain[1][1] = start
    strain[2][0] = True
    strain[2][1] = True
    strain[3] = axis
    for name in ("Mustrain;i", "Mustrain;a"):
        project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:{name}")
        project.set_Controls("parmMax", 8000.0, variable=f"{phase_index}:0:{name}")
    project.set_Frozen()
    project.set_Controls("cycles", 10)
    project.refine()
    project.save()
    y = np.asarray(hist.data["data"][1][1], float)
    yc = np.asarray(hist.data["data"][1][3], float)
    w = 1 / np.maximum(y, 1)
    rwp = 100 * np.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y ** 2))
    print("rwp", rwp, "residuals", hist.residuals)
    print("phase", phase.name, "mustrain", hap["Mustrain"])
    print("sizes_strains", [(p.name, p.data["Histograms"][hist.name]["Size"],
                             p.data["Histograms"][hist.name]["Mustrain"])
                            for p in project.phases()])
    print("frozen", project.get_Frozen())


if __name__ == "__main__":
    axis = [int(v) for v in sys.argv[4:7]]
    main(sys.argv[1], sys.argv[2], int(sys.argv[3]), axis)
