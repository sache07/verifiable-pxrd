#!/usr/bin/env python3
"""Continue a stable refinement with selected parameter blocks active."""

import sys
import numpy as np
from GSASII import GSASIIscriptable as G2


def hold_noncoordinates(project):
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]


def enable_established_profile(project):
    hist = project.histogram(0)
    hist.Background[0][1] = True
    hist.InstrumentParameters["Polariz."][2] = True
    hist.InstrumentParameters["SH/L"][2] = True
    hist.SampleParameters["SurfRoughA"][1] = True
    hist.SampleParameters["SurfRoughB"][1] = True
    for index, phase in enumerate(project.phases()):
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2][0] = True
        if index == 2:
            hap["Mustrain"][2][0] = True


def main(source, output, mode):
    project = G2.G2Project(gpxfile=source, newgpx=output)
    hist = project.histogram(0)
    if mode in ("profile", "profile_restore"):
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = " "
        if mode == "profile_restore":
            enable_established_profile(project)
    elif mode == "coordinates":
        hold_noncoordinates(project)
        for index in (0, 2):
            for atom in project.phases()[index].atoms():
                atom.refinement_flags = "X"
    elif mode == "nopolar":
        hist.InstrumentParameters["Polariz."][2] = False
    elif mode == "all_restore":
        enable_established_profile(project)
    elif mode != "all":
        raise ValueError(mode)
    project.set_Frozen()
    project.set_Controls("cycles", 16)
    project.refine()
    project.save()
    y = np.asarray(hist.data["data"][1][1], float)
    yc = np.asarray(hist.data["data"][1][3], float)
    w = 1 / np.maximum(y, 1)
    rwp = 100 * np.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y ** 2))
    print("mode", mode, "rwp", rwp, "frozen", project.get_Frozen())
    print("vary", project.data["Covariance"]["data"].get("varyList"))
    print("sample", hist.SampleParameters)
    print("instrument", hist.InstrumentParameters)


if __name__ == "__main__":
    main(*sys.argv[1:4])
