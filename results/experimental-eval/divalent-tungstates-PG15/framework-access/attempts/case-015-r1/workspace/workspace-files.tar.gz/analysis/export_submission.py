#!/usr/bin/env python3
"""Export submission CIFs and the independently replayed profile."""

from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent.parent
PROJECT = ROOT / "final.gpx"
REPLAY = ROOT / "analysis" / "replay_final_candidate"


project = G2.G2Project(gpxfile=str(PROJECT))
# Export tree values exactly as the evaluator does, never stale covariance values.
project.data["Covariance"]["data"] = {}
outputs = ["phase_ZnWO4.cif", "phase_ZnO.cif", "phase_WO3.cif"]
for phase, filename in zip(project.phases(), outputs):
    phase.export_CIF(str(ROOT / filename))

with np.load(REPLAY / "prediction.npz", allow_pickle=False) as profile:
    x = profile["x"]
    observed = profile["observed"]
    calculated = profile["predicted"]
    background = profile["background"]
fit = np.column_stack((x, observed, calculated, observed - calculated, background))
np.savetxt(
    ROOT / "fit.csv",
    fit,
    delimiter=",",
    header="two_theta,observed,calculated,difference,background",
    comments="",
    fmt=["%.8f", "%.8f", "%.10f", "%.10f", "%.10f"],
)

report = json.loads((REPLAY / "replay.json").read_text())
print("exported", outputs, "points", len(fit))
print("phases", report["phases"])
