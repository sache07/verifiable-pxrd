#!/usr/bin/env python3
"""Refine selected atomic coordinates against a fixed physical baseline."""

import sys
import numpy as np
from GSASII import GSASIIscriptable as G2


def hold_noncoordinate_parameters(project):
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    return hist


def main(source, output, phase_index, selection):
    project = G2.G2Project(gpxfile=source, newgpx=output)
    hist = hold_noncoordinate_parameters(project)
    phase = project.phases()[phase_index]
    selected = []
    for atom in phase.atoms():
        is_heavy = atom.element not in ("O", "N", "C", "H")
        use = selection == "all" or (selection == "heavy" and is_heavy) or (
            selection == "oxygen" and atom.element == "O"
        )
        if use:
            atom.refinement_flags = "X"
            selected.append(atom.label)
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.refine()
    project.save()
    y = np.asarray(hist.data["data"][1][1], float)
    yc = np.asarray(hist.data["data"][1][3], float)
    w = 1 / np.maximum(y, 1)
    rwp = 100 * np.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y ** 2))
    print("rwp", rwp, "selected", selected, "frozen", project.get_Frozen())
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.refinement_flags)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4])
