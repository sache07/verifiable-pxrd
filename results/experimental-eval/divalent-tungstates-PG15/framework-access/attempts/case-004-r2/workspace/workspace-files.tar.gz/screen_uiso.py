#!/usr/bin/env python3
"""Evaluate fixed common isotropic displacement values for both phases."""

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


source, output, co_u, w_u = sys.argv[1:5]
p = G2.G2Project(gpxfile=source, filename=output)
h = p.histogram(0)
h.data["Background"][0][1] = False
for v in h.data["Instrument Parameters"][0].values():
    if isinstance(v, list) and len(v) > 2:
        v[2] = False
for v in h.data["Sample Parameters"].values():
    if isinstance(v, list) and len(v) == 2 and isinstance(v[1], bool):
        v[1] = False
for phase in p.phases():
    phase.data["General"]["Cell"][0] = False
    value = float(co_u if phase.name == "CoWO4" else w_u)
    for atom in phase.atoms():
        atom.refinement_flags = " "
        atom.uiso = value
    hap = phase.data["Histograms"][h.name]
    hap["Scale"][1] = False
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][2] = False
p.set_Controls("cycles", 0)
p.refine()
p.save(output)
result = {"co_uiso": float(co_u), "wo3_uiso": float(w_u), "rwp_percent": p.histogram(0).get_wR()}
Path(output).with_suffix(".json").write_text(json.dumps(result) + "\n")
print(json.dumps(result))
