#!/usr/bin/env python3
import json
import sys

import numpy as np

from GSASII import GSASIIscriptable as G2


p = G2.G2Project(gpxfile=sys.argv[1])
h = p.histogram(0)
out = {
    "histogram": h.name,
    "rwp": h.get_wR(),
    "instrument": {k: v[1] for k, v in h.data["Instrument Parameters"][0].items()
                   if isinstance(v, list) and len(v) > 2},
    "sample": h.data["Sample Parameters"],
    "phases": {},
}
for phase in p.phases():
    hap = phase.data["Histograms"][h.name]
    out["phases"][phase.name] = {
        "cell": phase.data["General"]["Cell"][1:8],
        "mass": phase.data["General"]["Mass"],
        "scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
    }
print(json.dumps(out, indent=2))
if len(sys.argv) > 2:
    a = h.data["data"][1]
    np.savetxt(sys.argv[2], np.column_stack([a[0], a[1], a[3], np.asarray(a[1]) - np.asarray(a[3])]),
               delimiter=",", header="two_theta_deg,observed,calculated,difference", comments="")
