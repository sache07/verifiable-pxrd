#!/usr/bin/env python3
"""Restore reference-framework coordinates while retaining the refined profile/cells."""

import sys

from GSASII import GSASIIscriptable as G2


source, destination = sys.argv[1:3]
p = G2.G2Project(gpxfile=source, filename=destination)

reference = {
    "CoWO4": [
        (0.5000, 0.3258, 0.7500),
        (0.0000, 0.1819, 0.2500),
        (0.2160, 0.1070, 0.9370),
        (0.2560, 0.3766, 0.3970),
    ],
    "WO3": [
        (0.2800, 0.2400, -0.0300),
        (0.2470, 0.0330, 0.7810),
        (0.0000, 0.4750, 0.2200),
        (0.2800, 0.0400, 0.0300),
        (0.2100, 0.2900, 0.7350),
        (0.2900, 0.2900, 0.2650),
        (0.0000, 0.0250, 0.2200),
        (0.2520, 0.0260, 0.2850),
    ],
}

for phase in p.phases():
    coords = reference[phase.name]
    cx = phase.data["General"]["AtomPtrs"][0]
    if len(coords) != len(phase.data["Atoms"]):
        raise RuntimeError(f"atom-count mismatch for {phase.name}")
    for atom, xyz in zip(phase.data["Atoms"], coords):
        atom[cx:cx + 3] = list(xyz)

p.save(destination)
