from pathlib import Path
import shutil

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = Path("analysis/candidates")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_substituted(parent_id: str, old: str, new: str, name: str) -> None:
    structure = Structure.from_file(cod_path(parent_id), primitive=False)
    structure.replace_species({old: new})
    CifWriter(structure, symprec=1e-4, refine_struct=False).write_file(OUT / name)


OUT.mkdir(parents=True, exist_ok=True)

# Wolframite-framework analogues. Co substitutes only on the divalent-metal site.
for parent_id, element, stem in [
    ("9013902", "Mg", "mg_parent"),
    ("1520200", "Mn", "mn_parent"),
    ("1520641", "Zn", "zn_parent"),
    ("1567215", "Fe", "fe_parent"),
]:
    write_substituted(parent_id, element, "Co", f"CoWO4_{stem}.cif")

# Candidate secondary phases retained verbatim for screening/refinement.
for cod_id, name in [
    ("1528915", "WO3_1528915.cif"),
    ("2311041", "WO3_2311041.cif"),
    ("2106293", "WO3_2106293.cif"),
    ("1010618", "WO3_1010618.cif"),
    ("9005896", "Co3O4_9005896.cif"),
    ("5910031", "Co3O4_5910031.cif"),
    ("1541662", "CoO_1541662.cif"),
    ("1528166", "W18O49_1528166.cif"),
]:
    shutil.copy2(cod_path(cod_id), OUT / name)

print(f"Prepared {len(list(OUT.glob('*.cif')))} candidate CIFs in {OUT}")
