#!/usr/bin/env python3
"""Screen one March-Dollase axis against a fixed refined project."""

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


source, output, phase_name, axis_text = sys.argv[1:5]
axis = [int(x) for x in axis_text.split(",")]
p = G2.G2Project(gpxfile=source, filename=output)
h = p.histogram(0)

h.data["Background"][0][1] = False
for v in h.data["Instrument Parameters"][0].values():
    if isinstance(v, list) and len(v) > 2:
        v[2] = False
for v in h.data["Sample Parameters"].values():
    if isinstance(v, list) and len(v) == 2 and isinstance(v[1], bool):
        v[1] = False
for phase in p.phases():
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][h.name]
    hap["Scale"][1] = False
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][2] = False

target = p.phase(phase_name)
po = target.data["Histograms"][h.name]["Pref.Ori."]
po[0] = "MD"
po[1] = float(sys.argv[5]) if len(sys.argv) > 5 else 1.0
po[2] = True
po[3] = axis
p.set_Frozen()
p.data["Controls"]["data"]["shift factor"] = 0.5
p.set_Controls("cycles", 5)
p.refine()
p.save(output)
h = p.histogram(0)
ratio = p.phase(phase_name).data["Histograms"][h.name]["Pref.Ori."][1]
result = {"phase": phase_name, "axis": axis, "ratio": ratio, "rwp_percent": h.get_wR()}
Path(output).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
