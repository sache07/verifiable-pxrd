#!/usr/bin/env python3
"""Add one candidate phase to an existing GSAS-II trial and quantify it."""

import json
import math
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def physical_rwp(hist):
    d = hist.data["data"][1]
    x, y, w, calc = map(lambda z: np.asarray(z, float), (d[0], d[1], d[2], d[3]))
    use = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    return 100 * math.sqrt(np.sum(w[use] * (y[use] - calc[use]) ** 2) / np.sum(w[use] * y[use] ** 2))


source, output, name, cif = sys.argv[1:5]
output = Path(output)
output.parent.mkdir(parents=True, exist_ok=True)
p = G2.G2Project(gpxfile=source, filename=str(output))
h = p.histogram(0)

# Freeze the current nuisance/structure model, then fit only phase amounts.
h.data["Background"][0][1] = False
for value in h.data["Instrument Parameters"][0].values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for key, value in h.data["Sample Parameters"].items():
    if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
        value[1] = False
for phase in p.phases():
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][h.name]
    hap["Scale"][1] = False
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False

new = p.add_phase(str(Path(cif).resolve()), phasename=name, histograms=[h], fmthint="CIF")
hap = new.data["Histograms"][h.name]
hap["Scale"] = [0.10, False]
hap["Size"][0] = "isotropic"
hap["Size"][1][0] = 0.10
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = 1000.0
hap["Mustrain"][2] = [False, False, False]
for atom in new.atoms():
    atom.refinement_flags = " "
    atom.uiso = 0.01

for phase in p.phases():
    phase.data["Histograms"][h.name]["Scale"][1] = True

p.set_Controls("parmMin", 0.0, "*:0:Scale")
p.set_Controls("parmMax", 100.0, "*:0:Scale")
p.set_Controls("cycles", 8)
p.refine()

# Give only the added phase's cell a chance to register after its scale is known.
p.set_Frozen()
new = p.phase(name)
new.data["General"]["Cell"][0] = True
p.set_Controls("cycles", 8)
p.refine()
p.save(str(output))

h = p.histogram(0)
terms = {phase.name: max(0.0, phase.data["Histograms"][h.name]["Scale"][0]) * phase.data["General"]["Mass"]
         for phase in p.phases()}
total = sum(terms.values())
result = {
    "rwp_percent": physical_rwp(h),
    "fractions": {k: v / total for k, v in terms.items()},
    "cells": {phase.name: phase.data["General"]["Cell"][1:8] for phase in p.phases()},
}
output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
