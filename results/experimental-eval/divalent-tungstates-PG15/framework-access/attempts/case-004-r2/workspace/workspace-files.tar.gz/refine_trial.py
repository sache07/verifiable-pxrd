#!/usr/bin/env python3
"""Build and stage a GSAS-II Rietveld trial from named CIFs.

Run with the GSAS-II Python interpreter, for example:
  $GSAS2_PYTHON refine_trial.py analysis/trial name=path/to/model.cif ...
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path
import sys
import traceback

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"


def write_inputs(out: Path) -> tuple[np.ndarray, np.ndarray, list[float]]:
    raw = np.loadtxt(PATTERN, delimiter=",", skiprows=1)
    x, y = raw.T
    # GSAS-II's xye reader treats the third field as sigma.
    np.savetxt(out / "pattern.xye", np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]),
               fmt=["%.8f", "%.8f", "%.8f"])
    (out / "instrument.instprm").write_text(
        "# GSAS-II Cu Kalpha laboratory reflection geometry\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.80;Azimuth:0.0\n"
        "U:12.0;V:0.0;W:12.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )

    # Robust smooth baseline used only to initialize the GSAS background.
    baseline = percentile_filter(y, percentile=18, size=401, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    coeff = np.polynomial.chebyshev.chebfit(t, baseline, deg=12).tolist()
    return x, y, coeff


def mass_fractions(project: G2.G2Project, hist_name: str) -> dict[str, float]:
    terms = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist_name]
        terms[phase.name] = max(0.0, float(hap["Scale"][0])) * float(phase.data["General"]["Mass"])
    total = sum(terms.values())
    return {k: (v / total if total else 0.0) for k, v in terms.items()}


def serial(value):
    if isinstance(value, dict):
        return {str(k): serial(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serial(v) for v in value]
    if isinstance(value, np.ndarray):
        return serial(value.tolist())
    if isinstance(value, np.generic):
        return value.item()
    return value


def snapshot(project: G2.G2Project, hist, label: str) -> dict:
    data = hist.data["data"]
    x, obs, weights, calc, background = [np.asarray(data[1][i], float) for i in range(5)]
    use = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    denom = float(np.sum(weights[use] * obs[use] ** 2))
    rwp = 100.0 * math.sqrt(float(np.sum(weights[use] * (obs[use] - calc[use]) ** 2)) / denom)
    phases = {}
    for phase in project.phases():
        h = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": list(map(float, phase.data["General"]["Cell"][1:8])),
            "scale": float(h["Scale"][0]),
            "size": serial(h["Size"]),
            "mustrain": serial(h["Mustrain"]),
            "preferred_orientation": serial(h["Pref.Ori."]),
        }
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "label": label,
        "rwp_percent_recomputed": rwp,
        "rwp_percent_gsas": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "mass_fractions": mass_fractions(project, hist.name),
        "instrument": serial(hist.data["Instrument Parameters"][0]),
        "sample": serial(hist.data["Sample Parameters"]),
        "background": serial(hist.data["Background"]),
        "phases": phases,
        "vary_list": serial(cov.get("varyList", [])),
    }


def run_stage(project, hist, history: list[dict], label: str, cycles: int = 8) -> None:
    # Variables that hit bounds are frozen by GSAS-II. Clear that list before
    # each staged pass so a later, less-correlated model can move them inward.
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    project.refine()
    state = snapshot(project, project.histogram(hist.name), label)
    history.append(state)
    print(f"{label:30s} Rwp={state['rwp_percent_recomputed']:.4f}% "
          f"fractions={state['mass_fractions']}")


def build(out: Path, named_cifs: list[tuple[str, Path]]) -> None:
    out.mkdir(parents=True, exist_ok=True)
    x, y, background_coeff = write_inputs(out)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(out / "trial.gpx"))
    hist = project.add_powder_histogram(str(out / "pattern.xye"), str(out / "instrument.instprm"),
                                       fmthint="xye")
    phases = []
    for name, cif in named_cifs:
        phases.append(project.add_phase(str(cif.resolve()), phasename=name, histograms=[hist], fmthint="CIF"))

    hist.set_refinements({
        "Limits": [float(x[0]), float(x[-1])],
        "Background": {"type": "chebyschev-1", "no. coeffs": len(background_coeff),
                       "coeffs": background_coeff, "refine": False},
    })
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"Zero": 0.0, "Polariz.": 0.80, "U": 12.0, "V": 0.0,
                       "W": 12.0, "X": 1.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.03}.items():
        inst[key][1] = value
        inst[key][2] = False

    for i, phase in enumerate(phases):
        # Use comparable positive starting mass contributions.
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / float(phase.data["General"]["Mass"]), False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][1][1] = 0.30
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
            atom.uiso = 0.01

    # Physical ranges are the frozen laboratory's generation ranges. They also
    # prevent profile/cell compensation from producing an unreplayable model.
    for variable, lo, hi in [
        (":0:Zero", -0.25, 0.25),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Shift", -800.0, 800.0),
    ]:
        project.set_Controls("parmMin", lo, variable)
        project.set_Controls("parmMax", hi, variable)
    for i in range(len(phases)):
        for suffix, lo, hi in [("Scale", 0.0, 100.0), ("Size;i", 0.04, 1.5),
                               ("Mustrain;i", 0.0, 8000.0)]:
            project.set_Controls("parmMin", lo, f"{i}:0:{suffix}")
            project.set_Controls("parmMax", hi, f"{i}:0:{suffix}")

    history: list[dict] = []
    project.set_Controls("cycles", 0)
    project.refine()
    history.append(snapshot(project, project.histogram(hist.name), "initial"))

    hist = project.histogram(hist.name)
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    run_stage(project, hist, history, "background + scales", 18)

    hist = project.histogram(hist.name)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run_stage(project, hist, history, "cells + zero", 24)

    hist = project.histogram(hist.name)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    run_stage(project, hist, history, "instrument profile", 24)

    for phase in project.phases():
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True, "value": 0.30},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    run_stage(project, project.histogram(hist.name), history, "phase size + strain", 28)

    hist = project.histogram(hist.name)
    hist.set_refinements({"Instrument Parameters": ["SH/L"], "Sample Parameters": ["Shift"]})
    run_stage(project, hist, history, "asymmetry + displacement", 28)

    # A final joint pass after the profile parameters have settled.
    run_stage(project, project.histogram(hist.name), history, "joint repeat 1", 30)
    run_stage(project, project.histogram(hist.name), history, "joint repeat 2", 30)

    project.save(str(out / "trial.gpx"))
    final = snapshot(project, project.histogram(hist.name), "final")
    (out / "summary.json").write_text(json.dumps({"history": history, "final": final}, indent=2) + "\n")
    arr = project.histogram(hist.name).data["data"][1]
    np.savetxt(out / "fit.csv", np.column_stack([arr[0], arr[1], arr[3], arr[1] - arr[3]]),
               delimiter=",", header="two_theta_deg,observed,calculated,difference", comments="")


def main() -> None:
    if len(sys.argv) < 3:
        raise SystemExit("usage: refine_trial.py OUTDIR NAME=CIF [NAME=CIF ...]")
    out = Path(sys.argv[1])
    pairs = []
    for item in sys.argv[2:]:
        name, sep, path = item.partition("=")
        if not sep:
            raise SystemExit(f"expected NAME=CIF, got {item!r}")
        pairs.append((name, Path(path)))
    try:
        build(out, pairs)
    except Exception:
        out.mkdir(parents=True, exist_ok=True)
        (out / "failure.txt").write_text(traceback.format_exc())
        raise


if __name__ == "__main__":
    main()
