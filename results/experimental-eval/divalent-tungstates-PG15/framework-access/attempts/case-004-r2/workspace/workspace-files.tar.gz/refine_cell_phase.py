#!/usr/bin/env python3
"""Refine one phase cell while all other parameters remain fixed."""

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


source, output, phase_name = sys.argv[1:4]
p = G2.G2Project(gpxfile=source, filename=output)
h = p.histogram(0)
h.data["Background"][0][1] = False
for v in h.data["Instrument Parameters"][0].values():
    if isinstance(v, list) and len(v) > 2:
        v[2] = False
for v in h.data["Sample Parameters"].values():
    if isinstance(v, list) and len(v) == 2 and isinstance(v[1], bool):
        v[1] = False
for phase in p.phases():
    phase.data["General"]["Cell"][0] = phase.name == phase_name
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][h.name]
    hap["Scale"][1] = False
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][2] = False
p.set_Frozen()
p.data["Controls"]["data"]["shift factor"] = 0.25
p.set_Controls("cycles", 12)
p.refine()
p.save(output)
result = {"phase": phase_name, "rwp_percent": p.histogram(0).get_wR(),
          "cell": p.phase(phase_name).data["General"]["Cell"][1:8],
          "vary_list": p.data.get("Covariance", {}).get("data", {}).get("varyList", [])}
Path(output).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
