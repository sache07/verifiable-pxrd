#!/usr/bin/env python3
"""Apply one controlled refinement stage to an existing GSAS-II project."""

from __future__ import annotations

import json
import math
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def freeze_all(p, h):
    h.data["Background"][0][1] = False
    for v in h.data["Instrument Parameters"][0].values():
        if isinstance(v, list) and len(v) > 2:
            v[2] = False
    for v in h.data["Sample Parameters"].values():
        if isinstance(v, list) and len(v) == 2 and isinstance(v[1], bool):
            v[1] = False
    for phase in p.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def set_coordinate_bounds(p, phase, span=0.025):
    pid = int(phase.data["pId"])
    cx = phase.data["General"]["AtomPtrs"][0]
    for i, raw in enumerate(phase.data["Atoms"]):
        for axis, value in zip("xyz", raw[cx:cx + 3]):
            # The GSAS-II variable is named dAx/dAy/dAz, but its bounded value
            # is the resulting absolute fractional coordinate.
            var = f"{pid}::dA{axis}:{i}"
            p.set_Controls("parmMin", float(value) - span, var)
            p.set_Controls("parmMax", float(value) + span, var)


def rwp(hist):
    d = hist.data["data"][1]
    x, y, w, c = [np.asarray(d[i], float) for i in (0, 1, 2, 3)]
    use = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    return float(100 * math.sqrt(np.sum(w[use] * (y[use] - c[use]) ** 2) / np.sum(w[use] * y[use] ** 2)))


source, destination, mode = sys.argv[1:4]
cycles = int(sys.argv[4]) if len(sys.argv) > 4 else 6
p = G2.G2Project(gpxfile=source, filename=destination)
h = p.histogram(0)
freeze_all(p, h)
p.set_Frozen()
p.data["Controls"]["data"]["shift factor"] = 0.5

# Keep phase scale and smooth background current during all structural stages.
if mode in {"calibration", "cells_zero", "scale_bg", "pol_bg", "rough_bg", "rough_pol_bg", "heavy", "oxygen", "heavy_tight", "oxygen_tight", "allcoords", "uiso", "joint"}:
    h.data["Background"][0][1] = True
    for phase in p.phases():
        if phase.data["Histograms"][h.name].get("Use", True):
            phase.data["Histograms"][h.name]["Scale"][1] = True

if mode == "calibration":
    h.data["Instrument Parameters"][0]["Zero"][2] = True
    h.data["Sample Parameters"]["Shift"][1] = True
    for phase in p.phases():
        phase.data["General"]["Cell"][0] = True
elif mode == "cells_zero":
    h.data["Instrument Parameters"][0]["Zero"][2] = True
    for phase in p.phases():
        phase.data["General"]["Cell"][0] = True
elif mode == "zero":
    h.data["Instrument Parameters"][0]["Zero"][2] = True
elif mode == "shift":
    h.data["Sample Parameters"]["Shift"][1] = True
elif mode == "scale_bg":
    pass
elif mode == "pol_bg":
    h.data["Instrument Parameters"][0]["Polariz."][2] = True
elif mode in {"rough_bg", "rough_pol_bg"}:
    h.data["Sample Parameters"]["SurfRoughA"][1] = True
    h.data["Sample Parameters"]["SurfRoughB"][1] = True
    if mode == "rough_pol_bg":
        h.data["Instrument Parameters"][0]["Polariz."][2] = True
elif mode in {"heavy", "oxygen", "heavy_tight", "oxygen_tight", "allcoords"}:
    coordinate_mode = mode.removesuffix("_tight")
    for phase in p.phases():
        set_coordinate_bounds(p, phase, span=0.008 if mode.endswith("_tight") else 0.025)
        for atom in phase.atoms():
            is_oxygen = atom.element.split("+")[0].split("-")[0] == "O"
            if coordinate_mode == "allcoords" or (coordinate_mode == "heavy" and not is_oxygen) or (coordinate_mode == "oxygen" and is_oxygen):
                atom.refinement_flags = "X"
elif mode == "uiso":
    for phase in p.phases():
        pid = int(phase.data["pId"])
        for i, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            p.set_Controls("parmMin", 0.003, f"{pid}::AUiso:{i}")
            p.set_Controls("parmMax", 0.020, f"{pid}::AUiso:{i}")
elif mode == "profile":
    for key in ["U", "W", "X", "SH/L"]:
        h.data["Instrument Parameters"][0][key][2] = True
    for phase in p.phases():
        hap = phase.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][2][0] = True
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2][0] = True
elif mode == "joint":
    h.data["Instrument Parameters"][0]["Zero"][2] = True
    h.data["Sample Parameters"]["Shift"][1] = True
    for phase in p.phases():
        phase.data["General"]["Cell"][0] = True
        set_coordinate_bounds(p, phase, span=0.012)
        for atom in phase.atoms():
            atom.refinement_flags = "X"
else:
    raise SystemExit(f"unknown mode: {mode}")

# Maintain physical bounds for the parameters used by these modes.
for variable, lo, hi in [
    (":0:Zero", -0.25, 0.25), (":0:Shift", -800.0, 800.0),
    (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0),
    (":0:X", 0.1, 6.0), (":0:SH/L", 0.005, 0.10),
    (":0:Polariz.", 0.5, 1.0),
    (":0:SurfRoughA", 0.05, 0.6), (":0:SurfRoughB", 0.02, 0.5),
    ("*:0:Scale", 0.0, 100.0), ("*:0:Size;i", 0.04, 1.5),
    ("*:0:Mustrain;i", 0.0, 8000.0),
]:
    p.set_Controls("parmMin", lo, variable)
    p.set_Controls("parmMax", hi, variable)

p.set_Controls("cycles", cycles)
p.refine()
p.save(destination)
h = p.histogram(0)
result = {
    "mode": mode,
    "rwp_percent": rwp(h),
    "gof": p.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
    "frozen": p.get_Frozen(),
    "vary_list": p.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    "zero": h.data["Instrument Parameters"][0]["Zero"][1],
    "shift_um": h.data["Sample Parameters"]["Shift"][0],
    "cells": {q.name: q.data["General"]["Cell"][1:8] for q in p.phases()},
}
Path(destination).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
