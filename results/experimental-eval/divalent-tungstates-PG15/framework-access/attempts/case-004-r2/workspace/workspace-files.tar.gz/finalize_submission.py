#!/usr/bin/env python3
"""Freeze the selected model and export internally consistent deliverables."""

from __future__ import annotations

import json
import math
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


source = Path(sys.argv[1])
project_path = Path("final.gpx")
p = G2.G2Project(gpxfile=str(source), filename=str(project_path))
h = p.histogram(0)

# Freeze every refinement flag. A zero-variable GSAS-II calculation below
# regenerates the saved calculated profile from the exact submitted model.
h.data["Background"][0][1] = False
for value in h.data["Instrument Parameters"][0].values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for value in h.data["Sample Parameters"].values():
    if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
        value[1] = False
for phase in p.phases():
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][h.name]
    hap["Scale"][1] = False
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False

p.set_Frozen()
p.set_Controls("cycles", 0)
p.refine()
p.save(str(project_path))

# Use the original public x/y values verbatim in the exported profile.
observed = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1, ndmin=2)
x_public, y_public = observed.T
arrays = h.data["data"][1]
x_project = np.asarray(arrays[0], dtype=float)
y_project = np.asarray(arrays[1], dtype=float)
calculated = np.asarray(arrays[3], dtype=float)
background = np.asarray(arrays[4], dtype=float)
if not (len(x_project) == len(x_public) and
        np.allclose(x_project, x_public, rtol=0, atol=1e-7) and
        np.allclose(y_project, y_public, rtol=0, atol=1e-5)):
    raise RuntimeError("final project histogram does not match inputs/pattern.csv")
if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
    raise RuntimeError("calculated profile is nonfinite or negative")

profile = np.column_stack((x_public, y_public, calculated, y_public - calculated))
np.savetxt(
    "fit.csv", profile, delimiter=",",
    header="two_theta_deg,observed,calculated,difference", comments="",
    fmt=["%.10f", "%.10f", "%.10f", "%.10f"],
)

weights = 1.0 / np.maximum(y_public, 1.0)
residual = y_public - calculated
chi_square = float(np.sum(weights * residual * residual))
denominator = float(np.sum(weights * y_public * y_public))
rwp = float(100.0 * math.sqrt(chi_square / denominator))
rp = float(100.0 * np.sum(np.abs(residual)) / np.sum(y_public))
# The last converged scale/background stage used 15 variables.
gof = float(math.sqrt(chi_square / (len(y_public) - 15)))

masses = []
records = []
for phase in p.phases():
    hap = phase.data["Histograms"][h.name]
    contribution = float(phase.data["General"]["Mass"] * hap["Scale"][0])
    masses.append(contribution)
    records.append((phase, contribution))
total = float(sum(masses))
if total <= 0:
    raise RuntimeError("nonpositive total crystalline scale")

# Match the evaluator's export convention: ignore stale covariance values and
# export the full-precision atoms/cell stored in each phase.
p.data["Covariance"]["data"] = {}
phase_rows = []
for phase, contribution in records:
    cif_path = Path(f"phase_{phase.name}.cif")
    phase.export_CIF(str(cif_path))
    phase_rows.append({
        "name": phase.name,
        "formula": phase.name,
        "cif_path": str(cif_path),
        "weight_fraction": contribution / total,
    })

result = {
    "phases": phase_rows,
    "fraction_basis": "normalized over modeled crystalline phases",
    "refinement_histogram": h.name,
    "project_path": str(project_path),
    "fit_profile": "fit.csv",
    "fit_statistics": {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "GOF": gof,
        "chi_square": chi_square,
        "n_points": int(len(y_public)),
    },
}
Path("result.json").write_text(json.dumps(result, indent=2) + "\n")

summary = {
    **result,
    "background_minimum_counts": float(np.min(background)),
    "instrument": {
        key: value[1]
        for key, value in h.data["Instrument Parameters"][0].items()
        if isinstance(value, list) and len(value) > 2
    },
    "sample_shift_um": float(h.data["Sample Parameters"]["Shift"][0]),
    "cells": {phase.name: phase.data["General"]["Cell"][1:8] for phase in p.phases()},
    "scales": {
        phase.name: phase.data["Histograms"][h.name]["Scale"][0]
        for phase in p.phases()
    },
}
print(json.dumps(summary, indent=2))
