#!/usr/bin/env python3
"""Screen a WO3 structure by replacing the active WO3 in a template project."""

import json
import math
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


template, output, cif = sys.argv[1:4]
output = Path(output)
p = G2.G2Project(gpxfile=template, filename=str(output))
h = p.histogram(0)

# Freeze every existing parameter and disable the old WO3 contribution.
h.data["Background"][0][1] = False
for v in h.data["Instrument Parameters"][0].values():
    if isinstance(v, list) and len(v) > 2:
        v[2] = False
for v in h.data["Sample Parameters"].values():
    if isinstance(v, list) and len(v) == 2 and isinstance(v[1], bool):
        v[1] = False
old_wo3 = p.phase("WO3")
old_hap = old_wo3.data["Histograms"][h.name]
old_scale = float(old_hap["Scale"][0])
old_size = float(old_hap["Size"][1][0])
old_strain = float(old_hap["Mustrain"][1][0])
old_hap["Use"] = False
old_hap["Scale"] = [0.0, False]

for phase in p.phases():
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][h.name]
    hap["Scale"][1] = False
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][2] = False

alt = p.add_phase(str(Path(cif).resolve()), phasename="WO3_alt", histograms=[h], fmthint="CIF")
hap = alt.data["Histograms"][h.name]
hap["Scale"] = [old_scale, False]
hap["Size"][0] = "isotropic"
hap["Size"][1][0] = old_size
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = old_strain
hap["Mustrain"][2] = [False, False, False]
for atom in alt.atoms():
    atom.refinement_flags = " "
    atom.uiso = 0.01

p.phase("CoWO4").data["Histograms"][h.name]["Scale"][1] = True
hap["Scale"][1] = True
p.set_Controls("parmMin", 0.0, "*:0:Scale")
p.set_Controls("parmMax", 100.0, "*:0:Scale")
p.set_Controls("cycles", 5)
p.refine()

p.set_Frozen()
alt = p.phase("WO3_alt")
alt.data["General"]["Cell"][0] = True
p.set_Controls("cycles", 10)
p.refine()
p.save(str(output))

h = p.histogram(0)
d = h.data["data"][1]
x, y, w, calc = map(lambda z: np.asarray(z, float), (d[0], d[1], d[2], d[3]))
use = (x >= h.data["Limits"][1][0]) & (x <= h.data["Limits"][1][1])
rwp = 100 * math.sqrt(np.sum(w[use] * (y[use] - calc[use]) ** 2) / np.sum(w[use] * y[use] ** 2))
terms = {q.name: max(0.0, q.data["Histograms"][h.name]["Scale"][0]) * q.data["General"]["Mass"]
         for q in p.phases() if q.data["Histograms"][h.name].get("Use", True)}
total = sum(terms.values())
result = {"rwp_percent": rwp, "fractions": {k: v / total for k, v in terms.items()},
          "alt_cell": alt.data["General"]["Cell"][1:8]}
output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
