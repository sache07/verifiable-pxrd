#!/usr/bin/env python3
"""Recalculate a project after setting fixed profile parameters."""

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


source, output, *assignments = sys.argv[1:]
p = G2.G2Project(gpxfile=source, filename=output)
h = p.histogram(0)
h.data["Background"][0][1] = False
for v in h.data["Instrument Parameters"][0].values():
    if isinstance(v, list) and len(v) > 2:
        v[2] = False
for v in h.data["Sample Parameters"].values():
    if isinstance(v, list) and len(v) == 2 and isinstance(v[1], bool):
        v[1] = False
for phase in p.phases():
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][h.name]
    hap["Scale"][1] = False
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][2] = False

used = {}
for item in assignments:
    key, value = item.split("=", 1)
    value = float(value)
    used[key] = value
    if key in {"U", "W", "X", "SH/L", "Polariz."}:
        h.data["Instrument Parameters"][0][key][1] = value
    elif key in {"SurfRoughA", "SurfRoughB"}:
        h.data["Sample Parameters"][key][0] = value
    elif key.endswith("_size"):
        p.phase(key[:-5]).data["Histograms"][h.name]["Size"][1][0] = value
    elif key.endswith("_strain"):
        p.phase(key[:-7]).data["Histograms"][h.name]["Mustrain"][1][0] = value
    else:
        raise SystemExit(f"unknown profile key {key}")
p.set_Controls("cycles", 0)
p.refine()
p.save(output)
result = {"values": used, "rwp_percent": p.histogram(0).get_wR()}
Path(output).with_suffix(".json").write_text(json.dumps(result) + "\n")
print(json.dumps(result))
