#!/usr/bin/env python3
"""Create fit.csv and result.json from the verified GSAS-II replay."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


def main():
    with np.load(".tmp/replay_final/prediction.npz", allow_pickle=False) as replay:
        x = replay["x"].astype(float)
        observed = replay["observed"].astype(float)
        calculated = replay["predicted"].astype(float)
    difference = observed - calculated
    np.savetxt(
        "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.10f",
    )

    project = json.loads(Path(".tmp/final_project_summary.json").read_text())
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100 * np.sqrt(chi_square / denominator))
    rp = float(100 * np.sum(np.abs(difference)) / np.sum(observed))
    n_points = int(observed.size)
    # The last converged least-squares pass used 78 variables (reported in the
    # GSAS-II listing); subsequent fixed-parameter forward evaluations did not
    # add variables.
    n_parameters = 78
    dof = n_points - n_parameters
    reduced_chi_square = chi_square / dof
    r_exp = float(100 * np.sqrt(dof / denominator))

    result = {
        "method": "GSAS-II Rietveld refinement with native project replay",
        "refinement_histogram": project["histogram"],
        "phases": [
            {
                "name": "CuWO4",
                "formula": "CuWO4",
                "space_group": "P -1",
                "cif_path": "CuWO4.cif",
                "weight_fraction": project["phases"][0]["weight_fraction"],
            },
            {
                "name": "WO3_2311041",
                "formula": "WO3",
                "space_group": "P 21/c",
                "cif_path": "WO3.cif",
                "weight_fraction": project["phases"][1]["weight_fraction"],
            },
        ],
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "r_exp_percent": r_exp,
            "goodness_of_fit": float(np.sqrt(reduced_chi_square)),
            "chi_square": chi_square,
            "reduced_chi_square": reduced_chi_square,
            "n_points": n_points,
            "n_refined_parameters": n_parameters,
            "weighting": "1/max(observed_counts,1)",
        },
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
