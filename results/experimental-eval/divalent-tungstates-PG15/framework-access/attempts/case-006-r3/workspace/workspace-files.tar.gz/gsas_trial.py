#!/usr/bin/env python3
"""Build and refine trial GSAS-II models for the supplied powder scan."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter

from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIscriptable as G2


WORK = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def phase_path(token: str) -> Path:
    supplied = Path(token)
    if supplied.is_file():
        return supplied.resolve()
    return cod_path(token)


def instrument_text() -> str:
    return (
        "# GSAS-II trial Cu K-alpha Bragg-Brentano instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.08;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:80.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def background_coefficients(x: np.ndarray, y: np.ndarray, degree: int) -> list[float]:
    # A low local percentile follows the smooth laboratory background while
    # mostly rejecting the dense high-angle Bragg peaks.
    baseline = gaussian_filter1d(
        percentile_filter(y, size=501, percentile=12, mode="nearest"), 120
    )
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, baseline, degree - 1).tolist()


def set_instrument_value(hist, key: str, value: float) -> None:
    item = hist.InstrumentParameters[key]
    item[0] = value
    item[1] = value


def summarize(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    weight = np.asarray(hist.getdata("Yweight"), float)
    rwp = 100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2))
    result = {
        "label": label,
        "rwp_recomputed": float(rwp),
        "wR_GSAS": hist.get_wR(),
        "instrument": {
            k: float(hist.InstrumentParameters[k][1])
            for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "sample": {
            k: (float(v[0]) if isinstance(v, list) else v)
            for k, v in hist.SampleParameters.items()
            if k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius")
        },
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "composition": phase.composition,
                "cell": phase.get_cell(),
                "mass": float(phase.data["General"]["Mass"]),
                "scale": float(hap["Scale"][0]),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
            }
        )
    print(json.dumps(result, indent=2, default=str), flush=True)
    return result


def run_refinement(project: G2.G2Project, label: str, cycles: int = 6) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine()
    return summarize(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ids", required=True, help="comma-separated COD identifiers or CIF paths")
    parser.add_argument("--names", help="comma-separated phase names")
    parser.add_argument("--out", required=True)
    parser.add_argument(
        "--stage",
        choices=("initial", "intensity", "position", "profile"),
        default="initial",
        help="last staged refinement to run",
    )
    args = parser.parse_args()

    ids = [v.strip() for v in args.ids.split(",") if v.strip()]
    names = [v.strip() for v in args.names.split(",")] if args.names else ids
    if len(ids) != len(names):
        raise ValueError("--ids and --names must have the same number of values")
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    inst = out / "trial.instprm"
    inst.write_text(instrument_text())

    project = G2.G2Project(newgpx=str(out / "trial.gpx"))
    phases = [
        project.add_phase(str(phase_path(cod_id)), phasename=name, fmthint="CIF")
        for cod_id, name in zip(ids, names)
    ]
    hist = project.add_powder_histogram(
        str(WORK / "inputs" / "pattern.csv"), str(inst), phases=phases, fmthint="comma"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    x, y = np.loadtxt(WORK / "inputs" / "pattern.csv", delimiter=",", skiprows=1).T
    coeffs = background_coefficients(x, y, 12)
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(coeffs),
                "coeffs": coeffs,
                "refine": False,
            },
        }
    )
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]

    project.set_Controls("cycles", 0)
    project.refine()
    records = [summarize(project, "initial")]
    if args.stage == "initial":
        (out / "summary.json").write_text(json.dumps(records, indent=2, default=str) + "\n")
        return

    # Start with only linear intensity parameters while peaks remain broad.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    records.append(run_refinement(project, "background_scales", 5))
    if args.stage == "intensity":
        project.save()
        (out / "summary.json").write_text(json.dumps(records, indent=2, default=str) + "\n")
        return

    # Lock peak positions using the common zero and each phase cell.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    records.append(run_refinement(project, "zero_cells", 8))
    if args.stage == "position":
        project.save()
        (out / "summary.json").write_text(json.dumps(records, indent=2, default=str) + "\n")
        return

    # Refine the common instrumental profile, then phase-specific broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    records.append(run_refinement(project, "instrument", 8))
    for phase in project.phases():
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True, "value": 0.5},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    records.append(run_refinement(project, "phase_profiles", 8))
    project.save()
    (out / "summary.json").write_text(json.dumps(records, indent=2, default=str) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
