#!/usr/bin/env python3
"""Refine one optional specimen/structure branch from an existing GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist):
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    wt = np.asarray(hist.getdata("Yweight"), float)
    return float(100 * np.sqrt(np.sum(wt * (obs - calc) ** 2) / np.sum(wt * obs**2)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--md", help="March-Dollase axis as h,k,l")
    ap.add_argument("--md-start", type=float, default=1.0)
    ap.add_argument("--rough", action="store_true")
    ap.add_argument("--uiso", type=float)
    ap.add_argument("--refine-uiso", action="store_true")
    ap.add_argument("--strain", help="isotropic or uniaxial h,k,l")
    ap.add_argument("--strain-start", type=float, default=500.0)
    ap.add_argument("--background-coeffs", type=int)
    ap.add_argument("--size", type=float)
    ap.add_argument("--refine-size", action="store_true")
    ap.add_argument("--x-profile", type=float)
    ap.add_argument("--fix-x-profile", action="store_true")
    ap.add_argument("--u-profile", type=float)
    ap.add_argument("--fix-u-profile", action="store_true")
    ap.add_argument("--polarization", type=float)
    ap.add_argument("--fix-polarization", action="store_true")
    ap.add_argument("--cycles", type=int, default=12)
    args = ap.parse_args()

    output = Path(args.out).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.input, newgpx=str(output))
    hist = project.histograms()[0]
    phase = project.phases()[0]
    hap = phase.data["Histograms"][hist.name]
    if args.md:
        axis = [int(v) for v in args.md.split(",")]
        if len(axis) != 3 or not any(axis):
            raise ValueError("--md requires a nonzero h,k,l triple")
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = args.md_start
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
    if args.rough:
        hist.SampleParameters["SurfRoughA"] = [0.20, True]
        hist.SampleParameters["SurfRoughB"] = [0.10, True]
    if args.uiso is not None:
        for atom in phase.atoms():
            atom.uiso = args.uiso
            if args.refine_uiso:
                atom.refinement_flags = "XU" if "X" in atom.refinement_flags else "U"
    if args.strain:
        mustrain = hap["Mustrain"]
        mustrain[1][0] = args.strain_start
        if args.strain == "isotropic":
            mustrain[0] = "isotropic"
            mustrain[1][1] = args.strain_start
            mustrain[2] = [True, False, False]
        else:
            axis = [int(v) for v in args.strain.split(",")]
            if len(axis) != 3 or not any(axis):
                raise ValueError("--strain requires isotropic or a nonzero h,k,l triple")
            mustrain[0] = "uniaxial"
            mustrain[1][1] = args.strain_start
            mustrain[2] = [True, True, False]
            mustrain[3] = axis
    if args.background_coeffs is not None:
        if not 3 <= args.background_coeffs <= 36:
            raise ValueError("--background-coeffs must be between 3 and 36")
        current = hist.Background[0][2]
        if args.background_coeffs > current:
            hist.Background[0].extend([0.0] * (args.background_coeffs - current))
        elif args.background_coeffs < current:
            del hist.Background[0][3 + args.background_coeffs : 3 + current]
        hist.Background[0][2] = args.background_coeffs
        hist.Background[0][1] = True
    if args.size is not None:
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = args.size
        hap["Size"][2][0] = args.refine_size
    if args.x_profile is not None:
        hist.InstrumentParameters["X"][0:2] = [args.x_profile, args.x_profile]
        if args.fix_x_profile:
            hist.InstrumentParameters["X"][2] = False
    if args.u_profile is not None:
        hist.InstrumentParameters["U"][0:2] = [args.u_profile, args.u_profile]
        hist.InstrumentParameters["U"][2] = not args.fix_u_profile
    if args.polarization is not None:
        hist.InstrumentParameters["Polariz."][0:2] = [args.polarization, args.polarization]
        if args.fix_polarization:
            hist.InstrumentParameters["Polariz."][2] = False
    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save()
    result = {
        "rwp": rwp(hist),
        "md": {
            "axis": hap["Pref.Ori."][3],
            "ratio": hap["Pref.Ori."][1],
            "refine": hap["Pref.Ori."][2],
        },
        "roughness": {
            "A": hist.SampleParameters["SurfRoughA"][0],
            "B": hist.SampleParameters["SurfRoughB"][0],
        },
        "uiso": {atom.label: atom.uiso for atom in phase.atoms()},
        "mustrain": hap["Mustrain"][:4],
        "cell": phase.get_cell(),
        "zero": hist.InstrumentParameters["Zero"][1],
        "shift_um": hist.SampleParameters["Shift"][0],
        "profile": {
            "W": hist.InstrumentParameters["W"][1],
            "U": hist.InstrumentParameters["U"][1],
            "X": hist.InstrumentParameters["X"][1],
            "polarization": hist.InstrumentParameters["Polariz."][1],
            "size_um": hap["Size"][1][0],
        },
    }
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
