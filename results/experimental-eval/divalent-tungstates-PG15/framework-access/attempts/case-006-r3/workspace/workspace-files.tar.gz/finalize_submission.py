#!/usr/bin/env python3
"""Freeze the selected GSAS-II model and export its phase CIFs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    args = ap.parse_args()

    project = G2.G2Project(gpxfile=args.input, newgpx="final.gpx")
    histograms = project.histograms()
    if len(histograms) != 1:
        raise ValueError("Expected one powder histogram")
    phases = project.phases()
    if len(phases) != 2:
        raise ValueError("Expected the selected two-phase model")
    project.data["Controls"]["data"]["LastSavedAs"] = str(Path("final.gpx").resolve())
    project.save()

    paths = [Path("CuWO4.cif"), Path("WO3.cif")]
    for phase, path in zip(phases, paths):
        phase.export_CIF(str(path))

    hist = histograms[0]
    mass_scales = [
        float(phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in phases
    ]
    total = sum(mass_scales)
    summary = {
        "histogram": hist.name,
        "phases": [
            {
                "project_name": phase.name,
                "cif_path": str(path),
                "composition": phase.composition,
                "cell": phase.get_cell(),
                "weight_fraction": mass_scale / total,
            }
            for phase, path, mass_scale in zip(phases, paths, mass_scales)
        ],
        "instrument": {
            key: hist.InstrumentParameters[key]
            for key in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
        },
        "sample": {
            key: hist.SampleParameters[key]
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
        },
    }
    Path(".tmp/final_project_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
