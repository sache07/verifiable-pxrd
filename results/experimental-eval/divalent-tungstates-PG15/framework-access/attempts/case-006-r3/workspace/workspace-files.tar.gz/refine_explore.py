#!/usr/bin/env python3
"""Controlled refinements starting from the indexed CuWO4 trial project."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/trials/cuwo4_analogue_position/trial.gpx"
OUT = ROOT / ".tmp/explore"


def set_inst(hist, key, value, refine=False):
    hist.InstrumentParameters[key][0] = float(value)
    hist.InstrumentParameters[key][1] = float(value)
    hist.InstrumentParameters[key][2] = bool(refine)


def clear_flags(hist, phase):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if isinstance(hist.SampleParameters.get(key), list):
            hist.SampleParameters[key][1] = False
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = False
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False


def report(project, label):
    hist = project.histograms()[0]
    phase = project.phases()[0]
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    wt = np.asarray(hist.getdata("Yweight"), float)
    rwp = 100 * np.sqrt(np.sum(wt * (obs - calc) ** 2) / np.sum(wt * obs**2))
    hap = phase.data["Histograms"][hist.name]
    rec = {
        "label": label,
        "rwp": float(rwp),
        "cell": phase.get_cell(),
        "zero": hist.InstrumentParameters["Zero"][1],
        "shift_um": hist.SampleParameters["Shift"][0],
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("U", "V", "W", "X", "SH/L", "Polariz.")
        },
        "size": hap["Size"][1][0],
        "mustrain": hap["Mustrain"][1][0],
        "scale": hap["Scale"][0],
        "roughness": [
            hist.SampleParameters["SurfRoughA"][0],
            hist.SampleParameters["SurfRoughB"][0],
        ],
        "atoms": {
            atom.label: {
                "xyz": list(atom.coordinates),
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        },
    }
    print(json.dumps(rec, indent=2), flush=True)
    return rec


def refine(project, label, cycles=10):
    project.set_Controls("cycles", cycles)
    project.refine()
    rec = report(project, label)
    project.save(str(OUT / f"{label}.gpx"))
    return rec


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUT / "working.gpx"))
    hist = project.histograms()[0]
    phase = project.phases()[0]
    clear_flags(hist, phase)

    # Use a physically allowed representative decomposition of the observed
    # peak widths. With one phase, instrument X and crystallite size (and U and
    # isotropic strain) are exactly or nearly collinear.
    set_inst(hist, "U", 0.0)
    set_inst(hist, "V", 0.0)
    set_inst(hist, "W", 15.0)
    set_inst(hist, "X", 3.0)
    set_inst(hist, "SH/L", 0.03)
    set_inst(hist, "Polariz.", 0.75)
    hist.SampleParameters["Shift"] = [-600.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.InstrumentParameters["Zero"][0:2] = [0.1, 0.1]
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.30
    hap["Size"][2][0] = False
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2][0] = False

    hist.Background[0][1] = True
    hap["Scale"][1] = True
    hist.InstrumentParameters["Zero"][2] = True
    hist.SampleParameters["Shift"][1] = True
    phase.data["General"]["Cell"][0] = True
    records = [refine(project, "01_angle", 12)]

    # Refine a positive common profile and polarization, retaining the fixed
    # zero-strain, 0.30-um representative specimen contribution.
    for key in ("W", "X", "SH/L", "Polariz."):
        hist.InstrumentParameters[key][2] = True
    records.append(refine(project, "02_profile", 12))

    phase.set_refinements({"Atoms": {"Cu1": "X", "W1": "X"}})
    records.append(refine(project, "03_heavy_atoms", 12))

    phase.set_refinements({"Atoms": {"all": "X"}})
    records.append(refine(project, "04_all_atoms", 15))
    (OUT / "records.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
