#!/usr/bin/env python3
"""Add and refine a candidate minor phase against a converged principal model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist):
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    wt = np.asarray(hist.getdata("Yweight"), float)
    return float(100 * np.sqrt(np.sum(wt * (obs - calc) ** 2) / np.sum(wt * obs**2)))


def refine(project, cycles):
    project.set_Controls("cycles", cycles)
    project.refine()


def summary(project, label):
    hist = project.histograms()[0]
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(mass)
        phases.append(
            {
                "name": phase.name,
                "mass_scale": mass,
                "scale": hap["Scale"][0],
                "cell": phase.get_cell(),
                "size": hap["Size"][1][0],
                "mustrain": hap["Mustrain"][:4],
                "atoms": {
                    atom.label: {"xyz": list(atom.coordinates), "uiso": atom.uiso}
                    for atom in phase.atoms()
                },
            }
        )
    total = sum(masses)
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / total
    result = {"label": label, "rwp": rwp(hist), "phases": phases}
    print(json.dumps(result, indent=2), flush=True)
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--cif", required=True)
    ap.add_argument("--name", default="minor")
    ap.add_argument("--out", required=True)
    ap.add_argument("--initial-fraction", type=float, default=0.05)
    args = ap.parse_args()

    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.input, newgpx=str(out))
    hist = project.histograms()[0]
    major = project.phases()[0]
    minor = project.add_phase(args.cif, phasename=args.name, histograms=[hist], fmthint="CIF")
    for atom in minor.atoms():
        atom.uiso = 0.005
        atom.refinement_flags = " "
    hap_major = major.data["Histograms"][hist.name]
    hap = minor.data["Histograms"][hist.name]
    mass_major = major.data["General"]["Mass"]
    mass_minor = minor.data["General"]["Mass"]
    ratio = args.initial_fraction / (1 - args.initial_fraction)
    hap["Scale"] = [hap_major["Scale"][0] * ratio * mass_major / mass_minor, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.5
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][1][1] = 500.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]
    minor.data["General"]["Cell"][0] = True

    records = []
    refine(project, 15)
    records.append(summary(project, "cell_scale"))

    # Candidate-specific isotropic width. Instrumental and principal-phase
    # broadening are retained from the established model.
    hap["Size"][2][0] = True
    hap["Mustrain"][2][0] = True
    refine(project, 15)
    records.append(summary(project, "profile"))

    # Heavy-atom coordinates carry most of the X-ray information for WO3.
    for atom in minor.atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"
    refine(project, 18)
    records.append(summary(project, "heavy_atoms"))
    project.save()
    out.with_suffix(".summary.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
