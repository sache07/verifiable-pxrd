#!/usr/bin/env python3
"""Create a controlled branch from a multiphase GSAS-II refinement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def fit_stats(hist):
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    wt = np.asarray(hist.getdata("Yweight"), float)
    return {
        "rwp": float(100 * np.sqrt(np.sum(wt * (obs - calc) ** 2) / np.sum(wt * obs**2))),
        "rp": float(100 * np.sum(np.abs(obs - calc)) / np.sum(obs)),
        "chi2": float(np.sum(wt * (obs - calc) ** 2)),
        "n": int(obs.size),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--roughness", help="off or fixed A,B")
    ap.add_argument("--refine-roughness", action="store_true")
    ap.add_argument("--u-profile", type=float, help="fixed instrumental U")
    ap.add_argument("--refine-u-profile", action="store_true")
    ap.add_argument("--minor-strain", help="isotropic or uniaxial h,k,l")
    ap.add_argument("--minor-size", type=float)
    ap.add_argument("--fix-minor-size", action="store_true")
    ap.add_argument("--minor-atoms", choices=("none", "heavy", "all"))
    ap.add_argument("--minor-uiso", type=float)
    ap.add_argument("--background-coeffs", type=int)
    ap.add_argument("--cycles", type=int, default=20)
    ap.add_argument("--shift-factor", type=float)
    args = ap.parse_args()

    output = Path(args.out).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=args.input, newgpx=str(output))
    hist = project.histograms()[0]
    if len(project.phases()) < 2:
        raise ValueError("The input project must contain at least two phases")
    minor = project.phases()[1]
    hap = minor.data["Histograms"][hist.name]

    if args.roughness:
        if args.roughness == "off":
            a, b = 0.0, 0.0
        else:
            a, b = (float(v) for v in args.roughness.split(","))
        hist.SampleParameters["SurfRoughA"] = [a, args.refine_roughness]
        hist.SampleParameters["SurfRoughB"] = [b, args.refine_roughness]
    if args.u_profile is not None:
        hist.InstrumentParameters["U"][0:2] = [args.u_profile, args.u_profile]
        hist.InstrumentParameters["U"][2] = args.refine_u_profile
    if args.minor_strain:
        if args.minor_strain == "isotropic":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2] = [True, False, False]
        else:
            axis = [int(v) for v in args.minor_strain.split(",")]
            if len(axis) != 3 or not any(axis):
                raise ValueError("--minor-strain requires isotropic or h,k,l")
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
            hap["Mustrain"][2] = [True, True, False]
            hap["Mustrain"][3] = axis
    if args.minor_size is not None:
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = args.minor_size
        hap["Size"][2][0] = not args.fix_minor_size
    if args.minor_atoms is not None:
        for atom in minor.atoms():
            if args.minor_atoms == "all" or (
                args.minor_atoms == "heavy" and atom.element == "W"
            ):
                atom.refinement_flags = "X"
            else:
                atom.refinement_flags = " "
    if args.minor_uiso is not None:
        for atom in minor.atoms():
            atom.uiso = args.minor_uiso
    if args.background_coeffs is not None:
        n = args.background_coeffs
        if not 3 <= n <= 36:
            raise ValueError("--background-coeffs must be 3..36")
        old = int(hist.Background[0][2])
        if n > old:
            hist.Background[0].extend([0.0] * (n - old))
        elif n < old:
            del hist.Background[0][3 + n : 3 + old]
        hist.Background[0][2] = n
        hist.Background[0][1] = True

    project.set_Controls("cycles", args.cycles)
    if args.shift_factor is not None:
        project.data["Controls"]["data"]["shift factor"] = args.shift_factor
    project.refine()
    project.save()

    masses = []
    phases = []
    for phase in project.phases():
        phap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * phap["Scale"][0])
        masses.append(mass_scale)
        phases.append(
            {
                "name": phase.name,
                "mass_scale": mass_scale,
                "cell": phase.get_cell(),
                "size": phap["Size"][:4],
                "mustrain": phap["Mustrain"][:4],
                "atom_flags": {a.label: a.refinement_flags for a in phase.atoms()},
            }
        )
    total = sum(masses)
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / total
    result = {
        **fit_stats(hist),
        "roughness": {
            "A": hist.SampleParameters["SurfRoughA"],
            "B": hist.SampleParameters["SurfRoughB"],
        },
        "shift_um": hist.SampleParameters["Shift"],
        "instrument": {
            k: hist.InstrumentParameters[k]
            for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
        },
        "phases": phases,
    }
    output.with_suffix(".summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
