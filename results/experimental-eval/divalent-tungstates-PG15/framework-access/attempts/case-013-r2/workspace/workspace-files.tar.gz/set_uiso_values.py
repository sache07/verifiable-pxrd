#!/usr/bin/env python3
"""Set one fixed isotropic displacement value per phase and recalculate."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("values", help="comma-separated values in phase order")
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
values = [float(v) for v in args.values.split(",")]
shutil.copy2(args.source, args.output)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
hist = project.histograms()[0]
phases = project.phases()
if len(values) != len(phases):
    raise ValueError("one Uiso value is required per phase")

hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
project.data["Constraints"]["data"]["Phase"] = []
for phase, value in zip(phases, values):
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.set_refinements({"Atoms": {"all": ""}})
    cia = phase.data["General"]["AtomPtrs"][3]
    for atom in phase.data["Atoms"]:
        atom[cia] = "I"
        atom[cia + 1] = value

project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
project.refine()
project.save()
print(f"fixed_Uiso: Rwp={hist.get_wR():.6f} values={values}", flush=True)
