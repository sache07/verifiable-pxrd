#!/usr/bin/env python3
"""Refresh the common instrumental profile on a fixed phase model."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
shutil.copy2(args.source, args.output)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
hist = project.histograms()[0]
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.set_refinements({"Atoms": {"all": ""}})
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
project.index_ids()
controls = project.data["Controls"]["data"]
controls["parmFrozen"] = {"FrozenList": []}
controls["parmMinDict"] = {
    G2obj.G2VarObj(":0:U"): 0.0,
    G2obj.G2VarObj(":0:W"): 1.0,
    G2obj.G2VarObj(":0:X"): 0.05,
    G2obj.G2VarObj(":0:SH/L"): 0.001,
    G2obj.G2VarObj(":0:Polariz."): 0.0,
}
controls["parmMaxDict"] = {
    G2obj.G2VarObj(":0:U"): 50.0,
    G2obj.G2VarObj(":0:W"): 50.0,
    G2obj.G2VarObj(":0:X"): 8.0,
    G2obj.G2VarObj(":0:SH/L"): 0.2,
    G2obj.G2VarObj(":0:Polariz."): 1.0,
}
project.refine()
project.save()
print(
    f"instrument: Rwp={hist.get_wR():.6f} "
    + " ".join(f"{k}={hist.InstrumentParameters[k][1]:.7g}" for k in ("U", "W", "X", "SH/L", "Polariz.")),
    flush=True,
)
hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
project.refine()
project.save()
print(f"recalculated: Rwp={hist.get_wR():.6f}", flush=True)
