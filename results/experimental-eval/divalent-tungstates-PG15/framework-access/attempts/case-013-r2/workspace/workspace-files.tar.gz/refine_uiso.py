#!/usr/bin/env python3
"""Refine one shared isotropic displacement parameter per phase."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--cycles", type=int, default=15)
parser.add_argument("--minimum", type=float, default=0.003)
parser.add_argument("--maximum", type=float, default=0.020)
args = parser.parse_args()
shutil.copy2(args.source, args.output)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
hist = project.histograms()[0]
phases = project.phases()

hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
for phase in phases:
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.set_refinements({"Atoms": {"all": "U"}})

project.data["Constraints"]["data"]["Phase"] = []
project.index_ids()
controls = project.data["Controls"]["data"]
controls["parmFrozen"] = {"FrozenList": []}
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
for p, phase in enumerate(phases):
    variables = [f"{p}::AUiso:{i}" for i in range(len(phase.data["Atoms"]))]
    if len(variables) > 1:
        project.add_EquivConstr(variables, reloadIdx=False)
    for variable in variables:
        obj = G2obj.G2VarObj(variable)
        controls["parmMinDict"][obj] = args.minimum
        controls["parmMaxDict"][obj] = args.maximum

project.refine()
project.save()
print(f"Uiso: Rwp={hist.get_wR():.6f}", flush=True)
for p, phase in enumerate(phases):
    cia = phase.data["General"]["AtomPtrs"][3]
    values = [float(atom[cia + 1]) for atom in phase.data["Atoms"]]
    print(f"phase {p} {phase.name}: {values}", flush=True)

for phase in phases:
    phase.set_refinements({"Atoms": {"all": ""}})
project.refine()
project.save()
print(f"recalculated: Rwp={hist.get_wR():.6f}", flush=True)
