#!/usr/bin/env python3
"""Refit scales/background after setting one phase scale to zero."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("phase", type=int)
parser.add_argument("--cycles", type=int, default=12)
args = parser.parse_args()

shutil.copy2(args.source, args.output)
G2.SetPrintLevel("warn")
p = G2.G2Project(gpxfile=str(args.output))
p.set_Controls("cycles", args.cycles)
h = p.histogram(0)
phases = p.phases()
h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
h.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
for phase in phases:
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.set_refinements({"Atoms": {"all": ""}})
    phase.set_HAP_refinements({"Scale": True}, [h])
target = phases[args.phase]
target.data["Histograms"][h.name]["Scale"] = [0.0, False]
p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
p.refine()
p.save()
print(f"omitted={args.phase}:{target.name} Rwp={h.get_wR():.8f} chi={p.data['Covariance']['data']['Rvals']['chisq']:.8f}")
