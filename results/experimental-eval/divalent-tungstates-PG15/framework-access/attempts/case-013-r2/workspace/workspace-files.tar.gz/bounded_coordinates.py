#!/usr/bin/env python3
"""Refine selected atomic coordinates inside a small parent-model box."""

from __future__ import annotations

import argparse
import re
import shutil
from pathlib import Path

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("phase", type=int)
parser.add_argument("--elements", required=True, help="comma-separated element symbols")
parser.add_argument("--delta-frac", type=float, default=0.006)
parser.add_argument("--delta-A", type=float, help="axis-wise Cartesian bound; overrides --delta-frac")
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
wanted = {item.strip() for item in args.elements.split(",") if item.strip()}

shutil.copy2(args.source, args.output)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
hist = project.histograms()[0]
phases = project.phases()
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
for phase in phases:
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.set_refinements({"Atoms": {"all": ""}})

phase = phases[args.phase]
cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
project.index_ids()
controls = project.data["Controls"]["data"]
controls["parmFrozen"] = {"FrozenList": []}
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
selected = []
starts = {}
cell_lengths = list(map(float, phase.data["General"]["Cell"][1:4]))
for i, atom in enumerate(phase.data["Atoms"]):
    element = re.match(r"[A-Z][a-z]?", str(atom[ct])).group(0)
    if element not in wanted:
        continue
    atom[ct + 1] = "X"
    selected.append(i)
    starts[i] = list(map(float, atom[cx : cx + 3]))
    for axis, value, length in zip("xyz", starts[i], cell_lengths):
        delta = args.delta_A / length if args.delta_A is not None else args.delta_frac
        variable = G2obj.G2VarObj(f"{args.phase}::dA{axis}:{i}")
        controls["parmMinDict"][variable] = value - delta
        controls["parmMaxDict"][variable] = value + delta

if not selected:
    raise ValueError(f"no atoms of {wanted} found")
project.refine()
project.save()
print(f"coordinates: Rwp={hist.get_wR():.6f} selected={selected}", flush=True)
for i in selected:
    now = list(map(float, phase.data["Atoms"][i][cx : cx + 3]))
    delta = [b - a for a, b in zip(starts[i], now)]
    print(f"atom {i} start={starts[i]} delta={delta}", flush=True)

phase.set_refinements({"Atoms": {"all": ""}})
project.refine()
project.save()
print(f"recalculated: Rwp={hist.get_wR():.6f}", flush=True)
