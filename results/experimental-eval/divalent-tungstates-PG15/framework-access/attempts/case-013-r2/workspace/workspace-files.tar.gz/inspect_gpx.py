#!/usr/bin/env python3
"""Print/plot residual diagnostics for a GSAS-II project."""

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks


parser = argparse.ArgumentParser()
parser.add_argument("gpx", type=Path)
parser.add_argument("--out", type=Path)
args = parser.parse_args()
out = args.out or args.gpx.with_suffix("")

project = G2.G2Project(gpxfile=str(args.gpx))
hist = project.histogram(0)
x = np.asarray(hist.getdata("X"), float)
obs = np.asarray(hist.getdata("Yobs"), float)
calc = np.asarray(hist.getdata("Ycalc"), float)
bkg = np.asarray(hist.getdata("Background"), float)
diff = obs - calc
smooth = gaussian_filter1d(diff, 1.5)
peaks, props = find_peaks(smooth, prominence=30, height=30, distance=5)
order = np.argsort(smooth[peaks])[::-1]
print("largest positive residual peaks")
for j in order[:80]:
    i = peaks[j]
    print(f"{x[i]:10.5f} residual={smooth[i]:9.2f} obs={obs[i]:9.1f} calc={calc[i]:9.1f} prominence={props['prominences'][j]:9.2f}")

for name, values in (("two_theta", x), ("observed", obs), ("calculated", calc), ("difference", diff), ("background", bkg)):
    if not np.all(np.isfinite(values)):
        raise RuntimeError(f"nonfinite {name}")
np.savetxt(str(out) + "_fit.csv", np.column_stack((x, obs, calc, diff, bkg)), delimiter=",", header="two_theta,observed,calculated,difference,background", comments="")

try:
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(3, 1, figsize=(16, 10), sharey=False)
    for ax, lo, hi in zip(axes, (10, 40, 70), (40, 70, 100)):
        use = (x >= lo) & (x <= hi)
        ax.plot(x[use], obs[use], color="black", lw=0.6, label="observed")
        ax.plot(x[use], calc[use], color="tab:red", lw=0.7, label="calculated")
        ax.plot(x[use], diff[use], color="tab:blue", lw=0.5, label="difference")
        ax.set_xlim(lo, hi)
        ax.set_ylabel("counts")
    axes[0].legend(ncol=3)
    axes[-1].set_xlabel(r"$2\theta$ (degrees)")
    fig.tight_layout()
    fig.savefig(str(out) + "_fit.png", dpi=180)
except ImportError:
    pass
