#!/usr/bin/env python3
"""Test allowed March-Dollase axes for one phase from a common project."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])

parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("outdir", type=Path)
parser.add_argument("phase", type=int)
parser.add_argument("--cycles", type=int, default=10)
args = parser.parse_args()
args.outdir.mkdir(parents=True, exist_ok=True)
G2.SetPrintLevel("warn")

for axis in AXES:
    label = "".join(str(v) for v in axis)
    destination = args.outdir / f"phase{args.phase}_axis{label}.gpx"
    shutil.copy2(args.source, destination)
    project = G2.G2Project(gpxfile=str(destination))
    project.set_Controls("cycles", args.cycles)
    hist = project.histograms()[0]
    phases = project.phases()
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
    )
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_refinements({"Atoms": {"all": ""}})
    hap = phases[args.phase].data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    project.index_ids()
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {G2obj.G2VarObj(f"{args.phase}:0:MD"): 0.4}
    controls["parmMaxDict"] = {G2obj.G2VarObj(f"{args.phase}:0:MD"): 2.5}
    project.refine()
    project.save()
    print(
        f"axis={axis} Rwp={hist.get_wR():.6f} MD={hap['Pref.Ori.'][1]:.7f}",
        flush=True,
    )
