#!/usr/bin/env python3
"""Print a compact numerical audit of a saved GSAS-II powder project."""

from __future__ import annotations

import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, dict):
        return {str(key): plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


parser = argparse.ArgumentParser()
parser.add_argument("project")
args = parser.parse_args()

p = G2.G2Project(gpxfile=args.project)
h = p.histogram(0)
x = np.asarray(h.getdata("X"), float)
obs = np.asarray(h.getdata("Yobs"), float)
calc = np.asarray(h.getdata("Ycalc"), float)
bkg = np.asarray(h.getdata("Background"), float)
w = 1.0 / np.maximum(obs, 1.0)
loss = float(np.sum(w * (obs - calc) ** 2))
den = float(np.sum(w * obs**2))

rows = []
masses = []
for ph in p.phases():
    gen = ph.data["General"]
    hap = ph.data["Histograms"][h.name]
    cx, ct, cs, cia = gen["AtomPtrs"]
    masses.append(float(hap["Scale"][0]) * float(gen["Mass"]))
    rows.append(
        {
            "name": ph.name,
            "cell": list(map(float, gen["Cell"][1:8])),
            "space_group": gen["SGData"]["SpGrp"],
            "scale": float(hap["Scale"][0]),
            "mass": float(gen["Mass"]),
            "size": hap["Size"][:4],
            "mustrain": hap["Mustrain"][:4],
            "pref_ori": hap["Pref.Ori."][:4],
            "uiso": [float(a[cia + 1]) for a in ph.data["Atoms"]],
            "atom_count": len(ph.data["Atoms"]),
        }
    )
for row, mass in zip(rows, masses):
    row["weight_fraction"] = mass / sum(masses)

cov = p.data.get("Covariance", {}).get("data", {})
out = {
    "filename": p.filename,
    "histogram": h.name,
    "points": len(x),
    "limits": h.data.get("Limits"),
    "residuals": h.residuals,
    "independent_rwp_percent_saved_curve": 100.0 * np.sqrt(loss / den),
    "chi_square_saved_curve": loss,
    "background_min_max": [float(np.min(bkg)), float(np.max(bkg))],
    "ycalc_min_max": [float(np.min(calc)), float(np.max(calc))],
    "instrument": {k: v for k, v in h.InstrumentParameters.items()},
    "sample": h.SampleParameters,
    "covariance_rvals": cov.get("Rvals"),
    "vary_list": cov.get("varyList"),
    "phases": rows,
    "controls": p.data.get("Controls", {}).get("data", {}),
}
print(json.dumps(plain(out), indent=2))
