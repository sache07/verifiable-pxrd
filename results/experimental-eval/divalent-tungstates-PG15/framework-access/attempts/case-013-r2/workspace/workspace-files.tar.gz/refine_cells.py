#!/usr/bin/env python3
"""Refresh unit cells one phase at a time after profile stabilization."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
shutil.copy2(args.source, args.output)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
hist = project.histograms()[0]
phases = project.phases()
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
for phase in phases:
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.set_refinements({"Atoms": {"all": ""}})
project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}

for i, phase in enumerate(phases):
    phase.set_refinements({"Cell": True})
    project.refine()
    project.save()
    print(
        f"phase {i} {phase.name}: Rwp={hist.get_wR():.6f} "
        f"cell={phase.data['General']['Cell'][1:8]}",
        flush=True,
    )
    phase.clear_refinements({"Cell": True})
    shutil.copy2(args.output, args.output.with_name(f"{args.output.stem}_phase{i}{args.output.suffix}"))

project.refine()
project.save()
print(f"recalculated: Rwp={hist.get_wR():.6f}", flush=True)
