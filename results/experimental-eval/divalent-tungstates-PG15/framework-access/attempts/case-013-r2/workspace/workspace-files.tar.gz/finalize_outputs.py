#!/usr/bin/env python3
"""Freeze the selected GSAS-II refinement and export all requested artifacts."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PHASE_INFO = [
    {
        "name": "scheelite PbWO4",
        "formula": "PbWO4",
        "cif": "phase_1_PbWO4_scheelite.cif",
        "model": "COD 9009811; I41/a",
        "confidence": "high",
    },
    {
        "name": "monoclinic WO3",
        "formula": "WO3",
        "cif": "phase_2_WO3_monoclinic.cif",
        "model": "COD 2311041; P21/c",
        "confidence": "high",
    },
    {
        "name": "massicot beta-PbO",
        "formula": "PbO",
        "cif": "phase_3_PbO_massicot.cif",
        "model": "COD 2310433; Pbcm",
        "confidence": "high",
    },
    {
        "name": "long-period alpha-PbO approximant",
        "formula": "PbO",
        "cif": "phase_4_PbO_alpha_modulated.cif",
        "model": "COD 1533609; Pbma long-period approximant",
        "confidence": "moderate",
    },
    {
        "name": "Pb2WO5 intermediate",
        "formula": "Pb2WO5",
        "cif": "phase_5_Pb2WO5.cif",
        "model": "C2/m Pb2MoO5 analogue (COD 7220560), Mo replaced by W",
        "confidence": "moderate; analogue-derived atomic model",
    },
    {
        "name": "monoclinic Pb2O3-like phase",
        "formula": "Pb2O3",
        "cif": "phase_6_Pb2O3_tentative.cif",
        "model": "COD 2311012; P21/c",
        "confidence": "tentative",
    },
    {
        "name": "minium Pb3O4",
        "formula": "Pb3O4",
        "cif": "phase_7_Pb3O4_minor.cif",
        "model": "COD 1537983; P42/mbc",
        "confidence": "tentative minor phase",
    },
]


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("--workspace", type=Path, default=Path("."))
args = parser.parse_args()
root = args.workspace.resolve()
final_gpx = root / "final.gpx"
shutil.copy2(args.source.resolve(), final_gpx)

project = G2.G2Project(gpxfile=str(final_gpx))
histograms = project.histograms()
phases = project.phases()
if len(histograms) != 1 or len(phases) != len(PHASE_INFO):
    raise RuntimeError("selected project does not contain the expected one histogram and seven phases")
hist = histograms[0]

x = np.asarray(hist.getdata("X"), float)
observed = np.asarray(hist.getdata("Yobs"), float)
calculated = np.asarray(hist.getdata("Ycalc"), float)
difference = observed - calculated
if not all(np.all(np.isfinite(a)) for a in (x, observed, calculated, difference)):
    raise RuntimeError("nonfinite final profile")
if np.any(calculated < 0):
    raise RuntimeError("negative calculated counts")
np.savetxt(
    root / "fit.csv",
    np.column_stack((x, observed, calculated, difference)),
    delimiter=",",
    header="two_theta,observed,calculated,difference",
    comments="",
    fmt=["%.10f", "%.10f", "%.10f", "%.10f"],
)

masses = []
for phase in phases:
    hap = phase.data["Histograms"][hist.name]
    masses.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
total_mass = float(sum(masses))
if total_mass <= 0:
    raise RuntimeError("nonpositive modeled crystalline mass")
fractions = [mass / total_mass for mass in masses]

weights = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weights * difference**2))
denominator = float(np.sum(weights * observed**2))
rwp = float(100.0 * np.sqrt(chi_square / denominator))
rp = float(hist.residuals["R"])
rexp = float(hist.residuals["wRmin"])
cov_rvals = project.data["Covariance"]["data"].get("Rvals", {})
nobs = int(cov_rvals.get("Nobs", len(x)))
nvars = int(cov_rvals.get("Nvars", 0))
reduced_chi_square = float(chi_square / max(nobs - nvars, 1))
gof = float(np.sqrt(reduced_chi_square))

# Export the saved atom arrays without allowing stale covariance values to alter
# printed digits or append obsolete uncertainties.
project.data["Covariance"]["data"] = {}
for phase, info in zip(phases, PHASE_INFO):
    phase.export_CIF(str(root / info["cif"]), quickmode=True)

phase_rows = []
for info, fraction in zip(PHASE_INFO, fractions):
    phase_rows.append(
        {
            "name": info["name"],
            "formula": info["formula"],
            "cif_path": info["cif"],
            "weight_fraction": fraction,
            "identification_confidence": info["confidence"],
        }
    )

result = {
    "phases": phase_rows,
    "weight_fraction_basis": "normalized over the seven modeled crystalline phases; no amorphous fraction determined",
    "fit_statistics": {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "r_expected_percent": rexp,
        "chi_square": chi_square,
        "reduced_chi_square": reduced_chi_square,
        "goodness_of_fit": gof,
        "observations": nobs,
        "refined_variables_in_final_scale_background_cycle": nvars,
    },
    "refinement_histogram": hist.name,
    "profile_file": "fit.csv",
    "gsas_project": "final.gpx",
}
(root / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

table_rows = []
for info, fraction in zip(PHASE_INFO, fractions):
    table_rows.append(
        f"| {info['name']} | {100*fraction:.2f} | {info['model']} | {info['confidence']} |"
    )

report = f"""# Powder XRD phase analysis

The pattern is best represented by seven crystalline components. Weight fractions below are normalized over those modeled crystalline phases; the data do not determine an amorphous fraction or absolute crystalline yield.

| Phase | wt.% | Structural model | Assessment |
|---|---:|---|---|
{chr(10).join(table_rows)}

## Evidence and refinement

The GSAS-II fit uses the complete 10.009–99.994° 2theta scan, the reported Cu Kalpha1/Kalpha2 wavelengths and 0.5 doublet ratio, and counting-statistical weights of `1/max(I,1)`. Refined unit cells, bounded atomic-coordinate adjustments, phase scales, phase-specific size/strain, selected March-Dollase terms, a smooth background, and the common instrumental profile are stored in `final.gpx`. The independently computed profile statistics are Rwp = {rwp:.3f}%, Rp = {rp:.3f}%, Rexp = {rexp:.3f}%, and goodness of fit = {gof:.3f} (chi-square = {chi_square:.1f}; {nobs} points).

Scheelite PbWO4 accounts for the dominant 27–33° and corresponding high-angle reflection families. Monoclinic WO3 is required by its split low-angle 23–24° family and numerous higher-angle lines. The two PbO models are independently supported: massicot accounts for its orthorhombic 29–33° family, while the long-period alpha-PbO approximant supplies additional broadened/superstructure intensity that simple litharge does not. The C2/m Pb2WO5 model accounts for distinct intensity near 25.9°, 29–31°, 43°, and 47°. Pb2O3-like and Pb3O4 models account for weaker remaining peak families; omitting any of the first six phases raised Rwp to 10–36%, while omitting Pb3O4 raised it to about 8.46%. PbO2, Pb7W8O28.8, raspite/WO2-type alternatives, and tested Pb3WO6 analogues refined to negligible scale or gave inferior fits.

## Remaining uncertainty

The Pb2WO5 CIF is an analogue-derived Pb2MoO5 framework with Mo replaced by W because no direct Pb2WO5 reference was available; its phase family and approximate amount are supported, but its detailed oxygen coordinates are not uniquely determined. The monoclinic Pb2O3-like component required a comparatively large cell adjustment and strong anisotropic broadening, so the exact structure and its {100*fractions[5]:.1f} wt.% fraction cannot be considered reliable independently of this model. Minor Pb3O4 ({100*fractions[6]:.1f} wt.%) is also strongly overlapped and model-dependent. Geometry screening flags short O-O contacts in the published Pb2O3 and Pb3O4 model families (about 1.72 and 1.80 A after refinement), reinforcing that those CIFs are tentative profile models rather than definitive local structures. The split between the two PbO forms and the Pb2WO5/Pb2O3-like components is correlated; realistic systematic fraction uncertainty is several percentage points for those phases and exceeds the least-squares standard errors. Structured residuals remain (Rwp well above Rexp), so these tentative assignments should not be treated as unique structure solutions.
"""
(root / "report.md").write_text(report)

print(f"wrote final.gpx, fit.csv, result.json, report.md and {len(PHASE_INFO)} CIFs")
print(f"Rwp={rwp:.8f} Rp={rp:.8f} GOF={gof:.8f} fraction_sum={sum(fractions):.12f}")
