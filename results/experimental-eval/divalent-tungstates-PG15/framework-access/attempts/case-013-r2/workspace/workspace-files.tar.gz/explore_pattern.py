#!/usr/bin/env python3
"""Small peak-picking/plotting helper for the supplied raw pattern."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.signal import find_peaks, peak_widths


data = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
x = data["two_theta_deg"]
y = data["intensity"]
step = float(np.median(np.diff(x)))

# A broad percentile baseline is robust to the dense overlapping peak groups.
baseline = percentile_filter(y, percentile=20, size=501, mode="nearest")
signal = gaussian_filter1d(y - baseline, 1.2)
peaks, props = find_peaks(signal, prominence=35, height=45, distance=5)
width_samples = peak_widths(signal, peaks, rel_height=0.5)[0]

order = np.argsort(signal[peaks])[::-1]
print(f"points={len(x)} step={step:.8f} intensity=[{y.min():.0f},{y.max():.0f}]")
print("rank two_theta intensity net_height prominence fwhm_deg")
for rank, j in enumerate(order[:100], 1):
    i = peaks[j]
    print(
        f"{rank:3d} {x[i]:11.5f} {y[i]:9.1f} {signal[i]:10.1f} "
        f"{props['prominences'][j]:10.1f} {width_samples[j] * step:9.4f}"
    )

fig, ax = plt.subplots(figsize=(15, 6))
ax.plot(x, y, lw=0.55, color="black")
ax.plot(x, baseline, lw=0.8, color="tab:orange")
ax.set(xlabel=r"$2\theta$ (deg, Cu K$\alpha$)", ylabel="Counts", xlim=(x.min(), x.max()))
fig.tight_layout()
fig.savefig("pattern_overview.png", dpi=180)

fig, axes = plt.subplots(3, 1, figsize=(15, 9))
for ax, lo, hi in zip(axes, (10, 40, 70), (40, 70, 100)):
    use = (x >= lo) & (x <= hi)
    ax.plot(x[use], y[use], lw=0.65, color="black")
    ax.set_xlim(lo, hi)
    ax.set_ylabel("Counts")
axes[-1].set_xlabel(r"$2\theta$ (deg, Cu K$\alpha$)")
fig.tight_layout()
fig.savefig("pattern_segments.png", dpi=180)
