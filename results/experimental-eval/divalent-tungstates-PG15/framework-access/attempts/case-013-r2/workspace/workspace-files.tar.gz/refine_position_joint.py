#!/usr/bin/env python3
"""Jointly refine common angular position terms and all phase unit cells."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--zero", type=float, default=0.20)
parser.add_argument("--shift", type=float, default=-200.0)
parser.add_argument("--cycles", type=int, default=20)
args = parser.parse_args()

shutil.copy2(args.source, args.output)
G2.SetPrintLevel("warn")
p = G2.G2Project(gpxfile=str(args.output))
p.set_Controls("cycles", args.cycles)
h = p.histogram(0)
phases = p.phases()

h.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
h.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
h.InstrumentParameters["Zero"][1] = args.zero
h.SampleParameters["Shift"][0] = args.shift
h.set_refinements({"Instrument Parameters": ["Zero"]})
h.set_refinements({"Sample Parameters": ["Shift"]})
for phase in phases:
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.set_refinements({"Atoms": {"all": ""}})
    phase.set_refinements({"Cell": True})

p.index_ids()
controls = p.data["Controls"]["data"]
controls["parmFrozen"] = {"FrozenList": []}
controls["parmMinDict"] = {
    G2obj.G2VarObj(":0:Zero"): -0.25,
    G2obj.G2VarObj(":0:Shift"): -800.0,
}
controls["parmMaxDict"] = {
    G2obj.G2VarObj(":0:Zero"): 0.25,
    G2obj.G2VarObj(":0:Shift"): 800.0,
}

p.refine()
p.save()
print(
    f"joint: Rwp={h.get_wR():.7f} Zero={h.InstrumentParameters['Zero'][1]:.8f} "
    f"Shift={h.SampleParameters['Shift'][0]:.5f}",
    flush=True,
)
for i, phase in enumerate(phases):
    print(i, phase.name, phase.data["General"]["Cell"][1:8], flush=True)

h.clear_refinements({"Instrument Parameters": ["Zero"]})
h.clear_refinements({"Sample Parameters": ["Shift"]})
for phase in phases:
    phase.clear_refinements({"Cell": True})
p.refine()
p.save()
print(f"recalculated: Rwp={h.get_wR():.7f}", flush=True)
