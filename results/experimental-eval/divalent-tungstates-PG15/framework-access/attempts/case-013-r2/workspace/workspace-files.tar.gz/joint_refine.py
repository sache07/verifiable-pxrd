#!/usr/bin/env python3
"""Apply selected textures and a stable physical profile to the seven-phase model."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--pb2o3-axis", choices=("110", "111"), required=True)
parser.add_argument("--cycles", type=int, default=12)
args = parser.parse_args()

args.output.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(args.source, args.output)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
hist = project.histograms()[0]
phases = project.phases()

hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
for phase in phases:
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.set_refinements({"Atoms": {"all": ""}})


def texture(index: int, axis: list[int], ratio: float, refine: bool) -> None:
    hap = phases[index].data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = ratio
    hap["Pref.Ori."][2] = refine
    hap["Pref.Ori."][3] = axis


# Independent axis screens. Boundary terms are held at the physically allowed
# edge; the two interior ratios are allowed to readjust jointly.
texture(1, [1, 1, 0], 1.2288, True)
texture(3, [1, 1, 1], 0.7000, False)
texture(4, [1, 0, 0], 1.1393, True)
if args.pb2o3_axis == "110":
    texture(5, [1, 1, 0], 1.4000, False)
else:
    texture(5, [1, 1, 1], 0.7000, False)
texture(6, [0, 0, 1], 0.7000, False)

# Values from bounded one-at-a-time width refinements. Keeping the highly
# correlated size/strain pairs fixed makes the forward profile reproducible.
sizes = [0.21325, 0.13740, 0.25994, 0.03048, 1.13233, 1.5, 1.5]
strains = [156.9, 0.0, 2600.6, 85.5, 1965.5, 10000.0, 10000.0]
for phase, size, strain in zip(phases, sizes, strains):
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = size
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = strain
    hap["Mustrain"][1][1] = strain
    hap["Mustrain"][2] = [False, False, False]

for key, value in {"U": 7.75, "W": 23.13, "X": 5.715, "SH/L": 0.03702, "Polariz.": 0.8531}.items():
    hist.InstrumentParameters[key][1] = value

project.index_ids()
controls = project.data["Controls"]["data"]
controls["parmFrozen"] = {"FrozenList": []}
controls["parmMinDict"] = {
    G2obj.G2VarObj(":0:U"): 0.0,
    G2obj.G2VarObj(":0:W"): 1.0,
    G2obj.G2VarObj(":0:X"): 0.05,
    G2obj.G2VarObj("1:0:MD"): 0.7,
    G2obj.G2VarObj("4:0:MD"): 0.7,
}
controls["parmMaxDict"] = {
    G2obj.G2VarObj(":0:U"): 50.0,
    G2obj.G2VarObj(":0:W"): 50.0,
    G2obj.G2VarObj(":0:X"): 8.0,
    G2obj.G2VarObj("1:0:MD"): 1.4,
    G2obj.G2VarObj("4:0:MD"): 1.4,
}

project.refine()
project.save()
print(f"textures/fixed profile: Rwp={hist.get_wR():.6f}", flush=True)

hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
project.refine()
project.save()
print(
    f"instrument: Rwp={hist.get_wR():.6f} "
    f"U={hist.InstrumentParameters['U'][1]:.5g} W={hist.InstrumentParameters['W'][1]:.5g} "
    f"X={hist.InstrumentParameters['X'][1]:.5g}",
    flush=True,
)

# Freeze the instrument profile for a final exact recalculation. This also
# ensures any limit handling cannot leave stale calculated intensities.
hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
project.refine()
project.save()
print(f"final_recalculated: Rwp={hist.get_wR():.6f}", flush=True)
for i in (1, 3, 4, 5, 6):
    pref = phases[i].data["Histograms"][hist.name]["Pref.Ori."]
    print(f"phase {i} MD={pref[1]:.7f} axis={pref[3]}", flush=True)
