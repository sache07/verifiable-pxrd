#!/usr/bin/env python3
"""Continue a candidate refinement with bounded specimen broadening."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2


def summarize(project, hist, stage: str) -> None:
    print(f"{stage}: Rwp={hist.get_wR():.6f}")
    print(
        "  instrument",
        {k: round(float(hist.InstrumentParameters[k][1]), 6) for k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")},
    )
    for i, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        print(
            f"  {i} {phase.name}: scale={hap['Scale'][0]:.7g} "
            f"size={hap['Size'][1][:3]} mustrain={hap['Mustrain'][1][:3]}"
        )


def checkpoint(project, hist, out: Path, stage: str) -> None:
    project.save()
    shutil.copy2(out, out.with_name(f"{out.stem}_{stage}{out.suffix}"))
    summarize(project, hist, stage)


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--cycles", type=int, default=12)
parser.add_argument("--atomic", action="store_true")
args = parser.parse_args()

args.output.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(args.source, args.output)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
hist = project.histograms()[0]
phases = project.phases()
project.set_Controls("cycles", args.cycles)

# Remove the highly correlated simultaneous zero/specimen shift refinement and
# keep the already established peak-position solution while widths are fitted.
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
for phase in phases:
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True})

# Start from a physical common profile. Sample broadening absorbs the width
# previously forced into X when all phases were held at the same width.
hist.InstrumentParameters["U"][1] = max(0.2, float(hist.InstrumentParameters["U"][1]))
hist.InstrumentParameters["X"][1] = min(6.0, float(hist.InstrumentParameters["X"][1]))
controls = project.data["Controls"]["data"]
project.index_ids()
controls["parmMinDict"] = {
    G2obj.G2VarObj(":0:U"): 0.0,
    G2obj.G2VarObj(":0:W"): 1.0,
    G2obj.G2VarObj(":0:X"): 0.05,
}
controls["parmMaxDict"] = {
    G2obj.G2VarObj(":0:U"): 50.0,
    G2obj.G2VarObj(":0:W"): 50.0,
    G2obj.G2VarObj(":0:X"): 8.0,
}
for i in range(len(phases)):
    controls["parmMinDict"][G2obj.G2VarObj(f"{i}:0:Size;i")] = 0.02
    controls["parmMinDict"][G2obj.G2VarObj(f"{i}:0:Mustrain;i")] = 0.0
    controls["parmMaxDict"][G2obj.G2VarObj(f"{i}:0:Size;i")] = 2.0
    controls["parmMaxDict"][G2obj.G2VarObj(f"{i}:0:Mustrain;i")] = 10000.0

for phase in phases:
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
project.refine()
checkpoint(project, hist, args.output, "sizes")

for phase in phases:
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
project.refine()
checkpoint(project, hist, args.output, "sizes_strain")

# Hold phase widths while re-establishing the common instrumental floor.
for phase in phases:
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
project.refine()
checkpoint(project, hist, args.output, "instrument")

# One joint pass from the stabilized solution resolves the remaining common vs.
# phase-specific width allocation.
for phase in phases:
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
project.refine()
checkpoint(project, hist, args.output, "joint_profile")

if args.atomic:
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in phases:
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        phase.set_refinements({"Atoms": {"all": "X"}})
    project.refine()
    checkpoint(project, hist, args.output, "coordinates")

project.save()
summarize(project, hist, "final")
