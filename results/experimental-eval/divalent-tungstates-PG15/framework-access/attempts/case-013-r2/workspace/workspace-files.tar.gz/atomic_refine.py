#!/usr/bin/env python3
"""Refine symmetry-allowed coordinates one phase at a time."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--cycles", type=int, default=12)
args = parser.parse_args()

args.output.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(args.source, args.output)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
hist = project.histograms()[0]
phases = project.phases()
project.set_Controls("cycles", args.cycles)

hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
for phase in phases:
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.set_refinements({"Atoms": {"all": ""}})

for i, phase in enumerate(phases):
    phase.set_refinements({"Atoms": {"all": "X"}})
    project.refine()
    project.save()
    print(f"phase {i} {phase.name}: Rwp={hist.get_wR():.6f}", flush=True)
    shutil.copy2(args.output, args.output.with_name(f"{args.output.stem}_phase{i}{args.output.suffix}"))
    phase.set_refinements({"Atoms": {"all": ""}})

project.save()
print(f"final: Rwp={hist.get_wR():.6f}", flush=True)
