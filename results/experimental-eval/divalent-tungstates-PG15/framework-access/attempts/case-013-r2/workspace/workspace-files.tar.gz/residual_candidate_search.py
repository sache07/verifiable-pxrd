#!/usr/bin/env python3
"""Rank chemically allowed COD phases against a GSAS residual profile."""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
INDEX = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/"
    "site-packages/dara/data/cod_filtered_info_2024.json.gz"
)


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


parser = argparse.ArgumentParser()
parser.add_argument("fit_csv", type=Path)
parser.add_argument("--omit", nargs="*", default=[])
args = parser.parse_args()

data = np.genfromtxt(args.fit_csv, delimiter=",", names=True)
x = data["two_theta"]
obs = data["observed"]
residual = data["difference"]
step = float(np.median(np.diff(x)))
weight = 1.0 / np.maximum(obs, 1.0)
base_chi = float(np.dot(weight, residual * residual))

with gzip.open(INDEX, "rt") as handle:
    index = json.load(handle)
records = []
for key in ("O-Pb-W", "O-Pb", "O-W"):
    records.extend((key, *record) for record in index.get(key, []))

calc = XRDCalculator(wavelength=1.540598, symprec=0)
results = []
for key, formula, cod_id, sg, rvalue in records:
    if cod_id in args.omit:
        continue
    try:
        structure = CifParser(str(cif_path(cod_id)), occupancy_tolerance=2).parse_structures(primitive=False)[0]
        pattern = calc.get_pattern(structure, two_theta_range=(9.0, 101.0), scaled=False)
    except Exception as exc:
        print(f"FAIL {cod_id} {formula}: {type(exc).__name__}: {exc}")
        continue
    pos0 = np.asarray(pattern.x, float)
    inten = np.asarray(pattern.y, float)
    best = (-np.inf, None)
    for cell_scale in np.linspace(0.97, 1.03, 25):
        arg = np.sin(np.deg2rad(pos0 / 2.0)) / cell_scale
        use_arg = np.abs(arg) < 1
        shifted0 = np.rad2deg(2 * np.arcsin(arg[use_arg]))
        ii = inten[use_arg]
        for offset in np.linspace(-0.1, 0.55, 14):
            pos = shifted0 + offset
            inds = np.rint((pos - x[0]) / step).astype(int)
            use = (inds >= 0) & (inds < len(x))
            sticks = np.zeros_like(x)
            np.add.at(sticks, inds[use], ii[use])
            for fwhm in (0.16, 0.24, 0.36, 0.55):
                sigma_points = fwhm / 2.35482 / step
                prof = gaussian_filter1d(sticks, sigma_points)
                denom = float(np.dot(weight, prof * prof))
                if denom <= 0:
                    continue
                coef = max(0.0, float(np.dot(weight, prof * residual)) / denom)
                new_chi = float(np.dot(weight, (residual - coef * prof) ** 2))
                improvement = base_chi - new_chi
                if improvement > best[0]:
                    best = (improvement, (cell_scale, offset, fwhm, coef, new_chi))
    results.append((best[0], key, cod_id, formula, sg, best[1]))

print(f"base_chi_square={base_chi:.6g}")
print("delta_chi key id formula sg cell_scale offset_deg fwhm_deg coefficient residual_chi")
for improvement, key, cod_id, formula, sg, params in sorted(results, reverse=True):
    cell_scale, offset, fwhm, coef, new_chi = params
    print(
        f"{improvement:12.3f} {key:7s} {cod_id} {formula:18s} {sg:3d} "
        f"{cell_scale:.5f} {offset:+.3f} {fwhm:.3f} {coef:.5g} {new_chi:.3f}"
    )
