#!/usr/bin/env python3
"""Compare chemically plausible frozen-COD structures with observed peaks."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.optimize import nnls


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
INDEX = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/"
    "site-packages/dara/data/cod_filtered_info_2024.json.gz"
)


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


raw = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
x = raw["two_theta_deg"]
y = raw["intensity"]
step = np.median(np.diff(x))
base = percentile_filter(y, percentile=15, size=401, mode="nearest")
ynet = np.maximum(y - base, 0.0)

with gzip.open(INDEX, "rt") as handle:
    index = json.load(handle)

records = []
for key in ("O-Pb-W", "O-Pb", "O-W"):
    records.extend((key, *record) for record in index.get(key, []))

calc = XRDCalculator(wavelength=1.540598, symprec=0)
print("candidate comparison: single-CIF approximate profile NNLS against baseline-subtracted data")
print("key id formula sg score scale_shift top peaks (2theta:intensity)")
for key, formula, cod_id, sg, rvalue in records:
    path = cif_path(cod_id)
    try:
        structure = CifParser(str(path), occupancy_tolerance=2).parse_structures(primitive=False)[0]
        pattern = calc.get_pattern(structure, two_theta_range=(9.5, 100.5), scaled=True)
    except Exception as exc:
        print(f"FAIL {key} {cod_id} {formula} SG{sg}: {type(exc).__name__}: {exc}")
        continue

    best = (np.inf, None, None)
    # Approximate broadening, cell mismatch and angular offset. This is for triage only.
    for stretch in np.linspace(0.992, 1.008, 33):
        for offset in np.linspace(-0.35, 0.35, 29):
            sticks = np.zeros_like(x)
            pos = np.asarray(pattern.x) * stretch + offset
            inten = np.asarray(pattern.y)
            inds = np.rint((pos - x[0]) / step).astype(int)
            use = (inds >= 0) & (inds < len(x))
            np.add.at(sticks, inds[use], inten[use])
            prof = gaussian_filter1d(sticks, 9.0)
            design = np.column_stack((prof, np.ones_like(x)))
            coef, _ = nnls(design, ynet)
            resid = ynet - design @ coef
            score = np.mean(resid * resid) / max(np.mean(ynet * ynet), 1.0)
            if score < best[0]:
                best = (score, stretch, offset)
    top = np.argsort(pattern.y)[::-1][:12]
    peaks = " ".join(f"{pattern.x[i]:.2f}:{pattern.y[i]:.0f}" for i in top)
    print(
        f"{key:7s} {cod_id} {formula:18s} {sg:3d} {best[0]:.4f} "
        f"{best[1]:.5f}/{best[2]:+.3f} {peaks}"
    )
