#!/usr/bin/env python3
"""Build and refine a candidate multiphase GSAS-II model.

Run with the GSAS-II Python environment. This is intentionally conservative:
the early stages establish scale/background/position before profile and atomic
parameters are introduced.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
NAMES = {
    "9009811": "PbWO4_scheelite",
    "1527935": "PbWO4_scheelite_old",
    "9016035": "Pb7W8O28p8",
    "9007617": "PbWO4_raspite",
    "2311041": "WO3_monoclinic_2311041",
    "1528915": "WO3_monoclinic_1528915",
    "2106293": "WO3_triclinic_2106293",
    "1010618": "WO3_1010618",
    "1563541": "WO3_monoclinic_1563541",
    "9012700": "PbO_litharge",
    "2310433": "PbO_massicot",
}


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inputs(root: Path) -> tuple[Path, Path]:
    raw = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
    x = raw["two_theta_deg"]
    y = raw["intensity"]
    datafile = root / "observed.xye"
    # The third column is sigma, so the least-squares weights are 1/max(y,1).
    np.savetxt(datafile, np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.10g")
    inst = root / "instrument.instprm"
    inst.write_text(
        "#GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.25;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return datafile, inst


def mass_fractions(project: G2.G2Project, hist) -> dict[str, float]:
    values = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        values.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
    total = sum(values)
    return {p.name: v / total for p, v in zip(project.phases(), values)} if total > 0 else {}


def report(project: G2.G2Project, hist, label: str) -> None:
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    vals = {
        "stage": label,
        "residuals": hist.residuals,
        "fractions": mass_fractions(project, hist),
        "instrument": {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.") if k in inst},
        "sample": {k: sample[k][0] if isinstance(sample.get(k), list) else sample.get(k) for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Scale")},
        "cells": {p.name: p.data["General"]["Cell"][1:8] for p in project.phases()},
        "hap": {
            p.name: {
                "scale": p.data["Histograms"][hist.name]["Scale"][0],
                "size": p.data["Histograms"][hist.name]["Size"][:4],
                "mustrain": p.data["Histograms"][hist.name]["Mustrain"][:4],
                "pref_ori": p.data["Histograms"][hist.name]["Pref.Ori."][:4],
            }
            for p in project.phases()
        },
    }
    print(json.dumps(vals, indent=2, default=lambda o: np.asarray(o).tolist()), flush=True)


def refine(project: G2.G2Project, hist, label: str) -> None:
    print(f"\n===== {label} =====", flush=True)
    project.refine()
    project.save()
    checkpoint = Path(project.filename).with_name(
        "candidate_" + "_".join(label.lower().replace("/", " ").split()) + ".gpx"
    )
    shutil.copy2(project.filename, checkpoint)
    report(project, hist, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--ids", nargs="+", required=True)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--atomic", action="store_true")
    args = parser.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    datafile, instfile = write_inputs(args.out)
    gpxfile = args.out / "candidate.gpx"
    if gpxfile.exists():
        gpxfile.unlink()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(gpxfile))
    hist = project.add_powder_histogram(str(datafile), str(instfile), fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]

    raw = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
    xx = raw["two_theta_deg"]
    yy = raw["intensity"]
    # Initialize a 12-term smooth background from a broad lower-envelope fit.
    from scipy.ndimage import percentile_filter

    envelope = percentile_filter(yy, percentile=15, size=401, mode="nearest")
    t = 2 * (xx - xx[0]) / (xx[-1] - xx[0]) - 1
    coeff = np.polynomial.chebyshev.chebfit(t, envelope, 11).tolist()
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": len(coeff), "coeffs": coeff, "refine": False}}
    )

    phases = []
    for cod_id in args.ids:
        supplied = Path(cod_id)
        source = supplied if supplied.is_file() else cif_path(cod_id)
        if not source.is_file():
            raise FileNotFoundError(source)
        phase_name = supplied.stem if supplied.is_file() else NAMES.get(cod_id, cod_id)
        phase = project.add_phase(
            str(source), phasename=phase_name, histograms=[hist], fmthint="CIF"
        )
        phases.append(phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / max(float(phase.data["General"]["Mass"]), 1.0), False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][1][1] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 500.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        # Match the generator convention: one positive isotropic Uiso per phase.
        cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
        for atom in phase.data["Atoms"]:
            atom[cia] = "I"
            atom[cia + 1] = 0.01

    project.set_Controls("cycles", args.cycles)
    project.save()
    # Confirm that the imported scan exactly preserves the public grid and counts.
    if not np.allclose(hist.getdata("X"), xx, rtol=0, atol=1e-7):
        raise RuntimeError("GSAS-II changed the observed angle grid")
    if not np.allclose(hist.getdata("Yobs"), yy, rtol=0, atol=1e-5):
        raise RuntimeError("GSAS-II changed observed counts")

    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    refine(project, hist, "background and phase scales")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, hist, "zero and cells")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    refine(project, hist, "instrument profile and polarization")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, hist, "specimen shift")

    if args.profile:
        # Hold the common instrumental width fixed while phase-specific widths
        # enter, reducing the otherwise near-singular X/size tradeoff.
        hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        for phase in phases:
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True, "value": 0.3}}, [hist])
        refine(project, hist, "phase sizes")

        for phase in phases:
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
        refine(project, hist, "isotropic microstrain")

    if args.atomic:
        for phase in phases:
            # Coordinate-only first; refining every occupancy is chemically unjustified.
            phase.set_refinements({"Atoms": {"all": "X"}})
        refine(project, hist, "atomic coordinates")
        for phase in phases:
            phase.set_refinements({"Atoms": {"all": "XU"}})
        refine(project, hist, "coordinates and Uiso")

    project.save()
    report(project, hist, "final")


if __name__ == "__main__":
    main()
