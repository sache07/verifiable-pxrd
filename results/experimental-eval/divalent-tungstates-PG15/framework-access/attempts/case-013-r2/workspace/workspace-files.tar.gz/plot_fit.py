#!/usr/bin/env python3
"""Plot an extracted fit CSV (runs in the materials-science environment)."""

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


parser = argparse.ArgumentParser()
parser.add_argument("csv", type=Path)
parser.add_argument("--out", type=Path)
args = parser.parse_args()
data = np.genfromtxt(args.csv, delimiter=",", names=True)
x = data["two_theta"]
obs = data["observed"]
calc = data["calculated"]
diff = data["difference"]

fig, axes = plt.subplots(4, 1, figsize=(16, 12))
for ax, lo, hi in zip(axes, (10, 20, 40, 70), (20, 40, 70, 100)):
    use = (x >= lo) & (x <= hi)
    ax.plot(x[use], obs[use], color="black", lw=0.65, label="observed")
    ax.plot(x[use], calc[use], color="tab:red", lw=0.75, label="calculated")
    ax.plot(x[use], diff[use], color="tab:blue", lw=0.55, label="difference")
    ax.axhline(0, color="0.6", lw=0.4)
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
axes[0].legend(ncol=3)
axes[-1].set_xlabel(r"$2\theta$ (degrees)")
fig.tight_layout()
fig.savefig(args.out or args.csv.with_suffix(".png"), dpi=180)
