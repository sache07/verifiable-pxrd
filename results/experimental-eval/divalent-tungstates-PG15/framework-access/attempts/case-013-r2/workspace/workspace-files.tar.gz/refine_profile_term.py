#!/usr/bin/env python3
"""Refine one phase's size or strain term from a stable project."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("phase", type=int)
parser.add_argument("term", choices=("size", "strain", "uniaxial"))
parser.add_argument("--axis", default="001")
parser.add_argument("--cycles", type=int, default=12)
args = parser.parse_args()

args.output.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(args.source, args.output)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
hist = project.histograms()[0]
phases = project.phases()

hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
for phase in phases:
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.set_refinements({"Atoms": {"all": ""}})

project.index_ids()
controls = project.data["Controls"]["data"]
controls["parmFrozen"] = {"FrozenList": []}
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
hap = phases[args.phase].data["Histograms"][hist.name]

if args.term == "size":
    hap["Size"][0] = "isotropic"
    hap["Size"][2][0] = True
    variable = G2obj.G2VarObj(f"{args.phase}:0:Size;i")
    controls["parmMinDict"][variable] = 0.02
    controls["parmMaxDict"][variable] = 5.0
elif args.term == "strain":
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][2][0] = True
    variable = G2obj.G2VarObj(f"{args.phase}:0:Mustrain;i")
    controls["parmMinDict"][variable] = 0.0
    controls["parmMaxDict"][variable] = 20000.0
else:
    axis = [int(c) for c in args.axis]
    if len(axis) != 3:
        raise ValueError("axis must be a three-digit hkl such as 001")
    base = max(float(hap["Mustrain"][1][0]), 300.0)
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = base
    hap["Mustrain"][1][1] = base
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = axis
    for suffix in ("i", "a"):
        variable = G2obj.G2VarObj(f"{args.phase}:0:Mustrain;{suffix}")
        controls["parmMinDict"][variable] = 0.0
        controls["parmMaxDict"][variable] = 30000.0

project.refine()
project.save()
print(
    f"refined: Rwp={hist.get_wR():.6f} size={hap['Size'][1][:2]} "
    f"strain={hap['Mustrain'][1][:2]} mode={hap['Mustrain'][0]}",
    flush=True,
)

phases[args.phase].clear_HAP_refinements({"Size": True, "Mustrain": True})
project.refine()
project.save()
print(f"recalculated: Rwp={hist.get_wR():.6f}", flush=True)
