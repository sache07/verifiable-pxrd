#!/usr/bin/env python3
"""Add and screen one atomic phase against an established GSAS-II project."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source_project", type=Path)
parser.add_argument("output_project", type=Path)
parser.add_argument("cif", type=Path)
parser.add_argument("--name", required=True)
parser.add_argument("--cycles", type=int, default=12)
args = parser.parse_args()

args.output_project.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(args.source_project, args.output_project)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output_project))
project.set_Controls("cycles", args.cycles)
hist = project.histograms()[0]

# Freeze established nuisance/structural terms; retain only their phase scales
# and the smooth background while the candidate is screened.
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.set_refinements({"Atoms": {"all": ""}})

candidate = project.add_phase(
    str(args.cif), phasename=args.name, histograms=[hist], fmthint="CIF"
)
hap = candidate.data["Histograms"][hist.name]
hap["Scale"] = [0.1 / max(float(candidate.data["General"]["Mass"]), 1.0), True]
hap["Size"][0] = "isotropic"
hap["Size"][1][0] = 0.3
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = 500.0
hap["Mustrain"][1][1] = 500.0
hap["Mustrain"][2] = [False, False, False]
hap["Pref.Ori."][0] = "MD"
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = False
cx, ct, cs, cia = candidate.data["General"]["AtomPtrs"]
for atom in candidate.data["Atoms"]:
    atom[cia] = "I"
    atom[cia + 1] = 0.01

project.refine()
project.save()
print(f"scale: Rwp={hist.get_wR():.6f} scale={hap['Scale'][0]:.8g}", flush=True)

candidate.set_refinements({"Cell": True})
project.refine()
project.save()
print(
    f"cell: Rwp={hist.get_wR():.6f} scale={hap['Scale'][0]:.8g} "
    f"cell={candidate.data['General']['Cell'][1:8]}",
    flush=True,
)

candidate.clear_refinements({"Cell": True})
project.refine()
project.save()
print(f"recalculated: Rwp={hist.get_wR():.6f} scale={hap['Scale'][0]:.8g}", flush=True)
