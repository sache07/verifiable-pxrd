#!/usr/bin/env python3
"""Joint bounded refinement of phase-specific profile and texture terms."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--widths", action="store_true")
parser.add_argument("--textures", action="store_true")
parser.add_argument("--cycles", type=int, default=20)
args = parser.parse_args()
if not (args.widths or args.textures):
    parser.error("select --widths and/or --textures")

shutil.copy2(args.source, args.output)
G2.SetPrintLevel("warn")
p = G2.G2Project(gpxfile=str(args.output))
p.set_Controls("cycles", args.cycles)
h = p.histogram(0)
phases = p.phases()
h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
h.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
for phase in phases:
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.set_refinements({"Atoms": {"all": ""}})

p.index_ids()
controls = p.data["Controls"]["data"]
controls["parmFrozen"] = {"FrozenList": []}
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}

for i, phase in enumerate(phases):
    hap = phase.data["Histograms"][h.name]
    if args.widths:
        hap["Size"][2][0] = True
        size = G2obj.G2VarObj(f"{i}:0:Size;i")
        controls["parmMinDict"][size] = 0.04
        controls["parmMaxDict"][size] = 1.5
        if hap["Mustrain"][0] == "uniaxial":
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][1] = True
            for suffix in ("i", "a"):
                var = G2obj.G2VarObj(f"{i}:0:Mustrain;{suffix}")
                controls["parmMinDict"][var] = 0.0
                controls["parmMaxDict"][var] = 32000.0
        else:
            hap["Mustrain"][2][0] = True
            var = G2obj.G2VarObj(f"{i}:0:Mustrain;i")
            controls["parmMinDict"][var] = 0.0
            controls["parmMaxDict"][var] = 8000.0
    if args.textures:
        hap["Pref.Ori."][2] = True
        md = G2obj.G2VarObj(f"{i}:0:MD")
        controls["parmMinDict"][md] = 0.7
        controls["parmMaxDict"][md] = 1.4

p.refine()
p.save()
print(f"joint Rwp={h.get_wR():.8f}", flush=True)
for i, phase in enumerate(phases):
    hap = phase.data["Histograms"][h.name]
    print(
        i,
        phase.name,
        "size", hap["Size"][1][0],
        "strain", hap["Mustrain"][0], hap["Mustrain"][1][:2], hap["Mustrain"][3],
        "MD", hap["Pref.Ori."][1], hap["Pref.Ori."][3],
        flush=True,
    )

for phase in phases:
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
p.refine()
p.save()
print(f"recalculated Rwp={h.get_wR():.8f}", flush=True)
