#!/usr/bin/env python3
"""Create chemically substituted tungstate models from COD analogues."""

from pathlib import Path

from pymatgen.core import Element
from pymatgen.io.cif import CifParser, CifWriter


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = Path("models")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def substitute(cod_id: str, replacements: dict[str, str], output: str) -> None:
    structure = CifParser(cod_path(cod_id)).parse_structures(primitive=False)[0]
    structure.replace_species({Element(old): Element(new) for old, new in replacements.items()})
    CifWriter(structure, symprec=1e-4, significant_figures=10).write_file(OUT / output)


OUT.mkdir(exist_ok=True)
substitute("7220560", {"Mo": "W"}, "Pb2WO5_from_Pb2MoO5.cif")
substitute("1001661", {"Mg": "Pb"}, "Pb3WO6_from_MgPb2WO6.cif")
substitute("1534803", {"Ba": "Pb"}, "Pb3WO6_from_Ba3WO6.cif")
substitute("1563081", {"Ca": "Pb"}, "Pb3WO6_from_Ca3WO6.cif")
substitute("2002703", {"Mn": "Pb"}, "Pb3WO6_from_Mn3WO6.cif")
