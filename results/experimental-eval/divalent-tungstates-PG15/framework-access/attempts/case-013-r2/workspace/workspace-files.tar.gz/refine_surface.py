#!/usr/bin/env python3
"""Test Bragg-Brentano surface-roughness attenuation."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIobj as G2obj
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
shutil.copy2(args.source, args.output)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(args.output))
project.set_Controls("cycles", args.cycles)
hist = project.histograms()[0]

hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
)
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase.set_refinements({"Atoms": {"all": ""}})

hist.SampleParameters["SurfRoughA"] = [0.10, True]
hist.SampleParameters["SurfRoughB"] = [0.05, True]
project.index_ids()
controls = project.data["Controls"]["data"]
controls["parmFrozen"] = {"FrozenList": []}
controls["parmMinDict"] = {
    G2obj.G2VarObj(":0:SurfRoughA"): 0.0,
    G2obj.G2VarObj(":0:SurfRoughB"): 0.001,
}
controls["parmMaxDict"] = {
    G2obj.G2VarObj(":0:SurfRoughA"): 1.0,
    G2obj.G2VarObj(":0:SurfRoughB"): 1.0,
}
project.refine()
project.save()
print(
    f"surface: Rwp={hist.get_wR():.6f} A={hist.SampleParameters['SurfRoughA'][0]:.7g} "
    f"B={hist.SampleParameters['SurfRoughB'][0]:.7g}",
    flush=True,
)
hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
project.refine()
project.save()
print(f"recalculated: Rwp={hist.get_wR():.6f}", flush=True)
