"""Physically constrained single-phase CuWO4 refinement and model branches."""
from pathlib import Path
import copy
import json
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def report(project, label):
    h = project.histogram(0)
    p = project.phase(0)
    inst = h.data["Instrument Parameters"][0]
    hap = p.data["Histograms"][h.name]
    row = {
        "stage": label,
        "rwp": h.get_wR(),
        "cell": p.data["General"]["Cell"][1:8],
        "inst": {k: inst[k][1] for k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")},
        "sample": {k: h.SampleParameters[k][0] for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")},
        "hap_scale": hap["Scale"][0],
        "size": hap["Size"][1][:3],
        "mustrain": hap["Mustrain"][1][:3],
        "po": hap["Pref.Ori."][:4],
        "uiso": [a.uiso for a in p.atoms()],
        "coords": [list(a.coordinates) for a in p.atoms()],
        "background": h.data["Background"][0][3:],
        "covariance": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }
    print("RESULT", json.dumps(row, default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o)))
    return row


def run_refine(project, label, rows):
    project.refine(makeBack=False)
    rows.append(report(project, label))


def set_bounds(project):
    bounds = {
        ":0:Zero": (-1.0, 1.0),
        ":0:Shift": (-1000.0, 1000.0),
        ":0:U": (0.0, 100.0),
        ":0:W": (0.1, 100.0),
        ":0:X": (0.01, 10.0),
        ":0:SH/L": (0.001, 0.2),
        ":0:Polariz.": (0.0, 1.0),
        ":0:SurfRoughA": (0.0, 1.0),
        ":0:SurfRoughB": (0.0, 1.0),
        "0:0:Size;i": (0.02, 100.0),
        "0:0:Mustrain;i": (0.0, 20000.0),
        "0::AUiso:*": (0.0001, 0.10),
    }
    for var, (lo, hi) in bounds.items():
        project.set_Controls("parmMin", lo, var)
        project.set_Controls("parmMax", hi, var)


def build_base(path):
    path.unlink(missing_ok=True)
    project = G2.G2Project(newgpx=str(path))
    h = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma/tab/semicolon separated",
    )
    p = project.add_phase(
        str(ROOT / "initial_CuWO4.cif"),
        phasename="CuWO4_triclinic",
        histograms=[h], fmthint="CIF",
    )
    h.SampleParameters["Type"] = "Bragg-Brentano"
    h.SampleParameters["Gonio. radius"] = 200.0
    h.SampleParameters["Scale"] = [1.0, False]
    h.SampleParameters["Shift"] = [0.0, False]
    h.SampleParameters["SurfRoughA"] = [0.0, False]
    h.SampleParameters["SurfRoughB"] = [0.0, False]
    h.set_refinements({
        "Limits": [float(h.data["data"][1][0][0]), float(h.data["data"][1][0][-1])],
        "Background": {
            "type": "chebyschev-1", "no. coeffs": 18,
            "coeffs": [1200.0] + [0.0] * 17, "refine": True,
        },
    })
    # Fold isotropic specimen broadening into the effective Caglioti/Lorentzian
    # terms; this removes exact size-X and strain-U degeneracies.
    p.setSampleProfile(h, "size", "isotropic", 10.0, LGmix=1.0)
    p.setSampleProfile(h, "microstrain", "isotropic", 0.0, LGmix=1.0)
    p.HAPvalue("Scale", 1.0, [h])
    p.set_HAP_refinements({"Scale": True}, [h])
    inst = h.data["Instrument Parameters"][0]
    for key, value in {"Zero": 0.32, "U": 30.0, "W": 8.0, "X": 1.0, "SH/L": 0.05}.items():
        inst[key][1] = value
    project.set_Controls("cycles", 15)
    set_bounds(project)
    return project, h, p


def main():
    G2.SetPrintLevel("warn")
    rows = []
    base_path = ROOT / "constrained_base.gpx"
    project, h, p = build_base(base_path)

    h.set_refinements({"Instrument Parameters": ["Zero"]})
    p.set_refinements({"Cell": True})
    run_refine(project, "scale_background_cell_zero", rows)

    h.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_refine(project, "effective_profile", rows)

    h.set_refinements({"Sample Parameters": ["Shift"]})
    run_refine(project, "zero_displacement", rows)

    # Freeze the strongly correlated calibration/profile terms while refining
    # the structure factors.
    h.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L"],
        "Sample Parameters": ["Shift"],
    })
    p.clear_refinements({"Cell": True})
    p.set_refinements({"Atoms": {"Cu1": "X", "W1": "X"}})
    run_refine(project, "heavy_coordinates", rows)
    p.set_refinements({"Atoms": {"all": "X"}})
    run_refine(project, "all_coordinates", rows)

    # The synthetic specimen model applies one phase-wide Uiso. Tie all atom
    # Uiso values to avoid unstable element-by-element displacement factors.
    p.set_refinements({"Atoms": {"all": "XU"}})
    project.add_EquivConstr(tuple(f"0::AUiso:{i}" for i in range(len(p.atoms()))))
    run_refine(project, "coordinates_common_uiso", rows)

    h.set_refinements({"Instrument Parameters": ["Polariz."]})
    run_refine(project, "polarization", rows)

    project.save(str(base_path))
    (ROOT / "constrained_log.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
