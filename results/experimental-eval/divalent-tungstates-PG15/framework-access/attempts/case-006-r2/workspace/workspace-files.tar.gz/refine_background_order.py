"""Test a smooth Chebyshev background order from the physical two-phase model."""
from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("order", type=int)
    parser.add_argument("--start", default="aniso_uiso_fixed.gpx")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    output = ROOT / f"background_{args.order}.gpx"
    project = G2.G2Project(gpxfile=str(ROOT / args.start), filename=str(output))
    project.set_Controls("cycles", 30)
    hist = project.histogram(0)
    old = hist.data["Background"][0]
    coefficients = (old[3:args.order + 3] +
                    [0.0] * max(0, args.order - old[2]))
    hist.set_refinements({"Background": {"type": "chebyschev-1",
                                          "no. coeffs": args.order,
                                          "coeffs": coefficients,
                                          "refine": True}})
    rows = []
    for stage in range(2):
        project.refine(makeBack=False)
        rows.append({"stage": stage + 1, "rwp": hist.get_wR(),
                     "background": hist.data["Background"][0],
                     "rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})})
        print(args.order, stage + 1, hist.get_wR(), flush=True)
    project.save(str(output))
    (ROOT / f"background_{args.order}.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
