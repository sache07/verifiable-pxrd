"""Build and stage a GSAS-II refinement for the CuWO4 candidate."""
from pathlib import Path
import json
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
GPX = ROOT / "trial_cuwo4.gpx"


def summary(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hap = phase.data["Histograms"][hist.name]
    record = {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "cell": phase.data["General"]["Cell"][1:8],
        "instrument": {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")},
        "sample": {k: sample[k][0] if isinstance(sample.get(k), list) else sample.get(k)
                   for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "scale": hap["Scale"][0],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "background": hist.data["Background"][0],
    }
    print("STAGE", json.dumps(record, default=lambda x: x.tolist() if hasattr(x, "tolist") else x))
    return record


def refine(project, label, log):
    project.refine(makeBack=False)
    log.append(summary(project, label))


def main():
    G2.SetPrintLevel("warn")
    GPX.unlink(missing_ok=True)
    project = G2.G2Project(newgpx=str(GPX))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma/tab/semicolon separated",
    )
    phase = project.add_phase(
        str(ROOT / "initial_CuWO4.cif"),
        phasename="CuWO4_triclinic",
        histograms=[hist],
        fmthint="CIF",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.set_refinements({
        "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [1200.0] + [0.0] * 11,
            "refine": True,
        },
    })
    phase.setSampleProfile(hist, "size", "isotropic", 0.30, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=1.0)
    phase.HAPvalue("Scale", 1.0, [hist])
    phase.set_HAP_refinements({"Scale": True}, [hist])
    project.set_Controls("cycles", 12)
    log = []

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "background_scale_zero", log)

    phase.set_refinements({"Cell": True})
    refine(project, "cell", log)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "instrument_profile", log)

    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    }, [hist])
    refine(project, "sample_broadening", log)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "zero_and_displacement", log)

    # Surface roughness is a physically permitted whole-specimen effect and
    # is only retained if the refinement remains stable.
    hist.SampleParameters["SurfRoughA"][0] = 0.20
    hist.SampleParameters["SurfRoughB"][0] = 0.10
    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    refine(project, "surface_roughness", log)

    # Refine the heavy-atom positions before all oxygen positions.
    phase.set_refinements({"Atoms": {"Cu1": "X", "W1": "X"}})
    refine(project, "heavy_atom_coordinates", log)
    phase.set_refinements({"Atoms": {"all": "X"}})
    refine(project, "all_coordinates", log)

    project.save(str(GPX))
    (ROOT / "trial_cuwo4_log.json").write_text(json.dumps(log, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else x) + "\n")


if __name__ == "__main__":
    main()
