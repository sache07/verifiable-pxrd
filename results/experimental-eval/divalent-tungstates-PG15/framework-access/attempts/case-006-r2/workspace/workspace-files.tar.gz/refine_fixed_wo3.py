"""Refine CuWO4 + WO3 while retaining the published, physical WO3 geometry."""
from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE_COORDS = [
    (0.714, 0.487, 0.721),
    (0.225, 0.474, 0.007),
    (0.028, 0.037, 0.746),
    (0.716, 0.043, 0.708),
    (0.998, 0.262, 0.712),
    (0.206, 0.042, 0.995),
    (0.534, 0.023, 0.750),
    (0.519, 0.259, 0.789),
]


def bound(project, variable, lower, upper):
    project.set_Controls("parmMin", lower, variable)
    project.set_Controls("parmMax", upper, variable)


def fractions(project, hist):
    values = [float(p.data["General"]["Mass"]) *
              float(p.data["Histograms"][hist.name]["Scale"][0])
              for p in project.phases()]
    total = sum(values)
    return [v / total for v in values]


def snapshot(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    return {
        "stage": label,
        "rwp": hist.get_wR(),
        "fractions": fractions(project, hist),
        "cells": [p.data["General"]["Cell"][1:8] for p in project.phases()],
        "uiso": [[a.uiso for a in p.atoms()] for p in project.phases()],
        "instrument": {k: inst[k][1] for k in
                       ("Zero", "U", "W", "X", "SH/L", "Polariz.")},
        "sample": {k: hist.SampleParameters[k] for k in
                   ("Shift", "SurfRoughA", "SurfRoughB")},
        "profiles": [{"size": p.data["Histograms"][hist.name]["Size"][1][0],
                      "mustrain": p.data["Histograms"][hist.name]["Mustrain"][1][0]}
                     for p in project.phases()],
        "frozen": project.get_Frozen(),
        "rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }


def run_refinement(project, rows, label):
    project.refine(makeBack=False)
    rows.append(snapshot(project, label))
    print(label, rows[-1]["rwp"], rows[-1]["fractions"], flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("--rough", choices=("none", "fixed-a", "free"), default="fixed-a")
    parser.add_argument("--minor-profile", action="store_true")
    parser.add_argument("--background", type=int, default=18)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = ROOT / f"fixed_{args.name}.gpx"
    project = G2.G2Project(gpxfile=str(ROOT / "wo3_2311041.gpx"), filename=str(output))
    project.set_Controls("cycles", 30)
    project.set_Frozen()
    hist = project.histogram(0)
    cu, wo = project.phases()
    inst = hist.data["Instrument Parameters"][0]

    # Restore the published monoclinic WO3 coordinates. Refining all coordinates
    # of a ~3 wt% phase is not identifiable and produced short, invalid contacts.
    for atom, xyz in zip(wo.atoms(), SOURCE_COORDS):
        atom.coordinates = xyz
        atom.uiso = 0.006
        atom.refinement_flags = " "
    wo.set_refinements({"Cell": True})
    wo.set_HAP_refinements({"Scale": True}, [hist])

    # CuWO4 is the dominant phase and supports coordinate refinement. Its one
    # tied isotropic displacement parameter is constrained to the generator's
    # physically sampled interval.
    cu.set_refinements({"Cell": True, "Atoms": {"all": "XU"}})
    for atom in cu.atoms():
        if atom.uiso < 0.003:
            atom.uiso = 0.004
    bound(project, "0::AUiso:*", 0.003, 0.020)
    bound(project, "1::AUiso:*", 0.003, 0.020)

    # Effective common peak-shape terms include the dominant phase's specimen
    # broadening; their present values are a stable starting point. Keep all
    # calibration terms in broad physical intervals.
    for key in ("Zero", "U", "W", "X", "SH/L", "Polariz."):
        inst[key][2] = True
    inst["Polariz."][1] = max(0.52, inst["Polariz."][1])
    for var, lo, hi in ((":0:Zero", -0.25, 0.25), (":0:U", 0.0, 80.0),
                        (":0:W", 0.1, 50.0), (":0:X", 0.01, 10.0),
                        (":0:SH/L", 0.003, 0.15), (":0:Polariz.", 0.5, 1.0),
                        (":0:Shift", -800.0, 800.0)):
        bound(project, var, lo, hi)
    hist.SampleParameters["Shift"][1] = True

    if args.rough == "none":
        hist.SampleParameters["SurfRoughA"] = [0.0, False]
        hist.SampleParameters["SurfRoughB"] = [0.0, False]
    elif args.rough == "fixed-a":
        hist.SampleParameters["SurfRoughA"] = [0.05, False]
        hist.SampleParameters["SurfRoughB"] = [0.075, True]
        bound(project, ":0:SurfRoughB", 0.02, 0.50)
    else:
        hist.SampleParameters["SurfRoughA"] = [0.20, True]
        hist.SampleParameters["SurfRoughB"] = [0.10, True]
        bound(project, ":0:SurfRoughA", 0.05, 0.60)
        bound(project, ":0:SurfRoughB", 0.02, 0.50)

    old_background = hist.data["Background"][0]
    hist.set_refinements({"Background": {"type": "chebyschev-1",
                                          "no. coeffs": args.background,
                                          "coeffs": old_background[3:] +
                                                    [0.0] * max(0, args.background - old_background[2]),
                                          "refine": True}})

    # Begin with no phase-specific broadening beyond the effective common
    # profile. It can subsequently be released for only the minor phase.
    for phase in (cu, wo):
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
    rows = []
    run_refinement(project, rows, "physical_wo3")
    run_refinement(project, rows, "converged")

    if args.minor_profile:
        wo.setSampleProfile(hist, "size", "isotropic", 0.20, LGmix=1.0)
        wo.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=1.0)
        wo.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }, [hist])
        bound(project, "1:0:Size;i", 0.04, 5.0)
        bound(project, "1:0:Mustrain;i", 0.0, 8000.0)
        run_refinement(project, rows, "minor_profile")
        run_refinement(project, rows, "minor_profile_converged")

    project.save(str(output))
    (ROOT / f"fixed_{args.name}.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
