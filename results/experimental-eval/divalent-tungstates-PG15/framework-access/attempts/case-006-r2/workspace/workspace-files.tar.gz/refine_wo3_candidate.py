"""Add and refine one residual-WO3 candidate against the CuWO4 model."""
from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def set_bound(project, var, lo, hi):
    project.set_Controls("parmMin", lo, var)
    project.set_Controls("parmMax", hi, var)


def fractions(project, hist):
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    total = sum(masses)
    return [m / total for m in masses]


def snap(project, label):
    h = project.histogram(0)
    return {"stage": label, "rwp": h.get_wR(), "fractions": fractions(project, h),
            "cells": [p.data["General"]["Cell"][1:8] for p in project.phases()]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cod_id")
    ap.add_argument("--start", default="branch_rough.gpx")
    args = ap.parse_args()
    G2.SetPrintLevel("warn")

    out = ROOT / f"wo3_{args.cod_id}.gpx"
    project = G2.G2Project(gpxfile=str(ROOT / args.start), filename=str(out))
    h = project.histogram(0)
    cu = project.phase(0)
    wo = project.add_phase(str(cif_path(args.cod_id)), phasename=f"WO3_{args.cod_id}",
                           histograms=[h], fmthint="CIF")
    project.set_Controls("cycles", 20)
    wo.HAPvalue("Scale", 3.0, [h])
    wo.setSampleProfile(h, "size", "isotropic", 10.0, LGmix=1.0)
    wo.setSampleProfile(h, "microstrain", "isotropic", 0.0, LGmix=1.0)
    wo.set_HAP_refinements({"Scale": True}, [h])
    wo.set_refinements({"Cell": True})
    stages = []
    project.refine(makeBack=False)
    stages.append(snap(project, "scale_cell"))

    wo.set_refinements({"Atoms": {"all": "X"}})
    project.refine(makeBack=False)
    stages.append(snap(project, "coordinates"))

    # One Uiso is used per generated phase; enforce that physical model here.
    wo.set_refinements({"Atoms": {"all": "XU"}})
    project.add_EquivConstr(tuple(f"1::AUiso:{i}" for i in range(len(wo.atoms()))))
    set_bound(project, "1::AUiso:*", 0.0001, 0.10)
    project.refine(makeBack=False)
    stages.append(snap(project, "coordinates_uiso"))

    # Revisit the common calibration and both cells after the overlapped WO3
    # reflections have been assigned.
    cu.set_refinements({"Cell": True})
    h.set_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L"]})
    h.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    stages.append(snap(project, "joint_final"))
    project.save(str(out))

    inst = h.data["Instrument Parameters"][0]
    result = {
        "cod_id": args.cod_id,
        "rwp": h.get_wR(),
        "fractions": fractions(project, h),
        "stages": stages,
        "cells": [p.data["General"]["Cell"][1:8] for p in project.phases()],
        "instrument": {k: inst[k][1] for k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")},
        "sample": {k: h.SampleParameters[k] for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")},
        "phases": [{"name": p.name,
                    "scale": p.data["Histograms"][h.name]["Scale"],
                    "size": p.data["Histograms"][h.name]["Size"],
                    "mustrain": p.data["Histograms"][h.name]["Mustrain"],
                    "mass": p.data["General"]["Mass"]} for p in project.phases()],
        "frozen": project.data["Controls"]["data"].get("parmFrozen"),
        "rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }
    (ROOT / f"wo3_{args.cod_id}.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print("WO3", json.dumps(result, default=str))


if __name__ == "__main__":
    main()
