"""Create the requested machine-readable outputs from the frozen GPX replay."""
from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / ".tmp" / "replay_final"


def main():
    replay = json.loads((REPLAY / "replay.json").read_text())
    if replay.get("status") != "replayed" or replay.get("profile_review_flags"):
        raise RuntimeError(f"Final project did not replay cleanly: {replay}")

    with np.load(REPLAY / "prediction.npz") as archive:
        calculated = np.asarray(archive["predicted"], float)
    observed_table = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    two_theta, observed = observed_table.T
    if calculated.shape != observed.shape:
        raise RuntimeError("Replay and observed grids differ")

    difference = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))

    project = G2.G2Project(gpxfile=str(ROOT / "final.gpx"))
    covariance = project.data.get("Covariance", {}).get("data", {})
    n_parameters = int(covariance.get("Rvals", {}).get("Nvars", len(covariance.get("varyList", []))))
    n_observations = int(observed.size)
    degrees_of_freedom = n_observations - n_parameters
    goodness_of_fit = float(np.sqrt(chi_square / degrees_of_freedom))
    r_expected = float(rwp / goodness_of_fit)

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((two_theta, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.10f",
    )

    fractions = [float(row["weight_fraction"]) for row in replay["phases"]]
    if abs(sum(fractions) - 1.0) > 1e-12:
        raise RuntimeError("Replay phase fractions are not normalized")
    result = {
        "phases": [
            {
                "name": "triclinic copper(II) tungstate",
                "formula": "CuWO4",
                "space_group": "P -1",
                "cif_path": "phase_1_CuWO4.cif",
                "weight_fraction": fractions[0],
                "weight_fraction_uncertainty_estimate": 0.005,
            },
            {
                "name": "monoclinic tungsten(VI) oxide",
                "formula": "WO3",
                "space_group": "P 21/c",
                "cif_path": "phase_2_WO3.cif",
                "weight_fraction": fractions[1],
                "weight_fraction_uncertainty_estimate": 0.005,
            },
        ],
        "fraction_basis": "normalized over modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "R_expected_percent": r_expected,
            "goodness_of_fit": goodness_of_fit,
            "chi_square": chi_square,
            "n_observations": n_observations,
            "n_refined_parameters": n_parameters,
            "degrees_of_freedom": degrees_of_freedom,
            "weighting": "1/max(observed_counts, 1)",
        },
        "refinement_histogram": replay["histogram"],
        "profile_source": "native GSAS-II zero-cycle replay of final.gpx on the original grid",
        "project_sha256": replay["project_sha256"],
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
