"""Run one constrained GSAS-II model branch from constrained_base.gpx."""
from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def bounds(project, name, lo, hi):
    project.set_Controls("parmMin", lo, name)
    project.set_Controls("parmMax", hi, name)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("--po", nargs=3, type=int)
    parser.add_argument("--strain", nargs=3, type=int)
    parser.add_argument("--rough", action="store_true")
    parser.add_argument("--rough-fixed", nargs=2, type=float)
    parser.add_argument("--background", type=int)
    parser.add_argument("--release-profile", action="store_true")
    parser.add_argument("--release-cell", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = ROOT / f"branch_{args.name}.gpx"
    project = G2.G2Project(gpxfile=str(ROOT / "constrained_base.gpx"), filename=str(out))
    h = project.histogram(0)
    p = project.phase(0)
    hap = p.data["Histograms"][h.name]
    project.set_Controls("cycles", 20)

    if args.po:
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(args.po)
        bounds(project, "0:0:MD", 0.5, 2.0)
    if args.strain:
        # Keep the instrument profile fixed at first; the two uniaxial
        # coefficients capture only reflection-dependent broadening.
        p.setSampleProfile(h, "microstrain", "uniaxial", 300.0, 1500.0, list(args.strain), LGmix=1.0)
        p.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "refine": True,
                                             "direction": list(args.strain)}}, [h])
        bounds(project, "0:0:Mustrain;i", 0.0, 20000.0)
        bounds(project, "0:0:Mustrain;a", 0.0, 20000.0)
    if args.rough:
        h.SampleParameters["SurfRoughA"] = [0.20, True]
        h.SampleParameters["SurfRoughB"] = [0.10, True]
        bounds(project, ":0:SurfRoughA", 0.0, 1.0)
        bounds(project, ":0:SurfRoughB", 0.0, 1.0)
    if args.rough_fixed:
        h.SampleParameters["SurfRoughA"] = [args.rough_fixed[0], False]
        h.SampleParameters["SurfRoughB"] = [args.rough_fixed[1], False]
    if args.background:
        old = h.data["Background"][0]
        h.set_refinements({"Background": {"type": "chebyschev-1",
                                           "no. coeffs": args.background,
                                           "coeffs": old[3:] + [0.0] * max(0, args.background - len(old[3:])),
                                           "refine": True}})
    if args.release_profile:
        h.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    if args.release_cell:
        p.set_refinements({"Cell": True})
        h.set_refinements({"Instrument Parameters": ["Zero"]})
        h.set_refinements({"Sample Parameters": ["Shift"]})

    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save(str(out))
    inst = h.data["Instrument Parameters"][0]
    result = {
        "name": args.name,
        "rwp": h.get_wR(),
        "cell": p.data["General"]["Cell"][1:8],
        "instrument": {k: inst[k][1] for k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")},
        "sample": {k: h.SampleParameters[k] for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")},
        "mustrain": hap["Mustrain"],
        "po": hap["Pref.Ori."],
        "background": h.data["Background"][0],
        "frozen": project.data["Controls"]["data"].get("parmFrozen"),
        "vary": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
        "rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }
    (ROOT / f"branch_{args.name}.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print("BRANCH", json.dumps(result, default=str))


if __name__ == "__main__":
    main()
