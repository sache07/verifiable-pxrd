"""Physically constrained CuWO4 + monoclinic WO3 refinement."""
from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WO3 = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif")
OUT = ROOT / "physical_two_phase.gpx"


def bound(project, var, lo, hi):
    project.set_Controls("parmMin", lo, var)
    project.set_Controls("parmMax", hi, var)


def mass_fractions(project, h):
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][h.name]["Scale"][0]
              for p in project.phases()]
    return [float(v / sum(masses)) for v in masses]


def record(project, label):
    h = project.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    row = {
        "stage": label, "rwp": h.get_wR(), "fractions": mass_fractions(project, h),
        "cells": [p.data["General"]["Cell"][1:8] for p in project.phases()],
        "instrument": {k: inst[k][1] for k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")},
        "sample": {k: h.SampleParameters[k] for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")},
        "profiles": [{"size": p.data["Histograms"][h.name]["Size"],
                       "mustrain": p.data["Histograms"][h.name]["Mustrain"]}
                      for p in project.phases()],
        "uiso": [[a.uiso for a in p.atoms()] for p in project.phases()],
        "rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }
    print("PHYSICAL", json.dumps(row, default=str))
    return row


def refine(project, label, rows):
    project.refine(makeBack=False)
    rows.append(record(project, label))


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(ROOT / "branch_rough.gpx"), filename=str(OUT))
    h = project.histogram(0)
    cu = project.phase(0)
    wo = project.add_phase(str(WO3), phasename="WO3_monoclinic", histograms=[h], fmthint="CIF")
    project.set_Controls("cycles", 25)
    rows = []

    # Remove the roughness term that returned to its zero boundary once WO3
    # is modeled, and retain a physical polarization interval.
    h.SampleParameters["Scale"] = [1.0, False]
    h.SampleParameters["SurfRoughA"] = [0.0, False]
    h.SampleParameters["SurfRoughB"] = [0.0, False]
    inst = h.data["Instrument Parameters"][0]
    inst["Polariz."][1] = 0.70
    inst["Polariz."][2] = True
    bound(project, ":0:Polariz.", 0.5, 1.0)

    # Assign the narrow common instrument contribution explicitly. Phase
    # widths are then represented by physical size and microstrain terms.
    for key, value in {"U": 10.0, "W": 5.0, "X": 0.50, "SH/L": 0.05}.items():
        inst[key][1] = value
        inst[key][2] = key in ("U", "W", "SH/L")
    for var, lo, hi in ((":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0),
                        (":0:X", 0.1, 6.0), (":0:SH/L", 0.005, 0.10)):
        bound(project, var, lo, hi)

    # Avoid the near-exact Zero/Shift degeneracy: preserve the established
    # zero and refine the physically meaningful specimen displacement.
    inst["Zero"][2] = False
    h.SampleParameters["Shift"][1] = True
    bound(project, ":0:Shift", -800.0, 800.0)

    cu.setSampleProfile(h, "size", "isotropic", 0.30, LGmix=1.0)
    cu.setSampleProfile(h, "microstrain", "isotropic", 1000.0, LGmix=1.0)
    wo.setSampleProfile(h, "size", "isotropic", 1.00, LGmix=1.0)
    wo.setSampleProfile(h, "microstrain", "isotropic", 500.0, LGmix=1.0)
    for pid, phase in enumerate((cu, wo)):
        phase.set_HAP_refinements({"Scale": True,
                                   "Size": {"type": "isotropic", "refine": True},
                                   "Mustrain": {"type": "isotropic", "refine": True}}, [h])
        bound(project, f"{pid}:0:Size;i", 0.04, 5.0)
        bound(project, f"{pid}:0:Mustrain;i", 0.0, 12000.0)

    wo.HAPvalue("Scale", 1.3, [h])
    wo.set_refinements({"Cell": True})
    # Source coordinates are retained for the 3 wt% phase. Only one tied,
    # positive Uiso is fitted, which is identifiable from the intensity falloff.
    for atom in wo.atoms():
        atom.uiso = 0.010
        atom.refinement_flags = "U"
    project.add_EquivConstr(tuple(f"1::AUiso:{i}" for i in range(len(wo.atoms()))))
    bound(project, "1::AUiso:*", 0.0001, 0.10)

    refine(project, "phase_scale_cell_and_profiles", rows)
    refine(project, "profile_convergence", rows)

    # Refit both cells and CuWO4 coordinates after deconvolving the WO3 lines.
    cu.set_refinements({"Cell": True, "Atoms": {"all": "XU"}})
    refine(project, "joint_cells_cu_structure", rows)
    refine(project, "joint_convergence", rows)

    # A modestly richer background represents the smooth measured continuum.
    old = h.data["Background"][0]
    h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 24,
                                       "coeffs": old[3:] + [0.0] * 6, "refine": True}})
    refine(project, "background_24", rows)
    refine(project, "final", rows)

    project.save(str(OUT))
    (ROOT / "physical_two_phase_log.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
