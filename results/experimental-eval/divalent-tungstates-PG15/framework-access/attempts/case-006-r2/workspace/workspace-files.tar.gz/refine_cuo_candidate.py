"""Test a physical residual-CuO phase in the CuWO4 + WO3 model."""
from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(identifier):
    return COD / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def fractions(project, hist):
    terms = [float(p.data["General"]["Mass"]) *
             float(p.data["Histograms"][hist.name]["Scale"][0])
             for p in project.phases()]
    return [v / sum(terms) for v in terms]


def snapshot(project, label):
    hist = project.histogram(0)
    return {
        "stage": label,
        "rwp": hist.get_wR(),
        "fractions": fractions(project, hist),
        "cells": [p.data["General"]["Cell"][1:8] for p in project.phases()],
        "uiso": [[a.uiso for a in p.atoms()] for p in project.phases()],
        "profiles": [{"size": p.data["Histograms"][hist.name]["Size"],
                      "mustrain": p.data["Histograms"][hist.name]["Mustrain"]}
                     for p in project.phases()],
        "frozen": project.get_Frozen(),
        "rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("cod_id")
    parser.add_argument("--start", default="stable_bf.gpx")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    output = ROOT / f"cuo_{args.cod_id}.gpx"
    project = G2.G2Project(gpxfile=str(ROOT / args.start), filename=str(output))
    project.set_Controls("cycles", 30)
    project.set_Frozen()
    hist = project.histogram(0)
    cuo = project.add_phase(str(cif_path(args.cod_id)), phasename=f"CuO_{args.cod_id}",
                            histograms=[hist], fmthint="CIF")
    cuo.HAPvalue("Scale", 2.5, [hist])
    cuo.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=1.0)
    cuo.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    cuo.set_HAP_refinements({"Scale": True}, [hist])
    cuo.set_refinements({"Cell": False})
    for atom in cuo.atoms():
        atom.refinement_flags = " "

    rows = []
    for label in ("cuo_scale_cell", "converged"):
        project.refine(makeBack=False)
        rows.append(snapshot(project, label))
        print(label, rows[-1]["rwp"], rows[-1]["fractions"], flush=True)
    project.save(str(output))
    (ROOT / f"cuo_{args.cod_id}.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
