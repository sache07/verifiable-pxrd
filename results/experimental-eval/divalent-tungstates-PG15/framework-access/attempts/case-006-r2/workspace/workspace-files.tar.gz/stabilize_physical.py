"""Stabilize a physical fixed-WO3 refinement after parameters reach bounds."""
from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def bound(project, variable, lower, upper):
    project.set_Controls("parmMin", lower, variable)
    project.set_Controls("parmMax", upper, variable)


def fractions(project, hist):
    terms = [float(p.data["General"]["Mass"]) *
             float(p.data["Histograms"][hist.name]["Scale"][0])
             for p in project.phases()]
    return [v / sum(terms) for v in terms]


def describe(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    return {
        "stage": label,
        "rwp": hist.get_wR(),
        "fractions": fractions(project, hist),
        "instrument": {k: inst[k][1] for k in
                       ("Zero", "U", "W", "X", "SH/L", "Polariz.")},
        "sample": {k: hist.SampleParameters[k] for k in
                   ("Shift", "SurfRoughA", "SurfRoughB")},
        "cells": [p.data["General"]["Cell"][1:8] for p in project.phases()],
        "profiles": [{"size": p.data["Histograms"][hist.name]["Size"],
                      "mustrain": p.data["Histograms"][hist.name]["Mustrain"]}
                     for p in project.phases()],
        "frozen": project.get_Frozen(),
        "rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }


def refine(project, rows, label):
    project.refine(makeBack=False)
    rows.append(describe(project, label))
    print(label, rows[-1]["rwp"], rows[-1]["fractions"], flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("--start", default="fixed_rough_a.bak0.gpx")
    parser.add_argument("--calibration", choices=("zero-fixed", "shift-fixed", "both-fixed"),
                        default="zero-fixed")
    parser.add_argument("--minor-size", type=float)
    parser.add_argument("--minor-strain", type=float)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = ROOT / f"stable_{args.name}.gpx"
    project = G2.G2Project(gpxfile=str(ROOT / args.start), filename=str(output))
    project.set_Controls("cycles", 30)
    project.set_Frozen()
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    cu, wo = project.phases()

    # Bound-limited parameters are fixed at physically valid limits. Explicitly
    # assign every tied Uiso so the saved model itself is self-consistent.
    for atom in cu.atoms():
        atom.uiso = 0.003
        atom.refinement_flags = "X"
    for atom in wo.atoms():
        atom.uiso = 0.006
        atom.refinement_flags = " "
    inst["Polariz."][1:] = [0.5, False]
    hist.SampleParameters["SurfRoughA"] = [0.05, False]
    hist.SampleParameters["SurfRoughB"][1] = True

    if args.calibration == "zero-fixed":
        inst["Zero"][2] = False
        hist.SampleParameters["Shift"][1] = True
    elif args.calibration == "shift-fixed":
        inst["Zero"][2] = True
        hist.SampleParameters["Shift"][1] = False
    else:
        inst["Zero"][2] = False
        hist.SampleParameters["Shift"][1] = False

    cu.set_refinements({"Cell": True, "Atoms": {"all": "X"}})
    wo.set_refinements({"Cell": True})
    cu.set_HAP_refinements({"Scale": True}, [hist])
    wo.set_HAP_refinements({"Scale": True}, [hist])
    for phase in (cu, wo):
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])

    if args.minor_size is not None:
        wo.setSampleProfile(hist, "size", "isotropic", args.minor_size, LGmix=1.0)
        wo.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
        bound(project, "1:0:Size;i", 0.04, 5.0)
    if args.minor_strain is not None:
        wo.setSampleProfile(hist, "microstrain", "isotropic", args.minor_strain, LGmix=1.0)
        wo.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
        bound(project, "1:0:Mustrain;i", 0.0, 8000.0)

    rows = []
    refine(project, rows, "stabilized")
    refine(project, rows, "converged")
    project.save(str(output))
    (ROOT / f"stable_{args.name}.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
