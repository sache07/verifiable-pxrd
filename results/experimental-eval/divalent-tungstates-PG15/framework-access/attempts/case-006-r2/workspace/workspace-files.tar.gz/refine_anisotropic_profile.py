"""Test the generator's allowed uniaxial microstrain models for CuWO4."""
from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def bound(project, variable, lower, upper):
    project.set_Controls("parmMin", lower, variable)
    project.set_Controls("parmMax", upper, variable)


def fractions(project, hist):
    terms = [float(p.data["General"]["Mass"]) *
             float(p.data["Histograms"][hist.name]["Scale"][0])
             for p in project.phases()]
    return [v / sum(terms) for v in terms]


def snapshot(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    return {
        "stage": label, "rwp": hist.get_wR(), "fractions": fractions(project, hist),
        "instrument": {k: inst[k][1] for k in ("U", "W", "X", "SH/L")},
        "mustrain": project.phase(0).data["Histograms"][hist.name]["Mustrain"],
        "frozen": project.get_Frozen(),
        "rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("axis", nargs=3, type=int)
    parser.add_argument("equatorial", type=float)
    parser.add_argument("axial", type=float)
    parser.add_argument("--start", default="stable_bf.gpx")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = ROOT / f"aniso_{args.name}.gpx"
    project = G2.G2Project(gpxfile=str(ROOT / args.start), filename=str(output))
    project.set_Controls("cycles", 30)
    project.set_Frozen()
    hist = project.histogram(0)
    phase = project.phase(0)
    phase.setSampleProfile(hist, "microstrain", "uniaxial", args.equatorial,
                           args.axial, args.axis, LGmix=1.0)
    phase.set_HAP_refinements({
        "Mustrain": {"type": "uniaxial", "refine": True, "direction": args.axis}
    }, [hist])
    bound(project, "0:0:Mustrain;i", 0.0, 8000.0)
    bound(project, "0:0:Mustrain;a", 0.0, 8000.0)

    rows = []
    for label in ("anisotropic", "converged"):
        project.refine(makeBack=False)
        rows.append(snapshot(project, label))
        print(label, rows[-1]["rwp"], rows[-1]["mustrain"][:4], flush=True)
    project.save(str(output))
    (ROOT / f"aniso_{args.name}.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
