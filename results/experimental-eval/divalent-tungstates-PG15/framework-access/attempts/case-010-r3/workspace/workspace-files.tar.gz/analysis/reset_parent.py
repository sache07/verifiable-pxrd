#!/usr/bin/env python3
"""Reset phase cells/coordinates in a GPX to selected COD parent CIFs."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cid: str) -> Path:
    return COD_ROOT / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("input_gpx", type=Path)
    p.add_argument("output_gpx", type=Path)
    p.add_argument("cod_ids", help="comma-separated, in project phase order")
    p.add_argument("--coordinates-only", action="store_true")
    args = p.parse_args()
    ids = args.cod_ids.split(",")
    args.output_gpx.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.input_gpx.resolve()))
    if len(ids) != len(project.phases()):
        raise ValueError("one COD id required per phase")
    scratch = G2.G2Project(newgpx=str(args.output_gpx.with_suffix(".parents.gpx").resolve()))
    for idx, (phase, cid) in enumerate(zip(project.phases(), ids)):
        parent = scratch.add_phase(str(cod_path(cid)), phasename=f"parent_{idx}", fmthint="CIF")
        if not args.coordinates_only:
            phase.data["General"]["Cell"][1:8] = list(parent.data["General"]["Cell"][1:8])
        atoms, parent_atoms = phase.atoms(), parent.atoms()
        if len(atoms) != len(parent_atoms):
            raise ValueError(f"independent-site count mismatch for phase {idx}")
        for atom, source in zip(atoms, parent_atoms):
            if atom.element != source.element:
                raise ValueError(f"site-order mismatch for phase {idx}")
            atom.coordinates = source.coordinates
    project.save(str(args.output_gpx.resolve()))


if __name__ == "__main__":
    main()
