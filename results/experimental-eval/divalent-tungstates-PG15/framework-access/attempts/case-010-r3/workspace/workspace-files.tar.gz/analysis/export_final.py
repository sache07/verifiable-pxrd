#!/usr/bin/env python3
"""Export the final GSAS-II project, phase CIFs, profile, and result metadata."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "finalists" / "tuned.gpx"


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(ROOT / "final.gpx"))
    project.set_Controls("cycles", 0)
    project.refine()
    project.save()

    hist = project.histograms()[0]
    phases = project.phases()
    exports = ["phase_WO3.cif", "phase_Mn2O3.cif"]
    for phase, filename in zip(phases, exports):
        phase.export_CIF(str(ROOT / filename))

    arrays = hist.data["data"][1]
    x, observed, calculated = (np.asarray(arrays[i], float) for i in (0, 1, 3))
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        writer.writerows(
            (f"{xx:.8f}", f"{yo:.8f}", f"{yc:.8f}", f"{dy:.8f}")
            for xx, yo, yc, dy in zip(x, observed, calculated, difference)
        )

    raw_mass = np.array(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in phases
        ],
        float,
    )
    fractions = raw_mass / raw_mass.sum()
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    mean_weighted_squared_residual = chi_square / len(observed)
    result = {
        "phases": [
            {
                "name": "monoclinic tungsten(VI) oxide",
                "formula": "WO3",
                "space_group": "P 21/c",
                "cif_path": exports[0],
                "weight_fraction": float(fractions[0]),
            },
            {
                "name": "cubic manganese(III) oxide",
                "formula": "Mn2O3",
                "space_group": "I a -3",
                "cif_path": exports[1],
                "weight_fraction": float(fractions[1]),
            },
        ],
        "fraction_basis": "normalized over the modeled crystalline phases",
        "refinement_histogram": hist.name,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "chi_square": chi_square,
            "mean_weighted_squared_residual": mean_weighted_squared_residual,
            "weighted_residual_rms_noise_units": float(np.sqrt(mean_weighted_squared_residual)),
            "n_points": int(len(observed)),
            "weighting": "1/max(observed_counts,1)",
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
