#!/usr/bin/env python3
"""Alternate coordinate least squares with projection onto elementwise RMS balls."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from interpolate_coordinates import lattice, parse_targets


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = "X"
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def project_coordinates(
    project: G2.G2Project,
    reference: G2.G2Project,
    targets: dict[tuple[int, str], float],
) -> list[tuple[int, str, float, float]]:
    report = []
    for pidx, (phase, rphase) in enumerate(zip(project.phases(), reference.phases())):
        mat = lattice(phase.get_cell())
        atoms, ratoms = phase.atoms(), rphase.atoms()
        for element in sorted({a.element for a in atoms}):
            target = targets[(pidx, element)]
            selected = [(a, ra) for a, ra in zip(atoms, ratoms) if a.element == element]
            deltas, weights = [], []
            for atom, ratom in selected:
                delta = np.asarray(atom.coordinates) - np.asarray(ratom.coordinates)
                delta -= np.rint(delta)
                deltas.append(delta)
                weights.append(float(atom.mult) * float(atom.occupancy))
            rms = float(
                np.sqrt(np.average([np.dot(d @ mat, d @ mat) for d in deltas], weights=weights))
            )
            scale = min(1.0, target / rms) if rms else 1.0
            if scale < 1.0:
                for (atom, ratom), delta in zip(selected, deltas):
                    atom.coordinates = tuple((np.asarray(ratom.coordinates) + scale * delta).tolist())
            report.append((pidx, element, rms, min(rms, target)))
    return report


def rwp(project: G2.G2Project) -> float:
    arrays = project.histograms()[0].data["data"][1]
    obs, calc = np.asarray(arrays[1]), np.asarray(arrays[3])
    weight = 1.0 / np.maximum(obs, 1.0)
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("reference_gpx", type=Path)
    parser.add_argument("input_gpx", type=Path)
    parser.add_argument("output_gpx", type=Path)
    parser.add_argument("--targets", required=True, type=parse_targets)
    parser.add_argument("--passes", type=int, default=12)
    parser.add_argument("--cycles-per-pass", type=int, default=1)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    reference = G2.G2Project(gpxfile=str(args.reference_gpx.resolve()))
    project = G2.G2Project(gpxfile=str(args.input_gpx.resolve()))
    args.output_gpx.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(args.output_gpx.resolve()))
    if set(args.targets) != {
        (pidx, element)
        for pidx, phase in enumerate(project.phases())
        for element in {atom.element for atom in phase.atoms()}
    }:
        raise ValueError("targets must specify every phase/element pair")
    clear_flags(project)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}

    for iteration in range(args.passes):
        project.set_Controls("cycles", args.cycles_per_pass)
        project.refine()
        before = rwp(project)
        report = project_coordinates(project, reference, args.targets)
        project.save()
        project.set_Controls("cycles", 0)
        project.refine()
        print(iteration + 1, "Rwp_before_projection", before, "Rwp_projected", rwp(project), report, flush=True)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.save()


if __name__ == "__main__":
    main()
