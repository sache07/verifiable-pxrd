#!/usr/bin/env python3
"""Refine a controlled GSAS-II profile/structure variant from a good model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIobj as G2obj


AXES = {
    "none": None,
    "100": [1, 0, 0],
    "010": [0, 1, 0],
    "001": [0, 0, 1],
    "110": [1, 1, 0],
    "111": [1, 1, 1],
}


def comma_pair(text: str, cast=float):
    vals = [cast(v.strip()) for v in text.split(",")]
    if len(vals) != 2:
        raise argparse.ArgumentTypeError("expected two comma-separated values")
    return vals


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    for val in inst.values():
        if isinstance(val, list) and len(val) >= 3 and isinstance(val[2], bool):
            val[2] = False
    for val in hist.data["Sample Parameters"].values():
        if isinstance(val, list) and len(val) == 2 and isinstance(val[1], bool):
            val[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def summarize(project: G2.G2Project, options: dict) -> dict:
    hist = project.histograms()[0]
    arrays = hist.data["data"][1]
    x, obs, calc, bkg = (np.asarray(arrays[i], float) for i in (0, 1, 3, 4))
    w = 1.0 / np.maximum(obs, 1.0)
    rwp = 100.0 * np.sqrt(np.sum(w * (obs - calc) ** 2) / np.sum(w * obs**2))
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    try:
        mf = hist.ComputeMassFracs()
    except Exception:
        mf = {}
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "fraction": float(mf.get(phase.name, (np.nan,))[0]),
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size_um": [float(v) for v in hap["Size"][1][:2]],
            "microstrain_ppm": [float(v) for v in hap["Mustrain"][1][:2]],
            "microstrain_type": hap["Mustrain"][0],
            "microstrain_axis": list(hap["Mustrain"][3]),
            "MD_ratio": float(hap["Pref.Ori."][1]),
            "MD_axis": list(hap["Pref.Ori."][3]),
            "Uiso": [float(atom.uiso) for atom in phase.atoms()],
            "coordinates": [list(map(float, atom.coordinates)) for atom in phase.atoms()],
        }
    return {
        "Rwp_percent": float(rwp),
        "GSAS_wR_percent": hist.get_wR(),
        "background_min": float(np.min(bkg)),
        "instrument": {key: float(inst[key][1]) for key in ("Zero", "Polariz.", "U", "V", "W", "X", "SH/L")},
        "sample": {
            "Shift_um": float(sample["Shift"][0]),
            "SurfRoughA": float(sample["SurfRoughA"][0]),
            "SurfRoughB": float(sample["SurfRoughB"][0]),
        },
        "phases": phases,
        "options": options,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx", type=Path)
    parser.add_argument("output_gpx", type=Path)
    parser.add_argument("--po-axes", type=lambda s: comma_pair(s, str), default=["none", "none"])
    parser.add_argument("--sh-orders", type=lambda s: comma_pair(s, int), default=[0, 0])
    parser.add_argument("--uiso", type=lambda s: comma_pair(s, float), default=[0.01, 0.01])
    parser.add_argument("--polarization", type=float, default=0.75)
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--bound-roughness", action="store_true")
    parser.add_argument("--surf-a", type=float)
    parser.add_argument("--surf-b", type=float)
    parser.add_argument("--strain-axes", type=lambda s: comma_pair(s, str), default=["none", "none"])
    parser.add_argument("--refine-calibration", action="store_true")
    parser.add_argument("--zero", type=float)
    parser.add_argument("--shift", type=float)
    parser.add_argument("--w", type=float, default=14.0)
    parser.add_argument("--refine-w", action="store_true")
    parser.add_argument("--bound-coordinates", action="store_true")
    parser.add_argument(
        "--coordinate-mode",
        choices=("all", "heavy", "oxygen", "none"),
        default="all",
        help="Select which atomic coordinates are varied.",
    )
    parser.add_argument("--heavy-bound-A", type=float, default=0.04)
    parser.add_argument("--oxygen-bound-A", type=float, default=0.05)
    parser.add_argument("--cycles", type=int, default=10)
    args = parser.parse_args()
    if any(a not in AXES for a in args.po_axes + args.strain_axes):
        parser.error("unknown axis code")

    G2.SetPrintLevel("warn")
    args.output_gpx.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.input_gpx.resolve()))
    project.save(str(args.output_gpx.resolve()))
    clear_flags(project)
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    # Fixed bounded quantities for this variant.
    inst["Polariz."][1] = float(args.polarization)
    inst["Polariz."][2] = False
    inst["U"][1], inst["U"][2] = 0.1, False
    inst["V"][1], inst["V"][2] = 0.0, False
    inst["X"][1], inst["X"][2] = 0.1, False
    inst["Y"][1], inst["Y"][2] = 0.0, False
    if args.zero is not None:
        inst["Zero"][1] = float(args.zero)
    if args.shift is not None:
        sample["Shift"][0] = float(args.shift)
    inst["Zero"][2] = bool(args.refine_calibration)
    sample["Shift"][1] = bool(args.refine_calibration)
    inst["W"][1] = float(args.w)
    inst["W"][2] = bool(args.refine_w)
    inst["SH/L"][2] = True
    if (args.surf_a is None) != (args.surf_b is None):
        parser.error("--surf-a and --surf-b must be supplied together")
    if args.surf_a is not None:
        sample["SurfRoughA"] = [float(args.surf_a), bool(args.roughness)]
        sample["SurfRoughB"] = [float(args.surf_b), bool(args.roughness)]
    elif args.roughness:
        sample["SurfRoughA"] = [0.2, True]
        sample["SurfRoughB"] = [0.1, True]
    else:
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.0, False]
    hist.data["Background"][0][1] = True

    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    # Parameter-limit keys are stored with persistent phase/atom IDs. Populate
    # GSAS-II's lookup tables before converting sequential variable names.
    project.index_ids()
    if args.roughness and args.bound_roughness:
        for name, low, high in (("SurfRoughA", 0.05, 0.6), ("SurfRoughB", 0.02, 0.5)):
            variable = G2obj.G2VarObj(f":0:{name}")
            controls["parmMinDict"][variable] = low
            controls["parmMaxDict"][variable] = high

    for idx, phase in enumerate(project.phases()):
        phase.data["General"]["Cell"][0] = True
        for atom in phase.atoms():
            atom.uiso = float(args.uiso[idx])
            selected = (
                args.coordinate_mode == "all"
                or (args.coordinate_mode == "heavy" and atom.element != "O")
                or (args.coordinate_mode == "oxygen" and atom.element == "O")
            )
            atom.refinement_flags = "X" if selected else " "
        if args.bound_coordinates:
            lengths = phase.get_cell()
            axis_lengths = [lengths["length_a"], lengths["length_b"], lengths["length_c"]]
            for atom_index, atom in enumerate(phase.atoms()):
                radial = args.oxygen_bound_A if atom.element == "O" else args.heavy_bound_A
                for axis, (letter, center, axis_length) in enumerate(zip("xyz", atom.coordinates, axis_lengths)):
                    delta = float(radial) / float(axis_length)
                    name = G2obj.G2VarObj(f"{idx}::dA{letter}:{atom_index}")
                    controls["parmMinDict"][name] = float(center - delta)
                    controls["parmMaxDict"][name] = float(center + delta)
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
        strain_axis = AXES[args.strain_axes[idx]]
        if strain_axis is None:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2] = [True, False, False]
        else:
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
            hap["Mustrain"][2] = [True, True, False]
            hap["Mustrain"][3] = list(strain_axis)
        po_axis = AXES[args.po_axes[idx]]
        if args.sh_orders[idx] > 0:
            phase.HAPvalue("PO", args.sh_orders[idx])
            hap["Pref.Ori."][2] = True
        else:
            hap["Pref.Ori."][0] = "MD"
            if po_axis is None:
                hap["Pref.Ori."][1] = 1.0
                hap["Pref.Ori."][2] = False
            else:
                hap["Pref.Ori."][1] = 0.98
                hap["Pref.Ori."][2] = True
                hap["Pref.Ori."][3] = list(po_axis)

    project.set_Controls("cycles", args.cycles)
    project.save()
    project.refine()
    project.save()
    options = {
        "po_axes": args.po_axes,
        "sh_orders": args.sh_orders,
        "uiso": args.uiso,
        "polarization": args.polarization,
        "roughness": args.roughness,
        "bound_roughness": args.bound_roughness,
        "surf_a": args.surf_a,
        "surf_b": args.surf_b,
        "strain_axes": args.strain_axes,
        "refine_calibration": args.refine_calibration,
        "W_fixed_or_start": args.w,
        "refine_W": args.refine_w,
        "bounded_coordinates": args.bound_coordinates,
        "coordinate_mode": args.coordinate_mode,
    }
    summary = summarize(project, options)
    args.output_gpx.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
