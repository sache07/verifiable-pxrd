#!/usr/bin/env python3
"""Tune linear scales/background for a fixed structural and peak-shape model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def summarize(project: G2.G2Project) -> dict:
    hist = project.histograms()[0]
    arrays = hist.data["data"][1]
    obs, calc, background = (np.asarray(arrays[i], float) for i in (1, 3, 4))
    weight = 1 / np.maximum(obs, 1)
    rwp = 100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2))
    raw = {
        phase.name: float(phase.data["Histograms"][hist.name]["Scale"][0])
        * float(phase.data["General"]["Mass"])
        for phase in project.phases()
    }
    total = sum(raw.values())
    return {
        "Rwp_percent": float(rwp),
        "background_min": float(background.min()),
        "fractions": {name: value / total for name, value in raw.items()},
        "surface_roughness": {
            key: float(hist.data["Sample Parameters"][key][0])
            for key in ("SurfRoughA", "SurfRoughB")
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx", type=Path)
    parser.add_argument("output_gpx", type=Path)
    parser.add_argument("--surf-a", type=float, required=True)
    parser.add_argument("--surf-b", type=float, required=True)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--refine-profile", action="store_true")
    parser.add_argument("--polarization", type=float)
    parser.add_argument("--uiso", type=lambda s: [float(v) for v in s.split(",")])
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input_gpx.resolve()))
    args.output_gpx.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(args.output_gpx.resolve()))
    clear_flags(project)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    hist.data["Sample Parameters"]["SurfRoughA"] = [args.surf_a, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [args.surf_b, False]
    if args.polarization is not None:
        hist.data["Instrument Parameters"][0]["Polariz."][1] = args.polarization
    if args.uiso is not None:
        if len(args.uiso) != len(project.phases()):
            parser.error("--uiso needs one comma-separated value per phase")
        for value, phase in zip(args.uiso, project.phases()):
            for atom in phase.atoms():
                atom.uiso = value
    if args.refine_profile:
        hist.data["Instrument Parameters"][0]["SH/L"][2] = True
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        if args.refine_profile:
            hap["Size"][2][0] = True
            hap["Mustrain"][2][0] = True
            if hap["Mustrain"][0] == "uniaxial":
                hap["Mustrain"][2][1] = True
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save()
    # Store arrays calculated from the final parameter vector, rather than the
    # penultimate least-squares cycle retained by some GSAS-II refinements.
    clear_flags(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save()
    result = summarize(project)
    args.output_gpx.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
