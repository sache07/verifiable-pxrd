#!/usr/bin/env python3
"""Scale refined coordinate-displacement directions to requested element RMS values."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def lattice(cell: dict[str, float]) -> np.ndarray:
    a, b, c = (cell[f"length_{x}"] for x in "abc")
    alpha, beta, gamma = (np.deg2rad(cell[f"angle_{x}"]) for x in ("alpha", "beta", "gamma"))
    av = np.array([a, 0.0, 0.0])
    bv = np.array([b * np.cos(gamma), b * np.sin(gamma), 0.0])
    cx = c * np.cos(beta)
    cy = c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)
    cv = np.array([cx, cy, np.sqrt(max(0.0, c * c - cx * cx - cy * cy))])
    return np.vstack((av, bv, cv))


def parse_targets(text: str) -> dict[tuple[int, str], float]:
    result: dict[tuple[int, str], float] = {}
    for item in text.split(","):
        key, value = item.split("=", 1)
        phase, element = key.split(":", 1)
        result[(int(phase), element)] = float(value)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("parent_gpx", type=Path)
    parser.add_argument("direction_gpx", type=Path)
    parser.add_argument("output_gpx", type=Path)
    parser.add_argument("--targets", required=True, type=parse_targets)
    args = parser.parse_args()

    parent = G2.G2Project(gpxfile=str(args.parent_gpx.resolve()))
    direction = G2.G2Project(gpxfile=str(args.direction_gpx.resolve()))
    parent.save(str(args.output_gpx.resolve()))
    phases = parent.phases()
    dphases = direction.phases()
    if len(phases) != len(dphases):
        raise ValueError("phase counts differ")

    for pidx, (phase, dphase) in enumerate(zip(phases, dphases)):
        atoms, datoms = phase.atoms(), dphase.atoms()
        if len(atoms) != len(datoms):
            raise ValueError("atom counts differ")
        mat = lattice(phase.get_cell())
        for element in sorted({a.element for a in atoms}):
            target = args.targets.get((pidx, element), 0.0)
            selected = [(a, da) for a, da in zip(atoms, datoms) if a.element == element]
            deltas = []
            weights = []
            for atom, datom in selected:
                delta = np.asarray(datom.coordinates) - np.asarray(atom.coordinates)
                delta -= np.rint(delta)
                deltas.append(delta)
                weights.append(float(atom.mult) * float(atom.occupancy))
            rms = np.sqrt(
                np.average([np.dot(d @ mat, d @ mat) for d in deltas], weights=weights)
            )
            scale = 0.0 if rms == 0.0 else target / rms
            for (atom, _), delta in zip(selected, deltas):
                atom.coordinates = tuple((np.asarray(atom.coordinates) + scale * delta).tolist())
            print(pidx, phase.name, element, "direction_rms", rms, "target", target, "scale", scale)
    parent.save()


if __name__ == "__main__":
    main()
