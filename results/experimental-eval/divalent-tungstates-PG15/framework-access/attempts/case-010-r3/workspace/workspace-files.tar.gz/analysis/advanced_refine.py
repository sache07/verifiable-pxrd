#!/usr/bin/env python3
"""Physically constrained follow-up refinement of a screened GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def metric(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    arrays = hist.data["data"][1]
    x, obs, calc, bkg = (np.asarray(arrays[i], float) for i in (0, 1, 3, 4))
    weights = 1.0 / np.maximum(obs, 1.0)
    rwp = 100.0 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2))
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "label": label,
        "Rwp_percent": float(rwp),
        "GSAS_wR_percent": hist.get_wR(),
        "background_min": float(np.min(bkg)),
        "instrument": {key: float(inst[key][1]) for key in ("Zero", "Polariz.", "U", "V", "W", "X", "SH/L")},
        "sample": {
            "Shift_um": float(sample["Shift"][0]),
            "SurfRoughA": float(sample["SurfRoughA"][0]),
            "SurfRoughB": float(sample["SurfRoughB"][0]),
        },
        "phases": {},
    }
    try:
        fractions = hist.ComputeMassFracs()
    except Exception:
        fractions = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "fraction": float(fractions.get(phase.name, (np.nan,))[0]),
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size_um": [float(v) for v in hap["Size"][1][:2]],
            "microstrain_ppm": [float(v) for v in hap["Mustrain"][1][:2]],
            "MD_ratio": float(hap["Pref.Ori."][1]),
            "MD_axis": list(hap["Pref.Ori."][3]),
            "Uiso_values": [float(atom.uiso) for atom in phase.atoms()],
        }
    print(json.dumps(result), flush=True)
    return result


def run_step(project: G2.G2Project, label: str, history: list[dict]) -> None:
    project.refine()
    history.append(metric(project, label))


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    for key, val in inst.items():
        if isinstance(val, list) and len(val) >= 3 and isinstance(val[2], bool):
            val[2] = False
    sample = hist.data["Sample Parameters"]
    for val in sample.values():
        if isinstance(val, list) and len(val) == 2 and isinstance(val[1], bool):
            val[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx", type=Path)
    parser.add_argument("output_gpx", type=Path)
    parser.add_argument("--background-terms", type=int, default=16)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.output_gpx.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.input_gpx.resolve()))
    project.save(str(args.output_gpx.resolve()))
    hist = project.histograms()[0]
    clear_flags(project)

    inst = hist.data["Instrument Parameters"][0]
    # Use nonnegative lower-end common broadening. Phase size/microstrain can
    # represent the common contribution without risking negative peak widths.
    for key, value in {"U": 0.1, "V": 0.0, "W": 30.0, "X": 0.1, "Y": 0.0, "SH/L": 0.04}.items():
        inst[key][1] = value
        inst[key][2] = False
    inst["Polariz."][1] = 0.75
    inst["Polariz."][2] = False

    sample = hist.data["Sample Parameters"]
    sample["Gonio. radius"] = 200.0
    # Retain the sensible calibration estimates from screening, but re-solve
    # them only after cells and widths settle.
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    old_bkg = list(hist.data["Background"][0][3:])
    coeffs = old_bkg[: args.background_terms] + [0.0] * max(0, args.background_terms - len(old_bkg))
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": coeffs,
                "refine": True,
            }
        }
    )

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        for atom in phase.atoms():
            atom.uiso = 0.01
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.25
        hap["Size"][1][1] = 0.25
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1800.0
        hap["Mustrain"][1][1] = 1800.0
        hap["Mustrain"][2] = [True, False, False]

    project.set_Controls("cycles", 12)
    project.save()
    history: list[dict] = []
    run_step(project, "physical_widths_cells", history)

    # Calibration is represented exactly by constant Zero plus Bragg-Brentano
    # specimen displacement. Both are bounded by good screened starting values.
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    inst["Zero"][2] = True
    sample["Shift"][1] = True
    run_step(project, "calibration", history)

    # W and axial divergence are not degenerate with phase size/strain in the
    # same way as U and X, so refine these common profile terms.
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    inst["W"][2] = True
    inst["SH/L"][2] = True
    run_step(project, "common_profile", history)

    # Recover the symmetry-preserving coordinate perturbations applied to the
    # registered parent models. Occupancies remain fixed.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "X"
    run_step(project, "coordinates", history)

    # Generator Uiso is one scalar per phase. Constrain all sites in a phase to
    # one value to avoid unphysical site-by-site displacement overfitting.
    project.save()
    for pidx, phase in enumerate(project.phases()):
        atoms = phase.atoms()
        for atom in atoms:
            atom.refinement_flags = "XU"
        if len(atoms) > 1:
            variables = [f"{pidx}::AUiso:{i}" for i in range(len(atoms))]
            project.add_EquivConstr(variables, reloadIdx=(pidx == 0))
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    inst["Polariz."][2] = True
    run_step(project, "coordinates_common_uiso_polarization", history)

    project.save()
    summary = {
        "input_gpx": str(args.input_gpx),
        "output_gpx": str(args.output_gpx),
        "history": history,
        "final": history[-1],
    }
    args.output_gpx.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
