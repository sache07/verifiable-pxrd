#!/usr/bin/env python3
"""Build and refine a small GSAS-II candidate model for the Mn-W-O scan.

Run with the GSAS-II Python interpreter. This is an exploratory helper; the
final export is made separately after candidate and profile-model selection.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def instrument_text() -> str:
    # Midpoint values in the documented laboratory ranges; all relevant
    # profile/calibration terms are subsequently refined.
    return (
        "# GSAS-II Cu Kalpha Bragg-Brentano instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.28;Polariz.:0.75;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:21.0;X:0.7745966692;Y:0.0;Z:0.0;SH/L:0.02236068\n"
    )


def set_initial_values(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"][1] = 0.28
    inst["U"][1] = 20.0
    inst["V"][1] = 0.0
    inst["W"][1] = 21.0
    inst["X"][1] = 0.8
    inst["SH/L"][1] = 0.022
    inst["Polariz."][1] = 0.75

    sample = hist.data["Sample Parameters"]
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    # A smooth raw-data background. Starting values need only be close enough
    # for the first linear least-squares cycle.
    hist.set_refinements(
        {
            "Limits": [9.90343322, 100.09455322],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [900.0] + [0.0] * 11,
                "refine": True,
            },
        }
    )

    # Approximate values from the stoichiometric precursor mass ratio. The
    # normalization is arbitrary at this stage and is refined below.
    start_scales = [11.5, 2.9]
    for phase, scale in zip(project.phases(), start_scales):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][1][1] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]


def refine_step(project: G2.G2Project, label: str) -> dict:
    project.refine()
    hist = project.histograms()[0]
    result = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }
    try:
        result["mass_fractions"] = {
            key: {"value": val[0], "sigma": val[1]}
            for key, val in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        result["mass_fraction_error"] = str(exc)
    print(json.dumps(result), flush=True)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("mn2o3_id")
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.outdir.mkdir(parents=True, exist_ok=True)
    inst_path = args.outdir / "instrument.instprm"
    inst_path.write_text(instrument_text())
    gpx_path = args.outdir / "candidate.gpx"
    project = G2.G2Project(newgpx=str(gpx_path))
    wo3 = project.add_phase(str(cod_path(args.wo3_id)), phasename=f"WO3_{args.wo3_id}", fmthint="CIF")
    mn2o3 = project.add_phase(str(cod_path(args.mn2o3_id)), phasename=f"Mn2O3_{args.mn2o3_id}", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(args.pattern.resolve()), str(inst_path.resolve()), phases=[wo3, mn2o3], fmthint="comma"
    )
    set_initial_values(project)
    project.set_Controls("cycles", 8)
    project.save()

    history = []
    # First solve linear background/phase scales at approximately aligned peaks.
    history.append(refine_step(project, "background_scales"))

    # Resolve constant zero from the cos(theta) specimen-height displacement.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    history.append(refine_step(project, "zero_shift"))

    # Refine lattice metrics only after calibration has settled.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    history.append(refine_step(project, "cells"))

    # Instrument broadening, then the phase-specific size/strain terms used by
    # the synthetic laboratory forward model.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]})
    history.append(refine_step(project, "instrument_profile"))
    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True, "value": 0.3}})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    history.append(refine_step(project, "size_strain"))

    project.save()
    arrays = hist.data["data"][1]
    x, obs, calc = (np.asarray(arrays[i], float) for i in (0, 1, 3))
    weights = 1.0 / np.maximum(obs, 1.0)
    rwp = 100.0 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs**2))
    summary = {
        "wo3_id": args.wo3_id,
        "mn2o3_id": args.mn2o3_id,
        "gpx": str(gpx_path),
        "rwp_recomputed_percent": float(rwp),
        "history": history,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
    }
    (args.outdir / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps({"final": summary["rwp_recomputed_percent"], "path": str(gpx_path)}))


if __name__ == "__main__":
    main()
