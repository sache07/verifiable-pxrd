#!/usr/bin/env python3
"""Replay-checked coordinate-descent refinement for a GSAS-II powder model.

GSAS-II stores a profile calculated before its final parameter update. This
driver accepts a step only after a zero-cycle recalculation from the updated
project, preventing a large last-cycle shift from masquerading as a good fit.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False


def rwp(project: G2.G2Project) -> float:
    hist = project.histogram(0)
    y = np.asarray(hist.getdata("Yobs"), float)
    c = np.asarray(hist.getdata("Ycalc"), float)
    w = np.asarray(hist.getdata("Yweight"), float)
    return float(100 * np.sqrt(np.sum(w * (y - c) ** 2) / np.sum(w * y**2)))


def state(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "Rwp_percent": rwp(project),
        "instrument": {
            key: float(inst[key][1])
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
            if key in inst
        },
        "sample": {
            key: float(sample[key][0])
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "background_min": float(np.min(hist.getdata("Background"))),
        "phases": {},
    }
    masses = []
    scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"])
        scale = float(hap["Scale"][0])
        masses.append(mass)
        scales.append(scale)
        result["phases"][phase.name] = {
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:8]],
            "scale": scale,
            "mass": mass,
            "size": [hap["Size"][0], [float(v) for v in hap["Size"][1]]],
            "mustrain": [hap["Mustrain"][0], [float(v) for v in hap["Mustrain"][1]], list(hap["Mustrain"][3])],
            "preferred_orientation": [float(hap["Pref.Ori."][1]), list(hap["Pref.Ori."][3])],
            "atoms": {
                atom.label: {
                    "element": atom.element,
                    "xyz": [float(v) for v in atom.coordinates],
                    "Uiso": float(atom.uiso) if atom.adp_flag == "I" else None,
                }
                for atom in phase.atoms()
            },
        }
    amounts = np.asarray(masses) * np.asarray(scales)
    fractions = amounts / amounts.sum()
    result["mass_fractions"] = {
        phase.name: float(value) for phase, value in zip(project.phases(), fractions)
    }
    return result


def phase(project: G2.G2Project, name: str):
    return next(p for p in project.phases() if p.name == name)


def enable(project: G2.G2Project, group: str) -> None:
    hist = project.histogram(0)
    if group == "scales":
        for item in project.phases():
            item.data["Histograms"][hist.name]["Scale"][1] = True
    elif group == "background":
        hist.data["Background"][0][1] = True
    elif group in {"zero", "U", "W", "X", "SH/L", "Polariz."}:
        key = "Zero" if group == "zero" else group
        hist.data["Instrument Parameters"][0][key][2] = True
    elif group == "shift":
        hist.data["Sample Parameters"]["Shift"][1] = True
    elif group.startswith("cell:"):
        phase(project, group.split(":", 1)[1]).data["General"]["Cell"][0] = True
    elif group.startswith("size:"):
        item = phase(project, group.split(":", 1)[1])
        item.data["Histograms"][hist.name]["Size"][2][0] = True
    elif group.startswith("strain:"):
        item = phase(project, group.split(":", 1)[1])
        item.data["Histograms"][hist.name]["Mustrain"][2][0] = True
    elif group.startswith("uniaxial:"):
        _, phase_name, raw_axis = group.split(":", 2)
        item = phase(project, phase_name)
        hap = item.data["Histograms"][hist.name]
        axis = [int(v) for v in raw_axis.split(",")]
        if hap["Mustrain"][0] != "uniaxial" or list(hap["Mustrain"][3]) != axis:
            base = float(hap["Mustrain"][1][0])
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][1] = 1.05 * base
            hap["Mustrain"][3] = axis
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
    elif group.startswith("atom:"):
        _, phase_name, label = group.split(":", 2)
        phase(project, phase_name).atom(label).refinement_flags = "X"
    elif group.startswith("atoms:"):
        _, phase_name, element = group.split(":", 2)
        for atom in phase(project, phase_name).atoms():
            if atom.element == element:
                atom.refinement_flags = "X"
    elif group.startswith("uiso:"):
        _, phase_name, label = group.split(":", 2)
        phase(project, phase_name).atom(label).refinement_flags = "U"
    elif group.startswith("uiso-phase:"):
        _, phase_name = group.split(":", 1)
        for atom in phase(project, phase_name).atoms():
            atom.refinement_flags = "U"
    elif group.startswith("uiso-scales:"):
        _, phase_name = group.split(":", 1)
        for atom in phase(project, phase_name).atoms():
            atom.refinement_flags = "U"
        for item in project.phases():
            item.data["Histograms"][hist.name]["Scale"][1] = True
    elif group.startswith("po:"):
        _, phase_name, raw_axis = group.split(":", 2)
        item = phase(project, phase_name)
        hap = item.data["Histograms"][hist.name]
        selected_axis = [int(v) for v in raw_axis.split(",")]
        hap["Pref.Ori."][0] = "MD"
        if abs(float(hap["Pref.Ori."][1]) - 1.0) < 1e-10 or list(hap["Pref.Ori."][3]) != selected_axis:
            hap["Pref.Ori."][1] = 1.01
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = selected_axis
    else:
        raise ValueError(group)


def physically_valid(project: G2.G2Project) -> bool:
    hist = project.histogram(0)
    if not np.isfinite(rwp(project)) or np.min(hist.getdata("Background")) < 0:
        return False
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "W", "X", "SH/L"):
        if float(inst[key][1]) < 0:
            return False
    if not 0 <= float(inst["Polariz."][1]) <= 1:
        return False
    for item in project.phases():
        hap = item.data["Histograms"][hist.name]
        if hap["Scale"][0] <= 0 or hap["Size"][1][0] <= 0 or hap["Mustrain"][1][0] < 0:
            return False
        for atom in item.atoms():
            if atom.adp_flag == "I" and not 0.003 <= float(atom.uiso) <= 0.020:
                return False
    return True


def candidate(
    source: Path,
    target: Path,
    group: str,
    damping: float,
) -> tuple[float, dict]:
    project = G2.G2Project(str(source))
    project.save(str(target))
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    clear_flags(project)
    enable(project, group)
    controls["max cyc"] = 1
    controls["shift factor"] = float(damping)
    controls["min dM/M"] = 1e-6
    project.refine()
    clear_flags(project)
    controls["max cyc"] = 0
    project.refine()
    value = rwp(project) if physically_valid(project) else float("inf")
    return value, state(project)


def optimize_group(
    current: Path,
    work: Path,
    group: str,
    initial_rwp: float,
    damping: float,
    max_accepts: int,
    ledger: list[dict],
) -> tuple[Path, float]:
    accepted = 0
    while accepted < max_accepts:
        best = None
        for factor in (1.0, 0.35, 0.1):
            safe_group = group.replace(":", "_").replace("/", "_").replace(".", "_")
            target = work / f"step-{len(ledger):04d}-{safe_group}-{factor:g}.gpx"
            value, snapshot = candidate(current, target, group, damping * factor)
            trial = {
                "group": group,
                "damping": damping * factor,
                "before_Rwp": initial_rwp,
                "after_Rwp": value,
                "accepted": False,
                "project": str(target),
                "state": snapshot,
            }
            ledger.append(trial)
            if best is None or value < best[0]:
                best = (value, target, trial)
        assert best is not None
        if best[0] < initial_rwp - 1e-5:
            best[2]["accepted"] = True
            current, initial_rwp = best[1], best[0]
            accepted += 1
            print(f"accept {group}: Rwp={initial_rwp:.6f}", flush=True)
        else:
            print(f"reject {group}: best={best[0]:.6f} current={initial_rwp:.6f}", flush=True)
            break
    return current, initial_rwp


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--rounds", type=int, default=2)
    parser.add_argument("--coordinates", action="store_true")
    parser.add_argument("--only")
    parser.add_argument("--damping", type=float, default=0.2)
    parser.add_argument("--accepts", type=int, default=6)
    parser.add_argument("--skip-nuisance", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    work = args.output.parent / (args.output.stem + "-steps")
    work.mkdir(parents=True, exist_ok=True)
    # Recalculate the input once so the objective always corresponds to its
    # serialized model rather than to a pre-update profile array.
    baseline = work / "baseline.gpx"
    project = G2.G2Project(str(args.input))
    project.save(str(baseline))
    clear_flags(project)
    project.set_Controls("cycles", 0)
    project.refine()
    current = baseline
    current_rwp = rwp(project)
    ledger: list[dict] = [{"group": "baseline", "state": state(project), "accepted": True}]
    print(f"baseline Rwp={current_rwp:.6f}", flush=True)

    if args.only:
        current, current_rwp = optimize_group(
            current, work, args.only, current_rwp, args.damping, args.accepts, ledger
        )
        if not args.skip_nuisance:
            for group in ("scales", "background"):
                current, current_rwp = optimize_group(
                    current, work, group, current_rwp, 1.0, 2, ledger
                )
        final = G2.G2Project(str(current))
        final.save(str(args.output))
        args.output.with_suffix(".robust.json").write_text(
            json.dumps(ledger, indent=2, allow_nan=False) + "\n"
        )
        print(f"final Rwp={current_rwp:.6f} project={args.output}", flush=True)
        return

    phase_names = ["WO3", "CaWO4", "CaCO3"]
    for _ in range(args.rounds):
        schedule = [
            ("scales", 1.0, 2),
            ("background", 1.0, 1),
            ("zero", 0.5, 2),
            ("shift", 0.5, 2),
            *[(f"cell:{name}", 0.35, 2) for name in phase_names],
            *[(f"size:{name}", 0.25, 2) for name in phase_names],
            *[(f"strain:{name}", 0.25, 2) for name in phase_names],
            ("scales", 1.0, 1),
            ("background", 1.0, 1),
        ]
        for group, damping, count in schedule:
            current, current_rwp = optimize_group(
                current, work, group, current_rwp, damping, count, ledger
            )

    for group, damping in [("W", 0.15), ("X", 0.15), ("SH/L", 0.25), ("Polariz.", 0.2), ("U", 0.1)]:
        current, current_rwp = optimize_group(
            current, work, group, current_rwp, damping, 2, ledger
        )

    if args.coordinates:
        source = G2.G2Project(str(current))
        atom_groups = [
            f"atom:{item.name}:{atom.label}"
            for item in source.phases()
            for atom in item.atoms()
            if atom.element == "W"
        ]
        for group in atom_groups:
            current, current_rwp = optimize_group(
                current, work, group, current_rwp, 0.03, 3, ledger
            )

    for group in ("scales", "background"):
        current, current_rwp = optimize_group(
            current, work, group, current_rwp, 1.0, 2, ledger
        )

    final = G2.G2Project(str(current))
    final.save(str(args.output))
    args.output.with_suffix(".robust.json").write_text(
        json.dumps(ledger, indent=2, allow_nan=False) + "\n"
    )
    print(f"final Rwp={current_rwp:.6f} project={args.output}", flush=True)


if __name__ == "__main__":
    main()
