#!/usr/bin/env python3
"""Replay-stable coordinate refinement with a generator-mismatch RMS cap."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from robust_optimize import clear_flags, phase, rwp


def lattice_matrix(cell):
    a, b, c, al, be, ga = cell
    al, be, ga = np.deg2rad([al, be, ga])
    matrix = np.array(
        [
            [a, 0.0, 0.0],
            [b * np.cos(ga), b * np.sin(ga), 0.0],
            [
                c * np.cos(be),
                c * (np.cos(al) - np.cos(be) * np.cos(ga)) / np.sin(ga),
                0.0,
            ],
        ]
    )
    matrix[2, 2] = np.sqrt(max(0.0, c * c - matrix[2, 0] ** 2 - matrix[2, 1] ** 2))
    return matrix


def project_rms(project, parent_xyz, phase_name, element, target_rms):
    item = phase(project, phase_name)
    matrix = lattice_matrix(item.data["General"]["Cell"][1:7])
    selected = [atom for atom in item.atoms() if atom.element == element]
    displacements = []
    for atom in selected:
        delta = np.asarray(atom.coordinates, float) - parent_xyz[atom.label]
        delta -= np.rint(delta)
        displacements.append(delta)
    rms = np.sqrt(np.mean([np.linalg.norm(delta @ matrix) ** 2 for delta in displacements]))
    if rms <= 0:
        raise ValueError("zero coordinate update cannot be projected")
    scale = target_rms / rms
    distances = []
    for atom, delta in zip(selected, displacements):
        value = parent_xyz[atom.label] + scale * delta
        atom.coordinates = list(value % 1.0)
        distances.append(np.linalg.norm((scale * delta) @ matrix))
    return float(np.sqrt(np.mean(np.square(distances)))), float(max(distances))


def candidate(source, target, parent_xyz, phase_name, element, target_rms, damping):
    project = G2.G2Project(str(source))
    project.save(str(target))
    clear_flags(project)
    for atom in phase(project, phase_name).atoms():
        if atom.element == element:
            atom.refinement_flags = "X"
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["max cyc"] = 1
    controls["shift factor"] = float(damping)
    project.refine()
    clear_flags(project)
    rms, maximum = project_rms(project, parent_xyz, phase_name, element, target_rms)
    project.save(str(target))
    controls["max cyc"] = 0
    project.refine()
    return rwp(project), rms, maximum


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--parent", type=Path, required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--element", required=True)
    parser.add_argument("--rms", type=float, required=True)
    parser.add_argument("--iterations", type=int, default=5)
    parser.add_argument("--damping", type=float, default=0.01)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    parent = G2.G2Project(str(args.parent))
    parent_xyz = {
        atom.label: np.asarray(atom.coordinates, float)
        for atom in phase(parent, args.phase).atoms()
        if atom.element == args.element
    }
    work = args.output.parent / (args.output.stem + "-projected-steps")
    work.mkdir(parents=True, exist_ok=True)
    current = args.input
    baseline = G2.G2Project(str(current))
    baseline.save(str(work / "baseline.gpx"))
    clear_flags(baseline)
    baseline.set_Controls("cycles", 0)
    baseline.refine()
    current = work / "baseline.gpx"
    best = rwp(baseline)
    print(f"baseline Rwp={best:.6f}", flush=True)
    for iteration in range(args.iterations):
        choices = []
        for factor in (1.0, 0.35, 0.1):
            target = work / f"iteration-{iteration:02d}-{factor:g}.gpx"
            value, rms, maximum = candidate(
                current,
                target,
                parent_xyz,
                args.phase,
                args.element,
                args.rms,
                args.damping * factor,
            )
            choices.append((value, target, rms, maximum))
        choice = min(choices, key=lambda row: row[0])
        if choice[0] >= best - 1e-5:
            print(f"reject best={choice[0]:.6f} current={best:.6f}", flush=True)
            break
        best, current = choice[0], choice[1]
        print(
            f"accept Rwp={best:.6f} rms={choice[2]:.6f} max={choice[3]:.6f}",
            flush=True,
        )
    final = G2.G2Project(str(current))
    final.save(str(args.output))
    print(f"final Rwp={best:.6f} project={args.output}", flush=True)


if __name__ == "__main__":
    main()
