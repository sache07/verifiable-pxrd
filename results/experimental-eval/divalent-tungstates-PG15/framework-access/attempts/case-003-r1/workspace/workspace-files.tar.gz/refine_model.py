#!/usr/bin/env python3
"""Build and refine a trial GSAS-II model for the CaCO3/WO3 reaction pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_observed(csv_path: Path, xye_path: Path) -> None:
    arr = np.genfromtxt(csv_path, delimiter=",", names=True)
    x = np.asarray(arr["two_theta_deg"], float)
    y = np.asarray(arr["intensity"], float)
    sig = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(xye_path, np.column_stack((x, y, sig)), fmt="%.8f %.8f %.8f")


def write_instrument(path: Path) -> None:
    path.write_text(
        "#GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.30;Polariz.:0.75;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:21.0;X:0.7745966692;Y:0.0;Z:0.0;SH/L:0.0223606798\n"
    )


def summary(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "label": label,
        "Rwp": hist.data["data"][0].get("wR"),
        "GOF": project.data.get("Covariance", {})
        .get("data", {})
        .get("Rvals", {})
        .get("GOF"),
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
            if key in inst
        },
        "sample": {
            key: sample[key][0] if isinstance(sample.get(key), list) else sample.get(key)
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.data["General"]["Cell"][1:8],
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": atom.coordinates,
                    "uiso": atom.uiso if atom.adp_flag == "I" else atom.ADP,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    try:
        result["mass_fractions"] = {
            key: list(value) for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    print(
        f"{label}: Rwp={result['Rwp']:.5f} GOF={result['GOF']:.5f} "
        f"fractions={{{', '.join(f'{k}: {v[0]:.5f}' for k, v in result.get('mass_fractions', {}).items())}}}",
        flush=True,
    )
    return result


def run_refinement(project: G2.G2Project, label: str) -> dict:
    project.set_Controls("cycles", 6)
    project.refine()
    return summary(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="2311041")
    parser.add_argument("--cawo4", default="7219229")
    parser.add_argument("--caco3", default="1547347")
    parser.add_argument("--wo3-path", type=Path)
    parser.add_argument("--cawo4-path", type=Path)
    parser.add_argument("--caco3-path", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--background", type=int, default=16)
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    xye = args.output.parent / f"{args.output.stem}.xye"
    inst_file = args.output.parent / f"{args.output.stem}.instprm"
    write_observed(Path("inputs/pattern.csv"), xye)
    write_instrument(inst_file)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(args.output))
    wo3_path = args.wo3_path or cod_path(args.wo3)
    cawo4_path = args.cawo4_path or cod_path(args.cawo4)
    caco3_path = args.caco3_path or cod_path(args.caco3)
    phases = [
        project.add_phase(str(wo3_path), phasename="WO3", fmthint="CIF"),
        project.add_phase(str(cawo4_path), phasename="CaWO4", fmthint="CIF"),
        project.add_phase(str(caco3_path), phasename="CaCO3", fmthint="CIF"),
    ]
    hist = project.add_powder_histogram(
        str(xye), str(inst_file), phases=phases, fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(hist.getdata("X")[0]), float(hist.getdata("X")[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background,
                "coeffs": [1000.0] + [0.0] * (args.background - 1),
                "refine": True,
            },
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})

    history = [run_refinement(project, "background_scales")]

    # Cell metrics and the common angular calibration establish peak positions.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    history.append(run_refinement(project, "cells_zero"))

    # A specimen-height term is required by the reflection geometry and is
    # distinguishable from Zero over this 10-100 degree range.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    history.append(run_refinement(project, "shift"))

    # Start each phase with an isotropic broadening model. Values are in um
    # and microstrain, respectively, in GSAS-II's native conventions.
    for phase, size in zip(phases, (0.5, 0.12, 0.5)):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][1][1] = size
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [True, False, False]
    history.append(run_refinement(project, "phase_broadening"))

    if args.quick:
        project.save(str(args.output))
        (args.output.with_suffix(".summary.json")).write_text(
            json.dumps(history, indent=2, default=float) + "\n"
        )
        return

    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    history.append(run_refinement(project, "instrument_profile"))

    project.save(str(args.output))
    (args.output.with_suffix(".summary.json")).write_text(
        json.dumps(history, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
