#!/usr/bin/env python3
"""Line-search saved heavy-atom coordinate updates with recalculated profiles."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2

from advanced_refine import metrics


BASE = Path("trials/clean-2311041.gpx")
TRIAL = Path("trials/heavy-base.gpx")
OUT = Path("trials/coord-scan")


def main() -> None:
    G2.SetPrintLevel("warn")
    base = G2.G2Project(str(BASE))
    trial = G2.G2Project(str(TRIAL))
    base_xyz = {
        (phase.name, atom.label): atom.coordinates
        for phase in base.phases()
        for atom in phase.atoms()
    }
    trial_xyz = {
        (phase.name, atom.label): atom.coordinates
        for phase in trial.phases()
        for atom in phase.atoms()
    }
    OUT.mkdir(parents=True, exist_ok=True)
    for t in [-0.25, -0.1, 0.0, 0.02, 0.05, 0.1, 0.2, 0.4, 0.7, 1.0]:
        project = G2.G2Project(str(TRIAL))
        for phase in project.phases():
            for atom in phase.atoms():
                key = (phase.name, atom.label)
                a = base_xyz[key]
                b = trial_xyz[key]
                atom.coordinates = [a[i] + t * (b[i] - a[i]) for i in range(3)]
                atom.refinement_flags = " "
        output = OUT / ("t_" + str(t).replace("-", "m").replace(".", "p") + ".gpx")
        project.save(str(output))
        project.set_Controls("cycles", 0)
        project.refine()
        result = metrics(project, f"t={t}")
        print(t, result["Rwp_percent"], flush=True)


if __name__ == "__main__":
    main()
