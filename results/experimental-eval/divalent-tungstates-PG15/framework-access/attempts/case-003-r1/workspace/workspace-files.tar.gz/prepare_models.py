#!/usr/bin/env python3
"""Create isotropic-ADP working copies of selected COD structures."""

from pathlib import Path

from pymatgen.io.cif import CifFile


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = Path("models")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def isotropic_copy(cod_id: str, name: str, uiso: float = 0.01) -> None:
    cif = CifFile.from_file(cod_path(cod_id))
    for block in cif.data.values():
        labels = block.data.get("_atom_site_label")
        if labels is None:
            continue
        for key in list(block.data):
            if key.lower().startswith("_atom_site_aniso_"):
                del block.data[key]
        block.data["_atom_site_adp_type"] = ["Uiso"] * len(labels)
        block.data["_atom_site_U_iso_or_equiv"] = [f"{uiso:.10f}"] * len(labels)
    OUT.mkdir(exist_ok=True)
    (OUT / name).write_text(str(cif) + "\n")


def main() -> None:
    isotropic_copy("2311041", "WO3-2311041-isotropic.cif")
    isotropic_copy("1528915", "WO3-1528915-isotropic.cif")
    isotropic_copy("2106293", "WO3-2106293-isotropic.cif")
    isotropic_copy("7219229", "CaWO4-7219229-isotropic.cif")
    isotropic_copy("1547347", "CaCO3-1547347-isotropic.cif")


if __name__ == "__main__":
    main()
