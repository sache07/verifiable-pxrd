#!/usr/bin/env python3
"""Damped, restart-stable refinement for the selected three-phase model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from advanced_refine import add_physical_bounds, metrics


def run(project: G2.G2Project, history: list[dict], label: str, cycles: int, damping: float) -> None:
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = int(cycles)
    controls["shift factor"] = float(damping)
    controls["min dM/M"] = 1e-5
    project.refine()
    history.append(metrics(project, label))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--heavy", action="store_true")
    parser.add_argument("--restarts", type=int, default=3)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(args.output))
    project.set_Frozen()
    project.index_ids()
    add_physical_bounds(project)

    # The clean input CIFs already contain phase-wise isotropic Uiso values.
    # Hold them and all coordinates during stabilization of the profile model.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "

    history = [metrics(project, "input")]
    for i in range(args.restarts):
        run(project, history, f"nuisance_{i + 1}", cycles=12, damping=0.25)

    if args.heavy:
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = "X" if atom.element == "W" else " "
        for i in range(args.restarts):
            run(project, history, f"heavy_{i + 1}", cycles=12, damping=0.08)

    # A zero-cycle calculation forces the stored profile to be regenerated
    # from the final parameter state, which also checks restart consistency.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    run(project, history, "recalculated", cycles=0, damping=0.25)
    project.save(str(args.output))
    args.output.with_suffix(".stable.json").write_text(
        json.dumps(history, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
