#!/usr/bin/env python3
"""Apply one controlled GSAS-II refinement branch to an existing project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from advanced_refine import metrics, refine, set_bound


def axis(value: str) -> list[int]:
    parts = value.replace(",", " ").split()
    if len(parts) != 3:
        raise argparse.ArgumentTypeError("axis needs three comma-separated integers")
    result = [int(v) for v in parts]
    if not any(result):
        raise argparse.ArgumentTypeError("axis cannot be zero")
    return result


def phase_by_name(project: G2.G2Project, name: str):
    for phase in project.phases():
        if phase.name == name:
            return phase
    raise ValueError(f"phase not found: {name}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=5)
    parser.add_argument("--po-phase", choices=["WO3", "CaWO4", "CaCO3"])
    parser.add_argument("--po-axis", type=axis)
    parser.add_argument("--uniaxial-phase", choices=["WO3", "CaWO4", "CaCO3"])
    parser.add_argument("--uniaxial-axis", type=axis)
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--instrument", nargs="*", choices=["U", "W", "X", "SH/L", "Polariz."])
    parser.add_argument("--oxygen-phase", choices=["WO3", "CaWO4", "CaCO3"])
    parser.add_argument("--adp-phase", choices=["WO3", "CaWO4", "CaCO3"])
    parser.add_argument("--background", type=int)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(args.output))
    project.index_ids()
    hist = project.histogram(0)
    # Branch tests vary only the requested structural term. Coordinates from
    # the parent refinement are retained but held to prevent an unrelated
    # underdetermined coordinate step from dominating the comparison.
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key, value in hist.data["Sample Parameters"].items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    history = [metrics(project, "input")]

    label_parts = []
    if args.po_phase:
        if args.po_axis is None:
            raise ValueError("--po-axis is required with --po-phase")
        phase = phase_by_name(project, args.po_phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.01
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(args.po_axis)
        set_bound(project, f"{phase.id}:0:MD", 0.7, 1.4)
        label_parts.append(f"PO-{args.po_phase}-{''.join(map(str, args.po_axis))}")

    if args.uniaxial_phase:
        if args.uniaxial_axis is None:
            raise ValueError("--uniaxial-axis is required with --uniaxial-phase")
        phase = phase_by_name(project, args.uniaxial_phase)
        hap = phase.data["Histograms"][hist.name]
        value = float(hap["Mustrain"][1][0])
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = value
        hap["Mustrain"][1][1] = value * 1.05
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = list(args.uniaxial_axis)
        set_bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{phase.id}:0:Mustrain;a", 0.0, 32000.0)
        label_parts.append(f"strain-{args.uniaxial_phase}-{''.join(map(str, args.uniaxial_axis))}")

    if args.roughness:
        hist.SampleParameters["SurfRoughA"] = [0.3, True]
        hist.SampleParameters["SurfRoughB"] = [0.08, True]
        set_bound(project, ":0:SurfRoughA", 0.0, 0.6)
        set_bound(project, ":0:SurfRoughB", 0.0, 0.5)
        label_parts.append("roughness")

    if args.instrument is not None:
        hist.set_refinements({"Instrument Parameters": list(args.instrument)})
        label_parts.append("instrument-" + "-".join(args.instrument))

    if args.oxygen_phase:
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = " "
        phase = phase_by_name(project, args.oxygen_phase)
        for atom in phase.atoms():
            if atom.element == "O":
                atom.refinement_flags = "X"
        label_parts.append("oxygen-" + args.oxygen_phase)

    if args.adp_phase:
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = atom.refinement_flags.replace("U", "")
        phase = phase_by_name(project, args.adp_phase)
        for i, atom in enumerate(phase.atoms()):
            atom.refinement_flags = atom.refinement_flags.strip() + "U"
            set_bound(project, f"{phase.id}::AUiso:{i}", 0.003, 0.020)
        label_parts.append("adp-" + args.adp_phase)

    if args.background:
        old = hist.data["Background"][0]
        coeffs = list(old[3:])
        if args.background > len(coeffs):
            coeffs += [0.0] * (args.background - len(coeffs))
        hist.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "no. coeffs": args.background,
                    "coeffs": coeffs[: args.background],
                    "refine": True,
                }
            }
        )
        label_parts.append(f"background-{args.background}")

    label = "+".join(label_parts) or "branch"
    refine(project, history, label, args.cycles)
    # Store a profile regenerated from the final parameter values. GSAS-II's
    # profile immediately after the last least-squares update still reflects
    # the pre-update state, which is unsuitable for replay comparisons.
    refine(project, history, label + "-recalculated", 0)
    project.save(str(args.output))
    args.output.with_suffix(".branch.json").write_text(
        json.dumps(history, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
