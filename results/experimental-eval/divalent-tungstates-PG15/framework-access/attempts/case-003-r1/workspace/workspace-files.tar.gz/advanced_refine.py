#!/usr/bin/env python3
"""Continue a trial refinement with the physical model used by the generator."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def metrics(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    y = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    weight = np.asarray(hist.getdata("Yweight"), float)
    rwp = 100.0 * np.sqrt(np.sum(weight * (y - calc) ** 2) / np.sum(weight * y**2))
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    try:
        fractions = {
            key: [float(v) for v in value]
            for key, value in hist.ComputeMassFracs().items()
        }
    except Exception:
        fractions = {}
    result = {
        "label": label,
        "Rwp_percent": float(rwp),
        "GOF": rvals.get("GOF"),
        "weighted_residual_rms": float(np.sqrt(np.mean(weight * (y - calc) ** 2))),
        "mass_fractions": fractions,
        "instrument": {
            key: float(hist.data["Instrument Parameters"][0][key][1])
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
            if key in hist.data["Instrument Parameters"][0]
        },
        "sample": {
            key: float(hist.data["Sample Parameters"][key][0])
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": {},
        "frozen": project.get_Frozen(),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:8]],
            "scale": float(hap["Scale"][0]),
            "size": [hap["Size"][0], [float(v) for v in hap["Size"][1]]],
            "mustrain": [hap["Mustrain"][0], [float(v) for v in hap["Mustrain"][1]], list(hap["Mustrain"][3])],
            "preferred_orientation": [
                hap["Pref.Ori."][0],
                float(hap["Pref.Ori."][1]),
                list(hap["Pref.Ori."][3]),
            ],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": [float(v) for v in atom.coordinates],
                    "Uiso": float(atom.uiso) if atom.adp_flag == "I" else None,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    print(
        f"{label}: Rwp={rwp:.5f}% wrms={result['weighted_residual_rms']:.5f} "
        f"fractions={{{', '.join(f'{k}: {v[0]:.5f}' for k, v in fractions.items())}}}",
        flush=True,
    )
    return result


def refine(project: G2.G2Project, history: list[dict], label: str, cycles: int = 5) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    history.append(metrics(project, label))


def set_bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable)
    project.set_Controls("parmMax", high, variable)


def make_isotropic_adps(project: G2.G2Project, initial: float = 0.01) -> None:
    """Match the generator, which assigns one isotropic U value per phase."""
    project.index_ids()
    for phase in project.phases():
        _, _, _, cia = phase.data["General"]["AtomPtrs"]
        for atom in phase.atoms():
            atom.data[cia] = "I"
            atom.data[cia + 1] = initial
            atom.refinement_flags = " "
        variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        for variable in variables:
            set_bound(project, variable, 0.003, 0.020)


def add_physical_bounds(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    bounds = {
        ":0:Zero": (-0.5, 0.5),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.1),
        ":0:Polariz.": (0.5, 1.0),
        ":0:SurfRoughA": (0.0, 0.6),
        ":0:SurfRoughB": (0.0, 0.5),
    }
    for variable, (low, high) in bounds.items():
        set_bound(project, variable, low, high)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][1][0] = float(np.clip(hap["Size"][1][0], 0.04, 1.5))
        hap["Mustrain"][1][0] = float(np.clip(hap["Mustrain"][1][0], 0.0, 8000.0))
        set_bound(project, f"{phase.id}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{phase.id}:0:MD", 0.7, 1.4)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--coordinates", action="store_true")
    parser.add_argument("--heavy-only", action="store_true")
    parser.add_argument("--instrument-u", action="store_true")
    parser.add_argument("--skip-instrument", action="store_true")
    parser.add_argument("--adps", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.input))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(args.output))
    project.set_Frozen()
    make_isotropic_adps(project)
    add_physical_bounds(project)
    history = [metrics(project, "input")]

    # Re-establish scales and background after replacing source ADPs by the
    # phase-wise isotropic values used in the measurement model.
    refine(project, history, "isotropic_adps", 6)

    hist = project.histogram(0)
    if not args.skip_instrument:
        profile_keys = ["W", "X", "SH/L", "Polariz."]
        if args.instrument_u:
            profile_keys.insert(0, "U")
        hist.set_refinements({"Instrument Parameters": profile_keys})
        refine(project, history, "instrument", 6)

    if args.roughness:
        hist.SampleParameters["SurfRoughA"] = [0.3, False]
        hist.SampleParameters["SurfRoughB"] = [0.08, False]
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        refine(project, history, "surface_roughness", 6)

    if args.coordinates:
        # Heavy-atom shifts dominate first; then allow the oxygen framework to
        # follow from a substantially better-conditioned starting model.
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = "X" if atom.element == "W" else " "
        refine(project, history, "heavy_atom_coordinates", 6)
        if not args.heavy_only:
            for phase in project.phases():
                for atom in phase.atoms():
                    atom.refinement_flags = "X"
            refine(project, history, "all_coordinates", 8)

    if args.adps:
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = atom.refinement_flags.strip() + "U"
        refine(project, history, "atomic_displacements", 6)

    project.save(str(args.output))
    args.output.with_suffix(".advanced.json").write_text(
        json.dumps(history, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
