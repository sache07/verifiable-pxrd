#!/usr/bin/env python3
"""Create the required, mutually consistent deliverables from one GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from robust_optimize import clear_flags


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials" / "best-stable.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "WO3": {
        "name": "monoclinic tungsten(VI) oxide",
        "formula": "WO3",
        "cif_path": "phase_WO3.cif",
        "reference": "COD 2311041",
    },
    "CaWO4": {
        "name": "scheelite calcium tungstate",
        "formula": "CaWO4",
        "cif_path": "phase_CaWO4.cif",
        "reference": "COD 7219229",
    },
    "CaCO3": {
        "name": "calcite",
        "formula": "CaCO3",
        "cif_path": "phase_CaCO3.cif",
        "reference": "COD 1547347",
    },
}


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE))
    clear_flags(project)
    for key in ("Hist", "HAP", "Phase", "Global"):
        project.get_Constraints(key)[:] = []
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.data["Covariance"]["data"] = {}
    project.save(str(FINAL))

    # Force the stored curve to be calculated from the final serialized values.
    project.set_Controls("cycles", 0)
    project.refine()
    clear_flags(project)
    project.data["Covariance"]["data"] = {}
    project.save(str(FINAL))

    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"), float)
    observed = np.asarray(hist.getdata("Yobs"), float)
    calculated = np.asarray(hist.getdata("Ycalc"), float)
    weights = np.asarray(hist.getdata("Yweight"), float)
    public = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if not np.allclose(x, public[:, 0], rtol=0, atol=1e-7):
        raise RuntimeError("final project grid differs from pattern.csv")
    if not np.allclose(observed, public[:, 1], rtol=0, atol=1e-5):
        raise RuntimeError("final project observations differ from pattern.csv")
    if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("final calculated profile is invalid")

    difference = observed - calculated
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100 * np.sqrt(chi_square / denominator))
    rp = float(100 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    wrms = float(np.sqrt(np.mean(weights * difference**2)))

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        writer.writerows(zip(x, observed, calculated, difference))

    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    fractions = np.asarray(masses, float) / np.sum(masses)

    records = []
    for phase, fraction in zip(project.phases(), fractions):
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif_path"]))
        cell = phase.data["General"]["Cell"][1:8]
        records.append(
            {
                "name": info["name"],
                "phase_id": phase.name,
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": info["cif_path"],
                "weight_fraction": float(fraction),
                "cell": {
                    "a_A": float(cell[0]),
                    "b_A": float(cell[1]),
                    "c_A": float(cell[2]),
                    "alpha_deg": float(cell[3]),
                    "beta_deg": float(cell[4]),
                    "gamma_deg": float(cell[5]),
                    "volume_A3": float(cell[6]),
                },
                "starting_reference": info["reference"],
            }
        )

    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "schema_version": 1,
        "refinement_histogram": hist.name,
        "phases": records,
        "phase_fraction_basis": "GSAS-II HAP scale multiplied by unit-cell mass, normalized over modeled crystalline phases",
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "weighted_chi_square": chi_square,
            "weighted_residual_rms": wrms,
            "data_points": int(len(x)),
            "difference_convention": "observed - calculated",
        },
        "calibration": {
            "zero_offset_deg": float(inst["Zero"][1]),
            "specimen_shift_um": float(sample["Shift"][0]),
            "wavelength_Kalpha1_A": float(inst["Lam1"][1]),
            "wavelength_Kalpha2_A": float(inst["Lam2"][1]),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"Rwp_percent": rwp, "Rp_percent": rp, "fractions": fractions.tolist()}, indent=2))


if __name__ == "__main__":
    main()
