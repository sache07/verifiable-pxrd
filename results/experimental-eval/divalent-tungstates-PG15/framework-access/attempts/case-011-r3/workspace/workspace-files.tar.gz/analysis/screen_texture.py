#!/usr/bin/env python3
"""Screen the allowed March-Dollase axes with bounded profile parameters."""

from pathlib import Path
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis/run1/03_cells.gpx"
OUT = ROOT / "analysis/texture_screen"
OUT.mkdir(parents=True, exist_ok=True)


def weighted_rwp(hist):
    a = hist.data["data"][1]
    return 100.0 * np.sqrt(np.sum(a[2] * a[5] ** 2) / np.sum(a[2] * a[1] ** 2))


def set_limit(project, variable, low, high):
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def fit(axis_name):
    axis = None if axis_name == "none" else [int(v) for v in axis_name]
    dest = OUT / f"mn_{axis_name}.gpx"
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(dest)
    project.set_Controls("cycles", 10)
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    # Avoid the exact zero/shift and X/size degeneracies in this screen.
    sample["Shift"][1] = False
    inst["X"][1] = 1.0
    inst["X"][2] = False
    for key, value in {"U": 15.0, "W": 10.0, "SH/L": 0.03, "Polariz.": 0.8}.items():
        inst[key][1] = value
        inst[key][2] = True

    phases = project.phases()
    for idx, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.12
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        if idx == 1 and axis is not None:
            hap["Pref.Ori."][3] = axis
            hap["Pref.Ori."][1] = 0.9
            hap["Pref.Ori."][2] = True

    for var, lo, hi in [
        (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0),
        (":0:SH/L", 0.005, 0.1), (":0:Polariz.", 0.5, 1.0),
        ("0:0:Size;i", 0.04, 1.5), ("1:0:Size;i", 0.04, 1.5),
        ("1:0:MD", 0.7, 1.4),
    ]:
        set_limit(project, var, lo, hi)
    project.refine(makeBack=False)
    print(axis_name, "profile", weighted_rwp(hist), flush=True)

    # Add phase-specific isotropic strain only after the main widths are stable.
    for idx, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][2][0] = True
        set_limit(project, f"{idx}:0:Mustrain;i", 0.0, 10000.0)
    project.refine(makeBack=False)
    rwp = weighted_rwp(hist)
    masses = np.array([
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in phases
    ])
    fractions = masses / masses.sum()
    print(axis_name, "strain", rwp, "fractions", fractions.tolist(), flush=True)
    print(
        axis_name,
        "inst", {k: inst[k][1] for k in ["Zero", "Polariz.", "U", "W", "X", "SH/L"]},
        "shift", sample["Shift"][0],
        flush=True,
    )
    for p in phases:
        hap = p.data["Histograms"][hist.name]
        print(axis_name, p.name, "size", hap["Size"][1][0], "strain", hap["Mustrain"][1][0], "MD", hap["Pref.Ori."][1:4], flush=True)
    project.save(dest)


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    names = sys.argv[1:] or ["none", "001", "100", "010", "110", "111"]
    for name in names:
        fit(name)
