#!/usr/bin/env python3
"""Continue the converged two-phase fit while screening WO3 texture axes."""

from pathlib import Path
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis/texture_screen/mn_110.gpx"
OUT = ROOT / "analysis/wo3_texture_screen"
OUT.mkdir(parents=True, exist_ok=True)


def rwp(hist):
    a = hist.data["data"][1]
    return 100 * np.sqrt(np.sum(a[2] * a[5] ** 2) / np.sum(a[2] * a[1] ** 2))


G2.SetPrintLevel("error")
for name in ["001", "100", "010", "110", "111"]:
    axis = [int(v) for v in name]
    fn = OUT / f"wo3_{name}.gpx"
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(fn)
    project.set_Controls("cycles", 15)
    hist = project.histograms()[0]
    wo3 = project.phases()[0]
    hap = wo3.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 0.9
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis
    project.set_Controls("parmMin", 0.7, variable="0:0:MD")
    project.set_Controls("parmMax", 1.4, variable="0:0:MD")
    project.refine(makeBack=False)
    print(name, rwp(hist), "MD", hap["Pref.Ori."][1], flush=True)
    project.save(fn)
