"""Export replay-verified final artifacts from the selected GSAS-II project."""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SOURCE_PROJECT = ROOT / "analysis" / "final_candidate_u_staged.gpx"
REPLAY_DIR = ROOT / "analysis" / "replay_check"
EXPECTED_PROJECT_SHA256 = (
    "4c70ec02bdb17037cb1812df1e7872dc4844e06416ca24a35cc4c1ce0af79c91"
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    replay = json.loads((REPLAY_DIR / "replay.json").read_text())
    if replay.get("status") != "replayed" or replay.get("profile_review_flags"):
        raise RuntimeError("The selected project did not pass clean independent replay")
    if sha256(SOURCE_PROJECT) != EXPECTED_PROJECT_SHA256:
        raise RuntimeError("Selected project changed after independent replay")
    if replay.get("project_sha256") != EXPECTED_PROJECT_SHA256:
        raise RuntimeError("Replay was performed on a different project")

    shutil.copy2(SOURCE_PROJECT, ROOT / "final.gpx")
    shutil.copy2(REPLAY_DIR / "phase_0.cif", ROOT / "WO3_monoclinic.cif")
    shutil.copy2(REPLAY_DIR / "phase_1.cif", ROOT / "MnO2_pyrolusite.cif")

    with np.load(REPLAY_DIR / "prediction.npz", allow_pickle=False) as archive:
        x = archive["x"]
        observed = archive["observed"]
        calculated = archive["predicted"]
    if np.any(~np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("Invalid independently regenerated profile")
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=("%.8f", "%.1f", "%.10f", "%.10f"),
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    print(
        json.dumps(
            {
                "project_sha256": sha256(ROOT / "final.gpx"),
                "n_points": len(x),
                "chi_square": chi_square,
                "rwp_percent": rwp,
                "rp_percent": rp,
                "minimum_calculated_counts": float(np.min(calculated)),
                "phase_fractions": {
                    phase["name"]: phase["weight_fraction"]
                    for phase in replay["phases"]
                },
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
