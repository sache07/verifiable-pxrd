#!/usr/bin/env python3
"""Build and stage a two-phase GSAS-II refinement for the MnO2/WO3 scan.

This is an exploratory refinement driver.  It always starts from the two COD
models selected by peak matching and writes checkpoints under analysis/run1.
"""

from pathlib import Path
import math
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "analysis" / "run1"
RUN.mkdir(parents=True, exist_ok=True)

COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
WO3 = COD / "2/31/10/2311041.cif"
MNO2 = COD / "1/51/41/1514110.cif"


def prepare_inputs():
    raw = np.genfromtxt(ROOT / "inputs/pattern.csv", delimiter=",", names=True)
    x = np.asarray(raw["two_theta_deg"], float)
    y = np.asarray(raw["intensity"], float)
    xye = RUN / "pattern.xye"
    with xye.open("w") as stream:
        stream.write("# two_theta intensity sigma\n")
        for xx, yy in zip(x, y):
            stream.write(f"{xx:.8f} {yy:.8f} {math.sqrt(max(yy, 1.0)):.10f}\n")
    inst = RUN / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.25;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def rvals(project, label):
    cov = project.data.get("Covariance", {}).get("data", {})
    vals = cov.get("Rvals", {})
    hist = project.histograms()[0]
    residuals = hist.data.get("Residuals", {})
    print(
        label,
        "Rwp=", vals.get("Rwp", residuals.get("Rwp")),
        "GOF=", vals.get("GOF"),
        "chisq=", vals.get("chisq"),
        "Nvars=", len(cov.get("varyList", [])),
    )
    print("  vary:", cov.get("varyList", []))
    print("  values:", cov.get("variables", []))
    print("  inst:", hist.data["Instrument Parameters"][0])
    print("  sample:", hist.data["Sample Parameters"])
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            "  phase", phase.name,
            "cell", phase.data["General"]["Cell"][1:7],
            "scale", hap["Scale"],
            "size", hap["Size"][:4],
            "mustrain", hap["Mustrain"][:4],
            "PO", hap["Pref.Ori."][:4],
        )


def refine(project, label):
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save(RUN / f"{label}.gpx")
    rvals(project, label)


def main():
    G2.SetPrintLevel("warn")
    xye, inst = prepare_inputs()
    project = G2.G2Project(newgpx=str(RUN / "working.gpx"))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.data["Sample Parameters"].update(
        {
            "Type": "Bragg-Brentano",
            "Gonio. radius": 200.0,
            "Shift": [0.0, False],
            "Transparency": [0.0, False],
            "SurfRoughA": [0.0, False],
            "SurfRoughB": [0.0, False],
        }
    )
    # Twelve smooth terms capture the broad low-angle continuum without peak terms.
    hist.set_refinements(
        {
            "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1100.0] + [0.0] * 11,
                "refine": True,
            },
        }
    )
    hist.SampleParameters["Scale"] = [1.0, False]

    wo3 = project.add_phase(str(WO3), phasename="WO3_monoclinic", histograms=[hist], fmthint="CIF")
    mno2 = project.add_phase(str(MNO2), phasename="MnO2_pyrolusite", histograms=[hist], fmthint="CIF")
    phases = [wo3, mno2]
    for phase in phases:
        # The generator uses one positive isotropic Uiso per phase.
        for atom in phase.atoms():
            atom.uiso = 0.01
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Size"][1][1] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])

    # A linear/background fit first establishes stable positive phase scales.
    refine(project, "01_scale_background")

    # Place all peaks with a common zero before allowing lattice changes.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "02_zero")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "03_cells")

    # Separate the constant zero from the cosine(theta) specimen displacement.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "04_shift")

    # Common instrumental width/asymmetry and phase-specific size.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    for phase in phases:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.5, "refine": True}},
            histograms=[hist],
        )
    refine(project, "05_profile_size")

    for phase in phases:
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}},
            histograms=[hist],
        )
    refine(project, "06_microstrain")

    # Refine symmetry-constrained coordinates and a common (per-phase) starting Uiso.
    for phase in phases:
        phase.set_refinements({"Atoms": {"all": "X"}})
    refine(project, "07_coordinates")

    # Keep the exploratory final state in an easy-to-inspect path.
    project.save(RUN / "initial_final.gpx")


if __name__ == "__main__":
    main()
