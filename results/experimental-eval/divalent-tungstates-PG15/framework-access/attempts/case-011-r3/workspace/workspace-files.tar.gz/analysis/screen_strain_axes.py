#!/usr/bin/env python3
"""Screen generator-allowed uniaxial microstrain axes for both phases."""

from pathlib import Path
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parents[1]
MODELS = ROOT / "analysis/model_screen"
OUT = ROOT / "analysis/strain_screen"
OUT.mkdir(parents=True, exist_ok=True)


def rwp(hist):
    a = hist.data["data"][1]
    return 100 * np.sqrt(np.sum(a[2] * a[5] ** 2) / np.sum(a[2] * a[1] ** 2))


G2.SetPrintLevel("error")
for record_id in ["2311041", "2106293"]:
    for phase_index in [0, 1]:
        for axis_name in ["001", "100", "010"]:
            axis = [int(v) for v in axis_name]
            src = MODELS / f"wo3_{record_id}.gpx"
            fn = OUT / f"{record_id}_p{phase_index}_{axis_name}.gpx"
            project = G2.G2Project(gpxfile=str(src))
            project.save(fn)
            project.set_Controls("cycles", 15)
            hist = project.histograms()[0]
            phase = project.phases()[phase_index]
            hap = phase.data["Histograms"][hist.name]
            iso = max(1.0, float(hap["Mustrain"][1][0]))
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][0] = iso
            hap["Mustrain"][1][1] = min(10000.0, 1.5 * iso)
            hap["Mustrain"][2] = [True, True, False]
            hap["Mustrain"][3] = axis
            for suffix in ["i", "a"]:
                project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;{suffix}")
                project.set_Controls("parmMax", 10000.0, variable=f"{phase_index}:0:Mustrain;{suffix}")
            project.refine(makeBack=False)
            print(
                record_id, phase_index, axis_name, rwp(hist),
                "strain", hap["Mustrain"][1][:2], flush=True
            )
            project.save(fn)
