#!/usr/bin/env python3
"""Compare plausible WO3 reference structures under the same bounded fit."""

from pathlib import Path
import os
import numpy as np
from GSASII import GSASIIscriptable as G2

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "analysis/model_screen"
RUN.mkdir(parents=True, exist_ok=True)
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
MNO2 = COD / "1/51/41/1514110.cif"
IDS = ["2311041", "1528915", "2106293", "1010618", "2107312", "1563541"]


def cif_path(record_id):
    return COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def rwp(hist):
    a = hist.data["data"][1]
    return 100 * np.sqrt(np.sum(a[2] * a[5] ** 2) / np.sum(a[2] * a[1] ** 2))


def bounds(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def fit(record_id):
    fn = RUN / f"wo3_{record_id}.gpx"
    project = G2.G2Project(newgpx=str(fn))
    hist = project.add_powder_histogram(
        str(ROOT / "analysis/run1/pattern.xye"),
        str(ROOT / "analysis/run1/instrument.instprm"), fmthint="xye"
    )
    hist.data["Sample Parameters"].update({
        "Type": "Bragg-Brentano", "Gonio. radius": 200.0,
        "Shift": [0.0, False], "Transparency": [0.0, False],
        "SurfRoughA": [0.0, False], "SurfRoughB": [0.0, False],
    })
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements({
        "Limits": [9.90343322, 100.09488522],
        "Background": {"type": "chebyschev-1", "no. coeffs": 12,
                       "coeffs": [1100.0] + [0.0] * 11, "refine": True},
    })
    wo3 = project.add_phase(str(cif_path(record_id)), phasename=f"WO3_{record_id}", histograms=[hist], fmthint="CIF")
    mno2 = project.add_phase(str(MNO2), phasename="MnO2_pyrolusite", histograms=[hist], fmthint="CIF")
    phases = [wo3, mno2]
    for phase in phases:
        for atom in phase.atoms():
            atom.uiso = 0.01
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"; hap["Size"][1][0] = 0.12; hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"; hap["Mustrain"][1][0] = 500.0; hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"; hap["Pref.Ori."][1] = 1.0; hap["Pref.Ori."][2] = False
        hap["Scale"][1] = True
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)

    hist.data["Instrument Parameters"][0]["Zero"][2] = True
    for phase in phases: phase.data["General"]["Cell"][0] = True
    project.refine(makeBack=False)

    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 15.0, "W": 10.0, "X": 1.0, "SH/L": 0.03, "Polariz.": 0.8}.items():
        inst[key][1] = value
    for key in ["U", "W", "SH/L", "Polariz."]: inst[key][2] = True
    inst["X"][2] = False
    for i, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
    mno2.data["Histograms"][hist.name]["Pref.Ori."][1] = 0.9
    mno2.data["Histograms"][hist.name]["Pref.Ori."][2] = True
    mno2.data["Histograms"][hist.name]["Pref.Ori."][3] = [1, 1, 0]
    for var, low, high in [
        (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0),
        (":0:SH/L", 0.005, 0.1), (":0:Polariz.", 0.5, 1.0),
        ("0:0:Size;i", 0.04, 1.5), ("1:0:Size;i", 0.04, 1.5),
        ("0:0:Mustrain;i", 0.0, 10000.0), ("1:0:Mustrain;i", 0.0, 10000.0),
        ("1:0:MD", 0.7, 1.4),
    ]: bounds(project, var, low, high)
    for _ in range(2): project.refine(makeBack=False)
    masses = np.array([p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in phases])
    print(record_id, "Rwp", rwp(hist), "fractions", (masses/masses.sum()).tolist(), flush=True)
    project.save(fn)


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    for record_id in IDS:
        fit(record_id)
