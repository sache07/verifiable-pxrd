#!/usr/bin/env python3
"""Build and stage-refine a two-phase GSAS-II model for the supplied scan."""

from pathlib import Path
import argparse
import json
import math
import sys

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(record_id):
    return COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def prepare_inputs(work):
    work.mkdir(parents=True, exist_ok=True)
    raw = np.genfromtxt(ROOT / "inputs/pattern.csv", delimiter=",", names=True)
    x = np.asarray(raw["two_theta_deg"], float)
    y = np.asarray(raw["intensity"], float)
    np.savetxt(work / "pattern.xye", np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.8f %.8g %.8g")
    (work / "instrument.instprm").write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha initial profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:21.0;X:0.7745966692;Y:0.0;Z:0.0;SH/L:0.0223606798\n"
    )
    # Smooth lower-envelope estimate, represented in the same normalized
    # Chebyshev coordinate used by the saved histogram limits.
    baseline = percentile_filter(y, percentile=20, size=401, mode="nearest")
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    coeffs = np.polynomial.chebyshev.chebfit(t, baseline, 11)
    return x, y, coeffs


def set_initial_hap(phase, hist, scale, size=0.3, strain=500.0):
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(scale), False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = float(size)
    hap["Size"][1][1] = float(size)
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = float(strain)
    hap["Mustrain"][1][1] = float(strain)
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    hap["Extinction"] = [0.0, False]


def summary(project, label):
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sp = hist.SampleParameters
    result = {
        "stage": label,
        "rwp": hist.get_wR(),
        "instrument": {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.") if k in inst},
        "sample": {k: sp[k][0] if isinstance(sp.get(k), list) else sp.get(k) for k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"][1],
            "mustrain": hap["Mustrain"][1],
            "po": hap["Pref.Ori."][1:4],
        }
    print(json.dumps(result, indent=2, default=float), flush=True)
    return result


def refine(project, label, cycles=8):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    return summary(project, label)


def build(args):
    G2.SetPrintLevel("warn")
    work = ROOT / args.work
    x, y, bg = prepare_inputs(work)
    project = G2.G2Project(newgpx=str(work / "trial.gpx"))
    hist = project.add_powder_histogram(str(work / "pattern.xye"), str(work / "instrument.instprm"), fmthint="xye")
    hist.data["data"][1][0] = x.copy()
    hist.data["data"][1][1] = y.copy()
    hist.data["data"][1][2] = 1.0 / np.maximum(y, 1.0)
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])],
                          "Background": {"type": "chebyschev-1", "no. coeffs": len(bg),
                                         "coeffs": bg.tolist(), "refine": False}})
    ni = project.add_phase(str(ROOT / "NiWO4_start.cif"), phasename="NiWO4", histograms=[hist], fmthint="CIF")
    wo = project.add_phase(str(cod_path(args.wo3)), phasename=f"WO3_{args.wo3}", histograms=[hist], fmthint="CIF")
    set_initial_hap(ni, hist, 1.0, size=0.25, strain=500.0)
    set_initial_hap(wo, hist, 0.3, size=0.25, strain=500.0)
    project.save()
    # The synthetic lab's stated support is also a defensible physical support
    # for refinement. GSAS-II freezes a variable if an iteration crosses one
    # of these limits, preventing negative widths and stale boundary solutions.
    bounds = {
        ":0:Zero": (-0.25, 0.25), ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0), ":0:W": (2.0, 40.0), ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.1), ":0:Polariz.": (0.5, 1.0),
    }
    for phase in project.phases():
        pid = phase.id
        bounds[f"{pid}:0:Size;i"] = (0.04, 1.5)
        bounds[f"{pid}:0:Mustrain;i"] = (0.0, 8000.0)
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    stages = [summary(project, "created")]

    # First obtain a stable intensity/background solution with structural and
    # profile variables fixed.
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])
    stages.append(refine(project, "background_scales", 8))

    # Cell and shared angular corrections align the two independent line sets.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]})
    stages.append(refine(project, "cells_zero_shift", 12))

    # Refine the session-level instrumental line shape first.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    stages.append(refine(project, "instrument_profile", 12))

    # Phase-specific broadening is part of the generating specimen model.
    if not args.fixed_profiles:
        for phase in project.phases():
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True},
                                       "Mustrain": {"type": "isotropic", "refine": True}}, [hist])
        stages.append(refine(project, "phase_profiles", 15))

    # Polarization changes relative peak intensities smoothly with angle.
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    stages.append(refine(project, "polarization", 12))

    (work / "stages.json").write_text(json.dumps(stages, indent=2, allow_nan=False) + "\n")
    project.save()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--work", default=".tmp/trial")
    parser.add_argument("--fixed-profiles", action="store_true")
    build(parser.parse_args())
