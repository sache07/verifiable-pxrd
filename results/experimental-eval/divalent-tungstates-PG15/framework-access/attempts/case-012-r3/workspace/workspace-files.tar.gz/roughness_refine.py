#!/usr/bin/env python3
"""Refine the two Suortti surface-roughness parameters from a chosen start."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--a", type=float, required=True)
parser.add_argument("--b", type=float, required=True)
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
G2.SetPrintLevel("warn")
out = Path(args.output).resolve(); out.parent.mkdir(parents=True, exist_ok=True)
p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out))
h = p.histogram(0)
h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
                     "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
h.SampleParameters["SurfRoughA"] = [args.a, True]
h.SampleParameters["SurfRoughB"] = [args.b, True]
h.set_refinements({"Background": True})
for ph in p.phases():
    ph.clear_refinements({"Cell": True})
    for atom in ph.atoms(): atom.refinement_flags = ""
    ph.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}, [h])
    ph.set_HAP_refinements({"Scale": True}, [h])
p.save(); p.set_Controls("cycles", args.cycles); p.refine(); p.save()
print(json.dumps({"rwp_native": h.get_wR(), "start": [args.a, args.b],
                  "SurfRoughA": h.SampleParameters["SurfRoughA"][0],
                  "SurfRoughB": h.SampleParameters["SurfRoughB"][0]}, indent=2))
