#!/usr/bin/env python3
"""Re-optimize global cell/instrument/sample terms with phase models fixed."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--cycles", type=int, default=18)
args = parser.parse_args()
G2.SetPrintLevel("warn")
out = Path(args.output).resolve(); out.parent.mkdir(parents=True, exist_ok=True)
p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out)); h = p.histogram(0)
p.set_Frozen()
h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
                     "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
h.set_refinements({"Background": True,
                   "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
                   "Sample Parameters": ["Shift"]})
for ph in p.phases():
    for atom in ph.atoms(): atom.refinement_flags = ""
    ph.set_refinements({"Cell": True})
    ph.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}, [h])
    ph.set_HAP_refinements({"Scale": True}, [h])
p.save(); p.set_Controls("cycles", args.cycles); p.refine(); p.save()
report = {"rwp_native": h.get_wR(), "frozen": p.get_Frozen(),
          "instrument": {k: h.InstrumentParameters[k][1] for k in ["Zero", "U", "W", "X", "SH/L", "Polariz."]},
          "shift": h.SampleParameters["Shift"][0],
          "cells": {ph.name: ph.get_cell() for ph in p.phases()}}
print(json.dumps(report, indent=2))
