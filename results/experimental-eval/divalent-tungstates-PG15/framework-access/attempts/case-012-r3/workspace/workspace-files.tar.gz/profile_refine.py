#!/usr/bin/env python3
"""Refine one phase-specific isotropic broadening parameter."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--phase", choices=["ni", "wo3"], required=True)
parser.add_argument("--parameter", choices=["size", "strain"], required=True)
parser.add_argument("--start", type=float, required=True)
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
G2.SetPrintLevel("warn")
out = Path(args.output).resolve(); out.parent.mkdir(parents=True, exist_ok=True)
p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out))
h = p.histogram(0)
h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
                     "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
h.set_refinements({"Background": True})
target = None
for ph in p.phases():
    ph.clear_refinements({"Cell": True})
    for atom in ph.atoms(): atom.refinement_flags = ""
    ph.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}, [h])
    ph.set_HAP_refinements({"Scale": True}, [h])
    if (args.phase == "ni" and ph.name.startswith("NiWO4")) or (args.phase == "wo3" and ph.name.startswith("WO3")):
        target = ph
if target is None: raise ValueError("target phase not found")
hap = target.data["Histograms"][h.name]
if args.parameter == "size":
    hap["Size"][0] = "isotropic"; hap["Size"][1][0] = args.start
    target.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [h])
else:
    hap["Mustrain"][0] = "isotropic"; hap["Mustrain"][1][0] = args.start
    target.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [h])
p.set_Frozen(); p.save(); p.set_Controls("cycles", args.cycles); p.refine(); p.save()
print(json.dumps({"rwp_native": h.get_wR(), "phase": target.name, "parameter": args.parameter,
                  "start": args.start, "size": hap["Size"][1][0],
                  "strain": hap["Mustrain"][1][0], "frozen": p.get_Frozen()}, indent=2))
