#!/usr/bin/env python3
"""Print key saved GSAS-II model values and optionally export its profile."""

from pathlib import Path
import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


parser = argparse.ArgumentParser()
parser.add_argument("gpx")
parser.add_argument("--csv")
args = parser.parse_args()
G2.SetPrintLevel("error")
p = G2.G2Project(gpxfile=args.gpx)
h = p.histogram(0)
d = [np.asarray(v, float) for v in h.data["data"][1][:6]]
x, obs, weight, calc, background, difference = d
masses = []
phases = []
for ph in p.phases():
    hap = ph.data["Histograms"][h.name]
    mass = float(ph.data["General"]["Mass"] * hap["Scale"][0])
    masses.append(mass)
    atoms = []
    for atom in ph.atoms():
        atoms.append({"label": atom.label, "element": atom.element,
                      "xyz": list(atom.coordinates), "occupancy": atom.occupancy,
                      "uiso": plain(atom.ADP), "flags": atom.refinement_flags})
    phases.append({"name": ph.name, "cell": ph.get_cell(), "cell_mass": ph.data["General"]["Mass"],
                   "scale": hap["Scale"][0], "size": hap["Size"], "mustrain": hap["Mustrain"],
                   "preferred_orientation": hap["Pref.Ori."], "atoms": atoms})
for row, mass in zip(phases, masses):
    row["weight_fraction"] = mass / sum(masses)
out = {"histogram": h.name, "rwp_gsas_percent": h.get_wR(), "residuals": h.residuals,
       "instrument": h.InstrumentParameters, "sample": h.SampleParameters,
       "background": h.Background, "background_min": float(background.min()),
       "weighted_residual_sum": float(np.sum(weight * (obs-calc)**2)),
       "rwp_recomputed_percent": float(100*np.sqrt(np.sum(weight*(obs-calc)**2)/np.sum(weight*obs**2))),
       "phases": phases, "controls": p.data["Controls"]["data"]}
print(json.dumps(plain(out), indent=2, default=str))
if args.csv:
    np.savetxt(args.csv, np.column_stack((x, obs, calc, background, obs-calc)), delimiter=",",
               header="two_theta_deg,observed,calculated,background,difference", comments="", fmt="%.10g")
