#!/usr/bin/env python3
"""Run the supplied frozen atomic replay on a GPX and report its Rwp."""

from pathlib import Path
import argparse
import importlib.util
import json
import os

import numpy as np

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("gpx")
parser.add_argument("--out", required=True)
args = parser.parse_args()
gpx = Path(args.gpx).resolve()
out = Path(args.out).resolve()
out.mkdir(parents=True, exist_ok=True)
src = ROOT / "learned/divalent-tungstates/scorer/runtime/replay_worker.py"
spec = importlib.util.spec_from_file_location("frozen_replay_worker", src)
worker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(worker)
os.chdir(out)
report = worker.replay({"project": str(gpx),
                        "observed": str((ROOT / "inputs/pattern.csv").resolve()),
                        "histogram": None})
z = np.load("prediction.npz")
obs, calc = z["observed"], z["predicted"]
weight = 1.0 / np.maximum(obs, 1.0)
report["replay_rwp_percent"] = float(100*np.sqrt(np.sum(weight*(obs-calc)**2)/np.sum(weight*obs**2)))
(out / "replay.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
print(json.dumps(report, indent=2, allow_nan=False))
