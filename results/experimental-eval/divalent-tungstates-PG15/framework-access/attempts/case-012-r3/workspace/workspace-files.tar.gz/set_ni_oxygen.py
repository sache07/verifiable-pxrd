#!/usr/bin/env python3
"""Set NiWO4 oxygen sites from the repaired published COD 5910277 model."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
args = parser.parse_args()
G2.SetPrintLevel("warn")
out = Path(args.output).resolve(); out.parent.mkdir(parents=True, exist_ok=True)
p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out)); h = p.histogram(0)
h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
                     "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
h.set_refinements({"Background": True})
for ph in p.phases():
    ph.clear_refinements({"Cell": True})
    ph.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}, [h])
    ph.set_HAP_refinements({"Scale": True}, [h])
    for atom in ph.atoms(): atom.refinement_flags = ""
    if ph.name.startswith("NiWO4"):
        ph.atom("O1").coordinates = [0.22, 0.11, -0.04]
        ph.atom("O2").coordinates = [0.26, 0.38, 0.39]
p.save(); p.set_Controls("cycles", 12); p.refine(); p.save()
ni = p.phase("NiWO4")
print(json.dumps({"rwp_native": h.get_wR(), "coordinates": {
    atom.label: [float(v) for v in atom.coordinates] for atom in ni.atoms()}}, indent=2))
