#!/usr/bin/env python3
"""Create the final GPX, replay it atomically, and write all submission files."""

from pathlib import Path
import argparse
import importlib.util
import json
import os
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("source_gpx")
args = parser.parse_args()
G2.SetPrintLevel("error")

# Save a self-contained project under the required final name without changing
# any of the fitted model values.
project = G2.G2Project(gpxfile=str(Path(args.source_gpx).resolve()), newgpx=str(ROOT / "final.gpx"))
project.save()
hist = project.histogram(0)
phase_objects = project.phases()
cells = {p.name: p.get_cell() for p in phase_objects}
native_residuals = hist.residuals

# Use the frozen evaluator's native atomic replay to generate the submitted
# curve and CIFs. This prevents stale calculated arrays from entering outputs.
replay_dir = ROOT / ".tmp/final-replay"
replay_dir.mkdir(parents=True, exist_ok=True)
for path in [replay_dir / "prediction.npz", replay_dir / "replay.json",
             replay_dir / "phase_0.cif", replay_dir / "phase_1.cif"]:
    path.unlink(missing_ok=True)
worker_path = ROOT / "learned/divalent-tungstates/scorer/runtime/replay_worker.py"
spec = importlib.util.spec_from_file_location("frozen_replay_worker", worker_path)
worker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(worker)
old_cwd = Path.cwd()
os.chdir(replay_dir)
try:
    replay = worker.replay({"project": str((ROOT / "final.gpx").resolve()),
                            "observed": str((ROOT / "inputs/pattern.csv").resolve()),
                            "histogram": None})
finally:
    os.chdir(old_cwd)
if replay.get("status") != "replayed":
    raise RuntimeError("final project did not replay: " + json.dumps(replay))
(replay_dir / "replay.json").write_text(json.dumps(replay, indent=2, allow_nan=False) + "\n")

names = ["phase_NiWO4.cif", "phase_WO3.cif"]
for phase, name in zip(replay["phases"], names):
    shutil.copyfile(replay_dir / phase["cif"], ROOT / name)

z = np.load(replay_dir / "prediction.npz")
x, observed, calculated, background = z["x"], z["observed"], z["predicted"], z["background"]
difference = observed - calculated
np.savetxt(ROOT / "fit.csv", np.column_stack((x, observed, calculated, difference, background)),
           delimiter=",", header="two_theta,observed,calculated,difference,background", comments="",
           fmt=["%.10f", "%.10g", "%.10g", "%.10g", "%.10g"])

weight = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weight * difference**2))
denominator = float(np.sum(weight * observed**2))
rwp = float(100 * np.sqrt(chi_square / denominator))
rp = float(100 * np.sum(np.abs(difference)) / np.sum(observed))
rexp = float(native_residuals.get("wRmin", np.nan))
gof = float(rwp / rexp) if np.isfinite(rexp) and rexp > 0 else None
fractions = [float(p["weight_fraction"]) for p in replay["phases"]]

fit_stats = {
    "rwp_percent": rwp,
    "rp_percent": rp,
    "rexp_percent": rexp,
    "goodness_of_fit": gof,
    "weighted_chi_square": chi_square,
    "chi_square_per_point": float(chi_square / len(x)),
    "n_points": int(len(x)),
    "weighting": "1/max(observed_counts,1)",
    "difference_convention": "observed-calculated",
    "replay_status": replay["status"],
}
result = {
    "phases": [
        {"name": "nickel tungstate (wolframite)", "formula": "NiWO4",
         "space_group": "P 1 2/c 1", "cif_path": names[0], "weight_fraction": fractions[0]},
        {"name": "tungsten(VI) oxide, monoclinic", "formula": "WO3",
         "space_group": "P 1 21/c 1", "cif_path": names[1], "weight_fraction": fractions[1]},
    ],
    "fit_statistics": fit_stats,
    "refinement_histogram": replay["histogram"],
    "fraction_basis": "normalized over modeled crystalline phases",
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

ni_cell = cells["NiWO4"]
wo_name = next(k for k in cells if k.startswith("WO3"))
wo_cell = cells[wo_name]
report = f"""# Powder XRD phase analysis

The crystalline model contains **wolframite NiWO4, {100*fractions[0]:.2f} wt%**, and **monoclinic WO3, {100*fractions[1]:.2f} wt%**, normalized over these modeled crystalline phases. No amorphous fraction can be obtained from this scan without an internal standard.

## Evidence

The NiO + WO3 precursor context and 900 °C firing make NiWO4 the expected reaction product. The wolframite model accounts for the independent peak series at approximately 19.21, 23.91, 24.85, 30.87, 36.52, 54.57 and 65–66 degrees 2theta. Monoclinic WO3 is required by the separate 23.06/23.53/24.29 degree triplet and matching lines near 28.84, 33.19, 33.52 and 34.09 degrees. Related P21/n, P-1 and orthorhombic WO3 models were screened; the retained P21/c model (COD 2311041 parent setting) gave the best stable whole-pattern fit.

The NiWO4 framework was adapted from available wolframite analogues and cross-checked against published COD 5910277. That Ni record has a duplicated/incomplete atom loop and cannot be imported directly, but its Ni and W coordinates agree closely with the refined heavy-atom sites. The refined cells are NiWO4 a={ni_cell['length_a']:.5f}, b={ni_cell['length_b']:.5f}, c={ni_cell['length_c']:.5f} A, beta={ni_cell['angle_beta']:.4f} degrees; and WO3 a={wo_cell['length_a']:.5f}, b={wo_cell['length_b']:.5f}, c={wo_cell['length_c']:.5f} A, beta={wo_cell['angle_beta']:.4f} degrees (the retained nonstandard P21/c setting).

The final fresh atomic replay gives Rwp={rwp:.3f}%, Rp={rp:.3f}%, Rexp={rexp:.3f}% and goodness-of-fit={gof:.3f}; chi-square per point is {chi_square/len(x):.3f} over {len(x)} points. A nonnegative NiO addition refined to only 0.014 wt% and did not materially change Rwp; its required strong line near 43.4 degrees is absent, so NiO is not included. There are no other coherent unmodeled peak series.

## Remaining uncertainty

The fractions are estimated to about +/-2 wt% absolute because phase scale, preferred orientation, displacement, line broadening and background are correlated. Trace crystalline phases below roughly 0.5–1 wt% cannot be excluded. Heavy-atom positions and cells are robust, but oxygen coordinates are less well constrained by Cu X-ray powder data; the submitted oxygen sublattices remain chemically plausible and should not be interpreted at single-crystal precision. Closely related very small WO3 symmetry distortions are not uniquely distinguishable at this resolution.
"""
(ROOT / "report.md").write_text(report)
print(json.dumps({"result": result, "cells": cells, "project": str(ROOT / "final.gpx")}, indent=2, allow_nan=False))
