#!/usr/bin/env python3
"""Refine heavy-atom or all atomic coordinates from an existing GPX."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--all-atoms", action="store_true")
parser.add_argument("--ni-oxygen", action="store_true")
parser.add_argument("--wo3-oxygen", action="store_true")
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
G2.SetPrintLevel("warn")
out = Path(args.output).resolve()
out.parent.mkdir(parents=True, exist_ok=True)
project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out))
hist = project.histogram(0)

# Hold peak positions and shapes fixed while adjusting structure factors. Keep
# only background and phase amplitudes alongside coordinates.
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
                        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
hist.set_refinements({"Background": True})
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
    phase.set_HAP_refinements({"Scale": True}, [hist])
    for atom in phase.atoms():
        atom.refinement_flags = ""
        use_oxygen = (phase.name.startswith("NiWO4") and args.ni_oxygen) or (phase.name.startswith("WO3") and args.wo3_oxygen)
        if args.all_atoms or atom.element in {"W", "Ni"} or (atom.element == "O" and use_oxygen):
            atom.refinement_flags = "X"

project.save()
project.set_Controls("cycles", args.cycles)
project.refine()
project.save()
report = {"rwp_native": hist.get_wR(), "phases": {}}
for phase in project.phases():
    report["phases"][phase.name] = [
        {"label": atom.label, "element": atom.element,
         "xyz": [float(v) for v in atom.coordinates], "flags": atom.refinement_flags}
        for atom in phase.atoms()
    ]
print(json.dumps(report, indent=2))
