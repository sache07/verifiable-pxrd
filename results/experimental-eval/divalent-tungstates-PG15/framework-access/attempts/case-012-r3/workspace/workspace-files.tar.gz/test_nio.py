#!/usr/bin/env python3
"""Diagnostic nonnegative Rietveld scale test for residual NiO."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


COD_NIO = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/01/00/1010093.cif")
parser = argparse.ArgumentParser(); parser.add_argument("input"); parser.add_argument("output"); args = parser.parse_args()
G2.SetPrintLevel("warn")
out = Path(args.output).resolve(); out.parent.mkdir(parents=True, exist_ok=True)
p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out)); h = p.histogram(0)
h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
                     "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
h.set_refinements({"Background": True})
for ph in p.phases():
    ph.clear_refinements({"Cell": True})
    for atom in ph.atoms(): atom.refinement_flags = ""
    ph.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}, [h])
    ph.set_HAP_refinements({"Scale": True}, [h])
nio = p.add_phase(str(COD_NIO), phasename="NiO_test", histograms=[h], fmthint="CIF")
hap = nio.data["Histograms"][h.name]
hap["Scale"] = [0.01, True]
hap["Size"][0] = "isotropic"; hap["Size"][1][0] = 0.25; hap["Size"][2][0] = False
hap["Mustrain"][0] = "isotropic"; hap["Mustrain"][1][0] = 500.0; hap["Mustrain"][2][0] = False
p.save(); p.set_Controls("parmMin", 0.0, variable=f"{nio.id}:0:Scale"); p.set_Controls("cycles", 15); p.refine(); p.save()
masses = [ph.data["General"]["Mass"]*ph.data["Histograms"][h.name]["Scale"][0] for ph in p.phases()]
print(json.dumps({"rwp_native": h.get_wR(), "scales": {ph.name: ph.data["Histograms"][h.name]["Scale"][0] for ph in p.phases()},
                  "weight_fractions": {ph.name: m/sum(masses) for ph,m in zip(p.phases(),masses)},
                  "frozen": p.get_Frozen()}, indent=2))
