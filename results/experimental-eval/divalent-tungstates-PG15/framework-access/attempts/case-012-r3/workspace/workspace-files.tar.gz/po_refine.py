#!/usr/bin/env python3
"""Screen/refine one March-Dollase preferred-orientation axis in a GPX."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--phase", choices=["ni", "wo3"], required=True)
parser.add_argument("--axis", nargs=3, type=int, required=True)
parser.add_argument("--cycles", type=int, default=12)
args = parser.parse_args()
G2.SetPrintLevel("warn")
out = Path(args.output).resolve(); out.parent.mkdir(parents=True, exist_ok=True)
p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out))
h = p.histogram(0)
h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
                     "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
h.set_refinements({"Background": True})
target = None
for ph in p.phases():
    ph.clear_refinements({"Cell": True})
    for atom in ph.atoms(): atom.refinement_flags = ""
    ph.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}, [h])
    ph.set_HAP_refinements({"Scale": True}, [h])
    if (args.phase == "ni" and ph.name.startswith("NiWO4")) or (args.phase == "wo3" and ph.name.startswith("WO3")):
        target = ph
if target is None: raise ValueError("target phase not found")
hap = target.data["Histograms"][h.name]
hap["Pref.Ori."][0] = "MD"
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = True
hap["Pref.Ori."][3] = list(args.axis)
p.save(); p.set_Controls("cycles", args.cycles); p.refine(); p.save()
print(json.dumps({"rwp_native": h.get_wR(), "phase": target.name,
                  "axis": args.axis, "ratio": hap["Pref.Ori."][1]}, indent=2))
