#!/usr/bin/env python3
"""Refine one common isotropic displacement parameter per phase."""

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--ni-start", type=float, default=0.008)
parser.add_argument("--wo3-start", type=float, default=0.008)
parser.add_argument("--cycles", type=int, default=15)
args = parser.parse_args()
G2.SetPrintLevel("warn")
out = Path(args.output).resolve(); out.parent.mkdir(parents=True, exist_ok=True)
p = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(out)); h = p.histogram(0)
p.get_Constraints("Phase").clear()
h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
                     "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
h.set_refinements({"Background": True})
for ph in p.phases():
    ph.clear_refinements({"Cell": True})
    ph.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}, [h])
    ph.set_HAP_refinements({"Scale": True}, [h])
    start = args.ni_start if ph.name.startswith("NiWO4") else args.wo3_start
    variables = []
    for i, atom in enumerate(ph.atoms()):
        atom.ADP = start; atom.refinement_flags = "U"
        variables.append(f"{ph.id}::AUiso:{i}")
    p.add_EquivConstr(tuple(variables), reloadIdx=True)
p.save(); p.set_Controls("cycles", args.cycles); p.refine(); p.save()
print(json.dumps({"rwp_native": h.get_wR(), "uiso": {
    ph.name: [float(atom.ADP) for atom in ph.atoms()] for ph in p.phases()}}, indent=2))
