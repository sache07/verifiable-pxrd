#!/usr/bin/env python3
"""Test positional refinement for one phase while holding profile terms fixed."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    source = Path(sys.argv[1]).resolve()
    phase_index = int(sys.argv[2])
    selection = sys.argv[3]
    output = Path(sys.argv[4]).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    chosen = phases[phase_index]
    labels = [a.label for a in chosen.atoms()
              if selection == "all" or (selection == "oxygen" and a.element == "O")]
    chosen.set_refinements({"Atoms": {label: "X" for label in labels}})
    project.set_Controls("cycles", 7)
    project.refine()
    project.save(str(output))
    print(json.dumps({
        "phase": phase_index,
        "selection": selection,
        "labels": labels,
        "wR": hist.get_wR(),
        "coordinates": [[a.label, a.element, list(map(float, a.coordinates))] for a in chosen.atoms()],
        "output": str(output),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
