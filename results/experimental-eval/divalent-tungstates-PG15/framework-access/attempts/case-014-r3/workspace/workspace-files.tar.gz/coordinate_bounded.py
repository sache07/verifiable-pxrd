#!/usr/bin/env python3
"""Refine coordinates within a bounded fractional displacement from a parent model."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def set_bound(project, variable, center, limit):
    project.set_Controls("parmMin", float(center) - float(limit), variable=variable)
    project.set_Controls("parmMax", float(center) + float(limit), variable=variable)


def main() -> None:
    source = Path(sys.argv[1]).resolve()
    phase_index = int(sys.argv[2])
    oxygen_limit = float(sys.argv[3])
    heavy_limit = float(sys.argv[4])
    output = Path(sys.argv[5]).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    chosen = phases[phase_index]
    chosen.set_refinements({"Atoms": {a.label: "X" for a in chosen.atoms()}})
    for atom_index, atom in enumerate(chosen.atoms()):
        limit = oxygen_limit if atom.element == "O" else heavy_limit
        for axis, center in zip("xyz", atom.coordinates):
            set_bound(project, f"{phase_index}::dA{axis}:{atom_index}", center, limit)
    project.set_Controls("cycles", 7)
    project.refine()
    project.save(str(output))
    print(json.dumps({
        "phase": phase_index,
        "oxygen_limit": oxygen_limit,
        "heavy_limit": heavy_limit,
        "wR": hist.get_wR(),
        "coordinates": [[a.label, a.element, list(map(float, a.coordinates))] for a in chosen.atoms()],
        "frozen": project.get_Frozen(),
        "output": str(output),
    }, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
