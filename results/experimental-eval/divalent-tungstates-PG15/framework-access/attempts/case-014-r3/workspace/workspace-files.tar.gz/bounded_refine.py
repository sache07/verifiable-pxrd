#!/usr/bin/env python3
"""Run a physically bounded, staged GSAS-II refinement for candidate models."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
WORK = ROOT / ".tmp" / "bounded"


def source_cif(record_id: str) -> Path:
    if record_id == "contracted_srwo4":
        return ROOT / ".tmp" / "bounded" / "contracted_srwo4_start.cif"
    if record_id == "cd_srwo4":
        return ROOT / ".tmp" / "analogues" / "cdwo4_sr_substituted.cif"
    if record_id == "srw3o8_mixed_scheelite":
        return ROOT / ".tmp" / "analogues" / "srw3o8_mixed_scheelite.cif"
    if record_id == "srwo3_pm3m":
        return ROOT / ".tmp" / "candidates" / "srwo3_pm3m.cif"
    if record_id == "wo3_pm3m":
        return ROOT / ".tmp" / "candidates" / "wo3_pm3m.cif"
    if record_id == "contracted_fergusonite_srwo4":
        return ROOT / ".tmp" / "analogues" / "contracted_fergusonite_srwo4.cif"
    if record_id == "srwo4_i4_analogue":
        return ROOT / ".tmp" / "analogues" / "srwo4_i4_analogue.cif"
    if record_id == "1563541":
        return ROOT / ".tmp" / "screen" / "cifs" / "1563541.cif"
    return COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def make_inputs() -> tuple[Path, Path]:
    WORK.mkdir(parents=True, exist_ok=True)
    x, y = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1).T
    xye = WORK / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.8f %.8f %.8f")
    inst = WORK / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; bounded Cu Kalpha start\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.08;Polariz.:0.7;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:20.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def set_cell(phase, values: list[float]) -> None:
    vol = G2lat.calc_V(G2lat.cell2A(values))
    phase.data["General"]["Cell"] = [False, *map(float, values), float(vol)]


def set_bound(project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def add_bounds(project, phases, hist, reference_cells) -> None:
    set_bound(project, ":0:Zero", -0.25, 0.25)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    for key, low, high in [
        ("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10), ("Polariz.", 0.5, 1.0),
    ]:
        set_bound(project, f":0:{key}", low, high)
    for i, (phase, reference_cell) in enumerate(zip(phases, reference_cells)):
        set_bound(project, f"{i}:0:Scale", 0.0, 100.0)
        set_bound(project, f"{i}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{i}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{i}:0:MD", 0.7, 1.4)
        avec = G2lat.cell2A(reference_cell)
        for j, val in enumerate(avec):
            # Bounds correspond to roughly +/-0.75% in cell lengths, wider
            # than the generator's reference perturbation but narrow enough
            # to prevent a wrong phase from escaping to another indexing.
            width = max(abs(float(val)) * 0.011, 1e-7)
            set_bound(project, f"{i}::A{j}", float(val) - width, float(val) + width)


def fractions(phases, hist_name: str) -> list[float]:
    amounts = [
        max(0.0, float(p.data["Histograms"][hist_name]["Scale"][0]))
        * float(p.data["General"]["Mass"])
        for p in phases
    ]
    total = sum(amounts)
    return [v / total for v in amounts] if total else [math.nan] * len(amounts)


def snapshot(project, phases, hist, stage: str) -> dict:
    inst = hist.InstrumentParameters
    result = {
        "stage": stage,
        "wR": hist.get_wR(),
        "fractions": fractions(phases, hist.name),
        "zero": float(inst["Zero"][1]),
        "shift": float(hist.SampleParameters["Shift"][0]),
        "cells": [list(map(float, p.data["General"]["Cell"][1:])) for p in phases],
        "scales": [float(p.data["Histograms"][hist.name]["Scale"][0]) for p in phases],
        "sizes": [float(p.data["Histograms"][hist.name]["Size"][1][0]) for p in phases],
        "strains": [float(p.data["Histograms"][hist.name]["Mustrain"][1][0]) for p in phases],
        "profile": {k: float(inst[k][1]) for k in ["U", "V", "W", "X", "Y", "SH/L", "Polariz."]},
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(result, sort_keys=True))
    return result


def run(label: str, ids: list[str]) -> None:
    out = WORK / label
    out.mkdir(parents=True, exist_ok=True)
    xye, instfile = make_inputs()
    project = G2.G2Project(newgpx=str(out / "model.gpx"))
    phases = [project.add_phase(str(source_cif(rid)), phasename=f"phase_{rid}", fmthint="CIF") for rid in ids]
    reference_cells = [list(map(float, p.data["General"]["Cell"][1:7])) for p in phases]

    # The dominant scheelite line positions show a near-upper-bound expanded
    # reference cell. Starting there avoids using cell strain to mimic zero/height.
    c0 = reference_cells[0]
    set_cell(phases[0], [c0[0] * 1.0048, c0[1] * 1.0048, c0[2] * 1.0048, *c0[3:]])
    hist = project.add_powder_histogram(str(xye), str(instfile), phases=phases, fmthint="xye")
    hist.set_refinements({
        "Limits": [10.05, 99.90],
        "Background": {"type": "chebyschev-1", "no. coeffs": 12,
                       "coeffs": [650.0] + [0.0] * 11, "refine": True},
    })
    sample = hist.SampleParameters
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Shift"] = [-800.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    sample["Scale"] = [1.0, False]

    start_fracs = np.array([0.82] + [(0.18 / (len(phases) - 1))] * (len(phases) - 1)) if len(phases) > 1 else np.array([1.0])
    for i, (phase, frac) in enumerate(zip(phases, start_fracs)):
        hap = phase.data["Histograms"][hist.name]
        # A common multiplier near that found in a one-phase fit.
        hap["Scale"] = [12.0 * float(frac) * float(phases[0].data["General"]["Mass"]) /
                        (0.82 * float(phase.data["General"]["Mass"])), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.06
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    project.save()
    add_bounds(project, phases, hist, reference_cells)
    project.set_Controls("cycles", 4)
    history = []

    project.refine()
    history.append(snapshot(project, phases, hist, "scale_background"))

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    history.append(snapshot(project, phases, hist, "zero_shift"))

    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine()
    history.append(snapshot(project, phases, hist, "cells"))

    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 0.06, "refine": True},
        })
    project.refine()
    history.append(snapshot(project, phases, hist, "phase_size"))
    for phase in phases:
        phase.clear_HAP_refinements({"Size": True})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project.refine()
    history.append(snapshot(project, phases, hist, "phase_strain"))
    hist.set_refinements({"Instrument Parameters": ["W"]})
    project.refine()
    history.append(snapshot(project, phases, hist, "profile_W"))

    project.save(str(out / "model.gpx"))
    data = hist.data["data"][1]
    arr = np.column_stack((data[0], data[1], data[3], data[4], data[1] - data[3]))
    np.savetxt(out / "profile.csv", arr, delimiter=",",
               header="two_theta_deg,observed,calculated,background,difference", comments="")
    (out / "summary.json").write_text(json.dumps({"label": label, "ids": ids, "history": history}, indent=2) + "\n")


def main() -> None:
    G2.SetPrintLevel("warn")
    if len(sys.argv) < 3:
        raise SystemExit("usage: bounded_refine.py LABEL COD_ID [COD_ID ...]")
    run(sys.argv[1], sys.argv[2:])


if __name__ == "__main__":
    main()
