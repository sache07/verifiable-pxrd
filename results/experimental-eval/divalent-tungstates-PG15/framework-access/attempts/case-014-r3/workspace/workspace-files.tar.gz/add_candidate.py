#!/usr/bin/env python3
"""Add one candidate phase to an existing GSAS-II project and refine it in stages."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def bound(project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def fractions(phases, hist_name: str) -> list[float]:
    amounts = [
        max(0.0, float(p.data["Histograms"][hist_name]["Scale"][0]))
        * float(p.data["General"]["Mass"])
        for p in phases
    ]
    total = sum(amounts)
    return [v / total for v in amounts] if total else [math.nan] * len(amounts)


def snapshot(project, hist, phases, stage: str) -> dict:
    result = {
        "stage": stage,
        "wR": hist.get_wR(),
        "fractions": fractions(phases, hist.name),
        "scales": [float(p.data["Histograms"][hist.name]["Scale"][0]) for p in phases],
        "cells": [list(map(float, p.data["General"]["Cell"][1:8])) for p in phases],
        "sizes": [p.data["Histograms"][hist.name]["Size"][:4] for p in phases],
        "strains": [p.data["Histograms"][hist.name]["Mustrain"][:4] for p in phases],
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(result, sort_keys=True, default=str))
    return result


def main() -> None:
    if len(sys.argv) != 5:
        raise SystemExit("usage: add_candidate.py SOURCE.gpx CANDIDATE.cif NAME OUTPUT.gpx")
    source = Path(sys.argv[1]).resolve()
    cif = Path(sys.argv[2]).resolve()
    name = sys.argv[3]
    output = Path(sys.argv[4]).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    old_phases = project.phases()

    # Start from the converged three-phase model and hold all of its structural,
    # profile and nuisance terms fixed. Its phase scales are allowed to
    # redistribute when a candidate is introduced.
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    hist.clear_refinements({"Background": True})
    for phase in old_phases:
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})

    candidate = project.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
    phases = project.phases()
    idx = len(phases) - 1
    reference_cell = list(map(float, candidate.data["General"]["Cell"][1:7]))
    hap = candidate.data["Histograms"][hist.name]

    old_total = sum(
        max(0.0, float(p.data["Histograms"][hist.name]["Scale"][0]))
        * float(p.data["General"]["Mass"])
        for p in old_phases
    )
    # Initialize the candidate at 4 wt%, a small but numerically visible amount.
    hap["Scale"] = [old_total * 0.04 / 0.96 / float(candidate.data["General"]["Mass"]), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.10
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False

    for i, phase in enumerate(phases):
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        bound(project, f"{i}:0:Scale", 0.0, 100.0)
    hist.set_refinements({"Background": True})
    bound(project, f"{idx}:0:Size;i", 0.03, 2.0)
    bound(project, f"{idx}:0:Mustrain;i", 0.0, 8000.0)
    avec = G2lat.cell2A(reference_cell)
    for j, value in enumerate(avec):
        width = max(abs(float(value)) * 0.045, 1e-7)
        bound(project, f"{idx}::A{j}", float(value) - width, float(value) + width)

    project.set_Controls("cycles", 8)
    history = []
    project.refine()
    history.append(snapshot(project, hist, phases, "scale_background"))

    candidate.set_refinements({"Cell": True})
    project.refine()
    history.append(snapshot(project, hist, phases, "candidate_cell"))

    candidate.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.refine()
    history.append(snapshot(project, hist, phases, "candidate_size"))

    candidate.clear_HAP_refinements({"Size": True})
    candidate.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project.refine()
    history.append(snapshot(project, hist, phases, "candidate_strain"))

    # Recalculate once with all candidate profile flags fixed. This updates the
    # saved profile when a variable has landed on a bound.
    candidate.clear_HAP_refinements({"Mustrain": True})
    candidate.clear_refinements({"Cell": True})
    project.set_Controls("cycles", 0)
    project.refine()
    history.append(snapshot(project, hist, phases, "recalculated"))
    project.save(str(output))

    (output.with_suffix(".json")).write_text(json.dumps({
        "source": str(source), "candidate": str(cif), "name": name,
        "history": history,
    }, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
