#!/usr/bin/env python3
"""Export the selected, self-consistent GSAS-II refinement deliverables."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_bg" / "b40_iter2.gpx"
PROJECT = ROOT / "final.gpx"

EXPORTS = [
    ("scheelite SrWO4", "phase_1_srwo4_scheelite.cif", "identified"),
    ("monoclinic WO3", "phase_2_wo3_monoclinic.cif", "identified"),
    (
        "contracted scheelite-type SrWO4 analogue",
        "phase_3_contracted_scheelite_analogue.cif",
        "tentative structure and semiquantitative fraction",
    ),
]


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(PROJECT))

    # Reload the exact submitted project before deriving every other artifact.
    project = G2.G2Project(gpxfile=str(PROJECT))
    histogram = project.histogram(0)
    phases = project.phases()
    if len(phases) != len(EXPORTS):
        raise RuntimeError(f"Expected {len(EXPORTS)} phases, found {len(phases)}")

    amounts = np.array(
        [
            float(phase.data["Histograms"][histogram.name]["Scale"][0])
            * float(phase.data["General"]["Mass"])
            for phase in phases
        ],
        dtype=float,
    )
    fractions = amounts / amounts.sum()

    cov = project["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    dep = cov.get("depSigDict", {})
    phase_rows = []
    for index, (phase, export, fraction) in enumerate(zip(phases, EXPORTS, fractions)):
        display_name, filename, status = export
        phase.export_CIF(str(ROOT / filename))
        esd = dep.get(f"{index}:0:WgtFrac", (None, None))[1]
        row = {
            "name": display_name,
            "cif_path": filename,
            "weight_fraction": float(fraction),
            "status": status,
        }
        if esd is not None and math.isfinite(float(esd)):
            row["weight_fraction_formal_esd"] = float(esd)
        phase_rows.append(row)

    data = histogram.data["data"][1]
    x = np.asarray(data[0], dtype=float)
    observed = np.asarray(data[1], dtype=float)
    calculated = np.asarray(data[3], dtype=float)
    background = np.asarray(data[4], dtype=float)
    # The independent replay regenerates the atomic profile over the complete
    # measured grid (including the handful of points outside the fit limits).
    replay_path = ROOT / ".tmp" / "replay" / "prediction.npz"
    if replay_path.is_file():
        with np.load(replay_path, allow_pickle=False) as replay:
            if not np.allclose(replay["x"], x, rtol=0, atol=1e-9) or not np.allclose(
                replay["observed"], observed, rtol=0, atol=1e-7
            ):
                raise RuntimeError("Replay profile does not match the submitted scan")
            calculated = replay["predicted"].copy()
            background = replay["background"].copy()
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, background, difference)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference",
        comments="",
        fmt="%.10g",
    )

    lo, hi = map(float, histogram.data["Limits"][1])
    mask = (x >= lo) & (x <= hi)
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    rwp = 100.0 * math.sqrt(chi_square / float(np.sum(weights * observed**2)))
    rp = 100.0 * np.sum(np.abs(difference)) / np.sum(observed)
    fit_stats = {
        "rwp_percent": rwp,
        "rp_percent": float(rp),
        "saved_refinement_rwp_percent": float(histogram.get_wR()),
        "goodness_of_fit": float(rvals.get("GOF", float("nan"))),
        "chi_square": chi_square,
        "observations": int(len(x)),
        "variables_in_last_refinement": int(rvals.get("Nvars", 0)),
        "refinement_range_two_theta_deg": [lo, hi],
        "background_model": "40-term Chebyshev-1",
    }
    result = {
        "phases": phase_rows,
        "fit_statistics": fit_stats,
        "refinement_histogram": histogram.name,
        "fraction_basis": "normalized over the three modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
