#!/usr/bin/env python3
"""Test one March-Dollase axis from a common refined GSAS-II project."""

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    source = Path(sys.argv[1]).resolve()
    phase_index = int(sys.argv[2])
    axis = [int(v) for v in sys.argv[3].split(",")]
    output = Path(sys.argv[4]).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source))
    hist = project.histogram(0)
    phases = project.phases()
    project.save(str(output))
    project.set_Frozen()
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2] = "MD", 1.0, False
    po = phases[phase_index].data["Histograms"][hist.name]["Pref.Ori."]
    po[3] = axis
    phases[phase_index].set_HAP_refinements({"Pref.Ori.": True})
    project.set_Controls("cycles", 6)
    project.refine()
    project.save(str(output))
    result = {
        "phase": phase_index,
        "axis": axis,
        "wR": hist.get_wR(),
        "ratios": [p.data["Histograms"][hist.name]["Pref.Ori."][1] for p in phases],
        "scales": [p.data["Histograms"][hist.name]["Scale"][0] for p in phases],
        "output": str(output),
    }
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
