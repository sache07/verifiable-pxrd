#!/usr/bin/env python3
"""Refine selected instrumental peak-profile terms with phase profiles fixed."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    source = Path(sys.argv[1]).resolve()
    names = sys.argv[2].split(",")
    output = Path(sys.argv[3]).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    hist.set_refinements({"Instrument Parameters": names})
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    project.set_Controls("cycles", 8)
    project.refine()
    project.save(str(output))
    print(json.dumps({
        "names": names, "wR": hist.get_wR(), "frozen": project.get_Frozen(),
        "instrument": {k: float(hist.InstrumentParameters[k][1]) for k in ["U", "V", "W", "X", "Y", "SH/L"]},
        "output": str(output),
    }, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
