#!/usr/bin/env python3
"""Grid-test a fixed phase-wise isotropic displacement parameter."""

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    source = Path(sys.argv[1]).resolve()
    phase_index = int(sys.argv[2])
    value = float(sys.argv[3])
    output = Path(sys.argv[4]).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    for atom in phases[phase_index].atoms():
        atom.uiso = value
    project.set_Controls("cycles", 5)
    project.refine()
    project.save(str(output))
    print(json.dumps({
        "phase": phase_index,
        "uiso": value,
        "wR": hist.get_wR(),
        "scales": [p.data["Histograms"][hist.name]["Scale"][0] for p in phases],
        "output": str(output),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
