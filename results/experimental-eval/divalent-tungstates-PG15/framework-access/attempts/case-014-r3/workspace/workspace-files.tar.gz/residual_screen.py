#!/usr/bin/env python3
"""Rank frozen-COD candidates against a residual profile by broadened correlation."""

import gzip
import json
import sys
import warnings
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")


def cif_path(record_id):
    return COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def main(path):
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    data = np.loadtxt(path, delimiter=",", skiprows=1)
    x, observed, calculated, background, residual = data.T
    step = np.median(np.diff(x))
    use = (x > 10.2) & (x < 99.8)
    weights = 1 / np.maximum(observed, 1)
    residual = np.clip(residual, -4 * np.sqrt(np.maximum(observed, 1)),
                       8 * np.sqrt(np.maximum(observed, 1)))
    residual_norm = np.sum(weights[use] * residual[use] ** 2)
    calculator = XRDCalculator(wavelength=1.540598, symprec=0)
    rows = []
    for system in ["O-Sr", "C-O-Sr", "O-W", "O-Sr-W"]:
        for row in index.get(system, []):
            formula, record_id = str(row[0]), str(row[1])
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    structure = Structure.from_file(cif_path(record_id), primitive=False)
                pattern = calculator.get_pattern(structure, two_theta_range=(9.0, 101.5), scaled=True)
            except Exception:
                continue
            positions = np.asarray(pattern.x)
            intensities = np.asarray(pattern.y)
            keep = intensities >= 0.5
            positions, intensities = positions[keep], intensities[keep]
            best = None
            for fwhm in [0.16, 0.24, 0.34, 0.48]:
                sigma = fwhm / 2.35482 / step
                for dilation in np.linspace(0.985, 1.015, 31):
                    p1 = dilation * positions
                    theta = np.deg2rad(p1 / 2)
                    p2 = np.rad2deg(2 * np.arcsin(np.clip(
                        (1.544426 / 1.540598) * np.sin(theta), -1, 1)))
                    impulse = np.zeros_like(x)
                    pp = np.r_[p1, p2]
                    ii = np.r_[intensities, 0.5 * intensities]
                    bins = np.rint((pp - x[0]) / step).astype(int)
                    valid = (bins >= 0) & (bins < len(impulse))
                    np.add.at(impulse, bins[valid], ii[valid])
                    base = gaussian_filter1d(impulse, sigma, mode="constant")
                    for offset in np.linspace(-0.5, 0.5, 41):
                        profile = np.interp(x - offset, x, base, left=0, right=0)
                        denominator = np.sum(weights[use] * profile[use] ** 2)
                        if denominator <= 0:
                            continue
                        numerator = np.sum(weights[use] * profile[use] * residual[use])
                        scale = max(0, numerator / denominator)
                        improvement = 2 * scale * numerator - scale * scale * denominator
                        correlation = numerator / np.sqrt(denominator * residual_norm)
                        trial = (improvement, correlation, scale, dilation, offset, fwhm)
                        if best is None or trial[0] > best[0]:
                            best = trial
            rows.append((best[0], best[1], formula, record_id, *best[2:],
                         structure.get_space_group_info(symprec=1e-3)[0]))
    for row in sorted(rows, reverse=True):
        print(f"imp={row[0]:10.1f} corr={row[1]:.4f} {row[2]:14s} {row[3]} "
              f"scale={row[4]:.3g} a={row[5]:.5f} b={row[6]:+.3f} "
              f"fwhm={row[7]:.2f} sg={row[8]}")


if __name__ == "__main__":
    main(Path(sys.argv[1]))
