#!/usr/bin/env python3
"""Screen candidate phase sets with staged GSAS-II Rietveld refinements.

This is an exploratory helper. It writes projects and a compact JSON summary
under .tmp/screen/; final deliverables are produced separately.
"""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp" / "screen"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(record_id: str) -> Path:
    sanitized = TMP / "cifs" / f"{record_id}.cif"
    if record_id == "1563541" and sanitized.exists():
        return sanitized
    return COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


CANDIDATES = {
    "srwo4_tet": ["1546036"],
    "srwo4_tet_wo3_1010618": ["1546036", "1010618"],
    "srwo4_tet_wo3_1528915": ["1546036", "1528915"],
    "srwo4_tet_wo3_1563541": ["1546036", "1563541"],
    "srwo4_tet_wo3_2311041": ["1546036", "2311041"],
    "srwo4_tet_wo3_2107312": ["1546036", "2107312"],
    "srwo4_tet_wo3_2106293": ["1546036", "2106293"],
    "srwo4_tet_wo3_1521532": ["1546036", "1521532"],
    "srwo4_tet_wo3_1521533": ["1546036", "1521533"],
    "srwo4_tet_wo3_1004057": ["1546036", "1004057"],
    "srwo4_tet_srco3_9008198": ["1546036", "9008198"],
    "srwo4_tet_srco3_1539128": ["1546036", "1539128"],
    "srwo4_tet_sr3w2o9": ["1546036", "2311977"],
    "srwo4_tet_srwo4_mono": ["1546036", "1546037"],
    "srwo4_tet_sro": ["1546036", "7200689"],
    "srwo4_tet_sro_wo3_1010618": ["1546036", "7200689", "1010618"],
    "srwo4_tet_sro_wo3_1528915": ["1546036", "7200689", "1528915"],
    "srwo4_tet_sro_wo3_1563541": ["1546036", "7200689", "1563541"],
    "srwo4_tet_sro_wo3_2311041": ["1546036", "7200689", "2311041"],
    "srwo4_tet_sro_wo3_2107312": ["1546036", "7200689", "2107312"],
    "srwo4_tet_sro_wo3_2106293": ["1546036", "7200689", "2106293"],
    "srwo4_tet_sro_srco3_9008198": ["1546036", "7200689", "9008198"],
    "srwo4_tet_sro_srco3_1539128": ["1546036", "7200689", "1539128"],
    "srwo4_tet_sro2_9008161": ["1546036", "9008161"],
    "srwo4_tet_sro10_1010383": ["1546036", "1010383"],
    "srwo4_tet_sro10_2310965": ["1546036", "2310965"],
}


def prepare_inputs() -> tuple[Path, Path]:
    TMP.mkdir(parents=True, exist_ok=True)
    x, y = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1).T
    xye = TMP / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.8f %.8f %.8f")
    inst = TMP / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha laboratory Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:20.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def mass_fractions(phases, hist_name: str) -> list[float]:
    raw = []
    for phase in phases:
        scale = float(phase.data["Histograms"][hist_name]["Scale"][0])
        mass = float(phase.data["General"]["Mass"])
        raw.append(max(0.0, scale * mass))
    total = sum(raw)
    return [v / total for v in raw] if total > 0 else [math.nan] * len(raw)


def refine_one(label: str, ids: list[str], xye: Path, inst: Path) -> dict:
    outdir = TMP / label
    outdir.mkdir(parents=True, exist_ok=True)
    gpx = outdir / "screen.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    phases = [
        project.add_phase(str(cod_path(rid)), phasename=f"p{i}_{rid}", fmthint="CIF")
        for i, rid in enumerate(ids)
    ]
    hist = project.add_powder_histogram(str(xye), str(inst), phases=phases, fmthint="xye")
    hist.set_refinements({
        "Limits": [10.05, 99.90],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [650.0] + [0.0] * 11,
            "refine": True,
        },
    })
    sample = hist.SampleParameters
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    sample["Scale"] = [1.0, False]

    # Start with broad but physically plausible specimen terms so all candidate
    # reflections contribute before profile refinement.
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / float(phase.data["General"]["Mass"]), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.1
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    project.set_Controls("cycles", 8)

    # Scale/background, then positions, then widths. Keep the screening model
    # modest so candidate ranking is driven by actual reflection accounting.
    project.refine()
    initial_fractions = mass_fractions(phases, hist.name)
    for phase, fraction in zip(phases, initial_fractions):
        if np.isfinite(fraction) and fraction > 0.002:
            phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    current_fractions = mass_fractions(phases, hist.name)
    for phase, fraction in zip(phases, current_fractions):
        if np.isfinite(fraction) and fraction > 0.002:
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "value": 0.1, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            })
    project.refine()
    project.refine()
    project.save(str(gpx))

    data = hist.data["data"][1]
    yobs = np.asarray(data[1], float)
    ycalc = np.asarray(data[3], float)
    weights = np.asarray(data[2], float)
    mask = (np.asarray(data[0]) >= 10.05) & (np.asarray(data[0]) <= 99.90)
    rwp = 100.0 * math.sqrt(np.sum(weights[mask] * (yobs[mask] - ycalc[mask]) ** 2) /
                            np.sum(weights[mask] * yobs[mask] ** 2))
    instp = hist.InstrumentParameters
    return {
        "label": label,
        "ids": ids,
        "gpx": str(gpx.relative_to(ROOT)),
        "wR_GSAS_percent": hist.get_wR(),
        "Rwp_recomputed_percent": rwp,
        "fractions": mass_fractions(phases, hist.name),
        "cells": {p.name: p.data["General"]["Cell"][1:] for p in phases},
        "zero_deg": float(instp["Zero"][1]),
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "profile": {k: float(instp[k][1]) for k in ["U", "V", "W", "X", "Y", "SH/L"]},
        "residuals": hist.residuals,
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    xye, inst = prepare_inputs()
    names = sys.argv[1:] or list(CANDIDATES)
    results = []
    for label in names:
        try:
            row = refine_one(label, CANDIDATES[label], xye, inst)
            results.append(row)
            print(json.dumps(row, sort_keys=True))
        except Exception as exc:
            row = {"label": label, "error": f"{type(exc).__name__}: {exc}"}
            results.append(row)
            print(json.dumps(row, sort_keys=True))
    (TMP / "summary.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
