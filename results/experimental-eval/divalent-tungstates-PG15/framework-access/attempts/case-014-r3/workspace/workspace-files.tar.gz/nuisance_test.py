#!/usr/bin/env python3
"""Refine selected specimen/instrument intensity nuisance parameters."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def bound(project, variable, low, high):
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def main() -> None:
    source = Path(sys.argv[1]).resolve()
    mode = sys.argv[2]
    output = Path(sys.argv[3]).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    if mode in {"roughness", "both", "rough_b", "rough_b_pol"}:
        hist.SampleParameters["SurfRoughA"] = [float(sys.argv[4]) if len(sys.argv) > 4 else 0.2,
                                                mode in {"roughness", "both"}]
        hist.SampleParameters["SurfRoughB"] = [float(sys.argv[5]) if len(sys.argv) > 5 else 0.1, True]
        bound(project, ":0:SurfRoughA", 0.0, 0.8)
        bound(project, ":0:SurfRoughB", 0.001, 0.8)
    if mode in {"polarization", "both", "rough_b_pol"}:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        bound(project, ":0:Polariz.", 0.5, 1.0)
    project.set_Controls("cycles", 8)
    project.refine()
    project.save(str(output))
    print(json.dumps({
        "mode": mode,
        "wR": hist.get_wR(),
        "roughness_A": float(hist.SampleParameters["SurfRoughA"][0]),
        "roughness_B": float(hist.SampleParameters["SurfRoughB"][0]),
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "frozen": project.get_Frozen(),
        "output": str(output),
    }, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
