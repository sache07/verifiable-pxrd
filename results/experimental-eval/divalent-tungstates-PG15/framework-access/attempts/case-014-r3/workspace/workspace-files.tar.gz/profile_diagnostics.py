#!/usr/bin/env python3
"""Summarize and plot residuals saved in a GSAS-II project."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    project = G2.G2Project(gpxfile=sys.argv[1])
    hist = project.histogram(0)
    data = hist.data["data"][1]
    x, obs, weight, calc, bkg = map(np.asarray, data[:5])
    diff = obs - calc
    selected = (x >= 10.05) & (x <= 99.90)
    rows = []
    for lo in range(10, 100, 10):
        use = (x >= lo) & (x < lo + 10)
        rows.append({
            "range": [lo, lo + 10],
            "Rwp_percent": float(100 * np.sqrt(np.sum(weight[use] * diff[use] ** 2) /
                                                np.sum(weight[use] * obs[use] ** 2))),
            "mean_difference": float(np.mean(diff[use])),
        })
    std = np.abs(diff) * np.sqrt(weight)
    candidates = np.where(selected)[0]
    top = candidates[np.argsort(std[candidates])[-30:][::-1]]
    result = {
        "saved_wR_percent": hist.get_wR(),
        "manual_Rwp_percent": float(100 * np.sqrt(np.sum(weight[selected] * diff[selected] ** 2) /
                                                   np.sum(weight[selected] * obs[selected] ** 2))),
        "ranges": rows,
        "top_residual_bins": [[float(x[i]), float(obs[i]), float(calc[i]), float(diff[i]), float(std[i])]
                              for i in top],
    }
    try:
        from scipy.ndimage import gaussian_filter1d
        from scipy.signal import find_peaks
        smooth = gaussian_filter1d(diff, 2.0)
        peaks, props = find_peaks(smooth, prominence=60.0, width=1.0)
        order = peaks[np.argsort(props["prominences"])[::-1]]
        result["positive_residual_peaks"] = [
            [float(x[i]), float(smooth[i]), float(props["prominences"][np.where(peaks == i)[0][0]])]
            for i in order[:80] if selected[i]
        ]
    except Exception as exc:
        result["peak_search_error"] = str(exc)
    print(json.dumps(result, indent=2))
    if len(sys.argv) > 2:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(2, 1, figsize=(14, 7), sharex=True,
                                 gridspec_kw={"height_ratios": [2.4, 1]})
        axes[0].plot(x, obs, color="black", lw=0.5, label="observed")
        axes[0].plot(x, calc, color="crimson", lw=0.6, label="calculated")
        axes[0].plot(x, bkg, color="steelblue", lw=0.5, label="background")
        axes[0].set_yscale("symlog", linthresh=100)
        axes[0].legend(loc="upper right")
        axes[0].set_ylabel("counts")
        axes[1].plot(x, diff, color="black", lw=0.45)
        axes[1].axhline(0, color="gray", lw=0.5)
        axes[1].set_ylabel("obs - calc")
        axes[1].set_xlabel(r"2$\theta$ (degree)")
        fig.tight_layout()
        fig.savefig(Path(sys.argv[2]), dpi=150)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
