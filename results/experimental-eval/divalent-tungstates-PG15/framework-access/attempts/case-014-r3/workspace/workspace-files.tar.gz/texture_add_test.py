#!/usr/bin/env python3
"""Test preferred orientation on one phase while retaining other phase corrections."""

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2

source = Path(sys.argv[1]).resolve()
phase_index = int(sys.argv[2])
axis = [int(v) for v in sys.argv[3].split(",")]
output = Path(sys.argv[4]).resolve()
output.parent.mkdir(parents=True, exist_ok=True)
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(source))
project.save(str(output))
project.set_Frozen()
hist = project.histogram(0)
phases = project.phases()
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
for phase in phases:
    phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
po = phases[phase_index].data["Histograms"][hist.name]["Pref.Ori."]
po[0], po[1], po[2], po[3] = "MD", 1.0, True, axis
project.set_Controls("cycles", 7)
project.refine()
project.save(str(output))
print(json.dumps({
    "phase": phase_index, "axis": axis, "wR": hist.get_wR(), "frozen": project.get_Frozen(),
    "ratios": [p.data["Histograms"][hist.name]["Pref.Ori."][1] for p in phases],
    "output": str(output),
}, sort_keys=True, default=str))
