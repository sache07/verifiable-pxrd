#!/usr/bin/env python3
"""Export observed/calculated/background/difference arrays from a GSAS-II project."""

import sys
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=sys.argv[1])
data = project.histogram(0).data["data"][1]
array = np.column_stack((data[0], data[1], data[3], data[4], np.asarray(data[1]) - np.asarray(data[3])))
np.savetxt(sys.argv[2], array, delimiter=",",
           header="two_theta_deg,observed,calculated,background,difference", comments="")
