#!/usr/bin/env python3
"""Find I41/a database structures whose cells match the contracted phase."""

from __future__ import annotations

import gzip
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.core import Structure


INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
TARGET = np.array([5.12584, 5.12584, 11.10373])


def cif_path(record_id: str) -> Path:
    return COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


with gzip.open(INDEX, "rt") as stream:
    index = json.load(stream)

rows = {}
for system_rows in index.values():
    for row in system_rows:
        if int(row[2]) == 88:
            rows[str(row[1])] = str(row[0])

matches = []
for record_id, formula in rows.items():
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = Structure.from_file(cif_path(record_id), primitive=False)
        lengths = np.array(structure.lattice.abc)
        angles = np.array(structure.lattice.angles)
        if np.max(np.abs(angles - 90)) > 0.1:
            continue
        # Handle a conventional tetragonal cell and harmless a/b exchange.
        if abs(lengths[0] - lengths[1]) / np.mean(lengths[:2]) > 0.01:
            continue
        mismatch = float(np.sqrt(np.mean(((lengths - TARGET) / TARGET) ** 2)))
        if mismatch > 0.12:
            continue
        comp = structure.composition
        reduced = comp.reduced_composition
        matches.append((mismatch, record_id, formula, list(map(float, lengths)),
                        reduced.formula, len(structure),
                        structure.get_space_group_info(symprec=1e-3)[0]))
    except Exception:
        continue

for row in sorted(matches):
    print(json.dumps({
        "rms_relative_cell_mismatch": row[0], "id": row[1], "index_formula": row[2],
        "cell": row[3], "reduced_formula": row[4], "sites": row[5], "space_group": row[6],
        "path": str(cif_path(row[1])),
    }, sort_keys=True))
