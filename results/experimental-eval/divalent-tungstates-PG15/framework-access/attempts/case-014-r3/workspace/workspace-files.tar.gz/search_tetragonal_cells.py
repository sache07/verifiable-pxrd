#!/usr/bin/env python3
"""Fast header scan for COD tetragonal cells near a requested metric."""

from __future__ import annotations

import gzip
import json
import math
import re
from pathlib import Path


INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
TARGET = (5.109, 5.109, 11.065)


def cif_path(record_id: str) -> Path:
    return COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def number(text: str, tag: str) -> float | None:
    match = re.search(rf"(?mi)^\s*{re.escape(tag)}\s+['\"]?([+-]?[0-9]+(?:\.[0-9]*)?(?:[Ee][+-]?[0-9]+)?)", text)
    return float(match.group(1)) if match else None


def main() -> None:
    with gzip.open(INDEX, "rt") as handle:
        index = json.load(handle)
    records = {}
    for rows in index.values():
        for formula, record_id, sg_number, *_ in rows:
            if 75 <= int(sg_number) <= 142:
                records[str(record_id)] = (str(formula), int(sg_number))

    matches = []
    for record_id, (formula, sg_number) in records.items():
        path = cif_path(record_id)
        try:
            text = path.read_text(errors="ignore")
            abc = tuple(number(text, f"_cell_length_{axis}") for axis in "abc")
            angles = tuple(number(text, f"_cell_angle_{axis}") for axis in ("alpha", "beta", "gamma"))
            if any(v is None for v in abc + angles):
                continue
            if abs(abc[0] - abc[1]) / ((abc[0] + abc[1]) / 2) > 0.01:
                continue
            if max(abs(v - 90) for v in angles) > 0.2:
                continue
            mismatch = math.sqrt(sum(((v - t) / t) ** 2 for v, t in zip(abc, TARGET)) / 3)
            if mismatch <= 0.035:
                matches.append((mismatch, record_id, formula, sg_number, abc, path))
        except OSError:
            continue

    for mismatch, record_id, formula, sg_number, abc, path in sorted(matches):
        print(json.dumps({
            "mismatch": mismatch, "id": record_id, "formula": formula,
            "sg_number": sg_number, "cell": abc, "path": str(path),
        }, sort_keys=True))


if __name__ == "__main__":
    main()
