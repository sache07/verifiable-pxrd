#!/usr/bin/env python3
"""Plot a CSV profile exported by export_profile.py."""

import sys
import numpy as np
import matplotlib.pyplot as plt

data = np.loadtxt(sys.argv[1], delimiter=",", skiprows=1)
x, obs, calc, bkg, diff = data.T
fig, axes = plt.subplots(3, 1, figsize=(16, 10), sharex=False)
for ax, (lo, hi) in zip(axes, [(10, 40), (40, 70), (70, 100)]):
    use = (x >= lo) & (x <= hi)
    ax.plot(x[use], obs[use], color="black", lw=0.7, label="observed")
    ax.plot(x[use], calc[use], color="crimson", lw=0.7, label="calculated")
    ax.plot(x[use], bkg[use], color="darkorange", lw=0.6, label="background")
    ax.plot(x[use], diff[use] + 120, color="royalblue", lw=0.6, label="difference + 120")
    ax.axhline(120, color="gray", lw=0.4)
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
axes[0].legend(ncol=4, fontsize=8)
axes[-1].set_xlabel(r"2$\theta$ (degree)")
fig.tight_layout()
fig.savefig(sys.argv[2], dpi=150)
