#!/usr/bin/env python3
"""Jointly refine bounded instrument and phase broadening parameters."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def bound(project, variable, low, high):
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def main() -> None:
    # SOURCE OUTPUT U W X MODE0 MODE1 MODE2
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    starts = list(map(float, sys.argv[3:6]))
    modes = sys.argv[6:9]
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    hist.clear_refinements({"Background": True})
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})

    for key, value in zip(("U", "W", "X"), starts):
        hist.InstrumentParameters[key][1] = value
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for key, low, high in (("U", 0, 40), ("W", 2, 40), ("X", .1, 6), ("SH/L", .005, .10)):
        bound(project, f":0:{key}", low, high)

    for i, (phase, mode) in enumerate(zip(phases, modes)):
        hap = phase.data["Histograms"][hist.name]
        size = max(.04, min(1.5, float(hap["Size"][1][0])))
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": size, "refine": True}})
        bound(project, f"{i}:0:Size;i", .04, 1.5)
        if mode == "off":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2] = [False, False, False]
        elif mode == "iso":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = max(300.0, min(8000.0, float(hap["Mustrain"][1][0]) or 1000.0))
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
            bound(project, f"{i}:0:Mustrain;i", 0.0, 8000.0)
        elif mode.startswith("u"):
            axis = [int(v) for v in mode[1:]]
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][3] = axis
            hap["Mustrain"][1][0] = max(300.0, min(8000.0, float(hap["Mustrain"][1][0]) or 1000.0))
            hap["Mustrain"][1][1] = max(300.0, min(8000.0, float(hap["Mustrain"][1][1]) or 1000.0))
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][1] = True
            bound(project, f"{i}:0:Mustrain;a", 0.0, 8000.0)
        else:
            raise ValueError(mode)

    project.set_Controls("cycles", 12)
    project.refine()
    # Recalculate after any bounded variables have been clipped/frozen.
    for phase in phases:
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(output))
    print(json.dumps({
        "wR": hist.get_wR(), "modes": modes, "frozen": project.get_Frozen(),
        "instrument": {k: float(hist.InstrumentParameters[k][1]) for k in ["U", "W", "X", "SH/L"]},
        "sizes": [float(p.data["Histograms"][hist.name]["Size"][1][0]) for p in phases],
        "strains": [p.data["Histograms"][hist.name]["Mustrain"][:4] for p in phases],
        "output": str(output),
    }, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
