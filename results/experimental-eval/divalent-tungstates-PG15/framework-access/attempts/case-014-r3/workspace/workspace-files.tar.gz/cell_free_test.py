#!/usr/bin/env python3
"""Diagnostic refinement of phase cells with wider bounds at a fixed displacement."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def bound(project, variable, low, high):
    project.set_Controls("parmMin", float(low), variable=variable)
    project.set_Controls("parmMax", float(high), variable=variable)


def main():
    source = Path(sys.argv[1]).resolve()
    shift = float(sys.argv[2])
    output = Path(sys.argv[3]).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    hist.clear_refinements({"Background": True})
    hist.SampleParameters["Shift"] = [shift, False]
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    bound(project, ":0:Zero", -.25, .25)
    for i, phase in enumerate(phases):
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_refinements({"Cell": True})
        avec = G2lat.cell2A(phase.data["General"]["Cell"][1:7])
        for j, value in enumerate(avec):
            width = max(abs(float(value)) * .06, 1e-7)
            bound(project, f"{i}::A{j}", float(value) - width, float(value) + width)
    project.set_Controls("cycles", 12)
    project.refine()
    for phase in phases:
        phase.clear_refinements({"Cell": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(output))
    print(json.dumps({
        "shift": shift, "zero": float(hist.InstrumentParameters["Zero"][1]),
        "wR": hist.get_wR(), "frozen": project.get_Frozen(),
        "cells": [list(map(float, p.data["General"]["Cell"][1:8])) for p in phases],
        "output": str(output),
    }, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
