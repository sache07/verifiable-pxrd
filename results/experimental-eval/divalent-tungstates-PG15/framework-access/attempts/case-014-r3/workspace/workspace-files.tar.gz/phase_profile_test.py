#!/usr/bin/env python3
"""Refine one phase's isotropic or uniaxial broadening model."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    source = Path(sys.argv[1]).resolve()
    phase_index = int(sys.argv[2])
    mode = sys.argv[3]
    output = Path(sys.argv[4]).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    phase = phases[phase_index]
    if mode == "size":
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    elif mode == "strain":
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    elif mode.startswith("uniaxial:"):
        axis = [int(v) for v in mode.split(":", 1)[1].split(",")]
        hap = phase.data["Histograms"][hist.name]["Mustrain"]
        hap[0] = "uniaxial"
        hap[3] = axis
        hap[1][1] = hap[1][0] if hap[1][1] <= 0 else hap[1][1]
        hap[2][0] = True
        hap[2][1] = True
        project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;a")
        project.set_Controls("parmMax", 8000.0, variable=f"{phase_index}:0:Mustrain;a")
    else:
        raise ValueError(mode)
    project.set_Controls("cycles", 8)
    project.refine()
    project.save(str(output))
    print(json.dumps({
        "phase": phase_index, "mode": mode, "wR": hist.get_wR(), "frozen": project.get_Frozen(),
        "sizes": [p.data["Histograms"][hist.name]["Size"][:4] for p in phases],
        "strains": [p.data["Histograms"][hist.name]["Mustrain"][:4] for p in phases],
        "output": str(output),
    }, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
