#!/usr/bin/env python3
"""Project a coordinate-refinement direction to element-wise Cartesian RMS limits."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def lattice_matrix(cell):
    a, b, c, alpha, beta, gamma = map(float, cell[:6])
    al, be, ga = np.deg2rad([alpha, beta, gamma])
    avec = np.array([a, 0.0, 0.0])
    bvec = np.array([b * np.cos(ga), b * np.sin(ga), 0.0])
    cx = c * np.cos(be)
    cy = c * (np.cos(al) - np.cos(be) * np.cos(ga)) / np.sin(ga)
    cz = math.sqrt(max(0.0, c * c - cx * cx - cy * cy))
    return np.vstack([avec, bvec, [cx, cy, cz]])


def main():
    source = Path(sys.argv[1]).resolve()
    direction_file = Path(sys.argv[2]).resolve()
    phase_index = int(sys.argv[3])
    oxygen_rms = float(sys.argv[4])
    heavy_rms = float(sys.argv[5])
    output = Path(sys.argv[6]).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source))
    direction = G2.G2Project(gpxfile=str(direction_file))
    project.save(str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})

    base_phase = phases[phase_index]
    direction_phase = direction.phases()[phase_index]
    base_atoms = base_phase.atoms()
    direction_atoms = direction_phase.atoms()
    matrix = lattice_matrix(base_phase.data["General"]["Cell"][1:7])
    applied = {}
    for element in sorted({a.element for a in base_atoms}):
        target = oxygen_rms if element == "O" else heavy_rms
        indices = [i for i, atom in enumerate(base_atoms) if atom.element == element]
        deltas = []
        weights = []
        for i in indices:
            delta = np.asarray(direction_atoms[i].coordinates) - np.asarray(base_atoms[i].coordinates)
            delta -= np.rint(delta)
            deltas.append(delta)
            weights.append(float(base_atoms[i].mult))
        cart2 = np.array([np.dot(delta, matrix) @ np.dot(delta, matrix) for delta in deltas])
        rms = float(np.sqrt(np.average(cart2, weights=weights)))
        scale = min(1.0, target / rms) if rms > 0 and target > 0 else 0.0
        for i, delta in zip(indices, deltas):
            base_atoms[i].coordinates = (np.asarray(base_atoms[i].coordinates) + scale * delta) % 1.0
        applied[element] = {"direction_rms_A": rms, "target_rms_A": target,
                            "applied_rms_A": rms * scale, "scale": scale}

    project.set_Controls("cycles", 6)
    project.refine()
    project.save(str(output))
    print(json.dumps({
        "phase": phase_index, "applied": applied, "wR": hist.get_wR(),
        "coordinates": [[a.label, a.element, list(map(float, a.coordinates))] for a in base_phase.atoms()],
        "output": str(output),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
