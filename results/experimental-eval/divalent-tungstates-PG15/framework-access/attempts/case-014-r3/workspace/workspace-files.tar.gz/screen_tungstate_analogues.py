#!/usr/bin/env python3
"""Screen ABO4 tungstate frameworks after substituting the A cation with Sr."""

from __future__ import annotations

import warnings
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
IDS = [
    "1527204", "1520645", "1549132", "4000806", "4000807", "9013902",
    "7219229", "5910088", "1546035", "1520200", "1520641", "2101679",
    "2101690", "1527935", "9009811", "9007617", "1546036", "1546037",
]


def path(record_id):
    return COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def main(profile_path: str):
    data = np.loadtxt(profile_path, delimiter=",", skiprows=1)
    x, observed, _, _, residual = data.T
    step = float(np.median(np.diff(x)))
    use = (x > 10.2) & (x < 99.8)
    weights = 1 / np.maximum(observed, 1)
    residual = np.clip(residual, -4 * np.sqrt(np.maximum(observed, 1)), 8 * np.sqrt(np.maximum(observed, 1)))
    norm = np.sum(weights[use] * residual[use] ** 2)
    rows = []
    for rid in IDS:
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                parent = Structure.from_file(path(rid), primitive=False)
            mapping = {str(el): "Sr" for el in parent.composition.elements if str(el) not in {"W", "O"}}
            model = parent.copy()
            model.replace_species(mapping)
            pattern = XRDCalculator(wavelength=1.540598).get_pattern(model, scaled=True, two_theta_range=(10, 100))
        except Exception:
            continue
        pos, inten = np.asarray(pattern.x), np.asarray(pattern.y)
        keep = inten >= .25
        pos, inten = pos[keep], inten[keep]
        best = None
        for fwhm in (.12, .18, .26, .36, .50, .70):
            sigma = fwhm / 2.35482 / step
            for dilation in np.linspace(.95, 1.05, 101):
                p1 = dilation * pos
                theta = np.deg2rad(p1 / 2)
                p2 = np.rad2deg(2 * np.arcsin(np.clip((1.544426 / 1.540598) * np.sin(theta), -1, 1)))
                impulse = np.zeros_like(x)
                pp, ii = np.r_[p1, p2], np.r_[inten, .5 * inten]
                bins = np.rint((pp - x[0]) / step).astype(int)
                valid = (bins >= 0) & (bins < len(x))
                np.add.at(impulse, bins[valid], ii[valid])
                base = gaussian_filter1d(impulse, sigma, mode="constant")
                for offset in np.linspace(-.6, .6, 49):
                    trial = np.interp(x - offset, x, base, left=0, right=0)
                    den = np.sum(weights[use] * trial[use] ** 2)
                    num = np.sum(weights[use] * trial[use] * residual[use])
                    scale = max(0.0, num / den) if den else 0.0
                    improvement = 2 * scale * num - scale * scale * den
                    item = (improvement, num / np.sqrt(den * norm), scale, dilation, offset, fwhm)
                    if best is None or item[0] > best[0]:
                        best = item
        rows.append((*best, rid, parent.composition.reduced_formula, model.composition.reduced_formula,
                     parent.get_space_group_info(symprec=1e-3)[0], parent.lattice.abc, mapping))
    for row in sorted(rows, reverse=True):
        print(row)


if __name__ == "__main__":
    import sys
    main(sys.argv[1])
