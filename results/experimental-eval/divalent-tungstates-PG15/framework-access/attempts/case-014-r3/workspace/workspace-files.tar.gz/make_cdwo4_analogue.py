#!/usr/bin/env python3
"""Construct the Sr-for-Cd analogue of tetragonal CdWO4 COD 1549132."""

import sys
from pathlib import Path

from pymatgen.core import Structure

sys.path.insert(0, str(Path(__file__).resolve().parent / "learned" / "divalent-tungstates" / "runtime"))
from models import write_synthetic_model

source = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/54/91/1549132.cif")
output = Path(".tmp/analogues/cdwo4_sr_substituted.cif")
structure = Structure.from_file(source, primitive=False)
structure.replace_species({"Cd": "Sr"})
write_synthetic_model(structure, output)
print(output.resolve())
