#!/usr/bin/env python3
"""Print compact diagnostics for one or more GSAS-II projects."""

from __future__ import annotations

import json
import math
import sys

from GSASII import GSASIIscriptable as G2


def inspect(path: str) -> dict:
    project = G2.G2Project(gpxfile=path)
    hist = project.histogram(0)
    phases = project.phases()
    amounts = [
        max(0.0, float(p.data["Histograms"][hist.name]["Scale"][0]))
        * float(p.data["General"]["Mass"])
        for p in phases
    ]
    total = sum(amounts)
    return {
        "path": path,
        "wR": hist.get_wR(),
        "Rp": hist.data.get("Residuals", {}).get("Rp"),
        "fractions": [v / total for v in amounts] if total else [math.nan] * len(amounts),
        "scales": [float(p.data["Histograms"][hist.name]["Scale"][0]) for p in phases],
        "cells": [list(map(float, p.data["General"]["Cell"][1:8])) for p in phases],
        "uiso": [[float(a.uiso) for a in p.atoms()] for p in phases],
        "atoms": [[{"label": a.label, "type": a.element, "xyz": list(map(float, a.coordinates)),
                     "uiso": float(a.uiso)} for a in p.atoms()] for p in phases],
        "preferred_orientation": [p.data["Histograms"][hist.name]["Pref.Ori."][:4] for p in phases],
        "instrument": {k: v[:2] for k, v in hist.InstrumentParameters.items()
                       if k in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."}},
        "sample": {k: v for k, v in hist.SampleParameters.items()
                   if k in {"Shift", "SurfRoughA", "SurfRoughB", "Gonio. radius"}},
    }


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    for filename in sys.argv[1:]:
        print(json.dumps(inspect(filename), sort_keys=True, default=str))
