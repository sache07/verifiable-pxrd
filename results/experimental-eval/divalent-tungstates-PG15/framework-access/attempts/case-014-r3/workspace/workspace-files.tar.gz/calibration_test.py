#!/usr/bin/env python3
"""Refine zero and phase cells at a fixed specimen displacement."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    source = Path(sys.argv[1]).resolve()
    shift = float(sys.argv[2])
    output = Path(sys.argv[3]).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    hist.SampleParameters["Shift"] = [shift, False]
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.set_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    project.set_Controls("cycles", 7)
    project.refine()
    project.save(str(output))
    print(json.dumps({
        "shift": shift, "zero": float(hist.InstrumentParameters["Zero"][1]),
        "cells": [list(map(float, p.data["General"]["Cell"][1:8])) for p in phases],
        "wR": hist.get_wR(), "frozen": project.get_Frozen(), "output": str(output),
    }, sort_keys=True, default=str))


if __name__ == "__main__":
    main()
