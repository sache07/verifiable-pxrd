#!/usr/bin/env python3
"""Save the selected project and export its phase CIFs."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/coordinate-caps/O0p03-M0p03.gpx")


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save("final.gpx")
    hist = project.histograms()[0]
    cif_names = ("phase_WO3.cif", "phase_Co3O4.cif")
    for phase, name in zip(project.phases(), cif_names):
        phase.export_CIF(name)
    masses = np.array(
        [
            phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()
        ]
    )
    summary = {
        "histogram": hist.name,
        "residuals": hist.residuals,
        "fractions": (masses / masses.sum()).tolist(),
        "phases": [
            {
                "name": phase.name,
                "cif": cif,
                "cell": phase.get_cell(),
                "composition": phase.composition,
            }
            for phase, cif in zip(project.phases(), cif_names)
        ],
    }
    Path(".tmp/final-project-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
