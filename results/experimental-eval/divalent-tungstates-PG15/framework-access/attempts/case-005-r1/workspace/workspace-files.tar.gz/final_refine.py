#!/usr/bin/env python3
"""Build the physically bounded final GSAS-II refinement for this pattern."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
ROOT = Path(".tmp/final-build")


def cod_path(record_id: str) -> Path:
    return COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def fractions(project, hist) -> list[float]:
    values = np.array(
        [
            p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
            for p in project.phases()
        ],
        dtype=float,
    )
    return (values / values.sum()).tolist()


def snapshot(project, hist, stage: str) -> dict:
    result = {
        "stage": stage,
        "wR_percent": float(hist.get_wR()),
        "fractions": fractions(project, hist),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "frozen": project.get_Frozen(),
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": atom.coordinates,
                        "uiso": atom.uiso,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    return result


def checkpoint(project, hist, log: list[dict], stage: str) -> None:
    project.save()
    shutil.copyfile(project.filename, ROOT / f"{stage}.gpx")
    row = snapshot(project, hist, stage)
    log.append(row)
    print(stage, "Rwp", row["wR_percent"], "fractions", row["fractions"], flush=True)


def refine(project, hist, log: list[dict], stage: str) -> None:
    project.refine()
    checkpoint(project, hist, log, stage)


def clear_flags(project, hist, *, background: bool = True, scales: bool = True) -> None:
    project.set_Frozen()
    for item in hist.InstrumentParameters.values():
        if isinstance(item, list) and len(item) > 2:
            item[2] = False
    for item in hist.SampleParameters.values():
        if isinstance(item, list) and len(item) > 1 and isinstance(item[1], bool):
            item[1] = False
    hist.Background[0][1] = background
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = scales
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False


def set_limit(project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    pattern = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
    x, y = pattern.T
    np.savetxt(
        ROOT / "pattern.xye",
        np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))),
        fmt="%.12g",
    )
    (ROOT / "instrument.instprm").write_text(
        "# Synthetic laboratory instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.10;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(ROOT / "working.gpx"))
    wo3 = project.add_phase(str(cod_path("2311041")), phasename="WO3_monoclinic", fmthint="CIF")
    co3o4 = project.add_phase(str(cod_path("9005896")), phasename="Co3O4_spinel", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        phases=[wo3, co3o4],
        fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-450.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})

    source_coordinates: dict[int, list[tuple[float, float, float]]] = {}
    for phase in (wo3, co3o4):
        source_coordinates[phase.id] = [tuple(atom.coordinates) for atom in phase.atoms()]
        for atom in phase.atoms():
            if atom.adp_flag == "I":
                atom.uiso = 0.01
            atom.refinement_flags = " "
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 2000.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [float(np.median(y))] + [0.0] * 11,
                "refine": True,
            }
        }
    )
    project.set_Controls("cycles", 8)
    set_limit(project, ":0:Zero", -0.25, 0.25)
    set_limit(project, ":0:Shift", -800.0, 800.0)
    set_limit(project, ":0:U", 0.0, 40.0)
    set_limit(project, ":0:W", 2.0, 40.0)
    set_limit(project, ":0:X", 0.1, 6.0)
    set_limit(project, ":0:SH/L", 0.005, 0.10)
    for phase in (wo3, co3o4):
        set_limit(project, f"{phase.id}:0:Size;i", 0.04, 1.5)
        set_limit(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)

    log: list[dict] = []
    refine(project, hist, log, "01_background_scales")
    for phase in (wo3, co3o4):
        phase.set_refinements({"Cell": True})
    refine(project, hist, log, "02_cells")
    hist.set_refinements({"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]})
    refine(project, hist, log, "03_zero_shift")
    for phase in (wo3, co3o4):
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.30, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    refine(project, hist, log, "04_phase_profiles")
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, hist, log, "05_instrument_profile")

    # Intensity corrections are fit only after peak positions and widths are stable.
    clear_flags(project, hist)
    hist.SampleParameters["SurfRoughA"] = [0.30, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    hist.InstrumentParameters["Polariz."][2] = True
    set_limit(project, ":0:SurfRoughA", 0.05, 0.60)
    set_limit(project, ":0:SurfRoughB", 0.02, 0.50)
    set_limit(project, ":0:Polariz.", 0.50, 1.00)
    refine(project, hist, log, "06_intensity_corrections")

    # The generator uses one scalar Uiso for all atoms in each phase.
    clear_flags(project, hist)
    for phase in (wo3, co3o4):
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            variable = f"{phase.id}::AUiso:{index}"
            variables.append(variable)
            set_limit(project, variable, 0.003, 0.020)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
    refine(project, hist, log, "07_uiso")

    # Refine symmetry-preserving positions, but cap each fractional component
    # to a physically modest displacement from the published parent model.
    clear_flags(project, hist)
    for phase in (wo3, co3o4):
        a, b, c = phase.get_cell()["length_a"], phase.get_cell()["length_b"], phase.get_cell()["length_c"]
        lengths = (a, b, c)
        for index, (atom, source) in enumerate(zip(phase.atoms(), source_coordinates[phase.id])):
            atom.refinement_flags = "X"
            cap_A = 0.08 if atom.element == "O" else 0.06
            for axis, (letter, length) in enumerate(zip("xyz", lengths)):
                delta = cap_A / length
                set_limit(
                    project,
                    f"{phase.id}::dA{letter}:{index}",
                    source[axis] - delta,
                    source[axis] + delta,
                )
    refine(project, hist, log, "08_bounded_coordinates")

    # A final lattice-only pass removes small coordinate/cell staging effects.
    clear_flags(project, hist)
    for phase in (wo3, co3o4):
        phase.set_refinements({"Cell": True})
    refine(project, hist, log, "09_final_cells")
    (ROOT / "stages.json").write_text(json.dumps(log, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
