#!/usr/bin/env python3
"""Refine one constrained isotropic displacement parameter per phase."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(args.input, args.output)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.output))
    project.filename = str(args.output.resolve())
    project.set_Frozen()
    hist = project.histograms()[0]
    for item in hist.InstrumentParameters.values():
        if isinstance(item, list) and len(item) > 2:
            item[2] = False
    for item in hist.SampleParameters.values():
        if isinstance(item, list) and len(item) > 1 and isinstance(item[1], bool):
            item[1] = False
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            atom.uiso = 0.01
            variable = f"{phase.id}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
    project.set_Controls("cycles", 8)
    project.refine()
    rows = []
    total = sum(
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    )
    for phase in project.phases():
        mass = phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        rows.append(
            {
                "name": phase.name,
                "weight_fraction": mass / total,
                "uiso": [atom.uiso for atom in phase.atoms()],
            }
        )
    result = {"wR": hist.get_wR(), "phases": rows}
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
