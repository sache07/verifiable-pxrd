#!/usr/bin/env python3
"""Test bounded whole-pattern intensity corrections from a common project."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_flags(project, hist) -> None:
    project.set_Frozen()
    for item in hist.InstrumentParameters.values():
        if isinstance(item, list) and len(item) > 2:
            item[2] = False
    for item in hist.SampleParameters.values():
        if isinstance(item, list) and len(item) > 1 and isinstance(item[1], bool):
            item[1] = False
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--tag", required=True)
    args = parser.parse_args()
    variants = ("roughness", "polarization", "roughness_polarization")
    root = Path(".tmp") / args.tag
    root.mkdir(parents=True, exist_ok=True)
    rows = []
    G2.SetPrintLevel("warn")
    for variant in variants:
        output = root / f"{variant}.gpx"
        shutil.copyfile(args.input, output)
        project = G2.G2Project(gpxfile=str(output))
        project.filename = str(output.resolve())
        hist = project.histograms()[0]
        clear_flags(project, hist)
        if "roughness" in variant:
            hist.SampleParameters["SurfRoughA"] = [0.30, True]
            hist.SampleParameters["SurfRoughB"] = [0.10, True]
            project.set_Controls("parmMin", 0.05, variable=f":{hist.id}:SurfRoughA")
            project.set_Controls("parmMax", 0.60, variable=f":{hist.id}:SurfRoughA")
            project.set_Controls("parmMin", 0.02, variable=f":{hist.id}:SurfRoughB")
            project.set_Controls("parmMax", 0.50, variable=f":{hist.id}:SurfRoughB")
        if "polarization" in variant:
            hist.InstrumentParameters["Polariz."][2] = True
            project.set_Controls("parmMin", 0.5, variable=f":{hist.id}:Polariz.")
            project.set_Controls("parmMax", 1.0, variable=f":{hist.id}:Polariz.")
        project.set_Controls("cycles", 8)
        project.refine()
        phase_rows = []
        total = sum(
            p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
            for p in project.phases()
        )
        for p in project.phases():
            mass = p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
            phase_rows.append({"name": p.name, "weight_fraction": mass / total})
        row = {
            "variant": variant,
            "wR": hist.get_wR(),
            "surf_rough_A": hist.SampleParameters["SurfRoughA"][0],
            "surf_rough_B": hist.SampleParameters["SurfRoughB"][0],
            "polarization": hist.InstrumentParameters["Polariz."][1],
            "phases": phase_rows,
            "output": str(output),
        }
        rows.append(row)
        print(row, flush=True)
    (root / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
