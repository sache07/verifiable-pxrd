#!/usr/bin/env python3
"""Exploratory staged GSAS-II refinement for the Co3O4/WO3 pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(record_id: str) -> Path:
    return COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def set_inst_value(hist, key: str, value: float) -> None:
    item = hist.InstrumentParameters[key]
    if len(item) > 1:
        item[1] = float(value)
    else:
        item[0] = float(value)


def summary(project, hist, stage: str) -> dict:
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
                "mass": float(phase.data["General"]["Mass"]),
            }
        )
    masses = np.array([p["mass"] * p["scale"] for p in phases])
    if np.sum(masses) > 0:
        fractions = (masses / np.sum(masses)).tolist()
    else:
        fractions = [None] * len(phases)
    return {
        "stage": stage,
        "wR": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "fractions": fractions,
        "phases": phases,
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }


def run_refinement(project, hist, log: list, stage: str) -> None:
    project.refine()
    state = summary(project, hist, stage)
    log.append(state)
    print(stage, "wR", state["wR"], "fractions", state["fractions"], flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", required=True)
    parser.add_argument("--co3o4", default="9005896")
    parser.add_argument("--tag", required=True)
    parser.add_argument("--coordinates", action="store_true")
    parser.add_argument("--skip-all-profiles", action="store_true")
    args = parser.parse_args()

    root = Path(".tmp") / args.tag
    root.mkdir(parents=True, exist_ok=True)
    pattern = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
    x, y = pattern.T
    # GSAS-II's xye reader interprets the third column as a pointwise sigma.
    np.savetxt(root / "pattern.xye", np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.12g")
    (root / "instrument.instprm").write_text(
        "# Synthetic laboratory instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.10;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(root / "trial.gpx"))
    wo3 = project.add_phase(str(cod_path(args.wo3)), phasename=f"WO3_{args.wo3}", fmthint="CIF")
    co3o4 = project.add_phase(str(cod_path(args.co3o4)), phasename=f"Co3O4_{args.co3o4}", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(root / "pattern.xye"), str(root / "instrument.instprm"), phases=[wo3, co3o4], fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-450.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})

    for phase in (wo3, co3o4):
        for atom in phase.atoms():
            if atom.adp_flag == "I":
                atom.uiso = 0.01
            atom.refinement_flags = " "
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 2000.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [float(np.median(y))] + [0.0] * 11,
                "refine": True,
            }
        }
    )
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["max cyc"] = 8
    limits = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
    }
    for phase in (wo3, co3o4):
        limits[f"{phase.id}:0:Size;i"] = (0.04, 1.5)
        limits[f"{phase.id}:0:Mustrain;i"] = (0.0, 8000.0)
    for variable, (low, high) in limits.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    log: list[dict] = []

    run_refinement(project, hist, log, "background_scales")

    for phase in (wo3, co3o4):
        phase.set_refinements({"Cell": True})
    run_refinement(project, hist, log, "cells")

    hist.set_refinements({"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]})
    run_refinement(project, hist, log, "zero_shift")

    for phase in (wo3, co3o4):
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.3, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    run_refinement(project, hist, log, "phase_profiles")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_refinement(project, hist, log, "instrument_profile")

    if not args.skip_all_profiles:
        run_refinement(project, hist, log, "all_profiles")

    if args.coordinates:
        wo3.set_refinements({"Atoms": {"all": "X"}})
        co3o4.set_refinements({"Atoms": {"all": "X"}})
        run_refinement(project, hist, log, "coordinates")

    project.save()
    (root / "summary.json").write_text(json.dumps(log, indent=2, default=str) + "\n")
    print(json.dumps(summary(project, hist, "final"), indent=2, default=str))


if __name__ == "__main__":
    main()
