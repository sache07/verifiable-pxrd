#!/usr/bin/env python3
"""Write fit.csv, result.json and report.md from the verified final replay."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


def main() -> None:
    replay_dir = Path(".tmp/replay-final")
    replay = json.loads((replay_dir / "replay.json").read_text())
    if replay.get("status") != "replayed" or replay.get("profile_review_flags"):
        raise RuntimeError(f"Final project did not pass replay: {replay}")
    profile = np.load(replay_dir / "prediction.npz")
    x = profile["x"]
    observed = profile["observed"]
    calculated = profile["predicted"]
    difference = observed - calculated
    np.savetxt(
        "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.12g",
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    rexp = 1.7221471569050886
    fractions = [row["weight_fraction"] for row in replay["phases"]]
    result = {
        "schema_version": 1,
        "refinement_histogram": replay["histogram"],
        "phases": [
            {
                "name": "monoclinic tungsten trioxide",
                "formula": "WO3",
                "space_group": "P 1 21/c 1 (No. 14)",
                "cif_path": "phase_WO3.cif",
                "weight_fraction": fractions[0],
            },
            {
                "name": "cobalt oxide spinel",
                "formula": "Co3O4",
                "space_group": "F d -3 m (No. 227)",
                "cif_path": "phase_Co3O4.cif",
                "weight_fraction": fractions[1],
            },
        ],
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "rexp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "weighted_chi_square": chi_square,
            "mean_weighted_squared_residual": chi_square / len(x),
            "n_points": int(len(x)),
            "weights": "1/max(observed_counts,1), used as a Poisson proxy because pointwise uncertainties were not supplied",
        },
        "calibration": {
            "zero_deg": -0.09089450797941885,
            "sample_displacement_um": -800.0,
            "goniometer_radius_mm": 200.0,
        },
        "quantification_scope": "Weight fractions are normalized over the two modeled crystalline phases; amorphous material is not quantified.",
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")

    report = f"""# Powder XRD phase analysis

The crystalline pattern is modeled as **monoclinic WO3 (P 21/c, No. 14), {100*fractions[0]:.2f} wt%**, and **spinel Co3O4 (Fd-3m, No. 227), {100*fractions[1]:.2f} wt%**. Fractions are normalized over the modeled crystalline material.

## Evidence

The WO3 assignment accounts for the diagnostic low-angle triplet at 23.465, 23.954 and 24.714 degrees 2theta and the related groups near 33.6-34.5, 42.2, 50.3 and 56.2 degrees after the refined common angular/specimen correction. The refined P21/c cell is a = 7.69197 A, b = 7.53506 A, c = 10.54285 A and beta = 136.1539 degrees. Competing orthorhombic and coarse monoclinic WO3 entries left large systematic peak/intensity residuals; a triclinic entry could only approach the fit by changing its lattice beyond the supplied framework's allowed reference perturbation. The submitted model is based on COD 2311041 with bounded coordinate refinement.

Co3O4 is fixed by its spinel sequence at 19.368, 31.636, 37.200, 45.143, 59.683 and 65.561 degrees 2theta; its refined cubic cell is a = 8.08249 A. The phase model derives from COD 9005896. The approximately 3:1 WO3:Co3O4 mass ratio is also close to the unreacted-precursor ratio expected from the stated 1:1 Co:W dosing.

A deliberately added CoWO4 wolframite analogue refined to only 0.078 +/- 0.088 wt% and did not improve the fit significantly (about 0.34 wt% at a model-dependent 3-sigma upper bound). Thus no crystalline cobalt tungstate product is supported by this scan.

## Fit and uncertainty

Independent atomic replay of `final.gpx` gives Rwp = {rwp:.3f}%, Rp = {rp:.3f}%, Rexp = {rexp:.3f}% and goodness of fit = {rwp/rexp:.3f} over {len(x)} points, with no profile-validity flags. Residual structure remains around the strongest WO3 peaks, so the oxygen coordinates and profile/calibration decomposition are not uniquely determined. The P21/c framework and two-phase inventory are reliable; a reasonable systematic uncertainty on either reported phase fraction is about 1 wt% absolute. The fractions do not measure amorphous content, and trace phases with other structures may evade the CoWO4-specific limit.
"""
    Path("report.md").write_text(report)


if __name__ == "__main__":
    main()
