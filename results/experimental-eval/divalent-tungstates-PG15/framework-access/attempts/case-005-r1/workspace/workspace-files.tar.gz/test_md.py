#!/usr/bin/env python3
"""Compare allowed March-Dollase axes from a common GSAS-II project."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def clear_flags(project, hist) -> None:
    for item in hist.InstrumentParameters.values():
        if isinstance(item, list) and len(item) > 2:
            item[2] = False
    for item in hist.SampleParameters.values():
        if isinstance(item, list) and len(item) > 1 and isinstance(item[1], bool):
            item[1] = False
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--phase", required=True, type=int)
    parser.add_argument("--tag", required=True)
    args = parser.parse_args()
    root = Path(".tmp") / args.tag
    root.mkdir(parents=True, exist_ok=True)
    results = []
    G2.SetPrintLevel("warn")
    for axis in AXES:
        stem = "axis-" + "".join(str(v) for v in axis)
        output = root / f"{stem}.gpx"
        shutil.copyfile(args.input, output)
        project = G2.G2Project(gpxfile=str(output))
        project.filename = str(output.resolve())
        project.set_Frozen()
        hist = project.histograms()[0]
        clear_flags(project, hist)
        phase = project.phases()[args.phase]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        project.set_Controls("cycles", 8)
        project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:{hist.id}:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:{hist.id}:MD")
        project.refine()
        ratio = phase.data["Histograms"][hist.name]["Pref.Ori."][1]
        row = {"axis": axis, "ratio": ratio, "wR": hist.get_wR(), "output": str(output)}
        results.append(row)
        print(row, flush=True)
    (root / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
