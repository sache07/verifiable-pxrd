#!/usr/bin/env python3
"""Test physically plausible coordinate-displacement caps and recalc each fit."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


BASE = Path(".tmp/final-build/09_final_cells.gpx")
ROOT = Path(".tmp/coordinate-caps")
CAPS = ((0.03, 0.025), (0.04, 0.03), (0.05, 0.04), (0.06, 0.05))


def clear_flags(project, hist) -> None:
    project.set_Frozen()
    for item in hist.InstrumentParameters.values():
        if isinstance(item, list) and len(item) > 2:
            item[2] = False
    for item in hist.SampleParameters.values():
        if isinstance(item, list) and len(item) > 1 and isinstance(item[1], bool):
            item[1] = False
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def limit(project, variable, low, high) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    stages = json.loads(Path(".tmp/final-build/stages.json").read_text())
    sources = {
        i: [tuple(atom["coordinates"]) for atom in row["atoms"]]
        for i, row in enumerate(stages[0]["phases"])
    }
    results = []
    G2.SetPrintLevel("warn")
    for oxygen_cap, heavy_cap in CAPS:
        tag = f"O{oxygen_cap:.2f}-M{heavy_cap:.2f}".replace(".", "p")
        output = ROOT / f"{tag}.gpx"
        shutil.copyfile(BASE, output)
        project = G2.G2Project(gpxfile=str(output))
        project.filename = str(output.resolve())
        hist = project.histograms()[0]
        clear_flags(project, hist)
        for pindex, phase in enumerate(project.phases()):
            cell = phase.get_cell()
            lengths = (cell["length_a"], cell["length_b"], cell["length_c"])
            for aindex, (atom, source) in enumerate(zip(phase.atoms(), sources[pindex])):
                atom.refinement_flags = "X"
                cap = oxygen_cap if atom.element == "O" else heavy_cap
                for axis, (letter, length) in enumerate(zip("xyz", lengths)):
                    delta = cap / length
                    limit(project, f"{phase.id}::dA{letter}:{aindex}", source[axis] - delta, source[axis] + delta)
        project.set_Controls("cycles", 8)
        project.refine()
        # Recalculate at the clamped coordinates and update lattice parameters.
        clear_flags(project, hist)
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
        project.refine()
        values = [
            p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
            for p in project.phases()
        ]
        total = sum(values)
        row = {
            "oxygen_cap_A": oxygen_cap,
            "heavy_cap_A": heavy_cap,
            "wR": hist.get_wR(),
            "fractions": [v / total for v in values],
            "frozen": project.get_Frozen(),
            "output": str(output),
        }
        results.append(row)
        print(row, flush=True)
    (ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
