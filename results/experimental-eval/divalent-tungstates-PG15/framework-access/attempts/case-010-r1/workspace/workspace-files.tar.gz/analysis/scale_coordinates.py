#!/usr/bin/env python3
"""Scale refined coordinate shifts relative to a parent project and recalculate."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("parent", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--heavy-scale", type=float, required=True)
    parser.add_argument("--oxygen-scale", type=float, required=True)
    args = parser.parse_args()
    folder = args.output.resolve()
    folder.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(folder / "scaled.gpx"))
    parent = G2.G2Project(gpxfile=str(args.parent.resolve()))
    hist = project.histogram(0)
    phases = project.phases()
    for phase, source in zip(phases, parent.phases()):
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom, original in zip(phase.atoms(), source.atoms()):
            base = np.asarray(original.coordinates, float)
            current = np.asarray(atom.coordinates, float)
            delta = (current - base + 0.5) % 1.0 - 0.5
            scale = args.oxygen_scale if atom.element == "O" else args.heavy_scale
            atom.coordinates = tuple(base + scale * delta)
            atom.refinement_flags = " "
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    for key in ["Shift", "SurfRoughA", "SurfRoughB"]:
        hist.SampleParameters[key][1] = False
    project.set_Controls("cycles", 15)
    project.set_Frozen()
    project.refine(printFile=str(folder / "scaled.lst"))
    project.save()
    masses = np.asarray([p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in phases])
    result = {
        "heavy_scale": args.heavy_scale,
        "oxygen_scale": args.oxygen_scale,
        "rwp_percent": hist.get_wR(),
        "fractions": (masses / masses.sum()).tolist(),
    }
    (folder / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
