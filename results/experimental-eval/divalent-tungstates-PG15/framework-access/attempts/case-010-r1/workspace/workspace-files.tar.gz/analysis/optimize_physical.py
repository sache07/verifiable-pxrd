#!/usr/bin/env python3
"""Physically bounded staged refinement of the selected WO3/Mn2O3 model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


INSTRUMENT_KEYS = ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]


def fractions(phases, histogram_name):
    weighted = np.asarray(
        [p.data["General"]["Mass"] * p.data["Histograms"][histogram_name]["Scale"][0] for p in phases]
    )
    return weighted / weighted.sum()


def clear_nonlinear_flags(hist, phases):
    hist.clear_refinements({"Instrument Parameters": INSTRUMENT_KEYS})
    hist.SampleParameters["Shift"][1] = False
    hist.SampleParameters["SurfRoughA"][1] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "


def stage(project, hist, phases, folder, label, cycles=25):
    project.set_Controls("cycles", cycles)
    project.set_Frozen()
    project.refine(printFile=str(folder / f"{label}.lst"))
    project.save()
    shutil.copy2(folder / "physical.gpx", folder / f"{label}.gpx")
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(
        f"{label:28s} Rwp={hist.get_wR():.6f} GOF={rvals.get('GOF', float('nan')):.5f} "
        f"fractions={fractions(phases, hist.name)}",
        flush=True,
    )


def set_common_limits(project, hist, phases):
    project.index_ids()
    hid = hist.id
    for key, low, high in [
        ("Zero", -0.25, 0.25),
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
        ("Polariz.", 0.5, 1.0),
        ("Shift", -800.0, 800.0),
        ("SurfRoughA", 0.0, 0.6),
        ("SurfRoughB", 0.02, 0.5),
    ]:
        project.set_Controls("parmMin", low, variable=f":{hid}:{key}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{key}")
    for phase in phases:
        pid = phase.id
        for key, low, high in [
            ("Scale", 0.0, 100.0),
            ("Size;i", 0.04, 1.5),
            ("Mustrain;i", 0.0, 8000.0),
            ("Mustrain;a", 0.0, 8000.0),
            ("MD", 0.7, 1.4),
        ]:
            project.set_Controls("parmMin", low, variable=f"{pid}:{hid}:{key}")
            project.set_Controls("parmMax", high, variable=f"{pid}:{hid}:{key}")
        for index, _ in enumerate(phase.atoms()):
            project.set_Controls("parmMin", 0.003, variable=f"{pid}::AUiso:{index}")
            project.set_Controls("parmMax", 0.020, variable=f"{pid}::AUiso:{index}")


def atom_snapshot(phases):
    return [
        [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(map(float, atom.coordinates)),
                "uiso": float(atom.uiso),
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ]
        for phase in phases
    ]


def clip_coordinates(phases, parent_atoms, elements, limit):
    """Keep refined sites close to the registered parent using wrapped fractions."""
    for phase, reference in zip(phases, parent_atoms):
        for atom, original in zip(phase.atoms(), reference):
            if atom.element not in elements:
                continue
            old = np.asarray(original["coordinates"], float)
            new = np.asarray(atom.coordinates, float)
            delta = (new - old + 0.5) % 1.0 - 0.5
            atom.coordinates = tuple(old + np.clip(delta, -limit, limit))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--shift", type=float, required=True, help="Fixed GSAS-II sample Shift in micrometres")
    parser.add_argument("--coordinate-limit", type=float, default=0.010)
    args = parser.parse_args()
    folder = args.output.resolve()
    folder.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(folder / "physical.gpx"))
    hist = project.histogram(0)
    phases = project.phases()
    if len(phases) != 2:
        raise ValueError("This optimizer expects exactly two phases")
    clear_nonlinear_flags(hist, phases)
    parent_atoms = atom_snapshot(phases)
    set_common_limits(project, hist, phases)
    # Start from profile effects selected by earlier exhaustive axis tests.
    wo_hap = phases[0].data["Histograms"][hist.name]
    mn_hap = phases[1].data["Histograms"][hist.name]
    wo_hap["Size"][0] = "isotropic"
    wo_hap["Size"][1][0] = 0.09
    wo_hap["Mustrain"][0] = "uniaxial"
    wo_hap["Mustrain"][1][0:2] = [1100.0, 4800.0]
    wo_hap["Mustrain"][3] = [1, 0, 0]
    wo_hap["Pref.Ori."][0:4] = ["MD", 0.93, False, [1, 1, 0]]
    mn_hap["Size"][0] = "isotropic"
    mn_hap["Size"][1][0] = 0.096
    mn_hap["Mustrain"][0] = "isotropic"
    mn_hap["Mustrain"][1][0] = 2400.0
    mn_hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]

    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [float(args.shift), False]
    # The no-height fit gave Zero about +0.335 degrees; initialize its correlated
    # value for the fixed displacement branch and enforce the stated physical range.
    hist.InstrumentParameters["Zero"][1] = float(np.clip(0.335 + 0.000644 * args.shift, -0.24, 0.24))
    hist.InstrumentParameters["Zero"][2] = False
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.1, False]
    project.save()

    # Peak positions and specimen offset.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stage(project, hist, phases, folder, "01_cells_zero")
    clear_nonlinear_flags(hist, phases)

    # Separate the principal Gaussian/Lorentzian and specimen broadening terms.
    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    stage(project, hist, phases, folder, "02_sizes")
    clear_nonlinear_flags(hist, phases)

    phases[0].set_HAP_refinements({"Mustrain": {"type": "uniaxial", "direction": [1, 0, 0], "refine": True}})
    phases[1].set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    stage(project, hist, phases, folder, "03_strains")
    clear_nonlinear_flags(hist, phases)

    for number, key in enumerate(["W", "U", "X"], start=4):
        hist.set_refinements({"Instrument Parameters": [key]})
        stage(project, hist, phases, folder, f"{number:02d}_instrument_{key}")
        clear_nonlinear_flags(hist, phases)

    phases[0].set_HAP_refinements({"Mustrain": {"type": "uniaxial", "direction": [1, 0, 0], "refine": True}, "Size": {"type": "isotropic", "refine": True}})
    phases[1].set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}, "Size": {"type": "isotropic", "refine": True}})
    stage(project, hist, phases, folder, "07_phase_widths")
    clear_nonlinear_flags(hist, phases)

    hist.set_refinements({"Instrument Parameters": ["SH/L", "Polariz."]})
    stage(project, hist, phases, folder, "08_axial_polarization")
    clear_nonlinear_flags(hist, phases)

    # Cell/offset recoupling after the widths are realistic.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stage(project, hist, phases, folder, "09_cells_zero")
    clear_nonlinear_flags(hist, phases)

    for phase in phases:
        phase.set_refinements({"Atoms": {"all": "U"}})
    stage(project, hist, phases, folder, "10_uiso")
    clear_nonlinear_flags(hist, phases)

    phases[0].set_HAP_refinements({"Pref.Ori.": True})
    stage(project, hist, phases, folder, "11_wo3_texture")
    clear_nonlinear_flags(hist, phases)

    # Reference mismatch is small by construction. Take one linearized step for
    # each element class and clip it to the allowed vicinity of the parent. This
    # avoids unstable repeated coordinate steps for weak oxygen scattering.
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = "X" if atom.element == "W" else " "
    stage(project, hist, phases, folder, "12_w_coordinates_step", cycles=1)
    clip_coordinates(phases, parent_atoms, {"W"}, args.coordinate_limit)
    clear_nonlinear_flags(hist, phases)
    stage(project, hist, phases, folder, "13_w_coordinates_clipped", cycles=8)

    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = "X" if atom.element == "Mn" else " "
    stage(project, hist, phases, folder, "14_mn_coordinates_step", cycles=1)
    clip_coordinates(phases, parent_atoms, {"Mn"}, min(args.coordinate_limit, 0.006))
    clear_nonlinear_flags(hist, phases)
    stage(project, hist, phases, folder, "15_mn_coordinates_clipped", cycles=8)

    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = "X" if atom.element == "O" else " "
    stage(project, hist, phases, folder, "16_o_coordinates_step", cycles=1)
    clip_coordinates(phases, parent_atoms, {"O"}, args.coordinate_limit)
    clear_nonlinear_flags(hist, phases)
    stage(project, hist, phases, folder, "17_o_coordinates_clipped", cycles=8)

    # One final alternation of profile and position parameters.
    phases[0].set_HAP_refinements({"Mustrain": {"type": "uniaxial", "direction": [1, 0, 0], "refine": True}, "Size": {"type": "isotropic", "refine": True}})
    phases[1].set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}, "Size": {"type": "isotropic", "refine": True}})
    hist.set_refinements({"Instrument Parameters": ["W", "U", "X"]})
    stage(project, hist, phases, folder, "18_profiles_joint")
    clear_nonlinear_flags(hist, phases)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stage(project, hist, phases, folder, "19_cells_zero_final")
    clear_nonlinear_flags(hist, phases)

    # End with only linear scale/background terms active.
    stage(project, hist, phases, folder, "20_linear_final", cycles=15)
    clear_nonlinear_flags(hist, phases)
    project.save()

    x = np.asarray(hist.getdata("X"), float)
    observed = np.asarray(hist.getdata("Yobs"), float)
    calculated = np.asarray(hist.getdata("Ycalc"), float)
    np.savetxt(
        folder / "fit.csv",
        np.column_stack([x, observed, calculated, observed - calculated]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
    )
    result = {
        "rwp_percent": hist.get_wR(),
        "fractions": fractions(phases, hist.name).tolist(),
        "fixed_shift_um": args.shift,
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.data["Background"],
        "cells": [phase.get_cell() for phase in phases],
        "profiles": [phase.data["Histograms"][hist.name] for phase in phases],
        "parent_atoms": parent_atoms,
        "refined_atoms": atom_snapshot(phases),
        "rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
        "frozen": project.data.get("Controls", {}).get("data", {}).get("parmFrozen", {}),
    }
    (folder / "summary.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps({k: result[k] for k in ["rwp_percent", "fractions", "fixed_shift_um", "cells", "rvals", "frozen"]}, indent=2, default=str))


if __name__ == "__main__":
    main()
