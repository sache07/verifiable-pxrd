#!/usr/bin/env python3
"""Branch a refined GPX to test one physically motivated profile/specimen effect."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def fractions(phases, histname):
    mass = np.array([p.data["General"]["Mass"] * p.data["Histograms"][histname]["Scale"][0] for p in phases])
    return mass / mass.sum()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("effect", choices=["shift", "uniaxial", "texture", "roughness"])
    parser.add_argument("--phase", type=int, default=0)
    parser.add_argument("--axis", default="0,0,1")
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]
    folder = args.output.resolve()
    folder.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(folder / "effect.gpx"))
    hist = project.histogram(0)
    phases = project.phases()
    # Hold already-refined nonlinear terms while testing one additional effect.
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
    )
    hist.SampleParameters["Shift"][1] = False
    hist.SampleParameters["SurfRoughA"][1] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    pid, hid = phases[args.phase].id, hist.id

    if args.effect == "shift":
        hist.SampleParameters["Shift"] = [-300.0, True]
        hist.InstrumentParameters["Zero"][2] = True
        for phase in phases:
            phase.set_refinements({"Cell": True})
        project.set_Controls("parmMin", -1000.0, variable=f":{hid}:Shift")
        project.set_Controls("parmMax", 1000.0, variable=f":{hid}:Shift")
        project.set_Controls("parmMin", -1.0, variable=f":{hid}:Zero")
        project.set_Controls("parmMax", 1.0, variable=f":{hid}:Zero")
    elif args.effect == "uniaxial":
        hap = phases[args.phase].data["Histograms"][hist.name]
        value = max(1.0, float(hap["Mustrain"][1][0]))
        hap["Mustrain"][1][0] = value
        hap["Mustrain"][1][1] = value
        phases[args.phase].set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}}
        )
        for key in ("Mustrain;i", "Mustrain;a"):
            project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:{key}")
            project.set_Controls("parmMax", 10000.0, variable=f"{pid}:{hid}:{key}")
    elif args.effect == "texture":
        hap = phases[args.phase].data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = axis
        phases[args.phase].set_HAP_refinements({"Pref.Ori.": True})
        project.set_Controls("parmMin", 0.6, variable=f"{pid}:{hid}:MD")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:{hid}:MD")
    else:
        hist.SampleParameters["SurfRoughA"] = [0.3, True]
        hist.SampleParameters["SurfRoughB"] = [0.10, True]
        project.set_Controls("parmMin", 0.0, variable=f":{hid}:SurfRoughA")
        project.set_Controls("parmMax", 0.9, variable=f":{hid}:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=f":{hid}:SurfRoughB")
        project.set_Controls("parmMax", 2.0, variable=f":{hid}:SurfRoughB")

    project.set_Controls("cycles", 60)
    project.set_Frozen()
    project.refine(printFile=str(folder / "effect.lst"))
    project.save()
    phase = phases[args.phase]
    result = {
        "effect": args.effect,
        "phase": args.phase,
        "axis": axis,
        "rwp_percent": hist.get_wR(),
        "fractions": fractions(phases, hist.name).tolist(),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "hap": phase.data["Histograms"][hist.name],
        "cells": [p.get_cell() for p in phases],
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }
    (folder / "summary.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
