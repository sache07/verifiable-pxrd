#!/usr/bin/env python3
"""Test whether a third crystalline phase is supported by a refined residual."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def fractions(phases, histname):
    mass = np.array([p.data["General"]["Mass"] * p.data["Histograms"][histname]["Scale"][0] for p in phases])
    return mass / mass.sum()


def run(project, hist, phases, folder, label):
    project.set_Controls("cycles", 40)
    project.set_Frozen()
    project.refine(printFile=str(folder / f"{label}.lst"))
    project.save()
    print(label, "Rwp", hist.get_wR(), "fractions", fractions(phases, hist.name), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("cod_id")
    parser.add_argument("output", type=Path)
    parser.add_argument("--positions", action="store_true")
    args = parser.parse_args()
    folder = args.output.resolve()
    folder.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(folder / "extra.gpx"))
    hist = project.histogram(0)
    # Freeze the nonlinear parameters of the established phases for the initial test.
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
    )

    extra = project.add_phase(
        str(cod_path(args.cod_id)),
        phasename=f"extra_{args.cod_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    phases = project.phases()
    hap = extra.data["Histograms"][hist.name]
    hap["Scale"] = [0.5, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.10
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1200.0
    hap["Mustrain"][1][1] = 1200.0
    hap["Mustrain"][2] = [False, False, False]
    for atom in extra.atoms():
        atom.uiso = 0.01
        atom.refinement_flags = " "
    project.save()
    project.index_ids()
    pid, hid = extra.id, hist.id
    for key, low, high in [("Scale", 0.0, 100.0), ("Size;i", 0.02, 3.0), ("Mustrain;i", 0.0, 10000.0)]:
        project.set_Controls("parmMin", low, variable=f"{pid}:{hid}:{key}")
        project.set_Controls("parmMax", high, variable=f"{pid}:{hid}:{key}")

    run(project, hist, phases, folder, "01_scale")
    if fractions(phases, hist.name)[-1] > 0.002:
        extra.set_refinements({"Cell": True})
        run(project, hist, phases, folder, "02_cell")
        extra.clear_refinements({"Cell": True})
        extra.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
        run(project, hist, phases, folder, "03_profile")
        extra.clear_HAP_refinements({"Size": True, "Mustrain": True})
        if args.positions:
            extra.set_refinements({"Atoms": {"all": "X"}})
            run(project, hist, phases, folder, "04_positions")

    result = {
        "cod_id": args.cod_id,
        "rwp_percent": hist.get_wR(),
        "fractions": fractions(phases, hist.name).tolist(),
        "extra_cell": extra.get_cell(),
        "extra_hap": extra.data["Histograms"][hist.name],
    }
    (folder / "summary.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
