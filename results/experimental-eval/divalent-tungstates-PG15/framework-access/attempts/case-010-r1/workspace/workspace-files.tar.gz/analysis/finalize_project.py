#!/usr/bin/env python3
"""Freeze the selected GPX and export its exact phase models."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
INSTRUMENT_KEYS = ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(ROOT / "final.gpx"))
    hist = project.histogram(0)
    phases = project.phases()

    # Freeze every nonlinear flag. Values and the final covariance record remain
    # unchanged; this makes the submitted project a static, replayable model.
    hist.clear_refinements({"Instrument Parameters": INSTRUMENT_KEYS})
    hist.data["Background"][0][1] = False
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.save()

    filenames = ["phase_1_WO3.cif", "phase_2_Mn2O3.cif"]
    covariance = project.data.get("Covariance", {}).get("data", {})
    project.data["Covariance"]["data"] = {}
    try:
        for phase, filename in zip(phases, filenames):
            phase.export_CIF(str(ROOT / filename))
    finally:
        project.data["Covariance"]["data"] = covariance

    weighted = np.asarray(
        [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in phases]
    )
    summary = {
        "histogram": hist.name,
        "project_rwp_percent": hist.get_wR(),
        "fractions": (weighted / weighted.sum()).tolist(),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.data["Background"],
        "phases": [
            {
                "name": phase.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cell": phase.get_cell(),
                "cif_path": filename,
                "mass": phase.data["General"]["Mass"],
                "scale": phase.data["Histograms"][hist.name]["Scale"],
                "profile": phase.data["Histograms"][hist.name],
                "uiso_A2": [float(atom.uiso) for atom in phase.atoms()],
            }
            for phase, filename in zip(phases, filenames)
        ],
        "covariance_rvals": covariance.get("Rvals", {}),
    }
    (ROOT / "analysis" / "final_project_summary.json").write_text(
        json.dumps(summary, indent=2, default=str) + "\n"
    )
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
