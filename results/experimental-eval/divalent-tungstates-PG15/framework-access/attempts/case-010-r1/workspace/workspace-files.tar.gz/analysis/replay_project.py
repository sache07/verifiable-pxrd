#!/usr/bin/env python3
"""Run the frozen scorer's read-only GSAS-II replay on a project."""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WORKER = ROOT / "learned" / "divalent-tungstates" / "scorer" / "runtime" / "replay_worker.py"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--histogram")
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    spec = importlib.util.spec_from_file_location("frozen_replay_worker", WORKER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    request = {
        "project": str(args.project.resolve()),
        "observed": str((ROOT / "inputs" / "pattern.csv").resolve()),
    }
    if args.histogram:
        request["histogram"] = args.histogram
    old = Path.cwd()
    os.chdir(output)
    try:
        result = module.replay(request)
    finally:
        os.chdir(old)
    (output / "replay.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
