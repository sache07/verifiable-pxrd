#!/usr/bin/env python3
"""Refine one nonlinear parameter group from a GPX for controlled branching."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


INST = ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "kind",
        choices=["wo_strain", "mn_strain", "wo_size", "mn_size", "U", "W", "X", "SHL", "polarization", "texture", "zero", "shift", "roughness"],
    )
    parser.add_argument("--cycles", type=int, default=30)
    args = parser.parse_args()
    folder = args.output.resolve()
    folder.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(folder / "refined.gpx"))
    hist = project.histogram(0)
    phases = project.phases()
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    hist.clear_refinements({"Instrument Parameters": INST})
    for key in ["Shift", "SurfRoughA", "SurfRoughB"]:
        hist.SampleParameters[key][1] = False
    project.index_ids()
    hid = hist.id
    if args.kind == "wo_strain":
        axis = list(phases[0].data["Histograms"][hist.name]["Mustrain"][3])
        phases[0].set_HAP_refinements({"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}})
        project.set_Controls("parmMin", 0.0, variable=f"{phases[0].id}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{phases[0].id}:{hid}:Mustrain;i")
        project.set_Controls("parmMin", 0.0, variable=f"{phases[0].id}:{hid}:Mustrain;a")
        project.set_Controls("parmMax", 32000.0, variable=f"{phases[0].id}:{hid}:Mustrain;a")
    elif args.kind == "mn_strain":
        phases[1].set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        project.set_Controls("parmMin", 0.0, variable=f"{phases[1].id}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{phases[1].id}:{hid}:Mustrain;i")
    elif args.kind in {"wo_size", "mn_size"}:
        index = 0 if args.kind == "wo_size" else 1
        phases[index].set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        project.set_Controls("parmMin", 0.04, variable=f"{phases[index].id}:{hid}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{phases[index].id}:{hid}:Size;i")
    elif args.kind in {"U", "W", "X"}:
        hist.set_refinements({"Instrument Parameters": [args.kind]})
        bounds = {"U": (0.0, 40.0), "W": (2.0, 40.0), "X": (0.1, 6.0)}[args.kind]
        project.set_Controls("parmMin", bounds[0], variable=f":{hid}:{args.kind}")
        project.set_Controls("parmMax", bounds[1], variable=f":{hid}:{args.kind}")
    elif args.kind == "SHL":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.set_Controls("parmMin", 0.005, variable=f":{hid}:SH/L")
        project.set_Controls("parmMax", 0.1, variable=f":{hid}:SH/L")
    elif args.kind == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.5, variable=f":{hid}:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=f":{hid}:Polariz.")
    elif args.kind == "texture":
        phases[0].set_HAP_refinements({"Pref.Ori.": True})
        project.set_Controls("parmMin", 0.7, variable=f"{phases[0].id}:{hid}:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{phases[0].id}:{hid}:MD")
    elif args.kind == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        project.set_Controls("parmMin", -0.25, variable=f":{hid}:Zero")
        project.set_Controls("parmMax", 0.25, variable=f":{hid}:Zero")
    elif args.kind == "shift":
        hist.SampleParameters["Shift"][1] = True
        project.set_Controls("parmMin", -800.0, variable=f":{hid}:Shift")
        project.set_Controls("parmMax", 800.0, variable=f":{hid}:Shift")
    else:
        hist.SampleParameters["SurfRoughA"] = [0.2, True]
        hist.SampleParameters["SurfRoughB"] = [0.1, True]
        project.set_Controls("parmMin", 0.0, variable=f":{hid}:SurfRoughA")
        project.set_Controls("parmMax", 0.6, variable=f":{hid}:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=f":{hid}:SurfRoughB")
        project.set_Controls("parmMax", 0.5, variable=f":{hid}:SurfRoughB")
    project.set_Controls("cycles", args.cycles)
    project.set_Frozen()
    project.refine(printFile=str(folder / "refined.lst"))
    project.save()
    masses = np.asarray([p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in phases])
    result = {
        "kind": args.kind,
        "rwp_percent": hist.get_wR(),
        "fractions": (masses / masses.sum()).tolist(),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "profiles": [p.data["Histograms"][hist.name] for p in phases],
        "cells": [p.get_cell() for p in phases],
        "rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }
    (folder / "summary.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps({"kind": args.kind, "rwp_percent": result["rwp_percent"], "fractions": result["fractions"]}))


if __name__ == "__main__":
    main()
