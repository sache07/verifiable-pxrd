#!/usr/bin/env python3
"""Evaluate a fixed specimen-height branch with correlated zero held physical."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--shift", type=float, required=True)
    parser.add_argument("--reference-shift", type=float, default=-400.0)
    parser.add_argument("--slope", type=float, default=0.000644)
    args = parser.parse_args()
    folder = args.output.resolve()
    folder.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(folder / "shift.gpx"))
    hist = project.histogram(0)
    phases = project.phases()
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    hist.SampleParameters["Shift"][1] = False
    old_shift = float(hist.SampleParameters["Shift"][0])
    old_zero = float(hist.InstrumentParameters["Zero"][1])
    # Usually old_shift equals reference_shift; retaining both makes the saved
    # project self-describing if a different reference is supplied.
    reference_zero = old_zero + args.slope * (args.reference_shift - old_shift)
    new_zero = reference_zero + args.slope * (args.shift - args.reference_shift)
    hist.SampleParameters["Shift"] = [float(args.shift), False]
    hist.InstrumentParameters["Zero"][1] = float(new_zero)
    hist.InstrumentParameters["Zero"][2] = False
    project.set_Controls("cycles", 12)
    project.set_Frozen()
    project.refine(printFile=str(folder / "shift.lst"))
    project.save()
    masses = np.asarray([p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in phases])
    result = {
        "shift_um": args.shift,
        "zero_deg": hist.InstrumentParameters["Zero"][1],
        "rwp_percent": hist.get_wR(),
        "fractions": (masses / masses.sum()).tolist(),
        "cells": [p.get_cell() for p in phases],
    }
    (folder / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
