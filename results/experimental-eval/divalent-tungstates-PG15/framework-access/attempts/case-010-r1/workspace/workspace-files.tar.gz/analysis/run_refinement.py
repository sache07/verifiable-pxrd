#!/usr/bin/env python3
"""Build and stage a GSAS-II refinement for a selected COD phase pair."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def phase_weight_fractions(phases, histogram_name: str) -> np.ndarray:
    masses = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][histogram_name]["Scale"][0] for p in phases],
        dtype=float,
    )
    return masses / masses.sum()


def stage(project, hist, phases, outdir: Path, label: str) -> None:
    project.set_Controls("cycles", 25)
    project.refine(printFile=str(outdir / f"{label}.lst"))
    project.save()
    print(f"{label:24s} Rwp={hist.get_wR():9.5f} fractions={phase_weight_fractions(phases, hist.name)}")


def summarize(project, hist, phases) -> dict:
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "histogram": hist.name,
        "rwp_percent": hist.get_wR(),
        "histogram_results": hist.data["data"][0],
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.data["Background"],
        "fractions": phase_weight_fractions(phases, hist.name).tolist(),
        "covariance": {
            "Rvals": cov.get("Rvals"),
            "varyList": cov.get("varyList", []),
            "sig": np.asarray(cov.get("sig", []), dtype=float).tolist(),
        },
        "phases": [],
    }
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": a.label,
                        "element": a.element,
                        "xyz": a.coordinates,
                        "uiso": a.uiso,
                        "flags": a.refinement_flags,
                    }
                    for a in phase.atoms()
                ],
            }
        )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="2311041")
    parser.add_argument("--mn2o3", default="1514103")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--positions", action="store_true")
    args = parser.parse_args()

    outdir = args.out.resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project_path = outdir / "trial.gpx"
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(project_path))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "analysis" / "instrument.instprm"),
        fmthint="comma/tab/semicolon separated",
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.InstrumentParameters["Zero"][1] = 0.30
    for key, value in {"U": 15.0, "W": 12.0, "X": 1.5, "SH/L": 0.03, "Polariz.": 0.75}.items():
        hist.InstrumentParameters[key][1] = value

    phases = [
        project.add_phase(
            str(cod_path(args.wo3)), phasename=f"WO3_{args.wo3}", histograms=[hist], fmthint="CIF"
        ),
        project.add_phase(
            str(cod_path(args.mn2o3)), phasename=f"Mn2O3_{args.mn2o3}", histograms=[hist], fmthint="CIF"
        ),
    ]
    initial_fractions = [0.75, 0.25]
    for phase, fraction in zip(phases, initial_fractions):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 * fraction / phase.data["General"]["Mass"], False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][1][1] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.uiso = 0.01
            atom.refinement_flags = " "

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1200.0] + [0.0] * 11,
                "refine": True,
            },
            "Instrument Parameters": ["Zero"],
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    project.save()
    project.index_ids()
    hid = hist.id
    for key, low, high in [
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
        ("Polariz.", 0.5, 1.0),
        ("Zero", -1.0, 1.0),
    ]:
        project.set_Controls("parmMin", low, variable=f":{hid}:{key}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{key}")
    for phase in phases:
        pid = phase.id
        for key, low, high in [
            ("Scale", 0.0, 100.0),
            ("Size;i", 0.02, 3.0),
            ("Mustrain;i", 0.0, 10000.0),
        ]:
            project.set_Controls("parmMin", low, variable=f"{pid}:{hid}:{key}")
            project.set_Controls("parmMax", high, variable=f"{pid}:{hid}:{key}")
        for i, _ in enumerate(phase.atoms()):
            project.set_Controls("parmMin", 0.001, variable=f"{pid}::AUiso:{i}")
            project.set_Controls("parmMax", 0.03, variable=f"{pid}::AUiso:{i}")
    stage(project, hist, phases, outdir, "01_scale_bg_zero")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    stage(project, hist, phases, outdir, "02_cells")
    for phase in phases:
        phase.clear_refinements({"Cell": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})

    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.3, "refine": True}})
    stage(project, hist, phases, outdir, "03_sizes")
    for phase in phases:
        phase.clear_HAP_refinements({"Size": True})

    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    stage(project, hist, phases, outdir, "04_strain")
    for phase in phases:
        phase.clear_HAP_refinements({"Mustrain": True})

    for number, key in enumerate(["W", "U", "X"], start=5):
        hist.set_refinements({"Instrument Parameters": [key]})
        stage(project, hist, phases, outdir, f"{number:02d}_instrument_{key}")
        hist.clear_refinements({"Instrument Parameters": [key]})

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    stage(project, hist, phases, outdir, "08_phase_widths")
    for phase in phases:
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})

    hist.set_refinements({"Instrument Parameters": ["SH/L", "Polariz."]})
    stage(project, hist, phases, outdir, "09_axial_polarization")
    hist.clear_refinements({"Instrument Parameters": ["SH/L", "Polariz."]})

    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": 16, "refine": True}}
    )
    stage(project, hist, phases, outdir, "10_background16")

    # The generator applies one isotropic displacement parameter per phase.
    # Tie all Uiso values within each phase and refine one value per phase.
    project.save()
    project.index_ids()
    for phase in phases:
        phase.set_refinements({"Atoms": {"all": "U"}})
        varlist = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(varlist) > 1:
            project.add_EquivConstr(varlist, reloadIdx=False)
    stage(project, hist, phases, outdir, "11_uiso")

    if args.positions:
        for phase in phases:
            phase.set_refinements({"Atoms": {"all": "XU"}})
        stage(project, hist, phases, outdir, "12_positions")

    summary = summarize(project, hist, phases)
    (outdir / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    x = np.asarray(hist.getdata("X"), dtype=float)
    obs = np.asarray(hist.getdata("Yobs"), dtype=float)
    calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
    np.savetxt(
        outdir / "fit.csv",
        np.column_stack([x, obs, calc, obs - calc]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
    )
    print(
        json.dumps(
            {
                "rwp_percent": summary["rwp_percent"],
                "fractions": summary["fractions"],
                "instrument": summary["instrument"],
                "sample": summary["sample"],
                "phases": [
                    {k: phase[k] for k in ("name", "cell", "scale", "size", "mustrain", "preferred_orientation")}
                    for phase in summary["phases"]
                ],
            },
            indent=2,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
