#!/usr/bin/env python3
"""Plot observed, calculated, background and difference curves from GPX files."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--xmin", type=float)
    parser.add_argument("--xmax", type=float)
    parser.add_argument("projects", nargs="+", type=Path)
    args = parser.parse_args()

    G2.SetPrintLevel("error")
    fig, axes = plt.subplots(len(args.projects), 1, figsize=(16, 4 * len(args.projects)), squeeze=False)
    for ax, filename in zip(axes[:, 0], args.projects):
        project = G2.G2Project(gpxfile=str(filename.resolve()))
        hist = project.histogram(0)
        x = np.asarray(hist.getdata("X"), float)
        obs = np.asarray(hist.getdata("Yobs"), float)
        calc = np.asarray(hist.getdata("Ycalc"), float)
        bkg = np.asarray(hist.getdata("Background"), float)
        difference = obs - calc
        offset = -0.28 * np.max(obs)
        ax.plot(x, obs, color="black", lw=0.45, label="observed")
        ax.plot(x, calc, color="tab:red", lw=0.7, label="calculated")
        ax.plot(x, bkg, color="tab:green", lw=0.6, label="background")
        ax.plot(x, difference + offset, color="tab:blue", lw=0.45, label="difference (offset)")
        ax.axhline(offset, color="0.65", lw=0.4)
        ax.set_xlim(args.xmin if args.xmin is not None else x[0], args.xmax if args.xmax is not None else x[-1])
        ax.set_title(f"{filename}: Rwp={hist.get_wR():.4f}%")
        ax.set_ylabel("counts")
        ax.legend(loc="upper right", ncol=4, fontsize=8)
    axes[-1, 0].set_xlabel(r"$2\theta$ (degrees)")
    fig.tight_layout()
    fig.savefig(args.output, dpi=180)


if __name__ == "__main__":
    main()
