from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / ".tmp" / "inspect_gsas"
WORK.mkdir(parents=True, exist_ok=True)

G2.SetPrintLevel("warn")
project = G2.G2Project(newgpx=str(WORK / "inspect.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "analysis" / "instrument.instprm"),
    fmthint="comma/tab/semicolon separated",
)
print(hist.name)
for name in ("X", "Yobs", "Yweight"):
    values = np.asarray(hist.getdata(name), dtype=float)
    print(name, values.shape, values[:4], values.min(), values.max())
print("limits", hist.data["Limits"])
print("sample", hist.SampleParameters)
print("instrument", hist.InstrumentParameters)
project.save()
