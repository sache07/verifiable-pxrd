#!/usr/bin/env python3
"""Continue a trial GPX with staged atomic-coordinate refinement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def fractions(phases, histname):
    values = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][histname]["Scale"][0] for p in phases]
    )
    return values / values.sum()


def refine(project, hist, phases, folder, name):
    project.set_Controls("cycles", 50)
    project.set_Frozen()
    project.refine(printFile=str(folder / f"{name}.lst"))
    project.save()
    print(name, "Rwp", hist.get_wR(), "fractions", fractions(phases, hist.name), flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("input", type=Path)
    p.add_argument("output", type=Path)
    args = p.parse_args()
    folder = args.output.resolve()
    folder.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(folder / "positions.gpx"))
    hist = project.histogram(0)
    phases = project.phases()

    phases[0].set_refinements({"Atoms": {"all": "XU"}})
    refine(project, hist, phases, folder, "01_wo3_positions")

    phases[1].set_refinements({"Atoms": {"all": "XU"}})
    refine(project, hist, phases, folder, "02_all_positions")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, hist, phases, folder, "03_cells_zero")

    result = {
        "rwp_percent": hist.get_wR(),
        "fractions": fractions(phases, hist.name).tolist(),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "phases": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "hap": phase.data["Histograms"][hist.name],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": atom.coordinates,
                        "uiso": atom.uiso,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
            for phase in phases
        ],
        "covariance": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }
    (folder / "summary.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    x = np.asarray(hist.getdata("X"), float)
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    np.savetxt(
        folder / "fit.csv",
        np.column_stack([x, obs, calc, obs - calc]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
    )
    print(json.dumps({"rwp_percent": result["rwp_percent"], "fractions": result["fractions"]}, indent=2))


if __name__ == "__main__":
    main()
