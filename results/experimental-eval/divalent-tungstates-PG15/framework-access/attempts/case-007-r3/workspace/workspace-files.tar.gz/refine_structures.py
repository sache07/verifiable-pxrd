#!/usr/bin/env python3
"""Apply the same staged structural refinement to a three-phase trial GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def rwp(project: G2.G2Project, label: str, log: list[dict]) -> None:
    value = float(project.histograms()[0].get_wR())
    log.append({"stage": label, "Rwp_percent": value})
    print(f"{label}: {value:.6f}%")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(Path(args.input).resolve()), newgpx=str(Path(args.output).resolve())
    )
    project.set_Controls("cycles", 10)
    hist = project.histograms()[0]
    phases = project.phases()
    log: list[dict] = []

    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    hist.data["Instrument Parameters"][0]["Polariz."][1] = 0.8
    for phase in phases:
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        for atom in phase.atoms():
            atom.refinement_flags = " "

    # Determine the dominant phase's permitted March-Dollase [110] component
    # before allowing its coordinates to move.
    primary = phases[0]
    primary_hap = primary.data["Histograms"][hist.name]
    primary_hap["Pref.Ori."][1] = 1.0
    primary_hap["Pref.Ori."][3] = [1, 1, 0]
    primary.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    project.refine(makeBack=False)
    rwp(project, "primary_texture", log)

    # The generator applies one isotropic U value per phase. Equality
    # constraints retain that physical model while positions are refined.
    for atom in primary.atoms():
        atom.uiso = 0.008
        atom.refinement_flags = "XU"
    project.save()
    project.add_EquivConstr(
        tuple(f"{primary.id}::AUiso:{i}" for i in range(len(primary.atoms())))
    )
    project.refine(makeBack=False)
    rwp(project, "primary_coordinates", log)
    for atom in primary.atoms():
        atom.refinement_flags = " "

    secondary = phases[1]
    for atom in secondary.atoms():
        atom.uiso = 0.008
        atom.refinement_flags = "XU" if atom.element == "W" else "U"
    project.save()
    project.add_EquivConstr(
        tuple(f"{secondary.id}::AUiso:{i}" for i in range(len(secondary.atoms())))
    )
    project.refine(makeBack=False)
    rwp(project, "secondary_heavy_coordinates", log)
    for atom in secondary.atoms():
        atom.refinement_flags = " "

    tertiary = phases[2]
    for atom in tertiary.atoms():
        atom.uiso = 0.008
        atom.refinement_flags = "U"
    project.save()
    project.add_EquivConstr(
        tuple(f"{tertiary.id}::AUiso:{i}" for i in range(len(tertiary.atoms())))
    )
    project.refine(makeBack=False)
    rwp(project, "tertiary_Uiso", log)
    for atom in tertiary.atoms():
        atom.refinement_flags = " "

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    project.refine(makeBack=False)
    rwp(project, "profile", log)

    project.save(str(Path(args.output).resolve()))
    Path(args.output).with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
