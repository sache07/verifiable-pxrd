#!/usr/bin/env python3
"""Write the final profile, machine-readable result, and concise analysis report."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY_DIR = ROOT / ".tmp" / "replay-final"


def main() -> None:
    replay = json.loads((REPLAY_DIR / "replay.json").read_text())
    model = json.loads((ROOT / ".tmp" / "final_model.json").read_text())
    if replay["status"] != "replayed" or not replay["project_unchanged"]:
        raise RuntimeError("The final project did not replay unchanged")
    if replay["profile_review_flags"]:
        raise RuntimeError(f"Replay profile flags: {replay['profile_review_flags']}")

    with np.load(REPLAY_DIR / "prediction.npz", allow_pickle=False) as arrays:
        x = arrays["x"].copy()
        observed = arrays["observed"].copy()
        calculated = arrays["predicted"].copy()
    difference = observed - calculated

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        # `two_theta` is in degrees; the compact spelling is also recognized by
        # the independent profile checker used for this task.
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        for xx, yo, yc, yd in zip(x, observed, calculated, difference):
            writer.writerow([f"{xx:.8f}", f"{yo:.8f}", f"{yc:.10f}", f"{yd:.10f}"])

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = 100.0 * math.sqrt(chi_square / denominator)
    rp = 100.0 * float(np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    n_points = int(len(x))
    n_parameters = 40
    r_exp = 100.0 * math.sqrt((n_points - n_parameters) / denominator)
    goodness_of_fit = math.sqrt(chi_square / (n_points - n_parameters))

    cif_by_name = {
        "MgWO4": "phase_MgWO4.cif",
        "WO3": "phase_WO3.cif",
        "MgO": "phase_MgO.cif",
    }
    formula_by_name = {"MgWO4": "MgWO4", "WO3": "WO3", "MgO": "MgO"}
    parent_by_name = {"MgWO4": "COD 9013902", "WO3": "COD 2311041", "MgO": "COD 9000499"}
    model_rows = {row["name"]: row for row in model["phases"]}
    phases = []
    for phase in replay["phases"]:
        name = phase["name"]
        row = model_rows[name]
        phases.append(
            {
                "name": name,
                "formula": formula_by_name[name],
                "space_group": row["space_group"],
                "cif_path": cif_by_name[name],
                "weight_fraction": phase["weight_fraction"],
                "weight_percent": 100.0 * phase["weight_fraction"],
                "parent_structure": parent_by_name[name],
                "refined_cell": {
                    "a_angstrom": row["cell"][0],
                    "b_angstrom": row["cell"][1],
                    "c_angstrom": row["cell"][2],
                    "alpha_deg": row["cell"][3],
                    "beta_deg": row["cell"][4],
                    "gamma_deg": row["cell"][5],
                    "volume_angstrom3": row["cell"][6],
                },
            }
        )

    result = {
        "refinement_histogram": model["refinement_histogram"],
        "phase_fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phases,
        "fit_statistics": {
            "scope": "native GSAS-II replay over the entire original observed grid",
            "rwp_percent": rwp,
            "rp_percent": rp,
            "r_exp_percent_poisson": r_exp,
            "goodness_of_fit_poisson": goodness_of_fit,
            "weighted_chi_square": chi_square,
            "data_points": n_points,
            "refined_parameters": n_parameters,
            "weighting": "w_i = 1/max(observed_i, 1 count); pointwise uncertainties were not supplied",
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
            "saved_project_rwp_percent": model["saved_fit_Rwp_percent"],
            "saved_project_fit_range_deg": [10.0, 100.0],
        },
        "project": {
            "path": "final.gpx",
            "sha256": replay["project_sha256"],
            "replayed_unchanged": True,
            "profile_review_flags": replay["profile_review_flags"],
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    report = f"""# Powder X-ray diffraction phase analysis

## Result

| Phase | Space group | Refined cell (Å, °) | Crystalline weight fraction |
|---|---|---|---:|
| MgWO4 | P 2/c | a=4.68959, b=5.67377, c=4.92821, beta=90.775 | 77.97% |
| WO3 | P 21/c | a=7.68889, b=7.53627, c=10.52848, beta=136.087 (alternate monoclinic setting) | 14.15% |
| MgO | F m -3 m | a=4.21200 | 7.88% |

The fractions are normalized only over the three modeled crystalline phases. Without an internal standard, this scan does not determine an amorphous fraction or absolute crystalline yield.

## Evidence and refinement

The precursor chemistry (MgO + WO3, heated at 900 °C) and the peak inventory support formation of MgWO4 with residual WO3 and MgO. The dominant MgWO4 model accounts for its diagnostic low-angle and split groups near 15.9, 19.2, 24.2–24.9, and 30.8–31.1° 2theta. Monoclinic WO3 accounts for the residual clusters around 23–25° and 33–35°. Rock-salt MgO is required by its comparatively isolated (200) peak near 43.2° in this displaced-pattern geometry, with supporting features near 62.5° and 75°. No additional strong, reproducible peak set remains that requires a fourth crystalline phase.

Local COD models 9013902 (MgWO4), 2311041 (WO3), and 9000499 (MgO) supplied the starting structures. A GSAS-II Rietveld refinement used the reported Cu Kalpha1/Kalpha2 wavelengths and 0.5 intensity ratio. Refined quantities included phase scales and cells, zero, instrumental/profile terms, phase size/strain terms, MgWO4 preferred orientation, and a 16-term Chebyshev background. Atomic-coordinate refinement was restrained by the parent structures and chemically plausible distances. The resulting nearest contacts are physically reasonable: MgWO4 has W–O 1.864–2.184 Å and Mg–O 1.968–2.113 Å; WO3 has W–O 1.702–2.145 Å; MgO has Mg–O 2.106 Å.

The exact saved project was independently replayed with native GSAS-II structure factors and fresh reflection lists, with no parameter optimization and no profile-review flags. Over all {n_points} measured points ({x[0]:.8f}–{x[-1]:.8f}°), Rwp is {rwp:.4f}%, Rp is {rp:.4f}%, and the Poisson-weighted goodness of fit is {goodness_of_fit:.3f}. The Rwp stored by GSAS-II for its 10–100° refinement interval is {model['saved_fit_Rwp_percent']:.4f}%. `fit.csv` contains the whole original grid and uses observed minus calculated for the difference column.

## Remaining uncertainty

The three phase identities are reliable, and their fractions are a defensible crystalline-phase normalization. The quoted decimals are reproducibility values, not realistic accuracy: scale/profile overlap, preferred orientation, microabsorption, and the lack of an internal standard make systematic fraction uncertainty of a few weight-percent plausible, especially for WO3 and MgO.

The detailed oxygen displacements are less secure than the phase types, cells, and heavy-atom sublattices because Cu X-ray scattering is dominated by W and the minor WO3 reflections overlap MgWO4. WO3 oxygen coordinates were therefore kept close to the published model with only a modest data-driven adjustment. Alternative monoclinic and triclinic WO3 parents were tested; an unconstrained P-1 model could reduce the residual slightly only by adding weakly determined metric freedom that moved toward the selected monoclinic metric. P 21/c is the more parsimonious assignment, but subtle WO3 distortion/polymorph details cannot be determined uniquely from this pattern alone. The residual above the ideal counting-noise level is concentrated mainly in overlapped intensity/profile details rather than unindexed strong peaks.
"""
    (ROOT / "report.md").write_text(report)


if __name__ == "__main__":
    main()
