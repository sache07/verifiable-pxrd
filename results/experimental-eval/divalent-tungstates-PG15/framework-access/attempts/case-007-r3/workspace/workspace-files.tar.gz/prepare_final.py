#!/usr/bin/env python3
"""Freeze the selected GSAS-II model and export project-consistent CIFs."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/sizes-bounded.gpx").resolve()
FINAL = Path("final.gpx").resolve()
CIF_NAMES = {
    "MgWO4": "phase_MgWO4.cif",
    "WO3": "phase_WO3.cif",
    "MgO": "phase_MgO.cif",
}


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.save(str(FINAL))

    # Match the evaluator's export convention: use the full-precision saved
    # phase dictionaries and do not substitute values from a stale covariance.
    export_project = G2.G2Project(gpxfile=str(FINAL))
    export_project.data["Covariance"]["data"] = {}
    hist = export_project.histograms()[0]
    weighted = []
    rows = []
    for phase in export_project.phases():
        path = Path(CIF_NAMES[phase.name]).resolve()
        phase.export_CIF(str(path))
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        weighted.append(mass_scale)
        rows.append(
            {
                "name": phase.name,
                "cif_path": path.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cell": list(map(float, phase.data["General"]["Cell"][1:])),
                "mass_scale": mass_scale,
            }
        )
    total = sum(weighted)
    for row, value in zip(rows, weighted):
        row["weight_fraction"] = value / total
    Path(".tmp/final_model.json").write_text(
        json.dumps(
            {
                "refinement_histogram": hist.name,
                "saved_fit_Rwp_percent": float(hist.get_wR()),
                "phases": rows,
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
