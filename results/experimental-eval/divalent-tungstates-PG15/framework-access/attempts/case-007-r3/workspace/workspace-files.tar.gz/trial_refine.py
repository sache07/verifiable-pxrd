#!/usr/bin/env python3
"""Build and run a staged GSAS-II trial refinement for candidate phase testing."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_cif(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summarize(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    result = {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "instrument": {
            key: inst[key][1]
            for key in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")
            if key in inst
        },
        "sample": {
            key: value[0] if isinstance(value, list) else value
            for key, value in hist.data["Sample Parameters"].items()
            if key in ("Type", "Gonio. radius", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.data["General"]["Cell"][1:],
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
            }
        )
    data = hist.data["data"][1]
    x, yo, w, yc = (np.asarray(data[i], dtype=float) for i in range(4))
    use = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    result["manual_Rwp_percent"] = float(
        100.0 * np.sqrt(np.sum(w[use] * (yo[use] - yc[use]) ** 2) / np.sum(w[use] * yo[use] ** 2))
    )
    return result


def run_refinement(project: G2.G2Project, label: str, log: list[dict], quiet: bool = False) -> None:
    project.refine(makeBack=False)
    state = summarize(project, label)
    log.append(state)
    if quiet:
        print(f"{label}: Rwp={state['Rwp_percent']:.5f}%")
    else:
        print(json.dumps(state, indent=2, default=float))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--out", required=True)
    parser.add_argument("--short", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    inst_path = out.with_suffix(".instprm")
    inst_path.write_text(
        "# GSAS-II Cu K-alpha laboratory instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.30;Polariz.:0.80;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(out))
    phase_specs = [
        ("MgWO4", "9013902"),
        ("WO3", args.wo3),
        ("MgO", "9000499"),
    ]
    phases = [
        project.add_phase(str(cod_cif(cod_id)), phasename=name, fmthint="CIF")
        for name, cod_id in phase_specs
    ]
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", str(inst_path), phases=phases, fmthint="comma"
    )
    hist.data["Limits"][1] = [10.0, 100.0]
    sample = hist.data["Sample Parameters"]
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    sample["Scale"] = [1.0, False]

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 16,
                "coeffs": [1000.0] + [0.0] * 15,
                "refine": True,
            }
        }
    )
    for phase, scale in zip(phases, (1.0, 0.2, 0.05)):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]

    project.set_Controls("cycles", 8)
    log: list[dict] = [summarize(project, "setup")]

    run_refinement(project, "scales_background", log, args.quiet)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, "zero", log, args.quiet)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_refinement(project, "cells", log, args.quiet)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_refinement(project, "instrument_profile", log, args.quiet)

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    run_refinement(project, "phase_broadening", log, args.quiet)

    if not args.short:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        run_refinement(project, "polarization", log, args.quiet)

        # Refine a specimen displacement after the global zero has stabilized.
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        run_refinement(project, "sample_shift", log, args.quiet)

    project.save(str(out))
    out.with_suffix(".json").write_text(json.dumps(log, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
