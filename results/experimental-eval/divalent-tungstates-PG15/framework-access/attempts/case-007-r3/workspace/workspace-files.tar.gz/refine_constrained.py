#!/usr/bin/env python3
"""Reparameterize a trial GSAS-II fit using physically bounded profile terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    masses = []
    phase_rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(mass_scale)
        phase_rows.append(
            {
                "name": phase.name,
                "cell": list(map(float, phase.data["General"]["Cell"][1:])),
                "scale": float(hap["Scale"][0]),
                "size_um": float(hap["Size"][1][0]),
                "mustrain_ppm": float(hap["Mustrain"][1][0]),
                "mustrain_axial_ppm": float(hap["Mustrain"][1][1]),
                "mustrain_type": hap["Mustrain"][0],
                "mustrain_axis": hap["Mustrain"][3],
                "md_ratio": float(hap["Pref.Ori."][1]),
                "md_axis": hap["Pref.Ori."][3],
            }
        )
    total = sum(masses)
    for row, value in zip(phase_rows, masses):
        row["weight_fraction"] = value / total
    return {
        "stage": label,
        "Rwp_percent": float(hist.get_wR()),
        "instrument": {
            k: float(inst[k][1])
            for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")
        },
        "sample": {
            k: (float(v[0]) if isinstance(v, list) else v)
            for k, v in hist.data["Sample Parameters"].items()
            if k in ("Type", "Gonio. radius", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": phase_rows,
    }


def refine(project: G2.G2Project, label: str, log: list[dict]) -> None:
    project.refine(makeBack=False)
    row = state(project, label)
    log.append(row)
    print(f"{label}: Rwp={row['Rwp_percent']:.6f}%")


def bound(project: G2.G2Project, variable: str, lo: float, hi: float) -> None:
    project.set_Controls("parmMin", lo, variable=variable)
    project.set_Controls("parmMax", hi, variable=variable)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--roughness", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    project.set_Controls("cycles", 12)
    hist = project.histograms()[0]
    phases = project.phases()
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    log = [state(project, "loaded")]

    # Remove the broad, highly correlated profile model from the trial fit.
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz.", "Zero"]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in phases:
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])

    # Keep the apparent low-angle shift near the trial value while separating
    # the constant zero from the cos(theta) specimen-displacement term.
    inst["Zero"][1] = 0.18
    sample["Shift"] = [-310.0, False]
    bound(project, ":0:Zero", -0.25, 0.25)
    bound(project, ":0:Shift", -800.0, 800.0)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "calibration", log)

    # Re-establish phase and instrument broadening together inside the known
    # family used for these laboratory measurements.
    inst["U"][1] = 20.0
    inst["W"][1] = 10.0
    inst["X"][1] = 1.5
    inst["SH/L"][1] = 0.04
    bound(project, ":0:U", 0.0, 40.0)
    bound(project, ":0:W", 2.0, 40.0)
    bound(project, ":0:X", 0.1, 6.0)
    bound(project, ":0:SH/L", 0.005, 0.10)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.6
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1200.0
        hap["Mustrain"][1][1] = 1200.0
        bound(project, f"{phase.id}:0:Size;i", 0.04, 1.5)
        bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    refine(project, "bounded_profile", log)

    inst["Polariz."][1] = 0.75
    bound(project, ":0:Polariz.", 0.5, 1.0)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "polarization", log)

    if args.roughness:
        sample["SurfRoughA"] = [0.30, False]
        sample["SurfRoughB"] = [0.08, False]
        bound(project, ":0:SurfRoughA", 0.0, 0.999)
        bound(project, ":0:SurfRoughB", 0.0, 0.5)
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        refine(project, "surface_roughness", log)

    project.save(str(output))
    output.with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    main()
