from pathlib import Path
import argparse

import matplotlib.pyplot as plt
import numpy as np


parser = argparse.ArgumentParser()
parser.add_argument("npz")
parser.add_argument("--output", default=".tmp/gpx_profile.png")
args = parser.parse_args()
d = np.load(args.npz)
x, obs, calc, bkg, diff = (d[k] for k in ("x", "observed", "calculated", "background", "difference"))

fig, axes = plt.subplots(3, 1, figsize=(17, 11), sharex=False)
for ax, lo, hi in zip(axes, (9.8, 39.9, 69.9), (40.1, 70.1, 100.2)):
    m = (x >= lo) & (x <= hi)
    offset = -0.25 * np.max(obs[m])
    ax.plot(x[m], obs[m], color="black", lw=0.6, label="observed")
    ax.plot(x[m], calc[m], color="tab:red", lw=0.7, label="calculated")
    ax.plot(x[m], bkg[m], color="tab:green", lw=0.6, label="background")
    ax.plot(x[m], diff[m] + offset, color="tab:blue", lw=0.55, label="difference + offset")
    ax.axhline(offset, color="0.6", lw=0.4)
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
axes[0].legend(ncol=4, fontsize=8)
axes[-1].set_xlabel(r"$2\theta$ (degrees)")
fig.tight_layout()
Path(args.output).parent.mkdir(parents=True, exist_ok=True)
fig.savefig(args.output, dpi=180)
