"""Physically bounded Rietveld refinement for the selected BaCO3 + WO3 model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / ".tmp" / "bounded"
WORK.mkdir(parents=True, exist_ok=True)
GPX = WORK / "bounded.gpx"
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inputs() -> tuple[np.ndarray, np.ndarray]:
    data = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    x, y = data.T
    np.savetxt(
        WORK / "pattern.xye",
        np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))),
        fmt=["%.12f", "%.8f", "%.8f"],
    )
    (WORK / "instrument.instprm").write_text(
        "# GSAS-II Cu Kalpha laboratory instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.70;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:15.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return x, y


def compute_rwp(hist) -> float:
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    weight = 1 / np.maximum(obs, 1.0)
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def report(project, hist, label: str) -> dict:
    phase_rows = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(mass)
        phase_rows.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass_scale": mass,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "texture": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": a.label,
                        "element": a.element,
                        "coordinates": a.coordinates,
                        "uiso": a.uiso if a.adp_flag == "I" else None,
                    }
                    for a in phase.atoms()
                ],
            }
        )
    for row, mass in zip(phase_rows, masses):
        row["weight_fraction"] = mass / sum(masses)
    out = {
        "stage": label,
        "rwp_percent": compute_rwp(hist),
        "residuals": hist.residuals,
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": phase_rows,
        "vary_list": [str(v) for v in project.data["Covariance"]["data"].get("varyList", [])],
    }
    print(f"{label}: Rwp={out['rwp_percent']:.6f}%", flush=True)
    for row in phase_rows:
        print(
            f"  {row['name']} wf={row['weight_fraction']:.6f} "
            f"cell={row['cell']}",
            flush=True,
        )
    return out


def refine(project, hist, log: list, label: str, cycles: int = 18) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    project.save()
    log.append(report(project, hist, label))


def set_bounds(project, variable: str, lo: float, hi: float) -> None:
    project.set_Controls("parmMin", lo, variable)
    project.set_Controls("parmMax", hi, variable)


G2.SetPrintLevel("warn")
x, y = write_inputs()
project = G2.G2Project(newgpx=str(GPX))
baco3 = project.add_phase(str(cod_path("9010928")), phasename="BaCO3", fmthint="CIF")
wo3 = project.add_phase(str(cod_path("2311041")), phasename="WO3", fmthint="CIF")
phases = [baco3, wo3]
hist = project.add_powder_histogram(
    str(WORK / "pattern.xye"), str(WORK / "instrument.instprm"), phases=phases, fmthint="xye"
)
hist.Limits("lower", float(x[0]))
hist.Limits("upper", float(x[-1]))
hist.Excluded([])
hist.SampleParameters["Type"] = "Bragg-Brentano"
hist.SampleParameters["Gonio. radius"] = 200.0
hist.SampleParameters["Scale"] = [1.0, False]
hist.SampleParameters["Shift"] = [-400.0, False]
hist.SampleParameters["Transparency"] = [0.0, False]
hist.SampleParameters["SurfRoughA"] = [0.0, False]
hist.SampleParameters["SurfRoughB"] = [0.0, False]

# Seed a smooth background from a broad lower envelope.
envelope = percentile_filter(y, percentile=12, size=301, mode="nearest")
t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
bkg_coeffs = np.polynomial.chebyshev.chebfit(t, envelope, 13).tolist()
hist.set_refinements(
    {
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 14,
            "coeffs": bkg_coeffs,
            "refine": False,
        }
    }
)

for phase in phases:
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.01 / phase.data["General"]["Mass"], False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.6
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    for atom in phase.atoms():
        if atom.adp_flag != "I":
            raise ValueError("Expected isotropic source ADPs")
        atom.uiso = 0.008
        atom.refinement_flags = " "

project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
project.data["Controls"]["data"]["min dM/M"] = 1e-5
project.set_Controls("cycles", 0)
project.refine(makeBack=False)
project.save()

# Physical bounds from the stated laboratory family; they prevent profile and
# specimen terms from replacing phase-specific structure/broadening.
for var, lo, hi in [
    (":0:Zero", -0.25, 0.25),
    (":0:U", 0.0, 40.0),
    (":0:W", 2.0, 40.0),
    (":0:X", 0.1, 6.0),
    (":0:SH/L", 0.005, 0.10),
    (":0:Polariz.", 0.5, 1.0),
    (":0:Shift", -800.0, 800.0),
    (":0:SurfRoughA", 0.0, 0.6),
    (":0:SurfRoughB", 0.0, 0.5),
]:
    set_bounds(project, var, lo, hi)
for phase in phases:
    pid = phase.id
    set_bounds(project, f"{pid}:0:Scale", 0.0, 100.0)
    set_bounds(project, f"{pid}:0:Size;i", 0.04, 1.5)
    set_bounds(project, f"{pid}:0:Mustrain;i", 0.0, 8000.0)
    set_bounds(project, f"{pid}:0:MD", 0.7, 1.4)
    set_bounds(project, f"{pid}::AUiso:0", 0.003, 0.02)
    for i, atom in enumerate(phase.atoms()):
        span = 0.008 if atom.element in {"Ba", "W"} else 0.015
        for axis in "xyz":
            set_bounds(project, f"{pid}::dA{axis}:{i}", -span, span)

# One Uiso per phase, as used by the laboratory model.
project.data["Constraints"]["data"].update({"Hist": [], "HAP": [], "Phase": [], "Global": []})
for phase in phases:
    project.add_EquivConstr([f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())])

log = [report(project, hist, "initial")]

# Scale/background, angular calibration, and cells.
hist.Background[0][1] = True
for phase in phases:
    phase.data["Histograms"][hist.name]["Scale"][1] = True
refine(project, hist, log, "scale_background", 12)

hist.InstrumentParameters["Zero"][2] = True
for phase in phases:
    phase.data["General"]["Cell"][0] = True
refine(project, hist, log, "zero_cells", 18)

hist.SampleParameters["Shift"][1] = True
refine(project, hist, log, "shift", 18)

# Common instrument then phase-specific broadening.
for key in ("U", "W", "X", "SH/L"):
    hist.InstrumentParameters[key][2] = True
refine(project, hist, log, "instrument", 20)

for phase in phases:
    phase.data["Histograms"][hist.name]["Mustrain"][2][0] = True
refine(project, hist, log, "microstrain", 20)
for phase in phases:
    phase.data["Histograms"][hist.name]["Size"][2][0] = True
refine(project, hist, log, "size", 20)

# Polarization and the screened carbonate texture axis.
hist.InstrumentParameters["Polariz."][2] = True
refine(project, hist, log, "polarization", 15)
baco_hap = baco3.data["Histograms"][hist.name]
baco_hap["Pref.Ori."][1] = 1.0
baco_hap["Pref.Ori."][2] = True
baco_hap["Pref.Ori."][3] = [1, 1, 0]
refine(project, hist, log, "baco3_texture", 18)

# Equality-constrained phase ADPs.
for phase in phases:
    for atom in phase.atoms():
        atom.refinement_flags = "U"
refine(project, hist, log, "common_uiso", 18)

# Symmetry-constrained coordinate shifts, first heavy then all sites.
for phase in phases:
    for atom in phase.atoms():
        atom.refinement_flags = "XU" if atom.element in {"Ba", "W"} else "U"
refine(project, hist, log, "heavy_coordinates", 20)
for phase in phases:
    for atom in phase.atoms():
        atom.refinement_flags = "XU"
refine(project, hist, log, "all_coordinates", 25)

project.save()
(WORK / "bounded_summary.json").write_text(json.dumps(log, indent=2, default=str) + "\n")
