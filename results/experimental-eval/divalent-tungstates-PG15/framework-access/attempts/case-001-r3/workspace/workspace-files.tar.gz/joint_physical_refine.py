"""Jointly refine a bounded physical model while retaining Uiso constraints."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("--source", required=True)
parser.add_argument("--output", required=True)
parser.add_argument("--ba-uniaxial", action="store_true")
parser.add_argument("--roughness", action="store_true")
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=args.source, newgpx=args.output)
hist = project.histogram(0)
project.set_Frozen()

hist.Background[0][1] = True
for name in ("Zero", "U", "W", "X", "SH/L", "Polariz."):
    hist.InstrumentParameters[name][2] = True
hist.SampleParameters["Shift"][1] = True
hist.SampleParameters["Transparency"] = [0.0, False]
if args.roughness:
    hist.SampleParameters["SurfRoughA"] = [0.20, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    for variable, low, high in (
        (":0:SurfRoughA", 0.05, 0.60),
        (":0:SurfRoughB", 0.02, 0.50),
    ):
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)
else:
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

for phase in project.phases():
    phase.data["General"]["Cell"][0] = True
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][2][0] = True
    hap["Mustrain"][2][0] = True
    hap["Pref.Ori."][2] = phase.name == "BaCO3"
    for atom in phase.atoms():
        atom.refinement_flags = "U"

ba_hap = project.phase("BaCO3").data["Histograms"][hist.name]
if args.ba_uniaxial:
    ba_hap["Mustrain"][0] = "uniaxial"
    ba_hap["Mustrain"][1][0] = 4105.23
    ba_hap["Mustrain"][1][1] = 2866.78
    ba_hap["Mustrain"][2][0] = True
    ba_hap["Mustrain"][2][1] = True
    ba_hap["Mustrain"][3] = [0, 0, 1]
    project.set_Controls("parmMin", 300.0, "0:0:Mustrain;a")
    project.set_Controls("parmMax", 8000.0, "0:0:Mustrain;a")


def get_rwp() -> float:
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    weight = 1.0 / np.maximum(obs, 1.0)
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


stages = []
for label, cycles in (("joint_1", 25), ("joint_2", 25)):
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    project.save()
    stages.append({
        "stage": label,
        "rwp_percent": get_rwp(),
        "frozen": project.get_Frozen(),
        "vary_list": project.data["Covariance"]["data"].get("varyList", []),
    })
    print(label, stages[-1]["rwp_percent"], stages[-1]["frozen"], flush=True)

masses = [
    p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
    for p in project.phases()
]
result = {
    "rwp_percent": get_rwp(),
    "stages": stages,
    "weight_fractions": {p.name: float(m / sum(masses)) for p, m in zip(project.phases(), masses)},
    "uiso": {p.name: [a.uiso for a in p.atoms()] for p in project.phases()},
    "instrument": hist.InstrumentParameters,
    "sample": hist.SampleParameters,
    "phases": {
        p.name: {
            "cell": p.data["General"]["Cell"],
            "hap": p.data["Histograms"][hist.name],
        }
        for p in project.phases()
    },
    "residuals": hist.residuals,
}
Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
project.save(args.output)
print(json.dumps({"rwp_percent": result["rwp_percent"], "weight_fractions": result["weight_fractions"], "uiso": result["uiso"]}, indent=2))
