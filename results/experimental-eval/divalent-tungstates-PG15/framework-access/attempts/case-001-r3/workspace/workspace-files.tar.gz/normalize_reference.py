"""Render a COD CIF with the synthetic pool's neutral/Uiso conventions."""

import argparse
import sys
from pathlib import Path

from pymatgen.io.cif import CifParser


parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("destination", type=Path)
args = parser.parse_args()
sys.path.insert(0, str(Path("learned/divalent-tungstates/runtime").resolve()))
from models import write_synthetic_model

structure = CifParser(
    args.source, occupancy_tolerance=1.0, site_tolerance=1e-5, frac_tolerance=0
).parse_structures(primitive=False, on_error="raise")[0]
write_synthetic_model(structure, args.destination)
