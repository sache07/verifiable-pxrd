"""Evaluate regularized parent-to-Rietveld coordinate displacement factors."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("--template", required=True)
parser.add_argument("--parent", required=True)
parser.add_argument("--target", required=True)
parser.add_argument("--output", required=True)
parser.add_argument("--baco-non-o", type=float, default=0.2)
parser.add_argument("--baco-o", type=float, default=0.3)
parser.add_argument("--w", type=float, default=0.6)
parser.add_argument("--wo-o", type=float, default=0.05)
args = parser.parse_args()

factors = {
    "baco_non_o": args.baco_non_o,
    "baco_o": args.baco_o,
    "w": args.w,
    "wo_o": args.wo_o,
}

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=args.template, newgpx=args.output)
parent = G2.G2Project(gpxfile=args.parent)
target = G2.G2Project(gpxfile=args.target)
hist = project.histogram(0)
project.data["Constraints"]["data"].update({"Hist": [], "HAP": [], "Phase": [], "Global": []})
project.set_Frozen()

hist.Background[0][1] = True
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
    if key in hist.SampleParameters and isinstance(hist.SampleParameters[key], list):
        hist.SampleParameters[key][1] = False

fractional_displacements = {}
for phase in project.phases():
    p0 = parent.phase(phase.name)
    p1 = target.phase(phase.name)
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][2] = phase.name == "BaCO3"
    moved = []
    for atom, a0, a1 in zip(phase.atoms(), p0.atoms(), p1.atoms()):
        if (atom.label, atom.element) != (a0.label, a0.element) or (a0.label, a0.element) != (a1.label, a1.element):
            raise ValueError("Atom order mismatch")
        if phase.name == "BaCO3":
            factor = factors["baco_o" if atom.element == "O" else "baco_non_o"]
        else:
            factor = factors["wo_o" if atom.element == "O" else "w"]
        base = np.asarray(a0.coordinates, float)
        delta = np.asarray(a1.coordinates, float) - base
        delta -= np.rint(delta)
        displacement = factor * delta
        atom.coordinates = tuple((base + displacement) % 1.0)
        atom.refinement_flags = " "
        moved.append({"label": atom.label, "element": atom.element, "delta_frac": displacement.tolist()})
    fractional_displacements[phase.name] = moved

project.set_Controls("cycles", 15)
project.refine(makeBack=False)
project.save()

obs = np.asarray(hist.getdata("Yobs"), float)
calc = np.asarray(hist.getdata("Ycalc"), float)
weight = 1 / np.maximum(obs, 1.0)
rwp = float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))
masses = [
    p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
    for p in project.phases()
]
result = {
    "rwp_percent": rwp,
    "factors": factors,
    "weight_fractions": {p.name: float(m / sum(masses)) for p, m in zip(project.phases(), masses)},
    "fractional_displacements": fractional_displacements,
    "residuals": hist.residuals,
}
Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
