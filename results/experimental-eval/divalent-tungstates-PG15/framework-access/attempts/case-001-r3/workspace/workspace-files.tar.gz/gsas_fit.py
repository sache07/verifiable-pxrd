"""Build and refine trial GSAS-II projects for the BaCO3/WO3 pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import sys

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_data(work: Path) -> tuple[np.ndarray, np.ndarray]:
    data = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    x, y = data.T
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(
        work / "pattern.xye",
        np.column_stack((x, y, sigma)),
        fmt=["%.12f", "%.8f", "%.8f"],
    )
    return x, y


def write_instrument(path: Path) -> None:
    path.write_text(
        "# GSAS-II Cu Kalpha laboratory instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.25;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def baseline_coefficients(x: np.ndarray, y: np.ndarray, n_coeffs: int) -> list[float]:
    # Broad lower envelope used only to seed the background least squares.
    envelope = percentile_filter(y, percentile=12, size=301, mode="nearest")
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    coeffs = np.polynomial.chebyshev.chebfit(t, envelope, n_coeffs - 1)
    return coeffs.tolist()


def set_value(record: dict, key: str, value: float) -> None:
    record[key][0] = float(value)
    record[key][1] = float(value)


def summary(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    yobs = np.asarray(hist.getdata("Yobs"), float)
    ycalc = np.asarray(hist.getdata("Ycalc"), float)
    weight = 1 / np.maximum(yobs, 1.0)
    rwp = 100 * np.sqrt(np.sum(weight * (yobs - ycalc) ** 2) / np.sum(weight * yobs**2))
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for row, mass in zip(phases, masses):
        row["weight_fraction"] = mass / total if total > 0 else None
    result = {
        "stage": label,
        "rwp_recomputed_percent": rwp,
        "residuals": hist.residuals,
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": phases,
    }
    print(
        f"STAGE {label}: Rwp={rwp:.5f}% GSAS_wR={hist.residuals.get('wR')} "
        f"maxcalc={np.max(ycalc):.3f} mincalc={np.min(ycalc):.3f}",
        flush=True,
    )
    for row in phases:
        print(
            f"  {row['name']} wf={row['weight_fraction']:.6f} "
            f"scale={row['scale']:.8g} cell={row['cell']}",
            flush=True,
        )
    return result


def refine_stage(project: G2.G2Project, label: str, cycles: int = 8) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    project.save()
    return summary(project, label)


def build_project(args: argparse.Namespace, work: Path) -> G2.G2Project:
    x, y = prepare_data(work)
    inst_path = work / "instrument.instprm"
    write_instrument(inst_path)
    project = G2.G2Project(newgpx=str(work / "trial.gpx"))
    sources = [("BaCO3", args.baco3)]
    sources.append(("WO3", args.wo3))
    if args.bawo4:
        sources.append(("BaWO4", args.bawo4))
    if args.extra:
        sources.append(("extra", args.extra))
    phases = []
    for name, cod_id in sources:
        source = Path(args.wo3_path) if name == "WO3" and args.wo3_path else cod_path(cod_id)
        phases.append(project.add_phase(str(source), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(
        str(work / "pattern.xye"), str(inst_path), phases=phases, fmthint="xye"
    )
    hist.Limits("lower", float(x[0]))
    hist.Limits("upper", float(x[-1]))
    hist.Excluded([])
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    coeffs = baseline_coefficients(x, y, args.background_coeffs)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_coeffs,
                "coeffs": coeffs,
                "refine": False,
            }
        }
    )
    # Use plausible broadening values and mass-scaled phase amplitudes.
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [0.01 / phase.data["General"]["Mass"], False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][1][1] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save()
    return project


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    work = ROOT / ".tmp" / args.output
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)
    project = build_project(args, work)
    log = [summary(project, "initial")]
    if args.pilot:
        (work / "summary.json").write_text(json.dumps(log, indent=2, default=str) + "\n")
        return

    hist = project.histogram(0)
    phases = project.phases()

    # Stage 1: fit amplitudes and a smooth background while the peak positions stay fixed.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    log.append(refine_stage(project, "scale_background", 10))

    # Stage 2: common angular correction, then unit cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    log.append(refine_stage(project, "zero", 10))
    for phase in phases:
        phase.set_refinements({"Cell": True})
    log.append(refine_stage(project, "cells", 12))

    # Stage 3: distinguish constant zero from specimen displacement.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    log.append(refine_stage(project, "shift", 12))

    # Stage 4: common instrumental profile, then phase-specific broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    log.append(refine_stage(project, "instrument_profile", 15))
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 1.0, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    log.append(refine_stage(project, "phase_broadening", 18))

    # Stage 5 is optional: independent Uiso refinement is useful only as a diagnostic.
    # It is intentionally skipped during candidate screening because weak O-site ADPs
    # are underdetermined without equality constraints.
    if not args.skip_uiso:
        for phase in phases:
            for atom in phase.atoms():
                atom.refinement_flags = "U"
                if atom.adp_flag == "I" and atom.uiso <= 0:
                    atom.uiso = 0.008
        log.append(refine_stage(project, "uiso", 15))

    project.save(str(work / "trial.gpx"))
    (work / "summary.json").write_text(json.dumps(log, indent=2, default=str) + "\n")
    print(f"GSAS-II revision {GSASIIpath.GetVersionNumber()} saved {work / 'trial.gpx'}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--wo3", required=True)
    parser.add_argument("--wo3-path", default=None)
    parser.add_argument("--baco3", default="9010928")
    parser.add_argument("--bawo4", default=None)
    parser.add_argument("--extra", default=None)
    parser.add_argument("--background-coeffs", type=int, default=12)
    parser.add_argument("--pilot", action="store_true")
    parser.add_argument("--skip-uiso", action="store_true")
    return parser.parse_args()


if __name__ == "__main__":
    try:
        run(parse_args())
    except Exception as exc:
        print(f"ERROR: {exc!r}", file=sys.stderr)
        raise
