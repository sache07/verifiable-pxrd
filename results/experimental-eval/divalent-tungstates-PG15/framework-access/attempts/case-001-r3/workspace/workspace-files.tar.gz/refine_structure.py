"""Refine common phase ADPs and symmetry-constrained coordinates."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("--source", required=True)
parser.add_argument("--output", required=True)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=args.source, newgpx=args.output)
hist = project.histogram(0)


def rwp() -> float:
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    w = 1 / np.maximum(obs, 1.0)
    return float(100 * np.sqrt(np.sum(w * (obs - calc) ** 2) / np.sum(w * obs**2)))


def snapshot(label: str) -> dict:
    rows = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        rows.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass_scale": mass_scale,
                "texture": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": atom.coordinates,
                        "uiso": atom.uiso if atom.adp_flag == "I" else None,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    for row, value in zip(rows, masses):
        row["weight_fraction"] = value / sum(masses)
    out = {
        "stage": label,
        "rwp_percent": rwp(),
        "residuals": hist.residuals,
        "phases": rows,
        "vary_list": [str(v) for v in project.data["Covariance"]["data"].get("varyList", [])],
    }
    print(f"{label}: Rwp={out['rwp_percent']:.6f}%", flush=True)
    return out


def refine(label: str, cycles: int = 18) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    project.save()
    return snapshot(label)


# Clear all inherited refinement flags. Keep the selected BaCO3 texture model.
hist.clear_refinements(
    {
        "Background": True,
        "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    }
)
project.data["Constraints"]["data"].update({"Hist": [], "HAP": [], "Phase": [], "Global": []})
for phase in project.phases():
    phase.set_refinements({"Cell": False})
    phase.clear_HAP_refinements(
        {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist]
    )
    phase.set_HAP_refinements({"Scale": True}, [hist])
    if phase.name == "BaCO3":
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [1, 1, 0]
    for atom in phase.atoms():
        atom.refinement_flags = " "

hist.set_refinements({"Background": {"refine": True}})
log = [snapshot("start")]

# The generator/lab model uses one isotropic ADP per phase. Equality constraints
# make that physically meaningful and avoid independent weak oxygen-site ADPs.
project.save()
for phase in project.phases():
    atom_vars = []
    for i, atom in enumerate(phase.atoms()):
        if atom.adp_flag != "I":
            raise ValueError(f"Expected isotropic ADP for {phase.name}/{atom.label}")
        atom.uiso = 0.008
        atom.refinement_flags = "U"
        atom_vars.append(f"{phase.id}::AUiso:{i}")
    project.add_EquivConstr(atom_vars)
log.append(refine("common_uiso", 20))

# Heavy-atom shifts dominate the structural and intensity information.
for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = "XU" if atom.element in {"Ba", "W"} else "U"
log.append(refine("heavy_coordinates", 20))

# Then allow the light-site coordinates to recover the symmetry-preserving
# reference perturbation. The equality-constrained phase ADPs remain active.
for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = "XU"
log.append(refine("all_coordinates", 25))

project.save()
Path(args.output).with_suffix(".json").write_text(json.dumps(log, indent=2, default=str) + "\n")
