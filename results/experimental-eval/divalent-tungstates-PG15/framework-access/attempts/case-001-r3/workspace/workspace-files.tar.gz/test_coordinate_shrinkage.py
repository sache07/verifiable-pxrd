"""Test regularized coordinates along a Rietveld-derived displacement direction."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("--base", required=True)
parser.add_argument("--target", required=True)
parser.add_argument("--output", required=True)
parser.add_argument("--baco-non-o", type=float, default=0.0)
parser.add_argument("--baco-o", type=float, default=0.0)
parser.add_argument("--w", type=float, default=0.0)
parser.add_argument("--wo-o", type=float, default=0.0)
args = parser.parse_args()

factors = {
    "baco_non_o": args.baco_non_o,
    "baco_o": args.baco_o,
    "w": args.w,
    "wo_o": args.wo_o,
}
G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=args.base, newgpx=args.output)
target = G2.G2Project(gpxfile=args.target)
hist = project.histogram(0)

# Freeze every inherited parameter except scales, smooth background and the
# already-supported carbonate texture ratio.
hist.Background[0][1] = True
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
    if key in hist.SampleParameters and isinstance(hist.SampleParameters[key], list):
        hist.SampleParameters[key][1] = False
project.data["Constraints"]["data"].update({"Hist": [], "HAP": [], "Phase": [], "Global": []})

displacements = {}
for phase in project.phases():
    other = target.phase(phase.name)
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][2] = phase.name == "BaCO3"
    moved = []
    for atom, fit_atom in zip(phase.atoms(), other.atoms()):
        if atom.label != fit_atom.label or atom.element != fit_atom.element:
            raise ValueError("Atom order mismatch")
        if phase.name == "BaCO3":
            factor = factors["baco_o" if atom.element == "O" else "baco_non_o"]
        else:
            factor = factors["wo_o" if atom.element == "O" else "w"]
        base = np.asarray(atom.coordinates, float)
        delta = np.asarray(fit_atom.coordinates, float) - base
        delta -= np.rint(delta)
        atom.coordinates = tuple((base + factor * delta) % 1)
        atom.refinement_flags = " "
        moved.append((factor * delta).tolist())
    displacements[phase.name] = moved

project.set_Controls("cycles", 15)
project.refine(makeBack=False)
project.save()

obs = np.asarray(hist.getdata("Yobs"), float)
calc = np.asarray(hist.getdata("Ycalc"), float)
weight = 1 / np.maximum(obs, 1.0)
rwp = float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))
masses = [
    p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
    for p in project.phases()
]
result = {
    "rwp_percent": rwp,
    "factors": factors,
    "weight_fractions": {p.name: float(m / sum(masses)) for p, m in zip(project.phases(), masses)},
    "displacements_fractional": displacements,
    "residuals": hist.residuals,
}
Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
