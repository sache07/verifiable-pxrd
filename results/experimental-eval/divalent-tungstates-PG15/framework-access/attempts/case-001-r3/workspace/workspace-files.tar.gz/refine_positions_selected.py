"""Refine cells with one angular correction at a time to avoid collinearity."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("--source", required=True)
parser.add_argument("--output", required=True)
parser.add_argument("--offset", choices=("none", "zero", "shift"), required=True)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=args.source, newgpx=args.output)
hist = project.histogram(0)
project.set_Frozen()
project.data["Controls"]["data"]["parmMinDict"] = {}
project.data["Controls"]["data"]["parmMaxDict"] = {}
hist.Background[0][1] = True
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
    if key in hist.SampleParameters and isinstance(hist.SampleParameters[key], list):
        hist.SampleParameters[key][1] = False
if args.offset == "zero":
    hist.InstrumentParameters["Zero"][2] = True
elif args.offset == "shift":
    hist.SampleParameters["Shift"][1] = True

for phase in project.phases():
    phase.data["General"]["Cell"][0] = True
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][2] = phase.name == "BaCO3"
    for atom in phase.atoms():
        atom.refinement_flags = " "

project.set_Controls("cycles", 25)
project.refine(makeBack=False)
project.save()
obs = np.asarray(hist.getdata("Yobs"), float)
calc = np.asarray(hist.getdata("Ycalc"), float)
weight = 1 / np.maximum(obs, 1.0)
rwp = float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))
masses = [
    p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
    for p in project.phases()
]
result = {
    "offset": args.offset,
    "rwp_percent": rwp,
    "weight_fractions": {p.name: float(m / sum(masses)) for p, m in zip(project.phases(), masses)},
    "zero": hist.InstrumentParameters["Zero"],
    "shift": hist.SampleParameters["Shift"],
    "cells": {p.name: p.data["General"]["Cell"] for p in project.phases()},
    "residuals": hist.residuals,
}
Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
