"""Obtain a symmetry-constrained coordinate target with profile terms fixed."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("--source", required=True)
parser.add_argument("--output", required=True)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=args.source, newgpx=args.output)
hist = project.histogram(0)
project.data["Constraints"]["data"].update({"Hist": [], "HAP": [], "Phase": [], "Global": []})
project.set_Frozen()

hist.Background[0][1] = True
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
    if key in hist.SampleParameters and isinstance(hist.SampleParameters[key], list):
        hist.SampleParameters[key][1] = False

for pidx, phase in enumerate(project.phases()):
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][2] = phase.name == "BaCO3"
    variables = []
    for aidx, atom in enumerate(phase.atoms()):
        atom.refinement_flags = "U"
        variables.append(f"{pidx}::AUiso:{aidx}")
    project.add_EquivConstr(variables, reloadIdx=True)


def summarize(label: str) -> dict:
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    weight = 1 / np.maximum(obs, 1.0)
    value = float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))
    masses = [
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ]
    return {
        "stage": label,
        "rwp_percent": value,
        "weight_fractions": {p.name: float(m / sum(masses)) for p, m in zip(project.phases(), masses)},
        "phases": {
            p.name: {
                "uiso": [a.uiso for a in p.atoms()],
                "atoms": [
                    {"label": a.label, "element": a.element, "coordinates": a.coordinates}
                    for a in p.atoms()
                ],
            }
            for p in project.phases()
        },
        "vary_list": project.data["Covariance"]["data"].get("varyList", []),
        "residuals": hist.residuals,
    }


log = []
for label, elements, cycles in (
    ("heavy_coordinates", {"Ba", "W"}, 20),
    ("all_coordinates", None, 30),
):
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "XU" if elements is None or atom.element in elements else "U"
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    project.save()
    log.append(summarize(label))
    print(label, log[-1]["rwp_percent"], log[-1]["weight_fractions"], flush=True)

project.save(args.output)
Path(args.output).with_suffix(".json").write_text(json.dumps(log, indent=2, default=str) + "\n")
