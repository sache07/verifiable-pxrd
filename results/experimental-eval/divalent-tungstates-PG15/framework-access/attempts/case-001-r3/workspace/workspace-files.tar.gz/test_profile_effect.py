"""Screen profile/specimen effects against a frozen structural model."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("--source", required=True)
parser.add_argument("--output", required=True)
parser.add_argument("--mode", choices=["mustrain", "roughness", "polarization"], required=True)
parser.add_argument("--phase")
parser.add_argument("--axis", default="0,0,1")
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=args.source, newgpx=args.output)
hist = project.histogram(0)

# Explicitly freeze inherited flags (avoids the early-return behavior in the
# convenience background clear method).
hist.Background[0][1] = False
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
    if key in hist.SampleParameters and isinstance(hist.SampleParameters[key], list):
        hist.SampleParameters[key][1] = False
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][2] = False

details = {}
if args.mode == "mustrain":
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    iso = max(float(hap["Mustrain"][1][0]), 50.0)
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = iso
    hap["Mustrain"][1][1] = iso
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = [int(v) for v in args.axis.split(",")]
    details.update(phase=args.phase, axis=hap["Mustrain"][3])
elif args.mode == "roughness":
    hist.SampleParameters["SurfRoughA"] = [0.15, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
elif args.mode == "polarization":
    hist.InstrumentParameters["Polariz."][2] = True

project.set_Controls("cycles", 20)
project.refine(makeBack=False)
project.save()

obs = np.asarray(hist.getdata("Yobs"), float)
calc = np.asarray(hist.getdata("Ycalc"), float)
w = 1 / np.maximum(obs, 1.0)
rwp = float(100 * np.sqrt(np.sum(w * (obs - calc) ** 2) / np.sum(w * obs**2)))
result = {
    "mode": args.mode,
    "rwp_percent": rwp,
    "details": details,
    "polarization": hist.InstrumentParameters["Polariz."],
    "surface": {k: hist.SampleParameters[k] for k in ("SurfRoughA", "SurfRoughB")},
    "mustrain": {
        p.name: p.data["Histograms"][hist.name]["Mustrain"] for p in project.phases()
    },
    "residuals": hist.residuals,
}
Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
