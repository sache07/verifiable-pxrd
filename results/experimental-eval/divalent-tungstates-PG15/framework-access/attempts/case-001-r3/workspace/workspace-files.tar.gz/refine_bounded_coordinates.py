"""Refine modest coordinate perturbations while freezing the selected profile."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("--source", required=True)
parser.add_argument("--output", required=True)
parser.add_argument("--heavy-span", type=float, default=0.008)
parser.add_argument("--light-span", type=float, default=0.010)
parser.add_argument("--baco3-uiso", type=float, default=0.005)
parser.add_argument("--wo3-uiso", type=float, default=0.003)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=args.source, newgpx=args.output)
hist = project.histogram(0)

# Remove inherited limits/frozen variables, then freeze every inherited flag.
controls = project.data["Controls"]["data"]
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
controls["parmFrozen"] = {}
hist.Background[0][1] = True
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
    if key in hist.SampleParameters and isinstance(hist.SampleParameters[key], list):
        hist.SampleParameters[key][1] = False

for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][2] = phase.name == "BaCO3"
    target_u = args.baco3_uiso if phase.name == "BaCO3" else args.wo3_uiso
    for atom in phase.atoms():
        atom.uiso = target_u
        atom.refinement_flags = " "

project.data["Constraints"]["data"].update({"Hist": [], "HAP": [], "Phase": [], "Global": []})
project.save()

for phase in project.phases():
    for i, atom in enumerate(phase.atoms()):
        span = args.heavy_span if atom.element in {"Ba", "W"} else args.light_span
        for axis in "xyz":
            project.set_Controls("parmMin", -span, f"{phase.id}::dA{axis}:{i}")
            project.set_Controls("parmMax", span, f"{phase.id}::dA{axis}:{i}")


def rwp() -> float:
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    weight = 1 / np.maximum(obs, 1.0)
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def snap(label: str) -> dict:
    masses = []
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        m = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(m)
        rows.append(
            {
                "name": phase.name,
                "mass_scale": m,
                "texture": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": atom.coordinates,
                        "uiso": atom.uiso,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    for row, m in zip(rows, masses):
        row["weight_fraction"] = m / sum(masses)
    out = {"stage": label, "rwp_percent": rwp(), "phases": rows, "residuals": hist.residuals}
    print(f"{label}: {out['rwp_percent']:.6f}%", flush=True)
    return out


def refine(label: str, cycles: int) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    project.save()
    log.append(snap(label))


log = [snap("start")]
refine("rescale", 15)
for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = "X" if atom.element in {"Ba", "W"} else " "
refine("heavy", 20)
for phase in project.phases():
    for atom in phase.atoms():
        atom.refinement_flags = "X"
refine("all", 25)

project.save()
Path(args.output).with_suffix(".json").write_text(json.dumps(log, indent=2, default=str) + "\n")
