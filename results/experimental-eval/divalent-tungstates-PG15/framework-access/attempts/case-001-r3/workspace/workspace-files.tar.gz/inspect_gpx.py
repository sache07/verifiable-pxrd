import argparse

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("gpx")
parser.add_argument("--output", default=".tmp/gpx_profile.npz")
args = parser.parse_args()

project = G2.G2Project(gpxfile=args.gpx)
hist = project.histogram(0)
x = np.asarray(hist.getdata("X"), float)
obs = np.asarray(hist.getdata("Yobs"), float)
calc = np.asarray(hist.getdata("Ycalc"), float)
bkg = np.asarray(hist.getdata("Background"), float)
diff = obs - calc

np.savez_compressed(args.output, x=x, observed=obs, calculated=calc, background=bkg, difference=diff)

weight = 1 / np.maximum(obs, 1)
print("Rwp", 100 * np.sqrt(np.sum(weight * diff**2) / np.sum(weight * obs**2)))
print("max residual", x[np.argmax(np.abs(diff))], diff[np.argmax(np.abs(diff))])
