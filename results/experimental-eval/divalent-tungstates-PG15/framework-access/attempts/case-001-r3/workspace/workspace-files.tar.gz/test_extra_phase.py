"""Signed-scale test for a candidate minor phase against a fixed two-phase fit."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


parser = argparse.ArgumentParser()
parser.add_argument("--source", required=True)
parser.add_argument("--cod-id", required=True)
parser.add_argument("--name", required=True)
parser.add_argument("--output", required=True)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=args.source, newgpx=args.output)
hist = project.histogram(0)

# Freeze the selected two-phase model except for its phase amplitudes.
hist.clear_refinements(
    {
        "Background": True,
        "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L"],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    }
)
for phase in project.phases():
    phase.set_refinements({"Cell": False})
    for atom in phase.atoms():
        atom.refinement_flags = " "
    phase.clear_HAP_refinements(
        {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist]
    )
    phase.set_HAP_refinements({"Scale": True}, [hist])

extra = project.add_phase(str(cod_path(args.cod_id)), phasename=args.name, histograms=[hist], fmthint="CIF")
hap = extra.data["Histograms"][hist.name]
hap["Scale"] = [0.1, True]
hap["Size"][0] = "isotropic"
hap["Size"][1][0] = 1.0
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = 1000.0
hap["Mustrain"][2] = [False, False, False]

project.set_Controls("cycles", 15)
project.refine(makeBack=False)
project.save()

obs = np.asarray(hist.getdata("Yobs"), float)
calc = np.asarray(hist.getdata("Ycalc"), float)
weight = 1 / np.maximum(obs, 1.0)
rwp = float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))
rows = []
masses = []
for phase in project.phases():
    scale = float(phase.data["Histograms"][hist.name]["Scale"][0])
    mass_scale = scale * float(phase.data["General"]["Mass"])
    masses.append(mass_scale)
    rows.append({"name": phase.name, "scale": scale, "mass_scale": mass_scale})
total = sum(masses)
for row in rows:
    row["signed_weight_fraction"] = row["mass_scale"] / total
result = {"rwp_percent": rwp, "phases": rows, "residuals": hist.residuals}
Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
