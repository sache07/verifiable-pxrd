"""Screen one March-Dollase axis at a time against the selected two-phase fit."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("--source", required=True)
parser.add_argument("--phase", required=True)
parser.add_argument("--axis", required=True, help="comma-separated h,k,l")
parser.add_argument("--output", required=True)
args = parser.parse_args()
axis = [int(v) for v in args.axis.split(",")]

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=args.source, newgpx=args.output)
hist = project.histogram(0)
hist.clear_refinements(
    {
        "Background": True,
        "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L"],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    }
)
for phase in project.phases():
    phase.set_refinements({"Cell": False})
    for atom in phase.atoms():
        atom.refinement_flags = " "
    phase.clear_HAP_refinements(
        {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist]
    )
    phase.set_HAP_refinements({"Scale": True}, [hist])

target = project.phase(args.phase)
hap = target.data["Histograms"][hist.name]
hap["Pref.Ori."][0] = "MD"
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = True
hap["Pref.Ori."][3] = axis

project.set_Controls("cycles", 15)
project.refine(makeBack=False)
project.save()

obs = np.asarray(hist.getdata("Yobs"), float)
calc = np.asarray(hist.getdata("Ycalc"), float)
weight = 1 / np.maximum(obs, 1.0)
rwp = float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))
result = {
    "rwp_percent": rwp,
    "phase": args.phase,
    "axis": axis,
    "ratio": float(hap["Pref.Ori."][1]),
    "residuals": hist.residuals,
}
Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
