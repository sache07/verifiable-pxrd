"""Create fit.csv and result.json from the verified final-project replay."""

import csv
import json
from pathlib import Path

import numpy as np


replay_dir = Path(".tmp/final_replay")
report = json.loads((replay_dir / "replay.json").read_text())
if report.get("status") != "replayed" or report.get("profile_review_flags"):
    raise RuntimeError(f"Final replay did not pass physical review: {report}")

with np.load(replay_dir / "prediction.npz", allow_pickle=False) as data:
    x = np.asarray(data["x"], float)
    observed = np.asarray(data["observed"], float)
    calculated = np.asarray(data["predicted"], float)

difference = observed - calculated
weight = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weight * difference**2))
denominator = float(np.sum(weight * observed**2))
n_points = int(len(x))
n_parameters = 25
dof = n_points - n_parameters
rwp = float(100 * np.sqrt(chi_square / denominator))
rp = float(100 * np.sum(np.abs(difference)) / np.sum(observed))
r_exp = float(100 * np.sqrt(n_points / denominator))
reduced_chi_square = float(chi_square / dof)
gof = float(np.sqrt(reduced_chi_square))

with Path("fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream, lineterminator="\n")
    writer.writerow(["two_theta", "observed", "calculated", "difference"])
    for values in zip(x, observed, calculated, difference):
        writer.writerow([f"{values[0]:.10f}", f"{values[1]:.10f}", f"{values[2]:.10f}", f"{values[3]:.10f}"])

fractions = {phase["name"]: float(phase["weight_fraction"]) for phase in report["phases"]}
result = {
    "phases": [
        {
            "name": "witherite",
            "formula": "BaCO3",
            "space_group": "Pmcn setting of Pnma (No. 62)",
            "cif": "phase_baco3.cif",
            "weight_fraction": fractions["BaCO3"],
        },
        {
            "name": "monoclinic tungsten trioxide",
            "formula": "WO3",
            "space_group": "P21/c (No. 14)",
            "cif": "phase_wo3.cif",
            "weight_fraction": fractions["WO3"],
        },
    ],
    "weight_fraction_basis": "Normalized over the modeled crystalline phases; unmodeled amorphous material is excluded.",
    "fit_statistics": {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "r_exp_percent": r_exp,
        "goodness_of_fit": gof,
        "chi_square": chi_square,
        "reduced_chi_square": reduced_chi_square,
        "n_points": n_points,
        "n_refined_parameters_final_cycle": n_parameters,
        "degrees_of_freedom": dof,
        "weighting": "w_i = 1/max(observed_counts_i, 1), because pointwise standard uncertainties were not supplied",
    },
    "fit_profile": "fit.csv",
    "gsas_project": "final.gpx",
    "refinement_histogram": report["histogram"],
    "project_replay": {
        "status": report["status"],
        "parameters_optimized_during_replay": report["parameters_optimized"],
        "profile_review_flags": report["profile_review_flags"],
        "project_sha256": report["project_sha256"],
    },
}
Path("result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps(result, indent=2))
