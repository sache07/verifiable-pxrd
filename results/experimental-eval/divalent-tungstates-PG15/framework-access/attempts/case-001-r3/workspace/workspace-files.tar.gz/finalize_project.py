"""Save the selected GPX and export matching phase CIFs."""

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=".tmp/final_candidate.gpx", newgpx="final.gpx")
project.save("final.gpx")

# Do not print stale covariance-derived uncertainties into the CIFs. The atomic
# values themselves remain exactly those stored in final.gpx.
project.data["Covariance"]["data"] = {}
project.phase("BaCO3").export_CIF("phase_baco3.cif")
project.phase("WO3").export_CIF("phase_wo3.cif")
print("saved final.gpx, phase_baco3.cif, phase_wo3.cif")
