from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.signal import find_peaks, peak_widths


data = pd.read_csv("inputs/pattern.csv")
x = data["two_theta_deg"].to_numpy(float)
y = data["intensity"].to_numpy(float)

# A broad lower-envelope filter is used only for exploratory peak finding.
baseline = percentile_filter(y, percentile=15, size=401, mode="nearest")
net = gaussian_filter1d(y - baseline, 1.5)
peaks, props = find_peaks(net, prominence=60, height=70, distance=4)
width = peak_widths(net, peaks, rel_height=0.5)[0] * np.median(np.diff(x))
order = np.argsort(props["prominences"])[::-1]

print("rank,two_theta,intensity,net_height,prominence,fwhm_deg")
for rank, j in enumerate(order[:120], 1):
    i = peaks[j]
    print(
        f"{rank},{x[i]:.6f},{y[i]:.1f},{net[i]:.1f},"
        f"{props['prominences'][j]:.1f},{width[j]:.4f}"
    )

Path(".tmp").mkdir(exist_ok=True)
fig, axes = plt.subplots(2, 1, figsize=(16, 9), sharey=False)
for ax, lo, hi in zip(axes, (9.9, 50.0), (50.0, 100.1)):
    m = (x >= lo) & (x <= hi)
    ax.plot(x[m], y[m], color="black", lw=0.65)
    ax.plot(x[m], baseline[m], color="tab:orange", lw=0.7)
    chosen = peaks[(x[peaks] >= lo) & (x[peaks] <= hi)]
    ax.scatter(x[chosen], y[chosen], s=7, color="tab:red")
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
axes[-1].set_xlabel(r"$2\theta$ (degrees, Cu K$\alpha$)")
fig.tight_layout()
fig.savefig(".tmp/pattern_peaks.png", dpi=170)
