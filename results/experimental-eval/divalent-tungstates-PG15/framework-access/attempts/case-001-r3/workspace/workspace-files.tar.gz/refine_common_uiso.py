"""Refine one symmetry-independent isotropic displacement value per phase."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("--source", required=True)
parser.add_argument("--output", required=True)
parser.add_argument("--start", type=float, default=0.008)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=args.source, newgpx=args.output)
hist = project.histogram(0)
project.data["Constraints"]["data"].update({"Hist": [], "HAP": [], "Phase": [], "Global": []})
project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}

hist.Background[0][1] = True
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
    if key in hist.SampleParameters and isinstance(hist.SampleParameters[key], list):
        hist.SampleParameters[key][1] = False

for pidx, phase in enumerate(project.phases()):
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][2] = phase.name == "BaCO3"
    vars_for_phase = []
    for aidx, atom in enumerate(phase.atoms()):
        atom.uiso = args.start
        atom.refinement_flags = "U"
        vars_for_phase.append(f"{pidx}::AUiso:{aidx}")
    project.add_EquivConstr(vars_for_phase, reloadIdx=True)

project.set_Controls("cycles", 20)
project.refine(makeBack=False)
project.save()

obs = np.asarray(hist.getdata("Yobs"), float)
calc = np.asarray(hist.getdata("Ycalc"), float)
weight = 1.0 / np.maximum(obs, 1.0)
rwp = float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))
masses = [
    p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
    for p in project.phases()
]
result = {
    "rwp_percent": rwp,
    "uiso": {p.name: [a.uiso for a in p.atoms()] for p in project.phases()},
    "weight_fractions": {p.name: float(m / sum(masses)) for p, m in zip(project.phases(), masses)},
    "vary_list": project.data["Covariance"]["data"].get("varyList", []),
    "constraints": project.data["Constraints"]["data"],
    "residuals": hist.residuals,
}
Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
print(json.dumps(result, indent=2, default=str))
