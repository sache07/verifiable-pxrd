"""Physically bounded GSAS-II refinement from an existing two-phase project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project: G2.G2Project) -> float:
    hist = project.histogram(0)
    obs = np.asarray(hist.getdata("Yobs"), float)
    calc = np.asarray(hist.getdata("Ycalc"), float)
    weight = 1.0 / np.maximum(obs, 1.0)
    return float(100.0 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def refine(project: G2.G2Project, label: str, log: list[dict], cycles: int = 12) -> None:
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    item = {
        "stage": label,
        "rwp_percent": rwp(project),
        "gof": project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "vary_list": project.data["Covariance"]["data"].get("varyList", []),
        "frozen": project.get_Frozen(),
    }
    log.append(item)
    print(label, item["rwp_percent"], "frozen", item["frozen"], flush=True)


def set_inst(hist, name: str, value: float, refine_flag: bool = False) -> None:
    hist.InstrumentParameters[name][1] = float(value)
    hist.InstrumentParameters[name][2] = bool(refine_flag)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--zero", type=float, default=-0.15)
    parser.add_argument("--shift", type=float, default=-650.0)
    parser.add_argument("--U", type=float, default=20.0)
    parser.add_argument("--W", type=float, default=12.0)
    parser.add_argument("--X", type=float, default=3.0)
    parser.add_argument("--SHL", type=float, default=0.02)
    parser.add_argument("--polarization", type=float, default=0.7)
    parser.add_argument("--baco-size", type=float, default=0.5)
    parser.add_argument("--wo3-size", type=float, default=0.8)
    parser.add_argument("--baco-strain", type=float, default=0.0)
    parser.add_argument("--wo3-strain", type=float, default=2500.0)
    parser.add_argument("--baco-uiso", type=float, default=0.008)
    parser.add_argument("--wo3-uiso", type=float, default=0.008)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=args.base, newgpx=args.output)
    hist = project.histogram(0)
    project.data["Constraints"]["data"].update({"Hist": [], "HAP": [], "Phase": [], "Global": []})
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}

    for name, value in {
        "Zero": args.zero,
        "U": args.U,
        "V": 0.0,
        "W": args.W,
        "X": args.X,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": args.SHL,
        "Polariz.": args.polarization,
    }.items():
        set_inst(hist, name, value, False)
    hist.SampleParameters["Shift"] = [float(args.shift), False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.Background[0][1] = True

    starts = {
        "BaCO3": (args.baco_size, args.baco_strain, args.baco_uiso),
        "WO3": (args.wo3_size, args.wo3_strain, args.wo3_uiso),
    }
    for pidx, phase in enumerate(project.phases()):
        size, strain, uiso = starts[phase.name]
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.uiso = float(uiso)
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = float(size)
        hap["Size"][1][1] = float(size)
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = float(strain)
        hap["Mustrain"][1][1] = float(strain)
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][2] = phase.name == "BaCO3"
        if phase.name == "BaCO3":
            hap["Pref.Ori."][3] = [1, 1, 0]
        hap["Extinction"] = [0.0, False]

    project.save()
    project.index_ids()
    limits = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
        "0:0:Scale": (0.0, 1e6),
        "1:0:Scale": (0.0, 1e6),
        "0:0:MD": (0.7, 1.4),
        "0:0:Size;i": (0.04, 1.5),
        "1:0:Size;i": (0.04, 1.5),
    }
    if args.baco_strain > 0:
        limits["0:0:Mustrain;i"] = (300.0, 8000.0)
    if args.wo3_strain > 0:
        limits["1:0:Mustrain;i"] = (300.0, 8000.0)
    for variable, (low, high) in limits.items():
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)

    log: list[dict] = []
    refine(project, "scale_background", log, 12)

    # Peak positions: wide angular coverage distinguishes constant zero from
    # the cosine dependence of Bragg-Brentano specimen displacement.
    hist.InstrumentParameters["Zero"][2] = True
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    refine(project, "positions", log, 18)

    # Shared instrument broadening and polarization.
    for name in ("U", "W", "X", "SH/L", "Polariz."):
        hist.InstrumentParameters[name][2] = True
    refine(project, "instrument", log, 18)

    # Phase-specific size and optional strain.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        if starts[phase.name][1] > 0:
            hap["Mustrain"][2][0] = True
    refine(project, "phase_widths", log, 20)
    refine(project, "joint", log, 20)

    masses = [
        phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ]
    result = {
        "stages": log,
        "rwp_percent": rwp(project),
        "fractions": {phase.name: float(mass / sum(masses)) for phase, mass in zip(project.phases(), masses)},
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "phases": {
            phase.name: {
                "cell": phase.data["General"]["Cell"],
                "hap": phase.data["Histograms"][hist.name],
                "uiso": [atom.uiso for atom in phase.atoms()],
            }
            for phase in project.phases()
        },
    }
    Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    project.save(args.output)
    print(json.dumps({"rwp_percent": result["rwp_percent"], "fractions": result["fractions"]}, indent=2))


if __name__ == "__main__":
    main()
