"""Stable replay-consistent refinement of selected interior parameters."""

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("--source", required=True)
parser.add_argument("--output", required=True)
parser.add_argument("--mode", choices=("intensity", "widths", "joint"), required=True)
parser.add_argument("--rough-b", type=float, default=None)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=args.source, newgpx=args.output)
hist = project.histogram(0)
project.set_Frozen()
# All parameters varied here begin inside their physical ranges. Removing the
# inherited clipping limits avoids stale calculated arrays after a clamp.
project.data["Controls"]["data"]["parmMinDict"] = {}
project.data["Controls"]["data"]["parmMaxDict"] = {}
if args.rough_b is not None:
    hist.SampleParameters["SurfRoughB"][0] = float(args.rough_b)

hist.Background[0][1] = True
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
    if key in hist.SampleParameters and isinstance(hist.SampleParameters[key], list):
        hist.SampleParameters[key][1] = False

vary_intensity = args.mode in {"intensity", "joint"}
vary_widths = args.mode in {"widths", "joint"}
if vary_intensity:
    hist.InstrumentParameters["Polariz."][2] = True
    # Keep B fixed to remove the near-perfect A/B roughness correlation.
    hist.SampleParameters["SurfRoughA"][1] = True
if vary_widths:
    for name in ("W", "X", "SH/L"):
        hist.InstrumentParameters[name][2] = True

for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][2] = phase.name == "BaCO3"
    if vary_widths:
        # WO3 size is fixed at its physically admissible upper limit; all
        # other varied width terms start in the interior.
        if phase.name == "BaCO3":
            hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
    for atom in phase.atoms():
        atom.refinement_flags = "U" if vary_intensity else " "

project.set_Controls("cycles", 30)
project.refine(makeBack=False)
project.save()

obs = np.asarray(hist.getdata("Yobs"), float)
calc = np.asarray(hist.getdata("Ycalc"), float)
weight = 1 / np.maximum(obs, 1.0)
rwp = float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))
masses = [
    p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
    for p in project.phases()
]
result = {
    "mode": args.mode,
    "rwp_percent": rwp,
    "weight_fractions": {p.name: float(m / sum(masses)) for p, m in zip(project.phases(), masses)},
    "uiso": {p.name: [a.uiso for a in p.atoms()] for p in project.phases()},
    "instrument": hist.InstrumentParameters,
    "sample": hist.SampleParameters,
    "phases": {
        p.name: {"hap": p.data["Histograms"][hist.name]} for p in project.phases()
    },
    "vary_list": project.data["Covariance"]["data"].get("varyList", []),
    "residuals": hist.residuals,
}
Path(args.output).with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
print(json.dumps({"rwp_percent": rwp, "weight_fractions": result["weight_fractions"], "uiso": result["uiso"]}, indent=2))
