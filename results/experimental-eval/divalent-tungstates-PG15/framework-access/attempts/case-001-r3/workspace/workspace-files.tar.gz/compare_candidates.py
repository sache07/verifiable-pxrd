from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
IDS = [
    "9010928", "1011149",  # ambient BaCO3
    "1004057", "1010618", "1521532", "1521533", "1528915",
    "1563541", "2311041", "2106293", "2107312",  # WO3 polymorphs
    "1527204", "1001273", "1533878", "1534803",  # Ba-W-O phases
]


def cif_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


calc = XRDCalculator(wavelength=1.540598)
patterns = {}
for cod_id in IDS:
    try:
        structure = Structure.from_file(cif_path(cod_id))
        pattern = calc.get_pattern(structure, two_theta_range=(9.8, 100.2), scaled=True)
    except Exception as exc:
        print(cod_id, "ERROR", repr(exc))
        continue
    patterns[cod_id] = pattern
    order = np.argsort(pattern.y)[::-1][:14]
    peaks = " ".join(f"{pattern.x[i]:.3f}:{pattern.y[i]:.0f}" for i in order)
    print(
        cod_id,
        structure.composition.reduced_formula,
        structure.get_space_group_info(),
        tuple(round(v, 4) for v in structure.lattice.abc),
        tuple(round(v, 3) for v in structure.lattice.angles),
        peaks,
    )

data = pd.read_csv("inputs/pattern.csv")
x = data["two_theta_deg"].to_numpy(float)
y = data["intensity"].to_numpy(float)

Path(".tmp").mkdir(exist_ok=True)
fig, axes = plt.subplots(2, 1, figsize=(18, 10))
show_ids = ["9010928", "2106293", "2311041", "1010618", "1527204", "1001273", "1533878", "1534803"]
for ax, lo, hi in zip(axes, (9.8, 49.8), (49.8, 100.2)):
    mask = (x >= lo) & (x <= hi)
    ymax = y[mask].max()
    ax.plot(x[mask], y[mask], color="black", lw=0.65)
    offsets = np.linspace(-0.08 * ymax, -0.75 * ymax, len(show_ids))
    for cod_id, offset in zip(show_ids, offsets):
        if cod_id not in patterns:
            continue
        p = patterns[cod_id]
        pmask = (p.x >= lo) & (p.x <= hi)
        heights = p.y[pmask] / 100 * (0.06 * ymax)
        ax.vlines(p.x[pmask], offset, offset + heights, lw=0.7)
        ax.text(lo + 0.15, offset + 0.005 * ymax, cod_id, fontsize=8, va="bottom")
    ax.set_xlim(lo, hi)
    ax.set_ylim(-0.84 * ymax, 1.04 * ymax)
    ax.set_ylabel("counts / candidate sticks")
axes[-1].set_xlabel(r"$2\theta$ (degrees, Cu K$\alpha_1$)")
fig.tight_layout()
fig.savefig(".tmp/candidate_sticks.png", dpi=180)
