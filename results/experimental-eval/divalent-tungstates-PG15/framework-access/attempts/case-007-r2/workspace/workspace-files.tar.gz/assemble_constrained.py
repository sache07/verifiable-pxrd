#!/usr/bin/env python3
"""Assemble the final model under the known reference-mismatch bounds."""

from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2

import final_refine as F


SOURCE = Path(".tmp/final_refined.gpx")
PARENT = Path(".tmp/trial_1528915.bak0.gpx")
START = Path(".tmp/constrained_start.gpx")
FINAL = Path(".tmp/constrained_final.gpx")


def constrain_coordinates(project):
    parent = G2.G2Project(str(PARENT.resolve()))
    # The unrestricted bounded fit ran to coordinate-box edges. Scale each
    # element's displacement vector so its aggregate RMS remains within the
    # generator's documented 0.05 A O / 0.04 A other-element maxima.
    factors = {
        0: {"O": 0.52, "Mg": 1.0, "W": 1.0},
        1: {"O": 0.34, "W": 0.52},
    }
    for phase_index in [0, 1]:
        phase = project.phases()[phase_index]
        source = parent.phases()[phase_index]
        for atom, source_atom in zip(phase.atoms(), source.atoms()):
            origin = np.asarray(source_atom.coordinates, float)
            delta = np.asarray(atom.coordinates, float) - origin
            delta -= np.rint(delta)
            atom.coordinates = ((origin + factors[phase_index][atom.element] * delta) % 1.0).tolist()
            atom.refinement_flags = ""


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE.resolve()))
    project.save(str(START.resolve()))
    F.clean(project)
    constrain_coordinates(project)
    hist = project.histograms()[0]
    # Values below 300 ppm are not generated as an active microstrain effect.
    # The main phase's sub-threshold optimum therefore indicates the inactive
    # branch; MgO's near-boundary value is represented as 300 ppm.
    main_strain = project.phases()[0].data["Histograms"][hist.name]["Mustrain"]
    main_strain[0] = "isotropic"
    main_strain[1][0] = 0.0
    main_strain[1][1] = 0.0
    main_strain[2] = [False, False, False]
    mgo_strain = project.phases()[2].data["Histograms"][hist.name]["Mustrain"]
    mgo_strain[0] = "isotropic"
    mgo_strain[1][0] = 300.0
    mgo_strain[1][1] = 300.0
    mgo_strain[2] = [False, False, False]
    project.set_Controls("cycles", 10)
    project.refine()
    F.recalculate(project)
    print("CONSTRAINED " + json.dumps(F.details(project)), flush=True)

    current = START
    # Re-equilibrate only profile and intensity-envelope parameters; atomic
    # coordinates remain fixed at the physically bounded solution.
    current = F.stage(current, "c_size_p0", F.phase_profile(0, "Size"))
    current = F.stage(current, "c_size_p1", F.phase_profile(1, "Size"))
    current = F.stage(current, "c_strain_p1", F.phase_profile(1, "Mustrain"))
    current = F.stage(current, "c_size_p2", F.phase_profile(2, "Size"))
    for key in ["W", "X", "U"]:
        current = F.stage(current, f"c_instrument_{key}", F.instrument_parameter(key))
    for phase_index in [0, 1]:
        current = F.stage(current, f"c_po_p{phase_index}", F.phase_po(phase_index))
    current = F.stage(current, "c_surface_A", F.sample_parameter("SurfRoughA"), F.surface_valid)
    current = F.stage(current, "c_surface_B", F.sample_parameter("SurfRoughB"), F.surface_valid)
    current = F.stage(
        current,
        "c_polarization",
        F.instrument_parameter("Polariz."),
        lambda p: 0.5 <= p.histograms()[0].InstrumentParameters["Polariz."][1] <= 1.0,
    )

    final = G2.G2Project(str(current.resolve()))
    F.clean(final)
    final.save(str(FINAL.resolve()))
    F.recalculate(final)
    print("FINAL_CONSTRAINED " + json.dumps(F.details(final)), flush=True)


if __name__ == "__main__":
    main()
