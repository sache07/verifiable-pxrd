#!/usr/bin/env python3
"""Screen physically supported intensity parameters with structures held fixed."""

from __future__ import annotations

from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


START = Path(".tmp/final_moderate.bak0.gpx")
WORK = Path(".tmp/intensity_base.gpx")
FINAL = Path(".tmp/intensity_optimized.gpx")
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def rwp(project):
    hist = project.histograms()[0]
    _, obs, weights, calc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs ** 2)))


def clean(project):
    hist = project.histograms()[0]
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
    )
    hist.clear_refinements(
        {"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]}
    )
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def summary(project):
    hist = project.histograms()[0]
    return {
        "rwp": rwp(project),
        "fractions": hist.ComputeMassFracs(),
        "surface": [hist.SampleParameters["SurfRoughA"][0], hist.SampleParameters["SurfRoughB"][0]],
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "uiso": {phase.name: phase.atoms()[0].uiso for phase in project.phases()},
        "po": {
            phase.name: phase.data["Histograms"][hist.name]["Pref.Ori."][1:4]
            for phase in project.phases()
        },
    }


def evaluate(source, destination, setter=None, cycles=7):
    project = G2.G2Project(str(source.resolve()))
    project.save(str(destination.resolve()))
    clean(project)
    if setter is not None:
        setter(project)
    project.set_Controls("cycles", cycles)
    project.refine()
    clean(project)
    project.save()
    return project


def choose_grid(source, stage, options, setter):
    base = G2.G2Project(str(source.resolve()))
    candidates = [(rwp(base), "baseline", source)]
    print("GRID " + json.dumps({"stage": stage, "option": "baseline", **summary(base)}), flush=True)
    for index, option in enumerate(options):
        destination = Path(".tmp") / f"grid_{stage}_{index}.gpx"
        project = evaluate(source, destination, lambda p, v=option: setter(p, v))
        candidates.append((rwp(project), option, destination))
        print("GRID " + json.dumps({"stage": stage, "option": option, **summary(project)}), flush=True)
    best = min(candidates, key=lambda item: item[0])
    selected = G2.G2Project(str(best[2].resolve()))
    output = Path(".tmp") / f"selected_{stage}.gpx"
    clean(selected)
    selected.save(str(output.resolve()))
    print("SELECTED " + json.dumps({"stage": stage, "option": best[1], **summary(selected)}), flush=True)
    return output


def set_surface(project, pair):
    hist = project.histograms()[0]
    hist.SampleParameters["SurfRoughA"] = [float(pair[0]), False]
    hist.SampleParameters["SurfRoughB"] = [float(pair[1]), False]


def set_polarization(project, value):
    project.histograms()[0].InstrumentParameters["Polariz."][1] = float(value)


def set_uiso(project, specification):
    phase_index, value = specification
    for atom in project.phases()[phase_index].atoms():
        atom.uiso = float(value)
        atom.refinement_flags = ""


def set_po(project, specification):
    phase_index, axis = specification
    hist = project.histograms()[0]
    phase = project.phases()[phase_index]
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)
    hist_id = hist.data["data"][0]["hId"]
    project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:{hist_id}:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:{hist_id}:MD")


def main():
    G2.SetPrintLevel("warn")
    # Recompute the scale/background least-squares state with all accidental
    # coordinate flags removed from the backup checkpoint.
    baseline = evaluate(START, WORK, cycles=9)
    print("BASE " + json.dumps(summary(baseline)), flush=True)
    current = WORK

    surface_options = ([0.0, 0.0], [0.10, 0.025], [0.20, 0.040], [0.30, 0.080], [0.45, 0.150])
    current = choose_grid(current, "surface", surface_options, set_surface)
    current = choose_grid(current, "polarization", [0.5, 0.6, 0.8, 0.9, 1.0], set_polarization)

    uiso_values = [0.003, 0.0045, 0.0065, 0.010, 0.014, 0.020]
    for phase_index in range(3):
        options = [(phase_index, value) for value in uiso_values]
        current = choose_grid(current, f"uiso_p{phase_index}", options, set_uiso)

    # Screen texture only for phases with enough reflections/intensity to
    # support it. The MgO trace phase is left as a random powder.
    for phase_index in [0, 1]:
        options = [(phase_index, list(axis)) for axis in AXES]
        current = choose_grid(current, f"po_p{phase_index}", options, set_po)

    project = G2.G2Project(str(current.resolve()))
    clean(project)
    project.save(str(FINAL.resolve()))
    print("FINAL " + json.dumps(summary(project)), flush=True)


if __name__ == "__main__":
    main()
