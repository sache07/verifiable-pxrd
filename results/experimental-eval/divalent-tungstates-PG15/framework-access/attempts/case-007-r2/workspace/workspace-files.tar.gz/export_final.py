#!/usr/bin/env python3
"""Freeze the selected GSAS-II model and export all requested deliverables."""

from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2

import final_refine as F


SOURCE = Path(".tmp/polished_final.gpx")
PROJECT = Path("final.gpx")
PHASE_FILES = [
    Path("phase_1_MgWO4.cif"),
    Path("phase_2_WO3.cif"),
    Path("phase_3_MgO.cif"),
]
REFERENCE_IDS = ["COD 9013902", "COD 1528915", "COD 9000499"]


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE.resolve()))
    project.save(str(PROJECT.resolve()))
    F.clean(project)
    hist = project.histograms()[0]
    for phase in project.phases():
        phase.data["General"]["doPawley"] = False
        phase.data["Histograms"][hist.name]["LeBail"] = False

    # One final scale/background least-squares pass provides current covariance
    # estimates while all structural/profile parameters stay frozen.
    project.set_Controls("cycles", 6)
    project.refine()
    project.save()

    x, observed, weights, calculated, background, difference = [
        np.asarray(value, float) for value in hist.data["data"][1][:6]
    ]
    public = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1, ndmin=2)
    if not np.allclose(x, public[:, 0], rtol=0, atol=1e-9) or not np.array_equal(observed, public[:, 1]):
        raise RuntimeError("Final project no longer contains the complete observed scan")
    if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("Final calculated profile is nonfinite or negative")
    if np.min(background) < -1e-6:
        raise RuntimeError("Final background contains negative counts")

    np.savetxt(
        "fit.csv",
        np.column_stack([x, observed, calculated, observed - calculated]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
    )

    covariance = project.data.get("Covariance", {}).get("data", {})
    varied = covariance.get("varyList", [])
    denominator = float(np.sum(weights * observed**2))
    chi_square = float(np.sum(weights * (observed - calculated) ** 2))
    dof = max(1, len(x) - len(varied))
    rwp = float(100 * np.sqrt(chi_square / denominator))
    rp = float(100 * np.sum(np.abs(observed - calculated)) / np.sum(observed))
    rexp = float(100 * np.sqrt(dof / denominator))
    reduced = float(chi_square / dof)

    mass_fractions = hist.ComputeMassFracs()
    records = []
    formulas = ["MgWO4", "WO3", "MgO"]
    for index, (phase, path, formula, reference) in enumerate(
        zip(project.phases(), PHASE_FILES, formulas, REFERENCE_IDS)
    ):
        phase.export_CIF(str(path))
        fraction, esd = mass_fractions[phase.name]
        records.append(
            {
                "name": phase.name,
                "formula": formula,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "reference_model": reference,
                "cif_path": str(path),
                "weight_fraction": float(fraction),
                "formal_scale_esd": float(esd),
            }
        )

    result = {
        "method": "GSAS-II multiphase Rietveld refinement",
        "fraction_basis": "normalized over modeled crystalline phases",
        "refinement_histogram": hist.name,
        "phases": records,
        "unresolved_components": [],
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "rexp_percent": rexp,
            "goodness_of_fit": float(np.sqrt(reduced)),
            "weighted_chi_square": chi_square,
            "reduced_chi_square": reduced,
            "n_points": int(len(x)),
            "weighting": "1/max(observed,1)",
        },
        "calibration": {
            "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
            "sample_displacement_um": float(hist.SampleParameters["Shift"][0]),
        },
    }
    Path("result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
