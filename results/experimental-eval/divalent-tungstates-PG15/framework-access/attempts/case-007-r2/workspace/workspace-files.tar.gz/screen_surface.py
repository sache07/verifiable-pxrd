#!/usr/bin/env python3
"""Screen whole-specimen Suortti surface roughness starts."""

from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

BASE=Path('.tmp/positioned_1528915.gpx')
STARTS=((.1,.025),(.2,.05),(.3,.1),(.5,.1),(.3,.25),(.6,.3))

def rwp(p):
 h=p.histograms()[0];x,y,w,yc=[np.asarray(v,float) for v in h.data['data'][1][:4]]
 return float(100*np.sqrt(np.sum(w*(y-yc)**2)/np.sum(w*y*y)))

def trial(i,A,B):
 p=G2.G2Project(str(BASE.resolve()));p.save(str(Path('.tmp')/f'surface_{i}.gpx'))
 h=p.histograms()[0]
 h.clear_refinements({'Instrument Parameters':['Zero','U','W','X','SH/L','Polariz.']})
 h.clear_refinements({'Sample Parameters':['Shift','SurfRoughA','SurfRoughB']})
 for q in p.phases():
  q.clear_refinements({'Cell':True,'Atoms':[a.label for a in q.atoms()]})
  q.clear_HAP_refinements({'Size':True,'Mustrain':True,'Pref.Ori.':True})
 h.SampleParameters['SurfRoughA']=[A,True];h.SampleParameters['SurfRoughB']=[B,True]
 p.data['Controls']['data']['parmFrozen']={'FrozenList':[]};p.set_Controls('cycles',10);p.refine();p.save()
 out={'start':[A,B],'A':h.SampleParameters['SurfRoughA'][0],'B':h.SampleParameters['SurfRoughB'][0],
      'rwp':rwp(p),'fractions':h.ComputeMassFracs(),'frozen':[str(v) for v in p.get_Controls('parmFrozen')]}
 print('SURFACE',json.dumps(out),flush=True);return out

if __name__=='__main__':
 G2.SetPrintLevel('warn');print('BASE',rwp(G2.G2Project(str(BASE.resolve()))),flush=True)
 z=[trial(i,*v) for i,v in enumerate(STARTS)];print('BEST',json.dumps(min(z,key=lambda a:a['rwp'])),flush=True)
