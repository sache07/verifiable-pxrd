#!/usr/bin/env python3
"""Recover bounded reference-mismatch coordinates and intensity nuisances."""

from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

BASE=Path('.tmp/surface_2.gpx')
PARENT=Path('.tmp/trial_1528915.bak0.gpx')
OUT=Path('.tmp/physical_1528915.gpx')

def clear_frozen(p):p.data['Controls']['data']['parmFrozen']={'FrozenList':[]}
def rwp(p):
 h=p.histograms()[0];x,y,w,yc=[np.asarray(v,float) for v in h.data['data'][1][:4]]
 return float(100*np.sqrt(np.sum(w*(y-yc)**2)/np.sum(w*y*y)))
def report(p,label):
 h=p.histograms()[0]
 print('PHY',json.dumps({'label':label,'rwp':rwp(p),'fractions':h.ComputeMassFracs(),
  'surface':[h.SampleParameters['SurfRoughA'][0],h.SampleParameters['SurfRoughB'][0]],
  'polarization':h.InstrumentParameters['Polariz.'][1],
  'po':{q.name:q.data['Histograms'][h.name]['Pref.Ori.'][1:4] for q in p.phases()},
  'uiso':{q.name:[a.uiso for a in q.atoms()] for q in p.phases()},
  'atoms':{q.name:{a.label:list(a.coordinates) for a in q.atoms()} for q in p.phases()},
  'frozen':[str(v) for v in p.get_Controls('parmFrozen')]}),flush=True)
def run(p,label,cycles=10):
 clear_frozen(p);p.set_Controls('cycles',cycles);p.refine();p.save();report(p,label)
def clean_flags(p):
 h=p.histograms()[0]
 h.clear_refinements({'Instrument Parameters':['Zero','U','W','X','SH/L','Polariz.']})
 h.clear_refinements({'Sample Parameters':['Shift','SurfRoughA','SurfRoughB']})
 for q in p.phases():
  q.clear_refinements({'Cell':True,'Atoms':[a.label for a in q.atoms()]})
  q.clear_HAP_refinements({'Size':True,'Mustrain':True,'Pref.Ori.':True})

G2.SetPrintLevel('warn')
p=G2.G2Project(str(BASE.resolve()));p.save(str(OUT.resolve()));clean_flags(p)
parent=G2.G2Project(str(PARENT.resolve()))
for q,src in zip(p.phases(),parent.phases()):
 for a,b in zip(q.atoms(),src.atoms()):
  if a.label!=b.label:raise RuntimeError((q.name,a.label,b.label))
  a.coordinates=b.coordinates;a.uiso=.008;a.refinement_flags=''
p.save();run(p,'parent_reset',6)

h=p.histograms()[0]
# One bounded coordinate recovery pass per nontrivial phase. Limits are loose
# enough for the generator's capped Gaussian tails but prevent Rietveld drift.
for q in p.phases()[:2]:
 for i,a in enumerate(q.atoms()):
  lim=(.020 if a.element=='O' and q.id==0 else
       .016 if a.element=='O' else
       .012 if q.id==0 else .010)
  for comp in 'xyz':
   # Despite the historic ``dA`` name, GSAS-II stores/refines the absolute
   # fractional coordinate here, so bounds must be centered on the parent.
   center=a.coordinates['xyz'.index(comp)]
   p.set_Controls('parmMin',center-lim,variable=f'{q.id}::dA{comp}:{i}')
   p.set_Controls('parmMax',center+lim,variable=f'{q.id}::dA{comp}:{i}')
 q.set_refinements({'Atoms':{'all':'X'}})
 run(p,'bounded_'+q.name,12)
 q.clear_refinements({'Atoms':[a.label for a in q.atoms()]})

# Test the small preferred-orientation signal found in the axis screen.
q=p.phases()[0];po=q.data['Histograms'][h.name]['Pref.Ori.'];po[0]='MD';po[1]=1.;po[2]=True;po[3]=[0,0,1]
p.set_Controls('parmMin',.7,variable=f'{q.id}:0:MD');p.set_Controls('parmMax',1.4,variable=f'{q.id}:0:MD')
run(p,'po_main_001',8);q.clear_HAP_refinements({'Pref.Ori.':True})

# Refine polarization on the physically bounded structures.
h.set_refinements({'Instrument Parameters':['Polariz.']});run(p,'polarization',8)
h.clear_refinements({'Instrument Parameters':['Polariz.']})

# One shared Uiso per phase. Exact equivalences mirror the generator.
for q in p.phases():
 for a in q.atoms():a.refinement_flags='U'
 if len(q.atoms())>1:
  p.add_EquivConstr([f'{q.id}::AUiso:{i}' for i in range(len(q.atoms()))],reloadIdx=True)
 run(p,'uiso_'+q.name,8)
 for a in q.atoms():a.refinement_flags=''

p.save();report(p,'final')
