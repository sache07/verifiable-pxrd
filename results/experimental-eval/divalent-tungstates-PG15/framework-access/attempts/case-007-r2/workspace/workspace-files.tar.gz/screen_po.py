#!/usr/bin/env python3
"""Screen March-Dollase axes without carrying one trial into the next."""

from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2


BASE = Path(".tmp/positioned_1528915.gpx")
AXES = ([0,0,1],[1,0,0],[0,1,0],[1,1,0],[1,1,1])


def rwp(p):
    h=p.histograms()[0]
    x,y,w,yc=[np.asarray(v,float) for v in h.data['data'][1][:4]]
    return float(100*np.sqrt(np.sum(w*(y-yc)**2)/np.sum(w*y*y)))


def clean(p):
    h=p.histograms()[0]
    h.clear_refinements({'Instrument Parameters':['Zero','U','W','X','SH/L','Polariz.']})
    h.clear_refinements({'Sample Parameters':['Shift','SurfRoughA','SurfRoughB']})
    for q in p.phases():
        q.clear_refinements({'Cell':True,'Atoms':[a.label for a in q.atoms()]})
        q.clear_HAP_refinements({'Size':True,'Mustrain':True,'Pref.Ori.':True})
    p.data['Controls']['data']['parmFrozen']={'FrozenList':[]}


def trial(pidx,axis):
    tag=f"p{pidx}_"+''.join(map(str,axis))
    p=G2.G2Project(str(BASE.resolve()))
    p.save(str(Path('.tmp')/f'po_{tag}.gpx'))
    clean(p)
    h=p.histograms()[0]; q=p.phases()[pidx]
    po=q.data['Histograms'][h.name]['Pref.Ori.']
    po[0]='MD';po[1]=1.0;po[2]=True;po[3]=list(axis)
    p.set_Controls('parmMin',0.7,variable=f'{q.id}:{h.data["data"][0]["hId"]}:MD')
    p.set_Controls('parmMax',1.4,variable=f'{q.id}:{h.data["data"][0]["hId"]}:MD')
    p.set_Controls('cycles',7);p.refine();p.save()
    out={'phase':q.name,'phase_index':pidx,'axis':list(axis),'ratio':po[1],'rwp':rwp(p),
         'frozen':[str(v) for v in p.get_Controls('parmFrozen')]}
    print('PO',json.dumps(out),flush=True)
    return out


if __name__=='__main__':
    G2.SetPrintLevel('warn')
    import argparse
    a=argparse.ArgumentParser();a.add_argument('--phase',type=int,default=0);args=a.parse_args()
    print('BASE',rwp(G2.G2Project(str(BASE.resolve()))),flush=True)
    results=[trial(args.phase,axis) for axis in AXES]
    print('BEST',json.dumps(min(results,key=lambda z:z['rwp'])),flush=True)
