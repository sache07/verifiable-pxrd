#!/usr/bin/env python3
"""Build physically bounded Rietveld candidates from the optimized Le Bail profile."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/surface_2.gpx")
PARENT = Path(".tmp/trial_1528915.bak0.gpx")
LE_BAIL = Path(".tmp/lebail_profile.gpx")
OUT_PARENT = Path(".tmp/final_parent.gpx")
OUT_TIGHT = Path(".tmp/final_tight.gpx")
OUT_MODERATE = Path(".tmp/final_moderate.gpx")


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def rwp(project):
    hist = project.histograms()[0]
    _, obs, weights, calc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs ** 2)))


def clean_flags(project):
    hist = project.histograms()[0]
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
    )
    hist.clear_refinements(
        {"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]}
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.data["General"]["doPawley"] = False
        phase.data["Histograms"][hist.name]["LeBail"] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""


def report(project, label):
    hist = project.histograms()[0]
    payload = {
        "label": label,
        "rwp": rwp(project),
        "fractions": hist.ComputeMassFracs(),
        "zero": hist.InstrumentParameters["Zero"][1],
        "shift": hist.SampleParameters["Shift"][0],
        "surface": [hist.SampleParameters["SurfRoughA"][0], hist.SampleParameters["SurfRoughB"][0]],
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "instrument": {k: hist.InstrumentParameters[k][1] for k in ["U", "W", "X", "SH/L"]},
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "size": phase.data["Histograms"][hist.name]["Size"][1][0],
                "strain": phase.data["Histograms"][hist.name]["Mustrain"][1][0],
                "uiso": [atom.uiso for atom in phase.atoms()],
                "atoms": {atom.label: list(atom.coordinates) for atom in phase.atoms()},
            }
            for phase in project.phases()
        },
    }
    print("CANDIDATE " + json.dumps(payload), flush=True)


def refine(project, label, cycles=10):
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    report(project, label)


def copy_profile(project, le_bail):
    """Transfer only profile/geometry values, never Le Bail intensities."""
    hist = project.histograms()[0]
    source_hist = le_bail.histograms()[0]
    for key in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]:
        if key in hist.InstrumentParameters and key in source_hist.InstrumentParameters:
            hist.InstrumentParameters[key][1] = source_hist.InstrumentParameters[key][1]
    # The Le Bail optimum moved 1.1 um beyond the documented simulation range.
    # Use the physical boundary rather than retaining that numerical excursion.
    hist.SampleParameters["Shift"][0] = -800.0
    hist.SampleParameters["Shift"][1] = False
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Transparency"] = [0.0, False]
    # A/B are strongly correlated. These are the best interior, generator-valid
    # surface values from the Rietveld screen and are held fixed for comparison.
    hist.SampleParameters["SurfRoughA"] = [0.1927356, False]
    hist.SampleParameters["SurfRoughB"] = [0.03702694, False]
    hist.InstrumentParameters["Polariz."][1] = 0.70
    hist.InstrumentParameters["Polariz."][2] = False

    for phase, source_phase in zip(project.phases(), le_bail.phases()):
        phase.data["General"]["Cell"][1:] = deepcopy(source_phase.data["General"]["Cell"][1:])
        hap = phase.data["Histograms"][hist.name]
        source_hap = source_phase.data["Histograms"][source_hist.name]
        hap["Size"] = deepcopy(source_hap["Size"])
        hap["Mustrain"] = deepcopy(source_hap["Mustrain"])
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]


def prepare_parent():
    project = G2.G2Project(str(SOURCE.resolve()))
    project.save(str(OUT_PARENT.resolve()))
    clean_flags(project)
    parent = G2.G2Project(str(PARENT.resolve()))
    le_bail = G2.G2Project(str(LE_BAIL.resolve()))
    copy_profile(project, le_bail)
    for phase, source_phase in zip(project.phases(), parent.phases()):
        for atom, source_atom in zip(phase.atoms(), source_phase.atoms()):
            if atom.label != source_atom.label:
                raise RuntimeError((phase.name, atom.label, source_atom.label))
            atom.coordinates = source_atom.coordinates
            atom.uiso = 0.008
            atom.refinement_flags = ""

    hist = project.histograms()[0]
    hist.set_refinements({"Background": {"refine": True}})
    hist.SampleParameters["Scale"] = [1.0, False]
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    project.save()
    refine(project, "parent", 12)
    return project


def coordinate_candidate(base, destination, bounds, label):
    base.save(str(destination.resolve()))
    project = G2.G2Project(str(destination.resolve()))
    parent = G2.G2Project(str(PARENT.resolve()))
    clean_flags(project)
    hist = project.histograms()[0]
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})

    for phase_index in [0, 1]:
        phase = project.phases()[phase_index]
        parent_phase = parent.phases()[phase_index]
        for atom_index, (atom, parent_atom) in enumerate(zip(phase.atoms(), parent_phase.atoms())):
            atom.coordinates = parent_atom.coordinates
            limit = bounds[phase_index]["O" if atom.element == "O" else "heavy"]
            for component_index, component in enumerate("xyz"):
                center = parent_atom.coordinates[component_index]
                variable = f"{phase.id}::dA{component}:{atom_index}"
                project.set_Controls("parmMin", center - limit, variable=variable)
                project.set_Controls("parmMax", center + limit, variable=variable)
        phase.set_refinements({"Atoms": {"all": "X"}})
        refine(project, f"{label}_{phase.name}", 14)
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
        for atom in phase.atoms():
            atom.refinement_flags = ""

    # A second main-phase pass lets scales/background settle after the minor
    # phase changes, while retaining the same physical coordinate bounds.
    phase = project.phases()[0]
    phase.set_refinements({"Atoms": {"all": "X"}})
    refine(project, f"{label}_{phase.name}_second", 10)
    phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
    for atom in phase.atoms():
        atom.refinement_flags = ""
    project.save()
    report(project, label + "_final")
    return project


def main():
    G2.SetPrintLevel("warn")
    parent = prepare_parent()
    tight = {
        0: {"O": 0.012, "heavy": 0.008},
        1: {"O": 0.008, "heavy": 0.006},
    }
    moderate = {
        0: {"O": 0.020, "heavy": 0.012},
        1: {"O": 0.012, "heavy": 0.008},
    }
    coordinate_candidate(parent, OUT_TIGHT, tight, "tight")
    coordinate_candidate(parent, OUT_MODERATE, moderate, "moderate")


if __name__ == "__main__":
    main()
