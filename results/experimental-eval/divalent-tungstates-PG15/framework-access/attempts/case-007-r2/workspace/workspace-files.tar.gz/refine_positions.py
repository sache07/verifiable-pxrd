#!/usr/bin/env python3
"""Refine cells and angular calibration after profile stabilization."""

from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2


SRC = Path(".tmp/improved_1528915.gpx")
OUT = Path(".tmp/positioned_1528915.gpx")


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def stats(p, label):
    h = p.histograms()[0]
    x, y, w, yc = [np.asarray(v, float) for v in h.data["data"][1][:4]]
    rwp = 100 * np.sqrt(np.sum(w * (y-yc)**2) / np.sum(w*y*y))
    print("POS", json.dumps({
        "label": label, "rwp": rwp,
        "zero": h.InstrumentParameters["Zero"][1],
        "shift": h.SampleParameters["Shift"][0],
        "cells": {q.name:q.get_cell() for q in p.phases()},
        "fractions": h.ComputeMassFracs(),
    }), flush=True)


def run(p, label, cycles=8):
    clear_frozen(p)
    p.set_Controls("cycles", cycles)
    p.refine(); p.save(); stats(p,label)


G2.SetPrintLevel("warn")
p = G2.G2Project(str(SRC.resolve()))
p.save(str(OUT.resolve()))
h = p.histograms()[0]

# Clear every potentially conflicting geometry flag first.
h.clear_refinements({"Instrument Parameters": ["Zero","U","W","X","SH/L","Polariz."]})
h.clear_refinements({"Sample Parameters": ["Shift","SurfRoughA","SurfRoughB"]})
for q in p.phases():
    q.clear_refinements({"Cell": True})
stats(p,"start")

for q in p.phases():
    q.set_refinements({"Cell": True})
    run(p,"cell_"+q.name,10)
    q.clear_refinements({"Cell": True})

h.set_refinements({"Instrument Parameters":["Zero"]})
run(p,"zero",8)
h.clear_refinements({"Instrument Parameters":["Zero"]})

for q in p.phases():
    q.set_refinements({"Cell": True})
    run(p,"cell2_"+q.name,8)
    q.clear_refinements({"Cell": True})

# Shift and zero are almost collinear, so update only shift here, with zero fixed.
h.set_refinements({"Sample Parameters":["Shift"]})
run(p,"shift",8)
h.clear_refinements({"Sample Parameters":["Shift"]})

for q in p.phases():
    q.set_refinements({"Cell": True})
    run(p,"cell3_"+q.name,8)
    q.clear_refinements({"Cell": True})

p.save(); stats(p,"final")
