#!/usr/bin/env python3
"""Use Le Bail intensities to optimize only positions and peak shapes."""
from pathlib import Path
import json, numpy as np
from GSASII import GSASIIscriptable as G2
SRC=Path('.tmp/lebail.gpx');OUT=Path('.tmp/lebail_profile.gpx')
def rwp(p):
 h=p.histograms()[0];x,y,w,yc=[np.asarray(v,float) for v in h.data['data'][1][:4]]
 return float(100*np.sqrt(np.sum(w*(y-yc)**2)/np.sum(w*y*y)))
def clear(p):p.data['Controls']['data']['parmFrozen']={'FrozenList':[]}
def show(p,label):
 h=p.histograms()[0]
 print('LB',json.dumps({'label':label,'rwp':rwp(p),'zero':h.InstrumentParameters['Zero'][1],
  'shift':h.SampleParameters['Shift'][0],'inst':{k:h.InstrumentParameters[k][1] for k in ['U','W','X','SH/L']},
  'phases':{q.name:{'cell':q.get_cell(),'size':q.data['Histograms'][h.name]['Size'][1][0],
  'strain':q.data['Histograms'][h.name]['Mustrain'][1][0]} for q in p.phases()},
  'frozen':[str(v) for v in p.get_Controls('parmFrozen')]}),flush=True)
def run(p,label,n=8):clear(p);p.set_Controls('cycles',n);p.refine();p.save();show(p,label)
G2.SetPrintLevel('warn');p=G2.G2Project(str(SRC.resolve()));p.save(str(OUT.resolve()));h=p.histograms()[0]
h.clear_refinements({'Instrument Parameters':['Zero','U','W','X','SH/L','Polariz.']});h.clear_refinements({'Sample Parameters':['Shift','SurfRoughA','SurfRoughB']})
for q in p.phases():
 q.clear_refinements({'Cell':True,'Atoms':[a.label for a in q.atoms()]});q.clear_HAP_refinements({'Size':True,'Mustrain':True,'Pref.Ori.':True,'Scale':True});q.set_refinements({'LeBail':True})
 hid=h.data['data'][0]['hId']
 p.set_Controls('parmMin',-1.2e3,variable=f':{hid}:Shift');p.set_Controls('parmMax',1.2e3,variable=f':{hid}:Shift')
 for q in p.phases():
  p.set_Controls('parmMin',.04,variable=f'{q.id}:{hid}:Size;i');p.set_Controls('parmMax',1.5,variable=f'{q.id}:{hid}:Size;i')
  p.set_Controls('parmMin',0.,variable=f'{q.id}:{hid}:Mustrain;i');p.set_Controls('parmMax',8000.,variable=f'{q.id}:{hid}:Mustrain;i')
show(p,'start')
for passno in range(2):
 for q in p.phases():
  q.set_refinements({'Cell':True});run(p,f'p{passno}_cell_'+q.name,8);q.clear_refinements({'Cell':True})
 h.set_refinements({'Instrument Parameters':['Zero']});run(p,f'p{passno}_zero',8);h.clear_refinements({'Instrument Parameters':['Zero']})
 for q in p.phases():
  q.set_HAP_refinements({'Size':{'type':'isotropic','refine':True}});run(p,f'p{passno}_size_'+q.name,7);q.clear_HAP_refinements({'Size':True})
  q.set_HAP_refinements({'Mustrain':{'type':'isotropic','refine':True}});run(p,f'p{passno}_strain_'+q.name,7);q.clear_HAP_refinements({'Mustrain':True})
 for key in ['W','X','U','SH/L']:
  h.set_refinements({'Instrument Parameters':[key]});run(p,f'p{passno}_inst_'+key,7);h.clear_refinements({'Instrument Parameters':[key]})
 h.set_refinements({'Sample Parameters':['Shift']});run(p,f'p{passno}_shift',7);h.clear_refinements({'Sample Parameters':['Shift']})
p.save();show(p,'final')
