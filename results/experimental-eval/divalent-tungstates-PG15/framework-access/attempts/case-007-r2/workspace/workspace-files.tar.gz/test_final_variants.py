#!/usr/bin/env python3
"""Regularization and weak-parameter sensitivity tests around the final model."""

from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


BASE = Path(".tmp/final_refined.gpx")
PARENT = Path(".tmp/trial_1528915.bak0.gpx")


def rwp(project):
    hist = project.histograms()[0]
    _, obs, weights, calc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs ** 2)))


def clean(project):
    hist = project.histograms()[0]
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
    )
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(project):
    hist = project.histograms()[0]
    masses = [
        phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ]
    return [float(value / sum(masses)) for value in masses]


def evaluate(tag, setter):
    destination = Path(".tmp") / f"variant_{tag}.gpx"
    project = G2.G2Project(str(BASE.resolve()))
    project.save(str(destination.resolve()))
    clean(project)
    setter(project)
    project.set_Controls("cycles", 8)
    project.refine()
    clean(project)
    project.set_Controls("cycles", 0)
    project.refine()
    clean(project)
    project.save()
    hist = project.histograms()[0]
    out = {
        "tag": tag,
        "rwp": rwp(project),
        "fractions": fractions(project),
        "uiso": [phase.atoms()[0].uiso for phase in project.phases()],
        "strain": [phase.data["Histograms"][hist.name]["Mustrain"][:4] for phase in project.phases()],
    }
    print("VARIANT " + json.dumps(out), flush=True)
    return out


def coordinate_shrink(phase_index, alpha):
    parent = G2.G2Project(str(PARENT.resolve()))

    def setter(project):
        phase = project.phases()[phase_index]
        source = parent.phases()[phase_index]
        for atom, parent_atom in zip(phase.atoms(), source.atoms()):
            current = np.asarray(atom.coordinates, float)
            origin = np.asarray(parent_atom.coordinates, float)
            delta = current - origin
            delta -= np.rint(delta)
            atom.coordinates = ((origin + alpha * delta) % 1.0).tolist()

    return setter


def set_uiso(phase_index, value):
    def setter(project):
        for atom in project.phases()[phase_index].atoms():
            atom.uiso = value

    return setter


def set_strain(phase_index, kind, values, axis=(0, 0, 1)):
    def setter(project):
        hist = project.histograms()[0]
        hap = project.phases()[phase_index].data["Histograms"][hist.name]
        hap["Mustrain"][0] = kind
        hap["Mustrain"][1][0] = values[0]
        hap["Mustrain"][1][1] = values[1]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][3] = list(axis)

    return setter


def main():
    G2.SetPrintLevel("warn")
    base = G2.G2Project(str(BASE.resolve()))
    print("BASE " + json.dumps({"rwp": rwp(base), "fractions": fractions(base)}), flush=True)

    for phase_index in [0, 1]:
        for alpha in [0.0, 0.25, 0.5, 0.75]:
            evaluate(f"coords_p{phase_index}_a{alpha:.2f}".replace(".", "p"), coordinate_shrink(phase_index, alpha))

    for value in [0.0035, 0.0045, 0.0055, 0.0065]:
        evaluate(f"uiso_p0_{value:.4f}".replace(".", "p"), set_uiso(0, value))
    for value in [0.010, 0.012, 0.014, 0.016, 0.018]:
        evaluate(f"uiso_p1_{value:.3f}".replace(".", "p"), set_uiso(1, value))
    for value in [0.006, 0.008, 0.010, 0.012]:
        evaluate(f"uiso_p2_{value:.3f}".replace(".", "p"), set_uiso(2, value))

    evaluate("strain_p0_zero", set_strain(0, "isotropic", (0.0, 0.0)))
    evaluate("strain_p0_uniaxial_free", set_strain(0, "uniaxial", (25.18, 870.65), (1, 0, 0)))
    evaluate("strain_p0_uniaxial_physical", set_strain(0, "uniaxial", (300.0, 870.65), (1, 0, 0)))
    evaluate("strain_p2_zero", set_strain(2, "isotropic", (0.0, 0.0)))


if __name__ == "__main__":
    main()
