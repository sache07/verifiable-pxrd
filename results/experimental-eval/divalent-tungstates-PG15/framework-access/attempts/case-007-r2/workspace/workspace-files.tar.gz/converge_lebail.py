#!/usr/bin/env python3
"""Finish Le Bail intensity iterations and screen uniaxial strain axes."""

from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/lebail_profile.gpx")
CONVERGED = Path(".tmp/lebail_converged.gpx")
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def rwp(project):
    hist = project.histograms()[0]
    _, obs, weights, calc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs ** 2)))


def clean(project):
    hist = project.histograms()[0]
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
    )
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_refinements({"LeBail": True})
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def describe(project, label):
    hist = project.histograms()[0]
    print(
        "LEBAIL "
        + json.dumps(
            {
                "label": label,
                "rwp": rwp(project),
                "instrument": {k: hist.InstrumentParameters[k][1] for k in ["U", "W", "X", "SH/L", "Zero"]},
                "shift": hist.SampleParameters["Shift"][0],
                "profiles": {
                    phase.name: {
                        "size": phase.data["Histograms"][hist.name]["Size"][1],
                        "strain_type": phase.data["Histograms"][hist.name]["Mustrain"][0],
                        "strain": phase.data["Histograms"][hist.name]["Mustrain"][1],
                        "axis": phase.data["Histograms"][hist.name]["Mustrain"][3],
                    }
                    for phase in project.phases()
                },
            }
        ),
        flush=True,
    )


def converge(source, destination, cycles, label):
    project = G2.G2Project(str(source.resolve()))
    project.save(str(destination.resolve()))
    clean(project)
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    describe(project, label)
    return project


def axis_trial(source, phase_index, axis):
    tag = "".join(str(v) for v in axis)
    destination = Path(".tmp") / f"lebail_strain_p{phase_index}_{tag}.gpx"
    project = G2.G2Project(str(source.resolve()))
    project.save(str(destination.resolve()))
    clean(project)
    hist = project.histograms()[0]
    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][hist.name]
    current = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = current
    hap["Mustrain"][1][1] = current
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = list(axis)
    hist_id = hist.data["data"][0]["hId"]
    for suffix in ["Mustrain;i", "Mustrain;a"]:
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist_id}:{suffix}")
        project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:{hist_id}:{suffix}")
    project.set_Controls("cycles", 15)
    project.refine()
    clean(project)
    project.set_Controls("cycles", 12)
    project.refine()
    project.save()
    describe(project, f"strain_p{phase_index}_{tag}")


def main():
    G2.SetPrintLevel("warn")
    converge(SOURCE, CONVERGED, 40, "converged")
    for phase_index in range(3):
        for axis in AXES:
            axis_trial(CONVERGED, phase_index, axis)


if __name__ == "__main__":
    main()
