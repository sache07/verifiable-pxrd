#!/usr/bin/env python3
"""Conservative final nuisance/profile refinement with monotonic checkpoints."""

from __future__ import annotations

from pathlib import Path
import json

import numpy as np
from GSASII import GSASIIscriptable as G2


START = Path(".tmp/intensity_optimized.gpx")
INITIAL = Path(".tmp/final_refine_initial.gpx")
OUTPUT = Path(".tmp/final_refined.gpx")


def rwp(project):
    hist = project.histograms()[0]
    _, obs, weights, calc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    return float(100 * np.sqrt(np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs ** 2)))


def clean(project):
    hist = project.histograms()[0]
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
    )
    hist.clear_refinements(
        {"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]}
    )
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def details(project):
    hist = project.histograms()[0]
    masses = [
        phase.data["General"]["Mass"]
        * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ]
    total_mass = sum(masses)
    fractions = {
        phase.name: float(mass / total_mass)
        for phase, mass in zip(project.phases(), masses)
    }
    return {
        "rwp": rwp(project),
        "fractions": fractions,
        "zero": hist.InstrumentParameters["Zero"][1],
        "shift": hist.SampleParameters["Shift"][0],
        "surface": [hist.SampleParameters["SurfRoughA"][0], hist.SampleParameters["SurfRoughB"][0]],
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "instrument": {k: hist.InstrumentParameters[k][1] for k in ["U", "W", "X", "SH/L"]},
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "size": phase.data["Histograms"][hist.name]["Size"][1][0],
                "strain": phase.data["Histograms"][hist.name]["Mustrain"][1][0],
                "uiso": phase.atoms()[0].uiso,
                "po": phase.data["Histograms"][hist.name]["Pref.Ori."][1:4],
            }
            for phase in project.phases()
        },
    }


def recalculate(project):
    clean(project)
    project.set_Controls("cycles", 0)
    project.refine()
    clean(project)
    project.save()


def stage(source, label, configure, valid=lambda p: True, cycles=7):
    before = G2.G2Project(str(source.resolve()))
    before_value = rwp(before)
    destination = Path(".tmp") / f"final_stage_{label}.gpx"
    project = G2.G2Project(str(source.resolve()))
    project.save(str(destination.resolve()))
    clean(project)
    configure(project)
    project.set_Controls("cycles", cycles)
    project.refine()
    recalculate(project)
    accepted = bool(valid(project) and rwp(project) <= before_value + 1e-7)
    print(
        "STAGE "
        + json.dumps(
            {
                "label": label,
                "accepted": accepted,
                "before_rwp": before_value,
                **details(project),
            }
        ),
        flush=True,
    )
    return destination if accepted else source


def instrument_parameter(name):
    def configure(project):
        hist = project.histograms()[0]
        hist.set_refinements({"Instrument Parameters": [name]})
        hist_id = hist.data["data"][0]["hId"]
        bounds = {
            "Polariz.": (0.5, 1.0),
            "U": (0.0, 40.0),
            "W": (2.0, 40.0),
            "X": (0.1, 6.0),
            "Zero": (-0.25, 0.25),
        }
        if name in bounds:
            project.set_Controls("parmMin", bounds[name][0], variable=f":{hist_id}:{name}")
            project.set_Controls("parmMax", bounds[name][1], variable=f":{hist_id}:{name}")

    return configure


def sample_parameter(name):
    def configure(project):
        hist = project.histograms()[0]
        hist.set_refinements({"Sample Parameters": [name]})
        hist_id = hist.data["data"][0]["hId"]
        bounds = {"SurfRoughA": (0.05, 0.6), "SurfRoughB": (0.02, 0.5)}
        project.set_Controls("parmMin", bounds[name][0], variable=f":{hist_id}:{name}")
        project.set_Controls("parmMax", bounds[name][1], variable=f":{hist_id}:{name}")

    return configure


def phase_profile(phase_index, kind):
    def configure(project):
        hist = project.histograms()[0]
        phase = project.phases()[phase_index]
        phase.set_HAP_refinements({kind: {"type": "isotropic", "refine": True}})
        hist_id = hist.data["data"][0]["hId"]
        suffix = "Size;i" if kind == "Size" else "Mustrain;i"
        lo, hi = (0.04, 1.5) if kind == "Size" else (0.0, 8000.0)
        project.set_Controls("parmMin", lo, variable=f"{phase.id}:{hist_id}:{suffix}")
        project.set_Controls("parmMax", hi, variable=f"{phase.id}:{hist_id}:{suffix}")

    return configure


def phase_cell(phase_index):
    return lambda project: project.phases()[phase_index].set_refinements({"Cell": True})


def phase_po(phase_index):
    def configure(project):
        hist = project.histograms()[0]
        phase = project.phases()[phase_index]
        phase.data["Histograms"][hist.name]["Pref.Ori."][2] = True
        hist_id = hist.data["data"][0]["hId"]
        project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:{hist_id}:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:{hist_id}:MD")

    return configure


def surface_valid(project):
    hist = project.histograms()[0]
    a = hist.SampleParameters["SurfRoughA"][0]
    b = hist.SampleParameters["SurfRoughB"][0]
    return 0.05 <= a <= 0.6 and 0.02 <= b <= 0.5


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(START.resolve()))
    project.save(str(INITIAL.resolve()))
    clean(project)
    # The MgO Uiso scan was essentially flat while its scale moved by >1 wt%.
    # Use the prior-centred value rather than the numerical minimum at 0.014.
    for atom in project.phases()[2].atoms():
        atom.uiso = 0.008
    project.set_Controls("cycles", 8)
    project.refine()
    recalculate(project)
    print("INITIAL " + json.dumps(details(project)), flush=True)
    current = INITIAL

    # Intensity-envelope terms, one at a time because A/B/polarization are correlated.
    for label, configure, check in [
        ("surface_B_1", sample_parameter("SurfRoughB"), surface_valid),
        ("surface_A_1", sample_parameter("SurfRoughA"), surface_valid),
        ("surface_B_2", sample_parameter("SurfRoughB"), surface_valid),
        ("polarization_1", instrument_parameter("Polariz."), lambda p: 0.5 <= p.histograms()[0].InstrumentParameters["Polariz."][1] <= 1.0),
    ]:
        current = stage(current, label, configure, check)

    # Peak-width terms initialized from the Le Bail profile.
    for phase_index in range(3):
        current = stage(current, f"size_p{phase_index}", phase_profile(phase_index, "Size"))
        current = stage(current, f"strain_p{phase_index}", phase_profile(phase_index, "Mustrain"))
    for key in ["W", "X", "U"]:
        current = stage(current, f"instrument_{key}", instrument_parameter(key))

    # Small position updates after width stabilization.
    for phase_index in range(3):
        current = stage(current, f"cell_p{phase_index}", phase_cell(phase_index), cycles=8)
    current = stage(current, "zero", instrument_parameter("Zero"), cycles=8)

    # Revisit the two supported texture parameters and intensity envelope.
    for phase_index in [0, 1]:
        current = stage(current, f"po_p{phase_index}", phase_po(phase_index), cycles=7)
    for label, configure, check in [
        ("surface_A_2", sample_parameter("SurfRoughA"), surface_valid),
        ("surface_B_3", sample_parameter("SurfRoughB"), surface_valid),
        ("polarization_2", instrument_parameter("Polariz."), lambda p: 0.5 <= p.histograms()[0].InstrumentParameters["Polariz."][1] <= 1.0),
    ]:
        current = stage(current, label, configure, check)

    final = G2.G2Project(str(current.resolve()))
    clean(final)
    final.save(str(OUTPUT.resolve()))
    recalculate(final)
    print("FINAL " + json.dumps(details(final)), flush=True)


if __name__ == "__main__":
    main()
