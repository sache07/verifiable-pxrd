#!/usr/bin/env python3
"""Build and stage a GSAS-II Rietveld refinement for the MgO/WO3 case.

This is an exploratory driver.  It intentionally keeps all model choices in
plain Python so that trial projects can be compared before final export.
Run with the GSAS-II Python interpreter.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, minimum_filter1d

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_instrument(path: Path) -> None:
    path.write_text(
        "# Synthetic laboratory instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.70;Azimuth:0.0\n"
        "U:15.0;V:0.0;W:15.0;X:1.5;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def initial_background(x: np.ndarray, y: np.ndarray, ncoef: int) -> list[float]:
    """Estimate smooth lower envelope and convert to GSAS Chebyshev coefficients."""
    # Wide minimum + Gaussian filters remove the narrow diffraction peaks.
    env = gaussian_filter1d(minimum_filter1d(y, size=121, mode="nearest"), 80)
    # Correct most of the downward Poisson bias from a local minimum.
    env = env + 1.5 * np.sqrt(np.maximum(env, 1.0))
    t = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    return np.polynomial.chebyshev.chebfit(t, env, ncoef - 1).tolist()


def summarize(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    data = hist.data["data"][1]
    x, y, w, yc, yb = (np.asarray(data[i], float) for i in range(5))
    mask = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    resid = y - yc
    rwp = 100.0 * np.sqrt(np.sum(w[mask] * resid[mask] ** 2) / np.sum(w[mask] * y[mask] ** 2))
    result = {
        "label": label,
        "rwp_recomputed": float(rwp),
        "residuals": hist.residuals,
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items() if isinstance(v, list) and len(v) > 1},
        "sample": {k: (v[0] if isinstance(v, list) else v) for k, v in hist.SampleParameters.items()},
        "background_minmax": [float(np.min(yb)), float(np.max(yb))],
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "hap": {},
    }
    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        result["hap"][p.name] = {
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    try:
        result["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    print("STAGE", json.dumps(result, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x)))
    return result


def refine(project: G2.G2Project, label: str, cycles: int = 8) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    return summarize(project, label)


def set_bounds(project: G2.G2Project) -> None:
    bounds = {
        ":0:Zero": (-0.30, 0.30),
        ":0:Shift": (-900.0, 900.0),
        ":0:U": (0.0, 45.0),
        ":0:W": (0.5, 45.0),
        ":0:X": (0.02, 8.0),
        ":0:SH/L": (0.002, 0.15),
        ":0:Polariz.": (0.45, 1.0),
        ":0:SurfRoughA": (0.0, 0.8),
        ":0:SurfRoughB": (0.0, 0.8),
        "*:*:Size;i": (0.02, 3.0),
        "*:*:Mustrain;i": (0.0, 12000.0),
        "*:*:Scale": (1e-10, 1e5),
        "*::AUiso:*": (0.001, 0.03),
    }
    for var, (lo, hi) in bounds.items():
        project.set_Controls("parmMin", lo, variable=var)
        project.set_Controls("parmMax", hi, variable=var)


def build(args: argparse.Namespace) -> None:
    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    inst = out.with_suffix(".instprm")
    write_instrument(inst)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(str(ROOT / "inputs" / "pattern.csv"), str(inst), phases=[])
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [-550.0, False]

    phase_specs = [
        ("MgWO4_wolframite", "9013902"),
        ("WO3_monoclinic", args.wo3),
        ("MgO_periclase", "9000499"),
    ]
    phases = []
    for name, cid in phase_specs:
        phases.append(project.add_phase(str(cod_path(cid)), phasename=name, histograms=[hist], fmthint="CIF"))

    # Put every phase on a common sensible starting ADP. The generator also
    # uses one isotropic displacement value per phase.
    for phase in phases:
        for atom in phase.atoms():
            atom.uiso = 0.008

    x = np.asarray(hist.data["data"][1][0], float)
    y = np.asarray(hist.data["data"][1][1], float)
    coeff = initial_background(x, y, args.background_coeffs)
    hist.set_refinements({
        "Limits": [float(x[0]), float(x[-1])],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": len(coeff),
            "coeffs": coeff,
            "refine": True,
        },
    })

    # Rough phase-scale estimates keep the first normal matrix well behaved.
    for phase, scale in zip(phases, [2.0, 1.0, 1.0]):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0

    project.save()
    set_bounds(project)
    summarize(project, "initial")

    # 1. Scales/background with a close manual displacement estimate.
    refine(project, "scale_background", 10)

    # 2. Refine phase cells and specimen displacement to align all peaks.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "cells_shift", 12)

    # 3. Add the common angular zero.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "cells_shift_zero", 12)

    # 4. Common instrument width plus phase-specific size/strain.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 0.30, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    refine(project, "profile_isotropic", 16)

    # 5. Refine the heavy-atom coordinates first.
    for phase in phases[:2]:
        heavy = {a.label: "X" for a in phase.atoms() if a.element != "O"}
        phase.set_refinements({"Atoms": heavy})
    refine(project, "heavy_coordinates", 12)

    # 6. Then all coordinates. MgO remains fixed by symmetry.
    for phase in phases[:2]:
        phase.set_refinements({"Atoms": {"all": "X"}})
    refine(project, "all_coordinates", 16)

    # 7. One common Uiso per phase, implemented with exact equivalences.
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = atom.refinement_flags.replace("U", "") + "U"
        if len(phase.atoms()) > 1:
            vars_ = [f"{phase.id}::AUiso:{i}" for i in range(len(phase.atoms()))]
            project.add_EquivConstr(vars_, reloadIdx=True)
    refine(project, "uiso", 14)

    # 8. Polarization is a session-level instrument parameter.
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "polarization", 12)

    project.save(str(out))
    summarize(project, "final_trial")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--out", default=".tmp/trial_1528915.gpx")
    parser.add_argument("--background-coeffs", type=int, default=12)
    build(parser.parse_args())


if __name__ == "__main__":
    main()
