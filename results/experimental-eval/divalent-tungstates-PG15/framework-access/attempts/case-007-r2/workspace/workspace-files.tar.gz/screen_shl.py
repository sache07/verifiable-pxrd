#!/usr/bin/env python3
"""Profile all phase size/strain terms at fixed axial-divergence values."""
from pathlib import Path
import json, numpy as np
from GSASII import GSASIIscriptable as G2
BASE=Path('.tmp/positioned_1528915.gpx');VALUES=(.005,.01,.02,.04,.08)
def rwp(p):
 h=p.histograms()[0];x,y,w,yc=[np.asarray(v,float) for v in h.data['data'][1][:4]]
 return float(100*np.sqrt(np.sum(w*(y-yc)**2)/np.sum(w*y*y)))
def trial(v):
 tag=str(v).replace('.','p');p=G2.G2Project(str(BASE.resolve()));p.save(str(Path('.tmp')/f'shl_{tag}.gpx'));h=p.histograms()[0]
 h.clear_refinements({'Instrument Parameters':['Zero','U','W','X','SH/L','Polariz.']});h.InstrumentParameters['SH/L'][1]=v
 h.clear_refinements({'Sample Parameters':['Shift','SurfRoughA','SurfRoughB']})
 for q in p.phases():
  q.clear_refinements({'Cell':True,'Atoms':[a.label for a in q.atoms()]});q.clear_HAP_refinements({'Pref.Ori.':True})
  q.set_HAP_refinements({'Size':{'type':'isotropic','refine':True},'Mustrain':{'type':'isotropic','refine':True}})
 p.data['Controls']['data']['parmFrozen']={'FrozenList':[]};p.set_Controls('cycles',14);p.refine();p.save()
 out={'shl':v,'rwp':rwp(p),'profiles':{q.name:[q.data['Histograms'][h.name]['Size'][1][0],q.data['Histograms'][h.name]['Mustrain'][1][0]] for q in p.phases()},'frozen':[str(z) for z in p.get_Controls('parmFrozen')]}
 print('SHL',json.dumps(out),flush=True);return out
if __name__=='__main__':
 G2.SetPrintLevel('warn');print('BASE',rwp(G2.G2Project(str(BASE.resolve()))),flush=True);a=[trial(v) for v in VALUES];print('BEST',json.dumps(min(a,key=lambda z:z['rwp'])),flush=True)
