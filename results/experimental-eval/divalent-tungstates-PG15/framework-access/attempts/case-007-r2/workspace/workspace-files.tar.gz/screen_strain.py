#!/usr/bin/env python3
"""Screen the generator's permitted uniaxial microstrain axes."""

from pathlib import Path
import argparse, json
import numpy as np
from GSASII import GSASIIscriptable as G2

BASE=Path('.tmp/positioned_1528915.gpx')
AXES=([0,0,1],[1,0,0],[0,1,0])

def rwp(p):
    h=p.histograms()[0];x,y,w,yc=[np.asarray(v,float) for v in h.data['data'][1][:4]]
    return float(100*np.sqrt(np.sum(w*(y-yc)**2)/np.sum(w*y*y)))

def clean(p):
    h=p.histograms()[0]
    h.clear_refinements({'Instrument Parameters':['Zero','U','W','X','SH/L','Polariz.']})
    h.clear_refinements({'Sample Parameters':['Shift','SurfRoughA','SurfRoughB']})
    for q in p.phases():
        q.clear_refinements({'Cell':True,'Atoms':[a.label for a in q.atoms()]})
        q.clear_HAP_refinements({'Size':True,'Mustrain':True,'Pref.Ori.':True})
    p.data['Controls']['data']['parmFrozen']={'FrozenList':[]}

def trial(pidx,axis):
    tag=f'p{pidx}_'+''.join(map(str,axis))
    p=G2.G2Project(str(BASE.resolve()));p.save(str(Path('.tmp')/f'strain_{tag}.gpx'));clean(p)
    h=p.histograms()[0];q=p.phases()[pidx];hap=q.data['Histograms'][h.name]
    old=max(300.,float(hap['Mustrain'][1][0]))
    hap['Mustrain'][0]='uniaxial';hap['Mustrain'][1][0]=old;hap['Mustrain'][1][1]=old
    hap['Mustrain'][3]=list(axis);hap['Mustrain'][2]=[True,True,False]
    hid=h.data['data'][0]['hId']
    for name in ['Mustrain;i','Mustrain;a']:
        p.set_Controls('parmMin',0.0,variable=f'{q.id}:{hid}:{name}')
        p.set_Controls('parmMax',8000.0,variable=f'{q.id}:{hid}:{name}')
    p.set_Controls('cycles',10);p.refine();p.save()
    out={'phase':q.name,'phase_index':pidx,'axis':list(axis),'equatorial':hap['Mustrain'][1][0],
         'axial':hap['Mustrain'][1][1],'rwp':rwp(p),'frozen':[str(v) for v in p.get_Controls('parmFrozen')]}
    print('STRAIN',json.dumps(out),flush=True);return out

if __name__=='__main__':
    G2.SetPrintLevel('warn');ap=argparse.ArgumentParser();ap.add_argument('--phase',type=int,default=0);a=ap.parse_args()
    print('BASE',rwp(G2.G2Project(str(BASE.resolve()))),flush=True)
    results=[trial(a.phase,z) for z in AXES]
    print('BEST',json.dumps(min(results,key=lambda z:z['rwp'])),flush=True)
