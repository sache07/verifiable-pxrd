#!/usr/bin/env python3
"""Finish coordinate-descent equilibration of correlated final nuisances."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2

import final_refine as F


SOURCE = Path(".tmp/constrained_final.gpx")
FINAL = Path(".tmp/polished_final.gpx")


def main():
    G2.SetPrintLevel("warn")
    current = SOURCE
    for pass_index in range(2):
        current = F.stage(
            current,
            f"polish{pass_index}_surface_A",
            F.sample_parameter("SurfRoughA"),
            F.surface_valid,
        )
        current = F.stage(
            current,
            f"polish{pass_index}_surface_B",
            F.sample_parameter("SurfRoughB"),
            F.surface_valid,
        )
        current = F.stage(
            current,
            f"polish{pass_index}_polarization",
            F.instrument_parameter("Polariz."),
            lambda p: 0.5 <= p.histograms()[0].InstrumentParameters["Polariz."][1] <= 1.0,
        )
        for phase_index in [0, 1]:
            current = F.stage(current, f"polish{pass_index}_po_p{phase_index}", F.phase_po(phase_index))
    # Width terms can shift slightly when the envelope settles.
    current = F.stage(current, "polish_size_p0", F.phase_profile(0, "Size"))
    current = F.stage(current, "polish_size_p1", F.phase_profile(1, "Size"))
    current = F.stage(current, "polish_strain_p1", F.phase_profile(1, "Mustrain"))
    current = F.stage(current, "polish_W", F.instrument_parameter("W"))

    final = G2.G2Project(str(current.resolve()))
    F.clean(final)
    final.save(str(FINAL.resolve()))
    F.recalculate(final)
    print("POLISHED " + json.dumps(F.details(final)), flush=True)


if __name__ == "__main__":
    main()
