#!/usr/bin/env python3
"""Continue from the stable cell/scale checkpoint with conservative stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def summary(project: G2.G2Project, label: str) -> None:
    hist = project.histograms()[0]
    x, y, w, yc, yb = [np.asarray(v, float) for v in hist.data["data"][1][:5]]
    rwp = 100 * np.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2))
    print(
        "STEP",
        json.dumps(
            {
                "label": label,
                "rwp": float(rwp),
                "inst": {k: v[1] for k, v in hist.InstrumentParameters.items() if k in ["Zero", "U", "W", "X", "SH/L", "Polariz."]},
                "sample": {k: hist.SampleParameters[k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
                "background": [float(yb.min()), float(yb.max())],
                "phases": {
                    p.name: {
                        "cell": p.get_cell(),
                        "scale": p.data["Histograms"][hist.name]["Scale"][0],
                        "size": p.data["Histograms"][hist.name]["Size"][1][0],
                        "strain": p.data["Histograms"][hist.name]["Mustrain"][1][0],
                    }
                    for p in project.phases()
                },
                "fractions": hist.ComputeMassFracs(),
                "frozen": [str(v) for v in project.get_Controls("parmFrozen")],
            }
        ),
        flush=True,
    )


def clear_frozen(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def run(project: G2.G2Project, label: str, cycles: int = 6) -> None:
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    summary(project, label)


def set_exact_bounds(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    h = hist.data["data"][0]["hId"]
    bounds = {
        f":{h}:Zero": (-0.25, 0.25),
        f":{h}:Shift": (-800.0, 800.0),
        f":{h}:U": (0.0, 40.0),
        f":{h}:W": (2.0, 40.0),
        f":{h}:X": (0.1, 6.0),
        f":{h}:SH/L": (0.005, 0.10),
        f":{h}:Polariz.": (0.50, 1.0),
    }
    for phase in project.phases():
        bounds[f"{phase.id}:{h}:Size;i"] = (0.04, 1.5)
        bounds[f"{phase.id}:{h}:Mustrain;i"] = (0.0, 8000.0)
        bounds[f"{phase.id}:{h}:Scale"] = (1e-8, 1e4)
        for i in range(len(phase.atoms())):
            bounds[f"{phase.id}::AUiso:{i}"] = (0.003, 0.020)
    for var, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=var)
        project.set_Controls("parmMax", high, variable=var)


def configure(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    # Stop the correlated zero/shift/cell drift while profile terms settle.
    hist.InstrumentParameters["Zero"][1:] = [-0.18, False]
    hist.InstrumentParameters["U"][1:] = [10.0, False]
    hist.InstrumentParameters["W"][1:] = [6.0, False]
    hist.InstrumentParameters["X"][1:] = [1.0, False]
    hist.InstrumentParameters["SH/L"][1:] = [0.025, False]
    hist.InstrumentParameters["Polariz."][2] = False
    hist.SampleParameters["Shift"] = [-800.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.20
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2] = [False, False, False]
        for atom in phase.atoms():
            atom.refinement_flags = ""


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default=".tmp/trial_1528915.bak0.gpx")
    ap.add_argument("--out", default=".tmp/improved_1528915.gpx")
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(Path(args.input).resolve()))
    project.save(str(Path(args.out).resolve()))
    configure(project)
    set_exact_bounds(project)
    project.save()
    summary(project, "configured")

    # Re-establish scale/background after the conservative profile reset.
    run(project, "baseline", 6)

    phases = project.phases()
    hist = project.histograms()[0]

    # Size-only passes avoid the size/strain singularity seen in a full launch.
    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        run(project, f"size_{phase.name}", 6)
        phase.clear_HAP_refinements({"Size": True})

    # Then fit strain one phase at a time.
    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        run(project, f"strain_{phase.name}", 6)
        phase.clear_HAP_refinements({"Mustrain": True})

    # Fit the common instrumental terms sequentially, alternating with profile.
    for key in ["W", "X", "U", "SH/L"]:
        hist.set_refinements({"Instrument Parameters": [key]})
        run(project, f"instrument_{key}", 6)
        hist.clear_refinements({"Instrument Parameters": [key]})

    # A second coordinate-descent pass after the common width is established.
    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        run(project, f"size2_{phase.name}", 5)
        phase.clear_HAP_refinements({"Size": True})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        run(project, f"strain2_{phase.name}", 5)
        phase.clear_HAP_refinements({"Mustrain": True})

    # Keep refined profile values fixed while recovering atom positions.
    for phase in phases[:2]:
        heavy = {a.label: "X" for a in phase.atoms() if a.element != "O"}
        phase.set_refinements({"Atoms": heavy})
        run(project, f"heavy_{phase.name}", 8)
        phase.clear_refinements({"Atoms": list(heavy)})

    for phase in phases[:2]:
        oxygen = {a.label: "X" for a in phase.atoms() if a.element == "O"}
        phase.set_refinements({"Atoms": oxygen})
        run(project, f"oxygen_{phase.name}", 10)
        phase.clear_refinements({"Atoms": list(oxygen)})

    project.save()
    summary(project, "improved_final")


if __name__ == "__main__":
    main()
