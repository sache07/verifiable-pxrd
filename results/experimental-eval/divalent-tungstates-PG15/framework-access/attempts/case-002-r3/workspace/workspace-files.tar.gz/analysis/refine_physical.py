#!/usr/bin/env python3
"""Physically bounded GSAS-II refinements used for phase-model screening."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def setup_files(work: Path) -> tuple[Path, Path]:
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    xye = work / "pattern.xye"
    np.savetxt(xye, np.c_[x, y, np.sqrt(np.maximum(y, 1.0))], fmt="%.8f %.8f %.8f")
    inst = work / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; do not add/delete items!\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:15.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def initial_background(x: np.ndarray, y: np.ndarray, n: int = 16) -> list[float]:
    floor = percentile_filter(y, 10, size=301, mode="nearest")
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, floor, n - 1).tolist()


def set_limit(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    masses = []
    phases = {}
    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        masses.append(p.data["General"]["Mass"] * hap["Scale"][0])
        phases[p.name] = {
            "cell": p.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"][1][:3],
            "mustrain": hap["Mustrain"][1][:3],
            "mustrain_type": hap["Mustrain"][0],
            "po": hap["Pref.Ori."][:4],
        }
    fractions = (np.asarray(masses) / np.sum(masses)).tolist()
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "fractions": fractions,
        "instrument": {k: inst[k][1] for k in ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]},
        "sample": {k: sample[k][0] if isinstance(sample[k], list) else sample[k] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "phases": phases,
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(row, default=float), flush=True)
    return row


def run_refinement(project: G2.G2Project, label: str, log: list[dict]) -> None:
    project.refine(makeBack=False)
    log.append(snapshot(project, label))


def build(wo3_id: str, bao2_id: str, tag: str, refine_coordinates: bool) -> Path:
    work = ROOT / "analysis" / f"physical_{tag}"
    work.mkdir(parents=True, exist_ok=True)
    xye, inst_file = setup_files(work)
    gpx = work / "model.gpx"
    gpx.unlink(missing_ok=True)
    project = G2.G2Project(newgpx=str(gpx))
    project.add_phase(str(cod_path(wo3_id)), phasename=f"WO3_{wo3_id}", fmthint="CIF")
    project.add_phase(str(cod_path(bao2_id)), phasename=f"BaO2_{bao2_id}", fmthint="CIF")
    hist = project.add_powder_histogram(str(xye), str(inst_file), phases="all", fmthint="xye")
    hist.data["Sample Parameters"].update({"Type": "Bragg-Brentano", "Gonio. radius": 200.0, "Scale": [1.0, False]})
    x, y = map(np.asarray, hist.data["data"][1][:2])
    coeffs = initial_background(x, y)
    hist.set_refinements({
        "Limits": [float(x[0]), float(x[-1])],
        "Background": {"type": "chebyschev-1", "no. coeffs": len(coeffs), "coeffs": coeffs, "refine": True},
    })
    for p in project.phases():
        hap = p.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / p.data["General"]["Mass"], True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
    project.set_Controls("cycles", 6)
    project.index_ids()
    # Generator-supported physical ranges. Bounds also prevent negative widths.
    for name, bounds in {
        ":0:Zero": (-0.25, 0.25), ":0:U": (0.0, 40.0), ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0), ":0:SH/L": (0.005, 0.1), ":0:Polariz.": (0.5, 1.0),
        ":0:Shift": (-800.0, 800.0),
    }.items():
        set_limit(project, name, *bounds)
    for p in project.phases():
        pid = p.id
        set_limit(project, f"{pid}:0:Scale", 0.0, 1000.0)
        set_limit(project, f"{pid}:0:Size;i", 0.04, 1.5)
        set_limit(project, f"{pid}:0:Mustrain;i", 0.0, 10000.0)
        set_limit(project, f"{pid}:0:Mustrain;a", 0.0, 40000.0)
    project.save()
    log: list[dict] = []

    run_refinement(project, "background_scales", log)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for p in project.phases():
        p.set_refinements({"Cell": True})
    run_refinement(project, "zero_cells", log)

    for p in project.phases():
        p.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.3, "refine": True}})
    run_refinement(project, "sizes", log)

    # WO3 clearly needs strain broadening; allow BaO2 strain only after size settles.
    project.phases()[0].set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    run_refinement(project, "wo3_strain", log)
    project.phases()[1].set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    run_refinement(project, "all_strain", log)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    run_refinement(project, "instrument_uwx", log)
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    run_refinement(project, "axial_asymmetry", log)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(project, "specimen_shift", log)

    if refine_coordinates:
        for p in project.phases():
            p.set_refinements({"Atoms": {"all": "X"}})
        run_refinement(project, "coordinates", log)

    project.save()
    (work / "stages.json").write_text(json.dumps(log, indent=2, default=float) + "\n")
    return gpx


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="2311041")
    parser.add_argument("--bao2", default="1010113")
    parser.add_argument("--tag", default="default")
    parser.add_argument("--coordinates", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    print(build(args.wo3, args.bao2, args.tag, args.coordinates))
