#!/usr/bin/env python3
"""Create the submission project and CIF exports from the accepted refinement."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "calibrated" / "final_model.gpx"
FINAL = ROOT / "final.gpx"


def main() -> None:
    FINAL.unlink(missing_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    project.save()

    histogram = project.histograms()[0]
    outputs = {
        "WO3_2106293": ROOT / "phase_WO3.cif",
        "BaO2_1010113": ROOT / "phase_BaO2.cif",
    }
    masses = []
    phases = []
    for phase in project.phases():
        output = outputs[phase.name]
        output.unlink(missing_ok=True)
        phase.export_CIF(str(output))
        hap = phase.data["Histograms"][histogram.name]
        scaled_mass = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(scaled_mass)
        phases.append(
            {
                "name": phase.name,
                "cif_path": output.name,
                "scale": float(hap["Scale"][0]),
                "cell_mass": float(phase.data["General"]["Mass"]),
                "cell": {key: float(value) for key, value in phase.get_cell().items()},
            }
        )
    total = sum(masses)
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / total

    residuals = histogram.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    state = {
        "project": FINAL.name,
        "project_sha256": hashlib.sha256(FINAL.read_bytes()).hexdigest(),
        "histogram": histogram.name,
        "phases": phases,
        "fit_statistics": {
            "rwp_percent": float(residuals["wR"]),
            "rp_percent": float(residuals["R"]),
            "expected_rwp_min_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "weighted_chi_square": float(rvals["chisq"]),
            "n_points": int(rvals["Nobs"]),
            "n_refined_parameters_last_cycle": int(rvals["Nvars"]),
        },
    }
    (ROOT / "analysis" / "final_state.json").write_text(
        json.dumps(state, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(state, indent=2, allow_nan=False))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
