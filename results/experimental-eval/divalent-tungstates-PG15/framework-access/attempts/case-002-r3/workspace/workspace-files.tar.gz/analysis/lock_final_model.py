#!/usr/bin/env python3
"""Lock nonlinear parameters and finish with phase scales/background only."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]


def main():
    source = ROOT / "analysis" / "calibrated" / "converged.gpx"
    destination = ROOT / "analysis" / "calibrated" / "final_model.gpx"
    destination.unlink(missing_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
    project.set_Frozen()
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Sample Parameters"]["Scale"][1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.set_Controls("cycles", 12)
    project.save()
    project.refine(makeBack=False)
    project.save()
    print("Rwp", hist.get_wR(), "frozen", project.get_Frozen())


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
