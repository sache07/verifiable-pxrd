#!/usr/bin/env python3
"""Build a forward-only candidate on the bounded calibration branch."""

from pathlib import Path

from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
CELLS = {
    "WO3_2106293": [
        7.310220936445171,
        7.526330858808641,
        7.6838112967004895,
        89.21862147166665,
        90.7707621511114,
        90.5304171771633,
    ],
    "BaO2_1010113": [3.7989, 3.7989, 6.80385, 90.0, 90.0, 90.0],
}


def main():
    destination = ROOT / "analysis" / "calibrated" / "physical_forward.gpx"
    destination.unlink(missing_ok=True)
    project = G2.G2Project(gpxfile=str(ROOT / "final.gpx"), newgpx=str(destination))
    hist = project.histograms()[0]
    hist.data["Instrument Parameters"][0]["Zero"] = [0.0, -0.24759041846857596, False]
    hist.data["Sample Parameters"]["Shift"] = [-800.0, False]
    for phase in project.phases():
        cell = CELLS[phase.name]
        phase.data["General"]["Cell"][0] = False
        phase.data["General"]["Cell"][1:7] = cell
        phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))
    project.save()
    print(destination)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
