#!/usr/bin/env python3
"""Converge cells and specimen shift after fixing the correlated zero at its bound."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]


def main():
    source = ROOT / "analysis" / "calibrated" / "branch_bounded4.gpx"
    destination = ROOT / "analysis" / "calibrated" / "converged.gpx"
    destination.unlink(missing_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
    project.set_Frozen()
    hist = project.histograms()[0]
    hist.data["Instrument Parameters"][0]["Zero"] = [0.0, 0.25, False]
    hist.data["Sample Parameters"]["Shift"][1] = True
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    project.set_Controls("cycles", 30)
    project.save()
    project.refine(makeBack=False)
    project.save()
    print("Rwp", hist.get_wR(), "frozen", project.get_Frozen())
    print("zero", hist.data["Instrument Parameters"][0]["Zero"])
    print("shift", hist.data["Sample Parameters"]["Shift"])
    for phase in project.phases():
        print(phase.name, phase.get_cell())


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
