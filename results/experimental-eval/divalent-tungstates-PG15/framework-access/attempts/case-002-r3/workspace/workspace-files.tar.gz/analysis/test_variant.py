#!/usr/bin/env python3
"""Test one GSAS-II specimen/profile variant from a common project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


AXES = {"001": [0, 0, 1], "100": [1, 0, 0], "010": [0, 1, 0],
        "110": [1, 1, 0], "111": [1, 1, 1]}


def clear(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Sample Parameters"]["Scale"][1] = False
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def result(project: G2.G2Project, effect: str, phase_index: int | None, axis: str | None) -> dict:
    hist = project.histograms()[0]
    masses, phases = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(phase.data["General"]["Mass"] * hap["Scale"][0])
        phases.append({"name": phase.name, "size": hap["Size"][1][:3], "size_type": hap["Size"][0],
                       "strain": hap["Mustrain"][1][:3], "strain_type": hap["Mustrain"][0],
                       "strain_axis": hap["Mustrain"][3], "po": hap["Pref.Ori."][:4]})
    row = {"effect": effect, "phase": phase_index, "axis": axis, "rwp": hist.get_wR(),
           "fractions": (np.asarray(masses) / sum(masses)).tolist(), "phases": phases,
           "instrument": {k: hist.data["Instrument Parameters"][0][k][1] for k in ["Zero", "U", "W", "X", "SH/L", "Polariz."]},
           "sample": {k: hist.data["Sample Parameters"][k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
           "frozen": project.get_Frozen()}
    print(json.dumps(row, default=float), flush=True)
    return row


def run(source: Path, destination: Path, effect: str, phase_index: int | None, axis_name: str | None,
        value: float | None = None) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.unlink(missing_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
    project.set_Frozen()
    clear(project)
    hist = project.histograms()[0]
    axis = AXES.get(axis_name) if axis_name else None
    if effect == "strain":
        phase = project.phase(phase_index)
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
        hap["Mustrain"][2][0] = hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = axis
    elif effect == "po":
        phase = project.phase(phase_index)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")
    elif effect == "shift":
        hist.data["Sample Parameters"]["Shift"][1] = True
        project.set_Controls("parmMin", -800.0, variable=":0:Shift")
        project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    elif effect == "polarization":
        hist.data["Instrument Parameters"][0]["Polariz."][2] = True
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif effect == "roughness":
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.3, True]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.1, True]
        project.set_Controls("parmMin", 0.001, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.6, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.001, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")
    elif effect == "uiso":
        phase = project.phase(phase_index)
        variables = []
        for i, atom in enumerate(phase.atoms()):
            atom.uiso = 0.005
            atom.refinement_flags = "U"
            variables.append(f"{phase.id}::AUiso:{i}")
        project.set_Controls("parmMin", 0.003, variable=f"{phase.id}::AUiso:*")
        project.set_Controls("parmMax", 0.020, variable=f"{phase.id}::AUiso:*")
        if len(variables) > 1:
            project.add_EquivConstr(variables, override=True)
    elif effect == "uiso_fixed":
        phase = project.phase(phase_index)
        for atom in phase.atoms():
            atom.uiso = float(value)
            atom.refinement_flags = " "
    else:
        raise ValueError(effect)
    project.set_Controls("cycles", 15)
    project.save()
    project.refine(makeBack=False)
    project.save()
    row = result(project, effect, phase_index, axis_name)
    destination.with_suffix(".json").write_text(json.dumps(row, indent=2, default=float) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--effect", choices=["strain", "po", "shift", "polarization", "roughness", "uiso", "uiso_fixed"], required=True)
    parser.add_argument("--phase", type=int)
    parser.add_argument("--axis", choices=sorted(AXES))
    parser.add_argument("--value", type=float)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run(args.source, args.destination, args.effect, args.phase, args.axis, args.value)
