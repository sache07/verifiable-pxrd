#!/usr/bin/env python3
"""Explore physically bounded cells with zero and specimen displacement."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "source_atoms" / "model.gpx"
SOURCE_CELLS = {
    "WO3_2106293": [7.309, 7.522, 7.678, 88.81, 90.92, 90.93],
    "BaO2_1010113": [3.78, 3.78, 6.77, 90.0, 90.0, 90.0],
}


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Sample Parameters"]["Scale"][1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "


def set_source_cells(project: G2.G2Project) -> None:
    for phase in project.phases():
        cell = SOURCE_CELLS[phase.name]
        phase.data["General"]["Cell"][1:7] = cell
        phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def set_cell_limits(project: G2.G2Project) -> None:
    # A0..A2 are reciprocal-metric diagonal terms. A 0.5% direct-lattice
    # principal strain changes these by at most about 1.01%.
    for phase in project.phases():
        source_a = G2lat.cell2A(SOURCE_CELLS[phase.name])
        for index, value in enumerate(source_a):
            variable = f"{phase.id}::A{index}"
            if index < 3:
                low, high = value * (1 - 0.0102), value * (1 + 0.0102)
            else:
                # Off-diagonal reciprocal metric under a maximum 0.5% shear.
                low, high = value - 0.00042, value + 0.00042
            project.set_Controls("parmMin", min(low, high), variable=variable)
            project.set_Controls("parmMax", max(low, high), variable=variable)


def run(destination: Path, zero: float, shift: float, cycles: int, rounds: int) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.unlink(missing_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(destination))
    project.set_Frozen()
    clear_flags(project)
    set_source_cells(project)
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"][1] = zero
    inst["Zero"][2] = True
    hist.data["Sample Parameters"]["Shift"] = [shift, True]
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    project.set_Controls("cycles", cycles)
    project.save()

    # First recover the common angular correction with the reference cells.
    project.refine(makeBack=False)
    # Then permit only the documented reference-cell mismatch.
    set_cell_limits(project)
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    for _ in range(rounds):
        project.refine(makeBack=False)
    project.save()
    print(destination.name, "Rwp", hist.get_wR(), "zero", inst["Zero"],
          "shift", hist.data["Sample Parameters"]["Shift"])
    for phase in project.phases():
        print(phase.name, phase.get_cell())


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("destination", type=Path)
    parser.add_argument("--zero", type=float, required=True)
    parser.add_argument("--shift", type=float, required=True)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--rounds", type=int, default=2)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run(args.destination, args.zero, args.shift, args.cycles, args.rounds)
