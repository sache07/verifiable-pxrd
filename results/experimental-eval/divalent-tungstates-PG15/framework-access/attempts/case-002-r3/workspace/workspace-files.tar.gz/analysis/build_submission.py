#!/usr/bin/env python3
"""Write fit.csv, result.json and report.md from the verified final replay."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    state = json.loads((ROOT / "analysis" / "final_state.json").read_text())
    replay = json.loads((ROOT / "analysis" / "replay_check" / "replay.json").read_text())
    if replay["status"] != "replayed":
        raise RuntimeError("Final GSAS-II project did not replay")
    if replay["project_sha256"] != state["project_sha256"]:
        raise RuntimeError("Replay and final-state project hashes differ")
    if replay["profile_review_flags"]:
        raise RuntimeError("Replay profile review flags: " + repr(replay["profile_review_flags"]))

    curve = np.load(ROOT / "analysis" / "replay_check" / "prediction.npz")
    x = curve["x"]
    observed = curve["observed"]
    calculated = curve["predicted"]
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = 100.0 * np.sqrt(chi_square / denominator)
    rp = 100.0 * np.sum(np.abs(difference)) / np.sum(observed)
    rvals = state["fit_statistics"]

    phase_by_name = {row["name"]: row for row in replay["phases"]}
    result = {
        "method": "two-phase GSAS-II Rietveld refinement with atomic structural models",
        "refinement_histogram": replay["histogram"],
        "phases": [
            {
                "name": "triclinic tungsten(VI) oxide",
                "formula": "WO3",
                "space_group": "P -1",
                "reference": "COD 2106293",
                "cif_path": "phase_WO3.cif",
                "weight_fraction": phase_by_name["WO3_2106293"]["weight_fraction"],
            },
            {
                "name": "tetragonal barium peroxide",
                "formula": "BaO2",
                "space_group": "I4/mmm",
                "reference": "COD 1010113",
                "cif_path": "phase_BaO2.cif",
                "weight_fraction": phase_by_name["BaO2_1010113"]["weight_fraction"],
            },
        ],
        "fit_statistics": {
            "rwp_percent": float(rwp),
            "rp_percent": float(rp),
            "expected_rwp_min_percent": rvals["expected_rwp_min_percent"],
            "goodness_of_fit": rvals["goodness_of_fit"],
            "weighted_chi_square": chi_square,
            "n_points": int(len(x)),
        },
        "calibration": {
            "zero_deg": 0.25,
            "specimen_displacement_um": -78.59607353681129,
        },
        "fraction_basis": "normalized over the two modeled crystalline phases; no amorphous fraction determined",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

    report = f"""# Powder XRD phase analysis

## Result

The pattern is modeled by two crystalline phases:

| Phase | Structural model | Refined cell (Å, °) | Crystalline weight fraction |
|---|---|---|---:|
| WO3 | triclinic *P* -1, COD 2106293 | a = 7.31922, b = 7.53647, c = 7.69530; α = 89.5169, β = 90.7169, γ = 90.2694 | {100*result['phases'][0]['weight_fraction']:.2f}% |
| BaO2 | tetragonal *I*4/mmm, COD 1010113 | a = 3.81489, c = 6.85201 | {100*result['phases'][1]['weight_fraction']:.2f}% |

Fractions are normalized over these modeled crystalline phases. The data do not provide an absolute amorphous fraction.

## Evidence and refinement

The split low-angle group at approximately 23.4, 23.9 and 24.7° 2θ, followed by the dense higher-angle pattern, selects the low-symmetry WO3 model. A monoclinic WO3 alternative gave a visibly poorer whole-pattern fit. Independent peaks near 26.3, 27.0, 33.5, 42.9, 46.6 and 55.4° are accounted for by tetragonal BaO2. BaWO4 was rejected because its required strong reflections around 31.9–32.5° are absent. No coherent residual peak set requires a third crystalline phase. In the 200 °C synthesis context, the crystalline material is therefore consistent with largely unreacted precursors rather than detectable crystalline BaWO4 product.

The final GSAS-II atomic-model replay gives Rwp = {rwp:.3f}%, Rp = {rp:.3f}%, and goodness of fit = {rvals['goodness_of_fit']:.3f} (Poisson-limit Rwp = {rvals['expected_rwp_min_percent']:.3f}%). The supplied `fit.csv` was regenerated from `final.gpx`; no stored calculated profile was reused. Cu Kα1/Kα2 wavelengths and their 0.5 intensity ratio were fixed to the metadata. A +0.25° zero term and -78.6 µm specimen displacement were used.

## Remaining uncertainty

Phase identity is substantially more reliable than individual oxygen coordinates. Atomic shifts were restricted to a small neighborhood of the database models (oxygen RMS shift about 0.05 Å for WO3), and isotropic displacement parameters were fixed; the CIFs should therefore be treated as profile-compatible structural models, not independent high-precision coordinate determinations. The BaO2 model contains a 1.368 Å O-O peroxide pair. Its exact length is especially weakly constrained by X-ray data and is short relative to many ambient-pressure peroxides, so that oxygen coordinate should not be interpreted as a precise bond-length measurement.

Zero, specimen displacement and lattice scale are strongly correlated. Consequently, the reported unit-cell parameters have additional systematic uncertainty not represented by least-squares standard errors. Phase fractions were stable across the tested structural/profile variants; a conservative model uncertainty is about ±2 percentage points for each fraction. The residual Rwp above the counting-statistics limit indicates remaining line-shape/background mismatch, but no additional crystalline phase can be assigned reliably from it.
"""
    (ROOT / "report.md").write_text(report)


if __name__ == "__main__":
    main()
