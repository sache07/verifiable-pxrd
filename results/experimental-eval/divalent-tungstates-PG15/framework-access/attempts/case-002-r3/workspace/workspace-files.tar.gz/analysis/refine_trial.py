#!/usr/bin/env python3
"""Build and stage a GSAS-II refinement for the BaO2/WO3 pattern.

This is an exploratory driver. The final export/validation is performed by a
separate script after the phase model and refinement strategy are selected.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inputs(work: Path) -> tuple[Path, Path]:
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    xye = work / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.8f %.8f %.8f")
    inst = work / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; do not add/delete items!\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst


def background_coefficients(x: np.ndarray, y: np.ndarray, n: int = 14) -> list[float]:
    baseline = percentile_filter(y, percentile=12, size=301, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, baseline, n - 1).tolist()


def status(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    result = project.get_LastFitResults() or ()
    cov = project.data.get("Covariance", {}).get("data", {})
    entry = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("GOF"),
        "n_vary": len(cov.get("varyList", [])),
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "scales": {p.name: p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()},
        "last_fit_type": type(result).__name__,
    }
    print(json.dumps(entry, default=float))
    return entry


def refine(project: G2.G2Project, label: str, log: list[dict]) -> None:
    project.refine(makeBack=False)
    log.append(status(project, label))


def build(wo3_id: str, bao2_id: str, tag: str, coordinate_stage: bool) -> Path:
    work = ROOT / "analysis" / f"trial_{tag}"
    work.mkdir(parents=True, exist_ok=True)
    xye, inst = write_inputs(work)
    gpx = work / "trial.gpx"
    if gpx.exists():
        gpx.unlink()
    project = G2.G2Project(newgpx=str(gpx))
    wo3 = project.add_phase(str(cod_path(wo3_id)), phasename=f"WO3_{wo3_id}", fmthint="CIF")
    bao2 = project.add_phase(str(cod_path(bao2_id)), phasename=f"BaO2_{bao2_id}", fmthint="CIF")
    hist = project.add_powder_histogram(str(xye), str(inst), phases="all", fmthint="xye")
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    x, y = hist.data["data"][1][:2]
    coeffs = background_coefficients(np.asarray(x), np.asarray(y), 14)
    hist.set_refinements({
        "Limits": [float(x[0]), float(x[-1])],
        "Background": {"type": "chebyschev-1", "no. coeffs": len(coeffs), "coeffs": coeffs, "refine": True},
    })
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / phase.data["General"]["Mass"], True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][2][0] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = False
    project.set_Controls("cycles", 8)
    project.save()
    log: list[dict] = []

    refine(project, "background_scales", log)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, "zero_cells", log)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "instrument_profile", log)

    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True, "value": 0.3}})
    refine(project, "sizes", log)

    for phase in project.phases():
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, "microstrain", log)

    if coordinate_stage:
        for phase in project.phases():
            phase.set_refinements({"Atoms": {"all": "X"}})
        refine(project, "coordinates", log)

    project.save()
    (work / "stages.json").write_text(json.dumps(log, indent=2, default=float) + "\n")
    return gpx


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="2311041")
    parser.add_argument("--bao2", default="1010113")
    parser.add_argument("--tag", default="default")
    parser.add_argument("--coordinates", action="store_true")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    print(build(args.wo3, args.bao2, args.tag, args.coordinates))
