#!/usr/bin/env python3
"""Fit physical calibration/cell perturbations to refined reflection positions."""

from __future__ import annotations

import numpy as np
from scipy.optimize import least_squares
from GSASII import GSASIIscriptable as G2


SOURCE_CELLS = {
    "WO3_2106293": [7.309, 7.522, 7.678, 88.81, 90.92, 90.93],
    "BaO2_1010113": [3.78, 3.78, 6.77, 90.0, 90.0, 90.0],
}
WAVELENGTH = 1.540598
RADIUS_MM = 200.0


def lattice(cell):
    a, b, c, alpha, beta, gamma = cell
    alpha, beta, gamma = np.deg2rad([alpha, beta, gamma])
    av = np.array([a, 0.0, 0.0])
    bv = np.array([b * np.cos(gamma), b * np.sin(gamma), 0.0])
    cv = np.array(
        [
            c * np.cos(beta),
            c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma),
            0.0,
        ]
    )
    cv[2] = np.sqrt(c * c - cv[0] * cv[0] - cv[1] * cv[1])
    return np.vstack([av, bv, cv])


def cell_from_lattice(matrix):
    lengths = np.linalg.norm(matrix, axis=1)
    angles = []
    for u, v in [(matrix[1], matrix[2]), (matrix[0], matrix[2]), (matrix[0], matrix[1])]:
        angles.append(np.rad2deg(np.arccos(np.dot(u, v) / np.linalg.norm(u) / np.linalg.norm(v))))
    return [*lengths, *angles]


def strained_lattices(parameters):
    w = parameters[2:8]
    ew = np.array([[w[0], w[3], w[4]], [w[3], w[1], w[5]], [w[4], w[5], w[2]]])
    b = parameters[8:10]
    eb = np.diag([b[0], b[0], b[1]])
    return {
        "WO3_2106293": ((np.eye(3) + ew) @ lattice(SOURCE_CELLS["WO3_2106293"]).T).T,
        "BaO2_1010113": ((np.eye(3) + eb) @ lattice(SOURCE_CELLS["BaO2_1010113"]).T).T,
    }, ew, eb


def main():
    project = G2.G2Project(gpxfile="final.gpx")
    hist = project.histograms()[0]
    rows = []
    for name, reflection_data in hist.data["Reflection Lists"].items():
        for reflection in reflection_data["RefList"]:
            hkl = np.asarray(reflection[:3], float)
            position = float(reflection[5])
            intensity = max(float(reflection[9]), 0.0)
            if 10 <= position <= 100 and intensity > 0.05:
                rows.append((name, hkl, position, intensity))
    max_intensity = max(row[3] for row in rows)

    def predict(parameters):
        matrices, _, _ = strained_lattices(parameters)
        reciprocal_metrics = {
            name: np.linalg.inv(matrix @ matrix.T) for name, matrix in matrices.items()
        }
        output = []
        for name, hkl, _, _ in rows:
            metric_recip = reciprocal_metrics[name]
            d = 1.0 / np.sqrt(hkl @ metric_recip @ hkl)
            bragg = 2.0 * np.rad2deg(np.arcsin(WAVELENGTH / (2.0 * d)))
            displacement = -9e-2 / (np.pi * RADIUS_MM) * 4.0 * parameters[1] * np.cos(np.deg2rad(bragg / 2.0))
            output.append(bragg + parameters[0] + displacement)
        return np.asarray(output)

    target = np.asarray([row[2] for row in rows])
    # Fourth-root intensity weighting retains weak high-angle positional
    # information while emphasizing the reflections that determine the fit.
    weights = np.asarray([(row[3] / max_intensity) ** 0.25 for row in rows])

    def residual(parameters):
        return (predict(parameters) - target) * weights

    lower = np.array([-0.25, -800.0] + [-0.005] * 8)
    upper = np.array([0.25, 800.0] + [0.005] * 8)
    starts = [
        np.array([z, s] + [0.0] * 8)
        for z in (-0.2, 0.0, 0.2)
        for s in (-600.0, 0.0, 600.0)
    ]
    results = [least_squares(residual, start, bounds=(lower, upper), max_nfev=5000) for start in starts]
    fit = min(results, key=lambda result: np.sum(result.fun * result.fun))
    matrices, ew, eb = strained_lattices(fit.x)
    raw = predict(fit.x) - target
    print("n_reflections", len(rows), "success", fit.success, fit.message)
    print("parameters", fit.x.tolist())
    print("weighted_rms_deg", float(np.sqrt(np.mean(fit.fun * fit.fun))))
    print("unweighted_rms_deg", float(np.sqrt(np.mean(raw * raw))), "max_abs_deg", float(np.max(np.abs(raw))))
    print("WO3 strain eigenvalues", np.linalg.eigvalsh(ew).tolist())
    print("BaO2 strain eigenvalues", np.linalg.eigvalsh(eb).tolist())
    for name, matrix in matrices.items():
        print(name, cell_from_lattice(matrix))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
