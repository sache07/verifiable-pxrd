#!/usr/bin/env python3
"""Recover a physical profile from a good structural/cell starting model.

The exploratory refinements intentionally allowed broad unconstrained profile
motion to rank structural models. This script resets those nuisance parameters
and introduces them one at a time within the known laboratory ranges.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]


def limit(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def freeze_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key, value in hist.data["Sample Parameters"].items():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    parts, phase_data = [], {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        parts.append(phase.data["General"]["Mass"] * hap["Scale"][0])
        phase_data[phase.name] = {
            "cell": phase.get_cell(), "scale": hap["Scale"][0],
            "size": hap["Size"][1][:3], "size_type": hap["Size"][0],
            "strain": hap["Mustrain"][1][:3], "strain_type": hap["Mustrain"][0],
            "po": hap["Pref.Ori."][:4],
        }
    cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "stage": label, "rwp": hist.get_wR(), "gof": cov.get("GOF"),
        "max_shift_esd": cov.get("Max shft/sig"),
        "fractions": (np.asarray(parts) / sum(parts)).tolist(),
        "instrument": {k: inst[k][1] for k in ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]},
        "sample": {k: sample[k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "phases": phase_data, "frozen": project.get_Frozen(),
    }
    print(json.dumps(result, default=float), flush=True)
    return result


def fit(project: G2.G2Project, label: str, rows: list[dict], cycles: int = 10) -> None:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    rows.append(state(project, label))


def recover(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.unlink(missing_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
    project.index_ids()
    project.set_Frozen()
    freeze_flags(project)
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    for key, val in {"U": 20.0, "W": 20.0, "X": 1.0, "SH/L": 0.03, "Polariz.": 0.7}.items():
        inst[key][0] = inst[key][1] = val
    # Keep the well-determined approximate zero/cells, but reset specimen widths.
    for i, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.10 if i == 0 else 0.08
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 3000.0 if i == 0 else 0.0
    project.index_ids()
    for variable, bounds in {
        ":0:Zero": (-0.5, 0.5), ":0:U": (0.0, 40.0), ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0), ":0:SH/L": (0.005, 0.1), ":0:Polariz.": (0.5, 1.0),
        ":0:Shift": (-800.0, 800.0),
    }.items():
        limit(project, variable, *bounds)
    for p in project.phases():
        limit(project, f"{p.id}:0:Scale", 0.0, 1000.0)
        limit(project, f"{p.id}:0:Size;i", 0.04, 1.5)
        limit(project, f"{p.id}:0:Mustrain;i", 0.0, 10000.0)
        limit(project, f"{p.id}:0:Mustrain;a", 0.0, 40000.0)
    project.save()
    rows: list[dict] = []
    fit(project, "reset_calculation", rows, cycles=0)

    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    fit(project, "background_scales", rows)

    # Refine each broadening contribution separately to limit correlations.
    for i, phase in enumerate(project.phases()):
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        fit(project, f"size_phase_{i}", rows)
        phase.data["Histograms"][hist.name]["Size"][2][0] = False
        project.set_Frozen()
    for i, phase in enumerate(project.phases()):
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        fit(project, f"strain_phase_{i}", rows)
        phase.data["Histograms"][hist.name]["Mustrain"][2][0] = False
        project.set_Frozen()

    for key in ["W", "U", "X", "SH/L"]:
        inst[key][2] = True
        fit(project, f"instrument_{key}", rows)
        inst[key][2] = False
        project.set_Frozen()

    # Revisit positions after peak shape has settled.
    inst["Zero"][2] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    fit(project, "zero_cells", rows)
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
    inst["Zero"][2] = False

    # Atomic coordinates are refined phase by phase.
    for i, phase in enumerate(project.phases()):
        for atom in phase.atoms():
            atom.refinement_flags = "X"
        fit(project, f"coordinates_phase_{i}", rows, cycles=12)
        for atom in phase.atoms():
            atom.refinement_flags = " "

    # Final joint scale/background update with all nonlinear variables fixed.
    fit(project, "final_linear", rows)
    project.save()
    destination.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    recover(args.source, args.destination)
