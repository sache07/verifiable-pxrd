#!/usr/bin/env python3
"""Coordinate-descent cleanup of the physically bounded GSAS-II profile."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def clear_nonlinear(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    for val in hist.data["Instrument Parameters"][0].values():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    for val in hist.data["Sample Parameters"].values():
        if isinstance(val, list) and len(val) == 2 and isinstance(val[1], bool):
            val[1] = False
    hist.data["Sample Parameters"]["Scale"][1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def summary(project: G2.G2Project, stage: str, accepted: bool = True) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    masses, phases = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(phase.data["General"]["Mass"] * hap["Scale"][0])
        phases.append({
            "name": phase.name, "size": hap["Size"][1][:3], "size_type": hap["Size"][0],
            "strain": hap["Mustrain"][1][:3], "strain_type": hap["Mustrain"][0],
            "po": hap["Pref.Ori."][:4], "scale": hap["Scale"][0],
        })
    row = {
        "stage": stage, "accepted": accepted, "rwp": hist.get_wR(),
        "fractions": (np.asarray(masses) / sum(masses)).tolist(),
        "instrument": {k: inst[k][1] for k in ["Zero", "U", "W", "X", "SH/L", "Polariz."]},
        "phases": phases,
    }
    print(json.dumps(row, default=float), flush=True)
    return row


def fit(project: G2.G2Project, stage: str, rows: list[dict], cycles: int = 12, reject_worse: bool = True) -> bool:
    before = float(project.histograms()[0].get_wR() or np.inf)
    data, names = copy.deepcopy(project.data), copy.deepcopy(project.names)
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    after = float(project.histograms()[0].get_wR() or np.inf)
    accepted = not reject_worse or after <= before + 1e-7
    if not accepted:
        project.data, project.names = data, names
        project.index_ids()
    rows.append(summary(project, stage, accepted))
    return accepted


def run(source: Path, destination: Path, rounds: int) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.unlink(missing_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
    clear_nonlinear(project)
    project.set_Frozen()
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 40.0, "W": 2.0, "X": 0.1, "SH/L": 0.005}.items():
        inst[key][0] = inst[key][1] = value
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    project.save()
    rows: list[dict] = []
    # Recalculate and refit linear parameters after the instrumental reset.
    fit(project, "instrument_reset_linear", rows, cycles=12, reject_worse=False)
    for iteration in range(rounds):
        for i in range(len(project.phases())):
            clear_nonlinear(project)
            project.phase(i).set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
            fit(project, f"round_{iteration}_size_{i}", rows)
        for i in range(len(project.phases())):
            clear_nonlinear(project)
            project.phase(i).set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
            fit(project, f"round_{iteration}_strain_{i}", rows)
        clear_nonlinear(project)
        inst = project.histograms()[0].data["Instrument Parameters"][0]
        inst["Zero"][2] = True
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
        fit(project, f"round_{iteration}_zero_cells", rows)
    clear_nonlinear(project)
    fit(project, "final_linear", rows)
    project.save()
    destination.with_suffix(".json").write_text(json.dumps(rows, indent=2, default=float) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--rounds", type=int, default=2)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run(args.source, args.destination, args.rounds)
