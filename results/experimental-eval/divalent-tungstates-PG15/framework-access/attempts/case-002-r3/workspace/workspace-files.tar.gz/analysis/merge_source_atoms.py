#!/usr/bin/env python3
"""Combine source-model atoms with the selected refined nuisance model."""

from __future__ import annotations

import argparse
import copy
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def run(source_atoms: Path, nuisance_model: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.unlink(missing_ok=True)
    dst = G2.G2Project(gpxfile=str(source_atoms), newgpx=str(destination))
    src = G2.G2Project(gpxfile=str(nuisance_model))
    dh, sh = dst.histograms()[0], src.histograms()[0]
    for key in ["Instrument Parameters", "Sample Parameters", "Background", "Limits"]:
        dh.data[key] = copy.deepcopy(sh.data[key])
    # Calculated arrays are regenerated below; observations and weights remain
    # those loaded from the original pattern in the destination project.
    for i, phase in enumerate(dst.phases()):
        refined = src.phase(i)
        phase.data["General"]["Cell"] = copy.deepcopy(refined.data["General"]["Cell"])
        phase.data["General"]["Cell"][0] = False
        dhap = phase.data["Histograms"][dh.name]
        shap = refined.data["Histograms"][sh.name]
        for key in ["Scale", "Size", "Mustrain", "Pref.Ori.", "Extinction", "Babinet", "HStrain"]:
            dhap[key] = copy.deepcopy(shap[key])
        dhap["Scale"][1] = True
        dhap["Size"][2] = [False] * len(dhap["Size"][2])
        dhap["Mustrain"][2] = [False] * len(dhap["Mustrain"][2])
        dhap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
            atom.uiso = 0.003 if i == 0 else 0.010
    dh.data["Background"][0][1] = True
    for value in dh.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in dh.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    dh.data["Sample Parameters"]["Scale"][1] = False
    dst.set_Frozen()
    dst.set_Controls("cycles", 15)
    dst.save()
    dst.refine(makeBack=False)
    dst.save()
    print("Rwp", dst.histograms()[0].get_wR())


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("source_atoms", type=Path)
    parser.add_argument("nuisance_model", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run(args.source_atoms, args.nuisance_model, args.destination)
