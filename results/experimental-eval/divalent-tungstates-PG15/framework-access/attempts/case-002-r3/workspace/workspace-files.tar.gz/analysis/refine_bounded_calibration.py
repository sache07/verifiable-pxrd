#!/usr/bin/env python3
"""Constrain the alternative calibration branch to the stated instrument range."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]


def main(source: Path, destination: Path, cycles: int):
    destination.unlink(missing_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
    project.set_Frozen()
    hist = project.histograms()[0]
    hist.data["Instrument Parameters"][0]["Zero"][2] = True
    hist.data["Sample Parameters"]["Shift"][1] = True
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    print("Rwp", hist.get_wR())
    print("zero", hist.data["Instrument Parameters"][0]["Zero"])
    print("shift", hist.data["Sample Parameters"]["Shift"])
    for phase in project.phases():
        print(phase.name, phase.get_cell())


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--source",
        type=Path,
        default=ROOT / "analysis" / "calibrated" / "branch.gpx",
    )
    parser.add_argument(
        "--destination",
        type=Path,
        default=ROOT / "analysis" / "calibrated" / "branch_bounded.gpx",
    )
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    main(args.source, args.destination, args.cycles)
