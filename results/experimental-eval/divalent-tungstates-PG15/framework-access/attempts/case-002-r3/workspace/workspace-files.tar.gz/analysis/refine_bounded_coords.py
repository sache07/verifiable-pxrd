#!/usr/bin/env python3
"""Refine atomic coordinates within a small box around source positions."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def run(source: Path, destination: Path, fractional_bound: float) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.unlink(missing_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
    project.set_Frozen()
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Sample Parameters"]["Scale"][1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        for i, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "X"
            for axis, coordinate in zip("xyz", atom.coordinates):
                variable = f"{phase.id}::dA{axis}:{i}"
                project.set_Controls("parmMin", coordinate - fractional_bound, variable=variable)
                project.set_Controls("parmMax", coordinate + fractional_bound, variable=variable)
    project.set_Controls("cycles", 20)
    project.save()
    project.refine(makeBack=False)
    # Leave no coordinate flags active in the final candidate; update only
    # scales and background after accepting the bounded coordinates.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.set_Frozen()
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    project.save()
    print("bound", fractional_bound, "Rwp", project.histograms()[0].get_wR(), "frozen", project.get_Frozen())
    for phase in project.phases():
        phase.export_CIF(str(destination.with_name(destination.stem + "_" + phase.name + ".cif")))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--bound", type=float, required=True)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run(args.source, args.destination, args.bound)
