from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")


for axis in [(0, 1, 0), (1, 0, 0), (0, 0, 1), (1, 0, -1), (1, -1, -1)]:
    tag = "_".join(str(v).replace("-", "m") for v in axis)
    out = ROOT / f"po_dir_{tag}.gpx"
    project = G2.G2Project(gpxfile=str(ROOT / "adp_0p005.gpx"), newgpx=str(out))
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    major = project.phase(0)
    major.set_refinements({"Atoms": {"all": " "}})
    hap = major.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][3] = list(axis)
    major.set_HAP_refinements({"Pref.Ori.": True})
    project.refine(makeBack=False)
    project.save(str(out))
    print(axis, hist.get_wR(), hap["Pref.Ori."])
