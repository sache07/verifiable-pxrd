from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")


for kind, count in [
    ("lin interpolate", 30),
    ("lin interpolate", 60),
    ("lin interpolate", 100),
    ("inv interpolate", 40),
    ("log interpolate", 40),
]:
    tag = kind.split()[0] + str(count)
    out = ROOT / f"background_{tag}.gpx"
    project = G2.G2Project(gpxfile=str(ROOT / "adp_0p005.gpx"), newgpx=str(out))
    project.set_Controls("cycles", 18)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
    x = np.asarray(hist.data["data"][1][0], float)
    old_background = np.asarray(hist.data["data"][1][4], float)
    lo, hi = hist.data["Limits"][1]
    if kind == "lin interpolate":
        knots = np.linspace(lo, hi, count)
    elif kind == "inv interpolate":
        knots = 1 / np.linspace(1 / hi, 1 / lo, count)
    else:
        knots = np.exp(np.linspace(np.log(lo), np.log(hi), count))
    knots[0], knots[-1] = lo, hi
    coeffs = np.interp(knots, x, old_background).tolist()
    hist.set_refinements(
        {"Background": {"type": kind, "no. coeffs": count, "coeffs": coeffs, "refine": True}}
    )
    project.refine(makeBack=False)
    project.save(str(out))
    background = np.asarray(hist.data["data"][1][4], float)
    print(kind, count, hist.get_wR(), background.min(), background.max())
