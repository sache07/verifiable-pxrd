from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


path = Path("combo_rough_strain001.profile.csv")
x, yobs, ycalc, difference, background, weights = np.loadtxt(
    path, delimiter=",", skiprows=1
).T
centers = [15.61, 19.32, 26.27, 28.98, 30.44, 37.16, 48.98, 55.86, 66.82, 82.88, 89.72, 95.85]
fig, axes = plt.subplots(4, 3, figsize=(14, 12), constrained_layout=True)
for ax, center in zip(axes.flat, centers):
    half = 0.65 if center > 60 else 0.45
    mask = np.abs(x - center) <= half
    ax.plot(x[mask], yobs[mask] - background[mask], color="black", lw=0.9, label="obs-bg")
    ax.plot(x[mask], ycalc[mask] - background[mask], color="tab:red", lw=0.9, label="calc-bg")
    ax.plot(x[mask], difference[mask], color="tab:blue", lw=0.7, label="diff")
    ax.axhline(0, color="0.6", lw=0.5)
    ax.set_title(f"{center:.2f}°")
    ax.grid(alpha=0.15)
axes[0, 0].legend(fontsize=8)
fig.savefig("combo_peak_shapes.png", dpi=180)
