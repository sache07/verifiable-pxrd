from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")


for uiso in [0.003, 0.005, 0.008, 0.012, 0.016]:
    tag = str(uiso).replace(".", "p")
    out = ROOT / f"adp_{tag}.gpx"
    project = G2.G2Project(
        gpxfile=str(ROOT / "twoprofile_axis001.gpx"), newgpx=str(out)
    )
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    major, minor = project.phases()
    for atom in major.atoms():
        atom.uiso = uiso
        atom.refinement_flags = "X"
    for atom in minor.atoms():
        atom.uiso = 0.005
        atom.refinement_flags = " "
    project.refine(makeBack=False)
    project.save(str(out))
    print(
        uiso, "Rwp", hist.get_wR(),
        "scale", major.data["Histograms"][hist.name]["Scale"][0],
        "pol", hist.InstrumentParameters["Polariz."][1],
        "rough", hist.SampleParameters["SurfRoughA"][0], hist.SampleParameters["SurfRoughB"][0],
    )
