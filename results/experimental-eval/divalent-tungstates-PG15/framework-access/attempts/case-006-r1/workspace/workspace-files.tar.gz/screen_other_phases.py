from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")


for record_id in ["1527404", "2002403", "4000806", "4000807"]:
    out = ROOT / f"screen_other_{record_id}.gpx"
    project = G2.G2Project(
        gpxfile=str(ROOT / "twoprofile_axis001.gpx"), newgpx=str(out)
    )
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.clear_HAP_refinements(
            {"Mustrain": True, "Size": True, "Pref.Ori.": True, "Scale": True}
        )
    hist.clear_refinements({"Instrument Parameters": ["Zero", "Polariz.", "SH/L", "U", "V", "W", "X", "Y", "Z"]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    hist.clear_refinements({"Background": True})

    phase = project.add_phase(
        str(ROOT / f"candidate_other_{record_id}.cif"),
        phasename=f"candidate_{record_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    phase.set_refinements({"Cell": False})
    phase.set_HAP_refinements({"Scale": True})
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.2, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    project.refine(makeBack=False)
    project.save(str(out))
    print(record_id, "Rwp", hist.get_wR(), "scale", hap["Scale"])
