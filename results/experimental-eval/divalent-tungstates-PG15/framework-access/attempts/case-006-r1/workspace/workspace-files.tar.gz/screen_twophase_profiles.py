from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")


tests = {
    "iso": None,
    "axis001": [0, 0, 1],
    "axis100": [1, 0, 0],
    "axis010": [0, 1, 0],
}

for name, axis in tests.items():
    out = ROOT / f"twoprofile_{name}.gpx"
    project = G2.G2Project(
        gpxfile=str(ROOT / "screen_WO3_2311041.gpx"), newgpx=str(out)
    )
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    major, minor = project.phases()

    hist.InstrumentParameters["Zero"][2] = False
    hist.SampleParameters["Shift"][1] = False
    hist.set_refinements({"Instrument Parameters": ["Polariz.", "SH/L", "U", "W", "X"]})
    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    hist.set_refinements({"Background": True})

    major.set_refinements({"Cell": True, "Atoms": {"all": " "}})
    major.set_HAP_refinements({"Scale": True})
    mhap = major.data["Histograms"][hist.name]
    mhap["Size"][2] = [False, False, False]
    if axis is None:
        v = sum(mhap["Mustrain"][1][:2]) / 2
        mhap["Mustrain"][0] = "isotropic"
        mhap["Mustrain"][1][0] = v
        major.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    else:
        v = mhap["Mustrain"][1][0]
        mhap["Mustrain"][1][1] = v
        major.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}}
        )

    minor.set_refinements({"Cell": True, "Atoms": {"all": " "}})
    minor.set_HAP_refinements({"Scale": True})
    nhap = minor.data["Histograms"][hist.name]
    nhap["Size"][1][0] = 10.0
    nhap["Size"][2] = [False, False, False]
    minor.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})

    project.refine(makeBack=False)
    hist.SampleParameters["SurfRoughB"][1] = False
    project.refine(makeBack=False)
    project.save(str(out))
    print(
        name, "Rwp", hist.get_wR(),
        "major strain", mhap["Mustrain"][:4],
        "minor strain", nhap["Mustrain"][:4],
        "inst", {k: hist.InstrumentParameters[k][1] for k in ["Polariz.", "SH/L", "U", "W", "X"]},
    )
