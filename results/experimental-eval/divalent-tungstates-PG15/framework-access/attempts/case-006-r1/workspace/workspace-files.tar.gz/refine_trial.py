from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")


def state(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    hap = phase.data["Histograms"][hist.name]
    covariance = project.data.get("Covariance", {}).get("data", {})
    print(f"\n--- {label} ---")
    print("Rwp", hist.get_wR(), "GOF", covariance.get("Rvals", {}).get("GOF"))
    print("cell", phase.get_cell())
    print(
        "instrument",
        {k: v[1] for k, v in inst.items() if k in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}},
    )
    print(
        "sample",
        {k: (v[0] if isinstance(v, list) else v) for k, v in sample.items() if k in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"}},
    )
    print("background", hist.Background[0])
    print("scale", hap["Scale"], "size", hap["Size"], "mustrain", hap["Mustrain"], "PO", hap["Pref.Ori."])
    print("vary", covariance.get("varyList", []))
    print("atoms")
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.uiso, atom.refinement_flags)


def refine(project, label):
    project.refine(makeBack=False)
    state(project, label)


def main():
    project = G2.G2Project(newgpx=str(ROOT / "trial.gpx"))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "instrument.instprm"), fmthint="xye"
    )
    phase = project.add_phase(
        str(ROOT / "start_CuWO4.cif"), phasename="CuWO4", histograms=[hist], fmthint="CIF"
    )

    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 20,
                "coeffs": [1200.0] + [0.0] * 19,
                "refine": True,
            },
        }
    )
    phase.set_HAP_refinements({"Scale": True})
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][3] = [0, 0, 1]

    project.set_Controls("cycles", 8)
    state(project, "initial")

    refine(project, "background and scale")

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "cell and zero")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "instrument profile")

    phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True}})
    refine(project, "size")

    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, "microstrain")

    phase.set_refinements({"Atoms": {"all": "XU"}})
    refine(project, "coordinates and Uiso")

    project.save(str(ROOT / "trial.gpx"))
    print("GSAS-II revision", GSASIIpath.GetVersionNumber())


if __name__ == "__main__":
    main()
