from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")
project = G2.G2Project(
    gpxfile=str(ROOT / "combo_rough_strain001.gpx"),
    newgpx=str(ROOT / "diagnostic_lebail_fixed.gpx"),
)
project.set_Controls("cycles", 8)
hist = project.histogram(0)
phase = project.phase(0)
phase.set_refinements({"Cell": False, "Atoms": {"all": " "}, "LeBail": True})
phase.clear_HAP_refinements({"Mustrain": True, "Size": True, "Pref.Ori.": True, "Scale": True})
hist.clear_refinements(
    {
        "Background": True,
        "Instrument Parameters": ["Zero", "Polariz.", "SH/L", "U", "V", "W", "X", "Y", "Z"],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
    }
)
for i in range(12):
    project.refine(makeBack=False)
    print(i, project.histogram(0).get_wR())
project.save(str(ROOT / "diagnostic_lebail_fixed.gpx"))
