from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")


def report(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    cov = project.data.get("Covariance", {}).get("data", {})
    print("\n", label)
    print("Rwp", hist.get_wR(), "GOF", cov.get("Rvals", {}).get("GOF"))
    print("cell", phase.get_cell())
    print("inst", {k: v[1] for k, v in hist.InstrumentParameters.items() if k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]})
    print("sample", {k: v for k, v in hist.SampleParameters.items() if k in ["Shift", "SurfRoughA", "SurfRoughB"]})
    print("profile", "size", hap["Size"], "mustrain", hap["Mustrain"], "PO", hap["Pref.Ori."])
    print("atoms")
    for atom in phase.atoms():
        print(atom.label, atom.coordinates, atom.uiso, atom.refinement_flags)
    print("constraints", project.get_Constraints("Phase"))


project = G2.G2Project(gpxfile=str(ROOT / "trial.gpx"), newgpx=str(ROOT / "stage2.gpx"))
hist = project.histogram(0)
phase = project.phase(0)
hap = phase.data["Histograms"][hist.name]

# Cover every public point; replay scoring does not honor truncated fit limits.
x = hist.data["data"][1][0]
hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})

# Size and instrumental X are exactly correlated in this parameterization.
# Retain the current physical size as fixed and let X carry the resolvable sum.
hap["Size"][2] = [False, False, False]

# The specimen model has one phase-wide Uiso. Reset the unstable independent
# values and impose that physically meaningful equality during refinement.
for atom in phase.atoms():
    atom.uiso = 0.007
    atom.refinement_flags = "XU"
project.save(str(ROOT / "stage2.gpx"))
project.add_EquivConstr([f"0::AUiso:{i}" for i in range(len(phase.atoms()))])
project.set_Controls("parmMin", 0.0001, variable="0::AUiso:0")
project.set_Controls("parmMax", 0.05, variable="0::AUiso:0")

project.set_Controls("cycles", 12)
project.refine(makeBack=False)
report(project, "shared Uiso, full grid")

# Separate constant angular zero from the cosine-dependent specimen-height
# correction and fit polarization, which controls the broad angle-dependent
# intensity trend.
hist.SampleParameters["Shift"] = [0.0, True]
hist.set_refinements({"Instrument Parameters": ["Polariz."]})
project.refine(makeBack=False)
report(project, "shift and polarization")

# A somewhat richer smooth basis tests that residual continuum curvature is
# not being misassigned to Bragg intensities.
old = hist.Background[0]
hist.set_refinements(
    {
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 30,
            "coeffs": list(old[3:]) + [0.0] * (30 - old[2]),
            "refine": True,
        }
    }
)
project.refine(makeBack=False)
report(project, "30-term smooth background")
project.save(str(ROOT / "stage2.gpx"))
