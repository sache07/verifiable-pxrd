from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")
project = G2.G2Project(
    gpxfile=str(ROOT / "adp_0p005.gpx"),
    newgpx=str(ROOT / "diagnostic_generalized_strain.gpx"),
)
project.set_Controls("cycles", 25)
hist = project.histogram(0)
major, minor = project.phases()
major.set_refinements({"Atoms": {"all": " "}})
major.set_HAP_refinements({"Mustrain": {"type": "generalized", "refine": True}})
project.refine(makeBack=False)
project.save(str(ROOT / "diagnostic_generalized_strain.gpx"))
hap = major.data["Histograms"][hist.name]
print("Rwp", hist.get_wR())
print("mustrain", hap["Mustrain"])
