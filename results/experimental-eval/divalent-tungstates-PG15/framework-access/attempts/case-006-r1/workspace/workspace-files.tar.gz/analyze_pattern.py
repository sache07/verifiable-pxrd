from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.signal import find_peaks, peak_widths


data = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
x, y = data.T

# A broad rolling percentile is only for peak picking/visualization; the raw
# counts are retained for all subsequent GSAS-II refinements.
background = percentile_filter(y, percentile=15, size=401, mode="nearest")
signal = gaussian_filter1d(y - background, sigma=1.2)
peaks, properties = find_peaks(signal, prominence=120, height=90, distance=5)
widths = peak_widths(signal, peaks, rel_height=0.5)[0] * np.median(np.diff(x))
order = np.argsort(properties["prominences"])[::-1]

print("two_theta,intensity,net_height,prominence,fwhm_deg")
for j in order:
    i = peaks[j]
    print(
        f"{x[i]:.5f},{y[i]:.1f},{signal[i]:.1f},"
        f"{properties['prominences'][j]:.1f},{widths[j]:.4f}"
    )

fig, axes = plt.subplots(2, 1, figsize=(15, 8), constrained_layout=True)
axes[0].plot(x, y, color="black", linewidth=0.55)
axes[0].plot(x, background, color="tab:red", linewidth=0.8)
axes[0].set(xlim=(x.min(), x.max()), ylabel="Counts")
axes[1].plot(x, y, color="black", linewidth=0.65)
axes[1].plot(x, background, color="tab:red", linewidth=0.8)
axes[1].set(xlim=(10, 50), xlabel=r"$2\theta$ (deg)", ylabel="Counts")
for ax in axes:
    ax.grid(alpha=0.15)
fig.savefig("pattern_overview.png", dpi=170)
