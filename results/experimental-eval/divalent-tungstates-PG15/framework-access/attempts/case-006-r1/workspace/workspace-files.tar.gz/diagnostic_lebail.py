from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")
project = G2.G2Project(
    gpxfile=str(ROOT / "combo_rough_strain001.gpx"),
    newgpx=str(ROOT / "diagnostic_lebail.gpx"),
)
project.set_Controls("cycles", 25)
phase = project.phase(0)
phase.set_refinements({"LeBail": True})
for i in range(4):
    project.refine(makeBack=False)
    print(i, project.histogram(0).get_wR())
project.save(str(ROOT / "diagnostic_lebail.gpx"))
