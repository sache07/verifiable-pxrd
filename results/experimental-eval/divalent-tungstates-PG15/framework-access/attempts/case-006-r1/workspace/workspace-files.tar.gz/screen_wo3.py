from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")
CANDIDATES = ["1528915", "1563541", "2106293", "2107312", "1010618", "2311041"]


for record_id in CANDIDATES:
    out = ROOT / f"screen_WO3_{record_id}.gpx"
    project = G2.G2Project(
        gpxfile=str(ROOT / "combo_rough_strain001.gpx"), newgpx=str(out)
    )
    project.set_Controls("cycles", 14)
    hist = project.histogram(0)
    major = project.phase(0)

    # Hold the mature CuWO4/profile solution while screening only the minor
    # phase's identity, scale and cell.
    major.set_refinements({"Cell": False, "Atoms": {"all": " "}})
    major.clear_HAP_refinements({"Mustrain": True, "Size": True, "Pref.Ori.": True})
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "Polariz.", "SH/L", "U", "V", "W", "X", "Y", "Z"]}
    )
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    hist.clear_refinements({"Background": True})

    minor = project.add_phase(
        str(ROOT / f"candidate_WO3_{record_id}.cif"),
        phasename=f"WO3_{record_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    minor.set_refinements({"Cell": True})
    minor.set_HAP_refinements({"Scale": True})
    mhap = minor.data["Histograms"][hist.name]
    mhap["Scale"] = [3.0, True]
    mhap["Size"][0] = "isotropic"
    mhap["Size"][1][0] = 0.5
    mhap["Mustrain"][0] = "isotropic"
    mhap["Mustrain"][1][0] = 1000.0
    project.refine(makeBack=False)

    # The minor phase can have its own specimen broadening.
    minor.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.5, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )
    project.refine(makeBack=False)
    project.save(str(out))
    print(
        record_id,
        "Rwp", hist.get_wR(),
        "cell", minor.get_cell(),
        "scale", mhap["Scale"],
        "size", mhap["Size"][1][0],
        "strain", mhap["Mustrain"][1][0],
    )
