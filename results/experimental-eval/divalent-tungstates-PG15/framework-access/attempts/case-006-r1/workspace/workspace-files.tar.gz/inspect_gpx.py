from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


path = Path(sys.argv[1] if len(sys.argv) > 1 else "trial.gpx")
project = G2.G2Project(str(path))
hist = project.histogram(0)
x, yobs, weights, ycalc, background, residual = [
    np.asarray(a, dtype=float) for a in hist.data["data"][1]
]


def rwp(mask):
    return 100 * np.sqrt(
        np.sum(weights[mask] * (yobs[mask] - ycalc[mask]) ** 2)
        / np.sum(weights[mask] * yobs[mask] ** 2)
    )


print("points", len(x))
print("overall Rwp", rwp(np.ones(len(x), dtype=bool)))
print("min/max calc", ycalc.min(), ycalc.max())
print("min/max background", background.min(), background.max())
for lo, hi in [(10, 20), (20, 30), (30, 40), (40, 50), (50, 70), (70, 100)]:
    mask = (x >= lo) & (x < hi)
    print(f"Rwp {lo}-{hi}", rwp(mask), "mean residual", residual[mask].mean())

np.savetxt(
    path.with_suffix(".profile.csv"),
    np.column_stack([x, yobs, ycalc, residual, background, weights]),
    delimiter=",",
    header="two_theta,observed,calculated,difference,background,weight",
    comments="",
)
