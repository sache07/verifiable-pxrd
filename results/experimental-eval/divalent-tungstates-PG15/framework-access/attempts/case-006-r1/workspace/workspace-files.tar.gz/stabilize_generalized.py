from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "generalized_stable.gpx"
G2.SetPrintLevel("warn")

project = G2.G2Project(
    gpxfile=str(ROOT / "generalized_coordinates.gpx"), newgpx=str(OUT)
)
project.set_Controls("cycles", 25)
for cycle in range(1, 5):
    project.refine(makeBack=False)
    project.save(str(OUT))
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    print(
        cycle,
        "Rwp", project.histogram(0).get_wR(),
        "GOF", rvals.get("GOF"),
        "max_shift_esd", rvals.get("Max shft/sig"),
        "converged", rvals.get("converged"),
    )

for phase in project.phases():
    print(phase.name, phase.get_cell())
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.uiso)
