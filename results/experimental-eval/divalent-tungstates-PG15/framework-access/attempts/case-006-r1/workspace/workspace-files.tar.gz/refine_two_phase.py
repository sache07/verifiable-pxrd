from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")


def summary(project, label):
    hist = project.histogram(0)
    print("\n", label, "Rwp", hist.get_wR())
    print("inst", {k: v[1] for k, v in hist.InstrumentParameters.items() if k in ["Zero", "Polariz.", "SH/L", "U", "W", "X"]})
    print("sample", {k: v for k, v in hist.SampleParameters.items() if k in ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, phase.get_cell(), "scale", hap["Scale"], "size", hap["Size"][:3], "strain", hap["Mustrain"][:4])
        print(" atoms", [(a.label, a.coordinates, a.uiso, a.refinement_flags) for a in phase.atoms()])


for wo3_id in ["1528915", "2311041"]:
    out = ROOT / f"twophase_{wo3_id}.gpx"
    project = G2.G2Project(
        gpxfile=str(ROOT / f"screen_WO3_{wo3_id}.gpx"), newgpx=str(out)
    )
    project.set_Controls("cycles", 20)
    hist = project.histogram(0)
    cuwo4, wo3 = project.phases()

    # Keep the already estimated calibration combination fixed to remove the
    # near-exact zero/height/cell degeneracy while the phase model settles.
    hist.InstrumentParameters["Zero"][2] = False
    hist.SampleParameters["Shift"][1] = False
    hist.set_refinements(
        {"Instrument Parameters": ["Polariz.", "SH/L", "U", "W", "X"]}
    )
    hist.set_refinements(
        {"Sample Parameters": ["SurfRoughA", "SurfRoughB"]}
    )
    hist.set_refinements({"Background": True})

    cuwo4.set_refinements({"Cell": True, "Atoms": {"all": " "}})
    cuwo4.set_HAP_refinements(
        {
            "Scale": True,
            "Mustrain": {"type": "uniaxial", "direction": [0, 0, 1], "refine": True},
        }
    )
    cuwo4.data["Histograms"][hist.name]["Size"][2] = [False, False, False]

    wo3.set_refinements({"Cell": True, "Atoms": {"all": " "}})
    wo3.set_HAP_refinements({"Scale": True})
    whap = wo3.data["Histograms"][hist.name]
    whap["Size"][0] = "isotropic"
    whap["Size"][1][0] = 1.0
    whap["Mustrain"][0] = "isotropic"
    if not 0 < whap["Mustrain"][1][0] < 5000:
        whap["Mustrain"][1][0] = 1000.0
    wo3.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 1.0, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )

    project.refine(makeBack=False)
    summary(project, f"{wo3_id} profiles/cells/scales")

    # Refine the well-determined major-phase structure with its shared Uiso.
    cuwo4.set_refinements({"Atoms": {"all": "XU"}})
    project.refine(makeBack=False)
    summary(project, f"{wo3_id} major structure")

    # Only W positions are sufficiently sensitive in the ~minor phase.
    for atom in wo3.atoms():
        atom.refinement_flags = "X" if atom.element == "W" else " "
    project.refine(makeBack=False)
    summary(project, f"{wo3_id} minor W positions")

    # Alternate nuisance and structure once more after fixing one member of
    # the highly correlated roughness pair.
    hist.SampleParameters["SurfRoughB"][1] = False
    project.refine(makeBack=False)
    summary(project, f"{wo3_id} stabilized final")
    project.save(str(out))
