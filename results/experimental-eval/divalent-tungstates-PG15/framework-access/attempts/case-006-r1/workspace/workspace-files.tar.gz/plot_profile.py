from pathlib import Path
import sys

import matplotlib.pyplot as plt
import numpy as np


path = Path(sys.argv[1] if len(sys.argv) > 1 else "trial.profile.csv")
x, yobs, ycalc, residual, background, weights = np.loadtxt(
    path, delimiter=",", skiprows=1
).T
fig, axes = plt.subplots(3, 1, figsize=(16, 11), constrained_layout=True)
for ax, (lo, hi) in zip(axes, [(10, 100), (10, 50), (50, 100)]):
    mask = (x >= lo) & (x <= hi)
    ax.plot(x[mask], yobs[mask], color="black", lw=0.6, label="observed")
    ax.plot(x[mask], ycalc[mask], color="tab:red", lw=0.75, label="calculated")
    ax.plot(x[mask], residual[mask], color="tab:blue", lw=0.55, label="difference")
    ax.plot(x[mask], background[mask], color="tab:green", lw=0.55, label="background")
    ax.set_xlim(lo, hi)
    ax.grid(alpha=0.15)
axes[0].legend(ncols=4)
axes[-1].set_xlabel(r"$2\theta$ (deg)")
fig.savefig(path.with_suffix(".png"), dpi=160)
