from pathlib import Path
import sys

from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / "learned" / "divalent-tungstates" / "runtime"
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
for record_id in ["1011194", "9016057"]:
    source = COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"
    structure = Structure.from_file(source, primitive=False)
    write_synthetic_model(structure, ROOT / f"candidate_CuO_{record_id}.cif")
    print(record_id, structure.composition.reduced_formula, structure.get_space_group_info(symprec=1e-3), structure.lattice)
