from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")


for wo3_id in ["1528915", "2311041"]:
    for cuo_id in ["1011194", "9016057"]:
        out = ROOT / f"screen_WO3_{wo3_id}_CuO_{cuo_id}.gpx"
        project = G2.G2Project(
            gpxfile=str(ROOT / f"screen_WO3_{wo3_id}.gpx"), newgpx=str(out)
        )
        project.set_Controls("cycles", 14)
        hist = project.histogram(0)
        for phase in project.phases():
            phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
            phase.clear_HAP_refinements({"Mustrain": True, "Size": True, "Pref.Ori.": True})

        cuo = project.add_phase(
            str(ROOT / f"candidate_CuO_{cuo_id}.cif"),
            phasename=f"CuO_{cuo_id}",
            histograms=[hist],
            fmthint="CIF",
        )
        # The phase is very minor; hold the literature cell during identity
        # screening so a weak-scale/cell correlation cannot destroy the cell.
        cuo.set_refinements({"Cell": False})
        cuo.set_HAP_refinements({"Scale": True})
        hap = cuo.data["Histograms"][hist.name]
        hap["Scale"] = [0.3, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        project.refine(makeBack=False)
        cuo.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.5, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
        project.refine(makeBack=False)
        project.save(str(out))
        print(
            wo3_id,
            cuo_id,
            "Rwp", hist.get_wR(),
            "cell", cuo.get_cell(),
            "scale", hap["Scale"],
            "size", hap["Size"][1][0],
            "strain", hap["Mustrain"][1][0],
        )
