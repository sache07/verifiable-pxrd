from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")


def configure(project, do_rough=False, strain_axis=None, po_axis=None):
    hist = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    if do_rough:
        hist.SampleParameters["SurfRoughA"] = [0.36, True]
        hist.SampleParameters["SurfRoughB"] = [0.145, True]
    if strain_axis is not None:
        v = hap["Mustrain"][1][0]
        hap["Mustrain"][1][1] = v
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": list(strain_axis), "refine": True}}
        )
    if po_axis is not None:
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = list(po_axis)
        phase.set_HAP_refinements({"Pref.Ori.": True})


tests = {
    "rough_strain001": (True, (0, 0, 1), None),
    "rough_po100": (True, None, (1, 0, 0)),
    "strain001_po100": (False, (0, 0, 1), (1, 0, 0)),
    "rough_strain001_po100": (True, (0, 0, 1), (1, 0, 0)),
    "rough_strain001_po001": (True, (0, 0, 1), (0, 0, 1)),
}

for name, args in tests.items():
    out = ROOT / f"combo_{name}.gpx"
    project = G2.G2Project(gpxfile=str(ROOT / "stage2.gpx"), newgpx=str(out))
    project.set_Controls("cycles", 18)
    configure(project, *args)
    project.refine(makeBack=False)
    project.save(str(out))
    hist = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    print(
        name,
        hist.get_wR(),
        "rough", hist.SampleParameters["SurfRoughA"], hist.SampleParameters["SurfRoughB"],
        "strain", hap["Mustrain"][:4],
        "PO", hap["Pref.Ori."],
    )
