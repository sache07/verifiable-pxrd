from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")

project = G2.G2Project(
    gpxfile=str(ROOT / "diagnostic_generalized_strain.gpx"),
    newgpx=str(ROOT / "generalized_coordinates.gpx"),
)
project.set_Controls("cycles", 25)
hist = project.histogram(0)
major, minor = project.phases()

# The dominant phase carries enough intensity to refine fractional coordinates.
# Keep displacement parameters fixed at a physically ordinary room-temperature
# value; they are too correlated with scale/background for this data set.
for atom in major.atoms():
    atom.uiso = 0.005
    atom.refinement_flags = "X"
for atom in minor.atoms():
    atom.uiso = 0.005
    atom.refinement_flags = " "

project.refine(makeBack=False)
project.save(str(ROOT / "generalized_coordinates.gpx"))

cov = project.data.get("Covariance", {}).get("data", {})
print("Rwp", hist.get_wR(), "GOF", cov.get("Rvals", {}).get("GOF"))
for phase in project.phases():
    print(phase.name, phase.get_cell())
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.uiso)
