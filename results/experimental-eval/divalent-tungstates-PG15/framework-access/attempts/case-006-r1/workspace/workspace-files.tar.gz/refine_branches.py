from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
G2.SetPrintLevel("warn")


def run(name, setup):
    out = ROOT / f"branch_{name}.gpx"
    project = G2.G2Project(gpxfile=str(ROOT / "stage2.gpx"), newgpx=str(out))
    project.set_Controls("cycles", 15)
    hist = project.histogram(0)
    phase = project.phase(0)
    setup(project, hist, phase)
    project.refine(makeBack=False)
    project.save(str(out))
    hap = phase.data["Histograms"][hist.name]
    cov = project.data.get("Covariance", {}).get("data", {})
    print(
        name,
        "Rwp", hist.get_wR(),
        "GOF", cov.get("Rvals", {}).get("GOF"),
        "PO", hap["Pref.Ori."],
        "Mustrain", hap["Mustrain"][:4],
        "rough", hist.SampleParameters["SurfRoughA"], hist.SampleParameters["SurfRoughB"],
    )


def po(axis):
    def setup(project, hist, phase):
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = list(axis)
        phase.set_HAP_refinements({"Pref.Ori.": True})
    return setup


def strain(axis):
    def setup(project, hist, phase):
        hap = phase.data["Histograms"][hist.name]
        value = hap["Mustrain"][1][0]
        hap["Mustrain"][1][1] = value
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": list(axis), "refine": True}}
        )
    return setup


def rough(project, hist, phase):
    hist.SampleParameters["SurfRoughA"] = [0.30, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]


for label, axis in [
    ("po001", (0, 0, 1)),
    ("po100", (1, 0, 0)),
    ("po010", (0, 1, 0)),
    ("po110", (1, 1, 0)),
    ("po111", (1, 1, 1)),
]:
    run(label, po(axis))

for label, axis in [
    ("strain001", (0, 0, 1)),
    ("strain100", (1, 0, 0)),
    ("strain010", (0, 1, 0)),
]:
    run(label, strain(axis))

run("rough", rough)
