from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("error")
VALUES = (0.003, 0.006, 0.010, 0.015, 0.020)


def main():
    for wo_value in VALUES:
        for co_value in VALUES:
            path = Path(f"uiso_WO{int(1000*wo_value):02d}_Co{int(1000*co_value):02d}.gpx")
            shutil.copy2("coord_W40_O50.gpx", path)
            project = G2.G2Project(gpxfile=str(path))
            for phase_name, value in (("WO3", wo_value), ("Co3O4", co_value)):
                for atom in project.phase(phase_name).atoms():
                    atom.uiso = value
                    atom.refinement_flags = " "
            project.set_Controls("cycles", 15)
            project.refine()
            hist = project.histograms()[0]
            print(
                {
                    "WO3_Uiso": wo_value,
                    "Co3O4_Uiso": co_value,
                    "rwp": hist.get_wR(),
                    "polarization": hist.data["Instrument Parameters"][0]["Polariz."][1],
                },
                flush=True,
            )
            project.save()


if __name__ == "__main__":
    main()
