from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("error")


def main():
    for axis in ([0, 0, 1], [1, 1, 0], [1, 1, 1]):
        for ratio in (0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4):
            tag = "".join(map(str, axis))
            path = Path(f"cotex_{tag}_{ratio:.1f}.gpx")
            shutil.copy2("bg16.gpx", path)
            gpx = G2.G2Project(gpxfile=str(path))
            hist = gpx.histograms()[0]
            po = gpx.phase("Co3O4").data["Histograms"][hist.name]["Pref.Ori."]
            po[0], po[1], po[2], po[3] = "MD", ratio, False, list(axis)
            for _ in range(2):
                gpx.set_Controls("cycles", 12)
                gpx.refine()
            print({"axis": axis, "ratio": ratio, "rwp": hist.get_wR()}, flush=True)
            gpx.save()


if __name__ == "__main__":
    main()
