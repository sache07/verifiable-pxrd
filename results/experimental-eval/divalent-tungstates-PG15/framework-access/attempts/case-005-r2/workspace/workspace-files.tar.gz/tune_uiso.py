from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("error")


def main():
    for wo_value in (0.007, 0.008, 0.009):
        for co_value in (0.008, 0.010, 0.012):
            path = Path(f"tune_U_WO{int(1000*wo_value):02d}_Co{int(1000*co_value):02d}.gpx")
            shutil.copy2("projected231.gpx", path)
            gpx = G2.G2Project(gpxfile=str(path))
            for phase_name, value in (("WO3", wo_value), ("Co3O4", co_value)):
                for atom in gpx.phase(phase_name).atoms():
                    atom.uiso = value
                    atom.refinement_flags = " "
            for _ in range(3):
                gpx.set_Controls("cycles", 12)
                gpx.refine()
            hist = gpx.histograms()[0]
            print(
                {
                    "WO3_Uiso": wo_value,
                    "Co3O4_Uiso": co_value,
                    "rwp": hist.get_wR(),
                    "polarization": hist.data["Instrument Parameters"][0]["Polariz."][1],
                },
                flush=True,
            )
            gpx.save()


if __name__ == "__main__":
    main()
