from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("all")


def summary(project, label):
    hist = project.histograms()[0]
    arrays = hist.data["data"][1]
    x, y, w, yc, bkg, residual = [np.asarray(v, float) for v in arrays[:6]]
    rwp = 100 * np.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2))
    print(f"\nSUMMARY {label}: stored wR={hist.get_wR()} recomputed Rwp={rwp:.6f}")
    print("instrument", hist.data["Instrument Parameters"][0])
    print("sample", hist.data["Sample Parameters"])
    print("background", hist.data["Background"])
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        print(
            "phase",
            phase.name,
            "cell",
            phase.data["General"]["Cell"],
            "scale",
            hap["Scale"],
            "size",
            hap["Size"],
            "mustrain",
            hap["Mustrain"],
            "PO",
            hap["Pref.Ori."],
        )
    print("fractions", np.asarray(masses) / np.sum(masses))
    covariance = project.data.get("Covariance", {}).get("data", {})
    print("GOF", covariance.get("Rvals", {}).get("GOF"), "Nvars", len(covariance.get("varyList", [])))


def calculate(project, cycles=0):
    project.set_Controls("cycles", cycles)
    project.refine()


def main():
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "explore.gpx")
    project = G2.G2Project(newgpx=str(out))
    wo3 = project.add_phase("start_WO3.cif", phasename="WO3", fmthint="CIF")
    co3o4 = project.add_phase("start_Co3O4.cif", phasename="Co3O4", fmthint="CIF")
    hist = project.add_powder_histogram(
        "observed.xye", "start.instprm", phases="all", fmthint="xye"
    )
    sample = hist.data["Sample Parameters"]
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [-600.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [3000.0] + [0.0] * 7,
                "refine": False,
            },
        }
    )
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [2.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][1][1] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
    calculate(project, cycles=0)
    summary(project, "initial")

    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    calculate(project, cycles=8)
    summary(project, "background_scales")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    calculate(project, cycles=8)
    summary(project, "shift_cells")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in project.phases():
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    calculate(project, cycles=12)
    summary(project, "profiles")
    project.save()


if __name__ == "__main__":
    main()
