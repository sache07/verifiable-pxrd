import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


G2.SetPrintLevel("error")
TARGETS = {("WO3", "W"): 0.040, ("WO3", "O"): 0.050, ("Co3O4", "O"): 0.0135}


def coordinate_map(phase):
    return {atom.label: np.asarray(atom.coordinates, float) for atom in phase.atoms()}


def project_to_targets(gpx, references):
    for phase_name in ("WO3", "Co3O4"):
        phase = gpx.phase(phase_name)
        orthogonal, _ = G2lat.cell2AB(phase.data["General"]["Cell"][1:7])
        for element in {atom.element for atom in phase.atoms()}:
            target = TARGETS.get((phase_name, element), 0.0)
            selected = [atom for atom in phase.atoms() if atom.element == element]
            deltas = []
            for atom in selected:
                delta = np.asarray(atom.coordinates, float) - references[phase_name][atom.label]
                delta -= np.rint(delta)
                deltas.append(delta)
            rms = np.sqrt(np.mean([np.linalg.norm(orthogonal @ delta) ** 2 for delta in deltas]))
            scale = target / rms if rms and target else 0.0
            for atom, delta in zip(selected, deltas):
                atom.coordinates = tuple((references[phase_name][atom.label] + scale * delta) % 1)


def main():
    reference = G2.G2Project(gpxfile="screen_2311041.gpx")
    references = {name: coordinate_map(reference.phase(name)) for name in ("WO3", "Co3O4")}
    shutil.copy2("coord_W40_O50.gpx", "projected231.gpx")
    gpx = G2.G2Project(gpxfile="projected231.gpx")
    hist = gpx.histograms()[0]
    for iteration in range(8):
        for phase in gpx.phases():
            phase.set_refinements({"Atoms": {"all": "X"}})
        gpx.set_Controls("cycles", 1)
        gpx.refine()
        project_to_targets(gpx, references)
        for phase in gpx.phases():
            for atom in phase.atoms():
                atom.refinement_flags = " "
        gpx.save()
        gpx.set_Controls("cycles", 8)
        gpx.refine()
        print(iteration, hist.get_wR(), flush=True)
    gpx.save()


if __name__ == "__main__":
    main()
