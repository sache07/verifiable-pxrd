from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


G2.SetPrintLevel("error")
W_TARGETS = (0.01, 0.02, 0.03, 0.04)
O_TARGETS = (0.01, 0.02, 0.03, 0.04, 0.05)


def main():
    reference = G2.G2Project(gpxfile="screen_2311041.gpx").phase("WO3")
    unconstrained = G2.G2Project(gpxfile="allcoords231.gpx").phase("WO3")
    ref_xyz = {atom.label: np.asarray(atom.coordinates, float) for atom in reference.atoms()}
    fit_xyz = {atom.label: np.asarray(atom.coordinates, float) for atom in unconstrained.atoms()}
    elements = {atom.label: atom.element for atom in reference.atoms()}
    cell = unconstrained.data["General"]["Cell"][1:7]
    orthogonal, _ = G2lat.cell2AB(cell)
    rms = {}
    for element in ("W", "O"):
        distances = []
        for label in ref_xyz:
            if elements[label] != element:
                continue
            delta = fit_xyz[label] - ref_xyz[label]
            delta -= np.rint(delta)
            distances.append(np.linalg.norm(orthogonal @ delta))
        rms[element] = float(np.sqrt(np.mean(np.square(distances))))

    for w_target in W_TARGETS:
        for o_target in O_TARGETS:
            path = Path(f"coord_W{int(1000*w_target):02d}_O{int(1000*o_target):02d}.gpx")
            shutil.copy2("allcoords231.gpx", path)
            project = G2.G2Project(gpxfile=str(path))
            phase = project.phase("WO3")
            for atom in phase.atoms():
                delta = fit_xyz[atom.label] - ref_xyz[atom.label]
                delta -= np.rint(delta)
                target = w_target if atom.element == "W" else o_target
                atom.coordinates = tuple((ref_xyz[atom.label] + delta * target / rms[atom.element]) % 1)
                atom.refinement_flags = " "
            for atom in project.phase("Co3O4").atoms():
                atom.refinement_flags = " "
            project.set_Controls("cycles", 15)
            project.refine()
            hist = project.histograms()[0]
            print(
                {
                    "W_rms_A": w_target,
                    "O_rms_A": o_target,
                    "rwp": hist.get_wR(),
                    "polarization": hist.data["Instrument Parameters"][0]["Polariz."][1],
                },
                flush=True,
            )
            project.save()


if __name__ == "__main__":
    main()
