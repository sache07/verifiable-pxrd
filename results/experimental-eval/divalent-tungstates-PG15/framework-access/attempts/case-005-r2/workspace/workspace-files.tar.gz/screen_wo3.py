from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("error")


def refine(project, cycles):
    project.set_Controls("cycles", cycles)
    project.refine()


def run(codid):
    output = Path(f"screen_{codid}.gpx")
    project = G2.G2Project(newgpx=str(output))
    project.add_phase(f"start_WO3_{codid}.cif", phasename="WO3", fmthint="CIF")
    project.add_phase("start_Co3O4.cif", phasename="Co3O4", fmthint="CIF")
    hist = project.add_powder_histogram(
        "observed.xye", "start.instprm", phases="all", fmthint="xye"
    )
    sample = hist.data["Sample Parameters"]
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [-600.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [3000.0] + [0.0] * 7,
                "refine": False,
            }
        }
    )
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [2.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.2
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
    refine(project, 0)
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    refine(project, 6)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, 10)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    for phase in project.phases():
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    refine(project, 15)
    masses = np.array(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()
        ]
    )
    fractions = masses / masses.sum()
    inst = hist.data["Instrument Parameters"][0]
    return {
        "codid": codid,
        "rwp": hist.get_wR(),
        "wo3_fraction": fractions[0],
        "shift": sample["Shift"][0],
        "U": inst["U"][1],
        "W": inst["W"][1],
        "SHL": inst["SH/L"][1],
        "cells": [phase.data["General"]["Cell"][1:] for phase in project.phases()],
    }


if __name__ == "__main__":
    for candidate in sys.argv[1:]:
        try:
            print(run(candidate), flush=True)
        except Exception as exc:
            print({"codid": candidate, "error": repr(exc)}, flush=True)
