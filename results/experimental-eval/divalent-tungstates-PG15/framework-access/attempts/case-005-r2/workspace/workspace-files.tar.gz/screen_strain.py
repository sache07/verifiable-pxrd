from pathlib import Path
import shutil
import sys

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("error")
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def main(base, phase_name):
    for axis in AXES:
        tag = "".join(map(str, axis))
        path = Path(f"strain_{phase_name}_{tag}.gpx")
        shutil.copy2(base, path)
        project = G2.G2Project(gpxfile=str(path))
        hist = project.histograms()[0]
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        start = abs(float(hap["Mustrain"][1][0]))
        hap["Mustrain"][1][0] = start
        hap["Mustrain"][1][1] = start
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "refine": True,
                    "direction": list(axis),
                }
            }
        )
        project.set_Controls("cycles", 20)
        project.refine()
        print(
            {
                "phase": phase_name,
                "axis": axis,
                "rwp": hist.get_wR(),
                "mustrain": hap["Mustrain"],
            },
            flush=True,
        )
        project.save()


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
