from pathlib import Path
import shutil
import sys

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("error")
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def main(base, phase_name):
    for axis in AXES:
        tag = "".join(map(str, axis))
        path = Path(f"po_{phase_name}_{tag}.gpx")
        shutil.copy2(base, path)
        project = G2.G2Project(gpxfile=str(path))
        hist = project.histograms()[0]
        for phase in project.phases():
            po = phase.data["Histograms"][hist.name]["Pref.Ori."]
            po[1], po[2] = 1.0, False
        po = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", 1.0, True, list(axis)
        project.set_Controls("cycles", 15)
        project.refine()
        print(
            {
                "phase": phase_name,
                "axis": axis,
                "ratio": po[1],
                "rwp": hist.get_wR(),
                "polarization": hist.data["Instrument Parameters"][0]["Polariz."][1],
            },
            flush=True,
        )
        project.save()


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
