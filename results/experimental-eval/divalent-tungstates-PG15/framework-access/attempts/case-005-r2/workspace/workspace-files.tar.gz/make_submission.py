"""Create the human-readable deliverables from the verified final.gpx replay."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / ".tmp" / "replay_final"


def main() -> None:
    replay = json.loads((REPLAY / "replay.json").read_text())
    if replay.get("status") != "replayed":
        raise RuntimeError(f"Final project did not replay: {replay}")

    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as archive:
        x = np.asarray(archive["x"], dtype=float)
        observed = np.asarray(archive["observed"], dtype=float)
        calculated = np.asarray(archive["predicted"], dtype=float)

    public = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if not np.array_equal(x, public[:, 0]) or not np.array_equal(observed, public[:, 1]):
        raise RuntimeError("Replayed observations do not exactly match inputs/pattern.csv")
    if not np.isfinite(calculated).all() or np.any(calculated < 0):
        raise RuntimeError("Replayed calculated profile is not physical")

    difference = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    n_variables = 32
    degrees_of_freedom = len(x) - n_variables
    reduced_chi_square = chi_square / degrees_of_freedom

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        writer.writerows(
            (f"{xx:.12g}", f"{yo:.12g}", f"{yc:.12g}", f"{dy:.12g}")
            for xx, yo, yc, dy in zip(x, observed, calculated, difference)
        )

    phase_paths = {"WO3": "phase_WO3.cif", "Co3O4": "phase_Co3O4.cif"}
    phases = []
    for phase in replay["phases"]:
        name = phase["name"]
        phases.append(
            {
                "name": name,
                "formula": name,
                "cif_path": phase_paths[name],
                "weight_fraction": phase["weight_fraction"],
            }
        )

    result = {
        "phases": phases,
        "refinement_histogram": replay["histogram"],
        "weight_fraction_basis": "Normalized over the two modeled crystalline phases; amorphous or unidentified material is not quantified.",
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "chi_square": chi_square,
            "reduced_chi_square": reduced_chi_square,
            "gof": float(np.sqrt(reduced_chi_square)),
            "n_points": int(len(x)),
            "n_refined_variables": n_variables,
            "weighting": "Poisson approximation, w = 1/max(observed counts, 1)",
        },
        "calibration": {
            "zero_deg": 0.0,
            "specimen_displacement_micrometre": -659.1863065396562,
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
