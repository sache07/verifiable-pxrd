#!/usr/bin/env python3
"""Build and refine a GSAS-II powder project for candidate phase models.

Run with the GSAS-II Python interpreter. Phase arguments have the form
``name=/absolute/or/relative/model.cif``.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from GSASII import GSASIIscriptable as G2


def parse_phase(spec: str) -> tuple[str, Path]:
    name, sep, path = spec.partition("=")
    if not sep or not name or not path:
        raise argparse.ArgumentTypeError("phase must be NAME=PATH")
    return name, Path(path).resolve()


def baseline_coefficients(x: np.ndarray, y: np.ndarray, degree: int) -> list[float]:
    # A low-percentile envelope provides a stable starting point; all
    # coefficients are subsequently refined by GSAS-II.
    envelope = percentile_filter(y, percentile=15, size=401, mode="nearest")
    envelope = gaussian_filter1d(envelope, sigma=80)
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, envelope, degree).tolist()


def fractions(phases, hist_name: str) -> dict[str, float]:
    masses = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][hist_name]["Scale"][0] for p in phases],
        dtype=float,
    )
    total = masses.sum()
    return {p.name: float(m / total) for p, m in zip(phases, masses)} if total > 0 else {}


def report(stage: str, project, hist, phases) -> None:
    cov = project.data.get("Covariance", {}).get("data", {})
    print(f"STAGE {stage} Rwp={hist.get_wR():.6f} GOF={cov.get('GOF', float('nan')):.6f}")
    print("  fractions", fractions(phases, hist.name))
    inst = hist.data["Instrument Parameters"][0]
    print(
        "  instrument",
        {k: inst[k][1] for k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]},
    )
    sample = hist.SampleParameters
    print(
        "  sample",
        {k: sample[k][0] for k in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]},
    )
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        print(
            f"  {phase.name}",
            phase.get_cell(),
            "scale", hap["Scale"][0],
            "size", hap["Size"][:3],
            "mustrain", hap["Mustrain"][:4],
            "MD", hap["Pref.Ori."][:4],
        )


def refine(project, hist, phases, stage: str) -> None:
    project.refine(makeBack=False)
    report(stage, project, hist, phases)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+", type=parse_phase)
    parser.add_argument("--background", type=int, default=12)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--atoms", choices=["none", "heavy", "all"], default="none")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--polarization", action="store_true")
    args = parser.parse_args()

    root = Path.cwd()
    datafile = root / ".tmp" / "pattern.xye"
    instrument = root / "instrument.instprm"
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    raw = np.loadtxt(root / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    x, y = raw.T
    if not datafile.exists():
        np.savetxt(datafile, np.column_stack([x, y, np.sqrt(np.maximum(y, 1))]), fmt="%.8f")

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(output))
    phases = [
        project.add_phase(str(path), phasename=name, fmthint="CIF") for name, path in args.phases
    ]
    hist = project.add_powder_histogram(
        str(datafile), str(instrument), phases=phases, fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background,
                "coeffs": baseline_coefficients(x, y, args.background - 1),
                "refine": True,
            }
        }
    )
    for phase in phases:
        phase.data["Histograms"][hist.name]["Scale"][0] = 1.0
        phase.setSampleProfile(hist.name, "size", "isotropic", 0.08)
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", 3000.0)
        phase.set_HAP_refinements({"Scale": True})

    project.set_Controls("cycles", args.cycles)
    # These are the frozen laboratory's physically allowed generation ranges.
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.1),
        ":0:Polariz.": (0.5, 1.0),
    }
    for phase in phases:
        bounds[f"{phase.id}:0:Scale"] = (0.0, 1000.0)
        bounds[f"{phase.id}:0:Size;i"] = (0.04, 1.5)
        bounds[f"{phase.id}:0:Mustrain;i"] = (0.0, 8000.0)
    for variable, (lower, upper) in bounds.items():
        project.set_Controls("parmMin", lower, variable)
        project.set_Controls("parmMax", upper, variable)
    refine(project, hist, phases, "scale_background")

    # Determine the angle-dependent specimen displacement before allowing the
    # cells to absorb a common peak-position error. Zero is held at the valid
    # gauge value 0 because Zero, Shift and the overall cell scale are nearly
    # linearly dependent for a single Bragg-Brentano scan.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, hist, phases, "shift")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, hist, phases, "cells")

    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine(project, hist, phases, "size")

    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, hist, phases, "microstrain")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, hist, phases, "instrument_profile")

    if args.roughness:
        hist.SampleParameters["SurfRoughA"] = [0.1, False]
        hist.SampleParameters["SurfRoughB"] = [0.1, False]
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        refine(project, hist, phases, "roughness")

    if args.polarization:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        refine(project, hist, phases, "polarization")

    if args.atoms != "none":
        for phase in phases:
            selected = {}
            for atom in phase.atoms():
                if args.atoms == "all" or atom.element not in {"O", "H"}:
                    selected[atom.label] = "X"
            if selected:
                phase.set_refinements({"Atoms": selected})
        refine(project, hist, phases, f"atoms_{args.atoms}")

    # A final pass ensures all active variables are jointly converged.
    refine(project, hist, phases, "final")
    project.save(str(output))


if __name__ == "__main__":
    main()
