#!/usr/bin/env python3
"""Bounded direct optimization of a replayable GSAS-II powder profile.

Nonlinear parameters are optimized against freshly regenerated GSAS-II
profiles. At every evaluation, phase scales and Chebyshev background
coefficients are solved as linear weighted least-squares parameters. This
avoids GSAS-II's boundary-freezing behavior while retaining its exact atomic
structure factors and peak-shape implementation.
"""

from __future__ import annotations

import argparse
import copy
import pickle
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares, lsq_linear
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as LAT
from GSASII import GSASIIstrIO as IO
from GSASII import GSASIIstrMath as M


def parse_axis(spec: str):
    name, sep, values = spec.partition(":")
    if not sep:
        raise argparse.ArgumentTypeError("expected PHASE:h,k,l")
    try:
        axis = [int(v) for v in values.split(",")]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("axis entries must be integers") from exc
    if len(axis) != 3 or not any(axis):
        raise argparse.ArgumentTypeError("axis must be a nonzero h,k,l triple")
    return name, axis


def prepare(gpx: Path, observed: Path):
    public = np.loadtxt(observed, delimiter=",", skiprows=1)
    x, y = public.T
    histograms, phases = IO.GetUsedHistogramsAndPhases(str(gpx))
    candidates = []
    for name, hist in histograms.items():
        xx, yy = np.asarray(hist["Data"][0]), np.asarray(hist["Data"][1])
        if xx.shape == x.shape and np.allclose(xx, x, atol=1e-7, rtol=0) and np.allclose(yy, y, atol=1e-5, rtol=0):
            candidates.append(name)
    if len(candidates) != 1:
        raise RuntimeError(f"expected one matching histogram, found {candidates}")
    name = candidates[0]
    histogram = histograms[name]
    histograms = {name: histogram}
    histogram["Limits"] = [[float(x[0]), float(x[-1])], [float(x[0]), float(x[-1])]]

    controls = dict(IO.GetControls(str(gpx)))
    controls.pop("PhasePartials", None)
    rigid = IO.GetRigidBodies(str(gpx))
    ids = rigid.get("RBIds", {"Vector": [], "Residue": []})
    _, rb = IO.GetRigidBodyModels(rigid, Print=False)
    natoms, atomidx, _, phase, pawley, ff, ef, orb, bl, mf, maxss = IO.GetPhaseData(
        phases, {}, ids, Print=False
    )
    controls.update(
        atomIndx=atomidx,
        Natoms=natoms,
        FFtables=ff,
        EFtables=ef,
        ORBtables=orb,
        BLtables=bl,
        MFtables=mf,
        maxSSwave=maxss,
    )
    _, hap, extra = IO.GetHistogramPhaseData(phases, histograms, Controls=controls, Print=False)
    controls.update(extra)
    _, hp, hist1, extra = IO.GetHistogramData(histograms, Print=False)
    controls.update(extra)
    parameters = {**rb, **phase, **hap, **hp}
    IO.GetFprime(controls, histograms)
    return x, y, name, histogram, phases, controls, pawley, hist1, parameters


def read_partials(path: Path):
    rows = []
    with path.open("rb") as stream:
        while True:
            try:
                key = pickle.load(stream)
                value = pickle.load(stream)
            except EOFError:
                break
            if isinstance(key, str):
                rows.append((key, np.asarray(value, dtype=float)))
    return rows


def weighted_linear_fit(y, root_weight, profiles, background_basis):
    design = np.column_stack([*profiles, background_basis])
    weighted = design * root_weight[:, None]
    target = y * root_weight
    nphase = len(profiles)
    lower = np.r_[np.zeros(nphase), np.full(background_basis.shape[1], -np.inf)]
    upper = np.full(design.shape[1], np.inf)
    solved = lsq_linear(weighted, target, bounds=(lower, upper), method="bvls", tol=1e-10, max_iter=200)
    calculated = design @ solved.x
    return solved.x, calculated


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--max-nfev", type=int, default=80)
    ap.add_argument("--cells", action="store_true")
    ap.add_argument("--roughness", action="store_true")
    ap.add_argument("--keep-roughness", action="store_true",
                    help="retain supplied roughness values without fitting them")
    ap.add_argument("--uiso", action="store_true",
                    help="fit one common isotropic displacement parameter per phase")
    ap.add_argument("--texture", action="append", type=parse_axis, default=[])
    ap.add_argument("--uniaxial-strain", action="append", type=parse_axis, default=[])
    ap.add_argument("--no-profile", action="store_true")
    args = ap.parse_args()

    source = args.input.resolve()
    output = args.output.resolve()
    observed = (Path.cwd() / "inputs" / "pattern.csv").resolve()

    # Configure discrete texture-axis choices in the project before extracting
    # the native GSAS parameter dictionary.
    project = G2.G2Project(gpxfile=str(source))
    histogram_obj = project.histograms()[0]
    phase_objects = {p.name: p for p in project.phases()}
    for name, axis in args.texture:
        hap = phase_objects[name].data["Histograms"][histogram_obj.name]
        hap["Pref.Ori."][0] = "MD"
        ratio = float(hap["Pref.Ori."][1])
        hap["Pref.Ori."][1] = ratio if 0.7 < ratio < 1.4 else 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = axis
    for name, axis in args.uniaxial_strain:
        phase = phase_objects[name]
        hap = phase.data["Histograms"][histogram_obj.name]
        equatorial = max(1.0, float(hap["Mustrain"][1][0]))
        axial = equatorial
        if hap["Mustrain"][0] == "uniaxial" and len(hap["Mustrain"][1]) > 1:
            axial = max(1.0, float(hap["Mustrain"][1][1]))
        phase.setSampleProfile(
            histogram_obj.name, "microstrain", "uniaxial", equatorial, axial, axis
        )
    configured = output.with_suffix(".configured.gpx")
    project.save(str(configured))

    x, y, histogram_name, histogram, phases, controls, pawley, hist1, params = prepare(configured, observed)
    phase_names = list(phases)
    phase_ids = {name: phases[name]["pId"] for name in phase_names}
    uniaxial = dict(args.uniaxial_strain)
    root_weight = 1 / np.sqrt(np.maximum(y, 1.0))
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    nback = histogram["Background"][0][2]
    background_basis = np.polynomial.chebyshev.chebvander(t, nback - 1)
    partial_path = output.with_suffix(".partials")

    names = []
    initial = []
    lower = []
    upper = []

    def add(name, value, lo, hi):
        names.append(name)
        initial.append(float(value))
        lower.append(float(lo))
        upper.append(float(hi))

    # A zero value is a valid gauge for the near-degenerate Zero/Shift/cell
    # combination. Shift retains the physically meaningful angular dependence.
    add(":0:Shift", params[":0:Shift"], -800.0, 800.0)
    if not args.no_profile:
        starts = {":0:U": 15.0, ":0:W": 20.0, ":0:X": 2.0}
        for key, lo, hi in [(":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0), (":0:X", 0.1, 6.0)]:
            add(key, starts[key] if not lo < params[key] < hi else params[key], lo, hi)
        add(":0:SH/L", params[":0:SH/L"], 0.005, 0.1)
        add(":0:Polariz.", params[":0:Polariz."], 0.5, 1.0)
        for name in phase_names:
            pid = phase_ids[name]
            skey, mkey = f"{pid}:0:Size;i", f"{pid}:0:Mustrain;i"
            size0 = params[skey] if 0.04 < params[skey] < 1.5 else 0.08
            strain0 = params[mkey] if 0.0 < params[mkey] < 8000.0 else 2000.0
            add(skey, size0, 0.04, 1.5)
            add(mkey, strain0, 0.0, 8000.0)
            if name in uniaxial:
                akey = f"{pid}:0:Mustrain;a"
                axial0 = params[akey] if 0.0 < params[akey] < 32000.0 else strain0
                add(akey, axial0, 0.0, 32000.0)
    else:
        # For rapid discrete-axis screening, optimize only the equatorial and
        # axial microstrain components while retaining the supplied profile.
        for name, _axis in args.uniaxial_strain:
            pid = phase_ids[name]
            ikey, akey = f"{pid}:0:Mustrain;i", f"{pid}:0:Mustrain;a"
            add(ikey, params[ikey], 0.0, 8000.0)
            add(akey, params[akey], 0.0, 32000.0)
    if args.roughness:
        rough_a = params[":0:SurfRoughA"]
        rough_b = params[":0:SurfRoughB"]
        add(":0:SurfRoughA", rough_a if 0.05 < rough_a < 0.6 else 0.3, 0.05, 0.6)
        add(":0:SurfRoughB", rough_b if 0.02 < rough_b < 0.5 else 0.1, 0.02, 0.5)
    elif not args.keep_roughness:
        params[":0:SurfRoughA"] = 0.0
        params[":0:SurfRoughB"] = 0.0
    for name, _axis in args.texture:
        pid = phase_ids[name]
        ratio = params[f"{pid}:0:MD"]
        add(f"{pid}:0:MD", ratio if 0.7 < ratio < 1.4 else 1.0, 0.7, 1.4)
    if args.uiso:
        for name in phase_names:
            pid = phase_ids[name]
            values = [value for key, value in params.items() if key.startswith(f"{pid}::AUiso:")]
            value = float(np.mean(values))
            add(f"@Uiso:{name}", value if 0.003 < value < 0.02 else 0.01, 0.003, 0.02)
    if args.cells:
        for name in phase_names:
            pid = phase_ids[name]
            for index in (0, 1, 2, 4):
                key = f"{pid}::A{index}"
                value = params[key]
                width = max(abs(value) * 0.015, 5e-5)
                add(key, value, value - width, value + width)

    initial = np.asarray(initial)
    lower = np.asarray(lower)
    upper = np.asarray(upper)
    best = {"cost": np.inf, "x": None, "linear": None, "calculated": None, "evaluations": 0}
    cache = {"x": None, "result": None}

    # Set linear terms to neutral values; each evaluation solves them afresh.
    for name in phase_names:
        params[f"{phase_ids[name]}:0:Scale"] = 1.0
    for i in range(nback):
        params[f":0:Back;{i}"] = 0.0
    controls["PhasePartials"] = str(partial_path)

    def set_nonlinear_parameter(key, value):
        value = float(value)
        if key.startswith("@Uiso:"):
            phase_name = key.split(":", 1)[1]
            pid = phase_ids[phase_name]
            atom_keys = [entry for entry in params if entry.startswith(f"{pid}::AUiso:")]
            for atom_key in atom_keys:
                params[atom_key] = value
        else:
            params[key] = value

    def evaluate(vector):
        if cache["x"] is not None and np.array_equal(vector, cache["x"]):
            return cache["result"]
        for key, value in zip(names, vector):
            set_nonlinear_parameter(key, value)
        partial_path.write_bytes(b"")
        M.getPowderProfile(params, hist1, x, [], histogram, phases, controls, pawley, histogram_name)
        partial_rows = dict(read_partials(partial_path))
        profiles = [partial_rows[name] for name in phase_names]
        linear, calculated = weighted_linear_fit(y, root_weight, profiles, background_basis)
        residual = (calculated - y) * root_weight
        cost = float(residual @ residual)
        best["evaluations"] += 1
        if cost < best["cost"]:
            best.update(cost=cost, x=np.array(vector), linear=np.array(linear), calculated=calculated)
            rwp = 100 * np.sqrt(cost / np.sum(y))
            print(f"best eval={best['evaluations']} Rwp={rwp:.6f}", dict(zip(names, vector)), flush=True)
        cache["x"] = np.array(vector)
        cache["result"] = residual
        return residual

    result = least_squares(
        evaluate,
        initial,
        bounds=(lower, upper),
        x_scale="jac",
        diff_step=2e-4,
        max_nfev=args.max_nfev,
        verbose=2,
        ftol=1e-7,
        xtol=1e-7,
        gtol=1e-7,
    )
    evaluate(result.x)

    for key, value in zip(names, best["x"]):
        set_nonlinear_parameter(key, value)
    linear = best["linear"]
    phase_scales = linear[: len(phase_names)]
    back_coeffs = linear[len(phase_names) :]

    # Transfer the optimum into normal scriptable project fields.
    project = G2.G2Project(gpxfile=str(configured))
    hist_obj = project.histograms()[0]
    phase_obj_by_name = {p.name: p for p in project.phases()}
    inst = hist_obj.data["Instrument Parameters"][0]
    hist_obj.SampleParameters["Shift"][0] = params[":0:Shift"]
    hist_obj.SampleParameters["SurfRoughA"][0] = params[":0:SurfRoughA"]
    hist_obj.SampleParameters["SurfRoughB"][0] = params[":0:SurfRoughB"]
    for key in ("U", "W", "X", "SH/L", "Polariz."):
        inst[key][1] = params[f":0:{key}"]
    hist_obj.data["Background"][0][3:] = back_coeffs.tolist()
    for name, scale in zip(phase_names, phase_scales):
        phase = phase_obj_by_name[name]
        pid = phase.id
        hap = phase.data["Histograms"][hist_obj.name]
        hap["Scale"][0] = float(scale)
        if not args.no_profile:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = params[f"{pid}:0:Size;i"]
        if not args.no_profile or name in uniaxial:
            if name in uniaxial:
                hap["Mustrain"][0] = "uniaxial"
                hap["Mustrain"][1][0] = params[f"{pid}:0:Mustrain;i"]
                hap["Mustrain"][1][1] = params[f"{pid}:0:Mustrain;a"]
                hap["Mustrain"][3] = uniaxial[name]
            else:
                hap["Mustrain"][0] = "isotropic"
                hap["Mustrain"][1][0] = params[f"{pid}:0:Mustrain;i"]
        if any(texture_name == name for texture_name, _ in args.texture):
            hap["Pref.Ori."][1] = params[f"{pid}:0:MD"]
        if args.uiso:
            value = params[f"{pid}::AUiso:0"]
            for atom in phase.atoms():
                atom.uiso = value
        if args.cells:
            avec = [params[f"{pid}::A{i}"] for i in range(6)]
            cell = list(LAT.A2cell(avec))
            volume = float(LAT.calc_V(avec))
            phase.data["General"]["Cell"][1:8] = [*cell, volume]

    # Clear every refinement flag: final replay uses values, not flags, and a
    # zero-cycle calculation should not alter the bounded optimum.
    hist_obj.data["Background"][0][1] = False
    for value in hist_obj.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key in ("Shift", "SurfRoughA", "SurfRoughB"):
        hist_obj.SampleParameters[key][1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 0)
    project.save(str(output))
    project.refine(makeBack=False)
    project.save(str(output))

    final = G2.G2Project(gpxfile=str(output))
    fh = final.histograms()[0]
    masses = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][fh.name]["Scale"][0] for p in final.phases()]
    )
    masses /= masses.sum()
    print("FINAL", {"Rwp": fh.get_wR(), "fractions": dict(zip([p.name for p in final.phases()], masses.tolist())),
                    "optimizer": result.message, "evaluations": best["evaluations"]})


if __name__ == "__main__":
    main()
