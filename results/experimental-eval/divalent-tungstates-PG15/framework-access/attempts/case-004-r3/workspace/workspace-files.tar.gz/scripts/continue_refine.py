#!/usr/bin/env python3
"""Continue selected, physically interpretable refinements in an existing GPX."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def phase_fractions(phases, histogram):
    values = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][histogram.name]["Scale"][0] for p in phases]
    )
    values /= values.sum()
    return {p.name: float(v) for p, v in zip(phases, values)}


def parse_axis(spec: str):
    name, sep, axis = spec.partition(":")
    if not sep:
        raise argparse.ArgumentTypeError("axis must be PHASE:h,k,l")
    try:
        hkl = [int(v) for v in axis.split(",")]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("axis must contain integers") from exc
    if len(hkl) != 3 or not any(hkl):
        raise argparse.ArgumentTypeError("axis must be a nonzero h,k,l triple")
    return name, hkl


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--cycles", type=int, default=6)
    ap.add_argument("--roughness", action="store_true")
    ap.add_argument("--roughness-fixed", nargs=2, type=float, metavar=("A", "B"))
    ap.add_argument("--polarization", action="store_true")
    ap.add_argument("--polarization-fixed", type=float)
    ap.add_argument("--shift", action="store_true")
    ap.add_argument("--cells", action="store_true")
    ap.add_argument("--atoms", choices=["none", "heavy", "all"], default="none")
    ap.add_argument("--texture", action="append", type=parse_axis, default=[])
    ap.add_argument("--uniaxial-strain", action="append", type=parse_axis, default=[])
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    histogram = project.histograms()[0]
    phases = project.phases()
    by_name = {p.name: p for p in phases}

    # Remove stale parameter-limit freezes and begin from a controlled set of
    # active variables. Values already fitted in the input project are retained.
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}
    histogram.clear_refinements(
        {"Instrument Parameters": ["Zero", "Polariz.", "U", "W", "X", "SH/L"]}
    )
    histogram.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})

    if args.shift:
        histogram.set_refinements({"Sample Parameters": ["Shift"]})
    if args.cells:
        for phase in phases:
            phase.set_refinements({"Cell": True})
    if args.roughness:
        histogram.SampleParameters["SurfRoughA"] = [0.25, False]
        histogram.SampleParameters["SurfRoughB"] = [0.08, False]
        histogram.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    elif args.roughness_fixed:
        histogram.SampleParameters["SurfRoughA"] = [args.roughness_fixed[0], False]
        histogram.SampleParameters["SurfRoughB"] = [args.roughness_fixed[1], False]
    if args.polarization:
        histogram.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif args.polarization_fixed is not None:
        histogram.data["Instrument Parameters"][0]["Polariz."][1] = args.polarization_fixed
    if args.atoms != "none":
        for phase in phases:
            selected = {}
            for atom in phase.atoms():
                if args.atoms == "all" or atom.element not in {"O", "H"}:
                    selected[atom.label] = "X"
            phase.set_refinements({"Atoms": selected})
    for name, axis in args.texture:
        phase = by_name[name]
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = axis
        phase.set_HAP_refinements({"Pref.Ori.": True})
    for name, axis in args.uniaxial_strain:
        phase = by_name[name]
        hap = phase.data["Histograms"][histogram.name]
        current = max(0.0, float(hap["Mustrain"][1][0]))
        phase.setSampleProfile(histogram.name, "microstrain", "uniaxial", current, current, axis)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "refine": True, "direction": axis}}
        )

    project.set_Controls("cycles", args.cycles)
    project.save(str(args.output.resolve()))
    project.refine(makeBack=False)
    project.save(str(args.output.resolve()))

    project = G2.G2Project(gpxfile=str(args.output.resolve()))
    histogram = project.histograms()[0]
    phases = project.phases()
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    print("Rwp", histogram.get_wR(), "GOF", rvals.get("GOF"), "Nvars", rvals.get("Nvars"))
    print("fractions", phase_fractions(phases, histogram))
    print("sample", histogram.SampleParameters)
    print("instrument", histogram.data["Instrument Parameters"][0])
    for phase in phases:
        hap = phase.data["Histograms"][histogram.name]
        print(phase.name, phase.get_cell(), "scale", hap["Scale"], "MD", hap["Pref.Ori."],
              "size", hap["Size"], "mustrain", hap["Mustrain"])


if __name__ == "__main__":
    main()
