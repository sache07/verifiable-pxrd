from pathlib import Path

import numpy as np


root = Path(__file__).resolve().parent
observed = np.genfromtxt(root / "inputs" / "pattern.csv", delimiter=",", names=True)
replayed = np.load(root / ".tmp" / "replay-check" / "prediction.npz")

x_observed = observed["two_theta_deg"]
y_observed = observed["intensity"]
x_replayed = replayed["x"]
y_replayed = replayed["observed"]
y_calculated = replayed["predicted"]

if not np.array_equal(x_observed, x_replayed):
    raise RuntimeError("Replay grid differs from inputs/pattern.csv")
if not np.array_equal(y_observed, y_replayed):
    raise RuntimeError("Replay observations differ from inputs/pattern.csv")
if not np.all(np.isfinite(y_calculated)):
    raise RuntimeError("Replay produced non-finite calculated intensities")

np.savetxt(
    root / "fit.csv",
    np.column_stack((x_observed, y_observed, y_calculated, y_observed - y_calculated)),
    delimiter=",",
    header="two_theta,observed,calculated,difference",
    comments="",
    fmt=("%.8f", "%.8f", "%.12g", "%.12g"),
)

weights = 1.0 / np.maximum(y_observed, 1.0)
rwp = 100.0 * np.sqrt(
    np.sum(weights * (y_observed - y_calculated) ** 2)
    / np.sum(weights * y_observed**2)
)
print(f"rows={len(x_observed)} rwp_percent={rwp:.12f}")
