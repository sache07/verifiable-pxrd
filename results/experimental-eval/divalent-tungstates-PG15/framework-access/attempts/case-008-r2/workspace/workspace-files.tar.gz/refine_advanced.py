#!/usr/bin/env python3
"""Explore physically motivated refinements from the initial MnWO4 project."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def open_copy(source, dest):
    return G2.G2Project(gpxfile=str(ROOT / source), newgpx=str(ROOT / dest))


def report(project, label):
    h = project.histogram(0)
    p = project.phase(0)
    hap = p.data["Histograms"][h.name]
    row = {
        "label": label,
        "file": Path(project.filename).name,
        "rwp": h.residuals.get("wR"),
        "gof": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "cell": p.get_cell(),
        "zero": h.InstrumentParameters["Zero"][1],
        "shift": h.SampleParameters["Shift"][0],
        "roughA": h.SampleParameters["SurfRoughA"][0],
        "roughB": h.SampleParameters["SurfRoughB"][0],
        "polarization": h.InstrumentParameters["Polariz."][1],
        "profile": {k: h.InstrumentParameters[k][1] for k in ["U", "W", "X", "SH/L"]},
        "size": hap["Size"][1],
        "mustrain": hap["Mustrain"][1],
        "orientation": hap["Pref.Ori."][:4],
        "atoms": [
            {
                "label": a.label,
                "element": a.element,
                "xyz": a.coordinates,
                "flag": a.adp_flag,
                "adp": a.ADP,
                "refine": a.refinement_flags,
            }
            for a in p.atoms()
        ],
    }
    print("ADVANCED_SUMMARY " + json.dumps(row, default=float))
    return row


def run(project, label, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    return report(project, label)


def clean_base():
    project = open_copy("trial.gpx", "advanced_base.gpx")
    h, p = project.histogram(0), project.phase(0)
    h.set_refinements({"Limits": [9.90343322, 100.09488522]})
    # Size/X and isotropic strain/U have nearly exact one-phase correlations.
    # Preserve their current combined broadening while fixing the specimen terms.
    p.clear_HAP_refinements({"Size": True, "Mustrain": True})
    project.save()
    return run(project, "clean_full_range")


def roughness_trials():
    trials = []
    # Different starts are useful because the two Suortti parameters are nonlinear.
    for i, (a, b) in enumerate([(0.10, 0.03), (0.20, 0.08), (0.35, 0.12), (0.50, 0.25), (0.60, 0.45)]):
        name = f"rough_{i}.gpx"
        project = open_copy("advanced_base.gpx", name)
        h = project.histogram(0)
        h.SampleParameters["SurfRoughA"] = [a, True]
        h.SampleParameters["SurfRoughB"] = [b, True]
        project.save()
        trials.append(run(project, f"rough_start_{a}_{b}"))
    best = min(trials, key=lambda x: x["rwp"])
    print("ADVANCED_BEST_ROUGH " + json.dumps(best))
    return best["file"]


def coordinate_and_uiso(source):
    project = open_copy(source, "advanced_coords.gpx")
    phase = project.phase(0)
    # The generator uses one isotropic Uiso per phase. Convert the anisotropic
    # single-crystal parent values to that model before refining coordinates.
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.010
        atom.refinement_flags = "X"
    project.save()
    run(project, "coordinates")

    phase = project.phase(0)
    for atom in phase.atoms():
        atom.refinement_flags = "XU"
    project.add_EquivConstr(tuple(f"0::AUiso:{i}" for i in range(len(phase.atoms()))))
    project.set_Controls("parmMin", 0.001, variable="0::AUiso:0")
    project.set_Controls("parmMax", 0.05, variable="0::AUiso:0")
    project.save()
    run(project, "coordinates_common_uiso")
    return "advanced_coords.gpx"


def orientation_trials(source):
    trials = []
    # Retain a no-orientation reference for model-selection comparison.
    ref = open_copy(source, "orientation_none.gpx")
    ref.phase(0).clear_HAP_refinements({"Pref.Ori.": True})
    ref.save()
    trials.append(run(ref, "orientation_none"))
    for i, axis in enumerate(([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])):
        name = f"orientation_{i}.gpx"
        project = open_copy(source, name)
        phase, hist = project.phase(0), project.histogram(0)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.05
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        project.save()
        trials.append(run(project, "orientation_" + "".join(map(str, axis))))
    best = min(trials, key=lambda x: x["rwp"])
    print("ADVANCED_BEST_ORIENTATION " + json.dumps(best))
    return best["file"]


def main():
    G2.SetPrintLevel("error")
    clean_base()
    rough = roughness_trials()
    coords = coordinate_and_uiso(rough)
    orientation_trials(coords)


if __name__ == "__main__":
    main()
