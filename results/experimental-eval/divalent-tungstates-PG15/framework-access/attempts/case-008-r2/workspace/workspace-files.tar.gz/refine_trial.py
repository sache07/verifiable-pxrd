#!/usr/bin/env python3
"""Build and iteratively refine a trial MnWO4 GSAS-II project."""

from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "inputs" / "pattern.csv"
SOURCE_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)


def prepare_inputs():
    arr = np.loadtxt(DATA, delimiter=",", skiprows=1)
    sigma = np.sqrt(np.maximum(arr[:, 1], 1.0))
    np.savetxt(ROOT / "pattern.xye", np.column_stack((arr, sigma)), fmt="%.10g")
    (ROOT / "trial.instprm").write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha laboratory data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def summary(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "step": label,
        "residuals": hist.residuals,
        "cell": phase.get_cell(),
        "instrument": {k: v for k, v in inst.items() if k in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]},
        "sample": {k: sample.get(k) for k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type"]},
        "hap": {k: hap.get(k) for k in ["Scale", "Size", "Mustrain", "Pref.Ori."]},
        "varyList": [str(v) for v in cov.get("varyList", [])],
        "variables": list(map(float, cov.get("variables", []))),
        "sig": list(map(float, cov.get("sig", []))),
        "Rvals": cov.get("Rvals", {}),
    }
    print("TRIAL_SUMMARY " + json.dumps(result, default=str))


def refine(project, label):
    project.set_Controls("cycles", 10)
    project.refine()
    summary(project, label)


def main():
    G2.SetPrintLevel("warn")
    prepare_inputs()
    project = G2.G2Project(newgpx=str(ROOT / "trial.gpx"))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"), str(ROOT / "trial.instprm"), fmthint="Topas"
    )
    phase = project.add_phase(
        str(SOURCE_CIF), phasename="MnWO4_wolframite", histograms=[hist], fmthint="CIF"
    )

    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 10,
            "coeffs": [1000.0] + [0.0] * 9,
            "refine": True,
        },
    })
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][1][1] = 500.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]

    project.save()
    summary(project, "initial")

    refine(project, "background_scale")

    hist = project.histogram(0)
    phase = project.phase(0)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "zero_shift")

    phase.set_refinements({"Cell": True})
    refine(project, "cell")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "instrument_profile")

    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 1.0, "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    refine(project, "size_strain")

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "polarization")

    project.save()


if __name__ == "__main__":
    main()
