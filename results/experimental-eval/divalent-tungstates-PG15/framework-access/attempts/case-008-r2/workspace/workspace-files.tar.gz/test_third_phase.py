#!/usr/bin/env python3
"""Check whether any chemically plausible third phase has supported scale."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = {
    "MnO": "1514231",
    "Mn3O4": "9001963",
    "Mn2O3": "1514230",
    "Mn3WO6": "2002703",
    "WO3_P21m": "1010618",
    "WO3_Pnma": "2107312",
}


def cif(cid):
    return COD / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def main():
    G2.SetPrintLevel("error")
    rows = []
    for label, cid in CANDIDATES.items():
        project = G2.G2Project(gpxfile=str(ROOT / "two_cell.gpx"), newgpx=str(ROOT / f"third_{label}.gpx"))
        h = project.histogram(0)
        p = project.add_phase(str(cif(cid)), phasename=label, histograms=[h], fmthint="CIF")
        primary = project.phase(0)
        m0 = float(primary.data["General"]["Mass"])
        s0 = float(primary.data["Histograms"][h.name]["Scale"][0])
        m2 = float(p.data["General"]["Mass"])
        hap = p.data["Histograms"][h.name]
        hap["Scale"] = [s0 * m0 / m2 * 0.005 / 0.995, True]
        hap["Size"][0] = "isotropic"; hap["Size"][1][0] = 0.5; hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"; hap["Mustrain"][1][0] = 1000.; hap["Mustrain"][2] = [False, False, False]
        project.set_Controls("parmMin", 0.0, variable="2:0:Scale")
        project.set_Controls("cycles", 12)
        project.save(); project.refine(); project.save()
        h = project.histogram(0); phases = project.phases()
        vals = [float(q.data["General"]["Mass"]) * float(q.data["Histograms"][h.name]["Scale"][0]) for q in phases]
        row = {"label": label, "rwp": h.residuals.get("wR"), "fractions": [v/sum(vals) for v in vals],
               "scale": phases[2].data["Histograms"][h.name]["Scale"][0],
               "converged": project.data.get("Covariance",{}).get("data",{}).get("Rvals",{}).get("converged")}
        rows.append(row); print("THIRD_SUMMARY " + json.dumps(row))
    print("THIRD_RANKING")
    for row in sorted(rows,key=lambda x: x["rwp"]): print(json.dumps(row))


if __name__ == "__main__":
    main()
