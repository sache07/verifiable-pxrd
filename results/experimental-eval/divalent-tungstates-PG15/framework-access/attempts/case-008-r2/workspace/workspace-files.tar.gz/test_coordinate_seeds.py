#!/usr/bin/env python3
"""Test wolframite coordinate-refinement robustness from independent starts."""

from pathlib import Path
import json
import random

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent

# Coordinates in the same P2/c setting, ordered Mn, W, O1, O2.
SEEDS = {
    "Mn_parent": [(0.5, .6846, .25), (0., .18116, .25), (.2124, .1000, .9432), (.2498, .3780, .3937)],
    "Mg_analogue": [(0.5, .6742, .25), (0., .1819, .25), (.2160, .1070, .9370), (.2560, .3766, .3970)],
    "Zn_analogue": [(0.5, .6840, .25), (0., .18258, .25), (.2169, .1051, .9363), (.2565, .3777, .3996)],
    "Cd_analogue": [(0.5, .69729, .25), (0., .17855, .25), (.2018, .0955, .9504), (.2420, .3703, .3839)],
}


def main():
    G2.SetPrintLevel("error")
    rng = random.Random(982451653)
    parent = SEEDS["Mn_parent"]
    for k in range(6):
        coords = []
        for i, xyz in enumerate(parent):
            if i < 2:
                coords.append((xyz[0], xyz[1] + rng.uniform(-.010, .010), xyz[2]))
            else:
                coords.append(tuple(v + rng.uniform(-.010, .010) for v in xyz))
        SEEDS[f"random_{k}"] = coords

    rows = []
    for label, coords in SEEDS.items():
        project = G2.G2Project(gpxfile=str(ROOT / "two_cell.gpx"), newgpx=str(ROOT / f"coordseed_{label}.gpx"))
        phase = project.phase(0)
        for atom, xyz in zip(phase.atoms(), coords):
            atom.coordinates = xyz
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = .005
            atom.refinement_flags = "XU"
        project.set_Controls("parmMin", .003, variable="0::AUiso:0")
        project.set_Controls("parmMax", .020, variable="0::AUiso:0")
        project.set_Controls("cycles", 20)
        project.save(); project.refine(); project.save()
        h, phase = project.histogram(0), project.phase(0)
        amounts = [float(p.data["General"]["Mass"]) * float(p.data["Histograms"][h.name]["Scale"][0]) for p in project.phases()]
        row = {"label": label, "file": Path(project.filename).name, "rwp": h.residuals.get("wR"),
               "fractions": [v/sum(amounts) for v in amounts],
               "coords": [a.coordinates for a in phase.atoms()], "uiso": [a.ADP for a in phase.atoms()],
               "converged": project.data.get("Covariance",{}).get("data",{}).get("Rvals",{}).get("converged")}
        rows.append(row); print("COORDSEED_SUMMARY " + json.dumps(row))
    print("COORDSEED_RANKING")
    for row in sorted(rows,key=lambda x:x["rwp"]): print(json.dumps(row))


if __name__ == "__main__":
    main()
