#!/usr/bin/env python3
"""Create final.gpx and CIF exports from the selected two-phase refinement."""

from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "sound_wo3.gpx"


def main():
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(ROOT / "final.gpx"))
    project.save()
    hist = project.histogram(0)
    phases = project.phases()
    values = [float(p.data["General"]["Mass"]) * float(p.data["Histograms"][hist.name]["Scale"][0]) for p in phases]
    fractions = [v / sum(values) for v in values]

    # Export full-precision saved atoms rather than values reconstructed from
    # the covariance matrix. This mirrors the independent replay verifier.
    exported = G2.G2Project(gpxfile=str(ROOT / "final.gpx"))
    exported.data["Covariance"]["data"] = {}
    cif_names = ["phase_mnwo4.cif", "phase_wo3.cif"]
    for phase, name in zip(exported.phases(), cif_names):
        phase.export_CIF(str(ROOT / name))

    x_input, y_input = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1).T
    arrays = hist.data["data"][1]
    x, y, weight, calc, background = [np.asarray(v, float) for v in arrays[:5]]
    if not np.allclose(x, x_input, rtol=0, atol=1e-7) or not np.array_equal(y, y_input):
        raise RuntimeError("Final project histogram differs from the original observations")
    rwp = float(100 * np.sqrt(np.sum((y - calc) ** 2 / np.maximum(y, 1.0)) / np.sum(y * y / np.maximum(y, 1.0))))
    if not np.isfinite(calc).all() or np.min(calc) < 0 or np.min(background) < 0:
        raise RuntimeError("Final calculated profile or background is invalid")

    cov = project.data.get("Covariance", {}).get("data", {})
    info = {
        "project": "final.gpx",
        "histogram": hist.name,
        "cifs": cif_names,
        "fractions": fractions,
        "histogram_residuals": hist.residuals,
        "recomputed_rwp_percent": rwp,
        "covariance_rvals": cov.get("Rvals", {}),
        "cells": [p.get_cell() for p in phases],
        "profile_min": float(np.min(calc)),
        "background_min": float(np.min(background)),
    }
    print("FINAL_PREP " + json.dumps(info, default=float))


if __name__ == "__main__":
    main()
