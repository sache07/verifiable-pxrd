#!/usr/bin/env python3
"""Build a stable, physically bounded two-phase refinement and test minor broadening."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "secondary_fixed_WO3_P21c_1528915.gpx"


def copy_project(source, dest):
    return G2.G2Project(gpxfile=str(ROOT / source), newgpx=str(ROOT / dest))


def summary(project, label):
    h = project.histogram(0)
    phases = project.phases()
    amounts = [float(p.data["General"]["Mass"]) * float(p.data["Histograms"][h.name]["Scale"][0]) for p in phases]
    fracs = [v / sum(amounts) for v in amounts]
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "label": label,
        "file": Path(project.filename).name,
        "rwp": h.residuals.get("wR"),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "converged": cov.get("Rvals", {}).get("converged"),
        "fractions": fracs,
        "instrument": {k: h.InstrumentParameters[k][1] for k in ["Zero", "Polariz.", "U", "W", "X", "SH/L"]},
        "sample": {k: h.SampleParameters[k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "phases": [],
    }
    for p in phases:
        hap = p.data["Histograms"][h.name]
        row["phases"].append({
            "name": p.name,
            "cell": p.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "orientation": hap["Pref.Ori."][:4],
            "uiso": [a.ADP for a in p.atoms()],
        })
    print("TWO_PHYSICAL_SUMMARY " + json.dumps(row, default=float))
    return row


def refine(project, label, cycles=16):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    return summary(project, label)


def build_base():
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(ROOT / "two_physical.gpx"))
    h, major, minor = project.histogram(0), project.phase(0), project.phase(1)

    # Resolve exact instrument/specimen correlations with a representative
    # instrument U inside the known laboratory range and phase strain terms.
    h.InstrumentParameters["U"][1] = 30.0
    h.InstrumentParameters["U"][2] = False
    h.InstrumentParameters["Polariz."][1] = max(0.50, h.InstrumentParameters["Polariz."][1])
    h.InstrumentParameters["Polariz."][2] = True
    project.set_Controls("parmMin", 0.50, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.00, variable=":0:Polariz.")

    major_ms = major.data["Histograms"][h.name]["Mustrain"]
    major_ms[0] = "uniaxial"
    major_ms[2] = [True, True, False]
    major_ms[3] = [0, 0, 1]
    project.set_Controls("parmMin", 0.0, variable="0:0:Mustrain;i")
    project.set_Controls("parmMax", 12000.0, variable="0:0:Mustrain;i")
    project.set_Controls("parmMin", 0.0, variable="0:0:Mustrain;a")
    project.set_Controls("parmMax", 12000.0, variable="0:0:Mustrain;a")

    # Keep one common, physically allowed Uiso in the major phase.
    for atom in major.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.005
        atom.refinement_flags = "XU"
    project.set_Controls("parmMin", 0.003, variable="0::AUiso:0")
    project.set_Controls("parmMax", 0.020, variable="0::AUiso:0")

    # At ~2 wt%, WO3 ADP and coordinates are not independently measurable.
    # Use the protocol's central physical Uiso and the published coordinates.
    for atom in minor.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.010
        atom.refinement_flags = ""
    minor.set_refinements({"Cell": True})
    mhap = minor.data["Histograms"][h.name]
    mhap["Size"][0] = "isotropic"
    mhap["Size"][1][0] = 0.5
    mhap["Size"][2] = [False, False, False]
    mhap["Mustrain"][0] = "isotropic"
    mhap["Mustrain"][1][0] = 1000.0
    mhap["Mustrain"][2] = [False, False, False]
    project.save()
    refine(project, "bounded_two_phase")
    return "two_physical.gpx"


def profile_trials(source):
    rows = []
    fixed = copy_project(source, "two_profile_fixed.gpx")
    fixed.phase(1).clear_HAP_refinements({"Size": True, "Mustrain": True})
    fixed.save()
    rows.append(refine(fixed, "minor_profile_fixed"))

    size = copy_project(source, "two_profile_size.gpx")
    size.phase(1).set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.5, "refine": True}})
    size.set_Controls("parmMin", 0.04, variable="1:0:Size;i")
    size.set_Controls("parmMax", 1.50, variable="1:0:Size;i")
    size.save()
    rows.append(refine(size, "minor_profile_size"))

    strain = copy_project(source, "two_profile_strain.gpx")
    strain.phase(1).set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    strain.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")
    strain.set_Controls("parmMax", 8000.0, variable="1:0:Mustrain;i")
    strain.save()
    rows.append(refine(strain, "minor_profile_strain"))

    both = copy_project(source, "two_profile_both.gpx")
    both.phase(1).set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 0.5, "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    both.set_Controls("parmMin", 0.04, variable="1:0:Size;i")
    both.set_Controls("parmMax", 1.50, variable="1:0:Size;i")
    both.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")
    both.set_Controls("parmMax", 8000.0, variable="1:0:Mustrain;i")
    both.save()
    rows.append(refine(both, "minor_profile_both"))

    best = min(rows, key=lambda r: r["rwp"])
    print("TWO_PHYSICAL_BEST " + json.dumps(best))


def main():
    G2.SetPrintLevel("error")
    base = build_base()
    profile_trials(base)


if __name__ == "__main__":
    main()
