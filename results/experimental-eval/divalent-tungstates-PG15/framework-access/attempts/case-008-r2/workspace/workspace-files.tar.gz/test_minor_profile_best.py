#!/usr/bin/env python3
"""Test WO3 broadening with instrument U/X fixed at the major-phase solution."""

from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent

def run(label,size_ref,strain_ref):
    out=ROOT/f'minorprof_{label}.gpx'
    p=G2.G2Project(gpxfile=str(ROOT/'two_minorU_0.020.gpx'),newgpx=str(out))
    h=p.histogram(0);h.InstrumentParameters['U'][2]=False;h.InstrumentParameters['X'][2]=False
    ph=p.phase(1);hap=ph.data['Histograms'][h.name]
    hap['Size'][0]='isotropic';hap['Size'][2]=[size_ref,False,False]
    hap['Mustrain'][0]='isotropic';hap['Mustrain'][2]=[strain_ref,False,False]
    if size_ref:
        p.set_Controls('parmMin',.04,variable='1:0:Size;i');p.set_Controls('parmMax',1.5,variable='1:0:Size;i')
    if strain_ref:
        p.set_Controls('parmMin',0.,variable='1:0:Mustrain;i');p.set_Controls('parmMax',8000.,variable='1:0:Mustrain;i')
    p.set_Controls('cycles',16);p.save();p.refine();p.save();h=p.histogram(0)
    vals=[float(q.data['General']['Mass'])*float(q.data['Histograms'][h.name]['Scale'][0]) for q in p.phases()]
    row={'label':label,'file':out.name,'rwp':h.residuals.get('wR'),'fractions':[v/sum(vals) for v in vals],
         'size':p.phase(1).data['Histograms'][h.name]['Size'][1][0],
         'strain':p.phase(1).data['Histograms'][h.name]['Mustrain'][1][0],
         'converged':p.data.get('Covariance',{}).get('data',{}).get('Rvals',{}).get('converged')}
    print('MINORPROF_SUMMARY '+json.dumps(row));return row
def main():
    G2.SetPrintLevel('error');rows=[]
    for args in [('fixed',False,False),('size',True,False),('strain',False,True),('both',True,True)]:rows.append(run(*args))
    print('MINORPROF_BEST '+json.dumps(min(rows,key=lambda x:x['rwp'])))
if __name__=='__main__':main()
