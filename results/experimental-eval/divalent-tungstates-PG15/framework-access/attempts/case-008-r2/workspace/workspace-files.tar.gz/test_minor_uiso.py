#!/usr/bin/env python3
"""Profile sensitivity to physically plausible fixed WO3 Uiso values."""

from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2

ROOT=Path(__file__).resolve().parent

def main():
    G2.SetPrintLevel('error')
    rows=[]
    for value in [.003,.005,.010,.015,.020]:
        out=ROOT/f'two_minorU_{value:.3f}.gpx'
        p=G2.G2Project(gpxfile=str(ROOT/'two_cell.gpx'),newgpx=str(out))
        for a in p.phase(1).atoms():
            a.data[a.cia]='I';a.data[a.cia+1]=value;a.refinement_flags=''
        p.set_Controls('cycles',16);p.save();p.refine();p.save()
        h=p.histogram(0);vals=[float(q.data['General']['Mass'])*float(q.data['Histograms'][h.name]['Scale'][0]) for q in p.phases()]
        row={'uiso':value,'file':out.name,'rwp':h.residuals.get('wR'),'fractions':[v/sum(vals) for v in vals],
             'converged':p.data.get('Covariance',{}).get('data',{}).get('Rvals',{}).get('converged')}
        rows.append(row);print('MINOR_U_SUMMARY '+json.dumps(row))
    print('MINOR_U_BEST '+json.dumps(min(rows,key=lambda x:x['rwp'])))
if __name__=='__main__':main()
