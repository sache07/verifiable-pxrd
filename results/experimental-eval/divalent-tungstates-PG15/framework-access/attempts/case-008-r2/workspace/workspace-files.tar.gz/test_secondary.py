#!/usr/bin/env python3
"""Screen chemically allowed secondary phases in explicit GSAS-II refinements."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

CANDIDATES = {
    "Mn3WO6_2002703": "2002703",
    "MnO_1514108": "1514108",
    "MnO_1514231": "1514231",
    "Mn3O4_9001963": "9001963",
    "Mn2O3_1514230": "1514230",
    "WO3_hex_1004057": "1004057",
    "WO3_P21m_1010618": "1010618",
    "WO3_tet_1521532": "1521532",
    "WO3_tet_1521533": "1521533",
    "WO3_P21c_1528915": "1528915",
    "WO3_P21c_1563541": "1563541",
    "WO3_P21c_2311041": "2311041",
    "WO3_triclinic_2106293": "2106293",
    "WO3_Pnma_2107312": "2107312",
}


def cod_path(cid):
    return COD / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def run_one(label, cid):
    out = ROOT / f"secondary_fixed_{label}.gpx"
    project = G2.G2Project(
        gpxfile=str(ROOT / "physical_strain_0.gpx"), newgpx=str(out)
    )
    hist = project.histogram(0)
    major = project.phase(0)
    minor = project.add_phase(
        str(cod_path(cid)), phasename=label, histograms=[hist], fmthint="CIF"
    )
    major_hap = major.data["Histograms"][hist.name]
    minor_hap = minor.data["Histograms"][hist.name]
    # Start at 1 wt%; GSAS phase mass fractions are proportional to scale*cell mass.
    major_mass = float(major.data["General"]["Mass"])
    minor_mass = float(minor.data["General"]["Mass"])
    minor_hap["Scale"] = [
        float(major_hap["Scale"][0]) * major_mass / minor_mass * 0.01 / 0.99,
        True,
    ]
    minor_hap["Size"][0] = "isotropic"
    minor_hap["Size"][1][0] = 0.5
    minor_hap["Size"][2] = [False, False, False]
    minor_hap["Mustrain"][0] = "isotropic"
    minor_hap["Mustrain"][1][0] = 1000.0
    minor_hap["Mustrain"][1][1] = 1000.0
    minor_hap["Mustrain"][2] = [False, False, False]
    minor_hap["Pref.Ori."][0] = "MD"
    minor_hap["Pref.Ori."][1] = 1.0
    minor_hap["Pref.Ori."][2] = False
    project.set_Controls("parmMin", 0.0, variable="1:0:Scale")
    # Screen on the published cell first. Unconstrained cell refinement lets an
    # absent phase collapse its cell and creates meaningless scale minima.
    minor.set_refinements({"Cell": False})
    project.set_Controls("cycles", 16)
    project.save()
    project.refine()
    project.save()

    hist, major, minor = project.histogram(0), project.phase(0), project.phase(1)
    scales = [float(p.data["Histograms"][hist.name]["Scale"][0]) for p in [major, minor]]
    masses = [float(p.data["General"]["Mass"]) for p in [major, minor]]
    weighted = [s * m for s, m in zip(scales, masses)]
    total = sum(weighted)
    fractions = [x / total for x in weighted]
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "label": label,
        "cid": cid,
        "file": out.name,
        "rwp": hist.residuals.get("wR"),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "converged": cov.get("Rvals", {}).get("converged"),
        "fractions": fractions,
        "scales": scales,
        "minor_cell": minor.get_cell(),
    }
    print("SECONDARY_SUMMARY " + json.dumps(row))
    return row


def main():
    G2.SetPrintLevel("error")
    rows = []
    for label, cid in CANDIDATES.items():
        try:
            rows.append(run_one(label, cid))
        except Exception as exc:
            print("SECONDARY_ERROR " + json.dumps({"label": label, "cid": cid, "error": repr(exc)}))
    print("SECONDARY_RANKING")
    for row in sorted(rows, key=lambda r: r["rwp"]):
        print(json.dumps(row))


if __name__ == "__main__":
    main()
