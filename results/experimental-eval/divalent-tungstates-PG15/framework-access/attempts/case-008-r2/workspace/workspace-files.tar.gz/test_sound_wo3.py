#!/usr/bin/env python3
"""Replace the low-quality historical WO3 coordinates with a sound neutron model."""

from copy import deepcopy
from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
FINAL = ROOT / "final.gpx"
CANDIDATE = ROOT / "secondary_fixed_WO3_P21c_2311041.gpx"
OUTPUT = ROOT / "sound_wo3.gpx"


def summarize(project, label):
    hist = project.histogram(0)
    phases = project.phases()
    amounts = [
        float(p.data["General"]["Mass"])
        * float(p.data["Histograms"][hist.name]["Scale"][0])
        for p in phases
    ]
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "label": label,
        "rwp": hist.residuals.get("wR"),
        "rp": hist.residuals.get("R"),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "converged": cov.get("Rvals", {}).get("converged"),
        "fractions": [value / sum(amounts) for value in amounts],
        "cells": [phase.get_cell() for phase in phases],
        "minor_scale": phases[1].data["Histograms"][hist.name]["Scale"],
        "minor_strain": phases[1].data["Histograms"][hist.name]["Mustrain"],
    }
    print("SOUND_WO3 " + json.dumps(result, default=float))


def main():
    G2.SetPrintLevel("error")
    source = G2.G2Project(gpxfile=str(FINAL))
    project = G2.G2Project(gpxfile=str(CANDIDATE), newgpx=str(OUTPUT))

    # Preserve the final major phase, measured histogram, fitted background,
    # instrument/specimen model, and parameter bounds. Keep only the sound
    # neutron-derived WO3 structure from the candidate project.
    project.data["Controls"] = deepcopy(source.data["Controls"])
    project.data["Constraints"] = deepcopy(source.data["Constraints"])
    project.data["Restraints"] = deepcopy(source.data["Restraints"])
    project.data["Phases"]["MnWO4_wolframite"] = deepcopy(
        source.data["Phases"]["MnWO4_wolframite"]
    )
    source_hist = source.histogram(0).data
    target_hist = project.histogram(0).data
    for key in [
        "Limits",
        "Background",
        "Instrument Parameters",
        "Sample Parameters",
    ]:
        target_hist[key] = deepcopy(source_hist[key])

    hist = project.histogram(0)
    minor = project.phase(1)
    for atom in minor.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.020
        atom.refinement_flags = ""
    minor.set_refinements({"Cell": True})
    hap = minor.data["Histograms"][hist.name]
    hap["Scale"] = [0.82, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.5
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1600.0
    hap["Mustrain"][2] = [True, False, False]
    hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
    project.set_Controls("parmMin", 0.0, variable="1:0:Scale")
    project.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable="1:0:Mustrain;i")
    project.set_Controls("cycles", 16)
    project.data["Covariance"]["data"] = {}
    project.save()

    for index in range(8):
        project.refine()
        project.save()
        summarize(project, f"cycle_{index + 1}")

    exported = G2.G2Project(gpxfile=str(OUTPUT))
    exported.data["Covariance"]["data"] = {}
    exported.phase(1).export_CIF(str(ROOT / "sound_wo3.cif"))


if __name__ == "__main__":
    main()
