#!/usr/bin/env python3
"""Constrained, physically admissible refinement and specimen-model tests."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def copy_project(source, dest):
    return G2.G2Project(gpxfile=str(ROOT / source), newgpx=str(ROOT / dest))


def result(project, label):
    h, p = project.histogram(0), project.phase(0)
    hap = p.data["Histograms"][h.name]
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "label": label,
        "file": Path(project.filename).name,
        "rwp": h.residuals.get("wR"),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "converged": cov.get("Rvals", {}).get("converged"),
        "cell": p.get_cell(),
        "instrument": {k: h.InstrumentParameters[k][1] for k in ["Zero", "Polariz.", "U", "W", "X", "SH/L"]},
        "sample": {k: h.SampleParameters[k][0] if isinstance(h.SampleParameters[k], list) else h.SampleParameters[k]
                   for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "orientation": hap["Pref.Ori."][:4],
        "atoms": [{"label": a.label, "xyz": a.coordinates, "uiso": a.ADP} for a in p.atoms()],
        "vary": [str(v) for v in cov.get("varyList", [])],
    }
    print("PHYSICAL_SUMMARY " + json.dumps(row, default=float))
    return row


def refine(project, label, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    return result(project, label)


def build_atomic_model():
    project = copy_project("advanced_base.gpx", "physical_atomic.gpx")
    h, p = project.histogram(0), project.phase(0)
    h.SampleParameters["SurfRoughA"] = [0.05, True]
    h.SampleParameters["SurfRoughB"] = [0.11, True]
    project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    project.save()
    refine(project, "bounded_roughness")

    p = project.phase(0)
    for atom in p.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.010
        atom.refinement_flags = "X"
    project.save()
    refine(project, "bounded_roughness_coordinates")

    p = project.phase(0)
    for atom in p.atoms():
        atom.refinement_flags = "XU"
    project.add_EquivConstr(tuple(f"0::AUiso:{i}" for i in range(len(p.atoms()))))
    project.set_Controls("parmMin", 0.001, variable="0::AUiso:0")
    project.set_Controls("parmMax", 0.05, variable="0::AUiso:0")
    project.save()
    refine(project, "bounded_roughness_coordinates_uiso")
    return "physical_atomic.gpx"


def orientation_trials(source):
    trials = []
    none = copy_project(source, "physical_orientation_none.gpx")
    none.phase(0).clear_HAP_refinements({"Pref.Ori.": True})
    none.save()
    trials.append(refine(none, "physical_orientation_none"))
    for i, axis in enumerate(([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])):
        project = copy_project(source, f"physical_orientation_{i}.gpx")
        p, h = project.phase(0), project.histogram(0)
        po = p.data["Histograms"][h.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", 1.05, True, list(axis)
        project.set_Controls("parmMin", 0.70, variable="0:0:MD")
        project.set_Controls("parmMax", 1.40, variable="0:0:MD")
        project.save()
        trials.append(refine(project, "physical_orientation_" + "".join(map(str, axis))))
    best = min(trials, key=lambda r: r["rwp"])
    print("PHYSICAL_BEST_ORIENTATION " + json.dumps(best))
    return best["file"]


def anisotropic_strain_trials(source):
    trials = []
    ref = copy_project(source, "physical_strain_isotropic.gpx")
    ref.phase(0).clear_HAP_refinements({"Mustrain": True})
    ref.save()
    trials.append(refine(ref, "physical_strain_isotropic"))
    for i, axis in enumerate(([0, 0, 1], [1, 0, 0], [0, 1, 0])):
        project = copy_project(source, f"physical_strain_{i}.gpx")
        p, h = project.phase(0), project.histogram(0)
        ms = p.data["Histograms"][h.name]["Mustrain"]
        common = float(ms[1][0])
        ms[0] = "uniaxial"
        ms[1][0] = common
        ms[1][1] = common
        ms[2] = [False, True, False]
        ms[3] = list(axis)
        project.set_Controls("parmMin", 0.0, variable="0:0:Mustrain;a")
        project.set_Controls("parmMax", 12000.0, variable="0:0:Mustrain;a")
        project.save()
        trials.append(refine(project, "physical_strain_" + "".join(map(str, axis))))
    best = min(trials, key=lambda r: r["rwp"])
    print("PHYSICAL_BEST_STRAIN " + json.dumps(best))
    return best["file"]


def main():
    G2.SetPrintLevel("error")
    atomic = build_atomic_model()
    orientation = orientation_trials(atomic)
    anisotropic_strain_trials(orientation)


if __name__ == "__main__":
    main()
