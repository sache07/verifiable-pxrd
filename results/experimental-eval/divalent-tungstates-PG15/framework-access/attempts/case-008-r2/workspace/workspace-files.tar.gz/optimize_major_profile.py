#!/usr/bin/env python3
"""Optimize major-phase profile anisotropy after adding supported WO3."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def copy(source, dest):
    return G2.G2Project(gpxfile=str(ROOT / source), newgpx=str(ROOT / dest))


def summarize(project, label):
    h = project.histogram(0)
    phases = project.phases()
    amts = [float(p.data["General"]["Mass"]) * float(p.data["Histograms"][h.name]["Scale"][0]) for p in phases]
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "label": label,
        "file": Path(project.filename).name,
        "rwp": h.residuals.get("wR"),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "converged": cov.get("Rvals", {}).get("converged"),
        "fractions": [a / sum(amts) for a in amts],
        "instrument": {k: h.InstrumentParameters[k][1] for k in ["Zero", "Polariz.", "U", "W", "X", "SH/L"]},
        "sample": {k: h.SampleParameters[k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "major_cell": phases[0].get_cell(),
        "minor_cell": phases[1].get_cell(),
        "major_size": phases[0].data["Histograms"][h.name]["Size"],
        "major_strain": phases[0].data["Histograms"][h.name]["Mustrain"],
        "major_orientation": phases[0].data["Histograms"][h.name]["Pref.Ori."][:4],
        "major_uiso": [a.ADP for a in phases[0].atoms()],
    }
    print("MAJOR_PROFILE_SUMMARY " + json.dumps(row, default=float))
    return row


def refine(project, label, cycles=16):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    return summarize(project, label)


def cell_base():
    project = copy("secondary_fixed_WO3_P21c_1528915.gpx", "two_cell.gpx")
    project.phase(1).set_refinements({"Cell": True})
    project.set_Controls("parmMin", 0.003, variable="0::AUiso:0")
    project.set_Controls("parmMax", 0.020, variable="0::AUiso:0")
    project.save()
    refine(project, "two_phase_cell")
    # A second cycle commits bounded common U values to all dependent atoms.
    refine(project, "two_phase_cell_stable", cycles=8)
    return "two_cell.gpx"


def strain_axis_trials(source):
    rows = []
    for i, axis in enumerate(([0, 0, 1], [1, 0, 0], [0, 1, 0])):
        project = copy(source, f"major_profile_axis_{i}.gpx")
        h, p = project.histogram(0), project.phase(0)
        # Break exact one-phase profile correlations while allowing the total
        # major-phase crystallite and strain broadening to be determined.
        h.InstrumentParameters["U"][2] = False
        h.InstrumentParameters["X"][2] = False
        hap = p.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = list(axis)
        project.set_Controls("parmMin", 0.04, variable="0:0:Size;i")
        project.set_Controls("parmMax", 1.50, variable="0:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable="0:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable="0:0:Mustrain;i")
        project.set_Controls("parmMin", 0.0, variable="0:0:Mustrain;a")
        project.set_Controls("parmMax", 12000.0, variable="0:0:Mustrain;a")
        project.save()
        rows.append(refine(project, "major_profile_axis_" + "".join(map(str, axis))))
    best = min(rows, key=lambda x: x["rwp"])
    print("MAJOR_PROFILE_BEST_AXIS " + json.dumps(best))
    return best["file"]


def orientation_trials(source):
    rows = []
    none = copy(source, "major_profile_orientation_none.gpx")
    none.phase(0).clear_HAP_refinements({"Pref.Ori.": True})
    none.save()
    rows.append(refine(none, "major_profile_orientation_none"))
    for i, axis in enumerate(([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])):
        project = copy(source, f"major_profile_orientation_{i}.gpx")
        h, p = project.histogram(0), project.phase(0)
        po = p.data["Histograms"][h.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", 1.02, True, list(axis)
        project.set_Controls("parmMin", 0.70, variable="0:0:MD")
        project.set_Controls("parmMax", 1.40, variable="0:0:MD")
        project.save()
        rows.append(refine(project, "major_profile_orientation_" + "".join(map(str, axis))))
    best = min(rows, key=lambda x: x["rwp"])
    print("MAJOR_PROFILE_BEST_ORIENTATION " + json.dumps(best))


def main():
    G2.SetPrintLevel("error")
    base = cell_base()
    strain = strain_axis_trials(base)
    orientation_trials(strain)


if __name__ == "__main__":
    main()
