#!/usr/bin/env python3
"""Refine the supported MnWO4 + monoclinic WO3 model in defensible stages."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def summarize(project, label):
    h = project.histogram(0)
    phases = project.phases()
    masses = [float(p.data["General"]["Mass"]) for p in phases]
    scales = [float(p.data["Histograms"][h.name]["Scale"][0]) for p in phases]
    amounts = [m * s for m, s in zip(masses, scales)]
    fractions = [a / sum(amounts) for a in amounts]
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "label": label,
        "rwp": h.residuals.get("wR"),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "converged": cov.get("Rvals", {}).get("converged"),
        "fractions": fractions,
        "instrument": {k: h.InstrumentParameters[k][1] for k in ["Zero", "Polariz.", "U", "W", "X", "SH/L"]},
        "sample": {k: h.SampleParameters[k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "phases": [],
    }
    for p in phases:
        hap = p.data["Histograms"][h.name]
        row["phases"].append({
            "name": p.name,
            "cell": p.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "orientation": hap["Pref.Ori."][:4],
            "atoms": [{"label": a.label, "xyz": a.coordinates, "uiso": a.ADP, "refine": a.refinement_flags} for a in p.atoms()],
        })
    print("TWO_PHASE_SUMMARY " + json.dumps(row, default=float))
    return row


def refine(project, label, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    return summarize(project, label)


def main():
    G2.SetPrintLevel("error")
    project = G2.G2Project(
        gpxfile=str(ROOT / "secondary_fixed_WO3_P21c_1528915.gpx"),
        newgpx=str(ROOT / "two_phase.gpx"),
    )
    major, minor = project.phase(0), project.phase(1)
    # Keep the generator's physically allowed Uiso interval for the major phase.
    project.set_Controls("parmMin", 0.003, variable="0::AUiso:0")
    project.set_Controls("parmMax", 0.020, variable="0::AUiso:0")
    minor.set_refinements({"Cell": True})
    project.save()
    refine(project, "minor_cell")

    # The synthetic protocol uses one isotropic Uiso per phase. The source has
    # zero placeholders, so initialize and constrain a common physical value.
    minor = project.phase(1)
    for atom in minor.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.010
        atom.refinement_flags = "U"
    project.add_EquivConstr(tuple(f"1::AUiso:{i}" for i in range(len(minor.atoms()))))
    project.set_Controls("parmMin", 0.003, variable="1::AUiso:0")
    project.set_Controls("parmMax", 0.020, variable="1::AUiso:0")
    project.save()
    refine(project, "minor_cell_uiso")

    minor = project.phase(1)
    minor.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 0.5, "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    project.set_Controls("parmMin", 0.02, variable="1:0:Size;i")
    project.set_Controls("parmMax", 5.0, variable="1:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable="1:0:Mustrain;i")
    project.set_Controls("parmMax", 12000.0, variable="1:0:Mustrain;i")
    project.save()
    refine(project, "minor_profile")

    # Tungsten dominates this minor phase's scattering. Test only its two W
    # coordinates; oxygen-coordinate refinement is not supported at ~2 wt%.
    minor = project.phase(1)
    for atom in minor.atoms():
        atom.refinement_flags = "XU" if atom.element == "W" else "U"
    project.save()
    refine(project, "minor_tungsten_coordinates")


if __name__ == "__main__":
    main()
