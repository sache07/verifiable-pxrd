#!/usr/bin/env python3
"""Build and stage a GSAS-II Rietveld refinement for the supplied PXRD scan.

This script is intentionally small and case-local. It keeps the observed grid in
the GPX, uses the reported Cu K-alpha doublet, and records every refinement step
so trial profile models can be compared reproducibly.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


def instrument_text() -> str:
    return (
        "# GSAS-II case-local uncalibrated Cu K-alpha instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.10;Polariz.:0.80;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def parse_axis(value: str | None):
    if value is None:
        return None
    axis = [int(v) for v in value.split(",")]
    if len(axis) != 3 or not any(axis):
        raise ValueError("axis must be three comma-separated integers")
    return axis


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass": float(phase.data["General"]["Mass"]),
                "hap_scale": float(hap["Scale"][0]),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "type": atom.element,
                        "xyz": [float(v) for v in atom.coordinates],
                        "uiso": float(atom.uiso),
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    return {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "chisq": cov.get("Rvals", {}).get("chisq"),
        "instrument": {
            key: float(inst[key][1])
            for key in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
            if key in inst
        },
        "sample": {
            key: (float(value[0]) if isinstance(value, list) else value)
            for key, value in sample.items()
            if key in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type"]
        },
        "background": hist.data["Background"],
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "variables": [float(v) for v in cov.get("variables", [])],
        "sigmas": [float(v) for v in cov.get("sig", [])],
        "phases": phases,
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--phase", type=Path, action="append", required=True)
    parser.add_argument("--name", action="append")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--po-axis", type=str)
    parser.add_argument("--strain-axis", type=str)
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--atoms", choices=["none", "x", "xu"], default="xu")
    parser.add_argument("--background-terms", type=int, default=18)
    parser.add_argument("--stop-after", type=str)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    stem = args.output.with_suffix("")
    x, y = np.loadtxt(args.pattern, delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = stem.with_suffix(".xye")
    np.savetxt(xye, np.column_stack([x, y, sigma]), fmt="%.10g")
    instfile = stem.with_suffix(".instprm")
    instfile.write_text(instrument_text())

    project = G2.G2Project(newgpx=str(args.output))
    names = args.name or [p.stem for p in args.phase]
    if len(names) != len(args.phase):
        raise ValueError("--name count must match --phase count")
    phases = [
        project.add_phase(str(path.resolve()), phasename=name, fmthint="CIF")
        for path, name in zip(args.phase, names)
    ]
    hist = project.add_powder_histogram(
        str(xye.resolve()), str(instfile.resolve()), phases=phases, fmthint="xye"
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.10 if args.roughness else 0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.05 if args.roughness else 0.0, False]

    # Robustly estimate the continuum, then represent it in the exact Chebyshev
    # basis replayed by the evaluator.
    baseline = percentile_filter(y, percentile=12, size=501, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    coeffs = np.polynomial.chebyshev.chebfit(t, baseline, args.background_terms - 1)
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": coeffs.tolist(),
                "refine": False,
            },
        }
    )

    po_axis = parse_axis(args.po_axis)
    strain_axis = parse_axis(args.strain_axis)
    for i, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / max(len(phases), 1), False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.10
        hap["Size"][1][1] = 0.10
        hap["Size"][2] = [False, False, False]
        if strain_axis is None:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 1000.0
            hap["Mustrain"][1][1] = 1000.0
        else:
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][0] = 1000.0
            hap["Mustrain"][1][1] = 1000.0
            hap["Mustrain"][3] = strain_axis
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = po_axis or [0, 0, 1]
        hap["Extinction"] = [0.0, False]

    project.set_Controls("cycles", 12)
    project.set_Controls("parmMin", 0.0, variable="*:0:Scale")
    project.set_Controls("parmMin", -0.5, variable=":0:Zero")
    project.set_Controls("parmMax", 0.5, variable=":0:Zero")
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMax", 80.0, variable=":0:U")
    project.set_Controls("parmMin", 0.5, variable=":0:W")
    project.set_Controls("parmMax", 80.0, variable=":0:W")
    project.set_Controls("parmMin", 0.01, variable=":0:X")
    project.set_Controls("parmMax", 12.0, variable=":0:X")
    project.set_Controls("parmMin", 0.001, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.2, variable=":0:SH/L")
    project.set_Controls("parmMin", 0.3, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    project.set_Controls("parmMin", -1000.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1000.0, variable=":0:Shift")
    project.set_Controls("parmMin", 0.02, variable="*:0:Size;i")
    project.set_Controls("parmMax", 5.0, variable="*:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable="*:0:Mustrain;i")
    project.set_Controls("parmMax", 20000.0, variable="*:0:Mustrain;i")
    project.set_Controls("parmMin", 0.0, variable="*:0:Mustrain;a")
    project.set_Controls("parmMax", 20000.0, variable="*:0:Mustrain;a")
    project.set_Controls("parmMin", 0.5, variable="*:0:MD")
    project.set_Controls("parmMax", 2.0, variable="*:0:MD")
    project.set_Controls("parmMin", 0.0005, variable="*::AUiso:*")
    project.set_Controls("parmMax", 0.05, variable="*::AUiso:*")
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.8, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughB")

    log = [snapshot(project, "initial")]

    def run(
        label: str,
        hist_set=None,
        phase_set=None,
        hap_set=None,
        hist_clear=None,
        phase_clear=None,
        hap_clear=None,
    ):
        nonlocal hist, phases
        hist = project.histogram(0)
        phases = project.phases()
        if hist_clear:
            hist.clear_refinements(hist_clear)
        if phase_clear:
            for phase in phases:
                phase.clear_refinements(phase_clear)
        if hap_clear:
            for phase in phases:
                phase.clear_HAP_refinements(hap_clear, [hist])
        if hist_set:
            hist.set_refinements(hist_set)
        if phase_set:
            for phase in phases:
                phase.set_refinements(phase_set)
        if hap_set:
            for phase in phases:
                phase.set_HAP_refinements(hap_set, [hist])
        project.refine(makeBack=False)
        project.save(str(args.output))
        log.append(snapshot(project, label))
        stem.with_suffix(".stages.json").write_text(
            json.dumps(log, indent=2, allow_nan=False) + "\n"
        )
        shutil.copy2(args.output, stem.parent / f"{stem.name}.{label}.gpx")
        print(label, "Rwp", log[-1]["rwp_percent"], flush=True)
        if args.stop_after == label:
            raise SystemExit(0)

    run(
        "scale_background",
        hist_set={"Background": {"refine": True}},
        hap_set={"Scale": True},
    )
    run(
        "cell_zero",
        hist_set={"Instrument Parameters": ["Zero"]},
        phase_set={"Cell": True},
    )
    run(
        "constant_width_asymmetry",
        hist_set={"Instrument Parameters": ["W", "SH/L"]},
        phase_clear={"Cell": True},
        hist_clear={"Instrument Parameters": ["Zero"]},
    )
    if strain_axis is None:
        strain_ref = {"type": "isotropic", "refine": True}
    else:
        strain_ref = {"type": "uniaxial", "direction": strain_axis, "refine": True}
    run(
        "size_strain",
        hap_set={
            "Size": {"type": "isotropic", "value": 0.10, "refine": True},
            "Mustrain": strain_ref,
        },
        hist_clear={"Instrument Parameters": ["W", "SH/L"]},
    )
    run(
        "cell_zero_after_width",
        hist_set={"Instrument Parameters": ["Zero"]},
        phase_set={"Cell": True},
        hap_clear={"Size": True, "Mustrain": True},
    )
    run(
        "sample_shift",
        hist_set={
            "Sample Parameters": ["Shift"],
        },
        hist_clear={"Instrument Parameters": ["Zero"]},
        phase_clear={"Cell": True},
    )
    run(
        "cell_zero_with_fixed_shift",
        hist_set={"Instrument Parameters": ["Zero"]},
        phase_set={"Cell": True},
        hist_clear={"Sample Parameters": ["Shift"]},
    )
    run(
        "polarization",
        hist_set={"Instrument Parameters": ["Polariz."]},
        hist_clear={"Instrument Parameters": ["Zero"]},
        phase_clear={"Cell": True},
    )
    if args.roughness:
        run(
            "surface_roughness",
            hist_set={"Sample Parameters": ["SurfRoughA", "SurfRoughB"]},
            hist_clear={"Instrument Parameters": ["Polariz."]},
        )
    if po_axis is not None:
        run(
            "preferred_orientation",
            hap_set={"Pref.Ori.": True},
            hist_clear={"Instrument Parameters": ["Polariz."]},
        )
    if args.atoms in {"x", "xu"}:
        run(
            "atomic_coordinates",
            phase_set={"Atoms": {"all": "X"}},
            hist_clear={"Instrument Parameters": ["Polariz."]},
            hap_clear={"Pref.Ori.": True},
        )
    if args.atoms == "xu":
        run("atomic_coordinates_uiso", phase_set={"Atoms": {"all": "XU"}})
    # Keep the final pass deliberately limited to the linear intensity terms;
    # profile, lattice and atomic values above are retained but not made jointly
    # singular again.
    if args.atoms != "none":
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = " "
    run("final_linear")

    stem.with_suffix(".stages.json").write_text(json.dumps(log, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
