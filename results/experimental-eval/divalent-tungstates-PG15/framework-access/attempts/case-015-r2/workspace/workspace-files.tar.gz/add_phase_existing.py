#!/usr/bin/env python3
"""Add one trial phase to a GPX and refine nonnegative phase scales."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    p = argparse.ArgumentParser()
    p.add_argument("input", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("cif", type=Path)
    p.add_argument("name")
    args = p.parse_args()
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    project.set_Frozen()
    hist = project.histogram(0)
    # Clear all previously active nonlinear terms but retain their values.
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
    })
    hist.clear_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms(): atom.refinement_flags = " "
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
    trial = project.add_phase(
        str(args.cif.resolve()), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    hap = trial.data["Histograms"][hist.name]
    hap["Scale"] = [0.02, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.20
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Pref.Ori."][1] = 1.0
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases(): phase.set_HAP_refinements({"Scale": True}, [hist])
    project.set_Controls("cycles", 12)
    project.set_Controls("parmMin", 0.0, variable="*:0:Scale")
    project.refine(makeBack=False)
    project.save(str(args.output.resolve()))
    phases=[]; masses=[]
    for phase in project.phases():
        h=phase.data["Histograms"][hist.name]
        m=phase.data["General"]["Mass"]*h["Scale"][0]
        masses.append(m);phases.append({"name":phase.name,"scale":h["Scale"][0]})
    for row,m in zip(phases,masses):row["weight_fraction"]=m/sum(masses)
    result={"rwp_percent":project.histogram(0).get_wR(),"phases":phases,"frozen":project.get_Frozen()}
    args.output.with_suffix(".json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
