#!/usr/bin/env python3
"""Branch a saved GSAS-II project and refine selected parameter groups."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


INSTRUMENT_KEYS = ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]
SAMPLE_KEYS = ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]


def axis(text: str | None):
    if text is None:
        return None
    result = [int(v) for v in text.split(",")]
    if len(result) != 3 or not any(result):
        raise ValueError("axis must have three nonzero-combined integer components")
    return result


def state(project):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(mass)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": a.label,
                        "xyz": [float(v) for v in a.coordinates],
                        "adp_flag": a.adp_flag,
                        "adp": ([float(v) for v in a.ADP]
                                if a.adp_flag == "A" else float(a.ADP)),
                        "flags": a.refinement_flags,
                    }
                    for a in phase.atoms()
                ],
            }
        )
    total = sum(masses)
    for p, m in zip(phases, masses):
        p["weight_fraction"] = m / total
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "instrument": {k: float(inst[k][1]) for k in INSTRUMENT_KEYS if k in inst},
        "sample": {
            k: float(sample[k][0])
            for k in SAMPLE_KEYS
            if k in sample and isinstance(sample[k], list)
        },
        "phases": phases,
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "frozen": project.get_Frozen(),
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("input", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument(
        "--groups",
        default="linear",
        help="comma list: linear,cell,zero,shift,width,size,strain,po,roughness,polarization,x,u",
    )
    p.add_argument("--po-axis")
    p.add_argument("--strain-axis")
    p.add_argument("--x-elements", help="comma-separated elements for X refinement")
    p.add_argument("--x-phases", help="comma-separated phase names for X refinement")
    p.add_argument("--hap-phases", help="comma-separated phase names for size/strain/PO refinement")
    p.add_argument("--set-uiso", help="comma-separated fixed Uiso values, one per phase")
    p.add_argument("--set-roughness", help="fixed SurfRoughA,SurfRoughB")
    p.add_argument("--set-polarization", type=float)
    p.add_argument("--set-w", type=float, help="fixed Gaussian W profile term")
    p.add_argument("--set-shl", type=float, help="fixed axial-divergence SH/L")
    p.add_argument("--passes", type=int, default=1)
    p.add_argument("--cycles", type=int, default=12)
    args = p.parse_args()
    groups = set(args.groups.split(","))
    unknown = groups - {
        "linear", "cell", "zero", "shift", "width", "size", "strain",
        "po", "roughness", "polarization", "x", "u",
    }
    if unknown:
        raise ValueError("unknown groups: " + ",".join(sorted(unknown)))

    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()
    if args.set_uiso:
        values = [float(v) for v in args.set_uiso.split(",")]
        if len(values) != len(phases):
            raise ValueError("--set-uiso needs one value per phase")
        for phase, value in zip(phases, values):
            for atom in phase.atoms():
                # Imported literature CIFs can carry anisotropic ADPs, while
                # the synthetic reference convention is one isotropic value.
                if atom.adp_flag != "I":
                    atom.data[atom.cia] = "I"
                atom.data[atom.cia + 1] = value
    if args.set_roughness:
        values = [float(v) for v in args.set_roughness.split(",")]
        if len(values) != 2:
            raise ValueError("--set-roughness needs A,B")
        hist.data["Sample Parameters"]["SurfRoughA"][0] = values[0]
        hist.data["Sample Parameters"]["SurfRoughB"][0] = values[1]
    if args.set_polarization is not None:
        hist.data["Instrument Parameters"][0]["Polariz."][1] = args.set_polarization
    if args.set_w is not None:
        hist.data["Instrument Parameters"][0]["W"][1] = args.set_w
    if args.set_shl is not None:
        hist.data["Instrument Parameters"][0]["SH/L"][1] = args.set_shl

    # Start each branch with all nonlinear flags off. Values are retained.
    # Background's scriptable clear method returns immediately, so clear it in
    # a separate call after the other histogram flags.
    hist.clear_refinements({
        "Instrument Parameters": INSTRUMENT_KEYS,
        "Sample Parameters": SAMPLE_KEYS,
    })
    hist.clear_refinements({"Background": True})
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True},
            [hist],
        )

    # Always allow the linear terms to readjust after a nonlinear branch.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    if "cell" in groups:
        for phase in phases:
            phase.set_refinements({"Cell": True})
    inst = []
    if "zero" in groups: inst.append("Zero")
    if "width" in groups: inst.extend(["W", "SH/L"])
    if "polarization" in groups: inst.append("Polariz.")
    if inst: hist.set_refinements({"Instrument Parameters": inst})
    sample = []
    if "shift" in groups: sample.append("Shift")
    if "roughness" in groups:
        sample.extend(["SurfRoughA", "SurfRoughB"])
        hist.data["Sample Parameters"]["SurfRoughA"][0] = max(
            0.1, hist.data["Sample Parameters"]["SurfRoughA"][0]
        )
        hist.data["Sample Parameters"]["SurfRoughB"][0] = max(
            0.05, hist.data["Sample Parameters"]["SurfRoughB"][0]
        )
    if sample: hist.set_refinements({"Sample Parameters": sample})

    strain_axis = axis(args.strain_axis) or [0, 0, 1]
    po_axis = axis(args.po_axis) or [0, 0, 1]
    x_elements = set(args.x_elements.split(",")) if args.x_elements else None
    x_phases = set(args.x_phases.split(",")) if args.x_phases else None
    hap_phases = set(args.hap_phases.split(",")) if args.hap_phases else None
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        refs = {}
        use_hap = hap_phases is None or phase.name in hap_phases
        if "size" in groups and use_hap:
            refs["Size"] = {"type": "isotropic", "refine": True}
        if "strain" in groups and use_hap:
            hap["Mustrain"][1][0] = max(300.0, hap["Mustrain"][1][0])
            hap["Mustrain"][1][1] = max(300.0, hap["Mustrain"][1][1])
            refs["Mustrain"] = {
                "type": "uniaxial" if args.strain_axis else "isotropic",
                "direction": strain_axis,
                "refine": True,
            }
        if "po" in groups and use_hap:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][3] = po_axis
            refs["Pref.Ori."] = True
        if refs: phase.set_HAP_refinements(refs, [hist])
        if "u" in groups:
            phase.set_refinements({"Atoms": {"all": "U"}})
        if "x" in groups:
            for atom in phase.atoms():
                if ((x_phases is None or phase.name in x_phases)
                        and (x_elements is None or atom.element in x_elements)):
                    atom.refinement_flags = "X" + ("U" if "u" in groups else "")

    project.set_Controls("cycles", args.cycles)
    for control, variable, value in [
        ("parmMin", "*:0:Scale", 0.0),
        ("parmMin", ":0:Zero", -0.5), ("parmMax", ":0:Zero", 0.5),
        ("parmMin", ":0:W", 0.1), ("parmMax", ":0:W", 150.0),
        ("parmMin", ":0:SH/L", 0.001), ("parmMax", ":0:SH/L", 0.2),
        ("parmMin", ":0:Polariz.", 0.3), ("parmMax", ":0:Polariz.", 1.0),
        ("parmMin", ":0:Shift", -1000.0), ("parmMax", ":0:Shift", 1000.0),
        ("parmMin", ":0:SurfRoughA", 0.0), ("parmMax", ":0:SurfRoughA", 0.6),
        ("parmMin", ":0:SurfRoughB", 0.0), ("parmMax", ":0:SurfRoughB", 0.5),
        ("parmMin", "*:0:Size;i", 0.02), ("parmMax", "*:0:Size;i", 5.0),
        ("parmMin", "*:0:Mustrain;i", 0.0), ("parmMax", "*:0:Mustrain;i", 20000.0),
        ("parmMin", "*:0:Mustrain;a", 0.0), ("parmMax", "*:0:Mustrain;a", 20000.0),
        ("parmMin", "*:0:MD", 0.5), ("parmMax", "*:0:MD", 2.0),
        ("parmMin", "*::AUiso:*", 0.0005), ("parmMax", "*::AUiso:*", 0.05),
    ]:
        project.set_Controls(control, value, variable=variable)

    history = []
    for i in range(args.passes):
        project.refine(makeBack=False)
        project.save(str(args.output.resolve()))
        row = state(project)
        row["pass"] = i + 1
        history.append(row)
        print("pass", i + 1, "Rwp", row["rwp_percent"], flush=True)
    args.output.with_suffix(".json").write_text(json.dumps(history, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
