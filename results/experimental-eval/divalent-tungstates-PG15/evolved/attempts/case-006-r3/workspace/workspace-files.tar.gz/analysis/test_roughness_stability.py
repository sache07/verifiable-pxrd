#!/usr/bin/env python3
"""Test the one-parameter roughness correction against background order."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / "analysis" / "two_phase_wo3_niggli.gpx"


def configure_background(histogram, count):
    background = histogram.data["Background"][0]
    coefficients = list(background[3:])
    if count > len(coefficients):
        coefficients.extend([0.0] * (count - len(coefficients)))
    histogram.data["Background"][0] = [background[0], True, count] + coefficients[:count]


def main():
    G2sc.SetPrintLevel("warn")
    results = []
    for count in (6, 10):
        path = ROOT / "analysis" / f"trial_rough_background_{count}.gpx"
        project = G2sc.G2Project(str(BASELINE), newgpx=str(path))
        histogram = project.histogram(0)
        configure_background(histogram, count)
        histogram.SampleParameters["SurfRoughA"] = [0.0, False]
        histogram.SampleParameters["SurfRoughB"] = [0.05, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")
        project.set_Controls("cycles", 15)
        project.save()
        project.do_refinements([{}])
        project.do_refinements([{}])
        project.save()
        covariance = project.data["Covariance"]["data"]
        names = list(covariance["varyList"])
        index = names.index(":0:SurfRoughB")
        result = {
            "background_coefficients": count,
            "Rwp_percent": float(histogram.residuals["wR"]),
            "roughness_B": float(covariance["variables"][index]),
            "roughness_B_esd": float(covariance["sig"][index]),
            "max_shift_over_sigma": float(covariance["Rvals"]["Max shft/sig"]),
            "mass_fractions": {
                key: [float(value), float(esd)]
                for key, (value, esd) in histogram.ComputeMassFracs().items()
            },
        }
        results.append(result)
        print(json.dumps(result, indent=2))
    print("SUMMARY_JSON")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
