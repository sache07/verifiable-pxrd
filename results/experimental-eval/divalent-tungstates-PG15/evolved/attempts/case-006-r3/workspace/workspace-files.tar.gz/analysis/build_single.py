#!/usr/bin/env python3
"""Build and stage a baseline CuWO4 GSAS-II refinement."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/4/00/08/4000806.cif"
)
AMBIENT_CELL = [4.7026, 5.8389, 4.8786, 91.677, 92.469, 82.805]


def show(label, project, histogram, phase):
    inst = histogram.InstrumentParameters
    print(f"\n--- {label} ---")
    print("residuals", histogram.residuals)
    print("cell", phase.get_cell())
    print(
        "instrument",
        {key: inst[key][1] for key in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]},
    )
    print("background", histogram.data["Background"][0])
    print("scale", phase.data["Histograms"][histogram.name]["Scale"])
    print("vary", project.get_VaryList())


def refine(project, histogram, phase, label):
    project.do_refinements([{}])
    show(label, project, histogram, phase)


def main():
    G2sc.SetPrintLevel("warn")
    output = ROOT / "analysis" / "single.gpx"
    project = G2sc.G2Project(newgpx=str(output))
    histogram = project.add_powder_histogram(
        str(ROOT / "analysis" / "pattern.xye"),
        str(ROOT / "analysis" / "cu_lab.instprm"),
        fmthint="Topas xye",
    )
    phase = project.add_phase(
        str(SOURCE),
        phasename="CuWO4_triclinic",
        histograms=[histogram],
        fmthint="CIF",
    )

    cell = phase.data["General"]["Cell"]
    cell[1:7] = AMBIENT_CELL
    cell[7] = G2lat.calc_V(G2lat.cell2A(AMBIENT_CELL))

    # Keep phase nuisance parameters neutral while establishing the baseline.
    hap = phase.data["Histograms"][histogram.name]
    hap["Size"] = ["isotropic", [1.0, 1.0, 1.0], [False, False, False], [0, 0, 1], [1.0] * 6, [False] * 6]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    if len(hap["Mustrain"]) > 5:
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][2] = False
    hap["Extinction"][1] = False
    hap["Babinet"]["BabA"][1] = False
    hap["Babinet"]["BabU"][1] = False

    histogram.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [1400.0, -350.0, 180.0, -90.0, 45.0, -20.0, 8.0, -3.0],
                "refine": True,
            },
        }
    )
    phase.set_HAP_refinements({"Scale": True}, [histogram])
    project.set_Controls("cycles", 8)
    project.save()

    refine(project, histogram, phase, "background + scale")

    phase.set_refinements({"Cell": True})
    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, histogram, phase, "background + scale + cell + zero")
    refine(project, histogram, phase, "cell/zero replay")

    histogram.set_refinements({"Instrument Parameters": ["W"]})
    refine(project, histogram, phase, "add W")
    histogram.set_refinements({"Instrument Parameters": ["U", "X"]})
    refine(project, histogram, phase, "common U/W/X")
    refine(project, histogram, phase, "common-profile replay")
    project.save()


if __name__ == "__main__":
    main()
