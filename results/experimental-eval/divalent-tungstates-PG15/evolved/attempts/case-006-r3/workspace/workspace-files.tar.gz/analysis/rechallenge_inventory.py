#!/usr/bin/env python3
"""Challenge residual phase candidates after adding monoclinic WO3."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
CIF_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
CANDIDATES = [
    ("CuO_C2c_1011194", CIF_ROOT / "1/01/11/1011194.cif"),
    ("CuO_Cc_9016057", CIF_ROOT / "9/01/60/9016057.cif"),
    ("Cu3WO6_Pa3_1527404", CIF_ROOT / "1/52/74/1527404.cif"),
    ("Cu2WO4_P1_2002403", ROOT / "analysis/cu2wo4_2002403_clean.cif"),
]


def neutralize(hap):
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][1:3] = [1.0, False]
    hap["Scale"] = [0.2, True]


def main():
    G2sc.SetPrintLevel("warn")
    results = []
    for name, path in CANDIDATES:
        out = ROOT / "analysis" / f"rechallenge_{name}.gpx"
        project = G2sc.G2Project(
            str(ROOT / "analysis/two_phase_wo3_niggli.gpx"), newgpx=str(out)
        )
        histogram = project.histogram(0)
        phase = project.add_phase(
            str(path), phasename=name, histograms=[histogram], fmthint="CIF"
        )
        hap = phase.data["Histograms"][histogram.name]
        neutralize(hap)
        project.set_Controls("cycles", 15)
        project.save()
        project.set_Controls("parmMin", 0.0, variable="2:0:Scale")
        project.do_refinements([{}])
        project.do_refinements([{}])
        project.save()
        _, sigmas = project.get_LastFitResults()
        try:
            fractions = {
                key: [float(value), float(esd)]
                for key, (value, esd) in histogram.ComputeMassFracs().items()
            }
        except Exception as exc:
            fractions = {"error": str(exc)}
        sigma = sigmas.get("2:0:Scale")
        result = {
            "candidate": name,
            "scale": float(hap["Scale"][0]),
            "scale_esd": None if sigma is None else float(sigma),
            "Rwp_percent": float(histogram.residuals["wR"]),
            "Rp_percent": float(histogram.residuals["R"]),
            "mass_fractions": fractions,
        }
        results.append(result)
        print(json.dumps(result, indent=2))

    print("SUMMARY_JSON")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
