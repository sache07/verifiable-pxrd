#!/usr/bin/env python3
"""Check whether texture or polarization remains after surface roughness."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / "analysis" / "trial_rough_b.gpx"


def corr(project, target):
    covariance = project.data["Covariance"]["data"]
    names = list(covariance["varyList"])
    if target not in names:
        return []
    i = names.index(target)
    matrix = np.asarray(covariance["covMatrix"], dtype=float)
    sigmas = np.asarray(covariance["sig"], dtype=float)
    values = matrix[i] / (sigmas[i] * sigmas)
    return sorted(
        ((name, float(value)) for name, value in zip(names, values)
         if name != target and abs(value) >= 0.5),
        key=lambda item: abs(item[1]),
        reverse=True,
    )


def run(name, configure, parameters):
    path = ROOT / "analysis" / f"trial_rough_{name}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(path))
    project.set_Controls("cycles", 15)
    configure(project)
    project.save()
    project.do_refinements([{}])
    project.do_refinements([{}])
    project.save()
    histogram = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    names = list(covariance["varyList"])
    result = {
        "trial": name,
        "Rwp_percent": float(histogram.residuals["wR"]),
        "GOF": float(covariance["Rvals"]["GOF"]),
        "max_shift_over_sigma": float(covariance["Rvals"]["Max shft/sig"]),
        "mass_fractions": {
            key: [float(value), float(esd)]
            for key, (value, esd) in histogram.ComputeMassFracs().items()
        },
        "parameters": {},
    }
    for parameter in parameters:
        if parameter in names:
            i = names.index(parameter)
            value = float(covariance["variables"][i])
            esd = float(covariance["sig"][i])
        else:
            value = esd = None
        result["parameters"][parameter] = {
            "value": value,
            "esd": esd,
            "correlations_abs_ge_0.5": corr(project, parameter),
        }
    print(json.dumps(result, indent=2))
    return result


def polarization(project):
    project.histogram(0).InstrumentParameters["Polariz."][2] = True
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")


def texture(axis):
    def configure(project):
        histogram = project.histogram(0)
        preferred = project.phase(0).data["Histograms"][histogram.name]["Pref.Ori."]
        preferred[0:4] = ["MD", 1.0, True, list(axis)]
        project.set_Controls("parmMin", 0.2, variable="0:0:MD")
        project.set_Controls("parmMax", 5.0, variable="0:0:MD")
    return configure


def main():
    G2sc.SetPrintLevel("warn")
    results = [run("polarization", polarization, [":0:SurfRoughB", ":0:Polariz."])]
    for axis in ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)):
        label = "texture_" + "".join(str(value) for value in axis)
        results.append(run(label, texture(axis), [":0:SurfRoughB", "0:0:MD"]))
    print("SUMMARY_JSON")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
