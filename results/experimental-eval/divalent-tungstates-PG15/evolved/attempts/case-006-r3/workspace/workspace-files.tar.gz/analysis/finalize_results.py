#!/usr/bin/env python3
"""Replay the accepted model and export project-consistent deliverables."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "trial_rough_b.gpx"
FINAL = ROOT / "final.gpx"


def neutralize_rejected_terms(project):
    histogram = project.histogram(0)
    histogram.InstrumentParameters["Polariz."][2] = False
    histogram.SampleParameters["Shift"] = [0.0, False]
    histogram.SampleParameters["Transparency"] = [0.0, False]
    histogram.SampleParameters["SurfRoughA"] = [0.0, False]
    histogram.SampleParameters["SurfRoughB"][1] = True
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]


def replay_to_convergence():
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    histogram = project.histogram(0)
    x = np.asarray(histogram.data["data"][1][0], dtype=float)
    histogram.data["Limits"][1] = [float(x[0]), float(x[-1])]
    neutralize_rejected_terms(project)
    project.set_Controls("cycles", 15)
    project.save()

    history = []
    for replay in range(1, 7):
        # Explicit reopen makes this a save/reopen/replay test of the full range.
        project = G2sc.G2Project(str(FINAL))
        project.do_refinements([{}])
        project.save()
        covariance = project.data["Covariance"]["data"]
        record = {
            "replay": replay,
            "Rwp_percent": float(project.histogram(0).residuals["wR"]),
            "max_shift_over_sigma": float(
                covariance["Rvals"]["Max shft/sig"]
            ),
        }
        history.append(record)
        print(json.dumps(record))
        if replay >= 2 and record["max_shift_over_sigma"] < 0.05:
            break
    return project, history


def export(project, replay_history):
    histogram = project.histogram(0)
    phase_specs = [
        (project.phase(0), "CuWO4", ROOT / "CuWO4_triclinic.cif"),
        (project.phase(1), "WO3", ROOT / "WO3_monoclinic.cif"),
    ]
    for phase, _, path in phase_specs:
        phase.export_CIF(str(path))

    profile = np.asarray(histogram.data["data"][1], dtype=float)
    fit = np.column_stack(
        (profile[0], profile[1], profile[3], profile[5], profile[4])
    )
    np.savetxt(
        ROOT / "fit.csv",
        fit,
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference_observed_minus_calculated,background",
        comments="",
        fmt=("%.8f", "%.8f", "%.8f", "%.8f", "%.8f"),
    )

    fractions = histogram.ComputeMassFracs()
    covariance = project.data["Covariance"]["data"]
    residuals = histogram.residuals
    rvalues = covariance["Rvals"]
    phases = []
    for phase, formula, path in phase_specs:
        value, esd = fractions[phase.name]
        phase_id = phase.id
        phases.append(
            {
                "name": phase.name,
                "formula": formula,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": path.name,
                "weight_fraction": float(value),
                "weight_percent": float(100.0 * value),
                "formal_weight_fraction_esd": float(esd),
                "Bragg_R_percent": float(residuals[f"{phase_id}:0:Rf"]),
                "Bragg_R_F2_percent": float(residuals[f"{phase_id}:0:Rf^2"]),
            }
        )
    result = {
        "project_path": FINAL.name,
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "background_subtracted_R_percent": float(residuals["Rb"]),
            "background_subtracted_weighted_R_percent": float(residuals["wRb"]),
            "R_expected_percent": float(residuals["wRmin"]),
            "goodness_of_fit_sqrt_reduced_chi_squared": float(rvalues["GOF"]),
            "reduced_chi_squared": float(rvalues["GOF"] ** 2),
            "chi_squared": float(rvalues["chisq"]),
            "number_of_observations": int(rvalues["Nobs"]),
            "number_of_variables": int(rvalues["Nvars"]),
            "maximum_shift_over_esd_last_replay": float(
                rvalues["Max shft/sig"]
            ),
        },
        "replay_history": replay_history,
    }
    with (ROOT / "result.json").open("w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps(result, indent=2))


def main():
    G2sc.SetPrintLevel("warn")
    project, replay_history = replay_to_convergence()
    export(project, replay_history)


if __name__ == "__main__":
    main()
