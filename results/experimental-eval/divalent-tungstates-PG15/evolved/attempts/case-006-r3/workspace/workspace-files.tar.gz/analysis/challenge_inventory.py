#!/usr/bin/env python3
"""Re-challenge plausible secondary phases under the common baseline."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
CIF_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)

CANDIDATES = [
    ("CuO_C2c_1011194", "1011194"),
    ("CuO_Cc_9016057", "9016057"),
    ("WO3_P21n_1528915", "1528915"),
    ("WO3_Pminus1_2106293", "2106293"),
    ("Cu3WO6_Pa3_1527404", "1527404"),
    ("Cu2WO4_P1_2002403", "2002403"),
]


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(hap):
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def main():
    G2sc.SetPrintLevel("warn")
    results = []
    for name, cod_id in CANDIDATES:
        project_path = ROOT / "analysis" / f"challenge_{name}.gpx"
        project = G2sc.G2Project(
            str(ROOT / "analysis" / "prototype_atoms_u.gpx"),
            newgpx=str(project_path),
        )
        histogram = project.histogram(0)
        candidate = project.add_phase(
            str(cif_path(cod_id)),
            phasename=name,
            histograms=[histogram],
            fmthint="CIF",
        )
        hap = candidate.data["Histograms"][histogram.name]
        neutralize(hap)
        hap["Scale"] = [1.0, True]
        candidate.set_refinements({"Cell": False})
        project.set_Controls("cycles", 15)
        project.save()
        project.set_Controls("parmMin", 0.0, variable="1:0:Scale")
        project.do_refinements([{}])
        project.do_refinements([{}])
        project.save()

        shifts, sigmas = project.get_LastFitResults()
        scale = float(hap["Scale"][0])
        sigma = float(sigmas.get("1:0:Scale", float("nan")))
        try:
            fractions = {
                key: [float(value), float(esd)]
                for key, (value, esd) in histogram.ComputeMassFracs().items()
            }
        except Exception as exc:
            fractions = {"error": str(exc)}
        results.append(
            {
                "candidate": name,
                "cod_id": cod_id,
                "scale": scale,
                "scale_esd": sigma,
                "scale_over_esd": scale / sigma if sigma > 0 else None,
                "Rwp_percent": float(histogram.residuals["wR"]),
                "Rp_percent": float(histogram.residuals["R"]),
                "mass_fractions": fractions,
                "cell_fixed": candidate.get_cell(),
            }
        )
        print(json.dumps(results[-1], indent=2))

    print("\nSUMMARY_JSON")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
