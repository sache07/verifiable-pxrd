#!/usr/bin/env python3
"""Prepare GSAS-II input files without altering the measured intensities."""

from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    data = np.genfromtxt(
        ROOT / "inputs" / "pattern.csv", delimiter=",", names=True
    )
    x = data["two_theta_deg"]
    y = data["intensity"]
    # Pointwise uncertainties were not supplied. Counting-statistical
    # uncertainties are the least-assumptive working weights for raw counts.
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(
        ROOT / "analysis" / "pattern.xye",
        np.column_stack((x, y, sigma)),
        fmt=("%.8f", "%.8f", "%.8f"),
        header="two_theta_deg intensity sigma_sqrt_counts",
    )


if __name__ == "__main__":
    main()
