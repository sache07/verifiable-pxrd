#!/usr/bin/env python3
"""Verify exact agreement among final.gpx and exported deliverables."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main():
    project = G2sc.G2Project(str(ROOT / "final.gpx"))
    histogram = project.histogram(0)
    assert len(project.phases()) == 2
    assert project.get_Frozen() == []
    measured_limits, fitted_limits = histogram.data["Limits"]
    assert np.allclose(measured_limits, fitted_limits, rtol=0.0, atol=1e-10)

    with (ROOT / "result.json").open(encoding="utf-8") as stream:
        result = json.load(stream)
    fractions = histogram.ComputeMassFracs()
    submitted = {item["name"]: item for item in result["phases"]}
    assert set(submitted) == set(fractions)
    for name, (value, esd) in fractions.items():
        assert np.isclose(submitted[name]["weight_fraction"], value, atol=1e-14)
        assert np.isclose(
            submitted[name]["formal_weight_fraction_esd"], esd, atol=1e-14
        )
    assert np.isclose(sum(value for value, _ in fractions.values()), 1.0, atol=1e-14)

    profile = np.asarray(histogram.data["data"][1], dtype=float)
    exported = np.genfromtxt(ROOT / "fit.csv", delimiter=",", names=True)
    assert len(exported) == profile.shape[1]
    for field, row in (
        ("two_theta_deg", 0),
        ("observed", 1),
        ("calculated", 3),
        ("difference_observed_minus_calculated", 5),
        ("background", 4),
    ):
        assert np.allclose(exported[field], profile[row], rtol=0.0, atol=5.1e-9)
    assert np.allclose(
        exported["difference_observed_minus_calculated"],
        exported["observed"] - exported["calculated"],
        rtol=0.0,
        atol=1.1e-8,
    )

    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        assert hap["Pref.Ori."][2] is False
        assert not any(hap["Size"][2])
        assert not any(hap["Mustrain"][2])
        assert not any(hap["HStrain"][1])
        assert hap["Extinction"][1] is False
        assert hap["Babinet"]["BabA"][1] is False
        assert hap["Babinet"]["BabU"][1] is False
    assert histogram.SampleParameters["Shift"] == [0.0, False]
    assert histogram.SampleParameters["Transparency"] == [0.0, False]
    assert histogram.SampleParameters["SurfRoughA"] == [0.0, False]
    assert histogram.InstrumentParameters["Polariz."][2] is False

    print(
        json.dumps(
            {
                "status": "verified",
                "phase_count": len(project.phases()),
                "profile_points": profile.shape[1],
                "weight_fraction_sum": sum(value for value, _ in fractions.values()),
                "Rwp_percent": histogram.residuals["wR"],
                "frozen_parameters": project.get_Frozen(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
