#!/usr/bin/env python3
"""Fit the ambient Cu-rich wolframite prototype with a neutral baseline."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def summarize(label, project, histogram, phase):
    inst = histogram.InstrumentParameters
    hap = phase.data["Histograms"][histogram.name]
    print(f"\n--- {label} ---")
    print("residuals", histogram.residuals)
    print("cell", phase.get_cell())
    print(
        "instrument",
        {key: inst[key] for key in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]},
    )
    print("sample scale", histogram.SampleParameters["Scale"])
    print("phase scale", hap["Scale"])
    print("size", hap["Size"][:4])
    print("mustrain", hap["Mustrain"][:4])
    print("background", histogram.data["Background"][0])
    print("vary", project.get_VaryList())


def run(project, histogram, phase, label):
    project.do_refinements([{}])
    summarize(label, project, histogram, phase)


def main():
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(newgpx=str(ROOT / "analysis" / "prototype.gpx"))
    histogram = project.add_powder_histogram(
        str(ROOT / "analysis" / "pattern.xye"),
        str(ROOT / "analysis" / "cu_lab.instprm"),
        fmthint="Topas xye",
    )
    phase = project.add_phase(
        str(ROOT / "analysis" / "cuwo4_from_2101690.cif"),
        phasename="CuWO4_triclinic",
        histograms=[histogram],
        fmthint="CIF",
    )

    # Only the HAP scale carries the intensity normalization.
    histogram.SampleParameters["Scale"] = [1.0, False]
    phase.set_HAP_refinements({"Scale": True}, [histogram])

    # Neutralize every unused phase/sample nuisance contribution.
    hap = phase.data["Histograms"][histogram.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1.0e6, 1.0e6, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]
    histogram.SampleParameters["Shift"] = [0.0, False]
    histogram.SampleParameters["Transparency"] = [0.0, False]
    histogram.SampleParameters["SurfRoughA"] = [0.0, False]
    histogram.SampleParameters["SurfRoughB"] = [0.0, False]

    inst = histogram.InstrumentParameters
    for key, value in {
        "Zero": 0.30,
        "U": 20.0,
        "V": 0.0,
        "W": 20.0,
        "X": 6.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.04,
    }.items():
        inst[key][1] = value
        inst[key][2] = False

    histogram.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [1400.0, -350.0, 180.0, -90.0, 45.0, -20.0, 8.0, -3.0],
                "refine": True,
            },
        }
    )
    project.set_Controls("cycles", 12)
    project.save()
    for variable in [":0:U", ":0:W", ":0:X"]:
        project.set_Controls("parmMin", 0.0, variable=variable)
    project.set_Controls("parmMin", 0.002, variable=":0:SH/L")

    run(project, histogram, phase, "background + phase scale")
    phase.set_refinements({"Cell": True})
    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    run(project, histogram, phase, "cell + zero")
    run(project, histogram, phase, "cell/zero replay")

    histogram.set_refinements({"Instrument Parameters": ["W"]})
    run(project, histogram, phase, "add W")
    histogram.set_refinements({"Instrument Parameters": ["U", "X"]})
    run(project, histogram, phase, "common U/W/X")
    histogram.set_refinements({"Instrument Parameters": ["SH/L"]})
    run(project, histogram, phase, "add axial asymmetry")
    run(project, histogram, phase, "full replay")
    project.save()


if __name__ == "__main__":
    main()
