#!/usr/bin/env python3
"""Challenge polarization, surface roughness, and March-Dollase texture.

Each model starts from the same clean two-phase baseline so that rejected
terms cannot leak into later trials.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / "analysis" / "two_phase_wo3_niggli.gpx"


def correlations(project: G2sc.G2Project, target: str, cutoff: float = 0.5):
    cov = project.data["Covariance"]["data"]
    names = list(cov["varyList"])
    if target not in names:
        return []
    index = names.index(target)
    matrix = np.asarray(cov["covMatrix"], dtype=float)
    sigmas = np.asarray(cov["sig"], dtype=float)
    corr = matrix[index] / (sigmas[index] * sigmas)
    result = []
    for name, value in zip(names, corr):
        if name != target and abs(value) >= cutoff:
            result.append((name, float(value)))
    return sorted(result, key=lambda item: abs(item[1]), reverse=True)


def summarize(project, parameter_names):
    histogram = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    dep = cov.get("depSigDict", {})
    result = {
        "Rwp_percent": float(histogram.residuals["wR"]),
        "Rp_percent": float(histogram.residuals["R"]),
        "GOF": float(cov["Rvals"]["GOF"]),
        "max_shift_over_sigma": float(cov["Rvals"]["Max shft/sig"]),
        "mass_fractions": {
            key: [float(value), float(esd)]
            for key, (value, esd) in histogram.ComputeMassFracs().items()
        },
        "parameters": {},
    }
    names = list(cov["varyList"])
    values = np.asarray(cov["variables"], dtype=float)
    sigmas = np.asarray(cov["sig"], dtype=float)
    for parameter in parameter_names:
        if parameter in names:
            index = names.index(parameter)
            value, esd = float(values[index]), float(sigmas[index])
        elif parameter in dep:
            value, esd = map(float, dep[parameter])
        else:
            value, esd = None, None
        result["parameters"][parameter] = {
            "value": value,
            "esd": esd,
            "correlations_abs_ge_0.5": correlations(project, parameter),
        }
    return result


def run_trial(name, configure, parameter_names):
    destination = ROOT / "analysis" / f"trial_{name}.gpx"
    project = G2sc.G2Project(str(BASELINE), newgpx=str(destination))
    project.set_Controls("cycles", 15)
    configure(project)
    project.save()
    project.do_refinements([{}])
    project.do_refinements([{}])
    project.save()
    result = summarize(project, parameter_names)
    result["trial"] = name
    print(json.dumps(result, indent=2))
    return result


def configure_polarization(project):
    histogram = project.histogram(0)
    histogram.InstrumentParameters["Polariz."][2] = True
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")


def configure_rough_b(project):
    sample = project.histogram(0).SampleParameters
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.01, True]
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")


def configure_rough_ab(project):
    sample = project.histogram(0).SampleParameters
    sample["SurfRoughA"] = [0.5, True]
    sample["SurfRoughB"] = [0.01, True]
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")


def configure_texture(axis):
    def configure(project):
        histogram = project.histogram(0)
        hap = project.phase(0).data["Histograms"][histogram.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        project.set_Controls("parmMin", 0.2, variable="0:0:MD")
        project.set_Controls("parmMax", 5.0, variable="0:0:MD")

    return configure


def main():
    G2sc.SetPrintLevel("warn")
    results = []
    results.append(run_trial("polarization", configure_polarization, [":0:Polariz."]))
    results.append(run_trial("rough_b", configure_rough_b, [":0:SurfRoughB"]))
    results.append(
        run_trial(
            "rough_ab",
            configure_rough_ab,
            [":0:SurfRoughA", ":0:SurfRoughB"],
        )
    )
    for axis in ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)):
        label = "texture_" + "".join(str(value) for value in axis)
        results.append(run_trial(label, configure_texture(axis), ["0:0:MD"]))
    print("SUMMARY_JSON")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
