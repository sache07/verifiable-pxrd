#!/usr/bin/env python3
"""Challenge the coarse WO3 record with the physical neutron structure."""

from __future__ import annotations

import copy

from GSASII import GSASIIscriptable as G2sc


OLD_NAME = "WO3_P21n"
NEW_NAME = "WO3_P21n_neutron"


project = G2sc.G2Project(
    "trial_atoms_texture_reentry.gpx", newgpx="trial_wo3_neutron.gpx"
)
histogram = project.histogram(0)
old_phase = project.phase(OLD_NAME)
old_hap = copy.deepcopy(old_phase.data["Histograms"][histogram.name])

new_phase = project.add_phase(
    "wo3_neutron_transformed.cif",
    phasename=NEW_NAME,
    histograms=[histogram],
    fmthint="CIF",
)
new_phase.data["Histograms"][histogram.name] = old_hap
new_phase.data["Histograms"][histogram.name]["hId"] = histogram.id
new_phase.data["General"]["Cell"][0] = True
for atom in new_phase.atoms():
    atom.refinement_flags = ""

# Scriptable GSAS-II has no public phase-removal method. Remove the old phase
# from the same three tree locations populated by add_phase, then rebuild IDs.
del project.data["Phases"][OLD_NAME]
del histogram.data["Reflection Lists"][OLD_NAME]
for tree_item in project.names:
    if tree_item[0] == "Phases":
        tree_item.remove(OLD_NAME)
        break
project.index_ids()
project.update_ids()
project.save()
project.reload()

for replay in range(2):
    project.refine()
    histogram = project.histogram(0)
    phase = project.phase(NEW_NAME)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    print(
        "WO3_NEUTRON_REPLAY",
        replay + 1,
        "Rwp",
        histogram.residuals["wR"],
        "converged",
        rvals.get("converged"),
        "max_shift_esd",
        rvals.get("Max shft/sig"),
        "cell",
        phase.get_cell(),
        "fractions",
        histogram.ComputeMassFracs(),
        flush=True,
    )

project.phase(NEW_NAME).export_CIF("trial_wo3_neutron.cif")
project.save()
