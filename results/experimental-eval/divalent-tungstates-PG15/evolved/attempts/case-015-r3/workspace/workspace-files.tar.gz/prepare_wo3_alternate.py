#!/usr/bin/env python3
"""Transform COD 2311041 to the near-orthogonal monoclinic WO3 setting."""

from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(__file__).resolve().parent
SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/31/10/2311041.cif"
)
TARGET = ROOT / "wo3_neutron_transformed.cif"


structure = Structure.from_file(SOURCE)

# The source uses a long-c P21/c cell (beta about 136 degrees). This unimodular
# basis change gives the equivalent near-orthogonal cell used for the present
# powder pattern: a' = -a-c, b' = b, c' = a.
transform = np.array([[-1, 0, -1], [0, 1, 0], [1, 0, 0]], dtype=float)
new_lattice = Lattice(transform @ structure.lattice.matrix)
new_fractional = np.array([site.frac_coords for site in structure]) @ np.linalg.inv(
    transform
)
transformed = Structure(
    new_lattice,
    [site.species for site in structure],
    new_fractional,
    to_unit_cell=True,
)

analyzer = SpacegroupAnalyzer(transformed, symprec=0.05, angle_tolerance=3)
symmetrized = analyzer.get_symmetrized_structure()
a, b, c = transformed.lattice.abc
alpha, beta, gamma = transformed.lattice.angles
lines = [
    "data_WO3_neutron_transformed",
    "_audit_creation_method 'unimodular transform of COD 2311041'",
    "_chemical_formula_sum 'O3 W'",
    "_space_group_IT_number 14",
    "_symmetry_space_group_name_Hall '-P 2yn'",
    "_symmetry_space_group_name_H-M 'P 1 21/n 1'",
    f"_cell_length_a {a:.8f}",
    f"_cell_length_b {b:.8f}",
    f"_cell_length_c {c:.8f}",
    f"_cell_angle_alpha {alpha:.8f}",
    f"_cell_angle_beta {beta:.8f}",
    f"_cell_angle_gamma {gamma:.8f}",
    f"_cell_volume {transformed.volume:.8f}",
    "_cell_formula_units_Z 8",
    "loop_",
    "_symmetry_equiv_pos_as_xyz",
]
operators = [
    "x,y,z",
    "-x+1/2,y+1/2,-z+1/2",
    "-x,-y,-z",
    "x-1/2,-y-1/2,z-1/2",
]
for index, operation in enumerate(operators, 1):
    lines.append(operation)
lines.extend(
    [
        "loop_",
        "_atom_site_label",
        "_atom_site_type_symbol",
        "_atom_site_fract_x",
        "_atom_site_fract_y",
        "_atom_site_fract_z",
        "_atom_site_occupancy",
        "_atom_site_U_iso_or_equiv",
    ]
)
counts: dict[str, int] = {}
for group in symmetrized.equivalent_sites:
    site = group[0]
    symbol = site.specie.symbol
    counts[symbol] = counts.get(symbol, 0) + 1
    label = f"{symbol}{counts[symbol]}"
    x, y, z = np.mod(site.frac_coords, 1.0)
    lines.append(f"{label} {symbol} {x:.8f} {y:.8f} {z:.8f} 1.0 0.0")
TARGET.write_text("\n".join(lines) + "\n")
print(TARGET)
print(transformed.lattice.parameters)
