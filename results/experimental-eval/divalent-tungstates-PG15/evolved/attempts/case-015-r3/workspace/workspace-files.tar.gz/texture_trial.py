#!/usr/bin/env python3
"""March-Dollase axis challenges from the converged three-phase baseline."""

from __future__ import annotations

import argparse

from GSASII import GSASIIscriptable as G2sc


PHASE_NAMES = {
    "znwo4": "ZnWO4_wolframite",
    "wo3": "WO3_P21n",
    "zno": "ZnO_wurtzite",
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=PHASE_NAMES)
    parser.add_argument("axis", help="three digits, for example 101")
    parser.add_argument("output")
    args = parser.parse_args()
    axis = [int(char) for char in args.axis]

    project = G2sc.G2Project("trial_three_displacement.gpx", newgpx=args.output)
    hist = project.histogram(0)
    phase = project.phase(PHASE_NAMES[args.phase])
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = axis
    project.set_Controls("parmMin", 0.1, variable=f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 10.0, variable=f"{phase.id}:0:MD")
    project.save()

    for replay in range(2):
        project.refine()
        print(
            "TEXTURE_RESULT",
            args.phase,
            args.axis,
            replay + 1,
            "Rwp",
            hist.residuals["wR"],
            "MD",
            pref[1],
            "fractions",
            hist.ComputeMassFracs(),
            "frozen",
            project.get_Frozen(),
        )
    project.save()


if __name__ == "__main__":
    main()
