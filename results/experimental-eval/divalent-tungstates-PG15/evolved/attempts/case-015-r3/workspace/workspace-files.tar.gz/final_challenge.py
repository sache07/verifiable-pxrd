#!/usr/bin/env python3
"""Reversible final-model challenges after the WO3 source replacement."""

from __future__ import annotations

import argparse

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument(
    "mode",
    choices=[
        "no_strain",
        "size",
        "strain",
        "combined",
        "no_texture",
        "source_atoms",
    ],
)
parser.add_argument("source")
parser.add_argument("output")
args = parser.parse_args()

project = G2sc.G2Project(args.source, newgpx=args.output)
histogram = project.histogram(0)
wo3 = project.phase("WO3_P21n_neutron")
znwo4 = project.phase("ZnWO4_wolframite")
wo3_hap = wo3.data["Histograms"][histogram.name]
znwo4_hap = znwo4.data["Histograms"][histogram.name]

if args.mode == "no_strain":
    wo3_hap["Mustrain"][1][:] = [1.0, 1.0, 1.0]
    wo3_hap["Mustrain"][2][:] = [False, False, False]
elif args.mode == "size":
    wo3_hap["Mustrain"][1][:] = [1.0, 1.0, 1.0]
    wo3_hap["Mustrain"][2][:] = [False, False, False]
    wo3_hap["Size"][1][:] = [1.0, 10.0, 1.0]
    wo3_hap["Size"][2][:] = [True, False, False]
    project.set_Controls("parmMin", 0.001, variable=f"{wo3.id}:0:Size;i")
    project.set_Controls("parmMax", 10.0, variable=f"{wo3.id}:0:Size;i")
elif args.mode == "strain":
    wo3_hap["Size"][1][:] = [10.0, 10.0, 1.0]
    wo3_hap["Size"][2][:] = [False, False, False]
    wo3_hap["Mustrain"][1][:] = [1000.0, 1.0, 1.0]
    wo3_hap["Mustrain"][2][:] = [True, False, False]
    project.set_Controls("parmMin", 0.0, variable=f"{wo3.id}:0:Mustrain;i")
elif args.mode == "combined":
    wo3_hap["Size"][1][:] = [1.0, 10.0, 1.0]
    wo3_hap["Size"][2][:] = [True, False, False]
    project.set_Controls("parmMin", 0.001, variable=f"{wo3.id}:0:Size;i")
    project.set_Controls("parmMax", 10.0, variable=f"{wo3.id}:0:Size;i")
elif args.mode == "no_texture":
    znwo4_hap["Pref.Ori."][1] = 1.0
    znwo4_hap["Pref.Ori."][2] = False
elif args.mode == "source_atoms":
    source_coordinates = {
        "W": (0.0, 0.18258, 0.25),
        "Zn": (0.5, 0.6840, 0.25),
        "O1": (0.2169, 0.1051, -0.0637),
        "O2": (0.2565, 0.3777, 0.3996),
    }
    for atom in znwo4.atoms():
        atom.coordinates = source_coordinates[atom.label]
        atom.refinement_flags = ""

project.save()
for replay in range(2):
    project.refine()
    histogram = project.histogram(0)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    print(
        "FINAL_CHALLENGE",
        args.mode,
        replay + 1,
        "Rwp",
        histogram.residuals["wR"],
        "converged",
        rvals.get("converged"),
        "max_shift_esd",
        rvals.get("Max shft/sig"),
        "size",
        wo3_hap["Size"][1][0],
        "strain",
        wo3_hap["Mustrain"][1][0],
        "MD",
        znwo4_hap["Pref.Ori."][1],
        "fractions",
        histogram.ComputeMassFracs(),
        flush=True,
    )
project.save()
