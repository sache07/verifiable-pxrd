#!/usr/bin/env python3
"""Build reproducible GSAS-II trial refinements for phase-inventory tests."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

PHASES = {
    "znwo4": ("ZnWO4_wolframite", COD / "1/52/06/1520641.cif"),
    "zno": ("ZnO_wurtzite", COD / "9/00/41/9004178.cif"),
    "wo3_mono_a": ("WO3_P21n", COD / "1/52/89/1528915.cif"),
    "wo3_mono_b": ("WO3_P21c", COD / "1/56/35/1563541.cif"),
    "wo3_tri": ("WO3_P-1", COD / "2/10/62/2106293.cif"),
    "wo3_tet_130": ("WO3_P4ncc", COD / "1/52/15/1521532.cif"),
    "wo3_tet_129": ("WO3_P4nmm", COD / "1/52/15/1521533.cif"),
    "wo3_ortho": ("WO3_Pnma", COD / "2/10/73/2107312.cif"),
}


def neutralize_hap(phase, hist_name: str) -> None:
    """Set phase-specific broadening, texture, and corrections near neutral."""
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    # GSAS-II's allowed upper bound is 10 micrometres, effectively neutral here.
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [1.0, 1.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0:5] = ["MD", 1.0, False, [0, 0, 1], 0]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]
    hap["Scale"][0] = 1.0
    hap["Scale"][1] = True


def summarize(project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    result = {
        "stage": label,
        "residuals": hist.residuals,
        "instrument": {key: value[1] for key, value in inst.items() if key != "Type"},
        "sample": {
            key: value[0]
            for key, value in hist.SampleParameters.items()
            if isinstance(value, list) and value and isinstance(value[0], (int, float))
        },
        "phases": {},
        "frozen": project.get_Frozen(),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    try:
        result["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    print("TRIAL_SUMMARY " + json.dumps(result, default=float, sort_keys=True))
    return result


def replay(project, label: str, count: int = 2) -> None:
    """Refine, reopen implicitly, and replay to test numerical stability."""
    for index in range(count):
        project.refine()
        summarize(project, f"{label}_{index + 1}")


def build(
    output: Path,
    phase_keys: list[str],
    background_terms: int,
    profile_terms: list[str],
) -> None:
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        fmthint="xye",
    )
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": background_terms,
                "coeffs": [600.0] + [0.0] * (background_terms - 1),
            },
        }
    )
    hist.SampleParameters["Scale"][0] = 1.0
    hist.SampleParameters["Scale"][1] = False
    for key in phase_keys:
        name, source = PHASES[key]
        phase = project.add_phase(
            str(source), phasename=name, histograms=[hist], fmthint="CIF"
        )
        neutralize_hap(phase, hist.name)
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.save()

    # Establish background and all phase scales first.
    replay(project, "background_scales")

    # One angular correction (zero) and all cells, keeping background/scales active.
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    replay(project, "zero_cells")

    # Common nonnegative low-dimensional profile. U is excluded by default because
    # the unconstrained U/W/X trial required a strongly negative U.
    hist.set_refinements({"Instrument Parameters": profile_terms})
    for term in profile_terms:
        project.set_Controls("parmMin", 0.0, variable=f":0:{term}")
    replay(project, "common_profile")
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--phases", nargs="+", choices=sorted(PHASES), required=True)
    parser.add_argument("--background-terms", type=int, default=8)
    parser.add_argument(
        "--profile-terms", nargs="+", choices=["U", "W", "X"], default=["W", "X"]
    )
    args = parser.parse_args()
    build(args.output.resolve(), args.phases, args.background_terms, args.profile_terms)


if __name__ == "__main__":
    main()
