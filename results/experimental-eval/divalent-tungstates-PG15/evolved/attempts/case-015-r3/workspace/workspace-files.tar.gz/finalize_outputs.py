#!/usr/bin/env python3
"""Export the submitted profile and structures from the replayed GSAS-II model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_PROJECT = ROOT / "trial_final_wo3_strain_reentry.gpx"
FINAL_PROJECT = ROOT / "final.gpx"
PHASE_DIR = ROOT / "phases"

PHASE_FILES = {
    "ZnWO4_wolframite": "znwo4.cif",
    "WO3_P21n_neutron": "wo3.cif",
    "ZnO_wurtzite": "zno.cif",
}


def main() -> None:
    # The source project has already been reopened and replayed to convergence.
    # Copy it byte-for-byte, then use only the submitted copy for every export.
    shutil.copy2(SOURCE_PROJECT, FINAL_PROJECT)
    project = G2sc.G2Project(str(FINAL_PROJECT))
    histogram = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]

    assert rvals["converged"] is True
    assert not project.get_Frozen()
    assert set(PHASE_FILES) == {phase.name for phase in project.phases()}

    PHASE_DIR.mkdir(exist_ok=True)
    for phase in project.phases():
        phase.export_CIF(str(PHASE_DIR / PHASE_FILES[phase.name]))

    # GSAS-II uses searchsorted(high_limit) + 1, so reproduce its exact
    # refinement slice (including the nearest point just above the nominal
    # upper limit) rather than applying a second, slightly different mask.
    x, observed, weight, calculated, background, difference = (
        np.asarray(array) for array in histogram.data["data"][1]
    )
    low_limit, high_limit = histogram.data["Limits"][1]
    first = np.searchsorted(x, low_limit)
    last = np.searchsorted(x, high_limit) + 1
    profile = np.column_stack(
        (
            x[first:last],
            observed[first:last],
            calculated[first:last],
            difference[first:last],
            background[first:last],
        )
    )
    np.savetxt(
        ROOT / "fit.csv",
        profile,
        delimiter=",",
        header=(
            "two_theta_deg,observed_intensity,calculated_intensity,"
            "difference_intensity,background_intensity"
        ),
        comments="",
        fmt="%.10g",
    )

    # Report independent calculations from the submitted arrays as a guard
    # against accidental mismatch between the profile and project summary.
    obs = observed[first:last]
    calc = calculated[first:last]
    wt = weight[first:last]
    chisq = float(np.sum(wt * (obs - calc) ** 2))
    denominator = float(np.sum(wt * obs**2))
    n_obs = len(obs)
    n_var = len(covariance["varyList"])
    metrics = {
        "project": FINAL_PROJECT.name,
        "profile_points": n_obs,
        "two_theta_first_deg": float(x[first]),
        "two_theta_last_deg": float(x[last - 1]),
        "Rwp_percent": 100.0 * np.sqrt(chisq / denominator),
        "Rp_percent": 100.0 * np.sum(np.abs(obs - calc)) / np.sum(obs),
        "R_expected_percent": 100.0 * np.sqrt(n_obs / denominator),
        "chi_square": chisq,
        "reduced_chi_square": chisq / (n_obs - n_var),
        "goodness_of_fit": np.sqrt(chisq / (n_obs - n_var)),
        "refined_parameters": n_var,
        "max_shift_over_esd": rvals["Max shft/sig"],
        "fractions": histogram.ComputeMassFracs(),
    }
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
