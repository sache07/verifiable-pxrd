#!/usr/bin/env python3
"""One-phase-at-a-time coordinate refinement challenges."""

from __future__ import annotations

import argparse

from GSASII import GSASIIscriptable as G2sc


PHASE_NAMES = {
    "znwo4": "ZnWO4_wolframite",
    "wo3": "WO3_P21n",
    "zno": "ZnO_wurtzite",
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=PHASE_NAMES)
    parser.add_argument("output")
    args = parser.parse_args()

    project = G2sc.G2Project("trial_texture_znwo4_110.gpx", newgpx=args.output)
    hist = project.histogram(0)
    phase = project.phase(PHASE_NAMES[args.phase])
    phase.set_refinements({"Atoms": {"all": "X"}})
    project.save()
    for replay in range(2):
        project.refine()
        atoms = {
            atom.label: {
                "element": atom.element,
                "xyz": atom.coordinates,
                "occupancy": atom.occupancy,
                "uiso": atom.uiso,
            }
            for atom in phase.atoms()
        }
        print(
            "ATOM_RESULT",
            args.phase,
            replay + 1,
            "Rwp",
            hist.residuals["wR"],
            "atoms",
            atoms,
            "fractions",
            hist.ComputeMassFracs(),
            "frozen",
            project.get_Frozen(),
        )
    phase.export_CIF(args.output.rsplit(".", 1)[0] + ".cif")
    project.save()


if __name__ == "__main__":
    main()
