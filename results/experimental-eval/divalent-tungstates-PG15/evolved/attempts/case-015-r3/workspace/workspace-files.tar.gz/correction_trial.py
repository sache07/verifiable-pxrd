#!/usr/bin/env python3
"""Challenge common intensity corrections from a converged inventory model."""

from __future__ import annotations

import argparse

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", choices=["rough_b", "rough_ab", "polar_rough"])
    parser.add_argument("output")
    args = parser.parse_args()

    project = G2sc.G2Project("trial_wo3_mono_a.gpx", newgpx=args.output)
    hist = project.histogram(0)
    sample = hist.SampleParameters

    if args.model == "rough_b":
        sample["SurfRoughA"][:] = [0.0, False]
        sample["SurfRoughB"][:] = [0.03, True]
    else:
        sample["SurfRoughA"][:] = [0.5, True]
        sample["SurfRoughB"][:] = [0.05, True]
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughB")

    if args.model == "polar_rough":
        hist.InstrumentParameters["Polariz."][1:] = [0.8, True]
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")

    project.save()
    for replay in range(2):
        project.refine()
        print(
            "CORRECTION_RESULT",
            args.model,
            replay + 1,
            "Rwp",
            hist.residuals["wR"],
            "polar",
            hist.InstrumentParameters["Polariz."][1],
            "roughA",
            sample["SurfRoughA"][0],
            "roughB",
            sample["SurfRoughB"][0],
            "fractions",
            hist.ComputeMassFracs(),
            "frozen",
            project.get_Frozen(),
        )
    project.save()


if __name__ == "__main__":
    main()
