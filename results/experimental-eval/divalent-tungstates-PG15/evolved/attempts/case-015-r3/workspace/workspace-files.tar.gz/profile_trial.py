#!/usr/bin/env python3
"""One-at-a-time profile challenges from the accepted common baseline."""

from __future__ import annotations

import argparse

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "model", choices=["shl", "zn_size", "zn_strain", "wo3_size", "wo3_strain"]
    )
    parser.add_argument("output")
    args = parser.parse_args()

    project = G2sc.G2Project("trial_rough_ab.gpx", newgpx=args.output)
    hist = project.histogram(0)

    if args.model == "shl":
        hist.InstrumentParameters["SH/L"][1:] = [0.01, True]
        project.set_Controls("parmMin", 0.002, variable=":0:SH/L")
        project.set_Controls("parmMax", 1.0, variable=":0:SH/L")
    else:
        phase = project.phase("ZnWO4_wolframite" if args.model.startswith("zn_") else "WO3_P21n")
        if args.model.endswith("size"):
            phase.set_HAP_refinements(
                {
                    "Size": {
                        "type": "isotropic",
                        "refine": True,
                        "LGmix": {"value": 1.0, "refine": False},
                    }
                }
            )
        else:
            phase.set_HAP_refinements(
                {
                    "Mustrain": {
                        "type": "isotropic",
                        "refine": True,
                        "LGmix": {"value": 1.0, "refine": False},
                    }
                }
            )

    project.save()
    for replay in range(2):
        project.refine()
        values = {}
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            values[phase.name] = {
                "size": hap["Size"][1][0],
                "size_refine": hap["Size"][2][0],
                "strain": hap["Mustrain"][1][0],
                "strain_refine": hap["Mustrain"][2][0],
            }
        print(
            "PROFILE_RESULT",
            args.model,
            replay + 1,
            "Rwp",
            hist.residuals["wR"],
            "SHL",
            hist.InstrumentParameters["SH/L"][1],
            "W",
            hist.InstrumentParameters["W"][1],
            "X",
            hist.InstrumentParameters["X"][1],
            "phase_values",
            values,
            "fractions",
            hist.ComputeMassFracs(),
            "frozen",
            project.get_Frozen(),
        )
    project.save()


if __name__ == "__main__":
    main()
