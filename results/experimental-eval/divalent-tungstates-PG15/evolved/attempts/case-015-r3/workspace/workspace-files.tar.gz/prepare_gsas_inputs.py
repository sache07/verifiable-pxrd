#!/usr/bin/env python3
"""Convert the supplied count data to a GSAS-II xye histogram."""

from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
source = ROOT / "inputs" / "pattern.csv"
target = ROOT / "pattern.xye"

data = np.loadtxt(source, delimiter=",", skiprows=1)
x = data[:, 0]
y = data[:, 1]
sigma = np.sqrt(np.clip(y, 1.0, None))
np.savetxt(
    target,
    np.column_stack((x, y, sigma)),
    fmt=("%.8f", "%.8f", "%.8f"),
    header="two_theta_deg intensity sigma_poisson",
)
print(f"wrote {target} with {len(data)} points")
