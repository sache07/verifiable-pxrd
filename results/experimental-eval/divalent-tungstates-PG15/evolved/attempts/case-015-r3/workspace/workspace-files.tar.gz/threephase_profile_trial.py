#!/usr/bin/env python3
"""Profile challenges after the three-phase inventory was rebuilt."""

from __future__ import annotations

import argparse

from GSASII import GSASIIscriptable as G2sc


PHASE_NAMES = {
    "znwo4": "ZnWO4_wolframite",
    "wo3": "WO3_P21n",
    "zno": "ZnO_wurtzite",
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "model",
        choices=["shl"]
        + [f"{phase}_{term}" for phase in PHASE_NAMES for term in ("size", "strain")],
    )
    parser.add_argument("output")
    args = parser.parse_args()

    project = G2sc.G2Project("trial_threephase_rough.gpx", newgpx=args.output)
    hist = project.histogram(0)

    if args.model == "shl":
        hist.InstrumentParameters["SH/L"][1:] = [0.03, True]
        project.set_Controls("parmMin", 0.002, variable=":0:SH/L")
        project.set_Controls("parmMax", 1.0, variable=":0:SH/L")
    else:
        phase_key, term = args.model.split("_")
        phase = project.phase(PHASE_NAMES[phase_key])
        if term == "size":
            phase.set_HAP_refinements(
                {
                    "Size": {
                        "type": "isotropic",
                        "refine": True,
                        "LGmix": {"value": 1.0, "refine": False},
                    }
                }
            )
        else:
            phase.set_HAP_refinements(
                {
                    "Mustrain": {
                        "type": "isotropic",
                        "refine": True,
                        "LGmix": {"value": 1.0, "refine": False},
                    }
                }
            )
            phase_id = phase.id
            project.set_Controls("parmMin", 0.0, variable=f"{phase_id}:0:Mustrain;i")
            project.set_Controls("parmMax", 10000.0, variable=f"{phase_id}:0:Mustrain;i")

    project.save()
    for replay in range(2):
        project.refine()
        phase_values = {}
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            phase_values[phase.name] = {
                "size": hap["Size"][1][0],
                "size_refine": hap["Size"][2][0],
                "strain": hap["Mustrain"][1][0],
                "strain_refine": hap["Mustrain"][2][0],
            }
        print(
            "THREE_PROFILE_RESULT",
            args.model,
            replay + 1,
            "Rwp",
            hist.residuals["wR"],
            "SHL",
            hist.InstrumentParameters["SH/L"][1],
            "W",
            hist.InstrumentParameters["W"][1],
            "X",
            hist.InstrumentParameters["X"][1],
            "phase_values",
            phase_values,
            "fractions",
            hist.ComputeMassFracs(),
            "frozen",
            project.get_Frozen(),
        )
    project.save()


if __name__ == "__main__":
    main()
