#!/usr/bin/env python3
"""Test the two supported PbO isotropic-strain terms together."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_trial import summarize


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("shape", choices=["lorentz", "gauss", "mixed"])
    parser.add_argument(
        "--base", type=Path,
        default=ROOT / ".tmp" / "nuisance_polar_fixed_physical.gpx",
    )
    args = parser.parse_args()
    out = ROOT / ".tmp" / f"combined_strain_{args.shape}.gpx"
    gpx = G2sc.G2Project(str(args.base), newgpx=str(out))
    gpx.set_Frozen(None)
    gpx.set_Controls("cycles", 10)
    hist = gpx.histogram(0)
    starts = {1: 15000.0, 2: 23000.0}
    mix = {"lorentz": 1.0, "gauss": 0.0, "mixed": 0.5}[args.shape]
    for phase_index, value in starts.items():
        phase = gpx.phase(phase_index)
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = value
        hap["Mustrain"][1][2] = mix
        hap["Mustrain"][2][:] = [True, False, args.shape == "mixed"]
        vi = f"{phase.id}:{hist.id}:Mustrain;i"
        vm = f"{phase.id}:{hist.id}:Mustrain;mx"
        gpx.set_Controls("parmMin", 0.0, variable=vi)
        gpx.set_Controls("parmMax", 100000.0, variable=vi)
        gpx.set_Controls("parmMin", 0.0, variable=vm)
        gpx.set_Controls("parmMax", 1.0, variable=vm)
    gpx.save()
    history = []
    for label in ("combined", "replay"):
        gpx.refine(printFile=str(out.with_suffix(f".{label}.lst")))
        gpx.save()
        result = summarize(gpx, label)
        result["shape"] = args.shape
        result["broadening"] = {}
        for i in starts:
            phase = gpx.phase(i)
            hap = phase.data["Histograms"][hist.name]["Mustrain"]
            result["broadening"][phase.name] = {
                "microstrain": float(hap[1][0]),
                "lorentzian_fraction": float(hap[1][2]),
            }
        result["frozen"] = gpx.get_Frozen()
        print("COMBINED " + json.dumps(result, sort_keys=True))
        history.append(result)
    (ROOT / ".tmp" / f"combined_strain_{args.shape}.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
