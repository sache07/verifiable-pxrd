#!/usr/bin/env python3
"""Damped, reopen/replay convergence for the pruned five-phase model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from converge_five_phase import prune_and_bound
from refine_trial import summarize


ROOT = Path(__file__).resolve().parent
OUT = ROOT / ".tmp" / "five_phase_damped.gpx"


def main() -> None:
    source = ROOT / ".tmp" / "broadening_p4_strain.gpx"
    gpx = G2sc.G2Project(str(source), newgpx=str(OUT))
    history = []
    for cycle in range(4):
        prune_and_bound(gpx)
        controls = gpx["Controls"]["data"]
        controls["shift factor"] = 0.2
        controls["max cyc"] = 20
        controls["min dM/M"] = 0.0001
        gpx.save()
        gpx.refine(printFile=str(OUT.with_suffix(f".damped{cycle + 1}.lst")))
        gpx.save()
        result = summarize(gpx, f"damped_replay_{cycle + 1}")
        result["frozen"] = gpx.get_Frozen()
        history.append(result)
        shutil.copy2(OUT, ROOT / ".tmp" / f"five_phase_damped_{cycle + 1}.gpx")
        gpx = G2sc.G2Project(str(OUT))
    (ROOT / ".tmp" / "five_phase_damped.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
