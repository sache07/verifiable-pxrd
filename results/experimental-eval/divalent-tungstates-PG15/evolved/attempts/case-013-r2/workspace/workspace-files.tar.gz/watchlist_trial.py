#!/usr/bin/env python3
"""Re-challenge plausible alternate phases against the clean common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_trial import cod_path, neutralize_hap, summarize


ROOT = Path(__file__).resolve().parent
CANDIDATES = {
    "raspite": ("PbWO4_raspite_watch", "9007617"),
    "defect": ("Pb7W8O28.8_defect_watch", "9016035"),
    "litharge": ("PbO_litharge_watch", "9012700"),
}


def fix_displacements(gpx) -> None:
    """Use common Uiso where possible, retaining fixed source Uij otherwise."""
    for item in gpx.phases():
        for atom in item.atoms():
            atom.refinement_flags = " "
            try:
                atom.uiso = 0.010 if atom.element == "O" else 0.005
            except Exception:
                # Some source records use anisotropic displacement tensors.
                # Keep those physical source values fixed for a watch-list test.
                pass


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", choices=sorted(CANDIDATES))
    parser.add_argument(
        "--base", type=Path,
        default=ROOT / ".tmp" / "combined_strain_gauss.gpx",
    )
    args = parser.parse_args()

    name, cod_id = CANDIDATES[args.candidate]
    out = ROOT / ".tmp" / f"watch_{args.candidate}.gpx"
    gpx = G2sc.G2Project(str(args.base), newgpx=str(out))
    gpx.set_Frozen(None)
    gpx.set_Controls("cycles", 8)
    hist = gpx.histogram(0)
    phase = gpx.add_phase(str(cod_path(cod_id)), phasename=name, histograms=[hist])
    neutralize_hap(phase, hist.name)
    fix_displacements(gpx)

    # Give the candidate a small positive start. Keep its cell at the physical
    # source value during the first challenge so a weak/absent phase cannot
    # manufacture a match by distorting its metric.
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][:] = [0.05, True]
    phase.set_refinements({"Cell": False})
    gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    gpx.save()

    history = []
    for label in ("fixed_cell", "replay"):
        gpx.refine(printFile=str(out.with_suffix(f".{label}.lst")))
        gpx.save()
        result = summarize(gpx, label)
        result["candidate"] = name
        result["candidate_cod_id"] = cod_id
        result["candidate_scale"] = float(hap["Scale"][0])
        result["frozen"] = gpx.get_Frozen()
        history.append(result)
    (ROOT / ".tmp" / f"watch_{args.candidate}.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
