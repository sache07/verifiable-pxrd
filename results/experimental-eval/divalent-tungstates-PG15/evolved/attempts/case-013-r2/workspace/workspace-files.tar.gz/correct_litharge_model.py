#!/usr/bin/env python3
"""Correct the COD origin conversion for litharge and re-refine its scale."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_trial import summarize


ROOT = Path(__file__).resolve().parent
OUT = ROOT / ".tmp" / "corrected_litharge.gpx"


def main() -> None:
    gpx = G2sc.G2Project(str(ROOT / "final.gpx"), newgpx=str(OUT))
    hist = gpx.histogram(0)
    phase = gpx.phase(4)

    # COD 9012700 is P4/nmm origin choice 1. GSAS-II's automatic origin
    # conversion placed Pb on a general-multiplicity site. The equivalent
    # origin-choice-2 positions are Pb 2c (1/4,1/4,z) and O 2a (3/4,1/4,0).
    old_scale = float(phase.data["Histograms"][hist.name]["Scale"][0])
    phase.data["Atoms"].clear()
    phase.add_atom(0.25, 0.25, 0.23510, "Pb", "Pb", occ=1.0, uiso=0.005)
    phase.add_atom(0.75, 0.25, 0.0, "O", "O", occ=1.0, uiso=0.010)
    phase.data["Histograms"][hist.name]["Scale"][0] = 4.0 * old_scale
    gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")

    history = []
    for replay in range(4):
        gpx.set_Frozen(None)
        controls = gpx["Controls"]["data"]
        controls["shift factor"] = 0.2
        controls["max cyc"] = 20
        controls["min dM/M"] = 0.0001
        gpx.save()
        gpx.refine(printFile=str(OUT.with_suffix(f".replay{replay + 1}.lst")))
        gpx.save()
        result = summarize(gpx, f"reopened_replay_{replay + 1}")
        result.update({
            "litharge_composition": phase.composition,
            "litharge_atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "occupancy": atom.occupancy,
                    "multiplicity": atom.mult,
                }
                for atom in phase.atoms()
            ],
            "frozen": gpx.get_Frozen(),
        })
        history.append(result)
        gpx = G2sc.G2Project(str(OUT))
        hist = gpx.histogram(0)
        phase = gpx.phase(4)
    (ROOT / ".tmp" / "corrected_litharge.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
