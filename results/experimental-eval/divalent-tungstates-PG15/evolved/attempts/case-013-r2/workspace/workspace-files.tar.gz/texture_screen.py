#!/usr/bin/env python3
"""Screen symmetry-distinct March-Dollase axes with all other terms fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_trial import summarize


ROOT = Path(__file__).resolve().parent
AXES = {
    0: [(0, 0, 1), (1, 0, 0), (1, 1, 0)],
    1: [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)],
    2: [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)],
    3: [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)],
}


def freeze_all(gpx) -> None:
    hist = gpx.histogram(0)
    hist.data["Background"][0][1] = False
    for item in hist.data["Instrument Parameters"]:
        for value in item.values():
            if isinstance(value, list) and len(value) > 2:
                value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in gpx.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False
        for key in ("Size", "Mustrain"):
            hap[key][2] = [False] * len(hap[key][2])
            hap[key][5] = [False] * len(hap[key][5])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", type=int, choices=range(4))
    parser.add_argument(
        "--base", type=Path,
        default=ROOT / ".tmp" / "combined_strain_gauss.gpx",
    )
    args = parser.parse_args()
    results = []

    for axis in AXES[args.phase]:
        tag = "".join(str(i) for i in axis)
        out = ROOT / ".tmp" / f"texture_p{args.phase}_{tag}.gpx"
        gpx = G2sc.G2Project(str(args.base), newgpx=str(out))
        gpx.set_Frozen(None)
        gpx.set_Controls("cycles", 5)
        freeze_all(gpx)
        hist = gpx.histogram(0)
        phase = gpx.phase(args.phase)
        pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
        pref[0] = "MD"
        pref[1] = 1.0
        pref[2] = True
        pref[3] = list(axis)
        variable = f"{phase.id}:{hist.id}:MD"
        gpx.set_Controls("parmMin", 0.2, variable=variable)
        gpx.set_Controls("parmMax", 5.0, variable=variable)
        gpx.save()
        gpx.refine(printFile=str(out.with_suffix(".lst")))
        gpx.save()
        result = summarize(gpx, "texture_screen")
        result.update({
            "phase": phase.name,
            "phase_index": args.phase,
            "axis": list(axis),
            "march_dollase": float(pref[1]),
            "frozen": gpx.get_Frozen(),
        })
        results.append(result)
        print("TEXTURE " + json.dumps(result, sort_keys=True))
    (ROOT / ".tmp" / f"texture_p{args.phase}.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
