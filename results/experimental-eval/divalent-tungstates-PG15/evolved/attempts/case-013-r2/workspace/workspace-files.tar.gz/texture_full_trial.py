#!/usr/bin/env python3
"""Re-converge and replay one selected March-Dollase texture model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_trial import summarize


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", type=int, choices=range(4))
    parser.add_argument("h", type=int)
    parser.add_argument("k", type=int)
    parser.add_argument("l", type=int)
    parser.add_argument(
        "--base", type=Path,
        default=ROOT / ".tmp" / "combined_strain_gauss.gpx",
    )
    args = parser.parse_args()
    axis = [args.h, args.k, args.l]
    tag = "".join(str(i) for i in axis)
    out = ROOT / ".tmp" / f"texture_full_p{args.phase}_{tag}.gpx"
    gpx = G2sc.G2Project(str(args.base), newgpx=str(out))
    gpx.set_Frozen(None)
    gpx.set_Controls("cycles", 8)
    hist = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = axis
    variable = f"{phase.id}:{hist.id}:MD"
    gpx.set_Controls("parmMin", 0.2, variable=variable)
    gpx.set_Controls("parmMax", 5.0, variable=variable)
    gpx.save()

    history = []
    for label in ("full", "replay"):
        gpx.refine(printFile=str(out.with_suffix(f".{label}.lst")))
        gpx.save()
        result = summarize(gpx, label)
        result.update({
            "phase": phase.name,
            "axis": axis,
            "march_dollase": float(pref[1]),
            "frozen": gpx.get_Frozen(),
        })
        history.append(result)
        print("TEXTURE_FULL " + json.dumps(result, sort_keys=True))
    (ROOT / ".tmp" / f"texture_full_p{args.phase}_{tag}.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
