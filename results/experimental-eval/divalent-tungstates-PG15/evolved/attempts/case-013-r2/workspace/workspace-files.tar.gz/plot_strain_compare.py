#!/usr/bin/env python3
"""Diagnostic comparison of isotropic and uniaxial massicot profile fits."""

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def profile(path):
    project = G2sc.G2Project(str(path))
    hist = project.histogram(0)
    return tuple(hist.getdata(key) for key in ("x", "yobs", "ycalc"))


x, y, iso = profile(ROOT / ".tmp" / "five_phase_damped_3.gpx")
_, _, aniso = profile(ROOT / ".tmp" / "strain_full_p1_100.gpx")
np.savez_compressed(ROOT / ".tmp" / "strain_compare_data.npz",
                    x=x, observed=y, isotropic=iso, anisotropic=aniso)
