#!/usr/bin/env python3
"""Challenge isotropic phase size or strain one phase at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_trial import summarize


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", type=int, choices=range(5))
    parser.add_argument("term", choices=["size", "strain"])
    parser.add_argument(
        "--base", type=Path,
        default=ROOT / ".tmp" / "nuisance_polar_fixed_physical.gpx",
    )
    args = parser.parse_args()
    tag = f"broadening_p{args.phase}_{args.term}"
    out = ROOT / ".tmp" / f"{tag}.gpx"
    gpx = G2sc.G2Project(str(args.base), newgpx=str(out))
    gpx.set_Frozen(None)
    gpx.set_Controls("cycles", 8)
    hist = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]

    if args.term == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][1][2] = 1.0
        hap["Size"][2][:] = [True, False, False]
        variable = f"{phase.id}:{hist.id}:Size;i"
        gpx.set_Controls("parmMin", 0.001, variable=variable)
        gpx.set_Controls("parmMax", 10.0, variable=variable)
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2][:] = [True, False, False]
        variable = f"{phase.id}:{hist.id}:Mustrain;i"
        gpx.set_Controls("parmMin", 0.0, variable=variable)
        gpx.set_Controls("parmMax", 100000.0, variable=variable)

    gpx.save()
    history = []
    for label in ("challenge", "replay"):
        gpx.refine(printFile=str(out.with_suffix(f".{label}.lst")))
        gpx.save()
        result = summarize(gpx, label)
        result["tested_phase"] = phase.name
        result["term"] = args.term
        result["value"] = float(
            hap["Size"][1][0] if args.term == "size" else hap["Mustrain"][1][0]
        )
        result["frozen"] = gpx.get_Frozen()
        print("BROADENING " + json.dumps(result, sort_keys=True))
        history.append(result)
    (ROOT / ".tmp" / f"{tag}.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
