#!/usr/bin/env python3
"""Full damped/reopened trial for a selected massicot uniaxial strain axis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_trial import summarize


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("h", type=int)
    parser.add_argument("k", type=int)
    parser.add_argument("l", type=int)
    args = parser.parse_args()
    axis = [args.h, args.k, args.l]
    tag = "".join(str(i) for i in axis)
    screen = ROOT / ".tmp" / f"strain_axis_p1_{tag}.gpx"
    base = ROOT / ".tmp" / "five_phase_damped_3.gpx"
    out = ROOT / ".tmp" / f"strain_full_p1_{tag}.gpx"

    # Take the screened strain values, but retain all active refinements from
    # the clean base project.
    screened = G2sc.G2Project(str(screen))
    shist = screened.histogram(0)
    sstrain = screened.phase(1).data["Histograms"][shist.name]["Mustrain"]
    starts = [float(sstrain[1][0]), float(sstrain[1][1])]

    gpx = G2sc.G2Project(str(base), newgpx=str(out))
    hist = gpx.histogram(0)
    strain = gpx.phase(1).data["Histograms"][hist.name]["Mustrain"]
    strain[0] = "uniaxial"
    strain[1][:] = [starts[0], starts[1], 0.0]
    strain[2][:] = [True, True, False]
    strain[3] = axis
    for suffix in ("i", "a"):
        variable = f"1:{hist.id}:Mustrain;{suffix}"
        gpx.set_Controls("parmMin", 0.0, variable=variable)
        gpx.set_Controls("parmMax", 100000.0, variable=variable)

    history = []
    for replay in range(3):
        gpx.set_Frozen(None)
        controls = gpx["Controls"]["data"]
        controls["shift factor"] = 0.2
        controls["max cyc"] = 20
        controls["min dM/M"] = 0.0001
        gpx.save()
        gpx.refine(printFile=str(out.with_suffix(f".replay{replay + 1}.lst")))
        gpx.save()
        result = summarize(gpx, f"reopened_replay_{replay + 1}")
        result.update({
            "axis": axis,
            "equatorial_microstrain": float(strain[1][0]),
            "axial_microstrain": float(strain[1][1]),
            "frozen": gpx.get_Frozen(),
        })
        history.append(result)
        gpx = G2sc.G2Project(str(out))
        hist = gpx.histogram(0)
        strain = gpx.phase(1).data["Histograms"][hist.name]["Mustrain"]
    (ROOT / ".tmp" / f"strain_full_p1_{tag}.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
