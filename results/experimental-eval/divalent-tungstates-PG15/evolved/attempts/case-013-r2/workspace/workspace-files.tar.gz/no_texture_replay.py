#!/usr/bin/env python3
"""Re-optimize the accepted anisotropic model with massicot texture removed."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_trial import summarize


ROOT = Path(__file__).resolve().parent
OUT = ROOT / ".tmp" / "no_texture_anis.gpx"


def main() -> None:
    source = ROOT / ".tmp" / "strain_full_p1_100.gpx"
    gpx = G2sc.G2Project(str(source), newgpx=str(OUT))
    hist = gpx.histogram(0)
    pref = gpx.phase(1).data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = False
    history = []
    for replay in range(3):
        gpx.set_Frozen(None)
        controls = gpx["Controls"]["data"]
        controls["shift factor"] = 0.2
        controls["max cyc"] = 20
        controls["min dM/M"] = 0.0001
        gpx.save()
        gpx.refine(printFile=str(OUT.with_suffix(f".replay{replay + 1}.lst")))
        gpx.save()
        result = summarize(gpx, f"reopened_replay_{replay + 1}")
        result["frozen"] = gpx.get_Frozen()
        history.append(result)
        gpx = G2sc.G2Project(str(OUT))
    (ROOT / ".tmp" / "no_texture_anis.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
