#!/usr/bin/env python3
"""Replay a converged inventory while challenging selected nuisance terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_trial import summarize


ROOT = Path(__file__).resolve().parent


def set_fixed_uiso(gpx, physical: bool) -> None:
    for phase in gpx.phases():
        for atom in phase.atoms():
            atom.uiso = 0.010 if physical and atom.element == "O" else 0.005
            atom.refinement_flags = " "


def set_heavy_group_uiso(gpx) -> None:
    gpx.save()
    groups = []
    for phase in gpx.phases():
        variables = []
        for index, atom in enumerate(phase.atoms()):
            if atom.element == "O":
                atom.uiso = 0.010
                atom.refinement_flags = " "
            else:
                atom.uiso = 0.005
                atom.refinement_flags = "U"
                variables.append(f"{phase.id}::AUiso:{index}")
        groups.append(variables)
    gpx.save()
    for variables in groups:
        if len(variables) > 1:
            gpx.add_EquivConstr(variables, reloadIdx=False)
        for variable in variables:
            gpx.set_Controls("parmMin", 0.0, variable=variable)
            gpx.set_Controls("parmMax", 0.05, variable=variable)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=[
        "polar", "shl", "polar_shl", "fixed_uniform005",
        "fixed_physical", "polar_fixed_physical", "heavy_group_uiso",
        "polar_heavy_group_uiso", "polar_fixed_physical_shl",
        "shift_polar_fixed_physical",
    ])
    parser.add_argument(
        "--base",
        type=Path,
        default=ROOT / ".tmp" / "trial_stolzite_massicot_altwo3_superpbo.gpx",
    )
    parser.add_argument("--outdir", type=Path, default=ROOT / ".tmp")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    out = args.outdir / f"nuisance_{args.mode}.gpx"
    gpx = G2sc.G2Project(str(args.base), newgpx=str(out))
    gpx.set_Frozen(None)
    gpx.set_Controls("cycles", 8)
    hist = gpx.histogram(0)

    if "fixed_uniform005" in args.mode:
        set_fixed_uiso(gpx, False)
    if "fixed_physical" in args.mode:
        set_fixed_uiso(gpx, True)
    if "heavy_group_uiso" in args.mode:
        set_heavy_group_uiso(gpx)

    if "polar" in args.mode:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    if args.mode in ("shl", "polar_shl", "polar_fixed_physical_shl"):
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        gpx.set_Controls("parmMin", 0.001, variable=":0:SH/L")
        gpx.set_Controls("parmMax", 0.2, variable=":0:SH/L")
    if args.mode == "shift_polar_fixed_physical":
        inst = hist.data["Instrument Parameters"][0]
        inst["Zero"][0] = 0.0
        inst["Zero"][1] = 0.0
        inst["Zero"][2] = False
        sample = hist.data["Sample Parameters"]
        sample["Shift"][0] = -475.0
        sample["Shift"][1] = True
        gpx.set_Controls("parmMin", -2000.0, variable=":0:Shift")
        gpx.set_Controls("parmMax", 2000.0, variable=":0:Shift")

    gpx.save()
    history = []
    for label in ("challenge", "replay"):
        gpx.refine(printFile=str(out.with_suffix(f".{label}.lst")))
        gpx.save()
        history.append(summarize(gpx, label))
    (args.outdir / f"nuisance_{args.mode}.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
