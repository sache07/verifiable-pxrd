#!/usr/bin/env python3
"""Release the provisional weak litharge cell, then reopen and replay."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_trial import summarize


ROOT = Path(__file__).resolve().parent
OUT = ROOT / ".tmp" / "litharge_cell.gpx"


def main() -> None:
    gpx = G2sc.G2Project(str(ROOT / ".tmp" / "watch_litharge.gpx"), newgpx=str(OUT))
    gpx.set_Frozen(None)
    gpx.set_Controls("cycles", 8)
    phase = gpx.phase(4)
    phase.set_refinements({"Cell": True})
    gpx.save()
    gpx.refine(printFile=str(OUT.with_suffix(".cell.lst")))
    gpx.save()
    history = [summarize(gpx, "cell")]

    # A true reopen catches terms that only appear stable in memory.
    gpx = G2sc.G2Project(str(OUT))
    gpx.set_Controls("cycles", 8)
    gpx.refine(printFile=str(OUT.with_suffix(".replay.lst")))
    gpx.save()
    history.append(summarize(gpx, "reopened_replay"))
    for result in history:
        result["frozen"] = gpx.get_Frozen()
    (ROOT / ".tmp" / "litharge_cell.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
