#!/usr/bin/env python3
"""Build reproducible GSAS-II trial refinements for phase-inventory tests."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


MODELS = {
    "stolzite_massicot_wo3": [
        ("PbWO4_stolzite", "9009811"),
        ("PbO_massicot", "2310433"),
        ("WO3_monoclinic", "1528915"),
    ],
    "defect_massicot_wo3": [
        ("Pb7W8O28.8_defect", "9016035"),
        ("PbO_massicot", "2310433"),
        ("WO3_monoclinic", "1528915"),
    ],
    "both_massicot_wo3": [
        ("PbWO4_stolzite", "9009811"),
        ("Pb7W8O28.8_defect", "9016035"),
        ("PbO_massicot", "2310433"),
        ("WO3_monoclinic", "1528915"),
    ],
    "stolzite_litharge_wo3": [
        ("PbWO4_stolzite", "9009811"),
        ("PbO_litharge", "9012700"),
        ("WO3_monoclinic", "1528915"),
    ],
    "stolzite_massicot_altwo3": [
        ("PbWO4_stolzite", "9009811"),
        ("PbO_massicot", "2310433"),
        ("WO3_monoclinic_alt", "2311041"),
    ],
    "stolzite_massicot_wo3_raspite": [
        ("PbWO4_stolzite", "9009811"),
        ("PbWO4_raspite", "9007617"),
        ("PbO_massicot", "2310433"),
        ("WO3_monoclinic", "1528915"),
    ],
    "stolzite_massicot_wo3_superpbo": [
        ("PbWO4_stolzite", "9009811"),
        ("PbO_massicot", "2310433"),
        ("PbO_incommensurate_approx", "1533609"),
        ("WO3_monoclinic", "1528915"),
    ],
    "stolzite_massicot_altwo3_superpbo": [
        ("PbWO4_stolzite", "9009811"),
        ("PbO_massicot", "2310433"),
        ("PbO_incommensurate_approx", "1533609"),
        ("WO3_monoclinic_alt", "2311041"),
    ],
    "defect_massicot_altwo3_superpbo": [
        ("Pb7W8O28.8_defect", "9016035"),
        ("PbO_massicot", "2310433"),
        ("PbO_incommensurate_approx", "1533609"),
        ("WO3_monoclinic_alt", "2311041"),
    ],
    "stolzite_altwo3_superpbo": [
        ("PbWO4_stolzite", "9009811"),
        ("PbO_incommensurate_approx", "1533609"),
        ("WO3_monoclinic_alt", "2311041"),
    ],
}


def neutralize_hap(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1.0e6, 1.0e6, 0.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][4][:] = [1.0e6, 1.0e6, 1.0e6, 0.0, 0.0, 0.0]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 0.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def summarize(gpx, label: str) -> dict:
    hist = gpx.histogram(0)
    resid = dict(hist.data["data"][0])
    result = {
        "label": label,
        "residuals": {k: float(v) for k, v in resid.items() if isinstance(v, (int, float, np.number))},
        "instrument": {},
        "phases": {},
    }
    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in inst:
            result["instrument"][key] = float(inst[key][1])
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "scale": float(hap["Scale"][0]),
            "cell": {k: float(v) for k, v in phase.get_cell().items()},
        }
    try:
        result["mass_fractions"] = {
            k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    print("SUMMARY " + json.dumps(result, sort_keys=True))
    return result


def run_stage(gpx, label: str) -> dict:
    print(f"STAGE {label}")
    gpx.refine(printFile=str(Path(gpx.filename).with_suffix(f".{label}.lst")))
    gpx.save()
    return summarize(gpx, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", choices=sorted(MODELS))
    parser.add_argument("--outdir", type=Path, default=ROOT / ".tmp")
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    gpx_path = args.outdir / f"trial_{args.model}.gpx"
    gpx = G2sc.G2Project(newgpx=str(gpx_path))
    hist = gpx.add_powder_histogram(
        str(ROOT / ".tmp" / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
    )
    hist.set_refinements({"Limits": [10.05, 99.95]})

    phases = []
    for name, cod_id in MODELS[args.model]:
        phase = gpx.add_phase(str(cod_path(cod_id)), phasename=name, histograms=[hist])
        phases.append(phase)
        neutralize_hap(phase, hist.name)

    inst = hist.data["Instrument Parameters"][0]
    for key in inst:
        if isinstance(inst[key], list) and len(inst[key]) > 2:
            inst[key][2] = False
    for key, value in {"Zero": 0.0, "U": 0.0, "V": 0.0, "W": 15.0,
                       "X": 13.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002,
                       "Polariz.": 0.5}.items():
        if key in inst:
            inst[key][0] = value
            inst[key][1] = value

    sample = hist.data["Sample Parameters"]
    if "Scale" in sample:
        sample["Scale"][0] = 1.0
        sample["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample and isinstance(sample[key], list):
            sample[key][0] = 0.0
            sample[key][1] = False

    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 8,
            "coeffs": [700.0, -550.0, 350.0, -220.0, 130.0, -70.0, 30.0, -10.0],
        }
    })
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])

    gpx.set_Controls("cycles", args.cycles)
    gpx.save()
    for phase in phases:
        gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    for var in (":0:W", ":0:X"):
        gpx.set_Controls("parmMin", 0.0, variable=var)
        gpx.set_Controls("parmMax", 1000.0, variable=var)
    gpx.set_Controls("parmMin", -1.0, variable=":0:Zero")
    gpx.set_Controls("parmMax", 1.0, variable=":0:Zero")

    history = []
    history.append(run_stage(gpx, "scales_background"))

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    history.append(run_stage(gpx, "zero_cells"))

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    history.append(run_stage(gpx, "common_profile"))
    history.append(run_stage(gpx, "replay"))

    (args.outdir / f"trial_{args.model}.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )
    gpx.save()


if __name__ == "__main__":
    main()
