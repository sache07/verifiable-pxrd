#!/usr/bin/env python3
"""Create the exact final GSAS-II project, phase CIFs, fit and JSON summary."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "corrected_litharge.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "PbWO4_stolzite": {
        "display_name": "PbWO4 (stolzite)",
        "formula": "PbWO4",
        "cif": "phase_1_pbwo4_stolzite.cif",
        "source_cod_id": "9009811",
        "confidence": "high",
    },
    "PbO_massicot": {
        "display_name": "PbO (massicot)",
        "formula": "PbO",
        "cif": "phase_2_pbo_massicot.cif",
        "source_cod_id": "2310433",
        "confidence": "high",
    },
    "PbO_incommensurate_approx": {
        "display_name": "PbO (modulated alpha-PbO approximant)",
        "formula": "PbO",
        "cif": "phase_3_pbo_modulated_alpha.cif",
        "source_cod_id": "1533609",
        "confidence": "medium",
    },
    "WO3_monoclinic_alt": {
        "display_name": "WO3 (monoclinic gamma-WO3)",
        "formula": "WO3",
        "cif": "phase_4_wo3_monoclinic.cif",
        "source_cod_id": "2311041",
        "confidence": "high",
    },
    "PbO_litharge_watch": {
        "display_name": "PbO (litharge)",
        "formula": "PbO",
        "cif": "phase_5_pbo_litharge.cif",
        "source_cod_id": "9012700",
        "confidence": "low",
    },
}


def configure_full_range(gpx) -> None:
    gpx.set_Frozen(None)
    hist = gpx.histogram(0)
    hist.data["Limits"][1][:] = list(hist.data["Limits"][0])
    controls = gpx["Controls"]["data"]
    controls["shift factor"] = 0.2
    controls["max cyc"] = 20
    controls["min dM/M"] = 0.0001


def main() -> None:
    gpx = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
    configure_full_range(gpx)
    gpx.save()

    # Save, reopen and replay twice over the exact submitted range.
    for replay in range(2):
        gpx = G2sc.G2Project(str(FINAL))
        configure_full_range(gpx)
        gpx.refine(printFile=str(ROOT / ".tmp" / f"final_replay_{replay + 1}.lst"))
        gpx.save()

    gpx = G2sc.G2Project(str(FINAL))
    hist = gpx.histogram(0)
    if gpx.get_Frozen():
        raise RuntimeError(f"Final project contains frozen variables: {gpx.get_Frozen()}")

    fractions = hist.ComputeMassFracs()
    phases_json = []
    for phase in gpx.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif"]))
        fraction, esd = fractions[phase.name]
        phases_json.append({
            "name": info["display_name"],
            "formula": info["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": info["cif"],
            "weight_fraction": float(fraction),
            "weight_fraction_statistical_esd": float(esd),
            "source_cod_id": info["source_cod_id"],
            "confidence": info["confidence"],
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
        })

    x = hist.getdata("x")
    yobs = hist.getdata("yobs")
    ycalc = hist.getdata("ycalc")
    background = hist.getdata("background")
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg", "observed", "calculated", "background", "difference"
        ])
        for values in zip(x, yobs, ycalc, background):
            xx, obs, calc, back = (float(v) for v in values)
            writer.writerow([
                f"{xx:.8f}", f"{obs:.6f}", f"{calc:.6f}",
                f"{back:.6f}", f"{obs - calc:.6f}",
            ])

    residuals = hist.data["data"][0]
    rwp = float(residuals["wR"])
    rexp = float(residuals["wRmin"])
    result = {
        "phases": phases_json,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "reduced_chi_square": (rwp / rexp) ** 2,
            "durbin_watson": float(residuals["Durbin-Watson"]),
            "number_of_observations": int(residuals["Nobs"]),
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
            "weighting": "Poisson sigma = sqrt(observed counts); no measured point uncertainties supplied",
        },
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "fraction_basis": "normalized over the five modeled crystalline phases",
        "uncertainty_note": (
            "Weight-fraction ESDs are least-squares statistical values only; "
            "profile/model sensitivity and the strongly anticorrelated PbO split "
            "are discussed in report.md."
        ),
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    (ROOT / ".tmp" / "final_exact_summary.json").write_text(
        json.dumps({
            "fractions": {k: [float(v[0]), float(v[1])] for k, v in fractions.items()},
            "residuals": {k: float(v) for k, v in residuals.items()
                          if isinstance(v, (int, float))},
            "frozen": gpx.get_Frozen(),
        }, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
