#!/usr/bin/env python3
"""Render the profile arrays extracted from GSAS-II."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
data = np.load(ROOT / ".tmp" / "strain_compare_data.npz")
x, y = data["x"], data["observed"]
iso, aniso = data["isotropic"], data["anisotropic"]
windows = [(28.8, 31.1), (32.45, 33.2), (37.65, 38.45),
           (44.85, 45.75), (48.85, 51.2), (52.85, 53.7),
           (55.85, 56.55), (59.95, 60.85), (62.75, 63.55)]
fig, axes = plt.subplots(3, 3, figsize=(13, 9), constrained_layout=True)
for ax, (lo, hi) in zip(axes.ravel(), windows):
    mask = (x >= lo) & (x <= hi)
    ax.plot(x[mask], y[mask], color="black", lw=0.8, label="observed")
    ax.plot(x[mask], iso[mask], color="#2b6cb0", lw=1.0, label="isotropic")
    ax.plot(x[mask], aniso[mask], color="#c53030", lw=1.0, label="uniaxial [100]")
    ax.set_xlim(lo, hi)
    ax.set_title(f"{lo:.2f}–{hi:.2f}°")
    ax.tick_params(labelsize=8)
axes[0, 0].legend(fontsize=8)
fig.supxlabel(r"2$\theta$ (degrees)")
fig.supylabel("counts")
fig.savefig(ROOT / ".tmp" / "strain_compare.png", dpi=170)
