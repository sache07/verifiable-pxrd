#!/usr/bin/env python3
"""Prune rejected terms and repeatedly reopen/replay the five-phase model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from nuisance_trial import set_fixed_uiso
from refine_trial import summarize


ROOT = Path(__file__).resolve().parent
OUT = ROOT / ".tmp" / "five_phase_clean.gpx"


def prune_and_bound(gpx) -> None:
    gpx.set_Frozen(None)
    gpx.set_Controls("cycles", 10)
    hist = gpx.histogram(0)
    set_fixed_uiso(gpx, True)

    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "Y", "Z"):
        if key in inst:
            inst[key][0] = inst[key][1] = 0.0
            inst[key][2] = False
    inst["SH/L"][0] = inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False
    for key in ("Zero", "W", "X", "Polariz."):
        inst[key][2] = True

    sample = hist.data["Sample Parameters"]
    sample["Scale"][:] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample and isinstance(sample[key], list):
            sample[key][0] = 0.0
            sample[key][1] = False

    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 0.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][1][2] = 0.0
        hap["Mustrain"][2][2] = False
        hap["Pref.Ori."][2] = phase.id == 1
        if phase.id == 1:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][3] = [0, 1, 1]
        else:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
        if phase.id in (1, 2):
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2][:] = [True, False, False]
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2][:] = [False, False, False]
        gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    for phase_id in (1, 2):
        var = f"{phase_id}:{hist.id}:Mustrain;i"
        gpx.set_Controls("parmMin", 0.0, variable=var)
        gpx.set_Controls("parmMax", 100000.0, variable=var)
    gpx.set_Controls("parmMin", 0.2, variable=f"1:{hist.id}:MD")
    gpx.set_Controls("parmMax", 5.0, variable=f"1:{hist.id}:MD")


def main() -> None:
    source = ROOT / ".tmp" / "broadening_p4_strain.gpx"
    gpx = G2sc.G2Project(str(source), newgpx=str(OUT))
    history = []
    for cycle in range(3):
        prune_and_bound(gpx)
        gpx.save()
        gpx.refine(printFile=str(OUT.with_suffix(f".replay{cycle + 1}.lst")))
        gpx.save()
        result = summarize(gpx, f"reopened_replay_{cycle + 1}")
        result["frozen"] = gpx.get_Frozen()
        history.append(result)
        gpx = G2sc.G2Project(str(OUT))
    (ROOT / ".tmp" / "five_phase_clean.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
