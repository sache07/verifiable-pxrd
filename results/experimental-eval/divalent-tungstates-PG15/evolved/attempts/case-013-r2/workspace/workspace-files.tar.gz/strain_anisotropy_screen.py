#!/usr/bin/env python3
"""Challenge orthorhombic PbO isotropic strain with uniaxial alternatives."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_trial import summarize
from texture_screen import freeze_all


ROOT = Path(__file__).resolve().parent
AXES = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", type=int, choices=(1, 2))
    parser.add_argument(
        "--base", type=Path,
        default=ROOT / ".tmp" / "five_phase_damped_3.gpx",
    )
    args = parser.parse_args()
    results = []
    for axis in AXES:
        tag = "".join(str(i) for i in axis)
        out = ROOT / ".tmp" / f"strain_axis_p{args.phase}_{tag}.gpx"
        gpx = G2sc.G2Project(str(args.base), newgpx=str(out))
        gpx.set_Frozen(None)
        gpx.set_Controls("cycles", 8)
        freeze_all(gpx)
        hist = gpx.histogram(0)
        phase = gpx.phase(args.phase)
        strain = phase.data["Histograms"][hist.name]["Mustrain"]
        value = float(strain[1][0])
        strain[0] = "uniaxial"
        strain[1][:] = [value, value, 0.0]
        strain[2][:] = [True, True, False]
        strain[3] = list(axis)
        for suffix in ("i", "a"):
            variable = f"{phase.id}:{hist.id}:Mustrain;{suffix}"
            gpx.set_Controls("parmMin", 0.0, variable=variable)
            gpx.set_Controls("parmMax", 100000.0, variable=variable)
        gpx.save()
        gpx.refine(printFile=str(out.with_suffix(".lst")))
        gpx.save()
        result = summarize(gpx, "anisotropy_screen")
        result.update({
            "phase": phase.name,
            "axis": list(axis),
            "equatorial_microstrain": float(strain[1][0]),
            "axial_microstrain": float(strain[1][1]),
            "frozen": gpx.get_Frozen(),
        })
        results.append(result)
        print("STRAIN_AXIS " + json.dumps(result, sort_keys=True))
    (ROOT / ".tmp" / f"strain_axis_p{args.phase}.json").write_text(
        json.dumps(results, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
