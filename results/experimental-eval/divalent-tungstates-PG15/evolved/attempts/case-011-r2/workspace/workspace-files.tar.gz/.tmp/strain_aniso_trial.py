#!/usr/bin/env python3
"""Challenge isotropic WO3 microstrain with one low-dimensional uniaxial model."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("h", type=int)
    ap.add_argument("k", type=int)
    ap.add_argument("l", type=int)
    ap.add_argument("--ratio", type=float, default=1.3)
    ap.add_argument("out")
    args = ap.parse_args()
    out = Path(args.out).resolve()
    p = G2sc.G2Project(".tmp/texture_baseline.gpx", newgpx=str(out.with_suffix(".gpx")))
    p.data["Controls"]["data"]["max cyc"] = 15
    p.data["Controls"]["data"]["min dM/M"] = 1e-5
    p.data["Controls"]["data"]["shift factor"] = 0.15
    hist = p.histogram(0)
    wo3 = p.phase("gamma-WO3")
    ms = wo3.data["Histograms"][hist.name]["Mustrain"]
    iso = ms[1][0]
    ms[0] = "uniaxial"
    ms[1] = [iso, iso * args.ratio, 1.0]
    ms[2] = [True, True, False]
    ms[3] = [args.h, args.k, args.l]
    p.refine()
    p.save()
    ans = {
        "axis": ms[3],
        "Rvals": p.data["Covariance"]["data"]["Rvals"],
        "mass_fractions": hist.ComputeMassFracs(),
        "mustrain": ms,
        "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }
    out.with_suffix(".json").write_text(json.dumps(ans, indent=2) + "\n")
    print(json.dumps(ans, indent=2))


if __name__ == "__main__":
    main()
