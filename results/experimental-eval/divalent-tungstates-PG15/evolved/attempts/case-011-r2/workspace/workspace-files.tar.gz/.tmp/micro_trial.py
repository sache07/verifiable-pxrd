#!/usr/bin/env python3
"""Compare one-at-a-time phase broadening under a common narrow profile."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def neutral(phase, hist):
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1000.0, 1000.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]


def activate(phase, hist, kind):
    hap = phase.data["Histograms"][hist.name]
    if kind == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [0.12, 0.12, 1.0]
        hap["Size"][2] = [True, False, False]
    elif kind == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [500.0, 500.0, 1.0]
        hap["Mustrain"][2] = [True, False, False]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=".tmp/trial_2311041.gpx")
    ap.add_argument("mode", choices=[
        "none", "wo3_size", "wo3_strain", "mno2_size", "mno2_strain",
        "both_size", "wo3_size_strain",
    ])
    ap.add_argument("out")
    args = ap.parse_args()
    out = Path(args.out).resolve()
    p = G2sc.G2Project(args.base, newgpx=str(out.with_suffix(".gpx")))
    p.set_Controls("cycles", 12)
    h = p.histogram(0)
    wo3 = p.phase("gamma-WO3")
    mno2 = p.phase("beta-MnO2")
    for phase in (wo3, mno2):
        neutral(phase, h)
    if args.mode.startswith("wo3_size"):
        activate(wo3, h, "size")
    if args.mode.endswith("strain") and args.mode.startswith("wo3"):
        activate(wo3, h, "strain")
    if args.mode.startswith("mno2_size"):
        activate(mno2, h, "size")
    if args.mode.startswith("mno2_strain"):
        activate(mno2, h, "strain")
    if args.mode == "both_size":
        activate(wo3, h, "size")
        activate(mno2, h, "size")

    inst = h.data["Instrument Parameters"][0]
    for key, value, refine in (
        ("U", 0.0, False), ("V", 0.0, False), ("W", 4.0, True),
        ("X", 8.0, True), ("Y", 0.0, False), ("Z", 0.0, False),
    ):
        inst[key][1] = value
        inst[key][2] = refine
    for var in (":0:W", ":0:X"):
        p.set_Controls("parmMin", 0.0, variable=var)
    p.set_Controls("parmMax", 1000.0, variable=":0:W")
    p.set_Controls("parmMax", 100.0, variable=":0:X")
    p.refine()
    p.save()
    ans = {
        "mode": args.mode,
        "Rvals": p.data["Covariance"]["data"]["Rvals"],
        "mass_fractions": h.ComputeMassFracs(),
        "instrument": {k: inst[k][1] for k in ("U", "W", "X")},
        "WO3_size": wo3.data["Histograms"][h.name]["Size"],
        "WO3_strain": wo3.data["Histograms"][h.name]["Mustrain"],
        "MnO2_size": mno2.data["Histograms"][h.name]["Size"],
        "MnO2_strain": mno2.data["Histograms"][h.name]["Mustrain"],
        "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }
    out.with_suffix(".json").write_text(json.dumps(ans, indent=2) + "\n")
    print(json.dumps(ans, indent=2))


if __name__ == "__main__":
    main()
