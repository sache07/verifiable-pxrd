#!/usr/bin/env python3
"""Test a watch-list phase scale under a fixed accepted profile."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cif")
    ap.add_argument("--name", default="watch")
    ap.add_argument("out")
    args = ap.parse_args()
    out = Path(args.out).resolve()
    p = G2sc.G2Project(".tmp/101_replay.gpx", newgpx=str(out.with_suffix(".gpx")))
    p.data["Controls"]["data"]["max cyc"] = 20
    p.data["Controls"]["data"]["min dM/M"] = 1e-6
    p.data["Controls"]["data"]["shift factor"] = 0.2
    hist = p.histogram(0)

    # Preserve the accepted nonlinear profile while allowing background and all
    # composition scales to readjust under exactly the same line-shape model.
    for item in hist.data["Instrument Parameters"][0].values():
        if isinstance(item, list) and len(item) > 2 and isinstance(item[2], bool):
            item[2] = False
    hist.data["Sample Parameters"]["Scale"][1] = True
    hist.data["Background"][0][1] = True
    for phase in p.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = phase.name == "beta-MnO2"
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = False

    candidate = None
    if args.cif:
        candidate = p.add_phase(args.cif, phasename=args.name, histograms=[hist], fmthint="CIF")
        candidate.data["General"]["Cell"][0] = False
        hap = candidate.data["Histograms"][hist.name]
        hap["Scale"] = [0.02, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
        p.set_Controls("parmMin", 0.0, variable=f"{candidate.id}:0:Scale")

    p.refine()
    p.save()
    ans = {
        "candidate": args.name if candidate else None,
        "Rvals": p.data["Covariance"]["data"]["Rvals"],
        "mass_fractions": hist.ComputeMassFracs(),
        "scale": candidate.data["Histograms"][hist.name]["Scale"] if candidate else None,
        "cell": candidate.get_cell() if candidate else None,
        "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }
    out.with_suffix(".json").write_text(json.dumps(ans, indent=2) + "\n")
    print(json.dumps(ans, indent=2))


if __name__ == "__main__":
    main()
