#!/usr/bin/env python3
"""Reversible one-change nuisance trials from the accepted inventory baseline."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=[
        "replay", "polarization", "shl", "polarization_shl",
        "strain_mix", "background6", "background10", "roughness",
    ])
    ap.add_argument("out")
    args = ap.parse_args()
    out = Path(args.out).resolve()
    p = G2sc.G2Project(".tmp/source_2106293.gpx", newgpx=str(out.with_suffix(".gpx")))
    p.set_Controls("cycles", 12)
    h = p.histogram(0)
    inst = h.data["Instrument Parameters"][0]
    sample = h.data["Sample Parameters"]
    wo3 = p.phase("gamma-WO3")

    if args.mode in ("polarization", "polarization_shl"):
        inst["Polariz."][2] = True
        p.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        p.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    if args.mode in ("shl", "polarization_shl"):
        inst["SH/L"][1] = 0.01
        inst["SH/L"][2] = True
        p.set_Controls("parmMin", 0.002, variable=":0:SH/L")
        p.set_Controls("parmMax", 0.2, variable=":0:SH/L")
    if args.mode == "strain_mix":
        hap = wo3.data["Histograms"][h.name]
        hap["Mustrain"][1][2] = 0.5
        hap["Mustrain"][2][2] = True
    if args.mode.startswith("background"):
        n = int(args.mode.replace("background", ""))
        coeffs = list(h.data["Background"][0][3:])
        coeffs = (coeffs + [0.0] * n)[:n]
        h.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": n,
                                          "refine": True, "coeffs": coeffs}})
    if args.mode == "roughness":
        sample["SurfRoughA"] = [0.05, True]
        sample["SurfRoughB"] = [0.05, True]

    p.refine()
    p.save()
    ans = {
        "mode": args.mode,
        "Rvals": p.data["Covariance"]["data"]["Rvals"],
        "mass_fractions": h.ComputeMassFracs(),
        "instrument": {k: inst[k][1] for k in ("Polariz.", "SH/L", "W", "X")},
        "sample": {k: sample.get(k) for k in ("SurfRoughA", "SurfRoughB")},
        "strain": wo3.data["Histograms"][h.name]["Mustrain"],
        "background": h.data["Background"][0],
        "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }
    out.with_suffix(".json").write_text(json.dumps(ans, indent=2) + "\n")
    print(json.dumps(ans, indent=2))


if __name__ == "__main__":
    main()
