#!/usr/bin/env python3
"""Replay the accepted GSAS-II model and export the submission artifacts."""

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "watch_control.gpx"
PROJECT = ROOT / "final.gpx"


def main():
    project = G2sc.G2Project(str(SOURCE), newgpx=str(PROJECT))
    project.data["Controls"]["data"]["max cyc"] = 20
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.data["Controls"]["data"]["shift factor"] = 0.2
    project.save()
    # Final full-range replay with the accepted nonlinear terms held at their
    # replay-tested values; background and composition scales remain active.
    project.refine(printFile=str(ROOT / "final.lst"))
    project.save()

    # Reopen before every export so all artifacts come from the on-disk GPX.
    project = G2sc.G2Project(str(PROJECT))
    hist = project.histogram(0)
    phases = project.phases()
    if [p.name for p in phases] != ["gamma-WO3", "beta-MnO2"]:
        raise RuntimeError("Unexpected final phase inventory")

    cif_files = {
        "gamma-WO3": ROOT / "phase_WO3_P-1.cif",
        "beta-MnO2": ROOT / "phase_beta-MnO2.cif",
    }
    for phase in phases:
        phase.export_CIF(str(cif_files[phase.name]))

    x, yobs, _weight, ycalc, background, difference = hist.data["data"][1]
    with (ROOT / "fit.csv").open("w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow([
            "two_theta_deg", "observed_intensity", "calculated_intensity",
            "difference_observed_minus_calculated", "background_intensity",
        ])
        writer.writerows(zip(x, yobs, ycalc, difference, background))

    fractions = hist.ComputeMassFracs()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    hstats = hist.data["data"][0]
    cells = {phase.name: phase.get_cell() for phase in phases}
    phase_records = []
    metadata = {
        "gamma-WO3": {
            "name": "triclinic tungsten trioxide",
            "formula": "WO3",
            "space_group": "P -1",
            "source_record": "COD 2106293",
        },
        "beta-MnO2": {
            "name": "beta-MnO2 (pyrolusite)",
            "formula": "MnO2",
            "space_group": "P 42/m n m",
            "source_record": "COD 1514110",
        },
    }
    for phase in phases:
        value, sigma = fractions[phase.name]
        rec = dict(metadata[phase.name])
        rec.update({
            "cif_path": cif_files[phase.name].name,
            "weight_fraction": value,
            "weight_fraction_formal_su": sigma,
            "cell": cells[phase.name],
            "phase_fit_statistics": {
                "Rf_percent": float(hstats[f"{phase.id}:0:Rf"]),
                "Rf_squared_percent": float(hstats[f"{phase.id}:0:Rf^2"]),
            },
        })
        phase_records.append(rec)

    result = {
        "phases": phase_records,
        "weight_fraction_basis": "normalized over the two modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": float(rvals["Rwp"]),
            "Rp_percent": float(hstats["R"]),
            "GOF": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "N_observations": int(rvals["Nobs"]),
            "N_refined_parameters_final_replay": int(rvals["Nvars"]),
            "Durbin_Watson": float(hstats["Durbin-Watson"]),
            "weighting": "1/I Poisson proxy; pointwise standard uncertainties were not supplied",
        },
        "project_path": PROJECT.name,
        "profile_path": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
