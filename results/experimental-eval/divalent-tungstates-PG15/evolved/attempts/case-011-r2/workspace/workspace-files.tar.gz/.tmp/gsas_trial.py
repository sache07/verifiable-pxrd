#!/usr/bin/env python3
"""Apply one restrained, common GSAS-II nuisance model to a phase pair."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def neutralize_hap(phase, histogram):
    hap = phase.data["Histograms"][histogram.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1000.0, 1000.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--wo3", required=True)
    ap.add_argument("--mno2", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    out = Path(args.out).resolve()
    gpx = out.with_suffix(".gpx")
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(Path("pattern.xye").resolve()),
        str(Path("instrument.instprm").resolve()),
        fmthint="xye",
    )
    wo3 = project.add_phase(
        args.wo3, phasename="gamma-WO3", histograms=[hist], fmthint="CIF"
    )
    mno2 = project.add_phase(
        args.mno2, phasename="beta-MnO2", histograms=[hist], fmthint="CIF"
    )
    project.set_Controls("cycles", 8)
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "refine": True,
                "coeffs": [1000.0, -300.0, 100.0, -30.0, 10.0, 0.0, 0.0, 0.0],
            },
        }
    )
    for phase in project.phases():
        neutralize_hap(phase, hist)
    wo3.data["Histograms"][hist.name]["Scale"] = [1.0, False]
    mno2.data["Histograms"][hist.name]["Scale"] = [4.0, True]
    hist.data["Sample Parameters"]["Scale"] = [1.0, True]

    inst = hist.data["Instrument Parameters"][0]
    starts = {
        "Zero": 0.28,
        "U": 100.0,
        "V": 0.0,
        "W": 0.0,
        "X": 10.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
    }
    for key, value in starts.items():
        inst[key][1] = value
        inst[key][2] = False

    # Scales/background, one angular correction, cells, then common profile.
    project.refine()
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine()
    hist.set_refinements({"Instrument Parameters": ["U", "X"]})
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMin", 0.0, variable=":0:X")
    project.set_Controls("parmMax", 1000.0, variable=":0:U")
    project.set_Controls("parmMax", 100.0, variable=":0:X")
    project.refine()
    project.save()

    result = {
        "project": str(gpx),
        "wo3_source": args.wo3,
        "mno2_source": args.mno2,
        "Rvals": project.data["Covariance"]["data"]["Rvals"],
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {key: inst[key][1] for key in starts},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "phase_Rf": {
            phase.name: {
                "Rf": hist.data["data"][0].get(f"{phase.id}:0:Rf"),
                "Rf2": hist.data["data"][0].get(f"{phase.id}:0:Rf^2"),
            }
            for phase in project.phases()
        },
    }
    out.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
