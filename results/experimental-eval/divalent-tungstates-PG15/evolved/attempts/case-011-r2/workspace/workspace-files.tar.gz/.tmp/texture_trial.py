#!/usr/bin/env python3
"""Test one March-Dollase axis while preserving the accepted baseline."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("phase", choices=["wo3", "mno2"])
    ap.add_argument("h", type=int)
    ap.add_argument("k", type=int)
    ap.add_argument("l", type=int)
    ap.add_argument("out")
    args = ap.parse_args()
    axis = [args.h, args.k, args.l]
    out = Path(args.out).resolve()
    p = G2sc.G2Project(".tmp/baseline.gpx", newgpx=str(out.with_suffix(".gpx")))
    p.data["Controls"]["data"]["max cyc"] = 20
    p.data["Controls"]["data"]["min dM/M"] = 1e-5
    p.data["Controls"]["data"]["shift factor"] = 0.2
    hist = p.histogram(0)
    phase = p.phase("gamma-WO3" if args.phase == "wo3" else "beta-MnO2")
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = axis
    p.refine()
    p.save()
    ans = {
        "phase": args.phase,
        "axis": axis,
        "Rvals": p.data["Covariance"]["data"]["Rvals"],
        "mass_fractions": hist.ComputeMassFracs(),
        "MD": po[1],
        "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }
    out.with_suffix(".json").write_text(json.dumps(ans, indent=2) + "\n")
    print(json.dumps(ans, indent=2))


if __name__ == "__main__":
    main()
