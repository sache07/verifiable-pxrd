#!/usr/bin/env python3
"""Print compact refinement summaries for one or more GSAS-II projects."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def inspect(path: Path) -> dict:
    project = G2sc.G2Project(str(path))
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    x = hist.getdata("x")
    background = hist.getdata("background")
    limits = hist.data["Limits"][1]
    mask = (x >= limits[0]) & (x <= limits[1])
    variables = {
        str(var): [float(value), float(sigma)]
        for var, value, sigma in zip(
            cov.get("varyList", []), cov.get("variables", []), cov.get("sig", [])
        )
    }
    return {
        "file": str(path),
        "residuals": hist.residuals,
        "Rvals": cov.get("Rvals", {}),
        "mass_fractions": hist.ComputeMassFracs(),
        "limits": limits,
        "background": {
            "setup": hist.Background[0],
            "minimum": float(np.min(background[mask])),
            "maximum": float(np.max(background[mask])),
            "endpoints": [float(background[mask][0]), float(background[mask][-1])],
            "max_second_difference": float(np.max(np.abs(np.diff(background[mask], 2)))),
        },
        "instrument": {
            key: value[1:]
            for key, value in hist.InstrumentParameters.items()
            if key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")
        },
        "sample": hist.SampleParameters,
        "frozen": project.get_Frozen(),
        "variables": variables,
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "HAP": phase.getHAPvalues(hist),
            }
            for phase in project.phases()
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("projects", nargs="+")
    args = parser.parse_args()
    for filename in args.projects:
        print(json.dumps(inspect(Path(filename)), default=float, sort_keys=True))


if __name__ == "__main__":
    main()
