#!/usr/bin/env python3
"""Build the clean triclinic-WO3 + wolframite-CoWO4 baseline in stages."""

from __future__ import annotations

import contextlib
import io
import json
import os
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
WO3 = COD / "2/10/62/2106293.cif"
FEWO4 = COD / "9/00/81/9008124.cif"
OUTPUT = ROOT / ".tmp/inventory2_base.gpx"


def neutralize_hap(phase, hist) -> None:
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 1.0e6, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def replace_fe_with_co(phase) -> None:
    changed = 0
    for atom in phase.atoms():
        if atom.element == "Fe":
            atom.type = "Co"
            atom.label = atom.label.replace("Fe", "Co", 1)
            changed += 1
    if not changed:
        raise RuntimeError("Fe site not found in wolframite parent")
    G2sc.SetupGeneral(phase.data, None)


def run(project, label: str) -> None:
    with contextlib.redirect_stdout(io.StringIO()):
        project.refine()
    project.save()
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    print(json.dumps({
        "label": label,
        "Rwp": cov["Rvals"]["Rwp"],
        "chisq": cov["Rvals"]["chisq"],
        "Nvars": cov["Rvals"]["Nvars"],
        "converged": cov["Rvals"].get("converged"),
        "max_shift_esd": cov["Rvals"].get("Max shft/sig"),
        "mass_fractions": hist.ComputeMassFracs(),
    }, default=float, sort_keys=True))


def main() -> None:
    project = G2sc.G2Project(newgpx=str(OUTPUT))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"), str(ROOT / "instrument.instprm"), fmthint="comma"
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 12,
            "coeffs": [900.0] + [0.0] * 11,
        }
    })

    instrument = hist.InstrumentParameters
    for key, value in {
        "U": 0.0, "V": 0.0, "W": 100.0, "X": 5.0,
        "Y": 0.0, "Z": 0.0, "SH/L": 0.002,
    }.items():
        instrument[key][1] = value
        instrument[key][2] = False
    instrument["Zero"][1:] = [0.0, False]
    instrument["Polariz."][1:] = [0.5, False]
    instrument["I(L2)/I(L1)"][1:] = [0.5, False]

    sample = hist.SampleParameters
    sample["Scale"] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample:
            sample[key] = [0.0, False]

    wo3 = project.add_phase(str(WO3), phasename="WO3", histograms=[hist], fmthint="CIF")
    cowo4 = project.add_phase(str(FEWO4), phasename="CoWO4", histograms=[hist], fmthint="CIF")
    replace_fe_with_co(cowo4)
    for phase, scale in ((wo3, 1.0), (cowo4, 0.3)):
        neutralize_hap(phase, hist)
        phase.getHAPvalues(hist)["Scale"] = [scale, False]
        phase.data["General"]["Cell"][0] = False

    project.save()
    project.add_HoldConstr((f"{cowo4.id}::A4",))
    for variable in (":0:W", ":0:X"):
        project.set_Controls("parmMin", 0.0, variable=variable)
    for phase in (wo3, cowo4):
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")

    wo3.getHAPvalues(hist)["Scale"][1] = True
    cowo4.getHAPvalues(hist)["Scale"][1] = True
    run(project, "background_scales")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    wo3.data["General"]["Cell"][0] = True
    cowo4.data["General"]["Cell"][0] = True
    run(project, "zero_cells")

    hist.set_refinements({"Instrument Parameters": ["W"]})
    run(project, "common_W")
    hist.set_refinements({"Instrument Parameters": ["X"]})
    run(project, "common_WX")

    project = G2sc.G2Project(str(OUTPUT))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    run(project, "reopen_replay")


if __name__ == "__main__":
    main()
