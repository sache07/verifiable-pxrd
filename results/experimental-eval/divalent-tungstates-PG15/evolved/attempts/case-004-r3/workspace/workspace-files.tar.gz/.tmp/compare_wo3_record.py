#!/usr/bin/env python3
"""Replace WO3 with a physical alternate record under a common nuisance model."""

from __future__ import annotations

import argparse
import contextlib
import io
import json
import os

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"

from GSASII import GSASIIscriptable as G2sc


def neutralize_hap(phase, hist) -> None:
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 1.0e6, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [4300.0, 0.0, 1.0]
    hap["Mustrain"][2] = [True, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--cif", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--replays", type=int, default=3)
    args = parser.parse_args()

    project = G2sc.G2Project(args.base, newgpx=args.output)
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = project.histogram(0)

    old = project.phase("WO3")
    old_hap = old.getHAPvalues(hist)
    old_hap["Use"] = False
    old_hap["Scale"][1] = False
    old_hap["Mustrain"][2] = [False, False, False]
    old_hap["Pref.Ori."][2] = False
    old.data["General"]["Cell"][0] = False

    trial = project.add_phase(args.cif, phasename=args.name, histograms=[hist], fmthint="CIF")
    neutralize_hap(trial, hist)
    trial_hap = trial.getHAPvalues(hist)
    trial_hap["Scale"] = [old_hap["Scale"][0], True]
    trial.data["General"]["Cell"][0] = True
    project.set_Controls("parmMin", 0.0, variable=f"{trial.id}:0:Scale")
    project.set_Controls("parmMin", 0.0, variable=f"{trial.id}:0:Mustrain;i")
    project.set_Controls("parmMax", 15000.0, variable=f"{trial.id}:0:Mustrain;i")
    project.save()

    for _ in range(args.replays):
        with contextlib.redirect_stdout(io.StringIO()):
            project.refine()
        project.save()
        project = G2sc.G2Project(args.output)
        project.set_Controls("cycles", 12)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-6

    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    trial = project.phase(args.name)
    print(json.dumps({
        "record": args.name,
        "Rwp": cov["Rvals"]["Rwp"],
        "chisq": cov["Rvals"]["chisq"],
        "Nvars": cov["Rvals"]["Nvars"],
        "converged": cov["Rvals"].get("converged"),
        "max_shift_esd": cov["Rvals"].get("Max shft/sig"),
        "cell": trial.get_cell(),
        "HAP": trial.getHAPvalues(hist),
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
    }, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
