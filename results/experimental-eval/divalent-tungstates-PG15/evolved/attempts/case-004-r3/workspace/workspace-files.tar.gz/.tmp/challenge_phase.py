#!/usr/bin/env python3
"""Re-challenge a weak-phase candidate under the established common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
FILES = {
    "coo": COD / "1/54/16/1541662.cif",
    "co3o4": COD / "9/00/58/9005896.cif",
    "w18o49": COD / "1/52/81/1528166.cif",
}


def neutralize_hap(phase, hist) -> None:
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def summarize(proj, candidate: str, label: str) -> None:
    hist = proj.histogram(0)
    phase = proj.phase(candidate.upper())
    hap = phase.getHAPvalues(hist)
    out = {
        "label": label,
        "candidate": candidate,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "candidate_scale": hap["Scale"],
        "candidate_cell": phase.get_cell(),
        "candidate_composition": phase.composition,
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items() if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "frozen": proj.get_Frozen(),
    }
    print("CHALLENGE " + json.dumps(out, default=float, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", choices=sorted(FILES))
    parser.add_argument("--base", default=str(ROOT / ".tmp" / "clean_fewo_a.gpx"))
    parser.add_argument("--tag")
    args = parser.parse_args()
    tag = args.tag or f"challenge_{args.candidate}"
    outfile = ROOT / ".tmp" / f"{tag}.gpx"
    proj = G2sc.G2Project(args.base, newgpx=str(outfile))
    proj.set_Controls("cycles", 12)
    proj.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = proj.histogram(0)
    hist.SampleParameters["Scale"][0] = 1.0
    hist.SampleParameters["Scale"][1] = False
    phase = proj.add_phase(str(FILES[args.candidate]), phasename=args.candidate.upper(), histograms=[hist], fmthint="CIF")
    if args.candidate == "w18o49":
        # GSAS-II has no W+5 X-ray form-factor key; neutral-W scattering is
        # adequate for this scale-only screening of the mixed-valence phase.
        for atom in phase.atoms():
            if atom.element == "W":
                atom.type = "W"
        G2sc.SetupGeneral(phase.data, None)
    neutralize_hap(phase, hist)
    phase.data["General"]["Cell"][0] = False
    phase.getHAPvalues(hist)["Scale"] = [0.05, True]
    proj.save()
    proj.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    proj.refine()
    summarize(proj, args.candidate, "scale_test")
    # A save/reopen replay under the full active model.
    proj.save()
    replay = G2sc.G2Project(str(outfile))
    replay.set_Controls("cycles", 12)
    replay.refine()
    summarize(replay, args.candidate, "replay")
    replay.save()


if __name__ == "__main__":
    main()
