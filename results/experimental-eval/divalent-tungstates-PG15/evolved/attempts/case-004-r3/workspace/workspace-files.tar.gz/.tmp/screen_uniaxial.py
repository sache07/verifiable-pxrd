#!/usr/bin/env python3
"""Screen a low-dimensional uniaxial microstrain axis."""

from __future__ import annotations

import argparse
import contextlib
import io
import json
import os

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", default="WO3")
    parser.add_argument("--axis", nargs=3, type=int, required=True)
    parser.add_argument("--replays", type=int, default=2)
    args = parser.parse_args()

    project = G2sc.G2Project(args.base, newgpx=args.output)
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.getHAPvalues(hist)
    initial = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = initial
    hap["Mustrain"][1][1] = initial
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = list(args.axis)
    for suffix in ("Mustrain;i", "Mustrain;a"):
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:{suffix}")
        project.set_Controls("parmMax", 15000.0, variable=f"{phase.id}:0:{suffix}")
    project.save()

    for _ in range(args.replays):
        with contextlib.redirect_stdout(io.StringIO()):
            project.refine()
        project.save()
        project = G2sc.G2Project(args.output)
        project.set_Controls("cycles", 12)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-6

    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    selected = {
        str(var): [float(value), float(sigma)]
        for var, value, sigma in zip(
            cov.get("varyList", []), cov.get("variables", []), cov.get("sig", [])
        )
        if "Mustrain" in str(var)
    }
    print(json.dumps({
        "axis": args.axis,
        "Rwp": cov["Rvals"]["Rwp"],
        "chisq": cov["Rvals"]["chisq"],
        "converged": cov["Rvals"].get("converged"),
        "max_shift_esd": cov["Rvals"].get("Max shft/sig"),
        "mustrain": project.phase(args.phase).getHAPvalues(hist)["Mustrain"],
        "selected_variables": selected,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "output": args.output,
    }, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
