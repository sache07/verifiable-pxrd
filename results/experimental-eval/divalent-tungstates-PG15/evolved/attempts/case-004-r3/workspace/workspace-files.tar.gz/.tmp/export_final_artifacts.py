#!/usr/bin/env python3
"""Export CIFs and the exact final profile from the submitted GSAS-II project."""

from __future__ import annotations

import csv
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    project = G2sc.G2Project(str(ROOT / "final.gpx"))
    hist = project.histogram(0)
    if project.get_Frozen():
        raise RuntimeError(f"Refusing to export a project with frozen variables: {project.get_Frozen()}")
    if sorted(p.name for p in project.phases()) != ["CoWO4", "WO3"]:
        raise RuntimeError("Unexpected final phase inventory")

    project.phase("WO3").export_CIF(str(ROOT / "phase_WO3.cif"))
    project.phase("CoWO4").export_CIF(str(ROOT / "phase_CoWO4.cif"))

    x = np.asarray(hist.getdata("x"), dtype=float)
    observed = np.asarray(hist.getdata("yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("ycalc"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    difference = observed - calculated
    profile = np.column_stack((x, observed, calculated, difference, background))
    if profile.shape != (8301, 5) or not np.all(np.isfinite(profile)):
        raise RuntimeError(f"Unexpected profile shape/content: {profile.shape}")

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("two_theta_deg", "observed_counts", "calculated_counts", "difference_counts", "background_counts"))
        writer.writerows(profile.tolist())

    print("exported", len(x), "profile points")
    print("fractions", hist.ComputeMassFracs())
    print("residuals", hist.residuals)
    print("Rvals", project.data["Covariance"]["data"].get("Rvals", {}))


if __name__ == "__main__":
    main()
