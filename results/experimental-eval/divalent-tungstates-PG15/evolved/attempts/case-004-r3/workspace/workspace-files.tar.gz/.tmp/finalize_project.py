#!/usr/bin/env python3
"""Build and replay the accepted two-phase model over the full data range."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp" / "uni_111.gpx"
OUTPUT = ROOT / "final.gpx"


def neutral_common_terms(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    x = hist.getdata("x")
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]

    hist.SampleParameters["Scale"] = [1.0, False]
    for key in ("Absorption", "DisplaceX", "DisplaceY", "Shift", "SurfRoughA", "SurfRoughB", "Transparency"):
        if key in hist.SampleParameters:
            hist.SampleParameters[key][0] = 0.0
            hist.SampleParameters[key][1] = False

    inst = hist.InstrumentParameters
    inst["Polariz."][1:] = [1.0, False]
    for key in ("U", "V", "Y", "Z"):
        inst[key][1:] = [0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True
    inst["SH/L"][2] = True
    inst["Zero"][2] = True
    if "I(L2)/I(L1)" in inst:
        inst["I(L2)/I(L1)"][1:] = [0.5, False]

    # Keep the supported smooth 12-term background.
    hist.Background[0][1] = True
    hist.Background[0][2] = 12

    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 1_000_000.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]

        if phase.name == "WO3":
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][2] = [True, True, False]
            hap["Mustrain"][3] = [1, 1, 1]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [1, 0, 1]
        elif phase.name == "CoWO4":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1] = [0.0, 0.0, 1.0]
            hap["Mustrain"][2] = [False, False, False]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [0, 0, 1]
        else:
            raise RuntimeError(f"Unexpected phase {phase.name!r}")


def summary(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    print(
        "FINAL_PASS "
        + json.dumps(
            {
                "label": label,
                "limits": hist.data["Limits"][1],
                "residuals": hist.residuals,
                "Rvals": cov.get("Rvals", {}),
                "mass_fractions": hist.ComputeMassFracs(),
                "frozen": project.get_Frozen(),
            },
            default=float,
            sort_keys=True,
        )
    )


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    if sorted(p.name for p in project.phases()) != ["CoWO4", "WO3"]:
        raise RuntimeError("The accepted source project is not the expected two-phase model")
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    neutral_common_terms(project)
    project.save()

    for pass_no in range(1, 4):
        project.refine()
        project.save()
        project = G2sc.G2Project(str(OUTPUT))
        project.set_Controls("cycles", 12)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
        summary(project, f"full_range_replay_{pass_no}")

    if project.get_Frozen():
        raise RuntimeError(f"Final project contains frozen variables: {project.get_Frozen()}")
    project.save()


if __name__ == "__main__":
    main()
