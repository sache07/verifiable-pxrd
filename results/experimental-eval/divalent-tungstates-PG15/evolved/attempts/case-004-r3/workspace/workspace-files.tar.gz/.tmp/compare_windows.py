#!/usr/bin/env python3
"""Compare weighted residuals in diagnostic peak windows across projects."""

from __future__ import annotations

import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


CENTERS = [19.09, 23.18, 23.67, 24.42, 30.71, 36.44, 41.50, 44.40,
           52.15, 61.79, 65.15, 68.78, 71.96, 76.92, 81.63]


def summarize(filename: str) -> dict:
    hist = G2sc.G2Project(filename).histogram(0)
    x = hist.getdata("x")
    obs = hist.getdata("yobs")
    calc = hist.getdata("ycalc")
    weight = hist.getdata("yweight")
    rows = []
    for center in CENTERS:
        mask = (x >= center - 0.35) & (x <= center + 0.35)
        residual = obs[mask] - calc[mask]
        rows.append({
            "center": center,
            "weighted_ss": float(np.sum(weight[mask] * residual**2)),
            "left_mean_residual": float(np.mean(residual[x[mask] < center])),
            "right_mean_residual": float(np.mean(residual[x[mask] >= center])),
        })
    return {"project": filename, "windows": rows}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("projects", nargs="+")
    args = parser.parse_args()
    print(json.dumps([summarize(item) for item in args.projects], indent=2))


if __name__ == "__main__":
    main()
