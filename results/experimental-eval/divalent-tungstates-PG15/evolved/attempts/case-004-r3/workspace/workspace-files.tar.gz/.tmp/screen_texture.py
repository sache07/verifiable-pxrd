#!/usr/bin/env python3
"""Screen one March-Dollase texture axis with concise output."""

from __future__ import annotations

import argparse
import contextlib
import io
import json
import os

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", required=True, choices=("WO3", "CoWO4"))
    parser.add_argument("--axis", nargs=3, type=int, required=True)
    parser.add_argument("--replays", type=int, default=1)
    args = parser.parse_args()

    project = G2sc.G2Project(args.base, newgpx=args.output)
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = project.histogram(0)
    hap = project.phase(args.phase).getHAPvalues(hist)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(args.axis)
    project.save()

    for _ in range(args.replays):
        with contextlib.redirect_stdout(io.StringIO()):
            project.refine()
        project.save()
        project = G2sc.G2Project(args.output)
        project.set_Controls("cycles", 12)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-6

    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    md = None
    for var, value, sigma in zip(
        cov.get("varyList", []), cov.get("variables", []), cov.get("sig", [])
    ):
        if str(var).endswith(":MD"):
            md = [float(value), float(sigma)]
    print(json.dumps({
        "phase": args.phase,
        "axis": args.axis,
        "Rwp": float(cov["Rvals"]["Rwp"]),
        "chisq": float(cov["Rvals"]["chisq"]),
        "converged": bool(cov["Rvals"].get("converged")),
        "max_shift_esd": float(cov["Rvals"].get("Max shft/sig", 0.0)),
        "MD": md,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "output": args.output,
    }, default=float, sort_keys=True))


if __name__ == "__main__":
    main()
