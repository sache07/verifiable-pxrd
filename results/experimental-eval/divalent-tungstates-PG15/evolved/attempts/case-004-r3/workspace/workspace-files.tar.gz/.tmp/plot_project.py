#!/usr/bin/env python3
"""Plot an observed/calculated/difference profile and selected windows."""

from __future__ import annotations

import argparse
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
sys.path.insert(0, "<HOME>/.local/share/characterizagent/backends/gsas2/venv/lib/python3.11/site-packages")
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("output")
    args = parser.parse_args()

    hist = G2sc.G2Project(args.project).histogram(0)
    x = hist.getdata("x")
    obs = hist.getdata("yobs")
    calc = hist.getdata("ycalc")
    background = hist.getdata("background")
    diff = obs - calc

    fig, axes = plt.subplots(4, 1, figsize=(15, 11), constrained_layout=True)
    axes[0].plot(x, obs, "k-", lw=0.55, label="observed")
    axes[0].plot(x, calc, "r-", lw=0.55, label="calculated")
    axes[0].plot(x, background, color="royalblue", lw=0.6, label="background")
    offset = np.nanmin(obs) - 0.15 * (np.nanmax(obs) - np.nanmin(obs))
    axes[0].plot(x, diff + offset, color="gray", lw=0.5, label="difference (offset)")
    axes[0].set_xlim(x.min(), x.max())
    axes[0].legend(ncol=4, fontsize=8)
    axes[0].set_ylabel("counts")

    for ax, (lo, hi) in zip(axes[1:], ((18, 42), (42, 68), (68, 94))):
        mask = (x >= lo) & (x <= hi)
        ax.plot(x[mask], obs[mask], "k-", lw=0.7)
        ax.plot(x[mask], calc[mask], "r-", lw=0.7)
        local_offset = np.min(obs[mask]) - 0.2 * (np.max(obs[mask]) - np.min(obs[mask]))
        ax.plot(x[mask], diff[mask] + local_offset, color="royalblue", lw=0.6)
        ax.set_xlim(lo, hi)
        ax.set_ylabel("counts")
    axes[-1].set_xlabel(r"$2\theta$ (degrees)")
    fig.savefig(args.output, dpi=180)


if __name__ == "__main__":
    main()
