#!/usr/bin/env python3
"""Apply one reversible refinement variant to the converged two-phase model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def phase_key(text: str) -> str:
    return {"wo3": "WO3", "cowo4": "CoWO4"}[text.lower()]


def summarize(proj, label: str) -> None:
    hist = proj.histogram(0)
    cov = proj.data["Covariance"]["data"]
    out = {
        "label": label,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "Rvals": cov.get("Rvals", {}),
        "instrument": {k: v[1:] for k, v in hist.InstrumentParameters.items() if k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "background": hist.Background[0],
        "frozen": proj.get_Frozen(),
        "phases": {},
    }
    for phase in proj.phases():
        hap = phase.getHAPvalues(hist)
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    variables = {}
    for var, val, sig in zip(cov.get("varyList", []), cov.get("variables", []), cov.get("sig", [])):
        if any(token in var for token in ("Size", "Mustrain", "MD", "SH/L", "Polariz")):
            variables[var] = [val, sig]
    out["selected_variables"] = variables
    print("VARIANT " + json.dumps(out, default=float, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("background", "shl", "polar", "size", "strain", "texture", "fix_co_beta", "fix_polar", "fix_shl"))
    parser.add_argument("--phase", choices=("wo3", "cowo4"))
    parser.add_argument("--axis", nargs=3, type=int)
    parser.add_argument("--terms", type=int)
    parser.add_argument("--base", default=str(ROOT / ".tmp" / "best_base.gpx"))
    parser.add_argument("--tag", required=True)
    parser.add_argument("--replays", type=int, default=2)
    args = parser.parse_args()

    outfile = ROOT / ".tmp" / f"{args.tag}.gpx"
    proj = G2sc.G2Project(args.base, newgpx=str(outfile))
    proj.set_Controls("cycles", 12)
    proj.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = proj.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]

    if args.mode == "background":
        if args.terms is None:
            parser.error("--terms is required")
        current = list(hist.Background[0][3:])
        coeffs = (current + [0.0] * args.terms)[: args.terms]
        hist.set_refinements({"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": args.terms, "coeffs": coeffs}})
    elif args.mode == "shl":
        hist.InstrumentParameters["SH/L"][1] = 0.01
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        proj.set_Controls("parmMin", 0.002, variable=":0:SH/L")
        proj.set_Controls("parmMax", 0.1, variable=":0:SH/L")
    elif args.mode == "polar":
        hist.InstrumentParameters["Polariz."][1] = 0.5
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        proj.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        proj.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif args.mode in ("size", "strain", "texture"):
        if args.phase is None:
            parser.error("--phase is required")
        phase = proj.phase(phase_key(args.phase))
        hap = phase.getHAPvalues(hist)
        if args.mode == "size":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 0.5
            hap["Size"][1][2] = 1.0
            hap["Size"][2] = [True, False, False]
        elif args.mode == "strain":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 500.0
            hap["Mustrain"][1][2] = 1.0
            hap["Mustrain"][2] = [True, False, False]
        else:
            if args.axis is None:
                parser.error("--axis is required")
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(args.axis)
    elif args.mode == "fix_co_beta":
        phase = proj.phase("CoWO4")
        phase.data["General"]["Cell"][5] = 90.0
        G2sc.SetupGeneral(phase.data, None)
        proj.save()
        proj.add_HoldConstr((f"{phase.id}::A4",))
    elif args.mode == "fix_polar":
        hist.InstrumentParameters["Polariz."][1] = 1.0
        hist.InstrumentParameters["Polariz."][2] = False
    elif args.mode == "fix_shl":
        # GSAS-II's neutral axial-divergence value for this CW profile.
        hist.InstrumentParameters["SH/L"][1] = 0.002
        hist.InstrumentParameters["SH/L"][2] = False

    proj.save()
    for i in range(args.replays):
        proj.refine()
        summarize(proj, f"{args.tag}_pass_{i + 1}")
        proj.save()
        proj = G2sc.G2Project(str(outfile))
        proj.set_Controls("cycles", 12)
        proj.data["Controls"]["data"]["min dM/M"] = 1.0e-6


if __name__ == "__main__":
    main()
