#!/usr/bin/env python3
"""Build and compare staged GSAS-II refinements for the Co-W-O pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "inputs" / "pattern.csv"
IPARM = ROOT / "instrument.instprm"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

WO3 = COD / "1/52/89/1528915.cif"
CO_PARENTS = {
    "como": COD / "7/20/50/7205001.cif",
    "fewo_a": COD / "9/00/81/9008124.cif",
    "fewo_b": COD / "1/56/72/1567215.cif",
    "mnwo": COD / "1/52/02/1520200.cif",
    "znwo": COD / "1/52/06/1520641.cif",
}
EXTRAS = {
    "coo": COD / "1/54/16/1541662.cif",
    "co3o4": COD / "9/00/58/9005896.cif",
    "w18o49": COD / "1/52/81/1528166.cif",
}


def replace_first_element(phase, old: str, new: str) -> None:
    changed = 0
    for atom in phase.atoms():
        if atom.element == old:
            atom.type = new
            atom.label = atom.label.replace(old, new, 1)
            changed += 1
    if not changed:
        raise RuntimeError(f"No {old} atom found in {phase.name}")
    G2sc.SetupGeneral(phase.data, None)


def neutralize_hap(phase, hist) -> None:
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1.0e6, 1.0e6, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Size"][5] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def snapshot(proj, label: str) -> dict:
    hist = proj.histogram(0)
    inst = hist.InstrumentParameters
    out = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "background": list(hist.Background[0]),
        "sample": {k: v for k, v in hist.SampleParameters.items() if k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "phases": {},
        "frozen": proj.get_Frozen(),
    }
    for phase in proj.phases():
        hap = phase.getHAPvalues(hist)
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
            "composition": phase.composition,
            "density": phase.density,
        }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    print("SNAPSHOT " + json.dumps(out, default=float, sort_keys=True))
    return out


def refine(proj, label: str) -> dict:
    proj.refine()
    return snapshot(proj, label)


def build(tag: str, parent_key: str, extras: list[str], bkg_terms: int) -> tuple[G2sc.G2Project, list[dict]]:
    gpx = ROOT / ".tmp" / f"{tag}.gpx"
    proj = G2sc.G2Project(newgpx=str(gpx))
    proj.set_Controls("cycles", 10)
    proj.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = proj.add_powder_histogram(str(INPUT), str(IPARM), fmthint="comma")
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": bkg_terms,
            "coeffs": [900.0] + [0.0] * (bkg_terms - 1),
        }
    })
    inst = hist.InstrumentParameters
    for key, value in {"U": 0.0, "V": 0.0, "W": 120.0, "X": 5.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002}.items():
        inst[key][1] = value
        inst[key][2] = False
    inst["Zero"][1] = 0.0
    inst["Zero"][2] = False
    inst["Polariz."][1] = 0.5
    inst["Polariz."][2] = False
    inst["I(L2)/I(L1)"][1] = 0.5
    inst["I(L2)/I(L1)"][2] = False

    # Neutralize all sample corrections not in the model.
    sample = hist.SampleParameters
    sample["Scale"][0] = 1.0
    sample["Scale"][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample:
            sample[key][0] = 0.0
            sample[key][1] = False

    wo3 = proj.add_phase(str(WO3), phasename="WO3", histograms=[hist], fmthint="CIF")
    parent = CO_PARENTS[parent_key]
    cowo4 = proj.add_phase(str(parent), phasename="CoWO4", histograms=[hist], fmthint="CIF")
    if parent_key == "como":
        replace_first_element(cowo4, "Mo", "W")
    else:
        old = {"fewo_a": "Fe", "fewo_b": "Fe", "mnwo": "Mn", "znwo": "Zn"}[parent_key]
        replace_first_element(cowo4, old, "Co")

    phases = [wo3, cowo4]
    for extra in extras:
        p = proj.add_phase(str(EXTRAS[extra]), phasename=extra.upper(), histograms=[hist], fmthint="CIF")
        phases.append(p)
    for phase in phases:
        neutralize_hap(phase, hist)
        phase.getHAPvalues(hist)["Scale"] = [0.2 if phase.name != "WO3" else 1.0, False]
        phase.data["General"]["Cell"][0] = False

    # Explicit nonnegative limits for the common profile and all phase scales.
    proj.save()
    for var in (":0:W", ":0:X"):
        proj.set_Controls("parmMin", 0.0, variable=var)
    for phase in phases:
        proj.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")

    history: list[dict] = [snapshot(proj, "initial")]
    for phase in phases:
        phase.getHAPvalues(hist)["Scale"][1] = True
    history.append(refine(proj, "background_scales"))

    # One angular correction and cells, after scale/background stabilization.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.data["General"]["Cell"][0] = True
    history.append(refine(proj, "zero_cells"))

    # Build a compact common profile in reversible increments.
    hist.set_refinements({"Instrument Parameters": ["W"]})
    history.append(refine(proj, "common_W"))
    hist.set_refinements({"Instrument Parameters": ["X"]})
    history.append(refine(proj, "common_WX"))
    proj.save()
    return proj, history


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tag", required=True)
    parser.add_argument("--parent", choices=sorted(CO_PARENTS), default="como")
    parser.add_argument("--extra", action="append", choices=sorted(EXTRAS), default=[])
    parser.add_argument("--background", type=int, default=6)
    args = parser.parse_args()
    _, history = build(args.tag, args.parent, args.extra, args.background)
    print("FINAL " + json.dumps(history[-1], default=float))


if __name__ == "__main__":
    main()
