#!/usr/bin/env python3
"""Add one watch-list phase and refine its nonnegative scale under a fixed cell."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_experiment import CANDIDATES, set_neutral_hap, snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("candidate", choices=sorted(CANDIDATES))
    parser.add_argument("--cycles", type=int, default=20)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.base), newgpx=str(args.output))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(CANDIDATES[args.candidate]),
        phasename=args.candidate,
        histograms=[hist],
        fmthint="CIF",
    )
    # Some reduced-tungsten COD records label W as W+5, which is not in the
    # bundled GSAS-II x-ray form-factor table. Neutral atom labels retain the
    # appropriate elemental x-ray scattering for this scale-only screen.
    if args.candidate.startswith("W18O49"):
        for atom in phase.atoms():
            atom.type = atom.element
        G2sc.SetupGeneral(phase.data, None)
    set_neutral_hap(phase, hist.name)
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.05, True]
    phase.set_refinements({"Cell": False})
    project.index_ids()
    project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Scale")
    for var in (":0:U", ":0:W", ":0:X"):
        project.set_Controls("parmMin", 0.0, var)
    project.set_Controls("cycles", args.cycles)
    project.refine(makeBack=False)
    first = snapshot(project, "candidate_scale_first")
    project.save()

    replay = G2sc.G2Project(str(args.output))
    replay.set_Controls("cycles", args.cycles)
    replay.refine(makeBack=False)
    second = snapshot(replay, "candidate_scale_replay")
    replay.save()
    args.output.with_suffix(".json").write_text(
        json.dumps({"first": first, "replay": second}, indent=2, default=float) + "\n"
    )
    print(json.dumps(second, indent=2, default=float))


if __name__ == "__main__":
    main()
