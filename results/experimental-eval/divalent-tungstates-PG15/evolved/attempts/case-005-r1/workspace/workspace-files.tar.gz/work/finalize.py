#!/usr/bin/env python3
"""Replay the accepted model over all data and export an exact result bundle."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE_GPX = ROOT / "work" / "atom_wcommon.gpx"
FINAL_GPX = ROOT / "final.gpx"
PATTERN = ROOT / "inputs" / "pattern.csv"
FIT_CSV = ROOT / "fit.csv"
RESULT_JSON = ROOT / "result.json"

PHASE_METADATA = {
    "WO3_mono_2311041": {
        "name": "monoclinic tungsten trioxide",
        "formula": "WO3",
        "cif_path": "phase_1_WO3.cif",
        "source_structure": "COD 2311041",
    },
    "Co3O4_9005896": {
        "name": "cobalt(II,III) oxide spinel",
        "formula": "Co3O4",
        "cif_path": "phase_2_Co3O4.cif",
        "source_structure": "COD 9005896",
    },
}


def json_float(value):
    """Convert NumPy and masked scalar values to ordinary JSON numbers."""
    return float(np.asarray(value))


def read_pattern_bounds() -> tuple[float, float, int]:
    with PATTERN.open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    x = [float(row["two_theta_deg"]) for row in rows]
    return min(x), max(x), len(x)


def assert_clean_model(project: G2sc.G2Project) -> None:
    names = [phase.name for phase in project.phases()]
    if names != list(PHASE_METADATA):
        raise RuntimeError(f"Unexpected final phase inventory: {names}")
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "Y", "Z", "SH/L", "I(L2)/I(L1)", "Zero"):
        if inst[key][2]:
            raise RuntimeError(f"Unsupported instrument term is still refining: {key}")
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if any(hap["Size"][2]):
            raise RuntimeError(f"Unused size term is refining for {phase.name}")
        if hap["Pref.Ori."][2]:
            raise RuntimeError(f"Unsupported texture term is refining for {phase.name}")
    if any(hist.data["Sample Parameters"][key][1] for key in ("Transparency", "SurfRoughA", "SurfRoughB")):
        raise RuntimeError("Unsupported transparency/roughness term is still refining")


def replay_full_range() -> None:
    xmin, xmax, _ = read_pattern_bounds()
    project = G2sc.G2Project(str(SOURCE_GPX), newgpx=str(FINAL_GPX))
    assert_clean_model(project)
    hist = project.histogram(0)
    hist.set_refinements({"Limits": [xmin, xmax]})
    project.data["Controls"]["data"]["shift factor"] = 1.0
    project.set_Controls("cycles", 20)
    project.refine(makeBack=False)
    project.save()

    # Reopen and replay so the submitted project is demonstrably reproducible.
    replay = G2sc.G2Project(str(FINAL_GPX))
    assert_clean_model(replay)
    replay.data["Controls"]["data"]["shift factor"] = 1.0
    replay.set_Controls("cycles", 20)
    replay.refine(makeBack=False)
    replay.save()


def export_bundle() -> dict:
    project = G2sc.G2Project(str(FINAL_GPX))
    assert_clean_model(project)
    hist = project.histogram(0)
    xmin, xmax, expected_points = read_pattern_bounds()

    # Export CIFs from this exact in-memory instance of the submitted project.
    for phase in project.phases():
        out = ROOT / PHASE_METADATA[phase.name]["cif_path"]
        phase.export_CIF(str(out))

    arrays = [np.asarray(item, dtype=float) for item in hist.data["data"][1][:6]]
    x, observed, weight, calculated, background, difference = arrays
    if len(x) != expected_points:
        raise RuntimeError(f"Expected {expected_points} profile rows, found {len(x)}")
    if not np.allclose(difference, observed - calculated, atol=1e-8, rtol=1e-12):
        raise RuntimeError("GSAS-II difference array does not equal observed-calculated")
    if not (math.isclose(x[0], xmin, abs_tol=1e-9) and math.isclose(x[-1], xmax, abs_tol=1e-9)):
        raise RuntimeError("Exported profile does not span the complete measured range")
    with FIT_CSV.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        writer.writerows(
            zip(
                map(float, x),
                map(float, observed),
                map(float, calculated),
                map(float, difference),
                map(float, background),
            )
        )

    raw_fractions = hist.ComputeMassFracs()
    total_fraction = sum(float(raw_fractions[name][0]) for name in PHASE_METADATA)
    if not math.isfinite(total_fraction) or total_fraction <= 0:
        raise RuntimeError(f"Invalid crystalline mass-fraction sum: {total_fraction}")

    phases = []
    for phase in project.phases():
        metadata = PHASE_METADATA[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        fraction, fraction_esd = raw_fractions[phase.name]
        phases.append(
            {
                "name": metadata["name"],
                "formula": metadata["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": metadata["cif_path"],
                "source_structure": metadata["source_structure"],
                "weight_fraction": float(fraction) / total_fraction,
                "weight_fraction_esd_formal": float(fraction_esd) / total_fraction,
                "unit_cell": {
                    key: {
                        "value": json_float(value),
                        "esd": json_float(cell_esd[key]),
                    }
                    for key, value in cell.items()
                },
            }
        )

    residuals = hist.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_variables": int(rvals["Nvars"]),
            "converged": bool(rvals["converged"]),
            "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
        },
        "measurement_model": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelengths_angstrom": [1.540598, 1.544426],
            "Kalpha2_over_Kalpha1": 0.5,
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
            "profile_points": int(len(x)),
            "weights": "1 / observed counts (Poisson counting approximation)",
        },
        "normalization": "Weight fractions sum to 1 over the modeled crystalline phases; amorphous or unidentified content is not quantified.",
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
    }
    if not math.isclose(sum(item["weight_fraction"] for item in phases), 1.0, abs_tol=1e-12):
        raise RuntimeError("Exported crystalline weight fractions do not sum to unity")
    RESULT_JSON.write_text(json.dumps(result, indent=2) + "\n")

    # A final read-only agreement check catches accidental export/project drift.
    check = G2sc.G2Project(str(FINAL_GPX))
    check_fracs = check.histogram(0).ComputeMassFracs()
    for item, phase in zip(phases, check.phases(), strict=True):
        expected = float(check_fracs[phase.name][0]) / sum(
            float(value[0]) for value in check_fracs.values()
        )
        if not math.isclose(item["weight_fraction"], expected, rel_tol=0, abs_tol=1e-12):
            raise RuntimeError(f"Fraction/project mismatch for {phase.name}")
    if not math.isclose(
        result["fit_statistics"]["Rwp_percent"],
        float(check.histogram(0).residuals["wR"]),
        rel_tol=0,
        abs_tol=1e-12,
    ):
        raise RuntimeError("Fit statistics/project mismatch")

    summary = {
        "phase_fractions": {
            item["formula"]: item["weight_fraction"] for item in phases
        },
        "formal_fraction_esds": {
            item["formula"]: item["weight_fraction_esd_formal"] for item in phases
        },
        "fit_statistics": result["fit_statistics"],
        "cells": {
            item["formula"]: item["unit_cell"] for item in phases
        },
        "range": result["measurement_model"]["two_theta_range_deg"],
    }
    (ROOT / "work" / "final_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    return summary


def main() -> None:
    replay_full_range()
    print(json.dumps(export_bundle(), indent=2))


if __name__ == "__main__":
    main()
