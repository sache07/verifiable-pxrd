#!/usr/bin/env python3
"""Apply one reversible profile/HAP trial to a converged GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_experiment import snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "trial",
        choices=[
            "size", "strain", "strain_uniaxial", "texture", "shl", "ratio", "polarization",
            "roughness_b", "fix_u0", "release_u", "release_x", "none",
            "w_coords", "w_uiso", "w_coords_uiso", "co_o_coords",
            "w_coords_common_uiso",
        ],
    )
    parser.add_argument("phase", nargs="?")
    parser.add_argument("--axis", type=int, nargs=3)
    parser.add_argument("--md-start", type=float, default=1.0)
    parser.add_argument("--shift-factor", type=float, default=1.0)
    parser.add_argument("--cycles", type=int, default=12)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.base), newgpx=str(args.output))
    hist = project.histogram(0)
    # Explicit physical bounds for the accepted common profile terms.
    for var in (":0:U", ":0:W", ":0:X"):
        project.set_Controls("parmMin", 0.0, var)

    if args.trial in (
        "size", "strain", "strain_uniaxial", "texture", "w_coords",
        "w_uiso", "w_coords_uiso", "co_o_coords",
        "w_coords_common_uiso",
    ):
        if not args.phase:
            raise SystemExit("A phase name is required for size/strain trials")
        phase = project.phase(args.phase)
        if phase is None:
            raise SystemExit(f"Unknown phase: {args.phase}")
        hap = phase.data["Histograms"][hist.name]
        if args.trial == "w_coords":
            for atom in phase.atoms():
                atom.refinement_flags = "X" if atom.element == "W" else " "
        elif args.trial == "w_uiso":
            for index, atom in enumerate(phase.atoms()):
                if atom.element != "W":
                    atom.refinement_flags = " "
                    continue
                atom.uiso = 0.005 if atom.uiso <= 0 else atom.uiso
                atom.refinement_flags = "U"
                project.set_Controls("parmMin", 0.0, f"{phase.id}::AUiso:{index}")
                project.set_Controls("parmMax", 0.05, f"{phase.id}::AUiso:{index}")
        elif args.trial == "w_coords_uiso":
            for index, atom in enumerate(phase.atoms()):
                if atom.element != "W":
                    atom.refinement_flags = " "
                    continue
                atom.uiso = 0.005 if atom.uiso <= 0 else atom.uiso
                atom.refinement_flags = "XU"
                project.set_Controls("parmMin", 0.0, f"{phase.id}::AUiso:{index}")
                project.set_Controls("parmMax", 0.05, f"{phase.id}::AUiso:{index}")
        elif args.trial == "w_coords_common_uiso":
            w_indices = []
            for index, atom in enumerate(phase.atoms()):
                if atom.element != "W":
                    atom.refinement_flags = " "
                    continue
                w_indices.append(index)
                atom.uiso = 0.005 if atom.uiso <= 0 else atom.uiso
                atom.refinement_flags = "XU"
                project.set_Controls("parmMin", 0.0, f"{phase.id}::AUiso:{index}")
                project.set_Controls("parmMax", 0.05, f"{phase.id}::AUiso:{index}")
            project.add_EquivConstr(
                [f"{phase.id}::AUiso:{index}" for index in w_indices]
            )
        elif args.trial == "co_o_coords":
            for atom in phase.atoms():
                atom.refinement_flags = "X" if atom.element == "O" else " "
        elif args.trial == "size":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1.0
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
            )
        elif args.trial == "strain":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 300.0
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
        elif args.trial == "strain_uniaxial":
            if args.axis is None or args.axis == [0, 0, 0]:
                raise SystemExit("A nonzero --axis h k l is required for uniaxial strain")
            strain = hap["Mustrain"]
            start = max(float(strain[1][0]), 1.0)
            strain[0] = "uniaxial"
            strain[1][0] = start
            strain[1][1] = start
            strain[2][0] = True
            strain[2][1] = True
            strain[2][2] = False
            strain[3] = list(args.axis)
            project.index_ids()
            project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;i")
            project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Mustrain;a")
        else:
            if args.axis is None or args.axis == [0, 0, 0]:
                raise SystemExit("A nonzero --axis h k l is required for texture")
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = args.md_start
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(args.axis)
            project.index_ids()
            project.set_Controls("parmMin", 0.2, f"{phase.id}:{hist.id}:MD")
            project.set_Controls("parmMax", 5.0, f"{phase.id}:{hist.id}:MD")
    elif args.trial == "shl":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.set_Controls("parmMin", 0.0005, ":0:SH/L")
    elif args.trial == "ratio":
        hist.set_refinements({"Instrument Parameters": ["I(L2)/I(L1)"]})
        project.set_Controls("parmMin", 0.0, ":0:I(L2)/I(L1)")
        project.set_Controls("parmMax", 1.0, ":0:I(L2)/I(L1)")
    elif args.trial == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.0, ":0:Polariz.")
        project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    elif args.trial == "roughness_b":
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, True]
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
        project.set_Controls("parmMax", 1.0, ":0:SurfRoughB")
    elif args.trial == "fix_u0":
        inst = hist.data["Instrument Parameters"][0]
        inst["U"][0] = 0.0
        inst["U"][1] = 0.0
        inst["U"][2] = False
    elif args.trial == "release_u":
        hist.set_refinements({"Instrument Parameters": ["U"]})
    elif args.trial == "release_x":
        hist.set_refinements({"Instrument Parameters": ["X"]})

    project.data["Controls"]["data"]["shift factor"] = args.shift_factor
    project.set_Controls("cycles", args.cycles)
    project.refine(makeBack=False)
    first = snapshot(project, f"{args.trial}_first")
    project.save()

    # Save/reopen/replay is part of the acceptance test.
    replay = G2sc.G2Project(str(args.output))
    replay.data["Controls"]["data"]["shift factor"] = args.shift_factor
    replay.set_Controls("cycles", args.cycles)
    replay.refine(makeBack=False)
    second = snapshot(replay, f"{args.trial}_replay")
    replay.save()
    args.output.with_suffix(".json").write_text(
        json.dumps({"first": first, "replay": second}, indent=2, default=float) + "\n"
    )
    print(json.dumps(second, indent=2, default=float))


if __name__ == "__main__":
    main()
