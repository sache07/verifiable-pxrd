#!/usr/bin/env python3
"""Build and test staged GSAS-II models for the supplied PXRD pattern."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
PATTERN = ROOT / "inputs" / "pattern.csv"
INST = WORK / "cu_ka.instprm"
XYE = WORK / "pattern.xye"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = {
    "WO3_mono_1528915": cod_cif("1528915"),
    "WO3_mono_2311041": cod_cif("2311041"),
    "WO3_triclinic_2106293": cod_cif("2106293"),
    "WO3_orthorhombic_2107312": cod_cif("2107312"),
    "WO3_tetragonal_1521533": cod_cif("1521533"),
    "Co3O4_9005896": cod_cif("9005896"),
    "CoO_1541662": cod_cif("1541662"),
    "CoWO4_watch": WORK / "cowo4_clean.cif",
    "W18O49_1528166": cod_cif("1528166"),
    "W18O49_1538315": cod_cif("1538315"),
}


def prepare_xye() -> None:
    with PATTERN.open(newline="") as source, XYE.open("w") as target:
        rows = csv.DictReader(source)
        target.write("# two_theta intensity sigma\n")
        for row in rows:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            target.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")


def set_neutral_hap(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [1.0, False]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    # Neutral crystallite-size and microstrain terms. Values are deliberately
    # large/zero so they add no appreciable broadening while their flags stay off.
    size = hap["Size"]
    size[0] = "isotropic"
    size[1][0] = 1.0e6
    size[2] = [False for _ in size[2]]
    if len(size) > 5:
        size[5] = [False for _ in size[5]]
    strain = hap["Mustrain"]
    strain[0] = "isotropic"
    strain[1][0] = 0.0
    strain[2] = [False for _ in strain[2]]
    if len(strain) > 5:
        strain[5] = [False for _ in strain[5]]
    pref = hap["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = False


def configure_histogram(hist) -> None:
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": False,
                "no. coeffs": 6,
                "coeffs": [3100.0, -60.0, 15.0, 0.0, 0.0, 0.0],
            }
        }
    )
    sample = hist.data["Sample Parameters"]
    sample["Type"] = "Bragg-Brentano"
    sample["Scale"] = [1.0, False]
    sample["Gonio. radius"] = 240.0
    sample["Shift"] = [-750.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)", "Zero"):
        if key in inst and len(inst[key]) > 2:
            inst[key][2] = False


def snapshot(gpx, label: str) -> dict:
    hist = gpx.histogram(0)
    result = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {
            key: val[1]
            for key, val in hist.data["Instrument Parameters"][0].items()
            if isinstance(val, list) and len(val) > 1
        },
        "sample": {
            key: val[0]
            for key, val in hist.data["Sample Parameters"].items()
            if isinstance(val, list) and val and isinstance(val[0], (int, float))
        },
        "background": hist.data["Background"][0],
        "phases": {},
    }
    try:
        result["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    return result


def run_refinement(gpx, label: str, history: list[dict]) -> None:
    gpx.set_Controls("cycles", 8)
    gpx.refine(makeBack=False)
    history.append(snapshot(gpx, label))
    print(json.dumps(history[-1], indent=2, default=float))


def build_model(model_name: str, phase_names: list[str], include_x: bool = False) -> Path:
    prepare_xye()
    out = WORK / f"{model_name}.gpx"
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(str(XYE), str(INST), fmthint="xye")
    configure_histogram(hist)
    for name in phase_names:
        phase = gpx.add_phase(
            str(CANDIDATES[name]), phasename=name, histograms=[hist], fmthint="CIF"
        )
        set_neutral_hap(phase, hist.name)
    history: list[dict] = [snapshot(gpx, "initial")]
    # Re-establish the common baseline whenever this model is built.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in gpx.phases():
        phase.set_HAP_refinements({"Scale": True})
    run_refinement(gpx, "background_scales", history)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(gpx, "plus_specimen_shift", history)
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    run_refinement(gpx, "plus_cells", history)
    hist.set_refinements({"Instrument Parameters": ["W"]})
    run_refinement(gpx, "plus_W", history)
    hist.set_refinements({"Instrument Parameters": ["U"]})
    run_refinement(gpx, "plus_U", history)
    if include_x:
        hist.set_refinements({"Instrument Parameters": ["X"]})
        run_refinement(gpx, "plus_X", history)
    gpx.save()
    (WORK / f"{model_name}_history.json").write_text(
        json.dumps(history, indent=2, default=float) + "\n"
    )
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model")
    parser.add_argument("phases", nargs="+")
    parser.add_argument("--include-x", action="store_true")
    args = parser.parse_args()
    unknown = sorted(set(args.phases) - CANDIDATES.keys())
    if unknown:
        raise SystemExit(f"Unknown candidates: {unknown}")
    print(build_model(args.model, args.phases, include_x=args.include_x))


if __name__ == "__main__":
    main()
