#!/usr/bin/env python3
"""Extract observed/calculated/background/difference arrays from a GSAS-II project."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    project = G2sc.G2Project(str(args.gpx))
    hist = project.histogram(0)
    arrays = [np.asarray(v) for v in hist.data["data"][1][:6]]
    with args.output.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "observed", "weight", "calculated", "background", "difference"])
        writer.writerows(zip(*arrays))


if __name__ == "__main__":
    main()
