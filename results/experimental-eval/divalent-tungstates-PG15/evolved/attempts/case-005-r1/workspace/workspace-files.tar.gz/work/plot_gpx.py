#!/usr/bin/env python3
"""Create full-range and isolated-family diagnostics from a GSAS-II project."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("profile", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    data = np.genfromtxt(args.profile, delimiter=",", names=True)
    x = data["two_theta_deg"]
    obs = data["observed_counts"]
    calc = data["calculated_counts"]
    bkg = data["background_counts"]
    diff = data["difference_counts"]

    fig = plt.figure(figsize=(15, 15), constrained_layout=True)
    grid = fig.add_gridspec(5, 2, height_ratios=[1.25, 1, 1, 1, 1])
    full = fig.add_subplot(grid[0, :])
    full.plot(x, obs, color="black", lw=0.55, label="observed")
    full.plot(x, calc, color="#d62728", lw=0.65, label="calculated")
    offset = min(obs) - 0.18 * (max(obs) - min(obs))
    full.plot(x, diff + offset, color="#1f77b4", lw=0.45, label="difference (offset)")
    full.plot(x, bkg, color="#2ca02c", lw=0.5, label="background")
    full.set_xlim(10, 100)
    full.set_ylabel("counts")
    full.legend(ncol=4, fontsize=8)
    full.set_title(args.profile.stem)

    windows = [
        (18.6, 20.1, "low: Co₃O₄ 111"),
        (23.0, 25.1, "low: WO₃ triplet"),
        (31.1, 34.8, "mid-low: mixed families"),
        (36.5, 39.3, "mid: Co₃O₄ 311/222"),
        (44.2, 45.7, "mid: Co₃O₄ 400"),
        (49.7, 51.1, "mid: WO₃ + overlap"),
        (54.0, 56.8, "mid-high: mixed families"),
        (59.0, 66.0, "high: Co₃O₄ 511/440"),
    ]
    for ax, (lo, hi, title) in zip([fig.add_subplot(grid[i, j]) for i in range(1, 5) for j in range(2)], windows):
        mask = (x >= lo) & (x <= hi)
        ax.plot(x[mask], obs[mask], color="black", lw=0.8)
        ax.plot(x[mask], calc[mask], color="#d62728", lw=0.9)
        local_span = max(obs[mask]) - min(obs[mask])
        local_offset = min(obs[mask]) - 0.20 * local_span
        ax.plot(x[mask], diff[mask] + local_offset, color="#1f77b4", lw=0.65)
        ax.plot(x[mask], bkg[mask], color="#2ca02c", lw=0.55)
        ax.set_xlim(lo, hi)
        ax.set_title(title, fontsize=9)
        ax.tick_params(labelsize=8)
    fig.supxlabel(r"2$\theta$ (degrees)")
    fig.supylabel("counts")
    fig.savefig(args.output, dpi=170)


if __name__ == "__main__":
    main()
