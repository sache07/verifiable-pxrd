#!/usr/bin/env python3
"""Add fixed-cell NiO to the converged common model and refine its scale only."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


NIO_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/01/00/1010093.cif"
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.base.resolve()))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(args.output.resolve()))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(NIO_CIF), phasename="NiO_watch", histograms=[hist], fmthint="CIF"
    )
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][:] = [0.0, False]
    for term in hap["Babinet"].values():
        term[:] = [0.0, False]
    phase.data["General"]["Cell"][0] = False
    phase.HAPvalue("Scale", 0.10)
    phase.set_HAP_refinements({"Scale": True})
    p_id = phase.data["pId"]
    h_id = hist.data["data"][0]["hId"]
    project.set_Controls("parmMin", 0.0, variable=f"{p_id}:{h_id}:Scale")

    project.save()
    project.refine(makeBack=False)
    project.save()
    project = G2sc.G2Project(str(args.output.resolve()))
    project.refine(makeBack=False)
    project.save()

    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    vary = [str(v) for v in cov.get("varyList", [])]
    scale_name = f"{p_id}:{h_id}:Scale"
    scale_result = None
    if scale_name in vary:
        i = vary.index(scale_name)
        scale_result = {
            "value": float(cov["variables"][i]),
            "sigma": float(cov["sig"][i]),
        }
    result = {
        "Rwp": hist.data["data"][0].get("wR"),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "mass_fractions": hist.ComputeMassFracs(),
        "NiO_scale": scale_result,
        "NiO_cell_refined": phase.data["General"]["Cell"][0],
        "frozen": project.get_Frozen(),
    }
    payload = json.dumps(result, indent=2, default=str) + "\n"
    if args.json:
        args.json.write_text(payload)
    print("WATCH_RESULT " + json.dumps(result, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
