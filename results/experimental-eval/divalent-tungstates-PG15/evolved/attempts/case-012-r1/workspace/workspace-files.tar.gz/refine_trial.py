#!/usr/bin/env python3
"""Build and stage a conservative GSAS-II Rietveld trial model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PHASES = {
    "NiWO4": ROOT / "candidates/niwo4_clean.cif",
    "NiWO4_Zn_proto": ROOT / "candidates/niwo4_zn_prototype.cif",
    "NiWO4_Mg_proto": ROOT / "candidates/niwo4_mg_prototype.cif",
    "NiWO4_Mn_proto": ROOT / "candidates/niwo4_mn_prototype.cif",
    "WO3_monoclinic": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/1/52/89/1528915.cif"
    ),
    "WO3_monoclinic_alt": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/2/31/10/2311041.cif"
    ),
    "WO3_monoclinic_neutron": ROOT / "candidates/wo3_p21n_neutron.cif",
    "WO3_triclinic": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/2/10/62/2106293.cif"
    ),
    "NiO": Path(
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/1/01/00/1010093.cif"
    ),
}


def summary(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    hmeta = hist.data["data"][0]
    inst = hist.data["Instrument Parameters"][0]
    cov = project.data["Covariance"]["data"]
    try:
        mass = hist.ComputeMassFracs()
    except Exception as exc:
        mass = {"error": str(exc)}
    out = {
        "label": label,
        "wR_percent": hmeta.get("wR"),
        "R": hmeta.get("R"),
        "Rb": hmeta.get("Rb"),
        "Rwp": cov.get("Rvals", {}).get("Rwp"),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "chisq": cov.get("Rvals", {}).get("chisq"),
        "mass_fractions": mass,
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L")
            if key in inst
        },
        "sample_parameters": hist.data["Sample Parameters"],
        "background": hist.data["Background"][0],
        "phases": {},
        "frozen": project.get_Frozen(),
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        out["phases"][phase.name] = {
            "scale": hap["Scale"],
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    print("STAGE " + json.dumps(out, default=str, sort_keys=True))
    return out


def run_refine(project: G2sc.G2Project, label: str) -> G2sc.G2Project:
    project.save()
    # Reopen before every accepted stage so the on-disk project is what is replayed.
    project = G2sc.G2Project(str(project.filename))
    project.refine(makeBack=False)
    project.save()
    summary(project, label)
    return project


def build(output: Path, phase_names: list[str], instrument: Path) -> G2sc.G2Project:
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(instrument),
        fmthint="comma/tab/semicolon",
    )
    hist.Limits("lower", 10.02)
    hist.Limits("upper", 99.98)
    for name in phase_names:
        project.add_phase(
            str(PHASES[name]), phasename=name, histograms=[hist], fmthint="CIF"
        )

    # Neutral nuisance state: no phase-specific size/strain, texture, extinction,
    # hydrostatic strain or Babinet correction is active in the common baseline.
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [1000.0, 1000.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"][:] = [0.0, False]
        for term in hap["Babinet"].values():
            term[:] = [0.0, False]

    project.set_Controls("cycles", 8)
    controls = project.data["Controls"]["data"]
    controls["deriv type"] = "analytic Hessian"
    controls["min dM/M"] = 1.0e-5
    controls["Marquardt"] = -3

    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    # The absolute histogram scale is fixed; only phase scales carry composition.
    sample["Scale"][0] = 1.0
    sample["Scale"][1] = False
    for nuisance in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if nuisance in sample and isinstance(sample[nuisance], list) and len(sample[nuisance]) > 1:
            sample[nuisance][1] = False
    # Use a minimal nonnegative U/W/X common profile; V, Y and Z remain neutral.
    for key, value in (("U", 2.0), ("V", 0.0), ("W", 2.0), ("X", 0.2), ("Y", 0.0), ("Z", 0.0)):
        inst[key][0] = value
        inst[key][1] = value
        inst[key][2] = False
    inst["SH/L"][0] = inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": [1000.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            }
        }
    )
    for i, phase in enumerate(project.phases()):
        phase.HAPvalue("Scale", 1.0)
        phase.set_HAP_refinements({"Scale": True})
        project.set_Controls("parmMin", 0.0, variable=f"{i}:0:Scale")
    for key in ("U", "W", "X"):
        project.set_Controls("parmMin", 0.0, variable=f":0:{key}")
    project.set_Controls("parmMax", 0.2, variable=":0:SH/L")
    project.save()
    summary(project, "setup")
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--stop-after",
        choices=("scales", "zero", "cells", "W", "X", "U", "replay"),
        default="replay",
    )
    parser.add_argument(
        "--instrument", type=Path, default=ROOT / "instrument.instprm"
    )
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+", choices=sorted(PHASES))
    args = parser.parse_args()
    output = args.output.resolve()
    project = build(output, args.phases, args.instrument.resolve())
    hist = project.histogram(0)

    project = run_refine(project, "background_scales")
    if args.stop_after == "scales":
        return
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project = run_refine(project, "plus_zero")
    if args.stop_after == "zero":
        return

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project = run_refine(project, "plus_cells")
    if args.stop_after == "cells":
        return

    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["W"]})
    project = run_refine(project, "plus_W")
    if args.stop_after == "W":
        return

    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["X"]})
    project = run_refine(project, "plus_X")
    if args.stop_after == "X":
        return

    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["U"]})
    project = run_refine(project, "plus_U")
    if args.stop_after == "U":
        return

    # Re-open and replay the full range with no settings change.
    project = G2sc.G2Project(str(output))
    project.refine(makeBack=False)
    project.save()
    summary(project, "replay")


if __name__ == "__main__":
    main()
