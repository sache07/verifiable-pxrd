#!/usr/bin/env python3
"""Replay a single reversible profile/intensity nuisance trial from a GPX."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def report(project: G2sc.G2Project, trial: str) -> dict:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    vary = [str(v) for v in cov.get("varyList", [])]
    values = np.asarray(cov.get("variables", []), dtype=float)
    sigmas = np.asarray(cov.get("sig", []), dtype=float)
    selected = {
        name: {
            "value": float(values[i]),
            "sigma": float(sigmas[i]) if i < len(sigmas) else None,
        }
        for i, name in enumerate(vary)
        if any(
            token in name
            for token in (
                "Size",
                "Mustrain",
                "MD",
                "Polariz.",
                "SurfRough",
                "dAx",
                "dAy",
                "dAz",
            )
        )
    }
    return {
        "trial": trial,
        "project": str(project.filename),
        "Rwp": hist.data["data"][0].get("wR"),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "mass_fractions": hist.ComputeMassFracs(),
        "selected_variables": selected,
        "phase_HAP": {
            phase.name: {
                "Size": phase.getHAPvalues(hist)["Size"],
                "Mustrain": phase.getHAPvalues(hist)["Mustrain"],
                "Pref.Ori.": phase.getHAPvalues(hist)["Pref.Ori."],
            }
            for phase in project.phases()
        },
        "atoms": {
            phase.name: {
                atom.label: {
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            }
            for phase in project.phases()
        },
        "polarization": hist.data["Instrument Parameters"][0]["Polariz."],
        "surface_roughness": {
            key: hist.data["Sample Parameters"][key]
            for key in ("SurfRoughA", "SurfRoughB")
        },
        "background": hist.data["Background"][0],
        "frozen": project.get_Frozen(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "trial",
        choices=(
            "replay",
            "size",
            "strain",
            "size_strain",
            "no_size",
            "no_strain",
            "texture",
            "no_texture",
            "atoms",
            "polarization",
            "roughness",
            "roughness_ab",
            "background8",
            "background10",
        ),
    )
    parser.add_argument("--phase", type=int, default=0)
    parser.add_argument("--axis", nargs=3, type=int, default=(0, 0, 1))
    parser.add_argument("--atoms", nargs="+", default=["all"])
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.base.resolve()))
    # Clone before any call that indexes parameter IDs: GSAS-II may save the
    # active project while indexing, so this protects the immutable baseline.
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project.save(str(args.output.resolve()))
    hist = project.histogram(0)
    if args.trial in (
        "size",
        "strain",
        "size_strain",
        "no_size",
        "no_strain",
        "texture",
        "no_texture",
        "atoms",
    ):
        phase = project.phase(args.phase)
        hap = phase.getHAPvalues(hist)
        p_id = phase.data["pId"]
        h_id = hist.data["data"][0]["hId"]
        if args.trial == "no_size":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][:] = [10.0, 1000.0, 1.0]
            hap["Size"][2][:] = [False, False, False]
            hap["Size"][5][:] = [False] * len(hap["Size"][5])
        elif args.trial == "no_strain":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
            hap["Mustrain"][2][:] = [False, False, False]
            hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        elif args.trial == "no_texture":
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
            hap["Pref.Ori."][3] = list(args.axis)
        elif args.trial == "atoms":
            if args.atoms == ["all"]:
                phase.set_refinements({"Atoms": {"all": "X"}})
            else:
                phase.set_refinements(
                    {"Atoms": {label: "X" for label in args.atoms}}
                )
        elif args.trial == "size":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1.0
            hap["Size"][2][0] = True
            project.set_Controls("parmMin", 0.01, variable=f"{p_id}:{h_id}:Size;i")
            project.set_Controls("parmMax", 10.0, variable=f"{p_id}:{h_id}:Size;i")
        elif args.trial == "strain":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 500.0
            hap["Mustrain"][2][0] = True
            project.set_Controls(
                "parmMin", 0.0, variable=f"{p_id}:{h_id}:Mustrain;i"
            )
            project.set_Controls(
                "parmMax", 10000.0, variable=f"{p_id}:{h_id}:Mustrain;i"
            )
        elif args.trial == "size_strain":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1.0
            hap["Size"][2][0] = True
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 500.0
            hap["Mustrain"][2][0] = True
            project.set_Controls("parmMin", 0.01, variable=f"{p_id}:{h_id}:Size;i")
            project.set_Controls("parmMax", 10.0, variable=f"{p_id}:{h_id}:Size;i")
            project.set_Controls(
                "parmMin", 0.0, variable=f"{p_id}:{h_id}:Mustrain;i"
            )
            project.set_Controls(
                "parmMax", 10000.0, variable=f"{p_id}:{h_id}:Mustrain;i"
            )
        else:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(args.axis)
            project.set_Controls("parmMin", 0.2, variable=f"{p_id}:{h_id}:MD")
            project.set_Controls("parmMax", 5.0, variable=f"{p_id}:{h_id}:MD")
    elif args.trial == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif args.trial == "roughness":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"][:] = [0.0, False]
        sample["SurfRoughB"][:] = [0.01, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")
    elif args.trial == "roughness_ab":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"][:] = [0.5, True]
        sample["SurfRoughB"][:] = [0.05, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")
    elif args.trial in ("background8", "background10"):
        n_coeffs = 8 if args.trial == "background8" else 10
        hist.set_refinements(
            {
                "Background": {
                    "type": "chebyschev-1",
                    "refine": True,
                    "no. coeffs": n_coeffs,
                }
            }
        )

    project.save()
    # First convergence, followed by an exact on-disk reopen/replay.
    project.refine(makeBack=False)
    project.save()
    project = G2sc.G2Project(str(args.output.resolve()))
    project.refine(makeBack=False)
    project.save()

    result = report(project, args.trial)
    payload = json.dumps(result, indent=2, default=str) + "\n"
    if args.json:
        args.json.write_text(payload)
    print("TRIAL_RESULT " + json.dumps(result, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
