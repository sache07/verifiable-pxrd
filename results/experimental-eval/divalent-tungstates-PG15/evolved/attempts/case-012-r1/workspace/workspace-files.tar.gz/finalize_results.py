#!/usr/bin/env python3
"""Create the exact final GPX and all requested exports from a vetted model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def neutralize_rejected_terms(project: G2sc.G2Project) -> None:
    """Make the accepted/rejected refinement choices explicit in the GPX."""
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    # Full recorded angular range (the +1 search rule includes both endpoints).
    hist.data["Limits"][1] = list(hist.data["Limits"][0])

    sample["Scale"][:] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][0] = 0.0
        sample[key][1] = False

    for key in ("V", "Y", "Z"):
        inst[key][0] = inst[key][1] = 0.0
        inst[key][2] = False
    inst["SH/L"][0] = inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False
    for key in ("Zero", "Polariz.", "U", "W", "X"):
        inst[key][2] = True
    for key in ("Lam1", "Lam2", "I(L2)/I(L1)"):
        inst[key][2] = False

    hist.data["Background"][0][1] = True
    for i, phase in enumerate(project.phases()):
        phase.data["General"]["Cell"][0] = True
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 1000.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][:] = [0.0, False]
        for term in hap["Babinet"].values():
            term[:] = [0.0, False]

        if i == 0:  # NiWO4
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
            hap["Mustrain"][2][:] = [False, False, False]
            hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = float(hap["Pref.Ori."][1])
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [0, 0, 1]
            for atom in phase.atoms():
                atom.refinement_flags = "X" if atom.label == "Ni1" else ""
        else:  # WO3
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2][:] = [True, False, False]
            hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
            for atom in phase.atoms():
                atom.refinement_flags = ""


def fit_statistics(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    hfit = hist.data["data"][0]
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "Rwp_percent": float(hfit["wR"]),
        "Rp_percent": float(hfit["R"]),
        "R_background_percent": float(hfit["Rb"]),
        "weighted_R_background_percent": float(hfit["wRb"]),
        "Rexp_percent": float(hfit["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "durbin_watson": float(hfit["Durbin-Watson"]),
        "number_of_observations": int(hfit["Nobs"]),
        "two_theta_min_deg": float(hist.getdata("x")[0]),
        "two_theta_max_deg": float(hist.getdata("x")[-1]),
    }


def phase_record(
    phase: G2sc.G2Phase,
    fraction: tuple[float, float],
    display_name: str,
    formula: str,
    cif_path: str,
) -> dict:
    cell, cell_esd = phase.get_cell_and_esd()
    return {
        "name": display_name,
        "formula": formula,
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "cif_path": cif_path,
        "weight_fraction": float(fraction[0]),
        "weight_fraction_formal_esd": float(fraction[1]),
        "cell": {key: float(value) for key, value in cell.items()},
        "cell_formal_esd": {key: float(value) for key, value in cell_esd.items()},
    }


def write_report(project: G2sc.G2Project, result: dict) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    ni_hap = project.phase(0).getHAPvalues(hist)
    wo_hap = project.phase(1).getHAPvalues(hist)
    ni_atom = project.phase(0).atom("Ni1")
    stats = result["fit_statistics"]
    ni, wo = result["phases"]
    n_background = hist.data["Background"][0][2]
    report = f"""# Quantitative phase analysis

## Result

The modeled crystalline material is **NiWO4 (wolframite, P2/c)** plus **monoclinic WO3 (P21/n)**. Fractions normalized over these modeled crystalline phases are **{100*ni['weight_fraction']:.2f} wt% NiWO4** and **{100*wo['weight_fraction']:.2f} wt% WO3**. The covariance-derived formal standard uncertainty is about {100*ni['weight_fraction_formal_esd']:.2f} wt% for each fraction, but a more realistic model/systematic uncertainty is approximately 1 wt% because source/profile and structural-model choices dominate the counting-statistical value. No amorphous fraction can be obtained from this analysis, so these values are not absolute bulk fractions.

The full-range final replay gives Rwp = {stats['Rwp_percent']:.3f}%, Rp = {stats['Rp_percent']:.3f}%, Rexp = {stats['Rexp_percent']:.3f}%, and GOF = {stats['goodness_of_fit']:.3f} for {stats['number_of_observations']} observations from {stats['two_theta_min_deg']:.5f} to {stats['two_theta_max_deg']:.5f} degrees 2theta.

## Evidence and model selection

The 900 C NiO + WO3 reaction context supports NiWO4 formation. NiWO4 is required by coherent families near 19.19, 23.91/24.85, 30.87, 36.52, 41.63, and 54.58 degrees. Residual monoclinic WO3 is independently required by its split low-angle cluster at 23.06, 23.53, and 24.28 degrees and families near 26.53, 28.82, 33.20/34.09, and 55.88 degrees.

Inventory challenges used the same restrained nuisance model. A neutron-derived monoclinic WO3 record, transformed exactly to the conventional near-orthogonal P21/n setting, gave Rwp 5.558% before later nuisance/coordinate tests; an older rounded monoclinic record gave 5.979%, while triclinic WO3 gave 5.584% despite three additional cell freedoms. A single-wavelength source model gave 6.991%, supporting the reported Cu Kalpha1/Kalpha2 pair and fixed 0.5 intensity ratio. For NiWO4, the exact P2/c record decisively outperformed fully occupied Ni-substituted ZnWO4, MgWO4, and MnWO4 prototypes (Rwp 5.55% versus 7.46%, 6.98%, and 7.45%, respectively). All screened structures had sensible occupancy and octahedral coordination before fitting.

NiO was reintroduced under the final common profile with its cell fixed. It refined to only 0.21 +/- 0.09 wt% and improved Rwp by 0.0014 percentage point; its diagnostic 43.3 degree family is absent. This is below reliable detection and NiO is therefore excluded rather than reported as a phase. The trial implies an approximate 3-sigma upper level near 0.5 wt% under this model.

## Refinement and physical checks

The common baseline uses a {n_background}-coefficient smooth Chebyshev background, one zero correction ({inst['Zero'][1]:.5f} degrees), nonnegative U/W/X profile terms ({inst['U'][1]:.3f}, {inst['W'][1]:.3f}, {inst['X'][1]:.3f}), and refined polarization ({inst['Polariz.'][1]:.4f}). V/Y/Z are zero, SH/L is fixed at 0.002, sample shift/transparency/roughness are neutral, and phase size terms are fixed at the effectively neutral 10 micrometre limit. Low-, middle-, and high-angle isolated families show no systematic position or common-width drift. WO3 alone supports replay-stable isotropic microstrain ({wo_hap['Mustrain'][1][0]:.0f} microstrain); WO3 size runs to the neutral bound. NiWO4 isotropic strain runs to zero, while its apparent size term is bound when tested alone and becomes more than 0.90 correlated with common X and WO3 strain when combined; all are therefore rejected.

Symmetry-distinct [100], [010], [001], and [101] March-Dollase trials were compared. WO3 ratios remained statistically indistinguishable from random orientation. NiWO4 supports a small [001] correction (MD = {ni_hap['Pref.Ori.'][1]:.5f}); improvements occur across several isolated families rather than one line. Surface roughness was rejected: its two-parameter test drove A to its lower bound and correlated B by more than 0.90 with both phase scales. Refining SH/L was likewise rejected because it was 0.98 correlated with zero.

The refined Ni coordinate is y = {ni_atom.coordinates[1]:.6f}; the other NiWO4 atom coordinates remain at the selected exact-record values. Unrestrained oxygen-coordinate refinement lowered Rwp but produced an under-bonded W coordination and was rejected. WO3 coordinates remain those of the neutron parent. Thus the cells, phase fractions, Ni position, and heavy-atom framework are supported by this laboratory pattern, but detailed oxygen positions are not independently determined reliably.

`final.gpx`, the two exported CIFs, `fit.csv`, and `result.json` all come from the same final save/reopen/replay state.
"""
    (ROOT / "report.md").write_text(report)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    args = parser.parse_args()

    final_path = ROOT / "final.gpx"
    project = G2sc.G2Project(str(args.base.resolve()))
    project.save(str(final_path))
    neutralize_rejected_terms(project)
    project.save()

    replay_rwp = []
    for _ in range(3):
        project = G2sc.G2Project(str(final_path))
        project.refine(makeBack=False)
        project.save()
        replay_rwp.append(float(project.histogram(0).data["data"][0]["wR"]))

    project = G2sc.G2Project(str(final_path))
    frozen = project.get_Frozen()
    if frozen:
        raise RuntimeError(f"Final project contains frozen/bound variables: {frozen}")

    hist = project.histogram(0)
    x = np.asarray(hist.getdata("x"), dtype=float)
    yobs = np.asarray(hist.getdata("yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("ycalc"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    if hist.data["data"][0]["Nobs"] != len(x):
        raise RuntimeError("Final refinement does not include the complete measured range")
    if ycalc[0] == 0 or ycalc[-1] == 0:
        raise RuntimeError("Calculated profile is missing a range endpoint")

    project.phase(0).export_CIF(str(ROOT / "phase_NiWO4.cif"))
    project.phase(1).export_CIF(str(ROOT / "phase_WO3.cif"))
    profile = np.column_stack((x, yobs, ycalc, yobs - ycalc, background))
    np.savetxt(
        ROOT / "fit.csv",
        profile,
        delimiter=",",
        header=(
            "two_theta_deg,observed_counts,calculated_counts,"
            "difference_counts,background_counts"
        ),
        comments="",
        fmt="%.10g",
    )

    fractions = hist.ComputeMassFracs()
    result = {
        "phases": [
            phase_record(
                project.phase(0),
                fractions[project.phase(0).name],
                "NiWO4",
                "NiWO4",
                "phase_NiWO4.cif",
            ),
            phase_record(
                project.phase(1),
                fractions[project.phase(1).name],
                "WO3 (monoclinic)",
                "WO3",
                "phase_WO3.cif",
            ),
        ],
        "fit_statistics": fit_statistics(project),
        "fraction_basis": "normalized over modeled crystalline phases",
        "project_path": "final.gpx",
    }
    if not np.isclose(sum(p["weight_fraction"] for p in result["phases"]), 1.0):
        raise RuntimeError("Final phase fractions are not normalized")
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    write_report(project, result)

    # Verify exact numerical agreement after writing the requested exports.
    csv = np.loadtxt(ROOT / "fit.csv", delimiter=",", skiprows=1)
    if not np.allclose(csv[:, 0], x, rtol=0, atol=5e-8):
        raise RuntimeError("fit.csv x values do not match final.gpx")
    if not np.allclose(csv[:, 1], yobs, rtol=1e-9, atol=1e-6):
        raise RuntimeError("fit.csv observed values do not match final.gpx")
    if not np.allclose(csv[:, 2], ycalc, rtol=1e-9, atol=1e-6):
        raise RuntimeError("fit.csv calculated values do not match final.gpx")
    print(
        json.dumps(
            {
                "replay_Rwp": replay_rwp,
                "result": result,
                "frozen": frozen,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
