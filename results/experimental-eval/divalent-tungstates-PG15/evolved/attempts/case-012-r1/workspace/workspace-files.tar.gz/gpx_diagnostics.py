#!/usr/bin/env python3
"""Residual and peak-shape diagnostics for a GSAS-II powder project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from scipy.signal import find_peaks, peak_widths


def peak_table(x: np.ndarray, signal: np.ndarray, prominence: float) -> list[dict]:
    dx = float(np.median(np.diff(x)))
    idx, props = find_peaks(signal, prominence=prominence, distance=5, width=2)
    widths = peak_widths(signal, idx, rel_height=0.5)[0] * dx
    rows = []
    for n, i in enumerate(idx):
        rows.append(
            {
                "index": int(i),
                "two_theta": float(x[i]),
                "height": float(signal[i]),
                "prominence": float(props["prominences"][n]),
                "fwhm_deg": float(widths[n]),
            }
        )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    project = G2sc.G2Project(args.project)
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("x"))
    yobs = np.asarray(hist.getdata("yobs"))
    ycalc = np.asarray(hist.getdata("ycalc"))
    background = np.asarray(hist.getdata("background"))
    obs = yobs - background
    calc = ycalc - background
    residual = yobs - ycalc

    obs_rows = peak_table(x, obs, 120.0)
    calc_rows = peak_table(x, calc, 70.0)
    matched = []
    for row in obs_rows:
        near = min(calc_rows, key=lambda c: abs(c["two_theta"] - row["two_theta"]))
        delta = row["two_theta"] - near["two_theta"]
        if abs(delta) > 0.20:
            continue
        neighbors = [
            o for o in obs_rows
            if o is not row and abs(o["two_theta"] - row["two_theta"]) < 0.55
        ]
        matched.append(
            {
                "two_theta_obs": row["two_theta"],
                "two_theta_calc": near["two_theta"],
                "delta_deg": delta,
                "height_obs": row["height"],
                "height_calc": near["height"],
                "height_ratio_obs_calc": row["height"] / max(near["height"], 1.0),
                "fwhm_obs_deg": row["fwhm_deg"],
                "fwhm_calc_deg": near["fwhm_deg"],
                "isolated_observed": len(neighbors) == 0,
            }
        )

    res_idx, res_props = find_peaks(residual, prominence=50.0, distance=7, width=2)
    residual_rows = sorted(
        [
            {
                "two_theta": float(x[i]),
                "residual": float(residual[i]),
                "prominence": float(res_props["prominences"][n]),
                "standardized": float(residual[i] / np.sqrt(max(yobs[i], 1.0))),
            }
            for n, i in enumerate(res_idx)
            if 10.02 <= x[i] <= 99.98
        ],
        key=lambda row: row["prominence"],
        reverse=True,
    )

    reflections = {}
    for phase, refdict in hist.reflections().items():
        refs = np.asarray(refdict["RefList"])
        reflections[phase] = [
            {
                "hkl": [int(v) for v in ref[:3]],
                "two_theta": float(ref[5]),
                "Fcalc_sq": float(ref[9]),
            }
            for ref in refs
        ]

    output = {
        "project": args.project,
        "fit": hist.data["data"][0],
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": hist.data["Instrument Parameters"][0],
        "matched_peaks_by_angle": sorted(matched, key=lambda r: r["two_theta_obs"]),
        "largest_positive_residual_peaks": residual_rows[:30],
        "reflections": reflections,
    }
    payload = json.dumps(output, default=str, indent=2)
    if args.output:
        args.output.write_text(payload + "\n")
    else:
        print(payload)


if __name__ == "__main__":
    main()
