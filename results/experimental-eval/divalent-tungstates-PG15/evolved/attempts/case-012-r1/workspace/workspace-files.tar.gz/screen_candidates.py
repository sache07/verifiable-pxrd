#!/usr/bin/env python3
"""Peak-family screen for chemically plausible Ni-W-O phases."""

from __future__ import annotations

from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import percentile_filter
from scipy.signal import find_peaks


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = {
    "NiWO4_P2c_clean": ROOT / "candidates/niwo4_clean.cif",
    "WO3_P21n_1528915": COD / "1/52/89/1528915.cif",
    "WO3_P-1_2106293": COD / "2/10/62/2106293.cif",
    "WO3_P4ncc_1521532": COD / "1/52/15/1521532.cif",
    "WO3_P4nmm_1521533": COD / "1/52/15/1521533.cif",
    "WO3_Pnma_2107312": COD / "2/10/73/2107312.cif",
    "NiO_Fm3m_1010093": COD / "1/01/00/1010093.cif",
}


def observed_peaks() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    # A wide percentile filter gives a robust local baseline without fitting phases.
    baseline = percentile_filter(y, percentile=20, size=151, mode="nearest")
    signal = y - baseline
    idx, props = find_peaks(signal, prominence=90, distance=6, width=2)
    return x[idx], props["prominences"], y[idx]


def screen(name: str, path: Path, obs_x: np.ndarray, obs_prom: np.ndarray) -> None:
    structure = Structure.from_file(path)
    pattern = XRDCalculator(wavelength="CuKa1").get_pattern(
        structure, two_theta_range=(10, 100), scaled=True
    )
    calc_x = np.asarray(pattern.x)
    calc_i = np.asarray(pattern.y)
    keep = calc_i >= 1.0
    calc_x, calc_i = calc_x[keep], calc_i[keep]
    nearest = np.abs(calc_x[:, None] - obs_x[None, :]).argmin(axis=1)
    delta = obs_x[nearest] - calc_x
    # Weight line-position evidence by sqrt intensity so one dominant line cannot decide.
    weights = np.sqrt(calc_i)
    matched = np.abs(delta) <= 0.22
    coverage = float(weights[matched].sum() / weights.sum())
    strong = calc_i >= 10.0
    strong_coverage = float(weights[strong & matched].sum() / weights[strong].sum())
    coherent = int(np.count_nonzero(strong & matched))
    print(f"\n{name}: {structure.composition.reduced_formula}; {structure.get_space_group_info()}")
    print(
        f"  weighted coverage={coverage:.3f}; strong coverage={strong_coverage:.3f}; "
        f"strong families matched={coherent}/{np.count_nonzero(strong)}"
    )
    order = np.argsort(calc_i)[::-1][:18]
    print("  calc_2theta  rel_I  nearest_obs  delta")
    for i in order:
        print(f"  {calc_x[i]:10.4f} {calc_i[i]:6.1f} {obs_x[nearest[i]]:11.4f} {delta[i]:+7.4f}")


def main() -> None:
    obs_x, obs_prom, _ = observed_peaks()
    print("Observed peaks used:", len(obs_x))
    print("Top observed 2theta:", np.round(obs_x[np.argsort(obs_prom)[-25:]], 4))
    for name, path in CANDIDATES.items():
        screen(name, path, obs_x, obs_prom)


if __name__ == "__main__":
    main()
