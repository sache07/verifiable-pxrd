#!/usr/bin/env python3
"""One-at-a-time common intensity-correction trials on the final inventory."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=["polarization", "roughness"])
args = parser.parse_args()

output = ROOT / ".tmp" / f"trial_{args.mode}.gpx"
project = G2sc.G2Project(
    str(ROOT / ".tmp" / "watch_bawo4_triclinic.gpx"), newgpx=str(output)
)
hist = project.histogram(0)

if args.mode == "polarization":
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
else:
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"][:] = [0.5, True]
    sample["SurfRoughB"][:] = [0.05, True]
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughB")

project.set_Controls("cycles", 15)
project.save()
project.do_refinements([{}])
project.save()
project = G2sc.G2Project(str(output))
project.set_Controls("cycles", 15)
project.do_refinements([{}])
project.save()

hist = project.histogram(0)
inst = hist.data["Instrument Parameters"][0]
sample = hist.data["Sample Parameters"]
print(json.dumps({
    "mode": args.mode,
    "Rwp": hist.residuals.get("wR"),
    "R": hist.residuals.get("R"),
    "polarization": inst["Polariz."][1],
    "roughness_A": sample["SurfRoughA"][0],
    "roughness_B": sample["SurfRoughB"][0],
    "shift_um": sample["Shift"][0],
    "fractions": hist.ComputeMassFracs(),
}))
