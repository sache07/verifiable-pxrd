#!/usr/bin/env python3
"""Replay the accepted WO3/BaO2/BaO/Ba3W2O9 inventory to stability."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / ".tmp" / "final_inventory.gpx"


def state(project, label):
    hist = project.histogram(0)
    print("STATE_JSON " + json.dumps({
        "step": label,
        "Rwp": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "shift_um": hist.data["Sample Parameters"]["Shift"][0],
        "fractions": hist.ComputeMassFracs(),
        "phases": [{
            "name": p.name,
            "cell": p.get_cell(),
            "cell_refine": p.data["General"]["Cell"][0],
            "scale": p.data["Histograms"][hist.name]["Scale"][0],
            "size": p.data["Histograms"][hist.name]["Size"][1],
            "size_refine": p.data["Histograms"][hist.name]["Size"][2],
            "Rf": hist.residuals.get(f"{p.id}:0:Rf"),
        } for p in project.phases()],
        "frozen": [str(v) for v in project.get_Frozen()],
    }))


project = G2sc.G2Project(
    str(ROOT / ".tmp" / "watch_ba3w2o9_1533878.gpx"), newgpx=str(OUTPUT)
)
for index in range(1, 5):
    project.set_Controls("cycles", 25)
    project.do_refinements([{}])
    project.save()
    state(project, f"replay_{index}")
    project = G2sc.G2Project(str(OUTPUT))
