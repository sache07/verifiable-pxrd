#!/usr/bin/env python3
"""Run a restrained, comparable GSAS-II screening refinement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(phase: G2sc.G2Phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1000.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][:] = [0.0, False]
    hap["Scale"][1] = True


def run(project: G2sc.G2Project, label: str) -> None:
    project.do_refinements([{}])
    project.save()
    hist = project.histogram(0)
    print(label, "Rwp", hist.residuals.get("wR"), "R", hist.residuals.get("R"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("width", choices=["none", "size", "strain", "both"])
    parser.add_argument("phases", nargs="+", help="name=COD_ID")
    parser.add_argument("--single", action="store_true", help="Use Cu K-alpha1 only")
    args = parser.parse_args()

    out = ROOT / ".tmp" / f"screen_{args.label}_{args.width}.gpx"
    instrument = ROOT / ".tmp" / ("instrument_single.instprm" if args.single else "instrument.instprm")
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(instrument),
        fmthint="comma",
    )
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 6},
    })
    hist.clear_refinements({"Sample Parameters": ["Scale"]})
    sample = hist.data["Sample Parameters"]
    sample["Scale"][:] = [1.0, False]
    for key in ["Absorption", "DisplaceX", "DisplaceY", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
        if key in sample and isinstance(sample[key], list) and len(sample[key]) > 1:
            sample[key][1] = False

    inst = hist.data["Instrument Parameters"][0]
    for key in ["U", "V", "W", "X", "Y", "Z", "SH/L", "Zero"]:
        if key in inst:
            inst[key][2] = False
    inst["U"][1] = 2.0
    inst["V"][1] = 0.0
    inst["W"][1] = 5.0
    inst["X"][1] = 0.0
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002
    inst["Zero"][1] = 0.0

    phases = []
    for spec in args.phases:
        name, cod_id = spec.split("=", 1)
        phase = project.add_phase(str(cod_cif(cod_id)), phasename=name, histograms=[hist], fmthint="CIF")
        phase.clear_refinements({"Cell": True})
        neutralize(phase, hist.name)
        phases.append(phase)

    project.set_Controls("cycles", 8)
    project.save()
    run(project, "scales_background")

    for phase in phases:
        pid = phase.id
        if args.width in {"size", "both"}:
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][1][0] = 0.15
            hap["Size"][1][2] = 0.5
            project.set_Controls("parmMin", 0.005, variable=f"{pid}:0:Size;i")
            project.set_Controls("parmMax", 1000.0, variable=f"{pid}:0:Size;i")
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True, "LGmix": {"value": 0.5, "refine": False}}})
            run(project, f"size_{phase.name}")
        if args.width in {"strain", "both"}:
            hap = phase.data["Histograms"][hist.name]
            hap["Mustrain"][1][0] = 3000.0
            hap["Mustrain"][1][2] = 0.5
            project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
            project.set_Controls("parmMax", 30000.0, variable=f"{pid}:0:Mustrain;i")
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True, "LGmix": {"value": 0.5, "refine": False}}})
            run(project, f"strain_{phase.name}")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("parmMin", -0.5, variable=":0:Zero")
    project.set_Controls("parmMax", 0.5, variable=":0:Zero")
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 12)
    run(project, "zero_cells")

    # Save, reopen and replay to expose non-reproducible or unconverged models.
    project = G2sc.G2Project(str(out))
    project.set_Controls("cycles", 12)
    run(project, "replay")
    hist = project.histogram(0)
    result = {
        "label": args.label,
        "width": args.width,
        "single": args.single,
        "gpx": str(out),
        "Rwp": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "Rwp_background_subtracted": hist.residuals.get("wRb"),
        "instrument": {key: value[1] for key, value in hist.data["Instrument Parameters"][0].items() if key in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"}},
        "phases": [],
        "frozen": project.get_Frozen(),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"].append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "mass": phase.data["General"]["Mass"],
            "scale": hap["Scale"][0],
            "size": hap["Size"][1],
            "mustrain": hap["Mustrain"][1],
            "Rf": hist.residuals.get(f"{phase.id}:0:Rf"),
        })
    result_path = out.with_suffix(".json")
    result_path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
