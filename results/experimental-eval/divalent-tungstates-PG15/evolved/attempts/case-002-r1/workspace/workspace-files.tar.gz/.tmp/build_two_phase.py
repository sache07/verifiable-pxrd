#!/usr/bin/env python3
"""Build a physically screened two-phase baseline with seeded cells."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def set_cell(phase, cell):
    phase.data["General"]["Cell"][1:7] = list(cell)
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def neutral_hap(phase, hist_name, size=0.04):
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"][:] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [size, size, 0.5]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][:] = [0.0, False]


def report(project, label):
    hist = project.histogram(0)
    print("\n", label, "Rwp", hist.residuals.get("wR"), "R", hist.residuals.get("R"))
    print("instrument", {k: v for k, v in hist.data["Instrument Parameters"][0].items() if k in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"}})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "cell", phase.get_cell(), "scale", hap["Scale"], "size", hap["Size"], "strain", hap["Mustrain"])


def refine(project, label, cycles=10):
    project.set_Controls("cycles", cycles)
    project.do_refinements([{}])
    project.save()
    report(project, label)


def main():
    out = ROOT / ".tmp" / "two_phase_baseline.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / ".tmp" / "instrument.instprm"),
        fmthint="comma",
    )
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 6},
    })
    hist.clear_refinements({"Sample Parameters": ["Scale"]})
    hist.data["Sample Parameters"]["Scale"][:] = [1.0, False]
    for key in ["Absorption", "DisplaceX", "DisplaceY", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
        if key in hist.data["Sample Parameters"]:
            hist.data["Sample Parameters"][key][1] = False
    inst = hist.data["Instrument Parameters"][0]
    for key in ["U", "V", "W", "X", "Y", "Z", "SH/L", "Zero"]:
        inst[key][2] = False
    for key, value in {"U": 2.0, "V": 0.0, "W": 5.0, "X": 0.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002, "Zero": 0.0}.items():
        inst[key][1] = value

    wo3 = project.add_phase(
        phasefile=None,
        phasename="WO3_monoclinic",
        histograms=[hist],
        spacegroup="P 21/n",
        cell=[7.29733787, 7.539, 7.688, 90.0, 90.91472727, 90.0],
    )
    # Asymmetric-unit coordinates from neutron structure COD 2311041 after
    # a unimodular transformation into the conventional P21/n cell.
    for label, element, xyz in [
        ("W1", "W", [0.254, 0.037, 0.282]),
        ("W2", "W", [0.250, 0.023, 0.784]),
        ("O1", "O", [0.279, 0.487, 0.993]),
        ("O2", "O", [0.993, 0.474, 0.218]),
        ("O3", "O", [0.292, 0.043, 0.008]),
        ("O4", "O", [0.288, 0.262, 0.286]),
        ("O5", "O", [0.005, 0.042, 0.211]),
        ("O6", "O", [0.211, 0.259, 0.730]),
    ]:
        wo3.add_atom(*xyz, element, label, occ=1.0, uiso=0.01)
    bao2 = project.add_phase(
        str(cod_cif("1010113")),
        phasename="BaO2_tetragonal",
        histograms=[hist],
        fmthint="CIF",
    )
    set_cell(wo3, [7.219, 7.434, 7.588, 90.0, 90.915, 90.0])
    neutral_hap(wo3, hist.name, 0.04)
    neutral_hap(bao2, hist.name, 0.04)
    wo3.clear_refinements({"Cell": True})
    bao2.clear_refinements({"Cell": True})
    project.save()

    refine(project, "scales_background", 8)

    # The seeded WO3 cell places the three diagnostic axial reflections on
    # their observed peaks. Refine cells before permitting any extra width.
    wo3.set_refinements({"Cell": True})
    refine(project, "WO3_cell", 12)
    wo3.clear_refinements({"Cell": True})
    bao2.set_refinements({"Cell": True})
    refine(project, "BaO2_cell", 12)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("parmMin", -0.3, variable=":0:Zero")
    project.set_Controls("parmMax", 0.3, variable=":0:Zero")
    wo3.set_refinements({"Cell": True})
    refine(project, "common_zero_cells", 12)

    # Save/reopen/replay the baseline before width comparisons.
    project = G2sc.G2Project(str(out))
    refine(project, "replay", 12)


if __name__ == "__main__":
    main()
