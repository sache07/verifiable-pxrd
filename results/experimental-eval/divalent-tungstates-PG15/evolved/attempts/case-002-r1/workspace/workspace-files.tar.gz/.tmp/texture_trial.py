#!/usr/bin/env python3
"""Run one replayed March-Dollase axis trial from the common baseline."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("phase", choices=["wo3", "bao2", "bawo4"])
parser.add_argument("axis", help="three comma-separated Miller indices")
parser.add_argument("--baseline", default=".tmp/watch_bawo4_triclinic.gpx")
args = parser.parse_args()
axis = [int(i) for i in args.axis.split(",")]
if len(axis) != 3:
    raise SystemExit("axis must contain three indices")

phase_index = {"wo3": 0, "bao2": 1, "bawo4": 2}[args.phase]
axis_tag = "".join(str(i).replace("-", "m") for i in axis)
baseline = ROOT / args.baseline
suffix = "_final" if baseline.name == "final_inventory.gpx" else ""
output = ROOT / ".tmp" / f"texture_{args.phase}_{axis_tag}{suffix}.gpx"
project = G2sc.G2Project(
    str(baseline), newgpx=str(output)
)
hist = project.histogram(0)
phase = project.phase(phase_index)
po = phase.data["Histograms"][hist.name]["Pref.Ori."]
po[0] = "MD"
po[1] = 0.90
po[2] = True
po[3] = axis
project.set_Controls("parmMin", 0.5, variable=f"{phase.id}:0:MD")
project.set_Controls("parmMax", 2.0, variable=f"{phase.id}:0:MD")
project.set_Controls("cycles", 15)
project.save()
project.do_refinements([{}])
project.save()
project = G2sc.G2Project(str(output))
project.set_Controls("cycles", 15)
project.do_refinements([{}])
project.save()

hist = project.histogram(0)
phase = project.phase(phase_index)
po = phase.data["Histograms"][hist.name]["Pref.Ori."]
cov = project.data["Covariance"]["data"]
varname = f"{phase.id}:0:MD"
sigma = None
if varname in cov.get("varyList", []):
    sigma = float(cov["sig"][cov["varyList"].index(varname)])
print("TRIAL_JSON " + json.dumps({
    "phase": phase.name,
    "axis": axis,
    "MD": po[1],
    "sigma": sigma,
    "Rwp": hist.residuals.get("wR"),
    "R": hist.residuals.get("R"),
    "fractions": hist.ComputeMassFracs(),
    "project": str(output),
}))
