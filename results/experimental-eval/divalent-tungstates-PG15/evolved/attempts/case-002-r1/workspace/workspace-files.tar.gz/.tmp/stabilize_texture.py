#!/usr/bin/env python3
"""Replay the accepted WO3 [101] texture model before final export."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / ".tmp" / "final_model_candidate.gpx"


def state(project, label):
    hist = project.histogram(0)
    wo3 = project.phase("WO3_triclinic")
    print("STATE_JSON " + json.dumps({
        "step": label,
        "Rwp": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "shift_um": hist.data["Sample Parameters"]["Shift"][0],
        "WO3_preferred_orientation": wo3.data["Histograms"][hist.name]["Pref.Ori."],
        "fractions": hist.ComputeMassFracs(),
        "phases": [{
            "name": p.name,
            "cell": p.get_cell(),
            "scale": p.data["Histograms"][hist.name]["Scale"][0],
            "size": p.data["Histograms"][hist.name]["Size"][1],
            "Rf": hist.residuals.get(f"{p.id}:0:Rf"),
        } for p in project.phases()],
        "frozen": [str(v) for v in project.get_Frozen()],
    }))


project = G2sc.G2Project(
    str(ROOT / ".tmp" / "texture_wo3_101_final.gpx"), newgpx=str(OUTPUT)
)
for index in range(1, 5):
    project.set_Controls("cycles", 25)
    project.do_refinements([{}])
    project.save()
    state(project, f"replay_{index}")
    project = G2sc.G2Project(str(OUTPUT))
