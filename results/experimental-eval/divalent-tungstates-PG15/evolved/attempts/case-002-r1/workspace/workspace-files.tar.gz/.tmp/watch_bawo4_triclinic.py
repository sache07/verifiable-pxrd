#!/usr/bin/env python3
"""Challenge the ordered scheelite BaWO4 prototype on the triclinic baseline."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("parent", nargs="?", choices=["bamo", "euwo"], default="bamo")
args = parser.parse_args()
OUTPUT = ROOT / ".tmp" / f"watch_bawo4_triclinic_{args.parent}.gpx"


def state(project, label):
    hist = project.histogram(0)
    rows, total = [], 0.0
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw = hap["Scale"][0] * phase.data["General"]["Mass"]
        total += raw
        rows.append({
            "name": phase.name,
            "raw_mass": raw,
            "scale": hap["Scale"][0],
            "cell": phase.get_cell(),
            "Rf": hist.residuals.get(f"{phase.id}:0:Rf"),
        })
    for row in rows:
        row["weight_fraction"] = row["raw_mass"] / total
    print(json.dumps({
        "step": label,
        "Rwp": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "shift_um": hist.data["Sample Parameters"]["Shift"][0],
        "phases": rows,
    }))


def run(project, label, cycles):
    project.set_Controls("cycles", cycles)
    project.do_refinements([{}])
    project.save()
    state(project, label)


project = G2sc.G2Project(
    str(ROOT / ".tmp" / "alternate_wo3_triclinic.gpx"), newgpx=str(OUTPUT)
)
hist = project.histogram(0)
bawo4 = project.add_phase(
    str(ROOT / ".tmp" / (
        "BaWO4_BaMoO4_prototype.cif" if args.parent == "bamo"
        else "BaWO4_EuWO4_prototype.cif"
    )),
    phasename="BaWO4_scheelite",
    histograms=[hist],
    fmthint="CIF",
)
hap = bawo4.data["Histograms"][hist.name]
hap["Scale"][:] = [0.10, True]
hap["Size"][0] = "isotropic"
hap["Size"][1][:] = [0.04, 0.04, 0.5]
hap["Size"][2][:] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
hap["Mustrain"][2][:] = [False, False, False]
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = False
bawo4.clear_refinements({"Cell": True})
project.save()
run(project, "scale", 12)
bawo4.set_refinements({"Cell": True})
run(project, "cell", 15)
project = G2sc.G2Project(str(OUTPUT))
run(project, "replay", 18)
