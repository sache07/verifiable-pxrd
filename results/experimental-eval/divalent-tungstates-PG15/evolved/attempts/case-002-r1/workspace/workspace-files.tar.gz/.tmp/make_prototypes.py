#!/usr/bin/env python3
"""Create physically screened cross-chemistry prototypes for GSAS-II trials."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


source = Structure.from_file(cod_cif("2300459"))  # ordered I41/a BaMoO4 at 298 K
source.replace_species({"Mo": "W"})
target = Structure(
    Lattice.tetragonal(5.614, 12.719),
    source.species,
    source.frac_coords,
    site_properties=source.site_properties,
)
CifWriter(target, symprec=1e-3).write_file(ROOT / ".tmp" / "BaWO4_BaMoO4_prototype.cif")

# A second, chemically complementary parent retains the WO4 tetrahedron from
# a high-quality room-temperature EuWO4 single-crystal refinement. Replacing
# Eu2+ by Ba2+ is isovalent; imposing the BaWO4 cell gives W-O = 1.857 A and
# Ba-O = 2.716-2.718 A, avoiding the split/short contacts in COD 1527204.
source = Structure.from_file(cod_cif("1561850"))
source.replace_species({"Eu": "Ba"})
target = Structure(
    Lattice.tetragonal(5.614, 12.719),
    source.species,
    source.frac_coords,
    site_properties=source.site_properties,
)
CifWriter(target, symprec=1e-3).write_file(ROOT / ".tmp" / "BaWO4_EuWO4_prototype.cif")

# Normalize the legacy P-b-m-m symmetry operators for the partially occupied
# Ba0.15WO3 bronze so GSAS-II can test the record without changing its sites.
bronze = Structure.from_file(cod_cif("1001273"))
CifWriter(bronze, symprec=1e-3).write_file(ROOT / ".tmp" / "Ba0p15WO3_sanitized.cif")

# Put the physically sound neutron WO3 model into the conventional near-90-degree
# monoclinic setting used by the room-temperature powder indexing.
wo3 = Structure.from_file(cod_cif("2311041"))
wo3.make_supercell([[-1, 0, -1], [0, 1, 0], [1, 0, 0]])
analyzer = SpacegroupAnalyzer(wo3, symprec=1e-3, angle_tolerance=1.0)
symmetrized = analyzer.get_symmetrized_structure()
a, b, c = wo3.lattice.abc
alpha, beta, gamma = wo3.lattice.angles
lines = [
    "data_WO3_neutron_conventional",
    "_chemical_formula_sum 'W2 O6'",
    "_symmetry_space_group_name_Hall '-P 2yn'",
    "_symmetry_space_group_name_H-M 'P 1 21/n 1'",
    "_symmetry_Int_Tables_number 14",
    f"_cell_length_a {a:.8f}",
    f"_cell_length_b {b:.8f}",
    f"_cell_length_c {c:.8f}",
    f"_cell_angle_alpha {alpha:.8f}",
    f"_cell_angle_beta {beta:.8f}",
    f"_cell_angle_gamma {gamma:.8f}",
    "loop_",
    "_symmetry_equiv_pos_as_xyz",
]
for operation in [
    "x,y,z",
    "-x+1/2,y+1/2,-z+1/2",
    "-x,-y,-z",
    "x-1/2,-y-1/2,z-1/2",
]:
    lines.append(f"'{operation}'")
lines.extend([
    "loop_",
    "_atom_site_label",
    "_atom_site_type_symbol",
    "_atom_site_fract_x",
    "_atom_site_fract_y",
    "_atom_site_fract_z",
    "_atom_site_occupancy",
    "_atom_site_U_iso_or_equiv",
])
counts = {"W": 0, "O": 0}
for sites in symmetrized.equivalent_sites:
    site = sites[0]
    symbol = site.species_string
    counts[symbol] += 1
    x, y, z = site.frac_coords
    lines.append(f"{symbol}{counts[symbol]} {symbol} {x:.8f} {y:.8f} {z:.8f} 1.0 0.01")
(ROOT / ".tmp" / "WO3_neutron_conventional.cif").write_text("\n".join(lines) + "\n")
