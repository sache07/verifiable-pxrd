#!/usr/bin/env python3
"""Compare physically plausible WO3 polymorph records under one nuisance model."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutral(phase, hist_name):
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"][:] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [0.04, 0.04, 0.5]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False


def report(project, label):
    hist = project.histogram(0)
    print(json.dumps({
        "step": label,
        "Rwp": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "shift": hist.data["Sample Parameters"]["Shift"][0],
        "phases": [{"name": p.name, "cell": p.get_cell(), "scale": p.data["Histograms"][hist.name]["Scale"][0], "Rf": hist.residuals.get(f"{p.id}:0:Rf")} for p in project.phases()],
    }))


def run(project, label, cycles=12):
    project.set_Controls("cycles", cycles)
    project.do_refinements([{}])
    project.save()
    report(project, label)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("record", choices=["triclinic", "orthorhombic"])
    args = parser.parse_args()
    cod_id = {"triclinic": "2106293", "orthorhombic": "2107312"}[args.record]
    output = ROOT / ".tmp" / f"alternate_wo3_{args.record}.gpx"
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(str(ROOT / "inputs" / "pattern.csv"), str(ROOT / ".tmp" / "instrument.instprm"), fmthint="comma")
    hist.set_refinements({"Limits": [10.0, 100.0], "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 6}})
    hist.clear_refinements({"Sample Parameters": ["Scale"]})
    hist.data["Sample Parameters"]["Scale"][:] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"][:] = [-500.0, True]
    for key in ["Absorption", "DisplaceX", "DisplaceY", "Transparency", "SurfRoughA", "SurfRoughB"]:
        hist.data["Sample Parameters"][key][1] = False
    inst = hist.data["Instrument Parameters"][0]
    for key in ["U", "V", "W", "X", "Y", "Z", "SH/L", "Zero"]:
        inst[key][2] = False
    for key, value in {"U": 2.0, "V": 0.0, "W": 5.0, "X": 0.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002, "Zero": 0.0}.items():
        inst[key][1] = value
    wo3 = project.add_phase(str(cif(cod_id)), phasename=f"WO3_{args.record}", histograms=[hist], fmthint="CIF")
    bao2 = project.add_phase(str(cif("1010113")), phasename="BaO2_tetragonal", histograms=[hist], fmthint="CIF")
    project.set_Controls("parmMin", -1500.0, variable=":0:Shift")
    project.set_Controls("parmMax", 1500.0, variable=":0:Shift")
    neutral(wo3, hist.name)
    neutral(bao2, hist.name)
    wo3.clear_refinements({"Cell": True})
    bao2.clear_refinements({"Cell": True})
    project.save()
    run(project, "scale", 10)
    wo3.set_refinements({"Cell": True})
    bao2.set_refinements({"Cell": True})
    run(project, "cells", 15)
    project = G2sc.G2Project(str(output))
    run(project, "replay", 15)


if __name__ == "__main__":
    main()
