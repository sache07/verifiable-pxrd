#!/usr/bin/env python3
"""Build and probe an initial GSAS-II model for the supplied PXRD pattern."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summary(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"\n--- {label} ---")
    print("residuals", json.dumps(hist.residuals, default=float, sort_keys=True))
    print("instrument")
    for key, value in hist.get("Instrument Parameters")[0].items():
        if key in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}:
            print(key, value)
    print("background", hist.get("Background")[0])
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            phase.name,
            "cell", phase.get_cell(),
            "scale", hap["Scale"],
            "size", hap["Size"],
            "mustrain", hap["Mustrain"],
            "prefori", hap["Pref.Ori."],
        )


def main() -> None:
    out = ROOT / ".tmp" / "probe.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / ".tmp" / "instrument.instprm"),
        fmthint="comma",
    )
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 6,
        },
    })
    phases = [
        project.add_phase(str(cif("1528915")), phasename="WO3_monoclinic", histograms=[hist], fmthint="CIF"),
        project.add_phase(str(cif("1010113")), phasename="BaO2_tetragonal", histograms=[hist], fmthint="CIF"),
        project.add_phase(str(cif("1527204")), phasename="BaWO4_scheelite", histograms=[hist], fmthint="CIF"),
    ]
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    project.set_Controls("cycles", 8)
    project.save()
    summary(project, "initial")

    project.do_refinements([{}])
    summary(project, "background and scales")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.do_refinements([{}])
    summary(project, "zero and cells")
    project.save()


if __name__ == "__main__":
    main()
