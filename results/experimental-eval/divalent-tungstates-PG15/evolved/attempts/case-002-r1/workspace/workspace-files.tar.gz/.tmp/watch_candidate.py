#!/usr/bin/env python3
"""Scale-only watch-list challenge under the established common model."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


parser = argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("cod_id")
parser.add_argument("--baseline", default=".tmp/watch_bawo4_triclinic.gpx")
parser.add_argument("--size", type=float, default=0.04)
args = parser.parse_args()
tag = "".join(c.lower() if c.isalnum() else "_" for c in args.name)
baseline = ROOT / args.baseline
suffix = "_final" if baseline.name == "final_candidate.gpx" else ""
output = ROOT / ".tmp" / f"watch_{tag}_{args.cod_id}{suffix}.gpx"
project = G2sc.G2Project(
    str(baseline), newgpx=str(output)
)
hist = project.histogram(0)
phase = project.add_phase(
    str(
        ROOT / ".tmp" / "Ba0p15WO3_sanitized.cif"
        if args.cod_id == "1001273" else cod_cif(args.cod_id)
    ),
    phasename=args.name,
    histograms=[hist],
    fmthint="CIF",
)
hap = phase.data["Histograms"][hist.name]
hap["Scale"][:] = [0.01, True]
hap["Size"][0] = "isotropic"
hap["Size"][1][:] = [args.size, args.size, 0.5]
hap["Size"][2][:] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
hap["Mustrain"][2][:] = [False, False, False]
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = False
phase.clear_refinements({"Cell": True})
project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
project.set_Controls("cycles", 15)
project.save()
project.do_refinements([{}])
project.save()
project = G2sc.G2Project(str(output))
project.set_Controls("cycles", 15)
project.do_refinements([{}])
project.save()

hist = project.histogram(0)
phase = project.phase(args.name)
hap = phase.data["Histograms"][hist.name]
print("WATCH_JSON " + json.dumps({
    "name": args.name,
    "cod_id": args.cod_id,
    "Rwp": hist.residuals.get("wR"),
    "R": hist.residuals.get("R"),
    "scale": hap["Scale"][0],
    "Rf": hist.residuals.get(f"{phase.id}:0:Rf"),
    "cell": phase.get_cell(),
    "fractions": hist.ComputeMassFracs(),
    "frozen": [str(v) for v in project.get_Frozen()],
    "project": str(output),
}))
