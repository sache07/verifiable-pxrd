#!/usr/bin/env python3
"""Build the clean WO3 + BaO2 + BaO model with accepted major-phase sizes."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BAO_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/01/13/1011362.cif"
)
OUTPUT = ROOT / ".tmp" / "three_phase_profile.gpx"


def state(project, label):
    hist = project.histogram(0)
    print("STATE_JSON " + json.dumps({
        "step": label,
        "Rwp": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "shift_um": hist.data["Sample Parameters"]["Shift"][0],
        "fractions": hist.ComputeMassFracs(),
        "phases": [{
            "name": p.name,
            "cell": p.get_cell(),
            "scale": p.data["Histograms"][hist.name]["Scale"][0],
            "size": p.data["Histograms"][hist.name]["Size"][1],
            "Rf": hist.residuals.get(f"{p.id}:0:Rf"),
        } for p in project.phases()],
        "frozen": [str(v) for v in project.get_Frozen()],
    }))


def run(project, label):
    project.set_Controls("cycles", 25)
    project.do_refinements([{}])
    project.save()
    state(project, label)


project = G2sc.G2Project(
    str(ROOT / ".tmp" / "alternate_wo3_triclinic.gpx"), newgpx=str(OUTPUT)
)
hist = project.histogram(0)
wo3 = project.phase("WO3_triclinic")
bao2 = project.phase("BaO2_tetragonal")
for phase, start in [(wo3, 0.02354), (bao2, 0.01932)]:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [start, 0.023, 0.5]
    hap["Size"][2][:] = [True, False, False]
    hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
    hap["Mustrain"][2][:] = [False, False, False]
    project.set_Controls("parmMin", 0.015, variable=f"{phase.id}:0:Size;i")
    project.set_Controls("parmMax", 0.10, variable=f"{phase.id}:0:Size;i")

bao = project.add_phase(
    str(BAO_CIF), phasename="BaO_rocksalt", histograms=[hist], fmthint="CIF"
)
hap = bao.data["Histograms"][hist.name]
hap["Scale"][:] = [0.2, True]
hap["Size"][0] = "isotropic"
hap["Size"][1][:] = [0.023, 0.023, 0.5]
hap["Size"][2][:] = [False, False, False]
hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
hap["Mustrain"][2][:] = [False, False, False]
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = False
bao.clear_refinements({"Cell": True})
project.set_Controls("parmMin", 0.0, variable=f"{bao.id}:0:Scale")
project.save()
run(project, "combined_sizes")

for index in range(1, 4):
    project = G2sc.G2Project(str(OUTPUT))
    run(project, f"replay_{index}")
