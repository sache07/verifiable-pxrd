#!/usr/bin/env python3
"""Independent major-phase size or strain trial from the common-width model."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("phase", choices=["wo3", "bao2"])
parser.add_argument("mode", choices=["size", "strain"])
args = parser.parse_args()
phase_index = {"wo3": 0, "bao2": 1}[args.phase]
output = ROOT / ".tmp" / f"phase_width_{args.phase}_{args.mode}.gpx"
project = G2sc.G2Project(
    str(ROOT / ".tmp" / "common_size_0p023.gpx"), newgpx=str(output)
)
hist = project.histogram(0)
phase = project.phase(phase_index)
hap = phase.data["Histograms"][hist.name]
if args.mode == "size":
    hap["Size"][1][0] = 0.023
    project.set_Controls("parmMin", 0.015, variable=f"{phase.id}:0:Size;i")
    project.set_Controls("parmMax", 0.10, variable=f"{phase.id}:0:Size;i")
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True,
                 "LGmix": {"value": 0.5, "refine": False}}
    })
else:
    hap["Mustrain"][1][0] = 100.0
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
    project.set_Controls("parmMax", 5000.0, variable=f"{phase.id}:0:Mustrain;i")
    phase.set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True,
                     "LGmix": {"value": 0.5, "refine": False}}
    })
project.set_Controls("cycles", 25)
project.save()
project.do_refinements([{}])
project.save()
project = G2sc.G2Project(str(output))
project.do_refinements([{}])
project.save()

hist = project.histogram(0)
phase = project.phase(phase_index)
hap = phase.data["Histograms"][hist.name]
print("WIDTH_JSON " + json.dumps({
    "phase": phase.name,
    "mode": args.mode,
    "Rwp": hist.residuals.get("wR"),
    "R": hist.residuals.get("R"),
    "size": hap["Size"][1],
    "strain": hap["Mustrain"][1],
    "frozen": [str(v) for v in project.get_Frozen()],
    "fractions": hist.ComputeMassFracs(),
    "project": str(output),
}))
