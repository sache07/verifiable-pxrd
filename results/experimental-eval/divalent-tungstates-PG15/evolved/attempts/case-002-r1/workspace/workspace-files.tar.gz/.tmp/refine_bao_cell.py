#!/usr/bin/env python3
"""Refine and replay the rocksalt BaO cell after its scale-only challenge."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
output = ROOT / ".tmp" / "inventory_four_phase.gpx"
project = G2sc.G2Project(
    str(ROOT / ".tmp" / "watch_bao_rocksalt_1011362.gpx"), newgpx=str(output)
)
bao = project.phase("BaO_rocksalt")
bao.set_refinements({"Cell": True})
project.set_Controls("cycles", 18)
project.save()
project.do_refinements([{}])
project.save()
project = G2sc.G2Project(str(output))
project.set_Controls("cycles", 18)
project.do_refinements([{}])
project.save()

hist = project.histogram(0)
print(json.dumps({
    "Rwp": hist.residuals.get("wR"),
    "R": hist.residuals.get("R"),
    "shift_um": hist.data["Sample Parameters"]["Shift"][0],
    "fractions": hist.ComputeMassFracs(),
    "phases": [{
        "name": p.name,
        "cell": p.get_cell(),
        "scale": p.data["Histograms"][hist.name]["Scale"][0],
        "Rf": hist.residuals.get(f"{p.id}:0:Rf"),
    } for p in project.phases()],
    "frozen": [str(v) for v in project.get_Frozen()],
}))
