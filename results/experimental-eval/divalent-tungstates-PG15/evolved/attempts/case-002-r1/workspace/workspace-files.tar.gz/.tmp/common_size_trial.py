#!/usr/bin/env python3
"""Replay a fixed common isotropic-size value on the stable inventory."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("size_um", type=float)
args = parser.parse_args()
tag = str(args.size_um).replace(".", "p")
output = ROOT / ".tmp" / f"common_size_{tag}.gpx"
project = G2sc.G2Project(
    str(ROOT / ".tmp" / "final_candidate.gpx"), newgpx=str(output)
)
hist = project.histogram(0)
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [args.size_um, args.size_um, 0.5]
    hap["Size"][2][:] = [False, False, False]
project.set_Controls("cycles", 20)
project.save()
project.do_refinements([{}])
project.save()
project = G2sc.G2Project(str(output))
project.do_refinements([{}])
project.save()
hist = project.histogram(0)
print("SIZE_JSON " + json.dumps({
    "size_um": args.size_um,
    "Rwp": hist.residuals.get("wR"),
    "R": hist.residuals.get("R"),
    "fractions": hist.ComputeMassFracs(),
}))
