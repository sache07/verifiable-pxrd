#!/usr/bin/env python3
"""Final replay and exact project-derived CIF/profile/JSON exports."""

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
FINAL = ROOT / "final.gpx"

phase_specs = {
    "WO3_triclinic": {
        "display_name": "Tungsten trioxide (triclinic)",
        "formula": "WO3",
        "cif_path": "phase_1_WO3_triclinic.cif",
        "confidence": "high",
        "estimated_absolute_systematic_uncertainty": 0.02,
        "structure_source": "COD 2106293 (room-temperature triclinic WO3)",
    },
    "BaO2_tetragonal": {
        "display_name": "Barium peroxide (tetragonal)",
        "formula": "BaO2",
        "cif_path": "phase_2_BaO2_tetragonal.cif",
        "confidence": "high",
        "estimated_absolute_systematic_uncertainty": 0.02,
        "structure_source": "COD 1010113",
    },
    "BaO_rocksalt": {
        "display_name": "Barium oxide (rocksalt)",
        "formula": "BaO",
        "cif_path": "phase_3_BaO_rocksalt.cif",
        "confidence": "moderate",
        "estimated_absolute_systematic_uncertainty": 0.005,
        "structure_source": "COD 1011362; source cell held fixed",
    },
    "Ba3W2O9": {
        "display_name": "Barium tungstate oxide (rhombohedral)",
        "formula": "Ba3W2O9",
        "cif_path": "phase_4_Ba3W2O9_rhombohedral.cif",
        "confidence": "low (tentative trace phase)",
        "estimated_absolute_systematic_uncertainty": 0.003,
        "structure_source": "COD 1533878; source cell held fixed",
    },
}

# Save under the requested name, reopen it, replay once, and save. All exports
# below are then made from another reopening of this exact project file.
project = G2sc.G2Project(
    str(ROOT / ".tmp" / "final_model_candidate.gpx"), newgpx=str(FINAL)
)
project.save()
project = G2sc.G2Project(str(FINAL))
project.set_Controls("cycles", 25)
project.do_refinements([{}])
project.save()
project = G2sc.G2Project(str(FINAL))
hist = project.histogram(0)

fractions = hist.ComputeMassFracs()
for phase in project.phases():
    spec = phase_specs[phase.name]
    phase.export_CIF(str(ROOT / spec["cif_path"]))

x, observed, weight, calculated, background, difference = hist.data["data"][1][:6]
low, high = hist.data["Limits"][1]
# GSAS-II uses the first point at/above each limit and includes the high-limit
# index, so reproduce its exact 8284-point slice (the final point is 100.00795°).
first = int(np.searchsorted(x, low))
last = int(np.searchsorted(x, high)) + 1
mask = np.zeros_like(x, dtype=bool)
mask[first:last] = True
with (ROOT / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow([
        "two_theta_deg", "observed_counts", "calculated_counts",
        "background_counts", "difference_counts", "weight_inv_counts",
    ])
    for values in zip(
        x[mask], observed[mask], calculated[mask], background[mask],
        difference[mask], weight[mask],
    ):
        writer.writerow([f"{float(v):.10g}" for v in values])

cov = project.data["Covariance"]["data"]
rvals = cov["Rvals"]
vary_to_sig = {str(v): float(s) for v, s in zip(cov["varyList"], cov["sig"])}
weighted_residual = difference[mask] * np.sqrt(weight[mask])
durbin_watson = float(
    np.sum(np.diff(weighted_residual) ** 2) / np.sum(weighted_residual ** 2)
)

phases_json = []
for phase in project.phases():
    spec = phase_specs[phase.name]
    cell, cell_esd = phase.get_cell_and_esd()
    hap = phase.data["Histograms"][hist.name]
    fraction, fraction_esd = fractions[phase.name]
    row = {
        "name": spec["display_name"],
        "project_phase_name": phase.name,
        "formula": spec["formula"],
        "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
        "cif_path": spec["cif_path"],
        "weight_fraction": float(fraction),
        "weight_fraction_formal_esd": float(fraction_esd),
        "estimated_absolute_systematic_uncertainty": spec[
            "estimated_absolute_systematic_uncertainty"
        ],
        "confidence": spec["confidence"],
        "structure_source": spec["structure_source"],
        "cell": {key: float(value) for key, value in cell.items()},
        "cell_formal_esd": {key: float(value) for key, value in cell_esd.items()},
        "cell_refined": bool(phase.data["General"]["Cell"][0]),
        "R_F_percent": float(hist.residuals.get(f"{phase.id}:0:Rf")),
        "profile": {
            "isotropic_size_um": float(hap["Size"][1][0]),
            "isotropic_size_refined": bool(hap["Size"][2][0]),
            "isotropic_microstrain": float(hap["Mustrain"][1][0]),
        },
    }
    size_key = f"{phase.id}:0:Size;i"
    if size_key in vary_to_sig:
        row["profile"]["isotropic_size_formal_esd_um"] = vary_to_sig[size_key]
    phases_json.append(row)

result = {
    "phases": phases_json,
    "weight_fraction_normalization": (
        "Fractions sum to one over the modeled crystalline phases only; "
        "no amorphous fraction was determined."
    ),
    "fit_statistics": {
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "R_background_percent": float(hist.residuals["Rb"]),
        "weighted_R_background_percent": float(hist.residuals["wRb"]),
        "Rwp_minimum_percent": float(hist.residuals["wRmin"]),
        "chi_square": float(rvals["chisq"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_variables": int(rvals["Nvars"]),
        "durbin_watson_weighted_residual": durbin_watson,
        "converged": bool(rvals["converged"]),
        "max_shift_over_esd": float(rvals["Max shft/sig"]),
    },
    "measurement_and_refinement": {
        "radiation": "Cu K-alpha1/K-alpha2",
        "wavelength_Kalpha1_angstrom": 1.540598,
        "wavelength_Kalpha2_angstrom": 1.544426,
        "Kalpha2_to_Kalpha1_ratio": 0.5,
        "refined_two_theta_range_deg": [float(low), float(high)],
        "weighting": "1 / observed counts (counting-statistical assumption)",
        "angular_correction": {
            "type": "specimen displacement",
            "shift_micrometers": float(hist.data["Sample Parameters"]["Shift"][0]),
        },
        "background": "six-term Chebyshev-1",
        "preferred_orientation": {
            "phase": "WO3_triclinic",
            "model": "March-Dollase",
            "axis": [1, 0, 1],
            "ratio": float(
                project.phase("WO3_triclinic").data["Histograms"][hist.name][
                    "Pref.Ori."
                ][1]
            ),
        },
    },
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

print(json.dumps({
    "Rwp": result["fit_statistics"]["Rwp_percent"],
    "GOF": result["fit_statistics"]["goodness_of_fit"],
    "DW": durbin_watson,
    "fractions": {row["formula"]: row["weight_fraction"] for row in phases_json},
    "formal_esd": {
        row["formula"]: row["weight_fraction_formal_esd"] for row in phases_json
    },
    "max_shift_over_esd": result["fit_statistics"]["max_shift_over_esd"],
}, indent=2))
