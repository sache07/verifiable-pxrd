#!/usr/bin/env python3
"""Challenge BaWO4 records against the established two-phase baseline."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD_EXACT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/72/1527204.cif")


def state(project, label):
    hist = project.histogram(0)
    row = {"step": label, "Rwp": hist.residuals.get("wR"), "R": hist.residuals.get("R"), "phases": []}
    total = 0.0
    for phase in project.phases():
        scale = phase.data["Histograms"][hist.name]["Scale"][0]
        raw = scale * phase.data["General"]["Mass"]
        total += raw
        row["phases"].append({"name": phase.name, "scale": scale, "raw_mass": raw, "cell": phase.get_cell()})
    for phase in row["phases"]:
        phase["weight_fraction"] = phase["raw_mass"] / total
    print(json.dumps(row))


def run(project, label, cycles=12):
    project.set_Controls("cycles", cycles)
    project.do_refinements([{}])
    project.save()
    state(project, label)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("record", choices=["prototype", "exact"])
    args = parser.parse_args()
    output = ROOT / ".tmp" / f"watch_bawo4_{args.record}.gpx"
    project = G2sc.G2Project(str(ROOT / ".tmp" / "shift_trial.gpx"), newgpx=str(output))
    hist = project.histogram(0)
    phasefile = ROOT / ".tmp" / "BaWO4_BaMoO4_prototype.cif" if args.record == "prototype" else COD_EXACT
    bawo4 = project.add_phase(str(phasefile), phasename="BaWO4_scheelite", histograms=[hist], fmthint="CIF")
    hap = bawo4.data["Histograms"][hist.name]
    hap["Scale"][:] = [0.1, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [0.04, 0.04, 0.5]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    bawo4.clear_refinements({"Cell": True})
    project.save()
    run(project, "scale", 12)
    bawo4.set_refinements({"Cell": True})
    run(project, "cell", 15)
    project = G2sc.G2Project(str(output))
    run(project, "replay", 15)


if __name__ == "__main__":
    main()
