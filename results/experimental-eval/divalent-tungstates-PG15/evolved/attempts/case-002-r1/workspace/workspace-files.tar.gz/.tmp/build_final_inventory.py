#!/usr/bin/env python3
"""Add rocksalt BaO to the physical EuWO4-derived inventory and replay it."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BAO_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/01/13/1011362.cif"
)
OUTPUT = ROOT / ".tmp" / "inventory_four_phase_euwo.gpx"


def state(project, label):
    hist = project.histogram(0)
    print("STATE_JSON " + json.dumps({
        "step": label,
        "Rwp": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "shift_um": hist.data["Sample Parameters"]["Shift"][0],
        "fractions": hist.ComputeMassFracs(),
        "phases": [{
            "name": p.name,
            "cell": p.get_cell(),
            "scale": p.data["Histograms"][hist.name]["Scale"][0],
            "Rf": hist.residuals.get(f"{p.id}:0:Rf"),
        } for p in project.phases()],
        "frozen": [str(v) for v in project.get_Frozen()],
    }))


def run(project, label, cycles=18):
    project.set_Controls("cycles", cycles)
    project.do_refinements([{}])
    project.save()
    state(project, label)


project = G2sc.G2Project(
    str(ROOT / ".tmp" / "watch_bawo4_triclinic_euwo.gpx"),
    newgpx=str(OUTPUT),
)
hist = project.histogram(0)
bao = project.add_phase(
    str(BAO_CIF), phasename="BaO_rocksalt", histograms=[hist], fmthint="CIF"
)
hap = bao.data["Histograms"][hist.name]
hap["Scale"][:] = [0.01, True]
hap["Size"][0] = "isotropic"
hap["Size"][1][:] = [0.04, 0.04, 0.5]
hap["Size"][2][:] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
hap["Mustrain"][2][:] = [False, False, False]
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = False
bao.clear_refinements({"Cell": True})
project.set_Controls("parmMin", 0.0, variable=f"{bao.id}:0:Scale")
project.save()
run(project, "BaO_scale")

bao.set_refinements({"Cell": True})
run(project, "BaO_cell")

project = G2sc.G2Project(str(OUTPUT))
run(project, "replay_1", 20)
project = G2sc.G2Project(str(OUTPUT))
run(project, "replay_2", 20)
