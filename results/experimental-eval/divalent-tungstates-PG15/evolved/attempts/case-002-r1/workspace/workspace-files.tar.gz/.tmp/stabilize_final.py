#!/usr/bin/env python3
"""Prune unstable minor-phase cells and establish a replay-stable project."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / ".tmp" / "final_candidate.gpx"


def set_cell(phase, cell):
    phase.data["General"]["Cell"][1:7] = list(cell)
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def state(project, label):
    hist = project.histogram(0)
    print("STATE_JSON " + json.dumps({
        "step": label,
        "Rwp": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "shift_um": hist.data["Sample Parameters"]["Shift"][0],
        "fractions": hist.ComputeMassFracs(),
        "phases": [{
            "name": p.name,
            "cell": p.get_cell(),
            "cell_refine": p.data["General"]["Cell"][0],
            "scale": p.data["Histograms"][hist.name]["Scale"][0],
            "Rf": hist.residuals.get(f"{p.id}:0:Rf"),
        } for p in project.phases()],
        "frozen": [str(v) for v in project.get_Frozen()],
    }))


def run(project, label):
    project.set_Controls("cycles", 25)
    project.do_refinements([{}])
    project.save()
    state(project, label)


project = G2sc.G2Project(
    str(ROOT / ".tmp" / "inventory_four_phase_euwo.gpx"), newgpx=str(OUTPUT)
)
bawo4 = project.phase("BaWO4_scheelite")
bao = project.phase("BaO_rocksalt")
set_cell(bawo4, [5.614, 5.614, 12.719, 90.0, 90.0, 90.0])
set_cell(bao, [5.496, 5.496, 5.496, 90.0, 90.0, 90.0])
bawo4.clear_refinements({"Cell": True})
bao.clear_refinements({"Cell": True})
project.save()
run(project, "pruned")

for index in range(1, 4):
    project = G2sc.G2Project(str(OUTPUT))
    run(project, f"replay_{index}")
