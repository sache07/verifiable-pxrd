#!/usr/bin/env python3
"""Re-challenge two physical scheelite prototypes under the accepted widths."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("parent", choices=["euwo", "bamo"])
parser.add_argument("--baseline", default=".tmp/three_phase_profile.gpx")
args = parser.parse_args()
source = {
    "euwo": "BaWO4_EuWO4_prototype.cif",
    "bamo": "BaWO4_BaMoO4_prototype.cif",
}[args.parent]
baseline = ROOT / args.baseline
suffix = "_final" if baseline.name == "final_inventory.gpx" else ""
output = ROOT / ".tmp" / f"rechallenge_bawo4_{args.parent}{suffix}.gpx"
project = G2sc.G2Project(
    str(baseline), newgpx=str(output)
)
hist = project.histogram(0)
phase = project.add_phase(
    str(ROOT / ".tmp" / source), phasename="BaWO4_scheelite",
    histograms=[hist], fmthint="CIF"
)
hap = phase.data["Histograms"][hist.name]
hap["Scale"][:] = [0.01, True]
hap["Size"][0] = "isotropic"
hap["Size"][1][:] = [0.023, 0.023, 0.5]
hap["Size"][2][:] = [False, False, False]
hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
hap["Mustrain"][2][:] = [False, False, False]
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = False
phase.clear_refinements({"Cell": True})
project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
project.set_Controls("cycles", 25)
project.save()
project.do_refinements([{}])
project.save()
project = G2sc.G2Project(str(output))
project.do_refinements([{}])
project.save()
hist = project.histogram(0)
phase = project.phase("BaWO4_scheelite")
print("BAWO4_JSON " + json.dumps({
    "parent": args.parent,
    "Rwp": hist.residuals.get("wR"),
    "R": hist.residuals.get("R"),
    "scale": phase.data["Histograms"][hist.name]["Scale"][0],
    "Rf": hist.residuals.get(f"{phase.id}:0:Rf"),
    "fractions": hist.ComputeMassFracs(),
    "frozen": [str(v) for v in project.get_Frozen()],
}))
