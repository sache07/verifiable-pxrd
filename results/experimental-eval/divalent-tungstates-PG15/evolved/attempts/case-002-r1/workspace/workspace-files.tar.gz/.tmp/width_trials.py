#!/usr/bin/env python3
"""Compare phase size and strain broadening from neutral values."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def report(project, label):
    hist = project.histogram(0)
    row = {"step": label, "Rwp": hist.residuals.get("wR"), "R": hist.residuals.get("R"), "frozen": project.get_Frozen(), "phases": []}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"].append({"name": phase.name, "scale": hap["Scale"][0], "size": hap["Size"][1], "strain": hap["Mustrain"][1]})
    print(json.dumps(row))


def refine(project, label, cycles=12):
    project.set_Controls("cycles", cycles)
    project.do_refinements([{}])
    project.save()
    report(project, label)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["size", "strain", "both"])
    args = parser.parse_args()
    output = ROOT / ".tmp" / f"width_{args.mode}.gpx"
    project = G2sc.G2Project(str(ROOT / ".tmp" / "shift_trial.gpx"), newgpx=str(output))
    project.set_Frozen()
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [1000.0, 1000.0, 0.5]
        hap["Size"][2][:] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 0.5]
        hap["Mustrain"][2][:] = [False, False, False]
    project.save()
    refine(project, "neutral", 12)

    for phase in project.phases():
        pid = phase.id
        hap = phase.data["Histograms"][hist.name]
        if args.mode in {"size", "both"}:
            hap["Size"][1][0] = 0.04
            project.set_Controls("parmMin", 0.01, variable=f"{pid}:0:Size;i")
            project.set_Controls("parmMax", 1.0, variable=f"{pid}:0:Size;i")
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True, "LGmix": {"value": 0.5, "refine": False}}})
            refine(project, f"size_{phase.name}")
        if args.mode in {"strain", "both"}:
            hap["Mustrain"][1][0] = 1500.0
            project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
            project.set_Controls("parmMax", 10000.0, variable=f"{pid}:0:Mustrain;i")
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True, "LGmix": {"value": 0.5, "refine": False}}})
            refine(project, f"strain_{phase.name}")

    project = G2sc.G2Project(str(output))
    refine(project, "replay", 15)


if __name__ == "__main__":
    main()
