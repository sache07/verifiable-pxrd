#!/usr/bin/env python3
"""Challenge the weak Pb3O4 phase with its fixed 293 K reference cell."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = ROOT / "final.gpx"
OUTDIR = ROOT / "audit" / "minium_fixed_cell"
PROJECT = OUTDIR / "model.gpx"


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(SOURCE), newgpx=str(PROJECT))
    project.set_Controls("cycles", 20)

    minium = project.phase("Pb3O4_minium")
    minium.set_refinements({"Cell": False})
    a = 8.811
    c = 6.563
    minium.data["General"]["Cell"] = [
        False,
        a,
        a,
        c,
        90.0,
        90.0,
        90.0,
        a * a * c,
    ]

    project.save()
    for _ in range(4):
        project.do_refinements([{}])
        project.save()
        project = G2sc.G2Project(str(PROJECT))

    hist = project.histogram(0)
    fractions = {
        name: {"fraction": value[0], "esd": value[1]}
        for name, value in hist.ComputeMassFracs().items()
    }
    summary = {
        "rwp_percent": hist.data["data"][0]["wR"],
        "rp_percent": hist.data["data"][0]["R"],
        "fractions": fractions,
        "minium_cell": minium.get_cell(),
    }
    (OUTDIR / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
