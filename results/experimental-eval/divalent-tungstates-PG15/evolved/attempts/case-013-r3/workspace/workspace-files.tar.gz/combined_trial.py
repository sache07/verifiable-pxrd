#!/usr/bin/env python3
"""Test complementary terms after accepting the common polarization correction."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
BASE = ROOT / "trials/polarization/model.gpx"


def configure(project: G2sc.G2Project, trial: str) -> dict:
    histogram = project.histogram(0)
    note: dict = {"trial": trial}
    if trial == "pol_shl":
        histogram.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.set_Controls("parmMin", 0.0001, ":0:SH/L")
        project.set_Controls("parmMax", 0.2, ":0:SH/L")
    elif trial == "pol_strain3":
        phase = project.phase(3)
        phase.setSampleProfile(histogram, "microstrain", "isotropic", 0.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [histogram],
        )
        project.set_Controls("parmMin", 0.0, "3:0:Mustrain;i")
        project.set_Controls("parmMax", 100000.0, "3:0:Mustrain;i")
    elif trial == "pb2_shl":
        histogram.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.set_Controls("parmMin", 0.0001, ":0:SH/L")
        project.set_Controls("parmMax", 0.2, ":0:SH/L")
    elif trial == "pb2_strain":
        phase = project.phase(3)
        phase.setSampleProfile(histogram, "microstrain", "isotropic", 0.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [histogram],
        )
        project.set_Controls("parmMin", 0.0, "3:0:Mustrain;i")
        project.set_Controls("parmMax", 100000.0, "3:0:Mustrain;i")
    elif trial == "pb2_pbo_md":
        phase = project.phase(2)
        pref = phase.data["Histograms"][histogram.name]["Pref.Ori."]
        pref[0] = "MD"
        pref[1] = 1.0
        pref[2] = True
        pref[3] = [1, 0, 0]
        project.set_Controls("parmMin", 0.2, "2:0:MD")
        project.set_Controls("parmMax", 5.0, "2:0:MD")
        note.update({"phase": phase.name, "axis": [1, 0, 0]})
    elif trial == "pb2_roughness":
        sample = histogram.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.9, True]
        sample["SurfRoughB"] = [0.1, True]
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, ":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
        project.set_Controls("parmMax", 5.0, ":0:SurfRoughB")
    elif trial == "pol_roughness":
        sample = histogram.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.9, True]
        sample["SurfRoughB"] = [0.1, True]
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, ":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
        project.set_Controls("parmMax", 5.0, ":0:SurfRoughB")
    elif trial.startswith("md_"):
        _, phase_id_text, axis_text = trial.split("_", 2)
        phase_id = int(phase_id_text)
        axis = [int(value) for value in axis_text]
        phase = project.phase(phase_id)
        pref = phase.data["Histograms"][histogram.name]["Pref.Ori."]
        pref[0] = "MD"
        pref[1] = 1.0
        pref[2] = True
        pref[3] = axis
        project.set_Controls("parmMin", 0.2, f"{phase_id}:0:MD")
        project.set_Controls("parmMax", 5.0, f"{phase_id}:0:MD")
        note.update({"phase": phase.name, "axis": axis})
    else:
        raise ValueError(trial)
    return note


def summarize(project: G2sc.G2Project, note: dict) -> dict:
    histogram = project.histogram(0)
    residuals = histogram.data["data"][0]
    instrument = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    mass_fracs = histogram.ComputeMassFracs()
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases.append(
            {
                "name": phase.name,
                "mass_fraction": mass_fracs[phase.name][0],
                "microstrain": hap["Mustrain"][1][0],
                "MD": hap["Pref.Ori."][1],
                "MD_axis": hap["Pref.Ori."][3],
            }
        )
    return {
        **note,
        "wR_percent": histogram.get_wR(),
        "R_percent": residuals.get("R"),
        "Rb_percent": residuals.get("Rb"),
        "SH_over_L": instrument["SH/L"][1],
        "polarization": instrument["Polariz."][1],
        "U": instrument["U"][1],
        "W": instrument["W"][1],
        "X": instrument["X"][1],
        "surface_roughness_A": sample["SurfRoughA"][0],
        "surface_roughness_B": sample["SurfRoughB"][0],
        "frozen": project.get_Frozen(),
        "phases": phases,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("trial")
    args = parser.parse_args()
    outdir = ROOT / "combined_trials" / args.trial
    outdir.mkdir(parents=True, exist_ok=True)
    output = outdir / "model.gpx"
    base = (
        ROOT / "combined_trials/md_3_100/model.gpx"
        if args.trial.startswith("pb2_")
        else BASE
    )
    project = G2sc.G2Project(str(base), newgpx=str(output))
    project.set_Controls("cycles", 15)
    note = configure(project, args.trial)
    project.save()
    project.do_refinements([{}])
    project.save()
    project = G2sc.G2Project(str(output))
    project.do_refinements([{}])
    project.save()
    summary = summarize(project, note)
    (outdir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
