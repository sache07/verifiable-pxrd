#!/usr/bin/env python3
"""Run restrained, common-baseline GSAS-II comparisons for phase records."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod(cod_id: str) -> str:
    return str(COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif")


MODELS = {
    "base": [
        ("PbWO4_scheelite", cod("9009811")),
        ("WO3_monoclinic", cod("1528915")),
        ("PbO_massicot", cod("2310433")),
        ("Pb2WO5_analogue", str(ROOT / "candidates/Pb2WO5_from_7220560.cif")),
    ],
    "pbwo4_old": [
        ("PbWO4_scheelite", cod("1527935")),
        ("WO3_monoclinic", cod("1528915")),
        ("PbO_massicot", cod("2310433")),
        ("Pb2WO5_analogue", str(ROOT / "candidates/Pb2WO5_from_7220560.cif")),
    ],
    "wo3_1966": [
        ("PbWO4_scheelite", cod("9009811")),
        ("WO3_monoclinic", cod("2311041")),
        ("PbO_massicot", cod("2310433")),
        ("Pb2WO5_analogue", str(ROOT / "candidates/Pb2WO5_from_7220560.cif")),
    ],
    "wo3_triclinic": [
        ("PbWO4_scheelite", cod("9009811")),
        ("WO3_triclinic", cod("2106293")),
        ("PbO_massicot", cod("2310433")),
        ("Pb2WO5_analogue", str(ROOT / "candidates/Pb2WO5_from_7220560.cif")),
    ],
    "wo3_p21m": [
        ("PbWO4_scheelite", cod("9009811")),
        ("WO3_monoclinic", cod("1010618")),
        ("PbO_massicot", cod("2310433")),
        ("Pb2WO5_analogue", str(ROOT / "candidates/Pb2WO5_from_7220560.cif")),
    ],
    "pbo_litharge": [
        ("PbWO4_scheelite", cod("9009811")),
        ("WO3_monoclinic", cod("1528915")),
        ("PbO_litharge", cod("9012700")),
        ("Pb2WO5_analogue", str(ROOT / "candidates/Pb2WO5_from_7220560.cif")),
    ],
    "pb2wo5_cr_parent": [
        ("PbWO4_scheelite", cod("9009811")),
        ("WO3_monoclinic", cod("1528915")),
        ("PbO_massicot", cod("2310433")),
        ("Pb2WO5_analogue", str(ROOT / "candidates/Pb2WO5_from_8103050.cif")),
    ],
    "pb3o4": [
        ("PbWO4_scheelite", cod("9009811")),
        ("WO3_monoclinic", cod("2311041")),
        ("PbO_massicot", cod("2310433")),
        ("Pb2WO5_analogue", str(ROOT / "candidates/Pb2WO5_from_7220560.cif")),
        ("Pb3O4_minium", cod("9012124")),
    ],
    "pb3o4_ortho": [
        ("PbWO4_scheelite", cod("9009811")),
        ("WO3_monoclinic", cod("2311041")),
        ("PbO_massicot", cod("2310433")),
        ("Pb2WO5_analogue", str(ROOT / "candidates/Pb2WO5_from_7220560.cif")),
        ("Pb3O4_minium", cod("9013442")),
    ],
    "raspite_watch": [
        ("PbWO4_scheelite", cod("9009811")),
        ("WO3_monoclinic", cod("2311041")),
        ("PbO_massicot", cod("2310433")),
        ("Pb2WO5_analogue", str(ROOT / "candidates/Pb2WO5_from_7220560.cif")),
        ("PbWO4_raspite", cod("9007617")),
    ],
    "pb7w8_watch": [
        ("PbWO4_scheelite", cod("9009811")),
        ("WO3_monoclinic", cod("2311041")),
        ("PbO_massicot", cod("2310433")),
        ("Pb2WO5_analogue", str(ROOT / "candidates/Pb2WO5_from_7220560.cif")),
        ("Pb7W8O29_defect", cod("9016035")),
    ],
}


def set_baseline(project: G2sc.G2Project, histogram) -> None:
    project.set_Controls("cycles", 12)
    histogram.set_refinements({"Limits": [10.01, 99.99]})
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
                "coeffs": [900.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            }
        }
    )
    histogram.data["Instrument Parameters"][0]["Zero"][1] = 0.27
    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
def phase_summary(project: G2sc.G2Project, histogram) -> list[dict]:
    mass_fracs = histogram.ComputeMassFracs()
    rows = []
    for phase in project.phases():
        rows.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "phase_scale": phase.HAPvalue("Scale", targethistlist=[histogram]),
                "mass_fraction": mass_fracs[phase.name][0],
                "mass_fraction_esd": mass_fracs[phase.name][1],
            }
        )
    return rows


def run(model_name: str) -> None:
    model_dir = ROOT / "comparisons" / model_name
    model_dir.mkdir(parents=True, exist_ok=True)
    gpx = model_dir / "model.gpx"
    project = G2sc.G2Project(newgpx=str(gpx))
    histogram = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"), str(ROOT / "instrument.instprm")
    )
    set_baseline(project, histogram)

    if len(MODELS[model_name]) == 5:
        initial_phase_scales = [0.72, 0.10, 0.07, 0.08, 0.03]
    else:
        initial_phase_scales = [0.80, 0.10, 0.07, 0.08]
    for (phase_name, phase_file), scale in zip(MODELS[model_name], initial_phase_scales):
        phase = project.add_phase(
            phase_file,
            phasename=phase_name,
            histograms=[histogram],
            fmthint="CIF",
        )
        phase.HAPvalue("Scale", scale, [histogram])
        phase.data["Histograms"][histogram.name]["Scale"][1] = False
        phase.setSampleProfile(histogram, "size", "isotropic", 10.0, LGmix=1.0)
        phase.setSampleProfile(histogram, "microstrain", "isotropic", 0.0, LGmix=1.0)
        phase.clear_HAP_refinements(
            {
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
            },
            [histogram],
        )

    # Parameter limits need phase/histogram indices to exist first.
    for variable, lower, upper in (
        (":0:Zero", -1.0, 1.0),
        (":0:U", 0.0, 200.0),
        (":0:W", 0.0, 200.0),
        (":0:X", 0.0, 100.0),
    ):
        project.set_Controls("parmMin", lower, variable)
        project.set_Controls("parmMax", upper, variable)

    # Establish intensity/background/zero with fixed phase ratios and cells.
    histogram.set_refinements({"Sample Parameters": ["Scale"]})
    project.save()
    project.do_refinements([{}])

    # Fix the common scale and release all phase scales plus cells.
    histogram = project.histogram(0)
    histogram.data["Sample Parameters"]["Scale"][1] = False
    for phase in project.phases():
        phase.data["Histograms"][histogram.name]["Scale"][1] = True
        phase.set_refinements({"Cell": True})
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")
    project.save()
    project.do_refinements([{}])
    project.do_refinements([{}])

    # Rebuild one clean common nonnegative U/W/X profile.
    project.set_Frozen()
    histogram = project.histogram(0)
    histogram.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    project.save()
    project.do_refinements([{}])

    # Reopen and replay as a reproducibility check.
    project.save()
    project = G2sc.G2Project(str(gpx))
    project.do_refinements([{}])
    project.save()
    histogram = project.histogram(0)
    residuals = histogram.data["data"][0]
    summary = {
        "model": model_name,
        "wR_percent": histogram.get_wR(),
        "R_percent": residuals.get("R"),
        "Rb_percent": residuals.get("Rb"),
        "instrument": {
            key: value[1]
            for key, value in histogram.data["Instrument Parameters"][0].items()
            if isinstance(value, list) and len(value) > 1
        },
        "frozen": project.get_Frozen(),
        "phases": phase_summary(project, histogram),
    }
    (model_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", choices=sorted(MODELS))
    args = parser.parse_args()
    run(args.model)


if __name__ == "__main__":
    main()
