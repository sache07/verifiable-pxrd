#!/usr/bin/env python3
"""Build, replay, and export the selected restrained five-phase refinement."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = ROOT / "combined_trials/pb2_pbo_md/model.gpx"
FINAL = ROOT / "final.gpx"

PHASE_META = [
    (
        "PbWO4",
        "phase_1_PbWO4_scheelite.cif",
        "scheelite, I41/a",
        "COD 9009811",
        "well supported",
    ),
    (
        "WO3",
        "phase_2_WO3_monoclinic.cif",
        "monoclinic, P21/c",
        "COD 2311041",
        "well supported",
    ),
    (
        "PbO",
        "phase_3_PbO_massicot.cif",
        "massicot, Pbcm",
        "COD 2310433",
        "well supported",
    ),
    (
        "Pb2WO5",
        "phase_4_Pb2WO5_prototype.cif",
        "C2/m prototype model",
        "Pb2MoO5 COD 7220560 with Mo replaced by W",
        "provisional analogue structure",
    ),
    (
        "Pb3O4",
        "phase_5_Pb3O4_minium.cif",
        "minium, P42/mbc",
        "COD 9012124",
        "tentative minor phase",
    ),
]


def configure(project: G2sc.G2Project) -> None:
    histogram = project.histogram(0)
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-4

    # Include both measured end points in every replay and in the exported fit.
    measured_limits = histogram.data["Limits"][0]
    histogram.set_refinements({"Limits": list(measured_limits)})

    # U repeatedly moved below zero in common-profile trials. Keep its physical
    # boundary value but prune it from the variable list; W and X remain active.
    instrument = histogram.data["Instrument Parameters"][0]
    instrument["U"][1] = 0.0
    instrument["U"][2] = False
    project.set_Frozen()

    # Repeated low-angle asymmetry supports one common axial-divergence term.
    instrument["SH/L"][2] = True
    project.set_Controls("parmMin", 0.0001, ":0:SH/L")
    project.set_Controls("parmMax", 0.2, ":0:SH/L")

    # Explicitly neutralize rejected sample and phase nuisance terms.
    sample = histogram.data["Sample Parameters"]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][0] = 0.0
        sample[key][1] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Extinction"][0] = 0.0
        hap["Extinction"][1] = False


def refine_and_replay(project: G2sc.G2Project) -> G2sc.G2Project:
    project.save()
    # Repeated full-range passes remove dependence on the last staged change.
    for _ in range(3):
        project.do_refinements([{}])
        project.save()
        project = G2sc.G2Project(str(FINAL))
    project.do_refinements([{}])
    project.save()
    return G2sc.G2Project(str(FINAL))


def export(project: G2sc.G2Project) -> dict:
    histogram = project.histogram(0)
    mass_fracs = histogram.ComputeMassFracs()
    phase_rows = []
    for phase, (
        formula,
        cif_name,
        structure_label,
        source_model,
        assessment,
    ) in zip(project.phases(), PHASE_META):
        phase.export_CIF(str(ROOT / cif_name))
        fraction, fraction_esd = mass_fracs[phase.name]
        hap = phase.data["Histograms"][histogram.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phase_rows.append(
            {
                "name": phase.name,
                "formula": formula,
                "structure": structure_label,
                "source_model": source_model,
                "assessment": assessment,
                "cif_path": cif_name,
                "weight_fraction": fraction,
                "weight_percent": 100.0 * fraction,
                "weight_fraction_esd": fraction_esd,
                "cell": cell,
                "cell_esd": cell_esd,
                "preferred_orientation": {
                    "model": hap["Pref.Ori."][0],
                    "axis": hap["Pref.Ori."][3],
                    "parameter": hap["Pref.Ori."][1],
                    "refined": hap["Pref.Ori."][2],
                },
            }
        )

    profile = histogram.data["data"][1]
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((profile[0], profile[1], profile[3], profile[5], profile[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )

    residuals = histogram.data["data"][0]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    instrument = histogram.data["Instrument Parameters"][0]
    result = {
        "fraction_basis": "normalized over modeled crystalline phases",
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent": residuals.get("wR"),
            "rp_percent": residuals.get("R"),
            "rb_percent": residuals.get("Rb"),
            "expected_rwp_percent": residuals.get("wRmin"),
            "goodness_of_fit": rvals.get("GOF"),
            "chi_squared": rvals.get("chisq"),
            "n_observations": rvals.get("Nobs"),
            "n_variables": rvals.get("Nvars"),
            "durbin_watson": residuals.get("Durbin-Watson"),
        },
        "instrument_model": {
            "zero_deg": instrument["Zero"][1],
            "polarization": instrument["Polariz."][1],
            "U": instrument["U"][1],
            "W": instrument["W"][1],
            "X": instrument["X"][1],
            "SH_over_L": instrument["SH/L"][1],
            "kalpha2_to_kalpha1": instrument["I(L2)/I(L1)"][1],
        },
        "uncertainty_note": (
            "Reported ESDs are conditional least-squares values only; they do "
            "not include phase-inventory, source-structure, or profile-model "
            "uncertainty. Pb2WO5 is represented by a substituted analogue and "
            "the minor Pb3O4 assignment/fraction is tentative."
        ),
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    configure(project)
    project = refine_and_replay(project)
    result = export(project)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
