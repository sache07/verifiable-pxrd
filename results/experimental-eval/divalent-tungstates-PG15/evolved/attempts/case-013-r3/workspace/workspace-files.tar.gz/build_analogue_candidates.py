#!/usr/bin/env python3
"""Build Pb2WO5 prototype candidates from isostoichiometric COD parents."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
OUT = Path("candidates")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def build(cod_id: str, replaced_element: str) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species({replaced_element: "W"})
    output = OUT / f"Pb2WO5_from_{cod_id}.cif"
    CifWriter(structure, symprec=0.01, refine_struct=False).write_file(output)
    print(output)


def main() -> None:
    OUT.mkdir(exist_ok=True)
    build("7220560", "Mo")
    build("8103050", "Cr")


if __name__ == "__main__":
    main()
