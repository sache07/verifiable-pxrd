#!/usr/bin/env python3
"""Replay one restrained nuisance-model trial from the five-phase baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
BASE = ROOT / "comparisons/pb3o4/model.gpx"


def configure(project: G2sc.G2Project, trial: str) -> dict:
    histogram = project.histogram(0)
    note: dict = {"trial": trial}
    if trial == "shl":
        histogram.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.set_Controls("parmMin", 0.0001, ":0:SH/L")
        project.set_Controls("parmMax", 0.2, ":0:SH/L")
    elif trial == "polarization":
        histogram.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.0, ":0:Polariz.")
        project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    elif trial.startswith("size_"):
        phase_id = int(trial.split("_", 1)[1])
        phase = project.phase(phase_id)
        phase.setSampleProfile(histogram, "size", "isotropic", 10.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [histogram],
        )
        project.set_Controls("parmMin", 0.01, f"{phase_id}:0:Size;i")
        project.set_Controls("parmMax", 10.0, f"{phase_id}:0:Size;i")
        note["phase"] = phase.name
    elif trial.startswith("strain_"):
        phase_id = int(trial.split("_", 1)[1])
        phase = project.phase(phase_id)
        phase.setSampleProfile(histogram, "microstrain", "isotropic", 0.0, LGmix=1.0)
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            },
            [histogram],
        )
        project.set_Controls("parmMin", 0.0, f"{phase_id}:0:Mustrain;i")
        project.set_Controls("parmMax", 100000.0, f"{phase_id}:0:Mustrain;i")
        note["phase"] = phase.name
    else:
        raise ValueError(trial)
    return note


def summarize(project: G2sc.G2Project, note: dict) -> dict:
    histogram = project.histogram(0)
    residuals = histogram.data["data"][0]
    instrument = histogram.data["Instrument Parameters"][0]
    mass_fracs = histogram.ComputeMassFracs()
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases.append(
            {
                "name": phase.name,
                "mass_fraction": mass_fracs[phase.name][0],
                "size_micrometre": hap["Size"][1][0],
                "microstrain": hap["Mustrain"][1][0],
            }
        )
    return {
        **note,
        "wR_percent": histogram.get_wR(),
        "R_percent": residuals.get("R"),
        "Rb_percent": residuals.get("Rb"),
        "SH_over_L": instrument["SH/L"][1],
        "polarization": instrument["Polariz."][1],
        "U": instrument["U"][1],
        "W": instrument["W"][1],
        "X": instrument["X"][1],
        "frozen": project.get_Frozen(),
        "phases": phases,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("trial")
    args = parser.parse_args()
    outdir = ROOT / "trials" / args.trial
    outdir.mkdir(parents=True, exist_ok=True)
    output = outdir / "model.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    project.set_Controls("cycles", 15)
    note = configure(project, args.trial)
    project.save()
    project.do_refinements([{}])
    project.save()
    project = G2sc.G2Project(str(output))
    project.do_refinements([{}])
    project.save()
    summary = summarize(project, note)
    (outdir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
