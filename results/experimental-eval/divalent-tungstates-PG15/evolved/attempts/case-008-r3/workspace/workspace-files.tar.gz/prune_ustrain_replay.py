from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def summary(project: G2sc.G2Project, stage: str) -> None:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    values = dict(zip(cov.get("varyList", []), cov.get("variables", [])))
    sigmas = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    print(
        "PRUNED "
        + json.dumps(
            {
                "stage": stage,
                "wR": hist.get_wR(),
                "R": hist.data["data"][0].get("R"),
                "GOF": cov.get("Rvals", {}).get("GOF"),
                "mass_fractions": hist.ComputeMassFracs(),
                "instrument": {
                    key: value[1]
                    for key, value in hist.data["Instrument Parameters"][0].items()
                    if key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
                },
                "shift": hist.data["Sample Parameters"]["Shift"][0],
                "mustrain": project.phase(0).data["Histograms"][hist.name]["Mustrain"],
                "mustrain_value": values.get("0:0:Mustrain;i"),
                "mustrain_esd": sigmas.get("0:0:Mustrain;i"),
                "frozen": project.get_Frozen(),
            },
            default=float,
        )
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    G2sc.SetPrintLevel("all")
    project = G2sc.G2Project(str(args.input), newgpx=str(args.output))
    project.set_Frozen()
    project.set_Controls("cycles", 15)
    hist = project.histogram(0)
    mustrain = project.phase(0).data["Histograms"][hist.name]["Mustrain"]
    mustrain[0] = "uniaxial"
    # GSAS-II's uniaxial derivative contains a division by the fixed axial
    # term, so use a negligible positive neutral value rather than exact zero.
    mustrain[1][1] = 1.0
    mustrain[2] = [True, False, False]
    mustrain[3] = [0, 1, 0]
    project.set_Controls("parmMin", 0.0, variable="0:0:Mustrain;i")
    project.set_Controls("parmMax", 10000.0, variable="0:0:Mustrain;i")
    project.refine()
    project.save()
    summary(project, "pruned")

    replay = G2sc.G2Project(str(args.output))
    replay.set_Frozen()
    replay.set_Controls("cycles", 15)
    replay.refine()
    replay.save()
    summary(replay, "replay")


if __name__ == "__main__":
    main()
