from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIpwd as G2pwd
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("phase")
    parser.add_argument("--rows", type=int, default=30)
    args = parser.parse_args()

    baseline = G2sc.G2Project(str(args.baseline))
    trial = G2sc.G2Project(str(args.candidate))
    base_hist = baseline.histogram(0)
    trial_hist = trial.histogram(0)

    x = np.asarray(base_hist.getdata("x"), dtype=float)
    yobs = np.asarray(base_hist.getdata("yobs"), dtype=float)
    base_calc = np.asarray(base_hist.getdata("ycalc"), dtype=float)
    trial_calc = np.asarray(trial_hist.getdata("ycalc"), dtype=float)
    weight = np.asarray(base_hist.getdata("yweight"), dtype=float)
    base_resid = yobs - base_calc
    trial_resid = yobs - trial_calc

    refs = np.asarray(trial_hist.reflections()[args.phase]["RefList"], dtype=float)
    # Normal powder list: h,k,l,mult,d,pos,sig,gam,Fobs^2,Fcalc^2,phase,Icorr,Prfo
    intensity = refs[:, 3] * np.maximum(refs[:, 9], 0.0) * np.maximum(refs[:, 11], 0.0)
    order = np.argsort(intensity)[::-1]

    other_positions: list[float] = []
    for name, block in trial_hist.reflections().items():
        if name == args.phase:
            continue
        values = np.asarray(block["RefList"], dtype=float)
        if values.size:
            other_positions.extend(values[:, 5].tolist())
    other_positions_array = np.asarray(other_positions)

    print(
        "h k l position fwhm relI nearest_other "
        "base_matched trial_matched delta_chi2 local_points"
    )
    top = float(np.max(intensity))
    shown = 0
    for idx in order:
        row = refs[idx]
        pos = row[5]
        if pos < x[0] or pos > x[-1]:
            continue
        sigma = np.sqrt(max(row[6], 0.0001)) / 100.0
        gamma = row[7] / 100.0
        fwhm = float(G2pwd.getgamFW(gamma, sigma))
        radius = max(1.5 * fwhm, 0.05)
        use = np.abs(x - pos) <= radius
        if not np.any(use):
            continue
        phase_delta = trial_calc[use] - base_calc[use]
        norm = np.sqrt(np.sum(weight[use] * phase_delta**2))
        if norm > 0:
            matched_before = float(np.sum(weight[use] * base_resid[use] * phase_delta) / norm)
            matched_after = float(np.sum(weight[use] * trial_resid[use] * phase_delta) / norm)
        else:
            matched_before = matched_after = 0.0
        delta_chi2 = float(
            np.sum(weight[use] * base_resid[use] ** 2)
            - np.sum(weight[use] * trial_resid[use] ** 2)
        )
        nearest = float(np.min(np.abs(other_positions_array - pos)))
        print(
            f"{int(row[0]):2d} {int(row[1]):2d} {int(row[2]):2d} "
            f"{pos:9.4f} {fwhm:7.4f} {100.0*intensity[idx]/top:7.2f} "
            f"{nearest:8.4f} {matched_before:12.4f} {matched_after:13.4f} "
            f"{delta_chi2:10.3f} {np.count_nonzero(use):4d}"
        )
        shown += 1
        if shown >= args.rows:
            break

    use_all = (x >= x[0]) & (x <= x[-1])
    print(
        "GLOBAL delta_chi2",
        float(
            np.sum(weight[use_all] * base_resid[use_all] ** 2)
            - np.sum(weight[use_all] * trial_resid[use_all] ** 2)
        ),
    )


if __name__ == "__main__":
    main()
