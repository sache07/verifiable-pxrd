from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def summarize(project: G2sc.G2Project, probe: str, phase_index: int = 0) -> None:
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    cov = project.data["Covariance"]["data"]
    values = dict(zip(cov.get("varyList", []), cov.get("variables", [])))
    sigmas = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    print(
        "PROBE "
        + json.dumps(
            {
                "probe": probe,
                "wR": hist.get_wR(),
                "R": hist.data["data"][0].get("R"),
                "Rb": hist.data["data"][0].get("Rb"),
                "wRb": hist.data["data"][0].get("wRb"),
                "GOF": cov.get("Rvals", {}).get("GOF"),
                "cell": phase.get_cell(),
                "instrument": {
                    k: v[1]
                    for k, v in hist.data["Instrument Parameters"][0].items()
                    if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "I(L2)/I(L1)")
                },
                "sample": {
                    k: v[0]
                    for k, v in hist.data["Sample Parameters"].items()
                    if isinstance(v, list) and k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Scale")
                },
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
                "background": hist.data["Background"][0],
                "frozen": project.get_Frozen(),
                "values": values,
                "sigmas": sigmas,
            },
            default=float,
        )
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "probe",
        choices=(
            "polarization",
            "shl",
            "kalpha_ratio",
            "atoms_x",
            "atoms_xu",
            "size",
            "strain",
            "strain_uniaxial",
            "texture",
            "background",
            "replay",
        ),
    )
    parser.add_argument("--axis", nargs=3, type=int, default=(0, 1, 0))
    parser.add_argument("--background-terms", type=int, default=8)
    parser.add_argument("--phase", type=int, default=0)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("all")
    project = G2sc.G2Project(str(args.input), newgpx=str(args.output))
    project.save()
    project.set_Frozen()
    project.set_Controls("cycles", 15)
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    phase_prefix = f"{phase.id}:0"
    hap = phase.data["Histograms"][hist.name]

    if args.probe == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif args.probe == "shl":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.set_Controls("parmMin", 0.0001, variable=":0:SH/L")
        project.set_Controls("parmMax", 0.2, variable=":0:SH/L")
    elif args.probe == "kalpha_ratio":
        hist.set_refinements({"Instrument Parameters": ["I(L2)/I(L1)"]})
        project.set_Controls("parmMin", 0.0, variable=":0:I(L2)/I(L1)")
        project.set_Controls("parmMax", 1.0, variable=":0:I(L2)/I(L1)")
    elif args.probe in ("atoms_x", "atoms_xu"):
        phase.set_refinements({"Atoms": {"all": "X" if args.probe == "atoms_x" else "XU"}})
    elif args.probe == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 10.0
        hap["Size"][2] = [True, False, False]
        project.set_Controls("parmMin", 0.01, variable=f"{phase_prefix}:Size;i")
        project.set_Controls("parmMax", 10.0, variable=f"{phase_prefix}:Size;i")
    elif args.probe == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 10.0
        hap["Mustrain"][2] = [True, False, False]
        project.set_Controls("parmMin", 0.0, variable=f"{phase_prefix}:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{phase_prefix}:Mustrain;i")
    elif args.probe == "strain_uniaxial":
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][:2] = [100.0, 100.0]
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = list(args.axis)
        project.set_Controls("parmMin", 0.0, variable=f"{phase_prefix}:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{phase_prefix}:Mustrain;i")
        project.set_Controls("parmMin", 0.0, variable=f"{phase_prefix}:Mustrain;a")
        project.set_Controls("parmMax", 10000.0, variable=f"{phase_prefix}:Mustrain;a")
    elif args.probe == "texture":
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(args.axis)
        project.set_Controls("parmMin", 0.2, variable=f"{phase_prefix}:MD")
        project.set_Controls("parmMax", 5.0, variable=f"{phase_prefix}:MD")
    elif args.probe == "background":
        old = hist.data["Background"][0]
        coeffs = list(old[3:])
        if args.background_terms > len(coeffs):
            coeffs.extend([0.0] * (args.background_terms - len(coeffs)))
        else:
            coeffs = coeffs[: args.background_terms]
        hist.data["Background"][0] = [old[0], True, args.background_terms, *coeffs]

    project.refine()
    project.save()
    summarize(project, args.probe, args.phase)


if __name__ == "__main__":
    main()
