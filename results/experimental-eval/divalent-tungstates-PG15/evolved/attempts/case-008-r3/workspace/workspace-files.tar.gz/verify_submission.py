from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parent


def main() -> None:
    result = json.loads((ROOT / "result.json").read_text())
    fit = np.loadtxt(ROOT / "fit.csv", delimiter=",", skiprows=1)
    project = G2sc.G2Project(str(ROOT / "final.gpx"))
    hist = project.histogram(0)
    phases = project.phases()
    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]

    expected = np.column_stack(
        (
            hist.getdata("x"),
            hist.getdata("yobs"),
            hist.getdata("ycalc"),
            hist.getdata("background"),
            np.asarray(hist.getdata("yobs")) - np.asarray(hist.getdata("ycalc")),
            hist.getdata("yweight"),
        )
    )
    if fit.shape != expected.shape:
        raise AssertionError((fit.shape, expected.shape))
    max_profile_delta = np.max(np.abs(fit - expected), axis=0)
    if not np.allclose(fit, expected, rtol=1.0e-9, atol=5.0e-6):
        raise AssertionError(f"fit.csv differs from final.gpx: {max_profile_delta}")

    fractions = hist.ComputeMassFracs()
    for phase, row in zip(phases, result["phases"]):
        if abs(fractions[phase.name][0] - row["weight_fraction"]) > 1.0e-12:
            raise AssertionError(f"fraction mismatch for {phase.name}")
    if abs(sum(row["weight_fraction"] for row in result["phases"]) - 1.0) > 1.0e-12:
        raise AssertionError("result fractions are not normalized")

    stats = result["fit_statistics"]
    if abs(hist.get_wR() - stats["Rwp_percent"]) > 1.0e-12:
        raise AssertionError("Rwp mismatch")
    if abs(rvals["GOF"] - stats["GOF"]) > 1.0e-12:
        raise AssertionError("GOF mismatch")
    if project.get_Frozen():
        raise AssertionError(f"frozen variables remain: {project.get_Frozen()}")
    if not rvals["converged"] or rvals["Max shft/sig"] >= 0.05:
        raise AssertionError(f"final refinement not converged: {rvals}")
    if list(hist.data["Limits"][0]) != list(hist.data["Limits"][1]):
        raise AssertionError("final project does not use the full range")

    structures = {}
    for phase, row in zip(phases, result["phases"]):
        structure = Structure.from_file(ROOT / row["cif_path"])
        phase_volume = phase.get_cell()["volume"]
        if abs(structure.volume - phase_volume) > 0.01:
            raise AssertionError(f"CIF cell mismatch for {phase.name}")
        cation_oxygen = []
        for site in structure:
            if site.specie.symbol not in ("Mn", "W"):
                continue
            distances = sorted(
                float(neighbor.nn_distance)
                for neighbor in structure.get_neighbors(site, 3.1)
                if neighbor.specie.symbol == "O"
            )
            cation_oxygen.append(distances)
        if not cation_oxygen or any(len(values) < 6 for values in cation_oxygen):
            raise AssertionError(f"inadequate cation coordination in {row['cif_path']}")
        structures[row["name"]] = {
            "formula": structure.composition.reduced_formula,
            "space_group": structure.get_space_group_info(),
            "cation_O_min_A": min(min(values) for values in cation_oxygen),
            "cation_O_max_A": max(max(values[:6]) for values in cation_oxygen),
        }

    print(
        json.dumps(
            {
                "status": "ok",
                "phase_count": len(phases),
                "profile_points": len(fit),
                "max_profile_column_delta": max_profile_delta.tolist(),
                "Rwp_percent": hist.get_wR(),
                "GOF": rvals["GOF"],
                "max_shift_over_sigma": rvals["Max shft/sig"],
                "fractions": fractions,
                "structures": structures,
            },
            default=float,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
