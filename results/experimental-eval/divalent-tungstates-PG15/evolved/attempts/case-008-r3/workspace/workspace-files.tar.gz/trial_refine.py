from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def initial_background(x: np.ndarray, y: np.ndarray, degree: int = 9) -> list[float]:
    # Use low quantiles from narrow bins so the starting polynomial follows the
    # measured continuum rather than the Bragg maxima.
    edges = np.linspace(x[0], x[-1], 181)
    bx, by = [], []
    for lo, hi in zip(edges[:-1], edges[1:]):
        use = (x >= lo) & (x < hi)
        if np.any(use):
            bx.append(float(np.median(x[use])))
            by.append(float(np.quantile(y[use], 0.12)))
    tx = -1.0 + 2.0 * (np.asarray(bx) - x[0]) / (x[-1] - x[0])
    return np.polynomial.chebyshev.chebfit(tx, np.asarray(by), degree).tolist()


def stage_summary(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phase_rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phase_rows.append(
            {
                "name": phase.name,
                "scale": hap["Scale"][0],
                "cell": phase.get_cell(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
            }
        )
    info = {
        "stage": label,
        "residuals": hist.data["data"][0].get("Residuals", {}),
        "wR": hist.get_wR(),
        "instrument": {
            k: v[1]
            for k, v in hist.data["Instrument Parameters"][0].items()
            if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "I(L2)/I(L1)")
        },
        "sample": {
            k: v[0] if isinstance(v, list) else v
            for k, v in hist.data["Sample Parameters"].items()
            if k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Scale")
        },
        "background": hist.data["Background"][0],
        "phases": phase_rows,
        "vary": project.get_VaryList(),
        "frozen": project.get_Frozen(),
    }
    print("STAGE " + json.dumps(info, default=float))
    return info


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cod-id", default="1520200")
    parser.add_argument("--name", default="MnWO4")
    parser.add_argument("--output", type=Path, default=ROOT / ".tmp/mnwo4_baseline.gpx")
    parser.add_argument("--correction", choices=("shift", "zero"), default="zero")
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("all")
    project = G2sc.G2Project(newgpx=str(args.output))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs/pattern.csv"),
        str(ROOT / "cu_kalpha.instprm"),
        fmthint="comma",
    )
    phase = project.add_phase(
        str(cod_path(args.cod_id)),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )

    xy = hist.data["data"][1]
    coeffs = initial_background(np.asarray(xy[0]), np.asarray(xy[1]), degree=9)
    hist.data["Background"][0] = ["chebyschev-1", True, len(coeffs), *coeffs]

    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1] = 100.0
    inst["V"][1] = 0.0
    inst["W"][1] = 400.0
    inst["X"][1] = 0.0
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [1.0e6, 1.0e6, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}

    project.set_Controls("cycles", 12)
    for variable, lower, upper in (
        (":0:U", 0.0, 5000.0),
        (":0:W", 0.01, 5000.0),
        (":0:X", 0.0, 100.0),
        # GSAS-II stores Bragg-Brentano specimen displacement in micrometres.
        (":0:Shift", -2000.0, 2000.0),
        (":0:Zero", -1.0, 1.0),
        ("0:0:Scale", 0.0, 1.0e6),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    # Scale/background first; then positions; then the smallest common profile.
    project.refine()
    stage_summary(project, "background_scale")

    project.phase(0).set_refinements({"Cell": True})
    if args.correction == "shift":
        project.histogram(0).set_refinements({"Sample Parameters": ["Shift"]})
    else:
        project.histogram(0).set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    stage_summary(project, f"cell_{args.correction}")

    project.histogram(0).set_refinements({"Instrument Parameters": ["W"]})
    project.refine()
    stage_summary(project, "W")

    project.histogram(0).set_refinements({"Instrument Parameters": ["U"]})
    project.refine()
    stage_summary(project, "UW")

    project.histogram(0).set_refinements({"Instrument Parameters": ["X"]})
    project.refine()
    stage_summary(project, "UWX")
    project.save()


if __name__ == "__main__":
    main()
