from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def phase_summary(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    vary = cov.get("varyList", [])
    sig = dict(zip(vary, cov.get("sig", [])))
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        variable = f"{phase.id}:0:Scale"
        phases.append(
            {
                "name": phase.name,
                "mass": phase.data["General"].get("Mass"),
                "scale": hap["Scale"][0],
                "scale_esd": sig.get(variable),
                "cell": phase.get_cell(),
                "cell_refine": phase.data["General"]["Cell"][0],
            }
        )
    try:
        mass_fractions = hist.ComputeMassFracs()
    except Exception as error:
        mass_fractions = {"error": repr(error)}
    print(
        "CANDIDATE "
        + json.dumps(
            {
                "stage": label,
                "wR": hist.get_wR(),
                "R": hist.data["data"][0].get("R"),
                "GOF": cov.get("Rvals", {}).get("GOF"),
                "frozen": project.get_Frozen(),
                "mass_fractions": mass_fractions,
                "phases": phases,
            },
            default=float,
        )
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--cod-id")
    source.add_argument("--cif", type=Path)
    parser.add_argument("--name", required=True)
    parser.add_argument("--refine-cell", action="store_true")
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    cif = cod_path(args.cod_id) if args.cod_id else args.cif
    G2sc.SetPrintLevel("all")
    project = G2sc.G2Project(str(args.input), newgpx=str(args.output))
    project.save()
    project.set_Frozen()
    project.set_Controls("cycles", 15)
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cif),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.25, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    project.set_Controls("parmMax", 1.0e5, variable=f"{phase.id}:0:Scale")

    project.refine()
    project.save()
    phase_summary(project, "scale")

    if args.refine_cell and phase.data["Histograms"][hist.name]["Scale"][0] > 0.0:
        project.set_Frozen()
        project.phase(phase.name).set_refinements({"Cell": True})
        project.refine()
        project.save()
        phase_summary(project, "cell")

    # Explicit save/reopen/replay test with the accepted active flags.
    replay = G2sc.G2Project(str(args.output))
    replay.set_Controls("cycles", 15)
    replay.refine()
    replay.save()
    phase_summary(replay, "replay")


if __name__ == "__main__":
    main()
