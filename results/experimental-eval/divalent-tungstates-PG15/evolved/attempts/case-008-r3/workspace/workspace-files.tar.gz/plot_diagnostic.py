from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.project))
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("x"))
    obs = np.asarray(hist.getdata("yobs"))
    calc = np.asarray(hist.getdata("ycalc"))
    bkg = np.asarray(hist.getdata("background"))
    diff = obs - calc
    refs = hist.reflections()

    spans = [(9.9, 32.5), (32.5, 55.0), (55.0, 77.5), (77.5, 100.1)]
    fig, axes = plt.subplots(4, 1, figsize=(16, 12), constrained_layout=True)
    colors = ["#1b9e77", "#7570b3", "#d95f02", "#e7298a"]
    for ax, (lo, hi) in zip(axes, spans):
        use = (x >= lo) & (x <= hi)
        ax.plot(x[use], obs[use], color="black", lw=0.7, label="observed")
        ax.plot(x[use], calc[use], color="#d62728", lw=0.8, label="calculated")
        ax.plot(x[use], bkg[use], color="#777777", lw=0.5, label="background")
        local_span = max(float(np.max(obs[use]) - np.min(bkg[use])), 1.0)
        offset = float(np.min(bkg[use]) - 0.13 * local_span)
        ax.plot(x[use], diff[use] + offset, color="#1f77b4", lw=0.55, label="difference")
        tick_gap = 0.025 * local_span
        for number, (name, block) in enumerate(refs.items()):
            positions = np.asarray(block["RefList"])[:, 5]
            positions = positions[(positions >= lo) & (positions <= hi)]
            level = offset - (number + 1) * tick_gap
            ax.vlines(positions, level - 0.35 * tick_gap, level + 0.35 * tick_gap,
                      color=colors[number % len(colors)], lw=0.55,
                      label=name if ax is axes[0] else None)
        ax.set_xlim(lo, hi)
        ax.set_ylim(offset - (len(refs) + 1.5) * tick_gap, float(np.max(obs[use])) * 1.04)
        ax.set_ylabel("counts")
    axes[-1].set_xlabel(r"$2\theta$ (deg)")
    axes[0].legend(loc="upper right", ncol=3, fontsize=8)
    fig.savefig(args.output, dpi=180)


if __name__ == "__main__":
    main()
