from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
INPUT_PROJECT = ROOT / ".tmp/final_replay3.gpx"
FINAL_PROJECT = ROOT / "final.gpx"


def neutralize_rejected_terms(project: G2sc.G2Project) -> None:
    """Keep only the replay-stable baseline and accepted texture term."""
    hist = project.histogram(0)
    hist.data["Limits"][1] = list(hist.data["Limits"][0])
    hist.data["Background"][0][1] = True

    inst = hist.data["Instrument Parameters"][0]
    for name in ("V", "Y", "Z"):
        inst[name][1] = 0.0
        inst[name][2] = False
    for name in ("U", "W", "X", "Polariz."):
        inst[name][2] = True
    inst["Zero"][1] = 0.0
    inst["Zero"][2] = False
    inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False
    inst["I(L2)/I(L1)"][1] = 0.5
    inst["I(L2)/I(L1)"][2] = False

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"][1] = True
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"] = [0.0, False]
        hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}

    main_hap = project.phase(0).data["Histograms"][hist.name]
    main_hap["Pref.Ori."][:4] = ["MD", main_hap["Pref.Ori."][1], True, [1, 1, 0]]
    minor_hap = project.phase(1).data["Histograms"][hist.name]
    minor_hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]

    bounds = (
        (":0:U", 0.0, 5000.0),
        (":0:W", 0.01, 5000.0),
        (":0:X", 0.0, 100.0),
        (":0:Polariz.", 0.0, 1.0),
        (":0:Shift", -2000.0, 2000.0),
        ("0:0:Scale", 0.0, 1.0e6),
        ("1:0:Scale", 0.0, 1.0e6),
        ("0:0:MD", 0.2, 5.0),
    )
    for variable, lower, upper in bounds:
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)


def replay(project_path: Path, new_project: bool = False) -> dict[str, float | bool]:
    if new_project:
        project = G2sc.G2Project(str(INPUT_PROJECT), newgpx=str(project_path))
    else:
        project = G2sc.G2Project(str(project_path))
    project.set_Frozen()
    project.set_Controls("cycles", 15)
    neutralize_rejected_terms(project)
    project.refine()
    project.save()
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    fractions = hist.ComputeMassFracs()
    return {
        "Rwp_percent": float(hist.get_wR()),
        "GOF": float(rvals.get("GOF")),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig")),
        "MnWO4_weight_fraction": float(fractions["MnWO4"][0]),
        "WO3_weight_fraction": float(fractions["WO3m_2311041"][0]),
        "converged": bool(rvals.get("converged")),
    }


def export_results() -> dict[str, object]:
    project = G2sc.G2Project(str(FINAL_PROJECT))
    hist = project.histogram(0)
    phases = project.phases()
    if len(phases) != 2:
        raise RuntimeError(f"Expected two final phases, found {len(phases)}")
    if project.get_Frozen():
        raise RuntimeError(f"Final project contains frozen variables: {project.get_Frozen()}")

    cif_names = ["MnWO4.cif", "WO3.cif"]
    for phase, cif_name in zip(phases, cif_names):
        phase.export_CIF(str(ROOT / cif_name))

    x = np.asarray(hist.getdata("x"), dtype=float)
    observed = np.asarray(hist.getdata("yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("ycalc"), dtype=float)
    background = np.asarray(hist.getdata("background"), dtype=float)
    difference = observed - calculated
    weight = np.asarray(hist.getdata("yweight"), dtype=float)
    fit = np.column_stack((x, observed, calculated, background, difference, weight))
    np.savetxt(
        ROOT / "fit.csv",
        fit,
        delimiter=",",
        header=(
            "two_theta_deg,observed_counts,calculated_counts,"
            "background_counts,difference_observed_minus_calculated,weight"
        ),
        comments="",
        fmt="%.10g",
    )

    fractions = hist.ComputeMassFracs()
    fraction_sum = sum(value[0] for value in fractions.values())
    if not np.isclose(fraction_sum, 1.0, atol=1.0e-10):
        raise RuntimeError(f"Mass fractions are not normalized: {fraction_sum}")

    cov = project.data["Covariance"]["data"]
    rvals = cov.get("Rvals", {})
    stats = hist.data["data"][0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    phase_rows = []
    descriptors = (
        ("MnWO4", "MnWO4", "wolframite", "1520200", "MnWO4.cif"),
        ("WO3", "WO3", "monoclinic", "2311041", "WO3.cif"),
    )
    for phase, (name, formula, structure_type, source_id, cif_name) in zip(phases, descriptors):
        value, esd = fractions[phase.name]
        cell = phase.get_cell()
        phase_rows.append(
            {
                "name": name,
                "formula": formula,
                "structure_type": structure_type,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "source_cod_id": source_id,
                "cif_path": cif_name,
                "weight_fraction": float(value),
                "weight_fraction_esd": float(esd),
                "weight_percent": float(100.0 * value),
                "cell": {key: float(number) for key, number in cell.items()},
            }
        )

    result: dict[str, object] = {
        "normalization": "Weight fractions sum to 1 over the modeled crystalline phases.",
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": float(hist.get_wR()),
            "Rp_percent": float(stats["R"]),
            "Rb_percent": float(stats["Rb"]),
            "wRb_percent": float(stats["wRb"]),
            "GOF": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_variables": int(rvals["Nvars"]),
            "durbin_watson": float(stats["Durbin-Watson"]),
            "max_shift_over_sigma_last_cycle": float(rvals["Max shft/sig"]),
            "converged": bool(rvals["converged"]),
            "phase_Rf_percent": {
                "MnWO4": float(stats["0:0:Rf"]),
                "WO3": float(stats["1:0:Rf"]),
            },
        },
        "measurement_model": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelength_Kalpha1_angstrom": float(inst["Lam1"][1]),
            "wavelength_Kalpha2_angstrom": float(inst["Lam2"][1]),
            "Kalpha2_to_Kalpha1_ratio": float(inst["I(L2)/I(L1)"][1]),
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
            "weighting": "Poisson approximation, w = 1 / observed counts",
            "specimen_displacement_micrometre": float(sample["Shift"][0]),
        },
        "files": {
            "project": "final.gpx",
            "profile": "fit.csv",
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> None:
    G2sc.SetPrintLevel("all")
    history = [replay(FINAL_PROJECT, new_project=True)]
    history.append(replay(FINAL_PROJECT))
    history.append(replay(FINAL_PROJECT))
    result = export_results()
    print("FINAL_REPLAYS " + json.dumps(history))
    print("FINAL_RESULT " + json.dumps(result))


if __name__ == "__main__":
    main()
