from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def emit(project: G2sc.G2Project, stage: str) -> None:
    hist = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    print(
        "NOTEXTURE "
        + json.dumps(
            {
                "stage": stage,
                "wR": hist.get_wR(),
                "R": hist.data["data"][0].get("R"),
                "GOF": cov.get("Rvals", {}).get("GOF"),
                "mass_fractions": hist.ComputeMassFracs(),
                "pref_ori": project.phase(0).data["Histograms"][hist.name]["Pref.Ori."],
                "frozen": project.get_Frozen(),
            },
            default=float,
        )
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    G2sc.SetPrintLevel("all")
    project = G2sc.G2Project(str(args.input), newgpx=str(args.output))
    project.set_Frozen()
    project.set_Controls("cycles", 15)
    hist = project.histogram(0)
    pref = project.phase(0).data["Histograms"][hist.name]["Pref.Ori."]
    pref[:4] = ["MD", 1.0, False, [0, 0, 1]]
    project.refine()
    project.save()
    emit(project, "no_texture")

    replay = G2sc.G2Project(str(args.output))
    replay.set_Frozen()
    replay.set_Controls("cycles", 15)
    replay.refine()
    replay.save()
    emit(replay, "replay")


if __name__ == "__main__":
    main()
