from pathlib import Path
from pprint import pprint

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
MNWO4 = CIF_ROOT / "1/52/02/1520200.cif"

project = G2sc.G2Project(newgpx=str(ROOT / ".tmp/inspect.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / "inputs/pattern.csv"),
    str(ROOT / "cu_kalpha.instprm"),
    fmthint="comma",
)
phase = project.add_phase(
    str(MNWO4),
    phasename="MnWO4",
    histograms=[hist],
    fmthint="CIF",
)

print("HIST", hist.name)
print("LIMITS")
pprint(hist.data["Limits"])
print("BACKGROUND")
pprint(hist.data["Background"])
print("INSTRUMENT")
pprint(hist.data["Instrument Parameters"])
print("SAMPLE")
pprint(hist.data["Sample Parameters"])
print("HAP")
pprint(phase.data["Histograms"][hist.name])
print("CELL")
pprint(phase.data["General"]["Cell"])
print("ATOMS")
for atom in phase.atoms():
    print(atom.label, atom.element, atom.coordinates, atom.occupancy, atom.uiso, atom.refinement_flags)
project.save()
