#!/usr/bin/env python3
"""Re-test the leading WO3 records with profile release only after cells converge."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_candidates import BACKGROUND, COD, WORK, neutralize_hap, summarize


OUT = WORK / ".tmp" / "top_models"
MODELS = {
    "wo3_mono_1528915": COD / "1/52/89/1528915.cif",
    "wo3_mono_2311041": COD / "2/31/10/2311041.cif",
    "wo3_triclinic_2106293": COD / "2/10/62/2106293.cif",
}
CO3O4 = COD / "9/00/58/9005896.cif"


def fit(label: str, wo3_file: Path) -> dict:
    model_dir = OUT / label
    model_dir.mkdir(parents=True, exist_ok=True)
    project_path = model_dir / "model.gpx"
    gpx = G2sc.G2Project(newgpx=str(project_path))
    hist = gpx.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )
    for phase_name, phase_file in (("WO3", wo3_file), ("Co3O4", CO3O4)):
        phase = gpx.add_phase(
            str(phase_file),
            phasename=phase_name,
            histograms=[hist],
            fmthint="CIF",
        )
        neutralize_hap(phase, hist.name)
        phase.set_refinements({"Cell": False})

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": BACKGROUND,
            },
            "Sample Parameters": ["Shift"],
        }
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-583.0, True]
    for key, value in (("U", 182.0), ("V", 0.0), ("W", 0.0), ("X", 13.0), ("Y", 0.0), ("SH/L", 0.002)):
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False

    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    for phase_index, _phase in enumerate(gpx.phases()):
        gpx.set_Controls("parmMin", 1e-12, f"{phase_index}:0:Scale")

    # First solve scale/background/geometry with a common fixed profile.
    gpx.refine(printFile=str(model_dir / "stage1_baseline.lst"))
    # Then cells, keeping the common profile fixed.
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    gpx.refine(printFile=str(model_dir / "stage2_cells.lst"))
    # Only now release the two nonnegative common-profile terms.
    hist = gpx.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["U", "X"]})
    gpx.set_Controls("parmMin", 0.0, ":0:U")
    gpx.set_Controls("parmMin", 0.0, ":0:X")
    gpx.refine(printFile=str(model_dir / "stage3_profile.lst"))
    gpx.save()
    # Full-range replay from the serialized project.
    gpx = G2sc.G2Project(str(project_path))
    gpx.refine(printFile=str(model_dir / "replay.lst"))
    gpx.save()
    return summarize(gpx)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    result = {}
    for label, wo3_file in MODELS.items():
        try:
            result[label] = fit(label, wo3_file)
            print(f"{label}: Rwp={result[label]['residuals']['wR']:.5f}", flush=True)
        except Exception as exc:
            result[label] = {"error": f"{type(exc).__name__}: {exc}"}
            print(f"{label}: ERROR {exc}", flush=True)
    output = OUT / "comparison.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(output, flush=True)


if __name__ == "__main__":
    main()
