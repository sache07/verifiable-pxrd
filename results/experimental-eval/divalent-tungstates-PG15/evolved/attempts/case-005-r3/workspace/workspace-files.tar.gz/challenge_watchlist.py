#!/usr/bin/env python3
"""Challenge plausible CoWO4 prototypes against the clean two-phase profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_candidates import WORK, neutralize_hap, summarize


BASE = WORK / ".tmp/top_models/wo3_mono_2311041/model.gpx"
OUT = WORK / ".tmp/watchlist"
CANDIDATES = {
    "CoWO4_from_CoMoO4_7205001": WORK / ".tmp/cowo4_from_comoo4_7205001.cif",
    "CoWO4_from_FeWO4_9008124": WORK / ".tmp/cowo4_from_fewo4_9008124.cif",
}


def challenge(label: str, cif: Path) -> dict:
    model_dir = OUT / label
    model_dir.mkdir(parents=True, exist_ok=True)
    path = model_dir / "challenge.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    hist = gpx.histogram(0)
    phase = gpx.add_phase(
        str(cif),
        phasename="CoWO4",
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_hap(phase, hist.name)
    # Start below one weight percent and refine scale before any cell release.
    phase.HAPvalue("Scale", 0.10)
    phase.set_HAP_refinements({"Scale": True}, [hist])
    phase.set_refinements({"Cell": False})
    gpx.set_Controls("parmMin", 1e-12, "2:0:Scale")
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    gpx.refine(printFile=str(model_dir / "scale_challenge.lst"))
    first = summarize(gpx)
    gpx.save()
    gpx = G2sc.G2Project(str(path))
    gpx.refine(printFile=str(model_dir / "replay.lst"))
    gpx.save()
    return {"first_pass": first, "replay": summarize(gpx)}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    result = {}
    for label, cif in CANDIDATES.items():
        try:
            result[label] = challenge(label, cif)
            replay = result[label]["replay"]
            print(
                f"{label}: scale={replay['phase_scales']['CoWO4']:.6g}, "
                f"Rwp={replay['residuals']['wR']:.5f}",
                flush=True,
            )
        except Exception as exc:
            result[label] = {"error": f"{type(exc).__name__}: {exc}"}
            print(f"{label}: ERROR {exc}", flush=True)
    output = OUT / "watchlist.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(output, flush=True)


if __name__ == "__main__":
    main()
