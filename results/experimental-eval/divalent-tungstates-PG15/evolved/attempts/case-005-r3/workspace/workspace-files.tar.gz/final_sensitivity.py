#!/usr/bin/env python3
"""Sensitivity checks around the selected two-phase GSAS-II model."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from refine_candidates import WORK, summarize


BASE = WORK / ".tmp/conventional_model/model.gpx"
OUT = WORK / ".tmp/final_sensitivity"


def covariance_summary(gpx: G2sc.G2Project) -> dict:
    cov = gpx.data["Covariance"]["data"]
    vary = cov.get("varyList", [])
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    sig = np.asarray(cov.get("sig", []), dtype=float)
    pairs = []
    if matrix.shape == (len(vary), len(vary)) and len(vary):
        denom = np.outer(sig, sig)
        with np.errstate(divide="ignore", invalid="ignore"):
            corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom != 0)
        for i in range(len(vary)):
            for j in range(i):
                pairs.append((abs(float(corr[i, j])), vary[i], vary[j], float(corr[i, j])))
    pairs.sort(reverse=True)
    return {
        "message": cov.get("Rvals", {}).get("msg"),
        "largest_correlations": [
            {"absolute": a, "variable_1": v1, "variable_2": v2, "signed": c}
            for a, v1, v2, c in pairs[:12]
        ],
    }


def extra_summary(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    out = summarize(gpx)
    out["polarization"] = hist.InstrumentParameters["Polariz."][1]
    out["sample_parameters"] = {
        key: hist.SampleParameters[key]
        for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
    }
    out["uiso"] = {
        phase.name: {
            atom.label: {
                "element": atom.element,
                "value": atom.uiso,
                "refinement_flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        }
        for phase in gpx.phases()
    }
    out["nvars"] = len(gpx.data["Covariance"]["data"].get("varyList", []))
    out["covariance"] = covariance_summary(gpx)
    return out


def clone_and_refine(label: str, setup: Callable[[G2sc.G2Project], None]) -> dict:
    trial_dir = OUT / label
    trial_dir.mkdir(parents=True, exist_ok=True)
    project = trial_dir / "trial.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(project))
    setup(gpx)
    gpx.set_Controls("cycles", 16)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    gpx.refine(printFile=str(trial_dir / "first.lst"))
    first = extra_summary(gpx)
    gpx.save()
    gpx = G2sc.G2Project(str(project))
    gpx.refine(printFile=str(trial_dir / "replay.lst"))
    gpx.save()
    return {"first_pass": first, "replay": extra_summary(gpx)}


def background_order(ncoeff: int) -> Callable[[G2sc.G2Project], None]:
    def setup(gpx: G2sc.G2Project) -> None:
        gpx.histogram(0).set_refinements(
            {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": ncoeff}}
        )

    return setup


def roughness(gpx: G2sc.G2Project) -> None:
    sample = gpx.histogram(0).SampleParameters
    sample["SurfRoughA"] = [0.5, True]
    sample["SurfRoughB"] = [0.01, True]
    gpx.set_Controls("parmMin", 0.0, ":0:SurfRoughA")
    gpx.set_Controls("parmMax", 1.0, ":0:SurfRoughA")
    gpx.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
    gpx.set_Controls("parmMax", 2.0, ":0:SurfRoughB")


def fixed_uiso(cation: float, oxygen: float) -> Callable[[G2sc.G2Project], None]:
    def setup(gpx: G2sc.G2Project) -> None:
        for phase in gpx.phases():
            for atom in phase.atoms():
                atom.uiso = oxygen if atom.element == "O" else cation
                atom.refinement_flags = atom.refinement_flags.replace("U", "")

    return setup


def grouped_uiso(phases: tuple[str, ...]) -> Callable[[G2sc.G2Project], None]:
    def setup(gpx: G2sc.G2Project) -> None:
        gpx.index_ids()
        for pidx, phase in enumerate(gpx.phases()):
            if phase.name not in phases:
                continue
            by_element: dict[str, list[int]] = {}
            for aidx, atom in enumerate(phase.atoms()):
                atom.refinement_flags = atom.refinement_flags.replace("U", "") + "U"
                by_element.setdefault(atom.element, []).append(aidx)
                var = f"{pidx}::AUiso:{aidx}"
                gpx.set_Controls("parmMin", 0.0001, var)
                gpx.set_Controls("parmMax", 0.05, var)
            for indices in by_element.values():
                if len(indices) > 1:
                    variables = tuple(f"{pidx}::AUiso:{aidx}" for aidx in indices)
                    gpx.add_EquivConstr(variables, reloadIdx=False)

    return setup


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    trials: list[tuple[str, Callable[[G2sc.G2Project], None]]] = [
        ("background_4", background_order(4)),
        ("background_8", background_order(8)),
        ("surface_roughness", roughness),
        ("fixed_uiso_cation005_oxygen010", fixed_uiso(0.005, 0.010)),
        ("fixed_uiso_cation003_oxygen012", fixed_uiso(0.003, 0.012)),
        ("fixed_uiso_all005", fixed_uiso(0.005, 0.005)),
        ("fixed_uiso_all015", fixed_uiso(0.015, 0.015)),
        ("grouped_uiso_WO3", grouped_uiso(("WO3",))),
        ("grouped_uiso_Co3O4", grouped_uiso(("Co3O4",))),
        ("grouped_uiso_both", grouped_uiso(("WO3", "Co3O4"))),
    ]
    result = {}
    for label, setup in trials:
        try:
            result[label] = clone_and_refine(label, setup)
            replay = result[label]["replay"]
            fractions = replay["mass_fractions"]
            print(
                f"{label}: Rwp={replay['residuals']['wR']:.6f}, "
                f"WO3={100 * fractions['WO3']['value']:.3f} wt%, "
                f"p={replay['polarization']:.5f}, nvar={replay['nvars']}",
                flush=True,
            )
        except Exception as exc:
            result[label] = {"error": f"{type(exc).__name__}: {exc}"}
            print(f"{label}: ERROR {type(exc).__name__}: {exc}", flush=True)
    output = OUT / "sensitivity.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(output, flush=True)


if __name__ == "__main__":
    main()
