#!/usr/bin/env python3
"""Re-evaluate the nearest WO3 source/symmetry alternatives under the final profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import final_sensitivity as fs
from refine_candidates import WORK


FINAL = WORK / ".tmp/final_combination_trials/Co_O_coordinate_U_common/trial.gpx"
OUT = WORK / ".tmp/final_source_rechallenge"
SOURCES = {
    "monoclinic_1528915": WORK / ".tmp/top_models/wo3_mono_1528915/model.gpx",
    "triclinic_2106293": WORK / ".tmp/top_models/wo3_triclinic_2106293/model.gpx",
}


def configure(gpx: G2sc.G2Project) -> None:
    reference = G2sc.G2Project(str(FINAL))
    href = reference.histogram(0)
    hist = gpx.histogram(0)

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 9,
                "coeffs": list(href.Background[0][3:]),
            }
        }
    )
    hist.SampleParameters["Shift"] = list(href.SampleParameters["Shift"])
    hist.SampleParameters["Scale"] = [1.0, False]
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key] = [0.0, False]
    for key in ("Polariz.", "U", "W", "X"):
        hist.InstrumentParameters[key][1] = href.InstrumentParameters[key][1]
        hist.InstrumentParameters[key][2] = True
    for key, value in (("V", 0.0), ("Y", 0.0), ("SH/L", 0.002)):
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False
    gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
    for key in ("U", "W", "X"):
        gpx.set_Controls("parmMin", 0.0, f":0:{key}")

    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True}, [hist])
        hdata = phase.data["Histograms"][hist.name]
        hdata["Size"][0] = "isotropic"
        hdata["Size"][1] = [10.0, 10.0, 1.0]
        hdata["Size"][2] = [False, False, False]
        hdata["Pref.Ori."][0] = "MD"
        hdata["Pref.Ori."][1] = 1.0
        hdata["Pref.Ori."][2] = False
        hdata["Extinction"] = [0.0, False]
        hdata["Babinet"]["BabA"] = [0.0, False]
        hdata["Babinet"]["BabU"] = [0.0, False]
        gpx.set_Controls("parmMin", 1e-12, f"{phase.id}:0:Scale")

    wo3_hap = gpx.phase("WO3").data["Histograms"][hist.name]
    wo3_hap["Mustrain"][0] = "uniaxial"
    wo3_hap["Mustrain"][1] = [4000.0, 2800.0, 1.0]
    wo3_hap["Mustrain"][2] = [True, True, False]
    wo3_hap["Mustrain"][3] = [0, 1, 0]
    co_hap = gpx.phase("Co3O4").data["Histograms"][hist.name]
    co_hap["Mustrain"][0] = "isotropic"
    co_hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    co_hap["Mustrain"][2] = [False, False, False]

    # Refine the one independent spinel oxygen coordinate and one common Uiso.
    oxygen = gpx.phase("Co3O4").atom("O")
    oxygen.refinement_flags = "XU"
    for atom in gpx.phase("Co3O4").atoms()[:2]:
        atom.refinement_flags = "U"
    gpx.index_ids()
    variables = tuple(f"1::AUiso:{i}" for i in range(3))
    for variable in variables:
        gpx.set_Controls("parmMin", 0.0001, variable)
        gpx.set_Controls("parmMax", 0.05, variable)
    gpx.add_EquivConstr(variables, reloadIdx=False)


def run(label: str, base: Path) -> dict:
    directory = OUT / label
    directory.mkdir(parents=True, exist_ok=True)
    project = directory / "trial.gpx"
    gpx = G2sc.G2Project(str(base), newgpx=str(project))
    configure(gpx)
    gpx.set_Controls("cycles", 20)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    gpx.refine(printFile=str(directory / "first.lst"))
    gpx.save()
    gpx = G2sc.G2Project(str(project))
    gpx.refine(printFile=str(directory / "replay.lst"))
    gpx.save()
    result = fs.extra_summary(gpx)
    result["frozen"] = [str(item) for item in gpx.data["Controls"]["data"]["parmFrozen"].get("FrozenList", [])]
    result["space_group"] = gpx.phase("WO3").data["General"]["SGData"]["SpGrp"]
    return result


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    result = {}
    for label, base in SOURCES.items():
        try:
            result[label] = run(label, base)
            trial = result[label]
            print(
                f"{label}: Rwp={trial['residuals']['wR']:.6f}, "
                f"WO3={100 * trial['mass_fractions']['WO3']['value']:.3f} wt%, "
                f"p={trial['polarization']:.5f}, maxshift={trial['max_shift_over_sigma']:.3f}",
                flush=True,
            )
        except Exception as exc:
            result[label] = {"error": f"{type(exc).__name__}: {exc}"}
            print(f"{label}: ERROR {type(exc).__name__}: {exc}", flush=True)
    output = OUT / "trials.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(output, flush=True)


if __name__ == "__main__":
    main()
