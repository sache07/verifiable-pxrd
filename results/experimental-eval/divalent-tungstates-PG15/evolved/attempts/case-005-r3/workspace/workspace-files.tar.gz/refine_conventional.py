#!/usr/bin/env python3
"""Refine the selected monoclinic model in a near-orthogonal equivalent setting."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_candidates import BACKGROUND, COD, WORK, neutralize_hap, summarize


OUT = WORK / ".tmp/conventional_model"
WO3 = WORK / ".tmp/wo3_2311041_niggli.cif"
CO3O4 = COD / "9/00/58/9005896.cif"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    project = OUT / "model.gpx"
    gpx = G2sc.G2Project(newgpx=str(project))
    hist = gpx.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )
    for name, cif in (("WO3", WO3), ("Co3O4", CO3O4)):
        phase = gpx.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
        neutralize_hap(phase, hist.name)
        phase.set_refinements({"Cell": False})

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": BACKGROUND,
            },
            "Sample Parameters": ["Shift"],
        }
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-584.5, True]
    for key, value in (("Polariz.", 0.66), ("U", 145.0), ("V", 0.0), ("W", 0.0), ("X", 13.0), ("Y", 0.0), ("SH/L", 0.002)):
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False

    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    for i, _phase in enumerate(gpx.phases()):
        gpx.set_Controls("parmMin", 1e-12, f"{i}:0:Scale")

    gpx.refine(printFile=str(OUT / "stage1_baseline.lst"))
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    gpx.refine(printFile=str(OUT / "stage2_cells.lst"))

    hist = gpx.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["Polariz.", "U", "X"]})
    for variable, low, high in ((":0:Polariz.", 0.0, 1.0), (":0:U", 0.0, None), (":0:X", 0.0, None)):
        gpx.set_Controls("parmMin", low, variable)
        if high is not None:
            gpx.set_Controls("parmMax", high, variable)
    gpx.refine(printFile=str(OUT / "stage3_profile.lst"))

    wo3 = gpx.phase("WO3")
    hap = wo3.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [1000.0, 0.0, 1.0]
    hap["Mustrain"][2] = [True, False, False]
    gpx.refine(printFile=str(OUT / "stage4_isotropic_strain.lst"))

    # The unique b direction is invariant under the cell transformation.
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1] = [hap["Mustrain"][1][0], hap["Mustrain"][1][0], 1.0]
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = [0, 1, 0]
    gpx.refine(printFile=str(OUT / "stage5_uniaxial_strain.lst"))

    gpx.save()
    gpx = G2sc.G2Project(str(project))
    gpx.refine(printFile=str(OUT / "replay.lst"))
    gpx.save()

    result = summarize(gpx)
    h = gpx.histogram(0)
    result["WO3_mustrain"] = gpx.phase("WO3").data["Histograms"][h.name]["Mustrain"]
    result["covariance_message"] = gpx.data["Covariance"]["data"].get("Rvals", {}).get("msg")
    (OUT / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
