#!/usr/bin/env python3
"""Re-challenge symmetry-distinct March-Dollase axes under the final candidate."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

import final_sensitivity as fs
from refine_candidates import WORK


BASE = WORK / ".tmp/final_combination_trials/Co_O_coordinate_U_common/trial.gpx"
OUT = WORK / ".tmp/final_texture_rechallenge"
AXES = {
    "WO3": ([1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0], [1, 0, 1], [0, 1, 1], [1, 1, 1]),
    "Co3O4": ([1, 0, 0], [1, 1, 0], [1, 1, 1]),
}


def axis_text(axis: list[int] | tuple[int, int, int]) -> str:
    return "".join(str(i) for i in axis)


def run(phase_name: str, axis: tuple[int, int, int]) -> dict:
    label = f"{phase_name}_{axis_text(axis)}"
    directory = OUT / label
    directory.mkdir(parents=True, exist_ok=True)
    project = directory / "trial.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(project))
    hist = gpx.histogram(0)
    phase = gpx.phase(phase_name)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = list(axis)
    gpx.set_Controls("parmMin", 0.1, f"{phase.id}:0:MD")
    gpx.set_Controls("parmMax", 10.0, f"{phase.id}:0:MD")
    gpx.set_Controls("cycles", 16)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    gpx.refine(printFile=str(directory / "first.lst"))
    gpx.save()
    gpx = G2sc.G2Project(str(project))
    gpx.refine(printFile=str(directory / "replay.lst"))
    gpx.save()
    result = fs.extra_summary(gpx)
    hist = gpx.histogram(0)
    result["preferred_orientation"] = gpx.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
    result["frozen"] = [str(item) for item in gpx.data["Controls"]["data"]["parmFrozen"].get("FrozenList", [])]
    return result


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    result = {}
    for phase_name, axes in AXES.items():
        for axis in axes:
            label = f"{phase_name}_{axis_text(axis)}"
            try:
                result[label] = run(phase_name, axis)
                trial = result[label]
                ratio = trial["preferred_orientation"][1]
                print(
                    f"{label}: Rwp={trial['residuals']['wR']:.6f}, "
                    f"MD={ratio:.6f}, maxshift={trial['max_shift_over_sigma']:.3f}",
                    flush=True,
                )
            except Exception as exc:
                result[label] = {"error": f"{type(exc).__name__}: {exc}"}
                print(f"{label}: ERROR {type(exc).__name__}: {exc}", flush=True)
    output = OUT / "trials.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(output, flush=True)


if __name__ == "__main__":
    main()
