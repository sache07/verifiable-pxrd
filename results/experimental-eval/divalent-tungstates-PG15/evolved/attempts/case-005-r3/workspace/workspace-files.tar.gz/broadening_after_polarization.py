#!/usr/bin/env python3
"""Repeat phase-broadening/profile trials after accepting polarization."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc

import nuisance_trials as trials
from refine_candidates import WORK


BASE = WORK / ".tmp/nuisance_trials/polarization/trial.gpx"
OUT = WORK / ".tmp/broadening_after_polarization"
NAMES = ("add_W", "WO3_size", "Co3O4_size", "WO3_strain", "Co3O4_strain")


def run(name: str) -> dict:
    trials.BASE = BASE
    trials.OUT = OUT
    return trials.run_trial(name)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    result = {}
    for name in NAMES:
        try:
            result[name] = run(name)
            print(
                f"{name}: Rwp={result[name]['summary']['residuals']['wR']:.5f} "
                f"{result[name]['parameters']}",
                flush=True,
            )
        except Exception as exc:
            result[name] = {"error": f"{type(exc).__name__}: {exc}"}
            print(f"{name}: ERROR {exc}", flush=True)
    output = OUT / "trials.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(output, flush=True)


if __name__ == "__main__":
    main()
