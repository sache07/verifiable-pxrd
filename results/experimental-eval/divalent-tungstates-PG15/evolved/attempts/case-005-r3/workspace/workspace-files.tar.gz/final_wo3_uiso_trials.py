#!/usr/bin/env python3
"""Test parsimonious WO3 displacement models on the final structural candidate."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from GSASII import GSASIIscriptable as G2sc

import final_sensitivity as fs
from refine_candidates import WORK


BASE = WORK / ".tmp/final_combination_trials/Co_O_coordinate_U_common/trial.gpx"
OUT = WORK / ".tmp/final_wo3_uiso_trials"


def set_uiso(gpx: G2sc.G2Project, indices: tuple[int, ...], constrain: bool = True) -> None:
    gpx.index_ids()
    phase = gpx.phase("WO3")
    variables = []
    for aidx, atom in enumerate(phase.atoms()):
        atom.refinement_flags = atom.refinement_flags.replace("U", "")
        if aidx not in indices:
            continue
        atom.refinement_flags += "U"
        variable = f"0::AUiso:{aidx}"
        variables.append(variable)
        gpx.set_Controls("parmMin", 0.0001, variable)
        gpx.set_Controls("parmMax", 0.05, variable)
    if constrain and len(variables) > 1:
        gpx.add_EquivConstr(tuple(variables), reloadIdx=False)


def common(gpx: G2sc.G2Project) -> None:
    set_uiso(gpx, tuple(range(8)))


def tungsten_only(gpx: G2sc.G2Project) -> None:
    set_uiso(gpx, (0, 1))


def oxygen_only(gpx: G2sc.G2Project) -> None:
    set_uiso(gpx, tuple(range(2, 8)))


def grouped(gpx: G2sc.G2Project) -> None:
    gpx.index_ids()
    phase = gpx.phase("WO3")
    for atom in phase.atoms():
        atom.refinement_flags = atom.refinement_flags.replace("U", "") + "U"
    for indices in ((0, 1), tuple(range(2, 8))):
        variables = tuple(f"0::AUiso:{aidx}" for aidx in indices)
        for variable in variables:
            gpx.set_Controls("parmMin", 0.0001, variable)
            gpx.set_Controls("parmMax", 0.05, variable)
        gpx.add_EquivConstr(variables, reloadIdx=False)


def run(label: str, setup: Callable[[G2sc.G2Project], None]) -> dict:
    directory = OUT / label
    directory.mkdir(parents=True, exist_ok=True)
    project = directory / "trial.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(project))
    setup(gpx)
    gpx.set_Controls("cycles", 16)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    gpx.refine(printFile=str(directory / "first.lst"))
    gpx.save()
    gpx = G2sc.G2Project(str(project))
    gpx.refine(printFile=str(directory / "replay.lst"))
    gpx.save()
    result = fs.extra_summary(gpx)
    result["frozen"] = [str(item) for item in gpx.data["Controls"]["data"]["parmFrozen"].get("FrozenList", [])]
    cov = gpx.data["Covariance"]["data"]
    result["chisq"] = cov.get("Rvals", {}).get("chisq")
    return result


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    result = {}
    for label, setup in (
        ("WO3_U_common", common),
        ("WO3_U_tungsten", tungsten_only),
        ("WO3_U_oxygen", oxygen_only),
        ("WO3_U_grouped", grouped),
    ):
        try:
            result[label] = run(label, setup)
            trial = result[label]
            print(
                f"{label}: Rwp={trial['residuals']['wR']:.6f}, "
                f"WO3={100 * trial['mass_fractions']['WO3']['value']:.3f} wt%, "
                f"p={trial['polarization']:.5f}, maxshift={trial['max_shift_over_sigma']:.3f}",
                flush=True,
            )
        except Exception as exc:
            result[label] = {"error": f"{type(exc).__name__}: {exc}"}
            print(f"{label}: ERROR {type(exc).__name__}: {exc}", flush=True)
    output = OUT / "trials.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(output, flush=True)


if __name__ == "__main__":
    main()
