#!/usr/bin/env python3
"""Run the CoWO4 prototype watch list against the final two-phase candidate."""

from __future__ import annotations

from GSASII import GSASIIscriptable as G2sc

import challenge_watchlist as watch
from refine_candidates import WORK


def main() -> None:
    watch.BASE = WORK / ".tmp/final_combination_trials/Co_O_coordinate_U_common/trial.gpx"
    watch.OUT = WORK / ".tmp/final_watchlist_rechallenge"
    watch.OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    watch.main()


if __name__ == "__main__":
    main()
