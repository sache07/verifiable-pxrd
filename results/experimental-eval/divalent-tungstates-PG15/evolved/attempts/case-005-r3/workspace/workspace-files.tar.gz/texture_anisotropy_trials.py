#!/usr/bin/env python3
"""Test symmetry-distinct texture axes and uniaxial WO3 strain directions."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_candidates import WORK, summarize


BASE = WORK / ".tmp/broadening_after_polarization/WO3_strain/trial.gpx"
OUT = WORK / ".tmp/texture_anisotropy"

WO3_AXES = ([1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0], [1, 0, 1], [0, 1, 1], [1, 1, 1])
CO3O4_AXES = ([1, 0, 0], [1, 1, 0], [1, 1, 1])
STRAIN_AXES = ([1, 0, 0], [0, 1, 0], [0, 0, 1])


def axis_text(axis: list[int] | tuple[int, int, int]) -> str:
    return "".join(str(i) for i in axis)


def configure(gpx: G2sc.G2Project, kind: str, phase_name: str, axis: list[int]) -> None:
    hist = gpx.histogram(0)
    phase = gpx.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    if kind == "texture":
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        gpx.set_Controls("parmMin", 0.1, f"{phase.id}:0:MD")
        gpx.set_Controls("parmMax", 10.0, f"{phase.id}:0:MD")
    elif kind == "strain":
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1] = [2709.0, 2709.0, 1.0]
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = list(axis)


def extra(gpx: G2sc.G2Project, phase_name: str) -> dict:
    hist = gpx.histogram(0)
    hap = gpx.phase(phase_name).data["Histograms"][hist.name]
    cov = gpx.data["Covariance"]["data"]
    return {
        "preferred_orientation": hap["Pref.Ori."],
        "mustrain": hap["Mustrain"],
        "covariance_message": cov.get("Rvals", {}).get("msg"),
    }


def run(label: str, kind: str, phase_name: str, axis: list[int]) -> dict:
    trial_dir = OUT / label
    trial_dir.mkdir(parents=True, exist_ok=True)
    project = trial_dir / "trial.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(project))
    configure(gpx, kind, phase_name, axis)
    gpx.set_Controls("cycles", 8)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    gpx.refine(printFile=str(trial_dir / "fit.lst"))
    gpx.save()
    gpx = G2sc.G2Project(str(project))
    gpx.refine(printFile=str(trial_dir / "replay.lst"))
    gpx.save()
    return {"summary": summarize(gpx), "extra": extra(gpx, phase_name)}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    specs = []
    for axis in WO3_AXES:
        specs.append((f"WO3_texture_{axis_text(axis)}", "texture", "WO3", list(axis)))
    for axis in CO3O4_AXES:
        specs.append((f"Co3O4_texture_{axis_text(axis)}", "texture", "Co3O4", list(axis)))
    for axis in STRAIN_AXES:
        specs.append((f"WO3_uniaxial_strain_{axis_text(axis)}", "strain", "WO3", list(axis)))

    result = {}
    for label, kind, phase_name, axis in specs:
        try:
            result[label] = run(label, kind, phase_name, axis)
            summary = result[label]["summary"]
            print(
                f"{label}: Rwp={summary['residuals']['wR']:.5f}, "
                f"fractions={summary['mass_fractions']}, "
                f"extra={result[label]['extra']}",
                flush=True,
            )
        except Exception as exc:
            result[label] = {"error": f"{type(exc).__name__}: {exc}"}
            print(f"{label}: ERROR {exc}", flush=True)
    output = OUT / "trials.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(output, flush=True)


if __name__ == "__main__":
    main()
