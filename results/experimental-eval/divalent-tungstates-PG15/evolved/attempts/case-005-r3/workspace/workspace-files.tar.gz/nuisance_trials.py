#!/usr/bin/env python3
"""One-at-a-time baseline/profile/phase-broadening trials on the selected model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from refine_candidates import WORK, summarize


BASE = WORK / ".tmp/top_models/wo3_mono_2311041/model.gpx"
OUT = WORK / ".tmp/nuisance_trials"
TRIALS = (
    "polarization",
    "asymmetry",
    "add_W",
    "WO3_size",
    "Co3O4_size",
    "WO3_strain",
    "Co3O4_strain",
)


def configure(gpx: G2sc.G2Project, trial: str) -> None:
    hist = gpx.histogram(0)
    if trial == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
    elif trial == "asymmetry":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        gpx.set_Controls("parmMin", 0.0005, ":0:SH/L")
        gpx.set_Controls("parmMax", 1.0, ":0:SH/L")
    elif trial == "add_W":
        hist.InstrumentParameters["W"][1] = 10.0
        hist.set_refinements({"Instrument Parameters": ["W"]})
        gpx.set_Controls("parmMin", 0.0, ":0:W")
    else:
        phase_name, kind = trial.split("_")
        phase = gpx.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        if kind == "size":
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1.0
            hap["Size"][2] = [True, False, False]
        elif kind == "strain":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 300.0
            hap["Mustrain"][2] = [True, False, False]


def parameters(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    out = {
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "SH_over_L": hist.InstrumentParameters["SH/L"][1],
        "U": hist.InstrumentParameters["U"][1],
        "W": hist.InstrumentParameters["W"][1],
        "X": hist.InstrumentParameters["X"][1],
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        out[f"{phase.name}_size_um"] = hap["Size"][1][0]
        out[f"{phase.name}_microstrain"] = hap["Mustrain"][1][0]
    return out


def run_trial(trial: str) -> dict:
    trial_dir = OUT / trial
    trial_dir.mkdir(parents=True, exist_ok=True)
    project = trial_dir / "trial.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(project))
    configure(gpx, trial)
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    gpx.refine(printFile=str(trial_dir / "fit.lst"))
    gpx.save()
    gpx = G2sc.G2Project(str(project))
    gpx.refine(printFile=str(trial_dir / "replay.lst"))
    gpx.save()
    return {"summary": summarize(gpx), "parameters": parameters(gpx)}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    result = {}
    for trial in TRIALS:
        try:
            result[trial] = run_trial(trial)
            print(
                f"{trial}: Rwp={result[trial]['summary']['residuals']['wR']:.5f} "
                f"{result[trial]['parameters']}",
                flush=True,
            )
        except Exception as exc:
            result[trial] = {"error": f"{type(exc).__name__}: {exc}"}
            print(f"{trial}: ERROR {exc}", flush=True)
    output = OUT / "trials.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(output, flush=True)


if __name__ == "__main__":
    main()
