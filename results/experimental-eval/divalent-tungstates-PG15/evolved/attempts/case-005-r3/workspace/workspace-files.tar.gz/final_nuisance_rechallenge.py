#!/usr/bin/env python3
"""Re-challenge nuisance and structural terms under the selected smooth background."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from GSASII import GSASIIscriptable as G2sc

import final_sensitivity as fs
from refine_candidates import WORK


BASE = WORK / ".tmp/final_profile_trials/background_9/trial.gpx"
OUT = WORK / ".tmp/final_nuisance_rechallenge"


def fixed_polarization(gpx: G2sc.G2Project) -> None:
    gpx.histogram(0).InstrumentParameters["Polariz."][1:] = [1.0, False]


def add_w(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.InstrumentParameters["W"][1:] = [2.0, True]
    gpx.set_Controls("parmMin", 0.0, ":0:W")


def asymmetry(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.InstrumentParameters["SH/L"][1:] = [0.002, True]
    gpx.set_Controls("parmMin", 0.0005, ":0:SH/L")
    gpx.set_Controls("parmMax", 1.0, ":0:SH/L")


def roughness(gpx: G2sc.G2Project) -> None:
    fs.roughness(gpx)


def hap(gpx: G2sc.G2Project, phase_name: str) -> dict:
    hist = gpx.histogram(0)
    return gpx.phase(phase_name).data["Histograms"][hist.name]


def wo3_no_strain(gpx: G2sc.G2Project) -> None:
    data = hap(gpx, "WO3")["Mustrain"]
    data[0] = "isotropic"
    data[1] = [0.0, 0.0, 1.0]
    data[2] = [False, False, False]


def wo3_isotropic_strain(gpx: G2sc.G2Project) -> None:
    data = hap(gpx, "WO3")["Mustrain"]
    data[0] = "isotropic"
    data[1] = [2700.0, 0.0, 1.0]
    data[2] = [True, False, False]
    gpx.set_Controls("parmMin", 0.0, "0:0:Mustrain;i")


def phase_size(phase_name: str) -> Callable[[G2sc.G2Project], None]:
    def setup(gpx: G2sc.G2Project) -> None:
        data = hap(gpx, phase_name)["Size"]
        data[0] = "isotropic"
        data[1] = [1.0, 1.0, 1.0]
        data[2] = [True, False, False]
        pidx = gpx.phase(phase_name).id
        gpx.set_Controls("parmMin", 0.01, f"{pidx}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, f"{pidx}:0:Size;i")

    return setup


def co3o4_strain(gpx: G2sc.G2Project) -> None:
    data = hap(gpx, "Co3O4")["Mustrain"]
    data[0] = "isotropic"
    data[1] = [300.0, 0.0, 1.0]
    data[2] = [True, False, False]
    gpx.set_Controls("parmMin", 0.0, "1:0:Mustrain;i")


def run(label: str, setup: Callable[[G2sc.G2Project], None]) -> dict:
    directory = OUT / label
    directory.mkdir(parents=True, exist_ok=True)
    project = directory / "trial.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(project))
    setup(gpx)
    gpx.set_Controls("cycles", 16)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    gpx.refine(printFile=str(directory / "first.lst"))
    gpx.save()
    gpx = G2sc.G2Project(str(project))
    gpx.refine(printFile=str(directory / "replay.lst"))
    gpx.save()
    result = fs.extra_summary(gpx)
    hist = gpx.histogram(0)
    result["WO3_HAP"] = gpx.phase("WO3").data["Histograms"][hist.name]
    result["Co3O4_HAP"] = gpx.phase("Co3O4").data["Histograms"][hist.name]
    result["frozen"] = [str(item) for item in gpx.data["Controls"]["data"]["parmFrozen"].get("FrozenList", [])]
    return result


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    trials: list[tuple[str, Callable[[G2sc.G2Project], None]]] = [
        ("polarization_fixed_1", fixed_polarization),
        ("add_W", add_w),
        ("asymmetry", asymmetry),
        ("surface_roughness", roughness),
        ("WO3_no_strain", wo3_no_strain),
        ("WO3_isotropic_strain", wo3_isotropic_strain),
        ("WO3_size_with_strain", phase_size("WO3")),
        ("Co3O4_size", phase_size("Co3O4")),
        ("Co3O4_strain", co3o4_strain),
        ("grouped_uiso_WO3", fs.grouped_uiso(("WO3",))),
        ("grouped_uiso_Co3O4", fs.grouped_uiso(("Co3O4",))),
        ("grouped_uiso_both", fs.grouped_uiso(("WO3", "Co3O4"))),
    ]
    result = {}
    for label, setup in trials:
        try:
            result[label] = run(label, setup)
            trial = result[label]
            print(
                f"{label}: Rwp={trial['residuals']['wR']:.6f}, "
                f"WO3={100 * trial['mass_fractions']['WO3']['value']:.3f} wt%, "
                f"p={trial['polarization']:.5f}, maxshift={trial['max_shift_over_sigma']:.3f}",
                flush=True,
            )
        except Exception as exc:
            result[label] = {"error": f"{type(exc).__name__}: {exc}"}
            print(f"{label}: ERROR {type(exc).__name__}: {exc}", flush=True)
    output = OUT / "trials.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(output, flush=True)


if __name__ == "__main__":
    main()
