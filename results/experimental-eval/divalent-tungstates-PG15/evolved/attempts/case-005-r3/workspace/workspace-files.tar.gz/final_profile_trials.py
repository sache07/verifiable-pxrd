#!/usr/bin/env python3
"""Profile and background challenges around the eight-term provisional model."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from GSASII import GSASIIscriptable as G2sc

import final_sensitivity as fs
from refine_candidates import WORK


BASE = WORK / ".tmp/final_sensitivity/background_8/trial.gpx"
OUT = WORK / ".tmp/final_profile_trials"


def background_order(ncoeff: int) -> Callable[[G2sc.G2Project], None]:
    def setup(gpx: G2sc.G2Project) -> None:
        gpx.histogram(0).set_refinements(
            {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": ncoeff}}
        )

    return setup


def run(label: str, setup: Callable[[G2sc.G2Project], None]) -> dict:
    directory = OUT / label
    directory.mkdir(parents=True, exist_ok=True)
    project = directory / "trial.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(project))
    setup(gpx)
    gpx.set_Controls("cycles", 16)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    gpx.refine(printFile=str(directory / "first.lst"))
    gpx.save()
    gpx = G2sc.G2Project(str(project))
    gpx.refine(printFile=str(directory / "replay.lst"))
    gpx.save()
    result = fs.extra_summary(gpx)
    cov = gpx.data["Covariance"]["data"]
    sigmas = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    result["background_sigmas"] = [
        sigmas.get(f":0:Back;{i}")
        for i in range(gpx.histogram(0).Background[0][2])
    ]
    result["chisq"] = cov.get("Rvals", {}).get("chisq")
    result["gof"] = cov.get("Rvals", {}).get("GOF")
    result["nobs"] = cov.get("Rvals", {}).get("Nobs")
    return result


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    result = {}
    for order in (7, 9, 10, 12):
        label = f"background_{order}"
        try:
            result[label] = run(label, background_order(order))
            trial = result[label]
            last = trial["background"][-1]
            last_su = trial["background_sigmas"][-1]
            print(
                f"{label}: Rwp={trial['residuals']['wR']:.6f}, "
                f"chi2={trial['chisq']:.1f}, p={trial['polarization']:.5f}, "
                f"last={last:.3f}({last_su:.3f})",
                flush=True,
            )
        except Exception as exc:
            result[label] = {"error": f"{type(exc).__name__}: {exc}"}
            print(f"{label}: ERROR {type(exc).__name__}: {exc}", flush=True)
    output = OUT / "background_orders.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(output, flush=True)


if __name__ == "__main__":
    main()
