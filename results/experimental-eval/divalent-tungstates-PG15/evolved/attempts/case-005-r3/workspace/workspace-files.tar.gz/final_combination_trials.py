#!/usr/bin/env python3
"""Final structural/profile combinations after accepting a nonzero W term."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from GSASII import GSASIIscriptable as G2sc

import final_sensitivity as fs
from refine_candidates import WORK


BASE = WORK / ".tmp/final_nuisance_rechallenge/add_W/trial.gpx"
OUT = WORK / ".tmp/final_combination_trials"


def compose(*functions: Callable[[G2sc.G2Project], None]) -> Callable[[G2sc.G2Project], None]:
    def setup(gpx: G2sc.G2Project) -> None:
        for function in functions:
            function(gpx)

    return setup


def background_order(ncoeff: int) -> Callable[[G2sc.G2Project], None]:
    def setup(gpx: G2sc.G2Project) -> None:
        gpx.histogram(0).set_refinements(
            {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": ncoeff}}
        )

    return setup


def fixed_polarization(gpx: G2sc.G2Project) -> None:
    gpx.histogram(0).InstrumentParameters["Polariz."][1:] = [1.0, False]


def wo3_size(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    data = gpx.phase("WO3").data["Histograms"][hist.name]["Size"]
    data[0] = "isotropic"
    data[1] = [1.0, 1.0, 1.0]
    data[2] = [True, False, False]
    gpx.set_Controls("parmMin", 0.01, "0:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, "0:0:Size;i")


def co_oxygen_coordinate(gpx: G2sc.G2Project) -> None:
    atom = gpx.phase("Co3O4").atom("O")
    atom.refinement_flags = atom.refinement_flags.replace("X", "") + "X"


def co_uiso_common(gpx: G2sc.G2Project) -> None:
    gpx.index_ids()
    phase = gpx.phase("Co3O4")
    variables = []
    for aidx, atom in enumerate(phase.atoms()):
        atom.refinement_flags = atom.refinement_flags.replace("U", "") + "U"
        variable = f"1::AUiso:{aidx}"
        variables.append(variable)
        gpx.set_Controls("parmMin", 0.0001, variable)
        gpx.set_Controls("parmMax", 0.05, variable)
    gpx.add_EquivConstr(tuple(variables), reloadIdx=False)


def co_uiso_cations(gpx: G2sc.G2Project) -> None:
    gpx.index_ids()
    phase = gpx.phase("Co3O4")
    variables = []
    for aidx in (0, 1):
        atom = phase.atoms()[aidx]
        atom.refinement_flags = atom.refinement_flags.replace("U", "") + "U"
        variable = f"1::AUiso:{aidx}"
        variables.append(variable)
        gpx.set_Controls("parmMin", 0.0001, variable)
        gpx.set_Controls("parmMax", 0.05, variable)
    phase.atom("O").refinement_flags = phase.atom("O").refinement_flags.replace("U", "")
    gpx.add_EquivConstr(tuple(variables), reloadIdx=False)


def co_uiso_oxygen(gpx: G2sc.G2Project) -> None:
    gpx.index_ids()
    phase = gpx.phase("Co3O4")
    for atom in phase.atoms()[:2]:
        atom.refinement_flags = atom.refinement_flags.replace("U", "")
    atom = phase.atom("O")
    atom.refinement_flags = atom.refinement_flags.replace("U", "") + "U"
    gpx.set_Controls("parmMin", 0.0001, "1::AUiso:2")
    gpx.set_Controls("parmMax", 0.05, "1::AUiso:2")


def co_uiso_grouped(gpx: G2sc.G2Project) -> None:
    fs.grouped_uiso(("Co3O4",))(gpx)


def run(label: str, setup: Callable[[G2sc.G2Project], None]) -> dict:
    directory = OUT / label
    directory.mkdir(parents=True, exist_ok=True)
    project = directory / "trial.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(project))
    setup(gpx)
    gpx.set_Controls("cycles", 16)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    gpx.refine(printFile=str(directory / "first.lst"))
    gpx.save()
    gpx = G2sc.G2Project(str(project))
    gpx.refine(printFile=str(directory / "replay.lst"))
    gpx.save()
    result = fs.extra_summary(gpx)
    result["Co3O4_atoms"] = {
        atom.label: {
            "coordinates": atom.coordinates,
            "uiso": atom.uiso,
            "flags": atom.refinement_flags,
        }
        for atom in gpx.phase("Co3O4").atoms()
    }
    hist = gpx.histogram(0)
    result["WO3_size"] = gpx.phase("WO3").data["Histograms"][hist.name]["Size"]
    result["frozen"] = [str(item) for item in gpx.data["Controls"]["data"]["parmFrozen"].get("FrozenList", [])]
    cov = gpx.data["Covariance"]["data"]
    result["chisq"] = cov.get("Rvals", {}).get("chisq")
    return result


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    trials: list[tuple[str, Callable[[G2sc.G2Project], None]]] = [
        ("background_8", background_order(8)),
        ("background_10", background_order(10)),
        ("polarization_fixed_1", fixed_polarization),
        ("WO3_size", wo3_size),
        ("Co_O_coordinate", co_oxygen_coordinate),
        ("Co_U_common", co_uiso_common),
        ("Co_U_cations", co_uiso_cations),
        ("Co_U_oxygen", co_uiso_oxygen),
        ("Co_U_grouped", co_uiso_grouped),
        ("Co_O_coordinate_U_common", compose(co_oxygen_coordinate, co_uiso_common)),
        ("Co_O_coordinate_U_cations", compose(co_oxygen_coordinate, co_uiso_cations)),
        ("Co_O_coordinate_U_grouped", compose(co_oxygen_coordinate, co_uiso_grouped)),
    ]
    result = {}
    for label, setup in trials:
        try:
            result[label] = run(label, setup)
            trial = result[label]
            oxygen = trial["Co3O4_atoms"]["O"]
            print(
                f"{label}: Rwp={trial['residuals']['wR']:.6f}, "
                f"WO3={100 * trial['mass_fractions']['WO3']['value']:.3f} wt%, "
                f"p={trial['polarization']:.5f}, O_x={oxygen['coordinates'][0]:.6f}, "
                f"maxshift={trial['max_shift_over_sigma']:.3f}",
                flush=True,
            )
        except Exception as exc:
            result[label] = {"error": f"{type(exc).__name__}: {exc}"}
            print(f"{label}: ERROR {type(exc).__name__}: {exc}", flush=True)
    output = OUT / "trials.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(output, flush=True)


if __name__ == "__main__":
    main()
