#!/usr/bin/env python3
"""Re-evaluate triclinic WO3 under the accepted physical nuisance model."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc

from refine_candidates import WORK, summarize


BASE = WORK / ".tmp/top_models/wo3_triclinic_2106293/model.gpx"
OUT = WORK / ".tmp/triclinic_finalmodel"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    project = OUT / "model.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(project))
    hist = gpx.histogram(0)
    gpx.set_Controls("cycles", 12)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6

    hist.InstrumentParameters["Polariz."][1] = 0.94
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    gpx.set_Controls("parmMin", 0.0, ":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, ":0:Polariz.")
    gpx.refine(printFile=str(OUT / "stage1_polarization.lst"))

    wo3 = gpx.phase("WO3")
    hap = wo3.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [1000.0, 0.0, 1.0]
    hap["Mustrain"][2] = [True, False, False]
    gpx.refine(printFile=str(OUT / "stage2_isotropic_strain.lst"))

    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1] = [hap["Mustrain"][1][0], hap["Mustrain"][1][0], 1.0]
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = [0, 1, 0]
    gpx.refine(printFile=str(OUT / "stage3_uniaxial_strain.lst"))

    gpx.save()
    gpx = G2sc.G2Project(str(project))
    gpx.refine(printFile=str(OUT / "replay.lst"))
    gpx.save()

    result = summarize(gpx)
    h = gpx.histogram(0)
    result["WO3_mustrain"] = gpx.phase("WO3").data["Histograms"][h.name]["Mustrain"]
    result["covariance_message"] = gpx.data["Covariance"]["data"].get("Rvals", {}).get("msg")
    (OUT / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
