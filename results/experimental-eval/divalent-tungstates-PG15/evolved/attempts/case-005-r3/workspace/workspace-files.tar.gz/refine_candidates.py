#!/usr/bin/env python3
"""Compare physically plausible phase records under one restrained GSAS-II model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = WORK / ".tmp" / "candidate_models"

BACKGROUND = [
    2896.6649746725293,
    95.69834791719762,
    42.000773108607554,
    -87.6988703997049,
    69.45799420775246,
    -54.91942386759169,
]

MODELS = {
    "wo3_mono_1528915__co3o4_9005896": [
        ("WO3", COD / "1/52/89/1528915.cif"),
        ("Co3O4", COD / "9/00/58/9005896.cif"),
    ],
    "wo3_mono_altsetting_2311041__co3o4_9005896": [
        ("WO3", COD / "2/31/10/2311041.cif"),
        ("Co3O4", COD / "9/00/58/9005896.cif"),
    ],
    "wo3_triclinic_2106293__co3o4_9005896": [
        ("WO3", COD / "2/10/62/2106293.cif"),
        ("Co3O4", COD / "9/00/58/9005896.cif"),
    ],
    "wo3_orthorhombic_2107312__co3o4_9005896": [
        ("WO3", COD / "2/10/73/2107312.cif"),
        ("Co3O4", COD / "9/00/58/9005896.cif"),
    ],
    "wo3_smallcell_mono_1563541__co3o4_9005896": [
        ("WO3", COD / "1/56/35/1563541.cif"),
        ("Co3O4", COD / "9/00/58/9005896.cif"),
    ],
    "wo3_mono_1528915__co3o4_old_5910031": [
        ("WO3", COD / "1/52/89/1528915.cif"),
        ("Co3O4", COD / "5/91/00/5910031.cif"),
    ],
}


def neutralize_hap(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [1.0, True]
    # 10 micrometres is the GSAS-II upper/neutral crystallite-size limit.
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def summarize(gpx: G2sc.G2Project) -> dict:
    hist = gpx.histogram(0)
    cov = gpx.data.get("Covariance", {}).get("data", {})
    cells = {}
    scales = {}
    for phase in gpx.phases():
        cells[phase.name] = phase.get_cell()
        scales[phase.name] = phase.HAPvalue("Scale")
    return {
        "residuals": hist.residuals,
        "mass_fractions": {
            key: {"value": val[0], "sigma": val[1]}
            for key, val in hist.ComputeMassFracs().items()
        },
        "cells": cells,
        "phase_scales": scales,
        "profile": {
            key: hist.InstrumentParameters[key][1]
            for key in ("U", "V", "W", "X", "Y", "SH/L")
        },
        "shift_micrometres": hist.SampleParameters["Shift"][0],
        "background": hist.Background[0][3:],
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
    }


def refine_model(label: str, phase_files: list[tuple[str, Path]]) -> dict:
    model_dir = OUT / label
    model_dir.mkdir(parents=True, exist_ok=True)
    project_path = model_dir / "model.gpx"
    gpx = G2sc.G2Project(newgpx=str(project_path))
    hist = gpx.add_powder_histogram(
        str(WORK / "inputs" / "pattern.csv"),
        str(WORK / "instrument.instprm"),
        fmthint="comma",
    )
    for phase_name, phase_file in phase_files:
        phase = gpx.add_phase(
            str(phase_file),
            phasename=phase_name,
            histograms=[hist],
            fmthint="CIF",
        )
        neutralize_hap(phase, hist.name)
        phase.set_refinements({"Cell": False})

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": BACKGROUND,
            },
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["U", "X"],
        }
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-583.0, True]
    for key, value, refine in (
        ("U", 182.0, True),
        ("V", 0.0, False),
        ("W", 0.0, False),
        ("X", 13.0, True),
        ("Y", 0.0, False),
        ("SH/L", 0.002, False),
    ):
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = refine

    gpx.set_Controls("cycles", 10)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    gpx.set_Controls("parmMin", 0.0, ":0:U")
    gpx.set_Controls("parmMin", 0.0, ":0:X")
    for phase_index, _phase in enumerate(gpx.phases()):
        gpx.set_Controls("parmMin", 1e-12, f"{phase_index}:0:Scale")

    # Re-establish common background, scales, geometry and profile first.
    gpx.refine(printFile=str(model_dir / "stage1.lst"))
    # Cell release follows scale convergence.
    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    gpx.refine(printFile=str(model_dir / "stage2.lst"))
    # Save/reopen and replay the complete range with no model changes.
    gpx.save()
    gpx = G2sc.G2Project(str(project_path))
    gpx.refine(printFile=str(model_dir / "replay.lst"))
    gpx.save()
    return summarize(gpx)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    results = {}
    for label, phase_files in MODELS.items():
        try:
            results[label] = refine_model(label, phase_files)
            rwp = results[label]["residuals"].get("wR")
            print(f"{label}: Rwp={rwp:.5f}")
        except Exception as exc:  # preserve failures for audit
            results[label] = {"error": f"{type(exc).__name__}: {exc}"}
            print(f"{label}: ERROR {exc}")
    output = OUT / "comparison.json"
    output.write_text(json.dumps(results, indent=2) + "\n")
    print(output)


if __name__ == "__main__":
    main()
