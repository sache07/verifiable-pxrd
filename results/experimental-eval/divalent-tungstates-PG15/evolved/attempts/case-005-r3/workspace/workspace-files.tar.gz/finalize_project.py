#!/usr/bin/env python3
"""Replay the accepted GSAS-II model and export the exact submission artifacts."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from refine_candidates import WORK


BASE = WORK / ".tmp/final_combination_trials/Co_O_coordinate_U_common/trial.gpx"
PROJECT = WORK / "final.gpx"
CIFS = {"WO3": WORK / "phase_WO3.cif", "Co3O4": WORK / "phase_Co3O4.cif"}
FIT = WORK / "fit.csv"


def enforce_pruned_model(gpx: G2sc.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = True
    for key in ("Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key] = [0.0, False]

    for key in hist.InstrumentParameters:
        if len(hist.InstrumentParameters[key]) > 2:
            hist.InstrumentParameters[key][2] = key in ("Polariz.", "U", "W", "X")
    hist.InstrumentParameters["V"][1] = 0.0
    hist.InstrumentParameters["Y"][1] = 0.0
    hist.InstrumentParameters["SH/L"][1] = 0.002
    hist.InstrumentParameters["Zero"][1] = 0.0
    hist.Background[0][0] = "chebyschev-1"
    hist.Background[0][1] = True
    hist.Background[0][2] = 9

    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True}, [hist])
        hdata = phase.data["Histograms"][hist.name]
        hdata["Pref.Ori."][0] = "MD"
        hdata["Pref.Ori."][1] = 1.0
        hdata["Pref.Ori."][2] = False
        hdata["Size"][0] = "isotropic"
        hdata["Size"][1] = [10.0, 10.0, 1.0]
        hdata["Size"][2] = [False, False, False]
        hdata["HStrain"][0] = [0.0 for _ in hdata["HStrain"][0]]
        hdata["HStrain"][1] = [False for _ in hdata["HStrain"][1]]
        hdata["Extinction"] = [0.0, False]
        hdata["Babinet"]["BabA"] = [0.0, False]
        hdata["Babinet"]["BabU"] = [0.0, False]

    wo3 = gpx.phase("WO3")
    for atom in wo3.atoms():
        atom.refinement_flags = ""
        atom.uiso = 0.01
    wo_hap = wo3.data["Histograms"][hist.name]
    wo_hap["Mustrain"][0] = "uniaxial"
    wo_hap["Mustrain"][2] = [True, True, False]
    wo_hap["Mustrain"][3] = [0, 1, 0]

    co3o4 = gpx.phase("Co3O4")
    co3o4.atom("Co1").refinement_flags = "U"
    co3o4.atom("Co2").refinement_flags = "U"
    co3o4.atom("O").refinement_flags = "XU"
    co_hap = co3o4.data["Histograms"][hist.name]
    co_hap["Mustrain"][0] = "isotropic"
    co_hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    co_hap["Mustrain"][2] = [False, False, False]

    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.set_Controls("cycles", 20)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6


def parameter(gpx: G2sc.G2Project, name: str) -> dict:
    cov = gpx.data["Covariance"]["data"]
    values = dict(zip(cov.get("varyList", []), cov.get("variables", [])))
    sigmas = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    return {"value": float(values[name]), "esd": float(sigmas[name])}


def main() -> None:
    G2sc.SetPrintLevel("warn")
    gpx = G2sc.G2Project(str(BASE), newgpx=str(PROJECT))
    enforce_pruned_model(gpx)
    gpx.refine(printFile=str(WORK / "final.lst"))
    gpx.save()

    # Required save/reopen/replay check over the full measured range.
    gpx = G2sc.G2Project(str(PROJECT))
    gpx.refine(printFile=str(WORK / "final_replay.lst"))
    gpx.save()

    hist = gpx.histogram(0)
    for phase_name, path in CIFS.items():
        gpx.phase(phase_name).export_CIF(str(path))

    x, observed, weights, calculated, background, difference = [
        np.asarray(array, dtype=float) for array in hist.data["data"][1][:6]
    ]
    with FIT.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "background_counts",
                "difference_obs_minus_calc_counts",
                "weight_inverse_counts",
            ]
        )
        for row in zip(x, observed, calculated, background, difference, weights):
            writer.writerow([repr(float(value)) for value in row])

    covariance = gpx.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    fractions = hist.ComputeMassFracs()
    cells = {}
    for phase in gpx.phases():
        cell, cell_esd = phase.get_cell_and_esd()
        cells[phase.name] = {"value": cell, "esd": cell_esd}
    summary = {
        "project": str(PROJECT.relative_to(WORK)),
        "cifs": {key: str(path.relative_to(WORK)) for key, path in CIFS.items()},
        "fit_csv": str(FIT.relative_to(WORK)),
        "fit_statistics": {
            "Rwp_percent": hist.residuals["wR"],
            "Rp_percent": hist.residuals["R"],
            "Rexp_percent": hist.residuals["wRmin"],
            "Rb_percent": hist.residuals["Rb"],
            "wRb_percent": hist.residuals["wRb"],
            "chi_squared": rvals["chisq"],
            "n_observations": rvals["Nobs"],
            "n_variables": rvals["Nvars"],
            "degrees_of_freedom": rvals["Nobs"] - rvals["Nvars"],
            "reduced_chi_squared": rvals["chisq"] / (rvals["Nobs"] - rvals["Nvars"]),
            "goodness_of_fit": rvals["GOF"],
            "converged": rvals["converged"],
            "maximum_shift_over_esd": rvals["Max shft/sig"],
            "covariance_message": rvals.get("msg"),
        },
        "fractions": {
            phase: {"value": value, "esd": esd} for phase, (value, esd) in fractions.items()
        },
        "cells": cells,
        "parameters": {
            "polarization": parameter(gpx, ":0:Polariz."),
            "profile_U": parameter(gpx, ":0:U"),
            "profile_W": parameter(gpx, ":0:W"),
            "profile_X": parameter(gpx, ":0:X"),
            "specimen_shift_micrometres": parameter(gpx, ":0:Shift"),
            "WO3_microstrain_equatorial": parameter(gpx, "0:0:Mustrain;i"),
            "WO3_microstrain_axial": parameter(gpx, "0:0:Mustrain;a"),
            "Co3O4_common_Uiso_angstrom_squared": parameter(gpx, "1::AUiso:0"),
            "Co3O4_oxygen_coordinate_increment": parameter(gpx, "1::dAx:2"),
        },
        "Co3O4_oxygen_x": gpx.phase("Co3O4").atom("O").coordinates[0],
        "n_profile_points": len(x),
        "difference_identity_max_abs": float(np.max(np.abs(difference - (observed - calculated)))),
        "fraction_sum": float(sum(value for value, _esd in fractions.values())),
    }
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
