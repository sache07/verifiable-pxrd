#!/usr/bin/env python3
"""Profile the objective versus fixed effective polarization."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc

from refine_candidates import WORK, summarize


BASE = WORK / ".tmp/conventional_model/model.gpx"
OUT = WORK / ".tmp/polarization_grid"
VALUES = (0.50, 0.60, 0.70, 0.80, 0.90, 0.94, 0.98, 1.00)


def run(value: float) -> dict:
    label = f"p{value:.2f}"
    trial_dir = OUT / label
    trial_dir.mkdir(parents=True, exist_ok=True)
    path = trial_dir / "trial.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(path))
    hist = gpx.histogram(0)
    hist.InstrumentParameters["Polariz."][1] = value
    hist.InstrumentParameters["Polariz."][2] = False
    gpx.set_Controls("cycles", 10)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    gpx.refine(printFile=str(trial_dir / "fit.lst"))
    gpx.save()
    gpx = G2sc.G2Project(str(path))
    gpx.refine(printFile=str(trial_dir / "replay.lst"))
    gpx.save()
    result = summarize(gpx)
    result["polarization"] = value
    result["mustrain"] = gpx.phase("WO3").data["Histograms"][gpx.histogram(0).name]["Mustrain"]
    return result


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    G2sc.SetPrintLevel("warn")
    result = {}
    for value in VALUES:
        try:
            result[f"{value:.2f}"] = run(value)
            r = result[f"{value:.2f}"]
            print(
                f"P={value:.2f}: Rwp={r['residuals']['wR']:.5f}, "
                f"fractions={r['mass_fractions']}",
                flush=True,
            )
        except Exception as exc:
            result[f"{value:.2f}"] = {"error": f"{type(exc).__name__}: {exc}"}
            print(f"P={value:.2f}: ERROR {exc}", flush=True)
    output = OUT / "grid.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(output, flush=True)


if __name__ == "__main__":
    main()
