#!/usr/bin/env python3
"""Replay, save, and export the final GSAS-II phase model and profile."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
SOURCE = WORK / "strict_inventory5_exact.gpx"
FINAL = WORK / "final.gpx"

PHASES = {
    "WO3_mono_2311041": {
        "name": "monoclinic WO3",
        "formula": "WO3",
        "cif": "phase_WO3_monoclinic.cif",
        "confidence": "high",
    },
    "beta_MnO2_1514232": {
        "name": "beta-MnO2 (pyrolusite)",
        "formula": "MnO2",
        "cif": "phase_beta_MnO2.cif",
        "confidence": "high",
    },
    "Mn2O3_bixbyite_1514230": {
        "name": "Mn2O3 (bixbyite)",
        "formula": "Mn2O3",
        "cif": "phase_Mn2O3_bixbyite.cif",
        "confidence": "moderate",
    },
    "watch_MnWO4_exact_1520200": {
        "name": "MnWO4 (wolframite-type, trace)",
        "formula": "MnWO4",
        "cif": "phase_MnWO4_wolframite_trace.cif",
        "confidence": "tentative",
    },
    "watch_MnOOH_manganite_9009774": {
        "name": "gamma-MnOOH (manganite)",
        "formula": "MnOOH",
        "cif": "phase_gamma_MnOOH_manganite.cif",
        "confidence": "moderate",
    },
}


def replay_final() -> G2sc.G2Project:
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(FINAL))
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.set_Controls("cycles", 50)
    project.refine()
    project.save()

    replay = G2sc.G2Project(str(FINAL))
    replay.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    replay.set_Controls("cycles", 50)
    replay.refine()
    replay.save()
    return replay


def main() -> None:
    project = replay_final()
    histogram = project.histograms()[0]
    internal_names = [phase.name for phase in project.phases()]
    if internal_names != list(PHASES):
        raise RuntimeError(f"Unexpected phase inventory: {internal_names}")

    frozen = [
        str(item)
        for values in project.data["Controls"]["data"]
        .get("parmFrozen", {})
        .values()
        for item in values
    ]
    if frozen:
        raise RuntimeError(f"Final project has frozen out-of-bound variables: {frozen}")

    mass_fractions = histogram.ComputeMassFracs()
    phase_results = []
    for phase in project.phases():
        metadata = PHASES[phase.name]
        phase.export_CIF(str(WORK / metadata["cif"]))
        fraction, fraction_esd = mass_fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        phase_results.append(
            {
                "name": metadata["name"],
                "formula": metadata["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": metadata["cif"],
                "weight_fraction": fraction,
                "weight_fraction_esd": fraction_esd,
                "confidence": metadata["confidence"],
                "cell": cell,
                "cell_esd": cell_esd,
            }
        )

    x = np.asarray(histogram.getdata("X"), dtype=float)
    observed = np.asarray(histogram.getdata("Yobs"), dtype=float)
    calculated = np.asarray(histogram.getdata("Ycalc"), dtype=float)
    difference = np.asarray(histogram.getdata("Residual"), dtype=float)
    background = np.asarray(histogram.getdata("Background"), dtype=float)
    if not np.allclose(difference, observed - calculated, rtol=0.0, atol=1e-8):
        raise RuntimeError("GSAS-II residual does not equal observed minus calculated")

    with (WORK / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_obs_minus_calc",
                "background_counts",
            ]
        )
        writer.writerows(zip(x, observed, calculated, difference, background))

    hstats = histogram.data["data"][0]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    nobs = int(rvals["Nobs"])
    nvars = int(rvals["Nvars"])
    chisq = float(rvals["chisq"])
    result = {
        "phases": phase_results,
        "fit_statistics": {
            "Rwp_percent": float(histogram.get_wR()),
            "Rp_percent": float(hstats["R"]),
            "Rexp_percent": float(hstats["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": chisq,
            "reduced_chi_square": chisq / (nobs - nvars),
            "durbin_watson": float(hstats["Durbin-Watson"]),
            "n_observations": nobs,
            "n_refined_parameters": nvars,
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
        },
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    if not math.isclose(
        sum(item["weight_fraction"] for item in phase_results),
        1.0,
        rel_tol=0.0,
        abs_tol=1e-10,
    ):
        raise RuntimeError("Phase fractions do not sum to unity")
    (WORK / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
