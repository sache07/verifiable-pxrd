#!/usr/bin/env python3
"""Final replay and watch-list challenges for the four-phase inventory."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc

from followup_trials import refine_existing_cell
from rebuild_inventory import WORK, add_and_refine, cod_cif


def replay(source: str, output: str, repeats: int = 4) -> dict:
    project = G2sc.G2Project(str(WORK / source))
    project.save(str(WORK / output))
    project.set_Controls("cycles", 25)
    history = []
    for _ in range(repeats):
        project.refine()
        histogram = project.histograms()[0]
        history.append(histogram.get_wR())
    project.save()
    histogram = project.histograms()[0]
    return {
        "project": output,
        "Rwp_history_percent": history,
        "mass_fractions": histogram.ComputeMassFracs(),
        "frozen": [
            str(item)
            for values in project.data["Controls"]["data"]
            .get("parmFrozen", {})
            .values()
            for item in values
        ],
    }


def main() -> None:
    results = []
    results.append(
        replay(
            "inventory4_mnwo4_cell.gpx",
            "inventory4_exact_replay.gpx",
        )
    )
    results.append(
        refine_existing_cell(
            "inventory3_watch_mnwo4_analogue.gpx",
            "inventory4_analogue_cell.gpx",
            "watch_MnWO4_analogue",
        )
    )

    source = "inventory4_exact_replay.gpx"
    candidates = [
        (
            "inventory4_watch_mno2_pnnm.gpx",
            cod_cif("9016546"),
            "watch_manganite_incomplete_9016546",
        ),
        (
            "inventory4_watch_ramsdellite.gpx",
            WORK / "watch_MnO2_ramsdellite_standard.cif",
            "watch_MnO2_ramsdellite",
        ),
        (
            "inventory4_watch_mn3o4.gpx",
            cod_cif("1514104"),
            "watch_Mn3O4_hausmannite_1514104",
        ),
        (
            "inventory4_watch_mn3wo6.gpx",
            cod_cif("2002703"),
            "watch_Mn3WO6_2002703",
        ),
    ]
    for output, phasefile, name in candidates:
        results.append(add_and_refine(source, output, phasefile, name))

    print("RESULTS_JSON")
    print(json.dumps(results, indent=2, default=str))


if __name__ == "__main__":
    main()
