#!/usr/bin/env python3
"""Rebuild and challenge the residual-led crystalline phase inventory."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_cif(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_hap(phase, histogram) -> None:
    """Use GSAS-II's effectively infinite size and zero strain/texture terms."""
    hap = phase.getHAPvalues(histogram.name)
    hap["Size"] = [
        "isotropic",
        [10.0, 10.0, 1.0],
        [False, False, False],
        [0, 0, 1],
        [10.0, 10.0, 10.0, 0.0, 0.0, 0.0],
        [False] * 6,
    ]
    hap["Mustrain"] = [
        "isotropic",
        [0.0, 0.0, 1.0],
        [False, False, False],
        [0, 0, 1],
        [0.0] * len(hap["Mustrain"][4]),
        [False] * len(hap["Mustrain"][5]),
    ]
    hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    phase.set_HAP_refinements({"Scale": True}, histograms=[histogram])


def add_and_refine(
    source: str,
    output: str,
    phasefile: Path,
    name: str,
    *,
    refine_cell: bool = False,
) -> dict:
    project = G2sc.G2Project(str(WORK / source))
    # GSAS-II saves automatically while adding a phase, so redirect the
    # project filename before changing it to preserve the source project.
    project.save(str(WORK / output))
    histogram = project.histograms()[0]
    phase = project.add_phase(
        str(phasefile),
        phasename=name,
        histograms=[histogram],
        fmthint="CIF",
    )
    neutralize_hap(phase, histogram)
    project.index_ids()
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    project.set_Controls("parmMax", 1000.0, variable=f"{phase.id}:0:Scale")
    project.set_Controls("cycles", 20)
    project.save()
    project.refine()
    if refine_cell:
        phase.set_refinements({"Cell": True})
        project.refine()
    project.save()

    # Reopen and replay to ensure the saved project is reproducible.
    replay = G2sc.G2Project(str(WORK / output))
    replay.set_Controls("cycles", 20)
    replay.refine()
    replay.save()
    histogram = replay.histograms()[0]
    phase = replay.phase(name)
    scale = phase.getHAPvalues(histogram.name)["Scale"]
    mass = histogram.ComputeMassFracs()
    return {
        "project": output,
        "Rwp_percent": histogram.get_wR(),
        "Rp_percent": histogram.data["data"][0].get("R"),
        "phase": name,
        "scale": scale[0],
        "scale_esd": scale[1] if len(scale) > 1 else None,
        "weight_fraction": mass[name][0],
        "weight_fraction_esd": mass[name][1],
        "cell": phase.get_cell(),
        "cell_esd": phase.get_cell_and_esd()[1],
        "frozen": [
            str(item)
            for values in replay.data["Controls"]["data"]
            .get("parmFrozen", {})
            .values()
            for item in values
        ],
    }


def recover_two_phase_base(source: str, output: str) -> None:
    """Remove phases added during screening without changing the fitted base."""
    project = G2sc.G2Project(str(WORK / source))
    project.save(str(WORK / output))
    keep = {"WO3_mono_2311041", "beta_MnO2_1514232"}
    for name in list(project.data["Phases"]):
        if name != "data" and name not in keep:
            project.data["Phases"].pop(name)
    histogram = project.histograms()[0]
    for name in list(histogram.data["Reflection Lists"]):
        if name not in keep:
            histogram.data["Reflection Lists"].pop(name)
    for tree_entry in project.names:
        if tree_entry and tree_entry[0] == "Phases":
            tree_entry[:] = ["Phases"] + [
                name for name in tree_entry[1:] if name in keep
            ]
    project.index_ids()
    project.save()


def main() -> None:
    results = []
    recover_two_phase_base("aniso_011.gpx", "inventory_base.gpx")
    base = "inventory_base.gpx"

    # Same-composition record challenge for bixbyite Mn2O3.
    results.append(
        add_and_refine(
            base,
            "challenge_mn2o3_i213.gpx",
            cod_cif("1010586"),
            "Mn2O3_I213_1010586",
        )
    )
    results.append(
        add_and_refine(
            base,
            "challenge_mn2o3_pcab.gpx",
            cod_cif("1514103"),
            "Mn2O3_Pcab_1514103",
        )
    )

    # Accepted provisional phase; scale is established before the cell trial.
    results.append(
        add_and_refine(
            base,
            "inventory3_mn2o3_fixed.gpx",
            cod_cif("1514230"),
            "Mn2O3_bixbyite_1514230",
        )
    )
    results.append(
        add_and_refine(
            base,
            "inventory3_mn2o3_cell.gpx",
            cod_cif("1514230"),
            "Mn2O3_bixbyite_1514230",
            refine_cell=True,
        )
    )

    # Re-challenge the watch list only after the three-phase profile is rebuilt.
    source = "inventory3_mn2o3_fixed.gpx"
    results.append(
        add_and_refine(
            source,
            "inventory3_watch_mnwo4_exact.gpx",
            cod_cif("1520200"),
            "watch_MnWO4_exact_1520200",
        )
    )
    results.append(
        add_and_refine(
            source,
            "inventory3_watch_mnwo4_analogue.gpx",
            WORK / "watch_MnWO4_from_FeWO4_9008124.cif",
            "watch_MnWO4_analogue",
        )
    )
    results.append(
        add_and_refine(
            source,
            "inventory3_watch_mno2_pnnm.gpx",
            cod_cif("9016546"),
            "watch_manganite_incomplete_9016546",
        )
    )
    results.append(
        add_and_refine(
            source,
            "inventory3_watch_ramsdellite.gpx",
            cod_cif("1514102"),
            "watch_MnO2_ramsdellite_1514102",
        )
    )
    results.append(
        add_and_refine(
            source,
            "inventory3_watch_mn3o4.gpx",
            cod_cif("1514104"),
            "watch_Mn3O4_hausmannite_1514104",
        )
    )

    print("RESULTS_JSON")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
