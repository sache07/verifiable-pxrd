#!/usr/bin/env python3
"""Rewrite the legacy ramsdellite CIF in a GSAS-II-compatible setting."""

from pathlib import Path

from pymatgen.io.cif import CifParser, CifWriter


SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/51/41/1514102.cif"
)
OUTPUT = Path(__file__).resolve().parent / "watch_MnO2_ramsdellite_standard.cif"


def main() -> None:
    structure = CifParser(SOURCE).parse_structures(primitive=False)[0]
    CifWriter(structure, symprec=1e-4, refine_struct=True).write_file(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    main()
