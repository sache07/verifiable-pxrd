#!/usr/bin/env python3
"""Cell and residual phase trials after rebuilding the three-phase profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from rebuild_inventory import WORK, add_and_refine, cod_cif


def refine_existing_cell(source: str, output: str, phase_name: str) -> dict:
    project = G2sc.G2Project(str(WORK / source))
    project.save(str(WORK / output))
    project.phase(phase_name).set_refinements({"Cell": True})
    project.set_Controls("cycles", 25)
    project.refine()
    project.save()

    replay = G2sc.G2Project(str(WORK / output))
    replay.set_Controls("cycles", 25)
    replay.refine()
    replay.save()
    histogram = replay.histograms()[0]
    phase = replay.phase(phase_name)
    return {
        "project": output,
        "Rwp_percent": histogram.get_wR(),
        "Rp_percent": histogram.data["data"][0].get("R"),
        "mass_fractions": histogram.ComputeMassFracs(),
        "cell": phase.get_cell(),
        "cell_and_esd": phase.get_cell_and_esd(),
        "frozen": [
            str(item)
            for values in replay.data["Controls"]["data"]
            .get("parmFrozen", {})
            .values()
            for item in values
        ],
    }


def main() -> None:
    results = []
    results.append(
        refine_existing_cell(
            "inventory3_watch_mnwo4_exact.gpx",
            "inventory4_mnwo4_cell.gpx",
            "watch_MnWO4_exact_1520200",
        )
    )
    results.append(
        add_and_refine(
            "inventory3_mn2o3_fixed.gpx",
            "inventory3_watch_mn3o4.gpx",
            cod_cif("1514104"),
            "watch_Mn3O4_hausmannite_1514104",
        )
    )
    ramsdellite = WORK / "watch_MnO2_ramsdellite_standard.cif"
    if ramsdellite.exists():
        results.append(
            add_and_refine(
                "inventory3_mn2o3_fixed.gpx",
                "inventory3_watch_ramsdellite.gpx",
                ramsdellite,
                "watch_MnO2_ramsdellite",
            )
        )
    print("RESULTS_JSON")
    print(json.dumps(results, indent=2, default=str))


if __name__ == "__main__":
    main()
