#!/usr/bin/env python3
"""Compare chemically complete MnOOH polymorphs under the final baseline."""

from __future__ import annotations

import json

from rebuild_inventory import add_and_refine, cod_cif


def main() -> None:
    source = "strict_inventory4_exact.gpx"
    results = []
    for output, cod_id, name in [
        (
            "strict_watch_mnooh_manganite.gpx",
            "9009774",
            "watch_MnOOH_manganite_9009774",
        ),
        (
            "strict_watch_mnooh_groutite.gpx",
            "9009773",
            "watch_MnOOH_groutite_9009773",
        ),
        (
            "strict_watch_mnooh_pnnm.gpx",
            "1011020",
            "watch_MnOOH_Pnnm_1011020",
        ),
    ]:
        results.append(add_and_refine(source, output, cod_cif(cod_id), name))
    print("RESULTS_JSON")
    print(json.dumps(results, indent=2, default=str))


if __name__ == "__main__":
    main()
