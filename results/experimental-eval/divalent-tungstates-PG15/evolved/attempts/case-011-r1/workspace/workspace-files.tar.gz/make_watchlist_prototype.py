#!/usr/bin/env python3
"""Build a MnWO4 wolframite watch-list model from an ambient FeWO4 parent."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)
PARENT = ROOT / "9/00/81/9008124.cif"
EXACT = ROOT / "1/52/02/1520200.cif"
OUTPUT = Path(__file__).resolve().parent / "watch_MnWO4_from_FeWO4_9008124.cif"


def main() -> None:
    parent = Structure.from_file(PARENT)
    exact = Structure.from_file(EXACT)
    parent.replace_species({"Fe": "Mn"})
    # Keep the ambient ferberite fractional coordinates but place them in the
    # measured MnWO4 metric so a scale-only test is not defeated by Fe/Mn size.
    parent = Structure(
        Lattice.from_parameters(*exact.lattice.abc, *exact.lattice.angles),
        parent.species,
        parent.frac_coords,
        site_properties=parent.site_properties,
    )
    CifWriter(parent, symprec=1e-5, refine_struct=False).write_file(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    main()
