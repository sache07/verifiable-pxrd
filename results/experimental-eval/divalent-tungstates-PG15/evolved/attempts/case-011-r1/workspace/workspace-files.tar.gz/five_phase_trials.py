#!/usr/bin/env python3
"""Rebuild and challenge the provisional five-phase inventory."""

from __future__ import annotations

import json

from followup_trials import refine_existing_cell
from rebuild_inventory import WORK, add_and_refine, cod_cif
from strict_finalize import strict_replay


def main() -> None:
    results = []
    results.append(
        strict_replay(
            "strict_watch_mnooh_manganite.gpx",
            "strict_inventory5_exact.gpx",
        )
    )
    # The MnOOH cell trial was run separately and rejected because its four
    # metric terms did not replay stably; keep the modern reference cell fixed.
    results.append(
        add_and_refine(
            "strict_inventory4_analogue.gpx",
            "strict_inventory5_analogue.gpx",
            cod_cif("9009774"),
            "watch_MnOOH_manganite_9009774",
        )
    )
    results.append(
        add_and_refine(
            "strict_inventory3.gpx",
            "strict_inventory4_no_mnwo4.gpx",
            cod_cif("9009774"),
            "watch_MnOOH_manganite_9009774",
        )
    )

    source = "strict_inventory5_exact.gpx"
    for output, phasefile, name in [
        (
            "inventory5_watch_mnooh_pnnm.gpx",
            cod_cif("1011020"),
            "watch_MnOOH_Pnnm_1011020",
        ),
        (
            "inventory5_watch_mnooh_groutite.gpx",
            cod_cif("9009773"),
            "watch_MnOOH_groutite_9009773",
        ),
        (
            "inventory5_watch_ramsdellite.gpx",
            WORK / "watch_MnO2_ramsdellite_standard.cif",
            "watch_MnO2_ramsdellite",
        ),
        (
            "inventory5_watch_mn3o4.gpx",
            cod_cif("1514104"),
            "watch_Mn3O4_hausmannite_1514104",
        ),
        (
            "inventory5_watch_mn3wo6.gpx",
            cod_cif("2002703"),
            "watch_Mn3WO6_2002703",
        ),
    ]:
        results.append(add_and_refine(source, output, phasefile, name))

    print("RESULTS_JSON")
    print(json.dumps(results, indent=2, default=str))


if __name__ == "__main__":
    main()
