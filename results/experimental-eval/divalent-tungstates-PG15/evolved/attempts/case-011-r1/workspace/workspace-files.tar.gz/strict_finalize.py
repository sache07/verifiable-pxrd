#!/usr/bin/env python3
"""Strictly converge the fixed-cell inventory and replay final challenges."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc

from rebuild_inventory import WORK, add_and_refine, cod_cif


def strict_replay(source: str, output: str) -> dict:
    project = G2sc.G2Project(str(WORK / source))
    project.save(str(WORK / output))
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.set_Controls("cycles", 50)
    project.refine()
    project.save()

    replay = G2sc.G2Project(str(WORK / output))
    replay.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    replay.set_Controls("cycles", 50)
    replay.refine()
    replay.save()
    histogram = replay.histograms()[0]
    return {
        "project": output,
        "Rwp_percent": histogram.get_wR(),
        "Rp_percent": histogram.data["data"][0].get("R"),
        "mass_fractions": histogram.ComputeMassFracs(),
        "frozen": [
            str(item)
            for values in replay.data["Controls"]["data"]
            .get("parmFrozen", {})
            .values()
            for item in values
        ],
    }


def main() -> None:
    results = []
    results.append(
        strict_replay(
            "inventory3_mn2o3_fixed.gpx",
            "strict_inventory3.gpx",
        )
    )
    results.append(
        strict_replay(
            "inventory3_watch_mnwo4_exact.gpx",
            "strict_inventory4_exact.gpx",
        )
    )
    results.append(
        strict_replay(
            "inventory3_watch_mnwo4_analogue.gpx",
            "strict_inventory4_analogue.gpx",
        )
    )

    source = "strict_inventory4_exact.gpx"
    for output, phasefile, name in [
        (
            "strict_watch_mno2_pnnm.gpx",
            cod_cif("9016546"),
            "watch_manganite_incomplete_9016546",
        ),
        (
            "strict_watch_ramsdellite.gpx",
            WORK / "watch_MnO2_ramsdellite_standard.cif",
            "watch_MnO2_ramsdellite",
        ),
        (
            "strict_watch_mn3o4.gpx",
            cod_cif("1514104"),
            "watch_Mn3O4_hausmannite_1514104",
        ),
        (
            "strict_watch_mn3wo6.gpx",
            cod_cif("2002703"),
            "watch_Mn3WO6_2002703",
        ),
    ]:
        results.append(add_and_refine(source, output, phasefile, name))

    print("RESULTS_JSON")
    print(json.dumps(results, indent=2, default=str))


if __name__ == "__main__":
    main()
