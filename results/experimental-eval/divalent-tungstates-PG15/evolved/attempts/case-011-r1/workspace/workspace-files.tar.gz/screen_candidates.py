#!/usr/bin/env python3
"""Compare chemically plausible phase records under one neutral GSAS-II baseline."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path(__file__).resolve().parent
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_cif(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_hap(phase, histogram) -> None:
    """Remove default phase-specific size, strain, texture, and extinction."""
    hap = phase.getHAPvalues(histogram.name)
    hap["Size"] = [
        "isotropic",
        [10000.0, 10000.0, 1.0],
        [False, False, False],
        [0, 0, 1],
        [10000.0, 10000.0, 10000.0, 0.0, 0.0, 0.0],
        [False] * 6,
    ]
    hap["Mustrain"] = [
        "isotropic",
        [0.0, 0.0, 1.0],
        [False, False, False],
        [0, 0, 1],
        [0.0] * len(hap["Mustrain"][4]),
        [False] * len(hap["Mustrain"][5]),
    ]
    hap["Pref.Ori."] = ["MD", 1.0, False, [0, 0, 1], 0, {}, [], 0.1]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}
    hap["HStrain"][0] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    phase.set_HAP_refinements({"Scale": True}, histograms=[histogram])


def set_inst_value(histogram, name: str, value: float) -> None:
    parm = histogram.data["Instrument Parameters"][0][name]
    parm[0] = parm[1] = value


def run_model(tag: str, records: list[tuple[str, str]]) -> dict:
    path = WORK / f"screen_{tag}.gpx"
    project = G2sc.G2Project(newgpx=str(path))
    hist = project.add_powder_histogram(
        str(WORK / "inputs/pattern.csv"), str(WORK / "instrument.instprm")
    )
    hist.data["Sample Parameters"]["Scale"][1] = False
    for key in ("Absorption", "DisplaceX", "DisplaceY", "Shift", "Transparency"):
        if key in hist.data["Sample Parameters"]:
            val = hist.data["Sample Parameters"][key]
            if isinstance(val, list) and len(val) > 1:
                val[0], val[1] = 0.0, False
    for key in ("SurfRoughA", "SurfRoughB"):
        hist.data["Sample Parameters"][key] = [0.0, False]

    set_inst_value(hist, "Zero", 0.30)
    set_inst_value(hist, "U", 2.0)
    set_inst_value(hist, "V", 0.0)
    set_inst_value(hist, "W", 100.0)
    set_inst_value(hist, "X", 5.0)
    set_inst_value(hist, "Y", 0.0)
    set_inst_value(hist, "Z", 0.0)
    set_inst_value(hist, "SH/L", 0.002)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
                "coeffs": [1200.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            },
            "Instrument Parameters": ["Zero"],
        }
    )

    phases = []
    for cod_id, name in records:
        phase = project.add_phase(
            str(cod_cif(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        neutralize_hap(phase, hist)
        phases.append(phase)

    project.index_ids()
    project.set_Controls("parmMin", 0.10, variable=":0:Zero")
    project.set_Controls("parmMax", 0.50, variable=":0:Zero")
    for phase in phases:
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMax", 1000.0, variable=f"{phase.id}:0:Scale")

    project.set_Controls("cycles", 10)
    project.refine()
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 15)
    project.refine()

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for var, low, high in (
        (":0:U", 0.0, 100.0),
        (":0:W", 0.0, 500.0),
        (":0:X", 0.0, 100.0),
    ):
        project.set_Controls("parmMin", low, variable=var)
        project.set_Controls("parmMax", high, variable=var)
    project.set_Controls("cycles", 20)
    project.refine()
    project.save()

    inst = hist.data["Instrument Parameters"][0]
    return {
        "tag": tag,
        "project": path.name,
        "wR_percent": hist.get_wR(),
        "R_percent": hist.data["data"][0].get("R"),
        "zero_deg": inst["Zero"][1],
        "profile": {key: inst[key][1] for key in ("U", "W", "X", "SH/L")},
        "frozen": [
            str(item)
            for values in project.data["Controls"]["data"].get("parmFrozen", {}).values()
            for item in values
        ],
        "phases": [
            {
                "name": phase.name,
                "scale": phase.getHAPvalues(hist.name)["Scale"][0],
                "cell": phase.get_cell(),
            }
            for phase in phases
        ],
    }


MODELS = {
    "mono2311041_rutile1514232": [
        ("2311041", "WO3_mono_2311041"),
        ("1514232", "beta_MnO2_1514232"),
    ],
    "mono1528915_rutile1514232": [
        ("1528915", "WO3_mono_1528915"),
        ("1514232", "beta_MnO2_1514232"),
    ],
    "triclinic2106293_rutile1514232": [
        ("2106293", "WO3_triclinic_2106293"),
        ("1514232", "beta_MnO2_1514232"),
    ],
    "orthorhombic2107312_rutile1514232": [
        ("2107312", "WO3_orthorhombic_2107312"),
        ("1514232", "beta_MnO2_1514232"),
    ],
    "mono2311041_rutile1514110": [
        ("2311041", "WO3_mono_2311041"),
        ("1514110", "beta_MnO2_1514110"),
    ],
    "mono2311041_pnnm9016546": [
        ("2311041", "WO3_mono_2311041"),
        ("9016546", "MnO2_Pnnm_9016546"),
    ],
}


def main() -> None:
    selected = sys.argv[1:] or list(MODELS)
    results = []
    for tag in selected:
        print(f"\n===== {tag} =====", flush=True)
        results.append(run_model(tag, MODELS[tag]))
        print(json.dumps(results[-1], indent=2), flush=True)
    print("\nRESULTS_JSON")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
