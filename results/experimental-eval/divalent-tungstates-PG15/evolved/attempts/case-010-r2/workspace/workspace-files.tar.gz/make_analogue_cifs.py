#!/usr/bin/env python3
"""Create physically screened Mn-W-O prototype substitutions for phase challenges."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def substitute(cod_id: str, old: str, new: str, output: str) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species({old: new})
    CifWriter(structure, symprec=1e-3).write_file(output)


# Fe2+ -> Mn2+ in the ambient-pressure wolframite topology. The 1967 parent
# has plausible W-O geometry; two newer FeWO4 records were rejected for
# unphysical 1.31-1.50 A W-O contacts.
substitute("9008124", "Fe", "Mn", "MnWO4_ambient_analogue.cif")

# Te6+ -> W6+ in the R-3 Mn3TeO6 topology; charge and octahedral chemistry are
# conserved and this provides an independent physical check on COD 2002703.
substitute("2211528", "Te", "W", "Mn3WO6_te_analogue.cif")
