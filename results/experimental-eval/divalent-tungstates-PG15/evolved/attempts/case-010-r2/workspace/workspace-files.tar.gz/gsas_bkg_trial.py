#!/usr/bin/env python3
"""Replay a converged project with a selected Chebyshev background order."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import GSASII.GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("coefficients", type=int)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    project["Controls"]["data"]["max cyc"] = 7
    project["Controls"]["data"]["min dM/M"] = 0.0002
    hist = project.histogram(0)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.coefficients,
                "refine": True,
            }
        }
    )
    history = []
    project.save()
    for replay in range(3):
        project.refine(makeBack=False)
        history.append({"replay": replay + 1, "rwp_percent": hist.get_wR()})
    project.save()
    print(
        "BKG_RESULT="
        + json.dumps(
            {
                "gpx": str(args.output),
                "coefficients": args.coefficients,
                "rwp_percent": hist.get_wR(),
                "background": hist.data["Background"][0],
                "history": history,
                "fractions": hist.ComputeMassFracs(),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
