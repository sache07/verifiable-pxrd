#!/usr/bin/env python3
"""Fully reconverge a supported watch-list candidate with the common profile fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import GSASII.GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--strain-phase", default="Mn2O3")
    parser.add_argument("--cycles", type=int, default=7)
    parser.add_argument("--replays", type=int, default=3)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    project["Controls"]["data"]["max cyc"] = args.cycles
    project["Controls"]["data"]["min dM/M"] = 0.0002
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    hist.data["Sample Parameters"]["Scale"][1] = False
    inst = hist.data["Instrument Parameters"][0]
    for key, value in inst.items():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    inst["Zero"][2] = True

    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        if phase.name == args.strain_phase:
            hap["Mustrain"][1][0] = 1300.0
            hap["Mustrain"][2][0] = True

    history = []
    project.save()
    for replay in range(args.replays):
        project.refine(makeBack=False)
        history.append(
            {
                "replay": replay + 1,
                "rwp_percent": hist.get_wR(),
                "scales": {
                    phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
                    for phase in project.phases()
                },
            }
        )
    project.save()
    print(
        "PROMOTE_RESULT="
        + json.dumps(
            {
                "gpx": str(args.output),
                "rwp_percent": hist.get_wR(),
                "rp_percent": hist.data["data"][0].get("R"),
                "history": history,
                "fractions": hist.ComputeMassFracs(),
                "phases": [
                    {
                        "name": phase.name,
                        "cell": phase.get_cell(),
                        "space_group": phase.data["General"]["SGData"]["SpGrp"],
                    }
                    for phase in project.phases()
                ],
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
