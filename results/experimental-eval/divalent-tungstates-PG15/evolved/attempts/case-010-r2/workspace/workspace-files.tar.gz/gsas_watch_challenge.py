#!/usr/bin/env python3
"""Test one watch-list phase against a converged residual with nuisances fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import GSASII.GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def source_path(token: str) -> Path:
    path = Path(token)
    if path.suffix.lower() == ".cif":
        return path
    return COD_ROOT / token[0] / token[1:3] / token[3:5] / f"{token}.cif"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_project", type=Path)
    parser.add_argument("output_project", type=Path)
    parser.add_argument("candidate")
    parser.add_argument("name")
    args = parser.parse_args()

    project = G2sc.G2Project(
        str(args.source_project), newgpx=str(args.output_project)
    )
    project["Controls"]["data"]["max cyc"] = 6
    project["Controls"]["data"]["min dM/M"] = 0.0001
    hist = project.histogram(0)

    # Freeze the converged residual model so this is a one-parameter scale test.
    hist.data["Background"][0][1] = False
    hist.data["Sample Parameters"]["Scale"][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])

    candidate = project.add_phase(
        str(source_path(args.candidate)),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = candidate.data["Histograms"][hist.name]
    hap["Scale"] = [0.01, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    project.save()

    status = "ok"
    error = None
    try:
        project.refine(makeBack=False)
    except Exception as exc:  # retain the project and report a rejected trial
        status = "failed"
        error = f"{type(exc).__name__}: {exc}"
    project.save()

    scale = hap["Scale"][0]
    sigma = None
    covariance = project["Covariance"]["data"]
    key = f"{candidate.id}:{hist.id}:Scale"
    if key in covariance.get("varyList", []):
        index = covariance["varyList"].index(key)
        sigma = float(covariance["sig"][index])
    print(
        "WATCH_RESULT="
        + json.dumps(
            {
                "candidate": args.name,
                "status": status,
                "error": error,
                "scale": scale,
                "scale_sigma": sigma,
                "z_score": None if not sigma else scale / sigma,
                "rwp_percent": hist.get_wR(),
                "cell": candidate.get_cell(),
                "space_group": candidate.data["General"]["SGData"]["SpGrp"],
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
