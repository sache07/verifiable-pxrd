#!/usr/bin/env python3
"""Run a restrained, common-nuisance GSAS-II screen of COD phase records."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import GSASII.GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def run_refinement(project: G2sc.G2Project, label: str, history: list[dict]) -> None:
    project.refine(makeBack=False)
    hist = project.histogram(0)
    history.append(
        {
            "stage": label,
            "rwp_percent": hist.get_wR(),
            "scales": {
                phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
                for phase in project.phases()
            },
        }
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "phases",
        nargs="+",
        help="COD_ID or COD_ID:phase_name",
    )
    parser.add_argument("--cycles", type=int, default=4)
    args = parser.parse_args()

    project = G2sc.G2Project(newgpx=str(args.output))
    hist = project.add_powder_histogram(
        "pattern.xye", "instrument.instprm", fmthint="xye"
    )
    phases = []
    for item in args.phases:
        cod_id, sep, name = item.partition(":")
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=name if sep else cod_id,
            histograms=[hist],
            fmthint="CIF",
        )
        phases.append(phase)

    controls = project["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 0.0005

    # Fix the redundant overall histogram scale and neutralize phase nuisances.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [1.0, 1.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [1000.0, 1000.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
        phase.set_HAP_refinements({"Scale": True})

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "refine": True,
            }
        }
    )
    project.save()

    history: list[dict] = []
    run_refinement(project, "background_scales", history)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, "plus_zero", history)
    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_refinement(project, "plus_cells_1", history)
    run_refinement(project, "plus_cells_2", history)
    project.save()

    inst = hist.data["Instrument Parameters"][0]
    result = {
        "gpx": str(args.output),
        "history": history,
        "rwp_percent": hist.get_wR(),
        "rp_percent": hist.data["data"][0].get("R"),
        "gof": hist.data["data"][0].get("wR")
        / hist.data["data"][0].get("wRmin"),
        "zero_deg": inst["Zero"][1],
        "background": hist.data["Background"][0],
        "phases": [
            {
                "name": phase.name,
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "cell": phase.get_cell(),
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
            }
            for phase in phases
        ],
    }
    print("SCREEN_RESULT=" + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
