#!/usr/bin/env python3
"""Export the final GSAS-II model and all requested deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
import GSASII.GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE_PROJECT = ROOT / ".tmp" / "final_verified.gpx"
FINAL_PROJECT = ROOT / "final.gpx"

PHASES = {
    "WO3": {
        "name": "WO3",
        "formula": "WO3",
        "cif_path": "WO3.cif",
        "cod_id": "2311041",
        "cell_formula_units_z": 8,
        "status": "established",
    },
    "Mn2O3": {
        "name": "Mn2O3",
        "formula": "Mn2O3",
        "cif_path": "Mn2O3.cif",
        "cod_id": "1514230",
        "cell_formula_units_z": 16,
        "status": "established",
    },
    "MnWO4_exact": {
        "name": "MnWO4",
        "formula": "MnWO4",
        "cif_path": "MnWO4.cif",
        "cod_id": "1520200",
        "cell_formula_units_z": 2,
        "status": "tentative weak phase; fraction is model-dependent",
    },
}


def scalar(value: object) -> float:
    """Convert numpy and masked scalars to ordinary JSON-safe floats."""
    return float(np.asarray(value))


def main() -> None:
    if not SOURCE_PROJECT.is_file():
        raise FileNotFoundError(SOURCE_PROJECT)

    # Set conventional formula-unit counts used only for CIF composition labels.
    # This metadata does not enter the calculated diffraction profile.
    project = G2sc.G2Project(str(SOURCE_PROJECT), newgpx=str(FINAL_PROJECT))
    for phase in project.phases():
        phase.data["General"]["cellZ"] = PHASES[phase.name][
            "cell_formula_units_z"
        ]

    # Save before exporting anything. All files below are therefore generated
    # from the exact submitted project state.
    project.save()
    histogram = project.histogram(0)
    profile = histogram.data["data"][1]
    summary = histogram.data["data"][0]
    fractions = histogram.ComputeMassFracs()

    phase_results = []
    for phase_index, phase in enumerate(project.phases()):
        spec = PHASES[phase.name]
        export_name = spec["name"]
        internal_name = phase.name

        # The wrapper name controls the human-readable CIF phase label only; it
        # does not modify the submitted project or its parameter indexing.
        phase.name = export_name
        phase.export_CIF(str(ROOT / spec["cif_path"]))
        phase.name = internal_name

        fraction, fraction_su = fractions[internal_name]
        cell = {key: scalar(value) for key, value in phase.get_cell().items()}
        phase_results.append(
            {
                "name": spec["name"],
                "formula": spec["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cell": cell,
                "cif_path": spec["cif_path"],
                "weight_fraction": scalar(fraction),
                "weight_fraction_standard_uncertainty": scalar(fraction_su),
                "weight_percent": 100.0 * scalar(fraction),
                "weight_percent_standard_uncertainty": 100.0 * scalar(fraction_su),
                "structure_source": {
                    "database": "Crystallography Open Database",
                    "entry": spec["cod_id"],
                },
                "assessment": spec["status"],
                "bragg_r_factor_percent": scalar(summary[f"{phase_index}:0:Rf"]),
                "bragg_r_f_squared_percent": scalar(summary[f"{phase_index}:0:Rf^2"]),
            }
        )

    fit_path = ROOT / "fit.csv"
    with fit_path.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "background_counts",
                "difference_counts",
            ]
        )
        for values in zip(profile[0], profile[1], profile[3], profile[4], profile[5]):
            writer.writerow([format(scalar(value), ".12g") for value in values])

    covariance = project["Covariance"]["data"]
    rvals = covariance["Rvals"]
    result = {
        "phases": phase_results,
        "weight_fraction_basis": (
            "normalized over the modeled crystalline phases; no amorphous fraction "
            "was determined"
        ),
        "fit_statistics": {
            "r_wp_percent": scalar(summary["wR"]),
            "r_p_percent": scalar(summary["R"]),
            "r_exp_percent": scalar(summary["wRmin"]),
            "goodness_of_fit": scalar(rvals["GOF"]),
            "chi_square": scalar(rvals["chisq"]),
            "background_subtracted_r_wp_percent": scalar(summary["wRb"]),
            "background_subtracted_r_p_percent": scalar(summary["Rb"]),
            "durbin_watson": scalar(summary["Durbin-Watson"]),
            "n_observations": int(summary["Nobs"]),
            "n_refined_parameters": len(covariance["varyList"]),
            "maximum_shift_over_standard_uncertainty": scalar(
                rvals["Max shft/sig"]
            ),
            "two_theta_range_deg": [scalar(profile[0][0]), scalar(profile[0][-1])],
        },
        "measurement_model": {
            "radiation": "Cu K-alpha doublet",
            "wavelength_kalpha1_angstrom": 1.540598,
            "wavelength_kalpha2_angstrom": 1.544426,
            "kalpha2_to_kalpha1_ratio": 0.5,
            "uncertainty_model": (
                "Poisson counting approximation, sigma=sqrt(observed counts), "
                "because pointwise uncertainties were not supplied"
            ),
        },
        "refinement_program": "GSAS-II",
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }

    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
