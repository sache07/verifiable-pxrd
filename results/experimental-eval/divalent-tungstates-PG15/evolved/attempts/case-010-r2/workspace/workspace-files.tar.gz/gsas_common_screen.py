#!/usr/bin/env python3
"""Screen phase records with the accepted common profile held fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import GSASII.GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def source_path(token: str) -> Path:
    path = Path(token)
    if path.suffix.lower() == ".cif":
        return path
    return COD_ROOT / token[0] / token[1:3] / token[3:5] / f"{token}.cif"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+", help="COD_ID[:name] or path.cif[:name]")
    parser.add_argument("--strain-phase")
    parser.add_argument("--cycles", type=int, default=5)
    args = parser.parse_args()

    project = G2sc.G2Project(newgpx=str(args.output))
    hist = project.add_powder_histogram(
        "pattern.xye", "instrument.instprm", fmthint="xye"
    )
    phases = []
    for item in args.phases:
        token, sep, name = item.partition(":")
        phase = project.add_phase(
            str(source_path(token)),
            phasename=name if sep else Path(token).stem,
            histograms=[hist],
            fmthint="CIF",
        )
        phases.append(phase)

    project["Controls"]["data"]["max cyc"] = args.cycles
    project["Controls"]["data"]["min dM/M"] = 0.0002
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    inst = hist.data["Instrument Parameters"][0]
    common = {
        "U": 155.68463970832917,
        "V": 0.0,
        "W": 5.0,
        "X": 12.180698721639947,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.04332865503191442,
        "Polariz.": 0.6892071061807321,
    }
    for key, value in common.items():
        inst[key][1] = value
        inst[key][2] = False

    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        phase.set_HAP_refinements({"Scale": True})
        if args.strain_phase == phase.name:
            hap["Mustrain"][1][0] = 1300.0
            hap["Mustrain"][2][0] = True

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "refine": True,
            },
            "Instrument Parameters": ["Zero"],
        }
    )
    project.save()

    history = []
    for stage in ["scales_background_zero", "cells_1", "cells_2", "replay"]:
        if stage == "cells_1":
            for phase in phases:
                phase.set_refinements({"Cell": True})
        project.refine(makeBack=False)
        history.append(
            {
                "stage": stage,
                "rwp_percent": hist.get_wR(),
                "scales": {
                    phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
                    for phase in phases
                },
            }
        )
    project.save()
    print(
        "COMMON_RESULT="
        + json.dumps(
            {
                "gpx": str(args.output),
                "rwp_percent": hist.get_wR(),
                "rp_percent": hist.data["data"][0].get("R"),
                "history": history,
                "fractions": hist.ComputeMassFracs(),
                "phases": [
                    {
                        "name": phase.name,
                        "space_group": phase.data["General"]["SGData"]["SpGrp"],
                        "cell": phase.get_cell(),
                    }
                    for phase in phases
                ],
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
