#!/usr/bin/env python3
"""Test one phase-dependent size or strain term against a fixed common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import GSASII.GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", help="phase name or zero-based index")
    parser.add_argument("kind", choices=["size", "strain"])
    parser.add_argument("--cycles", type=int, default=6)
    parser.add_argument("--replays", type=int, default=2)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    project["Controls"]["data"]["max cyc"] = args.cycles
    project["Controls"]["data"]["min dM/M"] = 0.0002
    hist = project.histogram(0)

    # Freeze the accepted common profile while testing one sample term.
    inst = hist.data["Instrument Parameters"][0]
    for key in ["U", "V", "W", "X", "Y", "Z", "SH/L"]:
        inst[key][2] = False

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])

    try:
        target = project.phase(int(args.phase))
    except ValueError:
        target = project.phase(args.phase)
    hap = target.data["Histograms"][hist.name]
    if args.kind == "size":
        hap["Size"][2][0] = True
    else:
        hap["Mustrain"][2][0] = True

    history = []
    project.save()
    for replay in range(args.replays):
        project.refine(makeBack=False)
        history.append(
            {
                "replay": replay + 1,
                "rwp_percent": hist.get_wR(),
                "size_um": hap["Size"][1][0],
                "microstrain": hap["Mustrain"][1][0],
            }
        )
    project.save()
    print(
        "HAP_RESULT="
        + json.dumps(
            {
                "gpx": str(args.output),
                "phase": target.name,
                "kind": args.kind,
                "rwp_percent": hist.get_wR(),
                "size_um": hap["Size"][1][0],
                "microstrain": hap["Mustrain"][1][0],
                "history": history,
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
