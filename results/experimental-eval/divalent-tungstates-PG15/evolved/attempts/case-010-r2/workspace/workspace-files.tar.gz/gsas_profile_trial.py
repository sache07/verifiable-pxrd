#!/usr/bin/env python3
"""Replay a GSAS-II project while testing a common profile parameter set."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import GSASII.GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("params", nargs="*", choices=["U", "W", "X", "SH/L"])
    parser.add_argument("--cycles", type=int, default=6)
    parser.add_argument("--replays", type=int, default=2)
    parser.add_argument("--fixed-w", type=float)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.source), newgpx=str(args.output))
    project["Controls"]["data"]["max cyc"] = args.cycles
    project["Controls"]["data"]["min dM/M"] = 0.0002
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]

    # Remove the default 1-micron/1000-microstrain sample broadening so the
    # common profile is established before any phase-dependent broadening.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2] = [False, False, False]
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])

    # Keep V/Y/Z neutral and use only explicitly requested nonnegative terms.
    starts = {"U": 10.0, "W": 20.0, "X": 1.0, "SH/L": 0.002}
    for key in ["U", "V", "W", "X", "Y", "Z", "SH/L"]:
        inst[key][2] = False
    if args.fixed_w is not None:
        if args.fixed_w < 0:
            raise ValueError("--fixed-w must be nonnegative")
        inst["W"][1] = args.fixed_w
    for key in args.params:
        if key == "X" and inst[key][1] <= 0:
            inst[key][1] = starts[key]
        inst[key][2] = True

    history = []
    project.save()
    for replay in range(args.replays):
        project.refine(makeBack=False)
        history.append(
            {
                "replay": replay + 1,
                "rwp_percent": hist.get_wR(),
                "profile": {key: inst[key][1] for key in starts},
            }
        )
    project.save()
    print(
        "PROFILE_RESULT="
        + json.dumps(
            {
                "gpx": str(args.output),
                "rwp_percent": hist.get_wR(),
                "rp_percent": hist.data["data"][0].get("R"),
                "rwp_min_percent": hist.data["data"][0].get("wRmin"),
                "profile": {key: inst[key][1] for key in starts},
                "history": history,
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
