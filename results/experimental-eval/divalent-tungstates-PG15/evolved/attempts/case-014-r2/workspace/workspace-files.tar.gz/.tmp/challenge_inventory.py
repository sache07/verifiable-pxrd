#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")
root = Path.cwd()
candidates = [
    ("WO3_Pnma", ".tmp/wo3_pnma_start.cif"),
    ("WO3_P21c", ".tmp/wo3_p21c_start.cif"),
    ("WO3_P21m", ".tmp/wo3_p21m_start.cif"),
    ("SrWO4_fergusonite", ".tmp/srwo4_fergusonite_start.cif"),
    ("Sr3W2O9_C2c", ".tmp/sr3w2o9_start.cif"),
    ("SrCO3_Pnma", ".tmp/srco3_pnma_start.cif"),
]


def neutral_hap(phase, hist) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1.0e6, 1.0e6, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"][1] = True


summaries = []
for name, cif in candidates:
    out = root / ".tmp" / f"challenge_{name}.gpx"
    gpx = G2sc.G2Project(str(root / ".tmp" / "main_only.gpx"), newgpx=str(out))
    hist = gpx.histogram(0)
    main = gpx.phase("SrWO4_scheelite")
    # Shared, physically admissible baseline for every record challenge.
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        hist.InstrumentParameters[key][2] = False
    hist.InstrumentParameters["U"][:2] = [0.0, 0.0]
    hist.InstrumentParameters["V"][:2] = [0.0, 0.0]
    hist.InstrumentParameters["W"][:2] = [475.0, 475.0]
    hist.InstrumentParameters["X"][:2] = [0.0, 0.0]
    hist.InstrumentParameters["Y"][:2] = [0.0, 0.0]
    hist.InstrumentParameters["Z"][:2] = [0.0, 0.0]
    hist.InstrumentParameters["SH/L"][:2] = [0.002, 0.002]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"][1] = True
    hist.Background[0][1] = True
    neutral_hap(main, hist)
    trial = gpx.add_phase(str(root / cif), phasename=name, histograms=[hist])
    neutral_hap(trial, hist)
    trial.data["Histograms"][hist.name]["Scale"][0] = 1.0

    # Re-establish common background/scales/angular correction and then cells.
    main.data["General"]["Cell"][0] = False
    trial.data["General"]["Cell"][0] = False
    gpx.refine()
    main.data["General"]["Cell"][0] = True
    trial.data["General"]["Cell"][0] = True
    gpx.refine()
    gpx.save()
    # Replay after a clean reopen.
    gpx = G2sc.G2Project(str(out))
    hist = gpx.histogram(0)
    gpx.refine()
    gpx.save()
    phases = []
    for ph in gpx.phases():
        phases.append({
            "name": ph.name,
            "scale": ph.data["Histograms"][hist.name]["Scale"][0],
            "cell": ph.data["General"]["Cell"][1:8],
            "composition": ph.composition,
        })
    summaries.append({
        "candidate": name,
        "residuals": hist.residuals,
        "shift": hist.SampleParameters["Shift"][0],
        "background": hist.Background[0][3:],
        "phases": phases,
    })
    print(json.dumps(summaries[-1], default=float, sort_keys=True))

print("SUMMARY")
print(json.dumps(summaries, default=float, indent=2))
