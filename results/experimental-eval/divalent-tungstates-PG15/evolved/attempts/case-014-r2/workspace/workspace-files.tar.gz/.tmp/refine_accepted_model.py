#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")
root = Path.cwd()
out = root / ".tmp" / "final_model_candidate.gpx"
gpx = G2sc.G2Project(
    str(root / ".tmp/final_broad_2_strain.gpx"), newgpx=str(out)
)
hist = gpx.histogram(0)
hist.InstrumentParameters["W"][2] = True
hist.InstrumentParameters["X"][2] = True
hist.SampleParameters["SurfRoughB"][1] = True
hist.Background[0][1] = True
hist.SampleParameters["Shift"][1] = True
for phase in gpx.phases():
    phase.data["General"]["Cell"][0] = True
    phase.data["Histograms"][hist.name]["Scale"][1] = True

for _ in range(3):
    gpx.refine()
gpx.save()
gpx = G2sc.G2Project(str(out))
hist = gpx.histogram(0)
for _ in range(3):
    gpx.refine()
gpx.save()

cov = gpx.data["Covariance"]["data"]
phase = gpx.phase("Sr2WO5_Pnma_prototype")
hap = phase.data["Histograms"][hist.name]
summary = {
    "residuals": dict(hist.residuals),
    "GOF": cov.get("Rvals", {}).get("GOF"),
    "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
    "profile": {
        k: hist.InstrumentParameters[k]
        for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")
    },
    "roughness_B": hist.SampleParameters["SurfRoughB"],
    "shift_um": hist.SampleParameters["Shift"],
    "sr2wo5_strain_micro": hap["Mustrain"],
    "mass_fractions": hist.ComputeMassFracs(),
    "cells": {p.name: p.get_cell() for p in gpx.phases()},
}
print(json.dumps(summary, default=float, indent=2))
