#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")
root = Path.cwd()
models = [
    ("Sr2WO5_Nd2TiO5_prototype", root / ".tmp/sr2wo5_from_nd2tio5.cif"),
    ("Sr2WO5_Gd2ReO5_prototype", root / ".tmp/sr2wo5_from_gd2reo5.cif"),
]


def neutral_hap(phase, hist) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"][1] = True


results = []
for name, cif in models:
    out = root / ".tmp" / f"replace_{name}.gpx"
    gpx = G2sc.G2Project(
        str(root / ".tmp/three_phase_baseline.gpx"), newgpx=str(out)
    )
    hist = gpx.histogram(0)
    hist.InstrumentParameters["W"][2] = False
    hist.InstrumentParameters["X"][2] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    old = gpx.phase("Sr2WO5_Pnma_prototype")
    old.data["Histograms"][hist.name]["Use"] = False
    old.data["Histograms"][hist.name]["Scale"][1] = False
    old.data["General"]["Cell"][0] = False
    for phase in (gpx.phase("SrWO4_scheelite"), gpx.phase("WO3_P21c")):
        neutral_hap(phase, hist)
        phase.data["General"]["Cell"][0] = False
    trial = gpx.add_phase(str(cif), phasename=name, histograms=[hist])
    neutral_hap(trial, hist)
    trial.data["Histograms"][hist.name]["Scale"][0] = 5.0
    trial.data["General"]["Cell"][0] = False
    gpx.refine()
    stage1 = {
        "Rwp": hist.residuals["wR"],
        "scale": trial.data["Histograms"][hist.name]["Scale"][0],
    }
    if stage1["scale"] > 1.0e-6:
        for phase in (gpx.phase("SrWO4_scheelite"), gpx.phase("WO3_P21c"), trial):
            phase.data["General"]["Cell"][0] = True
        gpx.refine()
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    hist = gpx.histogram(0)
    gpx.refine()
    gpx.save()
    trial = gpx.phase(name)
    result = {
        "model": name,
        "stage1": stage1,
        "Rwp": hist.residuals["wR"],
        "scale": trial.data["Histograms"][hist.name]["Scale"][0],
        "cell": trial.get_cell(),
    }
    results.append(result)
    print(json.dumps(result, default=float), flush=True)

print(json.dumps(results, default=float, indent=2))
