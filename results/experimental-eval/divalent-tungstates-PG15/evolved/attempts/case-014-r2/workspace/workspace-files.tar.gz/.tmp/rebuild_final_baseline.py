#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")
root = Path.cwd()


def neutralize(gpx, hist) -> None:
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Scale"][1] = True
        phase.data["General"]["Cell"][0] = True


results = []
for label, rough_start, rough_refine in (
    ("no_roughness", 0.0, False),
    ("roughness_B", 0.20, True),
):
    out = root / ".tmp" / f"final_baseline_{label}.gpx"
    gpx = G2sc.G2Project(
        str(root / ".tmp/background_10.gpx"), newgpx=str(out)
    )
    hist = gpx.histogram(0)
    neutralize(gpx, hist)
    for key in ("U", "V", "Y", "Z", "SH/L", "Polariz."):
        hist.InstrumentParameters[key][2] = False
    hist.InstrumentParameters["U"][:2] = [0.0, 0.0]
    hist.InstrumentParameters["V"][:2] = [0.0, 0.0]
    hist.InstrumentParameters["Y"][:2] = [0.0, 0.0]
    hist.InstrumentParameters["Z"][:2] = [0.0, 0.0]
    hist.InstrumentParameters["SH/L"][:2] = [0.002, 0.002]
    hist.InstrumentParameters["Polariz."][:2] = [0.5, 0.5]
    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["X"][2] = True
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [rough_start, rough_refine]
    hist.SampleParameters["Scale"] = [1.0, False]
    for _ in range(2):
        gpx.refine()
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    hist = gpx.histogram(0)
    for _ in range(2):
        gpx.refine()
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    result = {
        "model": label,
        "Rwp": hist.residuals["wR"],
        "Rp": hist.residuals["R"],
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "W": hist.InstrumentParameters["W"][1],
        "X": hist.InstrumentParameters["X"][1],
        "shift_um": hist.SampleParameters["Shift"][0],
        "roughness_B": hist.SampleParameters["SurfRoughB"][0],
        "mass_fractions": hist.ComputeMassFracs(),
        "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
    }
    results.append(result)
    print(json.dumps(result, default=float), flush=True)

print(json.dumps(results, default=float, indent=2))
