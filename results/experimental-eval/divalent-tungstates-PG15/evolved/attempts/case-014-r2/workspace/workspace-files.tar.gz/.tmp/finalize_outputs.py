#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")
root = Path.cwd()
project_path = root / "final.gpx"
gpx = G2sc.G2Project(
    str(root / ".tmp/test_scheelite_oxygen.gpx"), newgpx=str(project_path)
)
hist = gpx.histogram(0)
x = np.asarray(hist.getdata("X"), dtype=float)
hist.data["Limits"][1] = [float(x[0] - 1.0e-5), float(x[-1] + 1.0e-5)]

# Accepted common baseline: Cu Kalpha doublet, one displacement correction,
# nonnegative W/X, one low-angle roughness term, and a smooth 10-coefficient
# Chebyshev background. Rejected profile and sample terms remain neutral.
for key in ("U", "V", "Y", "Z", "SH/L", "Polariz."):
    hist.InstrumentParameters[key][2] = False
hist.InstrumentParameters["U"][:2] = [0.0, 0.0]
hist.InstrumentParameters["V"][:2] = [0.0, 0.0]
hist.InstrumentParameters["Y"][:2] = [0.0, 0.0]
hist.InstrumentParameters["Z"][:2] = [0.0, 0.0]
hist.InstrumentParameters["SH/L"][:2] = [0.002, 0.002]
hist.InstrumentParameters["Polariz."][:2] = [0.5, 0.5]
hist.InstrumentParameters["W"][2] = True
hist.InstrumentParameters["X"][2] = True
hist.Background[0][1] = True
hist.SampleParameters["Scale"] = [1.0, False]
hist.SampleParameters["Shift"][1] = True
hist.SampleParameters["SurfRoughA"] = [0.0, False]
hist.SampleParameters["SurfRoughB"][1] = True

for index, phase in enumerate(gpx.phases()):
    phase.data["General"]["Cell"][0] = True
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]
    if index == 2:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2][:] = [True, False, False]
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]
    for atom in phase.data["Atoms"]:
        atom[2] = "X" if index == 0 and atom[1].split("-")[0] == "O" else ""


def refine_to_convergence(project, histogram, minimum_cycles: int = 2) -> list[float]:
    shifts = []
    for cycle in range(12):
        project.refine()
        value = float(
            project.data["Covariance"]["data"].get("Rvals", {}).get(
                "Max shft/sig", float("inf")
            )
        )
        shifts.append(value)
        if cycle + 1 >= minimum_cycles and value < 0.03:
            break
    return shifts


first_pass = refine_to_convergence(gpx, hist)
gpx.save()

# Reopen and replay the complete measured range before export.
gpx = G2sc.G2Project(str(project_path))
hist = gpx.histogram(0)
hist.data["Limits"][1] = [float(x[0] - 1.0e-5), float(x[-1] + 1.0e-5)]
replay_pass = refine_to_convergence(gpx, hist, minimum_cycles=1)
gpx.save()

# Export only from the final, reopened project to keep project/CIF/profile
# agreement exact.
gpx = G2sc.G2Project(str(project_path))
hist = gpx.histogram(0)
phase_exports = [
    (gpx.phase("SrWO4_scheelite"), root / "SrWO4_scheelite.cif"),
    (gpx.phase("WO3_P21c"), root / "WO3_monoclinic_P21n.cif"),
    (
        gpx.phase("Sr2WO5_Pnma_prototype"),
        root / "Sr2WO5_Pnma_prototype.cif",
    ),
]
for phase, output in phase_exports:
    phase.export_CIF(str(output))

x = np.asarray(hist.getdata("X"), dtype=float)
y_obs = np.asarray(hist.getdata("Yobs"), dtype=float)
y_calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
background = np.asarray(hist.getdata("Background"), dtype=float)
difference = y_obs - y_calc
with (root / "fit.csv").open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_counts",
            "calculated_counts",
            "difference_counts",
            "background_counts",
        ]
    )
    writer.writerows(
        zip(
            (f"{value:.8f}" for value in x),
            (f"{value:.6f}" for value in y_obs),
            (f"{value:.6f}" for value in y_calc),
            (f"{value:.6f}" for value in difference),
            (f"{value:.6f}" for value in background),
        )
    )

masses = hist.ComputeMassFracs()
covariance = gpx.data["Covariance"]["data"]
rvals = covariance.get("Rvals", {})
phase_specs = [
    {
        "name": "SrWO4 (scheelite)",
        "formula": "SrWO4",
        "space_group": "I 41/a",
        "cif_path": "SrWO4_scheelite.cif",
        "project_phase": "SrWO4_scheelite",
        "phase_index": 0,
        "structure_status": "identified; cell and oxygen coordinates refined",
    },
    {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/n (No. 14; setting-equivalent to P 21/c)",
        "cif_path": "WO3_monoclinic_P21n.cif",
        "project_phase": "WO3_P21c",
        "phase_index": 1,
        "structure_status": "identified; literature coordinates and refined cell",
    },
    {
        "name": "Sr2WO5 (orthorhombic prototype)",
        "formula": "Sr2WO5",
        "space_group": "Pnma",
        "cif_path": "Sr2WO5_Pnma_prototype.cif",
        "project_phase": "Sr2WO5_Pnma_prototype",
        "phase_index": 2,
        "structure_status": "provisional Ba2ReO5-derived prototype; cell refined",
    },
]
phases = []
for spec in phase_specs:
    project_phase = spec.pop("project_phase")
    index = spec.pop("phase_index")
    fraction, fraction_esd = masses[project_phase]
    phase = gpx.phase(project_phase)
    phases.append(
        {
            **spec,
            "weight_fraction": float(fraction),
            "weight_percent": float(100.0 * fraction),
            "formal_weight_fraction_esd": float(fraction_esd),
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
            "Rf_percent": float(hist.residuals[f"{index}:0:Rf"]),
        }
    )

result = {
    "phases": phases,
    "fit_statistics": {
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rp_percent": float(hist.residuals["R"]),
        "Rexp_percent": float(hist.residuals["wRmin"]),
        "GOF": float(rvals.get("GOF")),
        "chi_square": float(rvals.get("chisq")),
        "n_observations": int(rvals.get("Nobs")),
        "n_refined_variables": int(rvals.get("Nvars")),
        "weighting": "sigma=sqrt(observed counts); no pointwise uncertainties supplied",
        "two_theta_range_deg": [float(x[0]), float(x[-1])],
    },
    "files": {"project": "final.gpx", "profile": "fit.csv"},
    "normalization": "Weight fractions sum to one over the three modeled crystalline phases; amorphous/unmodeled material is excluded.",
    "uncertainty_note": "Formal covariance errors exclude phase-model and fixed-ADP uncertainty; see report.md.",
}
with (root / "result.json").open("w") as handle:
    json.dump(result, handle, indent=2)
    handle.write("\n")

print(
    json.dumps(
        {
            "first_pass_shifts": first_pass,
            "replay_pass_shifts": replay_pass,
            "result": result,
            "profile_endpoints": {
                "first": [x[0], y_obs[0], y_calc[0], background[0]],
                "last": [x[-1], y_obs[-1], y_calc[-1], background[-1]],
            },
        },
        indent=2,
    )
)
