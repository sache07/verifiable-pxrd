#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")
root = Path.cwd()
source = root / ".tmp" / "final_baseline_roughness_B.gpx"


def reset_broadening(gpx, hist) -> None:
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
        hap["Mustrain"][2][:] = [False, False, False]


results = []
for phase_index in range(3):
    for mode in ("size", "strain"):
        out = root / ".tmp" / f"final_broad_{phase_index}_{mode}.gpx"
        gpx = G2sc.G2Project(str(source), newgpx=str(out))
        hist = gpx.histogram(0)
        reset_broadening(gpx, hist)
        hist.InstrumentParameters["W"][2] = False
        hist.InstrumentParameters["X"][2] = False
        hist.SampleParameters["SurfRoughB"][1] = False
        target = gpx.phase(phase_index)
        hap = target.data["Histograms"][hist.name]
        if mode == "size":
            hap["Size"][1][0] = 1.0
            hap["Size"][2][0] = True
        else:
            hap["Mustrain"][1][0] = 500.0
            hap["Mustrain"][2][0] = True
        gpx.refine()
        gpx.save()
        gpx = G2sc.G2Project(str(out))
        hist = gpx.histogram(0)
        gpx.refine()
        gpx.save()
        target = gpx.phase(phase_index)
        hap = target.data["Histograms"][hist.name]
        cov = gpx.data["Covariance"]["data"]
        results.append(
            {
                "phase": target.name,
                "mode": mode,
                "Rwp": hist.residuals["wR"],
                "Rf": hist.residuals.get(f"{phase_index}:0:Rf"),
                "size_um": hap["Size"][1][0],
                "strain_micro": hap["Mustrain"][1][0],
                "converged": cov.get("Rvals", {}).get("converged"),
                "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
                "vary": cov.get("varyList", []),
                "sig": list(cov.get("sig", [])),
            }
        )
        print(json.dumps(results[-1], default=float), flush=True)

print(json.dumps(results, default=float, indent=2))
