#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")
root = Path.cwd()
models = [
    ("WO3_Pnma_alt", root / ".tmp/wo3_pnma_start.cif"),
    ("WO3_P21m_alt", root / ".tmp/wo3_p21m_start.cif"),
]


def neutral_hap(phase, hist) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"][1] = True


results = []
for name, cif in models:
    out = root / ".tmp" / f"replace_{name}.gpx"
    gpx = G2sc.G2Project(
        str(root / ".tmp/three_phase_baseline.gpx"), newgpx=str(out)
    )
    hist = gpx.histogram(0)
    hist.InstrumentParameters["W"][2] = False
    hist.InstrumentParameters["X"][2] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    old = gpx.phase("WO3_P21c")
    old.data["Histograms"][hist.name]["Use"] = False
    old.data["Histograms"][hist.name]["Scale"][1] = False
    old.data["General"]["Cell"][0] = False
    for phase in (gpx.phase("SrWO4_scheelite"), gpx.phase("Sr2WO5_Pnma_prototype")):
        neutral_hap(phase, hist)
        phase.data["General"]["Cell"][0] = False
    trial = gpx.add_phase(str(cif), phasename=name, histograms=[hist])
    neutral_hap(trial, hist)
    trial.data["Histograms"][hist.name]["Scale"][0] = 2.4
    trial.data["General"]["Cell"][0] = False

    # Scale first under the common nuisance model.
    gpx.refine()
    scale_stage = trial.data["Histograms"][hist.name]["Scale"][0]

    # Then permit all active cells and replay from disk.
    for phase in (gpx.phase("SrWO4_scheelite"), gpx.phase("Sr2WO5_Pnma_prototype"), trial):
        phase.data["General"]["Cell"][0] = True
    gpx.refine()
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    hist = gpx.histogram(0)
    gpx.refine()
    gpx.save()
    trial = gpx.phase(name)
    result = {
        "model": name,
        "scale_stage": scale_stage,
        "Rwp": hist.residuals["wR"],
        "Rf": hist.residuals.get("3:0:Rf"),
        "cell": trial.get_cell(),
        "scale": trial.data["Histograms"][hist.name]["Scale"][0],
    }
    results.append(result)
    print(json.dumps(result, default=float), flush=True)

print(json.dumps(results, default=float, indent=2))
