#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")
root = Path.cwd()
out = root / ".tmp" / "three_phase_baseline.gpx"
gpx = G2sc.G2Project(
    str(root / ".tmp" / "three_phase_sr2wo5_contracted_test.gpx"),
    newgpx=str(out),
)
hist = gpx.histogram(0)

# Rebuild a common profile after the inventory change. Keep rejected terms at
# neutral values and refine only the nonnegative W/X pair.
for key in ("U", "V", "Y", "Z", "SH/L", "Polariz."):
    hist.InstrumentParameters[key][2] = False
hist.InstrumentParameters["U"][:2] = [0.0, 0.0]
hist.InstrumentParameters["V"][:2] = [0.0, 0.0]
hist.InstrumentParameters["Y"][:2] = [0.0, 0.0]
hist.InstrumentParameters["Z"][:2] = [0.0, 0.0]
hist.InstrumentParameters["SH/L"][:2] = [0.002, 0.002]
hist.InstrumentParameters["Polariz."][:2] = [0.5, 0.5]
hist.InstrumentParameters["W"][2] = True
hist.InstrumentParameters["X"][2] = True
hist.Background[0][1] = True
hist.SampleParameters["Shift"][1] = True
hist.SampleParameters["SurfRoughA"] = [0.0, False]
hist.SampleParameters["SurfRoughB"][1] = False
hist.SampleParameters["Scale"] = [1.0, False]
for phase in gpx.phases():
    phase.data["General"]["Cell"][0] = True
    phase.data["Histograms"][hist.name]["Scale"][1] = True

gpx.refine()
stage1 = {
    "residuals": dict(hist.residuals),
    "W": hist.InstrumentParameters["W"][1],
    "X": hist.InstrumentParameters["X"][1],
    "roughB": hist.SampleParameters["SurfRoughB"][0],
}

# Re-estimate the single accepted low-angle roughness term under the rebuilt
# profile, while retaining the same smooth six-term background.
hist.SampleParameters["SurfRoughB"][1] = True
gpx.refine()
gpx.save()

# Full-range reopen/replay.
gpx = G2sc.G2Project(str(out))
hist = gpx.histogram(0)
gpx.refine()
gpx.save()
summary = {
    "stage1": stage1,
    "final_residuals": dict(hist.residuals),
    "profile": {
        k: hist.InstrumentParameters[k]
        for k in ("U", "V", "W", "X", "Y", "Z", "SH/L")
    },
    "sample": {
        k: hist.SampleParameters[k]
        for k in ("Shift", "SurfRoughA", "SurfRoughB")
    },
    "mass_fractions": hist.ComputeMassFracs(),
    "cells": {p.name: p.get_cell() for p in gpx.phases()},
}
print(json.dumps(summary, default=float, indent=2))
