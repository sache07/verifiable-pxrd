#!/usr/bin/env python3
"""Approximate profile screen for chemically plausible COD records.

This is deliberately not the final refinement.  It holds a common angular
correction and a smooth background while scanning candidate cell scale and
Gaussian width, then solves only nonnegative phase scales.  The purpose is to
rank records for subsequent GSAS-II tests without allowing the background to
absorb their peak families.
"""

from __future__ import annotations

import gzip
import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Lattice, Structure
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.optimize import nnls


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")
L1 = 1.540598
L2 = 1.544426
KA2_RATIO = 0.5
ANGULAR_COS = 0.394


def cif_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def refined_scheelite() -> Structure:
    source = Structure.from_file(cif_path("1546036"))
    source.lattice = Lattice.tetragonal(5.42107, 11.94786)
    return source


def sticks(structure: Structure) -> tuple[np.ndarray, np.ndarray]:
    pattern = XRDCalculator(wavelength=L1).get_pattern(
        structure, two_theta_range=(8.0, 102.0), scaled=False
    )
    return np.asarray(pattern.x), np.asarray(pattern.y)


def transform_positions(pos: np.ndarray, cell_scale: float, wavelength: float) -> np.ndarray:
    # Isotropic direct-cell scaling followed by wavelength change and the one
    # shared cos(theta) correction.  Invalid high-angle values are discarded
    # by the caller.
    theta = np.radians(pos / 2.0)
    arg = np.sin(theta) * (wavelength / L1) / cell_scale
    out = np.full_like(arg, np.nan)
    valid = np.abs(arg) < 1.0
    out[valid] = np.degrees(2.0 * np.arcsin(arg[valid]))
    out[valid] += ANGULAR_COS * np.cos(np.radians(out[valid] / 2.0))
    return out


def profile(
    x: np.ndarray,
    pos: np.ndarray,
    intensity: np.ndarray,
    cell_scale: float,
    fwhm_30: float,
    slope: float = 0.0025,
) -> np.ndarray:
    out = np.zeros_like(x)
    step = float(np.median(np.diff(x)))
    for wavelength, ratio in ((L1, 1.0), (L2, KA2_RATIO)):
        centers = transform_positions(pos, cell_scale, wavelength)
        # Linear stick deposition followed by one constant-width convolution
        # is sufficient for fast record ranking; GSAS-II supplies the final
        # angle-dependent profile.
        valid = np.isfinite(centers) & (centers >= x[0]) & (centers <= x[-1])
        indices = (centers[valid] - x[0]) / step
        lower = np.floor(indices).astype(int)
        frac = indices - lower
        values = intensity[valid] * ratio
        np.add.at(out, lower, values * (1.0 - frac))
        upper_ok = lower + 1 < len(out)
        np.add.at(out, lower[upper_ok] + 1, values[upper_ok] * frac[upper_ok])
    sigma_points = fwhm_30 / 2.35482 / step
    out = gaussian_filter1d(out, sigma_points)
    norm = np.linalg.norm(out)
    return out / norm if norm else out


def candidate_records() -> list[tuple[str, str, int, float | None]]:
    with gzip.open(INDEX, "rt") as handle:
        database = json.load(handle)
    records: list[tuple[str, str, int, float | None]] = []
    for system, rows in database.items():
        elements = set(system.replace("-", " ").split())
        if (
            elements
            and elements <= {"Sr", "W", "O", "C"}
            and elements & {"Sr", "W"}
            and "O" in elements
        ):
            for formula, cod_id, space_group, quality in rows:
                records.append((formula, str(cod_id), int(space_group), quality))
    return records


def main() -> None:
    data = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
    x = data["two_theta_deg"]
    y = data["intensity"]
    step = float(np.median(np.diff(x)))
    # Broad lower-envelope background; all candidate comparisons use exactly
    # this same residual and phase/profile assumptions.
    win = int(round(2.4 / step)) | 1
    background = gaussian_filter1d(percentile_filter(y, 12, size=win), win / 11)
    target = np.maximum(y - background, 0.0)
    weights = 1.0 / np.sqrt(np.maximum(y, 25.0))

    main_pos, main_i = sticks(refined_scheelite())
    main_profile = profile(x, main_pos, main_i, 1.0, 0.24)
    base_scale = nnls((main_profile * weights[:, None]), target * weights)[0]
    base_calc = main_profile * base_scale[0]
    base_sse = float(np.sum(((target - base_calc) * weights) ** 2))

    results = []
    for formula, cod_id, sg, quality in candidate_records():
        if cod_id == "1546036":
            continue
        path = cif_path(cod_id)
        if not path.is_file():
            continue
        try:
            structure = Structure.from_file(path)
            pos, inten = sticks(structure)
        except Exception:
            continue
        best = None
        for scale in np.linspace(0.94, 1.06, 49):
            for fwhm in (0.16, 0.22, 0.30, 0.40, 0.52):
                trial = profile(x, pos, inten, scale, fwhm)
                design = np.column_stack((main_profile, trial))
                coeff = nnls(design * weights[:, None], target * weights)[0]
                calc = design @ coeff
                sse = float(np.sum(((target - calc) * weights) ** 2))
                candidate = (sse, scale, fwhm, coeff[1], coeff[0])
                if best is None or candidate < best:
                    best = candidate
        assert best is not None
        results.append(
            {
                "formula": formula,
                "cod_id": cod_id,
                "sg": sg,
                "quality": quality,
                "improvement_pct": 100.0 * (base_sse - best[0]) / base_sse,
                "cell_scale": best[1],
                "fwhm30": best[2],
                "candidate_scale": best[3],
                "main_scale": best[4],
                "cell": [*structure.lattice.abc, *structure.lattice.angles],
            }
        )
    results.sort(key=lambda row: row["improvement_pct"], reverse=True)
    print(json.dumps({"base_sse": base_sse, "results": results[:40]}, indent=2))


if __name__ == "__main__":
    main()
