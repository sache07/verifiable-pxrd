#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")
root = Path.cwd()
source = root / ".tmp" / "two_phase_roughB.gpx"
out = root / ".tmp" / "three_phase_sr2wo5_contracted_test.gpx"
gpx = G2sc.G2Project(str(source), newgpx=str(out))
hist = gpx.histogram(0)


def neutral_hap(phase) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1.0e6, 1.0e6, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"][1] = True


for phase in gpx.phases():
    neutral_hap(phase)
    phase.data["General"]["Cell"][0] = False

trial = gpx.add_phase(
    str(root / ".tmp" / "sr2wo5_contracted_start.cif"),
    phasename="Sr2WO5_Pnma_prototype",
    histograms=[hist],
)
neutral_hap(trial)
trial.data["Histograms"][hist.name]["Scale"][0] = 1.0
trial.data["General"]["Cell"][0] = False

# Stage 1: establish whether the parent-cell prototype has positive scale.
hist.Background[0][1] = True
hist.SampleParameters["Shift"][1] = True
hist.SampleParameters["SurfRoughB"][1] = False
gpx.refine()
stage1 = {
    "residuals": dict(hist.residuals),
    "scales": {
        p.name: p.data["Histograms"][hist.name]["Scale"][0]
        for p in gpx.phases()
    },
}

# Stage 2: only after scale testing, allow all cells to adapt and reconverge.
for phase in gpx.phases():
    phase.data["General"]["Cell"][0] = True
gpx.refine()
gpx.save()

# Required replay from disk over the complete range.
gpx = G2sc.G2Project(str(out))
hist = gpx.histogram(0)
gpx.refine()
gpx.save()
summary = {
    "stage1": stage1,
    "final_residuals": dict(hist.residuals),
    "shift": hist.SampleParameters["Shift"][0],
    "rough_b": hist.SampleParameters["SurfRoughB"][0],
    "mass_fractions": hist.ComputeMassFracs(),
    "phases": {
        p.name: {
            "scale": p.data["Histograms"][hist.name]["Scale"][0],
            "cell": p.get_cell(),
        }
        for p in gpx.phases()
    },
}
print(json.dumps(summary, default=float, indent=2))
