#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("all")
root = Path.cwd()
gpx = G2sc.G2Project(str(root / ".tmp" / "initial.gpx"), newgpx=str(root / ".tmp" / "main_only.gpx"))
hist = gpx.histogram(0)
phase = gpx.phase("SrWO4_scheelite")

# One scale convention: sample scale fixed, phase scale refined.
hist.SampleParameters["Scale"] = [1.0, False]
hist.SampleParameters["Shift"] = [-688.0, False]
hist.SampleParameters["Transparency"] = [0.0, False]
hist.SampleParameters["SurfRoughA"] = [0.0, False]
hist.SampleParameters["SurfRoughB"] = [0.0, False]
phase.data["Histograms"][hist.name]["Scale"] = [0.1, True]
hap = phase.data["Histograms"][hist.name]
# Neutral phase broadening for the common-profile baseline.
hap["Size"][0] = "isotropic"
hap["Size"][1][:] = [1.0e6, 1.0e6, 1.0]
hap["Size"][2][:] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
hap["Mustrain"][2][:] = [False, False, False]

# Smooth low-order background.
hist.set_refinements({
    "Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": 6,
        "coeffs": [900.0, -400.0, 250.0, -100.0, 50.0, -20.0],
    }
})

def snapshot(label: str) -> None:
    print("SNAPSHOT", label)
    print("residuals", json.dumps(hist.residuals, default=float, sort_keys=True))
    print("cell", phase.data["General"]["Cell"])
    print("scale", phase.data["Histograms"][hist.name]["Scale"])
    print("sample", {k: hist.SampleParameters[k] for k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")})
    print("instrument", {k: hist.InstrumentParameters[k] for k in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Zero", "I(L2)/I(L1)")})
    print("background", hist.Background[0])

gpx.refine()
snapshot("background_scale")

# Refit the single physically meaningful angular correction with the cell.
hist.set_refinements({"Sample Parameters": ["Shift"]})
phase.set_refinements({"Cell": True})
gpx.refine()
snapshot("shift_cell")

# Common instrumental width: nonnegative low-dimensional Gaussian U/W first;
# V/Y/Z and Lorentz X remain neutral for this baseline trial.
hist.InstrumentParameters["X"][:2] = [0.0, 0.0]
hist.set_refinements({"Instrument Parameters": ["U", "W"]})
gpx.refine()
snapshot("profile")
gpx.save()
