#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")
root = Path.cwd()
axes = ([0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 0, 1])
results = []
for axis in axes:
    tag = "".join(map(str, axis))
    out = root / ".tmp" / f"texture_{tag}.gpx"
    gpx = G2sc.G2Project(
        str(root / ".tmp/three_phase_baseline.gpx"), newgpx=str(out)
    )
    hist = gpx.histogram(0)
    hist.InstrumentParameters["W"][2] = False
    hist.InstrumentParameters["X"][2] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    for phase in gpx.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[1] = 1.0
        po[2] = False
    main = gpx.phase("SrWO4_scheelite")
    po = main.data["Histograms"][hist.name]["Pref.Ori."]
    po[3] = list(axis)
    po[2] = True
    gpx.refine()
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    hist = gpx.histogram(0)
    gpx.refine()
    gpx.save()
    main = gpx.phase("SrWO4_scheelite")
    po = main.data["Histograms"][hist.name]["Pref.Ori."]
    cov = gpx.data["Covariance"]["data"]
    vary = cov.get("varyList", [])
    sig = list(cov.get("sig", []))
    po_var = next((i for i, var in enumerate(vary) if "MD" in var), None)
    result = {
        "axis": axis,
        "Rwp": hist.residuals["wR"],
        "Rf_scheelite": hist.residuals["0:0:Rf"],
        "MD": po[1],
        "MD_esd": sig[po_var] if po_var is not None else None,
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
    }
    results.append(result)
    print(json.dumps(result, default=float), flush=True)

print(json.dumps(results, default=float, indent=2))
