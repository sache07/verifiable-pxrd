#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")
root = Path.cwd()
results = []
for order in (7, 8, 10):
    out = root / ".tmp" / f"background_{order}.gpx"
    gpx = G2sc.G2Project(
        str(root / ".tmp/three_phase_baseline.gpx"), newgpx=str(out)
    )
    hist = gpx.histogram(0)
    hist.InstrumentParameters["W"][2] = False
    hist.InstrumentParameters["X"][2] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    background = hist.Background[0]
    background[2] = order
    while len(background) < 3 + order:
        background.append(0.0)
    del background[3 + order :]
    background[1] = True
    gpx.refine()
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    hist = gpx.histogram(0)
    gpx.refine()
    gpx.save()
    b = np.asarray(hist.getdata("Background"))
    result = {
        "order": order,
        "Rwp": hist.residuals["wR"],
        "Rp": hist.residuals["R"],
        "background_min": float(b.min()),
        "background_max": float(b.max()),
        "background_at_10": float(b[0]),
        "background_at_100": float(b[-1]),
        "coefficients": hist.Background[0][3:],
    }
    results.append(result)
    print(json.dumps(result, default=float), flush=True)

print(json.dumps(results, default=float, indent=2))
