#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")
root = Path.cwd()
cod = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
candidates = [
    ("Sr3WO6_P21c_prototype", root / ".tmp/sr3wo6_refined_trial.cif"),
    ("Sr3W2O9_C2c", root / ".tmp/sr3w2o9_start.cif"),
    ("SrWO4_fergusonite", root / ".tmp/srwo4_fergusonite_start.cif"),
    ("SrCO3_Pnma", root / ".tmp/srco3_pnma_start.cif"),
    ("SrCO3_R3m", cod / "1/53/91/1539128.cif"),
    ("SrO_Fm3m", cod / "7/20/06/7200689.cif"),
    ("SrO2_I4mmm", cod / "1/01/01/1010114.cif"),
    ("SrO2_Pnma", cod / "9/00/81/9008161.cif"),
]


def neutral_hap(phase, hist) -> None:
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Scale"][1] = True


results = []
for name, cif in candidates:
    out = root / ".tmp" / f"final_challenge_{name}.gpx"
    gpx = G2sc.G2Project(
        str(root / ".tmp" / "final_baseline_roughness_B.gpx"), newgpx=str(out)
    )
    hist = gpx.histogram(0)
    hist.InstrumentParameters["W"][2] = False
    hist.InstrumentParameters["X"][2] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    for phase in gpx.phases():
        neutral_hap(phase, hist)
        phase.data["General"]["Cell"][0] = False
    trial = gpx.add_phase(str(cif), phasename=name, histograms=[hist])
    neutral_hap(trial, hist)
    trial.data["Histograms"][hist.name]["Scale"][0] = 0.1
    trial.data["General"]["Cell"][0] = False
    gpx.refine()
    gpx.save()
    gpx = G2sc.G2Project(str(out))
    hist = gpx.histogram(0)
    gpx.refine()
    gpx.save()
    trial = gpx.phase(name)
    masses = hist.ComputeMassFracs()
    cov = gpx.data["Covariance"]["data"]
    result = {
        "candidate": name,
        "Rwp": hist.residuals["wR"],
        "candidate_scale": trial.data["Histograms"][hist.name]["Scale"][0],
        "candidate_weight_fraction": masses[name][0],
        "candidate_weight_esd": masses[name][1],
        "cell": trial.get_cell(),
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_over_sigma": cov.get("Rvals", {}).get("Max shft/sig"),
    }
    results.append(result)
    print(json.dumps(result, default=float), flush=True)

print("SUMMARY")
print(json.dumps(results, default=float, indent=2))
