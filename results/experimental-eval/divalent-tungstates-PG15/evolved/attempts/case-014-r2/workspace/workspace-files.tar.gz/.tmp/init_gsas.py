#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")
root = Path.cwd()
gpx = G2sc.G2Project(newgpx=str(root / ".tmp" / "initial.gpx"))
hist = gpx.add_powder_histogram(
    str(root / ".tmp" / "pattern.xye"),
    str(root / ".tmp" / "cu_ka_bb.instprm"),
    fmthint="xye",
)
main = gpx.add_phase(
    str(root / ".tmp" / "srwo4_start.cif"),
    phasename="SrWO4_scheelite",
    histograms=[hist],
)
main.data["General"]["Cell"][1:7] = [5.42107, 5.42107, 11.94786, 90.0, 90.0, 90.0]
from GSASII import GSASIIlattice as G2lat
main.data["General"]["Cell"][7] = G2lat.calc_V(
    G2lat.cell2A(main.data["General"]["Cell"][1:7])
)
hist.Limits("lower", 10.01)
hist.Limits("upper", 99.99)
gpx.save()
print("hist", hist.name)
print("instrument", json.dumps(hist.InstrumentParameters, default=str, indent=2))
print("sample", json.dumps(hist.SampleParameters, default=str, indent=2))
print("background", json.dumps(hist.Background, default=str, indent=2))
print("phase cell", main.data["General"]["Cell"])
print("HAP", json.dumps(main.data["Histograms"][hist.name], default=str, indent=2))
