#!/usr/bin/env python3
"""Build and refine the Cu-W-O powder model in GSAS-II."""

from pathlib import Path
import json
import math
import sys

import numpy as np

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "instrument.instprm"
START_CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/4/00/08/4000806.cif"
)
WORK_GPX = ROOT / "work.gpx"


def set_cell(phase, cell):
    phase.data["General"]["Cell"][1:7] = list(cell)
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def summarize(gpx, label):
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    hap = phase.data["Histograms"][hist.name]
    print(f"\n--- {label} ---")
    print(
        "R-values",
        {k: hist.data["data"][0].get(k) for k in
         ("wR", "R", "Rb", "wRb", "wRmin", "Durbin-Watson")},
    )
    print("cell", phase.data["General"]["Cell"])
    print(
        "inst",
        {k: v for k, v in inst.items() if k in {
            "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L",
            "I(L2)/I(L1)", "Polariz."
        }},
    )
    print("scale", hap["Scale"])
    print("size", hap["Size"])
    print("mustrain", hap["Mustrain"])
    print("prefori", hap["Pref.Ori."])
    print("background", hist.data["Background"][0])


def main():
    G2sc.SetPrintLevel("all")
    if WORK_GPX.exists():
        WORK_GPX.unlink()
    gpx = G2sc.G2Project(newgpx=str(WORK_GPX))
    hist = gpx.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma"
    )
    phase = gpx.add_phase(
        str(START_CIF), phasename="CuWO4", histograms=[hist], fmthint="CIF"
    )
    hist.Limits("lower", float(hist.getdata("X")[0]))
    hist.Limits("upper", float(hist.getdata("X")[-1]))
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 5,
            "coeffs": [1500.0, -650.0, 250.0, -100.0, 50.0],
        }
    })
    set_cell(
        phase,
        (4.71059, 5.84514, 4.88348, 91.65684, 92.53538, 82.74808),
    )
    phase.set_HAP_refinements({"Scale": True})
    # Neutralize phase-specific broadening and preferred orientation.
    hap = phase.data["Histograms"][hist.name]
    # Keep the overall histogram scale fixed; the HAP scale carries phase amount.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hap["Scale"][0] = 92.0
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0e6
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    gpx.set_Controls("cycles", 12)
    gpx.save()
    summarize(gpx, "initial")
    gpx.refine()
    summarize(gpx, "background + scale")
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    gpx.refine()
    summarize(gpx, "cell + zero")
    hist.set_refinements({"Instrument Parameters": ["W"]})
    gpx.refine()
    summarize(gpx, "W-only profile")
    gpx.save(str(ROOT / "baseline.gpx"))

    # Effective polarization is not supplied in metadata; test it before texture.
    hist = gpx.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    gpx.refine()
    summarize(gpx, "polarization")
    gpx.save(str(ROOT / "polarization.gpx"))

    # The exact-composition source record was measured under pressure. Refine
    # relative coordinates while fixing W to define the structural origin.
    phase = gpx.phase(0)
    for atom in phase.atoms():
        atom.refinement_flags = " " if atom.element == "W" else "X"
    gpx.refine()
    summarize(gpx, "relative coordinates")
    gpx.save(str(ROOT / "coordinates.gpx"))
    gpx.save(str(WORK_GPX))


if __name__ == "__main__":
    main()
