#!/usr/bin/env python3
"""Create a conservative trial Rietveld fit for candidate screening."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_phase(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1000.0
    hap["Size"][1][1] = 1000.0
    hap["Size"][1][2] = 0.5
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][1][2] = 0.5
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def summarize(project, label: str) -> None:
    hist = project.histogram(0)
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print("instrument")
    for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "I(L2)/I(L1)"):
        print(key, hist.InstrumentParameters.get(key))
    print("background", hist.Background[0])
    print("sample", {k: v for k, v in hist.SampleParameters.items() if k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")})
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("phase", phase.name, "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "mustrain", hap["Mustrain"], "PO", hap["Pref.Ori."])
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fraction error", repr(exc))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("ids", nargs="+", help="COD ids")
    parser.add_argument("--names", nargs="*")
    parser.add_argument("--output", default="trial.gpx")
    parser.add_argument("--cell", action="store_true")
    parser.add_argument("--profile", action="store_true")
    args = parser.parse_args()

    out = Path(args.output)
    names = args.names or args.ids
    if len(names) != len(args.ids):
        raise SystemExit("--names must have one item per COD id")

    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    hist.set_refinements({
        "Limits": {"low": 10.0, "high": 100.0},
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 8},
    })
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    # Avoid the exact degeneracy between the histogram and phase scales.
    hist.SampleParameters["Scale"] = [1.0, False]

    phases = []
    for cod_id, name in zip(args.ids, names):
        phase = project.add_phase(
            str(cod_path(cod_id)), phasename=f"{name} [COD {cod_id}]",
            histograms=[hist], fmthint="CIF"
        )
        neutralize_phase(phase, hist.name)
        phase.set_HAP_refinements({"Scale": True})
        phases.append(phase)

    # Background and scales with a peak-matched fixed zero.
    project.do_refinements([{}])
    summarize(project, "background + scales")

    # One angular correction, then reconverge all active parameters.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.do_refinements([{}, {}])
    summarize(project, "+ zero")

    # Cell metrics only after the common angular correction has settled.
    if args.cell:
        for phase in phases:
            phase.set_refinements({"Cell": True})
        project.do_refinements([{}, {}])
        summarize(project, "+ cells")

    # Establish a low-dimensional, nonnegative common profile. V/Y/Z stay zero.
    if args.profile:
        inst = hist.InstrumentParameters
        inst["U"][1] = 100.0
        inst["W"][1] = 35.0
        hist.set_refinements({"Instrument Parameters": ["W"]})
        project.do_refinements([{}, {}])
        summarize(project, "+ W")
        hist.set_refinements({"Instrument Parameters": ["U"]})
        project.do_refinements([{}, {}])
        summarize(project, "+ U/W")
        inst["X"][1] = 0.5
        hist.set_refinements({"Instrument Parameters": ["X"]})
        project.do_refinements([{}, {}])
        summarize(project, "+ U/W/X")

    project.save(str(out))


if __name__ == "__main__":
    main()
