#!/usr/bin/env python3
"""Apply one controlled refinement challenge to an existing GSAS-II project."""

from __future__ import annotations

import argparse

from GSASII import GSASIIscriptable as G2sc

from refine_trial import summarize


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("mode", choices=["polarization", "shl", "texture", "size", "strain", "roughness"])
    parser.add_argument("--phase", type=int, default=0)
    parser.add_argument("--axis", nargs=3, type=int, default=[0, 0, 1])
    args = parser.parse_args()

    project = G2sc.G2Project(args.input)
    project.save(args.output)
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    label = args.mode

    if args.mode == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif args.mode == "shl":
        hist.InstrumentParameters["SH/L"][1] = 0.01
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    elif args.mode == "texture":
        hap = phase.data["Histograms"][hist.name]["Pref.Ori."]
        hap[0] = "MD"
        hap[1] = 1.0
        hap[2] = True
        hap[3] = list(args.axis)
        label += f" phase={args.phase} axis={tuple(args.axis)}"
    elif args.mode == "size":
        phase.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=1.0)
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True,
                                                   "LGmix": {"value": 1.0, "refine": False}}})
        label += f" phase={args.phase}"
    elif args.mode == "strain":
        phase.setSampleProfile(hist, "microstrain", "isotropic", 100.0, LGmix=0.0)
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True,
                                                       "LGmix": {"value": 0.0, "refine": False}}})
        label += f" phase={args.phase}"
    elif args.mode == "roughness":
        hist.SampleParameters["SurfRoughA"] = [0.5, True]
        hist.SampleParameters["SurfRoughB"] = [0.1, True]

    project["Controls"]["data"]["max cyc"] = 6
    project.do_refinements([{}, {}])
    summarize(project, label)
    project.save(args.output)


if __name__ == "__main__":
    main()
