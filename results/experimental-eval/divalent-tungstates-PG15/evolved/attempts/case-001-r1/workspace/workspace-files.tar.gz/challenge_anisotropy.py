#!/usr/bin/env python3
"""Challenge the accepted profile with one uniaxial strain term at a time."""

from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


AXES = ([1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0],
        [1, 0, 1], [0, 1, 1], [1, 1, 1])


def run(phase_index: int, axis: list[int]) -> None:
    tag = "".join(str(i) for i in axis)
    output = Path(".tmp") / f"aniso_strain_p{phase_index}_{tag}.gpx"
    project = G2sc.G2Project("final.gpx")
    project.save(str(output))
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    initial = hap["Mustrain"][1][0] if phase_index == 1 else 50.0
    phase.setSampleProfile(
        hist, "microstrain", "uniaxial", initial, initial, axis=axis, LGmix=0.0
    )
    phase.set_HAP_refinements(
        {
            "Mustrain": {
                "type": "uniaxial",
                "direction": axis,
                "refine": True,
                "LGmix": {"value": 0.0, "refine": False},
            }
        }
    )
    project["Controls"]["data"]["max cyc"] = 8
    project.do_refinements([{}])
    project.save(str(output))
    hap = phase.data["Histograms"][hist.name]
    rv = project["Covariance"]["data"]["Rvals"]
    print(
        phase_index,
        axis,
        "Rwp",
        hist.residuals["wR"],
        "strain",
        hap["Mustrain"][1][:2],
        "shift/esd",
        rv.get("Max shft/sig"),
        "converged",
        rv.get("converged"),
        flush=True,
    )


if __name__ == "__main__":
    Path(".tmp").mkdir(exist_ok=True)
    for phase_index in (0, 1):
        for axis in AXES:
            run(phase_index, list(axis))
