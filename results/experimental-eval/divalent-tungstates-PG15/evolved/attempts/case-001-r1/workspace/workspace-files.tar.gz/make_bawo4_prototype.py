#!/usr/bin/env python3
"""Build a full-occupancy BaWO4 model from the BaMoO4 scheelite prototype."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


source = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/30/04/2300459.cif"
)
output = Path("bawo4_bamo4_prototype.cif")

parent = Structure.from_file(source)
parent.replace_species({"Mo": "W"})
model = Structure(
    Lattice.tetragonal(5.614, 12.719),
    parent.species,
    parent.frac_coords,
    coords_are_cartesian=False,
    site_properties=parent.site_properties,
)
CifWriter(model, symprec=1e-5).write_file(output)
print(output)
