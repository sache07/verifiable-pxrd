#!/usr/bin/env python3
"""Replay the accepted GSAS-II model and export the exact submitted results."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SEED = Path(".tmp/trace_aniso_low.gpx")
FINAL = Path("final.gpx")

PHASE_INFO = [
    {
        "name": "barium carbonate",
        "formula": "BaCO3",
        "space_group": "Pnma (No. 62)",
        "cif": "BaCO3.cif",
        "source_model": "COD 9010928",
        "identification_status": "identified",
    },
    {
        "name": "tungsten trioxide",
        "formula": "WO3",
        "space_group": "P21/c (No. 14, source setting)",
        "cif": "WO3.cif",
        "source_model": "COD 2311041",
        "identification_status": "identified; monoclinic/triclinic metric ambiguity remains",
    },
    {
        "name": "barium tungstate",
        "formula": "BaWO4",
        "space_group": "I41/a (No. 88)",
        "cif": "BaWO4.cif",
        "source_model": "BaMoO4 COD 2300459 prototype with isovalent Mo6+ -> W6+ substitution",
        "identification_status": "tentative trace phase",
    },
]


def configure_fixed_baseline(project: G2sc.G2Project) -> None:
    """Make the accepted baseline explicit before the final replay."""
    hist = project.histogram(0)
    x = np.asarray(hist.data["data"][1][0], dtype=float)
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]

    hist.SampleParameters["Scale"] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        hist.SampleParameters[key] = [0.0, False]

    inst = hist.InstrumentParameters
    for key in ("V", "W", "Y", "Z"):
        inst[key][1:] = [0.0, False]
    inst["SH/L"][1:] = [0.002, False]
    inst["I(L2)/I(L1)"][1:] = [0.5, False]
    for key in ("Zero", "Polariz.", "U", "X"):
        inst[key][2] = True

    for i, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        if i != 1:
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        if i != 0:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False

    # Refined cells for the two major phases; fixed prototype cell for the trace.
    project.phase(0).data["General"]["Cell"][0] = True
    project.phase(1).data["General"]["Cell"][0] = True
    project.phase(2).data["General"]["Cell"][0] = False


def replay_and_save() -> None:
    project = G2sc.G2Project(str(SEED))
    project.save(str(FINAL))
    project = G2sc.G2Project(str(FINAL))
    configure_fixed_baseline(project)
    project["Controls"]["data"]["max cyc"] = 10
    project.do_refinements([{}, {}, {}])
    project.save(str(FINAL))

    # Reopen and replay once more to verify serialized-project reproducibility.
    project = G2sc.G2Project(str(FINAL))
    project.do_refinements([{}, {}])
    project.save(str(FINAL))


def export_outputs() -> None:
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)
    cov = project["Covariance"]["data"]
    rvals = cov["Rvals"]

    if not rvals.get("converged", False):
        raise RuntimeError("Final refinement did not converge")
    if rvals.get("Max shft/sig", math.inf) > 0.05:
        raise RuntimeError("Final refinement has an excessive shift/s.u.")

    fractions = hist.ComputeMassFracs()
    if not math.isclose(sum(v[0] for v in fractions.values()), 1.0, abs_tol=1e-10):
        raise RuntimeError("Mass fractions are not normalized")

    phases_json = []
    for i, (phase, info) in enumerate(zip(project.phases(), PHASE_INFO, strict=True)):
        phase.export_CIF(info["cif"])
        frac, frac_esd = fractions[phase.name]
        cell, cell_esd = phase.get_cell_and_esd()
        item = dict(info)
        item.update(
            {
                "weight_fraction": frac,
                "weight_fraction_formal_esd": frac_esd,
                "weight_percent": 100.0 * frac,
                "weight_percent_formal_esd": 100.0 * frac_esd,
                "cell": cell,
                "cell_formal_esd": cell_esd,
                "Bragg_R_F_percent": hist.residuals.get(f"{i}:0:Rf"),
                "Bragg_R_F2_percent": hist.residuals.get(f"{i}:0:Rf^2"),
            }
        )
        phases_json.append(item)

    xy = hist.data["data"][1]
    x, yobs, weights, ycalc, ybkg = [np.asarray(xy[i], dtype=float) for i in range(5)]
    ydiff = yobs - ycalc
    with Path("fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "background_counts",
                "difference_counts_observed_minus_calculated",
            ]
        )
        for row in zip(x, yobs, ycalc, ybkg, ydiff, strict=True):
            writer.writerow([format(value, ".12g") for value in row])

    result = {
        "input_pattern": "inputs/pattern.csv",
        "metadata": "inputs/metadata.json",
        "gsasii_project": str(FINAL),
        "fit_profile": "fit.csv",
        "weight_fraction_normalization": "modeled crystalline phases only; fractions sum to 1",
        "phases": phases_json,
        "fit_statistics": {
            "Rwp_percent": hist.residuals["wR"],
            "Rp_percent": hist.residuals["R"],
            "Rexp_percent": hist.residuals["wRmin"],
            "goodness_of_fit": rvals["GOF"],
            "reduced_chi_squared": rvals["GOF"] ** 2,
            "chi_squared": rvals["chisq"],
            "observations": rvals["Nobs"],
            "refined_variables": rvals["Nvars"],
            "refinement_range_deg_2theta": [float(x[0]), float(x[-1])],
            "maximum_final_shift_over_esd": rvals["Max shft/sig"],
        },
        "measurement_model": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelengths_angstrom": [1.540598, 1.544426],
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "counting_weights": "1/observed_counts",
        },
        "uncertainty_note": (
            "Reported e.s.d. values are covariance-only. Model/source/texture uncertainty, "
            "especially for trace BaWO4, is larger."
        ),
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")

    print(json.dumps({"fit_statistics": result["fit_statistics"], "fractions": {
        p["formula"]: p["weight_fraction"] for p in phases_json
    }}, indent=2))


if __name__ == "__main__":
    replay_and_save()
    export_outputs()
