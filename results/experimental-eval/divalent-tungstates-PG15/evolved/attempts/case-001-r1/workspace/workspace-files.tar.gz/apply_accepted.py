#!/usr/bin/env python3
"""Apply the accepted common/phase profile and texture model to a trial GPX."""

from __future__ import annotations

import argparse

from GSASII import GSASIIscriptable as G2sc

from refine_trial import summarize


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()

    project = G2sc.G2Project(args.input)
    project.save(args.output)
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    inst["Polariz."][1:] = [0.73, True]
    inst["U"][1] = 90.0
    inst["W"][1:] = [0.0, False]
    inst["X"][1] = 13.7

    baco3 = project.phase(0)
    po = baco3.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 0.91
    po[2] = True
    po[3] = [1, 1, 0]

    wo3 = project.phase(1)
    wo3.setSampleProfile(hist, "microstrain", "isotropic", 5800.0, LGmix=0.0)
    wo3.set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True,
                      "LGmix": {"value": 0.0, "refine": False}}
    })

    project["Controls"]["data"]["max cyc"] = 8
    project.do_refinements([{}, {}, {}])
    summarize(project, "accepted nuisance model")
    project.save(args.output)


if __name__ == "__main__":
    main()
