#!/usr/bin/env python3
"""Exploratory reversible GSAS-II refinement for the three-phase inventory."""

from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
GPX = ROOT / "explore.gpx"


def reopen(project):
    project.save()
    return G2sc.G2Project(str(GPX))


def summarize(project, label):
    hist = project.histogram(0)
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print(
        "instrument",
        {k: tuple(v) for k, v in hist.InstrumentParameters.items()
         if k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")},
    )
    print(
        "sample",
        {k: v for k, v in hist.SampleParameters.items()
         if k in ("Scale", "DisplaceX", "DisplaceY", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
    )
    print("background", hist.Background[0])
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as err:
        print("mass fractions error", repr(err))
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        print(
            phase.name,
            "scale", hap["Scale"],
            "cell", phase.get_cell(),
            "size", hap["Size"],
            "strain", hap["Mustrain"],
            "PO", hap["Pref.Ori."],
        )


G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(str(ROOT / "probe.gpx"), newgpx=str(GPX))
hist = project.histogram(0)
project["Controls"]["data"]["max cyc"] = 8
project["Controls"]["data"]["min dM/M"] = 1e-5

# Use one fixed overall scale and phase scales for relative/absolute phase amounts.
hist.SampleParameters["Scale"] = [1.0, False]

# Initialize a smooth six-term Chebyshev background from a low-percentile envelope.
x = np.asarray(hist.getdata("X"))
y = np.asarray(hist.getdata("Yobs"))
envelope = percentile_filter(y, size=401, percentile=12, mode="nearest")
xn = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
coeff = np.polynomial.chebyshev.chebfit(xn, envelope, 5).tolist()
hist.set_refinements({
    "Background": {
        "type": "chebyschev-1",
        "refine": True,
        "no. coeffs": 6,
        "coeffs": coeff,
    }
})

# Neutral nuisance terms before testing them explicitly.
for phase in project.phases():
    hap = phase.getHAPvalues(hist)
    hap["Scale"] = [1e-3, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1e6, 1e6, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]

project = reopen(project)
project.refine()
project = reopen(project)
summarize(project, "background + scales")

# One angular correction only: refine zero while all specimen shifts stay off.
hist = project.histogram(0)
hist.InstrumentParameters["Zero"][2] = True
project.refine()
project = reopen(project)
summarize(project, "+ zero")

# Refine symmetry-constrained cells after scale/position stabilization.
for phase in project.phases():
    phase.set_refinements({"Cell": True})
project.refine()
project = reopen(project)
summarize(project, "+ cells")

# Establish a common low-dimensional nonnegative U/W/X profile.
hist = project.histogram(0)
for key, value in [("U", 2.0), ("W", 5.0), ("X", 0.1)]:
    hist.InstrumentParameters[key][1] = value
    hist.InstrumentParameters[key][2] = True
for key in ("V", "Y", "Z", "SH/L"):
    hist.InstrumentParameters[key][2] = False
project.refine()
project = reopen(project)
summarize(project, "+ common U/W/X")

# Test axial-divergence asymmetry separately.
hist = project.histogram(0)
hist.InstrumentParameters["SH/L"][2] = True
project.refine()
project = reopen(project)
summarize(project, "+ SH/L")
