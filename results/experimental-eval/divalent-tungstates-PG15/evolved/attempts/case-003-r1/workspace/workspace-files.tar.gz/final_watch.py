#!/usr/bin/env python3
"""Re-challenge chemically plausible trace phases against the final profile."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
RECORDS = {
    "cao": ("1563196", "CaO"),
    "caoh2": ("7020138", "CaOH2"),
    "ca3wo6": ("1563081", "Ca3WO6"),
    "w18o49": ("1528166", "W18O49"),
    "ca_w_bronze": ("4030741", "Ca4.26W10O30"),
}


def cif_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=RECORDS)
parser.add_argument("size", nargs="?", type=float, default=0.10)
args = parser.parse_args()
cod_id, phase_name = RECORDS[args.mode]
size_tag = f"{args.size:g}".replace(".", "p")
output = ROOT / f"final_watch_{args.mode}_{size_tag}.gpx"

G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(
    str(ROOT / "combined_plus_cawo4_size.gpx"), newgpx=str(output)
)
hist = project.histogram(0)
watch = project.add_phase(
    str(cif_path(cod_id)), phasename=phase_name, histograms=[hist], fmthint="CIF"
)
if args.mode == "w18o49":
    for atom in watch.atoms():
        atom.type = atom.element
    G2sc.SetupGeneral(watch.data, None)

project["Controls"]["data"]["max cyc"] = 8
project["Controls"]["data"]["min dM/M"] = 1e-5
hap = watch.getHAPvalues(hist)
hap["Scale"] = [0.1, True]
hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
hap["Extinction"] = [0.0, False]
hap["Size"][0] = "isotropic"
hap["Size"][1] = [args.size, 10.0, 1.0]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1] = [0.0, 0.0, 1.0]
hap["Mustrain"][2] = [False, False, False]
watch.set_refinements({"Cell": False})

project.save()
for _ in range(4):
    project.refine()
    project.save()
    project = G2sc.G2Project(str(output))

hist = project.histogram(0)
rvals = project["Covariance"]["data"].get("Rvals", {})
fractions = hist.ComputeMassFracs()
print(
    args.mode, cod_id, "fixed_size", args.size,
    "Rwp", hist.residuals.get("wR"),
    "GOF", rvals.get("GOF"),
    "maxshift", rvals.get("Max shft/sig"),
    "converged", rvals.get("converged"),
    "watch_fraction", fractions.get(phase_name),
)
