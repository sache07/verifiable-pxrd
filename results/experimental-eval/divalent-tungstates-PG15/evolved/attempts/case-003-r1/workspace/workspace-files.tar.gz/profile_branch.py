#!/usr/bin/env python3
"""Replay pruned profile branches from the same saved GSAS-II state."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=("fixed", "w_only", "wx", "uw"))
args = parser.parse_args()
output = ROOT / f"branch_{args.mode}.gpx"

G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(
    str(ROOT / "physical_plus_calcite_strain.gpx"), newgpx=str(output)
)
project["Controls"]["data"]["max cyc"] = 8
project["Controls"]["data"]["min dM/M"] = 1e-5
hist = project.histogram(0)

# Prune the unsupported CaWO4 strain and the bound/correlated calcite size.
cawo4 = project.phase("CaWO4_scheelite").getHAPvalues(hist)
cawo4["Mustrain"][1][0] = 0.0
cawo4["Mustrain"][2] = [False, False, False]
calcite = project.phase("CaCO3_calcite").getHAPvalues(hist)
calcite["Size"][1][0] = 10.0
calcite["Size"][2] = [False, False, False]

# Keep all other broadening terms as accepted in the common parent state.
for key in ("V", "Y", "Z", "SH/L"):
    hist.InstrumentParameters[key][2] = False
hist.InstrumentParameters["SH/L"][1] = 0.002

settings = {
    "fixed": {"U": (20.0, False), "W": (5.0, False), "X": (2.0, False)},
    "w_only": {"U": (0.0, False), "W": (10.0, True), "X": (0.0, False)},
    "wx": {"U": (0.0, False), "W": (10.0, True), "X": (1.0, True)},
    "uw": {"U": (10.0, True), "W": (10.0, True), "X": (0.0, False)},
}[args.mode]
for key, (value, refine) in settings.items():
    hist.InstrumentParameters[key][1] = value
    hist.InstrumentParameters[key][2] = refine

project.save()
for _ in range(3):
    project.refine()
    project.save()
    project = G2sc.G2Project(str(output))

hist = project.histogram(0)
rvals = project["Covariance"]["data"].get("Rvals", {})
print(args.mode, "Rwp", hist.residuals.get("wR"), "R", hist.residuals.get("R"),
      "GOF", rvals.get("GOF"), "maxshift", rvals.get("Max shft/sig"),
      "converged", rvals.get("converged"))
print("profile", {k: hist.InstrumentParameters[k][1:] for k in ("Zero", "U", "W", "X", "SH/L")})
print("fractions", hist.ComputeMassFracs())
for phase in project.phases():
    hap = phase.getHAPvalues(hist)
    print(phase.name, "size", hap["Size"][1:3], "strain", hap["Mustrain"][1:3])
