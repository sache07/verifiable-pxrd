#!/usr/bin/env python3
"""Compare structural source records/polymorphs under one restrained profile."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


models = {
    "baseline": ("7219229", "2311041", "1547347"),
    "wo3_alt": ("7219229", "1528915", "1547347"),
    "wo3_triclinic": ("7219229", "2106293", "1547347"),
    "cawo4_fergusonite": ("1546035", "2311041", "1547347"),
    "calcite_aragonite": ("7219229", "2311041", "5000085"),
    "calcite_monoclinic": ("7219229", "2311041", "2106394"),
}

parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=models)
args = parser.parse_args()
output = ROOT / f"candidate_{args.mode}.gpx"

G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(newgpx=str(output))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma",
)
for name, cod_id in zip(
    ("CaWO4", "WO3", "CaCO3"), models[args.mode]
):
    project.add_phase(
        str(cif_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
    )

project["Controls"]["data"]["max cyc"] = 8
project["Controls"]["data"]["min dM/M"] = 1e-5
hist.SampleParameters["Scale"] = [1.0, False]

# Reuse the same smooth background order and starting envelope for all records.
parent = G2sc.G2Project(str(ROOT / "branch_w_only.gpx"))
parent_bkg = parent.histogram(0).Background[0]
hist.Background[0] = list(parent_bkg)
hist.Background[0][1] = True

# One angular correction and a nonnegative common W-only baseline.
for key, value, refine in (
    ("Zero", 0.3023, True),
    ("U", 0.0, False),
    ("V", 0.0, False),
    ("W", 11.73, False),
    ("X", 0.0, False),
    ("Y", 0.0, False),
    ("Z", 0.0, False),
    ("SH/L", 0.002, False),
):
    hist.InstrumentParameters[key][1] = value
    hist.InstrumentParameters[key][2] = refine

start_scales = (10.6, 29.7, 56.0)
for phase, scale in zip(project.phases(), start_scales):
    phase.set_refinements({"Cell": True})
    hap = phase.getHAPvalues(hist)
    hap["Scale"] = [scale, True]
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["Extinction"] = [0.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]

# Same fixed phase-width state for the source-record challenge.
cawo4 = project.phase("CaWO4").getHAPvalues(hist)
cawo4["Size"][1][0] = 0.0253
wo3 = project.phase("WO3").getHAPvalues(hist)
wo3["Size"][1][0] = 0.163
wo3["Mustrain"][1][0] = 5590.0
carbonate = project.phase("CaCO3").getHAPvalues(hist)
carbonate["Mustrain"][1][0] = 4820.0

project.save()
for _ in range(2):
    project.refine()
    project.save()
    project = G2sc.G2Project(str(output))

# Rebuild the common profile and phase widths after accepting/rejecting the record.
hist = project.histogram(0)
hist.InstrumentParameters["W"][2] = True
project.phase("CaWO4").getHAPvalues(hist)["Size"][2][0] = True
wo3 = project.phase("WO3").getHAPvalues(hist)
wo3["Size"][2][0] = True
wo3["Mustrain"][2][0] = True
project.phase("CaCO3").getHAPvalues(hist)["Mustrain"][2][0] = True
for _ in range(3):
    project.refine()
    project.save()
    project = G2sc.G2Project(str(output))

hist = project.histogram(0)
rvals = project["Covariance"]["data"].get("Rvals", {})
print(args.mode, models[args.mode], "Rwp", hist.residuals.get("wR"),
      "R", hist.residuals.get("R"), "GOF", rvals.get("GOF"),
      "maxshift", rvals.get("Max shft/sig"), "converged", rvals.get("converged"))
print("profile", {k: hist.InstrumentParameters[k][1:] for k in ("Zero", "W")})
try:
    print("fractions", hist.ComputeMassFracs())
except Exception as err:
    print("fractions error", repr(err))
for phase in project.phases():
    hap = phase.getHAPvalues(hist)
    print(phase.name, "scale", hap["Scale"], "cell", phase.get_cell(),
          "size", hap["Size"][1:3], "strain", hap["Mustrain"][1:3])
