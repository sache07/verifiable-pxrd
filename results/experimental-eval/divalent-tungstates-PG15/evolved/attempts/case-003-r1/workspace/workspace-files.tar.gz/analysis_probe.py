#!/usr/bin/env python3
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(newgpx=str(ROOT / "probe.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma",
)
for name, cod_id in [
    ("CaWO4_scheelite", "7219229"),
    ("WO3_monoclinic", "2311041"),
    ("CaCO3_calcite", "1547347"),
]:
    project.add_phase(
        str(cod_cif(cod_id)),
        phasename=name,
        histograms=[hist],
        fmthint="CIF",
    )
project.save()

print("histogram", hist.name)
print("limits", hist.data["Limits"])
print("instrument", hist.InstrumentParameters)
print("sample", hist.SampleParameters)
print("background", hist.Background)
for phase in project.phases():
    print("phase", phase.name)
    print(" cell", phase.get_cell())
    print(" general mass", phase.data["General"].get("Mass"))
    print(" HAP", phase.getHAPvalues(hist))
    print(" warnings", phase.data.get("warnings"))
