#!/usr/bin/env python3
"""Replay the accepted model and export the exact final deliverables."""

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "combined_plus_cawo4_size.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "CaWO4": {
        "name": "calcium tungstate (scheelite)",
        "formula": "CaWO4",
        "space_group": "I 41/a",
        "space_group_number": 88,
        "cif": "CaWO4.cif",
        "cod_id": "7219229",
        "cell_z": 4,
        "systematic_uncertainty_percent_approx": 1.0,
    },
    "WO3": {
        "name": "tungsten(VI) oxide (monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "space_group_number": 14,
        "cif": "WO3.cif",
        "cod_id": "2311041",
        "cell_z": 8,
        "systematic_uncertainty_percent_approx": 2.5,
    },
    "CaCO3": {
        "name": "calcium carbonate (calcite)",
        "formula": "CaCO3",
        "space_group": "R -3 c (hexagonal setting)",
        "space_group_number": 167,
        "cif": "CaCO3.cif",
        "cod_id": "1547347",
        "cell_z": 6,
        "systematic_uncertainty_percent_approx": 2.5,
    },
}


def f(value):
    return float(value)


G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
project["Controls"]["data"]["max cyc"] = 8
project["Controls"]["data"]["min dM/M"] = 1e-5
# Set the known number of reduced formula units explicitly. GSAS-II's
# quick-CIF heuristic uses the GCD of site multiplicities, which gives Z=4
# rather than Z=8 for this WO3 model with two independent W sites.
for phase in project.phases():
    phase.data["General"]["cellZ"] = PHASE_INFO[phase.name]["cell_z"]
project.save()

# Full-range save/reopen/replay. The last saved state is the one exported below.
for _ in range(6):
    project.refine()
    project.save()
    project = G2sc.G2Project(str(FINAL))

hist = project.histogram(0)
rvals = project["Covariance"]["data"].get("Rvals", {})
if not rvals.get("converged", False):
    raise RuntimeError("Final GSAS-II replay did not converge")

fractions = hist.ComputeMassFracs()
if not np.isclose(sum(v[0] for v in fractions.values()), 1.0, atol=1e-10):
    raise RuntimeError("Crystalline phase fractions are not normalized")

# CIFs are exported from the reopened final.gpx, not from an in-memory branch.
for phase in project.phases():
    phase.export_CIF(str(ROOT / PHASE_INFO[phase.name]["cif"]))

x = hist.getdata("x")
yobs = hist.getdata("yobs")
ycalc = hist.getdata("ycalc")
background = hist.getdata("background")
difference = yobs - ycalc
fit = np.column_stack((x, yobs, ycalc, difference, background))
np.savetxt(
    ROOT / "fit.csv",
    fit,
    delimiter=",",
    header="two_theta_deg,observed_counts,calculated_counts,difference_observed_minus_calculated,background_counts",
    comments="",
    fmt="%.17g",
)

fit_stats = {
    "rwp_percent": f(hist.residuals["wR"]),
    "rp_percent": f(hist.residuals["R"]),
    "rexp_percent": f(hist.residuals["wRmin"]),
    "goodness_of_fit": f(rvals["GOF"]),
    "chi_square": f(rvals["chisq"]),
    "n_observations": int(rvals["Nobs"]),
    "n_refined_parameters": int(rvals["Nvars"]),
    "max_shift_over_esd": f(rvals["Max shft/sig"]),
    "converged": bool(rvals["converged"]),
    "two_theta_min_deg": f(x[0]),
    "two_theta_max_deg": f(x[-1]),
}

phase_results = []
for phase in project.phases():
    info = PHASE_INFO[phase.name]
    value, esd = fractions[phase.name]
    cell, cell_esd = phase.get_cell_and_esd()
    phase_results.append(
        {
            "name": info["name"],
            "formula": info["formula"],
            "space_group": info["space_group"],
            "space_group_number": info["space_group_number"],
            "cif_path": info["cif"],
            "structure_source": f"COD {info['cod_id']}",
            "weight_fraction": f(value),
            "weight_fraction_formal_esd": f(esd),
            "weight_percent": 100.0 * f(value),
            "weight_percent_formal_esd": 100.0 * f(esd),
            "weight_percent_model_systematic_uncertainty_approx": info[
                "systematic_uncertainty_percent_approx"
            ],
            "cell": {key: f(value) for key, value in cell.items()},
            "cell_esd": {key: f(value) for key, value in cell_esd.items()},
        }
    )

result = {
    "modeled_crystalline_fraction_basis": "normalized to the three modeled crystalline phases; sum = 1",
    "phases": phase_results,
    "fit_statistics": fit_stats,
    "weighting_note": (
        "Pointwise uncertainties were not supplied; the refinement used "
        "count-statistical GSAS-II weights derived from the raw counts."
    ),
    "unmodeled_trace_note": (
        "No fourth phase was reliable: sharp-phase sensitivity is roughly "
        "sub-1 wt%, while non-specific broad-phase upper bounds approach 2 wt%."
    ),
    "project_path": "final.gpx",
    "fit_profile_path": "fit.csv",
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

rows = []
for item in phase_results:
    cell = item["cell"]
    if item["formula"] == "CaWO4":
        cell_text = f"a={cell['length_a']:.5f}, c={cell['length_c']:.5f} Å"
    elif item["formula"] == "WO3":
        cell_text = (
            f"a={cell['length_a']:.5f}, b={cell['length_b']:.5f}, "
            f"c={cell['length_c']:.5f} Å, β={cell['angle_beta']:.4f}°"
        )
    else:
        cell_text = f"a={cell['length_a']:.5f}, c={cell['length_c']:.5f} Å"
    rows.append(
        f"| {item['formula']} | {item['space_group']} | "
        f"{item['weight_percent']:.2f} ± {item['weight_percent_formal_esd']:.2f} | "
        f"{cell_text} | `{item['cif_path']}` |"
    )

report = f"""# Quantitative phase analysis

Three crystalline phases are required. Fractions are normalized over those modeled crystalline phases.

| Phase | Space group | wt% (formal ESD) | Refined cell | CIF |
|---|---:|---:|---|---|
{chr(10).join(rows)}

The formal scale-factor uncertainties understate model uncertainty. A conservative sensitivity estimate is about ±1 wt% for CaWO4 and ±2.5 wt% each for WO3 and CaCO3, mainly from overlap and preferred-orientation modeling. No amorphous fraction or absolute crystalline content can be obtained without an internal standard.

## Evidence

The chemistry is consistent with partial reaction of the stated CaCO3 + WO3 precursors at 500 °C. Scheelite CaWO4 is fixed by its 18.9°, 29.0°, 31.7°, 34.5°, 47.5° and 58.2° families. Monoclinic WO3 is especially diagnostic through the resolved 23.42°/23.90°/24.67° triplet and many higher-angle split families. Calcite is required by 29.71°, 39.72°, 43.47°, 47.8°, 48.8° and 57.7° families.

Ambient, fully occupied COD models 7219229 (scheelite), 2311041 (monoclinic WO3) and 1547347 (calcite atom model) were physically screened and used. Alternative source records or polymorphs were replayed under the same nuisance model: triclinic WO3 gave Rwp 8.99%, an alternate monoclinic WO3 record 11.03%, high-pressure fergusonite CaWO4 8.84%, aragonite 14.92%, and monoclinic CaCO3 11.29%, versus 8.74% for the corresponding common-profile inventory. The selected records also give chemically sensible density and coordination after cell refinement.

## Refinement and fit

The final GSAS-II replay used the full {fit_stats['two_theta_min_deg']:.3f}–{fit_stats['two_theta_max_deg']:.3f}° range, the supplied Cu Kα1/Kα2 wavelengths and 0.5 Kα2/Kα1 ratio, a smooth six-term Chebyshev background, one zero correction ({hist.InstrumentParameters['Zero'][1]:.4f}°), nonnegative common W broadening with U=X=0, and refined polarization ({hist.InstrumentParameters['Polariz.'][1]:.3f}). Supported phase broadening was retained as uniaxial CaWO4 size along [001], isotropic WO3 size plus uniaxial WO3 microstrain along [011], and isotropic calcite strain. March–Dollase terms were retained only after no-texture and symmetry-distinct-axis comparisons: CaWO4 [110], WO3 [010], and calcite [104]. Releasing U made it negative; releasing X made it >0.94 correlated with phase width terms. A second WO3 anisotropic size term was >0.90 correlated with strain and was pruned.

Final statistics are Rwp={fit_stats['rwp_percent']:.3f}%, Rp={fit_stats['rp_percent']:.3f}%, Rexp={fit_stats['rexp_percent']:.3f}%, GOF={fit_stats['goodness_of_fit']:.3f}, with {fit_stats['n_observations']} points and {fit_stats['n_refined_parameters']} refined parameters. Pointwise uncertainties were not supplied, so these statistics use count-statistical weights; the GOF above one reflects residual systematic mismatch as well as counting noise.

## Remaining uncertainty

Plausible trace phases were re-challenged against the final common profile. Ca3WO6 and W18O49 refined to zero. Nominal CaO and Ca–W bronze contributions were below 0.3 wt% and strongly width-dependent. Ca(OH)2 ranged from 0.45 to 1.79 wt% when its fixed crystallite size was changed from 10 to 0.03 µm; moreover, its strongest unique 001 line at 18.36° worsened rather than improved the residual, while most apparent gain came from overlapped peaks. Their structures/fractions therefore cannot be determined reliably and they are not included. Sharp-phase sensitivity is roughly sub-1 wt%; a non-specific broad-phase surrogate can approach 2 wt%.

Atomic coordinates, occupancies and displacement parameters were held at their physically screened source values; only lattice metrics and powder/profile terms were refined. Thus the phase identities and cells are supported, but local atomic geometry is not independently determined by this multiphase pattern. `final.gpx`, the submitted CIFs, fractions and `fit.csv` all come from the same reopened final project state.
"""
(ROOT / "report.md").write_text(report)

# Reopen once more to ensure the serialized project retains the submitted state.
check = G2sc.G2Project(str(FINAL))
check_hist = check.histogram(0)
check_fractions = check_hist.ComputeMassFracs()
if not np.allclose(check_hist.getdata("ycalc"), ycalc, rtol=0.0, atol=0.0):
    raise RuntimeError("Serialized final.gpx calculation differs from fit.csv source")
for name, (value, _) in fractions.items():
    if not np.isclose(check_fractions[name][0], value, rtol=0.0, atol=1e-12):
        raise RuntimeError(f"Serialized final.gpx fraction differs for {name}")

print("fit_statistics", fit_stats)
print("fractions", fractions)
for phase in project.phases():
    print(phase.name, phase.get_cell_and_esd(), phase.density)
