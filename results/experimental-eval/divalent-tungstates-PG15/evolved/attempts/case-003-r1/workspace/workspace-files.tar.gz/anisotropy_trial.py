#!/usr/bin/env python3
"""Challenge the isotropic phase-width terms with low-dimensional uniaxial models."""

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent

CASES = {
    "cawo4_size_001": ("CaWO4", "Size", [0, 0, 1]),
    "cawo4_size_110": ("CaWO4", "Size", [1, 1, 0]),
    "cawo4_size_101": ("CaWO4", "Size", [1, 0, 1]),
    "wo3_size_100": ("WO3", "Size", [1, 0, 0]),
    "wo3_size_010": ("WO3", "Size", [0, 1, 0]),
    "wo3_size_001": ("WO3", "Size", [0, 0, 1]),
    "wo3_size_101": ("WO3", "Size", [1, 0, 1]),
    "wo3_size_110": ("WO3", "Size", [1, 1, 0]),
    "wo3_size_011": ("WO3", "Size", [0, 1, 1]),
    "wo3_strain_100": ("WO3", "Mustrain", [1, 0, 0]),
    "wo3_strain_010": ("WO3", "Mustrain", [0, 1, 0]),
    "wo3_strain_001": ("WO3", "Mustrain", [0, 0, 1]),
    "wo3_strain_101": ("WO3", "Mustrain", [1, 0, 1]),
    "wo3_strain_110": ("WO3", "Mustrain", [1, 1, 0]),
    "wo3_strain_011": ("WO3", "Mustrain", [0, 1, 1]),
    "calcite_strain_001": ("CaCO3", "Mustrain", [0, 0, 1]),
    "calcite_strain_100": ("CaCO3", "Mustrain", [1, 0, 0]),
    "calcite_strain_104": ("CaCO3", "Mustrain", [1, 0, 4]),
}


def correlations(project, cutoff=0.8):
    cov = project["Covariance"]["data"]
    vary = cov.get("varyList", [])
    matrix = cov.get("covMatrix")
    if matrix is None:
        return []
    sig = np.sqrt(np.diag(matrix))
    corr = matrix / np.outer(sig, sig)
    pairs = []
    for i in range(len(vary)):
        for j in range(i):
            if np.isfinite(corr[i, j]) and abs(corr[i, j]) >= cutoff:
                pairs.append((abs(corr[i, j]), corr[i, j], vary[i], vary[j]))
    return sorted(pairs, reverse=True)


parser = argparse.ArgumentParser()
parser.add_argument("case", choices=CASES)
args = parser.parse_args()

phase_name, term, axis = CASES[args.case]
output = ROOT / f"anisotropy_{args.case}.gpx"

G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(str(ROOT / "texture_all3.gpx"), newgpx=str(output))
project["Controls"]["data"]["max cyc"] = 8
project["Controls"]["data"]["min dM/M"] = 1e-5
hist = project.histogram(0)
hap = project.phase(phase_name).getHAPvalues(hist)
profile = hap[term]

# A uniaxial term has equatorial and axial components. Starting them equal
# reproduces the accepted isotropic model exactly before the first cycle.
initial = float(profile[1][0])
profile[0] = "uniaxial"
profile[1][0] = initial
profile[1][1] = initial
profile[1][2] = 1.0
profile[2] = [True, True, False]
profile[3] = axis

project.save()
for _ in range(4):
    project.refine()
    project.save()
    project = G2sc.G2Project(str(output))

hist = project.histogram(0)
rvals = project["Covariance"]["data"].get("Rvals", {})
hap = project.phase(phase_name).getHAPvalues(hist)
print(
    args.case,
    "Rwp", hist.residuals.get("wR"),
    "R", hist.residuals.get("R"),
    "GOF", rvals.get("GOF"),
    "maxshift", rvals.get("Max shft/sig"),
    "converged", rvals.get("converged"),
)
print(term, repr(hap[term]))
print("fractions", hist.ComputeMassFracs())
for _, value, left, right in correlations(project)[:12]:
    print("corr", left, right, value)
