#!/usr/bin/env python3
"""Re-challenge plausible weak phases against the clean common profile."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
records = {
    "cao": ("1563196", "CaO"),
    "caoh2": ("7020138", "CaOH2"),
    "ca3wo6": ("1563081", "Ca3WO6"),
    "w18o49": ("1528166", "W18O49"),
    "ca_w_bronze": ("4030741", "Ca4.26W10O30"),
}


def cif_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=records)
parser.add_argument("size", nargs="?", type=float, default=0.10)
args = parser.parse_args()
cod_id, phase_name = records[args.mode]
size_tag = f"{args.size:g}".replace(".", "p")
output = ROOT / f"watch_{args.mode}_{size_tag}.gpx"

G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(str(ROOT / "candidate_baseline.gpx"), newgpx=str(output))
hist = project.histogram(0)
watch = project.add_phase(
    str(cif_path(cod_id)), phasename=phase_name, histograms=[hist], fmthint="CIF"
)
if args.mode == "w18o49":
    # The source uses formal W+5/W+6 labels that this GSAS-II scattering
    # table does not define. Neutral W/O form factors are the appropriate
    # X-ray approximation; coordinates and occupancies are unchanged.
    for atom in watch.atoms():
        atom.type = atom.element
    G2sc.SetupGeneral(watch.data, None)
project["Controls"]["data"]["max cyc"] = 8
project["Controls"]["data"]["min dM/M"] = 1e-5

hap = watch.getHAPvalues(hist)
hap["Scale"] = [0.1, True]
hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
hap["Extinction"] = [0.0, False]
hap["Size"][0] = "isotropic"
hap["Size"][1] = [args.size, 10.0, 1.0]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1] = [0.0, 0.0, 1.0]
hap["Mustrain"][2] = [False, False, False]
watch.set_refinements({"Cell": False})

# Refit background, all scales, zero, common W and established cells/profile terms.
project.save()
for _ in range(3):
    project.refine()
    project.save()
    project = G2sc.G2Project(str(output))

hist = project.histogram(0)
rvals = project["Covariance"]["data"].get("Rvals", {})
print(args.mode, cod_id, "fixed_size", args.size,
      "Rwp", hist.residuals.get("wR"), "R", hist.residuals.get("R"),
      "GOF", rvals.get("GOF"), "maxshift", rvals.get("Max shft/sig"),
      "converged", rvals.get("converged"))
print("fractions", hist.ComputeMassFracs())
watch = project.phase(phase_name)
hap = watch.getHAPvalues(hist)
print("watch scale", hap["Scale"], "cell", watch.get_cell(),
      "size", hap["Size"][1:3], "strain", hap["Mustrain"][1:3])
