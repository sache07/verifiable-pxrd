#!/usr/bin/env python3
"""Plot a GSAS-II fit for profile diagnostics."""

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("gpx", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()

project = G2sc.G2Project(str(args.gpx))
hist = project.histogram(0)
x = np.asarray(hist.getdata("X"))
yo = np.asarray(hist.getdata("Yobs"))
yc = np.asarray(hist.getdata("Ycalc"))
yb = np.asarray(hist.getdata("Background"))
yd = np.asarray(hist.getdata("Residual"))

fig, axes = plt.subplots(4, 1, figsize=(16, 12), constrained_layout=True)
axes[0].plot(x, yo, color="black", lw=0.65, label="observed")
axes[0].plot(x, yc, color="red", lw=0.65, label="calculated")
axes[0].plot(x, yb, color="royalblue", lw=0.55, label="background")
axes[0].plot(x, yd - 2500, color="gray", lw=0.45, label="difference (offset)")
axes[0].legend(ncol=4, fontsize=8)
axes[0].set_xlim(x[0], x[-1])
axes[0].set_ylabel("counts")

for ax, lo, hi in zip(axes[1:], (10, 35, 65), (35, 65, 100)):
    use = (x >= lo) & (x <= hi)
    ax.plot(x[use], yo[use], color="black", lw=0.8)
    ax.plot(x[use], yc[use], color="red", lw=0.75)
    ax.plot(x[use], yd[use] - 0.25 * np.max(yo[use]), color="gray", lw=0.55)
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
axes[-1].set_xlabel(r"$2\theta$ (degrees)")
fig.suptitle(f"{args.gpx.name}: Rwp={hist.residuals.get('wR', float('nan')):.3f}%")
fig.savefig(args.output, dpi=170)
