#!/usr/bin/env python3
"""Test global polarization and symmetry-distinct March-Dollase axes."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
textures = {
    "cawo4_001": ("CaWO4", [0, 0, 1]),
    "cawo4_100": ("CaWO4", [1, 0, 0]),
    "cawo4_110": ("CaWO4", [1, 1, 0]),
    "cawo4_101": ("CaWO4", [1, 0, 1]),
    "cawo4_112": ("CaWO4", [1, 1, 2]),
    "wo3_100": ("WO3", [1, 0, 0]),
    "wo3_010": ("WO3", [0, 1, 0]),
    "wo3_001": ("WO3", [0, 0, 1]),
    "wo3_101": ("WO3", [1, 0, 1]),
    "wo3_110": ("WO3", [1, 1, 0]),
    "wo3_011": ("WO3", [0, 1, 1]),
    "calcite_001": ("CaCO3", [0, 0, 1]),
    "calcite_100": ("CaCO3", [1, 0, 0]),
    "calcite_110": ("CaCO3", [1, 1, 0]),
    "calcite_101": ("CaCO3", [1, 0, 1]),
    "calcite_104": ("CaCO3", [1, 0, 4]),
    "calcite_012": ("CaCO3", [0, 1, 2]),
    "calcite_113": ("CaCO3", [1, 1, 3]),
}

parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=("polarization", *textures))
args = parser.parse_args()
output = ROOT / f"intensity_{args.mode}.gpx"
parent = ROOT / ("candidate_baseline.gpx" if args.mode == "polarization" else "intensity_polarization.gpx")

G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(str(parent), newgpx=str(output))
project["Controls"]["data"]["max cyc"] = 8
project["Controls"]["data"]["min dM/M"] = 1e-5
hist = project.histogram(0)

if args.mode == "polarization":
    hist.InstrumentParameters["Polariz."][2] = True
else:
    phase_name, axis = textures[args.mode]
    hap = project.phase(phase_name).getHAPvalues(hist)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis

project.save()
for _ in range(3):
    project.refine()
    project.save()
    project = G2sc.G2Project(str(output))

hist = project.histogram(0)
rvals = project["Covariance"]["data"].get("Rvals", {})
print(args.mode, "Rwp", hist.residuals.get("wR"), "R", hist.residuals.get("R"),
      "GOF", rvals.get("GOF"), "maxshift", rvals.get("Max shft/sig"),
      "converged", rvals.get("converged"),
      "polarization", hist.InstrumentParameters["Polariz."][1:])
print("fractions", hist.ComputeMassFracs())
if args.mode != "polarization":
    phase_name, _ = textures[args.mode]
    print("PO", phase_name, project.phase(phase_name).getHAPvalues(hist)["Pref.Ori."])
    print("vary", [v for v in project.get_VaryList() if "MD" in v or "SH" in v])
