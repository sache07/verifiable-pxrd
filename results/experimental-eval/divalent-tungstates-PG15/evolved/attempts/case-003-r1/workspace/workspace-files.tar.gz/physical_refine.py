#!/usr/bin/env python3
"""Build a physically constrained profile and test phase broadening terms."""

from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
GPX = ROOT / "physical.gpx"


def reopen(project):
    project.save()
    return G2sc.G2Project(str(GPX))


def converge(project, rounds=2):
    for _ in range(rounds):
        project.refine()
        project = reopen(project)
    return project


def snapshot(project, label):
    safe = label.lower().replace(" ", "_").replace("/", "_")
    project.save()
    shutil.copy2(GPX, ROOT / f"physical_{safe}.gpx")
    hist = project.histogram(0)
    rvals = project["Covariance"]["data"].get("Rvals", {})
    inst = hist.InstrumentParameters
    print(f"\n{label}: Rwp={hist.residuals.get('wR'):.5f} "
          f"GOF={rvals.get('GOF')} maxshift={rvals.get('Max shft/sig')} "
          f"converged={rvals.get('converged')}")
    print(" profile", {k: inst[k][1:] for k in ("Zero", "U", "W", "X", "SH/L")})
    try:
        print(" fractions", hist.ComputeMassFracs())
    except Exception as err:
        print(" fractions error", repr(err))
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        print(
            " ", phase.name,
            "scale", hap["Scale"],
            "size", hap["Size"][1:3],
            "strain", hap["Mustrain"][1:3],
            "cell", tuple(round(v, 7) for v in phase.get_cell().values()),
        )


def set_size(project, phase_name, value, refine=True):
    hist = project.histogram(0)
    hap = project.phase(phase_name).getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = value
    hap["Size"][1][2] = 1.0
    hap["Size"][2] = [refine, False, False]


def set_strain(project, phase_name, value, refine=True):
    hist = project.histogram(0)
    hap = project.phase(phase_name).getHAPvalues(hist)
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = value
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [refine, False, False]


G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(str(ROOT / "explore.gpx"), newgpx=str(GPX))
project["Controls"]["data"]["max cyc"] = 8
project["Controls"]["data"]["min dM/M"] = 1e-5
hist = project.histogram(0)

# Reset the common profile to a narrow, positive lab-instrument baseline.
for key, value in (("U", 20.0), ("W", 5.0), ("X", 2.0)):
    hist.InstrumentParameters[key][1] = value
    hist.InstrumentParameters[key][2] = False
for key in ("V", "Y", "Z"):
    hist.InstrumentParameters[key][1] = 0.0
    hist.InstrumentParameters[key][2] = False
hist.InstrumentParameters["SH/L"][1] = 0.002
hist.InstrumentParameters["SH/L"][2] = False

for phase in project.phases():
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]

project = reopen(project)
project = converge(project, 2)
snapshot(project, "positive common baseline")

# Compare phase size one phase at a time.
set_size(project, "CaWO4_scheelite", 0.10)
project = converge(project, 2)
snapshot(project, "plus CaWO4 size")

set_size(project, "WO3_monoclinic", 0.10)
project = converge(project, 2)
snapshot(project, "plus WO3 size")

set_size(project, "CaCO3_calcite", 1.0)
project = converge(project, 2)
snapshot(project, "plus calcite size")

# Compare complementary isotropic strain terms phase by phase.
set_strain(project, "CaWO4_scheelite", 300.0)
project = converge(project, 2)
snapshot(project, "plus CaWO4 strain")

set_strain(project, "WO3_monoclinic", 300.0)
project = converge(project, 2)
snapshot(project, "plus WO3 strain")

set_strain(project, "CaCO3_calcite", 100.0)
project = converge(project, 2)
snapshot(project, "plus calcite strain")

# Re-establish the common instrument profile after the inventory/profile change.
hist = project.histogram(0)
for key in ("U", "W", "X"):
    hist.InstrumentParameters[key][2] = True
project = converge(project, 3)
snapshot(project, "released common U W X")
