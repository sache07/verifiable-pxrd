#!/usr/bin/env python3
"""Combine only complementary anisotropic broadening terms and replay them."""

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
MODES = {
    "plus_cawo4_size": ("CaWO4", "Size", [0, 0, 1]),
    "plus_wo3_size": ("WO3", "Size", [0, 1, 1]),
    "plus_calcite_strain": ("CaCO3", "Mustrain", [0, 0, 1]),
}


parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=MODES)
args = parser.parse_args()

output = ROOT / f"combined_{args.mode}.gpx"
G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(
    str(ROOT / "anisotropy_wo3_strain_011.gpx"), newgpx=str(output)
)
project["Controls"]["data"]["max cyc"] = 8
project["Controls"]["data"]["min dM/M"] = 1e-5
hist = project.histogram(0)
phase_name, term, axis = MODES[args.mode]
profile = project.phase(phase_name).getHAPvalues(hist)[term]
initial = float(profile[1][0])
profile[0] = "uniaxial"
profile[1][0] = initial
profile[1][1] = initial
profile[1][2] = 1.0
profile[2] = [True, True, False]
profile[3] = axis

project.save()
for _ in range(5):
    project.refine()
    project.save()
    project = G2sc.G2Project(str(output))

hist = project.histogram(0)
rvals = project["Covariance"]["data"].get("Rvals", {})
print(
    args.mode,
    "Rwp", hist.residuals.get("wR"),
    "R", hist.residuals.get("R"),
    "GOF", rvals.get("GOF"),
    "maxshift", rvals.get("Max shft/sig"),
    "converged", rvals.get("converged"),
)
print("fractions", hist.ComputeMassFracs())
for phase in project.phases():
    hap = phase.getHAPvalues(hist)
    print(phase.name, "size", repr(hap["Size"]), "strain", repr(hap["Mustrain"]))

cov = project["Covariance"]["data"]
vary = cov.get("varyList", [])
matrix = cov.get("covMatrix")
if matrix is not None:
    sig = np.sqrt(np.diag(matrix))
    corr = matrix / np.outer(sig, sig)
    pairs = []
    for i in range(len(vary)):
        for j in range(i):
            if np.isfinite(corr[i, j]) and abs(corr[i, j]) >= 0.8:
                pairs.append((abs(corr[i, j]), corr[i, j], vary[i], vary[j]))
    for _, value, left, right in sorted(pairs, reverse=True)[:20]:
        print("corr", left, right, value)
