#!/usr/bin/env python3
"""Re-challenge marginal profile and intensity terms after width anisotropy."""

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
MODES = (
    "plus_calcite_strain",
    "no_cawo4_texture",
    "no_wo3_texture",
    "no_calcite_texture",
    "no_polarization",
    "release_u",
    "release_x",
)

parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=MODES)
args = parser.parse_args()
output = ROOT / f"rechallenge_{args.mode}.gpx"

G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(
    str(ROOT / "combined_plus_cawo4_size.gpx"), newgpx=str(output)
)
project["Controls"]["data"]["max cyc"] = 8
project["Controls"]["data"]["min dM/M"] = 1e-5
hist = project.histogram(0)

if args.mode == "plus_calcite_strain":
    strain = project.phase("CaCO3").getHAPvalues(hist)["Mustrain"]
    initial = float(strain[1][0])
    strain[0] = "uniaxial"
    strain[1][0:3] = [initial, initial, 1.0]
    strain[2] = [True, True, False]
    strain[3] = [0, 0, 1]
elif args.mode.startswith("no_") and args.mode.endswith("_texture"):
    phase_name = {
        "no_cawo4_texture": "CaWO4",
        "no_wo3_texture": "WO3",
        "no_calcite_texture": "CaCO3",
    }[args.mode]
    po = project.phase(phase_name).getHAPvalues(hist)["Pref.Ori."]
    po[1] = 1.0
    po[2] = False
elif args.mode == "no_polarization":
    hist.InstrumentParameters["Polariz."][1] = 0.5
    hist.InstrumentParameters["Polariz."][2] = False
elif args.mode == "release_u":
    hist.InstrumentParameters["U"][1] = 1.0
    hist.InstrumentParameters["U"][2] = True
elif args.mode == "release_x":
    hist.InstrumentParameters["X"][1] = 0.5
    hist.InstrumentParameters["X"][2] = True

project.save()
for _ in range(5):
    project.refine()
    project.save()
    project = G2sc.G2Project(str(output))

hist = project.histogram(0)
rvals = project["Covariance"]["data"].get("Rvals", {})
print(
    args.mode,
    "Rwp", hist.residuals.get("wR"),
    "R", hist.residuals.get("R"),
    "GOF", rvals.get("GOF"),
    "maxshift", rvals.get("Max shft/sig"),
    "converged", rvals.get("converged"),
)
print("fractions", hist.ComputeMassFracs())
print(
    "instrument",
    {key: hist.InstrumentParameters[key][1:] for key in ("Zero", "U", "W", "X", "Polariz.")},
)
for phase in project.phases():
    hap = phase.getHAPvalues(hist)
    print(
        phase.name,
        "PO", repr(hap["Pref.Ori."]),
        "size", repr(hap["Size"]),
        "strain", repr(hap["Mustrain"]),
    )

cov = project["Covariance"]["data"]
vary = cov.get("varyList", [])
matrix = cov.get("covMatrix")
if matrix is not None:
    sig = np.sqrt(np.diag(matrix))
    corr = matrix / np.outer(sig, sig)
    pairs = []
    for i in range(len(vary)):
        for j in range(i):
            if np.isfinite(corr[i, j]) and abs(corr[i, j]) >= 0.8:
                pairs.append((abs(corr[i, j]), corr[i, j], vary[i], vary[j]))
    for _, value, left, right in sorted(pairs, reverse=True)[:20]:
        print("corr", left, right, value)
