#!/usr/bin/env python3
"""Combine accepted texture candidates and replay the complete refinement."""

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=("cawo4_calcite", "all3"))
args = parser.parse_args()

if args.mode == "cawo4_calcite":
    parent = ROOT / "intensity_cawo4_110.gpx"
    output = ROOT / "texture_cawo4_calcite.gpx"
    additions = (("CaCO3", [1, 0, 4]),)
else:
    parent = ROOT / "texture_cawo4_calcite.gpx"
    output = ROOT / "texture_all3.gpx"
    additions = (("WO3", [0, 1, 0]),)

G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(str(parent), newgpx=str(output))
project["Controls"]["data"]["max cyc"] = 8
project["Controls"]["data"]["min dM/M"] = 1e-5
hist = project.histogram(0)
for phase_name, axis in additions:
    po = project.phase(phase_name).getHAPvalues(hist)["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 1.0, True, axis

project.save()
for _ in range(4):
    project.refine()
    project.save()
    project = G2sc.G2Project(str(output))

hist = project.histogram(0)
rvals = project["Covariance"]["data"].get("Rvals", {})
print(args.mode, "Rwp", hist.residuals.get("wR"), "R", hist.residuals.get("R"),
      "GOF", rvals.get("GOF"), "maxshift", rvals.get("Max shft/sig"),
      "converged", rvals.get("converged"),
      "polarization", hist.InstrumentParameters["Polariz."][1:])
print("fractions", hist.ComputeMassFracs())
for phase in project.phases():
    print(phase.name, "PO", phase.getHAPvalues(hist)["Pref.Ori."])

cov = project["Covariance"]["data"]
vary = cov.get("varyList", [])
matrix = cov.get("covMatrix")
if matrix is not None:
    sig = np.sqrt(np.diag(matrix))
    corr = matrix / np.outer(sig, sig)
    pairs = []
    for i in range(len(vary)):
        for j in range(i):
            if abs(corr[i, j]) >= 0.8:
                pairs.append((abs(corr[i, j]), corr[i, j], vary[i], vary[j]))
    for _, value, left, right in sorted(pairs, reverse=True)[:20]:
        print("corr", left, right, value)
