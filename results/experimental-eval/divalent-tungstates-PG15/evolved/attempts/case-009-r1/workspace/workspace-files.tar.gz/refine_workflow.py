#!/usr/bin/env python3
"""Scripted GSAS-II refinement and reproducible export for this PXRD dataset."""

from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
WORK = ROOT / ".tmp" / "gsas"
PATTERN = ROOT / "inputs" / "pattern.csv"
SOURCE_MNWO4 = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/02/1520200.cif"
)
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_cif(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_powder_input() -> tuple[Path, Path]:
    """Create a three-column Topas XYE file and a dual-wavelength instprm."""
    WORK.mkdir(parents=True, exist_ok=True)
    xye = WORK / "pattern.xye"
    with PATTERN.open(newline="") as source, xye.open("w") as target:
        reader = csv.DictReader(source)
        target.write("# Original counts; sigma=sqrt(counts) because no esds were supplied\n")
        for row in reader:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            target.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")

    inst = WORK / "cu_kalpha.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; laboratory Cu Kalpha reflection data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.5;Azimuth:0.0;"
        "I(L2)/I(L1):0.5\n"
        "U:20.0;V:0.0;W:60.0;X:10.0;Y:0.0;Z:0.0;SH/L:0.002\n"
    )
    return xye, inst


def summarize(gpx: G2sc.G2Project, label: str) -> None:
    hist = gpx.histogram(0)
    print(f"\n--- {label} ---")
    print("residuals", hist.residuals)
    print("instrument")
    for key, value in hist.InstrumentParameters.items():
        print(" ", key, value)
    print("sample", hist.SampleParameters)
    print("background", hist.Background)
    for phase in gpx.phases():
        print("phase", phase.name, phase.get_cell())
        print("HAP", phase.getHAPvalues(hist))
        print("atoms")
        for atom in phase.atoms():
            print(" ", atom.data)


def init_trial() -> None:
    xye, inst = make_powder_input()
    trial = WORK / "trial.gpx"
    if trial.exists():
        trial.unlink()
    gpx = G2sc.G2Project(newgpx=str(trial))
    hist = gpx.add_powder_histogram(
        str(xye), str(inst), fmthint="Topas xye"
    )
    phase = gpx.add_phase(
        str(SOURCE_MNWO4), phasename="MnWO4_wolframite", histograms=[hist]
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    # Start from a physically neutral specimen model.
    hist.SampleParameters["Scale"] = [1.0, False]
    hap = phase.getHAPvalues(hist)
    hap["Scale"][0] = 1.0
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 100.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    # Smooth, low-order background with an observed-count starting level.
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": 6,
                        "coeffs": [700.0, -400.0, 300.0, -180.0, 80.0, -30.0],
                        "refine": False}}
    )
    gpx.save()
    summarize(gpx, "initialized")


def run_stage(gpx: G2sc.G2Project, label: str, changes: dict) -> G2sc.G2Project:
    """Apply one reversible refinement stage and report its state."""
    print(f"\n===== refining {label} =====")
    gpx.do_refinements([changes])
    gpx.save()
    summarize(gpx, label)
    return gpx


def baseline_trial() -> None:
    path = WORK / "trial.gpx"
    gpx = G2sc.G2Project(str(path))
    gpx["Controls"]["data"]["max cyc"] = 8
    gpx["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = gpx.histogram(0)
    hist.SampleParameters["Scale"][1] = False
    # Low-order background and one phase scale first.
    gpx = run_stage(
        gpx,
        "background + phase scale",
        {"set": {"Background": {"refine": True}, "Scale": True}},
    )
    # One angular correction and the symmetry-constrained monoclinic cell.
    gpx = run_stage(
        gpx,
        "add zero + cell",
        {"set": {"Instrument Parameters": ["Zero"], "Cell": True}},
    )
    # A low-dimensional nonnegative common profile (V and Y stay fixed at zero).
    gpx = run_stage(
        gpx,
        "add W + X profile",
        {"set": {"Instrument Parameters": ["W", "X"]}},
    )
    gpx = run_stage(
        gpx,
        "add U profile",
        {"set": {"Instrument Parameters": ["U"]}},
    )
    # Save/reopen/replay to verify the fitted state is reproducible.
    gpx.save()
    gpx = G2sc.G2Project(str(path))
    gpx.refine()
    gpx.save()
    summarize(gpx, "baseline replay")


def physical_baseline() -> None:
    source = WORK / "trial.gpx"
    target = WORK / "baseline.gpx"
    gpx = G2sc.G2Project(str(source), newgpx=str(target))
    hist = gpx.histogram(0)
    hist.InstrumentParameters["U"] = [0.0, 0.0, False]
    hist.InstrumentParameters["V"] = [0.0, 0.0, False]
    hist.InstrumentParameters["Y"] = [0.0, 0.0, False]
    hist.InstrumentParameters["Z"] = [0.0, 0.0, False]
    gpx["Controls"]["data"]["max cyc"] = 12
    gpx.save()
    gpx.refine()
    gpx.save()
    # Required save/reopen/replay check.
    gpx = G2sc.G2Project(str(target))
    gpx.refine()
    gpx.save()
    summarize(gpx, "physical U=0 baseline replay")


def nuisance_trials() -> None:
    source = WORK / "baseline.gpx"
    trials = {
        "polarization": (None, ["Polariz."]),
        "roughness_b": ({"SurfRoughB": 0.0}, []),
        "polarization_roughness_b": ({"SurfRoughB": 0.0}, ["Polariz."]),
    }
    for name, (sample_values, instrument_keys) in trials.items():
        target = WORK / f"trial_{name}.gpx"
        gpx = G2sc.G2Project(str(source), newgpx=str(target))
        gpx["Controls"]["data"]["max cyc"] = 12
        hist = gpx.histogram(0)
        if sample_values:
            for key, value in sample_values.items():
                hist.SampleParameters[key][0] = value
                hist.SampleParameters[key][1] = True
        if instrument_keys:
            hist.set_refinements({"Instrument Parameters": instrument_keys})
        gpx.save()
        gpx.refine()
        gpx.save()
        print("TRIAL", name, "wR", hist.get_wR(),
              "polar", hist.InstrumentParameters["Polariz."],
              "roughA", hist.SampleParameters["SurfRoughA"],
              "roughB", hist.SampleParameters["SurfRoughB"])


def profile_trials() -> None:
    source = WORK / "trial_roughness_b.gpx"
    for name in ["shl", "kalpha_ratio", "size_iso", "strain_iso"]:
        target = WORK / f"trial_{name}.gpx"
        gpx = G2sc.G2Project(str(source), newgpx=str(target))
        gpx["Controls"]["data"]["max cyc"] = 12
        hist = gpx.histogram(0)
        phase = gpx.phase(0)
        if name == "shl":
            hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        elif name == "kalpha_ratio":
            hist.set_refinements({"Instrument Parameters": ["I(L2)/I(L1)"]})
        elif name == "size_iso":
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 10.0, "refine": True}},
                [hist],
            )
        elif name == "strain_iso":
            hap = phase.getHAPvalues(hist)
            hap["Mustrain"][1][0] = 100.0
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
            )
        gpx.save()
        gpx.refine()
        gpx.save()
        hap = phase.getHAPvalues(hist)
        print("TRIAL", name, "wR", hist.get_wR(),
              "SH/L", hist.InstrumentParameters["SH/L"],
              "ratio", hist.InstrumentParameters["I(L2)/I(L1)"],
              "W", hist.InstrumentParameters["W"],
              "X", hist.InstrumentParameters["X"],
              "size", hap["Size"], "strain", hap["Mustrain"])


def geometry_trials() -> None:
    source = WORK / "trial_roughness_b.gpx"
    for name, use_shl in [("shift", False), ("shift_shl", True)]:
        target = WORK / f"trial_{name}.gpx"
        gpx = G2sc.G2Project(str(source), newgpx=str(target))
        gpx["Controls"]["data"]["max cyc"] = 16
        hist = gpx.histogram(0)
        hist.InstrumentParameters["Zero"] = [0.0, 0.0, False]
        hist.SampleParameters["Shift"] = [0.0, True]
        if use_shl:
            hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        gpx.save()
        gpx.refine()
        gpx.save()
        print("TRIAL", name, "wR", hist.get_wR(),
              "zero", hist.InstrumentParameters["Zero"],
              "shift", hist.SampleParameters["Shift"],
              "SH/L", hist.InstrumentParameters["SH/L"],
              "cell", gpx.phase(0).get_cell())


def inventory_trial(
    name: str, final_profile: bool = False, refine_final_cell: bool = False
) -> None:
    candidates = {
        "mn3o4": ("Mn3O4_hausmannite", "9001963"),
        "wo3_monoclinic": ("WO3_monoclinic", "1528915"),
        "wo3_triclinic": ("WO3_triclinic", "2106293"),
        "mn3wo6": ("Mn3WO6", "2002703"),
        "mn2o3": ("Mn2O3_bixbyite", "1514230"),
        "mn2o3_i213": ("Mn2O3_I213", "1010586"),
        "mn2o3_pbca": ("Mn2O3_Pbca", "1514103"),
        "mno": ("MnO_rocksalt", "1514108"),
    }
    phase_name, cod_id = candidates[name]
    if final_profile:
        source = WORK / "trial_coordinates_all_shl.gpx"
        suffix = "_cell" if refine_final_cell else ""
        target = WORK / f"inventory_final_{name}{suffix}.gpx"
    else:
        source = WORK / "trial_background_10.gpx"
        target = WORK / f"inventory_clean_{name}.gpx"
    gpx = G2sc.G2Project(str(source), newgpx=str(target))
    gpx["Controls"]["data"]["max cyc"] = 12
    hist = gpx.histogram(0)
    phase = gpx.add_phase(
        str(cod_cif(cod_id)), phasename=phase_name, histograms=[hist]
    )
    hap = phase.getHAPvalues(hist)
    hap["Scale"] = [0.05 if final_profile else 0.5, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    phase.set_refinements({"Cell": bool(refine_final_cell)})
    gpx.save()
    gpx.refine()
    gpx.save()
    def scale_and_sigma() -> tuple[float, float | None]:
        var = f"{phase.id}:0:Scale"
        cov = gpx["Covariance"]["data"]
        if var in cov.get("varyList", []):
            idx = cov["varyList"].index(var)
            return float(cov["variables"][idx]), float(cov["sig"][idx])
        return float(phase.getHAPvalues(hist)["Scale"][0]), None

    scale = scale_and_sigma()
    # Refine the candidate cell only if a nonzero, significant scale survives.
    if (not final_profile and scale and scale[0] > 0 and scale[1]
            and scale[0] > 3.0 * scale[1]):
        phase.set_refinements({"Cell": True})
        gpx.refine()
        gpx.save()
        scale = scale_and_sigma()
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:
        fractions = {"error": repr(exc)}
    print(json.dumps({
        "trial": name,
        "cod_id": cod_id,
        "wR": hist.get_wR(),
        "candidate_scale": scale,
        "candidate_cell": phase.get_cell(),
        "fractions": fractions,
    }, indent=2))


def background_trial(ncoeff: int) -> None:
    source = WORK / "trial_shift.gpx"
    target = WORK / f"trial_background_{ncoeff}.gpx"
    gpx = G2sc.G2Project(str(source), newgpx=str(target))
    gpx["Controls"]["data"]["max cyc"] = 12
    hist = gpx.histogram(0)
    hist.set_refinements({"Background": {"type": "chebyschev-1",
                                           "no. coeffs": ncoeff,
                                           "refine": True}})
    gpx.save()
    gpx.refine()
    gpx.save()
    print("TRIAL background", ncoeff, "wR", hist.get_wR(),
          "coeffs", hist.Background[0][3:])


def analogue_trial() -> None:
    source = WORK / "trial_background_10.gpx"
    target = WORK / "trial_znwo4_mn_analogue.gpx"
    analogue = ROOT / ".tmp" / "znwo4_mn_substitution.cif"
    gpx = G2sc.G2Project(str(source), newgpx=str(target))
    gpx["Controls"]["data"]["max cyc"] = 16
    hist = gpx.histogram(0)
    old = gpx.phase(0)
    old.getHAPvalues(hist)["Use"] = False
    phase = gpx.add_phase(str(analogue), phasename="MnWO4_ZnWO4_analogue",
                          histograms=[hist])
    hap = phase.getHAPvalues(hist)
    hap["Scale"] = [64.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    phase.set_refinements({"Cell": True})
    gpx.save()
    gpx.refine()
    gpx.save()
    print("TRIAL analogue wR", hist.get_wR(), "cell", phase.get_cell(),
          "scale", hap["Scale"])


def coordinate_trial(which: str) -> None:
    source = WORK / "trial_background_10.gpx"
    target = WORK / f"trial_coordinates_{which}.gpx"
    gpx = G2sc.G2Project(str(source), newgpx=str(target))
    gpx["Controls"]["data"]["max cyc"] = 16
    phase = gpx.phase(0)
    atom_flags = {
        "heavy": {"Mn1": "X", "W1": "X"},
        "oxygen": {"O1": "X", "O2": "X"},
        "all": {"all": "X"},
    }[which]
    phase.set_refinements({"Atoms": atom_flags})
    gpx.save()
    gpx.refine()
    gpx.save()
    print("TRIAL coordinates", which, "wR", gpx.histogram(0).get_wR())
    for atom in phase.atoms():
        print(atom.label, atom.coordinates, atom.refinement_flags)
    print("correlations", gpx["Covariance"]["data"].get("Rvals", {}).get("msg"))


def texture_trial(axis_text: str) -> None:
    source = WORK / "trial_coordinates_all.gpx"
    target = WORK / f"trial_texture_{axis_text}.gpx"
    axis = [int(char) for char in axis_text]
    gpx = G2sc.G2Project(str(source), newgpx=str(target))
    gpx["Controls"]["data"]["max cyc"] = 12
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    po = phase.getHAPvalues(hist)["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = axis
    gpx.save()
    gpx.refine()
    gpx.save()
    cov = gpx["Covariance"]["data"]
    po_vars = [(v, cov["variables"][i], cov["sig"][i])
               for i, v in enumerate(cov.get("varyList", []))
               if "MD" in v or "Pref" in v]
    print("TRIAL texture", axis, "wR", hist.get_wR(), "PO", po,
          "variables", po_vars)


def finalize_project() -> None:
    """Replay the accepted two-phase model and export its exact saved state."""
    source = WORK / "inventory_final_mn2o3_pbca.gpx"
    target = ROOT / "final.gpx"
    gpx = G2sc.G2Project(str(source), newgpx=str(target))
    gpx["Controls"]["data"]["max cyc"] = 16
    gpx["Controls"]["data"]["min dM/M"] = 1.0e-6
    hist = gpx.histogram(0)

    # Submit the complete measured interval, including the few edge points that
    # were omitted during exploratory trials.
    x_all = np.asarray(hist.getdata("X"), dtype=float)
    hist.Limits("lower", float(x_all.min()))
    hist.Limits("upper", float(x_all.max()))

    major, minor = gpx.phases()
    major.set_refinements({"Cell": True})
    minor.set_refinements({"Cell": False})
    # The weak reference phase is not strong enough to refine atomic positions.
    minor.set_refinements({"Atoms": {"all": ""}})
    gpx.save()

    # Full-range reconvergence followed by two independent save/reopen replays.
    for replay in range(3):
        gpx.refine()
        gpx.save()
        print(
            "FINAL REPLAY", replay + 1,
            json.dumps(gpx["Covariance"]["data"].get("Rvals", {}), default=str),
        )
        if replay < 2:
            gpx = G2sc.G2Project(str(target))

    # Reopen once more so all exports are guaranteed to come from final.gpx.
    gpx = G2sc.G2Project(str(target))
    hist = gpx.histogram(0)
    phases = gpx.phases()
    if len(phases) != 2:
        raise RuntimeError(f"expected two accepted phases, found {len(phases)}")

    cif_paths = [ROOT / "phase_1_MnWO4.cif", ROOT / "phase_2_Mn2O3.cif"]
    for phase, cif_path in zip(phases, cif_paths):
        phase.export_CIF(str(cif_path))

    x = np.asarray(hist.getdata("X"), dtype=float)
    observed = np.asarray(hist.getdata("Yobs"), dtype=float)
    calculated = np.asarray(hist.getdata("Ycalc"), dtype=float)
    background = np.asarray(hist.getdata("Background"), dtype=float)
    difference = observed - calculated
    if not all(np.all(np.isfinite(a)) for a in
               (x, observed, calculated, background, difference)):
        raise RuntimeError("non-finite values in final fitted profile")
    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "two_theta_deg", "observed_counts", "calculated_counts",
            "difference_counts", "background_counts",
        ])
        writer.writerows(zip(x, observed, calculated, difference, background))

    fractions = hist.ComputeMassFracs()
    residuals = hist.residuals
    rvals = gpx["Covariance"]["data"].get("Rvals", {})
    phase_specs = [
        {
            "name": "MnWO4",
            "phase_label": "wolframite",
            "formula": "MnWO4",
            "space_group": "P 1 2/c 1",
            "space_group_number": 13,
            "structure_source": {"database": "COD", "id": "1520200"},
            "cell_and_coordinates": "refined",
        },
        {
            "name": "Mn2O3",
            "phase_label": "alpha-Mn2O3 (orthorhombic bixbyite distortion)",
            "formula": "Mn2O3",
            "space_group": "P b c a",
            "space_group_number": 61,
            "structure_source": {"database": "COD", "id": "1514103"},
            "cell_and_coordinates": "fixed to reference (minor-phase signal insufficient)",
        },
    ]
    phase_rows = []
    for phase, cif_path, spec in zip(phases, cif_paths, phase_specs):
        fraction, fraction_esd = fractions[phase.name]
        pid = phase.id
        row = dict(spec)
        row.update({
            "cif_path": cif_path.name,
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(fraction_esd),
            "cell": {k: float(v) for k, v in phase.get_cell().items()},
            "phase_fit_statistics": {
                "R_F_percent": float(residuals[f"{pid}:0:Rf"]),
                "R_F_squared_percent": float(residuals[f"{pid}:0:Rf^2"]),
                "n_reflections": int(residuals[f"{pid}:0:Nref"]),
            },
        })
        phase_rows.append(row)

    result = {
        "phases": phase_rows,
        "weight_fraction_basis": (
            "normalized over the modeled crystalline phases; amorphous content "
            "and unmodeled crystalline material are not quantified"
        ),
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_variables": int(rvals["Nvars"]),
            "refinement_range_two_theta_deg": [float(x.min()), float(x.max())],
            "weighting": "sigma=sqrt(observed counts); pointwise esds were not supplied",
        },
        "profile_path": "fit.csv",
        "gsasii_project_path": "final.gpx",
    }
    if not math.isclose(sum(p["weight_fraction"] for p in phase_rows),
                        1.0, rel_tol=0.0, abs_tol=1e-10):
        raise RuntimeError("phase fractions do not sum to unity")
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "init"
    if mode == "init":
        init_trial()
    elif mode == "baseline":
        baseline_trial()
    elif mode == "physical-baseline":
        physical_baseline()
    elif mode == "nuisance-trials":
        nuisance_trials()
    elif mode == "profile-trials":
        profile_trials()
    elif mode == "geometry-trials":
        geometry_trials()
    elif mode == "inventory-trial":
        inventory_trial(sys.argv[2])
    elif mode == "inventory-final":
        inventory_trial(sys.argv[2], final_profile=True)
    elif mode == "inventory-final-cell":
        inventory_trial(sys.argv[2], final_profile=True, refine_final_cell=True)
    elif mode == "background-trial":
        background_trial(int(sys.argv[2]))
    elif mode == "analogue-trial":
        analogue_trial()
    elif mode == "coordinate-trial":
        coordinate_trial(sys.argv[2])
    elif mode == "texture-trial":
        texture_trial(sys.argv[2])
    elif mode == "finalize":
        finalize_project()
    else:
        raise SystemExit(f"unknown mode: {mode}")
