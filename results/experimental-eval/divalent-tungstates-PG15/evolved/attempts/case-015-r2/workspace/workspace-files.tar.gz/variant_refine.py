#!/usr/bin/env python3
"""Matched-nuisance tests of physically plausible WO3 structure records."""

import json
import sys

from GSASII import GSASIIscriptable as G2sc

from refinement_experiments import (
    ROOT,
    build_baseline,
    refine_reopen,
)


VARIANTS = {
    "mono": "1528915",
    "neutron": "2311041",
    "triclinic": "2106293",
}


def run_variant(label):
    project = build_baseline(f"variant_{label}.gpx", VARIANTS[label])
    project = refine_reopen(project)
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project = refine_reopen(project, repeats=2)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project = refine_reopen(project, repeats=2)
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.5, True]
    sample["SurfRoughB"] = [0.05, True]
    project = refine_reopen(project, repeats=2)
    hist = project.histogram(0)
    wo3 = project.phase("WO3")
    hap = wo3.data["Histograms"][hist.name]
    hap["Mustrain"][1][0] = 100.0
    wo3.set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True}
    })
    project = refine_reopen(project, repeats=2)
    return refine_reopen(project)


def summarize(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    return {
        "label": label,
        "record": VARIANTS[label],
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "zero": inst["Zero"][1],
        "W": inst["W"][1],
        "X": inst["X"][1],
        "SH/L": inst["SH/L"][1],
        "roughness": [sample["SurfRoughA"][0], sample["SurfRoughB"][0]],
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "WO3_mustrain": project.phase("WO3").data["Histograms"][hist.name]["Mustrain"][1][0],
    }


def main():
    G2sc.SetPrintLevel("none")
    labels = sys.argv[1:] or ["neutron", "triclinic"]
    results = []
    for label in labels:
        project = run_variant(label)
        result = summarize(project, label)
        results.append(result)
        print(json.dumps(result, indent=2))
    (ROOT / "variant_summary.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
