#!/usr/bin/env python3
"""Exploratory GSAS-II refinements for the Zn-W-O powder pattern."""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = {
    "ZnWO4": "1520641",       # P 2/c, stoichiometric wolframite
    "WO3_mono": "1528915",    # P 21/n, room-temperature gamma-WO3
    "WO3_tri": "2106293",     # P -1, room-temperature triclinic WO3
    "WO3_old": "1010618",     # historical reduced-cell WO3 model
    "ZnO": "9004178",         # P 63mc wurtzite
}


def set_controls(project: G2sc.G2Project) -> None:
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 12
    controls["min dM/M"] = 1.0e-5


def instrument_values(hist) -> dict[str, float]:
    inst = hist.data["Instrument Parameters"][0]
    return {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1}


def phase_values(phase, hist_name: str) -> dict:
    hap = phase.data["Histograms"][hist_name]
    return {
        "scale": hap["Scale"][0],
        "scale_refine": hap["Scale"][1],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "cell": phase.get_cell(),
        "composition": phase.composition,
        "density": phase.density,
    }


def summarize(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    out = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": instrument_values(hist),
        "background": hist.data["Background"][0],
        "sample": hist.data["Sample Parameters"],
        "phases": {
            phase.name: phase_values(phase, hist.name) for phase in project.phases()
        },
    }
    print(json.dumps(out, indent=2, default=str))
    return out


def refine_step(project: G2sc.G2Project, label: str) -> dict:
    project.save()
    # Reopening each checkpoint tests that all refinement state is serialized.
    project = G2sc.G2Project(project.filename)
    set_controls(project)
    project.refine(makeBack=False)
    project.save()
    return summarize(project, label), project


def build_project(tag: str, phase_keys: list[str]) -> G2sc.G2Project:
    gpx = ROOT / f"trial_{tag}.gpx"
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 6,
            "coeffs": [900.0, -500.0, 200.0, -80.0, 20.0, 0.0],
        },
    })
    # Use phase scales for quantitative phase analysis; the histogram/sample
    # scale is otherwise exactly correlated with every phase scale.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    for key in phase_keys:
        phase = project.add_phase(
            str(cod_cif(CANDIDATES[key])),
            phasename=key,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.set_HAP_refinements({
            "Scale": True,
            "Size": {"type": "isotropic", "refine": False, "value": 1.0e6},
            "Mustrain": {"type": "isotropic", "refine": False},
        })
        # Explicitly neutralize terms that should not enter the baseline.
        hap = phase.data["Histograms"][hist.name]
        hap["Extinction"] = [0.0, False]
        hap["Pref.Ori."][2] = False
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
    set_controls(project)
    project.save()
    return project


def run_trial(tag: str, phase_keys: list[str]) -> dict:
    project = build_project(tag, phase_keys)
    log = []
    result, project = refine_step(project, "background+scales")
    log.append(result)

    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    result, project = refine_step(project, "+zero")
    log.append(result)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    result, project = refine_step(project, "+cells")
    log.append(result)

    hist = project.histogram(0)
    # Low-dimensional common profile: W and X only; U and V remain fixed.
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    result, project = refine_step(project, "+common_profile_WX")
    log.append(result)

    # Re-converge all current parameters after serialization.
    result, project = refine_step(project, "replay")
    log.append(result)
    return {"tag": tag, "phases": phase_keys, "steps": log}


def main() -> None:
    trials = {
        "zw": ["ZnWO4"],
        "zw_wm": ["ZnWO4", "WO3_mono"],
        "zw_wt": ["ZnWO4", "WO3_tri"],
        "zw_wo": ["ZnWO4", "WO3_old"],
        "zw_zno": ["ZnWO4", "ZnO"],
        "zw_wm_zno": ["ZnWO4", "WO3_mono", "ZnO"],
    }
    selected = sys.argv[1:] or list(trials)
    all_results = []
    for tag in selected:
        print(f"\nTRIAL {tag}: {trials[tag]}")
        try:
            all_results.append(run_trial(tag, trials[tag]))
        except Exception as exc:
            print(f"FAILED {tag}: {type(exc).__name__}: {exc}")
            all_results.append({"tag": tag, "error": f"{type(exc).__name__}: {exc}"})
    (ROOT / "trial_summary.json").write_text(json.dumps(all_results, indent=2, default=str))


if __name__ == "__main__":
    main()
