#!/usr/bin/env python3
"""Residual-led refinement experiments for ZnWO4 + WO3 + ZnO."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
PHASES = [
    ("ZnWO4", "1520641", 30.0),
    ("WO3", "1528915", 2.0),
    ("ZnO", "9004178", 12.0),
]


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def controls(project, cycles=20):
    c = project.data["Controls"]["data"]
    c["max cyc"] = cycles
    c["min dM/M"] = 1e-5


def neutral_hap(phase, hist, scale):
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(scale), True]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False] * len(hap["Size"][2])
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])


def build_baseline(filename="exp_baseline.gpx", wo3_id="1528915"):
    project = G2sc.G2Project(newgpx=str(ROOT / filename))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 6,
            "coeffs": [600.0, -580.0, 450.0, -250.0, 120.0, -40.0],
        },
    })
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    inst = hist.data["Instrument Parameters"][0]
    # Physical low-dimensional common profile; V, Y and Z are neutral.
    for key, value in {
        "U": 2.0,
        "V": 0.0,
        "W": 5.0,
        "X": 0.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "Polariz.": 0.5,
        "Zero": 0.0,
    }.items():
        inst[key][1] = value
        inst[key][2] = False

    for name, cod_id, scale in PHASES:
        if name == "WO3":
            cod_id = wo3_id
        phase = project.add_phase(
            str(cod_cif(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.set_refinements({"Cell": False})
        neutral_hap(phase, hist, scale)
    controls(project)
    project.save()
    return project


def refine_reopen(project, repeats=1, cycles=20):
    for _ in range(repeats):
        controls(project, cycles)
        project.save()
        project = G2sc.G2Project(project.filename)
        controls(project, cycles)
        project.refine(makeBack=False)
        project.save()
        project = G2sc.G2Project(project.filename)
    return project


def project_summary(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    try:
        mass = hist.ComputeMassFracs()
    except Exception as exc:
        mass = {"error": f"{type(exc).__name__}: {exc}"}
    cov = project.data["Covariance"]["data"]
    return {
        "label": label,
        "file": project.filename,
        "residuals": hist.residuals,
        "instrument": {
            k: {"value": v[1], "refine": v[2]}
            for k, v in inst.items()
            if isinstance(v, list) and len(v) > 2
        },
        "background": hist.data["Background"],
        "mass_fractions": mass,
        "phases": phases,
        "vary_list": cov.get("varyList", []),
        "variables": [float(x) for x in cov.get("variables", [])],
        "sigmas": [float(x) for x in cov.get("sig", [])],
    }


def make_baseline():
    project = build_baseline()
    hist = project.histogram(0)
    # Inventory, smooth background and phase scales first.
    project = refine_reopen(project, repeats=1)
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project = refine_reopen(project, repeats=2)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project = refine_reopen(project, repeats=2)
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    project = refine_reopen(project, repeats=2)
    # Full save/open replay.
    return refine_reopen(project, repeats=1)


def clone(source, filename):
    project = G2sc.G2Project(str(source), newgpx=str(ROOT / filename))
    project.save()
    return G2sc.G2Project(project.filename)


def branch(source, name):
    project = clone(source, f"exp_{name}.gpx")
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    if name == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif name == "shl":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    elif name == "polarization_shl":
        hist.set_refinements({"Instrument Parameters": ["Polariz.", "SH/L"]})
    elif name == "polarization1_shl":
        inst["Polariz."][1] = 1.0
        inst["Polariz."][2] = False
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    elif name == "roughB":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.05, True]
    elif name == "roughAB":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.5, True]
        sample["SurfRoughB"] = [0.05, True]
    elif name == "roughB_shl":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.05, True]
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    elif name == "roughAB_shl":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.5, True]
        sample["SurfRoughB"] = [0.05, True]
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    elif name == "uwx":
        hist.set_refinements({"Instrument Parameters": ["U"]})
    elif name == "w_only":
        inst["X"][1] = 0.0
        inst["X"][2] = False
    elif name == "background8":
        old = hist.data["Background"][0]
        hist.set_refinements({"Background": {
            "type": old[0], "refine": True, "no. coeffs": 8,
            "coeffs": list(old[3:]) + [0.0, 0.0],
        }})
    elif name.startswith("size_"):
        phase = project.phase(name.removeprefix("size_"))
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True, "value": 10.0}
        })
    elif name.startswith("strain_"):
        phase = project.phase(name.removeprefix("strain_"))
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 100.0
        phase.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True}
        })
    elif name.startswith("texture_"):
        parts = name.split("_")
        phase = project.phase(parts[1])
        axis = [int(v.replace("m", "-")) for v in parts[2:5]]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
    elif name.startswith("uniax_"):
        parts = name.split("_")
        phase = project.phase(parts[1])
        axis = [int(v.replace("m", "-")) for v in parts[2:5]]
        hap = phase.data["Histograms"][hist.name]
        start = abs(float(hap["Mustrain"][1][0])) or 100.0
        hap["Mustrain"][1][:] = [start, start, 1.0]
        phase.set_HAP_refinements({
            "Mustrain": {
                "type": "uniaxial", "direction": axis, "refine": True
            }
        })
    else:
        raise ValueError(name)
    project = refine_reopen(project, repeats=int(os.environ.get("PXRD_REPEATS", "2")))
    return project


def main():
    G2sc.SetPrintLevel("none")
    actions = sys.argv[1:] or ["baseline"]
    summaries = []
    if "baseline" in actions:
        base = make_baseline()
        s = project_summary(base, "baseline")
        summaries.append(s)
        print(json.dumps(s, indent=2))
    source = ROOT / os.environ.get("PXRD_SOURCE", "exp_baseline.gpx")
    for action in actions:
        if action == "baseline":
            continue
        p = branch(source, action)
        s = project_summary(p, action)
        summaries.append(s)
        if os.environ.get("PXRD_BRIEF"):
            print(json.dumps({
                "label": s["label"],
                "file": s["file"],
                "Rwp": s["residuals"].get("wR"),
                "Rp": s["residuals"].get("R"),
                "mass_fractions": s["mass_fractions"],
                "texture": {
                    k: v["preferred_orientation"] for k, v in s["phases"].items()
                },
            }, indent=2))
        else:
            print(json.dumps(s, indent=2))
    (ROOT / "experiment_summary.json").write_text(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
