#!/usr/bin/env python3
"""Compare one specimen-displacement correction with the accepted zero term."""

import json

from GSASII import GSASIIscriptable as G2sc

from refinement_experiments import ROOT, refine_reopen


def main():
    G2sc.SetPrintLevel("none")
    project = G2sc.G2Project(
        str(ROOT / "variant_triclinic.gpx"),
        newgpx=str(ROOT / "geometry_shift.gpx"),
    )
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"] = [inst["Zero"][0], 0.0, False]
    sample = hist.data["Sample Parameters"]
    sample["Shift"] = [-300.0, True]
    sample["Transparency"] = [0.0, False]
    project = refine_reopen(project, repeats=3, cycles=20)
    hist = project.histogram(0)
    result = {
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "GOF": project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "zero": hist.data["Instrument Parameters"][0]["Zero"],
        "shift_micrometres": hist.data["Sample Parameters"]["Shift"],
        "fractions": hist.ComputeMassFracs(),
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "converged": project.data["Covariance"]["data"].get("Rvals", {}).get("converged"),
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
