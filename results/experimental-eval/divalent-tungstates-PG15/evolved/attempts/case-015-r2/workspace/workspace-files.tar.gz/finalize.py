#!/usr/bin/env python3
"""Create the exact final GSAS-II project and synchronized deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from refinement_experiments import ROOT, refine_reopen


PHASE_META = {
    "ZnWO4": {
        "name": "zinc tungstate (wolframite)",
        "formula": "ZnWO4",
        "cif": "ZnWO4.cif",
        "source_cod_id": "1520641",
    },
    "WO3": {
        "name": "tungsten trioxide (triclinic)",
        "formula": "WO3",
        "cif": "WO3_triclinic.cif",
        "source_cod_id": "2106293",
    },
    "ZnO": {
        "name": "zinc oxide (wurtzite)",
        "formula": "ZnO",
        "cif": "ZnO.cif",
        "source_cod_id": "9004178",
    },
}


def enforce_final_model(project):
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]

    # Exactly one angular correction: instrument zero. No specimen shift or
    # transparency correction is active.
    inst = hist.data["Instrument Parameters"][0]
    for key, refine in {
        "Zero": True,
        "U": False,
        "V": False,
        "W": True,
        "X": True,
        "Y": False,
        "Z": False,
        "SH/L": True,
        "Polariz.": False,
        "I(L2)/I(L1)": False,
    }.items():
        inst[key][2] = refine
    inst["U"][1] = 2.0
    inst["V"][1] = 0.0
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["Polariz."][1] = 0.5
    inst["I(L2)/I(L1)"][1] = 0.5

    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"][1] = True
    sample["SurfRoughB"][1] = True

    background = hist.data["Background"][0]
    background[0] = "chebyschev-1"
    background[1] = True
    # Keep the accepted smooth six-coefficient background.
    if background[2] != 6:
        del background[9:]
        background[2] = 6

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Extinction"] = [0.0, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [False] * len(hap["Size"][2])
        hap["Size"][5][:] = [False] * len(hap["Size"][5])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2][:] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
        if phase.name == "WO3":
            hap["Mustrain"][1][0] = abs(float(hap["Mustrain"][1][0]))
            hap["Mustrain"][2][0] = True
        else:
            hap["Mustrain"][1][0] = 0.0


def main():
    G2sc.SetPrintLevel("all")
    project = G2sc.G2Project(
        # This is the clean converged triclinic branch. The similarly named
        # variant_triclinic.gpx was subsequently used for a rejected
        # anisotropic-broadening trial and is deliberately not reused here.
        str(ROOT / "exp_polarization.gpx"),
        newgpx=str(ROOT / "final.gpx"),
    )
    enforce_final_model(project)
    project = refine_reopen(project, repeats=1, cycles=8)
    enforce_final_model(project)
    project.save()
    project = G2sc.G2Project(str(ROOT / "final.gpx"))

    # One last no-change replay verifies that the saved state reproduces.
    project = refine_reopen(project, repeats=1, cycles=8)
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    if not rvals.get("converged", False):
        raise RuntimeError("Final refinement did not converge")
    if rvals.get("SVD0", 0):
        raise RuntimeError(f"Final refinement has {rvals['SVD0']} SVD singularities")

    fractions = hist.ComputeMassFracs()
    phase_results = []
    for phase in project.phases():
        meta = PHASE_META[phase.name]
        cif_path = ROOT / meta["cif"]
        phase.export_CIF(str(cif_path))
        sg = phase.data["General"]["SGData"]["SpGrp"].strip()
        frac, esd = fractions[phase.name]
        phase_results.append({
            "phase": meta["name"],
            "formula": meta["formula"],
            "space_group": sg,
            "cif_path": meta["cif"],
            "source_cod_id": meta["source_cod_id"],
            "weight_fraction": float(frac),
            "weight_fraction_formal_su": float(esd),
            "cell": {k: float(v) for k, v in phase.get_cell().items()},
        })

    x, yobs, weight, ycalc, ybkg, ydiff = [
        np.asarray(v, dtype=float) for v in hist.data["data"][1]
    ]
    if not np.allclose(ydiff, yobs - ycalc, atol=1e-8, rtol=0):
        raise RuntimeError("GSAS-II difference array is not observed minus calculated")
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "difference_observed_minus_calculated",
            "calculated_background",
        ])
        writer.writerows(zip(x, yobs, ycalc, ydiff, ybkg))

    fit_statistics = {
        "Rp_percent": float(hist.residuals["R"]),
        "Rwp_percent": float(hist.residuals["wR"]),
        "Rexp_percent": float(hist.residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_variables": int(rvals["Nvars"]),
        "refinement_range_two_theta_deg": [
            float(hist.data["Limits"][1][0]),
            float(hist.data["Limits"][1][1]),
        ],
    }
    result = {
        "method": "GSAS-II Rietveld refinement",
        "project_path": "final.gpx",
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phase_results,
        "fit_statistics": fit_statistics,
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    print(json.dumps({
        "fit_statistics": fit_statistics,
        "fractions": {k: list(v) for k, v in fractions.items()},
        "max_shift_over_su": rvals.get("Max shft/sig"),
        "files": ["final.gpx", "fit.csv", "result.json"] + [
            PHASE_META[p.name]["cif"] for p in project.phases()
        ],
    }, indent=2))


if __name__ == "__main__":
    main()
