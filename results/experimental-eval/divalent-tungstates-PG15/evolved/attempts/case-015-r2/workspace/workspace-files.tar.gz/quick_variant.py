#!/usr/bin/env python3
"""Near-solution matched refinement for the triclinic WO3 candidate."""

import json

from GSASII import GSASIIscriptable as G2sc

from refinement_experiments import build_baseline, refine_reopen


def main():
    G2sc.SetPrintLevel("none")
    project = build_baseline("variant_triclinic.gpx", "2106293")
    hist = project.histogram(0)
    hist.data["Background"][0][3:] = [549.1, -647.6, 455.0, -237.1, 105.2, -37.0]
    inst = hist.data["Instrument Parameters"][0]
    for key, value, refine in [
        ("Zero", 0.186, True), ("W", 78.0, True), ("X", 5.05, True),
        ("SH/L", 0.083, True), ("U", 2.0, False), ("V", 0.0, False),
    ]:
        inst[key][1] = value
        inst[key][2] = refine
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.162, True]
    sample["SurfRoughB"] = [0.844, True]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    wo3 = project.phase("WO3")
    hap = wo3.data["Histograms"][hist.name]
    hap["Mustrain"][1][0] = 2000.0
    wo3.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project = refine_reopen(project, repeats=3, cycles=20)
    hist = project.histogram(0)
    result = {
        "Rwp": hist.residuals.get("wR"),
        "Rp": hist.residuals.get("R"),
        "GOF": project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "fractions": hist.ComputeMassFracs(),
        "WO3_cell": project.phase("WO3").get_cell(),
        "WO3_strain": project.phase("WO3").data["Histograms"][hist.name]["Mustrain"][1][0],
        "converged": project.data["Covariance"]["data"].get("Rvals", {}).get("converged"),
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
