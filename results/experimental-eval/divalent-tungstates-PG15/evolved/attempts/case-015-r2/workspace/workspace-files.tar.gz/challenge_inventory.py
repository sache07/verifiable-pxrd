#!/usr/bin/env python3
"""Re-challenge weak phase candidates under a converged common profile."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def refine_reopen(project, cycles=15):
    project.data["Controls"]["data"]["max cyc"] = cycles
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.save()
    project = G2sc.G2Project(project.filename)
    project.data["Controls"]["data"]["max cyc"] = cycles
    project.refine(makeBack=False)
    project.save()
    return G2sc.G2Project(project.filename)


def main():
    G2sc.SetPrintLevel("none")
    out = ROOT / "challenge_zno.gpx"
    project = G2sc.G2Project(str(ROOT / "trial_zw_wm.gpx"), newgpx=str(out))
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cod_cif("9004178")),
        phasename="ZnO",
        histograms=[hist],
        fmthint="CIF",
    )
    phase.set_refinements({"Cell": False})
    phase.set_HAP_refinements({"Scale": True})
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.05, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    project = refine_reopen(project)
    scale_only = {
        "residuals": project.histogram(0).residuals,
        "scale": project.phase("ZnO").data["Histograms"][project.histogram(0).name]["Scale"],
        "mass_fractions": project.histogram(0).ComputeMassFracs(),
    }
    project.phase("ZnO").set_refinements({"Cell": True})
    project = refine_reopen(project)
    project = refine_reopen(project)
    final = {
        "residuals": project.histogram(0).residuals,
        "scale": project.phase("ZnO").data["Histograms"][project.histogram(0).name]["Scale"],
        "cell": project.phase("ZnO").get_cell(),
        "mass_fractions": project.histogram(0).ComputeMassFracs(),
    }
    print(json.dumps({"scale_only": scale_only, "cell_refined": final}, indent=2))


if __name__ == "__main__":
    main()
