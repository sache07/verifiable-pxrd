#!/usr/bin/env python3
"""Discriminate plausible polarization and surface-roughness corrections."""

from __future__ import annotations

import json
import sys

import numpy as np

from refine_workflow import GSAS2_SITE, ROOT, refine_and_log

sys.path.insert(0, str(GSAS2_SITE))
from GSASII import GSASIIscriptable as G2sc  # noqa: E402


SOURCE = ROOT / ".tmp" / "final_p1_strain.gpx"


def run(kind: str) -> list[dict]:
    output = ROOT / ".tmp" / f"correction_{kind}.gpx"
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(output))
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.data["Sample Parameters"]

    if kind == "roughness_ab":
        sample["SurfRoughA"] = [0.10, True]
        sample["SurfRoughB"] = [0.10, True]
        for key in ("SurfRoughA", "SurfRoughB"):
            project.set_Controls("parmMin", 0.0, variable=f":0:{key}")
            project.set_Controls("parmMax", 1.0, variable=f":0:{key}")
    elif kind == "polarization_roughness_b":
        inst["Polariz."][1] = 0.60
        inst["Polariz."][2] = True
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.03, True]
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughB")
    else:
        raise ValueError(kind)

    log: list[dict] = []
    refine_and_log(project, kind, log)
    project.save()
    project = G2sc.G2Project(str(output))
    refine_and_log(project, kind + "_replay", log)
    return log


def main() -> None:
    logs = {kind: run(kind) for kind in ("roughness_ab", "polarization_roughness_b")}
    (ROOT / ".tmp" / "correction_discrimination_log.json").write_text(
        json.dumps(logs, indent=2,
                   default=lambda obj: obj.tolist() if isinstance(obj, np.ndarray) else str(obj))
        + "\n"
    )


if __name__ == "__main__":
    main()
