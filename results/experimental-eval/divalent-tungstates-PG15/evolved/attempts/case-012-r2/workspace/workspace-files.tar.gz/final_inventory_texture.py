#!/usr/bin/env python3
"""Re-challenge residual NiO and low-index texture under the selected correction."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

from refine_workflow import GSAS2_SITE, ROOT, neutralize_phase, refine_and_log

sys.path.insert(0, str(GSAS2_SITE))
from GSASII import GSASIIscriptable as G2sc  # noqa: E402


SOURCE = ROOT / ".tmp" / "nuisance_polarization.gpx"
CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
NIO = CIF_ROOT / "1" / "01" / "00" / "1010093.cif"
AXES = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)]


def texture(phase_index: int, axis: tuple[int, int, int]) -> list[dict]:
    axis_tag = "".join(str(v) for v in axis)
    tag = f"final_texture_p{phase_index}_{axis_tag}"
    output = ROOT / ".tmp" / f"{tag}.gpx"
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(output))
    hist = project.histogram(0)
    po = project.phase(phase_index).getHAPvalues(hist)["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)
    project.set_Controls("parmMin", 0.5, variable=f"{phase_index}:0:MD")
    project.set_Controls("parmMax", 2.0, variable=f"{phase_index}:0:MD")
    log: list[dict] = []
    refine_and_log(project, tag, log)
    project.save()
    project = G2sc.G2Project(str(output))
    refine_and_log(project, tag + "_replay", log)
    return log


def nio_challenge() -> list[dict]:
    output = ROOT / ".tmp" / "final_NiO_challenge.gpx"
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(output))
    hist = project.histogram(0)
    nio = project.add_phase(
        str(NIO), phasename="NiO_watch", histograms=[hist], fmthint="CIF"
    )
    neutralize_phase(nio, hist)
    nio.getHAPvalues(hist)["Scale"][0] = 0.5
    nio.set_HAP_refinements({"Scale": True}, [hist])
    project.set_Controls("parmMin", 0.0, variable="2:0:Scale")
    project.save()
    log: list[dict] = []
    refine_and_log(project, "NiO_scale", log)
    project.save()
    project = G2sc.G2Project(str(output))
    refine_and_log(project, "NiO_scale_replay", log)
    return log


def main() -> None:
    logs: dict[str, object] = {"NiO": nio_challenge()}
    for phase_index in (0, 1):
        for axis in AXES:
            key = f"p{phase_index}_" + "".join(str(v) for v in axis)
            logs[key] = texture(phase_index, axis)
    (ROOT / ".tmp" / "final_inventory_texture_log.json").write_text(
        json.dumps(logs, indent=2,
                   default=lambda obj: obj.tolist() if isinstance(obj, np.ndarray) else str(obj))
        + "\n"
    )


if __name__ == "__main__":
    main()
