#!/usr/bin/env python3
"""Test conservative coordinate releases for the two supported phases."""

from __future__ import annotations

import json
import sys

import numpy as np

from refine_workflow import GSAS2_SITE, ROOT, refine_and_log

sys.path.insert(0, str(GSAS2_SITE))
from GSASII import GSASIIscriptable as G2sc  # noqa: E402


SOURCE = ROOT / ".tmp" / "trial_p1_strain.gpx"
TRIALS = {
    "niwo4_W": (0, ["W1"]),
    "niwo4_cations": (0, ["Ni1", "W1"]),
    "niwo4_all": (0, ["Ni1", "W1", "O1", "O2"]),
    "wo3_W": (1, ["W1", "W2"]),
    "wo3_all": (1, ["O6", "O2", "W1", "O5", "O3", "O1", "W2", "O4"]),
}


def trial(name: str, phase_index: int, labels: list[str]) -> list[dict]:
    output = ROOT / ".tmp" / f"coord_{name}.gpx"
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(output))
    phase = project.phase(phase_index)
    for label in labels:
        phase.atom(label).refinement_flags = "X"
    logs: list[dict] = []
    refine_and_log(project, name, logs)
    project.save()
    project = G2sc.G2Project(str(output))
    refine_and_log(project, name + "_replay", logs)
    return logs


def main() -> None:
    logs = {name: trial(name, *spec) for name, spec in TRIALS.items()}
    (ROOT / ".tmp" / "coordinate_trials_log.json").write_text(
        json.dumps(logs, indent=2, default=lambda obj: obj.tolist() if isinstance(obj, np.ndarray) else str(obj))
        + "\n"
    )


if __name__ == "__main__":
    main()
