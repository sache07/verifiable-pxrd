#!/usr/bin/env python3
"""Audit size/strain choices under the exact final intensity correction."""

from __future__ import annotations

import json
import sys

import numpy as np

from refine_workflow import GSAS2_SITE, ROOT, refine_and_log

sys.path.insert(0, str(GSAS2_SITE))
from GSASII import GSASIIscriptable as G2sc  # noqa: E402


NEUTRAL = ROOT / ".tmp" / "post_final_neutral.gpx"


def make_neutral() -> list[dict]:
    project = G2sc.G2Project(str(ROOT / "final.gpx"))
    project.save(str(NEUTRAL))
    hap = project.phase(1).getHAPvalues(project.histogram(0))["Mustrain"]
    hap[0] = "isotropic"
    hap[1][:] = [0.0, 0.0, 0.0]
    hap[2][:] = [False, False, False]
    log: list[dict] = []
    refine_and_log(project, "post_final_neutral", log)
    project = G2sc.G2Project(str(NEUTRAL))
    refine_and_log(project, "post_final_neutral_replay", log)
    return log


def trial(phase_index: int, kind: str) -> list[dict]:
    tag = f"post_final_p{phase_index}_{kind}"
    output = ROOT / ".tmp" / f"{tag}.gpx"
    project = G2sc.G2Project(str(NEUTRAL))
    project.save(str(output))
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    if kind == "size":
        phase.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=0.0)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True,
                      "LGmix": {"value": 0.0, "refine": False}}}, [hist]
        )
    else:
        phase.setSampleProfile(hist, "microstrain", "isotropic", 100.0, LGmix=0.0)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True,
                          "LGmix": {"value": 0.0, "refine": False}}}, [hist]
        )
    log: list[dict] = []
    refine_and_log(project, tag, log)
    project = G2sc.G2Project(str(output))
    refine_and_log(project, tag + "_replay", log)
    return log


def main() -> None:
    logs: dict[str, object] = {"neutral": make_neutral()}
    for phase_index in (0, 1):
        for kind in ("size", "strain"):
            logs[f"p{phase_index}_{kind}"] = trial(phase_index, kind)
    (ROOT / ".tmp" / "post_final_profile_audit.json").write_text(
        json.dumps(logs, indent=2,
                   default=lambda obj: obj.tolist() if isinstance(obj, np.ndarray) else str(obj))
        + "\n"
    )


if __name__ == "__main__":
    main()
