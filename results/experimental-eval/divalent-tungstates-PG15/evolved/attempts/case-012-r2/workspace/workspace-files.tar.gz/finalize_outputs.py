#!/usr/bin/env python3
"""Replay the accepted GSAS-II model and write the requested deliverables."""

from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import numpy as np

from refine_workflow import GSAS2_SITE, ROOT

sys.path.insert(0, str(GSAS2_SITE))
from GSASII import GSASIIscriptable as G2sc  # noqa: E402


SOURCE = ROOT / ".tmp" / "nuisance_polarization.gpx"
FINAL = ROOT / "final.gpx"
PHASE_DIR = ROOT / "phases"


def covariance_lookup(project: G2sc.G2Project) -> tuple[dict[str, float], dict[str, float]]:
    cov = project.data["Covariance"]["data"]
    values = dict(zip(cov.get("varyList", []), cov.get("variables", [])))
    sigmas = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    return values, sigmas


def peak_metrics(x: np.ndarray, signal: np.ndarray, background: np.ndarray,
                 center: float, half_window: float) -> dict[str, float]:
    use = (x > center - half_window) & (x < center + half_window)
    xx = x[use]
    yy = signal[use] - background[use]
    nedge = max(3, len(xx) // 10)
    local_floor = np.linspace(np.median(yy[:nedge]), np.median(yy[-nedge:]), len(yy))
    yy = yy - local_floor
    near = np.abs(xx - center) < min(0.15, half_window / 2)
    imax = np.where(near)[0][np.argmax(yy[near])]
    half_height = yy[imax] / 2.0

    left = right = math.nan
    for j in range(imax - 1, -1, -1):
        if yy[j] <= half_height < yy[j + 1]:
            left = xx[j] + (half_height - yy[j]) * (xx[j + 1] - xx[j]) / (yy[j + 1] - yy[j])
            break
    for j in range(imax, len(xx) - 1):
        if yy[j + 1] <= half_height < yy[j]:
            right = xx[j] + (half_height - yy[j]) * (xx[j + 1] - xx[j]) / (yy[j + 1] - yy[j])
            break
    top = (yy > 0.65 * yy[imax]) & (np.abs(xx - xx[imax]) < 0.15)
    centroid = float(np.sum(xx[top] * yy[top]) / np.sum(yy[top]))
    return {
        "centroid_deg": centroid,
        "fwhm_deg": float(right - left),
        "left_half_width_deg": float(xx[imax] - left),
        "right_half_width_deg": float(right - xx[imax]),
    }


def main() -> None:
    # Copy through GSAS-II so the new project is self-consistent, then replay
    # after expanding the fit limits to the exact measured endpoints.
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(FINAL))
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)
    xy = hist.data["data"][1]
    xlo = float(xy[0][0])
    xhi = float(xy[0][-1])
    hist.data["Limits"][1] = [xlo, xhi]
    project.set_Controls("cycles", 20)
    project.refine(makeBack=False)
    project.save()
    project = G2sc.G2Project(str(FINAL))
    project.refine(makeBack=False)
    project.save()

    # All exports below are made from this exact, reopened final project.
    project = G2sc.G2Project(str(FINAL))
    hist = project.histogram(0)
    xy = np.asarray(hist.data["data"][1], dtype=float)
    x, observed, weights, calculated, background, _stored_difference = xy
    rvals = project.data["Covariance"]["data"]["Rvals"]
    if int(rvals["Nobs"]) != len(x):
        raise RuntimeError(f"full-range replay used {rvals['Nobs']} of {len(x)} points")
    if np.any(calculated <= 0):
        raise RuntimeError("one or more full-range calculated intensities are missing")

    PHASE_DIR.mkdir(exist_ok=True)
    cif_paths = [
        PHASE_DIR / "NiWO4_wolframite.cif",
        PHASE_DIR / "WO3_monoclinic.cif",
    ]
    for phase, path in zip(project.phases(), cif_paths):
        phase.export_CIF(str(path))

    fit_path = ROOT / "fit.csv"
    with fit_path.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg", "observed_counts", "calculated_counts",
            "background_counts", "difference_counts",
        ])
        for row in zip(x, observed, calculated, background, observed - calculated):
            writer.writerow([f"{float(value):.10g}" for value in row])

    mass_fracs = hist.ComputeMassFracs()
    if not math.isclose(sum(v[0] for v in mass_fracs.values()), 1.0, abs_tol=1e-10):
        raise RuntimeError("mass fractions do not sum to one")
    values, sigmas = covariance_lookup(project)
    residuals = hist.residuals
    cells = [phase.get_cell() for phase in project.phases()]
    phase_specs = [
        {
            "project_name": "NiWO4_wolframite",
            "name": "nickel tungstate (wolframite)",
            "formula": "NiWO4",
            "space_group": "P 2/c",
            "space_group_number": 13,
            "cif_path": "phases/NiWO4_wolframite.cif",
            "source_model": "Ni-for-Zn substitution in isostructural COD 1520641; NiWO4 metric from COD 5910277",
            "estimated_systematic_uncertainty": 0.01,
        },
        {
            "project_name": "WO3_2311041",
            "name": "tungsten(VI) oxide (monoclinic gamma-WO3)",
            "formula": "WO3",
            "space_group": "P 21/c",
            "space_group_number": 14,
            "cif_path": "phases/WO3_monoclinic.cif",
            "source_model": "COD 2311041 neutron structure; alternate P21/c cell setting",
            "estimated_systematic_uncertainty": 0.01,
        },
    ]
    phases_json = []
    for i, (phase, spec, cell) in enumerate(zip(project.phases(), phase_specs, cells)):
        fraction, fraction_su = mass_fracs[phase.name]
        phases_json.append({
            **spec,
            "weight_fraction": fraction,
            "formal_standard_uncertainty": fraction_su,
            "cell": {key: float(value) for key, value in cell.items()},
            "fit_statistics": {
                "R_F_percent": float(residuals[f"{i}:0:Rf"]),
                "R_F_squared_percent": float(residuals[f"{i}:0:Rf^2"]),
                "number_of_reflections": int(residuals[f"{i}:0:Nref"]),
            },
        })

    fit_statistics = {
        "R_wp_percent": float(residuals["wR"]),
        "R_p_percent": float(residuals["R"]),
        "R_exp_percent": float(residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "number_of_observations": int(rvals["Nobs"]),
        "number_of_refined_parameters": int(rvals["Nvars"]),
        "weighted_background_R_percent": float(residuals["wRb"]),
    }
    if "Durbin-Watson" in residuals:
        fit_statistics["durbin_watson"] = float(residuals["Durbin-Watson"])

    result = {
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over the modeled crystalline phases; no amorphous fraction determined",
        "phases": phases_json,
        "fit_statistics": fit_statistics,
        "refined_profile": {
            "two_theta_range_deg": [float(x[0]), float(x[-1])],
            "background": "8-term Chebyshev-1",
            "specimen_displacement_micrometers": float(hist.data["Sample Parameters"]["Shift"][0]),
            "effective_polarization": float(hist.InstrumentParameters["Polariz."][1]),
            "profile_W": float(hist.InstrumentParameters["W"][1]),
            "profile_X": float(hist.InstrumentParameters["X"][1]),
            "WO3_isotropic_microstrain": float(project.phase(1).getHAPvalues(hist)["Mustrain"][1][0]),
            "weighting": "count-statistical proxy, weight = 1/observed counts; pointwise uncertainties were not supplied",
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    checks = [
        ("low-angle NiWO4 100", 19.19, 0.65),
        ("mid-angle NiWO4-dominated group", 54.55, 0.65),
        ("high-angle NiWO4-dominated group", 91.93, 0.45),
    ]
    diagnostic_rows = []
    for label, center, half_window in checks:
        obs = peak_metrics(x, observed, background, center, half_window)
        calc = peak_metrics(x, calculated, background, center, half_window)
        diagnostic_rows.append((label, obs, calc))
    max_center_delta = max(abs(o["centroid_deg"] - c["centroid_deg"])
                           for _, o, c in diagnostic_rows)
    max_width_delta = max(abs(o["fwhm_deg"] - c["fwhm_deg"])
                          for _, o, c in diagnostic_rows)

    ni_frac, ni_su = mass_fracs["NiWO4_wolframite"]
    wo_frac, wo_su = mass_fracs["WO3_2311041"]
    report = f"""# Quantitative crystalline-phase analysis

## Result

| Phase | Structural model | Weight fraction |
|---|---|---:|
| NiWO4, wolframite | P 2/c (No. 13) | {100*ni_frac:.2f}% |
| WO3, monoclinic gamma form | P 21/c (No. 14, alternate setting) | {100*wo_frac:.2f}% |

Fractions are normalized over the two modeled crystalline phases. The formal GSAS-II standard uncertainty is {100*ni_su:.2f} percentage point for either fraction, but model/source choices dominate; a more realistic uncertainty is about ±1 percentage point. No amorphous fraction can be obtained without an internal standard.

The final full-range replay gives Rwp = {residuals['wR']:.3f}%, Rp = {residuals['R']:.3f}%, Rexp = {residuals['wRmin']:.3f}%, and GOF = {rvals['GOF']:.3f} for {int(rvals['Nobs'])} points. Because pointwise uncertainties were not supplied, count-statistical weights (1/count) were used; formal uncertainties and GOF should therefore not be over-interpreted.

## Evidence and structural choices

Wolframite NiWO4 accounts for the dominant families (including 19.19°, 30.85°, 36.5°, and 54.6° 2theta). Coherent residual families at 23.03–24.27°, 33.2–34.1°, 49.9°, and 55.9° require WO3. Monoclinic room-temperature WO3 records reproduce these families; orthorhombic/hexagonal candidates fail positionally. A triclinic WO3 record gives a nearly indistinguishable small residual improvement, so the subtle monoclinic-versus-triclinic distortion is not reliably resolvable here; the physically expected room-temperature monoclinic model was retained.

The exact older NiWO4 database record has an incomplete oxygen asymmetric unit. A complete isostructural ZnWO4 parent (COD 1520641) was therefore screened with Ni substituted on the octahedral divalent-cation site. It outperformed the MnWO4 analogue and gives physical final geometry (Ni–O 2.064–2.083 Å; W–O 1.785–2.108 Å). Only Ni and W positional coordinates were refined. Oxygen coordinates in NiWO4, and all WO3 atomic coordinates, are source-model values and cannot be determined reliably from this Cu X-ray powder pattern.

NiO was reintroduced under the final common profile as a watch-list phase; its scale collapsed to 10^-12 and its unique 43.3°, 62.9°, and 75.5° families are absent. It was excluded. This rejects crystalline NiO at the sensitivity of this pattern, not every possible trace phase.

## Profile adequacy and remaining uncertainty

The accepted baseline uses a smooth 8-term Chebyshev background, one specimen-displacement correction, nonnegative common W/X broadening (U fixed at its zero bound), fixed minimum SH/L, and one refined effective-polarization term. WO3 alone requires replay-stable isotropic microstrain. Size terms hit bounds, SH/L was 97% correlated with displacement, and tested preferred-orientation axes were not supported coherently across multiple families, so these terms were pruned. A surface-roughness alternative was rejected because it was more scale-correlated and its two-parameter form collapsed to a boundary.

For isolated NiWO4-dominated groups sampled at low, middle, and high angle, observed/calculated centroids agree within {max_center_delta:.3f}° and local FWHM values within {max_width_delta:.3f}°. No repeated asymmetry residual remains across those groups. Remaining systematic uncertainty comes mainly from the uncalibrated instrument/intensity correction, fixed light-atom coordinates, WO3 symmetry ambiguity, peak overlap, and normalization only over modeled crystalline material.
"""
    (ROOT / "report.md").write_text(report)

    print(json.dumps({
        "Rwp_percent": residuals["wR"],
        "GOF": rvals["GOF"],
        "mass_fractions": mass_fracs,
        "n_observations": rvals["Nobs"],
        "n_parameters": rvals["Nvars"],
        "max_peak_centroid_delta_deg": max_center_delta,
        "max_peak_fwhm_delta_deg": max_width_delta,
        "final_project": str(FINAL),
    }, indent=2))


if __name__ == "__main__":
    main()
