#!/usr/bin/env python3
"""Compare phase-specific size and strain against the common profile."""

from __future__ import annotations

import copy
import json
import sys
from pathlib import Path

import numpy as np

from refine_workflow import GSAS2_SITE, ROOT, refine_and_log

sys.path.insert(0, str(GSAS2_SITE))
from GSASII import GSASIIscriptable as G2sc  # noqa: E402


SOURCE = ROOT / ".tmp" / "screen_2311041.gpx"


def run_trial(phase_index: int, kind: str) -> list[dict]:
    tag = f"p{phase_index}_{kind}"
    output = ROOT / ".tmp" / f"trial_{tag}.gpx"
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(output))
    hist = project.histogram(0)
    phase = project.phase(phase_index)

    if kind == "size":
        phase.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=0.0)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True, "LGmix": {"value": 0.0, "refine": False}}},
            [hist],
        )
    elif kind == "strain":
        phase.setSampleProfile(hist, "microstrain", "isotropic", 100.0, LGmix=0.0)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True, "LGmix": {"value": 0.0, "refine": False}}},
            [hist],
        )
    else:
        raise ValueError(kind)

    logs: list[dict] = []
    refine_and_log(project, tag, logs)
    project.save()
    project = G2sc.G2Project(str(output))
    refine_and_log(project, tag + "_replay", logs)
    return logs


def main() -> None:
    logs = {}
    for phase_index in (0, 1):
        for kind in ("size", "strain"):
            logs[f"p{phase_index}_{kind}"] = run_trial(phase_index, kind)
    (ROOT / ".tmp" / "profile_trials_log.json").write_text(
        json.dumps(logs, indent=2, default=lambda obj: obj.tolist() if isinstance(obj, np.ndarray) else str(obj))
        + "\n"
    )


if __name__ == "__main__":
    main()
