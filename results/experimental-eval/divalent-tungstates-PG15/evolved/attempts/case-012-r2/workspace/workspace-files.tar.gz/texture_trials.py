#!/usr/bin/env python3
"""Screen low-index March-Dollase axes against the no-texture baseline."""

from __future__ import annotations

import copy
import json
import sys

import numpy as np

from refine_workflow import GSAS2_SITE, ROOT, snapshot

sys.path.insert(0, str(GSAS2_SITE))
from GSASII import GSASIIscriptable as G2sc  # noqa: E402


SOURCE = ROOT / ".tmp" / "trial_p1_strain.gpx"
AXES = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)]


def trial(phase_index: int, axis: tuple[int, int, int]) -> dict:
    tag = f"p{phase_index}_" + "".join(map(str, axis))
    output = ROOT / ".tmp" / f"texture_{tag}.gpx"
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(output))
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    po = phase.getHAPvalues(hist)["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)
    project.set_Controls("parmMin", 0.5, variable=f"{phase_index}:0:MD")
    project.set_Controls("parmMax", 2.0, variable=f"{phase_index}:0:MD")
    project.refine(makeBack=False)
    project.save()
    return snapshot(project, tag)


def main() -> None:
    results = {}
    for phase_index in (0, 1):
        for axis in AXES:
            key = f"p{phase_index}_" + "".join(map(str, axis))
            print("testing", key)
            results[key] = trial(phase_index, axis)
    (ROOT / ".tmp" / "texture_trials_log.json").write_text(
        json.dumps(results, indent=2, default=lambda obj: obj.tolist() if isinstance(obj, np.ndarray) else str(obj))
        + "\n"
    )


if __name__ == "__main__":
    main()
