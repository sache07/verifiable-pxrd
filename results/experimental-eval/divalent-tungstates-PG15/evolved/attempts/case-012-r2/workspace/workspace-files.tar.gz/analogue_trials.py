#!/usr/bin/env python3
"""Compare complete wolframite analogue records under the accepted baseline."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

from refine_workflow import GSAS2_SITE, ROOT, build_project, refine_and_log

sys.path.insert(0, str(GSAS2_SITE))
from GSASII import GSASIIscriptable as G2sc  # noqa: E402


CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
WO3 = CIF_ROOT / "2" / "31" / "10" / "2311041.cif"


def run(tag: str, cif: Path) -> list[dict]:
    output = ROOT / ".tmp" / f"analogue_{tag}.gpx"
    project, hist = build_project(output, WO3, cif)
    log: list[dict] = []
    refine_and_log(project, "background_scales", log)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.data["Sample Parameters"]["Shift"][1] = True
    refine_and_log(project, "cells_shift", log)
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine_and_log(project, "common_profile", log)

    wo3 = project.phase(1)
    wo3.setSampleProfile(hist, "microstrain", "isotropic", 100.0, LGmix=0.0)
    wo3.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True, "LGmix": {"value": 0.0, "refine": False}}},
        [hist],
    )
    refine_and_log(project, "wo3_strain", log)
    project.save()
    project = G2sc.G2Project(str(output))
    refine_and_log(project, "fixed_coords_replay", log)

    niwo4 = project.phase(0)
    niwo4.atom("Ni1").refinement_flags = "X"
    niwo4.atom("W1").refinement_flags = "X"
    refine_and_log(project, "cation_coords", log)
    project.save()
    project = G2sc.G2Project(str(output))
    refine_and_log(project, "cation_coords_replay", log)
    return log


def main() -> None:
    records = {
        "Zn_parent": ROOT / "models" / "NiWO4_Zn_analogue.cif",
        "Mn_parent": ROOT / "models" / "NiWO4_Mn_analogue.cif",
    }
    logs = {tag: run(tag, path) for tag, path in records.items()}
    (ROOT / ".tmp" / "analogue_trials_log.json").write_text(
        json.dumps(logs, indent=2, default=lambda obj: obj.tolist() if isinstance(obj, np.ndarray) else str(obj))
        + "\n"
    )


if __name__ == "__main__":
    main()
