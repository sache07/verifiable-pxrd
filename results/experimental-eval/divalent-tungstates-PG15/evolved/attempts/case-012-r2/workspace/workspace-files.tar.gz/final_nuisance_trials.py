#!/usr/bin/env python3
"""Challenge angular/profile and low-angle intensity corrections one at a time."""

from __future__ import annotations

import json
import sys

import numpy as np

from refine_workflow import GSAS2_SITE, ROOT, refine_and_log

sys.path.insert(0, str(GSAS2_SITE))
from GSASII import GSASIIscriptable as G2sc  # noqa: E402


SOURCE = ROOT / ".tmp" / "final_p1_strain.gpx"


def trial(kind: str) -> list[dict]:
    output = ROOT / ".tmp" / f"nuisance_{kind}.gpx"
    project = G2sc.G2Project(str(SOURCE))
    project.save(str(output))
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.data["Sample Parameters"]

    if kind == "U":
        inst["U"][1] = 1.0
        inst["U"][2] = True
        project.set_Controls("parmMin", 0.0, variable=":0:U")
    elif kind == "shl":
        inst["SH/L"][1] = 0.005
        inst["SH/L"][2] = True
        project.set_Controls("parmMin", 0.002, variable=":0:SH/L")
        project.set_Controls("parmMax", 0.2, variable=":0:SH/L")
    elif kind == "polarization":
        inst["Polariz."][2] = True
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif kind == "roughness_b":
        sample["SurfRoughA"] = [0.0, False]
        sample["SurfRoughB"] = [0.001, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughB")
    else:
        raise ValueError(kind)

    log: list[dict] = []
    refine_and_log(project, kind, log)
    project.save()
    project = G2sc.G2Project(str(output))
    refine_and_log(project, kind + "_replay", log)
    return log


def main() -> None:
    logs = {kind: trial(kind) for kind in ("U", "shl", "polarization", "roughness_b")}
    (ROOT / ".tmp" / "final_nuisance_trials_log.json").write_text(
        json.dumps(logs, indent=2,
                   default=lambda obj: obj.tolist() if isinstance(obj, np.ndarray) else str(obj))
        + "\n"
    )


if __name__ == "__main__":
    main()
