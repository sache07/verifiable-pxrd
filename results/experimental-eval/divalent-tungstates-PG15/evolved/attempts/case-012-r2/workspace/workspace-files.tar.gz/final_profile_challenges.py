#!/usr/bin/env python3
"""Rebuild the selected source model and replay phase-profile challenges."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

from refine_workflow import GSAS2_SITE, ROOT, build_project, refine_and_log

sys.path.insert(0, str(GSAS2_SITE))
from GSASII import GSASIIscriptable as G2sc  # noqa: E402


CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
WO3 = CIF_ROOT / "2" / "31" / "10" / "2311041.cif"
NIWO4 = ROOT / "models" / "NiWO4_Zn_analogue.cif"
NEUTRAL = ROOT / ".tmp" / "final_neutral.gpx"


def build_neutral() -> list[dict]:
    project, hist = build_project(NEUTRAL, WO3, NIWO4)
    log: list[dict] = []
    refine_and_log(project, "background_scales", log)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.data["Sample Parameters"]["Shift"][1] = True
    refine_and_log(project, "cells_shift", log)
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine_and_log(project, "common_profile", log)
    project.phase(0).atom("Ni1").refinement_flags = "X"
    project.phase(0).atom("W1").refinement_flags = "X"
    refine_and_log(project, "cation_coordinates", log)
    project.save()
    project = G2sc.G2Project(str(NEUTRAL))
    refine_and_log(project, "neutral_replay", log)
    return log


def trial(phase_index: int, kind: str) -> list[dict]:
    tag = f"final_p{phase_index}_{kind}"
    output = ROOT / ".tmp" / f"{tag}.gpx"
    project = G2sc.G2Project(str(NEUTRAL))
    project.save(str(output))
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    if kind == "size":
        phase.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=0.0)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True,
                      "LGmix": {"value": 0.0, "refine": False}}},
            [hist],
        )
    elif kind == "strain":
        phase.setSampleProfile(hist, "microstrain", "isotropic", 100.0, LGmix=0.0)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True,
                          "LGmix": {"value": 0.0, "refine": False}}},
            [hist],
        )
    else:
        raise ValueError(kind)
    log: list[dict] = []
    refine_and_log(project, tag, log)
    project.save()
    project = G2sc.G2Project(str(output))
    refine_and_log(project, tag + "_replay", log)
    return log


def main() -> None:
    logs: dict[str, object] = {"neutral": build_neutral()}
    for phase_index in (0, 1):
        for kind in ("size", "strain"):
            logs[f"p{phase_index}_{kind}"] = trial(phase_index, kind)
    (ROOT / ".tmp" / "final_profile_challenges_log.json").write_text(
        json.dumps(logs, indent=2,
                   default=lambda obj: obj.tolist() if isinstance(obj, np.ndarray) else str(obj))
        + "\n"
    )


if __name__ == "__main__":
    main()
