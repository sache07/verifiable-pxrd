#!/usr/bin/env python3
"""Re-challenge the coherent two-phase baseline with residual NiO."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from refine_workflow import ROOT, GSAS2_SITE, build_project, neutralize_phase, refine_and_log

import sys

sys.path.insert(0, str(GSAS2_SITE))
from GSASII import GSASIIscriptable as G2sc  # noqa: E402


CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def challenge(wo3_id: str) -> list[dict]:
    out = ROOT / ".tmp" / f"challenge_{wo3_id}_NiO.gpx"
    project, hist = build_project(out, cif_path(wo3_id))
    nio = project.add_phase(
        str(cif_path("1010093")),
        phasename="NiO_1010093",
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_phase(nio, hist)
    nio.getHAPvalues(hist)["Scale"][0] = 0.25
    nio.set_HAP_refinements({"Scale": True}, [hist])
    project.save()
    project.set_Controls("parmMin", 0.0, variable="2:0:Scale")

    log: list[dict] = []
    refine_and_log(project, "rebuild_background_all_scales", log)
    # Refine cells only for the supported inventory; an unsupported test phase
    # must not be allowed to move its reflections to residual features.
    for phase in project.phases()[:2]:
        phase.set_refinements({"Cell": True})
    hist.data["Sample Parameters"]["Shift"][1] = True
    refine_and_log(project, "all_cells_shift", log)
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine_and_log(project, "common_W_X", log)
    project.save()
    project = G2sc.G2Project(str(out))
    refine_and_log(project, "reopen_replay", log)
    return log


def main() -> None:
    logs = {cod: challenge(cod) for cod in ("2311041", "2106293")}
    (ROOT / ".tmp" / "inventory_challenge_log.json").write_text(
        json.dumps(logs, indent=2, default=lambda obj: obj.tolist() if isinstance(obj, np.ndarray) else str(obj))
        + "\n"
    )


if __name__ == "__main__":
    main()
