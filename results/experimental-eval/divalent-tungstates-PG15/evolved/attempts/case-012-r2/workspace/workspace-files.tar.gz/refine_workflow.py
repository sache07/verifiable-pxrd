#!/usr/bin/env python3
"""Build and refine a conservative GSAS-II baseline for the PXRD pattern."""

from __future__ import annotations

import json
import copy
import sys
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
GSAS2_SITE = Path(
    "<HOME>/.local/share/characterizagent/backends/gsas2/venv/"
    "lib/python3.11/site-packages"
)
sys.path.insert(0, str(GSAS2_SITE))

from GSASII import GSASIIscriptable as G2sc  # noqa: E402


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phase_rows = []
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        phase_rows.append(
            {
                "name": phase.name,
                "cell": copy.deepcopy(phase.get_cell()),
                "scale": copy.deepcopy(hap["Scale"]),
                "size": copy.deepcopy(hap["Size"]),
                "mustrain": copy.deepcopy(hap["Mustrain"]),
                "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
            }
        )
    return {
        "label": label,
        "residuals": copy.deepcopy(hist.residuals),
        "instrument": copy.deepcopy(hist.InstrumentParameters),
        "sample": copy.deepcopy(hist.data["Sample Parameters"]),
        "background": copy.deepcopy(hist.data["Background"]),
        "phases": phase_rows,
    }


def refine_and_log(project: G2sc.G2Project, label: str, log: list[dict]) -> None:
    project.refine(makeBack=False)
    project.save()
    log.append(snapshot(project, label))
    print(label, project.histogram(0).residuals)


def neutralize_phase(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    """Remove phase-dependent broadening, texture, and intensity surrogates."""
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1.0, 1.0, 0.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 0.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"] = [0.0, False]
    hap["Babinet"]["BabU"] = [0.0, False]


def build_project(
    output: Path,
    wo3_cif: Path | None = None,
    niwo4_cif: Path | None = None,
) -> tuple[G2sc.G2Project, G2sc.G2PwdrData]:
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    phase = project.add_phase(
        str(niwo4_cif or (ROOT / "models" / "NiWO4_start.cif")),
        phasename="NiWO4_wolframite",
        histograms=[hist],
        fmthint="CIF",
    )
    phases = [phase]
    if wo3_cif is not None:
        phases.append(
            project.add_phase(
                str(wo3_cif),
                phasename=f"WO3_{wo3_cif.stem}",
                histograms=[hist],
                fmthint="CIF",
            )
        )
    project.save()
    project.set_Controls("cycles", 20)

    # Full measured range and a smooth low-order Chebyshev background.
    hist.set_refinements({"Limits": [10.01, 99.99]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
            }
        }
    )

    # Reflection geometry: refine specimen height (Shift), not a second zero term.
    sample = hist.data["Sample Parameters"]
    sample["Type"] = "Bragg-Brentano"
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [150.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    # Neutralize phase nuisance terms before testing them later.
    for p in phases:
        neutralize_phase(p, hist)

    inst = hist.InstrumentParameters
    inst["U"][1] = 0.0
    inst["V"][1] = 0.0
    inst["W"][1] = 36.0
    inst["X"][1] = 8.0
    inst["Y"][1] = 0.0
    for key in ("Zero", "U", "V", "Y", "Z", "SH/L", "I(L2)/I(L1)"):
        inst[key][2] = False
    for key in ("W", "X"):
        inst[key][2] = False
        project.set_Controls("parmMin", 0.0, variable=f":0:{key}")
    project.set_Controls("parmMin", -500.0, variable=":0:Shift")
    project.set_Controls("parmMax", 500.0, variable=":0:Shift")
    for i, p in enumerate(phases):
        p.getHAPvalues(hist)["Scale"][0] = 20.0 if i == 0 else 5.0
        p.set_HAP_refinements({"Scale": True}, [hist])
        project.set_Controls("parmMin", 0.0, variable=f"{i}:0:Scale")
    return project, hist


def refine_model(output: Path, wo3_cif: Path | None = None) -> list[dict]:
    project, hist = build_project(output, wo3_cif)
    log: list[dict] = []
    refine_and_log(project, "background_scale", log)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.data["Sample Parameters"]["Shift"][1] = True
    refine_and_log(project, "cell_shift_background_scale", log)

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine_and_log(project, "add_W_X", log)

    # Reopen and replay the exact active model to test persistence.
    project.save()
    project = G2sc.G2Project(str(output))
    refine_and_log(project, "reopen_replay", log)
    return log


def main() -> None:
    cif_root = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
    records = ["1528915", "2311041", "2106293", "2107312", "1010618", "1563541"]
    all_logs = {}
    for cod_id in records:
        cif = cif_root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"
        print(f"\n===== screening WO3 COD {cod_id} =====")
        all_logs[cod_id] = refine_model(ROOT / ".tmp" / f"screen_{cod_id}.gpx", cif)
    (ROOT / ".tmp" / "wo3_screen_log.json").write_text(
        json.dumps(all_logs, indent=2, default=lambda obj: obj.tolist() if isinstance(obj, np.ndarray) else str(obj))
        + "\n"
    )


if __name__ == "__main__":
    main()
