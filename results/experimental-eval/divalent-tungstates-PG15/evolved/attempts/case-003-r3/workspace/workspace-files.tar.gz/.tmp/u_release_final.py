#!/usr/bin/env python3
from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT=Path(__file__).resolve().parents[1]
TMP=ROOT/".tmp"
source=TMP/"sixphase_stable.gpx";target=TMP/"trial_final_u.gpx"
if target.exists():target.unlink()
gpx=G2sc.G2Project(str(source),newgpx=str(target))
gpx.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}
h=gpx.histogram(0);h.InstrumentParameters["U"][2]=True
gpx.set_Controls("parmMin",0.0,variable=":0:U")
gpx.set_Controls("parmMax",200.0,variable=":0:U")
for i in range(3):
    gpx.refine(printFile=str(TMP/f"trial_final_u_{i+1}.lst"))
    shifts,sigmas=gpx.get_LastFitResults()
    print("\npass",i+1,"R",json.dumps({k:v for k,v in h.residuals.items()
                                        if k in ("wR","R","wRb","Rb")},default=float),
          "profile",{k:h.InstrumentParameters[k] for k in ("U","W","X")},
          "mass",h.ComputeMassFracs(),"sigmaU",sigmas.get(":0:U"),
          "frozen",gpx.data["Controls"]["data"].get("parmFrozen"))
gpx.save()
