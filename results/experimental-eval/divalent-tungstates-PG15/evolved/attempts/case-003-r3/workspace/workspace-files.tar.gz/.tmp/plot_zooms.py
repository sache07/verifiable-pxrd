#!/usr/bin/env python3
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


data = np.load(Path(sys.argv[1]))
x, obs, calc, bkg, diff = (data[k] for k in
                           ("two_theta", "observed", "calculated", "background", "difference"))
windows = [(18.45, 19.35), (23.05, 23.75), (24.30, 25.00),
           (29.35, 30.05), (41.65, 42.55), (49.75, 50.65),
           (55.65, 56.75), (71.65, 72.65), (76.55, 77.75)]
fig, axes = plt.subplots(3, 3, figsize=(15, 10), constrained_layout=True)
for ax, limits in zip(axes.flat, windows):
    mask = (x >= limits[0]) & (x <= limits[1])
    ax.plot(x[mask], obs[mask], color="black", lw=1.0)
    ax.plot(x[mask], calc[mask], color="#d62728", lw=1.0)
    ax.plot(x[mask], bkg[mask], color="#2ca02c", lw=0.6)
    ax2 = ax.twinx()
    ax2.plot(x[mask], diff[mask], color="#1f77b4", lw=0.7, alpha=0.75)
    lim = max(100.0, np.max(np.abs(diff[mask])) * 1.25)
    ax2.set_ylim(-lim, lim)
    ax2.axhline(0, color="0.7", lw=0.4)
    ax2.tick_params(axis="y", colors="#1f77b4", labelsize=7)
    ax.set_xlim(*limits)
    ax.set_title(f"{limits[0]:.2f}–{limits[1]:.2f}°")
    ax.tick_params(labelsize=8)
fig.savefig(Path(sys.argv[2]), dpi=180)
