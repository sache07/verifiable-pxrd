#!/usr/bin/env python3
from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"


def report(gpx, label):
    h = gpx.histogram(0)
    print(f"\n=== {label} ===")
    print("residuals", json.dumps(h.residuals, sort_keys=True, default=float))
    print("mass", h.ComputeMassFracs())
    print("profile", {k: h.InstrumentParameters[k] for k in
                      ("U", "V", "W", "X", "Y", "SH/L")})
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        print(p.name, "size", hap["Size"][:3], "strain", hap["Mustrain"][:3])
    shifts, sigmas = gpx.get_LastFitResults()
    print("last", sorted(((abs(v), k, v, sigmas.get(k)) for k, v in shifts.items()),
                         reverse=True)[:6])


def fit(source, target, label, configure):
    path = TMP / target
    if path.exists():
        path.unlink()
    gpx = G2sc.G2Project(str(TMP / source), newgpx=str(path))
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    configure(gpx)
    for i in range(2):
        gpx.refine(printFile=str(TMP / f"{path.stem}_{i + 1}.lst"))
        report(gpx, f"{label} pass {i + 1}")
    gpx.save()


def add_wo3_strain(gpx):
    p = gpx.phase("WO3_monoclinic")
    p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True,
                                        "LGmix": {"value": 1.0, "refine": False}}})
    p.data["Histograms"][gpx.histogram(0).name]["Mustrain"][1][0] = 1000.0
    gpx.set_Controls("parmMin", 0.0, variable="0:0:Mustrain;i")
    gpx.set_Controls("parmMax", 10000.0, variable="0:0:Mustrain;i")


def refine_term(term):
    def configure(gpx):
        gpx.histogram(0).InstrumentParameters[term][2] = True
    return configure


def main():
    fit("wo3_size_cawo4_size.gpx", "sizes_wo3strain.gpx",
        "accepted sizes + WO3 strain", add_wo3_strain)
    fit("sizes_wo3strain.gpx", "profile_x2.gpx", "+ common X", refine_term("X"))
    fit("profile_x2.gpx", "profile_xw2.gpx", "+ common W", refine_term("W"))
    fit("profile_xw2.gpx", "profile_xwu2.gpx", "+ common U", refine_term("U"))


if __name__ == "__main__":
    main()
