#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import argparse
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_hap(phase, hist_name: str) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"][:] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [100.0, 100.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def summarize(gpx, label: str) -> None:
    hist = gpx.histogram(0)
    print(f"\n--- {label} ---")
    print("residuals", json.dumps(hist.residuals, indent=2, default=float))
    print("sample", hist.SampleParameters)
    print("instrument", {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.",
                                  "U", "V", "W", "X", "Y", "Z", "SH/L")})
    print("background", hist.data["Background"][0])
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "mustrain", hap["Mustrain"])
    try:
        print("mass fractions", hist.ComputeMassFracs())
    except Exception as exc:
        print("mass fractions unavailable", repr(exc))
    try:
        shifts, sigmas = gpx.get_LastFitResults()
        print("max shift/sigma", max((abs(v), k) for k, v in shifts.items()))
    except Exception as exc:
        print("fit shifts unavailable", repr(exc))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--tag", default="baseline")
    args = parser.parse_args()
    out = ROOT / ".tmp" / f"{args.tag}.gpx"
    if out.exists():
        out.unlink()
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / ".tmp" / "cu_kalpha.instprm"),
        fmthint="comma/tab/semicolon separated",
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 6,
            "coeffs": [1200.0, -600.0, 300.0, -150.0, 50.0, -20.0],
            "refine": True,
        }
    })
    hist.SampleParameters["Scale"][:] = [1.0, False]
    hist.SampleParameters["Shift"][:] = [-480.0, True]
    hist.SampleParameters["Transparency"][:] = [0.0, False]
    hist.SampleParameters["SurfRoughA"][:] = [0.0, False]
    hist.SampleParameters["SurfRoughB"][:] = [0.0, False]

    phase_specs = [
        ("WO3_monoclinic", args.wo3),
        ("CaCO3_calcite", "1547347"),
        ("CaWO4_scheelite", "7219229"),
    ]
    for name, source in phase_specs:
        source_path = Path(source)
        if not source_path.is_file():
            source_path = cif(source)
        phase = gpx.add_phase(str(source_path), phasename=name, histograms=[hist])
        neutralize_hap(phase, hist.name)

    gpx.set_Controls("cycles", 12)
    gpx.set_Controls("parmMin", 0.0, variable=":0:U")
    gpx.set_Controls("parmMin", 0.0, variable=":0:W")
    gpx.set_Controls("parmMin", 0.0, variable=":0:X")
    gpx.set_Controls("parmMax", 200.0, variable=":0:U")
    gpx.set_Controls("parmMax", 200.0, variable=":0:W")
    gpx.set_Controls("parmMax", 20.0, variable=":0:X")
    gpx.set_Controls("parmMin", -1500.0, variable=":0:Shift")
    gpx.set_Controls("parmMax", 500.0, variable=":0:Shift")
    for i in range(3):
        gpx.set_Controls("parmMin", 0.0, variable=f"{i}:0:Scale")

    gpx.save()
    summarize(gpx, "initial")
    gpx.refine(printFile=str(ROOT / ".tmp" / f"{args.tag}_stage1.lst"))
    summarize(gpx, "background + scales + displacement")

    for phase in gpx.phases():
        phase.set_refinements({"Cell": True})
    gpx.refine(printFile=str(ROOT / ".tmp" / f"{args.tag}_stage2.lst"))
    summarize(gpx, "+ cells")
    gpx.save()


if __name__ == "__main__":
    main()
