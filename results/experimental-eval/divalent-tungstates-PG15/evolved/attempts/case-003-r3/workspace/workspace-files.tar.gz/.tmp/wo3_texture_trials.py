#!/usr/bin/env python3
from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
SOURCE = TMP / "trial_wo3_uniaxial_strain_b.gpx"


def fit(tag, axis):
    target = TMP / f"trial_wo3_md_{tag}.gpx"
    if target.exists(): target.unlink()
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(target))
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    h = gpx.histogram(0)
    hap = gpx.phase("WO3_monoclinic").data["Histograms"][h.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    gpx.set_Controls("parmMin", 0.1, variable="0:0:MD")
    gpx.set_Controls("parmMax", 10.0, variable="0:0:MD")
    for i in range(2):
        gpx.refine(printFile=str(TMP / f"{target.stem}_{i+1}.lst"))
        shifts, sigmas = gpx.get_LastFitResults()
        print("\n", axis, "pass", i+1,
              "R", json.dumps({k:v for k,v in h.residuals.items()
                                if k in ("wR","R","wRb","Rb")}, default=float))
        print("mass", h.ComputeMassFracs(), "PO", hap["Pref.Ori."][:4],
              "sigmaMD", sigmas.get("0:0:MD"))
    gpx.save()


for tag, axis in (("100", (1,0,0)), ("010", (0,1,0)), ("001", (0,0,1)),
                  ("110", (1,1,0)), ("101", (1,0,1)), ("011", (0,1,1))):
    fit(tag, axis)
