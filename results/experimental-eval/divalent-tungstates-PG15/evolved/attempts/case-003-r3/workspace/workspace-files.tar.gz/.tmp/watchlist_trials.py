#!/usr/bin/env python3
from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
SOURCE = TMP / "trial_wo3_strain_mix.gpx"


def cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(phase, hname):
    hap = phase.data["Histograms"][hname]
    hap["Scale"][:] = [0.05, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def fit(tag, name, cod_id):
    target = TMP / f"watch_{tag}.gpx"
    if target.exists(): target.unlink()
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(target))
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    h = gpx.histogram(0)
    phase = gpx.add_phase(str(cif(cod_id)), phasename=name, histograms=[h])
    neutralize(phase, h.name)
    pid = phase.id
    gpx.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
    gpx.set_Controls("parmMax", 100.0, variable=f"{pid}:0:Scale")
    phase.set_refinements({"Cell": False})
    for i in range(2):
        gpx.refine(printFile=str(TMP / f"watch_{tag}_scale_{i+1}.lst"))
        shifts, sigmas = gpx.get_LastFitResults()
        masses = h.ComputeMassFracs()
        print("\n", tag, cod_id, "scale pass", i+1,
              "R", json.dumps({k:v for k,v in h.residuals.items()
                                if k in ("wR","R","wRb","Rb")}, default=float))
        print("candidate", name, "scale", phase.data["Histograms"][h.name]["Scale"],
              "mass", masses.get(name), "sigma", sigmas.get(f"{pid}:0:Scale"),
              "cell", phase.get_cell())
    # Only allow a cell trial after a clearly positive scale-only result.
    mass = h.ComputeMassFracs().get(name, (0.0, 0.0))[0]
    scale = phase.data["Histograms"][h.name]["Scale"][0]
    if mass > 0.001 and scale > 1e-5:
        phase.set_refinements({"Cell": True})
        gpx.refine(printFile=str(TMP / f"watch_{tag}_cell.lst"))
        print(tag, "cell pass", {k:v for k,v in h.residuals.items()
                                 if k in ("wR","R")},
              "candidate", phase.data["Histograms"][h.name]["Scale"],
              h.ComputeMassFracs().get(name), phase.get_cell())
    gpx.save()


for args in (
    ("cao", "watch_CaO", "1563196"),
    ("ca3wo6", "watch_Ca3WO6", "1563081"),
    ("aragonite", "watch_CaCO3_aragonite", "5000085"),
    ("vaterite", "watch_CaCO3_vaterite", "3000000"),
    ("wo3_triclinic", "watch_WO3_triclinic", "2106293"),
    ("wo3_orthorhombic", "watch_WO3_orthorhombic", "2107312"),
):
    fit(*args)
