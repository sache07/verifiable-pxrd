#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"


def report(gpx, label: str) -> None:
    h = gpx.histogram(0)
    print(f"\n=== {label} ===")
    print("R", json.dumps(h.residuals, sort_keys=True, default=float))
    print("mass", h.ComputeMassFracs())
    print("profile", {k: h.InstrumentParameters[k] for k in
                      ("U", "V", "W", "X", "Y", "SH/L")})
    print("shift", h.SampleParameters["Shift"])
    shifts, sigmas = gpx.get_LastFitResults()
    print("last", sorted(((abs(v), k, v, sigmas.get(k)) for k, v in shifts.items()),
                         reverse=True)[:6])


def fit(source: str, target: str, label: str, configure) -> None:
    target_path = TMP / target
    if target_path.exists():
        target_path.unlink()
    gpx = G2sc.G2Project(str(TMP / source), newgpx=str(target_path))
    configure(gpx)
    for repeat in range(2):
        gpx.refine(printFile=str(TMP / f"{target_path.stem}_{repeat + 1}.lst"))
        report(gpx, f"{label} pass {repeat + 1}")
    gpx.save()


def wx(gpx) -> None:
    inst = gpx.histogram(0).InstrumentParameters
    inst["U"][1:] = [0.0, False]
    inst["W"][2] = True
    inst["X"][2] = True


def uwx(gpx) -> None:
    inst = gpx.histogram(0).InstrumentParameters
    inst["U"][1:] = [100.0, True]
    inst["W"][2] = True
    inst["X"][2] = True
    gpx.set_Controls("parmMax", 1000.0, variable=":0:U")


def ux(gpx) -> None:
    inst = gpx.histogram(0).InstrumentParameters
    inst["U"][1:] = [100.0, True]
    inst["W"][1:] = [0.0, False]
    inst["X"][2] = True
    gpx.set_Controls("parmMax", 1000.0, variable=":0:U")


def main() -> None:
    fit("profile_w.gpx", "profile_wx.gpx", "W/X", wx)
    fit("profile_wx.gpx", "profile_uwx_free.gpx", "U/W/X", uwx)
    fit("profile_wx.gpx", "profile_ux.gpx", "U/X", ux)


if __name__ == "__main__":
    main()
