#!/usr/bin/env python3
from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
SOURCE = TMP / "trial_no_wo3_size.gpx"


def fit(name, configure):
    target = TMP / name
    if target.exists(): target.unlink()
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(target))
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    configure(gpx)
    h = gpx.histogram(0)
    for i in range(2):
        gpx.refine(printFile=str(TMP / f"{target.stem}_{i+1}.lst"))
        shifts, sigmas = gpx.get_LastFitResults()
        print("\n", name, "pass", i+1)
        print("R", json.dumps({k:v for k,v in h.residuals.items()
                               if k in ("wR","R","wRb","Rb")}, default=float))
        print("mass", h.ComputeMassFracs())
        for p in gpx.phases():
            hap = p.data["Histograms"][h.name]
            print(p.name, "size", hap["Size"][:4], "strain", hap["Mustrain"][:4])
        print("width esds", {k:v for k,v in sigmas.items()
                             if "Size" in k or "Mustrain" in k})
    gpx.save()


def cawo4_c_size(gpx):
    hap = gpx.phase("CaWO4_scheelite").data["Histograms"][gpx.histogram(0).name]
    value = hap["Size"][1][0]
    hap["Size"][0] = "uniaxial"
    hap["Size"][1][:] = [value, value, 1.0]
    hap["Size"][2][:] = [True, True, False]
    hap["Size"][3] = [0, 0, 1]
    for var in ("2:0:Size;i", "2:0:Size;a"):
        gpx.set_Controls("parmMin", 0.005, variable=var)
        gpx.set_Controls("parmMax", 10.0, variable=var)


def wo3_b_strain(gpx):
    hap = gpx.phase("WO3_monoclinic").data["Histograms"][gpx.histogram(0).name]
    value = hap["Mustrain"][1][0]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][:] = [value, value, 1.0]
    hap["Mustrain"][2][:] = [True, True, False]
    hap["Mustrain"][3] = [0, 1, 0]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    for var in ("0:0:Mustrain;i", "0:0:Mustrain;a"):
        gpx.set_Controls("parmMin", 0.0, variable=var)
        gpx.set_Controls("parmMax", 10000.0, variable=var)


fit("trial_cawo4_uniaxial_size.gpx", cawo4_c_size)
fit("trial_wo3_uniaxial_strain_b.gpx", wo3_b_strain)
