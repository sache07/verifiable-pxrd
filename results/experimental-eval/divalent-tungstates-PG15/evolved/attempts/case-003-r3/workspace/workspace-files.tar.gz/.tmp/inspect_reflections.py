#!/usr/bin/env python3
from pathlib import Path
import sys
from GSASII import GSASIIscriptable as G2sc

gpx = G2sc.G2Project(str(Path(sys.argv[1])))
h = gpx.histogram(0)
rlists = h.data["Reflection Lists"]
print(rlists.keys())
for phase, data in rlists.items():
    print("\n", phase, data.keys())
    print("Type", data.get("Type"), "Super", data.get("Super"))
    refs = data["RefList"]
    print("shape", refs.shape)
    for row in refs[:10]:
        print(row.tolist())
