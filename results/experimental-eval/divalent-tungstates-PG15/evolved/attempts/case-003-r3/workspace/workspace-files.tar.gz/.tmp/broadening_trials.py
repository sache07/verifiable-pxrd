#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"


def neutral_hap(phase, hname: str) -> None:
    hap = phase.data["Histograms"][hname]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][4][:] = [0.0] * len(hap["Mustrain"][4])
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])


def report(gpx, label: str) -> None:
    hist = gpx.histogram(0)
    print(f"\n=== {label} ===")
    print("residuals", json.dumps(hist.residuals, sort_keys=True, default=float))
    print("mass", hist.ComputeMassFracs())
    print("profile", {k: hist.InstrumentParameters[k] for k in
                      ("U", "V", "W", "X", "Y", "SH/L")})
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "size", hap["Size"][:3], "strain", hap["Mustrain"][:3])
    shifts, sigmas = gpx.get_LastFitResults()
    print("last", sorted(((abs(v), k, v, sigmas.get(k)) for k, v in shifts.items()),
                         reverse=True)[:8])


def fit(source: str, target: str, label: str, configure, repeats: int = 2) -> None:
    target_path = TMP / target
    if target_path.exists():
        target_path.unlink()
    gpx = G2sc.G2Project(str(TMP / source), newgpx=str(target_path))
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    configure(gpx)
    for i in range(repeats):
        gpx.refine(printFile=str(TMP / f"{target_path.stem}_{i + 1}.lst"))
        report(gpx, f"{label} pass {i + 1}")
    gpx.save()


def configure_narrow(gpx) -> None:
    h = gpx.histogram(0)
    inst = h.InstrumentParameters
    for key, value in (("U", 10.0), ("V", 0.0), ("W", 2.0),
                       ("X", 5.0), ("Y", 0.0), ("SH/L", 0.002)):
        inst[key][1:] = [value, False]
    for phase in gpx.phases():
        neutral_hap(phase, h.name)


def configure_wo3_size(gpx) -> None:
    phase = gpx.phase("WO3_monoclinic")
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 0.10, "refine": True,
                 "LGmix": {"value": 1.0, "refine": False}}
    })
    gpx.set_Controls("parmMin", 0.005, variable="0:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, variable="0:0:Size;i")


def configure_wo3_strain(gpx) -> None:
    phase = gpx.phase("WO3_monoclinic")
    phase.set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True,
                     "LGmix": {"value": 1.0, "refine": False}}
    })
    hap = phase.data["Histograms"][gpx.histogram(0).name]
    hap["Mustrain"][1][0] = 1000.0
    gpx.set_Controls("parmMin", 0.0, variable="0:0:Mustrain;i")
    gpx.set_Controls("parmMax", 10000.0, variable="0:0:Mustrain;i")


def main() -> None:
    fit("profile_ux.gpx", "narrow_base.gpx", "narrow common baseline",
        configure_narrow, repeats=2)
    fit("narrow_base.gpx", "wo3_size.gpx", "WO3 isotropic size",
        configure_wo3_size, repeats=2)
    fit("narrow_base.gpx", "wo3_strain.gpx", "WO3 isotropic strain",
        configure_wo3_strain, repeats=2)


if __name__ == "__main__":
    main()
