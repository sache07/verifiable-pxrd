#!/usr/bin/env python3
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


array_path = Path(sys.argv[1])
out_path = Path(sys.argv[2])
data = np.load(array_path)
x = data["two_theta"]
obs = data["observed"]
calc = data["calculated"]
bkg = data["background"]
diff = data["difference"]

fig, axes = plt.subplots(3, 1, figsize=(15, 10), constrained_layout=True)
for ax, limits in zip(axes, ((10, 40), (40, 70), (70, 100))):
    mask = (x >= limits[0]) & (x <= limits[1])
    local_max = np.percentile(obs[mask], 99.7)
    offset = -0.23 * local_max
    ax.plot(x[mask], obs[mask], color="black", lw=0.7, label="observed")
    ax.plot(x[mask], calc[mask], color="#d62728", lw=0.8, label="calculated")
    ax.plot(x[mask], bkg[mask], color="#2ca02c", lw=0.7, label="background")
    ax.plot(x[mask], diff[mask] + offset, color="#1f77b4", lw=0.6, label="difference (offset)")
    ax.axhline(offset, color="0.7", lw=0.5)
    ax.set_xlim(*limits)
    ax.set_ylim(offset - 0.1 * local_max, 1.1 * local_max)
    ax.set_ylabel("counts")
axes[0].legend(ncol=4, frameon=False, fontsize=9)
axes[-1].set_xlabel(r"$2\theta$ (degrees)")
fig.savefig(out_path, dpi=180)
