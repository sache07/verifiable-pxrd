#!/usr/bin/env python3
from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
SOURCE = TMP / "trial_cawo4_md_110.gpx"


def fit(name, configure):
    target = TMP / name
    if target.exists(): target.unlink()
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(target))
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    configure(gpx)
    h = gpx.histogram(0)
    for i in range(2):
        gpx.refine(printFile=str(TMP / f"{target.stem}_{i+1}.lst"))
        shifts, sigmas = gpx.get_LastFitResults()
        print("\n", name, "pass", i+1,
              "R", json.dumps({k:v for k,v in h.residuals.items()
                                if k in ("wR","R","wRb","Rb")}, default=float))
        print("mass", h.ComputeMassFracs())
        for p in gpx.phases():
            hap = p.data["Histograms"][h.name]
            print(p.name, "size", hap["Size"][:3], "strain", hap["Mustrain"][:3])
        print("mix esds", {k:v for k,v in sigmas.items() if k.endswith(";mx")})
    gpx.save()


def wo3_strain_mix(gpx):
    hap = gpx.phase("WO3_monoclinic").data["Histograms"][gpx.histogram(0).name]
    hap["Mustrain"][1][2] = 0.8
    hap["Mustrain"][2][2] = True
    gpx.set_Controls("parmMin", 0.0, variable="0:0:Mustrain;mx")
    gpx.set_Controls("parmMax", 1.0, variable="0:0:Mustrain;mx")


def cawo4_size_mix(gpx):
    hap = gpx.phase("CaWO4_scheelite").data["Histograms"][gpx.histogram(0).name]
    hap["Size"][1][2] = 0.8
    hap["Size"][2][2] = True
    gpx.set_Controls("parmMin", 0.0, variable="2:0:Size;mx")
    gpx.set_Controls("parmMax", 1.0, variable="2:0:Size;mx")


fit("trial_wo3_strain_mix.gpx", wo3_strain_mix)
fit("trial_cawo4_size_mix.gpx", cawo4_size_mix)
