#!/usr/bin/env python3
from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
source = TMP / "trial_polar.gpx"
target = TMP / "profile_polar_md104.gpx"
if target.exists():
    target.unlink()

gpx = G2sc.G2Project(str(source), newgpx=str(target))
gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
h = gpx.histogram(0)
hap = gpx.phase("CaCO3_calcite").data["Histograms"][h.name]
hap["Pref.Ori."][0] = "MD"
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = True
hap["Pref.Ori."][3] = [1, 0, 4]
gpx.set_Controls("parmMin", 0.1, variable="1:0:MD")
gpx.set_Controls("parmMax", 10.0, variable="1:0:MD")

for i in range(3):
    gpx.refine(printFile=str(TMP / f"profile_polar_md104_{i + 1}.lst"))
    shifts, sigmas = gpx.get_LastFitResults()
    print(f"pass {i + 1}")
    print("R", json.dumps({k: v for k, v in h.residuals.items()
                           if k in ("wR", "R", "wRb", "Rb")}, default=float))
    print("mass", h.ComputeMassFracs())
    print("Polariz", h.InstrumentParameters["Polariz."],
          "MD", hap["Pref.Ori."][:4])
    print("last", sorted(((abs(v), k, v, sigmas.get(k))
                          for k, v in shifts.items()), reverse=True)[:8])
gpx.save()
