#!/usr/bin/env python3
from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"


def report(gpx, label):
    h = gpx.histogram(0)
    calcite = gpx.phase("CaCO3_calcite").data["Histograms"][h.name]["Pref.Ori."]
    print(f"\n=== {label} ===")
    print("R", json.dumps({k: v for k, v in h.residuals.items()
                           if k in ("wR", "R", "wRb", "Rb")}, default=float))
    print("mass", h.ComputeMassFracs())
    print("Polariz", h.InstrumentParameters["Polariz."],
          "SH/L", h.InstrumentParameters["SH/L"], "calcite PO", calcite[:4])
    shifts, sigmas = gpx.get_LastFitResults()
    print("last", sorted(((abs(v), k, v, sigmas.get(k)) for k, v in shifts.items()),
                         reverse=True)[:5])


def fit(target, label, configure):
    path = TMP / target
    if path.exists():
        path.unlink()
    gpx = G2sc.G2Project(str(TMP / "profile_xw2.gpx"), newgpx=str(path))
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    configure(gpx)
    for i in range(2):
        gpx.refine(printFile=str(TMP / f"{path.stem}_{i + 1}.lst"))
        report(gpx, f"{label} pass {i + 1}")
    gpx.save()


def polar(gpx):
    gpx.histogram(0).InstrumentParameters["Polariz."][2] = True
    gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")


def shl(gpx):
    gpx.histogram(0).InstrumentParameters["SH/L"][2] = True
    gpx.set_Controls("parmMin", 0.002, variable=":0:SH/L")
    gpx.set_Controls("parmMax", 0.1, variable=":0:SH/L")


def calcite_md(axis):
    def configure(gpx):
        hap = gpx.phase("CaCO3_calcite").data["Histograms"][gpx.histogram(0).name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        gpx.set_Controls("parmMin", 0.1, variable="1:0:MD")
        gpx.set_Controls("parmMax", 10.0, variable="1:0:MD")
    return configure


def main():
    fit("trial_polar.gpx", "refined polarization", polar)
    fit("trial_shl.gpx", "refined SH/L asymmetry", shl)
    for tag, axis in (("001", (0, 0, 1)), ("100", (1, 0, 0)),
                      ("104", (1, 0, 4)), ("110", (1, 1, 0))):
        fit(f"trial_calcite_md_{tag}.gpx", f"calcite MD {axis}", calcite_md(axis))


if __name__ == "__main__":
    main()
