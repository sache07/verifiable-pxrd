#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"


def summary(gpx, label: str) -> None:
    hist = gpx.histogram(0)
    print(f"\n=== {label} ===")
    print("residuals", json.dumps(hist.residuals, sort_keys=True, default=float))
    print("mass", hist.ComputeMassFracs())
    print("sample", {k: hist.SampleParameters[k] for k in
                     ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")})
    print("inst", {k: hist.InstrumentParameters[k] for k in
                   ("Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")})
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        print("phase", phase.name, phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"][:3], "strain", hap["Mustrain"][:3],
              "PO", hap["Pref.Ori."][:4])
    shifts, sigmas = gpx.get_LastFitResults()
    ordered = sorted(((abs(value), key, value, sigmas.get(key))
                      for key, value in shifts.items()), reverse=True)
    print("largest last shifts", ordered[:8])


def run(input_name: str, output_name: str, label: str,
        instrument_terms: tuple[str, ...] = (), repeats: int = 1) -> None:
    output = TMP / output_name
    if output.exists():
        output.unlink()
    gpx = G2sc.G2Project(str(TMP / input_name), newgpx=str(output))
    hist = gpx.histogram(0)
    if instrument_terms:
        hist.set_refinements({"Instrument Parameters": list(instrument_terms)})
    for index in range(repeats):
        gpx.refine(printFile=str(TMP / f"{output.stem}_{index + 1}.lst"))
        summary(gpx, f"{label}, pass {index + 1}")
    gpx.save()


def main() -> None:
    run("alt_2311041.gpx", "reconverged.gpx", "baseline replay", repeats=3)
    run("reconverged.gpx", "profile_w.gpx", "+ W", ("W",), repeats=2)
    run("profile_w.gpx", "profile_uw.gpx", "+ U", ("U",), repeats=2)
    run("profile_uw.gpx", "profile_uwx.gpx", "+ X", ("X",), repeats=2)


if __name__ == "__main__":
    main()
