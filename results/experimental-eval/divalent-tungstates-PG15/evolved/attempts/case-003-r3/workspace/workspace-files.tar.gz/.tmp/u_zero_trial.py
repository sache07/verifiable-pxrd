#!/usr/bin/env python3
from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT=Path(__file__).resolve().parents[1];TMP=ROOT/".tmp"
target=TMP/"trial_final_u0.gpx"
if target.exists():target.unlink()
gpx=G2sc.G2Project(str(TMP/"sixphase_stable.gpx"),newgpx=str(target))
gpx.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}
h=gpx.histogram(0);h.InstrumentParameters["U"][1:]=[0.0,False]
for i in range(2):
    gpx.refine(printFile=str(TMP/f"trial_final_u0_{i+1}.lst"))
    print("pass",i+1,"R",json.dumps({k:v for k,v in h.residuals.items()
                                      if k in ("wR","R","wRb","Rb")},default=float),
          "profile",{k:h.InstrumentParameters[k] for k in ("U","W","X")},
          "mass",h.ComputeMassFracs())
gpx.save()
