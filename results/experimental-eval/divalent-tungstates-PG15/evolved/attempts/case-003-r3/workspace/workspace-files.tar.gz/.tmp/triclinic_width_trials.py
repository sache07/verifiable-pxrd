#!/usr/bin/env python3
from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT=Path(__file__).resolve().parents[1]
TMP=ROOT/".tmp"
SOURCE=TMP/"sixphase_stable.gpx"

def fit(mode):
    target=TMP/f"trial_triclinic_{mode}.gpx"
    if target.exists():target.unlink()
    gpx=G2sc.G2Project(str(SOURCE),newgpx=str(target))
    gpx.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}
    h=gpx.histogram(0);p=gpx.phase(5);hap=p.data["Histograms"][h.name]
    if mode=="size":
        hap["Size"][0]="isotropic";hap["Size"][1][:]=[0.1,10.,1.]
        hap["Size"][2][:]=[True,False,False];var="5:0:Size;i"
        gpx.set_Controls("parmMin",0.005,variable=var);gpx.set_Controls("parmMax",10.,variable=var)
    else:
        hap["Mustrain"][0]="isotropic";hap["Mustrain"][1][:]=[1000.,0.,1.]
        hap["Mustrain"][2][:]=[True,False,False];var="5:0:Mustrain;i"
        gpx.set_Controls("parmMin",0.,variable=var);gpx.set_Controls("parmMax",10000.,variable=var)
    for i in range(2):
        gpx.refine(printFile=str(TMP/f"trial_triclinic_{mode}_{i+1}.lst"))
        shifts,sigmas=gpx.get_LastFitResults()
        print("\n",mode,"pass",i+1,"R",json.dumps({k:v for k,v in h.residuals.items()
             if k in ("wR","R","wRb","Rb")},default=float),"mass",h.ComputeMassFracs(),
             "size",hap["Size"][:3],"strain",hap["Mustrain"][:3],"sigma",sigmas.get(var))
    gpx.save()

fit("size")
fit("strain")
