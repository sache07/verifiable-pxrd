#!/usr/bin/env python3
from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
source = TMP / "rechallenge_wo3_triclinic.gpx"
target = TMP / "sixphase_base.gpx"
if target.exists(): target.unlink()
gpx = G2sc.G2Project(str(source), newgpx=str(target))
gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
h = gpx.histogram(0)
for i in range(3):
    gpx.refine(printFile=str(TMP / f"sixphase_base_{i+1}.lst"))
    shifts, sigmas = gpx.get_LastFitResults()
    print("\npass", i+1, "R", json.dumps({k:v for k,v in h.residuals.items()
                                           if k in ("wR","R","wRb","Rb")}, default=float))
    print("mass", h.ComputeMassFracs())
    print("profile", {k:h.InstrumentParameters[k] for k in
                       ("U","W","X","SH/L","Polariz.")}, "shift",h.SampleParameters["Shift"])
    for p in gpx.phases():
        hap=p.data["Histograms"][h.name]
        print(p.id,p.name,"cell",p.get_cell(),"scale",hap["Scale"],
              "size",hap["Size"][:3],"strain",hap["Mustrain"][:3])
    print("max",sorted(((abs(v),k,v,sigmas.get(k)) for k,v in shifts.items()),reverse=True)[:8])
gpx.save()
