#!/usr/bin/env python3
from pathlib import Path
import csv
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
SOURCE = TMP / "trial_final_u.gpx"
FINAL = ROOT / "final.gpx"

OLD_NAME = "watch_WO3_triclinic"
NEW_NAME = "WO3_triclinic"


def rename_triclinic(gpx):
    phases = gpx.data["Phases"]
    if OLD_NAME not in phases:
        return
    pdata = phases.pop(OLD_NAME)
    pdata["General"]["Name"] = NEW_NAME
    phases[NEW_NAME] = pdata
    for entry in gpx.names:
        if entry and entry[0] == "Phases":
            entry[:] = [NEW_NAME if item == OLD_NAME else item for item in entry]
    for hist in gpx.histograms("PWDR"):
        rlists = hist.data.get("Reflection Lists", {})
        if OLD_NAME in rlists:
            rlists[NEW_NAME] = rlists.pop(OLD_NAME)


if FINAL.exists():
    FINAL.unlink()
gpx = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
rename_triclinic(gpx)
gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
gpx.save()

# Required save/reopen/replay checks. The second replay is the submitted state.
for replay in (1, 2):
    gpx = G2sc.G2Project(str(FINAL))
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    gpx.refine(printFile=str(TMP / f"final_replay_{replay}.lst"))
    gpx.save()
    hist = gpx.histogram(0)
    shifts, sigmas = gpx.get_LastFitResults()
    max_ratio = max((abs(value) / sigmas[key] for key, value in shifts.items()
                     if key in sigmas and sigmas[key]), default=0.0)
    print("replay", replay, "R", {k: hist.residuals[k] for k in
                                   ("wR", "R", "wRb", "Rb", "wRmin")},
          "mass", hist.ComputeMassFracs(), "max_shift_over_esd", max_ratio)

gpx = G2sc.G2Project(str(FINAL))
hist = gpx.histogram(0)

specs = [
    ("WO3_monoclinic", "monoclinic WO3", "WO3", "P 21/c", 14,
     "phase_1_WO3_monoclinic.cif", "COD 2311041"),
    ("CaCO3_calcite", "calcite", "CaCO3", "R -3 c", 167,
     "phase_2_CaCO3_calcite.cif", "COD 1547347"),
    ("CaWO4_scheelite", "scheelite CaWO4", "CaWO4", "I 41/a", 88,
     "phase_3_CaWO4_scheelite.cif", "COD 7219229"),
    ("WO3_orthorhombic", "orthorhombic WO3", "WO3", "P n m a", 62,
     "phase_4_WO3_orthorhombic.cif", "COD 2107312"),
    ("CaO", "calcium oxide", "CaO", "F m -3 m", 225,
     "phase_5_CaO.cif", "COD 1563196"),
    ("WO3_triclinic", "triclinic WO3", "WO3", "P -1", 2,
     "phase_6_WO3_triclinic.cif", "COD 2106293"),
]

mass = hist.ComputeMassFracs()
phase_records = []
for project_name, display_name, formula, sg, sgnum, filename, source in specs:
    phase = gpx.phase(project_name)
    phase.export_CIF(str(ROOT / filename))
    frac, esd = mass[project_name]
    phase_records.append({
        "name": display_name,
        "formula": formula,
        "space_group": sg,
        "space_group_number": sgnum,
        "cif_path": filename,
        "weight_fraction": float(frac),
        "weight_fraction_esd_formal": float(esd),
        "source_structure": source,
    })
    print(project_name, "cell", phase.get_cell(), "fraction", frac, esd)

# Export exactly the points evaluated by GSAS-II. Its upper-limit indexing
# includes the first grid point above the nominal 100 degree limit.
x, obs, weight, calc, background, difference = hist.data["data"][1]
lo, hi = hist.data["Limits"][1]
mask = np.asarray(calc) != 0.0
with (ROOT / "fit.csv").open("w", newline="") as fp:
    writer = csv.writer(fp)
    writer.writerow(["two_theta_deg", "observed_intensity", "calculated_intensity",
                     "difference_intensity", "background_intensity"])
    for values in zip(np.asarray(x)[mask], np.asarray(obs)[mask], np.asarray(calc)[mask],
                      np.asarray(difference)[mask], np.asarray(background)[mask]):
        writer.writerow([f"{values[0]:.8f}", *(f"{v:.8f}" for v in values[1:])])

rvals = gpx.data["Covariance"]["data"]["Rvals"]
resid = hist.residuals
result = {
    "phases": phase_records,
    "weight_fraction_basis": "normalized over the modeled crystalline phases",
    "fit_statistics": {
        "r_wp_percent": float(resid["wR"]),
        "r_p_percent": float(resid["R"]),
        "r_exp_percent": float(resid["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "n_observations": int(rvals["Nobs"]),
        "n_refined_parameters": int(rvals["Nvars"]),
        "two_theta_range_deg": [float(lo), float(hi)],
        "weighting": "Poisson approximation, w = 1 / observed counts",
    },
}
with (ROOT / "result.json").open("w") as fp:
    json.dump(result, fp, indent=2)
    fp.write("\n")

print(json.dumps(result, indent=2))
