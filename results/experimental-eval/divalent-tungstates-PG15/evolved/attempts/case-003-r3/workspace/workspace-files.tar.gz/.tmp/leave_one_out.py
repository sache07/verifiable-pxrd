#!/usr/bin/env python3
from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT=Path(__file__).resolve().parents[1]
TMP=ROOT/".tmp"
SOURCE=TMP/"sixphase_stable.gpx"

for tag,pid in (("cao",4),("ortho",3),("triclinic",5)):
    target=TMP/f"leaveout_{tag}.gpx"
    if target.exists():target.unlink()
    gpx=G2sc.G2Project(str(SOURCE),newgpx=str(target))
    gpx.data["Controls"]["data"]["parmFrozen"]={"FrozenList":[]}
    h=gpx.histogram(0);p=gpx.phase(pid);hap=p.data["Histograms"][h.name]
    hap["Scale"][:]=[0.0,False]
    for i in range(2):
        gpx.refine(printFile=str(TMP/f"leaveout_{tag}_{i+1}.lst"))
        print("\n",tag,"pass",i+1,"R",json.dumps({k:v for k,v in h.residuals.items()
              if k in ("wR","R","wRb","Rb")},default=float),"mass",h.ComputeMassFracs())
    gpx.save()
