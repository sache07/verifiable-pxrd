#!/usr/bin/env python3
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2sc


gpx = G2sc.G2Project(str(Path(sys.argv[1])))
x, obs, weight, calc, bkg, diff = gpx.histogram(0).data["data"][1]
np.savez_compressed(
    Path(sys.argv[2]),
    two_theta=np.asarray(x),
    observed=np.asarray(obs),
    calculated=np.asarray(calc),
    background=np.asarray(bkg),
    difference=np.asarray(diff),
)
