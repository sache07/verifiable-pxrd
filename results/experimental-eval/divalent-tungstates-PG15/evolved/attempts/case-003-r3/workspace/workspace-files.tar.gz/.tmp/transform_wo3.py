#!/usr/bin/env python3
"""Put COD 2311041 into a short, near-orthogonal P21/c setting."""
from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


root = Path(__file__).resolve().parents[1]
source = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/2/31/10/2311041.cif")
structure = Structure.from_file(source)
transform = np.array([[1, 0, 1], [0, 1, 0], [-1, 0, 0]])
lattice = Lattice(transform @ structure.lattice.matrix)
transformed = Structure(
    lattice,
    [site.species for site in structure],
    structure.cart_coords,
    coords_are_cartesian=True,
    to_unit_cell=True,
)
CifWriter(transformed, symprec=0.01, angle_tolerance=1).write_file(
    root / ".tmp" / "wo3_2311041_short.cif"
)
