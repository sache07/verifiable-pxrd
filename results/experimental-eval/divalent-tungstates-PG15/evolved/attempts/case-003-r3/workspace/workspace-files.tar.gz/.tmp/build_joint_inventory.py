#!/usr/bin/env python3
from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
SOURCE = TMP / "trial_wo3_strain_mix.gpx"
TARGET = TMP / "joint_inventory.gpx"


def cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize(phase, hname):
    hap = phase.data["Histograms"][hname]
    hap["Scale"][:] = [0.05, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["HStrain"][0][:] = [0.0] * len(hap["HStrain"][0])
    hap["HStrain"][1][:] = [False] * len(hap["HStrain"][1])
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def report(gpx, label):
    h = gpx.histogram(0)
    print("\n", label, "R", json.dumps({k:v for k,v in h.residuals.items()
                                         if k in ("wR","R","wRb","Rb")}, default=float))
    print("mass", h.ComputeMassFracs())
    print("profile", {k:h.InstrumentParameters[k] for k in
                       ("U","W","X","SH/L","Polariz.")},
          "shift", h.SampleParameters["Shift"])
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        print(p.id, p.name, "scale", hap["Scale"], "cell", p.get_cell(),
              "size", hap["Size"][:3], "strain", hap["Mustrain"][:3])
    shifts, sigmas = gpx.get_LastFitResults()
    print("max shifts", sorted(((abs(v),k,v,sigmas.get(k)) for k,v in shifts.items()),
                               reverse=True)[:8])


if TARGET.exists(): TARGET.unlink()
gpx = G2sc.G2Project(str(SOURCE), newgpx=str(TARGET))
gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
h = gpx.histogram(0)
ortho = gpx.add_phase(str(cif("2107312")), phasename="WO3_orthorhombic", histograms=[h])
cao = gpx.add_phase(str(cif("1563196")), phasename="CaO", histograms=[h])
for p in (ortho, cao):
    neutralize(p, h.name)
    p.set_refinements({"Cell": False})
    gpx.set_Controls("parmMin", 0.0, variable=f"{p.id}:0:Scale")
    gpx.set_Controls("parmMax", 100.0, variable=f"{p.id}:0:Scale")

for i in range(2):
    gpx.refine(printFile=str(TMP / f"joint_inventory_scales_{i+1}.lst"))
    report(gpx, f"joint scales pass {i+1}")

ortho.set_refinements({"Cell": True})
cao.set_refinements({"Cell": True})
for i in range(3):
    gpx.refine(printFile=str(TMP / f"joint_inventory_cells_{i+1}.lst"))
    report(gpx, f"joint cells/common profile pass {i+1}")
gpx.save()
