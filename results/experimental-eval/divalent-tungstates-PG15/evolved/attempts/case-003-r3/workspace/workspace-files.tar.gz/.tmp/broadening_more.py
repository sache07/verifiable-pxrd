#!/usr/bin/env python3
from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"


def report(gpx, label):
    h = gpx.histogram(0)
    print(f"\n=== {label} ===")
    print("residuals", json.dumps(h.residuals, sort_keys=True, default=float))
    print("mass", h.ComputeMassFracs())
    print("profile", {k: h.InstrumentParameters[k] for k in ("U", "W", "X", "SH/L")})
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        print(p.name, "size", hap["Size"][:3], "strain", hap["Mustrain"][:3])
    shifts, sigmas = gpx.get_LastFitResults()
    print("last", sorted(((abs(v), k, v, sigmas.get(k)) for k, v in shifts.items()),
                         reverse=True)[:7])


def fit(target, label, configure):
    path = TMP / target
    if path.exists():
        path.unlink()
    gpx = G2sc.G2Project(str(TMP / "wo3_size.gpx"), newgpx=str(path))
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    configure(gpx)
    for i in range(2):
        gpx.refine(printFile=str(TMP / f"{path.stem}_{i + 1}.lst"))
        report(gpx, f"{label} pass {i + 1}")
    gpx.save()


def set_iso_size(gpx, phase_name, phase_id, value):
    p = gpx.phase(phase_name)
    p.set_HAP_refinements({"Size": {"type": "isotropic", "value": value,
                                    "refine": True,
                                    "LGmix": {"value": 1.0, "refine": False}}})
    gpx.set_Controls("parmMin", 0.005, variable=f"{phase_id}:0:Size;i")
    gpx.set_Controls("parmMax", 10.0, variable=f"{phase_id}:0:Size;i")


def set_iso_strain(gpx, phase_name, phase_id, value):
    p = gpx.phase(phase_name)
    p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True,
                                        "LGmix": {"value": 1.0, "refine": False}}})
    p.data["Histograms"][gpx.histogram(0).name]["Mustrain"][1][0] = value
    gpx.set_Controls("parmMin", 0.0, variable=f"{phase_id}:0:Mustrain;i")
    gpx.set_Controls("parmMax", 10000.0, variable=f"{phase_id}:0:Mustrain;i")


def main():
    fit("wo3_size_cawo4_size.gpx", "+ CaWO4 isotropic size",
        lambda g: set_iso_size(g, "CaWO4_scheelite", 2, 0.05))
    fit("wo3_size_cawo4_strain.gpx", "+ CaWO4 isotropic strain",
        lambda g: set_iso_strain(g, "CaWO4_scheelite", 2, 3000.0))
    fit("wo3_size_strain.gpx", "+ WO3 isotropic strain with size",
        lambda g: set_iso_strain(g, "WO3_monoclinic", 0, 1000.0))


if __name__ == "__main__":
    main()
