#!/usr/bin/env python3
from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
SOURCE = TMP / "profile_polar_md104.gpx"


def fit(name, configure):
    target = TMP / name
    if target.exists(): target.unlink()
    gpx = G2sc.G2Project(str(SOURCE), newgpx=str(target))
    gpx.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    configure(gpx)
    h = gpx.histogram(0)
    for i in range(2):
        gpx.refine(printFile=str(TMP / f"{target.stem}_{i+1}.lst"))
        print("\n", name, "pass", i+1)
        print("R", json.dumps({k:v for k,v in h.residuals.items()
                               if k in ("wR","R","wRb","Rb")}, default=float))
        print("mass", h.ComputeMassFracs())
        for p in gpx.phases():
            hap = p.data["Histograms"][h.name]
            print(p.name, "size", hap["Size"][:3], "strain", hap["Mustrain"][:3])
    gpx.save()


def no_wo3_size(gpx):
    hap = gpx.phase("WO3_monoclinic").data["Histograms"][gpx.histogram(0).name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]


def no_wo3_strain(gpx):
    hap = gpx.phase("WO3_monoclinic").data["Histograms"][gpx.histogram(0).name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])


def no_wo3_both(gpx):
    no_wo3_size(gpx)
    no_wo3_strain(gpx)


fit("trial_no_wo3_size.gpx", no_wo3_size)
fit("trial_no_wo3_strain.gpx", no_wo3_strain)
fit("trial_no_wo3_broadening.gpx", no_wo3_both)
