#!/usr/bin/env python3
"""Rebuild and test BaO2 broadening after the peroxide geometry change."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument(
        "--mode", choices=("neutral", "isotropic-size", "equatorial-size", "axial-size", "isotropic-strain", "equatorial-size-strain"), required=True
    )
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    project.set_Controls("cycles", 10)
    project.data["Controls"].setdefault("parmFrozen", {})["FrozenList"] = []
    hist = project.histogram(0)
    hist.Background[0][1] = True
    inst = hist.InstrumentParameters
    inst["W"][1:3] = [0.0, False]
    for key in ("Zero", "Polariz.", "U", "X"):
        inst[key][2] = True

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        if phase.name != "BaO2":
            continue
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:3] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False, False, False]
        hap["Size"][3] = [0, 0, 1]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]

    phase = project.phase("BaO2")
    hap = phase.getHAPvalues(hist)
    bounds = []
    if args.mode == "isotropic-size":
        hap["Size"][1][0] = 0.2
        hap["Size"][2][0] = True
        bounds.append((f"{phase.id}:0:Size;i", 0.005, 1000.0))
    elif args.mode in ("equatorial-size", "axial-size", "equatorial-size-strain"):
        hap["Size"][0] = "uniaxial"
        if args.mode in ("equatorial-size", "equatorial-size-strain"):
            hap["Size"][1][:2] = [0.2, 10.0]
            hap["Size"][2][:2] = [True, False]
            bounds.append((f"{phase.id}:0:Size;i", 0.005, 1000.0))
        else:
            hap["Size"][1][:2] = [10.0, 0.2]
            hap["Size"][2][:2] = [False, True]
            bounds.append((f"{phase.id}:0:Size;a", 0.005, 1000.0))
    elif args.mode == "isotropic-strain":
        hap["Mustrain"][1][0] = 200.0
        hap["Mustrain"][2][0] = True
        bounds.append((f"{phase.id}:0:Mustrain;i", 0.0, 100000.0))
    if args.mode == "equatorial-size-strain":
        hap["Mustrain"][1][0] = 200.0
        hap["Mustrain"][2][0] = True
        bounds.append((f"{phase.id}:0:Mustrain;i", 0.0, 100000.0))

    project.save()
    for variable, lower, upper in bounds:
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    for variable, upper in ((":0:U", 2000.0), (":0:X", 200.0)):
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    for p in project.phases():
        project.set_Controls("parmMin", 0.0, variable=f"{p.id}:0:Scale")

    log = []
    for label in ("fit", "reopen_replay", "second_replay"):
        project.do_refinements([{}])
        project.save()
        hist = project.histogram(0)
        hap = project.phase("BaO2").getHAPvalues(hist)
        log.append(
            {
                "step": label,
                "wR": hist.get_wR(),
                "size": hap["Size"],
                "strain": hap["Mustrain"],
                "fractions": hist.ComputeMassFracs(),
                "instrument": {key: inst[key][1] for key in ("Zero", "Polariz.", "U", "W", "X")},
            }
        )
        project = G2sc.G2Project(str(args.out))
        hist = project.histogram(0)
        inst = hist.InstrumentParameters

    print(json.dumps({"mode": args.mode, "log": log}, indent=2))


if __name__ == "__main__":
    main()
