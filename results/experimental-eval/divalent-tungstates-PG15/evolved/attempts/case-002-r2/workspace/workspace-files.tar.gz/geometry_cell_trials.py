#!/usr/bin/env python3
"""Targeted final-model trials for weak-phase cell and BaO2 peroxide geometry."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def snapshot(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    return {
        "wR": hist.get_wR(),
        "mass_fractions": hist.ComputeMassFracs(),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "atoms": {
            phase.name: {
                atom.label: {
                    "coordinates": atom.coordinates,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            }
            for phase in project.phases()
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--bao-cell", action="store_true")
    parser.add_argument("--bao2-z", choices=("refine", "peroxide"))
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)

    # Keep the accepted model active while changing only the target quantity.
    for phase in project.phases():
        phase.set_refinements({"Cell": phase.name != "BaO" or args.bao_cell})
        phase.getHAPvalues(hist)["Scale"][1] = True
        for atom in phase.atoms():
            atom.refinement_flags = ""

    if args.bao2_z:
        oxygen = project.phase("BaO2").atom("O1")
        if args.bao2_z == "peroxide":
            c = project.phase("BaO2").get_cell()["length_c"]
            z = 0.5 - 1.49 / (2.0 * c)
            oxygen.coordinates = (0.0, 0.0, z)
        else:
            oxygen.refinement_flags = "X"

    # Clear stale entries for parameters that have been deliberately pruned.
    project.data["Controls"].setdefault("parmFrozen", {})["FrozenList"] = []
    project.save()

    log = [dict(step="start", **snapshot(project))]
    for label in ("fit", "reopen_replay"):
        project.do_refinements([{}])
        project.save()
        log.append(dict(step=label, **snapshot(project)))
        project = G2sc.G2Project(str(args.out))

    print(json.dumps(log, indent=2))


if __name__ == "__main__":
    main()
