#!/usr/bin/env python3
"""Measure where a weak candidate contributes with all nuisance terms frozen."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def freeze(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Extinction"][1] = False
        for value in hap["Babinet"].values():
            value[1] = False
    project.data["Controls"].setdefault("parmFrozen", {})["FrozenList"] = []


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--candidate", required=True)
    parser.add_argument("--zero-project", type=Path, required=True)
    args = parser.parse_args()

    full = G2sc.G2Project(str(args.project))
    zero = G2sc.G2Project(str(args.project), newgpx=str(args.zero_project))
    freeze(zero)
    hist0 = zero.histogram(0)
    zero.phase(args.candidate).getHAPvalues(hist0)["Scale"][0] = 0.0
    zero.save()
    zero.do_refinements([{}])
    zero.save()

    a = np.asarray(full.histogram(0).data["data"][1], dtype=float)
    b = np.asarray(zero.histogram(0).data["data"][1], dtype=float)
    x, obs, weight, calc_full = a[0], a[1], a[2], a[3]
    calc_zero = b[3]
    contribution = calc_full - calc_zero
    before = obs - calc_zero
    after = obs - calc_full
    point_gain = weight * (before * before - after * after)

    # Local maxima in the candidate-only profile, separated by 0.12 degrees.
    maxima = np.flatnonzero(
        (contribution[1:-1] > contribution[:-2])
        & (contribution[1:-1] >= contribution[2:])
        & (contribution[1:-1] > max(0.5, 0.02 * contribution.max()))
    ) + 1
    order = maxima[np.argsort(contribution[maxima])[::-1]]
    picked = []
    for idx in order:
        if all(abs(x[idx] - item["two_theta"]) > 0.12 for item in picked):
            mask = np.abs(x - x[idx]) <= 0.16
            picked.append(
                {
                    "two_theta": float(x[idx]),
                    "candidate_peak_height": float(contribution[idx]),
                    "local_chi2_gain": float(point_gain[mask].sum()),
                    "residual_before_at_peak": float(before[idx]),
                    "residual_after_at_peak": float(after[idx]),
                }
            )
        if len(picked) == 15:
            break

    print(
        json.dumps(
            {
                "candidate": args.candidate,
                "weight_fraction": full.histogram(0).ComputeMassFracs()[args.candidate],
                "Rwp_full": full.histogram(0).get_wR(),
                "candidate_fixed_nuisance_chi2_gain": float(point_gain.sum()),
                "candidate_profile_max": float(contribution.max()),
                "peaks": picked,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
