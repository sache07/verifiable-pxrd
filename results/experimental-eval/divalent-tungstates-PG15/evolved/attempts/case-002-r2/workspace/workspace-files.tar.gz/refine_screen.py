#!/usr/bin/env python3
"""Screen candidate structures against the measured PXRD pattern with GSAS-II."""

from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def sane(value: float) -> bool:
    return value is not None and math.isfinite(float(value))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase", nargs=2, action="append", metavar=("NAME", "CIF"), required=True)
    parser.add_argument("--cycles", type=int, default=6)
    args = parser.parse_args()

    root = Path.cwd()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(args.out))
    hist = project.add_powder_histogram(
        str(root / "inputs" / "pattern.csv"),
        str(root / "instrument.instprm"),
        fmthint="comma/tab/semicolon separated",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    sample = hist.SampleParameters
    sample["Scale"][:] = [1.0, False]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB", "DisplaceX", "DisplaceY", "Absorption"):
        if key in sample and isinstance(sample[key], list):
            sample[key][0] = 0.0
            sample[key][1] = False

    phases = []
    for name, cif in args.phase:
        phases.append(
            project.add_phase(
                cif,
                phasename=name,
                histograms=[hist],
                fmthint="CIF",
            )
        )

    project.set_Controls("cycles", args.cycles)
    project.save()
    for variable, upper in ((":0:U", 2000.0), (":0:W", 2000.0), (":0:X", 200.0)):
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    for phase in phases:
        variable = f"{phase.id}:0:Scale"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 1000.0, variable=variable)

    # Smooth low-order baseline; all phase-specific nuisance terms start neutral.
    hist.Background[0][:] = ["chebyschev-1", False, 6, 600.0, -350.0, 140.0, -45.0, 12.0, -2.0]
    for phase in phases:
        hap = phase.getHAPvalues(hist)
        hap["Scale"][:] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"][:] = [0.0, False]
        hap["Babinet"]["BabA"][:] = [0.0, False]
        hap["Babinet"]["BabU"][:] = [0.0, False]

    inst = hist.InstrumentParameters
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Zero", "Polariz.", "I(L2)/I(L1)"):
        if key in inst and len(inst[key]) > 2:
            inst[key][2] = False
    inst["U"][1] = 10.0
    inst["V"][1] = 0.0
    inst["W"][1] = 10.0
    inst["X"][1] = 0.1
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002

    log = []

    def run(label: str) -> None:
        project.save()
        project.do_refinements([{}])
        project.save()
        scales = {p.name: p.getHAPvalues(hist)["Scale"][0] for p in phases}
        cells = {p.name: p.get_cell() for p in phases}
        log.append(
            {
                "step": label,
                "wR": hist.get_wR(),
                "residuals": hist.residuals,
                "scales": scales,
                "cells": cells,
                "instrument": {k: inst[k][1] for k in inst if isinstance(inst[k], list) and len(inst[k]) > 1},
            }
        )

    # Start with baseline and all scales. Then one angular correction and cells.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    run("background_scales")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run("zero")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    run("cells")

    # Common nonnegative low-dimensional profile; V, Y and Z stay neutral/fixed.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    run("common_UWX")

    # Replay after serialization/reopen.
    project.save()
    project = G2sc.G2Project(str(args.out))
    hist = project.histogram(0)
    phases = project.phases()
    inst = hist.InstrumentParameters
    project.do_refinements([{}])
    project.save()
    log.append(
        {
            "step": "reopen_replay",
            "wR": hist.get_wR(),
            "residuals": hist.residuals,
            "scales": {p.name: p.getHAPvalues(hist)["Scale"][0] for p in phases},
            "cells": {p.name: p.get_cell() for p in phases},
            "instrument": {k: inst[k][1] for k in inst if isinstance(inst[k], list) and len(inst[k]) > 1},
        }
    )

    summary = {
        "project": str(args.out),
        "phases": [p.name for p in phases],
        "log": log,
    }
    print(json.dumps(summary, indent=2, default=float))


if __name__ == "__main__":
    main()
