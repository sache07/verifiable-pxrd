#!/usr/bin/env python3
"""Trial one phase-specific size or microstrain term from a neutral baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--kind", choices=("size", "strain"), required=True)
    parser.add_argument("--start", type=float)
    parser.add_argument("--preserve-profile", action="store_true")
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    inst["W"][1] = 0.0
    inst["W"][2] = False
    for key in ("U", "X", "Zero"):
        inst[key][2] = True
    hist.Background[0][1] = True

    selected = project.phase(args.phase)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        if not args.preserve_profile:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1000.0
            hap["Size"][2] = [False for _ in hap["Size"][2]]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    hap = selected.getHAPvalues(hist)
    if args.kind == "size":
        hap["Size"][1][0] = 1.0 if args.start is None else args.start
        hap["Size"][2][0] = True
        variable = f"{selected.id}:0:Size;i"
        lower, upper = 0.005, 1000.0
    else:
        hap["Mustrain"][1][0] = 100.0 if args.start is None else args.start
        hap["Mustrain"][2][0] = True
        variable = f"{selected.id}:0:Mustrain;i"
        lower, upper = 0.0, 100000.0

    project.save()
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)
    for key, upper in ((":0:U", 2000.0), (":0:X", 200.0)):
        project.set_Controls("parmMin", 0.0, variable=key)
        project.set_Controls("parmMax", upper, variable=key)
    for phase in project.phases():
        key = f"{phase.id}:0:Scale"
        project.set_Controls("parmMin", 0.0, variable=key)
        project.set_Controls("parmMax", 1000.0, variable=key)

    log = []
    for label in ("fit", "reopen_replay", "second_replay"):
        project.do_refinements([{}])
        project.save()
        sel = project.phase(args.phase).getHAPvalues(project.histogram(0))
        log.append(
            {
                "step": label,
                "wR": project.histogram(0).get_wR(),
                "instrument": {k: project.histogram(0).InstrumentParameters[k][1] for k in ("Zero", "U", "W", "X")},
                "size": sel["Size"],
                "mustrain": sel["Mustrain"],
                "mass_fractions": project.histogram(0).ComputeMassFracs(),
            }
        )
        project = G2sc.G2Project(str(args.out))

    print(json.dumps({"phase": args.phase, "kind": args.kind, "log": log}, indent=2))


if __name__ == "__main__":
    main()
