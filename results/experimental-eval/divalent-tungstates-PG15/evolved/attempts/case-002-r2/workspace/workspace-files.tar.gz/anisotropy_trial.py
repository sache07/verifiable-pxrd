#!/usr/bin/env python3
"""Test symmetry-appropriate uniaxial size broadening for tetragonal BaO2."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    inst["W"][1] = 0.0
    inst["W"][2] = False
    for key in ("U", "X", "Zero"):
        inst[key][2] = True
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.getHAPvalues(hist)["Scale"][1] = True

    phase = project.phase("BaO2")
    size = phase.getHAPvalues(hist)["Size"]
    start = float(size[1][0])
    size[0] = "uniaxial"
    size[1][0] = start
    size[1][1] = start
    size[2] = [True, True, False]
    size[3] = [0, 0, 1]

    project.save()
    for suffix in ("i", "a"):
        variable = f"{phase.id}:0:Size;{suffix}"
        project.set_Controls("parmMin", 0.005, variable=variable)
        project.set_Controls("parmMax", 1000.0, variable=variable)
    for variable, upper in ((":0:U", 2000.0), (":0:X", 200.0)):
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    log = []
    for label in ("fit", "reopen_replay", "second_replay"):
        project.do_refinements([{}])
        project.save()
        hist = project.histogram(0)
        log.append(
            {
                "step": label,
                "wR": hist.get_wR(),
                "size": project.phase("BaO2").getHAPvalues(hist)["Size"],
                "instrument": {k: hist.InstrumentParameters[k][1] for k in ("Zero", "U", "W", "X")},
                "mass_fractions": hist.ComputeMassFracs(),
            }
        )
        project = G2sc.G2Project(str(args.out))
    print(json.dumps({"log": log}, indent=2))


if __name__ == "__main__":
    main()
