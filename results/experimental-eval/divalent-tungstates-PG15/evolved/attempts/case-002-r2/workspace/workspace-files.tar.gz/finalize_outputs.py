#!/usr/bin/env python3
"""Create the exact final GSAS-II project and all machine-readable exports."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


BASE = Path(".tmp/final_chall_ba3w2o9.gpx")
FINAL = Path("final.gpx")

PHASE_EXPORTS = {
    "WO3": Path("phase_1_WO3.cif"),
    "BaO2": Path("phase_2_BaO2.cif"),
    "BaO": Path("phase_3_BaO.cif"),
    "Ba3W2O9": Path("phase_4_Ba3W2O9.cif"),
}

SOURCES = {
    "WO3": "COD 2106293",
    "BaO2": "COD 1010113; peroxide O position constrained in this refinement",
    "BaO": "COD 1011362",
    "Ba3W2O9": "COD 1533878",
}


def configure(project: G2sc.G2Project) -> None:
    """Make the accepted, pruned refinement model explicit."""
    hist = project.histogram(0)
    data = np.asarray(hist.data["data"][1])
    hist.Limits("lower", float(data[0, 0]))
    hist.Limits("upper", float(data[0, -1]))

    hist.Background[0][0] = "chebyschev-1"
    hist.Background[0][1] = True
    hist.Background[0][2] = 6
    hist.Background[1]["nDebye"] = 0
    hist.Background[1]["debyeTerms"] = []
    hist.Background[1]["nPeaks"] = 0
    hist.Background[1]["peaksList"] = []

    inst = hist.InstrumentParameters
    for key in inst:
        if isinstance(inst[key], list) and len(inst[key]) >= 3 and isinstance(inst[key][2], bool):
            inst[key][2] = False
    for key in ("Zero", "Polariz.", "U", "X"):
        inst[key][2] = True
    for key in ("V", "W", "Y", "Z"):
        inst[key][1] = 0.0
        inst[key][2] = False
    inst["SH/L"][1] = 0.002
    inst["SH/L"][2] = False

    sample = hist.SampleParameters
    for value in sample.values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for key in ("Absorption", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if key in sample:
            sample[key][0] = 0.0
            sample[key][1] = False

    for phase in project.phases():
        phase.set_refinements({"Cell": phase.name != "Ba3W2O9"})
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][:3] = [10.0, 10.0, 1.0]
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["Extinction"][:] = [0.0, False]
        for value in hap["Babinet"].values():
            value[:] = [0.0, False]

    wo3_po = project.phase("WO3").getHAPvalues(hist)["Pref.Ori."]
    wo3_po[1] = 0.9737469815131421
    wo3_po[2] = True
    wo3_po[3] = [1, 0, 1]

    bao2_size = project.phase("BaO2").getHAPvalues(hist)["Size"]
    bao2_size[0] = "uniaxial"
    bao2_size[1][:3] = [0.17262347146849089, 10.0, 1.0]
    bao2_size[2] = [True, False, False]
    bao2_size[3] = [0, 0, 1]

    # Enforce a chemically plausible peroxide bond. X-ray data do not
    # independently determine this light-atom coordinate robustly.
    bao2 = project.phase("BaO2")
    c = bao2.get_cell()["length_c"]
    bao2.atom("O1").coordinates = (0.0, 0.0, 0.5 - 1.49 / (2.0 * c))

    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    project.set_Controls("cycles", 10)
    project.save()

    # Bounds are only retained for parameters that remain active.
    for variable, lower, upper in (
        (":0:U", 0.0, 2000.0),
        (":0:X", 0.0, 200.0),
        (":0:Polariz.", 0.0, 1.0),
        (f"{project.phase('WO3').id}:0:MD", 0.2, 5.0),
        (f"{project.phase('BaO2').id}:0:Size;i", 0.005, 1000.0),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMax", 1000.0, variable=f"{phase.id}:0:Scale")


def main() -> None:
    project = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
    configure(project)

    replay = []
    for label in ("full_range_fit", "reopen_replay", "second_replay"):
        project.do_refinements([{}])
        project.save()
        hist = project.histogram(0)
        rvals = project.data["Covariance"]["data"]["Rvals"]
        replay.append(
            {
                "step": label,
                "Rwp_percent": hist.get_wR(),
                "GOF": rvals["GOF"],
                "mass_fractions": hist.ComputeMassFracs(),
                "converged": rvals["converged"],
                "delta_chi2": rvals["DelChi2"],
                "message": rvals.get("msg", ""),
            }
        )
        project = G2sc.G2Project(str(FINAL))

    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    hmeta = hist.data["data"][0]
    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]

    for phase in project.phases():
        phase.export_CIF(str(PHASE_EXPORTS[phase.name]))

    profile = np.asarray(hist.data["data"][1], dtype=float)
    with Path("fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        for x, obs, calc, diff, background in zip(
            profile[0], profile[1], profile[3], profile[5], profile[4]
        ):
            writer.writerow(
                [
                    f"{x:.8f}",
                    f"{obs:.8f}",
                    f"{calc:.8f}",
                    f"{diff:.8f}",
                    f"{background:.8f}",
                ]
            )

    phase_results = []
    for phase in project.phases():
        fraction, esd = fractions[phase.name]
        phase_results.append(
            {
                "name": phase.name,
                "formula": phase.data["General"].get("Name", phase.name),
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": str(PHASE_EXPORTS[phase.name]),
                "structure_source": SOURCES[phase.name],
                "weight_fraction": fraction,
                "weight_fraction_formal_esd": esd,
                "cell": phase.get_cell(),
                "cell_refined": phase.name != "Ba3W2O9",
                "phase_R_F_percent": hmeta.get(f"{phase.id}:0:Rf"),
                "phase_R_F2_percent": hmeta.get(f"{phase.id}:0:Rf^2"),
            }
        )

    result = {
        "fraction_basis": "normalized over modeled crystalline phases",
        "phases": phase_results,
        "fit_statistics": {
            "Rwp_percent": rvals["Rwp"],
            "Rp_percent": hmeta["R"],
            "R_background_percent": hmeta["Rb"],
            "Rwp_min_percent": hmeta["wRmin"],
            "GOF": rvals["GOF"],
            "chi_squared": rvals["chisq"],
            "n_observations": rvals["Nobs"],
            "n_refined_parameters": rvals["Nvars"],
            "converged": rvals["converged"],
            "durbin_watson": hmeta.get("Durbin-Watson"),
        },
        "project_path": str(FINAL),
        "profile_path": "fit.csv",
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")

    print(json.dumps({"replay": replay, "result": result}, indent=2))


if __name__ == "__main__":
    main()
