#!/usr/bin/env python3
"""Trial a single global polarization correction on the established profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    project = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    hist.Background[0][1] = True
    inst = hist.InstrumentParameters
    inst["W"][1] = 0.0
    inst["W"][2] = False
    for key in ("Zero", "U", "X", "Polariz."):
        inst[key][2] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.getHAPvalues(hist)["Scale"][1] = True
    project.save()
    project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    log = []
    for label in ("fit", "reopen_replay", "second_replay"):
        project.do_refinements([{}])
        project.save()
        hist = project.histogram(0)
        log.append(
            {
                "step": label,
                "wR": hist.get_wR(),
                "instrument": {k: hist.InstrumentParameters[k][1] for k in ("Zero", "Polariz.", "U", "W", "X")},
                "mass_fractions": hist.ComputeMassFracs(),
            }
        )
        project = G2sc.G2Project(str(args.out))
    print(json.dumps({"log": log}, indent=2))


if __name__ == "__main__":
    main()
