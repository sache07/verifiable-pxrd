#!/usr/bin/env python3
"""Re-challenge a candidate phase under an established two-phase GSAS-II profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--cif", type=Path, required=True)
    parser.add_argument("--start-scale", type=float, default=0.02)
    parser.add_argument("--preserve-profile", action="store_true")
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    hist = project.histogram(0)
    candidate = project.add_phase(
        str(args.cif), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    project.set_Controls("cycles", 8)

    # Preserve the clean common profile, with unsupported W pruned at zero.
    inst = hist.InstrumentParameters
    inst["W"][1] = 0.0
    inst["W"][2] = False
    for key in ("U", "X", "Zero"):
        inst[key][2] = True
    hist.Background[0][1] = True

    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        if not args.preserve_profile or phase.name == candidate.name:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1000.0
            hap["Size"][2] = [False for _ in hap["Size"][2]]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        if not args.preserve_profile or phase.name == candidate.name:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
        hap["Extinction"][:] = [0.0, False]
        phase.set_refinements({"Cell": phase.name != candidate.name})
    candidate.getHAPvalues(hist)["Scale"][0] = args.start_scale

    project.save()
    for phase in project.phases():
        variable = f"{phase.id}:0:Scale"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 1000.0, variable=variable)
    for variable, upper in ((":0:U", 2000.0), (":0:X", 200.0)):
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    log = []
    for label in ("reconverge", "replay"):
        project.do_refinements([{}])
        project.save()
        log.append(
            {
                "step": label,
                "wR": hist.get_wR(),
                "scales": {p.name: p.getHAPvalues(hist)["Scale"][0] for p in project.phases()},
                "cells": {p.name: p.get_cell() for p in project.phases()},
                "instrument": {k: inst[k][1] for k in ("Zero", "U", "W", "X")},
            }
        )
        project = G2sc.G2Project(str(args.out))
        hist = project.histogram(0)
        inst = hist.InstrumentParameters

    try:
        mass = hist.ComputeMassFracs()
    except Exception as exc:
        mass = {"error": str(exc)}
    print(json.dumps({"candidate": args.name, "log": log, "mass_fractions": mass}, indent=2))


if __name__ == "__main__":
    main()
