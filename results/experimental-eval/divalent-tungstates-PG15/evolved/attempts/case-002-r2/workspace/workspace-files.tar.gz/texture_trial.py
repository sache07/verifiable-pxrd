#!/usr/bin/env python3
"""Test one March-Dollase texture axis against the no-texture baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--axis", type=int, nargs=3, required=True)
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.base), newgpx=str(args.out))
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    hist.Background[0][1] = True
    inst = hist.InstrumentParameters
    inst["W"][1] = 0.0
    inst["W"][2] = False
    for key in ("Zero", "Polariz.", "U", "X"):
        inst[key][2] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = True
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    phase = project.phase(args.phase)
    po = phase.getHAPvalues(hist)["Pref.Ori."]
    po[1] = 1.0
    po[2] = True
    po[3] = list(args.axis)

    project.save()
    variable = f"{phase.id}:0:MD"
    project.set_Controls("parmMin", 0.2, variable=variable)
    project.set_Controls("parmMax", 5.0, variable=variable)
    log = []
    for label in ("fit", "reopen_replay"):
        project.do_refinements([{}])
        project.save()
        hist = project.histogram(0)
        po = project.phase(args.phase).getHAPvalues(hist)["Pref.Ori."]
        log.append(
            {
                "step": label,
                "wR": hist.get_wR(),
                "MD": po[1],
                "axis": po[3],
                "mass_fractions": hist.ComputeMassFracs(),
            }
        )
        project = G2sc.G2Project(str(args.out))
    print(json.dumps({"phase": args.phase, "axis": args.axis, "log": log}, indent=2))


if __name__ == "__main__":
    main()
