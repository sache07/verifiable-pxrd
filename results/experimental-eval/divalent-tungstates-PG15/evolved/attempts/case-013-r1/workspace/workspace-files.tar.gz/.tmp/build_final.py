from __future__ import annotations

import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent.parent
BASE = ROOT / '.tmp' / 'corrected_five_strain1.gpx'
FINAL = ROOT / 'final.gpx'

PHASE_INFO = [
    ('PbWO4 (scheelite/stolzite)', 'PbWO4', 'phase_1_PbWO4.cif', 'COD 9009811'),
    ('Pb2WO5 (C2/m prototype)', 'Pb2WO5', 'phase_2_Pb2WO5.cif', 'Pb2MoO5 COD 7220560 with isovalent W-for-Mo substitution'),
    ('WO3 (monoclinic)', 'WO3', 'phase_3_WO3.cif', 'COD 1528915'),
    ('PbO (massicot)', 'PbO', 'phase_4_PbO_massicot.cif', 'COD 2310433'),
    ('PbO (litharge)', 'PbO', 'phase_5_PbO_litharge.cif', 'COD 9012700 transformed to the GSAS-II P4/nmm origin-choice-2 setting'),
]


def clean_hap(phase, hist, retain_pb2wo5_strain=False):
    hap = phase.getHAPvalues(hist)
    hap['Scale'][1] = True
    hap['Pref.Ori.'][0] = 'MD'
    hap['Pref.Ori.'][1] = 1.0
    hap['Pref.Ori.'][2] = False
    hap['Pref.Ori.'][3] = [0, 0, 1]
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][:] = [10.0, 10.0, 1.0]
    hap['Size'][2][:] = [False, False, False]
    hap['Size'][4][:] = [10.0, 10.0, 10.0, 0.0, 0.0, 0.0]
    hap['Size'][5][:] = [False] * len(hap['Size'][5])
    hap['Mustrain'][0] = 'isotropic'
    if retain_pb2wo5_strain:
        hap['Mustrain'][1][:] = [1405.0, 1405.0, 1.0]
        hap['Mustrain'][2][:] = [True, False, False]
    else:
        hap['Mustrain'][1][:] = [0.0, 0.0, 1.0]
        hap['Mustrain'][2][:] = [False, False, False]
    hap['Mustrain'][4][:] = [0.0] * len(hap['Mustrain'][4])
    hap['Mustrain'][5][:] = [False] * len(hap['Mustrain'][5])
    hap['HStrain'][0][:] = [0.0] * len(hap['HStrain'][0])
    hap['HStrain'][1][:] = [False] * len(hap['HStrain'][1])
    hap['Extinction'][:] = [0.0, False]
    hap['Babinet']['BabA'][:] = [0.0, False]
    hap['Babinet']['BabU'][:] = [0.0, False]


gpx = G2sc.G2Project(str(BASE), newgpx=str(FINAL))
hist = gpx.histogram(0)
x = hist.getdata('X')
hist.Limits('lower', float(x[0]))
hist.Limits('upper', float(x[-1]))
hist.Excluded([])

# One angular correction, a compact nonnegative common profile, and no
# scale-correlated sample corrections.
inst = hist.InstrumentParameters
for key in ('U', 'V', 'Y', 'Z'):
    inst[key][1] = 0.0
    inst[key][2] = False
for key in ('W', 'X', 'Zero', 'Polariz.', 'SH/L'):
    inst[key][2] = True
inst['I(L2)/I(L1)'][:3] = [0.5, 0.5, False]
inst['Lam1'][:3] = [1.540598, 1.540598, False]
inst['Lam2'][:3] = [1.544426, 1.544426, False]

sample = hist.SampleParameters
sample['Scale'][:] = [1.0, False]
sample['Shift'][:] = [0.0, False]
sample['Transparency'][:] = [0.0, False]
sample['SurfRoughA'][:] = [0.0, False]
sample['SurfRoughB'][:] = [0.0, False]

hist.set_refinements({'Background': {
    'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 8,
}})

for index, phase in enumerate(gpx.phases()):
    phase.set_refinements({'Cell': True})
    for atom in phase.atoms():
        atom.refinement_flags = ' '
    clean_hap(phase, hist, retain_pb2wo5_strain=(index == 1))

gpx.set_Controls('cycles', 12)
gpx.save()
gpx.do_refinements([{}, {}, {}])
gpx.save()

# Reopen and replay over the exact submitted range.
gpx = G2sc.G2Project(str(FINAL))
gpx.do_refinements([{}])
gpx.save()
gpx = G2sc.G2Project(str(FINAL))
hist = gpx.histogram(0)

mass_fracs = hist.ComputeMassFracs()
phase_rows = []
for phase, (display_name, formula, cif_name, basis) in zip(gpx.phases(), PHASE_INFO):
    cif_path = ROOT / cif_name
    phase.export_CIF(str(cif_path))
    frac, frac_esd = mass_fracs[phase.name]
    phase_rows.append({
        'name': display_name,
        'formula': formula,
        'space_group': phase.data['General']['SGData']['SpGrp'].strip(),
        'cif_path': cif_name,
        'weight_fraction': float(frac),
        'weight_fraction_esd': float(frac_esd),
        'structure_basis': basis,
        'cell': {k: float(v) for k, v in phase.get_cell().items()},
    })

fit_path = ROOT / 'fit.csv'
fit_columns = ('X', 'Yobs', 'Ycalc', 'Residual', 'Background', 'Yweight')
fit_arrays = [hist.getdata(key) for key in fit_columns]
with fit_path.open('w', newline='') as handle:
    writer = csv.writer(handle)
    writer.writerow(('two_theta_deg', 'observed', 'calculated', 'difference_observed_minus_calculated', 'background', 'weight'))
    for row in zip(*fit_arrays):
        writer.writerow(f'{float(value):.10g}' for value in row)

res = hist.residuals
rvals = gpx.data['Covariance']['data']['Rvals']
result = {
    'project_path': 'final.gpx',
    'profile_path': 'fit.csv',
    'phases': phase_rows,
    'fit_statistics': {
        'Rwp_percent': float(res['wR']),
        'Rp_percent': float(res['R']),
        'Rexp_percent': float(res['wRmin']),
        'GOF': float(rvals['GOF']),
        'chi_squared': float(rvals['chisq']),
        'n_observations': int(rvals['Nobs']),
        'n_refined_variables': int(rvals['Nvars']),
    },
    'measurement_model': {
        'radiation': 'Cu K-alpha1/K-alpha2',
        'wavelength_Kalpha1_angstrom': 1.540598,
        'wavelength_Kalpha2_angstrom': 1.544426,
        'Kalpha2_to_Kalpha1_ratio': 0.5,
        'uncertainty_model': 'Poisson counting approximation: sigma=sqrt(observed counts); pointwise uncertainties were not supplied',
    },
}
(ROOT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')

print(json.dumps(result, indent=2))
