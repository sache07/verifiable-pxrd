from pathlib import Path
import json
import GSASIIscriptable as G2sc

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')

def cod(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'

gpx = G2sc.G2Project(newgpx=str(HERE / 'probe.gpx'))
hist = gpx.add_powder_histogram(str(HERE / 'pattern.xye'), str(HERE / 'instrument.instprm'), fmthint='Topas')
ph = gpx.add_phase(str(cod('9009811')), phasename='PbWO4_scheelite', histograms=[hist], fmthint='CIF')
print('hist', hist.name)
print('instrument', hist.InstrumentParameters)
print('sample', hist.SampleParameters)
print('background', hist.Background)
print('phase general', {k: ph.data['General'][k] for k in ('Name','Type','Cell','SGData','AtomPtrs','Mass')})
print('hap', json.dumps(ph.getHAPvalues(hist), default=str, indent=2))
gpx.save()
