from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cod(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


PHASES = {
    'pwo': ('PbWO4_scheelite', cod('9009811')),
    'pwod': ('Pb7W8O28p8_defect', cod('9016035')),
    'pwom': ('PbWO4_monoclinic', cod('9007617')),
    'p2wo5': ('Pb2WO5_C2m_prototype', HERE / 'Pb2WO5_prototype.cif'),
    'wo3m': ('WO3_monoclinic_P21n', cod('1528915')),
    'wo3t': ('WO3_triclinic_P-1', cod('2106293')),
    'wo3o': ('WO3_orthorhombic_Pnma', cod('2107312')),
    'pbo': ('PbO_massicot_Pbcm', cod('2310433')),
    'pboa': ('PbO_modulated_Pbma', cod('1533609')),
    'pbol': ('PbO_litharge_P4nmm', HERE / 'PbO_litharge_standard.cif'),
    'p3o4': ('Pb3O4_minium', cod('9012124')),
}


MODELS = {
    'pwo': ['pwo'],
    'pwo_p2wo5': ['pwo', 'p2wo5'],
    'pwo_wo3m': ['pwo', 'wo3m'],
    'pwo_pbo': ['pwo', 'pbo'],
    'pwo_p2wo5_wo3m': ['pwo', 'p2wo5', 'wo3m'],
    'pwod_p2wo5_wo3m_pbo': ['pwod', 'p2wo5', 'wo3m', 'pbo'],
    'pwom_p2wo5_wo3m_pbo': ['pwom', 'p2wo5', 'wo3m', 'pbo'],
    'pwo_p2wo5_wo3t': ['pwo', 'p2wo5', 'wo3t'],
    'pwo_p2wo5_wo3o': ['pwo', 'p2wo5', 'wo3o'],
    'pwo_wo3m_pbo': ['pwo', 'wo3m', 'pbo'],
    'pwo_p2wo5_wo3m_pbo': ['pwo', 'p2wo5', 'wo3m', 'pbo'],
    'pwo_p2wo5_wo3m_pbo_p3o4': ['pwo', 'p2wo5', 'wo3m', 'pbo', 'p3o4'],
    'pwo_p2wo5_wo3m_pbo_pbol': ['pwo', 'p2wo5', 'wo3m', 'pbo', 'pbol'],
    'pwo_p2wo5_wo3t_pbo_pbol': ['pwo', 'p2wo5', 'wo3t', 'pbo', 'pbol'],
    'pwo_p2wo5_wo3o_pbo_pbol': ['pwo', 'p2wo5', 'wo3o', 'pbo', 'pbol'],
    'pwo_p2wo5_wo3m_pbo_pbol_p3o4': ['pwo', 'p2wo5', 'wo3m', 'pbo', 'pbol', 'p3o4'],
    'pwo_p2wo5_wo3m_pboa': ['pwo', 'p2wo5', 'wo3m', 'pboa'],
    'pwo_p2wo5_wo3t_pbo': ['pwo', 'p2wo5', 'wo3t', 'pbo'],
    'pwo_p2wo5_wo3o_pbo': ['pwo', 'p2wo5', 'wo3o', 'pbo'],
    'pwo_p2wo5_wo3m_pbol': ['pwo', 'p2wo5', 'wo3m', 'pbol'],
    'pwo_p2wo5_wo3m_p3o4': ['pwo', 'p2wo5', 'wo3m', 'p3o4'],
}


def neutralize_hap(phase, hist):
    hap = phase.getHAPvalues(hist)
    hap['Scale'][:] = [1.0, True]
    hap['Pref.Ori.'][0] = 'MD'
    hap['Pref.Ori.'][1] = 1.0
    hap['Pref.Ori.'][2] = False
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][:] = [1.0e6, 1.0e6, 1.0]
    hap['Size'][2][:] = [False, False, False]
    hap['Size'][4][:] = [1.0e6, 1.0e6, 1.0e6, 0.0, 0.0, 0.0]
    hap['Size'][5][:] = [False] * 6
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][:] = [0.0, 0.0, 1.0]
    hap['Mustrain'][2][:] = [False, False, False]
    hap['Mustrain'][4][:] = [0.0] * len(hap['Mustrain'][4])
    hap['Mustrain'][5][:] = [False] * len(hap['Mustrain'][5])
    hap['HStrain'][0][:] = [0.0] * len(hap['HStrain'][0])
    hap['HStrain'][1][:] = [False] * len(hap['HStrain'][1])
    hap['Extinction'][:] = [0.0, False]
    hap['Babinet']['BabA'][:] = [0.0, False]
    hap['Babinet']['BabU'][:] = [0.0, False]


def snapshot(gpx, label):
    hist = gpx.histogram(0)
    print('\nSNAPSHOT', label)
    print('residuals', hist.residuals)
    print('instrument', {k: hist.InstrumentParameters[k] for k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'SH/L')})
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        print('phase', phase.name, 'scale', hap['Scale'], 'cell', phase.get_cell(),
              'size', hap['Size'][:3], 'strain', hap['Mustrain'][:3])


def refine_model(model_name: str):
    keys = MODELS[model_name]
    out = HERE / f'{model_name}.gpx'
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(HERE / 'pattern.xye'), str(HERE / 'instrument.instprm'), fmthint='Topas'
    )
    hist.Limits('lower', 10.05)
    hist.Limits('upper', 99.90)
    hist.SampleParameters['Scale'][:] = [1.0, False]
    hist.InstrumentParameters['Zero'][:2] = [0.28, 0.28]
    hist.InstrumentParameters['W'][:2] = [25.0, 25.0]
    hist.InstrumentParameters['X'][:2] = [10.0, 10.0]
    hist.InstrumentParameters['U'][:2] = [0.0, 0.0]
    hist.InstrumentParameters['V'][:2] = [0.0, 0.0]
    hist.InstrumentParameters['Y'][:2] = [0.0, 0.0]
    hist.InstrumentParameters['Z'][:2] = [0.0, 0.0]
    hist.InstrumentParameters['SH/L'][:2] = [0.002, 0.002]
    hist.set_refinements({'Background': {
        'type': 'chebyschev-1', 'refine': True, 'no. coeffs': 8,
        'coeffs': [700.0, -300.0, 180.0, -120.0, 70.0, -30.0, 10.0, 0.0],
    }})
    phases = []
    for key in keys:
        name, path = PHASES[key]
        phase = gpx.add_phase(str(path), phasename=name, histograms=[hist], fmthint='CIF')
        neutralize_hap(phase, hist)
        phases.append(phase)

    gpx.set_Controls('cycles', 8)
    gpx.save()
    snapshot(gpx, 'initial')

    # Common nuisance model: smooth background, all scales, one angular correction.
    gpx.do_refinements([{}])
    snapshot(gpx, 'background_scales')
    hist.set_refinements({'Instrument Parameters': ['Zero']})
    gpx.do_refinements([{}])
    snapshot(gpx, 'zero')

    # Only after scales and zero are stable, adjust cells and then common width.
    for phase in phases:
        phase.set_refinements({'Cell': True})
    gpx.do_refinements([{}])
    snapshot(gpx, 'cells')
    hist.set_refinements({'Instrument Parameters': ['W', 'X']})
    gpx.do_refinements([{}])
    snapshot(gpx, 'common_profile')
    gpx.do_refinements([{}])
    snapshot(gpx, 'replay')
    gpx.save()

    masses = hist.ComputeMassFracs()
    summary = {
        'model': model_name,
        'residuals': hist.residuals,
        'instrument': {k: hist.InstrumentParameters[k] for k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'SH/L')},
        'phases': {
            p.name: {
                'scale': p.getHAPvalues(hist)['Scale'],
                'mass_fraction': masses.get(p.name),
                'cell': p.get_cell(),
            }
            for p in phases
        },
    }
    (HERE / f'{model_name}.json').write_text(json.dumps(summary, indent=2))
    print('\nSUMMARY', json.dumps(summary, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('model', choices=sorted(MODELS))
    refine_model(parser.parse_args().model)
