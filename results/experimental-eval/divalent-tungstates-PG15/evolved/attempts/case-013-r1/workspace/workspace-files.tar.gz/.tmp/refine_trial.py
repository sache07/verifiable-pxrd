from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def summarize(gpx):
    hist = gpx.histogram(0)
    masses = hist.ComputeMassFracs()
    return {
        'residuals': hist.residuals,
        'instrument': {k: hist.InstrumentParameters[k] for k in
                       ('Zero', 'Polariz.', 'U', 'V', 'W', 'X', 'Y', 'SH/L')},
        'sample': {k: hist.SampleParameters[k] for k in
                   ('Scale', 'Shift', 'Transparency', 'SurfRoughA', 'SurfRoughB')},
        'phases': {
            p.name: {
                'mass_fraction': masses.get(p.name),
                'scale': p.getHAPvalues(hist)['Scale'],
                'size': p.getHAPvalues(hist)['Size'],
                'mustrain': p.getHAPvalues(hist)['Mustrain'],
                'pref_ori': p.getHAPvalues(hist)['Pref.Ori.'],
                'cell': p.get_cell(),
            }
            for p in gpx.phases()
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('base')
    parser.add_argument('output')
    parser.add_argument('modes', nargs='+')
    args = parser.parse_args()

    out = Path(args.output)
    gpx = G2sc.G2Project(args.base, newgpx=str(out))
    hist = gpx.histogram(0)
    for mode in args.modes:
        if mode == 'u':
            hist.InstrumentParameters['U'][:2] = [10.0, 10.0]
            hist.set_refinements({'Instrument Parameters': ['U']})
        elif mode == 'pol':
            hist.set_refinements({'Instrument Parameters': ['Polariz.']})
        elif mode == 'shl':
            hist.InstrumentParameters['SH/L'][:2] = [0.01, 0.01]
            hist.set_refinements({'Instrument Parameters': ['SH/L']})
        elif mode == 'rough':
            hist.SampleParameters['SurfRoughA'][:] = [0.9, True]
            hist.SampleParameters['SurfRoughB'][:] = [0.01, True]
        elif mode.startswith('usize'):
            idx, h, k, l = (int(v) for v in mode[5:].split(','))
            hap = gpx.phase(idx).getHAPvalues(hist)
            hap['Size'][0] = 'uniaxial'
            hap['Size'][1][:] = [1.0, 1.0, 1.0]
            hap['Size'][2][:] = [True, True, False]
            hap['Size'][3] = [h, k, l]
        elif mode.startswith('ustrain'):
            idx, h, k, l = (int(v) for v in mode[7:].split(','))
            hap = gpx.phase(idx).getHAPvalues(hist)
            hap['Mustrain'][0] = 'uniaxial'
            hap['Mustrain'][1][:] = [300.0, 300.0, 1.0]
            hap['Mustrain'][2][:] = [True, True, False]
            hap['Mustrain'][3] = [h, k, l]
        elif mode.startswith('size'):
            idx = int(mode[4:])
            phase = gpx.phase(idx)
            hap = phase.getHAPvalues(hist)
            hap['Size'][0] = 'isotropic'
            hap['Size'][1][:] = [1.0, 1.0, 1.0]
            hap['Size'][2][:] = [True, False, False]
        elif mode.startswith('strain'):
            idx = int(mode[6:])
            phase = gpx.phase(idx)
            hap = phase.getHAPvalues(hist)
            hap['Mustrain'][0] = 'isotropic'
            hap['Mustrain'][1][:] = [300.0, 300.0, 1.0]
            hap['Mustrain'][2][:] = [True, False, False]
        elif mode.startswith('md'):
            idx, h, k, l = (int(v) for v in mode[2:].split(','))
            hap = gpx.phase(idx).getHAPvalues(hist)
            hap['Pref.Ori.'][0] = 'MD'
            hap['Pref.Ori.'][1] = 1.0
            hap['Pref.Ori.'][2] = True
            hap['Pref.Ori.'][3] = [h, k, l]
        else:
            raise ValueError(mode)

    gpx.set_Controls('cycles', 10)
    gpx.save()
    gpx.do_refinements([{}, {}])
    gpx.save()
    # Save/reopen/replay to expose any non-replay-stable option.
    gpx = G2sc.G2Project(str(out))
    gpx.do_refinements([{}])
    gpx.save()
    result = summarize(gpx)
    out.with_suffix('.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
