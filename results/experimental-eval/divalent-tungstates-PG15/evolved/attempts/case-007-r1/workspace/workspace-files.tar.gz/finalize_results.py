#!/usr/bin/env python3
"""Replay the accepted GSAS-II model and generate the requested deliverables."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASELINE = ROOT / "watch_mgo.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_INFO = {
    "MgWO4": {
        "name": "MgWO4 (wolframite)",
        "formula": "MgWO4",
        "cif": "phase_mgwo4.cif",
        "cod_id": "9013902",
    },
    "WO3_P21c_neutron": {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif": "phase_wo3.cif",
        "cod_id": "2311041",
    },
    "MgO": {
        "name": "MgO (periclase)",
        "formula": "MgO",
        "cif": "phase_mgo.cif",
        "cod_id": "9000499",
    },
}


def f(value):
    """Convert NumPy scalar values to plain JSON numbers."""
    return float(value)


def replay_final() -> G2sc.G2Project:
    project = G2sc.G2Project(str(BASELINE), newgpx=str(FINAL_GPX))
    project.set_Controls("cycles", 16)
    project.refine(makeBack=False)
    project.save()

    # Acceptance requires an explicit save/reopen/full-range replay.
    project = G2sc.G2Project(str(FINAL_GPX))
    project.set_Controls("cycles", 16)
    project.refine(makeBack=False)
    project.save()

    # All exports are made from this final reopened copy.
    return G2sc.G2Project(str(FINAL_GPX))


def write_fit(hist) -> tuple[int, float, float, float, float, float, float]:
    arrays = [np.asarray(a, dtype=float) for a in hist.data["data"][1]]
    x, observed, _weight, calculated, background, difference = arrays
    low, high = (float(v) for v in hist.data["Limits"][1])
    # GSAS-II includes the first sampled point just above the nominal upper
    # limit. Select the exact calculated range so the CSV has the same Nobs.
    use = calculated != 0.0
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts_observed_minus_calculated",
                "background_counts",
            ]
        )
        for values in zip(
            x[use], observed[use], calculated[use], difference[use], background[use]
        ):
            writer.writerow([f"{v:.17g}" for v in values])
    return (
        int(use.sum()),
        low,
        high,
        float(x[use][0]),
        float(x[use][-1]),
        float(background[use].min()),
        float(background[use].max()),
    )


def build_result(
    project,
    hist,
    n_profile_points: int,
    nominal_low: float,
    nominal_high: float,
    sampled_low: float,
    sampled_high: float,
) -> dict:
    fractions = hist.ComputeMassFracs()
    fraction_sum = sum(value[0] for value in fractions.values())
    residuals = hist.residuals
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]

    phases = []
    for internal_name in PHASE_INFO:
        phase = project.phase(internal_name)
        info = PHASE_INFO[internal_name]
        value, sigma = fractions[internal_name]
        cell, cell_sigma = phase.get_cell_and_esd()
        phase.export_CIF(str(ROOT / info["cif"]))
        phase_id = phase.id
        phases.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": info["cif"],
                "source_cod_id": info["cod_id"],
                "weight_fraction": f(value / fraction_sum),
                "weight_fraction_formal_esd": f(sigma / fraction_sum),
                "weight_percent": f(100.0 * value / fraction_sum),
                "cell": {key: f(val) for key, val in cell.items()},
                "cell_formal_esd": {key: f(val) for key, val in cell_sigma.items()},
                "phase_Rf_percent": f(residuals[f"{phase_id}:0:Rf"]),
                "phase_Rf_squared_percent": f(residuals[f"{phase_id}:0:Rf^2"]),
            }
        )

    result = {
        "method": "GSAS-II multiphase Rietveld refinement",
        "project_path": FINAL_GPX.name,
        "profile_path": "fit.csv",
        "profile_difference_definition": "observed_counts - calculated_counts",
        "profile_range_two_theta_deg": [sampled_low, sampled_high],
        "nominal_refinement_limits_two_theta_deg": [nominal_low, nominal_high],
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": f(residuals["wR"]),
            "Rp_percent": f(residuals["R"]),
            "Rexp_percent_GSAS_wRmin": f(residuals["wRmin"]),
            "RBragg_percent": f(residuals["Rb"]),
            "weighted_RBragg_percent": f(residuals["wRb"]),
            "goodness_of_fit": f(rvals["GOF"]),
            "reduced_chi_square": f(rvals["GOF"] ** 2),
            "chi_square": f(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_profile_points_exported": n_profile_points,
            "n_refined_parameters": int(rvals["Nvars"]),
            "converged": bool(rvals["converged"]),
            "maximum_shift_over_sigma_final_cycle": f(rvals["Max shft/sig"]),
        },
        "fraction_basis": (
            "Normalized over the three modeled crystalline phases; no amorphous or "
            "unmodeled fraction is quantified."
        ),
        "uncertainty_note": (
            "Fraction e.s.d.s are formal covariance values using sqrt(counts) Poisson "
            "weights because pointwise uncertainties were not supplied; systematic "
            "model uncertainty is larger."
        ),
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def write_report(result: dict, bkg_min: float, bkg_max: float) -> None:
    by_formula = {phase["formula"]: phase for phase in result["phases"]}
    mgwo4 = by_formula["MgWO4"]
    wo3 = by_formula["WO3"]
    mgo = by_formula["MgO"]
    stats = result["fit_statistics"]

    def cell_text(phase: dict) -> str:
        c = phase["cell"]
        if phase["formula"] == "MgO":
            return f"a = {c['length_a']:.5f} Å"
        return (
            f"a = {c['length_a']:.5f}, b = {c['length_b']:.5f}, "
            f"c = {c['length_c']:.5f} Å, β = {c['angle_beta']:.4f}°"
        )

    report = f"""# Quantitative phase analysis

## Result

The crystalline pattern is modeled by three phases. Weight fractions are normalized only over those modeled crystalline phases.

| Phase | Space group | Weight fraction | Refined cell |
|---|---:|---:|---|
| MgWO4, wolframite | P 2/c | {mgwo4['weight_percent']:.2f} wt% | {cell_text(mgwo4)} |
| WO3, monoclinic | P 21/c | {wo3['weight_percent']:.2f} wt% | {cell_text(wo3)} |
| MgO, periclase | F m -3 m | {mgo['weight_percent']:.2f} wt% | {cell_text(mgo)} |

Final whole-pattern statistics are Rwp = {stats['Rwp_percent']:.3f}%, Rp = {stats['Rp_percent']:.3f}%, and goodness-of-fit = {stats['goodness_of_fit']:.3f} ({stats['n_observations']} observations, {stats['n_refined_parameters']} variables). The final save/reopen replay converged with maximum shift/s.u. = {stats['maximum_shift_over_sigma_final_cycle']:.3f}.

## Evidence and model selection

- MgWO4 is supported by the wolframite families at 15.93° (010), 19.23° (100), 24.21° (011), 30.80/31.11°, and many middle/high-angle families. The retained COD 9013902 model is a synthetic, ambient-pressure, fully occupied P2/c structure with sensible MgO6 and WO6 coordination. A weak [110] March–Dollase correction is required (final parameter about 1.087): under the completed three-phase inventory, Rwp is 9.344% versus 9.731% without texture and 9.51–9.55% for competing tested axes.
- WO3 is identified by the characteristic 23.43/23.91/24.68° triplet and coherent families near 33.57–34.48°, 48.56–50.21°, and higher angle. The full-occupancy neutron P21/c model (COD 2311041) preserves complete distorted WO6 octahedra. Under the same final nuisance model it outperforms triclinic (Rwp 9.613%), an alternate monoclinic record (9.822%), orthorhombic (12.586%), and hexagonal (19.180%) WO3. Competing WO3 texture axes improve Rwp by at most 0.014 percentage point and do not give a coherent axial-family trend, so no WO3 texture term is retained.
- MgO is supported independently by all six accessible rocksalt families: 111, 200, 220, 311, 222, and 400 at 37.23, 43.20, 62.57, 74.93, 78.86, and 94.24°. Adding it to the two-phase common-profile model lowers Rwp from 10.303% to 9.344%. Their extracted Fobs²/Fcalc² ratios are close to unity, so MgO texture is not justified.
- Oxygen-deficient W18O49 was re-challenged as a weak watch-list phase. With its source cell fixed it reached only 0.49 wt% and changed Rwp by 0.015 point, while several of its strongest unique or partly overlapped families coincide with negative residuals. Freeing its cell worsened Rwp to 9.48%. It is therefore not a reliable detection and is excluded. The other indexed Mg–W–O records are either a 900 °C-incompatible dihydrate or contain a dummy oxygen site rather than a usable alternate structure.

## Refinement and physical checks

The raw counts were fitted from 10.0° to 100.0° 2θ with Cu Kα1/Kα2 wavelengths and the reported 0.5 intensity ratio fixed. Because pointwise uncertainties were absent, sqrt(counts) Poisson uncertainties were used. The baseline uses a smooth six-coefficient Chebyshev background (positive over the fit range, {bkg_min:.0f}–{bkg_max:.0f} counts), one zero correction, a nonnegative common U/W/X profile, refined effective polarization, and a fixed replay-stable SH/L asymmetry value. Isolated low-, middle-, and high-angle profiles were checked for position, width, and asymmetry; no monotonic mismatch remained.

Phase scales and cells were refined. Atomic coordinates, occupancies, and displacement parameters were kept at the physically screened literature values because this mixed-phase laboratory X-ray pattern does not determine them independently. Size, microstrain, anisotropic broadening, roughness, extinction, and other unused nuisance terms were neutral/fixed. Isotropic size/strain and symmetry-distinct uniaxial-size trials either reached neutral/bounds, became nonphysical, drifted on replay, or changed Rwp negligibly, and were pruned.

## Remaining uncertainty

The phase identities and refined metrics are reliable, but the fractions are semi-quantitative. Formal covariance e.s.d.s are {100*mgwo4['weight_fraction_formal_esd']:.2f}, {100*wo3['weight_fraction_formal_esd']:.2f}, and {100*mgo['weight_fraction_formal_esd']:.2f} wt-percentage points for MgWO4, WO3, and MgO, respectively; these are smaller than realistic systematic uncertainty from overlap, preferred orientation, source structures, and the uncalibrated instrumental profile. About 1–2 wt-percentage points absolute is a more conservative interpretation. No amorphous fraction can be obtained from this normalization. The largest remaining residuals are low-angle MgWO4/WO3 intensity/profile residuals, not a coherent additional peak family.

The submitted CIFs, `fit.csv`, phase fractions, and statistics were all exported from the reopened `final.gpx` project.
"""
    (ROOT / "report.md").write_text(report)


def main() -> None:
    project = replay_final()
    hist = project.histogram(0)
    npoints, low, high, sampled_low, sampled_high, bkg_min, bkg_max = write_fit(hist)
    result = build_result(
        project, hist, npoints, low, high, sampled_low, sampled_high
    )
    write_report(result, bkg_min, bkg_max)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
