#!/usr/bin/env python3
"""Build and refine trial GSAS-II projects for the supplied PXRD pattern."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


PHASES = {
    "MgWO4": "9013902",
    "MgO": "9000499",
    "WO3_P21m": "1010618",
    "WO3_P21c": "1528915",
    "WO3_P21c_neutron": "2311041",
    "WO3_triclinic": "2106293",
    "WO3_Pnma": "2107312",
    "WO3_hexagonal": "1004057",
    "W18O49": "1538315",
}


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_hap(phase, hist_name: str) -> None:
    """Set unused phase/profile nuisance terms to neutral values."""
    hap = phase.data["Histograms"][hist_name]
    hap["Extinction"] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]
    hap["HStrain"][0] = [0.0 for _ in hap["HStrain"][0]]
    hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0e6
    hap["Size"][1][1] = 1.0e6
    hap["Size"][1][2] = 1.0
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Size"][5] = [False for _ in hap["Size"][5]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][4] = 0
    hap["Pref.Ori."][5] = {}


def snapshot(project, label: str) -> dict:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    out = {
        "label": label,
        "residuals": {
            k: (float(v) if isinstance(v, (int, float, np.number)) else str(v))
            for k, v in hist.residuals.items()
        },
        "instrument": {
            key: float(inst[key][1])
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L")
            if key in inst
        },
        "background": [float(v) for v in hist.Background[0][3:]],
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "scale": float(hap["Scale"][0]),
            "cell": {k: float(v) for k, v in phase.get_cell().items()},
            "size": json.loads(json.dumps(hap["Size"], default=float)),
            "mustrain": json.loads(json.dumps(hap["Mustrain"], default=float)),
            "preferred_orientation": json.loads(
                json.dumps(hap["Pref.Ori."], default=float)
            ),
        }
    return out


def refine_step(project, log: list[dict], label: str) -> None:
    project.refine(makeBack=False)
    project.save()
    log.append(snapshot(project, label))


def build(names: list[str], output: Path, profile_mode: str) -> tuple[object, list[dict]]:
    project = G2sc.G2Project(newgpx=str(output))
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        fmthint="xye",
    )
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 6,
            },
        }
    )
    hist.Background[0][3:] = [800.0, -450.0, 150.0, -60.0, 20.0, -5.0]
    for sample_parameter in hist.SampleParameters.values():
        if isinstance(sample_parameter, list) and len(sample_parameter) > 1:
            sample_parameter[1] = False
    inst = hist.InstrumentParameters
    for key, value in {
        "Zero": 0.34,
        "U": 10.0,
        "V": 0.0,
        "W": 20.0,
        "X": 1.0,
        "Y": 0.0,
        "Z": 0.0,
        "SH/L": 0.002,
        "I(L2)/I(L1)": 0.5,
        "Polariz.": 0.5,
    }.items():
        if key in inst:
            inst[key][1] = value
            inst[key][2] = False

    phases = []
    for name in names:
        phase = project.add_phase(
            str(cod_path(PHASES[name])),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase.data["General"]["Cell"][0] = False
        phase.set_HAP_refinements({"Scale": True})
        phase.HAPvalue("Scale", 1.0 / len(names))
        neutralize_hap(phase, hist.name)
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        phases.append(phase)

    project.save()
    log = [snapshot(project, "initial")]

    # Reversible baseline sequence: smooth background/scales, one angular
    # correction, cells, then a low-dimensional common profile.
    refine_step(project, log, "background_scales")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_step(project, log, "zero")
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine_step(project, log, "cells")

    if profile_mode in {"uw", "uwx", "uwx_shl"}:
        hist.set_refinements({"Instrument Parameters": ["U", "W"]})
        refine_step(project, log, "profile_UW")
    if profile_mode in {"uwx", "uwx_shl"}:
        hist.set_refinements({"Instrument Parameters": ["X"]})
        refine_step(project, log, "profile_UWX")
    if profile_mode == "uwx_shl":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        refine_step(project, log, "profile_UWX_SHL")

    # Re-converge the shared baseline after all provisional changes.
    refine_step(project, log, "reconverged")
    return project, log


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phases", nargs="+", choices=PHASES, default=["MgWO4"])
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--profile", choices=["fixed", "uw", "uwx", "uwx_shl"], default="uwx"
    )
    parser.add_argument("--log", type=Path)
    args = parser.parse_args()
    project, log = build(args.phases, args.output, args.profile)
    log_path = args.log or args.output.with_suffix(".json")
    log_path.write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
