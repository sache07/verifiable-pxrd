#!/usr/bin/env python3
"""Add a watch-list phase and rebuild/replay the common GSAS-II profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from build_refinement import PHASES, cod_path, neutralize_hap, snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", choices=["MgO", "W18O49"])
    parser.add_argument(
        "--keep-cell-fixed",
        action="store_true",
        help="replay the source metric without the subsequent cell challenge",
    )
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline), newgpx=str(args.output))
    project.set_Controls("cycles", 16)
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cod_path(PHASES[args.phase])),
        phasename=args.phase,
        histograms=[hist],
        fmthint="CIF",
    )
    if args.phase == "W18O49":
        # This COD record encodes formal oxidation states in the atom type
        # (W+5/O-2), which this GSAS-II X-ray form-factor table does not use.
        # Preserve chemistry and coordinates while normalizing to elements.
        atom_type_index = phase.data["General"]["AtomPtrs"][1]
        for atom in phase.data["Atoms"]:
            atom[atom_type_index] = "W" if atom[atom_type_index].startswith("W") else "O"
        G2sc.SetupGeneral(phase.data, str(cod_path(PHASES[args.phase]).parent))
    neutralize_hap(phase, hist.name)
    phase.data["Histograms"][hist.name]["Size"][1][0] = 10.0
    phase.HAPvalue("Scale", {"MgO": 2.0, "W18O49": 0.1}[args.phase])
    phase.set_HAP_refinements({"Scale": True})
    phase.data["General"]["Cell"][0] = False
    project.save()
    log = [snapshot(project, "watch_phase_added")]

    # Scale first under the established nuisance model.
    project.refine(makeBack=False)
    project.save()
    log.append(snapshot(project, "watch_scale"))

    if not args.keep_cell_fixed:
        # Then release the candidate cell and reconverge all existing shared terms.
        phase.set_refinements({"Cell": True})
        project.refine(makeBack=False)
        project.save()
        log.append(snapshot(project, "watch_cell_common_profile"))

    project = G2sc.G2Project(str(args.output))
    project.set_Controls("cycles", 16)
    project.refine(makeBack=False)
    project.save()
    log.append(snapshot(project, "reopened_replay"))
    args.output.with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
