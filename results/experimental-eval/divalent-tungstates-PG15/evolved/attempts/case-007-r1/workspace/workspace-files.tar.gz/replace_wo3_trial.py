#!/usr/bin/env python3
"""Re-challenge a WO3 record under the converged three-phase profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from build_refinement import PHASES, cod_path, neutralize_hap, snapshot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "replacement",
        choices=["WO3_P21c", "WO3_triclinic", "WO3_Pnma", "WO3_hexagonal"],
    )
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline), newgpx=str(args.output))
    project.set_Controls("cycles", 16)
    hist = project.histogram(0)
    old = project.phase("WO3_P21c_neutron")
    old_hap = old.data["Histograms"][hist.name]
    old_scale = float(old_hap["Scale"][0])
    old_hap["Use"] = False
    old_hap["Scale"][1] = False
    old.data["General"]["Cell"][0] = False

    candidate = project.add_phase(
        str(cod_path(PHASES[args.replacement])),
        phasename=args.replacement + "_replacement",
        histograms=[hist],
        fmthint="CIF",
    )
    neutralize_hap(candidate, hist.name)
    # Match the effectively neutral fixed size convention in the baseline.
    candidate.data["Histograms"][hist.name]["Size"][1][0] = 10.0
    candidate.HAPvalue("Scale", old_scale)
    candidate.set_HAP_refinements({"Scale": True})
    candidate.data["General"]["Cell"][0] = False
    project.save()
    log = [snapshot(project, "replacement_added")]

    # Rebuild common background/profile/scales first, with source metric fixed.
    project.refine(makeBack=False)
    project.save()
    log.append(snapshot(project, "replacement_scale_common_profile"))

    # Then release the candidate metric and fully reconverge.
    candidate.set_refinements({"Cell": True})
    project.refine(makeBack=False)
    project.save()
    log.append(snapshot(project, "replacement_cell_common_profile"))

    # Save/reopen/replay is the acceptance check.
    project = G2sc.G2Project(str(args.output))
    project.set_Controls("cycles", 16)
    project.refine(makeBack=False)
    project.save()
    log.append(snapshot(project, "reopened_replay"))
    args.output.with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
