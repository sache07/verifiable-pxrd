#!/usr/bin/env python3
"""Replay one reversible nuisance-model change from a converged GSAS-II baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from build_refinement import snapshot


def configure(project, mode: str) -> None:
    hist = project.histogram(0)
    mg = project.phase("MgWO4")
    wo3 = project.phase("WO3_P21c_neutron")
    mgo = project.phase("MgO") if any(p.name == "MgO" for p in project.phases()) else None
    hname = hist.name

    if mode == "shl":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    elif mode == "freeze_shl":
        hist.clear_refinements({"Instrument Parameters": ["SH/L"]})
    elif mode == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif mode.endswith("_size"):
        phase = mg if mode.startswith("mg_") else wo3
        hap = phase.data["Histograms"][hname]["Size"]
        hap[0] = "isotropic"
        hap[1][0] = 1.0
        hap[1][2] = 1.0
        hap[2] = [True, False, False]
        hap[5] = [False for _ in hap[5]]
    elif mode.endswith("_strain"):
        phase = mg if mode.startswith("mg_") else wo3
        hap = phase.data["Histograms"][hname]["Mustrain"]
        hap[0] = "isotropic"
        hap[1][0] = 100.0
        hap[1][2] = 1.0
        hap[2] = [True, False, False]
        hap[5] = [False for _ in hap[5]]
    elif mode.startswith("mg_usize_"):
        direction = [int(v) for v in mode.removeprefix("mg_usize_").split(",")]
        hap = mg.data["Histograms"][hname]["Size"]
        hap[0] = "uniaxial"
        # Keep the perpendicular size at the effectively neutral 10-micron
        # upper bound and test only coherent broadening parallel to the axis.
        hap[1][0] = 10.0
        hap[1][1] = 1.0
        hap[1][2] = 1.0
        hap[2] = [False, True, False]
        hap[3] = direction
        hap[5] = [False for _ in hap[5]]
    elif mode == "mg_md_none":
        hap = mg.data["Histograms"][hname]["Pref.Ori."]
        hap[0] = "MD"
        hap[1] = 1.0
        hap[2] = False
        hap[4] = 0
        hap[5] = {}
    elif mode.startswith("mg_md_"):
        direction = [int(v) for v in mode.removeprefix("mg_md_").split(",")]
        hap = mg.data["Histograms"][hname]["Pref.Ori."]
        hap[0] = "MD"
        hap[1] = 1.0
        hap[2] = True
        hap[3] = direction
        hap[4] = 0
        hap[5] = {}
    elif mode.startswith("mgo_md_"):
        if mgo is None:
            raise ValueError("MgO is not present in this project")
        direction = [int(v) for v in mode.removeprefix("mgo_md_").split(",")]
        hap = mgo.data["Histograms"][hname]["Pref.Ori."]
        hap[0] = "MD"
        hap[1] = 1.0
        hap[2] = True
        hap[3] = direction
        hap[4] = 0
        hap[5] = {}
    elif mode.startswith("wo3_md_"):
        direction = [int(v) for v in mode.removeprefix("wo3_md_").split(",")]
        hap = wo3.data["Histograms"][hname]["Pref.Ori."]
        hap[0] = "MD"
        hap[1] = 1.0
        hap[2] = True
        hap[3] = direction
        hap[4] = 0
        hap[5] = {}
    else:
        raise ValueError(mode)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("mode")
    args = parser.parse_args()

    project = G2sc.G2Project(str(args.baseline), newgpx=str(args.output))
    project.set_Controls("cycles", 16)
    configure(project, args.mode)
    project.save()
    log = [snapshot(project, "configured")]
    project.refine(makeBack=False)
    project.save()
    log.append(snapshot(project, "first_replay"))

    # Explicit save/reopen/replay check.
    project = G2sc.G2Project(str(args.output))
    project.set_Controls("cycles", 16)
    project.refine(makeBack=False)
    project.save()
    log.append(snapshot(project, "reopened_replay"))
    args.output.with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
