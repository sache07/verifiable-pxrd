#!/usr/bin/env python3
"""Replay the accepted model and export project-identical submission files."""

from pathlib import Path
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "full_range_test.gpx"
PROJECT = ROOT / "final.gpx"
CIF = ROOT / "phase_1_MnWO4_wolframite.cif"
FIT = ROOT / "fit.csv"
RESULT = ROOT / "result.json"


# Clone the accepted clean model, then save/reopen/replay the exact full range.
gpx = G2sc.G2Project(str(SOURCE), newgpx=str(PROJECT))
if len(gpx.phases()) != 1 or len(gpx.histograms()) != 1:
    raise RuntimeError("accepted model must contain exactly one phase and histogram")
hist = gpx.histogram(0)
x = np.asarray(hist.data["data"][1][0], dtype=float)
hist.data["Limits"][1] = [float(x[0]), float(x[-1])]
gpx.refine(makeBack=False)
gpx.save()

gpx = G2sc.G2Project(str(PROJECT))
gpx.refine(makeBack=False)
gpx.save()

# Reopen once more so every export comes from the on-disk submitted project.
gpx = G2sc.G2Project(str(PROJECT))
hist = gpx.histogram(0)
phase = gpx.phase(0)
cov = gpx.data["Covariance"]["data"]
rvals = cov["Rvals"]
if not rvals.get("converged") or rvals.get("SVD0"):
    raise RuntimeError("final replay did not converge cleanly")

# Assert that unsupported phase-specific and intensity nuisance terms are off.
hap = phase.data["Histograms"][hist.name]
if any(hap["Size"][2]) or any(hap["Mustrain"][2]):
    raise RuntimeError("unsupported isotropic size/strain refinement is active")
if any(hap["Size"][5]) or any(hap["Mustrain"][5]):
    raise RuntimeError("unsupported anisotropic size/strain refinement is active")
if hap["Pref.Ori."][2] or hap["Extinction"][1]:
    raise RuntimeError("unsupported texture/extinction refinement is active")

inst = hist.data["Instrument Parameters"][0]
for key in ("U", "V", "Y", "Z"):
    if inst[key][1] < 0:
        raise RuntimeError(f"negative profile coefficient {key}")

# GSAS-II CIF export from the exact phase object in final.gpx.
phase.export_CIF(str(CIF))

# Combined observed/calculated/difference profile from final.gpx.
profile = hist.data["data"][1]
x = np.asarray(profile[0], dtype=float)
yobs = np.asarray(profile[1], dtype=float)
ycalc = np.asarray(profile[3], dtype=float)
ybkg = np.asarray(profile[4], dtype=float)
ydiff = yobs - ycalc
table = np.column_stack((x, yobs, ycalc, ydiff, ybkg))
np.savetxt(
    FIT,
    table,
    delimiter=",",
    header=(
        "two_theta_deg,observed_counts,calculated_counts,"
        "difference_obs_minus_calc_counts,background_counts"
    ),
    comments="",
    fmt=["%.10f", "%.10f", "%.10f", "%.10f", "%.10f"],
)

cell, cell_esd = phase.get_cell_and_esd()
res = hist.residuals
nobs = int(rvals["Nobs"])
nvars = int(rvals["Nvars"])
chi_square = float(rvals["chisq"])
reduced_chi_square = chi_square / (nobs - nvars)

# Hill-Howard normalization used by GSAS-II is identically one for this
# accepted one-phase crystalline model. Its formal normalized s.u. is zero,
# but no absolute uncertainty is claimed without an external standard.
result = {
    "project_path": PROJECT.name,
    "profile_path": FIT.name,
    "weight_fraction_basis": "normalized over modeled crystalline phases",
    "phases": [
        {
            "phase_id": 1,
            "name": "MnWO4 (wolframite)",
            "formula": "MnWO4",
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "space_group_number": 13,
            "cif_path": CIF.name,
            "weight_fraction": 1.0,
            "weight_fraction_esd": None,
            "cell": {
                "a_angstrom": float(cell["length_a"]),
                "b_angstrom": float(cell["length_b"]),
                "c_angstrom": float(cell["length_c"]),
                "alpha_deg": float(cell["angle_alpha"]),
                "beta_deg": float(cell["angle_beta"]),
                "gamma_deg": float(cell["angle_gamma"]),
                "volume_angstrom3": float(cell["volume"]),
            },
            "cell_esd": {
                "a_angstrom": float(cell_esd["length_a"]),
                "b_angstrom": float(cell_esd["length_b"]),
                "c_angstrom": float(cell_esd["length_c"]),
                "beta_deg": float(cell_esd["angle_beta"]),
                "volume_angstrom3": float(cell_esd["volume"]),
            },
        }
    ],
    "fit_statistics": {
        "Rwp_percent": float(res["wR"]),
        "Rp_percent": float(res["R"]),
        "Rexp_percent": float(res["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_square": chi_square,
        "reduced_chi_square": reduced_chi_square,
        "R_Bragg_percent": float(res["0:0:Rf"]),
        "R_F_squared_percent": float(res["0:0:Rf^2"]),
        "durbin_watson": float(hist.data["data"][0]["Durbin-Watson"]),
        "n_observations": nobs,
        "n_refined_parameters": nvars,
        "two_theta_range_deg": [float(x[0]), float(x[-1])],
    },
    "measurement": {
        "radiation": "Cu Kalpha1/Kalpha2",
        "lambda1_angstrom": float(inst["Lam1"][1]),
        "lambda2_angstrom": float(inst["Lam2"][1]),
        "Kalpha2_to_Kalpha1_ratio": float(inst["I(L2)/I(L1)"][1]),
    },
}
RESULT.write_text(json.dumps(result, indent=2) + "\n")

print(json.dumps(result, indent=2))
