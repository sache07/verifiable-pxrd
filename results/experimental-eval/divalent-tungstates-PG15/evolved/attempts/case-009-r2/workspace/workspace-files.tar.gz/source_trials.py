#!/usr/bin/env python3
"""Compare physical wolframite structure records under one nuisance model."""

from pathlib import Path
import json
import math

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id):
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def build(cod_id, parent_element):
    name = f"source_{cod_id}"
    out = ROOT / f"{name}.gpx"
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    phase = gpx.add_phase(
        str(cod_path(cod_id)),
        phasename=f"MnWO4_from_COD_{cod_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    if parent_element != "Mn":
        replaced = 0
        for atom in phase.atoms():
            if atom.element == parent_element:
                atom.type = "Mn"
                replaced += 1
        if replaced != 1:
            raise RuntimeError(f"expected one {parent_element} site, found {replaced}")
        G2sc.SetupGeneral(phase.data, None)

    hist.set_refinements({"Limits": [9.904, 100.094]})
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    phase.data["Histograms"][hist.name]["Scale"] = [60.0, True]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [1200.0, -500.0, 250.0, -100.0, 30.0, 0.0, 0.0, 0.0],
                "refine": True,
            }
        }
    )
    inst = hist.data["Instrument Parameters"][0]
    for key, value, refine in (
        ("Zero", 0.0, False),
        ("U", 0.0, False),
        ("V", 0.0, False),
        ("W", 36.0, True),
        ("X", 6.0, True),
        ("Y", 0.0, False),
        ("Z", 0.0, False),
        ("SH/L", 0.002, False),
        ("Polariz.", 0.5, False),
    ):
        inst[key][1:] = [value, refine]
    sample = hist.data["Sample Parameters"]
    sample["Shift"] = [-424.0, True]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.1, False]
    sample["SurfRoughB"] = [0.42, True]

    # Put all records on the same target cell before comparing coordinates/ADPs.
    a, b, c, beta = 4.8306, 5.7568, 4.9961, 91.2183
    volume = a * b * c * math.sin(math.radians(beta))
    phase.data["General"]["Cell"][1:8] = [a, b, c, 90.0, beta, 90.0, volume]
    phase.data["General"]["Cell"][0] = True

    hap = phase.data["Histograms"][hist.name]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][2] = False
    hap["Extinction"][1] = False
    for item in hap["Babinet"].values():
        item[1] = False

    gpx.data["Controls"]["data"]["max cyc"] = 12
    for _ in range(4):
        gpx.refine(makeBack=False)
        gpx.save()
    gpx = G2sc.G2Project(str(out))
    gpx.refine(makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    row = {
        "cod_id": cod_id,
        "parent_element": parent_element,
        "Rwp": hist.get_wR(),
        "Rp": hist.residuals.get("R"),
        "Rf": hist.residuals.get("0:0:Rf"),
        "cell": phase.get_cell(),
        "shift_um": sample["Shift"][0],
        "roughB": sample["SurfRoughB"][0],
        "W": inst["W"][1],
        "X": inst["X"][1],
        "phase_scale": phase.data["Histograms"][hist.name]["Scale"][0],
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "xyz": list(atom.coordinates),
                "adp_flag": atom.adp_flag,
                "adp": atom.ADP if isinstance(atom.ADP, float) else list(atom.ADP),
            }
            for atom in phase.atoms()
        ],
        "gpx": out.name,
    }
    print("SOURCE", json.dumps(row, sort_keys=True))
    return row


rows = []
for cod_id, element in (
    ("1520200", "Mn"),
    ("9008124", "Fe"),
    ("1520641", "Zn"),
    ("9013902", "Mg"),
):
    rows.append(build(cod_id, element))

(ROOT / ".tmp" / "source_trials.json").write_text(json.dumps(rows, indent=2) + "\n")
