#!/usr/bin/env python3
"""Replay restrained profile/intensity-correction trials from baseline.gpx."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "baseline.gpx"


def clone(name):
    out = ROOT / f"trial_{name}.gpx"
    return G2sc.G2Project(str(BASE), newgpx=str(out)), out


def run(name, setup, cycles=2):
    gpx, out = clone(name)
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    setup(gpx, hist, phase)
    for _ in range(cycles):
        gpx.refine(makeBack=False)
        gpx.save()
    # exact reopen/replay
    gpx = G2sc.G2Project(str(out))
    gpx.refine(makeBack=False)
    gpx.save()
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hap = phase.data["Histograms"][hist.name]
    row = {
        "name": name,
        "Rwp": hist.get_wR(),
        "Rp": hist.residuals.get("R"),
        "zero": inst["Zero"][1],
        "U": inst["U"][1],
        "W": inst["W"][1],
        "X": inst["X"][1],
        "SHL": inst["SH/L"][1],
        "polarization": inst["Polariz."][1],
        "roughA": sample["SurfRoughA"][0],
        "roughB": sample["SurfRoughB"][0],
        "phase_scale": hap["Scale"][0],
        "cell": phase.get_cell(),
        "gpx": out.name,
    }
    print("TRIAL", json.dumps(row, sort_keys=True))
    return row


rows = []

for u in (0.0, 5.0, 10.0, 20.0, 40.0):
    def setup_u(g, h, p, u=u):
        inst = h.data["Instrument Parameters"][0]
        inst["U"][1:] = [u, False]
    rows.append(run(f"U_fixed_{u:g}", setup_u))


def setup_shl(g, h, p):
    h.data["Instrument Parameters"][0]["SH/L"][2] = True


rows.append(run("SHL_refined", setup_shl))

for pol in (0.5, 0.6, 0.7, 0.8, 0.9):
    def setup_pol(g, h, p, pol=pol):
        h.data["Instrument Parameters"][0]["Polariz."][1:] = [pol, False]
    rows.append(run(f"polarization_fixed_{pol:g}", setup_pol))


def setup_pol_refine(g, h, p):
    h.data["Instrument Parameters"][0]["Polariz."][1:] = [0.6, True]


rows.append(run("polarization_refined", setup_pol_refine))

for rough_a in (0.0, 0.1, 0.3, 0.5, 0.7):
    def setup_rough(g, h, p, rough_a=rough_a):
        sample = h.data["Sample Parameters"]
        sample["SurfRoughA"] = [rough_a, False]
        sample["SurfRoughB"] = [0.01, True]
    rows.append(run(f"rough_A{rough_a:g}_Bref", setup_rough))


def setup_rough_both(g, h, p):
    sample = h.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.3, True]
    sample["SurfRoughB"] = [0.03, True]


rows.append(run("rough_both", setup_rough_both))

(ROOT / ".tmp" / "nuisance_trials.json").write_text(json.dumps(rows, indent=2) + "\n")
