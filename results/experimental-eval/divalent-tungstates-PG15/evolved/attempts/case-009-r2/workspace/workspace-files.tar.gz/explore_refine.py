#!/usr/bin/env python3
"""Build a minimal GSAS-II MnWO4 refinement for model exploration."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def report(gpx, label):
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phase = gpx.phase(0)
    hap = phase.data["Histograms"][hist.name]
    print(f"\n--- {label} ---")
    print("residuals", hist.data["data"][0])
    print("wR", hist.get_wR())
    print("cell", phase.get_cell())
    print("inst", {k: v for k, v in inst.items() if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "I(L2)/I(L1)")})
    print("sample", {k: v for k, v in sample.items() if k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")})
    print("hap scale", hap["Scale"])
    print("size", hap["Size"])
    print("mustrain", hap["Mustrain"])
    print("pref ori", hap["Pref.Ori."])


gpx_path = ROOT / "explore.gpx"
gpx = G2sc.G2Project(newgpx=str(gpx_path))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma",
)
phase = gpx.add_phase(
    str(cod_path("1520200")),
    phasename="MnWO4_P2c",
    histograms=[hist],
    fmthint="CIF",
)
hist.set_refinements({"Limits": [10.0, 100.0]})
hist.set_refinements(
    {
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 8,
            "coeffs": [1200.0, -500.0, 250.0, -100.0, 30.0, 0.0, 0.0, 0.0],
            "refine": True,
        }
    }
)
phase.set_HAP_refinements({"Scale": True}, [hist])
gpx.data["Controls"]["data"]["max cyc"] = 8
gpx.save()

for label, action in [
    ("background+scale", None),
    ("+zero", lambda: hist.set_refinements({"Instrument Parameters": ["Zero"]})),
    ("+cell", lambda: phase.set_refinements({"Cell": True})),
    ("+UWX", lambda: hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})),
    ("+SHL", lambda: hist.set_refinements({"Instrument Parameters": ["SH/L"]})),
]:
    if action:
        action()
    gpx.refine(makeBack=False)
    gpx.save()
    report(gpx, label)

# Reopen and replay unchanged to test persistence/convergence.
gpx = G2sc.G2Project(str(gpx_path))
gpx.refine(makeBack=False)
gpx.save()
report(gpx, "reopened replay")
