#!/usr/bin/env python3
"""Challenge a clean MnWO4 profile with chemically plausible watch-list phases.

Each candidate starts with only its scale enabled.  The background, both phase
scales, the established common W/X profile, specimen displacement, roughness B,
and the MnWO4 cell are reconverged.  A candidate cell is released only when its
scale is both positive and significant after the scale-only replay.
"""

from pathlib import Path
import json
import re

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "neutral_profile.gpx"
CIF_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id):
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = (
    # Unreacted precursor and a physical polymorph challenge.
    ("Mn3O4_hausmannite", "9001963", "ambient tetragonal precursor"),
    ("Mn3O4_Pbcm", "1541183", "high-pressure orthorhombic polymorph"),
    # Ambient and source-temperature-relevant tungsten oxide alternatives.
    ("WO3_ambient_P21c", "1563541", "ambient monoclinic WO3"),
    ("WO3_ambient_P21n", "1528915", "alternate ambient monoclinic WO3"),
    ("WO3_Pnma", "2107312", "orthorhombic WO3 polymorph"),
    # Other exact Mn-O-W or plausible manganese-oxide products.
    ("Mn3WO6_R3bar", "2002703", "alternate ternary manganese tungstate"),
    ("Mn2O3_bixbyite", "1514230", "oxidized manganese oxide"),
    ("MnO_rocksalt", "1514108", "reduced manganese oxide"),
    ("MnO2_rutile", "1514110", "oxidized manganese oxide"),
)


def neutralize_hap(phase, hist):
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 10.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    for item in hap["Babinet"].values():
        item[0] = 0.0
        item[1] = False
    return hap


def normalize_atom_types(phase):
    """Repair COD ionic type strings that the GSAS-II CIF reader maps to H."""
    changed = False
    for atom in phase.atoms():
        match = re.match(r"(Mn|W|O)", atom.label, re.IGNORECASE)
        if not match:
            continue
        element = match.group(1).capitalize()
        if element == "Mn":
            element = "Mn"
        if atom.type != element:
            atom.type = element
            changed = True
    if changed:
        G2sc.SetupGeneral(phase.data, None)


def refined_value_and_sigma(gpx, variable):
    cov = gpx.data["Covariance"]["data"]
    if variable not in cov["varyList"]:
        return None, None
    i = cov["varyList"].index(variable)
    return float(cov["variables"][i]), float(cov["sig"][i])


def summarize(gpx, cod_id, label, note, stage, out):
    hist = gpx.histogram(0)
    candidate = gpx.phase(1)
    pid = candidate.data["pId"]
    hid = hist.data["data"][0]["hId"]
    hap = candidate.data["Histograms"][hist.name]
    value, sigma = refined_value_and_sigma(gpx, f"{pid}:{hid}:Scale")
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as err:
        fractions = {"error": str(err)}
    frac = fractions.get(candidate.name, (None, None))
    row = {
        "label": label,
        "cod_id": cod_id,
        "source_note": note,
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(hist.residuals.get("R")),
        "candidate_scale": float(hap["Scale"][0]),
        "candidate_scale_sigma": sigma,
        "candidate_scale_z": (
            None if sigma in (None, 0.0) else float(hap["Scale"][0]) / sigma
        ),
        "candidate_weight_fraction": (
            None if frac[0] is None else float(frac[0])
        ),
        "candidate_weight_fraction_sigma": (
            None if frac[1] is None else float(frac[1])
        ),
        "candidate_cell": candidate.get_cell(),
        "project": out.name,
    }
    print("INVENTORY", json.dumps(row, sort_keys=True))
    return row


def run_candidate(label, cod_id, note):
    out = ROOT / f"inventory_{label}.gpx"
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    candidate = gpx.add_phase(
        str(cod_path(cod_id)),
        phasename=f"{label}_COD_{cod_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    normalize_atom_types(candidate)
    candidate.data["General"]["Cell"][0] = False
    hap = neutralize_hap(candidate, hist)
    hap["Scale"] = [0.5, True]
    gpx.data["Controls"]["data"]["max cyc"] = 12
    gpx.save()

    # Scale first, with the established nuisance model and main cell active.
    for _ in range(3):
        gpx.refine(makeBack=False)
        gpx.save()
    gpx = G2sc.G2Project(str(out))
    gpx.refine(makeBack=False)
    gpx.save()
    row = summarize(gpx, cod_id, label, note, "scale_only_replay", out)

    # Require a meaningful positive signal before adding candidate-cell freedom.
    frac = row["candidate_weight_fraction"] or 0.0
    zscore = row["candidate_scale_z"] or 0.0
    if frac > 0.001 and zscore > 3.0:
        candidate = gpx.phase(1)
        candidate.data["General"]["Cell"][0] = True
        for _ in range(2):
            gpx.refine(makeBack=False)
            gpx.save()
        gpx = G2sc.G2Project(str(out))
        gpx.refine(makeBack=False)
        gpx.save()
        row = summarize(gpx, cod_id, label, note, "cell_released_replay", out)
    return row


rows = [run_candidate(*candidate) for candidate in CANDIDATES]
(ROOT / ".tmp" / "phase_inventory_trials.json").write_text(
    json.dumps(rows, indent=2) + "\n"
)
