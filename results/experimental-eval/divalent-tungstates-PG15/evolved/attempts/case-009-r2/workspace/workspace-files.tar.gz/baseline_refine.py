#!/usr/bin/env python3
"""Create a restrained one-phase MnWO4 baseline GSAS-II project."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
CIF = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/02/1520200.cif")


def values(gpx, label):
    hist = gpx.histogram(0)
    phase = gpx.phase(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hap = phase.data["Histograms"][hist.name]
    print(
        label,
        "Rwp", hist.get_wR(),
        "cell", phase.get_cell(),
        "zero", inst["Zero"][1],
        "UWX", [inst[k][1] for k in ("U", "W", "X")],
        "SHL", inst["SH/L"][1],
        "pol", inst["Polariz."][1],
        "sampleScale", sample["Scale"],
        "phaseScale", hap["Scale"],
        "rough", [sample["SurfRoughA"], sample["SurfRoughB"]],
    )


out = ROOT / (sys.argv[1] if len(sys.argv) > 1 else "baseline.gpx")
gpx = G2sc.G2Project(newgpx=str(out))
hist = gpx.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "instrument.instprm"),
    fmthint="comma",
)
phase = gpx.add_phase(str(CIF), phasename="MnWO4_P2c", histograms=[hist], fmthint="CIF")

# Full measured range, one absolute histogram scale, and one phase scale.
hist.set_refinements({"Limits": [9.904, 100.094]})
hist.data["Sample Parameters"]["Scale"] = [1.0, False]
phase.data["Histograms"][hist.name]["Scale"] = [1.0, True]

# Smooth low-order background. Neutral nuisance terms are explicit.
hist.set_refinements(
    {
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 8,
            "coeffs": [1200.0, -500.0, 250.0, -100.0, 30.0, 0.0, 0.0, 0.0],
            "refine": True,
        }
    }
)
inst = hist.data["Instrument Parameters"][0]
for key, value in {"U": 0.0, "V": 0.0, "W": 50.0, "X": 2.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.002}.items():
    inst[key][1] = value
    inst[key][2] = False
sample = hist.data["Sample Parameters"]
for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
    sample[key][0] = 0.0
    sample[key][1] = False
hap = phase.data["Histograms"][hist.name]
hap["Size"][2] = [False, False, False]
hap["Mustrain"][2] = [False, False, False]
hap["Pref.Ori."][2] = False
hap["Extinction"][1] = False
for item in hap["Babinet"].values():
    item[1] = False

gpx.data["Controls"]["data"]["max cyc"] = 12
gpx.save()

stages = [
    ("background-scale", lambda: None),
    ("zero", lambda: hist.set_refinements({"Instrument Parameters": ["Zero"]})),
    ("cell", lambda: phase.set_refinements({"Cell": True})),
    ("W", lambda: hist.set_refinements({"Instrument Parameters": ["W"]})),
    ("W-X", lambda: hist.set_refinements({"Instrument Parameters": ["X"]})),
]
for label, setup in stages:
    setup()
    gpx.refine(makeBack=False)
    gpx.save()
    values(gpx, label)

# Reopen and replay the exact model.
gpx = G2sc.G2Project(str(out))
gpx.refine(makeBack=False)
gpx.save()
values(gpx, "replay")
