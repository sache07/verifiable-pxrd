#!/usr/bin/env python3
"""Replay, freeze and export the final two-phase GSAS-II model."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/trials/final_candidate.gpx"
REPLAY = ROOT / ".tmp/final_replay.gpx"
FINAL = ROOT / "final.gpx"
PHASE_INFO = {
    "WO3_triclinic": {
        "formula": "WO3",
        "display_name": "tungsten(VI) oxide",
        "cif": "phase_WO3.cif",
        "structure_source": "COD 2106293 (triclinic P -1 WO3)",
    },
    "CoWO4": {
        "formula": "CoWO4",
        "display_name": "cobalt(II) tungstate",
        "cif": "phase_CoWO4.cif",
        "structure_source": (
            "COD 7205001 CoMoO4-II prototype with the occupied Mo site "
            "substituted by W"
        ),
    },
}


def native(value):
    """Convert NumPy scalar/container values into JSON-compatible objects."""
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(k): native(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [native(v) for v in value]
    return value


def replay_and_copy() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(REPLAY))
    project.set_Controls("cycles", 20)
    project.save()
    history = []
    for pass_number in range(1, 6):
        project = G2sc.G2Project(str(REPLAY))
        project.refine()
        project.save()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        history.append(
            {
                "pass": pass_number,
                "Rwp_percent": rvals["Rwp"],
                "goodness_of_fit": rvals["GOF"],
                "maximum_shift_over_esd": rvals["Max shft/sig"],
                "converged": bool(rvals["converged"]),
            }
        )
        # Require at least three full save/reopen passes and stop only once
        # the replay shift is small. The fit itself is already stationary.
        if pass_number >= 3 and rvals["Max shft/sig"] < 0.1:
            break
    with (ROOT / ".tmp/final_replay_history.json").open("w") as handle:
        json.dump(history, handle, indent=2)
        handle.write("\n")
    project = G2sc.G2Project(str(REPLAY), newgpx=str(FINAL))
    project.save()


def export() -> dict:
    # This reopen is intentional: all submitted quantities are read from the
    # exact on-disk project that accompanies the submission.
    project = G2sc.G2Project(str(FINAL))
    histogram = project.histogram(0)
    phases = project.phases()
    names = [phase.name for phase in phases]
    if names != ["WO3_triclinic", "CoWO4"]:
        raise RuntimeError(f"Unexpected final phase inventory: {names}")
    if project.get_Frozen():
        raise RuntimeError(f"Final project has frozen variables: {project.get_Frozen()}")

    fractions = histogram.ComputeMassFracs()
    fraction_sum = sum(item[0] for item in fractions.values())
    if abs(fraction_sum - 1.0) > 1e-10:
        raise RuntimeError(f"Mass fractions do not sum to unity: {fraction_sum}")

    arrays = {
        key: np.asarray(histogram.getdata(key), dtype=float)
        for key in ("X", "Yobs", "Ycalc", "Background", "Residual")
    }
    if not np.allclose(
        arrays["Residual"], arrays["Yobs"] - arrays["Ycalc"], rtol=0.0, atol=1e-9
    ):
        raise RuntimeError("GSAS-II residual array is not observed minus calculated")

    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "background", "difference"]
        )
        writer.writerows(
            zip(
                arrays["X"],
                arrays["Yobs"],
                arrays["Ycalc"],
                arrays["Background"],
                arrays["Residual"],
            )
        )

    result_phases = []
    for phase in phases:
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif"]))
        cell, cell_esd = phase.get_cell_and_esd()
        fraction, fraction_esd = fractions[phase.name]
        pid = phase.id
        result_phases.append(
            {
                "name": info["display_name"],
                "project_phase_name": phase.name,
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": info["cif"],
                "weight_fraction": fraction,
                "weight_percent": 100.0 * fraction,
                "formal_weight_fraction_esd": fraction_esd,
                "cell": cell,
                "cell_esd": cell_esd,
                "R_F_percent": histogram.residuals.get(f"{pid}:0:Rf"),
                "R_F_squared_percent": histogram.residuals.get(f"{pid}:0:Rf^2"),
                "structure_source": info["structure_source"],
            }
        )

    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "phases": result_phases,
        "weight_fraction_normalization": (
            "Normalized to 1.0 over the modeled crystalline phases only; "
            "no amorphous fraction or absolute crystalline content was determined."
        ),
        "fit_statistics": {
            "Rwp_percent": histogram.residuals["wR"],
            "Rp_percent": histogram.residuals["R"],
            "Rexp_percent": histogram.residuals["wRmin"],
            "goodness_of_fit": rvals["GOF"],
            "chi_squared": rvals["chisq"],
            "reduced_chi_squared": rvals["GOF"] ** 2,
            "observations": rvals["Nobs"],
            "refined_variables": rvals["Nvars"],
            "background_R_percent": histogram.residuals.get("Rb"),
            "weighted_background_R_percent": histogram.residuals.get("wRb"),
            "converged": bool(rvals["converged"]),
            "maximum_shift_over_esd": rvals["Max shft/sig"],
        },
        "measurement": {
            "radiation": "Cu K-alpha1/K-alpha2",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "two_theta_range_deg": [float(arrays["X"][0]), float(arrays["X"][-1])],
            "points": int(arrays["X"].size),
            "weighting": (
                "Pointwise uncertainties were absent; sigma=sqrt(max(counts,1)) "
                "was used as a counting-statistics proxy."
            ),
        },
        "files": {
            "GSAS-II_project": "final.gpx",
            "profile": "fit.csv",
        },
    }
    result = native(result)
    with (ROOT / "result.json").open("w") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")

    summary = {
        "result": result,
        "profile": {
            "background_min": float(arrays["Background"].min()),
            "background_max": float(arrays["Background"].max()),
            "observed_min": float(arrays["Yobs"].min()),
            "observed_max": float(arrays["Yobs"].max()),
            "max_abs_residual": float(np.abs(arrays["Residual"]).max()),
        },
        "instrument": native(histogram.InstrumentParameters),
        "sample": native(histogram.SampleParameters),
        "background_model": native(histogram.Background),
        "phase_HAP": {
            phase.name: native(phase.getHAPvalues(histogram)) for phase in phases
        },
        "frozen": native(project.get_Frozen()),
    }
    with (ROOT / ".tmp/final_export_summary.json").open("w") as handle:
        json.dump(summary, handle, indent=2)
        handle.write("\n")
    return summary


if __name__ == "__main__":
    replay_and_copy()
    print(json.dumps(export()["result"], indent=2))
