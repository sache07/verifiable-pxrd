#!/usr/bin/env python3
"""Test one March-Dollase texture axis on a fixed phase inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", type=int)
    parser.add_argument("axis", nargs=3, type=int)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.input), newgpx=str(args.output))
    gpx.save()
    gpx.set_Frozen()
    hist = gpx.histogram(0)
    phase = gpx.phase(args.phase)
    po = phase.getHAPvalues(hist)["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(args.axis)
    gpx.set_Controls("parmMin", 0.2, variable=f"{phase.id}:0:MD")
    gpx.set_Controls("parmMax", 5.0, variable=f"{phase.id}:0:MD")
    gpx.set_Controls("cycles", 14)
    gpx.data["Controls"]["data"]["shift factor"] = 0.15
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
    gpx.refine()
    gpx.save()
    cov = gpx.data["Covariance"]["data"]
    md_name = f"{phase.id}:0:MD"
    md_sigma = None
    if md_name in cov.get("varyList", []):
        md_sigma = cov["sig"][cov["varyList"].index(md_name)]
    out = {
        "project": str(args.output),
        "phase": phase.name,
        "axis": args.axis,
        "residuals": dict(hist.residuals),
        "fractions": hist.ComputeMassFracs(),
        "frozen": gpx.get_Frozen(),
        "ratio": po[1],
        "sigma": md_sigma,
        "pref_ori": po,
        "rvals": cov.get("Rvals", {}),
    }
    print(json.dumps(out, indent=2))
    with args.output.with_suffix(".json").open("w") as handle:
        json.dump(out, handle, indent=2)


if __name__ == "__main__":
    main()
