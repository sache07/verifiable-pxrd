#!/usr/bin/env python3
"""Normalize unsupported ionic atom labels in the COD W18O49 record."""

from pathlib import Path


source = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/52/81/1528166.cif"
)
target = Path(".tmp/candidates/W18O49_normalized.cif")
text = source.read_text()
text = text.replace(" W+5 ", " W ").replace(" W+6 ", " W ")
target.write_text(text)
