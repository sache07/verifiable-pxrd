#!/usr/bin/env python3
"""Joint trace-phase scale challenge under the accepted nuisance model."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2sc


INPUT = ".tmp/trials/final_candidate.gpx"
OUTPUT = ".tmp/watch_CoO_Co3O4.gpx"
PHASES = (
    (
        "CoO",
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/1/54/16/1541662.cif",
    ),
    (
        "Co3O4",
        "<HOME>/.local/share/characterizagent/backends/dara/"
        "cod-filtered-2024/cif/9/00/58/9005896.cif",
    ),
)


def neutralize(phase, hist) -> None:
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][1:4] = [1.0, False, [0, 0, 1]]
    hap["Extinction"][:] = [0.0, False]
    hap["Scale"][:] = [0.05, True]


gpx = G2sc.G2Project(INPUT, newgpx=OUTPUT)
hist = gpx.histogram(0)
added = []
for name, cif in PHASES:
    phase = gpx.add_phase(cif, phasename=name, histograms=[hist], fmthint="CIF")
    neutralize(phase, hist)
    added.append(phase)
gpx.save()
gpx.set_Frozen()
for phase in added:
    gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
gpx.set_Controls("cycles", 20)
gpx.data["Controls"]["data"]["shift factor"] = 0.1
gpx.data["Controls"]["data"]["min dM/M"] = 1e-6

history = []
for stage in ("joint-scale", "replay"):
    gpx.refine()
    gpx.save()
    hist = gpx.histogram(0)
    history.append(
        {
            "stage": stage,
            "wR": hist.residuals.get("wR"),
            "R": hist.residuals.get("R"),
            "scales": {
                name: gpx.phase(name).getHAPvalues(hist)["Scale"][0]
                for name, _ in PHASES
            },
            "fractions": hist.ComputeMassFracs(),
            "frozen": gpx.get_Frozen(),
        }
    )
    gpx = G2sc.G2Project(OUTPUT)

print(json.dumps(history, indent=2))
with open(".tmp/watch_CoO_Co3O4.json", "w") as handle:
    json.dump(history, handle, indent=2)
