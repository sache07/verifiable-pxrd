#!/usr/bin/env python3
"""Re-challenge one weak phase under an established GSAS-II profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def neutralize(phase, hist) -> None:
    hap = phase.getHAPvalues(hist)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [10.0, 10.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Pref.Ori."][1:4] = [1.0, False, [0, 0, 1]]
    hap["Extinction"][:] = [0.0, False]
    hap["Scale"][:] = [0.05, True]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("name")
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.input), newgpx=str(args.output))
    hist = gpx.histogram(0)
    phase = gpx.add_phase(str(args.cif), phasename=args.name, histograms=[hist], fmthint="CIF")
    neutralize(phase, hist)
    gpx.save()
    gpx.set_Frozen()
    gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    gpx.set_Controls("cycles", 20)
    gpx.data["Controls"]["data"]["shift factor"] = 0.1
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-6
    history = []
    for stage in ("scale", "replay"):
        gpx.refine()
        gpx.save()
        hist = gpx.histogram(0)
        phase = gpx.phase(args.name)
        history.append({
            "stage": stage,
            "wR": hist.residuals.get("wR"),
            "R": hist.residuals.get("R"),
            "scale": phase.getHAPvalues(hist)["Scale"][0],
            "frozen": gpx.get_Frozen(),
        })
        gpx = G2sc.G2Project(str(args.output))
    hist = gpx.histogram(0)
    phase = gpx.phase(args.name)
    out = {
        "project": str(args.output),
        "phase": args.name,
        "history": history,
        "residuals": dict(hist.residuals),
        "scale": phase.getHAPvalues(hist)["Scale"][0],
        "fractions": hist.ComputeMassFracs(),
        "frozen": gpx.get_Frozen(),
    }
    print(json.dumps(out, indent=2))
    with args.output.with_suffix(".json").open("w") as handle:
        json.dump(out, handle, indent=2)


if __name__ == "__main__":
    main()
