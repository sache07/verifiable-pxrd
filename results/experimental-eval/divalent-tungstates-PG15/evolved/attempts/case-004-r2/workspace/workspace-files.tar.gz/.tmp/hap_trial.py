#!/usr/bin/env python3
"""Test one phase-specific size or strain term from a neutral baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase")
    parser.add_argument("kind", choices=("size", "strain"))
    parser.add_argument("--axis", nargs=3, type=int)
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.input), newgpx=str(args.output))
    gpx.save()
    gpx.set_Frozen()
    hist = gpx.histogram(0)
    try:
        phase = gpx.phase(int(args.phase))
    except ValueError:
        phase = gpx.phase(args.phase)
    hap = phase.getHAPvalues(hist)

    if args.kind == "size":
        hap["Size"][0] = "uniaxial" if args.axis else "isotropic"
        hap["Size"][1][:] = [10.0, 10.0, 1.0]
        hap["Size"][2][:] = [True, bool(args.axis), False]
        if args.axis:
            hap["Size"][3] = list(args.axis)
        gpx.set_Controls("parmMin", 0.005, variable=f"{phase.id}:0:Size;i")
        gpx.set_Controls("parmMax", 10.0, variable=f"{phase.id}:0:Size;i")
        if args.axis:
            gpx.set_Controls("parmMin", 0.005, variable=f"{phase.id}:0:Size;a")
            gpx.set_Controls("parmMax", 10.0, variable=f"{phase.id}:0:Size;a")
    else:
        hap["Mustrain"][0] = "uniaxial" if args.axis else "isotropic"
        hap["Mustrain"][1][:] = [1.0, 1.0, 1.0]
        hap["Mustrain"][2][:] = [True, bool(args.axis), False]
        if args.axis:
            hap["Mustrain"][3] = list(args.axis)
        gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;i")
        gpx.set_Controls("parmMax", 100000.0, variable=f"{phase.id}:0:Mustrain;i")
        if args.axis:
            gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;a")
            gpx.set_Controls("parmMax", 100000.0, variable=f"{phase.id}:0:Mustrain;a")

    gpx.set_Controls("cycles", 14)
    gpx.data["Controls"]["data"]["shift factor"] = 0.2
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
    gpx.refine()
    gpx.save()
    out = {
        "project": str(args.output),
        "phase": phase.name,
        "kind": args.kind,
        "axis": args.axis,
        "residuals": dict(hist.residuals),
        "fractions": hist.ComputeMassFracs(),
        "frozen": gpx.get_Frozen(),
        "instrument": {k: hist.InstrumentParameters[k][1] for k in ("U", "W", "X", "SH/L")},
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
    }
    print(json.dumps(out, indent=2))
    with args.output.with_suffix(".json").open("w") as handle:
        json.dump(out, handle, indent=2)


if __name__ == "__main__":
    main()
