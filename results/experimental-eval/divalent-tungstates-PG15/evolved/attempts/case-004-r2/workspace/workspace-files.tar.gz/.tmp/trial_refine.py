#!/usr/bin/env python3
"""Run restrained GSAS-II inventory/profile trials on the supplied pattern."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"
TRIALS = TMP / "trials"
DB = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

PHASES = {
    "WO3_mono": (DB / "1/52/89/1528915.cif", "WO3"),
    "WO3_mono_neutron": (DB / "2/31/10/2311041.cif", "WO3_monoclinic_neutron"),
    "WO3_tric": (DB / "2/10/62/2106293.cif", "WO3_triclinic"),
    "WO3_p21m": (DB / "1/01/06/1010618.cif", "WO3_P21m"),
    "CoWO4_como": (TMP / "candidates/CoWO4_from_CoMoO4.cif", "CoWO4"),
    "CoWO4_fewo": (TMP / "candidates/CoWO4_from_FeWO4.cif", "CoWO4"),
    "CoWO4_mnwo": (TMP / "candidates/CoWO4_from_MnWO4.cif", "CoWO4"),
    "Co3O4": (DB / "9/00/58/9005896.cif", "Co3O4"),
    "CoO": (DB / "1/54/16/1541662.cif", "CoO"),
    "WO3_tetra": (DB / "1/52/15/1521532.cif", "WO3_tetragonal"),
}


def make_xye() -> Path:
    out = TMP / "pattern.xye"
    with (ROOT / "inputs/pattern.csv").open() as source, out.open("w") as target:
        for row in csv.DictReader(source):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            target.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    return out


def neutralize_phase_broadening(phase, hist) -> None:
    hap = phase.getHAPvalues(hist)
    # A huge domain size and zero microstrain make unused sample broadening negligible.
    hap["Size"][0] = "isotropic"
    hap["Size"][1][:] = [1000.0, 1000.0, 1.0]
    hap["Size"][2][:] = [False, False, False]
    hap["Size"][5][:] = [False] * len(hap["Size"][5])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][:] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2][:] = [False, False, False]
    hap["Mustrain"][5][:] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"][:] = [0.0, False]
    hap["Babinet"]["BabA"][:] = [0.0, False]
    hap["Babinet"]["BabU"][:] = [0.0, False]


def snapshot(gpx, label: str) -> dict:
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    out = {
        "label": label,
        "residuals": dict(hist.residuals),
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) >= 2},
        "sample_shift": sample["Shift"][0],
        "background": list(hist.Background[0]),
        "phases": {},
        "frozen": gpx.get_Frozen(),
    }
    try:
        fractions = hist.ComputeMassFracs()
    except Exception as exc:
        fractions = {"error": repr(exc)}
    out["mass_fractions"] = fractions
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        out["phases"][phase.name] = {
            "composition": phase.composition,
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cell": phase.get_cell(),
            "density": phase.density,
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    return out


def run_trial(
    name: str,
    phase_keys: list[str],
    profile_terms: list[str],
    fixed_profile: list[float] | None = None,
    fixed_cell_keys: set[str] | None = None,
) -> dict:
    TRIALS.mkdir(parents=True, exist_ok=True)
    gpx_path = TRIALS / f"{name}.gpx"
    gpx = G2sc.G2Project(newgpx=str(gpx_path))
    hist = gpx.add_powder_histogram(
        str(make_xye()), str(TMP / "lab_cuka.instprm"), fmthint="xye"
    )
    hist.Limits("lower", 9.90343322)
    hist.Limits("upper", 100.09488522)
    hist.SampleParameters["Scale"][:] = [1.0, False]
    hist.SampleParameters["Shift"][:] = [0.0, False]
    hist.SampleParameters["Transparency"][:] = [0.0, False]
    hist.SampleParameters["SurfRoughA"][:] = [0.0, False]
    hist.SampleParameters["SurfRoughB"][:] = [0.0, False]
    if fixed_profile is not None:
        for term, value in zip(("U", "W", "X"), fixed_profile):
            hist.InstrumentParameters[term][0] = float(value)
            hist.InstrumentParameters[term][1] = float(value)
            hist.InstrumentParameters[term][2] = False

    phases = []
    phase_key_pairs = []
    used_names: set[str] = set()
    for key in phase_keys:
        path, default_name = PHASES[key]
        phase_name = default_name
        suffix = 2
        while phase_name in used_names:
            phase_name = f"{default_name}_{suffix}"
            suffix += 1
        used_names.add(phase_name)
        phase = gpx.add_phase(
            str(path), phasename=phase_name, histograms=[hist], fmthint="CIF"
        )
        neutralize_phase_broadening(phase, hist)
        phase.getHAPvalues(hist)["Scale"][:] = [1.0, True]
        phases.append(phase)
        phase_key_pairs.append((key, phase))

    gpx.set_Controls("cycles", 8)
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
    gpx.data["Controls"]["data"]["shift factor"] = 0.3
    # Keep scale and common profile terms physical during screening.
    for phase in phases:
        gpx.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
    for term in ("U", "W", "X"):
        gpx.set_Controls("parmMin", 0.0, variable=f":0:{term}")
    gpx.set_Controls("parmMax", 5000.0, variable=":0:U")
    gpx.set_Controls("parmMax", 5000.0, variable=":0:W")
    gpx.set_Controls("parmMax", 200.0, variable=":0:X")

    history = []
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12}}
    )
    gpx.refine()
    history.append(snapshot(gpx, "background_scales"))

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for key, phase in phase_key_pairs:
        if not fixed_cell_keys or key not in fixed_cell_keys:
            phase.set_refinements({"Cell": True})
    gpx.refine()
    history.append(snapshot(gpx, "shift_cells"))

    for term in profile_terms:
        hist.set_refinements({"Instrument Parameters": [term]})
        gpx.refine()
        history.append(snapshot(gpx, f"profile_{'_'.join(profile_terms[:profile_terms.index(term)+1])}"))

    # Re-run all active variables together to remove step-order artifacts.
    gpx.refine()
    history.append(snapshot(gpx, "reconverged"))
    gpx.save()
    final = history[-1]
    summary = {"name": name, "phase_keys": phase_keys, "profile_terms": profile_terms,
               "fixed_profile": fixed_profile,
               "fixed_cell_keys": sorted(fixed_cell_keys or []),
               "gpx": str(gpx_path), "history": history, "final": final}
    with (TRIALS / f"{name}.json").open("w") as handle:
        json.dump(summary, handle, indent=2)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("phases", nargs="+")
    parser.add_argument("--profile", nargs="*", default=["W", "U", "X"])
    parser.add_argument("--fixed-profile", nargs=3, type=float, metavar=("U", "W", "X"))
    parser.add_argument("--fixed-cell", nargs="*", default=[])
    args = parser.parse_args()
    unknown = [key for key in args.phases if key not in PHASES]
    if unknown:
        raise SystemExit(f"Unknown phase keys: {unknown}; choices={sorted(PHASES)}")
    result = run_trial(
        args.name, args.phases, args.profile, args.fixed_profile, set(args.fixed_cell)
    )
    print(json.dumps(result["final"], indent=2))


if __name__ == "__main__":
    main()
