#!/usr/bin/env python3
"""Extract profile arrays and a compact reflection list from a GSAS-II project."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx", type=Path)
    parser.add_argument("outroot", type=Path)
    args = parser.parse_args()
    gpx = G2sc.G2Project(str(args.gpx))
    hist = gpx.histogram(0)
    arrays = [hist.getdata(k) for k in ("X", "Yobs", "Ycalc", "Background", "Residual")]
    with args.outroot.with_suffix(".csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "observed", "calculated", "background", "difference"])
        writer.writerows(zip(*arrays))
    refl_summary = {}
    for name, info in hist.reflections().items():
        refl_summary[name] = {
            "keys": sorted(info),
            "shape": list(info["RefList"].shape),
            "rows": info["RefList"].tolist(),
        }
    with args.outroot.with_suffix(".reflections.json").open("w") as handle:
        json.dump(refl_summary, handle)


if __name__ == "__main__":
    main()
