#!/usr/bin/env python3
from pathlib import Path
import csv
import math

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parents[1]
TMP = ROOT / ".tmp"


def make_xye():
    out = TMP / "pattern.xye"
    with (ROOT / "inputs/pattern.csv").open() as source, out.open("w") as target:
        for row in csv.DictReader(source):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            target.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    return out


def main():
    xye = make_xye()
    gpx_path = TMP / "inspect.gpx"
    gpx = G2sc.G2Project(newgpx=str(gpx_path))
    hist = gpx.add_powder_histogram(str(xye), str(TMP / "lab_cuka.instprm"), fmthint="xye")
    phase = gpx.add_phase(
        "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif",
        phasename="WO3",
        histograms=[hist],
        fmthint="CIF",
    )
    gpx.save()
    print("hist", hist.name)
    print("limits", hist.data["Limits"])
    print("background", hist.Background)
    print("instrument", hist.InstrumentParameters)
    print("sample", hist.SampleParameters)
    print("phase", phase.name, phase.composition, phase.get_cell(), phase.data["General"]["SGData"]["SpGrp"])
    print("HAP")
    for key, val in phase.getHAPvalues(hist).items():
        print(key, repr(val))
    print("controls", gpx.data["Controls"]["data"])


if __name__ == "__main__":
    main()
