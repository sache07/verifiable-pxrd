#!/usr/bin/env python3
"""Test one common profile/intensity correction on a converged baseline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("parameter", choices=("shl", "polarization", "roughness_b"))
    args = parser.parse_args()

    gpx = G2sc.G2Project(str(args.input), newgpx=str(args.output))
    gpx.save()
    gpx.set_Frozen()
    hist = gpx.histogram(0)
    if args.parameter == "shl":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        gpx.set_Controls("parmMin", 0.002, variable=":0:SH/L")
        gpx.set_Controls("parmMax", 0.2, variable=":0:SH/L")
    elif args.parameter == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        gpx.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        gpx.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    else:
        hist.SampleParameters["SurfRoughA"][:] = [0.0, False]
        hist.SampleParameters["SurfRoughB"][:] = [0.001, True]
        gpx.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        gpx.set_Controls("parmMax", 5.0, variable=":0:SurfRoughB")

    gpx.set_Controls("cycles", 16)
    gpx.data["Controls"]["data"]["shift factor"] = 0.2
    gpx.data["Controls"]["data"]["min dM/M"] = 1e-5
    gpx.refine()
    gpx.save()
    out = {
        "project": str(args.output),
        "parameter": args.parameter,
        "residuals": dict(hist.residuals),
        "fractions": hist.ComputeMassFracs(),
        "frozen": gpx.get_Frozen(),
        "instrument": {k: hist.InstrumentParameters[k][1] for k in ("U", "W", "X", "SH/L", "Polariz.")},
        "sample": {k: hist.SampleParameters[k] for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
    }
    print(json.dumps(out, indent=2))
    with args.output.with_suffix(".json").open("w") as handle:
        json.dump(out, handle, indent=2)


if __name__ == "__main__":
    main()
