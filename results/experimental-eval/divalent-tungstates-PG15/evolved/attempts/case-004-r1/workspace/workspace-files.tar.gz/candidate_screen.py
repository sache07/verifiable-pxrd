from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')
OUT = ROOT / '.tmp' / 'candidate_projects'
OUT.mkdir(parents=True, exist_ok=True)


def cod(cid):
    return COD / cid[0] / cid[1:3] / cid[3:5] / f'{cid}.cif'


WO3 = {
    'wo3_p21n_1528915': cod('1528915'),
    'wo3_p21c_2311041': cod('2311041'),
    'wo3_pminus1_2106293': cod('2106293'),
    'wo3_pnma_2107312': cod('2107312'),
    'wo3_p21m_1010618': cod('1010618'),
}

CO_PROTO = {
    'cowo4_como_7205001': (ROOT / 'cowo4_start.cif', {}),
    'cowo4_fewo_1567215': (cod('1567215'), {'Fe': 'Co'}),
    'cowo4_mnwo_1520200': (cod('1520200'), {'Mn': 'Co'}),
    'cowo4_znwo_1520641': (cod('1520641'), {'Zn': 'Co'}),
}


def neutralize(phase, hist):
    hap = phase.getHAPvalues(hist)
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][0] = 10.0
    hap['Size'][2] = [False for _ in hap['Size'][2]]
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][0] = 0.0
    hap['Mustrain'][2] = [False for _ in hap['Mustrain'][2]]
    hap['Pref.Ori.'][0:3] = ['MD', 1.0, False]
    hap['Extinction'] = [0.0, False]
    hap['Babinet'] = {'BabA': [0.0, False], 'BabU': [0.0, False]}


def add_phase(gpx, hist, path, name, substitutions=None):
    phase = gpx.add_phase(str(path), phasename=name, histograms=[hist], fmthint='CIF')
    if substitutions:
        for atom in phase.atoms():
            if atom.element in substitutions:
                old = atom.element
                atom.type = substitutions[old]
                atom.label = atom.label.replace(old, substitutions[old])
        G2sc.SetupGeneral(phase.data, None)
    neutralize(phase, hist)
    return phase


def run(tag, wo3_path, co_path, substitutions):
    gpx = G2sc.G2Project(newgpx=str(OUT / f'{tag}.gpx'))
    hist = gpx.add_powder_histogram(str(ROOT / 'pattern.xye'), str(ROOT / 'instrument.instprm'), fmthint='xye')
    hist.Limits('lower', 9.91)
    hist.Limits('upper', 100.09)
    wo3 = add_phase(gpx, hist, wo3_path, 'WO3')
    co = add_phase(gpx, hist, co_path, 'CoWO4', substitutions)

    hist.SampleParameters['Scale'] = [1.0, False]
    for key in ('Shift', 'Transparency', 'SurfRoughA', 'SurfRoughB'):
        if key in hist.SampleParameters:
            hist.SampleParameters[key] = [0.0, False]
    inst = hist.InstrumentParameters
    for key, value in [('Zero', 0.05), ('U', 0.0), ('V', 0.0), ('W', 59.64),
                       ('X', 14.12), ('Y', 0.0), ('Z', 0.0), ('SH/L', 0.002)]:
        inst[key][0] = value
        inst[key][1] = value
        inst[key][2] = (key == 'Zero')

    coeffs = [868.93, -434.94, 444.53, -275.17, 125.31, -57.69]
    hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 6,
                                         'coeffs': coeffs, 'refine': True}})
    wo3.getHAPvalues(hist)['Scale'] = [6.46, True]
    co.getHAPvalues(hist)['Scale'] = [9.55, True]
    wo3.set_refinements({'Cell': True})
    co.set_refinements({'Cell': True})
    gpx.set_Controls('cycles', 10)
    gpx.refine()
    gpx.save()
    result = {
        'tag': tag,
        'Rwp_percent': hist.residuals.get('wR'),
        'Rp_percent': hist.residuals.get('R'),
        'GOF': gpx.data.get('Covariance', {}).get('data', {}).get('Rvals', {}).get('GOF'),
        'mass_fractions': {k: v[0] for k, v in hist.ComputeMassFracs().items()},
        'zero': inst['Zero'][1],
        'WO3_cell': wo3.get_cell(),
        'CoWO4_cell': co.get_cell(),
        'WO3_composition': wo3.composition,
        'CoWO4_composition': co.composition,
    }
    print('CANDIDATE_RESULT', json.dumps(result, sort_keys=True))
    return result


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else 'wo3'
    results = []
    if mode == 'wo3':
        co_path, substitutions = CO_PROTO['cowo4_como_7205001']
        for name, wo3_path in WO3.items():
            results.append(run(name, wo3_path, co_path, substitutions))
    elif mode == 'co':
        wo3_path = WO3['wo3_p21n_1528915']
        for name, (co_path, substitutions) in CO_PROTO.items():
            results.append(run(name, wo3_path, co_path, substitutions))
    else:
        raise SystemExit('mode must be wo3 or co')
    (OUT / f'{mode}_results.json').write_text(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
