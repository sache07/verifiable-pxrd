from pathlib import Path
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
gpx = G2sc.G2Project(str(ROOT / 'probe.gpx'), newgpx=str(ROOT / 'baseline.gpx'))
hist = gpx.histogram(0)

# Remove the redundant specimen scale and preserve the products phase_scale*sample_scale.
sample_scale = hist.SampleParameters['Scale'][0]
for phase in gpx.phases():
    phase.getHAPvalues(hist)['Scale'][0] *= sample_scale
hist.SampleParameters['Scale'] = [1.0, False]

# Replay with a nonnegative, low-dimensional common W/X profile. The attempted
# U term was negative, so it is pruned at the physical boundary U=0.
inst = hist.InstrumentParameters
inst['U'][:] = [0.0, 0.0, False]
inst['W'][1] = max(1.0, inst['W'][1])
inst['W'][2] = True
inst['X'][1] = max(0.0, inst['X'][1])
inst['X'][2] = True
for key in ('V', 'Y', 'Z'):
    inst[key][:] = [0.0, 0.0, False]

gpx.set_Controls('cycles', 12)
gpx.save()
gpx.set_Controls('parmMin', 0.0, variable=':0:W')
gpx.set_Controls('parmMin', 0.0, variable=':0:X')
gpx.refine()
gpx.save()

print('residuals', hist.residuals)
print('mass fractions', hist.ComputeMassFracs())
print('instrument', {k: inst[k] for k in ('Zero','Polariz.','U','V','W','X','Y','Z','SH/L')})
print('sample scale', hist.SampleParameters['Scale'])
for phase in gpx.phases():
    print(phase.name, phase.get_cell(), phase.getHAPvalues(hist)['Scale'])
