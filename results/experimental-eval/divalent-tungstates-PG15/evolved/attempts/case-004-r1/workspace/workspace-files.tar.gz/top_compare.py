from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
DIR = ROOT / '.tmp' / 'candidate_projects'

for tag in ('wo3_p21c_2311041', 'wo3_pminus1_2106293'):
    gpx = G2sc.G2Project(str(DIR / f'{tag}.gpx'), newgpx=str(DIR / f'{tag}_profile.gpx'))
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    inst['U'][:] = [0.0, 0.0, False]
    for key in ('W', 'X'):
        inst[key][2] = True
    gpx.set_Controls('cycles', 12)
    gpx.save()
    gpx.set_Controls('parmMin', 0.0, variable=':0:W')
    gpx.set_Controls('parmMin', 0.0, variable=':0:X')
    gpx.refine()
    gpx.save()
    print('TOP_RESULT', json.dumps({
        'tag': tag,
        'Rwp_percent': hist.residuals.get('wR'),
        'Rp_percent': hist.residuals.get('R'),
        'GOF': gpx.data['Covariance']['data']['Rvals'].get('GOF'),
        'mass_fractions': {k: v[0] for k, v in hist.ComputeMassFracs().items()},
        'profile': {k: inst[k][1] for k in ('U','V','W','X','Y','Z')},
        'zero': inst['Zero'][1],
        'WO3_cell': gpx.phase('WO3').get_cell(),
        'CoWO4_cell': gpx.phase('CoWO4').get_cell(),
    }, sort_keys=True))
