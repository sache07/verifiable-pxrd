from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
BASE = ROOT / '.tmp' / 'candidate_projects' / 'profile_strain_joint.gpx'
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cod(cid):
    return COD / cid[0] / cid[1:3] / cid[3:5] / f'{cid}.cif'


CANDIDATES = {
    'WO2_1548686': '1548686',
    'W18O49_1528166': '1528166',
    'W10O29_1538317': '1538317',
    'W17O47_2107065': '2107065',
    'W3O8_2101050': '2101050',
    'W3O10_9014468': '9014468',
}


for name, cid in CANDIDATES.items():
    try:
        gpx = G2sc.G2Project(str(BASE), newgpx=str(ROOT / '.tmp' / 'candidate_projects' / f'watch_{name}.gpx'))
        hist = gpx.histogram(0)
        hist.Background[0][1] = False
        for key in ('Shift','Transparency','SurfRoughA','SurfRoughB'):
            if key in hist.SampleParameters:
                hist.SampleParameters[key][1] = False
        for value in hist.InstrumentParameters.values():
            if isinstance(value, list) and len(value) > 2:
                value[2] = False
        for oldphase in gpx.phases():
            oldphase.set_refinements({'Cell': False})
            hap0 = oldphase.getHAPvalues(hist)
            hap0['Scale'][1] = False
            hap0['Mustrain'][2] = [False for _ in hap0['Mustrain'][2]]
        phase = gpx.add_phase(str(cod(cid)), phasename=name, histograms=[hist], fmthint='CIF')
        hap = phase.getHAPvalues(hist)
        hap['Scale'] = [0.1, True]
        hap['Size'][0] = 'isotropic'; hap['Size'][1][0] = 10.0
        hap['Size'][2] = [False for _ in hap['Size'][2]]
        hap['Mustrain'][0] = 'isotropic'; hap['Mustrain'][1][0] = 0.0
        hap['Mustrain'][2] = [False for _ in hap['Mustrain'][2]]
        hap['Pref.Ori.'][0:3] = ['MD', 1.0, False]
        gpx.set_Controls('cycles', 6)
        gpx.refine()
        gpx.save()
        cov = gpx.data.get('Covariance', {}).get('data', {})
        sig = dict(zip(cov.get('varyList', []), cov.get('sig', [])))
        print('W_WATCH_RESULT', json.dumps({
            'candidate': name,
            'composition': phase.composition,
            'Rwp_percent': hist.residuals.get('wR'),
            'scale': hap['Scale'][0],
            'scale_esd': sig.get('2:0:Scale'),
            'mass_fractions': hist.ComputeMassFracs(),
        }, sort_keys=True))
    except Exception as exc:
        print('W_WATCH_RESULT', json.dumps({'candidate': name, 'error': repr(exc)}, sort_keys=True))
