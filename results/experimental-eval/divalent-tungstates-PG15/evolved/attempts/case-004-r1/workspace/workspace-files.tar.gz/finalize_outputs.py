from pathlib import Path
import csv
import json
import math
import numpy as np

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / '.tmp' / 'candidate_projects' / 'fullrange.gpx'
FINAL = ROOT / 'final.gpx'


def array(hist, name):
    return np.asarray(hist.getdata(name), dtype=float)


# Save the accepted project under its submitted name, then reopen it before
# producing every submitted numerical/structural artifact.
project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
project.save()
project = G2sc.G2Project(str(FINAL))
hist = project.histogram(0)

phase_files = {
    'WO3': ROOT / 'phase_wo3_triclinic.cif',
    'CoWO4': ROOT / 'phase_cowo4_wolframite.cif',
}
for phase_name, path in phase_files.items():
    project.phase(phase_name).export_CIF(str(path))

x = array(hist, 'X')
yobs = array(hist, 'Yobs')
ycalc = array(hist, 'Ycalc')
ybkg = array(hist, 'Background')
ydiff = array(hist, 'Residual')

with (ROOT / 'fit.csv').open('w', newline='') as stream:
    writer = csv.writer(stream)
    writer.writerow(['two_theta_deg', 'observed', 'calculated', 'difference', 'background'])
    for row in zip(x, yobs, ycalc, ydiff, ybkg):
        writer.writerow([f'{row[0]:.8f}', *(f'{value:.8f}' for value in row[1:])])

fractions = hist.ComputeMassFracs()
residuals = hist.residuals
cov = project.data['Covariance']['data']
rvals = cov['Rvals']

phase_specs = [
    ('WO3', 'Tungsten(VI) oxide, triclinic', 'WO3', 'P -1', 'phase_wo3_triclinic.cif', 0),
    ('CoWO4', 'Cobalt(II) tungstate, wolframite', 'CoWO4', 'P 2/c', 'phase_cowo4_wolframite.cif', 1),
]
phases = []
for key, name, formula, space_group, cif_path, pid in phase_specs:
    value, esd = fractions[key]
    phases.append({
        'name': name,
        'formula': formula,
        'space_group': space_group,
        'cif_path': cif_path,
        'weight_fraction': value,
        'weight_fraction_esd': esd,
        'cell': project.phase(key).get_cell(),
        'phase_Rf_percent': residuals.get(f'{pid}:0:Rf'),
        'phase_Rf_squared_percent': residuals.get(f'{pid}:0:Rf^2'),
    })

gof = float(rvals['GOF'])
result = {
    'phases': phases,
    'fit_statistics': {
        'Rp_percent': residuals['R'],
        'Rwp_percent': residuals['wR'],
        'Rexp_percent': residuals['wRmin'],
        'goodness_of_fit': gof,
        'reduced_chi_square': gof * gof,
        'chi_square': float(rvals['chisq']),
        'n_observations': int(rvals['Nobs']),
        'n_refined_parameters_last_cycle': int(rvals['Nvars']),
        'background_R_percent': residuals['Rb'],
        'weighted_background_R_percent': residuals['wRb'],
    },
    'measurement_range_two_theta_deg': [float(x[0]), float(x[-1])],
    'profile_points': int(len(x)),
    'weighting': 'Poisson counting estimate, weight = 1 / observed intensity; pointwise uncertainties were not supplied',
    'fractions_normalized_over_modeled_crystalline_phases': True,
}
with (ROOT / 'result.json').open('w') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')

# Required save/reopen/full-range replay check is performed on a disposable
# copy so final.gpx retains the covariance matrix from the reported fraction fit.
replay_path = ROOT / '.tmp' / 'final_replay.gpx'
replay = G2sc.G2Project(str(FINAL), newgpx=str(replay_path))
replay.set_Controls('cycles', 0)
replay.refine()
replay.save()
replay_hist = replay.histogram(0)
replay_ycalc = array(replay_hist, 'Ycalc')

verification = {
    'final_project_reopened': True,
    'full_range_replayed': [replay_hist.Limits('lower'), replay_hist.Limits('upper')],
    'profile_points': int(len(replay_ycalc)),
    'max_abs_ycalc_change_after_replay': float(np.max(np.abs(replay_ycalc - ycalc))),
    'rwp_before_replay': float(residuals['wR']),
    'rwp_after_replay': float(replay_hist.residuals['wR']),
    'fraction_sum': float(sum(item['weight_fraction'] for item in phases)),
    'max_abs_residual_identity_error': float(np.max(np.abs((yobs - ycalc) - ydiff))),
}
with (ROOT / '.tmp' / 'final_verification.json').open('w') as stream:
    json.dump(verification, stream, indent=2)
    stream.write('\n')

print(json.dumps({'result': result, 'verification': verification}, indent=2))
