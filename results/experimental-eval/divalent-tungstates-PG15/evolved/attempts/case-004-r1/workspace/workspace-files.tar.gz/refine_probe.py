from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
WO3_CIF = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/52/89/1528915.cif')


def state(gpx, label):
    hist = gpx.histogram(0)
    print(f'\n--- {label} ---')
    print('residuals', hist.residuals)
    print('instrument', {k: v for k, v in hist.InstrumentParameters.items()
                         if k in ('Zero', 'U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L', 'I(L2)/I(L1)', 'Polariz.')})
    print('background', hist.Background[0])
    print('sample', hist.SampleParameters)
    for phase in gpx.phases():
        hap = phase.getHAPvalues(hist)
        print(phase.name, 'cell', phase.get_cell(), 'composition', phase.composition,
              'density', phase.density, 'scale', hap['Scale'],
              'size', hap['Size'], 'mustrain', hap['Mustrain'],
              'prefori', hap['Pref.Ori.'])
    try:
        print('mass fractions', hist.ComputeMassFracs())
    except Exception as exc:
        print('mass fractions failed', repr(exc))


def main():
    out = ROOT / 'probe.gpx'
    gpx = G2sc.G2Project(newgpx=str(out))
    hist = gpx.add_powder_histogram(str(ROOT / 'pattern.xye'), str(ROOT / 'instrument.instprm'), fmthint='xye')
    hist.Limits('lower', 9.91)
    hist.Limits('upper', 100.09)
    wo3 = gpx.add_phase(str(WO3_CIF), phasename='WO3_gamma', histograms=[hist], fmthint='CIF')
    cowo4 = gpx.add_phase(str(ROOT / 'cowo4_start.cif'), phasename='CoWO4_wolframite', histograms=[hist], fmthint='CIF')

    coeffs = [842.17, -336.81, 355.072, -190.686, 69.9491, -21.2141]
    hist.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 6,
                                         'coeffs': coeffs, 'refine': True}})
    wo3.getHAPvalues(hist)['Scale'][0] = 0.5
    cowo4.getHAPvalues(hist)['Scale'][0] = 0.2
    wo3.set_HAP_refinements({'Scale': True}, [hist])
    cowo4.set_HAP_refinements({'Scale': True}, [hist])

    # Explicitly neutralize phase-specific profile, texture and roughness terms.
    for phase in (wo3, cowo4):
        hap = phase.getHAPvalues(hist)
        hap['Size'][0] = 'isotropic'
        hap['Size'][1][0] = 1.0e6
        hap['Size'][2] = [False for _ in hap['Size'][2]]
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = 0.0
        hap['Mustrain'][2] = [False for _ in hap['Mustrain'][2]]
        hap['Pref.Ori.'][0] = 'MD'
        hap['Pref.Ori.'][1] = 1.0
        hap['Pref.Ori.'][2] = False
        hap['Extinction'] = [0.0, False]
        hap['Babinet'] = {'BabA': [0.0, False], 'BabU': [0.0, False]}
    for key in ('Shift', 'Transparency', 'SurfRoughA', 'SurfRoughB'):
        if key in hist.SampleParameters:
            hist.SampleParameters[key][0] = 0.0
            hist.SampleParameters[key][1] = False

    gpx.set_Controls('cycles', 8)
    gpx.save()
    state(gpx, 'initial')

    gpx.refine()
    state(gpx, 'background + scales')

    # One angular correction, then cell metrics.
    hist.set_refinements({'Instrument Parameters': ['Zero']})
    wo3.set_refinements({'Cell': True})
    cowo4.set_refinements({'Cell': True})
    gpx.refine()
    state(gpx, 'background + scales + zero + cells')

    # Common low-dimensional profile; V, Y and Z remain fixed at zero.
    hist.set_refinements({'Instrument Parameters': ['U', 'W', 'X']})
    gpx.refine()
    state(gpx, 'common U/W/X profile')
    gpx.save()


if __name__ == '__main__':
    main()
