from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
BASE = ROOT / '.tmp' / 'candidate_projects' / 'profile_strain_joint.gpx'
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cod(cid):
    return COD / cid[0] / cid[1:3] / cid[3:5] / f'{cid}.cif'


for name, cid in {'CoO': '1541662', 'Co3O4': '9005896'}.items():
    out = ROOT / '.tmp' / 'candidate_projects' / f'watch_scale_{name}.gpx'
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    # Freeze the established nuisance model and inventory before probing only
    # the added record's scale.
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for oldphase in gpx.phases():
        oldphase.set_refinements({'Cell': False})
        oldphase.getHAPvalues(hist)['Scale'][1] = False

    phase = gpx.add_phase(str(cod(cid)), phasename=name, histograms=[hist], fmthint='CIF')
    hap = phase.getHAPvalues(hist)
    hap['Scale'] = [0.1, True]
    hap['Size'][0] = 'isotropic'; hap['Size'][1][0] = 10.0
    hap['Size'][2] = [False for _ in hap['Size'][2]]
    hap['Mustrain'][0] = 'isotropic'; hap['Mustrain'][1][0] = 0.0
    hap['Mustrain'][2] = [False for _ in hap['Mustrain'][2]]
    hap['Pref.Ori.'][0:3] = ['MD', 1.0, False]
    gpx.set_Controls('cycles', 5)
    gpx.refine()
    gpx.save()
    cov = gpx.data['Covariance']['data']
    sig = dict(zip(cov.get('varyList', []), cov.get('sig', [])))
    print('WATCH_SCALE_RESULT', json.dumps({
        'candidate': name,
        'Rwp_percent': hist.residuals.get('wR'),
        'scale': hap['Scale'][0],
        'scale_esd': sig.get('2:0:Scale'),
        'mass_fractions': hist.ComputeMassFracs(),
        'cell': phase.get_cell(),
    }, sort_keys=True))
