from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
BASE = ROOT / '.tmp' / 'candidate_projects' / 'wo3_pminus1_2106293_profile.gpx'
COD = Path('<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif')


def cod(cid):
    return COD / cid[0] / cid[1:3] / cid[3:5] / f'{cid}.cif'


CANDIDATES = {
    'CoO': cod('1541662'),
    'Co3O4': cod('9005896'),
}


def neutralize(phase, hist):
    hap = phase.getHAPvalues(hist)
    hap['Scale'] = [0.1, True]
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][0] = 10.0
    hap['Size'][2] = [False for _ in hap['Size'][2]]
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][0] = 0.0
    hap['Mustrain'][2] = [False for _ in hap['Mustrain'][2]]
    hap['Pref.Ori.'][0:3] = ['MD', 1.0, False]
    hap['Extinction'] = [0.0, False]
    hap['Babinet'] = {'BabA': [0.0, False], 'BabU': [0.0, False]}


for name, path in CANDIDATES.items():
    out = ROOT / '.tmp' / 'candidate_projects' / f'watch_{name}.gpx'
    gpx = G2sc.G2Project(str(BASE), newgpx=str(out))
    hist = gpx.histogram(0)
    phase = gpx.add_phase(str(path), phasename=name, histograms=[hist], fmthint='CIF')
    neutralize(phase, hist)
    gpx.set_Controls('cycles', 12)
    gpx.refine()
    stage1 = {
        'Rwp_percent': hist.residuals.get('wR'),
        'scale': phase.getHAPvalues(hist)['Scale'][0],
        'mass_fractions': {k: v[0] for k, v in hist.ComputeMassFracs().items()},
        'cell': phase.get_cell(),
    }
    # Only a physically positive candidate is allowed a cell refinement trial.
    if stage1['scale'] > 0:
        phase.set_refinements({'Cell': True})
        gpx.refine()
    gpx.save()
    result = {
        'candidate': name,
        'composition': phase.composition,
        'density': phase.density,
        'scale_before_cell': stage1,
        'Rwp_percent_final': hist.residuals.get('wR'),
        'scale_final': phase.getHAPvalues(hist)['Scale'][0],
        'mass_fractions_final': {k: v[0] for k, v in hist.ComputeMassFracs().items()},
        'cell_final': phase.get_cell(),
    }
    print('WATCH_RESULT', json.dumps(result, sort_keys=True))
