from pathlib import Path
import json
import sys
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
BASE = ROOT / '.tmp' / 'candidate_projects' / 'rough_profile.gpx'
OUT = ROOT / '.tmp' / 'candidate_projects'


def freeze(gpx):
    hist = gpx.histogram(0)
    hist.Background[0][1] = False
    for key in ('Shift','Transparency','SurfRoughA','SurfRoughB'):
        if key in hist.SampleParameters:
            hist.SampleParameters[key][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in gpx.phases():
        phase.set_refinements({'Cell': False})
        hap = phase.getHAPvalues(hist)
        hap['Scale'][1] = False
        hap['Size'][2] = [False for _ in hap['Size'][2]]
        hap['Size'][5] = [False for _ in hap['Size'][5]]
        hap['Mustrain'][2] = [False for _ in hap['Mustrain'][2]]
        hap['Mustrain'][5] = [False for _ in hap['Mustrain'][5]]
    return hist


def run(phase_name, kind, start):
    tag = f'{phase_name}_{kind}_{start:g}'.replace('.','p')
    gpx = G2sc.G2Project(str(BASE), newgpx=str(OUT / f'broad_{tag}.gpx'))
    hist = freeze(gpx)
    phase = gpx.phase(phase_name)
    hap = phase.getHAPvalues(hist)
    if kind == 'size':
        hap['Size'][0] = 'isotropic'
        hap['Size'][1][0] = float(start)
        hap['Size'][2][0] = True
    elif kind == 'strain':
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = float(start)
        hap['Mustrain'][2][0] = True
    else:
        raise ValueError(kind)
    gpx.set_Controls('cycles', 12)
    gpx.refine()
    gpx.save()
    cov = gpx.data['Covariance']['data']
    result = {
        'phase': phase_name,
        'kind': kind,
        'start': start,
        'Rwp_percent': hist.residuals.get('wR'),
        'GOF': cov.get('Rvals', {}).get('GOF'),
        'size': hap['Size'],
        'mustrain': hap['Mustrain'],
        'varyList': cov.get('varyList', []),
        'sig': cov.get('sig', []).tolist() if hasattr(cov.get('sig', []), 'tolist') else cov.get('sig', []),
    }
    print('BROAD_RESULT', json.dumps(result, sort_keys=True))


def main():
    for phase in ('WO3','CoWO4'):
        for start in (0.05, 0.2, 1.0):
            run(phase, 'size', start)
        for start in (200.0, 1000.0, 3000.0):
            run(phase, 'strain', start)


if __name__ == '__main__':
    main()
