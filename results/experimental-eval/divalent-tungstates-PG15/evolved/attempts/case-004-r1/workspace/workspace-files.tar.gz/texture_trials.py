from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc

ROOT = Path(__file__).resolve().parent
BASE = ROOT / '.tmp' / 'candidate_projects' / 'profile_strain_joint.gpx'
OUT = ROOT / '.tmp' / 'candidate_projects'
DIRECTIONS = ([1,0,0], [0,1,0], [0,0,1], [1,1,0], [1,0,1], [0,1,1], [1,1,1])


def freeze(gpx):
    hist = gpx.histogram(0)
    hist.Background[0][1] = False
    for key in ('Shift','Transparency','SurfRoughA','SurfRoughB'):
        if key in hist.SampleParameters:
            hist.SampleParameters[key][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in gpx.phases():
        phase.set_refinements({'Cell': False})
        hap = phase.getHAPvalues(hist)
        hap['Scale'][1] = False
        hap['Size'][2] = [False for _ in hap['Size'][2]]
        hap['Mustrain'][2] = [False for _ in hap['Mustrain'][2]]
        hap['Pref.Ori.'][2] = False
    return hist


for phase_name in ('WO3','CoWO4'):
    for direction in DIRECTIONS:
        dtag = ''.join(str(x) for x in direction)
        gpx = G2sc.G2Project(str(BASE), newgpx=str(OUT / f'texture_{phase_name}_{dtag}.gpx'))
        hist = freeze(gpx)
        phase = gpx.phase(phase_name)
        po = phase.getHAPvalues(hist)['Pref.Ori.']
        po[0] = 'MD'; po[1] = 1.0; po[2] = True; po[3] = list(direction)
        gpx.set_Controls('cycles', 8)
        gpx.refine()
        gpx.save()
        cov = gpx.data['Covariance']['data']
        result = {
            'phase': phase_name,
            'direction': direction,
            'Rwp_percent': hist.residuals.get('wR'),
            'MD': po[1],
            'varyList': cov.get('varyList', []),
            'sig': cov.get('sig', []).tolist() if hasattr(cov.get('sig', []), 'tolist') else cov.get('sig', []),
            'GOF': cov.get('Rvals', {}).get('GOF'),
        }
        print('TEXTURE_RESULT', json.dumps(result, sort_keys=True))
