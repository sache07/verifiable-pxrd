#!/usr/bin/env python3
"""Challenge a candidate phase against an already converged common model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import GSASII.GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_hap(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Scale"] = [0.05, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("cod_id")
    parser.add_argument("name")
    parser.add_argument("output")
    parser.add_argument("--cell", action="store_true")
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(gpxfile=args.input, newgpx=args.output)
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    project.data["Controls"]["data"]["shift factor"] = 0.25
    histogram = project.histogram(0)
    phase = project.add_phase(
        str(cod_path(args.cod_id)),
        phasename=args.name,
        histograms=[histogram],
        fmthint="CIF",
    )
    neutralize_hap(phase, histogram.name)
    phase_index = len(project.phases()) - 1
    project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Scale")
    if args.cell:
        phase.set_refinements({"Cell": True})

    project.save()
    project.refine(makeBack=False)
    project.save()

    vary = project.data["Covariance"]["data"].get("varyList", [])
    vals = project.data["Covariance"]["data"].get("variables", [])
    sigs = project.data["Covariance"]["data"].get("sig", [])
    parameter = f"{phase_index}:0:Scale"
    scale_result = next(
        (
            {"value": value, "esd": esd}
            for var, value, esd in zip(vary, vals, sigs)
            if str(var) == parameter
        ),
        None,
    )
    print(
        json.dumps(
            {
                "candidate": args.name,
                "cod_id": args.cod_id,
                "cell_refined": args.cell,
                "residuals": histogram.residuals,
                "mass_fractions": histogram.ComputeMassFracs(),
                "candidate_scale": scale_result,
                "candidate_cell": phase.get_cell(),
                "frozen": project.get_Frozen(),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
