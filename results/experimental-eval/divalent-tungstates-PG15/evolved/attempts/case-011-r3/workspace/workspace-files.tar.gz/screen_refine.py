#!/usr/bin/env python3
"""Apply one restrained GSAS-II screening refinement to a candidate phase pair."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import GSASII.GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def neutralize_hap(phase, histogram_name: str) -> None:
    hap = phase.data["Histograms"][histogram_name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1] = [10.0, 10.0, 1.0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1] = [0.0, 0.0, 1.0]
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    hap["Babinet"] = {"BabA": [0.0, False], "BabU": [0.0, False]}


def refine(project) -> None:
    project.save()
    project.refine(makeBack=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("mn_id")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(newgpx=str(args.output))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    wo3 = project.add_phase(
        str(cod_path(args.wo3_id)),
        phasename=f"WO3_{args.wo3_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    mno2 = project.add_phase(
        str(cod_path(args.mn_id)),
        phasename=f"MnO2_{args.mn_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    project.set_Controls("cycles", 15)

    for phase in project.phases():
        neutralize_hap(phase, hist.name)

    # Keep the overall and relative scales nondegenerate. The weak-phase scale is
    # released only after background, overall scale and specimen shift settle.
    hist.data["Sample Parameters"]["Scale"] = [8.0, True]
    hist.data["Sample Parameters"]["Shift"] = [-530.0, True]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    wo3.data["Histograms"][hist.name]["Scale"] = [1.0, False]
    mno2.data["Histograms"][hist.name]["Scale"] = [4.5, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "refine": True,
            }
        }
    )
    refine(project)

    mno2.data["Histograms"][hist.name]["Scale"][1] = True
    refine(project)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project)

    # W is fixed at its physical lower limit after unconstrained trials placed it
    # infinitesimally below zero. U and X supply the common Gaussian/Lorentzian
    # width dependence without a bound parameter in the final comparison.
    inst = hist.data["Instrument Parameters"][0]
    inst["W"] = [0.0, 0.0, False]
    hist.set_refinements({"Instrument Parameters": ["U", "X"]})
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMin", 0.0, variable=":0:X")
    refine(project)

    project.save()
    summary = {
        "wo3_id": args.wo3_id,
        "mn_id": args.mn_id,
        "project": str(args.output),
        "residuals": hist.residuals,
        "sample": {
            "scale": hist.data["Sample Parameters"]["Scale"][0],
            "shift_micrometres": hist.data["Sample Parameters"]["Shift"][0],
        },
        "profile": {
            key: inst[key][1] for key in ("U", "V", "W", "X", "Y", "SH/L")
        },
        "phases": {
            phase.name: {
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "cell": phase.get_cell(),
            }
            for phase in project.phases()
        },
    }
    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
