#!/usr/bin/env python3
"""Report whether a weak candidate is supported by distinct residual families."""

from __future__ import annotations

import argparse
import json

import numpy as np
import GSASII.GSASIIscriptable as G2sc


def reflection_rows(histogram, phase_name: str) -> list[dict]:
    refs = histogram.data["Reflection Lists"][phase_name]["RefList"]
    intensities = np.maximum(0.0, refs[:, 9] * refs[:, 11])
    maximum = float(np.max(intensities)) if len(intensities) else 0.0
    rows = []
    for ref, intensity in zip(refs, intensities):
        rows.append(
            {
                "hkl": [int(round(value)) for value in ref[:3]],
                "position": float(ref[5]),
                "relative_intensity": float(100.0 * intensity / maximum)
                if maximum
                else 0.0,
            }
        )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline")
    parser.add_argument("challenge")
    parser.add_argument("candidate")
    parser.add_argument("--lines", type=int, default=15)
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    base_project = G2sc.G2Project(args.baseline)
    trial_project = G2sc.G2Project(args.challenge)
    base_hist = base_project.histogram(0)
    trial_hist = trial_project.histogram(0)
    x, y, w, base_calc, _, _ = [np.asarray(v) for v in base_hist.data["data"][1]]
    trial_calc = np.asarray(trial_hist.data["data"][1][3])

    main_rows = []
    for phase in base_project.phases():
        main_rows.extend(reflection_rows(base_hist, phase.name))
    main_strong = [row for row in main_rows if row["relative_intensity"] >= 2.0]

    candidate_rows = sorted(
        reflection_rows(trial_hist, args.candidate),
        key=lambda row: row["relative_intensity"],
        reverse=True,
    )
    selected = []
    for row in candidate_rows:
        if row["relative_intensity"] < 1.0:
            continue
        if any(abs(row["position"] - old["position"]) < 0.08 for old in selected):
            continue
        selected.append(row)
        if len(selected) == args.lines:
            break

    for row in selected:
        position = row["position"]
        nearest = min(main_strong, key=lambda item: abs(item["position"] - position))
        mask = np.abs(x - position) <= 0.18
        base_sse = float(np.sum(w[mask] * (y[mask] - base_calc[mask]) ** 2))
        trial_sse = float(np.sum(w[mask] * (y[mask] - trial_calc[mask]) ** 2))
        index = int(np.argmin(np.abs(x - position)))
        row.update(
            {
                "nearest_main_distance": abs(nearest["position"] - position),
                "nearest_main_phase_hkl": nearest["hkl"],
                "baseline_residual_at_line": float(y[index] - base_calc[index]),
                "local_weighted_sse_change": trial_sse - base_sse,
            }
        )

    print(
        json.dumps(
            {
                "candidate": args.candidate,
                "baseline_rwp": base_hist.residuals.get("wR"),
                "trial_rwp": trial_hist.residuals.get("wR"),
                "lines": selected,
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
