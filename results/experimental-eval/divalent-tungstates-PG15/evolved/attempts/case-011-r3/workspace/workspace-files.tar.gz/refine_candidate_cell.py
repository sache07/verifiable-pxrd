#!/usr/bin/env python3
"""Release a candidate cell only after its scale-only screening pass."""

from __future__ import annotations

import argparse
import json

import GSASII.GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(gpxfile=args.input, newgpx=args.output)
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    project.data["Controls"]["data"]["shift factor"] = 0.25
    phase = project.phase(len(project.phases()) - 1)
    phase.set_refinements({"Cell": True})
    project.save()
    project.refine(makeBack=False)
    project.save()
    histogram = project.histogram(0)
    print(
        json.dumps(
            {
                "candidate": phase.name,
                "residuals": histogram.residuals,
                "mass_fractions": histogram.ComputeMassFracs(),
                "candidate_cell": phase.get_cell_and_esd(),
                "candidate_scale": phase.data["Histograms"][histogram.name]["Scale"],
                "frozen": project.get_Frozen(),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
