#!/usr/bin/env python3
"""Reversible removal of a selected phase-profile term."""

from __future__ import annotations

import argparse
import json

import GSASII.GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("mode", choices=("texture", "strain_anisotropy"))
    parser.add_argument("phase", type=int)
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(gpxfile=args.input, newgpx=args.output)
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    project.data["Controls"]["data"]["shift factor"] = 0.25
    histogram = project.histogram(0)
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][histogram.name]

    if args.mode == "texture":
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    else:
        start = sum(hap["Mustrain"][1][:2]) / 2.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1] = [start, start, 1.0]
        hap["Mustrain"][2] = [True, False, False]

    project.save()
    project.refine(makeBack=False)
    project.save()
    print(
        json.dumps(
            {
                "mode": args.mode,
                "phase": phase.name,
                "residuals": histogram.residuals,
                "mass_fractions": histogram.ComputeMassFracs(),
                "hap": {
                    "strain": hap["Mustrain"],
                    "texture": hap["Pref.Ori."],
                },
                "frozen": project.get_Frozen(),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
