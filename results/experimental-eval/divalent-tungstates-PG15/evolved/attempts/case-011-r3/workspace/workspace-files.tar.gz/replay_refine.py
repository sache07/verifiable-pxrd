#!/usr/bin/env python3
"""Save, reopen and replay a GSAS-II refinement over the full range."""

from __future__ import annotations

import argparse
import json

import GSASII.GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("--passes", type=int, default=3)
    parser.add_argument("--shift-factor", type=float, default=1.0)
    args = parser.parse_args()
    G2sc.SetPrintLevel("warn")

    history = []
    for index in range(args.passes):
        project = G2sc.G2Project(args.project)
        project.set_Controls("cycles", 25)
        project.data["Controls"]["data"]["shift factor"] = args.shift_factor
        project.save()
        project.refine(makeBack=False)
        project.save()
        hist = project.histogram(0)
        history.append(
            {
                "pass": index + 1,
                "wR": hist.residuals.get("wR"),
                "R": hist.residuals.get("R"),
                "mass_fractions": hist.ComputeMassFracs(),
                "profile": {
                    key: hist.data["Instrument Parameters"][0][key][1]
                    for key in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")
                },
                "hap": {
                    phase.name: {
                        "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                        "size": phase.data["Histograms"][hist.name]["Size"][1],
                        "strain": phase.data["Histograms"][hist.name]["Mustrain"][1],
                        "texture": phase.data["Histograms"][hist.name]["Pref.Ori."][1:4],
                    }
                    for phase in project.phases()
                },
            }
        )
        del hist, project

    print(json.dumps(history, sort_keys=True))


if __name__ == "__main__":
    main()
