#!/usr/bin/env python3
"""Run a single reversible nuisance/profile trial from an existing GPX."""

from __future__ import annotations

import argparse
import json

import GSASII.GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument(
        "mode",
        choices=(
            "background",
            "polarization",
            "shl",
            "size",
            "strain",
            "strain_uniaxial",
            "texture",
        ),
    )
    parser.add_argument("values", nargs="*")
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(gpxfile=args.input, newgpx=args.output)
    project.set_Frozen()
    project.set_Controls("cycles", 18)
    hist = project.histogram(0)

    if args.mode == "background":
        order = int(args.values[0])
        hist.set_refinements(
            {"Background": {"type": "chebyschev-1", "no. coeffs": order, "refine": True}}
        )
    elif args.mode == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.0, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif args.mode == "shl":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
        project.set_Controls("parmMin", 0.0005, variable=":0:SH/L")
        project.set_Controls("parmMax", 0.1, variable=":0:SH/L")
    elif args.mode in ("size", "strain", "strain_uniaxial", "texture"):
        phase_index = int(args.values[0])
        phase = project.phase(phase_index)
        hap = phase.data["Histograms"][hist.name]
        if args.mode == "size":
            hap["Size"][0] = "isotropic"
            hap["Size"][1] = [5.0, 5.0, 1.0]
            hap["Size"][2] = [True, False, False]
            project.set_Controls("parmMin", 0.01, variable=f"{phase_index}:0:Size;i")
            project.set_Controls("parmMax", 10.0, variable=f"{phase_index}:0:Size;i")
        elif args.mode == "strain":
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1] = [100.0, 100.0, 1.0]
            hap["Mustrain"][2] = [True, False, False]
            project.set_Controls("parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;i")
            project.set_Controls("parmMax", 10000.0, variable=f"{phase_index}:0:Mustrain;i")
        elif args.mode == "strain_uniaxial":
            axis = [int(v) for v in args.values[1:4]]
            start = max(100.0, float(hap["Mustrain"][1][0]))
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1] = [start, start, 1.0]
            hap["Mustrain"][2] = [True, True, False]
            hap["Mustrain"][3] = axis
            for suffix in ("i", "a"):
                project.set_Controls(
                    "parmMin", 0.0, variable=f"{phase_index}:0:Mustrain;{suffix}"
                )
                project.set_Controls(
                    "parmMax", 10000.0, variable=f"{phase_index}:0:Mustrain;{suffix}"
                )
        else:
            axis = [int(v) for v in args.values[1:4]]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = axis
            project.set_Controls("parmMin", 0.2, variable=f"{phase_index}:0:MD")
            project.set_Controls("parmMax", 5.0, variable=f"{phase_index}:0:MD")

    project.save()
    project.refine(makeBack=False)
    project.save()

    inst = hist.data["Instrument Parameters"][0]
    result = {
        "mode": args.mode,
        "values": args.values,
        "project": args.output,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "profile": {key: inst[key][1] for key in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")},
        "background": hist.data["Background"][0],
        "hap": {
            phase.name: {
                "scale": phase.data["Histograms"][hist.name]["Scale"],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "strain": phase.data["Histograms"][hist.name]["Mustrain"],
                "texture": phase.data["Histograms"][hist.name]["Pref.Ori."],
            }
            for phase in project.phases()
        },
        "vary": list(
            zip(
                project.data["Covariance"]["data"].get("varyList", []),
                project.data["Covariance"]["data"].get("variables", []),
                project.data["Covariance"]["data"].get("sig", []),
            )
        ),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
