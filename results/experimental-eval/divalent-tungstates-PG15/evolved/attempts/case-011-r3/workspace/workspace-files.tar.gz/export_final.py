#!/usr/bin/env python3
"""Export all submission artifacts from the exact final GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
import GSASII.GSASIIscriptable as G2sc


PROJECT = Path("final.gpx")
PROFILE = Path("fit.csv")
RESULT = Path("result.json")
PHASE_DIR = Path("phases")

PHASE_METADATA = {
    "WO3_2106293": {
        "name": "tungsten(VI) oxide (triclinic WO3)",
        "formula": "WO3",
        "source_cod_id": "2106293",
        "cif": PHASE_DIR / "WO3_triclinic.cif",
    },
    "MnO2_1514110": {
        "name": "pyrolusite MnO2",
        "formula": "MnO2",
        "source_cod_id": "1514110",
        "cif": PHASE_DIR / "MnO2_pyrolusite.cif",
    },
}


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(PROJECT))
    histogram = project.histogram(0)
    phases = project.phases()
    if {phase.name for phase in phases} != set(PHASE_METADATA):
        raise RuntimeError("Final project phase inventory does not match export map")

    PHASE_DIR.mkdir(exist_ok=True)
    mass_fractions = histogram.ComputeMassFracs()
    phase_results = []
    for phase in phases:
        metadata = PHASE_METADATA[phase.name]
        phase.export_CIF(str(metadata["cif"]))
        fraction, esd = mass_fractions[phase.name]
        phase_results.append(
            {
                "name": metadata["name"],
                "formula": metadata["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "source_cod_id": metadata["source_cod_id"],
                "cif": metadata["cif"].as_posix(),
                "weight_fraction": float(fraction),
                "weight_percent": float(100.0 * fraction),
                "formal_weight_fraction_esd": float(esd),
                "cell": {key: float(value) for key, value in phase.get_cell().items()},
            }
        )

    x, observed, weights, calculated, background, stored_difference = [
        np.asarray(item, dtype=float) for item in histogram.data["data"][1]
    ]
    difference = observed - calculated
    if not np.allclose(difference, stored_difference, rtol=0.0, atol=1e-8):
        raise RuntimeError("Stored GSAS-II difference curve disagrees with observed-calculated")
    with PROFILE.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts",
                "background_counts",
            ]
        )
        writer.writerows(
            zip(
                (f"{value:.8f}" for value in x),
                (f"{value:.8f}" for value in observed),
                (f"{value:.8f}" for value in calculated),
                (f"{value:.8f}" for value in difference),
                (f"{value:.8f}" for value in background),
            )
        )

    residuals = histogram.residuals
    rvals = project.data["Covariance"]["data"]["Rvals"]
    gof = float(rvals["GOF"])
    result = {
        "project": PROJECT.as_posix(),
        "profile": PROFILE.as_posix(),
        "phase_fraction_basis": "normalized over the modeled crystalline phases; amorphous content not determined",
        "phases": phase_results,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": gof,
            "reduced_chi_squared": gof * gof,
            "total_chi_squared": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
        },
    }
    if abs(sum(item["weight_fraction"] for item in phase_results) - 1.0) > 1e-10:
        raise RuntimeError("Crystalline weight fractions are not normalized")
    with RESULT.open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
