#!/usr/bin/env python3
"""Trial element-grouped isotropic displacement parameters for one phase."""

from __future__ import annotations

import argparse
import json

import GSASII.GSASIIscriptable as G2sc


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("phase", type=int)
    parser.add_argument("--all-together", action="store_true")
    args = parser.parse_args()

    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(gpxfile=args.input, newgpx=args.output)
    project.set_Frozen()
    project.set_Controls("cycles", 25)
    project.data["Controls"]["data"]["shift factor"] = 0.25
    phase = project.phase(args.phase)

    groups: dict[str, list[int]] = {}
    for index, atom in enumerate(phase.atoms()):
        group = "all" if args.all_together else atom.element
        groups.setdefault(group, []).append(index)
        if atom.uiso <= 0.0:
            atom.uiso = 0.008 if atom.element == "O" else 0.005
        atom.refinement_flags = "U"

    for indices in groups.values():
        variables = [f"{args.phase}::AUiso:{index}" for index in indices]
        if len(variables) > 1:
            project.add_EquivConstr(variables)
        project.set_Controls("parmMin", 0.0, variable=variables[0])
        project.set_Controls("parmMax", 0.05, variable=variables[0])

    project.save()
    project.refine(makeBack=False)
    project.save()
    histogram = project.histogram(0)
    covariance = project.data["Covariance"]["data"]
    print(
        json.dumps(
            {
                "phase": phase.name,
                "residuals": histogram.residuals,
                "mass_fractions": histogram.ComputeMassFracs(),
                "uiso": [
                    {
                        "index": index,
                        "label": atom.label,
                        "element": atom.element,
                        "value": atom.uiso,
                    }
                    for index, atom in enumerate(phase.atoms())
                ],
                "vary": list(
                    zip(
                        map(str, covariance.get("varyList", [])),
                        covariance.get("variables", []),
                        covariance.get("sig", []),
                    )
                ),
                "dependent": {
                    str(key): value
                    for key, value in covariance.get("depSigDict", {}).items()
                },
                "frozen": project.get_Frozen(),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
