#!/usr/bin/env python3
"""Test a uniaxial crystallite-size direction for monoclinic WO3."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

G2sc.SetPrintLevel("warn")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("axis")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]
    project = G2sc.G2Project(
        "texture_baco3_110_replay.gpx", filename=str(args.output)
    )
    hist = project.histogram(0)
    phase = project.phase("WO3")
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    size = phase.data["Histograms"][hist.name]["Size"]
    start = float(size[1][0])
    size[0] = "uniaxial"
    size[1] = [start, start, 1.0]
    size[2] = [True, True, False]
    size[3] = axis
    for suffix in ("i", "a"):
        variable = f"{phase.id}:0:Size;{suffix}"
        project.set_Controls("parmMin", 0.01, variable)
        project.set_Controls("parmMax", 10.0, variable)
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    project.save()
    project = G2sc.G2Project(str(args.output))
    hist = project.histogram(0)
    project.refine(makeBack=False)
    project.save()
    phase = project.phase("WO3")
    size = phase.data["Histograms"][hist.name]["Size"]
    print(
        json.dumps(
            {
                "axis": axis,
                "rwp_percent": hist.residuals["wR"],
                "size": size,
                "mass_fractions": hist.ComputeMassFracs(),
                "frozen": [
                    str(value)
                    for value in project.data["Controls"]["data"]
                    .get("parmFrozen", {})
                    .get("FrozenList", [])
                ],
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
