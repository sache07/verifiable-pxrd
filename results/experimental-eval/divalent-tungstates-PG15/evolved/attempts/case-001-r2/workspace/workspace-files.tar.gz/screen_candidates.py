#!/usr/bin/env python3
"""Compare chemically plausible COD records under one restrained GSAS-II baseline."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat

G2sc.SetPrintLevel("warn")


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CASES = {
    "base": [("1528915", "WO3"), ("9010928", "BaCO3")],
    "wo3_2311041": [("2311041", "WO3"), ("9010928", "BaCO3")],
    "wo3_2106293": [("2106293", "WO3"), ("9010928", "BaCO3")],
    "wo3_1563541": [("1563541", "WO3"), ("9010928", "BaCO3")],
    "wo3_2107312": [("2107312", "WO3"), ("9010928", "BaCO3")],
    "wo3_1521532": [("1521532", "WO3"), ("9010928", "BaCO3")],
    "wo3_1521533": [("1521533", "WO3"), ("9010928", "BaCO3")],
    "wo3_1004057": [("1004057", "WO3"), ("9010928", "BaCO3")],
    "baco3_1011149": [("1528915", "WO3"), ("1011149", "BaCO3")],
    "baco3_9006847": [("1528915", "WO3"), ("9006847", "BaCO3")],
    "baco3_1539129": [("1528915", "WO3"), ("1539129", "BaCO3")],
    "baco3_1539130": [("1528915", "WO3"), ("1539130", "BaCO3")],
    "base_bawo4_exact": [
        ("1528915", "WO3"), ("9010928", "BaCO3"), ("1527204", "BaWO4")
    ],
    "base_bawo4_proto": [
        ("1528915", "WO3"), ("9010928", "BaCO3"), ("proto", "BaWO4")
    ],
    "selected_bawo4_proto": [
        ("2311041", "WO3"), ("9010928", "BaCO3"), ("proto", "BaWO4")
    ],
}


def add_phase(project, histogram, record: str, name: str):
    if record != "proto":
        return project.add_phase(
            str(cif_path(record)), phasename=name, histograms=[histogram], fmthint="CIF"
        )

    # Ordered BaMoO4 (COD 2300459) is an isostructural scheelite parent.
    # Mo6+ -> W6+ is isovalent; use the measured BaWO4 cell from COD 1527204.
    phase = project.add_phase(
        str(cif_path("2300459")), phasename=name, histograms=[histogram], fmthint="CIF"
    )
    for atom in phase.atoms():
        if atom.element == "Mo":
            atom.type = "W+6"
            atom.label = atom.label.replace("Mo", "W")
    cell = [5.614, 5.614, 12.719, 90.0, 90.0, 90.0]
    phase.data["General"]["Cell"][1:7] = cell
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))
    G2sc.SetupGeneral(phase.data, None)
    return phase


def run_case(case: str, output_dir: Path) -> dict:
    base = G2sc.G2Project("trial_two_phase_shift.gpx")
    base_hist = base.histogram(0)
    outfile = output_dir / f"{case}.gpx"
    project = G2sc.G2Project(newgpx=str(outfile))
    histogram = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    histogram.data["Background"] = copy.deepcopy(base_hist.data["Background"])
    histogram.data["Instrument Parameters"] = copy.deepcopy(
        base_hist.data["Instrument Parameters"]
    )
    histogram.data["Sample Parameters"] = copy.deepcopy(base_hist.data["Sample Parameters"])

    # Fixed common profile: unsupported U and W are neutralized; only X retained.
    inst = histogram.data["Instrument Parameters"][0]
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        inst[key][2] = False
    inst["U"][1] = 0.0
    inst["V"][1] = 0.0
    inst["W"][1] = 0.0
    inst["X"][1] = 12.589633677666958
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002

    sample = histogram.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [-519.9691392132778, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    histogram.data["Background"][0][1] = True

    phases = []
    for record, name in CASES[case]:
        phase = add_phase(project, histogram, record, name)
        scale0 = 0.15 if name == "BaWO4" else (7.7 if name == "WO3" else 22.0)
        phase.data["Histograms"][histogram.name]["Scale"] = [scale0, True]
        phases.append(phase)

    project.update_ids()
    project.index_ids()
    project.set_Controls("cycles", 4)
    for phase in phases:
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")

    # Refit smooth background and all scales first under the common profile.
    project.refine(makeBack=False)
    project.save()

    # Then release one shared angular correction and all cells.
    histogram.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 5)
    project.refine(makeBack=False)
    project.save()

    try:
        mass_fractions = {
            key: {"value": val[0], "sigma": val[1]}
            for key, val in histogram.ComputeMassFracs().items()
        }
    except Exception as exc:
        mass_fractions = {"error": str(exc)}
    return {
        "case": case,
        "records": CASES[case],
        "rwp_percent": histogram.residuals.get("wR"),
        "rp_percent": histogram.residuals.get("R"),
        "shift_micrometres": sample["Shift"][0],
        "scales": {phase.name: phase.data["Histograms"][histogram.name]["Scale"][0] for phase in phases},
        "mass_fractions": mass_fractions,
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "project": str(outfile),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cases", nargs="+", choices=sorted(CASES))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project_dir = args.output.parent / (args.output.stem + "_projects")
    project_dir.mkdir(parents=True, exist_ok=True)
    results = []
    for case in args.cases:
        result = run_case(case, project_dir)
        results.append(result)
        print(json.dumps(result), flush=True)
    args.output.write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
