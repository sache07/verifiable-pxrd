#!/usr/bin/env python3
"""Replay one phase-broadening term at a time from a neutral common profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

G2sc.SetPrintLevel("warn")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=["WO3", "BaCO3", "BaWO4"])
    parser.add_argument("term", choices=["size", "strain"])
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    project = G2sc.G2Project("neutral_uwx.gpx", filename=str(args.output))
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}

    hap = phase.data["Histograms"][hist.name]
    if args.term == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][1][2] = 1.0
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
        variable = f"{phase.id}:0:Size;i"
        project.set_Controls("parmMin", 0.01, variable)
        project.set_Controls("parmMax", 10.0, variable)
    else:
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][2] = 1.0
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
        variable = f"{phase.id}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable)
        project.set_Controls("parmMax", 10000.0, variable)

    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    project.save()
    project = G2sc.G2Project(str(args.output))
    hist = project.histogram(0)
    project.refine(makeBack=False)
    project.save()
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    covariance = project.data["Covariance"]["data"]
    result = {
        "phase": args.phase,
        "term": args.term,
        "rwp_percent": hist.residuals["wR"],
        "rp_percent": hist.residuals["R"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "profile": {
            key: hist.data["Instrument Parameters"][0][key][1]
            for key in ("U", "W", "X")
        },
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.data["Controls"]["data"].get("parmFrozen"),
        "vary_list": covariance.get("varyList", []),
        "variables": covariance.get("variables", []).tolist(),
        "sigmas": covariance.get("sig", []).tolist(),
    }
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
