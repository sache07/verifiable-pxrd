#!/usr/bin/env python3
"""Challenge a single March-Dollase texture axis against the common model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

G2sc.SetPrintLevel("warn")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=["WO3", "BaCO3"])
    parser.add_argument("axis", help="three comma-separated integers")
    parser.add_argument("output", type=Path)
    parser.add_argument("--source", default="polar_wo3_size.gpx")
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]

    project = G2sc.G2Project(args.source, filename=str(args.output))
    hist = project.histogram(0)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    for phase in project.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        if phase.name == args.phase:
            po[0] = "MD"
            po[1] = 1.0
            po[2] = True
            po[3] = axis

    phase = project.phase(args.phase)
    variable = f"{phase.id}:0:MD"
    project.set_Controls("parmMin", 0.2, variable)
    project.set_Controls("parmMax", 5.0, variable)
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    project.save()
    covariance = project.data["Covariance"]["data"]
    vary = covariance.get("varyList", [])
    sigmas = covariance.get("sig", [])
    idx = vary.index(variable) if variable in vary else None
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    print(
        json.dumps(
            {
                "phase": args.phase,
                "axis": axis,
                "rwp_percent": hist.residuals["wR"],
                "md": po[1],
                "md_sigma": None if idx is None else float(sigmas[idx]),
                "mass_fractions": hist.ComputeMassFracs(),
                "frozen": [
                    str(value)
                    for value in controls.get("parmFrozen", {}).get("FrozenList", [])
                ],
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
