#!/usr/bin/env python3
"""Replay the selected model and export all submission artifacts from one GPX."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


G2sc.SetPrintLevel("warn")

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "texture_baco3_110_replay.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "WO3": {
        "display_name": "monoclinic WO3",
        "formula": "WO3",
        "space_group_number": 14,
        "source_model": "COD 2311041",
        "cif": "phase_WO3.cif",
    },
    "BaCO3": {
        "display_name": "orthorhombic BaCO3 (witherite)",
        "formula": "BaCO3",
        "space_group_number": 62,
        "source_model": "COD 9010928",
        "cif": "phase_BaCO3.cif",
    },
    "BaWO4": {
        "display_name": "scheelite BaWO4 (trace, provisional)",
        "formula": "BaWO4",
        "space_group_number": 88,
        "source_model": (
            "ordered BaMoO4 prototype COD 2300459 with isovalent Mo6+->W6+ "
            "substitution and a BaWO4 starting cell"
        ),
        "cif": "phase_BaWO4.cif",
    },
}


def configure_supported_model(project: G2sc.G2Project) -> None:
    """Make the retained terms explicit and remove stale trial state."""
    hist = project.histogram(0)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    project.set_Controls("cycles", 12)

    # Smooth eight-coefficient background and one angular correction.
    hist.data["Background"][0][1] = True
    sample = hist.data["Sample Parameters"]
    for key in ("DisplaceX", "DisplaceY", "Transparency", "SurfRoughA", "SurfRoughB"):
        sample[key][1] = False
    sample["Shift"][1] = True
    sample["Scale"][1] = False

    # Common nonnegative U/X profile. W and all other unsupported profile
    # or asymmetry terms are fixed at neutral values.
    inst = hist.data["Instrument Parameters"][0]
    for key in ("Zero", "V", "W", "Y", "Z", "SH/L"):
        inst[key][2] = False
    inst["Zero"][1] = 0.0
    inst["V"][1] = 0.0
    inst["W"][1] = 0.0
    inst["Y"][1] = 0.0
    inst["Z"][1] = 0.0
    inst["SH/L"][1] = 0.002
    for key in ("Polariz.", "U", "X"):
        inst[key][2] = True

    # Retain only WO3 isotropic size and BaCO3 [110] March-Dollase texture.
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"] = [0.0, False]
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]
        hap["LeBail"] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])

        if phase.name == "WO3":
            hap["Size"][0] = "isotropic"
            hap["Size"][2] = [True, False, False]
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
        else:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 10.0
            hap["Size"][2] = [False] * len(hap["Size"][2])
            if phase.name == "BaCO3":
                hap["Pref.Ori."][0] = "MD"
                hap["Pref.Ori."][2] = True
                hap["Pref.Ori."][3] = [1, 1, 0]
            else:
                hap["Pref.Ori."][1] = 1.0
                hap["Pref.Ori."][2] = False

        # Atomic coordinates, occupancies and displacement parameters remain
        # those of the screened reference structure/prototype.
        for atom in phase.data["Atoms"]:
            atom[2] = ""

    # Bounds enforce the physical sign/range without affecting the solution.
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, f"{phase.id}:0:Scale")
    project.set_Controls("parmMin", 0.01, f"{project.phase('WO3').id}:0:Size;i")
    project.set_Controls("parmMax", 10.0, f"{project.phase('WO3').id}:0:Size;i")
    project.set_Controls("parmMin", 0.2, f"{project.phase('BaCO3').id}:0:MD")
    project.set_Controls("parmMax", 5.0, f"{project.phase('BaCO3').id}:0:MD")
    project.set_Controls("parmMin", 0.0, ":0:U")
    project.set_Controls("parmMin", 0.0, ":0:X")
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")

    hist.data["Comments"] = [
        "Input: inputs/pattern.csv (original counts; Poisson 1/I weights)",
        "Cu Kalpha1 1.540598 A; Kalpha2 1.544426 A; I(Kalpha2)/I(Kalpha1)=0.5",
        "WO3 model: COD 2311041; BaCO3 model: COD 9010928",
        "BaWO4 model: ordered COD 2300459 scheelite prototype, Mo6+ replaced by W6+",
    ]


def replay_final_project() -> G2sc.G2Project:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    configure_supported_model(project)
    project.refine(makeBack=False)
    project.save()

    # Reopen and replay the full range to ensure persistence and convergence.
    project = G2sc.G2Project(str(FINAL))
    project.refine(makeBack=False)
    project.save()
    project = G2sc.G2Project(str(FINAL))

    rvals = project.data["Covariance"]["data"]["Rvals"]
    assert rvals.get("converged") is True
    assert rvals["Max shft/sig"] < 0.2
    assert not project.data["Controls"]["data"]["parmFrozen"]["FrozenList"]
    return project


def export_profile(hist) -> None:
    columns = [
        hist.getdata("X"),
        hist.getdata("Yobs"),
        hist.getdata("Ycalc"),
        hist.getdata("Residual"),
        hist.getdata("Background"),
    ]
    arrays = [np.asarray(value, dtype=float) for value in columns]
    assert all(np.all(np.isfinite(value)) for value in arrays)
    assert np.allclose(arrays[3], arrays[1] - arrays[2], rtol=0.0, atol=1e-10)
    assert float(np.min(arrays[4])) > 0.0

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_intensity",
                "calculated_intensity",
                "difference_intensity",
                "background_intensity",
            ]
        )
        for row in zip(*arrays):
            writer.writerow([format(float(value), ".15g") for value in row])


def export_cifs(project: G2sc.G2Project) -> None:
    for phase in project.phases():
        phase.export_CIF(str(ROOT / PHASE_INFO[phase.name]["cif"]))


def build_result(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    fractions = hist.ComputeMassFracs()
    assert math.isclose(sum(value[0] for value in fractions.values()), 1.0, abs_tol=1e-10)
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    residuals = hist.residuals

    phases = []
    for phase in project.phases():
        value, sigma = fractions[phase.name]
        general = phase.data["General"]
        phases.append(
            {
                "name": PHASE_INFO[phase.name]["display_name"],
                "formula": PHASE_INFO[phase.name]["formula"],
                "space_group": general["SGData"]["SpGrp"],
                "space_group_number": PHASE_INFO[phase.name]["space_group_number"],
                "cif_path": PHASE_INFO[phase.name]["cif"],
                "weight_fraction": float(value),
                "weight_fraction_esd": float(sigma),
                "weight_percent": float(100.0 * value),
                "weight_percent_esd": float(100.0 * sigma),
                "cell": phase.get_cell(),
                "model_source": PHASE_INFO[phase.name]["source_model"],
            }
        )

    result = {
        "input_pattern": "inputs/pattern.csv",
        "metadata": "inputs/metadata.json",
        "gsasii_project": "final.gpx",
        "fit_profile": "fit.csv",
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": float(residuals["wR"]),
            "Rp_percent": float(residuals["R"]),
            "R_background_percent": float(residuals["Rb"]),
            "weighted_R_background_percent": float(residuals["wRb"]),
            "Rexp_percent": float(residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_variables": int(rvals["Nvars"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
            "converged": bool(rvals["converged"]),
        },
        "uncertainty_note": (
            "ESDs are formal least-squares values under Poisson 1/I weights. "
            "They do not include structure choice, preferred orientation, profile, "
            "background, specimen-geometry, or possible amorphous-content uncertainty."
        ),
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def build_report(project: G2sc.G2Project, result: dict) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = {entry["formula"]: entry for entry in result["phases"]}
    fit = result["fit_statistics"]

    rows = []
    for formula in ("WO3", "BaCO3", "BaWO4"):
        phase = phases[formula]
        qualifier = "provisional trace" if formula == "BaWO4" else "robust identity"
        rows.append(
            f"| {phase['name']} | {phase['space_group']} (No. {phase['space_group_number']}) "
            f"| {phase['weight_percent']:.3f} +/- {phase['weight_percent_esd']:.3f} | {qualifier} |"
        )

    report = f"""# PXRD phase analysis

## Result

The best-supported crystalline model contains three phases. Fractions are normalized to the modeled crystalline material only.

| Phase | Refined space group | Weight % (formal esd) | Assessment |
|---|---:|---:|---|
{chr(10).join(rows)}

The major-phase identities are secure. The two major fractions should be interpreted to roughly 1-2 wt% practical precision, not at the much smaller formal esds. BaWO4 is a credible trace assignment, but its exact structure and fraction cannot be determined reliably from this pattern alone; report it as approximately 0.7 wt% and near the detection limit. No amorphous fraction can be measured without an internal standard.

## Evidence and inventory challenge

Monoclinic WO3 accounts for coherent families at approximately 23.43, 23.91, 24.65, 33.57, 34.45, 41.74/42.12, 50.21 and 56.18 degrees 2theta. Orthorhombic witherite BaCO3 accounts for the independent 24.21, 24.57, 34.04/34.86, 42.29, 45.17, 47.08 and 55.02 degree families. Their cells and intensities remain physical when refined together.

Composition-, symmetry-, disorder- and geometry-screening favored COD 2311041 for WO3 and COD 9010928 for BaCO3. Under the same initial nuisance model, the selected WO3 record gave Rwp 8.884%, versus 9.167% for another monoclinic record, 9.645% for a triclinic record, 14.91% for an orthorhombic record, and 24.4-28.2% for tetragonal/hexagonal records. Alternative BaCO3 records either gave poor fits or collapsed toward zero scale.

The weak residual families at about 26.82 (112), 28.41 (004), 32.24 (200), 43.35 (204), 49.07 (116) and 54.89 degrees (224) are consistent with scheelite BaWO4. The available exact COD entry was occupationally disordered and produced an unphysical short contact, so a stoichiometric-analogue search was used: ordered scheelite BaMoO4 (COD 2300459) was converted by the isovalent Mo6+ to W6+ substitution and its cell was started from BaWO4. Atomic coordinates were kept fixed. A final fair re-challenge under the same common profile and BaCO3 texture lowered Rwp from 7.2954% (WO3 + BaCO3) to {fit['Rwp_percent']:.4f}% with BaWO4. This multi-family improvement supports retaining the phase, but it is small enough that the assignment remains provisional.

## Refinement and fit quality

The final full-range replay converged with Rwp = {fit['Rwp_percent']:.4f}%, Rp = {fit['Rp_percent']:.4f}%, Rexp = {fit['Rexp_percent']:.4f}% and GOF = {fit['goodness_of_fit']:.3f} ({fit['n_observations']} points, {fit['n_refined_variables']} variables). The original counts were fit with Poisson 1/I weights because pointwise uncertainties were not supplied. The Cu Kalpha doublet and reported 0.5 intensity ratio were fixed.

The retained nuisance model consists of an eight-term smooth Chebyshev background, one Bragg-Brentano specimen shift ({sample['Shift'][0]:.2f} micrometres), a common nonnegative U/X profile (U = {inst['U'][1]:.3f}, W = 0, X = {inst['X'][1]:.3f}), and refined effective polarization ({inst['Polariz.'][1]:.4f}). WO3 requires one replay-stable isotropic size term; BaCO3 requires a replay-stable [110] March-Dollase correction. Unused phase size/strain, roughness, transparency, extinction and anisotropic broadening were neutralized. A released SH/L asymmetry term gave negligible improvement and was strongly correlated with specimen shift, so it was pruned. Strong isolated low-angle peaks and middle/high-angle families show no systematic position drift; the remaining serial residual structure and some overlapping-family width/intensity mismatch explain why GOF exceeds one.

Only phase scales and cells, the supported WO3 size and BaCO3 texture terms, common profile/polarization, one angular correction, and background were refined. Atomic coordinates, occupancies and displacement parameters come from the screened reference structures/prototype and were not determined de novo. Consequently, the BaWO4 oxygen geometry in particular is a plausible structural model rather than a unique solution. The quoted fractions also exclude any unmodeled crystalline phase below detection and all noncrystalline material.

The submitted CIFs, `fit.csv`, fractions and statistics were exported directly from the final replayed `final.gpx`.
"""
    (ROOT / "report.md").write_text(report)


def validate_outputs(project: G2sc.G2Project, result: dict) -> None:
    expected = [
        FINAL,
        ROOT / "fit.csv",
        ROOT / "result.json",
        ROOT / "report.md",
        *[ROOT / info["cif"] for info in PHASE_INFO.values()],
    ]
    assert all(path.is_file() and path.stat().st_size > 0 for path in expected)
    assert len(project.histogram(0).getdata("X")) == 8301
    assert len(result["phases"]) == 3
    assert math.isclose(sum(p["weight_fraction"] for p in result["phases"]), 1.0, abs_tol=1e-10)


def main() -> None:
    project = replay_final_project()
    export_cifs(project)
    export_profile(project.histogram(0))
    result = build_result(project)
    build_report(project, result)
    validate_outputs(project, result)
    print(json.dumps({"fit_statistics": result["fit_statistics"], "phases": result["phases"]}, indent=2))


if __name__ == "__main__":
    main()
