#!/usr/bin/env python3
"""Index coherent residual peaks with the GSAS-II cell-search routine."""

from __future__ import annotations

import argparse
import copy
import math

from GSASII import GSASIIindex as G2index


WAVELENGTH = 1.540598
ZERO = 0.350


PEAK_SETS = {
    "strict": [
        16.60536,
        20.64768,
        22.09291,
        29.75375,
        30.89473,
        32.63336,
        44.67338,
        53.44259,
        61.27730,
        66.98218,
    ],
    "extended": [
        16.60536,
        18.32226,
        20.64768,
        22.09291,
        24.73346,
        29.75375,
        30.89473,
        32.63336,
        34.49152,
        41.81550,
        44.67338,
        48.57443,
        53.44259,
        61.27730,
        66.98218,
    ],
}


def make_peaks(positions: list[float]) -> list[list[float | bool | int]]:
    peaks = []
    for position in positions:
        corrected = position - ZERO
        d = WAVELENGTH / (2.0 * math.sin(math.radians(corrected / 2.0)))
        peaks.append([position, 1.0, True, False, 0, 0, 0, d, 0.0])
    return peaks


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--set", choices=PEAK_SETS, default="strict")
    parser.add_argument("--volume", type=float, default=100.0)
    parser.add_argument("--timeout", type=float, default=2.0)
    args = parser.parse_args()

    # Cubic, tetragonal, orthorhombic and primitive monoclinic searches.
    bravais = [True] * 13 + [False, False, False, True, False]
    controls = [0, 0.0, 6, args.volume, 0, "P1"] + [0.0] * 8
    ok, dmin, cells = G2index.DoIndexPeaks(
        make_peaks(PEAK_SETS[args.set]),
        controls,
        bravais,
        None,
        ifX20=True,
        timeout=args.timeout,
        M20_min=1.0,
        return_Nc=True,
    )
    print("OK", ok, "dmin", dmin, "count", len(cells))
    for cell in G2index.sortM20(copy.deepcopy(cells))[:30]:
        print(cell)


if __name__ == "__main__":
    main()
