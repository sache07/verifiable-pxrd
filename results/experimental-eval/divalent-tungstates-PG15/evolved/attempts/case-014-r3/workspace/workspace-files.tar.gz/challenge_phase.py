#!/usr/bin/env python3
"""Challenge a weak candidate against a converged GSAS-II baseline."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


def neutralize(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> None:
    phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=0.5)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=0.5)
    hap = phase.getHAPvalues(hist.name)
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["Extinction"] = [0.0, False]
    if "Babinet" in hap:
        hap["Babinet"]["BabA"] = [0.0, False]
        hap["Babinet"]["BabU"] = [0.0, False]


def scale_cell(phase: G2sc.G2Phase, factor: float) -> None:
    raw = phase.data["General"]["Cell"]
    cell = [raw[i] * factor if i <= 3 else raw[i] for i in range(1, 7)]
    raw[1:7] = cell
    raw[7] = G2lat.calc_V(G2lat.cell2A(cell))


def set_cell(phase: G2sc.G2Phase, cell: list[float]) -> None:
    raw = phase.data["General"]["Cell"]
    raw[1:7] = cell
    raw[7] = G2lat.calc_V(G2lat.cell2A(cell))


def freeze_all(project: G2sc.G2Project, hist: G2sc.G2PwdrData) -> None:
    hist.Background[0][1] = False
    for item in hist.InstrumentParameters.values():
        if isinstance(item, list) and len(item) > 2:
            item[2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.getHAPvalues(hist.name)["Scale"][1] = False


def snapshot(project: G2sc.G2Project, hist: G2sc.G2PwdrData, tag: str) -> None:
    try:
        fractions = hist.ComputeMassFracs()
    except Exception:
        fractions = {}
    print(json.dumps({
        "step": tag,
        "residuals": hist.residuals,
        "instrument": {
            key: value for key, value in hist.InstrumentParameters.items()
            if key in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]
        },
        "phases": [{
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": phase.getHAPvalues(hist.name)["Scale"],
            "fraction": fractions.get(phase.name),
        } for phase in project.phases()],
    }, indent=2, default=float))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline")
    parser.add_argument("candidate")
    parser.add_argument("output")
    parser.add_argument("--label", required=True)
    parser.add_argument("--cell-scale", type=float, default=1.0)
    parser.add_argument("--cell", nargs=6, type=float)
    parser.add_argument("--initial-scale", type=float, default=0.10)
    args = parser.parse_args()

    # add_phase() autosaves to the project's current path, so make the trial
    # copy before loading it and never expose the source baseline to writes.
    shutil.copy2(args.baseline, args.output)
    project = G2sc.G2Project(gpxfile=args.output)
    project.set_Controls("cycles", 6)
    hist = project.histogram(0)
    freeze_all(project, hist)

    candidate = project.add_phase(
        args.candidate, phasename=args.label, histograms=[hist], fmthint="CIF"
    )
    neutralize(candidate, hist)
    if args.cell is not None:
        set_cell(candidate, args.cell)
    elif args.cell_scale != 1.0:
        scale_cell(candidate, args.cell_scale)
    hap = candidate.getHAPvalues(hist.name)
    hap["Scale"] = [args.initial_scale, True]
    variable = f"{candidate.data['pId']}:{hist.id}:Scale"
    project.set_Controls("parmMin", 0.0, variable=variable)
    project.refine()
    project.save(args.output)
    snapshot(project, hist, "candidate_scale_only")

    # Rebuild the common low-order model after changing the inventory.
    hist.Background[0][1] = True
    hist.InstrumentParameters["Zero"][2] = True
    for phase in project.phases():
        phase.getHAPvalues(hist.name)["Scale"][1] = True
        phase.data["General"]["Cell"][0] = True
    project.refine()
    project.save(args.output)
    snapshot(project, hist, "background_scales_zero_cells")

    hist.InstrumentParameters["W"][2] = True
    hist.InstrumentParameters["X"][2] = True
    project.refine()
    project.save(args.output)
    snapshot(project, hist, "shared_profile")

    # Save, reopen, and replay the exact full-range model.
    project = G2sc.G2Project(gpxfile=args.output)
    project.refine()
    project.save(args.output)
    snapshot(project, project.histogram(0), "replay")


if __name__ == "__main__":
    main()
