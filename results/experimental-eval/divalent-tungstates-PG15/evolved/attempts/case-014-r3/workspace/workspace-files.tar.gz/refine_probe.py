#!/usr/bin/env python3
"""Run a deliberately restrained GSAS-II candidate refinement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def set_cell(phase: G2sc.G2Phase, cell: list[float]) -> None:
    phase.data["General"]["Cell"][1:7] = cell
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def phase_summary(phase: G2sc.G2Phase, hist: G2sc.G2PwdrData) -> dict:
    hap = phase.getHAPvalues(hist.name)
    return {
        "name": phase.name,
        "cell": phase.get_cell(),
        "composition": phase.composition,
        "density": phase.density,
        "scale": hap["Scale"],
        "size": hap["Size"],
        "microstrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "hstrain": hap["HStrain"],
        "weight_fraction": hap.get("WgtFrac"),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", default="probe")
    parser.add_argument("--cod", nargs="+", default=["1546036"])
    parser.add_argument("--phase-files", nargs="+")
    parser.add_argument("--labels", nargs="+")
    args = parser.parse_args()

    phase_files = (
        [str(cod_path(cod_id)) for cod_id in args.cod]
        if args.phase_files is None
        else args.phase_files
    )
    labels = args.labels or args.cod
    if len(labels) != len(phase_files):
        raise ValueError("--labels and the phase-file list must have equal length")

    gpx_path = Path(f"{args.name}.gpx")
    project = G2sc.G2Project(newgpx=str(gpx_path))
    project.set_Controls("cycles", 8)
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", fmthint="comma"
    )
    hist.Limits("lower", 10.02)
    hist.Limits("upper", 99.98)
    hist.SampleParameters["Scale"] = [1.0, False]
    phases = [
        project.add_phase(
            phase_file, phasename=label, histograms=[hist], fmthint="CIF"
        )
        for phase_file, label in zip(phase_files, labels)
    ]

    # Initialize the unmistakable scheelite cell from its isolated peak families.
    if labels[0].startswith("SrWO4") or args.cod[0] == "1546036":
        set_cell(phases[0], [5.4280, 5.4280, 11.9690, 90.0, 90.0, 90.0])

    # Remove sample-dependent broadening and texture before fitting a shared profile.
    for phase in phases:
        phase.setSampleProfile(hist, "size", "isotropic", 10.0, LGmix=0.5)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=0.5)
        hap = phase.getHAPvalues(hist.name)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        if "Babinet" in hap:
            hap["Babinet"]["BabA"] = [0.0, False]
            hap["Babinet"]["BabU"] = [0.0, False]

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 8,
            }
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})

    def refine(tag: str) -> None:
        project.refine()
        project.save(str(gpx_path))
        print(
            json.dumps(
                {
                    "step": tag,
                    "residuals": hist.residuals,
                    "instrument": {
                        key: value
                        for key, value in hist.InstrumentParameters.items()
                        if key
                        in [
                            "Zero",
                            "U",
                            "V",
                            "W",
                            "X",
                            "Y",
                            "Z",
                            "SH/L",
                            "Polariz.",
                            "I(L2)/I(L1)",
                        ]
                    },
                    "background": hist.Background,
                    "phases": [phase_summary(p, hist) for p in phases],
                },
                indent=2,
                default=float,
            )
        )

    refine("background_scales")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine("zero_cells")
    hist.set_refinements({"Instrument Parameters": ["W"]})
    refine("profile_W")
    hist.set_refinements({"Instrument Parameters": ["X"]})
    refine("profile_WX")

    # Reopen and replay once to check persistence.
    project.save(str(gpx_path))
    project = G2sc.G2Project(gpxfile=str(gpx_path))
    project.refine()
    project.save(str(gpx_path))
    hist = project.histogram(0)
    print(json.dumps({"step": "replay", "residuals": hist.residuals}, indent=2))


if __name__ == "__main__":
    main()
