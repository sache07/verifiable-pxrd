#!/usr/bin/env python3
"""Screen symmetry-distinct March-Dollase axes one phase at a time."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SOURCE = Path("baseline_p1.gpx")
OUTDIR = Path("texture_trials")


def freeze(project, hist):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"][1] = False
        hap["Pref.Ori."][1:3] = [1.0, False]


def main():
    OUTDIR.mkdir(exist_ok=True)
    axes_by_phase = {
        0: [(0, 0, 1), (1, 0, 0), (1, 1, 0), (1, 0, 1)],
        1: [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)],
        2: [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)],
    }
    results = []
    for phase_index, axes in axes_by_phase.items():
        for axis in axes:
            axis_tag = "".join(map(str, axis))
            output = OUTDIR / f"p{phase_index}_{axis_tag}.gpx"
            shutil.copy2(SOURCE, output)
            project = G2sc.G2Project(gpxfile=str(output))
            project.set_Controls("cycles", 6)
            hist = project.histogram(0)
            freeze(project, hist)
            phase = project.phase(phase_index)
            po = phase.getHAPvalues(hist.name)["Pref.Ori."]
            po[0:4] = ["MD", 1.0, True, list(axis)]
            variable = f"{phase.data['pId']}:{hist.id}:MD"
            project.set_Controls("parmMin", 0.2, variable=variable)
            project.set_Controls("parmMax", 5.0, variable=variable)
            project.refine()
            project.save(str(output))
            covariance = project.data.get("Covariance", {}).get("data", {})
            esd = None
            if variable in covariance.get("varyList", []):
                esd = covariance["sig"][covariance["varyList"].index(variable)]
            results.append({
                "phase": phase.name,
                "axis": axis,
                "Rwp": hist.residuals.get("wR"),
                "MD": po[1],
                "esd": esd,
            })
            print(json.dumps(results[-1], default=float))
    print(json.dumps(results, indent=2, default=float))


if __name__ == "__main__":
    main()
