#!/usr/bin/env python3
"""Run one reversible nuisance/structure trial from a saved GSAS-II model."""

from __future__ import annotations

import argparse
import json
import shutil

from GSASII import GSASIIscriptable as G2sc


def freeze_common(project, hist):
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        for atom in phase.data["Atoms"]:
            atom[2] = ""


def common_on(project, hist):
    hist.Background[0][1] = True
    for key in ["Zero", "W", "X"]:
        hist.InstrumentParameters[key][2] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
        phase.getHAPvalues(hist.name)["Scale"][1] = True


def describe(project, hist, step):
    fracs = hist.ComputeMassFracs()
    print(json.dumps({
        "step": step,
        "residuals": hist.residuals,
        "instrument": {k: v for k, v in hist.InstrumentParameters.items()
                       if k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]},
        "sample": hist.SampleParameters,
        "fractions": fracs,
        "phases": [{
            "name": phase.name,
            "cell": phase.get_cell(),
            "atoms": [[a[0], a[2], a[3], a[4], a[5], a[10]] for a in phase.data["Atoms"]],
        } for phase in project.phases()],
    }, indent=2, default=float))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument(
        "mode",
        choices=[
            "polarization", "fixed_polarization_1", "srwo4_uiso", "srwo4_o_xyz",
            "srwo4_o_xyz_unbounded", "roughness_a",
            "wo3_strain", "sr2wo5_strain", "both_strain", "joint_accepted",
        ],
    )
    args = parser.parse_args()

    shutil.copy2(args.source, args.output)
    project = G2sc.G2Project(gpxfile=args.output)
    project.set_Controls("cycles", 8)
    hist = project.histogram(0)
    freeze_common(project, hist)

    if args.mode == "polarization":
        hist.InstrumentParameters["Polariz."][2] = True
        project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=f":{hist.id}:Polariz.")
    elif args.mode == "fixed_polarization_1":
        hist.InstrumentParameters["Polariz."][1] = 1.0
        hist.InstrumentParameters["Polariz."][2] = False
        common_on(project, hist)
    elif args.mode == "srwo4_uiso":
        phase = project.phase(0)
        for i, atom in enumerate(phase.data["Atoms"]):
            atom[2] = "U"
            project.set_Controls("parmMin", 0.0, variable=f"{phase.data['pId']}::AUiso:{i}")
            project.set_Controls("parmMax", 0.03, variable=f"{phase.data['pId']}::AUiso:{i}")
    elif args.mode == "srwo4_o_xyz":
        phase = project.phase(0)
        atom_index = 2
        phase.data["Atoms"][atom_index][2] = "X"
        for coordinate in ["dAx", "dAy", "dAz"]:
            variable = f"{phase.data['pId']}::{coordinate}:{atom_index}"
            project.set_Controls("parmMin", -0.03, variable=variable)
            project.set_Controls("parmMax", 0.03, variable=variable)
    elif args.mode == "srwo4_o_xyz_unbounded":
        phase = project.phase(0)
        phase.data["Atoms"][2][2] = "X"
    elif args.mode == "roughness_a":
        hist.SampleParameters["SurfRoughA"] = [0.01, True]
        hist.SampleParameters["SurfRoughB"] = [0.0, False]
        project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=f":{hist.id}:SurfRoughA")
    elif args.mode in ["wo3_strain", "sr2wo5_strain", "both_strain", "joint_accepted"]:
        indices = [1, 2] if args.mode in ["both_strain", "joint_accepted"] else [
            1 if args.mode == "wo3_strain" else 2
        ]
        for phase_index in indices:
            phase = project.phase(phase_index)
            hap = phase.getHAPvalues(hist.name)
            hap["Mustrain"][1][0] = 2600.0 if phase_index == 1 else 1600.0
            hap["Mustrain"][2][0] = True
            variable = f"{phase.data['pId']}:{hist.id}:Mustrain;i"
            project.set_Controls("parmMin", 0.0, variable=variable)
            project.set_Controls("parmMax", 10000.0, variable=variable)
        if args.mode == "joint_accepted":
            phase = project.phase(0)
            for i, atom in enumerate(phase.data["Atoms"]):
                atom[2] = "U"
                project.set_Controls(
                    "parmMin", 0.0, variable=f"{phase.data['pId']}::AUiso:{i}"
                )
                project.set_Controls(
                    "parmMax", 0.03, variable=f"{phase.data['pId']}::AUiso:{i}"
                )

    project.refine()
    project.save(args.output)
    describe(project, hist, "trial_only")

    common_on(project, hist)
    project.refine()
    project.save(args.output)
    describe(project, hist, "reconverged_common")

    project = G2sc.G2Project(gpxfile=args.output)
    project.refine()
    project.save(args.output)
    describe(project, project.histogram(0), "replay")


if __name__ == "__main__":
    main()
